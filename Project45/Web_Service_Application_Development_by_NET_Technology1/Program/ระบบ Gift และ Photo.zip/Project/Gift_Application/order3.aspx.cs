using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for order3.
	/// </summary>
	public class order3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.DropDownList DropDownList2;
		protected System.Web.UI.WebControls.DropDownList DropDownList3;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox TextBox3;
		protected System.Web.UI.WebControls.TextBox TextBox4;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.DropDownList DropDownList4;
		protected System.Web.UI.WebControls.DropDownList DropDownList5;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.DropDownList DropDownList6;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Label Label10;
		protected System.Web.UI.WebControls.Label Label11;
		protected System.Data.DataSet dataSet1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Gifts wb = new WebReference1.Gifts();
            WebReference1.contact[] contact = wb.get_contact_name(Convert.ToInt32(Session.Contents["a"]));
			int count=contact.Length;
			//dataSet1.Tables["table1"].Clear();			
			
			for(int i=0;i<count;i++)
			{
				DropDownList1.Items.Add(contact[i].contact_name);
			}

			DropDownList1.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			WebReference1.Gifts wb = new WebReference1.Gifts();
			int customer_id=Convert.ToInt32(Session["a"]);
			int contact_id=wb.get_contact_id(DropDownList1.SelectedItem.Text);
			string type_id=Convert.ToString(Request.QueryString["type_id"]);
			string subtype_id=Convert.ToString(Request.QueryString["subtype_id"]);
			string font_style=DropDownList2.SelectedItem.Text;
			string font_color=DropDownList3.SelectedItem.Text;
			string label=TextBox1.Text;
			string address=TextBox3.Text;
			int quantity=Convert.ToInt32(TextBox4.Text);
			string day=DropDownList4.SelectedItem.Text;
			if(day.Length==1)
				day="0"+day;
			string month="";
			if(DropDownList5.SelectedItem.Text=="���Ҥ�") month="01";
			else if (DropDownList5.SelectedItem.Text=="����Ҿѹ��") month="02";
			else if (DropDownList5.SelectedItem.Text=="�չҤ�") month="03";
			else if (DropDownList5.SelectedItem.Text=="����¹") month="04";
			else if (DropDownList5.SelectedItem.Text=="����Ҥ�") month="05";
			else if (DropDownList5.SelectedItem.Text=="�Զع�¹") month="06";
			else if (DropDownList5.SelectedItem.Text=="�á�Ҥ�") month="07";
			else if (DropDownList5.SelectedItem.Text=="�ԧ�Ҥ�") month="08";
			else if (DropDownList5.SelectedItem.Text=="�ѹ��¹") month="09";
			else if (DropDownList5.SelectedItem.Text=="���Ҥ�") month="10";
			else if (DropDownList5.SelectedItem.Text=="��Ȩԡ�¹") month="11";
			else if (DropDownList5.SelectedItem.Text=="�ѹ�Ҥ�") month="12";
			string year="";
			if(DropDownList6.SelectedItem.Text=="2546") year="2003";
			else if (DropDownList6.SelectedItem.Text=="2547") year="2004";
			string receivedateS=day+" "+month+" "+year+" "+"10:00:00";

			//WebReference1.job_order job_order=wb.order(customer_id,contact_id,type_id,subtype_id,font_style,font_color,label,receivedateS,address,quantity);
//			if(job_order==null)
//				Label10.Text="�������ö�ͧ�� ��سҵ�Ǩ�ͺ������";
//			else
//				Response.Redirect("order4.aspx?price="+job_order.price+"&dead_line="+job_order.dead_line);
//
			bool flag=wb.order2(customer_id,contact_id,type_id,subtype_id,font_style,font_color,label,receivedateS,address,quantity);
			if(!flag)
				Label10.Text="�������ö�ͧ�� ��سҵ�Ǩ�ͺ������";
			else
				Response.Redirect("order5.aspx");


            

		}
	}
}
