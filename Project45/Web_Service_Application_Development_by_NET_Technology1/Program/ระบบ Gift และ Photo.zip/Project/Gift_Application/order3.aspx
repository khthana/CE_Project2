<%@ Page language="c#" Codebehind="order3.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.order3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>order3</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="order3" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:dropdownlist id="DropDownList1" style="Z-INDEX: 101; LEFT: 242px; POSITION: absolute; TOP: 93px" runat="server" Width="159px" Height="37px"></asp:dropdownlist><asp:dropdownlist id="DropDownList6" style="Z-INDEX: 120; LEFT: 506px; POSITION: absolute; TOP: 368px" runat="server" Width="67px" Height="37px">
					<asp:ListItem>2546</asp:ListItem>
					<asp:ListItem>2547</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label9" style="Z-INDEX: 119; LEFT: 472px; POSITION: absolute; TOP: 369px" runat="server" Width="34px" Height="28px">��</asp:label>
				<asp:Label id="Label8" style="Z-INDEX: 118; LEFT: 304px; POSITION: absolute; TOP: 368px" runat="server" Width="34px" Height="28px">��͹</asp:Label>
				<asp:DropDownList id="DropDownList5" style="Z-INDEX: 117; LEFT: 356px; POSITION: absolute; TOP: 368px" runat="server" Width="100px" Height="37px">
					<asp:ListItem>���Ҥ�</asp:ListItem>
					<asp:ListItem>����Ҿѹ��</asp:ListItem>
					<asp:ListItem>�չҤ�</asp:ListItem>
					<asp:ListItem>����¹</asp:ListItem>
					<asp:ListItem>����Ҥ�</asp:ListItem>
					<asp:ListItem>�Զع�¹</asp:ListItem>
					<asp:ListItem>�á�Ҥ�</asp:ListItem>
					<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
					<asp:ListItem>�ѹ��¹</asp:ListItem>
					<asp:ListItem>���Ҥ�</asp:ListItem>
					<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
					<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label6" style="Z-INDEX: 114; LEFT: 125px; POSITION: absolute; TOP: 323px" runat="server" Width="88px" Height="32px">�ӹǹ���</asp:Label>
				<asp:TextBox id="TextBox4" style="Z-INDEX: 113; LEFT: 240px; POSITION: absolute; TOP: 320px" runat="server" Height="26px"></asp:TextBox>
				<asp:TextBox id="TextBox3" style="Z-INDEX: 112; LEFT: 240px; POSITION: absolute; TOP: 275px" runat="server" Height="26px"></asp:TextBox>
				<asp:Label id="Label5" style="Z-INDEX: 111; LEFT: 124px; POSITION: absolute; TOP: 273px" runat="server" Width="88px" Height="32px">�������</asp:Label>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 108; LEFT: 240px; POSITION: absolute; TOP: 222px" runat="server" Height="26px"></asp:TextBox>
				<asp:Label id="Label4" style="Z-INDEX: 110; LEFT: 123px; POSITION: absolute; TOP: 224px" runat="server" Width="88px" Height="32px">��ͤ���</asp:Label>
				<asp:DropDownList id="DropDownList3" style="Z-INDEX: 107; LEFT: 240px; POSITION: absolute; TOP: 181px" runat="server" Width="156px" Height="23px">
					<asp:ListItem>���</asp:ListItem>
					<asp:ListItem>����</asp:ListItem>
					<asp:ListItem>ᴧ</asp:ListItem>
					<asp:ListItem>����</asp:ListItem>
					<asp:ListItem>����ͧ</asp:ListItem>
					<asp:ListItem>�ͧ</asp:ListItem>
					<asp:ListItem>�Թ</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label3" style="Z-INDEX: 105; LEFT: 120px; POSITION: absolute; TOP: 127px" runat="server" Width="88px" Height="32px">Ẻ����ѡ��</asp:Label>
				<asp:table id="Table1" style="Z-INDEX: 103; LEFT: 124px; POSITION: absolute; TOP: 25px" runat="server" Width="262px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text=" ��͡��������´�����觫����Թ��� "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 120px; POSITION: absolute; TOP: 92px" runat="server" Width="108px" Height="26px">Contact Name</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 104; LEFT: 125px; POSITION: absolute; TOP: 177px" runat="server" Width="88px" Height="32px">�յ���ѡ��</asp:Label>
				<asp:DropDownList id="DropDownList2" style="Z-INDEX: 106; LEFT: 240px; POSITION: absolute; TOP: 134px" runat="server" Width="156px" Height="23px">
					<asp:ListItem>Angsana New</asp:ListItem>
					<asp:ListItem>Book Antiqua</asp:ListItem>
					<asp:ListItem>Cordia New</asp:ListItem>
					<asp:ListItem>Comic Sans MS</asp:ListItem>
					<asp:ListItem>Monotype Corsiva</asp:ListItem>
					<asp:ListItem>Times New Roman</asp:ListItem>
				</asp:DropDownList>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 109; LEFT: 240px; POSITION: absolute; TOP: 222px" runat="server" Height="26px"></asp:TextBox>
				<asp:Label id="Label7" style="Z-INDEX: 115; LEFT: 131px; POSITION: absolute; TOP: 372px" runat="server" Width="97px" Height="28px">�ѹ����Ѻ�Թ���</asp:Label>
				<asp:DropDownList id="DropDownList4" style="Z-INDEX: 116; LEFT: 240px; POSITION: absolute; TOP: 369px" runat="server" Width="46px" Height="37px">
					<asp:ListItem>1</asp:ListItem>
					<asp:ListItem>2</asp:ListItem>
					<asp:ListItem>3</asp:ListItem>
					<asp:ListItem>4</asp:ListItem>
					<asp:ListItem>5</asp:ListItem>
					<asp:ListItem>6</asp:ListItem>
					<asp:ListItem>7</asp:ListItem>
					<asp:ListItem>8</asp:ListItem>
					<asp:ListItem>9</asp:ListItem>
					<asp:ListItem>10</asp:ListItem>
					<asp:ListItem>11</asp:ListItem>
					<asp:ListItem>12</asp:ListItem>
					<asp:ListItem>13</asp:ListItem>
					<asp:ListItem>14</asp:ListItem>
					<asp:ListItem>15</asp:ListItem>
					<asp:ListItem>16</asp:ListItem>
					<asp:ListItem>17</asp:ListItem>
					<asp:ListItem>18</asp:ListItem>
					<asp:ListItem>19</asp:ListItem>
					<asp:ListItem>20</asp:ListItem>
					<asp:ListItem>21</asp:ListItem>
					<asp:ListItem>22</asp:ListItem>
					<asp:ListItem>23</asp:ListItem>
					<asp:ListItem>24</asp:ListItem>
					<asp:ListItem>25</asp:ListItem>
					<asp:ListItem>26</asp:ListItem>
					<asp:ListItem>27</asp:ListItem>
					<asp:ListItem>28</asp:ListItem>
					<asp:ListItem>29</asp:ListItem>
					<asp:ListItem>30</asp:ListItem>
					<asp:ListItem>31</asp:ListItem>
				</asp:DropDownList>
				<asp:Button id="Button1" style="Z-INDEX: 121; LEFT: 353px; POSITION: absolute; TOP: 464px" runat="server" Width="57px" Height="29px" Text="�ͧ"></asp:Button>
				<asp:Label id="Label10" style="Z-INDEX: 122; LEFT: 173px; POSITION: absolute; TOP: 465px" runat="server" Width="115px" Height="29px" ForeColor="Red"></asp:Label>
				<asp:Label id="Label11" style="Z-INDEX: 123; LEFT: 128px; POSITION: absolute; TOP: 412px" runat="server" Height="27px" Width="337px" ForeColor="#00C000">��س����͡�ѹ�Ѻ�Թ��� ���ҧ���¶Ѵ��ա 10 �ѹ</asp:Label></FONT></form>
	</body>
</HTML>
