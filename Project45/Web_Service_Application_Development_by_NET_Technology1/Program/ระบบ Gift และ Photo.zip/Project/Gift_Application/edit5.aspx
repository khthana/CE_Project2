<%@ Page language="c#" Codebehind="edit5.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.edit5" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>edit5</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="edit5" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 112px; POSITION: absolute; TOP: 34px" runat="server" Width="264px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text=" �ӡ������¹�ŧ��¡�� "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 119px; POSITION: absolute; TOP: 115px" runat="server" Width="260px" Height="80px" ForeColor="Red"></asp:Label></FONT>
		</form>
	</body>
</HTML>
