<%@ Page language="c#" Codebehind="pay2.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.pay2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>pay2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="pay2" method="post" runat="server">
			<asp:table id="Table1" style="Z-INDEX: 102; LEFT: 268px; POSITION: absolute; TOP: 52px" runat="server" Width="106px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
				<asp:TableRow>
					<asp:TableCell Text="
							�ӡ�è����Թ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:table>
			<asp:Label id="Label3" style="Z-INDEX: 108; LEFT: 165px; POSITION: absolute; TOP: 306px" runat="server" Width="114px" Height="24px">������� ��͹���</asp:Label>
			<asp:TextBox id="TextBox3" style="Z-INDEX: 105; LEFT: 434px; POSITION: absolute; TOP: 302px" runat="server" Width="57px" Height="28px"></asp:TextBox>
			<asp:TextBox id="TextBox2" style="Z-INDEX: 104; LEFT: 293px; POSITION: absolute; TOP: 301px" runat="server" Width="36px" Height="28px"></asp:TextBox>
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 168px; POSITION: absolute; TOP: 116px" runat="server" Width="289px" Height="32px" ForeColor="Red"></asp:Label>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 103; LEFT: 294px; POSITION: absolute; TOP: 186px" runat="server" Width="100px" Height="28px"></asp:TextBox>
			<asp:TextBox id="TextBox4" style="Z-INDEX: 106; LEFT: 297px; POSITION: absolute; TOP: 241px" runat="server" Width="99px" Height="27px"></asp:TextBox>
			<asp:Label id="Label2" style="Z-INDEX: 107; LEFT: 164px; POSITION: absolute; TOP: 188px" runat="server" Width="102px" Height="24px">�Ţ�ѵ��ôԵ</asp:Label>
			<asp:Label id="Label4" style="Z-INDEX: 109; LEFT: 351px; POSITION: absolute; TOP: 304px" runat="server" Width="67px" Height="24px">�շ��(�.�.)</asp:Label>
			<asp:Label id="Label5" style="Z-INDEX: 110; LEFT: 170px; POSITION: absolute; TOP: 252px" runat="server" Width="103px" Height="20px">�����Ѻ 4 ���</asp:Label>
			<asp:Button id="Button1" style="Z-INDEX: 111; LEFT: 295px; POSITION: absolute; TOP: 365px" runat="server" Width="68px" Height="29px" Text="����"></asp:Button>
		</form>
	</body>
</HTML>
