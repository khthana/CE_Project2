using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for left_customer.
	/// </summary>
	public class left_customer : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.Table Table2;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
	
		string[] picture={"431.jpg","441.jpg","511.jpg","751.jpg","811.jpg","111.jpg","311.jpg","351.jpg","631.jpg"};

		private void Page_Load(object sender, System.EventArgs e)
		{
			Random rd = new Random();
			int index=rd.Next(0,8);

			ImageButton1.ImageUrl="pic/"+picture[index];
			TableRow row= new TableRow();
			System.Web.UI.WebControls.TableCell cell = new TableCell();
			row.Cells.Add(cell);
			//Header
			WebReference1.Gifts wb = new WebReference1.Gifts();
			int customer_id=Convert.ToInt32(Session.Contents.Contents["a"]);
			string name=wb.get_name(customer_id);
			row.Cells[0].Text="<center>�Թ�յ�͹�Ѻ�س  "+name;
			Table2.Rows.Add(row);
			//Menu
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			DataRow rc = a.NewRow();
			rc["menu"] = "<center> <font color=black> <a href=make_contact.aspx target=main>"+" ���ҧ contact name</a>";
			a.Rows.Add(rc);	
			rc = a.NewRow();
			rc["menu"] = "<center> <font color=black> <a href=order.aspx target=main>"+" ����Թ���</a>";
			a.Rows.Add(rc);	
			rc = a.NewRow();
			rc["menu"] = "<center> <font color=black> <a href=pay.aspx target=main>"+" �����Թ</a>";
			a.Rows.Add(rc);	
			rc = a.NewRow();
			rc["menu"] = "<center> <font color=black> <a href=show.aspx target=main>"+" ����¡�÷�����</a>";
			a.Rows.Add(rc);
				rc = a.NewRow();
			rc["menu"] = "<center> <font color=black> <a href=edit.aspx target=main>"+" ����¹/¡��ԡ �����觨ͧ</a>";
			a.Rows.Add(rc);
				rc = a.NewRow();
			rc["menu"] = "<center> <font color=black> <a href=left_login.aspx>"+" �͡�ҡ�к�</a>";
			a.Rows.Add(rc);
			DataGrid1.DataSource=a;
			DataGrid1.DataBind();
			

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "menu";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
	}
}

