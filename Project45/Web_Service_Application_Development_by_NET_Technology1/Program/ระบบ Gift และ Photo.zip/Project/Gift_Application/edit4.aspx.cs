using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for edit4.
	/// </summary>
	public class edit4 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList DropDownList4;
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.DropDownList DropDownList5;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.DropDownList DropDownList6;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			//edit4.aspx?job_id="+gift_info.job_id+"&contact_id="+contact_id+"&subtype_detail="+gift_info.subtype_detail+"&label="+gift_info.label+"&address="+gift_info.address+"> edit";     
			int customer_id=Convert.ToInt32(Session["a"]);
			Session["job_id"]=Convert.ToInt32(Request.QueryString["job_id"]);
			Session["contact_id"]=Convert.ToInt32(Request.QueryString["contact_id"]);
			string subtype_detail=Convert.ToString(Session["subtype_detail"]);
			string address=Convert.ToString(Session["address"]);
			string label=Convert.ToString(Session["label"]);
			Label1.Text=subtype_detail;
			TextBox1.Text=Convert.ToString(Session["label"]);
			TextBox2.Text=Convert.ToString(Session["address"]);
			
			

			

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{

			Session["label"]=TextBox1.Text;
			Session["address"]=TextBox2.Text;
			string day=DropDownList4.SelectedItem.Text;
			if(day.Length==1)
				day="0"+day; 
			string month="";
			if(DropDownList5.SelectedItem.Text=="���Ҥ�") month="01";
			else if (DropDownList5.SelectedItem.Text=="����Ҿѹ��") month="02";
			else if (DropDownList5.SelectedItem.Text=="�չҤ�") month="03";
			else if (DropDownList5.SelectedItem.Text=="����¹") month="04";
			else if (DropDownList5.SelectedItem.Text=="����Ҥ�") month="05";
			else if (DropDownList5.SelectedItem.Text=="�Զع�¹") month="06";
			else if (DropDownList5.SelectedItem.Text=="�á�Ҥ�") month="07";
			else if (DropDownList5.SelectedItem.Text=="�ԧ�Ҥ�") month="08";
			else if (DropDownList5.SelectedItem.Text=="�ѹ��¹") month="09";
			else if (DropDownList5.SelectedItem.Text=="���Ҥ�") month="10";
			else if (DropDownList5.SelectedItem.Text=="��Ȩԡ�¹") month="11";
			else if (DropDownList5.SelectedItem.Text=="�ѹ�Ҥ�") month="12";
			string year="";
			if(DropDownList6.SelectedItem.Text=="2546") year="2003";
			else if (DropDownList6.SelectedItem.Text=="2547") year="2004";
			string receivedateS=day+" "+month+" "+year+" "+"10:00:00";
			Session["receivedateS"]=receivedateS;
			
			Response.Redirect("edit5.aspx");


		}
	}
}

