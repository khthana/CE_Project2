<%@ Page language="c#" Codebehind="search.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.search" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>search</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="search" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:DropDownList id="DropDownList1" style="Z-INDEX: 100; LEFT: 218px; POSITION: absolute; TOP: 86px" runat="server" Width="121px" Height="34px">
					<asp:ListItem Value="0">�ء��Դ</asp:ListItem>
					<asp:ListItem Value="1">��ͺ�ٻ</asp:ListItem>
					<asp:ListItem Value="2">��ش</asp:ListItem>
					<asp:ListItem Value="3">��¹</asp:ListItem>
					<asp:ListItem Value="4">�ǧ�ح�</asp:ListItem>
					<asp:ListItem Value="5">�ͧ������</asp:ListItem>
					<asp:ListItem Value="6">����</asp:ListItem>
					<asp:ListItem Value="7">��ش����¾� ���������</asp:ListItem>
					<asp:ListItem Value="8">���ͧ���ͧ˹�ҧҹ</asp:ListItem>
					<asp:ListItem Value="9">����</asp:ListItem>
				</asp:DropDownList>
				<asp:DropDownList id="DropDownList2" style="Z-INDEX: 111; LEFT: 217px; POSITION: absolute; TOP: 126px" runat="server" Height="34px" Width="121px">
					<asp:ListItem Value="0">�ءẺ</asp:ListItem>
					<asp:ListItem Value="1">�ҡ�</asp:ListItem>
					<asp:ListItem Value="2">��</asp:ListItem>
					<asp:ListItem Value="3">�չ</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label4" style="Z-INDEX: 110; LEFT: 106px; POSITION: absolute; TOP: 130px" runat="server" Height="23px" Width="77px">�ٻẺ</asp:Label>
				<asp:Table id="Table1" style="Z-INDEX: 109; LEFT: 86px; POSITION: absolute; TOP: 19px" runat="server" Width="348px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text="
							��سҡ�͡��Դ�ͧ�Թ��� ��Ъ�ǧ�Ҥҷ���ͧ���
						"></asp:TableCell>
					</asp:TableRow>
				</asp:Table>
				<asp:Label id="Label3" style="Z-INDEX: 106; LEFT: 107px; POSITION: absolute; TOP: 209px" runat="server" Width="77px" Height="23px">�Ҥ��٧�ش</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 105; LEFT: 106px; POSITION: absolute; TOP: 169px" runat="server" Width="77px" Height="23px">�Ҥҵ���ش</asp:Label>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 103; LEFT: 213px; POSITION: absolute; TOP: 208px" runat="server" Width="119px" Height="25px"></asp:TextBox>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 102; LEFT: 213px; POSITION: absolute; TOP: 164px" runat="server" Width="119px" Height="25px"></asp:TextBox>
				<asp:Label id="Label1" style="Z-INDEX: 104; LEFT: 108px; POSITION: absolute; TOP: 85px" runat="server" Width="77px" Height="23px">��Դ�Թ���</asp:Label>
				<asp:Button id="Button1" style="Z-INDEX: 107; LEFT: 193px; POSITION: absolute; TOP: 264px" runat="server" Width="66px" Height="34px" Text="����"></asp:Button>
				<IMG style="Z-INDEX: 108; LEFT: 461px; WIDTH: 200px; POSITION: absolute; TOP: 23px; HEIGHT: 321px" height="321" alt="" src="pic/o1.jpg" width="200"></FONT>
		</form>
	</body>
</HTML>
