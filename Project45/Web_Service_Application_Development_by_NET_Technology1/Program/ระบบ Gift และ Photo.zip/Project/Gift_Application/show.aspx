<%@ Page language="c#" Codebehind="show.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.show" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>show</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="show" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 103; LEFT: 186px; POSITION: absolute; TOP: 25px" runat="server" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White" Height="40px" Width="262px">
					<asp:TableRow>
						<asp:TableCell Text=" ��������´�����觫����Թ��Ңͧ�س "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 104; LEFT: 112px; POSITION: absolute; TOP: 112px" runat="server" BorderStyle="None" BackColor="White" BorderColor="#DEDFDE" GridLines="Vertical" DataSource="<%# dataTable1 %>" ForeColor="Black" CellPadding="4" BorderWidth="1px">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid></FONT></form>
	</body>
</HTML>
