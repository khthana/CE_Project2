<%@ Page language="c#" Codebehind="edit2.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.edit2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>edit2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="edit2" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 104; LEFT: 162px; POSITION: absolute; TOP: 121px" runat="server" DataSource="<%# dataTable1 %>" BorderWidth="1px" CellPadding="4" ForeColor="Black" GridLines="Vertical" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid>
				<asp:table id="Table1" style="Z-INDEX: 105; LEFT: 130px; POSITION: absolute; TOP: 43px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Height="40px" Width="338px">
					<asp:TableRow>
						<asp:TableCell Text=" ���͡ �ҹ ����ͧ���¡��ԡ��������¹�ŧ "></asp:TableCell>
					</asp:TableRow>
				</asp:table></FONT>
		</form>
	</body>
</HTML>
