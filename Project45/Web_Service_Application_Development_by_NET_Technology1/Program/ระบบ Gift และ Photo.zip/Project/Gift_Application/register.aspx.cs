using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for register.
	/// </summary>
	public class register : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label13;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.RadioButton RadioButton1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.TextBox TextBox3;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.RadioButton RadioButton2;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox TextBox4;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.TextBox TextBox5;
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.TextBox TextBox6;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.TextBox TextBox7;
		protected System.Web.UI.WebControls.Label Label10;
		protected System.Web.UI.WebControls.Label Label12;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.TextBox TextBox8;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			WebReference1.Gifts wb =new WebReference1.Gifts();
			string password=TextBox8.Text;
			string name=TextBox1.Text;
			string sur=TextBox3.Text;
			string address=TextBox2.Text;
			string sex;
			if (RadioButton1.Checked) sex="MALE";
			else sex="Female";
			int age=Convert.ToInt32(TextBox5.Text);
			string tel=TextBox6.Text;
			string email=TextBox4.Text;
			string uname=TextBox7.Text;
			int result=wb.signup(uname,password,name,sur,sex,age,tel,address,email);
			
			
			if (result!=0) Response.Redirect("regist_complete.aspx?id="+result);
			else 
			{
				Label13.Text="ŧ����¹�Դ��Ҵ ��سҵ�Ǩ�ͺ����������";
			}
		}
	}
}
