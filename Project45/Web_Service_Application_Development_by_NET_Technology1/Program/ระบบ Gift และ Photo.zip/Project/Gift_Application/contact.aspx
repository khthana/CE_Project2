<%@ Page language="c#" Codebehind="contact.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.contact" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>contact</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="contact" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Table id="Table1" style="Z-INDEX: 101; LEFT: 233px; POSITION: absolute; TOP: 68px" runat="server" Width="196px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text="
							�Դ��� ��������´�������
						"></asp:TableCell>
					</asp:TableRow>
				</asp:Table>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 159px; POSITION: absolute; TOP: 144px" runat="server" Height="93px" Width="363px">Label</asp:Label>
				<br>
				<br>
				<br>
				<br>
				<br>
				<br>
				<td>
					<div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"> <font color="#999999">
								GIFT REGISTRIES SHOP<br>
								Web Contact: bank_pic@yahoo.com Homepage: <a href="http://161.246.6.125/Project/Gift_Application/index2.htm">
									OLALA GIFT SHOP </a>ICQ: 5779584 MSN: bnets@hotmail.com Tel.0-2864-3446</font></font></div>
				</td>
		</form>
		</FONT>
	</body>
</HTML>
