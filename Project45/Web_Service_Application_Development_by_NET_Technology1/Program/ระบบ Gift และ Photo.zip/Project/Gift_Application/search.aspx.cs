using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for search.
	/// </summary>
	public class search : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.DropDownList DropDownList2;
		protected System.Web.UI.WebControls.Label Label3;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			string tid="",style="";
			double min,max;
			if(DropDownList1.SelectedItem.Text=="�ء��Դ") tid="0";
			else if (DropDownList1.SelectedItem.Text=="��ͺ�ٻ") tid="1";
			else if (DropDownList1.SelectedItem.Text=="��ش") tid="2";
			else if (DropDownList1.SelectedItem.Text=="��¹") tid="3";
			else if (DropDownList1.SelectedItem.Text=="�ǧ�ح�") tid="4";
			else if (DropDownList1.SelectedItem.Text=="�ͧ������") tid="5";
			else if (DropDownList1.SelectedItem.Text=="����") tid="6";
			else if (DropDownList1.SelectedItem.Text=="��ش����¾ä��������") tid="7";
			else if (DropDownList1.SelectedItem.Text=="���ͧ���ͧ˹�ҧҹ") tid="8";
			else if (DropDownList1.SelectedItem.Text=="����") tid="9";
			
			if(DropDownList2.SelectedItem.Text=="�ءẺ") style="";
			else if (DropDownList1.SelectedItem.Text=="�ҡ�") style="international";
			else if (DropDownList1.SelectedItem.Text=="��") style="thai";
			else if (DropDownList1.SelectedItem.Text=="�չ") style="chinese";
			

			min=Convert.ToInt32(TextBox1.Text);
			max=Convert.ToInt32(TextBox2.Text);
			string test="search_result.aspx?type_id="+tid+"&style="+style+"&min="+min+"&max="+max;
			Response.Redirect("search_result.aspx?type_id="+tid+"&style="+style+"&min="+min+"&max="+max);
		}
	}
}
