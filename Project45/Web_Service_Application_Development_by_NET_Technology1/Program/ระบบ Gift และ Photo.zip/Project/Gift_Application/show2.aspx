<%@ Page language="c#" Codebehind="show2.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.show2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>show2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="show2" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 197px; POSITION: absolute; TOP: 47px" runat="server" Width="315px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text=" ��������´�����觫����Թ��Ңͧ�س� contact"></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 104; LEFT: 254px; POSITION: absolute; TOP: 120px" runat="server" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None" DataSource="<%# dataTable1 %>" BorderWidth="1px" CellPadding="4" ForeColor="Black" GridLines="Vertical">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid></FONT>
		</form>
	</body>
</HTML>
