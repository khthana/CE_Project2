<%@ Page language="c#" Codebehind="order.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.order_aspx" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>order</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="order" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 111; LEFT: 135px; POSITION: absolute; TOP: 45px" runat="server" Width="257px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text=" ��س����͡��Ǵ�Թ��ҷ���ͧ��èͧ "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:HyperLink id="HyperLink9" style="Z-INDEX: 110; LEFT: 406px; POSITION: absolute; TOP: 203px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=9">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink8" style="Z-INDEX: 109; LEFT: 406px; POSITION: absolute; TOP: 164px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=8">���ͧ���ͧ</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 108; LEFT: 406px; POSITION: absolute; TOP: 114px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=7">��ش��¾�</asp:HyperLink>
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 107; LEFT: 206px; POSITION: absolute; TOP: 203px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=6">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 106; LEFT: 201px; POSITION: absolute; TOP: 162px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=5">�ͧ������</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 105; LEFT: 206px; POSITION: absolute; TOP: 117px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=4">�ǧ�ح�</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 104; LEFT: 40px; POSITION: absolute; TOP: 199px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=3">��¹</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 103; LEFT: 40px; POSITION: absolute; TOP: 159px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=2">��ش�������</asp:HyperLink>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 101; LEFT: 40px; POSITION: absolute; TOP: 116px" runat="server" Width="166px" Height="26px" NavigateUrl="order2.aspx?type_id=1">��ͺ�ٻ</asp:HyperLink></FONT></form>
	</body>
</HTML>
