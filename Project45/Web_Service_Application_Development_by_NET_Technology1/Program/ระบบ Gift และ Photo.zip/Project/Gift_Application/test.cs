//private void Page_Load(object sender, System.EventArgs e)
//		{
//			// Put user code to initialize the page here
//			HotelRef.HotelService0 Job = new HotelRef.HotelService0();
//			object scon_id  =  Session.Contents["contact_id"];
//			object scus_id  =  Session.Contents["customer_id"];
//			int contact_id  = System.Convert.ToInt32(scon_id);
//			int customer_id = System.Convert.ToInt32(scus_id);
//
//			Job.Show_All_Reserved_Info(customer_id,contact_id);
//			
//			int room_count    = Job.Show_All_Reserved_Info(customer_id,contact_id).room_job_id.Length;
//			int seminar_count = Job.Show_All_Reserved_Info(customer_id,contact_id).seminar_room_job_id.Length;
//			int cake_count    = Job.Show_All_Reserved_Info(customer_id,contact_id).cake_job_id.Length;
//			int food_count    = Job.Show_All_Reserved_Info(customer_id,contact_id).food_job_id.Length;
//			int flower_count  = Job.Show_All_Reserved_Info(customer_id,contact_id).flower_job_id.Length;
//						
//			HotelRef.CShowAllJobid x = new HotelRef.CShowAllJobid();
//
//			x.room_job_id = new Int32[room_count];
//			x.seminar_room_job_id = new Int32[seminar_count];
//			x.cake_job_id = new Int32[cake_count];
//			x.food_job_id = new Int32[food_count];
//			x.flower_job_id = new Int32[flower_count];			
//			// Insert into my class
//			for(int i=0; i<room_count; i++)
//				x.room_job_id[i] = Job.Show_All_Reserved_Info(customer_id,contact_id).room_job_id[i];				
//			for(int i=0; i<seminar_count; i++)
//				x.seminar_room_job_id[i] = Job.Show_All_Reserved_Info(customer_id,contact_id).seminar_room_job_id[i];
//			for(int i=0; i<cake_count; i++)
//				x.cake_job_id[i] = Job.Show_All_Reserved_Info(customer_id,contact_id).cake_job_id[i];
//			for(int i=0; i<food_count; i++)
//				x.food_job_id[i] = Job.Show_All_Reserved_Info(customer_id,contact_id).food_job_id[i];
//			for(int i=0; i<flower_count; i++)
//				x.flower_job_id[i] = Job.Show_All_Reserved_Info(customer_id,contact_id).flower_job_id[i];
//			
//			dataSet1.Tables["tblAllJob"].Clear();			
//			DataTable a = dataSet1.Tables["tblAllJob"];
//			// "room" Insert into DataGrid
//			for(int r=0; r<room_count; r++)
//			{	
//				string roomname;
//				HotelRef.HotelService0 srt = new HotelRef.HotelService0();
//				roomname = srt.Show_RoomType(x.room_job_id[r]);
//				
//				DataRow rc = a.NewRow();
//
//				rc["Job Id"]   = x.room_job_id[r];
//				rc["Job Name"] = roomname;
//
//				a.Rows.Add(rc);			
//			}
//
//			// "seminar" Insert into DataGrid
//			for(int r=0; r<seminar_count; r++)
//			{
//				string seminarroomname;
//				HotelRef.HotelService0 srt = new HotelRef.HotelService0();
//				seminarroomname = srt.Show_SeminarRoom_Name(x.seminar_room_job_id[r]);
//				
//				DataRow rc = a.NewRow();
//
//				rc["Job Id"]   = x.seminar_room_job_id[r];
//				rc["Job Name"] = seminarroomname;
//
//				a.Rows.Add(rc);			
//			}
//			DataGrid1.DataBind (); // Bind it!		
//		}
//
//		#region Web Form Designer generated code
//		override protected void OnInit(EventArgs e)
//		{
//			//
//			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
//			//
//			InitializeComponent();
//			base.OnInit(e);
//		}
//		
//		/// <summary>
//		/// Required method for Designer support - do not modify
//		/// the contents of this method with the code editor.
//		/// </summary>
//		private void InitializeComponent()
//		{    
//			this.dataSet1 = new System.Data.DataSet();
//			this.dataTable1 = new System.Data.DataTable();
//			this.dataColumn1 = new System.Data.DataColumn();
//			this.dataColumn2 = new System.Data.DataColumn();
//			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
//			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
//			// 
//			// dataSet1
//			// 
//			this.dataSet1.DataSetName = "NewDataSet";
//			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
//			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
//																		  this.dataTable1});
//			// 
//			// dataTable1
//			// 
//			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
//																			  this.dataColumn1,
//																			  this.dataColumn2});
//			this.dataTable1.TableName = "tblAllJob";
//			// 
//			// dataColumn1
//			// 
//			this.dataColumn1.Caption = "Job ID";
//			this.dataColumn1.ColumnName = "Job Id";
//			// 
//			// dataColumn2
//			// 
//			this.dataColumn2.Caption = "Job Name";
//			this.dataColumn2.ColumnName = "Job Name";
//			this.Load += new System.EventHandler(this.Page_Load);
//			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
//			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
//
//		}
//		#endregion
