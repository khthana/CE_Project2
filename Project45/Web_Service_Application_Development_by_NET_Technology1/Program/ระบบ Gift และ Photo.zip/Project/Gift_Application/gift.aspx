<%@ Page language="c#" Codebehind="gift.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.gift" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>gift</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="gift" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 100; LEFT: 204px; POSITION: absolute; TOP: 32px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Height="40px" Width="156px">
					<asp:TableRow>
						<asp:TableCell Text=" ��������´�Թ��ҷ���� "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:HyperLink id="HyperLink9" style="Z-INDEX: 110; LEFT: 406px; POSITION: absolute; TOP: 203px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=9">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink8" style="Z-INDEX: 109; LEFT: 406px; POSITION: absolute; TOP: 164px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=8">���ͧ���ͧ</asp:HyperLink>
				<asp:HyperLink id="HyperLink7" style="Z-INDEX: 108; LEFT: 406px; POSITION: absolute; TOP: 114px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=7">��ش��¾�</asp:HyperLink>
				<asp:HyperLink id="HyperLink6" style="Z-INDEX: 107; LEFT: 206px; POSITION: absolute; TOP: 203px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=6">����</asp:HyperLink>
				<asp:HyperLink id="HyperLink5" style="Z-INDEX: 106; LEFT: 201px; POSITION: absolute; TOP: 162px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=5">�ͧ������</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 105; LEFT: 206px; POSITION: absolute; TOP: 117px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=4">�ǧ�ح�</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 104; LEFT: 40px; POSITION: absolute; TOP: 199px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=3">��¹</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 103; LEFT: 40px; POSITION: absolute; TOP: 159px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=2">��ش�������</asp:HyperLink>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 101; LEFT: 40px; POSITION: absolute; TOP: 116px" runat="server" Height="26px" Width="166px" NavigateUrl="gift2.aspx?type_id=1">��ͺ�ٻ</asp:HyperLink></FONT>
		</form>
	</body>
</HTML>
