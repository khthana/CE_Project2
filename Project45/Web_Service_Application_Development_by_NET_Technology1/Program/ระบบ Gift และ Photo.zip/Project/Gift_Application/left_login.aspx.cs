using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for left1.
	/// </summary>
	public class left1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.ImageButton ImageButton1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		string[] picture={"431.jpg","441.jpg","511.jpg","751.jpg","811.jpg","111.jpg","311.jpg","351.jpg","631.jpg"};

		private void Page_Load(object sender, System.EventArgs e)
		{
			//Load Picture
			Random rd = new Random();
			int index=rd.Next(0,8);
			ImageButton1.ImageUrl="pic/"+picture[index];
			//Clear Session 
			Session.Contents["a"]="";
				
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			WebReference1.Gifts wb = new WebReference1.Gifts();
			string username=TextBox1.Text;
			string password=TextBox2.Text;
			int customer_id=wb.login(username,password);
			if(customer_id>0)
			{
				Session.Contents["a"]=customer_id;
				Response.Redirect("left_customer.aspx");
			}
			else 
			{
				Label3.Text="��������͡�Թ�Դ��Ҵ";
			}

		}

	}
}
