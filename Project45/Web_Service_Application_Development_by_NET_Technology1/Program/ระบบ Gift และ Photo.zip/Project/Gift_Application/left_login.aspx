<%@ Page language="c#" Codebehind="left_login.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.left1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>left1</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="left1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:textbox id="TextBox1" style="Z-INDEX: 101; LEFT: 99px; POSITION: absolute; TOP: 116px" runat="server" Width="75px" Height="27px"></asp:textbox><asp:table id="Table1" style="Z-INDEX: 106; LEFT: 32px; POSITION: absolute; TOP: 22px" runat="server" Width="131px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text="
							��͡�Թ�������к�
						"></asp:TableCell>
					</asp:TableRow>
				</asp:table><asp:textbox id="TextBox2" style="Z-INDEX: 104; LEFT: 100px; POSITION: absolute; TOP: 170px" runat="server" Width="73px" Height="27px" TextMode="Password"></asp:textbox><asp:label id="Label2" style="Z-INDEX: 103; LEFT: 22px; POSITION: absolute; TOP: 175px" runat="server" Width="74px" Height="33px">password</asp:label><asp:label id="Label1" style="Z-INDEX: 102; LEFT: 22px; POSITION: absolute; TOP: 119px" runat="server" Width="72px" Height="33px">username</asp:label><asp:button id="Button1" style="Z-INDEX: 105; LEFT: 73px; POSITION: absolute; TOP: 220px" runat="server" Height="29px" Text="Login"></asp:button><asp:imagebutton id="ImageButton1" style="Z-INDEX: 107; LEFT: 25px; POSITION: absolute; TOP: 313px" runat="server" Width="152px" Height="141px"></asp:imagebutton><asp:label id="Label3" style="Z-INDEX: 108; LEFT: 24px; POSITION: absolute; TOP: 77px" runat="server" Width="140px" Height="30px" ForeColor="Red"></asp:label><asp:hyperlink id="HyperLink1" style="Z-INDEX: 109; LEFT: 48px; POSITION: absolute; TOP: 267px" runat="server" Width="120px" Height="24px" Target="main" NavigateUrl="register.aspx">��Ѥ���Ҫԡ����</asp:hyperlink></FONT></form>
	</body>
</HTML>
