<%@ Page language="c#" Codebehind="order5.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.order5" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>order4</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="order4" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 201px; POSITION: absolute; TOP: 49px" runat="server" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White" Height="40px" Width="300px">
					<asp:TableRow>
						<asp:TableCell Text=" �ӡ������Թ������º���� �ͺ�س������ԡ�� "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:Label id="Label2" style="Z-INDEX: 103; LEFT: 78px; POSITION: absolute; TOP: 164px" runat="server" Height="48px" Width="581px" ForeColor="Magenta">Label</asp:Label></FONT>
		</form>
	</body>
</HTML>
