using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for gift2.
	/// </summary>
	public class gift2 : System.Web.UI.Page
	{
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataColumn dataColumn5;
		protected System.Data.DataColumn dataColumn6;
		protected System.Web.UI.WebControls.Table Table2;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
		
			
			// Put user code to initialize the page here
			string type_id=Request.QueryString["type_id"];
			string style="";
			double min =0;
			double max =100000;
			WebReference1.Gifts wb = new WebReference1.Gifts();

			WebReference1.GiftInfo[] gift_info=	wb.gift_detail(type_id,style,min,max);
			int count=gift_info.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			string group="";
			for(int i=0;i<count;i++)
			{
				DataRow rc = a.NewRow();
				rc["��Ǵ�Թ���"] = gift_info[i].type_name;
				group=gift_info[i].type_name;;
				rc["��Դ"] =gift_info[i].subtype_name;
				rc["��������´"] =gift_info[i].subtype_detail;
				rc["�Ҥ�"] =gift_info[i].price;
				int index=gift_info[i].pic_url.Length;
				string picture_large=gift_info[i].pic_url.Insert(index-4,"1");
				rc["�ٻ������ҧ"] ="<a href="+picture_large+" target=_blank> <img src ="+gift_info[i].pic_url+">";
				a.Rows.Add(rc);		
			}
			//Header
			TableRow row= new TableRow();
			System.Web.UI.WebControls.TableCell cell = new TableCell();
			row.Cells.Add(cell);
			//Header
			int customer_id=Convert.ToInt32(Session.Contents.Contents["a"]);
			string name=wb.get_name(customer_id);
			row.Cells[0].Text="<center> ��Ǵ "+group;
			Table2.Rows.Add(row);
			DataGrid2.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn3,
																			  this.dataColumn4,
																			  this.dataColumn5,
																			  this.dataColumn6});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.Caption = "��Ǵ�Թ���";
			this.dataColumn1.ColumnName = "��Ǵ�Թ���";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "��Դ";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "��������´";
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "�Ҥ�";
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "�ٻ������ҧ";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
	}
}
