using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for edit5.
	/// </summary>
	public class edit5 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			int customer_id=Convert.ToInt32(Session["a"]);
			int job_id=Convert.ToInt32(Session["job_id"]);
			int contact_id=Convert.ToInt32(Session["contact_id"]);
			string subtype_detail=Convert.ToString(Session["subtype_detail"]);
			string address=Convert.ToString(Session["address"]);
			string label=Convert.ToString(Session["label"]);
			string receivedateS=Convert.ToString(Session["receivedateS"]);

			WebReference1.Gifts wb = new WebReference1.Gifts();
			WebReference1.job_order a= wb.edit_order(customer_id,contact_id,job_id,receivedateS,address,label);
			if(a.job_id>0)
				Label1.Text="�ӡ������¹�ŧ��¡�����º����";
			else
				Label1.Text="�������ö�ӡ������¹�ŧ��";

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
