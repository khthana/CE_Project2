using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for pay.
	/// </summary>
	public class pay : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Gifts wb = new WebReference1.Gifts();
			int customer_id=Convert.ToInt32(Session["a"]);
			//int contact_id=Convert.ToInt32(Request.QueryString["contact_id"]);
			WebReference1.pay_contact[] gift_info= wb.contact_pay(customer_id);
			int count=gift_info.Length;
			if(count!=0)
			{
				dataSet1.Tables["table1"].Clear();			
				DataTable a = dataSet1.Tables["table1"];
				for(int i=0;i<count;i++)
				{
					
						DataRow rc = a.NewRow();
						rc["contact name"] =gift_info[i].contact_name;
						rc["�ӹǹ�Թ"] =gift_info[i].price;
						rc["����"] ="<a href=pay2.aspx?contact_id="+gift_info[i].contact_id+"> ����";
						a.Rows.Add(rc);		
				}
				DataGrid2.DataBind();
			}else
				Label1.Text="�������¡��㴤�ҧ����";

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "contact name";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "�ӹǹ�Թ";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "����";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
	}
}
