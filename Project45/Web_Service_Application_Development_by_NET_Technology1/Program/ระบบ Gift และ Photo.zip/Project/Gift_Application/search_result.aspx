<%@ Page language="c#" Codebehind="search_result.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.search_result" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>search_result</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="search_result" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Table id="Table1" style="Z-INDEX: 101; LEFT: 250px; POSITION: absolute; TOP: 35px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Width="100px" Height="40px">
					<asp:TableRow>
						<asp:TableCell Text="
							�š�ä���
						"></asp:TableCell>
					</asp:TableRow>
				</asp:Table>
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 102; LEFT: 94px; POSITION: absolute; TOP: 99px" runat="server" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None" BorderWidth="1px" CellPadding="4" ForeColor="Black" DataSource="<%# dataTable1 %>" GridLines="Vertical">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid></FONT>
		</form>
	</body>
</HTML>
