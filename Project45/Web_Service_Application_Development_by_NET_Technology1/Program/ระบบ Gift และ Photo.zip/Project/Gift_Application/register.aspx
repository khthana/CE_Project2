<%@ Page language="c#" Codebehind="register.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.register" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>register</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="register" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:TextBox id="TextBox8" style="Z-INDEX: 122; LEFT: 356px; POSITION: absolute; TOP: 348px" runat="server" MaxLength="15" TextMode="Password" Height="26px" Width="111px"></asp:TextBox>
				<asp:table id="Table1" style="Z-INDEX: 123; LEFT: 153px; POSITION: absolute; TOP: 46px" runat="server" Width="281px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text=" ��Ѥ���Ҫԡ���� ��س� ��͡���������ú��ǹ"></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:Label id="Label12" style="Z-INDEX: 119; LEFT: 265px; POSITION: absolute; TOP: 354px" runat="server" Height="21px" Width="66px">���ʼ�ҹ</asp:Label>
				<asp:Label id="Label10" style="Z-INDEX: 118; LEFT: 54px; POSITION: absolute; TOP: 354px" runat="server" Height="21px" Width="66px">���ͼ����</asp:Label>
				<asp:TextBox id="TextBox7" style="Z-INDEX: 117; LEFT: 120px; POSITION: absolute; TOP: 351px" runat="server" MaxLength="15" Height="26px" Width="111px"></asp:TextBox>
				<asp:Label id="Label9" style="Z-INDEX: 116; LEFT: 59px; POSITION: absolute; TOP: 310px" runat="server" Height="21px" Width="61px">���Ѿ��</asp:Label>
				<asp:TextBox id="TextBox6" style="Z-INDEX: 115; LEFT: 121px; POSITION: absolute; TOP: 306px" runat="server" MaxLength="20" Height="26px" Width="111px"></asp:TextBox>
				<asp:Label id="Label8" style="Z-INDEX: 114; LEFT: 388px; POSITION: absolute; TOP: 271px" runat="server" Height="21px" Width="30px">��</asp:Label>
				<asp:Label id="Label7" style="Z-INDEX: 113; LEFT: 291px; POSITION: absolute; TOP: 271px" runat="server" Height="21px" Width="30px">����</asp:Label>
				<asp:TextBox id="TextBox5" style="Z-INDEX: 112; LEFT: 335px; POSITION: absolute; TOP: 267px" runat="server" MaxLength="15" Height="26px" Width="40px"></asp:TextBox>
				<asp:Label id="Label6" style="Z-INDEX: 111; LEFT: 264px; POSITION: absolute; TOP: 309px" runat="server" Height="21px" Width="50px">������</asp:Label>
				<asp:TextBox id="TextBox4" style="Z-INDEX: 110; LEFT: 356px; POSITION: absolute; TOP: 305px" runat="server" MaxLength="50" Height="26px" Width="111px"></asp:TextBox>
				<asp:Label id="Label4" style="Z-INDEX: 109; LEFT: 63px; POSITION: absolute; TOP: 268px" runat="server" Height="21px" Width="30px">��</asp:Label>
				<asp:RadioButton id="RadioButton2" style="Z-INDEX: 108; LEFT: 199px; POSITION: absolute; TOP: 270px" runat="server" Height="10px" Width="55px" Text="˭ԧ"></asp:RadioButton>
				<asp:Label id="Label3" style="Z-INDEX: 106; LEFT: 63px; POSITION: absolute; TOP: 172px" runat="server" Height="21px" Width="30px">�������</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 103; LEFT: 252px; POSITION: absolute; TOP: 130px" runat="server" Height="21px" Width="25px">ʡ��</asp:Label>
				<asp:TextBox id="TextBox3" style="Z-INDEX: 101; LEFT: 290px; POSITION: absolute; TOP: 129px" runat="server" MaxLength="50" Height="26px" Width="175px"></asp:TextBox>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 100; LEFT: 121px; POSITION: absolute; TOP: 129px" runat="server" MaxLength="30" Height="26px" Width="111px"></asp:TextBox>
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 65px; POSITION: absolute; TOP: 129px" runat="server" Height="21px" Width="25px">����</asp:Label>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 105; LEFT: 120px; POSITION: absolute; TOP: 175px" runat="server" Height="80px" Width="256px" MaxLength="300"></asp:TextBox>
				<asp:RadioButton id="RadioButton1" style="Z-INDEX: 107; LEFT: 122px; POSITION: absolute; TOP: 269px" runat="server" Height="10px" Width="51px" Text="���"></asp:RadioButton>
				<asp:Button id="Button1" style="Z-INDEX: 120; LEFT: 286px; POSITION: absolute; TOP: 403px" runat="server" Height="27px" Width="74px" Text="ŧ����¹"></asp:Button>
				<asp:Label id="Label13" style="Z-INDEX: 121; LEFT: 92px; POSITION: absolute; TOP: 397px" runat="server" Height="35px" Width="150px" ForeColor="Red"></asp:Label></FONT>
		</form>
	</body>
</HTML>
