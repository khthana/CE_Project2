<%@ Page language="c#" Codebehind="make_contact.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.make_contact" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>make_contact</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="make_contact" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:textbox id="TextBox1" style="Z-INDEX: 101; LEFT: 257px; POSITION: absolute; TOP: 121px" runat="server" Width="102px" Height="30px"></asp:textbox><asp:table id="Table1" style="Z-INDEX: 104; LEFT: 86px; POSITION: absolute; TOP: 40px" runat="server" Width="325px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text=" ���ҧ Contact Name �������㹡������Թ��� "></asp:TableCell>
					</asp:TableRow>
				</asp:table><asp:label id="Label1" style="Z-INDEX: 102; LEFT: 113px; POSITION: absolute; TOP: 125px" runat="server" Width="118px" Height="37px" Font-Bold="True" ForeColor="#C000C0">Contact Name</asp:label><asp:button id="Button1" style="Z-INDEX: 103; LEFT: 208px; POSITION: absolute; TOP: 184px" runat="server" Width="68px" Height="30px" Text="���ҧ"></asp:button></FONT></form>
	</body>
</HTML>
