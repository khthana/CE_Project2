<%@ Page language="c#" Codebehind="pay.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.pay" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>regist_complete</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="regist_complete" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 203px; POSITION: absolute; TOP: 44px" runat="server" Width="214px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text="
							��¡���Թ��ҷ���ѧ���������Թ
						"></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:DataGrid id=DataGrid2 style="Z-INDEX: 102; LEFT: 185px; POSITION: absolute; TOP: 151px" runat="server" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None" GridLines="Vertical" DataSource="<%# dataTable1 %>" ForeColor="Black" CellPadding="4" BorderWidth="1px">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:DataGrid>
				<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 245px; POSITION: absolute; TOP: 104px" runat="server" Height="32px" Width="129px"></asp:Label></FONT>
		</form>
	</body>
</HTML>
