using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for show.
	/// </summary>
	public class show : System.Web.UI.Page
	{
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataColumn dataColumn6;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Data.DataColumn dataColumn1;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Gifts wb = new WebReference1.Gifts();
			int customer_id=Convert.ToInt32(Session["a"]);
			WebReference1.customer_id_info[] gift_info= wb.showorder_by_customer_id(customer_id);
			
			int count=gift_info.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			string z="";
			for(int i=0;i<count;i++)
			{
				z="";
				DataRow rc = a.NewRow();
				rc["contact name"] = "<a href=show2.aspx?contact_id="+gift_info[i].contact_id+">"+gift_info[i].contact_name;
				rc["�Ҥҷ�����"] =gift_info[i].totalPrice;
				//int index=gift_info[i].pic_url.Length;
				//string picture_large=gift_info[i].pic_url.Insert(index-4,"1");
				for(int j=0;j<gift_info[i].deadline.Length-6;j++)
					z=z+gift_info[i].deadline[j];
				rc["�ѹ��˹������Թ"] =z;
				a.Rows.Add(rc);		
			}
			DataGrid2.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn1 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn4,
																			  this.dataColumn6,
																			  this.dataColumn1});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "contact name";
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "�Ҥҷ�����";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "�ѹ��˹������Թ";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
	}
}
