using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Gift_Application
{
	/// <summary>
	/// Summary description for cancle2.
	/// </summary>
	public class cancle2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			int customer_id =Convert.ToInt32(Session["a"]);
			int contact_id = Convert.ToInt32(Request.QueryString["contact_id"]);
			int job_id = Convert.ToInt32(Request.QueryString["job_id"]);
			WebReference1.Gifts wb = new WebReference1.Gifts();
			bool can_cancle=wb.order_cancle_job(customer_id,contact_id,job_id);
			if(can_cancle)
				Label1.Text="�ӡ��¡��ԡ�����觫��� ���º��������";
			else
				Label1.Text="���¡��ԡ�Դ��Ҵ �������ö�ӡ��¡��ԡ��";
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
