<%@ Page language="c#" Codebehind="pay3.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.pay3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>pay3</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="pay3" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 275px; POSITION: absolute; TOP: 50px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Height="40px" Width="163px">
					<asp:TableRow>
						<asp:TableCell Text="
							�ӡ�è����Թ���º����
						"></asp:TableCell>
					</asp:TableRow>
				</asp:table><IMG style="Z-INDEX: 102; LEFT: 239px; WIDTH: 257px; POSITION: absolute; TOP: 150px; HEIGHT: 194px" height="194" alt="" src="pic/111.jpg" width="257"></FONT>
		</form>
	</body>
</HTML>
