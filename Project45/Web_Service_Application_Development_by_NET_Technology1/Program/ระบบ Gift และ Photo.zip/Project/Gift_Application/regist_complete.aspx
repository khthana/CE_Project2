<%@ Page language="c#" Codebehind="regist_complete.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.regist_complete" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>regist_complete</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="regist_complete" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 106; LEFT: 158px; POSITION: absolute; TOP: 81px" runat="server" Width="272px" Height="40px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text="
							ŧ����¹���º���� ��س���͡�Թ�������к�
						"></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:ImageButton id="ImageButton1" style="Z-INDEX: 107; LEFT: 170px; POSITION: absolute; TOP: 184px" runat="server" Width="251px" Height="184px" ImageUrl="http://161.246.6.125/Project\Gift_Application\pic\441.jpg"></asp:ImageButton></FONT>
		</form>
	</body>
</HTML>
