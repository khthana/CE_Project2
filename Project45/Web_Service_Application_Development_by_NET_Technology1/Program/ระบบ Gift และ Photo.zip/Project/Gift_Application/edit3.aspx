<%@ Page language="c#" Codebehind="edit3.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.edit3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>edit3</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ffb7b7" MS_POSITIONING="GridLayout">
		<form id="edit3" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:datagrid id=DataGrid2 style="Z-INDEX: 104; LEFT: 9px; POSITION: absolute; TOP: 146px" runat="server" BorderColor="#DEDFDE" BackColor="White" BorderStyle="None" DataSource="<%# dataTable1 %>" BorderWidth="1px" CellPadding="4" ForeColor="Black" GridLines="Vertical">
					<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#CE5D5A"></SelectedItemStyle>
					<AlternatingItemStyle BackColor="White"></AlternatingItemStyle>
					<ItemStyle BackColor="#F7F7DE"></ItemStyle>
					<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#6B696B"></HeaderStyle>
					<FooterStyle BackColor="#CCCC99"></FooterStyle>
					<PagerStyle HorizontalAlign="Right" ForeColor="Black" BackColor="#F7F7DE" Mode="NumericPages"></PagerStyle>
				</asp:datagrid><asp:table id="Table1" style="Z-INDEX: 105; LEFT: 118px; POSITION: absolute; TOP: 55px" runat="server" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted" Width="264px" Height="40px">
					<asp:TableRow>
						<asp:TableCell Text=" ��������´�����觫����Թ��Ңͧ�س ��س����͡ �ҹ ����ͧ���¡��ԡ��������¹�ŧ "></asp:TableCell>
					</asp:TableRow>
				</asp:table></FONT></form>
	</body>
</HTML>
