<%@ Page language="c#" Codebehind="edit4.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.edit4" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>edit4</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="edit4" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 148px; POSITION: absolute; TOP: 36px" runat="server" Width="264px" Height="40px" BorderColor="White" BackColor="#FFE0C0" BorderStyle="Dotted">
					<asp:TableRow>
						<asp:TableCell Text=" �ӡ������¹�ŧ��¡�� : �ѹ����ͧ����Ѻ�Թ���,��ͤ���,�������"></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:Label id="Label5" style="Z-INDEX: 105; LEFT: 120px; POSITION: absolute; TOP: 219px" runat="server" Width="88px" Height="32px">�������</asp:Label>
				<asp:TextBox id="TextBox2" style="Z-INDEX: 102; LEFT: 253px; POSITION: absolute; TOP: 212px" runat="server" Height="26px"></asp:TextBox>
				<asp:Label id="Label4" style="Z-INDEX: 104; LEFT: 117px; POSITION: absolute; TOP: 165px" runat="server" Width="88px" Height="32px">��ͤ���</asp:Label>
				<asp:TextBox id="TextBox1" style="Z-INDEX: 103; LEFT: 252px; POSITION: absolute; TOP: 165px" runat="server" Height="26px"></asp:TextBox>
				<asp:dropdownlist id="DropDownList6" style="Z-INDEX: 111; LEFT: 489px; POSITION: absolute; TOP: 272px" runat="server" Width="67px" Height="37px">
					<asp:ListItem>2546</asp:ListItem>
					<asp:ListItem>2547</asp:ListItem>
				</asp:dropdownlist>
				<asp:label id="Label9" style="Z-INDEX: 110; LEFT: 451px; POSITION: absolute; TOP: 275px" runat="server" Width="34px" Height="28px">��</asp:label>
				<asp:Label id="Label8" style="Z-INDEX: 109; LEFT: 283px; POSITION: absolute; TOP: 274px" runat="server" Width="34px" Height="28px">��͹</asp:Label>
				<asp:DropDownList id="DropDownList5" style="Z-INDEX: 108; LEFT: 335px; POSITION: absolute; TOP: 274px" runat="server" Width="100px" Height="37px">
					<asp:ListItem>���Ҥ�</asp:ListItem>
					<asp:ListItem>����Ҿѹ��</asp:ListItem>
					<asp:ListItem>�չҤ�</asp:ListItem>
					<asp:ListItem>����¹</asp:ListItem>
					<asp:ListItem>����Ҥ�</asp:ListItem>
					<asp:ListItem>�Զع�¹</asp:ListItem>
					<asp:ListItem>�á�Ҥ�</asp:ListItem>
					<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
					<asp:ListItem>�ѹ��¹</asp:ListItem>
					<asp:ListItem>���Ҥ�</asp:ListItem>
					<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
					<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label7" style="Z-INDEX: 106; LEFT: 110px; POSITION: absolute; TOP: 278px" runat="server" Width="97px" Height="28px">�ѹ����Ѻ�Թ���</asp:Label>
				<asp:DropDownList id="DropDownList4" style="Z-INDEX: 107; LEFT: 219px; POSITION: absolute; TOP: 275px" runat="server" Width="46px" Height="37px">
					<asp:ListItem>1</asp:ListItem>
					<asp:ListItem>2</asp:ListItem>
					<asp:ListItem>3</asp:ListItem>
					<asp:ListItem>4</asp:ListItem>
					<asp:ListItem>5</asp:ListItem>
					<asp:ListItem>6</asp:ListItem>
					<asp:ListItem>7</asp:ListItem>
					<asp:ListItem>8</asp:ListItem>
					<asp:ListItem>9</asp:ListItem>
					<asp:ListItem>10</asp:ListItem>
					<asp:ListItem>11</asp:ListItem>
					<asp:ListItem>12</asp:ListItem>
					<asp:ListItem>13</asp:ListItem>
					<asp:ListItem>14</asp:ListItem>
					<asp:ListItem>15</asp:ListItem>
					<asp:ListItem>16</asp:ListItem>
					<asp:ListItem>17</asp:ListItem>
					<asp:ListItem>18</asp:ListItem>
					<asp:ListItem>19</asp:ListItem>
					<asp:ListItem>20</asp:ListItem>
					<asp:ListItem>21</asp:ListItem>
					<asp:ListItem>22</asp:ListItem>
					<asp:ListItem>23</asp:ListItem>
					<asp:ListItem>24</asp:ListItem>
					<asp:ListItem>25</asp:ListItem>
					<asp:ListItem>26</asp:ListItem>
					<asp:ListItem>27</asp:ListItem>
					<asp:ListItem>28</asp:ListItem>
					<asp:ListItem>29</asp:ListItem>
					<asp:ListItem>30</asp:ListItem>
					<asp:ListItem>31</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label1" style="Z-INDEX: 112; LEFT: 115px; POSITION: absolute; TOP: 105px" runat="server" Width="288px" Height="41px" ForeColor="#FF8080">Label</asp:Label>
				<asp:Button id="Button1" style="Z-INDEX: 113; LEFT: 272px; POSITION: absolute; TOP: 336px" runat="server" Width="82px" Height="28px" Text="����¹�ŧ"></asp:Button></FONT>
		</form>
	</body>
</HTML>
