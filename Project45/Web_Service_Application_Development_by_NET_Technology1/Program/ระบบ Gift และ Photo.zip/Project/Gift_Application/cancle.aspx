<%@ Page language="c#" Codebehind="cancle.aspx.cs" AutoEventWireup="false" Inherits="Gift_Application.cancle" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>cancle</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ffb7b7">
		<form id="cancle" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:table id="Table1" style="Z-INDEX: 101; LEFT: 160px; POSITION: absolute; TOP: 32px" runat="server" Height="40px" Width="167px" BorderStyle="Dotted" BackColor="#FFE0C0" BorderColor="White">
					<asp:TableRow>
						<asp:TableCell Text=" ¡��ԡ�����觫����Թ��� "></asp:TableCell>
					</asp:TableRow>
				</asp:table>
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 122px; POSITION: absolute; TOP: 138px" runat="server" Height="28px" Width="225px" ForeColor="Red"></asp:Label></FONT>
		</form>
	</body>
</HTML>
