<%@ Page language="c#" Codebehind="family.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.family" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>family</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0">
		<form id="family" method="post" runat="server">
			<table width="780" border="0" align="center" cellpadding="0" cellspacing="0">
				<tr>
					<td><table width="780" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="231" valign="top"><table width="237" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td><img src="family123_01.jpg" tppabs="http://www.jardinbridal.com/images/family123_01.jpg" width="237" height="156"></td>
										</tr>
										<tr>
											<td><img src="family123_02.jpg" tppabs="http://www.jardinbridal.com/images/family123_02.jpg" width="237" height="111"></td>
										</tr>
										<tr>
											<td><img src="family123_03.jpg" tppabs="http://www.jardinbridal.com/images/family123_03.jpg" width="237" height="83"></td>
										</tr>
									</table>
								</td>
								<td width="549" valign="top"><table width="543" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td><img src="543x53family.gif" tppabs="http://www.jardinbridal.com/images/543x53family.gif" width="543" height="53"></td>
										</tr>
									</table>
									<table width="542" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="354"><img src="354x28contactus.gif" tppabs="http://www.jardinbridal.com/images/354x28contactus.gif" width="354" height="28"></td>
											<td width="188"><img src="189x28.gif" tppabs="http://www.jardinbridal.com/images/189x28.gif" width="189" height="28"></td>
										</tr>
									</table>
									<table width="543" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="2" style="WIDTH: 2px"></td>
											<td width="352" valign="top"><table width="350" border="0" cellspacing="0" cellpadding="0">
													<tr>
														<td><div align="center"><font color="#ffffff">...</font></div>
														</td>
													</tr>
													<tr>
														<td><div align="center"><img src="f1.jpg" tppabs="http://www.jardinbridal.com/images/f1.jpg" width="200" height="120" border="0"></A></div>
														</td>
													</tr>
												</table>
												<table width="350" border="0" cellspacing="0" cellpadding="0">
													<tr>
														<td>&nbsp;</td>
														<td>&nbsp;</td>
													</tr>
													<tr>
														<td><div align="center"><img src="f2.jpg" tppabs="http://www.jardinbridal.com/images/f2.jpg" width="100" height="120" border="0"></A></div>
														</td>
														<td><div align="center"><img src="f3.jpg" tppabs="http://www.jardinbridal.com/images/f3.jpg" width="100" height="120" border="0"></A></div>
														</td>
													</tr>
												</table>
												<p align="center"><font size="2">"᷹�����Դ�֧ �����Ҿ��觤���ͺ���㹤�ͺ����"</font><br>
												</p>
												<p><FONT face="Tahoma"></FONT>&nbsp;</p>
												<p>&nbsp;</p>
											</td>
											<td width="181" valign="top"><table width="180" border="0" cellspacing="0" cellpadding="0">
													<tr>
														<td width="180">
															<OBJECT codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" height="194" width="178" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
																<PARAM NAME="_cx" VALUE="4710">
																<PARAM NAME="_cy" VALUE="5133">
																<PARAM NAME="FlashVars" VALUE="4710">
																<PARAM NAME="Movie" VALUE="178x194.swf">
																<PARAM NAME="Src" VALUE="178x194.swf">
																<PARAM NAME="WMode" VALUE="Window">
																<PARAM NAME="Play" VALUE="-1">
																<PARAM NAME="Loop" VALUE="-1">
																<PARAM NAME="Quality" VALUE="High">
																<PARAM NAME="SAlign" VALUE="">
																<PARAM NAME="Menu" VALUE="-1">
																<PARAM NAME="Base" VALUE="">
																<PARAM NAME="AllowScriptAccess" VALUE="always">
																<PARAM NAME="Scale" VALUE="ShowAll">
																<PARAM NAME="DeviceFont" VALUE="0">
																<PARAM NAME="EmbedMovie" VALUE="0">
																<PARAM NAME="BGColor" VALUE="">
																<PARAM NAME="SWRemote" VALUE="">
																<embed src="178x194.swf" tppabs="http://www.jardinbridal.com/images/178x194.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="178" height="194">
																</embed>
															</OBJECT>
														</td>
													</tr>
													<tr>
														<td><a href="g1.html" tppabs="http://www.jardinbridal.com/g1.html"><img src="pagenew3_07.gif" tppabs="http://www.jardinbridal.com/images/pagenew3_07.gif" alt="" width="178" height="75" border="0"></a></td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</form>
	</body>
</HTML>
