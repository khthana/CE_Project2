<%@ Page language="c#" Codebehind="reserve1.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.reserve1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 100; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Label id="Label3" style="Z-INDEX: 114; LEFT: 422px; POSITION: absolute; TOP: 242px" runat="server" Height="28px" Width="33px">�ͺ</asp:Label>
			<asp:Table id="Table1" style="Z-INDEX: 101; LEFT: 471px; POSITION: absolute; TOP: 40px" runat="server" Width="170px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							���͡��ԡ�÷���ͧ��èͧ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:dropdownlist id="DropDownList6" style="Z-INDEX: 103; LEFT: 793px; POSITION: absolute; TOP: 181px" runat="server" Height="37px" Width="67px">
				<asp:ListItem>2546</asp:ListItem>
				<asp:ListItem>2547</asp:ListItem>
			</asp:dropdownlist>
			<asp:label id="Label9" style="Z-INDEX: 104; LEFT: 763px; POSITION: absolute; TOP: 181px" runat="server" Height="28px" Width="34px">��</asp:label>
			<asp:Label id="Label8" style="Z-INDEX: 106; LEFT: 595px; POSITION: absolute; TOP: 180px" runat="server" Height="28px" Width="34px">��͹</asp:Label>
			<asp:DropDownList id="DropDownList5" style="Z-INDEX: 108; LEFT: 647px; POSITION: absolute; TOP: 180px" runat="server" Height="37px" Width="100px">
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>����Ҿѹ��</asp:ListItem>
				<asp:ListItem>�չҤ�</asp:ListItem>
				<asp:ListItem>����¹</asp:ListItem>
				<asp:ListItem>����Ҥ�</asp:ListItem>
				<asp:ListItem>�Զع�¹</asp:ListItem>
				<asp:ListItem>�á�Ҥ�</asp:ListItem>
				<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
				<asp:ListItem>�ѹ��¹</asp:ListItem>
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
				<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label7" style="Z-INDEX: 110; LEFT: 422px; POSITION: absolute; TOP: 184px" runat="server" Height="28px" Width="97px">�ѹ���</asp:Label>
			<asp:DropDownList id="DropDownList4" style="Z-INDEX: 113; LEFT: 531px; POSITION: absolute; TOP: 181px" runat="server" Height="37px" Width="46px">
				<asp:ListItem>1</asp:ListItem>
				<asp:ListItem>2</asp:ListItem>
				<asp:ListItem>3</asp:ListItem>
				<asp:ListItem>4</asp:ListItem>
				<asp:ListItem>5</asp:ListItem>
				<asp:ListItem>6</asp:ListItem>
				<asp:ListItem>7</asp:ListItem>
				<asp:ListItem>8</asp:ListItem>
				<asp:ListItem>9</asp:ListItem>
				<asp:ListItem>10</asp:ListItem>
				<asp:ListItem>11</asp:ListItem>
				<asp:ListItem>12</asp:ListItem>
				<asp:ListItem>13</asp:ListItem>
				<asp:ListItem>14</asp:ListItem>
				<asp:ListItem>15</asp:ListItem>
				<asp:ListItem>16</asp:ListItem>
				<asp:ListItem>17</asp:ListItem>
				<asp:ListItem>18</asp:ListItem>
				<asp:ListItem>19</asp:ListItem>
				<asp:ListItem>20</asp:ListItem>
				<asp:ListItem>21</asp:ListItem>
				<asp:ListItem>22</asp:ListItem>
				<asp:ListItem>23</asp:ListItem>
				<asp:ListItem>24</asp:ListItem>
				<asp:ListItem>25</asp:ListItem>
				<asp:ListItem>26</asp:ListItem>
				<asp:ListItem>27</asp:ListItem>
				<asp:ListItem>28</asp:ListItem>
				<asp:ListItem>29</asp:ListItem>
				<asp:ListItem>30</asp:ListItem>
				<asp:ListItem>31</asp:ListItem>
			</asp:DropDownList>
			<asp:DropDownList id="DropDownList2" style="Z-INDEX: 115; LEFT: 529px; POSITION: absolute; TOP: 244px" runat="server" Width="156px" Height="34px" AutoPostBack="True">
				<asp:ListItem Value="��س����͡��Դ��ԡ��">��س����͡��Դ��ԡ��</asp:ListItem>
			</asp:DropDownList>
			<asp:Button id="Button2" style="Z-INDEX: 116; LEFT: 620px; POSITION: absolute; TOP: 351px" runat="server" Width="69px" Height="33px" BackColor="#FFC080" Text="�ӡ�èͧ"></asp:Button>
			<HR style="Z-INDEX: 117; LEFT: 445px; WIDTH: 42.8%; POSITION: absolute; TOP: 414px; HEIGHT: 1px" width="42.8%" color="#ff99cc" SIZE="1">
			<asp:dropdownlist id="DropDownList3" style="Z-INDEX: 118; LEFT: 536px; POSITION: absolute; TOP: 124px" runat="server" Width="167px" Height="37px"></asp:dropdownlist>
			<asp:Label id="Label2" style="Z-INDEX: 119; LEFT: 414px; POSITION: absolute; TOP: 123px" runat="server" Width="92px" Height="26px">Contact Name</asp:Label>
			<asp:Label id="Label1" style="Z-INDEX: 120; LEFT: 413px; POSITION: absolute; TOP: 342px" runat="server" Width="155px" Height="42px" ForeColor="Red"></asp:Label>
			<asp:dropdownlist id="DropDownList8" style="Z-INDEX: 121; LEFT: 792px; POSITION: absolute; TOP: 295px" runat="server" Width="67px" Height="37px">
				<asp:ListItem Value="2546">2546</asp:ListItem>
				<asp:ListItem Value="2547">2547</asp:ListItem>
			</asp:dropdownlist>
			<asp:label id="Label6" style="Z-INDEX: 122; LEFT: 762px; POSITION: absolute; TOP: 295px" runat="server" Width="34px" Height="28px">��</asp:label>
			<asp:Label id="Label5" style="Z-INDEX: 123; LEFT: 594px; POSITION: absolute; TOP: 294px" runat="server" Width="34px" Height="28px">��͹</asp:Label>
			<asp:DropDownList id="DropDownList7" style="Z-INDEX: 124; LEFT: 646px; POSITION: absolute; TOP: 294px" runat="server" Width="100px" Height="37px">
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>����Ҿѹ��</asp:ListItem>
				<asp:ListItem>�չҤ�</asp:ListItem>
				<asp:ListItem>����¹</asp:ListItem>
				<asp:ListItem>����Ҥ�</asp:ListItem>
				<asp:ListItem>�Զع�¹</asp:ListItem>
				<asp:ListItem>�á�Ҥ�</asp:ListItem>
				<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
				<asp:ListItem>�ѹ��¹</asp:ListItem>
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
				<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label4" style="Z-INDEX: 125; LEFT: 421px; POSITION: absolute; TOP: 298px" runat="server" Width="97px" Height="28px">�ѹ����Ѻ�ͧ</asp:Label>
			<asp:DropDownList id="DropDownList1" style="Z-INDEX: 126; LEFT: 530px; POSITION: absolute; TOP: 295px" runat="server" Width="46px" Height="37px">
				<asp:ListItem>1</asp:ListItem>
				<asp:ListItem>2</asp:ListItem>
				<asp:ListItem>3</asp:ListItem>
				<asp:ListItem>4</asp:ListItem>
				<asp:ListItem>5</asp:ListItem>
				<asp:ListItem>6</asp:ListItem>
				<asp:ListItem>7</asp:ListItem>
				<asp:ListItem>8</asp:ListItem>
				<asp:ListItem>9</asp:ListItem>
				<asp:ListItem>10</asp:ListItem>
				<asp:ListItem>11</asp:ListItem>
				<asp:ListItem>12</asp:ListItem>
				<asp:ListItem>13</asp:ListItem>
				<asp:ListItem>14</asp:ListItem>
				<asp:ListItem>15</asp:ListItem>
				<asp:ListItem>16</asp:ListItem>
				<asp:ListItem>17</asp:ListItem>
				<asp:ListItem>18</asp:ListItem>
				<asp:ListItem>19</asp:ListItem>
				<asp:ListItem>20</asp:ListItem>
				<asp:ListItem>21</asp:ListItem>
				<asp:ListItem>22</asp:ListItem>
				<asp:ListItem>23</asp:ListItem>
				<asp:ListItem>24</asp:ListItem>
				<asp:ListItem>25</asp:ListItem>
				<asp:ListItem>26</asp:ListItem>
				<asp:ListItem>27</asp:ListItem>
				<asp:ListItem>28</asp:ListItem>
				<asp:ListItem>29</asp:ListItem>
				<asp:ListItem>30</asp:ListItem>
				<asp:ListItem>31</asp:ListItem>
			</asp:DropDownList>
		</form>
	</body>
</HTML>
