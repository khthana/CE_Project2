using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for head3.
	/// </summary>
	public class head3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.HyperLink HyperLink2;
		protected System.Web.UI.WebControls.HyperLink HyperLink1;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void LinkButton2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("home.aspx target=main2");
		}

		private void LinkButton1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("regist.aspx target=main2");
		}

		private void Button1_Click(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			string username=TextBox1.Text;
			string password= TextBox2.Text;
			int result=wb.login(username,password);
			if(result>0)
			{
				Session["customer"]=result;
				Response.Redirect("login.aspx");
			}
			else
				Label3.Text="���ʼԴ��Ҵ";


		}


	}
}
