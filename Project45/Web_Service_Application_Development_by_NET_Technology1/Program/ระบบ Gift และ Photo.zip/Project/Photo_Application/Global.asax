<%@ Application Codebehind="Global.asax.cs" Inherits="Photo_Application.Global" %>
