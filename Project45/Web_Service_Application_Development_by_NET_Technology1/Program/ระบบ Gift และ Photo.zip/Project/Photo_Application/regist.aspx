<%@ Page language="c#" Codebehind="regist.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.regist" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>regist</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="regist" method="post" runat="server">
			<IMG style="Z-INDEX: 104; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 0px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 102; LEFT: 433px; POSITION: absolute; TOP: 14px" runat="server" BorderColor="#FFE0C0" BackColor="#FFC0C0" BorderStyle="Solid" Width="161px" Height="40px">
				<asp:TableRow>
					<asp:TableCell Text="
							�ӡ����Ѥ���Ҫԡ����
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>
			<asp:TextBox id="TextBox8" style="Z-INDEX: 123; LEFT: 698px; POSITION: absolute; TOP: 310px" runat="server" Width="111px" Height="26px" MaxLength="15" TextMode="Password"></asp:TextBox>
			<asp:Label id="Label12" style="Z-INDEX: 124; LEFT: 607px; POSITION: absolute; TOP: 316px" runat="server" Width="66px" Height="21px">���ʼ�ҹ</asp:Label>
			<asp:Label id="Label10" style="Z-INDEX: 125; LEFT: 396px; POSITION: absolute; TOP: 316px" runat="server" Width="66px" Height="21px">���ͼ����</asp:Label>
			<asp:TextBox id="TextBox7" style="Z-INDEX: 126; LEFT: 462px; POSITION: absolute; TOP: 313px" runat="server" Width="111px" Height="26px" MaxLength="15"></asp:TextBox>
			<asp:Label id="Label9" style="Z-INDEX: 127; LEFT: 401px; POSITION: absolute; TOP: 272px" runat="server" Width="61px" Height="21px">���Ѿ��</asp:Label>
			<asp:TextBox id="TextBox6" style="Z-INDEX: 128; LEFT: 463px; POSITION: absolute; TOP: 268px" runat="server" Width="111px" Height="26px" MaxLength="20"></asp:TextBox>
			<asp:Label id="Label8" style="Z-INDEX: 129; LEFT: 730px; POSITION: absolute; TOP: 233px" runat="server" Width="30px" Height="21px">��</asp:Label>
			<asp:Label id="Label7" style="Z-INDEX: 130; LEFT: 633px; POSITION: absolute; TOP: 233px" runat="server" Width="30px" Height="21px">����</asp:Label>
			<asp:TextBox id="TextBox5" style="Z-INDEX: 131; LEFT: 677px; POSITION: absolute; TOP: 229px" runat="server" Width="40px" Height="26px" MaxLength="15"></asp:TextBox>
			<asp:Label id="Label6" style="Z-INDEX: 132; LEFT: 606px; POSITION: absolute; TOP: 271px" runat="server" Width="50px" Height="21px">������</asp:Label>
			<asp:TextBox id="TextBox4" style="Z-INDEX: 133; LEFT: 698px; POSITION: absolute; TOP: 267px" runat="server" Width="111px" Height="26px" MaxLength="50"></asp:TextBox>
			<asp:Label id="Label4" style="Z-INDEX: 134; LEFT: 405px; POSITION: absolute; TOP: 230px" runat="server" Width="30px" Height="21px">��</asp:Label>
			<asp:RadioButton id="RadioButton2" style="Z-INDEX: 135; LEFT: 541px; POSITION: absolute; TOP: 232px" runat="server" Width="55px" Height="10px" Text="˭ԧ"></asp:RadioButton>
			<asp:Label id="Label3" style="Z-INDEX: 136; LEFT: 405px; POSITION: absolute; TOP: 134px" runat="server" Width="30px" Height="21px">�������</asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 137; LEFT: 594px; POSITION: absolute; TOP: 92px" runat="server" Width="25px" Height="21px">ʡ��</asp:Label>
			<asp:TextBox id="TextBox3" style="Z-INDEX: 138; LEFT: 632px; POSITION: absolute; TOP: 91px" runat="server" Width="175px" Height="26px" MaxLength="50"></asp:TextBox>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 139; LEFT: 463px; POSITION: absolute; TOP: 91px" runat="server" Width="111px" Height="26px" MaxLength="30"></asp:TextBox>
			<asp:Label id="Label1" style="Z-INDEX: 140; LEFT: 407px; POSITION: absolute; TOP: 91px" runat="server" Width="25px" Height="21px">����</asp:Label>
			<asp:TextBox id="TextBox2" style="Z-INDEX: 141; LEFT: 462px; POSITION: absolute; TOP: 137px" runat="server" Width="256px" Height="80px" MaxLength="300"></asp:TextBox>
			<asp:RadioButton id="RadioButton1" style="Z-INDEX: 142; LEFT: 464px; POSITION: absolute; TOP: 231px" runat="server" Width="51px" Height="10px" Text="���"></asp:RadioButton>
			<asp:Button id="Button1" style="Z-INDEX: 143; LEFT: 628px; POSITION: absolute; TOP: 365px" runat="server" Width="74px" Height="27px" Text="ŧ����¹"></asp:Button>
			<asp:Label id="Label13" style="Z-INDEX: 144; LEFT: 434px; POSITION: absolute; TOP: 359px" runat="server" Width="150px" Height="35px" ForeColor="Red"></asp:Label>
		</form>
	</body>
</HTML>
