<%@ Page language="c#" Codebehind="cancel2.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.cancel2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server" target="header2">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 102; LEFT: 473px; POSITION: absolute; TOP: 56px" runat="server" Width="182px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							¡��ԡ��èͧ��� contact
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 482px; POSITION: absolute; TOP: 136px" runat="server" Height="40px" Width="121px" ForeColor="#FF8080"></asp:Label>
		</form>
	</body>
</HTML>
