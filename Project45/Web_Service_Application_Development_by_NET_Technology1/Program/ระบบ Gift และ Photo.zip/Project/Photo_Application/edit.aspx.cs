using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for edit.
	/// </summary>
	public class edit : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataColumn dataColumn5;
		protected System.Data.DataColumn dataColumn6;
		protected System.Data.DataColumn dataColumn2;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Data.DataColumn dataColumn1;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			int customer_id=Convert.ToInt32(Session["customer"]);
			WebReference1.customer_id_info[] info= wb.show_order_by_customer_id(customer_id);
            		
			int count=info.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			string z="";
			int g;
			for(int i=0;i<count;i++)
			{
				z="";
				DataRow rc = a.NewRow();
				rc["contact name"] = info[i].contact_name;
				rc["�Ҥҷ�����"] =info[i].totalPrice;
				//int index=info[i].pic_url.Length;
				//string picture_large=info[i].pic_url.Insert(index-4,"1");
				if(info[i].deadline!=null)
					for(g=0;g<(info[i].deadline.Length-5);g++)
						z=z+info[i].deadline[g];
					//z=info[i].deadline[0].ToString()+info[i].deadline[1].ToString()+"/"+info[i].deadline[2].ToString()+info[i].deadline[3].ToString()+"/"+info[i].deadline[5].ToString()+info[i].deadline[6].ToString()+info[i].deadline[7].ToString()+info[i].deadline[8].ToString();
				else
					z="";
				//rc["edit"] ="<a href=edit2.aspx?contact_id="+info[i].contact_id+">edit";
				rc["���͡"]="<a href=edit2.aspx?contact_id="+info[i].contact_id+">���͡";
				rc["¡��ԡ"]="<a href=cancel2.aspx?contact_id="+info[i].contact_id+">¡��ԡ";
				rc["�ѹ��˹������Թ"] =z;
				a.Rows.Add(rc);		
			}
			DataGrid2.DataBind();

			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn1 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn4,
																			  this.dataColumn5,
																			  this.dataColumn6,
																			  this.dataColumn2,
																			  this.dataColumn1});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "contact name";
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "�Ҥҷ�����";
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "�ѹ��˹������Թ";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "���͡";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "¡��ԡ";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
	}
}
