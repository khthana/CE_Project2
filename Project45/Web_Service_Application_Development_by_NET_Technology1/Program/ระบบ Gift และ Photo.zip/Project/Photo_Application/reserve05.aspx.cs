using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for reserve05.
	/// </summary>
	public class reserve05 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			string type_id = Convert.ToString(Request.QueryString["type_id"]);
			WebReference1.service_info[] services = wb.service_detail(type_id,0,1000000);
			int count=services.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			for(int i=0;i<count;i++)
			{
				DataRow rc = a.NewRow();
				rc["��ࡨ"] = services[i].subtype_name;
				rc["���͡"] ="<a href=reserve1.aspx?type_id="+services[i].type_id+"&subtype_id="+services[i].subtype_id+"> �ͧ";
				rc["�Ҥ�"] =services[i].price;
				//int index=gift_info[i].pic_url.Length;
				//string picture_large=gift_info[i].pic_url.Insert(index-4,"1");
				rc["��������´"] = services[i].subtype_detail;
				a.Rows.Add(rc);		
			}
			DataGrid1.DataBind();
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn4});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "��ࡨ";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "��������´";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "�Ҥ�";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "���͡";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
		
		}
	}
}
