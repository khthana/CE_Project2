<%@ Page language="c#" Codebehind="out1.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.wedding" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>wedding</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" topmargin="0" leftmargin="0">
		<form id="wedding" method="post" runat="server">
			<table align="center" width="780" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="231" valign="top"><img src="237x350wedding.jpg" tppabs="http://www.jardinbridal.com/images/237x350wedding.jpg" width="237" height="350"></td>
					<td width="549" valign="top"><table width="543" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="543x53wedding.gif" tppabs="http://www.jardinbridal.com/images/543x53wedding.gif" width="543" height="53"></td>
							</tr>
						</table>
						<FONT face="Tahoma"></FONT>
						<table width="542" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="354"><img src="354x28contactus.gif" tppabs="http://www.jardinbridal.com/images/354x28.gif" width="354" height="28"></td>
								<td width="188"><img src="189x28.gif" tppabs="http://www.jardinbridal.com/images/189x28.gif" width="189" height="28"></td>
							</tr>
						</table>
						<table width="350" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td>
									<br>
								</td>
							</tr>
							<tr>
								<td>
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img src="out.jpg" align="center" tppabs="http://www.jardinbridal.com/images/w4.jpg" border="0">
								</td>
							</tr>
						</table>
						<p align="left"><FONT face="Tahoma"></FONT>&nbsp;</p>
					</td>
					<td width="181" valign="top">
					</td>
				</tr>
			</table>
			</TD></TR></TABLE></TD></TR></TABLE>
		</form>
		</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
	</body>
</HTML>
