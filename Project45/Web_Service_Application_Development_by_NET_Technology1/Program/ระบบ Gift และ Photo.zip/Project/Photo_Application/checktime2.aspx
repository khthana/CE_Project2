<%@ Page language="c#" Codebehind="checktime2.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.checktime2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 100; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 105; LEFT: 483px; POSITION: absolute; TOP: 15px" runat="server" Width="119px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							�ͺ�ѹ���ҷ����ҧ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:DataGrid id=DataGrid2 style="Z-INDEX: 106; LEFT: 458px; POSITION: absolute; TOP: 96px" runat="server" BorderStyle="None" BorderColor="#DEBA84" BackColor="#DEBA84" Height="252px" Width="173px" BorderWidth="1px" CellPadding="3" DataSource="<%# dataTable1 %>" AllowPaging="True" PageSize="6"  OnPageIndexChanged =showdata CellSpacing="2">
				<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#738A9C"></SelectedItemStyle>
				<ItemStyle ForeColor="#8C4510" BackColor="#FFF7E7"></ItemStyle>
				<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#A55129"></HeaderStyle>
				<FooterStyle ForeColor="#8C4510" BackColor="#F7DFB5"></FooterStyle>
				<PagerStyle HorizontalAlign="Center" ForeColor="#8C4510" Mode="NumericPages"></PagerStyle>
			</asp:DataGrid>
		</form>
	</body>
</HTML>
