<%@ Page language="c#" Codebehind="show3.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.show3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:DataGrid id="DataGrid2" style="Z-INDEX: 106; LEFT: 392px; POSITION: absolute; TOP: 100px" runat="server" Width="405px" Height="192px" BackColor="#DEBA84" BorderColor="#DEBA84" BorderStyle="None" CellPadding="3" BorderWidth="1px" CellSpacing="2">
				<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#738A9C"></SelectedItemStyle>
				<ItemStyle ForeColor="#8C4510" BackColor="#FFF7E7"></ItemStyle>
				<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#A55129"></HeaderStyle>
				<FooterStyle ForeColor="#8C4510" BackColor="#F7DFB5"></FooterStyle>
				<PagerStyle HorizontalAlign="Center" ForeColor="#8C4510" Mode="NumericPages"></PagerStyle>
			</asp:DataGrid>
			<asp:Table id="Table1" style="Z-INDEX: 102; LEFT: 526px; POSITION: absolute; TOP: 17px" runat="server" Width="150px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							��¡�èͧ�ͧ��ҹ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
		</form>
	</body>
</HTML>
