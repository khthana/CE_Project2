<%@ Page language="c#" Codebehind="create_contact.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.create_contact" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>create_contact</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 105; LEFT: 473px; POSITION: absolute; TOP: 27px" runat="server" Width="126px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							���ҧ contact ����
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:TextBox id="TextBox1" style="Z-INDEX: 102; LEFT: 531px; POSITION: absolute; TOP: 126px" runat="server" Width="94px" Height="27px"></asp:TextBox>
			<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 413px; POSITION: absolute; TOP: 130px" runat="server" Width="96px" Height="31px" Visible="False">Contact Name</asp:Label>
			<asp:Button id="Button1" style="Z-INDEX: 104; LEFT: 499px; POSITION: absolute; TOP: 225px" runat="server" Width="90px" Height="33px" Text="���ҧ contact" BackColor="#FFC080"></asp:Button>
			<asp:Label id="Label2" style="Z-INDEX: 106; LEFT: 409px; POSITION: absolute; TOP: 176px" runat="server" Height="39px" Width="230px" ForeColor="Red"></asp:Label>
		</form>
	</body>
</HTML>
