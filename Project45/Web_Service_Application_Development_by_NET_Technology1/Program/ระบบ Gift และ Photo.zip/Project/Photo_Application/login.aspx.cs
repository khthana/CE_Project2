using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for login.
	/// </summary>
	public class login : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Panel Panel1;
		protected System.Web.UI.WebControls.Button Button3;
		protected System.Web.UI.WebControls.Button Button4;
		protected System.Web.UI.WebControls.Button Button5;
		protected System.Web.UI.WebControls.Button Button8;
		protected System.Web.UI.WebControls.Button Button6;
		protected System.Web.UI.WebControls.Button Button7;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			//Console.Write(" asdad");
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button8.Click += new System.EventHandler(this.Button8_Click);
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Button3.Click += new System.EventHandler(this.Button3_Click);
			this.Button4.Click += new System.EventHandler(this.Button4_Click);
			this.Button5.Click += new System.EventHandler(this.Button5_Click);
			this.Button7.Click += new System.EventHandler(this.Button7_Click);
			this.Button6.Click += new System.EventHandler(this.Button6_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("create_contact.aspx");
		}

		private void Button2_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("checktime1.aspx");
		}

		private void Button7_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("logout.aspx");
		}

		private void Button8_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("home.aspx");
		}

		private void Button3_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("reserve.aspx");
		}

		private void Button4_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("checktime1.aspx");
		
		}

		private void Button5_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("show.aspx");
		}

		private void Button6_Click(object sender, System.EventArgs e)
		{
			Response.Redirect("edit.aspx");
		}
	}
}
