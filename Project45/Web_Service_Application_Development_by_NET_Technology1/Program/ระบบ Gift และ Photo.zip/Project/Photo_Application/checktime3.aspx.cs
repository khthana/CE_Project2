using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for checktime3.
	/// </summary>
	public class checktime3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb =new WebReference1.Photo();
			int type_id=Convert.ToInt32(Request.QueryString["type_id"]);
			string date=Convert.ToString(Request.QueryString["date"]);
			int round=Convert.ToInt32(Request.QueryString["round"]);

			//			type_id=Convert.ToInt32(Session["type_id"]);
			//			day=Convert.ToInt32(Session["day"]);
			bool result=false;
			if(type_id==1 ||  type_id==2)
				result =wb.in_studio_time_available1(type_id,date,round);
			else if(type_id==6)
			{ 
				if(round==1)
					result=wb.multimedia_time_available1(date+" 09:00:00");
				else
					result=wb.multimedia_time_available1(date+" 13:00:00");
			}
			else
				result =wb.out_studio_time_available1(type_id,date,round);
			

			if(result)
				Label1.Text="�ѹ���  "+date[0]+date[1]+"/"+date[3]+date[4]+"/"+date[6]+date[7]+date[8]+date[9]+" �ͺ  "+round+"   :  "+"��ҧ";
			else
				Label1.Text="�ѹ���  "+date[0]+date[1]+"/"+date[3]+date[4]+"/"+date[6]+date[7]+date[8]+date[9]+" �ͺ  "+round+"   :  "+"�����ҧ";

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
