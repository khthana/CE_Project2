<%@ Page language="c#" Codebehind="wedding.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.wedding" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>wedding</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" topmargin="0" leftmargin="0">
		<form id="wedding" method="post" runat="server">
			<table align="center" width="780" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="231" valign="top"><img src="237x350wedding.jpg" tppabs="http://www.jardinbridal.com/images/237x350wedding.jpg" width="237" height="350"></td>
					<td width="549" valign="top"><table width="543" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="543x53wedding.gif" tppabs="http://www.jardinbridal.com/images/543x53wedding.gif" width="543" height="53"></td>
							</tr>
						</table>
						<table width="350" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><div align="center"><FONT face="Tahoma"></FONT></A></div>
								</td>
								<td><div align="center"><FONT face="Tahoma"></FONT></A></div>
								</td>
								<td><div align="center"><FONT face="Tahoma"></FONT></A></div>
								</td>
							</tr>
							<tr>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
								<td>&nbsp;</td>
							</tr>
							<tr>
								<td><div align="center"><FONT face="Tahoma"></FONT><a href="z7.htm" tppabs="http://www.jardinbridal.com/z7.htm" target="_blank"></a></div>
								</td>
								<td><div align="center"><FONT face="Tahoma"></FONT><a href="z8.htm" tppabs="http://www.jardinbridal.com/z8.htm" target="_blank"></a></div>
								</td>
								<td><div align="center"><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT><a href="z9.htm" tppabs="http://www.jardinbridal.com/z9.htm" target="_blank"></a></div>
								</td>
							</tr>
						</table>
						<p align="left">&nbsp;</p>
					</td>
					<td width="181" valign="top"><table width="180" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="180">
									<OBJECT codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" height="194" width="178" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
										<PARAM NAME="_cx" VALUE="4710">
										<PARAM NAME="_cy" VALUE="5133">
										<PARAM NAME="FlashVars" VALUE="4710">
										<PARAM NAME="Movie" VALUE="178x194.swf">
										<PARAM NAME="Src" VALUE="178x194.swf">
										<PARAM NAME="WMode" VALUE="Window">
										<PARAM NAME="Play" VALUE="-1">
										<PARAM NAME="Loop" VALUE="-1">
										<PARAM NAME="Quality" VALUE="High">
										<PARAM NAME="SAlign" VALUE="">
										<PARAM NAME="Menu" VALUE="-1">
										<PARAM NAME="Base" VALUE="">
										<PARAM NAME="AllowScriptAccess" VALUE="always">
										<PARAM NAME="Scale" VALUE="ShowAll">
										<PARAM NAME="DeviceFont" VALUE="0">
										<PARAM NAME="EmbedMovie" VALUE="0">
										<PARAM NAME="BGColor" VALUE="">
										<PARAM NAME="SWRemote" VALUE="">
										<embed src="178x194.swf" tppabs="http://www.jardinbridal.com/images/178x194.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="178" height="194">
										</embed>
									</OBJECT>
								</td>
							</tr>
							<tr>
								<td><a href="g1.html" tppabs="http://www.jardinbridal.com/g1.html"><img src="pagenew3_07.gif" tppabs="http://www.jardinbridal.com/images/pagenew3_07.gif" alt="" width="178" height="75" border="0"></a></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			</td> </tr> </table> </TD></TR></TABLE>
		</form>
		</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
	</body>
</HTML>
