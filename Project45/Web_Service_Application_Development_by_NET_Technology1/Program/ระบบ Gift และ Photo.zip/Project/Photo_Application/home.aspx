<%@ Page language="c#" Codebehind="home.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.home" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>home</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="home" method="post" runat="server">
			<FONT face="Tahoma"></FONT>
			<table width="780" align="center" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td width="231" valign="top"><img src="pic/237x350.jpg" tppabs="http://www.jardinbridal.com/images/237x350.jpg" width="237" height="350"></td>
					<td width="549" valign="top"><table width="543" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td><img src="pic/543x53.gif" tppabs="http://www.jardinbridal.com/images/543x53.gif" width="543" height="53"></td>
							</tr>
						</table>
						<table width="542" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="354"><img src="pic/354x28.gif" tppabs="http://www.jardinbridal.com/images/354x28.gif" width="354" height="28"></td>
								<td width="188"><img src="pic/189x28.gif" tppabs="http://www.jardinbridal.com/images/189x28.gif" width="189" height="28"></td>
							</tr>
						</table>
						<table width="543" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="1" style="WIDTH: 1px"><FONT face="Tahoma"></FONT></td>
								<td width="352" valign="top">
									<br>
									<IMG src="pic/bullet.gif" border="0" tppabs="pic/bullet.gif"> &nbsp;&nbsp; <font color="#fd86eb" size="3">
										"Remember your special day in a beautiful way with us THE PRINCESS BRIDE 
										STUDIO"<br>
									</font><font color="#9e7d50" size="2">
										<p>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ������ԧ� ����յ���١��� ��Ф�������� 
										�Ҫվ ������ԧ�ͧ THE PRINCESS BRIDE ������Դ����ʻҡ��ͻҡ ���� ������ҧ��� 
										�ͧ��� �ǡ�Ѻ����ⴴ ��㹵�� �ͧ ������-��� �Դ���Ҿ��� �繸����ҵ� 
										��зѺ� ��ä�����͡�� �Ӥѭ ����˹��㹪��Ե���������ѹź ���͹ �繪�ǧ���� 
										�����Ш��ѹ�֡ ��� ��ʹ��� ���Ҿ���·��ʹ��� �����ç����觤׹-�ѹ ���� ��� 
										���� �آ...���������</font></P>
									<br>
									<br>
									<p>&nbsp;</p>
									<p><FONT face="Tahoma"></FONT>&nbsp;</p>
								</td>
								<td width="181" valign="top"><table width="180" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td width="180">
												<OBJECT codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" height="194" width="178" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
													<PARAM NAME="_cx" VALUE="4710">
													<PARAM NAME="_cy" VALUE="5133">
													<PARAM NAME="FlashVars" VALUE="4710">
													<PARAM NAME="Movie" VALUE="178x194.swf">
													<PARAM NAME="Src" VALUE="178x194.swf">
													<PARAM NAME="WMode" VALUE="Window">
													<PARAM NAME="Play" VALUE="-1">
													<PARAM NAME="Loop" VALUE="-1">
													<PARAM NAME="Quality" VALUE="High">
													<PARAM NAME="SAlign" VALUE="">
													<PARAM NAME="Menu" VALUE="-1">
													<PARAM NAME="Base" VALUE="">
													<PARAM NAME="AllowScriptAccess" VALUE="always">
													<PARAM NAME="Scale" VALUE="ShowAll">
													<PARAM NAME="DeviceFont" VALUE="0">
													<PARAM NAME="EmbedMovie" VALUE="0">
													<PARAM NAME="BGColor" VALUE="">
													<PARAM NAME="SWRemote" VALUE="">
													<embed src="pic/178x194.swf" tppabs="pic/178x194.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="178" height="194">
													</embed>
												</OBJECT>
											</td>
										</tr>
										<tr>
											<td><img src="pic/pagenew3_07.gif" tppabs="http://www.jardinbridal.com/images/pagenew3_07.gif" alt="" width="178" height="75" border="0"></a></td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
						<FONT face="Tahoma">&nbsp;</FONT></td>
				</tr>
			</table>
			</TD></TR></TABLE>
		</form>
	</body>
</HTML>
