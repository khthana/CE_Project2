using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for reserve.
	/// </summary>
	public class reserve : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.Label Label2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button2_Click(object sender, System.EventArgs e)
		{
			int tid=0;
			if (DropDownList1.SelectedItem.Text=="�����Ҿ���������ʵٴ���") tid=1;
			else if (DropDownList1.SelectedItem.Text=="�����Ҿ��ͺ�����ʵٴ���") tid=2;
			else if (DropDownList1.SelectedItem.Text=="�����Ҿ�ҹ������") tid=3;
			else if (DropDownList1.SelectedItem.Text=="�����Ҿ�ҹ�Ѻ��ԭ��") tid=4;
			else if (DropDownList1.SelectedItem.Text=="�����Դ��ͧҹ������") tid=5;
			else if (DropDownList1.SelectedItem.Text=="�����Դ��� ����ŵ������ ���ૹ൪��") tid=6;
			
			Response.Redirect("reserve05.aspx?type_id="+tid);
		}
	}
}
