<%@ Page language="c#" Codebehind="show2.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.show2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:datagrid id=DataGrid2 style="Z-INDEX: 106; LEFT: 418px; POSITION: absolute; TOP: 94px" runat="server" CellSpacing="2" BorderWidth="1px" CellPadding="3" DataSource="<%# dataSet1 %>" BorderStyle="None" BorderColor="#DEBA84" BackColor="#DEBA84" Height="192px" Width="313px">
				<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#738A9C"></SelectedItemStyle>
				<ItemStyle ForeColor="#8C4510" BackColor="#FFF7E7"></ItemStyle>
				<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#A55129"></HeaderStyle>
				<FooterStyle ForeColor="#8C4510" BackColor="#F7DFB5"></FooterStyle>
				<PagerStyle HorizontalAlign="Center" ForeColor="#8C4510" Mode="NumericPages"></PagerStyle>
			</asp:datagrid><asp:table id="Table1" style="Z-INDEX: 102; LEFT: 493px; POSITION: absolute; TOP: 16px" runat="server" BorderStyle="Solid" BorderColor="#FFE0C0" BackColor="#FFC0C0" Height="40px" Width="147px">
				<asp:TableRow>
					<asp:TableCell Text="
							��¡�èͧ�ͧ��ҹ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:table>&nbsp;
		</form>
	</body>
</HTML>
