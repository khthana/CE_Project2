<%@ Page language="c#" Codebehind="regist_complete.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.regist_complete" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server" target="header2">
			<IMG style="Z-INDEX: 100; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 105; LEFT: 465px; POSITION: absolute; TOP: 132px" runat="server" Width="191px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							�š��ŧ����¹���º����
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
		</form>
	</body>
</HTML>
