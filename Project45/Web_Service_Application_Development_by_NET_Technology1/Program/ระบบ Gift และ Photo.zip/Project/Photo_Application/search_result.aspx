<%@ Page language="c#" Codebehind="search_result.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.search_result" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>wedding</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" topmargin="0" leftmargin="0">
		<form id="wedding" method="post" runat="server">
			<center>
				<FONT face="Tahoma"><IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 0px; HEIGHT: 395px" alt="" src="237x350wedding.jpg"></FONT></TD></TR></TABLE></TD></TR></TABLE>&nbsp;&nbsp;
			</center>
		</form>
		</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
		<asp:Table id="Table1" style="Z-INDEX: 102; LEFT: 462px; POSITION: absolute; TOP: 20px" runat="server" Width="380px" Height="40px" BorderColor="#FFE0C0" BackColor="#FFC0C0" BorderStyle="Solid">
			<asp:TableRow>
				<asp:TableCell Text="
							�š�ä��ҵ����Դ�ͧ��ԡ�� ��Ъ�ǧ�Ҥҷ���ͧ���
						"></asp:TableCell>
			</asp:TableRow>
		</asp:Table>
		<asp:DataGrid id=DataGrid1 style="Z-INDEX: 103; LEFT: 400px; POSITION: absolute; TOP: 121px" runat="server" Height="193px" Width="501px" BackColor="LightGoldenrodYellow" BorderColor="Tan" BorderWidth="1px" CellPadding="2" GridLines="None" ForeColor="Black" DataSource="<%# dataTable1 %>">
			<SelectedItemStyle ForeColor="GhostWhite" BackColor="DarkSlateBlue"></SelectedItemStyle>
			<AlternatingItemStyle BackColor="PaleGoldenrod"></AlternatingItemStyle>
			<HeaderStyle Font-Bold="True" BackColor="Tan"></HeaderStyle>
			<FooterStyle BackColor="Tan"></FooterStyle>
			<PagerStyle HorizontalAlign="Center" ForeColor="DarkSlateBlue" BackColor="PaleGoldenrod"></PagerStyle>
		</asp:DataGrid>
	</body>
</HTML>
