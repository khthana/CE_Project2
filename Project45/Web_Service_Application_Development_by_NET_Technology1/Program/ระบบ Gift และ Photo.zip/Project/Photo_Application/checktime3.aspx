<%@ Page language="c#" Codebehind="checktime3.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.checktime3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 102; LEFT: 493px; POSITION: absolute; TOP: 16px" runat="server" Width="127px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							�ͺ�ѹ���ҷ����ҧ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 447px; POSITION: absolute; TOP: 99px" runat="server" Height="36px" Width="279px" ForeColor="#FF8000" Font-Size="Large"></asp:Label>
		</form>
	</body>
</HTML>
