<%@ Page language="c#" Codebehind="checktime1.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.checktime1" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Label id="Label3" style="Z-INDEX: 114; LEFT: 422px; POSITION: absolute; TOP: 342px" runat="server" Height="28px" Width="33px">�ͺ</asp:Label>
			<asp:Table id="Table1" style="Z-INDEX: 103; LEFT: 471px; POSITION: absolute; TOP: 45px" runat="server" Width="208px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							��Ǩ�ͺ�ͺ���ҷ���ͧ���
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:Button id="Button1" style="Z-INDEX: 102; LEFT: 754px; POSITION: absolute; TOP: 201px" runat="server" Width="69px" Height="33px" Text="��Ǩ�ͺ" BackColor="#FFC080"></asp:Button>
			<asp:DropDownList id="DropDownList1" style="Z-INDEX: 104; LEFT: 566px; POSITION: absolute; TOP: 151px" runat="server" Height="34px" Width="157px" AutoPostBack="True">
				<asp:ListItem Value="0">�����Ҿ���������ʵٴ���</asp:ListItem>
				<asp:ListItem Value="1">�����Ҿ��ͺ�����ʵٴ���</asp:ListItem>
				<asp:ListItem Value="2">�����Ҿ�ҹ������</asp:ListItem>
				<asp:ListItem Value="3">�����Ҿ�ҹ�Ѻ��ԭ��</asp:ListItem>
				<asp:ListItem Value="4">�����Դ��ͧҹ������</asp:ListItem>
				<asp:ListItem Value="5">�����Դ��� ����ŵ������ ���ૹ൪��</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label1" style="Z-INDEX: 105; LEFT: 415px; POSITION: absolute; TOP: 147px" runat="server" Height="35px" Width="71px">��ԡ��</asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 106; LEFT: 415px; POSITION: absolute; TOP: 200px" runat="server" Height="33px" Width="121px">�ӹǹ�ѹ��ǧ˹��</asp:Label>
			<asp:TextBox id="TextBox1" style="Z-INDEX: 107; LEFT: 567px; POSITION: absolute; TOP: 206px" runat="server" Height="23px" Width="148px"></asp:TextBox>
			<asp:dropdownlist id="DropDownList6" style="Z-INDEX: 108; LEFT: 793px; POSITION: absolute; TOP: 281px" runat="server" Height="37px" Width="67px">
				<asp:ListItem>2546</asp:ListItem>
				<asp:ListItem>2547</asp:ListItem>
			</asp:dropdownlist>
			<asp:label id="Label9" style="Z-INDEX: 109; LEFT: 763px; POSITION: absolute; TOP: 281px" runat="server" Height="28px" Width="34px">��</asp:label>
			<asp:Label id="Label8" style="Z-INDEX: 110; LEFT: 595px; POSITION: absolute; TOP: 280px" runat="server" Height="28px" Width="34px">��͹</asp:Label>
			<asp:DropDownList id="DropDownList5" style="Z-INDEX: 111; LEFT: 647px; POSITION: absolute; TOP: 280px" runat="server" Height="37px" Width="100px">
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>����Ҿѹ��</asp:ListItem>
				<asp:ListItem>�չҤ�</asp:ListItem>
				<asp:ListItem>����¹</asp:ListItem>
				<asp:ListItem>����Ҥ�</asp:ListItem>
				<asp:ListItem>�Զع�¹</asp:ListItem>
				<asp:ListItem>�á�Ҥ�</asp:ListItem>
				<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
				<asp:ListItem>�ѹ��¹</asp:ListItem>
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
				<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label7" style="Z-INDEX: 112; LEFT: 422px; POSITION: absolute; TOP: 284px" runat="server" Height="28px" Width="97px">�ѹ���</asp:Label>
			<asp:DropDownList id="DropDownList4" style="Z-INDEX: 113; LEFT: 531px; POSITION: absolute; TOP: 281px" runat="server" Height="37px" Width="46px">
				<asp:ListItem>1</asp:ListItem>
				<asp:ListItem>2</asp:ListItem>
				<asp:ListItem>3</asp:ListItem>
				<asp:ListItem>4</asp:ListItem>
				<asp:ListItem>5</asp:ListItem>
				<asp:ListItem>6</asp:ListItem>
				<asp:ListItem>7</asp:ListItem>
				<asp:ListItem>8</asp:ListItem>
				<asp:ListItem>9</asp:ListItem>
				<asp:ListItem>10</asp:ListItem>
				<asp:ListItem>11</asp:ListItem>
				<asp:ListItem>12</asp:ListItem>
				<asp:ListItem>13</asp:ListItem>
				<asp:ListItem>14</asp:ListItem>
				<asp:ListItem>15</asp:ListItem>
				<asp:ListItem>16</asp:ListItem>
				<asp:ListItem>17</asp:ListItem>
				<asp:ListItem>18</asp:ListItem>
				<asp:ListItem>19</asp:ListItem>
				<asp:ListItem>20</asp:ListItem>
				<asp:ListItem>21</asp:ListItem>
				<asp:ListItem>22</asp:ListItem>
				<asp:ListItem>23</asp:ListItem>
				<asp:ListItem>24</asp:ListItem>
				<asp:ListItem>25</asp:ListItem>
				<asp:ListItem>26</asp:ListItem>
				<asp:ListItem>27</asp:ListItem>
				<asp:ListItem>28</asp:ListItem>
				<asp:ListItem>29</asp:ListItem>
				<asp:ListItem>30</asp:ListItem>
				<asp:ListItem>31</asp:ListItem>
			</asp:DropDownList>
			<asp:DropDownList id="DropDownList2" style="Z-INDEX: 115; LEFT: 529px; POSITION: absolute; TOP: 344px" runat="server" Width="156px" Height="34px" OnSelectedIndexChanged="change_ddl">
				<asp:ListItem>��س����͡��Դ��ԡ��</asp:ListItem>
			</asp:DropDownList>
			<asp:Button id="Button2" style="Z-INDEX: 116; LEFT: 758px; POSITION: absolute; TOP: 340px" runat="server" Width="69px" Height="33px" BackColor="#FFC080" Text="��Ǩ�ͺ"></asp:Button>
			<HR style="Z-INDEX: 117; LEFT: 404px; WIDTH: 461px; POSITION: absolute; TOP: 250px" width="100%" color="#ff99cc" SIZE="2">
		</form>
	</body>
</HTML>
