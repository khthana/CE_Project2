<%@ Page language="c#" Codebehind="edit.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.edit" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server" target="header2">
			<IMG style="Z-INDEX: 100; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:DataGrid id=DataGrid2 style="Z-INDEX: 107; LEFT: 383px; POSITION: absolute; TOP: 118px" runat="server" BorderStyle="None" BorderColor="#DEBA84" BackColor="#DEBA84" Width="437px" DataSource="<%# dataTable1 %>" CellPadding="3" BorderWidth="1px" CellSpacing="2">
				<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#738A9C"></SelectedItemStyle>
				<ItemStyle ForeColor="#8C4510" BackColor="#FFF7E7"></ItemStyle>
				<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#A55129"></HeaderStyle>
				<FooterStyle ForeColor="#8C4510" BackColor="#F7DFB5"></FooterStyle>
				<PagerStyle HorizontalAlign="Center" ForeColor="#8C4510" Mode="NumericPages"></PagerStyle>
			</asp:DataGrid>
			<asp:Table id="Table1" style="Z-INDEX: 105; LEFT: 473px; POSITION: absolute; TOP: 47px" runat="server" Width="218px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							���͡��¡�÷���ͧ���¡��ԡ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:Label id="Label1" style="Z-INDEX: 106; LEFT: 454px; POSITION: absolute; TOP: 309px" runat="server" BorderColor="Yellow" BackColor="#FFE0C0" Height="70px" Width="340px" Font-Size="Larger" ForeColor="DarkGoldenrod">�ҡ��ͧ���¡��ԡ��� contact ��顴��� cancel ���ҵ�ͧ���������䢧ҹ,����¡��ԡ�ҹ ��顴��� edit �����������͡�٨ҡ�ҹ������������ contact ���</asp:Label>
		</form>
	</body>
</HTML>
