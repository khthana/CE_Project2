using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for show3.
	/// </summary>
	public class show3 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataColumn dataColumn6;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataTable dataTable2;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn7;
		protected System.Data.DataColumn dataColumn8;
		protected System.Data.DataColumn dataColumn9;
		protected System.Data.DataColumn dataColumn10;
		protected System.Data.DataColumn dataColumn5;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			int customer_id=Convert.ToInt32(Session["customer"]);
			int contact_id=Convert.ToInt32(Request.QueryString["contact_id"]);
			int job_id =Convert.ToInt32(Request.QueryString["job_id"]);
			int type_id =Convert.ToInt32(Request.QueryString["type_id"]);
			//WebReference1.contact_id_info[] gift_info= wb.showorder_by_contact_id(contact_id);
			WebReference1.photo_vdo_job_id_info info;
			if(type_id<=5)
			{
				if((type_id==1) || (type_id==2))
					info= wb.show_instudio_by_job_id(contact_id,job_id);
				else
					info= wb.show_outstudio_by_job_id(contact_id,job_id);

				dataSet1.Tables["table1"].Clear();			
				DataTable a = dataSet1.Tables["table1"];

				DataRow rc = a.NewRow();
				rc["��Դ"] = info.subtype_name;
				rc["��������´"] =info.subtype_detail;
				rc["�ѹ"] =info.reserve_date;
				rc["�ͺ"] =info.round;
				rc["�Ҥҷ�����"] =info.job_total_price;
				a.Rows.Add(rc);		

				DataGrid2.DataSource=a;
			}else
			{
				WebReference1.multimedia_job_id_info infos= wb.show_multimedia_by_job_id(contact_id,job_id);
				dataSet1.Tables["table2"].Clear();			
				DataTable a = dataSet1.Tables["table2"];
				string z="";
				DataRow rc = a.NewRow();
				rc["��Դ"] = infos.subtype_name;
				rc["��������´"] =infos.subtype_detail;
				rc["�ѹ���ͧ"] =infos.reserve_date;
				for(int j=0;j<infos.finish_date.Length-7;j++)
					z=z+infos.finish_date[j];
				rc["�ѹ����Ѻ�ͧ"] =z;
                rc["�Ҥҷ�����"] =infos.job_total_price;
				a.Rows.Add(rc);		

				DataGrid2.DataSource=a;
			}

			
			
			
			DataGrid2.DataBind();

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn5 = new System.Data.DataColumn();
			this.dataTable2 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn7 = new System.Data.DataColumn();
			this.dataColumn8 = new System.Data.DataColumn();
			this.dataColumn9 = new System.Data.DataColumn();
			this.dataColumn10 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable2)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1,
																		  this.dataTable2});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn4,
																			  this.dataColumn6,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn5});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "��Դ";
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "��������´";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "�ѹ";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "�ͺ";
			// 
			// dataColumn5
			// 
			this.dataColumn5.ColumnName = "�Ҥҷ�����";
			// 
			// dataTable2
			// 
			this.dataTable2.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn7,
																			  this.dataColumn8,
																			  this.dataColumn9,
																			  this.dataColumn10});
			this.dataTable2.TableName = "Table2";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "��Դ";
			// 
			// dataColumn7
			// 
			this.dataColumn7.ColumnName = "��������´";
			// 
			// dataColumn8
			// 
			this.dataColumn8.ColumnName = "�ѹ���ͧ";
			// 
			// dataColumn9
			// 
			this.dataColumn9.ColumnName = "�ѹ����Ѻ�ͧ";
			// 
			// dataColumn10
			// 
			this.dataColumn10.ColumnName = "�Ҥҷ�����";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable2)).EndInit();

		}
		#endregion
	}
}
