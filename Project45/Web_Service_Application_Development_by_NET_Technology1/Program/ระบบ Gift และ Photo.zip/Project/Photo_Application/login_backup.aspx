<%@ Page language="c#" Codebehind="login_backup.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.login_backup" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>head3</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="head3" method="post" runat="server" target="main2">
			<FONT face="Tahoma">
				<asp:Panel BackColor="#edc935" id="Panel1" style="Z-INDEX: 101; LEFT: 110px; POSITION: absolute; TOP: 2px" runat="server" Width="790px" Height="40px">&nbsp;&nbsp;&nbsp; &nbsp;
<asp:Button id="Button8" runat="server" Height="24px" Width="58px" BackColor="#FFC080" ForeColor="Black" Text="˹���á" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
<asp:Button id="Button1" runat="server" Height="24px" Width="89px" BackColor="#FFC080" ForeColor="Black" Text="���ҧ contact" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
&nbsp;
<asp:Button id="Button2" runat="server" Height="24px" Width="63px" BackColor="#FFC080" ForeColor="Black" Text="���ͺ����" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
&nbsp;
<asp:Button id="Button3" runat="server" Height="24px" Width="68px" BackColor="#FFC080" ForeColor="Black" Text="�ͧ��ԡ��" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
&nbsp;
<asp:Button id="Button4" runat="server" Height="24px" Width="81px" BackColor="#FFC080" ForeColor="Black" Text="��Ǩ�ͺ������ҧ" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
&nbsp;
<asp:Button id="Button5" runat="server" Height="24px" Width="80px" BackColor="#FFC080" ForeColor="Black" Text="�ٺ�ԡ�÷��ͧ" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
&nbsp;
<asp:Button id="Button6" runat="server" Height="24px" Width="91px" BackColor="#FFC080" ForeColor="Black" Text="¡��ԡ��¡��" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp; 
&nbsp;
<asp:Button id="Button7" runat="server" Height="24px" Width="86px" BackColor="#FFC080" ForeColor="Black" Text="�͡�ҡ�к�" BorderColor="#FFFFC0"></asp:Button>&nbsp;&nbsp;</asp:Panel></FONT>
		</form>
	</body>
</HTML>
