using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for wedding.
	/// </summary>
	public class search: System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox TextBox1;
		protected System.Web.UI.WebControls.TextBox TextBox2;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.Button Button1;
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.DropDownList DropDownList2;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
		
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button1.Click += new System.EventHandler(this.Button1_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button1_Click(object sender, System.EventArgs e)
		{
			string tid="";
			double min,max;
			if(DropDownList2.SelectedItem.Text=="�ء��ԡ��") tid="0";
			else if (DropDownList2.SelectedItem.Text=="��ԡ�ö����Ҿ������ �ʵٴ���") tid="1";
			else if (DropDownList2.SelectedItem.Text=="��ԡ�ö����Ҿ��ͺ���� �ʵٴ���") tid="2";
			else if (DropDownList2.SelectedItem.Text=="��ԡ�ö����Ҿ��ѹ�觧ҹ �͡ʵٴ���") tid="3";
			else if (DropDownList2.SelectedItem.Text=="��ԡ�ö����Ҿ�ѹ�Ѻ��ԭ�� �������� �͡ʵٴ���") tid="4";
			else if (DropDownList2.SelectedItem.Text=="��ԡ�ö����Ҿ�Դ���㹧ҹ����§") tid="5";
			else if (DropDownList2.SelectedItem.Text=="��ԡ�ö����Դ��ͨѴ���Դ�����ŵ������ ���ૹ൪�� 㹧ҹ�觧ҹ") tid="6";


			min=Convert.ToInt32(TextBox1.Text);
			max=Convert.ToInt32(TextBox2.Text);

			Response.Redirect("search_result.aspx?type_id="+tid+"&min="+min+"&max="+max);
		}
	}
}
