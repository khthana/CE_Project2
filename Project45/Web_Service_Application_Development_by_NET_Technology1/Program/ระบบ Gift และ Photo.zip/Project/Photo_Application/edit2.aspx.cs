using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for edit2.
	/// </summary>
	public class edit2 : System.Web.UI.Page
	{
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn4;
		protected System.Data.DataColumn dataColumn6;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
		protected System.Data.DataColumn dataColumn2;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			int customer_id=Convert.ToInt32(Session["customer"]);
			int contact_id=Convert.ToInt32(Request.QueryString["contact_id"]);
			WebReference1.contact_id_info[] info= wb.show_order_by_contact_id(contact_id);
			int count=info.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			string z="";
			for(int i=0;i<count;i++)
			{
				z="";
				DataRow rc = a.NewRow();
				rc["��ԡ�÷����觨ͧ"] = info[i].subtype_name;
				for(int j=0;j<info[i].receive_date.Length-5;j++)
					z=z+info[i].receive_date[j];
				rc["�ѹ�Ѻ�ͧ"] =z;
				rc["���͡"] ="<a href=edit3.aspx?job_id="+info[i].job_id+"&contact_id="+contact_id+"&type_id="+info[i].type_id+"> ���͡";
				//rc["cancel"]="<a href=cancle2.aspx?job_id="+info[i].job_id+">cancel";
				a.Rows.Add(rc);		
			}
			DataGrid2.DataBind();
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn4 = new System.Data.DataColumn();
			this.dataColumn6 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn4,
																			  this.dataColumn6,
																			  this.dataColumn2});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "��ԡ�÷����觨ͧ";
			// 
			// dataColumn6
			// 
			this.dataColumn6.ColumnName = "�ѹ�Ѻ�ͧ";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "���͡";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion
	}
}
