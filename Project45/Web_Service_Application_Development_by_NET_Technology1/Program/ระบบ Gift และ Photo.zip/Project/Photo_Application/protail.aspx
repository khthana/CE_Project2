<%@ Page language="c#" Codebehind="protail.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.protail" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>protail</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" marginheight="0" marginwidth="0" topmargin="0" leftmargin="0">
		<form id="protail" method="post" runat="server">
			<table align="center" width="780" border="0" cellspacing="0" cellpadding="0">
				<TBODY>
					<tr>
						<td width="231" valign="top"><table width="237" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td><img src="237x350-portrail_01.jpg" tppabs="http://www.jardinbridal.com/images/237x350-portrail_01.jpg" width="237" height="98"></td>
								</tr>
								<tr>
									<td><img src="237x350-portrail_02.jpg" tppabs="http://www.jardinbridal.com/images/237x350-portrail_02.jpg" width="237" height="111"></td>
								</tr>
								<tr>
									<td><img src="237x350-portrail_03.jpg" tppabs="http://www.jardinbridal.com/images/237x350-portrail_03.jpg" width="237" height="141"></td>
								</tr>
							</table>
						</td>
						<td width="549" valign="top"><table width="543" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td><img src="543x53Portrail.gif" tppabs="http://www.jardinbridal.com/images/543x53Portrail.gif" width="543" height="53"></td>
								</tr>
							</table>
							<table width="542" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="354"><img src="354x28contactus.gif" tppabs="http://www.jardinbridal.com/images/354x28contactus.gif" width="354" height="28"></td>
									<td width="188"><img src="189x28.gif" tppabs="http://www.jardinbridal.com/images/189x28.gif" width="189" height="28"></td>
								</tr>
							</table>
							<table width="543" border="0" cellspacing="0" cellpadding="0">
								<TBODY>
									<tr>
										<td width="1" style="WIDTH: 1px"><FONT face="Tahoma"></FONT></td>
										<td width="352" valign="top">
											<table width="350" border="0" cellspacing="0" cellpadding="0">
												<tr>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
												</tr>
												<tr>
													<td><div align="center"><img src="p1.jpg" tppabs="http://www.jardinbridal.com/images/p1.jpg" width="100" height="120" border="0"></a></div>
													</td>
													<td><div align="center"><img src="p2.jpg" tppabs="http://www.jardinbridal.com/images/p2.jpg" width="100" height="120" border="0"></a></div>
													</td>
												</tr>
												<tr>
													<td>&nbsp;</td>
													<td>&nbsp;</td>
												</tr>
												<tr>
													<td><div align="center"><img src="p3.jpg" tppabs="http://www.jardinbridal.com/images/p3.jpg" width="100" height="120" border="0"></a></div>
													</td>
													<td><div align="center"><img src="p4.jpg" tppabs="http://www.jardinbridal.com/images/p4.jpg" width="100" height="120" border="0"></a></div>
													</td>
												</tr>
											</table>
											<p align="center"><br>
											</p>
										</td>
										<td width="181" valign="top"><table width="180" border="0" cellspacing="0" cellpadding="0">
												<tr>
													<td width="180">
														<OBJECT codeBase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" height="194" width="178" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
															<PARAM NAME="_cx" VALUE="4710">
															<PARAM NAME="_cy" VALUE="5133">
															<PARAM NAME="FlashVars" VALUE="4710">
															<PARAM NAME="Movie" VALUE="178x194.swf">
															<PARAM NAME="Src" VALUE="178x194.swf">
															<PARAM NAME="WMode" VALUE="Window">
															<PARAM NAME="Play" VALUE="-1">
															<PARAM NAME="Loop" VALUE="-1">
															<PARAM NAME="Quality" VALUE="High">
															<PARAM NAME="SAlign" VALUE="">
															<PARAM NAME="Menu" VALUE="-1">
															<PARAM NAME="Base" VALUE="">
															<PARAM NAME="AllowScriptAccess" VALUE="always">
															<PARAM NAME="Scale" VALUE="ShowAll">
															<PARAM NAME="DeviceFont" VALUE="0">
															<PARAM NAME="EmbedMovie" VALUE="0">
															<PARAM NAME="BGColor" VALUE="">
															<PARAM NAME="SWRemote" VALUE="">
															<embed src="178x194.swf" tppabs="http://www.jardinbridal.com/images/178x194.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="178" height="194">
															</embed>
														</OBJECT>
													</td>
												</tr>
												<tr>
													<td><a href="g1.html" tppabs="http://www.jardinbridal.com/g1.html"><img src="pagenew3_07.gif" tppabs="http://www.jardinbridal.com/images/pagenew3_07.gif" alt="" width="178" height="75" border="0"></a></td>
												</tr>
											</table>
		</form>
		</TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
	</body>
</HTML>
