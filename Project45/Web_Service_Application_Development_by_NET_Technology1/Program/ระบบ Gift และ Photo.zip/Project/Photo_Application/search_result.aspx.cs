using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for wedding.
	/// </summary>
	public class search_result: System.Web.UI.Page
	{
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Data.DataColumn dataColumn4;
		protected System.Web.UI.WebControls.DataGrid DataGrid1;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string type_id=Convert.ToString(Request.QueryString["type_id"]);
			double min =Convert.ToInt32(Request.QueryString["min"]);
			double max =Convert.ToInt32(Request.QueryString["max"]);
			WebReference1.Photo wb = new WebReference1.Photo();

			WebReference1.service_info[] gift_info=	wb.service_detail(type_id,min,max);;
			int count=gift_info.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			for(int i=0;i<count;i++)
			{
				DataRow rc = a.NewRow();
				rc["��Ǵ��ԡ��"] = gift_info[i].type_name;
				rc["��Դ"] =gift_info[i].subtype_name;
				rc["��������´"] =gift_info[i].subtype_detail;
				rc["�Ҥ�"] =gift_info[i].price;
				a.Rows.Add(rc);		
			}

			DataGrid1.DataBind();
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			this.dataColumn4 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3,
																			  this.dataColumn4});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "��Ǵ��ԡ��";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "��Դ";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "��������´";
			// 
			// dataColumn4
			// 
			this.dataColumn4.ColumnName = "�Ҥ�";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion



	
	}
}
