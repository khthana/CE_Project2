using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for cancel.
	/// </summary>
	public class cancel : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Web.UI.WebControls.Label Label1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			int customer_id=Convert.ToInt32(Session["customer"]);
			int contact_id=Convert.ToInt32(Request.QueryString["contact_id"]);
			int job_id=Convert.ToInt32(Request.QueryString["job_id"]);
			int type_id=Convert.ToInt32(Request.QueryString["type_id"]);
			bool can_cancel=false;
			if((type_id==1) || (type_id==2))
				can_cancel=wb.in_studio_cancle_job(customer_id,contact_id,job_id);
			else if(type_id==6)
				can_cancel=wb.multimedia_cancle_job(customer_id,contact_id,job_id);
			else
				can_cancel=wb.out_studio_cancle_job(customer_id,contact_id,job_id);
			if(can_cancel)
				Label1.Text="¡��ԡ���º����";
			else
				Label1.Text="�������ö�ӡ��¡��ԡ��";

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
