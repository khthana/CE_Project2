<%@ Page language="c#" Codebehind="head3.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.head3" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>head3</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="head3" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:panel id="Panel1" style="Z-INDEX: 101; LEFT: 117px; POSITION: absolute; TOP: 0px" runat="server" BackColor="#edc935" Width="790px" Height="40px">&nbsp;&nbsp;&nbsp; 
<asp:Label id="Label3" runat="server" Height="17px" Width="74px" ForeColor="Red"></asp:Label>&nbsp;&nbsp;&nbsp;&nbsp; 
<asp:Label id="Label1" runat="server" Height="21px" Width="59px" BackColor="#EDC935" ForeColor="#FF8080">username</asp:Label>&nbsp;&nbsp; 
<asp:TextBox id="TextBox1" runat="server" Height="20px" Width="74px"></asp:TextBox>&nbsp;&nbsp; 
<asp:Label id="Label2" runat="server" Height="22px" Width="75px" BackColor="#EDC935" ForeColor="#FF8080">password</asp:Label>&nbsp; 
<asp:TextBox id="TextBox2" runat="server" Height="20px" Width="69px" TextMode="Password"></asp:TextBox>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
<asp:Button id="Button1" runat="server" Height="24px" Width="47px" BackColor="#FFC080" ForeColor="Black" BorderColor="#FFFFC0" Text="login"></asp:Button>&nbsp;&nbsp;&nbsp;&nbsp; 
<asp:HyperLink id="HyperLink1" runat="server" Height="14px" Width="68px" Target="main2" NavigateUrl="home.aspx">Home</asp:HyperLink>&nbsp; 
<asp:HyperLink id="HyperLink2" runat="server" Height="7px" Width="138px" Target="main2" NavigateUrl="regist.aspx">Sign Up New User!</asp:HyperLink></asp:panel></FONT></form>
	</body>
</HTML>
