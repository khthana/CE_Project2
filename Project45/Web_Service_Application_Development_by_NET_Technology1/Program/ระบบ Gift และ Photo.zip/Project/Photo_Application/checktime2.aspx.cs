using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for checktime2.
	/// </summary>
	public class checktime2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
		protected System.Data.DataSet dataSet1;
		protected System.Data.DataTable dataTable1;
		protected System.Data.DataColumn dataColumn1;
		protected System.Data.DataColumn dataColumn2;
		protected System.Data.DataColumn dataColumn3;
		protected System.Web.UI.WebControls.DataGrid DataGrid2;
	
		public void binddata()
		{
			WebReference1.Photo wb =new WebReference1.Photo();
			WebReference1.time_available[] times;
			int type_id=Convert.ToInt32(Request.QueryString["type_id"]);
			int day=Convert.ToInt32(Request.QueryString["day"]);
//			type_id=Convert.ToInt32(Session["type_id"]);
//			day=Convert.ToInt32(Session["day"]);

			if(type_id==1 ||  type_id==2)
				times =wb.in_studio_time_available2(type_id,day);
			else if(type_id==6)
				times=wb.multimedia_time_available2(day);
			else
				times=wb.out_studio_time_available2(type_id,day);

			int count=times.Length;
			dataSet1.Tables["table1"].Clear();			
			DataTable a = dataSet1.Tables["table1"];
			for(int i=0;i<count;i++)
			{
				DataRow rc = a.NewRow();
				rc["�ѹ���"] = times[i].date;
				//rc["�ٻẺ"] =
				rc["�ͺ"] =times[i].round;
				rc["����"] =times[i].time;
				a.Rows.Add(rc);		
			}
			DataGrid2.DataBind();
		}
		public void showdata(object sender,DataGridPageChangedEventArgs e)
		{
			DataGrid2.CurrentPageIndex=e.NewPageIndex;
			binddata();
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
//			WebReference1.Photo wb =new WebReference1.Photo();
//			WebReference1.time_available[] times;
//			int type_id=Convert.ToInt32(Request.QueryString["tid"]);
//			int day=Convert.ToInt32(Request.QueryString["day"]);
//			Session["type_id"]=type_id;
//			Session["day"]=day;
//
//			if(type_id==1 ||  type_id==2)
//				times =wb.in_studio_time_available2(type_id,day);
//			else if(type_id==6)
//				times=wb.multimedia_time_available2(day);
//			else
//				times=wb.out_studio_time_available2(type_id,day);
//
//			int count=times.Length;
//			dataSet1.Tables["table1"].Clear();			
//			DataTable a = dataSet1.Tables["table1"];
//			for(int i=0;i<count;i++)
//			{
//				DataRow rc = a.NewRow();
//				rc["�ѹ���"] = times[i].date;
//				//rc["�ٻẺ"] =
//				rc["�ͺ"] =times[i].round;
//				rc["����"] =times[i].time;
//				a.Rows.Add(rc);		
//			}
//
//			DataGrid2.DataBind();
			
			if(!Page.IsPostBack)
				binddata();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.dataSet1 = new System.Data.DataSet();
			this.dataTable1 = new System.Data.DataTable();
			this.dataColumn1 = new System.Data.DataColumn();
			this.dataColumn2 = new System.Data.DataColumn();
			this.dataColumn3 = new System.Data.DataColumn();
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).BeginInit();
			// 
			// dataSet1
			// 
			this.dataSet1.DataSetName = "NewDataSet";
			this.dataSet1.Locale = new System.Globalization.CultureInfo("th-TH");
			this.dataSet1.Tables.AddRange(new System.Data.DataTable[] {
																		  this.dataTable1});
			// 
			// dataTable1
			// 
			this.dataTable1.Columns.AddRange(new System.Data.DataColumn[] {
																			  this.dataColumn1,
																			  this.dataColumn2,
																			  this.dataColumn3});
			this.dataTable1.TableName = "Table1";
			// 
			// dataColumn1
			// 
			this.dataColumn1.ColumnName = "�ѹ���";
			// 
			// dataColumn2
			// 
			this.dataColumn2.ColumnName = "�ͺ";
			// 
			// dataColumn3
			// 
			this.dataColumn3.ColumnName = "����";
			this.Load += new System.EventHandler(this.Page_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataTable1)).EndInit();

		}
		#endregion


	}
}
