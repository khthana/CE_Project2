<%@ Page language="c#" Codebehind="edit4.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.edit4" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta content="Microsoft Visual Studio 7.0" name="GENERATOR">
		<meta content="C#" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server">
			<IMG style="Z-INDEX: 100; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">&nbsp;
			<asp:table id="Table1" style="Z-INDEX: 105; LEFT: 473px; POSITION: absolute; TOP: 47px" runat="server" Height="40px" Width="267px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							���͡�ѹ������ҷ���ͧ�������¹�ŧ
						"></asp:TableCell>
				</asp:TableRow>
			</asp:table>&nbsp;
			<asp:label id="Label3" style="Z-INDEX: 127; LEFT: 422px; POSITION: absolute; TOP: 196px" runat="server" Height="28px" Width="33px">�ͺ</asp:label><asp:dropdownlist id="DropDownList6" style="Z-INDEX: 128; LEFT: 793px; POSITION: absolute; TOP: 135px" runat="server" Height="37px" Width="67px">
				<asp:ListItem>2546</asp:ListItem>
				<asp:ListItem>2547</asp:ListItem>
			</asp:dropdownlist><asp:label id="Label9" style="Z-INDEX: 129; LEFT: 763px; POSITION: absolute; TOP: 135px" runat="server" Height="28px" Width="34px">��</asp:label><asp:label id="Label8" style="Z-INDEX: 130; LEFT: 595px; POSITION: absolute; TOP: 134px" runat="server" Height="28px" Width="34px">��͹</asp:label><asp:dropdownlist id="DropDownList5" style="Z-INDEX: 131; LEFT: 647px; POSITION: absolute; TOP: 134px" runat="server" Height="37px" Width="100px">
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>����Ҿѹ��</asp:ListItem>
				<asp:ListItem>�չҤ�</asp:ListItem>
				<asp:ListItem>����¹</asp:ListItem>
				<asp:ListItem>����Ҥ�</asp:ListItem>
				<asp:ListItem>�Զع�¹</asp:ListItem>
				<asp:ListItem>�á�Ҥ�</asp:ListItem>
				<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
				<asp:ListItem>�ѹ��¹</asp:ListItem>
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
				<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
			</asp:dropdownlist><asp:label id="Label7" style="Z-INDEX: 132; LEFT: 422px; POSITION: absolute; TOP: 138px" runat="server" Height="28px" Width="97px">�ѹ���</asp:label><asp:dropdownlist id="DropDownList4" style="Z-INDEX: 133; LEFT: 531px; POSITION: absolute; TOP: 135px" runat="server" Height="37px" Width="46px">
				<asp:ListItem>1</asp:ListItem>
				<asp:ListItem>2</asp:ListItem>
				<asp:ListItem>3</asp:ListItem>
				<asp:ListItem>4</asp:ListItem>
				<asp:ListItem>5</asp:ListItem>
				<asp:ListItem>6</asp:ListItem>
				<asp:ListItem>7</asp:ListItem>
				<asp:ListItem>8</asp:ListItem>
				<asp:ListItem>9</asp:ListItem>
				<asp:ListItem>10</asp:ListItem>
				<asp:ListItem>11</asp:ListItem>
				<asp:ListItem>12</asp:ListItem>
				<asp:ListItem>13</asp:ListItem>
				<asp:ListItem>14</asp:ListItem>
				<asp:ListItem>15</asp:ListItem>
				<asp:ListItem>16</asp:ListItem>
				<asp:ListItem>17</asp:ListItem>
				<asp:ListItem>18</asp:ListItem>
				<asp:ListItem>19</asp:ListItem>
				<asp:ListItem>20</asp:ListItem>
				<asp:ListItem>21</asp:ListItem>
				<asp:ListItem>22</asp:ListItem>
				<asp:ListItem>23</asp:ListItem>
				<asp:ListItem>24</asp:ListItem>
				<asp:ListItem>25</asp:ListItem>
				<asp:ListItem>26</asp:ListItem>
				<asp:ListItem>27</asp:ListItem>
				<asp:ListItem>28</asp:ListItem>
				<asp:ListItem>29</asp:ListItem>
				<asp:ListItem>30</asp:ListItem>
				<asp:ListItem>31</asp:ListItem>
			</asp:dropdownlist><asp:dropdownlist id="DropDownList2" style="Z-INDEX: 134; LEFT: 529px; POSITION: absolute; TOP: 198px" runat="server" Height="34px" Width="156px" AutoPostBack="True">
				<asp:ListItem Value="��س����͡��Դ��ԡ��">��س����͡��Դ��ԡ��</asp:ListItem>
			</asp:dropdownlist><asp:button id="Button2" style="Z-INDEX: 135; LEFT: 620px; POSITION: absolute; TOP: 305px" runat="server" Height="33px" Width="95px" Text="�ӡ������¹" BackColor="#FFC080"></asp:button>
			<HR style="Z-INDEX: 136; LEFT: 445px; WIDTH: 42.8%; POSITION: absolute; TOP: 368px; HEIGHT: 1px" width="42.8%" color="#ff99cc" SIZE="1">
			<asp:label id="Label1" style="Z-INDEX: 137; LEFT: 413px; POSITION: absolute; TOP: 296px" runat="server" Height="42px" Width="155px" ForeColor="Red"></asp:label><asp:dropdownlist id="DropDownList8" style="Z-INDEX: 138; LEFT: 792px; POSITION: absolute; TOP: 249px" runat="server" Height="37px" Width="67px">
				<asp:ListItem Value="2546">2546</asp:ListItem>
				<asp:ListItem Value="2547">2547</asp:ListItem>
			</asp:dropdownlist><asp:label id="Label6" style="Z-INDEX: 139; LEFT: 762px; POSITION: absolute; TOP: 249px" runat="server" Height="28px" Width="34px">��</asp:label><asp:label id="Label5" style="Z-INDEX: 140; LEFT: 594px; POSITION: absolute; TOP: 248px" runat="server" Height="28px" Width="34px">��͹</asp:label><asp:dropdownlist id="DropDownList7" style="Z-INDEX: 141; LEFT: 646px; POSITION: absolute; TOP: 248px" runat="server" Height="37px" Width="100px">
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>����Ҿѹ��</asp:ListItem>
				<asp:ListItem>�չҤ�</asp:ListItem>
				<asp:ListItem>����¹</asp:ListItem>
				<asp:ListItem>����Ҥ�</asp:ListItem>
				<asp:ListItem>�Զع�¹</asp:ListItem>
				<asp:ListItem>�á�Ҥ�</asp:ListItem>
				<asp:ListItem>�ԧ�Ҥ�</asp:ListItem>
				<asp:ListItem>�ѹ��¹</asp:ListItem>
				<asp:ListItem>���Ҥ�</asp:ListItem>
				<asp:ListItem>��Ȩԡ�¹</asp:ListItem>
				<asp:ListItem>�ѹ�Ҥ�</asp:ListItem>
			</asp:dropdownlist><asp:label id="Label4" style="Z-INDEX: 142; LEFT: 421px; POSITION: absolute; TOP: 252px" runat="server" Height="28px" Width="97px">�ѹ����Ѻ�ͧ</asp:label><asp:dropdownlist id="DropDownList1" style="Z-INDEX: 143; LEFT: 530px; POSITION: absolute; TOP: 249px" runat="server" Height="37px" Width="46px">
				<asp:ListItem>1</asp:ListItem>
				<asp:ListItem>2</asp:ListItem>
				<asp:ListItem>3</asp:ListItem>
				<asp:ListItem>4</asp:ListItem>
				<asp:ListItem>5</asp:ListItem>
				<asp:ListItem>6</asp:ListItem>
				<asp:ListItem>7</asp:ListItem>
				<asp:ListItem>8</asp:ListItem>
				<asp:ListItem>9</asp:ListItem>
				<asp:ListItem>10</asp:ListItem>
				<asp:ListItem>11</asp:ListItem>
				<asp:ListItem>12</asp:ListItem>
				<asp:ListItem>13</asp:ListItem>
				<asp:ListItem>14</asp:ListItem>
				<asp:ListItem>15</asp:ListItem>
				<asp:ListItem>16</asp:ListItem>
				<asp:ListItem>17</asp:ListItem>
				<asp:ListItem>18</asp:ListItem>
				<asp:ListItem>19</asp:ListItem>
				<asp:ListItem>20</asp:ListItem>
				<asp:ListItem>21</asp:ListItem>
				<asp:ListItem>22</asp:ListItem>
				<asp:ListItem>23</asp:ListItem>
				<asp:ListItem>24</asp:ListItem>
				<asp:ListItem>25</asp:ListItem>
				<asp:ListItem>26</asp:ListItem>
				<asp:ListItem>27</asp:ListItem>
				<asp:ListItem>28</asp:ListItem>
				<asp:ListItem>29</asp:ListItem>
				<asp:ListItem>30</asp:ListItem>
				<asp:ListItem>31</asp:ListItem>
			</asp:dropdownlist></form>
	</body>
</HTML>
