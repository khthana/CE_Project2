using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for reserve2.
	/// </summary>
	public class reserve2 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Table Table1;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string date=Convert.ToString(Request.QueryString["pay_date"]);
			Label1.Text="�ӡ�èͧ���º�������� ��سҪ����Թ "+Convert.ToString(Request.QueryString["price"])+"  �����ѹ��� "+date[0]+date[1]+"/"+date[3]+date[4]+"/"+date[6]+date[7]+date[8]+date[9];
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
