using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Photo_Application
{
	/// <summary>
	/// Summary description for edit4.
	/// </summary>
	public class edit4 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList DropDownList1;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.DropDownList DropDownList7;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.DropDownList DropDownList8;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button Button2;
		protected System.Web.UI.WebControls.DropDownList DropDownList2;
		protected System.Web.UI.WebControls.DropDownList DropDownList4;
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.DropDownList DropDownList5;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.DropDownList DropDownList6;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Table Table1;
		string type_id,subtype_id;
		private void Page_Load(object sender, System.EventArgs e)
		{
			subtype_id=Convert.ToString(Request.QueryString["subtype_id"]);
			type_id=Convert.ToString(Request.QueryString["type_id"]);
			if(!Page.IsPostBack)
				data();
			
			if(type_id!="6")
			{
				DropDownList1.Visible=false;
				DropDownList7.Visible=false;
				DropDownList8.Visible=false;
				Label4.Visible=false;
				Label5.Visible=false;
				Label6.Visible=false;
			}
			
			data2();
			WebReference1.Photo wb = new WebReference1.Photo();

			WebReference1.contact[] contact = wb.get_contact_name(Convert.ToInt32(Session.Contents["customer"]));
			int count=contact.Length;
			//dataSet1.Tables["table1"].Clear();			
			

		}
		public void change_ddl(object sender,EventArgs e)
		{
			data2();
		}
		public void data2()
		{
			if (DropDownList2.SelectedItem.Text=="�ͺ 1 ����   9.00-11.00") Session["round"]="1";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 2 ���� 10.00-12.00") Session["round"]="2";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 3 ���� 13.00-15.00") Session["round"]="3";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 4 ����   8.00-17.00") Session["round"]="4";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 5 ���� 15.00-17.00") Session["round"]="5";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 6 ���� 16.00-18.00") Session["round"]="6";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 7 ���� 17.00-19.00") Session["round"]="7";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 8 ���� 18.00-20.00") Session["round"]="8";
				//out studio round
			else if (DropDownList2.SelectedItem.Text=="�ͺ 1 ����   8.00-12.00") Session["round"]="1";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 2 ���� 13.00-17.00") Session["round"]="2";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 3 ���� 18.00-22.00") Session["round"]="3";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 4 ����   8.00-17.00") Session["round"]="4";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 5 ���� 13.00-22.00") Session["round"]="5";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 6 ����  8.00-22.00") Session["round"]="6";
				//multi
			else if (DropDownList2.SelectedItem.Text=="�ͺ 1 ����    9.00-12.00") Session["round"]="1";
			else if (DropDownList2.SelectedItem.Text=="�ͺ 2 ����  13.00-16.00") Session["round"]="2";
		}

		
		public void data()
		{
			DropDownList2.Items.Clear();
			if( type_id=="1" || type_id=="2"  )
			{						
				DropDownList2.Items.Add("�ͺ 1 ����   9.00-11.00");
				DropDownList2.Items.Add("�ͺ 2 ���� 10.00-12.00");
				DropDownList2.Items.Add("�ͺ 3 ���� 13.00-15.00");
				DropDownList2.Items.Add("�ͺ 4 ���� 14.00-16.00");
				DropDownList2.Items.Add("�ͺ 5 ���� 15.00-17.00");
				DropDownList2.Items.Add("�ͺ 6 ���� 16.00-18.00");
				DropDownList2.Items.Add("�ͺ 7 ���� 17.00-19.00");
				DropDownList2.Items.Add("�ͺ 8 ���� 18.00-20.00");
			}
			else if(type_id=="6")
			{
				DropDownList2.Items.Add("�ͺ 1 ����    9.00-12.00");
				DropDownList2.Items.Add("�ͺ 2 ����  13.00-16.00");
			}
			else
			{
				if(subtype_id=="1")
				{
					DropDownList2.Items.Add("�ͺ 1 ����   8.00-12.00");
					DropDownList2.Items.Add("�ͺ 2 ���� 13.00-17.00");
					DropDownList2.Items.Add("�ͺ 3 ���� 18.00-22.00");
				}
				else if(subtype_id=="2")
				{
					DropDownList2.Items.Add("�ͺ 4 ����   8.00-17.00");
					DropDownList2.Items.Add("�ͺ 5 ���� 13.00-22.00");
				}
				else
					DropDownList2.Items.Add("�ͺ 6 ����  8.00-22.00");
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Button2.Click += new System.EventHandler(this.Button2_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Button2_Click(object sender, System.EventArgs e)
		{
			WebReference1.Photo wb = new WebReference1.Photo();
			int rounds=Convert.ToInt32(Session["round"]);
			int customer_id=Convert.ToInt32(Session["customer"]);
			int contact_id=Convert.ToInt32(Request.QueryString["contact_id"]);
			int job_id=Convert.ToInt32(Request.QueryString["job_id"]);
			int type_id=Convert.ToInt32(Request.QueryString["type_id"]);
			string day=DropDownList4.SelectedItem.Text;
			if(day.Length==1)
				day="0"+day; 
			string month="";
			if(DropDownList5.SelectedItem.Text=="���Ҥ�") month="01";
			else if (DropDownList5.SelectedItem.Text=="����Ҿѹ��") month="02";
			else if (DropDownList5.SelectedItem.Text=="�չҤ�") month="03";
			else if (DropDownList5.SelectedItem.Text=="����¹") month="04";
			else if (DropDownList5.SelectedItem.Text=="����Ҥ�") month="05";
			else if (DropDownList5.SelectedItem.Text=="�Զع�¹") month="06";
			else if (DropDownList5.SelectedItem.Text=="�á�Ҥ�") month="07";
			else if (DropDownList5.SelectedItem.Text=="�ԧ�Ҥ�") month="08";
			else if (DropDownList5.SelectedItem.Text=="�ѹ��¹") month="09";
			else if (DropDownList5.SelectedItem.Text=="���Ҥ�") month="10";
			else if (DropDownList5.SelectedItem.Text=="��Ȩԡ�¹") month="11";
			else if (DropDownList5.SelectedItem.Text=="�ѹ�Ҥ�") month="12";
			string year="";
			if(DropDownList6.SelectedItem.Text=="2546") year="2003";
			else if (DropDownList6.SelectedItem.Text=="2547") year="2004";
			string receivedateS=day+" "+month+" "+year+" ";
			Session["receivedateS"]=receivedateS;

			// Date2
			day=DropDownList1.SelectedItem.Text;
			if(day.Length==1)
				day="0"+day;
			month="";
			if(DropDownList7.SelectedItem.Text=="���Ҥ�") month="01";
			else if (DropDownList7.SelectedItem.Text=="����Ҿѹ��") month="02";
			else if (DropDownList7.SelectedItem.Text=="�չҤ�") month="03";
			else if (DropDownList7.SelectedItem.Text=="����¹") month="04";
			else if (DropDownList7.SelectedItem.Text=="����Ҥ�") month="05";
			else if (DropDownList7.SelectedItem.Text=="�Զع�¹") month="06";
			else if (DropDownList7.SelectedItem.Text=="�á�Ҥ�") month="07";
			else if (DropDownList7.SelectedItem.Text=="�ԧ�Ҥ�") month="08";
			else if (DropDownList7.SelectedItem.Text=="�ѹ��¹") month="09";
			else if (DropDownList7.SelectedItem.Text=="���Ҥ�") month="10";
			else if (DropDownList7.SelectedItem.Text=="��Ȩԡ�¹") month="11";
			else if (DropDownList7.SelectedItem.Text=="�ѹ�Ҥ�") month="12";
			year="";
			if(DropDownList8.SelectedItem.Text=="2546") year="2003";
			else if (DropDownList8.SelectedItem.Text=="2547") year="2004";
			string date2=day+" "+month+" "+year;



			string result;
			if( (type_id==1) || (type_id==2) )
				result=wb.in_studio_edit_reservation(customer_id,contact_id,job_id,receivedateS,rounds);
			else if(type_id==6)
			{
				if(rounds==1)
					receivedateS=receivedateS+" 09:00:00";
				else
					receivedateS=receivedateS+" 13:00:00";
				result=wb.multimedia_edit_reservation(customer_id,contact_id,job_id,receivedateS,day);
			}
			else
				result=wb.out_studio_edit_reservation(customer_id,contact_id,job_id,receivedateS,rounds);
			if(result!="")
				Response.Redirect("edit5.aspx");
			else
				Label1.Text="�������ö����¹��¡����";

		}
	}
}

