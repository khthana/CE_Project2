<%@ Page language="c#" Codebehind="reserve2.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.reserve2" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>logout</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="create_contact" method="post" runat="server" target="header2">
			<IMG style="Z-INDEX: 101; LEFT: 115px; WIDTH: 248px; POSITION: absolute; TOP: 5px; HEIGHT: 395px" alt="" src="237x350wedding.jpg">
			<asp:Table id="Table1" style="Z-INDEX: 102; LEFT: 495px; POSITION: absolute; TOP: 48px" runat="server" Width="126px" Height="40px" BackColor="#FFC0C0" BorderColor="#FFE0C0" BorderStyle="Solid">
				<asp:TableRow>
					<asp:TableCell Text="
							��èͧ���º����
						"></asp:TableCell>
				</asp:TableRow>
			</asp:Table>&nbsp;
			<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 403px; POSITION: absolute; TOP: 156px" runat="server" Height="58px" Width="370px" ForeColor="#FFC080"></asp:Label>
		</form>
	</body>
</HTML>
