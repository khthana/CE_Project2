<%@ Page language="c#" Codebehind="head2.aspx.cs" AutoEventWireup="false" Inherits="Photo_Application.head2_aspx" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>head2</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio 7.0">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" topmargin="0" leftmargin="0">
		<form id="head2" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Table id="Table1" CellPadding="0" CellSpacing="0" style="Z-INDEX: 101; LEFT: 120px; POSITION: absolute; TOP: -5px" runat="server" Width="780px" Height="25px">
					<asp:TableRow>
						<asp:TableCell Text="
							&lt;a href=&quot;home.aspx&quot; target=&quot;main2&quot;&gt;&lt;/a&gt;&lt;img src=&quot;pic/pagenew_17.jpg&quot;&gt;"></asp:TableCell>
						<asp:TableCell Text="
							&lt;img src=&quot;pic/pagenew_18.jpg&quot;&gt;"></asp:TableCell>
						<asp:TableCell Text="
							&lt;img src=&quot;pic/pagenew_19.jpg&quot;&gt;"></asp:TableCell>
						<asp:TableCell Text="
							&lt;img src=&quot;pic/pagenew_20.jpg&quot;&gt;"></asp:TableCell>
						<asp:TableCell Text="
							&lt;img src=&quot;pic/pagenew_21.jpg&quot;&gt;"></asp:TableCell>
						<asp:TableCell Text="
							&lt;img src=&quot;pic/pagenew_22.jpg&quot;&gt;"></asp:TableCell>
					</asp:TableRow>
				</asp:Table></FONT>
		</form>
	</body>
</HTML>
