<%@ WebService Language="c#" Codebehind="Service7.asmx.cs" Class="photo7.Photo" %>
