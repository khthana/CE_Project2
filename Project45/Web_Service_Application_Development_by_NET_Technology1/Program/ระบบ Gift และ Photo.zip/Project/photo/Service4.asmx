<%@ WebService Language="c#" Codebehind="Service4.asmx.cs" Class="photo4.Photo" %>
