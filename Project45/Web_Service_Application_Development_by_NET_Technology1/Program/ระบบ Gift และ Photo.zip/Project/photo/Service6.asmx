<%@ WebService Language="c#" Codebehind="Service6.asmx.cs" Class="photo6.Photo" %>
