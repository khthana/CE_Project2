<%@ WebService Language="c#" Codebehind="Service9.asmx.cs" Class="photo9.Photo" %>
