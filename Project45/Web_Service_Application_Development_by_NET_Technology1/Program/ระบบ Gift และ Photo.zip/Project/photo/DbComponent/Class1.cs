using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DbComponent
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class Gift
	{
		SqlCommand cmd;
		public static String connectionString = "Server=localhost;database=photo;uid=sa;pwd=;";
//		String SqlString;
		SqlConnection myConnection; 
		SqlTransaction tran;

		public Gift()
		{
			myConnection = new SqlConnection(connectionString);
		}
		public Gift(string NEWconnection)
		{
			myConnection = new SqlConnection(NEWconnection);
		}

		public string Excute(string SqlString)
		{
			//SqlString = "INSERT bank (username,password) VALUES ('banks' ,'metha') ";
			//SqlString = "Delete bank where username='bank'";
			cmd = new SqlCommand();
			cmd.CommandText=SqlString;
			try
			{
				myConnection.Open();
				cmd.Connection=myConnection;
				
				tran = myConnection.BeginTransaction();
				cmd.Transaction=tran;
				cmd.ExecuteNonQuery();
				//commit end of transaction
				tran.Commit();
			}
			catch(SqlException E)
			{
				//Roll back if error
				tran.Rollback();
				return "Error Exception :  "+ E.ToString();
			}
			cmd.Connection.Close();

			return "ok";
		}

		public object ExcuteScalar(string SqlString)
		{
			//SqlString = "select * from bank";

			cmd = new SqlCommand(SqlString, myConnection);
			Object o;
			try
			{
				myConnection.Open();
				o = cmd.ExecuteScalar();
			}
			catch(Exception E)
			{
				return o="Error Exception :  "+ E.ToString();
			}
			cmd.Connection.Close();
			
			return o;
		}
		public DataSet Query(string SqlString,string tablename)
		{
			//SqlString = "select * from bank";
			//- test
//			SqlString ="select gift_subtype_id,Gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= 100 and gift_price <= 200 and gift_style = '��'";
			DataSet myDataSet;
			cmd = new SqlCommand(SqlString, myConnection);
			SqlDataAdapter myDataAdapter = 	new SqlDataAdapter(cmd); 
			myDataSet = new DataSet();
			try
			{
				myDataAdapter.Fill (myDataSet,tablename);
			} 
			catch (SqlException E) 
			{	

//				myDataAdapter.Fill (myDataSet,"Error Exception :  "+ E.ToString() );
				//throw new Exception("Error : Sql Statement");
				Exception newE = new Exception("Error : Sql Statement ",E);
				throw newE;
				return  myDataSet;
			}

			return myDataSet;
		}

		public string Test(string SqlString)
		{


//			cmd = new SqlCommand(SqlString, myConnection);
//			SqlConnection mysqlConnection =new SqlConnection(mycon);
			cmd = new SqlCommand();
			cmd.CommandText=SqlString;

//			myConnection.BeginTransaction(tran);

			try
			{
				myConnection.Open();
				cmd.Connection=myConnection;
				tran = myConnection.BeginTransaction();
				cmd.Transaction=tran;
	
				cmd.ExecuteNonQuery();
//				throw new Exception();
				tran.Commit();
			}
			catch(SqlException E)
			{
				tran.Rollback();
				return "Error Exception :  "+ E.ToString();
			}
			cmd.Connection.Close();

			return "ok";
		}

	}
}
