<%@ WebService Language="c#" Codebehind="Service10.asmx.cs" Class="photo10.Photo" %>
