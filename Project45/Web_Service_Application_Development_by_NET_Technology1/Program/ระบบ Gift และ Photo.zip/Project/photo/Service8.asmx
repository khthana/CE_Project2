<%@ WebService Language="c#" Codebehind="Service8.asmx.cs" Class="photo8.Photo" %>
