<%@ WebService Language="c#" Codebehind="Service5.asmx.cs" Class="photo5.Photo" %>
