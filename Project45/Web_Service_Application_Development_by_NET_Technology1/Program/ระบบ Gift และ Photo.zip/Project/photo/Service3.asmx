<%@ WebService Language="c#" Codebehind="Service3.asmx.cs" Class="photo3.Photo" %>
