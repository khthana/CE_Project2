using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace photo7
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class contact
	{
		public int contact_id;
		public string contact_name;
	}

	public class job_reservation
	{
		public int job_id;
		public string dead_line;
		public double price;
	}
	public class customer_id_info
	{
		public int contact_id;
		public string contact_name;
		public double totalPrice;
		public string deadline;
	}
	public class contact_id_info
	{
		public int job_id;
		public string type_id;
		public string type_name;
		public string subtype_name;
		public string receive_date;
	}
	public class photo_vdo_job_id_info
	{
		public int contact_id;
		public int job_id;
		public string type_id;
		public string subtype_id;
		public string subtype_name;
		public string subtype_detail;
		public string reserve_date;
		public string round;
		public double job_total_price ;
	}

	public class multimedia_job_id_info
	{
		public int contact_id;
		public int job_id;
		public string type_id;
		public string subtype_id;
		public string subtype_name;
		public string subtype_detail;
		public string reserve_date;
		public string finish_date;
		public double job_total_price ;
	}
	
	public struct Job
	{
		public int[] job_id;
		public double[] jobtotalprice;
		public Job(int number_job,int[] job_ids,double[] jobtotalprices)
		{
			job_id = job_ids;
			jobtotalprice = jobtotalprices;

		}
	}
	public class TotalPrice
	{
		public int contact_id;
		public double totalprice;
		public Job in_job;
		public Job out_job;
		public Job multimedia_job;
		public string deadline_confirm;
		public TotalPrice(){}
		public TotalPrice(int contact_numbers,int number_job,int[] job_ids,double[] jobtotalprices,double totalprices,DateTime deadline)
		{
			//--- number_job not use
			//int[] job_id = new int[number_job];
			//double jobtotalprice = new double[number_job];
			contact_id = contact_numbers;
			totalprice=totalprices;
			//deadline_confirm = new DateTime();
			deadline_confirm=photo.Photo.DateToString(deadline);
		}
	}
	public class service_info
	{
		public string type_id;
		public string type_name;
		public string subtype_id;
		public string subtype_name;
		public string subtype_detail;
		public double price;
	}

	public struct time_available
	{
		public string date;
		public int round;
		public string time;
	}
	public class Photo : System.Web.Services.WebService
	{
		string DbConnection;
		public Photo()
		{
			DbConnection="Server=localhost;database=photo7;uid=sa;pwd=;";
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		public int test()
		{

			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			DateTime myDate = new DateTime(2003,1,10,9,0,0,0);
			string SqlString = "select count(*) from customer where username='bank'";
			//string result=
			int nums=Convert.ToInt32(db.ExcuteScalar(SqlString));
			
			return nums;
		}
		// Get contact_id
		[WebMethod]
		public int get_contact_id(int customer_id,string contact_name)
		{
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			string SqlString = "select photo_studio_contact_id from photo_studio_contact where photo_studio_contact_name='"+contact_name+"' and customer_id="+customer_id;
			int contact_id=Convert.ToInt32(db.ExcuteScalar(SqlString));
			return contact_id;
		}
		[WebMethod]
			//public DataSet get_contact_name(int customer_id)
		public contact[] get_contact_name(int customer_id)
		{
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			string SqlString = "select photo_studio_contact_id,photo_studio_contact_name from photo_studio_contact where customer_id="+customer_id;
			DataSet myDataSet=db.Query(SqlString,"photo");

			int count=myDataSet.Tables["photo"].Rows.Count;
			int i;
			contact[] cont = new contact[count];

			for (i=0;i<count;i++)
			{
				cont[i] = new contact();
				cont[i].contact_name=System.Convert.ToString(myDataSet.Tables["photo"].Rows[i]["photo_studio_contact_name"]);
				cont[i].contact_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[i]["photo_studio_contact_id"]);
			}
			return cont;
		}
		//-- 1. Gift_Detail -> OK
		//		[WebMethod]
		//		public DataSet gift_detail (string type_id,string style,double min_price,double max_price)
		//		{
		//				string tablename="tbl_giftinfo";
		//			//string SqlString ="select gift_subtype_id,Gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= 100 and gift_price <= 200 and gift_style = '��'";
		//			string SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'"+"and Gift.gift_type_id='"+type_id+"'";
		//			//string SqlString ="select * from gift_order";
		//			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
		//			DataSet myDataSet=db.Query(SqlString,tablename);
		//
		//			return myDataSet;
		//
		//		}

		public static DateTime StringToDate(string input_date)
		{			
			//input_date = "12 01 1993";
			string dd = input_date.Substring(0,2);
			string mm = input_date.Substring(3,2);
			string yy = input_date.Substring(6,4);
			int intyy = 543 + System.Convert.ToInt32(yy);
			string newyy = System.Convert.ToString(intyy);
			string output_date = newyy + "-" + mm + "-" + dd;
			DateTime x = System.Convert.ToDateTime(output_date);
			return x;
		}

		public static DateTime StringToTime(string input_time)
		{
			//input_date = "12 01 1993";
			string hh = input_time.Substring(0,2);
			string mm = input_time.Substring(3,2);
			string ss = input_time.Substring(6,2);
			string output_time = hh + ":" + mm + ":" + ss;
			DateTime x = System.Convert.ToDateTime(output_time);
			return x;
		}
		public static DateTime StringToDateTime(string input)
		{
			//input_date = "12 01 1993";
			string dd = input.Substring(0,2);
			string mm = input.Substring(3,2);
			string yy = input.Substring(6,4);
			int intyy = 543 + System.Convert.ToInt32(yy);
			string newyy = System.Convert.ToString(intyy);
			string output_date = newyy + "-" + mm + "-" + dd;

			string hh = input.Substring(11,2);
			mm = input.Substring(14,2);
			string ss = input.Substring(17,2);
			string output_time = hh + ":" + mm + ":" + ss;

			string output_date_time = output_date+" "+output_time;
			DateTime x = System.Convert.ToDateTime(output_date_time);
		
			return x;
		}
		
		public static string DateToString(DateTime old)
		{
			string 	newdate=old.Day+" "+old.Month+" "+old.Year+" "+old.Hour+":"+old.Minute+":"+old.Second;
			return newdate;
		}

		//-- 1. Services_detail --
		[WebMethod]
		public service_info[] service_detail (string type_id,double min_price,double max_price)
		{
			string tablename="photo";
			//string SqlString ="select package_type_name.package_type_id,package_type_name,package_subtype_id,package_subtype_name,package_subtype_detail,package_price from photo_package ,package_type_name where photo_package.package_type_id =package_type_name.package_type_id";
			string SqlString;
			if(type_id=="0")
				SqlString="select package_type_name.package_type_id,package_type_name,package_subtype_id,package_subtype_name,package_subtype_detail,package_price from photo_package ,package_type_name where photo_package.package_type_id =package_type_name.package_type_id and package_price >="+min_price+" and  package_price <="+max_price+" order by package_type_name.package_type_id";
			else
				SqlString ="select package_type_name.package_type_id,package_type_name,package_subtype_id,package_subtype_name,package_subtype_detail,package_price from photo_package ,package_type_name where photo_package.package_type_id =package_type_name.package_type_id and package_price >="+min_price+" and  package_price <="+max_price+" and package_type_name.package_type_id='"+type_id+"'";
			//string SqlString ="select * from gift_order";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			DataSet myDataSet=db.Query(SqlString,tablename);
			
			int count=myDataSet.Tables[tablename].Rows.Count;
			int i;
			service_info[] services_info = new service_info[count];
							
			for (i=0;i<count;i++)
			{
				services_info[i]=new service_info();
				services_info[i].type_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["package_type_id"]);
				services_info[i].type_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["package_type_name"]);
				services_info[i].subtype_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["package_subtype_id"]);
				services_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["package_subtype_name"]);
				services_info[i].subtype_detail=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["package_subtype_detail"]);
				services_info[i].price=System.Convert.ToDouble(myDataSet.Tables[tablename].Rows[i]["package_price"]);

			}
			return services_info;

			//return myDataSet;
		}
		//-- 2. In Studio Avalible --
		//-- 2.1 True /Flase
		//-- IN Type  1 :wedding 2 : family 
		[WebMethod]
		public bool in_studio_time_available1(int type_id,string checkdates,int round)
		{
			
			//Build String -> DateTime
			DateTime checkdate= photo.Photo.StringToDate(checkdates);
			string checkdate2 = checkdate.Month+"/"+checkdate.Day+"/"+checkdate.Year;
			//must pass all parameter
			string SqlString ="select count(*) from in_studio_photo_reservation where package_type_id="+type_id+" and reserve_date ='"+ checkdate2+"' and round ="+round;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int result= Convert.ToInt32(db.ExcuteScalar(SqlString));
			if(result==1)
				return false;
			else
				return true;
		}		
		//-- 2.2 Array of time 
		[WebMethod]
		public time_available[] in_studio_time_available2(int type_id,int num_day)
		{	
			DateTime checkdate = new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day);
			string SqlString;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			time_available[] tm= new time_available[num_day*8];
			string[] round_time = {"9.00-11.00","10.00-12.00","13.00-15.00","14.00-16.00","15.00-17.00","16.00-18.00","17.00-19.00","18.00-20.00"};
			int n =0;
			string checkdate2;
			for(int i=0;i<num_day;i++)
			{
				//time_available[] ta= new time_available[numday];
				for(int j=1;j<9;j++)
				{
					checkdate2 = checkdate.Month+"/"+checkdate.Day+"/"+checkdate.Year;
					SqlString ="select count(*) from in_studio_photo_reservation where package_type_id="+type_id+" and reserve_date='"+checkdate2+"' and round ="+j;
					int exist = Convert.ToInt32(db.ExcuteScalar(SqlString));
					DateTime z= checkdate;
					z=z.AddYears(-543);
					if(exist==0)
					{

						tm[n].date=z.ToShortDateString();
						tm[n].round=j;
						tm[n].time=round_time[j-1];
						n++;
					}
				} 
				checkdate=checkdate.AddDays(1);
			}
			return tm;
		}
		//-- 3. Out Studio Avalible -- 
		//-- type 3 : wedding , 4 : parinya ,5 : vdo
		//--3.1 return bool
		[WebMethod]
		public bool out_studio_time_available1(int type_id,string checkdates,int round)
		{	
			//Build String -> DateTime
			DateTime checkdate= photo.Photo.StringToDate(checkdates);
			string checkdate2 = checkdate.Month+"/"+checkdate.Day+"/"+checkdate.Year;
			string SqlString ="select count(*) from out_studio_photo_reservation where package_type_id="+type_id+" and reserve_date ='"+ checkdate+"' and round ="+round;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int result= Convert.ToInt32(db.ExcuteScalar(SqlString));
			if(result==1)
				return false;
			else
				return true;
		}	
		//--3.2 return available table
		[WebMethod]
		public time_available[] out_studio_time_available2(int type_id,int num_day)
		{
			// type id 
			DateTime checkdate = new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day);
			string SqlString;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			time_available[] tm= new time_available[num_day*6];
			string[] round_time = {"8.00-12.00","13.00-17.00","18.00-12.00","8.00-17.00","13.00-22.00","8.00-22.00",};
			int n =0;
			string checkdate2;
			for(int i=0;i<num_day;i++)
			{
				//time_available[] ta= new time_available[numday];
				for(int j=1;j<7;j++)
				{
					checkdate2 = checkdate.Month+"/"+checkdate.Day+"/"+checkdate.Year;
					SqlString ="select count(*) from out_studio_photo_reservation where package_type_id="+type_id+" and reserve_date='"+checkdate2+"' and round ="+j;
					int exist = Convert.ToInt32(db.ExcuteScalar(SqlString));
					DateTime z= checkdate;
					z=z.AddYears(-543);
					
					if(exist==0)
					{
						tm[n].date=z.ToShortDateString();
						tm[n].round=j;
						tm[n].time=round_time[j-1];
						n++;
					}
				} 
				checkdate=checkdate.AddDays(1);
			}
			return tm;
		}
		//-- 4. Multimedia Avalible -- 
		//-- time 9.00 (-12.00) and 13.00 (-16.00)
		//--4.1 return bool
		[WebMethod]
		public bool multimedia_time_available1(string checkdates)
		{
			//Build String -> DateTime
			DateTime checkdate= photo.Photo.StringToDateTime(checkdates);
			string checkdate2=checkdate.Year+"/"+checkdate.Month+"/"+checkdate.Day+" "+checkdate.Hour+":"+checkdate.Minute+":"+checkdate.Millisecond;
			string SqlString ="select count(*) from multimedia_order where reserve_date ='"+ checkdate2+"'";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int result= Convert.ToInt32(db.ExcuteScalar(SqlString));
			if(result==1)
				return false;
			else
				return true;
		}	
		//--4.2 return available table
		[WebMethod]
		public time_available[] multimedia_time_available2(int num_day)
		{
			// type id 
			DateTime checkdate1 = new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day,9,0,0);
			DateTime checkdate2 = new DateTime(DateTime.Now.Year,DateTime.Now.Month,DateTime.Now.Day,13,0,0);
			string SqlString;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			time_available[] tm= new time_available[num_day*2];
			string[] round_time = {"9.00-12.00","13.00-16.00"};
			int n =0;
			string checkdate3,checkdate4;
			for(int i=0;i<num_day;i++)
			{
				//time_available[] ta= new time_available[numday];
				checkdate3 = checkdate1.Year+"/"+checkdate1.Month+"/"+checkdate1.Day+" "+checkdate1.Hour+":"+checkdate1.Minute+":"+checkdate1.Millisecond;
				checkdate4 = checkdate2.Year+"/"+checkdate2.Month+"/"+checkdate2.Day+" "+checkdate2.Hour+":"+checkdate2.Minute+":"+checkdate2.Millisecond;
				SqlString ="select count(*) from multimedia_order where reserve_date ='"+ checkdate3+"'";
				int exist = Convert.ToInt32(db.ExcuteScalar(SqlString));
				DateTime z= checkdate1;
				z=z.AddYears(-543);

				if(exist==0)
				{
					tm[n].date=z.ToShortDateString();
					tm[n].round=1;
					tm[n].time=round_time[0];
					n++;
				}
				SqlString ="select count(*) from multimedia_order where reserve_date ='"+ checkdate4+"'";
				exist = Convert.ToInt32(db.ExcuteScalar(SqlString));
				DateTime z2= checkdate2;
				z2=z2.AddYears(-543);
				if(exist==0)
				{
					tm[n].date=z2.ToShortDateString();
					tm[n].round=2;
					tm[n].time=round_time[1];
					n++;
				}
				checkdate1=checkdate1.AddDays(1);
				checkdate2=checkdate2.AddDays(1);
			}
			return tm;
		}

		//-- 20. Place_detail -- read address from text
		[WebMethod]
		public string place_detail()
		{	
			// + change address
			return "Chiangmai";
		}
		//-- 5. Sign Up -> OK but should return  case of error
		[WebMethod]
		public int signup(string username,string password,string firstname,string lastname,string sex,int age,string tel,string address,string email)
		{	
			string SqlString="select count(*) from customer where username ='"+username+"'";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = Convert.ToInt16(db.ExcuteScalar(SqlString));
			//if exist return 0
			if (count==1)
				return 0;
			SqlString="Insert into customer values ('"+username+"','"+password+"','"+firstname+"','"+lastname+"','"+sex+"',"+age+",'"+tel+"','"+address+"','"+email+"')";
			string result=db.Excute(SqlString);	
			if(result=="ok")
			{
				SqlString="select customer_id from customer where username='"+username+"' and password='"+password+"'";
				int customer_id =Convert.ToInt32(db.ExcuteScalar(SqlString));
				return customer_id;
				
			}
			else
				return 0;

		}
		//-- 6. Login ->true OK
		[WebMethod]
		public int login(string username,string password)
		{	
			string SqlString="select customer_id from customer where username='"+username+"' and password='"+password+"'";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int result=Convert.ToInt16(db.ExcuteScalar(SqlString));
			if(result==0)
				return 0;
			else
				return result;
		}

		//-- 7. Create_contact_id -> OK
		[WebMethod]
		public int create_contact_id(int customer_id,string contact_name)
		{	
			// select customer id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			//int customer_id = System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			// insert customer id to get new contact id
			string SqlString = "insert  into photo_studio_contact(customer_id,photo_studio_contact_name) values("+customer_id+",'"+contact_name+"')";
			string result=db.Excute(SqlString);
			if(result=="ok")
			{
				SqlString = "Select photo_studio_contact_id from photo_studio_contact where customer_id="+customer_id + " order by photo_studio_contact_id desc";
				int photo_contact_id = System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				
				return photo_contact_id;
			}
			else
			{
				//Console.WriteLine(result);
				return 0;
			}
		}
		//-- 8 Reserve in Studio type 1 : wedding , 2 : family
		[WebMethod]
		public job_reservation reserve_instudio(int customer_id,int contact_id,string type_id,string subtype_id,string reservedates,int round)
		{
			//Build String -> Date
			DateTime reservedate= photo.Photo.StringToDate(reservedates);
			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (reservedate.Year==DateTime.Now.Year))
			{
				if( (reservedate.DayOfYear-DateTime.Now.DayOfYear)<10)
				{	
					job_reservation job = new job_reservation();
					job.job_id=0;
					return job;
				}
			}
			else if(reservedate.Year<DateTime.Now.Year)
			{
				job_reservation job = new job_reservation();
				job.job_id=0;
				return job;
			}
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			//Select customer_id from username AND check PASSSWORD
			//string SqlString = "Select customer_id from customer where username='"+username+"' and password ='"+password+"'";
			//int customer_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			//if username ,password does not exist return 0
			if(customer_id<1)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-1;
				return job;
			}

			//check if date time available
			string reservedate2 = reservedate.Month+"/"+reservedate.Day+"/"+reservedate.Year;
			string SqlString ="select count(*) from in_studio_photo_reservation where reserve_date='"+reservedate2+"' and round ="+round;
			int ava_result = Convert.ToInt32(db.ExcuteScalar(SqlString));
			//if not available return
			if(ava_result==1)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-2;
				return job;
			}

			//prepare data to insert : price ,pay date ="" : 1900-01-01
			SqlString =" select package_price from photo_package where package_type_id ='"+type_id+"' and package_subtype_id ='"+subtype_id+"'";
			double price = Convert.ToDouble(db.ExcuteScalar(SqlString));
			//Insert Reserve
			SqlString ="Insert into in_studio_photo_reservation values('" + type_id + "','" +subtype_id+ "'," +contact_id+ "," +customer_id+ ",'" +reservedate2+ "',"+round+"," +price+ ",'')";
			string result = db.Excute(SqlString);
			if(result!="ok")
			{	
				job_reservation job = new job_reservation();
				job.job_id=-3;
				return job;
			}

			//check old deadline exist
			SqlString="Select deadline_confirm from photo_studio_contact where photo_studio_contact_id ="+contact_id;
			DateTime old_deadline = new DateTime();
			bool have_old_deadline;
			try
			{
				old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
				have_old_deadline=true;
			}
			catch(System.Exception e)
			{
				have_old_deadline=false;
			}
			//if old deadline exist 
			if (have_old_deadline)
			{
				DateTime new_deadline = reservedate.Subtract(deadline);
				//if new deadline date arrive before old deadline ->Update Deadline
				if(new_deadline.DayOfYear<old_deadline.DayOfYear)
				{
					string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
					db.Excute(SqlString);
				}
				else
					new_deadline=old_deadline;
				// reutrn job_id
				SqlString="select instudio_photo_job_id from in_studio_photo_reservation where photo_studio_contact_id="+contact_id+" and package_type_id='"+type_id+"' and package_subtype_id='"+subtype_id+"' and reserve_date='"+reservedate2+"' order by instudio_photo_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				job_reservation job = new job_reservation();
				job.job_id=job_id;
				job.dead_line=photo.Photo.DateToString(new_deadline);
				job.price=price;

				return job;
				
			}
			else
			{
				DateTime new_deadline = reservedate.Subtract(deadline);
				string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
				SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
				db.Excute(SqlString);
				// reutrn job_id
				SqlString="select instudio_photo_job_id from in_studio_photo_reservation where photo_studio_contact_id="+contact_id+" and package_type_id='"+type_id+"' and package_subtype_id='"+subtype_id+"' and reserve_date='"+reservedate2+"' order by instudio_photo_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				job_reservation job = new job_reservation();
				job.job_id=job_id;
				job.dead_line=photo.Photo.DateToString(new_deadline);
				job.price=price;

				return job;

			}
			job_reservation job0 = new job_reservation();
			job0.job_id=0;

			return job0;
		}
		//8.2.00 find photographer id that available in that day Type : film,vdo --> OK
		[WebMethod]
		public int[] find_photographer(string type,DateTime day)
		{
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			string day2 = day.Year+"/"+day.Month+"/"+day.Day;
			string SqlString = "select photographer_id from photographer where (photographer_id not in (select photographer.photographer_id from photographer,photographer_reserve where photographer_reserve.photographer_id=photographer.photographer_id and photographer_type='"+type+"' and reserve_date='"+day2+"')) and photographer_type='"+type+"'";
			DataSet myDataSet= db.Query(SqlString,"photo");
			int count=myDataSet.Tables["photo"].Rows.Count;
			// No photographer available
			if(count==0)
			{
				int[]  no_ava= {0};				
				return no_ava;
			}
			int[] photographer_id = new int[count];
			int i;
			for (i=0;i<count;i++)
			{
				photographer_id[i]=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[i]["photographer_id"]);
			}

			return photographer_id;
		}

		//-- 8.2 Reserve Out Studio type 3:wedding ,4: parinya , 5: vdo
		[WebMethod]
		public job_reservation reserve_outstudio(int customer_id,int contact_id,string type_id,string subtype_id,string reservedates,int round)
		{
			//Build String -> Date
			DateTime reservedate= photo.Photo.StringToDate(reservedates);
			string type;
			if((type_id=="3")||(type_id=="4"))
				type="film";
			else if(type_id=="5")
				type="vdo";
			else
			{	
				job_reservation job = new job_reservation();
				job.job_id=-4;// not match type with this function
				return job;
			}
				
			//check Sub Type  && Round
			if(subtype_id=="1")
			{
				if(!((round==1)||(round==2)||(round==3)))
				{	
					job_reservation job = new job_reservation();
					job.job_id=-5;// round and subtype pacjage does not match
					return job;
				}
			}
			else if(subtype_id=="2")
			{
				if(!((round==4)||(round==5)))
				{	
					job_reservation job = new job_reservation();
					job.job_id=-5;// round and subtype pacjage does not match
					return job;
				}

			}
			else if(subtype_id=="3")
				if(!(round==6))
				{	
					job_reservation job = new job_reservation();
					job.job_id=-5;// round and subtype pacjage does not match
					return job;
				}



			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (reservedate.Year==DateTime.Now.Year))
			{
				if( (reservedate.DayOfYear-DateTime.Now.DayOfYear)<10)
				{	
					job_reservation job = new job_reservation();
					job.job_id=0;
					return job;
				}
			}
			else if(reservedate.Year<DateTime.Now.Year)
			{
				job_reservation job = new job_reservation();
				job.job_id=0;
				return job;
			}


			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			//Select customer_id from username AND check PASSSWORD
			//string SqlString = "Select customer_id from customer where username='"+username+"' and password ='"+password+"'";
			//int customer_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			//if username ,password does not exist return 0
			if(customer_id<1)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-1;
				return job;
			}

			//check if date time that there are any Photograper Available
			int[] photographer_id = find_photographer(type,reservedate);
			if(photographer_id[0]==0)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-2; // no photographer available
				return job;
			}
			//prepare data to insert : price ,pay date ="" : 1900-01-01
			string SqlString =" select package_price from photo_package where package_type_id ='"+type_id+"' and package_subtype_id ='"+subtype_id+"'";
			double price = Convert.ToDouble(db.ExcuteScalar(SqlString));
			//Insert Reserve Photographer_reserve
			string reservedate2 = reservedate.Month+"/"+reservedate.Day+"/"+reservedate.Year;
			SqlString ="Insert photographer_reserve values("+photographer_id[0]+",'"+reservedate2+"')";
			string result_ph=db.Excute(SqlString);
			if(result_ph!="ok")
			{	
				job_reservation job = new job_reservation();
				job.job_id=-3; // insert fails
				return job;
			}	
			//Select photographer_job_id to insert to out_studio_reserve
			SqlString ="select photographer_job_id from photographer_reserve where photographer_id = "+photographer_id[0]+" and reserve_date='"+reservedate2+"' order by photographer_job_id desc ";
			int photographer_job_id=Convert.ToInt32(db.ExcuteScalar(SqlString));
			//Insert to Out_studio_reservation
			SqlString ="Insert into out_studio_photo_reservation values('" + type_id + "','" +subtype_id+ "'," +contact_id+ "," +customer_id+ ","+photographer_job_id+","+photographer_id[0]+",'" +reservedate2+ "',"+round+"," +price+ ",'')";
			string result = db.Excute(SqlString);
			if(result!="ok")
			{	
				job_reservation job = new job_reservation();
				job.job_id=-3; // insert fails
				return job;
			}	

			//check old deadline exist
			SqlString="Select deadline_confirm from photo_studio_contact where photo_studio_contact_id ="+contact_id;
			DateTime old_deadline = new DateTime();
			bool have_old_deadline;
			try
			{
				old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
				have_old_deadline=true;
			}
			catch(System.Exception e)
			{
				have_old_deadline=false;
			}
			//if old deadline exist 
			if (have_old_deadline)
			{
				DateTime new_deadline = reservedate.Subtract(deadline);
				//if new deadline date arrive before old deadline ->Update Deadline
				if(new_deadline.DayOfYear<old_deadline.DayOfYear)
				{
					string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
					db.Excute(SqlString);
				}
				else
					new_deadline=old_deadline;
				// reutrn job_id
				SqlString="select outstudio_photo_job_id from out_studio_photo_reservation where photo_studio_contact_id="+contact_id+" and package_type_id='"+type_id+"' and package_subtype_id='"+subtype_id+"' and reserve_date='"+reservedate2+"' order by outstudio_photo_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				job_reservation job = new job_reservation();
				job.job_id=job_id;
				job.dead_line=photo.Photo.DateToString(new_deadline);
				job.price=price;

				return job;

				
			}
			else
			{
				DateTime new_deadline = reservedate.Subtract(deadline);
				string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
				SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
				db.Excute(SqlString);
				// reutrn job_id
				SqlString="select outstudio_photo_job_id from out_studio_photo_reservation where photo_studio_contact_id="+contact_id+" and package_type_id='"+type_id+"' and package_subtype_id='"+subtype_id+"' and reserve_date='"+reservedate2+"' order by outstudio_photo_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				job_reservation job = new job_reservation();
				job.job_id=job_id;
				job.dead_line=photo.Photo.DateToString(new_deadline);
				job.price=price;

				return job;

			}
						
			job_reservation job0 = new job_reservation();
			job0.job_id=0;

			return job0;

		}
		//-- 8.3 Reserve Multimedia
		[WebMethod]
		public job_reservation reserve_multimedia(int customer_id,int contact_id,string subtype_id,string reservedates,string show_dates)
		{
			//Build String -> DateTime
			DateTime reservedate= photo.Photo.StringToDateTime(reservedates);
			//Build String -> Date
			DateTime show_date= photo.Photo.StringToDate(show_dates);
			string type_id="6";
			//check Day Reserve and Finish more than 10 days
			if((show_date.DayOfYear-reservedate.DayOfYear)<10)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-4;
				return job;
			}
			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (reservedate.Year==DateTime.Now.Year))
			{
				if( (reservedate.DayOfYear-DateTime.Now.DayOfYear)<10)
				{	
					job_reservation job = new job_reservation();
					job.job_id=0;
					return job;
				}
			}
			else if(reservedate.Year<DateTime.Now.Year)
			{
				job_reservation job = new job_reservation();
				job.job_id=0;
				return job;
			}

			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			//Select customer_id from username AND check PASSSWORD
			//string SqlString = "Select customer_id from customer where username='"+username+"' and password ='"+password+"'";
			//int customer_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			//if username ,password does not exist return 0
			if(customer_id<1)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-1;
				return job;
			}
			//check if only Date and Time 9.00/13.00 available
			string reservedate2 = reservedate.Month+"/"+reservedate.Day+"/"+reservedate.Year+"  "+reservedate.Hour+":"+reservedate.Minute+":"+reservedate.Millisecond;
			string SqlString ="select count(*) from multimedia_order where reserve_date='"+reservedate2+"'";
			int ava_result = Convert.ToInt32(db.ExcuteScalar(SqlString));
			//if not available return
			if(ava_result==1)
			{	
				job_reservation job = new job_reservation();
				job.job_id=-2;
				return job;
			}
			//prepare data to insert : price ,pay date ="" : 1900-01-01 
			SqlString =" select package_price from photo_package where package_type_id ='"+type_id+"' and package_subtype_id ='"+subtype_id+"'";
			double price = Convert.ToDouble(db.ExcuteScalar(SqlString));
			string show_date2 = show_date.Month+"/"+show_date.Day+"/"+show_date.Year;
			//Insert Order multimedia
			SqlString ="Insert into multimedia_order values('" + type_id + "','" +subtype_id+ "'," +contact_id+ "," +customer_id+ ",'" +reservedate2+ "','"+show_date2+"'," +price+ ",'')";
			string result = db.Excute(SqlString);
			if(result!="ok")
			{	
				job_reservation job = new job_reservation();
				job.job_id=-3;
				return job;
			}
			//check old deadline exist
			SqlString="Select deadline_confirm from photo_studio_contact where photo_studio_contact_id ="+contact_id;
			DateTime old_deadline = new DateTime();
			bool have_old_deadline;
			try
			{
				old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
				have_old_deadline=true;
			}
			catch(System.Exception e)
			{
				have_old_deadline=false;
			}
			//if old deadline exist 
			if (have_old_deadline)
			{
				DateTime new_deadline = reservedate.Subtract(deadline);
				//if new deadline date arrive before old deadline ->Update Deadline
				if(new_deadline.DayOfYear<old_deadline.DayOfYear)
				{
					string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
					db.Excute(SqlString);

				}
				else
					new_deadline=old_deadline;
				// reutrn job_id
				SqlString="select multimedia_job_id from multimedia_order where photo_studio_contact_id="+contact_id+" and package_type_id='"+type_id+"' and package_subtype_id='"+subtype_id+"' and reserve_date='"+reservedate2+"' order by multimedia_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				job_reservation job = new job_reservation();
				job.job_id=job_id;
				job.dead_line=photo.Photo.DateToString(new_deadline);
				job.price=price;

				return job;

				
			}
			else
			{
				DateTime new_deadline = reservedate.Subtract(deadline);
				string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
				SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
				db.Excute(SqlString);
				// reutrn job_id
				SqlString="select multimedia_job_id from multimedia_order where photo_studio_contact_id="+contact_id+" and package_type_id='"+type_id+"' and package_subtype_id='"+subtype_id+"' and reserve_date='"+reservedate2+"' order by multimedia_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				job_reservation job = new job_reservation();
				job.job_id=job_id;
				job.dead_line=photo.Photo.DateToString(new_deadline);
				job.price=price;

				return job;

			}
			job_reservation job0 = new job_reservation();
			job0.job_id=0;

			return job0;

		}

		//-- 8.4 Reserve Album
		//-- 9.0 Total price in Contact
		[WebMethod]
			//public void totals(int customer_id,int contact_id)
		public TotalPrice totals(int customer_id,int contact_id)
		{
			//Slect customer_id from username
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			//string SqlString = "Select customer_id from customer where username='"+username+"' and password='"+password+"'";
			//int customer_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			string SqlString = "select count(*) from photo_studio_contact where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			int result_contact = Convert.ToInt32(db.ExcuteScalar(SqlString));
			if(result_contact!=1)
				return null; // no contact_id with this customer id (username)
			//not do yet
			// IN STUDIO
			SqlString="select instudio_photo_job_id,job_total_price  from in_studio_photo_reservation where photo_studio_contact_id="+contact_id;
			DataSet myDataSet=db.Query(SqlString,"gift_order");
			//DataTable myDataTable 
			int count=myDataSet.Tables["gift_order"].Rows.Count;
			int[] job_id = new int[count];
			double[] job_price = new double[count];
			int i;
			double totalprice=0;
			for (i=0;i<count;i++)
			{
				job_id[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["instudio_photo_job_id"]);
				job_price[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["job_total_price"]);
				totalprice=totalprice+job_price[i];
			}

			// OUT STUDIO
			SqlString="select outstudio_photo_job_id,job_total_price  from out_studio_photo_reservation where photo_studio_contact_id="+contact_id;
			myDataSet=db.Query(SqlString,"gift_order");
			//DataTable myDataTable 
			count=myDataSet.Tables["gift_order"].Rows.Count;
			job_id = new int[count];
			job_price = new double[count];
			//double totalprice=0;
			for (i=0;i<count;i++)
			{
				job_id[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["outstudio_photo_job_id"]);
				job_price[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["job_total_price"]);
				totalprice=totalprice+job_price[i];
			}

			// Multimedia STUDIO
			SqlString="select multimedia_job_id,job_total_price  from multimedia_order where photo_studio_contact_id="+contact_id;
			myDataSet=db.Query(SqlString,"gift_order");
			//DataTable myDataTable 
			count=myDataSet.Tables["gift_order"].Rows.Count;
			job_id = new int[count];
			job_price = new double[count];
			//double totalprice=0;
			for (i=0;i<count;i++)
			{
				job_id[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["multimedia_job_id"]);
				job_price[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["job_total_price"]);
				totalprice=totalprice+job_price[i];
			}

			DateTime deadline_date;
			// get DeadLine Date 
			SqlString ="select deadline_confirm from photo_studio_contact where photo_studio_contact_id="+contact_id;
			try
			{
				deadline_date=Convert.ToDateTime(db.ExcuteScalar(SqlString));
			}
			catch(Exception e)
			{
				deadline_date= new DateTime(1,1,1);
			}
			TotalPrice price = new TotalPrice(contact_id,count,job_id,job_price,totalprice,deadline_date);
			
			return price;
		}
		//-- 10. Pay 
		//-- 11. show reserve by customer_id
		[WebMethod]
		public customer_id_info[] show_order_by_customer_id(int customer_id)
		{	
			//Select customer id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			//DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//select  Detail from Gift_Contact
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			string SqlString="select photo_studio_contact_id,photo_studio_contact_name,deadline_confirm from photo_studio_contact where customer_id="+customer_id;
			DataSet myDataSet=db.Query(SqlString,"photo");
			int count=myDataSet.Tables["photo"].Rows.Count;
			int i;
			customer_id_info[] customer_info = new customer_id_info[count];
			for (i=0;i<count;i++)
			{
				customer_info[i]=new customer_id_info();
				customer_info[i].contact_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[i]["photo_studio_contact_id"]);
				customer_info[i].contact_name=System.Convert.ToString(myDataSet.Tables["photo"].Rows[i]["photo_studio_contact_name"]);
				TotalPrice total =totals(customer_id,customer_info[i].contact_id);
				if(total.totalprice>0)
					customer_info[i].totalPrice=total.totalprice;
				else
					customer_info[i].totalPrice=0;
				if(myDataSet.Tables["photo"].Rows[i]["deadline_confirm"]!=System.DBNull.Value)
				{
					string deadline_string=Photo.DateToString(System.Convert.ToDateTime(myDataSet.Tables["photo"].Rows[i]["deadline_confirm"]));
					customer_info[i].deadline=deadline_string;
				}

				
			}
			
			return customer_info;
		}
		//-- 11.2 Show Order by Contact Id   --OK
		[WebMethod]
		public contact_id_info[] show_order_by_contact_id(int contact_id)
		{	
			//select contact_id
			//string SqlString="select  photo_studio_contact_id from photo_studio_contact where photo_studio_contact_name ='"+contact_name+"'";
			//decimal contact_id = db.ExcuteScalar(SqlString);
			
			
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//Get Job from 3 Tables
			//Table 1.In studio
			string SqlString="select distinct instudio_photo_job_id,in_studio_photo_reservation.package_type_id,package_type_name,package_subtype_name,reserve_date from in_studio_photo_reservation,photo_package,package_type_name where in_studio_photo_reservation.package_type_id=package_type_name.package_type_id and in_studio_photo_reservation.package_type_id=photo_package.package_type_id and in_studio_photo_reservation.package_subtype_id=photo_package.package_subtype_id and photo_studio_contact_id="+contact_id;
			DataSet myDataSet1=db.Query(SqlString,"photo_job1");
			int count1=myDataSet1.Tables["photo_job1"].Rows.Count;
			//Table 2.Out studio
			SqlString="select distinct outstudio_photo_job_id,out_studio_photo_reservation.package_type_id,package_type_name,package_subtype_name,reserve_date from out_studio_photo_reservation,photo_package,package_type_name where out_studio_photo_reservation.package_type_id=package_type_name.package_type_id and out_studio_photo_reservation.package_type_id=photo_package.package_type_id and out_studio_photo_reservation.package_subtype_id=photo_package.package_subtype_id and photo_studio_contact_id="+contact_id;
			DataSet myDataSet2=db.Query(SqlString,"photo_job2");
			int count2=myDataSet2.Tables["photo_job2"].Rows.Count;
			//Table 3.Vdo studio
			SqlString="select distinct multimedia_job_id,multimedia_order.package_type_id,package_type_name,package_subtype_name,reserve_date from multimedia_order,photo_package,package_type_name where multimedia_order.package_type_id=package_type_name.package_type_id and multimedia_order.package_type_id=photo_package.package_type_id and multimedia_order.package_subtype_id=photo_package.package_subtype_id and photo_studio_contact_id="+contact_id;
			DataSet myDataSet3=db.Query(SqlString,"photo_job3");
			int count3=myDataSet3.Tables["photo_job3"].Rows.Count;
			int sum_count=count1+count2+count3;
			int i,j;
			contact_id_info[] contact_info = new contact_id_info[sum_count];
			//from In studio
			for (i=0,j=0;i<count1;i++,j++)
			{
				contact_info[i]=new contact_id_info();
				contact_info[i].type_id=System.Convert.ToString(myDataSet1.Tables["photo_job1"].Rows[i]["package_type_id"]);
				contact_info[i].job_id=System.Convert.ToInt32(myDataSet1.Tables["photo_job1"].Rows[i]["instudio_photo_job_id"]);
				contact_info[i].type_name=System.Convert.ToString(myDataSet1.Tables["photo_job1"].Rows[i]["package_type_name"]);
				contact_info[i].subtype_name=System.Convert.ToString(myDataSet1.Tables["photo_job1"].Rows[i]["package_subtype_name"]);
				contact_info[i].receive_date=photo.Photo.DateToString(System.Convert.ToDateTime(myDataSet1.Tables["photo_job1"].Rows[i]["reserve_date"]));
			}
			//from Out studio
			for (i=0;i<count2;i++,j++)
			{
				contact_info[j]=new contact_id_info();
				contact_info[j].job_id=System.Convert.ToInt32(myDataSet2.Tables["photo_job2"].Rows[i]["outstudio_photo_job_id"]);
				contact_info[j].type_id=System.Convert.ToString(myDataSet2.Tables["photo_job2"].Rows[i]["package_type_id"]);
				contact_info[j].type_name=System.Convert.ToString(myDataSet2.Tables["photo_job2"].Rows[i]["package_type_name"]);
				contact_info[j].subtype_name=System.Convert.ToString(myDataSet2.Tables["photo_job2"].Rows[i]["package_subtype_name"]);
				contact_info[j].receive_date=photo.Photo.DateToString(System.Convert.ToDateTime(myDataSet2.Tables["photo_job2"].Rows[i]["reserve_date"]));
			}
			//from Multimedia
			for (i=0;i<count3;i++,j++)
			{
				contact_info[j]=new contact_id_info();
				contact_info[j].job_id=System.Convert.ToInt32(myDataSet3.Tables["photo_job3"].Rows[i]["multimedia_job_id"]);
				contact_info[j].type_id=System.Convert.ToString(myDataSet3.Tables["photo_job3"].Rows[i]["package_type_id"]);
				contact_info[j].type_name=System.Convert.ToString(myDataSet3.Tables["photo_job3"].Rows[i]["package_type_name"]);
				contact_info[j].subtype_name=System.Convert.ToString(myDataSet3.Tables["photo_job3"].Rows[i]["package_subtype_name"]);
				contact_info[j].receive_date=photo.Photo.DateToString(System.Convert.ToDateTime(myDataSet3.Tables["photo_job3"].Rows[i]["reserve_date"]));
			}
		
			return contact_info;
		}
		//-- 11. show IN STUDIO reserve by job_id
		[WebMethod]
		public photo_vdo_job_id_info show_instudio_by_job_id(int contact_id,int job_id)
		{	
			string SqlString = "select distinct instudio_photo_job_id,photo_studio_contact_id,photo_package.package_type_id,photo_package.package_subtype_id,package_subtype_name,package_subtype_detail,reserve_date,round_time,job_total_price from in_studio_photo_reservation,in_studio_time,photo_package where in_studio_photo_reservation.package_type_id=photo_package.package_type_id and in_studio_photo_reservation.package_subtype_id=photo_package.package_subtype_id and in_studio_photo_reservation.round=in_studio_time.round and photo_studio_contact_id="+contact_id+" and instudio_photo_job_id="+job_id;
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//select  Detail 
			DataSet myDataSet=db.Query(SqlString,"photo");
			int count=myDataSet.Tables["photo"].Rows.Count;
			//int i;

			if(count==1)
			{
				photo_vdo_job_id_info job_info = new photo_vdo_job_id_info();
	
				//job_info[i]=new photo_vdo_job_id_info();
				job_info.contact_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[0]["photo_studio_contact_id"]);
				job_info.job_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[0]["instudio_photo_job_id"]);
				job_info.type_id=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_type_id"]);
				job_info.subtype_id=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_id"]);
				job_info.subtype_name=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_name"]);
				job_info.subtype_detail=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_detail"]);
				DateTime z= Convert.ToDateTime(myDataSet.Tables["photo"].Rows[0]["reserve_date"]);
				z=z.AddYears(-543);
				job_info.reserve_date=System.Convert.ToString(z);
				job_info.round=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["round_time"]);
				job_info.job_total_price=System.Convert.ToDouble(myDataSet.Tables["photo"].Rows[0]["job_total_price"]);
	
				return job_info;
			}
			else 
				return null;
		}
	
		//-- 11.4 show OUT STUDIO reserve by job_id
		[WebMethod]
		public photo_vdo_job_id_info show_outstudio_by_job_id(int contact_id,int job_id)
		{	
			string SqlString = "select distinct outstudio_photo_job_id,photo_studio_contact_id,photo_package.package_type_id,photo_package.package_subtype_id,package_subtype_name,package_subtype_detail,reserve_date,round_time,job_total_price from out_studio_photo_reservation,out_studio_time,photo_package where out_studio_photo_reservation.package_type_id=photo_package.package_type_id and out_studio_photo_reservation.package_subtype_id=photo_package.package_subtype_id and out_studio_photo_reservation.round=out_studio_time.round and photo_studio_contact_id="+contact_id+" and outstudio_photo_job_id="+job_id;
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//select  Detail 
			DataSet myDataSet=db.Query(SqlString,"photo");
			int count=myDataSet.Tables["photo"].Rows.Count;
			//int i;

			if(count==1)
			{
				photo_vdo_job_id_info job_info = new photo_vdo_job_id_info();
	
				//job_info[i]=new photo_vdo_job_id_info();
				job_info.contact_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[0]["photo_studio_contact_id"]);
				job_info.job_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[0]["outstudio_photo_job_id"]);
				job_info.type_id=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_type_id"]);
				job_info.subtype_id=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_id"]);
				job_info.subtype_name=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_name"]);
				job_info.subtype_detail=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_detail"]);
				DateTime z= Convert.ToDateTime(myDataSet.Tables["photo"].Rows[0]["reserve_date"]);
				z=z.AddYears(-543);
				job_info.reserve_date=System.Convert.ToString(z);
				job_info.round=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["round_time"]);
				job_info.job_total_price=System.Convert.ToDouble(myDataSet.Tables["photo"].Rows[0]["job_total_price"]);
	
				return job_info;
			}
			else 
				return null;
		}
	
		//-- 11.5 show MultiMedia reserve by job_id
		[WebMethod]
		public multimedia_job_id_info show_multimedia_by_job_id(int contact_id,int job_id)
		{	
			string SqlString = "select distinct multimedia_job_id,photo_studio_contact_id,photo_package.package_type_id,photo_package.package_subtype_id,package_subtype_name,package_subtype_detail,reserve_date,finish_date,job_total_price from multimedia_order,photo_package where multimedia_order.package_type_id=photo_package.package_type_id and multimedia_order.package_subtype_id=photo_package.package_subtype_id and  photo_studio_contact_id="+contact_id+" and multimedia_job_id="+job_id;
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//select  Detail 
			DataSet myDataSet=db.Query(SqlString,"photo");
			int count=myDataSet.Tables["photo"].Rows.Count;
			if(count==1)
			{
				multimedia_job_id_info job_info = new multimedia_job_id_info();
	
				//job_info[i]=new photo_vdo_job_id_info();
				job_info.contact_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[0]["photo_studio_contact_id"]);
				job_info.job_id=System.Convert.ToInt32(myDataSet.Tables["photo"].Rows[0]["multimedia_job_id"]);
				job_info.type_id=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_type_id"]);
				job_info.subtype_id=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_id"]);
				job_info.subtype_name=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_name"]);
				job_info.subtype_detail=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["package_subtype_detail"]);
				DateTime z = Convert.ToDateTime(myDataSet.Tables["photo"].Rows[0]["reserve_date"]);
				z=z.AddYears(-543);
				job_info.reserve_date=System.Convert.ToString(z);
				job_info.finish_date=System.Convert.ToString(myDataSet.Tables["photo"].Rows[0]["finish_date"]);
				job_info.job_total_price=System.Convert.ToDouble(myDataSet.Tables["photo"].Rows[0]["job_total_price"]);
				return job_info;
			}
			else 
				return null;
		}
		//-- 12.1 Order In Studio Cancle by contact -->
		[WebMethod]
		public bool in_studio_cancle_contact(int customer_id,int contact_id)
		{	
			string SqlString="select count(*) from in_studio_photo_reservation where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			SqlString="delete from in_studio_photo_reservation where photo_studio_contact_id="+contact_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;

		}
		//-- 12.2 Order IN Studio Cancle by job --> 
		[WebMethod]
		public bool in_studio_cancle_job(int customer_id,int contact_id,int job_id)
		{	
			string SqlString="select count(*) from in_studio_photo_reservation where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id+" and instudio_photo_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			SqlString="delete from in_studio_photo_reservation where photo_studio_contact_id="+contact_id+" and instudio_photo_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;
		}
		//-- 12.3 Order Out Studio Cancle by contact -->
		[WebMethod]
		public bool out_studio_cancle_contact(int customer_id,int contact_id)
		{	
			string SqlString="select count(*) from out_studio_photo_reservation where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			SqlString="delete from out_studio_photo_reservation where photo_studio_contact_id="+contact_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;

		}
		//-- 12.4 Order Out Studio Cancle by job --> 
		[WebMethod]
		public bool out_studio_cancle_job(int customer_id,int contact_id,int job_id)
		{	
			string SqlString="select count(*) from out_studio_photo_reservation where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id+" and outstudio_photo_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			SqlString="delete from out_studio_photo_reservation where photo_studio_contact_id="+contact_id+" and outstudio_photo_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;
		}
		//-- 12.5 Order Multimedia Studio Cancle by contact -->
		[WebMethod]
		public bool multimedia_cancle_contact(int customer_id,int contact_id)
		{	
			string SqlString="select count(*) from multimedia_order where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			SqlString="delete from multimedia_order where photo_studio_contact_id="+contact_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;

		}
		//-- 12.6 Order Multimedia Studio Cancle by job --> 
		[WebMethod]
		public bool multimedia_cancle_job(int customer_id,int contact_id,int job_id)
		{	
			string SqlString="select count(*) from multimedia_order where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id+" and multimedia_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			SqlString="delete from multimedia_order where photo_studio_contact_id="+contact_id+" and multimedia_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;
		}
		//Cancle  contact all table(all type of job)
		[WebMethod]
		public bool cancle_contact(int customer_id,int contact_id)
		{	
			//check if customer and contact exist
			string SqlString="select count(*) from photo_studio_contact where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;

			//check  there are job in this table		
			SqlString="select count(*) from multimedia_order where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			string result="";
			if(count!=0)
			{
				SqlString="delete from multimedia_order where photo_studio_contact_id="+contact_id;
				result=db.Excute(SqlString);
			}
			SqlString="select count(*) from in_studio_photo_reservation where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			if(count!=0)
			{
				SqlString="delete from in_studio_photo_reservation where photo_studio_contact_id="+contact_id;
				result=db.Excute(SqlString);
			}
			SqlString="select count(*) from out_studio_photo_reservation where customer_id="+customer_id+" and photo_studio_contact_id="+contact_id;
			count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			if(count!=0)
			{
				SqlString="delete from out_studio_photo_reservation where photo_studio_contact_id="+contact_id;
				result=db.Excute(SqlString);
			}	
					
			SqlString="delete photo_studio_contact where photo_studio_contact_id="+contact_id+" and customer_id="+customer_id;
			result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;
		}
		//-- 13.1 Edit IN Studio time 
		[WebMethod]
		public string in_studio_edit_reservation(int customer_id,int contact_id,int job_id,string reservedates,int round)
		{	
			//Build String -> Date
			DateTime reserve_date= photo.Photo.StringToDate(reservedates);

			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (reserve_date.DayOfYear-DateTime.Now.DayOfYear)<10)
				return "";

			// U must to change TIME DATE
			string reserve_date2=reserve_date.Year+"/"+reserve_date.Month+"/"+reserve_date.Day+" "+reserve_date.Hour+":"+reserve_date.Minute+":"+reserve_date.Millisecond;
			string SqlString="Update in_studio_photo_reservation SET reserve_date='"+reserve_date2+"' , round='"+round+"' where instudio_photo_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			string result=db.Excute(SqlString);
			if(result=="ok")
			{
				// UPDATE Contact ------------------

				//check old deadline exist
				SqlString="Select deadline_confirm from photo_studio_contact where photo_studio_contact_id ="+contact_id;
				DateTime old_deadline = new DateTime();
				bool have_old_deadline;
				try
				{
					old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
					have_old_deadline=true;
				}
				catch(System.Exception e)
				{
					have_old_deadline=false;
				}
				//if old deadline exist 
				if (have_old_deadline)
				{
					DateTime new_deadline = reserve_date.Subtract(deadline);
					//if new deadline date arrive before old deadline ->Update Deadline
					if(new_deadline.DayOfYear<old_deadline.DayOfYear)
					{
						string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
						SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
						db.Excute(SqlString);
					}
					return photo.Photo.DateToString(new_deadline);
				
				}
				else
				{
					DateTime new_deadline = reserve_date.Subtract(deadline);
					string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
					db.Excute(SqlString);
					// reutrn job_id
					return photo.Photo.DateToString(new_deadline);
				}
			}
			else // else Update Success
				return "";

		}	
		//-- 13.2 Edit OUT Studio time 
		[WebMethod]
		public string out_studio_edit_reservation(int customer_id,int contact_id,int job_id,string reservedates,int round)
		{	
			//Build String -> Date
			DateTime reserve_date= photo.Photo.StringToDate(reservedates);

			// Check round must in the same interval as 4 hrs ,8 hrs ,12 hrs
			string SqlString = "select round from in_studio_photo_reservation where instudio_photo_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int old_round=Convert.ToInt32(db.ExcuteScalar(SqlString));
			if((old_round>0)&&(old_round<4)) //round 1-3
			{
				if((round<0)||(round>3))
					return "";
			}
			else if((old_round==4)||(old_round==5)) //round 4-5
			{
				if(!((round==4)||(round==5)))
					return "";
			}
			else if(old_round==6) //round 6
			{	
				if(round!=6)
					return "";
			}
			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (reserve_date.Year==DateTime.Now.Year))
			{
				if( (reserve_date.DayOfYear-DateTime.Now.DayOfYear)<10)
				{	
					return "";
				}
			}
			else if(reserve_date.Year<DateTime.Now.Year)
			{
				return "";
			}
			
				

			// U must to change TIME DATE
			string reserve_date2=reserve_date.Year+"/"+reserve_date.Month+"/"+reserve_date.Day+" "+reserve_date.Hour+":"+reserve_date.Minute+":"+reserve_date.Millisecond;
			SqlString="Update out_studio_photo_reservation SET reserve_date='"+reserve_date2+"' , round='"+round+"' where outstudio_photo_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
			{
				// UPDATE Contact ------------------

				//check old deadline exist
				SqlString="Select deadline_confirm from photo_studio_contact where photo_studio_contact_id ="+contact_id;
				DateTime old_deadline = new DateTime();
				bool have_old_deadline;
				try
				{
					old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
					have_old_deadline=true;
				}
				catch(System.Exception e)
				{
					have_old_deadline=false;
				}
				//if old deadline exist 
				if (have_old_deadline)
				{
					DateTime new_deadline = reserve_date.Subtract(deadline);
					//if new deadline date arrive before old deadline ->Update Deadline
					if(new_deadline.DayOfYear<old_deadline.DayOfYear)
					{
						string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
						SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
						db.Excute(SqlString);
					}
					return photo.Photo.DateToString(new_deadline);
				
				}
				else
				{
					DateTime new_deadline = reserve_date.Subtract(deadline);
					string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
					db.Excute(SqlString);
					// reutrn job_id
					return photo.Photo.DateToString(new_deadline);
				}
			}
			else // else Update Success
				return "";

		}

		//-- 13.3 Edit Multimedia time 
		[WebMethod]
		public string multimedia_edit_reservation(int customer_id,int contact_id,int job_id,string reservedates,string finishdates)
		{	
			//Build String -> DateTime
			DateTime reserve_date= photo.Photo.StringToDate(reservedates);
			//Build String -> Date
			DateTime finish_date= photo.Photo.StringToDate(finishdates);

			//check Day Reserve and Finish more than 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if((finish_date.DayOfYear-reserve_date.DayOfYear)<10)
				return "";
			//check Date you must order advance for 10 days
			if( (reserve_date.Year==DateTime.Now.Year))
			{
				if( (reserve_date.DayOfYear-DateTime.Now.DayOfYear)<10)
				{	
					return "";
				}
			}
			else if(reserve_date.Year<DateTime.Now.Year)
			{
				return "";
			}


			// U must to change TIME DATE
			string reserve_date2=reserve_date.Year+"/"+reserve_date.Month+"/"+reserve_date.Day+" "+reserve_date.Hour+":"+reserve_date.Minute+":"+reserve_date.Millisecond;
			string finish_date2=finish_date.Year+"/"+finish_date.Month+"/"+finish_date.Day+" "+finish_date.Hour+":"+finish_date.Minute+":"+finish_date.Millisecond;
			string SqlString="Update multimedia_order SET  reserve_date='"+reserve_date2+"' , finish_date='"+finish_date2+"' where multimedia_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			string result=db.Excute(SqlString);
			if(result=="ok")
			{
				// UPDATE Contact ------------------

				//check old deadline exist
				SqlString="Select deadline_confirm from photo_studio_contact where photo_studio_contact_id ="+contact_id;
				DateTime old_deadline = new DateTime();
				bool have_old_deadline;
				try
				{
					old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
					have_old_deadline=true;
				}
				catch(System.Exception e)
				{
					have_old_deadline=false;
				}
				//if old deadline exist 
				if (have_old_deadline)
				{
					DateTime new_deadline = reserve_date.Subtract(deadline);
					//if new deadline date arrive before old deadline ->Update Deadline
					if(new_deadline.DayOfYear<old_deadline.DayOfYear)
					{
						string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
						SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
						db.Excute(SqlString);
					}
					return photo.Photo.DateToString(new_deadline);
				
				}
				else
				{
					DateTime new_deadline = reserve_date.Subtract(deadline);
					string new_deadline2 = new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update photo_studio_contact SET deadline_confirm = '"+new_deadline2+"' where photo_studio_contact_id="+contact_id;
					db.Excute(SqlString);
					// reutrn job_id
					return photo.Photo.DateToString(new_deadline);
				}
			}
			else// else Update Success
				return "";
		}

	
	}//class
}//namespace 
