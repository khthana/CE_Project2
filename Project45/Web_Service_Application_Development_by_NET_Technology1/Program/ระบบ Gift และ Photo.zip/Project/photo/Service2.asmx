<%@ WebService Language="c#" Codebehind="Service2.asmx.cs" Class="photo2.Photo" %>
