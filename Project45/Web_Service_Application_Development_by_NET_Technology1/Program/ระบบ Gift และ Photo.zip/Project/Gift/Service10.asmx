<%@ WebService Language="c#" Codebehind="Service10.asmx.cs" Class="Gift10.Gifts" %>
