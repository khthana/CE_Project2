<%@ Application Codebehind="Global.asax.cs" Inherits="Gift.Global" %>
