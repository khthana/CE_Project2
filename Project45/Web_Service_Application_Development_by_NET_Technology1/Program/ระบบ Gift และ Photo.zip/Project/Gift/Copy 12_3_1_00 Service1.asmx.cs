using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace Gift
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class job_order
	{
		public decimal job_id;
		public string dead_line;
		public double price;
		public string address;
	}
	public class customer_id_info
	{
		public decimal contact_id;
		public string contact_name;
		public double totalPrice;
		public DateTime deadline;
	}
	public class contact_id_info
	{
		public decimal job_id;
		public string subtype_name;
		public DateTime receive_date;
	}
	public class job_id_info
	{
		public decimal contact_id; //new
		public decimal job_id; //new
		public string  type_id;
		public string subtype_id;
		public string  subtype_name; //new
		public string subtype_detail;//new
        public string label;
		public DateTime receive_date;
		public string address;
		public int quantity;
		public double job_total_price ;
	}
	public class GiftInfo
	{
		public string type_id;
		public string type_name;
		public string subtype_id;
		public string subtype_name;
		public string subtype_detail;
		public string pic_url;
		public double price;
	}
	public class TotalPrice
	{
		public decimal contact_number;
		public decimal[] job_id;
		public double[] jobtotalprice;
		public double totalprice;
		public DateTime deadline_confirm;
		
		public TotalPrice(){}
		public TotalPrice(decimal contact_numbers,int number_job,decimal[] job_ids,double[] jobtotalprices,double totalprices,DateTime deadline)
		{
			//--- number_job not use
			//int[] job_id = new int[number_job];
			//double jobtotalprice = new double[number_job];
			contact_number = contact_numbers;
			job_id = job_ids;
			jobtotalprice = jobtotalprices;
			totalprice=totalprices;
			deadline_confirm = new DateTime();
			deadline_confirm=deadline;
		}
	}
	public class OrderInfo
	{
		public string username;
		public string type_id;
		public string subtype_id;
		public string subtype_detail;
		public string label;
		public DateTime recievedate;
		//		DateTime recievetime;
		public string address;
		public int quantity;
		public DateTime deadline_confirm;		

		public OrderInfo(DateTime recieve,DateTime deadline)
		{
			recievedate = new DateTime();
			recievedate=recieve;
			deadline_confirm = new DateTime();
			deadline_confirm=deadline;
		}
	}


	public class Gifts : System.Web.Services.WebService
	{
		public Gifts()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5
		//-- 0. Test Fnction --
		[WebMethod]
		public job_order test()
		{
			return null;

//			DbComponent.Gift  db = new DbComponent.Gift();
//			DateTime now = DateTime.Now;
//			DateTime myDate = new DateTime(2003,1,10,9,0,0,0);
//			string SqlString = "select count(*) from customer where username='bank'";
//			//string result=
//			int nums=Convert.ToInt32(db.ExcuteScalar(SqlString));
			

		}
		//-- 1. Gift_Detail -> OK
		[WebMethod]
		public GiftInfo[] gift_detail (string type_id,string style,double min_price,double max_price)
		{	string tablename="tbl_giftinfo";
			//string SqlString ="select gift_subtype_id,Gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= 100 and gift_price <= 200 and gift_style = '��'";
			string SqlString;
			if( (type_id=="0")&& (style==""))
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price ;
			else if(type_id=="0") 
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'";
			else if(style=="") 
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price +"and Gift.gift_type_id='"+type_id+"'";
			else // search all condition
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'"+"and Gift.gift_type_id='"+type_id+"'";
			//string SqlString ="select * from gift_order";
			DbComponent.Gift db = new DbComponent.Gift();
			DataSet myDataSet=db.Query(SqlString,tablename);

			int count=myDataSet.Tables[tablename].Rows.Count;
			int i;
			GiftInfo[] gift_info = new GiftInfo[count];
							
			for (i=0;i<count;i++)
			{
				gift_info[i]=new GiftInfo();
				gift_info[i].type_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_type_id"]);
				gift_info[i].type_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_type_name"]);
				gift_info[i].subtype_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_id"]);
				gift_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_name"]);
				gift_info[i].subtype_detail=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_detail"]);
				gift_info[i].pic_url=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_pic_url"]);
				gift_info[i].price=System.Convert.ToDouble(myDataSet.Tables[tablename].Rows[i]["gift_price"]);

			}
			return gift_info;
			//return myDataSet;

		}
		
		//-- 2. Place_detail -- read address from text
		[WebMethod]
		public string place_detail()
		{	
			// + change address
			return "Address of Gift Shop place";
		}
		//-- 3. Sign Up -> OK but should return  case of error
		[WebMethod]
		public bool signup(string username,string password,string firstname,string lastname,string sex,int age,string tel,string address,string email)
		{	
			string SqlString="select count(*) from customer where username ='"+username+"'";
			DbComponent.Gift db = new DbComponent.Gift();
			int count = Convert.ToInt16(db.ExcuteScalar(SqlString));
			//if exist return 0
			if (count==1)
				return false;
			SqlString="Insert into customer values ('"+username+"','"+password+"','"+firstname+"','"+lastname+"','"+sex+"',"+age+",'"+tel+"','"+address+"','"+email+"')";
			string result=db.Excute(SqlString);	
			if(result=="ok")
				return true;
			return false;
		}
		//-- 4. Login ->true OK
		[WebMethod]
		public int login(string username,string password)
		{	
			string SqlString="select customer_id from customer where username='"+username+"' and password='"+password+"'";
			DbComponent.Gift db = new DbComponent.Gift();
			int result=Convert.ToInt16(db.ExcuteScalar(SqlString));
			if(result==0)
				return 0;
			else
				return result;

		}

		//-- 5. Create_contact_id -> OK
		[WebMethod]
		public decimal create_contact_id(string username,string contact_name)
		{	
			// select customer id from username
			string SqlString = "Select customer_id from customer where username='"+username+"'";
			DbComponent.Gift  db = new DbComponent.Gift();
			decimal customer_id = System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			// insert customer id to get new contact id
			SqlString = "Insert gift_shop_contact(customer_id,gift_shop_contact_name) values ("+customer_id+",'"+contact_name+"')";
			string result=db.Excute(SqlString);
			if(result=="ok")
			{
				SqlString = "Select gift_shop_contact_id from gift_shop_contact where customer_id="+customer_id + " order by gift_shop_contact_id desc";
				decimal gift_contact_id = System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
				
				return gift_contact_id;
			}
			else
			{
				//Console.WriteLine(result);
				
				return 0;
			}
		}
		//-- 6. Order -> return job id
		[WebMethod]
		public job_order order(decimal customer_id,decimal contact_id,string type_id,string subtype_id,string font_style,string font_color,string label,DateTime receivedate,string address,int quantity)
		{	
			// **** parameter forgot font syle , font color
			//string font_color ="pink";
			//string font_style="Arial";
			//DateTime myTime = new DateTime(2003,3,15,9,0,0);
			DateTime myTime = receivedate;
			//check time 9.00-17.00
			TimeSpan start_time = new TimeSpan(0,9,0,0,0);
			TimeSpan stop_time = new TimeSpan(0,17,0,0,0);
			//check if not range of time 8.00-17.00 -> ERROR  return 0
			if(!((myTime.TimeOfDay>start_time) && (myTime.TimeOfDay<stop_time)))
				return null;
			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,17,0,0,0);
			if( (myTime.DayOfYear-DateTime.Now.DayOfYear)<10)
				return null;
			DbComponent.Gift db = new DbComponent.Gift();
			//Slect customer_id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			//decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//Calculate Job Price : Quantity * gift_price
			string SqlString="Select gift_price from gift where gift_type_id='"+type_id+"' and gift_subtype_id='"+subtype_id+"'";
			int gift_price=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			int job_total_price = gift_price * quantity;
			//Insert Order
			string date_format=receivedate.Year+"-"+receivedate.Month+"-"+receivedate.Day+" "+receivedate.Hour+":"+receivedate.Minute+"."+receivedate.Millisecond;
			SqlString ="Insert gift_order (gift_shop_contact_id,gift_type_id,gift_subtype_id,printed_message,font_color,font_style,receive_date,receive_address,quantity,job_total_price) values("+contact_id+","+type_id+","+subtype_id+",'"+label+"','"+font_color+"','"+font_style+"','"+date_format+"','"+address+"',"+quantity+","+job_total_price+")";
			string result=db.Excute(SqlString);
			//check old deadline exist
			SqlString="Select deadline_confirm from gift_shop_contact where gift_shop_contact_id ="+contact_id;
			DateTime old_deadline = new DateTime();
			bool have_old_deadline;
			try
			{
				old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
				have_old_deadline=true;
			}
			catch(System.Exception e)
			{
				have_old_deadline=false;
			}
			//if old deadline exist 
			if (have_old_deadline)
			{
				DateTime new_deadline = myTime.Subtract(deadline);
				//if new deadline date arrive before old deadline ->Update Deadline
				if(new_deadline.DayOfYear<old_deadline.DayOfYear)
				{
					SqlString="Update gift_shop_contact SET deadline_confirm = '"+new_deadline+"' where gift_shop_contact_id="+contact_id;
					db.Excute(SqlString);
				}
				// reutrn job_id
				SqlString="select gift_job_id from gift_order where gift_shop_contact_id="+contact_id+" and printed_message='"+label+"' order by gift_job_id desc";
				decimal job_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
				//Bulid job_order class
				job_order order = new job_order();
				string 	new_deadline2=new_deadline.Day+" "+new_deadline.Month+" "+new_deadline.Year+" "+new_deadline.Hour+":"+new_deadline.Minute+":"+new_deadline.Second;
				order.job_id=job_id;
				order.dead_line=new_deadline2;
				order.price=job_total_price;
				order.address=place_detail();
				return order;
				}
			else
			{
				DateTime new_deadline = myTime.Subtract(deadline);
				SqlString="Update gift_shop_contact SET deadline_confirm = '"+new_deadline+"' where gift_shop_contact_id="+contact_id;
				db.Excute(SqlString);
				// reutrn job_id
				SqlString="select gift_job_id from gift_order where gift_shop_contact_id="+contact_id+" and printed_message='"+label+"' order by gift_job_id desc";
				decimal job_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
				//Bulid job_order class
				job_order order = new job_order();
				string new_deadline2=new_deadline.Day+" "+new_deadline.Month+" "+new_deadline.Year+" "+new_deadline.Hour+":"+new_deadline.Minute+":"+new_deadline.Second;
				order.job_id=job_id;
				order.dead_line=new_deadline2;
				order.price=job_total_price;
				order.address=place_detail();
				return order;

			}
						
			return null;
		}
		//-- 7. Total -- OK
		[WebMethod]
		public TotalPrice total(decimal customer_id,decimal contact_id)
		{
			//Slect customer_id from username
//			string SqlString = "Select customer_id from customer where username='"+username+"'";
//			decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			DbComponent.Gift db = new DbComponent.Gift();
			string SqlString="select gift_job_id,job_total_price  from gift_order where gift_shop_contact_id="+contact_id;
			DataSet myDataSet=db.Query(SqlString,"gift_order");
			//DataTable myDataTable 
			int count=myDataSet.Tables["gift_order"].Rows.Count;
			decimal[] job_id = new decimal[count];
			double[] job_price = new double[count];
			int i;
			double totalprice=0;
			for (i=0;i<count;i++)
			{
				job_id[i]=System.Convert.ToDecimal(myDataSet.Tables["gift_order"].Rows[i]["gift_job_id"]);
				job_price[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["job_total_price"]);
				totalprice=totalprice+job_price[i];
			}
			// get DeadLine Date 
			SqlString ="select deadline_confirm from gift_shop_contact where gift_shop_contact_id="+contact_id;
			DateTime deadline_date=Convert.ToDateTime(db.ExcuteScalar(SqlString));
			TotalPrice price = new TotalPrice(contact_id,count,job_id,job_price,totalprice,deadline_date);
			
			return price;
		}
		//-- 8. Pay -- Not to do now wait for BANK
		//-- 9.1 Show Order by Customer   --OK
		[WebMethod]
		public customer_id_info[] showorder_by_customer_name(decimal customer_id)
		{	
			//Select customer id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			DbComponent.Gift db =new DbComponent.Gift();
			//decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//select  Detail from Gift_Contact
			string SqlString="select gift_shop_contact_id,gift_shop_contact_name,deadline_confirm from gift_shop_contact where customer_id="+customer_id;
			DataSet myDataSet=db.Query(SqlString,"gift_shop_contact");
			int count=myDataSet.Tables["gift_shop_contact"].Rows.Count;
			int i;
			customer_id_info[] customer_info = new customer_id_info[count];
							
			for (i=0;i<count;i++)
			{
				customer_info[i]=new customer_id_info();
				customer_info[i].contact_id=System.Convert.ToDecimal(myDataSet.Tables["gift_shop_contact"].Rows[i]["gift_shop_contact_id"]);
				customer_info[i].contact_name=System.Convert.ToString(myDataSet.Tables["gift_shop_contact"].Rows[i]["gift_shop_contact_name"]);
				customer_info[i].deadline=System.Convert.ToDateTime(myDataSet.Tables["gift_shop_contact"].Rows[i]["deadline_confirm"]);
			}

			
			return customer_info;
		}
		//-- 9.2 Show Order by Contact Id   --OK
		[WebMethod]
		public contact_id_info[] showorder_by_contact_id(decimal contact_id)
		{	
			//select contact_id
			//string SqlString="select  photo_studio_contact_id from photo_studio_contact where photo_studio_contact_name ='"+contact_name+"'";
			//DbComponent.Gift db =new DbComponent.Gift();
			//decimal contact_id = db.ExcuteScalar(SqlString);
			//select  Detail from Gift_Contact
			DbComponent.Gift db =new DbComponent.Gift();
			string SqlString="select gift_job_id,gift_subtype_name,receive_date from gift_order,gift where gift_order.gift_subtype_id=gift.gift_subtype_id and gift_shop_contact_id="+contact_id;
			DataSet myDataSet=db.Query(SqlString,"contact");
			int count=myDataSet.Tables["contact"].Rows.Count;
			int i;
			contact_id_info[] contact_info = new contact_id_info[count];
							
			for (i=0;i<count;i++)
			{
				contact_info[i]=new contact_id_info();
				contact_info[i].job_id=System.Convert.ToDecimal(myDataSet.Tables["contact"].Rows[i]["gift_job_id"]);
				contact_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables["contact"].Rows[i]["gift_subtype_name"]);
				contact_info[i].receive_date=System.Convert.ToDateTime(myDataSet.Tables["contact"].Rows[i]["receive_date"]);
			}
		
			return contact_info;
		}

		//-- 9.3 Show Order by Job Id   --> OK
		[WebMethod]
		public job_id_info showorder_by_job_id(decimal contact_id,decimal job_id)
		{	
			//			//Select customer id from username
			//			string SqlString = "Select customer_id from customer where username='"+username+"'";
			////			DbComponent.Gift db =new DbComponent.Gift();
			//			decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//select  Detail from Gift_Contact
			DbComponent.Gift db =new DbComponent.Gift();
			string SqlString="select gift_job_id,gift_shop_contact_id,gift.gift_type_id,gift.gift_subtype_id,gift_subtype_name,gift_subtype_detail,printed_message,receive_date,receive_address,quantity,job_total_price  from gift_order,gift where gift_order.gift_type_id=gift.gift_type_id and gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
			DataSet myDataSet=db.Query(SqlString,"job");
			int count=myDataSet.Tables["job"].Rows.Count;
			int i=0;
			job_id_info job_info = new job_id_info();
			
				job_info.contact_id=System.Convert.ToDecimal(myDataSet.Tables["job"].Rows[i]["gift_shop_contact_id"]);
				job_info.job_id=System.Convert.ToDecimal(myDataSet.Tables["job"].Rows[i]["gift_job_id"]);
				job_info.type_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_type_id"]);
				job_info.subtype_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_id"]);
				job_info.subtype_name=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_name"]);
				job_info.subtype_detail=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_detail"]);
				job_info.label=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["printed_message"]);
				job_info.receive_date=System.Convert.ToDateTime(myDataSet.Tables["job"].Rows[i]["receive_date"]);
				job_info.address=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["receive_address"]);
				job_info.quantity=System.Convert.ToInt32(myDataSet.Tables["job"].Rows[i]["quantity"]);
				job_info.job_total_price=System.Convert.ToDouble(myDataSet.Tables["job"].Rows[i]["job_total_price"]);
			
		
			return job_info;
		}

//		//-- 9.3 Show Order by Job Id   --> OK
//		[WebMethod]
//		public job_id_info[] showorder_by_job_id(decimal contact_id,decimal job_id)
//		{	
//			//			//Select customer id from username
//			//			string SqlString = "Select customer_id from customer where username='"+username+"'";
//			////			DbComponent.Gift db =new DbComponent.Gift();
//			//			decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
//			//select  Detail from Gift_Contact
//			DbComponent.Gift db =new DbComponent.Gift();
//			string SqlString="select gift_job_id,gift_shop_contact_id,gift.gift_type_id,gift.gift_subtype_id,gift_subtype_name,gift_subtype_detail,printed_message,receive_date,receive_address,quantity,job_total_price  from gift_order,gift where gift_order.gift_type_id=gift.gift_type_id and gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
//			DataSet myDataSet=db.Query(SqlString,"job");
//			int count=myDataSet.Tables["job"].Rows.Count;
//			int i;
//			job_id_info[] job_info = new job_id_info[count];
//			
//			for (i=0;i<count;i++)
//			{
//				job_info[i]=new job_id_info();
//				job_info[i].contact_id=System.Convert.ToDecimal(myDataSet.Tables["job"].Rows[i]["gift_shop_contact_id"]);
//				job_info[i].job_id=System.Convert.ToDecimal(myDataSet.Tables["job"].Rows[i]["gift_job_id"]);
//				job_info[i].type_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_type_id"]);
//				job_info[i].subtype_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_id"]);
//				job_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_name"]);
//				job_info[i].subtype_detail=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_detail"]);
//				job_info[i].label=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["printed_message"]);
//				job_info[i].receive_date=System.Convert.ToDateTime(myDataSet.Tables["job"].Rows[i]["receive_date"]);
//				job_info[i].address=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["receive_address"]);
//				job_info[i].quantity=System.Convert.ToInt32(myDataSet.Tables["job"].Rows[i]["quantity"]);
//				job_info[i].job_total_price=System.Convert.ToDouble(myDataSet.Tables["job"].Rows[i]["job_total_price"]);
//			}
//		
//			return job_info;
//		}
		//-- 10. Edit Order --
		[WebMethod]
		public string edit_order(decimal contact_id,decimal job_id,DateTime receivetime,string address,string label)
		{	
			// Check that we can change befor receive date 10 days
			//string SqlString ="select receive_date from gift_order where gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
			DbComponent.Gift db = new DbComponent.Gift();
			//DateTime old_receive=db.ExcuteScalar(SqlString);
			TimeSpan diffDate=receivetime.Subtract(DateTime.Now);
			if((diffDate.Days<10))
				return "You must change receive date to the day before receive for 10 days";
			string SqlString="Update gift_order SET receive_date= '"+receivetime+"',printed_message='"+label+"',receive_address='"+address+"' where gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return "Ok , You can edit your order information";
			else
				return "There's something error about your parameter passed";
		}
		//-- 11.1 Order Cancle by contact --> OK
		[WebMethod]
		public bool order_cancle_contact(decimal customer_id,decimal contact_id)
		{	
			string SqlString="select count(*) from customer where customer_id=2"+customer_id;
			DbComponent.Gift db = new DbComponent.Gift();
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;
			SqlString="delete from gift_order where gift_shop_contact_id="+contact_id;
			
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;

		}
		//-- 11.2 Order Cancle by job --> OK
		[WebMethod]
		public bool order_cancle_job(int customer_id,decimal contact_id,decimal job_id)
		{	
			string SqlString="select count(*) from customer where customer_id=2"+customer_id;
			DbComponent.Gift db = new DbComponent.Gift();
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;
			SqlString="delete from gift_order where gift_shop_contact_id="+contact_id+" and  gift_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;

		}

	}
}
