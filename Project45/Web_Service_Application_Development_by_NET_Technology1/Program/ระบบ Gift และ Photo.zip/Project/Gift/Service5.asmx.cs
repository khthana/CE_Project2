using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace Gift5
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class order_queue
	{
		public	int customer_id;
		public	int contact_id;
		public	string type_id;
		public	string subtype_id;
		public	string font_style;
		public	string font_color;
		public	string label;
		public	string receivedateS;
		public	string address;
		public	int quantity;
	}
	public class contact
	{
		public int contact_id;
		public string contact_name;
	}

	public class job_order
	{
		public int job_id;
		public string dead_line;
		public double price;
	}
	public class customer_id_info
	{
		public int contact_id;
		public string contact_name;
		public double totalPrice;
		public string deadline;//datetime
	}
	public class contact_id_info
	{
		public int job_id;
		public string subtype_name;
		public string receive_date; //datetime
	}
	public class job_id_info
	{
		public int contact_id; //new
		public int job_id; //new
		public string  type_id;
		public string subtype_id;
		public string  subtype_name; //new
		public string subtype_detail;//new
		public string label;
		public string receive_date;//datetime
		public string address;
		public int quantity;
		public double job_total_price ;
	}
	public class GiftInfo
	{
		public string type_id;
		public string type_name;
		public string subtype_id;
		public string subtype_name;
		public string subtype_detail;
		public string pic_url;
		public double price;
	}
	public class TotalPrice
	{
		public int contact_id;
		public int[] job_id;
		public double[] jobtotalprice;
		public double totalprice;
		public string deadline_confirm;
		
		public TotalPrice(){}
		public TotalPrice(int contact_numbers,int number_job,int[] job_ids,double[] jobtotalprices,double totalprices,DateTime deadline)
		{
			//--- number_job not use
			//int[] job_id = new int[number_job];
			//double jobtotalprice = new double[number_job];
			contact_id = contact_numbers;
			job_id = job_ids;
			jobtotalprice = jobtotalprices;
			totalprice=totalprices;
			//deadline_confirm = new DateTime();
			deadline_confirm=Gift.Gifts.DateToString(deadline);
			//deadline_confirm=deadline;
		}
	}
	public class OrderInfo
	{
		public string username;
		public string type_id;
		public string subtype_id;
		public string subtype_detail;
		public string label;
		public string recievedate;
		//		DateTime recievetime;
		public string address;
		public int quantity;
		public string deadline_confirm;		

		public OrderInfo(DateTime recieve,DateTime deadline)
		{
			//recievedate = new DateTime();
			recievedate=Gift.Gifts.DateToString(recieve);
			//deadline_confirm = new DateTime();
			deadline_confirm=Gift.Gifts.DateToString(deadline);
		}
	}


	public class Gifts : System.Web.Services.WebService
	{
		int iCount=0;
		private System.Messaging.MessageQueue MQ;
		System.Messaging.Message m;
		string DbConnection;
		public Gifts()
		{
			DbConnection="Server=localhost;database=gift5;uid=sa;pwd=;";
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{

			this.MQ = new System.Messaging.MessageQueue();
			this.MQ.Path = "olala154\\Private$\\msmq1";
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5
		//-- 0. Test Fnction --
		public static DateTime StringToDate(string input_date)
		{			
			//input_date = "12 01 1993";
			string dd = input_date.Substring(0,2);
			string mm = input_date.Substring(3,2);
			string yy = input_date.Substring(6,4);
			int intyy = 543 + System.Convert.ToInt32(yy);
			string newyy = System.Convert.ToString(intyy);
			string output_date = newyy + "-" + mm + "-" + dd;
			DateTime x = System.Convert.ToDateTime(output_date);
			return x;
		}

		public static DateTime StringToTime(string input_time)
		{
			//input_date = "12 01 1993";
			string hh = input_time.Substring(0,2);
			string mm = input_time.Substring(3,2);
			string ss = input_time.Substring(6,2);
			string output_time = hh + ":" + mm + ":" + ss;
			DateTime x = System.Convert.ToDateTime(output_time);
			return x;
		}
		public static DateTime StringToDateTime(string input)
		{
			//input_date = "12 01 1993";
			string dd = input.Substring(0,2);
			string mm = input.Substring(3,2);
			string yy = input.Substring(6,4);
			int intyy = 543 + System.Convert.ToInt32(yy);
			string newyy = System.Convert.ToString(intyy);
			string output_date = newyy + "-" + mm + "-" + dd;

			string hh = input.Substring(11,2);
			mm = input.Substring(14,2);
			string ss = input.Substring(17,2);
			string output_time = hh + ":" + mm + ":" + ss;

			string output_date_time = output_date+" "+output_time;
			DateTime x = System.Convert.ToDateTime(output_date_time);
		
			return x;
		}
		public static string DateToString(DateTime old)
		{
			string 	newdate=old.Day+" "+old.Month+" "+old.Year+" "+old.Hour+":"+old.Minute+":"+old.Second;
			return newdate;
		}

		[WebMethod]
		public DateTime test(string a)
		{
			DateTime b = Gift.Gifts.StringToDateTime(a);

			return b;

			//			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			//			DateTime now = DateTime.Now;
			//			DateTime myDate = new DateTime(2003,1,10,9,0,0,0);
			//			string SqlString = "select count(*) from customer where username='bank'";
			//			//string result=
			//			int nums=Convert.ToInt32(db.ExcuteScalar(SqlString));
			

		}
		// Get Firstname
		[WebMethod]
		public string get_name(int customer_id)
		{
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			string SqlString = "select firstname from customer where customer_id="+customer_id;
			string a=Convert.ToString(db.ExcuteScalar(SqlString));
			return a;
		}
		// Get contact_id
		[WebMethod]
		public int get_contact_id(string contact_name)
		{
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			string SqlString = "select gift_shop_contact_id from gift_shop_contact where gift_shop_contact_name='"+contact_name+"'";
			int contact_id=Convert.ToInt32(db.ExcuteScalar(SqlString));
			return contact_id;
		}
		
		// Get contact_name
		[WebMethod]
			//public DataSet get_contact_name(int customer_id)
		public contact[] get_contact_name(int customer_id)
		{
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			string SqlString = "select gift_shop_contact_id,gift_shop_contact_name from gift_shop_contact where customer_id="+customer_id;
			DataSet myDataSet=db.Query(SqlString,"gift");

			int count=myDataSet.Tables["gift"].Rows.Count;
			int i;
			contact[] cont = new contact[count];

			for (i=0;i<count;i++)
			{
				cont[i] = new contact();
				cont[i].contact_name=System.Convert.ToString(myDataSet.Tables["gift"].Rows[i]["gift_shop_contact_name"]);
				cont[i].contact_id=System.Convert.ToInt32(myDataSet.Tables["gift"].Rows[i]["gift_shop_contact_id"]);
			}
			return cont;
		}


		//-- 1. Gift_Detail -> OK
		[WebMethod]
		public GiftInfo[] gift_detail (string type_id,string style,double min_price,double max_price)
		{
				string tablename="tbl_giftinfo";
			//string SqlString ="select gift_subtype_id,Gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= 100 and gift_price <= 200 and gift_style = '��'";
			string SqlString;
			if( (type_id=="0")&& (style==""))
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price+" order by Gift.gift_type_id" ;
			else if(type_id=="0") 
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'"+" order by Gift.gift_type_id";
			else if(style=="") 
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price +"and Gift.gift_type_id='"+type_id+"'"+" order by Gift.gift_type_id";
			else // search all condition
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'"+"and Gift.gift_type_id='"+type_id+"'"+" order by Gift.gift_type_id";
			//string SqlString ="select * from gift_order";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			DataSet myDataSet=db.Query(SqlString,tablename);

			int count=myDataSet.Tables[tablename].Rows.Count;
			int i;
			GiftInfo[] gift_info = new GiftInfo[count];
			for (i=0;i<count;i++)
			{
				gift_info[i]=new GiftInfo();
				gift_info[i].type_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_type_id"]);
				gift_info[i].type_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_type_name"]);
				gift_info[i].subtype_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_id"]);
				gift_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_name"]);
				gift_info[i].subtype_detail=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_detail"]);
				gift_info[i].pic_url=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_pic_url"]);
				gift_info[i].price=System.Convert.ToDouble(myDataSet.Tables[tablename].Rows[i]["gift_price"]);

			}
			return gift_info;
			//return myDataSet;

		}
		//-- 1.2 Gift_Detail -> OK  RETURN DATASET
		[WebMethod]
		public DataSet gift_detail2 (string type_id,string style,double min_price,double max_price)
		{
			string tablename="gift";
			//string SqlString ="select gift_subtype_id,Gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= 100 and gift_price <= 200 and gift_style = '��'";
			string SqlString;
			if( (type_id=="0")&& (style==""))
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price ;
			else if(type_id=="0") 
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'";
			else if(style=="") 
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price +"and Gift.gift_type_id='"+type_id+"'";
			else // search all condition
				SqlString ="select gift_subtype_id,gift.gift_type_id,gift_style,gift_price,gift_subtype_name,gift_pic_url,gift_subtype_detail,gift_type_name from Gift , Type_name Where Gift.gift_type_id = Type_name.gift_type_id and gift_price >= " + min_price+" and gift_price <= "+ max_price + " and gift_style = '"+style+"'"+"and Gift.gift_type_id='"+type_id+"'";
			//string SqlString ="select * from gift_order";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			DataSet myDataSet=db.Query(SqlString,tablename);
			return myDataSet;

			int count=myDataSet.Tables[tablename].Rows.Count;
			int i;
			GiftInfo[] gift_info = new GiftInfo[count];
							
			for (i=0;i<count;i++)
			{
				gift_info[i]=new GiftInfo();
				gift_info[i].type_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_type_id"]);
				gift_info[i].type_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_type_name"]);
				gift_info[i].subtype_id=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_id"]);
				gift_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_name"]);
				gift_info[i].subtype_detail=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_subtype_detail"]);
				gift_info[i].pic_url=System.Convert.ToString(myDataSet.Tables[tablename].Rows[i]["gift_pic_url"]);
				gift_info[i].price=System.Convert.ToDouble(myDataSet.Tables[tablename].Rows[i]["gift_price"]);

			}
			//return gift_info;
			//return myDataSet;

		}
		//-- 2. Place_detail -- read address from text
		[WebMethod]
		public string place_detail()
		{	
			// + change address
			return "Bangkok Ladkrabang";
		}
		//-- 3. Sign Up -> OK but should return  case of error
		[WebMethod]
		public int signup(string username,string password,string firstname,string lastname,string sex,int age,string tel,string address,string email)
		{	
			string SqlString="select count(*) from customer where username ='"+username+"'";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = Convert.ToInt16(db.ExcuteScalar(SqlString));
			//if exist return 0
			if (count==1)
				return 0;
			SqlString="Insert into customer values ('"+username+"','"+password+"','"+firstname+"','"+lastname+"','"+sex+"',"+age+",'"+tel+"','"+address+"','"+email+"')";
			string result=db.Excute(SqlString);	
			if(result=="ok")
			{
				SqlString="select customer_id from customer where username='"+username+"' and password='"+password+"'";
				int customer_id =Convert.ToInt32(db.ExcuteScalar(SqlString));
				return customer_id;
				
			}
			else
				return 0;
		}
		//-- 4. Login ->true OK
		[WebMethod]
		public int login(string username,string password)
		{	
			string SqlString="select customer_id from customer where username='"+username+"' and password='"+password+"'";
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int result=Convert.ToInt16(db.ExcuteScalar(SqlString));
			if(result==0)
				return 0;
			else
				return result;

		}

		//-- 5. Create_contact_id -> OK
		[WebMethod]
		public int create_contact_id(int customer_id,string contact_name)
		{	
			// select customer id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			DbComponent.Gift  db = new DbComponent.Gift(DbConnection);
			//int customer_id = System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			// insert customer id to get new contact id
			string SqlString = "Insert gift_shop_contact(customer_id,gift_shop_contact_name) values ("+customer_id+",'"+contact_name+"')";
			string result=db.Excute(SqlString);
			if(result=="ok")
			{
				SqlString = "Select gift_shop_contact_id from gift_shop_contact where customer_id="+customer_id + " order by gift_shop_contact_id desc";
				int gift_contact_id = System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				
				return gift_contact_id;
			}
			else
			{
				//Console.WriteLine(result);
				
				return 0;
			}
		}
		//-- 6. Order -> return job id
		[WebMethod]
		public job_order order(int customer_id,int contact_id,string type_id,string subtype_id,string font_style,string font_color,string label,string receivedateS,string address,int quantity)
		{	
			DateTime receivedate=StringToDateTime(receivedateS);
			// **** parameter forgot font syle , font color
			//string font_color ="pink";
			//string font_style="Arial";
			//DateTime myTime = new DateTime(2003,3,15,9,0,0);
			DateTime myTime = receivedate;
			//check time 9.00-17.00
			TimeSpan start_time = new TimeSpan(0,9,0,0,0);
			TimeSpan stop_time = new TimeSpan(0,17,0,0,0);
			//check if not range of time 9.00-17.00 -> ERROR  return 0
			if(!((myTime.TimeOfDay>start_time) && (myTime.TimeOfDay<stop_time)))
				return null;
			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (myTime.DayOfYear-DateTime.Now.DayOfYear)<10)
				return null;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			//Slect customer_id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			//decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//Calculate Job Price : Quantity * gift_price
			string SqlString="Select gift_price from gift where gift_type_id='"+type_id+"' and gift_subtype_id='"+subtype_id+"'";
			int gift_price=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
			int job_total_price = gift_price * quantity;
			//Insert Order
			receivedate.AddYears(-543);
			string date_format=receivedate.Year+"-"+receivedate.Month+"-"+receivedate.Day+" "+receivedate.Hour+":"+receivedate.Minute+":"+receivedate.Millisecond;
			SqlString ="Insert gift_order (gift_shop_contact_id,customer_id,gift_type_id,gift_subtype_id,printed_message,font_color,font_style,receive_date,receive_address,quantity,job_total_price) values("+contact_id+","+customer_id+","+type_id+","+subtype_id+",'"+label+"','"+font_color+"','"+font_style+"','"+date_format+"','"+address+"',"+quantity+","+job_total_price+")";
			string result=db.Excute(SqlString);
			//check old deadline exist
			SqlString="Select deadline_confirm from gift_shop_contact where gift_shop_contact_id ="+contact_id;
			DateTime old_deadline = new DateTime();
			bool have_old_deadline;
			try
			{
				old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
				have_old_deadline=true;
			}
			catch(System.Exception e)
			{
				have_old_deadline=false;
			}
			//if old deadline exist 
			if (have_old_deadline)
			{
				DateTime new_deadline = myTime.Subtract(deadline);
				//if new deadline date arrive before old deadline ->Update Deadline
				if(new_deadline.DayOfYear<old_deadline.DayOfYear)
				{
					string new_deadline3=new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update gift_shop_contact SET deadline_confirm = '"+new_deadline3+"' where gift_shop_contact_id="+contact_id;
					db.Excute(SqlString);
				}
				else
					new_deadline=old_deadline;
				// reutrn job_id
				SqlString="select gift_job_id from gift_order where gift_shop_contact_id="+contact_id+" and printed_message='"+label+"' order by gift_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				//Bulid job_order class
				job_order order = new job_order();
				string 	new_deadline2=new_deadline.Day+" "+new_deadline.Month+" "+new_deadline.Year+" "+new_deadline.Hour+":"+new_deadline.Minute+":"+new_deadline.Second;
				order.job_id=job_id;
				order.dead_line=new_deadline2;
				order.price=job_total_price;
				return order;
			}
			else
			{
				DateTime new_deadline = myTime.Subtract(deadline);
				string new_deadline2=new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
				SqlString="Update gift_shop_contact SET deadline_confirm = '"+new_deadline2+"' where gift_shop_contact_id="+contact_id;
				db.Excute(SqlString);
				// reutrn job_id
				SqlString="select gift_job_id from gift_order where gift_shop_contact_id="+contact_id+" and printed_message='"+label+"' order by gift_job_id desc";
				int job_id=System.Convert.ToInt32(db.ExcuteScalar(SqlString));
				//Bulid job_order class
				job_order order = new job_order();
				new_deadline2=new_deadline.Day+" "+new_deadline.Month+" "+new_deadline.Year+" "+new_deadline.Hour+":"+new_deadline.Minute+":"+new_deadline.Second;
				order.job_id=job_id;
				order.dead_line=new_deadline2;
				order.price=job_total_price;
				return order;

			}
						
			return null;
		}

		//-- 6.1 Order -> MSMQQQQQQQQ
		[WebMethod]
		public bool order2(int customer_id,int contact_id,string type_id,string subtype_id,string font_style,string font_color,string label,string receivedateS,string address,int quantity)
		{	
			DateTime receivedate=StringToDateTime(receivedateS);
			// **** parameter forgot font syle , font color
			//string font_color ="pink";
			//string font_style="Arial";
			//DateTime myTime = new DateTime(2003,3,15,9,0,0);
			DateTime myTime = receivedate;
			//check time 9.00-17.00
			TimeSpan start_time = new TimeSpan(0,9,0,0,0);
			TimeSpan stop_time = new TimeSpan(0,17,0,0,0);
			//check if not range of time 9.00-17.00 -> ERROR  return 0
			if(!((myTime.TimeOfDay>start_time) && (myTime.TimeOfDay<stop_time)))
				return false;
			//check Date you must order advance for 10 days
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if( (myTime.DayOfYear-DateTime.Now.DayOfYear)<10)
				return false;

			order_queue obj_order = new order_queue();
			obj_order.customer_id=customer_id;
			obj_order.contact_id= contact_id;
			obj_order.type_id= type_id;
			obj_order.subtype_id= subtype_id;
			obj_order.font_style= font_style;
			obj_order.font_color= font_color;
			obj_order.label= label;
			obj_order.receivedateS= receivedateS;
			obj_order.address= address;
			obj_order.quantity= quantity;
			
			//Send to Queue
			System.Random ran= 	new System.Random();
			iCount=ran.Next(100);
			try
			{
				m = new System.Messaging.Message();
				m.Label="code : "+iCount.ToString();
				//obj_order.label="���� ���ͺ : "+m.Label;
				m.Body=obj_order;
				MQ.Send(m);
				
				return true;
			}

			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
				return false;
				//return ex.ToString();
			}
			//			return iCount.ToString();

						
			return true;
		}



		//-- 7. Total -- OK
		//[WebMethod]
		public  TotalPrice totals(int customer_id,int contact_id)
		{
			//Slect customer_id from username
			//			string SqlString = "Select customer_id from customer where username='"+username+"'";
			//			decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			string SqlString="select gift_job_id,job_total_price  from gift_order where gift_shop_contact_id="+contact_id;
			DataSet myDataSet=db.Query(SqlString,"gift_order");
			//DataTable myDataTable 
			int count=myDataSet.Tables["gift_order"].Rows.Count;
			int[] job_id = new int[count];
			double[] job_price = new double[count];
			int i;
			double totalprice=0;
			for (i=0;i<count;i++)
			{
				job_id[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["gift_job_id"]);
				job_price[i]=System.Convert.ToInt32(myDataSet.Tables["gift_order"].Rows[i]["job_total_price"]);
				totalprice=totalprice+job_price[i];
			}
			// get DeadLine Date
			if(count>0)
			{
				SqlString ="select deadline_confirm from gift_shop_contact where gift_shop_contact_id="+contact_id;
				DateTime deadline_date=Convert.ToDateTime(db.ExcuteScalar(SqlString));
				TotalPrice price = new TotalPrice(contact_id,count,job_id,job_price,totalprice,deadline_date);
				return price;
			}
			else
			{
				TotalPrice price= new TotalPrice();
				price.totalprice=0;
				return price;
			}
			
			
		}
		//-- 8. Pay -- Not to do now wait for BANK
		//-- 9.1 Show Order by Customer   --OK
		[WebMethod]
		public customer_id_info[] showorder_by_customer_id(int customer_id)
		{	
			//Select customer id from username
			//string SqlString = "Select customer_id from customer where username='"+username+"'";
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//select  Detail from Gift_Contact
			string SqlString="select gift_shop_contact_id,gift_shop_contact_name,deadline_confirm from gift_shop_contact where customer_id="+customer_id;
			DataSet myDataSet=db.Query(SqlString,"gift_shop_contact");
			int count=myDataSet.Tables["gift_shop_contact"].Rows.Count;
			int i;
			customer_id_info[] customer_info = new customer_id_info[count];
							
			for (i=0;i<count;i++)
			{
				customer_info[i]=new customer_id_info();
				customer_info[i].contact_id=System.Convert.ToInt32(myDataSet.Tables["gift_shop_contact"].Rows[i]["gift_shop_contact_id"]);
				TotalPrice total =totals(customer_id,customer_info[i].contact_id);
				if(total.totalprice>0)
					customer_info[i].totalPrice=total.totalprice;
				else
					customer_info[i].totalPrice=0;
				customer_info[i].contact_name=System.Convert.ToString(myDataSet.Tables["gift_shop_contact"].Rows[i]["gift_shop_contact_name"]);
				if(myDataSet.Tables["gift_shop_contact"].Rows[i]["deadline_confirm"]!=System.DBNull.Value)
				{
					string deadline_string=Gift.Gifts.DateToString(System.Convert.ToDateTime(myDataSet.Tables["gift_shop_contact"].Rows[i]["deadline_confirm"]));
					customer_info[i].deadline=deadline_string;
				}
				else
					customer_info[i].deadline="�ѧ���ӡ�èͧ��¡���";
			}

			
			return customer_info;
		}
		//-- 9.2 Show Order by Contact Id   --OK
		[WebMethod]
		public contact_id_info[] showorder_by_contact_id(int contact_id)
		{	
			//select contact_id
			//string SqlString="select  photo_studio_contact_id from photo_studio_contact where photo_studio_contact_name ='"+contact_name+"'";
			//DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//decimal contact_id = db.ExcuteScalar(SqlString);
			//select  Detail from Gift_Contact
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			string SqlString="select gift_job_id,gift_subtype_name,receive_date from gift_order,gift where gift_order.gift_subtype_id=gift.gift_subtype_id and gift.gift_type_id=gift_order.gift_type_id and gift_shop_contact_id="+contact_id;
			DataSet myDataSet=db.Query(SqlString,"contact");
			int count=myDataSet.Tables["contact"].Rows.Count;
			int i;
			contact_id_info[] contact_info = new contact_id_info[count];
							
			for (i=0;i<count;i++)
			{
				contact_info[i]=new contact_id_info();
				contact_info[i].job_id=System.Convert.ToInt32(myDataSet.Tables["contact"].Rows[i]["gift_job_id"]);
				contact_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables["contact"].Rows[i]["gift_subtype_name"]);
				DateTime x= System.Convert.ToDateTime(myDataSet.Tables["contact"].Rows[i]["receive_date"]);
				//x.AddYears(-543);
				string receive_date_string=Gift.Gifts.DateToString(x);

				contact_info[i].receive_date=receive_date_string;
			}
		
			return contact_info;
		}

		//-- 9.3 Show Order by Job Id   --> OK
		[WebMethod]
		public job_id_info showorder_by_job_id(int contact_id,int job_id)
		{	
			//			//Select customer id from username
			//			string SqlString = "Select customer_id from customer where username='"+username+"'";
			////			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			//			decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
			//select  Detail from Gift_Contact
			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
			string SqlString="select gift_job_id,gift_shop_contact_id,gift.gift_type_id,gift.gift_subtype_id,gift_subtype_name,gift_subtype_detail,printed_message,receive_date,receive_address,quantity,job_total_price  from gift_order,gift where gift_order.gift_type_id=gift.gift_type_id and gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
			DataSet myDataSet=db.Query(SqlString,"job");
			int count=myDataSet.Tables["job"].Rows.Count;
			int i=0;
			job_id_info job_info = new job_id_info();
			
			job_info.contact_id=System.Convert.ToInt32(myDataSet.Tables["job"].Rows[i]["gift_shop_contact_id"]);
			job_info.job_id=System.Convert.ToInt32(myDataSet.Tables["job"].Rows[i]["gift_job_id"]);
			job_info.type_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_type_id"]);
			job_info.subtype_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_id"]);
			job_info.subtype_name=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_name"]);
			job_info.subtype_detail=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_detail"]);
			job_info.label=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["printed_message"]);
			string receive_date2=Gift.Gifts.DateToString(System.Convert.ToDateTime(myDataSet.Tables["job"].Rows[i]["receive_date"]));
			job_info.receive_date=receive_date2;
			job_info.address=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["receive_address"]);
			job_info.quantity=System.Convert.ToInt32(myDataSet.Tables["job"].Rows[i]["quantity"]);
			job_info.job_total_price=System.Convert.ToDouble(myDataSet.Tables["job"].Rows[i]["job_total_price"]);
			
		
			return job_info;
		}

		//		//-- 9.3 Show Order by Job Id   --> OK
		//		[WebMethod]
		//		public job_id_info[] showorder_by_job_id(decimal contact_id,decimal job_id)
		//		{	
		//			//			//Select customer id from username
		//			//			string SqlString = "Select customer_id from customer where username='"+username+"'";
		//			////			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
		//			//			decimal customer_id=System.Convert.ToDecimal(db.ExcuteScalar(SqlString));
		//			//select  Detail from Gift_Contact
		//			DbComponent.Gift db =new DbComponent.Gift(DbConnection);
		//			string SqlString="select gift_job_id,gift_shop_contact_id,gift.gift_type_id,gift.gift_subtype_id,gift_subtype_name,gift_subtype_detail,printed_message,receive_date,receive_address,quantity,job_total_price  from gift_order,gift where gift_order.gift_type_id=gift.gift_type_id and gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
		//			DataSet myDataSet=db.Query(SqlString,"job");
		//			int count=myDataSet.Tables["job"].Rows.Count;
		//			int i;
		//			job_id_info[] job_info = new job_id_info[count];
		//			
		//			for (i=0;i<count;i++)
		//			{
		//				job_info[i]=new job_id_info();
		//				job_info[i].contact_id=System.Convert.ToDecimal(myDataSet.Tables["job"].Rows[i]["gift_shop_contact_id"]);
		//				job_info[i].job_id=System.Convert.ToDecimal(myDataSet.Tables["job"].Rows[i]["gift_job_id"]);
		//				job_info[i].type_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_type_id"]);
		//				job_info[i].subtype_id=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_id"]);
		//				job_info[i].subtype_name=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_name"]);
		//				job_info[i].subtype_detail=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["gift_subtype_detail"]);
		//				job_info[i].label=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["printed_message"]);
		//				job_info[i].receive_date=System.Convert.ToDateTime(myDataSet.Tables["job"].Rows[i]["receive_date"]);
		//				job_info[i].address=System.Convert.ToString(myDataSet.Tables["job"].Rows[i]["receive_address"]);
		//				job_info[i].quantity=System.Convert.ToInt32(myDataSet.Tables["job"].Rows[i]["quantity"]);
		//				job_info[i].job_total_price=System.Convert.ToDouble(myDataSet.Tables["job"].Rows[i]["job_total_price"]);
		//			}
		//		
		//			return job_info;
		//		}
		//-- 10. Edit Order --
		[WebMethod]
		public job_order edit_order(int customer_id,int contact_id,int job_id,string receivetimeS,string address,string label)
		{	
			string SqlString="select count(*) from customer where customer_id="+customer_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return null;
			// Check that we can change befor receive date 10 days
			//string SqlString ="select receive_date from gift_order where gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
			DateTime receivetime=Gift.Gifts.StringToDateTime(receivetimeS);
			DateTime myTime= receivetime;
			//DateTime old_receive=db.ExcuteScalar(SqlString);
			TimeSpan diffDate=receivetime.Subtract(DateTime.Now);
			TimeSpan deadline = new TimeSpan(10,0,0,0,0);
			if((diffDate.Days<10))
				return null;
			//return "You must change receive date to the day before receive for 10 days";
			SqlString="Update gift_order SET receive_date= '"+receivetime+"',printed_message='"+label+"',receive_address='"+address+"' where gift_shop_contact_id="+contact_id+" and gift_job_id="+job_id;
			string result=db.Excute(SqlString);
			SqlString="select job_total_price  from gift_order where gift_job_id="+job_id;
			double job_total_price=Convert.ToDouble(db.ExcuteScalar(SqlString));

			//check old deadline exist
			SqlString="Select deadline_confirm from gift_shop_contact where gift_shop_contact_id ="+contact_id;
			DateTime old_deadline = new DateTime();
			bool have_old_deadline;
			try
			{
				old_deadline=System.Convert.ToDateTime(db.ExcuteScalar(SqlString));
				have_old_deadline=true;
			}
			catch(System.Exception e)
			{
				have_old_deadline=false;
			}
			//if old deadline exist 
			if (have_old_deadline)
			{
				DateTime new_deadline = myTime.Subtract(deadline);
				//if new deadline date arrive before old deadline ->Update Deadline
				if(new_deadline.DayOfYear<old_deadline.DayOfYear)
				{
					string new_deadline3=new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
					SqlString="Update gift_shop_contact SET deadline_confirm = '"+new_deadline3+"' where gift_shop_contact_id="+contact_id;
					db.Excute(SqlString);
				}
				else
					new_deadline=old_deadline;
				//Bulid job_order class
				//				DateTime z1= new DateTime(2546,1,1);
				//				DateTime z2= new DateTime(2003,1,1);
				//				TimeSpan year543= z1.
				new_deadline=new_deadline.AddYears(-543);
				job_order order = new job_order();
				string 	new_deadline2=new_deadline.Day+" "+new_deadline.Month+" "+new_deadline.Year+" "+new_deadline.Hour+":"+new_deadline.Minute+":"+new_deadline.Second;
				order.job_id=job_id;
				order.dead_line=new_deadline2;
				order.price=job_total_price;
				return order;
			}
			else
			{
				DateTime new_deadline = myTime.Subtract(deadline);
				string new_deadline2=new_deadline.Month+"/"+new_deadline.Day+"/"+new_deadline.Year;
				SqlString="Update gift_shop_contact SET deadline_confirm = '"+new_deadline2+"' where gift_shop_contact_id="+contact_id;
				db.Excute(SqlString);
				new_deadline=new_deadline.AddYears(-543);
				//Bulid job_order class
				job_order order = new job_order();
				new_deadline2=new_deadline.Day+" "+new_deadline.Month+" "+new_deadline.Year+" "+new_deadline.Hour+":"+new_deadline.Minute+":"+new_deadline.Second;
				order.job_id=job_id;
				order.dead_line=new_deadline2;
				order.price=job_total_price;
				return order;
			}

			//				return "Ok , You can edit your order information";
			//			else
			//				return "There's something error about your parameter passed";
		}
		//-- 11.1 Order Cancle by contact --> OK
		[WebMethod]
		public bool order_cancle_contact(int customer_id,int contact_id)
		{	
			string SqlString="select count(*) from gift_shop_contact where customer_id="+customer_id+" and gift_shop_contact_id="+contact_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;
			SqlString="delete from gift_order where gift_shop_contact_id="+contact_id;
			string result=db.Excute(SqlString);
			SqlString="delete gift_shop_contact where gift_shop_contact_id="+contact_id;
			result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;
		}
		//-- 11.2 Order Cancle by job --> OK
		[WebMethod]
		public bool order_cancle_job(int customer_id,int contact_id,int job_id)
		{	
			string SqlString="select count(*) from customer where customer_id="+customer_id;
			DbComponent.Gift db = new DbComponent.Gift(DbConnection);
			int count = System.Convert.ToInt16(db.ExcuteScalar(SqlString));
			// if customer_id exist
			if(count==0)
				return false;
			SqlString="delete from gift_order where gift_shop_contact_id="+contact_id+" and  gift_job_id="+job_id;
			string result=db.Excute(SqlString);
			if(result=="ok")
				return true;
			else
				return false;

		}
	}
}
