<%@ WebService Language="c#" Codebehind="Service6.asmx.cs" Class="Gift6.Gifts" %>
