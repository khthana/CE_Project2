<%@ WebService Language="c#" Codebehind="Service7.asmx.cs" Class="Gift7.Gifts" %>
