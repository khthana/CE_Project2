<%@ WebService Language="c#" Codebehind="Service8.asmx.cs" Class="Gift8.Gifts" %>
