<%@ WebService Language="c#" Codebehind="Service2.asmx.cs" Class="Gift2.Gifts" %>
