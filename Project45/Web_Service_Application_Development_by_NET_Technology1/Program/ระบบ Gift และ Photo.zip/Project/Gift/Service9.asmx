<%@ WebService Language="c#" Codebehind="Service9.asmx.cs" Class="Gift9.Gifts" %>
