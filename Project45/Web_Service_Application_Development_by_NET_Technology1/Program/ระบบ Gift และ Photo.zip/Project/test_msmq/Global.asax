<%@ Application Codebehind="Global.asax.cs" Inherits="test_msmq.Global" %>
