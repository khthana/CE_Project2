using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace test_msmq
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class order_info
	{
		public int customer_id;
		public int contact_id;
		public string type_id;
		public string subtype_id;
		public string font_style;
		public string font_color;
		public string label;
		public string date;
		public double job_total_price;
		public string address;
		public int quantity;
	}
	public class Service1 : System.Web.Services.WebService
	{
		int iCount=0;
		private System.Messaging.MessageQueue MQ;
		System.Messaging.Message m;
		//private System.Messaging.MessageQueue MQ;
		public Service1()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}
		[WebMethod]
		public string send()
		{
			
			order_info order_obj = new order_info();
			order_obj.address="���ͺ���";
			order_obj.contact_id=2;
			order_obj.customer_id=1;
			order_obj.font_color="�� ���ͺ";
			order_obj.font_style="��͹�� ���ͺ";
			order_obj.label="���� ���ͺ";
			order_obj.job_total_price=1000;
			order_obj.type_id="1";
			order_obj.date="02/02/2003";
			order_obj.quantity=10;
			order_obj.subtype_id="1";


			System.Random ran= 	new System.Random();
			iCount=ran.Next(100);
			try
			{
				m = new System.Messaging.Message();
				//				MQ.Send("bank " + iCount.ToString());
				m.Label="S007_"+iCount.ToString();
				order_obj.label="���� ���ͺ : "+m.Label;
				m.Body=order_obj;
				MQ.Send(m);
				
				return "OK : "+m.Label;
			}

			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
				return ex.ToString();
			}
			//			return iCount.ToString();
		}


		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.MQ = new System.Messaging.MessageQueue();
			// 
			// MQ
			// 
			this.MQ.Path = "olala154\\Private$\\msmq1";

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5

//		[WebMethod]
//		public string HelloWorld()
//		{
//			return "Hello World";
//		}
	}
}
