<%@ WebService Language="c#" Codebehind="Service1.asmx.cs" Class="mail.Service1" %>
