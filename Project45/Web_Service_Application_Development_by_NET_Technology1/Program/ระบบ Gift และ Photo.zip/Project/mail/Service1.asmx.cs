using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Web.Mail;
namespace mail
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class Service1 : System.Web.Services.WebService
	{
		public Service1()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		// WEB SERVICE EXAMPLE
		// The HelloWorld() example service returns the string Hello World
		// To build, uncomment the following lines then save and build the project
		// To test this web service, press F5

		[WebMethod]
		public string sendmail(string mailto,string mailfrom,string subject,string body)
		{
			try
			{
				// สร้าง MailMessage object ขึ้นมาใหม่
				MailMessage myMail = new MailMessage();
 
				// กำหนดค่าต่าง ๆ ที่ต้องการ
				myMail.To = mailto;
				myMail.From = mailfrom;
				myMail.Subject = subject;
				myMail.Body = body;    
				//myMail.BodyFormat = MailFormat.Text;
 

				// กำหนดชื่อ SMTP Server
				SmtpMail.SmtpServer = "161.246.10.21";
				//SmtpMail.SmtpServer = "161.246.6.125";

				// ส่งเมล์
				SmtpMail.Send(myMail); 

				return  "Your mail has been sent.";
			}
			catch(Exception E)
			{
				return  "Error : "+E.ToString();
			}
			
		}
		[WebMethod]
		public string sendnews(string subject,string body)
		{
			try
			{
				// สร้าง MailMessage object ขึ้นมาใหม่
				MailMessage myMail = new MailMessage();
 
				// กำหนดค่าต่าง ๆ ที่ต้องการ
				myMail.To = mailto_whom();
				myMail.From = "s2010277@kmitl.ac.th";
				myMail.Subject = subject;
				myMail.Body = body;    
				//myMail.BodyFormat = MailFormat.Text;
 

				// กำหนดชื่อ SMTP Server
				SmtpMail.SmtpServer = "161.246.10.21";
				//SmtpMail.SmtpServer = "161.246.6.125";

				// ส่งเมล์
				SmtpMail.Send(myMail); 
				

				return  "Your mail has been sent.";
			}
			catch(Exception E)
			{
				return  "Error : "+E.ToString();
			}
		}
		[WebMethod]
		public string mailto_whom()
		{
			DbComponent.Gift  db = new  DbComponent.Gift();
			string SqlString ="select users.email from uses_services,users  where uses_services.uid=users.uid and services_id=1";
			DataSet myDataSet= new DataSet();
			myDataSet=db.Query(SqlString,"bank");
			int n = myDataSet.Tables["bank"].Rows.Count;
			string receiver ="";
			for(int i=0;i<n;i++)
				if(i+1==n)
					receiver =receiver+myDataSet.Tables["bank"].Rows[i]["email"];
				else
					receiver =receiver+myDataSet.Tables["bank"].Rows[i]["email"]+",";
			return receiver;

		}

		[WebMethod]
		public string send_activate(string username,string email)
		{
			try
			{
				// สร้าง MailMessage object ขึ้นมาใหม่
				MailMessage myMail = new MailMessage();
 
				// กำหนดค่าต่าง ๆ ที่ต้องการ
				//myMail.To = mailto_whom();
				
				myMail.To = email;
				myMail.From = "s2010277@kmitl.ac.th";
				myMail.Subject ="Passport System activate your account : "+username;
				CryphtoComp.DES des = new CryphtoComp.DES();
				string Eusername=des.Encrypt(username,"0ew,jwfh");
				string body="Hi "+username+" ,TO Complete registration please activate your account at  <font face=\"Arial, Helvetica\" size=-1>"+
					"<a href=\"http://161.246.6.125/net/passport/ppsystem.asmx/activate?username="+Eusername.ToString()+"\"> Activate : "+username+" </a>";

				myMail.Body = body;    
				myMail.BodyFormat = MailFormat.Html;

 

				// กำหนดชื่อ SMTP Server
				SmtpMail.SmtpServer = "161.246.10.21";
				//SmtpMail.SmtpServer = "161.246.6.125";

				// ส่งเมล์
				SmtpMail.Send(myMail); 
				

				return  "Your mail has been sent.";
			}
			catch(Exception E)
			{
				return  "Error : "+E.ToString();
			}
		}	
		


		//Gift Reply MSMQ
		[WebMethod]
		public string send_order_ok(string username,string email,bool flag)
		{
			try
			{
				// สร้าง MailMessage object ขึ้นมาใหม่
				MailMessage myMail = new MailMessage();
 
				// กำหนดค่าต่าง ๆ ที่ต้องการ
				//myMail.To = mailto_whom();
				
				myMail.To = email;
				myMail.From = "bnets@hotmial.com";
				myMail.Subject ="ตอบรับการสั่งจองของคุณ : "+username;
				CryphtoComp.DES des = new CryphtoComp.DES();
				string Eusername=des.Encrypt(username,"0ew,jwfh");
				string body;
				if(flag)
					body="ขอบคุณครับคุณ "+username+" ,การสั่งจองของท่านเรียบร้อยกรุณารอรับสินค้าตามวันเวลาที่ท่านได้ทำการจองไป  <font face=\"Arial, Helvetica\" size=-1>"+
					"<a href=\"http://161.246.6.125/Project/Gift_Application/index2.htm\"> เข้าสู่เว็บไซต์ </a>";
				else
					body="ขอโทษครับคุณ "+username+" ,ระบบ ไม่สามารทำการจองสินค้าให้ได้ กรุณาเข้าสู่เว็บไซต์เพื่อทำการจองใหม่อีกครั้ง  <font face=\"Arial, Helvetica\" size=-1>"+
						"<a href=\"http://161.246.6.125/Project/Gift_Application/index2.htm\"> เข้าสู่เว็บไซต์ </a>";


				myMail.Body = body;    
				myMail.BodyFormat = MailFormat.Html;

 

				// กำหนดชื่อ SMTP Server
				SmtpMail.SmtpServer = "161.246.10.21";
				//SmtpMail.SmtpServer = "161.246.6.125";

				// ส่งเมล์
				SmtpMail.Send(myMail); 
				

				return  "Your mail has been sent.";
			}
			catch(Exception E)
			{
				return  "Error : "+E.ToString();
			}
		}	




	}//class
}//namespace

