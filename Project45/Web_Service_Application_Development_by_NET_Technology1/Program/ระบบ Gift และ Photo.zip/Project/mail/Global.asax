<%@ Application Codebehind="Global.asax.cs" Inherits="mail.Global" %>
