// ImgProcess.h: interface for the CImgProcess class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMGPROCESS_H__D6D4B34F_DDA9_4567_8B16_74FC2B237E03__INCLUDED_)
#define AFX_IMGPROCESS_H__D6D4B34F_DDA9_4567_8B16_74FC2B237E03__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CImgProcess : public CObject  
{
public:
	CRect m_cRect;
	CImgProcess(int ID);
	virtual ~CImgProcess();
	void start();

protected:
	BYTE* nd;
	BYTE* st;
	int m_nWidth;
	int m_nHeight;
	void run();

	static UINT  run(LPVOID p);
	int getRight();
	int getLeft();
	int getBottom();
	int getTop();
private:
	bool IsSimilar(int x, int y);
	int m_nID;
	bool m_bRunning;
};

#endif // !defined(AFX_IMGPROCESS_H__D6D4B34F_DDA9_4567_8B16_74FC2B237E03__INCLUDED_)
