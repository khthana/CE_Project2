//------------------------------------------------------------------------------
// File: StillCapDlg.cpp
//
// Desc: DirectShow sample code - implementation of callback and dialog
//       objects for StillCap application.
//
// Copyright (c) 1999-2001 Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------


#include "stdafx.h"
#include "StillCap.h"
#include "StillCapDlg.h"
#include "..\..\common\dshowutil.cpp"

#include <sys/timeb.h>
#include <time.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// An application can advertise the existence of its filter graph
// by registering the graph with a global Running Object Table (ROT).
// The GraphEdit application can detect and remotely view the running
// filter graph, allowing you to 'spy' on the graph with GraphEdit.
//
// To enable registration in this sample, define REGISTER_FILTERGRAPH.
//
#ifdef DEBUG
#define REGISTER_FILTERGRAPH
#endif


// Constants
#define WM_CAPTURE_BITMAP   WM_APP + 1
#define WM_PROCEED_BITMAP	WM_APP + 2
#define WM_CONTROLLED		WM_APP + 3


// Global data
BOOL g_bOneShot = FALSE;
DWORD g_dwGraphRegister=0;  // For running object table
HWND g_hwnd;

bool g_bCaptured = true;
bool g_bCapturing = false;
int g_threshold = 120;

// Structures
typedef struct _callbackinfo 
{
    double dblSampleTime;
    long lBufferSize;
    BYTE *pBuffer;
    BITMAPINFOHEADER bih;

} CALLBACKINFO;

CALLBACKINFO cb={0};


//
//		SSSSSSSSSS		AAAAAAAAAAA
//		SS				AA		 AA
//		SS				AA		 AA
//		SS				AA		 AA
//		SSSSSSSSSS		AAAAAAAAAAA
//				SS		AA		 AA
//				SS		AA		 AA
//				SS		AA		 AA		
//				SS		AA		 AA		
//		SSSSSSSSSS		AA		 AA		
//
//
//

// Note: this object is a SEMI-COM object, and can only be created statically.
// We use this little semi-com object to handle the sample-grab-callback,
// since the callback must provide a COM interface. We could have had an interface
// where you provided a function-call callback, but that's really messy, so we
// did it this way. You can put anything you want into this C++ object, even
// a pointer to a CDialog. Be aware of multi-thread issues though.
//
class CSampleGrabberCB : public ISampleGrabberCB 
{
public:
    // these will get set by the main thread below. We need to
    // know this in order to write out the bmp
    long lWidth;
    long lHeight;
    CStillCapDlg * pOwner;
    TCHAR m_szCapDir[MAX_PATH]; // the directory we want to capture to
    TCHAR m_szSnappedName[MAX_PATH];
    BOOL bFileWritten;

    CSampleGrabberCB( )
    {
        pOwner = NULL;
        m_szCapDir[0] = 0;
        bFileWritten = FALSE;
    }   

    // fake out any COM ref counting
    //
    STDMETHODIMP_(ULONG) AddRef() { return 2; }
    STDMETHODIMP_(ULONG) Release() { return 1; }

    // fake out any COM QI'ing
    //
    STDMETHODIMP QueryInterface(REFIID riid, void ** ppv)
    {
        if( riid == IID_ISampleGrabberCB || riid == IID_IUnknown ) 
        {
            *ppv = (void *) static_cast<ISampleGrabberCB*> ( this );
            return NOERROR;
        }    
        return E_NOINTERFACE;
    }

    // we don't implement this interface for this example
    //
    STDMETHODIMP SampleCB( double SampleTime, IMediaSample * pSample )
    {
        return 0;
    }

    // The sample grabber is calling us back on its deliver thread.
    // This is NOT the main app thread!
    //
    //           !!!!! WARNING WARNING WARNING !!!!!
    //
    // On Windows 9x systems, you are not allowed to call most of the 
    // Windows API functions in this callback.  Why not?  Because the
    // video renderer might hold the global Win16 lock so that the video
    // surface can be locked while you copy its data.  This is not an
    // issue on Windows 2000, but is a limitation on Win95,98,98SE, and ME.
    // Calling a 16-bit legacy function could lock the system, because 
    // it would wait forever for the Win16 lock, which would be forever
    // held by the video renderer.
    //
    // As a workaround, copy the bitmap data during the callback,
    // post a message to our app, and write the data later.
    //
    STDMETHODIMP BufferCB( double dblSampleTime, BYTE * pBuffer, long lBufferSize )
    {
        // this flag will get set to true in order to take a picture
        //
        if( !g_bOneShot )
            return 0;

        // Since we can't access Windows API functions in this callback, just
        // copy the bitmap data to a global structure for later reference.
        cb.dblSampleTime = dblSampleTime;
        cb.lBufferSize   = lBufferSize;

        // If we haven't yet allocated the data buffer, do it now.
        // Just allocate what we need to store the new bitmap.
        if (!cb.pBuffer)
            cb.pBuffer = new BYTE[lBufferSize];

        // Copy the bitmap data into our global buffer
        if (cb.pBuffer)
            memcpy(cb.pBuffer, pBuffer, lBufferSize);

        // Post a message to our application, telling it to come back
        // and write the saved data to a bitmap file on the user's disk.
        PostMessage(g_hwnd, WM_CAPTURE_BITMAP, 0, 0L);
        return 0;
    }

    // This function will be called whenever a captured still needs to be
    // displayed in the preview window.  It is called initially within
    // CopyBitmap() to display the captured still, but it is also called
    // whenever the main dialog needs to repaint and when we transition
    // from video capture mode back into still capture mode.
    //
    BOOL DisplayCapturedBits(BYTE *pBuffer, BITMAPINFOHEADER *pbih)
    {
        // If we haven't yet snapped a still, return
        if (!bFileWritten || !pOwner || !pBuffer)
            return FALSE;

        // put bits into the preview window with StretchDIBits
        //
        HWND hwndStill = NULL;
        pOwner->GetDlgItem( IDC_STILL, &hwndStill );

        RECT rc;
        ::GetWindowRect( hwndStill, &rc );
        long lStillWidth = rc.right - rc.left;
        long lStillHeight = rc.bottom - rc.top;
        
        HDC hdcStill = GetDC( hwndStill );
        PAINTSTRUCT ps;
        BeginPaint(hwndStill, &ps);

        SetStretchBltMode(hdcStill, COLORONCOLOR);
        StretchDIBits( 
            hdcStill, 0, 0, 
            lStillWidth, lStillHeight, 
            0, 0, lWidth, lHeight, 
            pBuffer, 
            (BITMAPINFO*) pbih, 
            DIB_RGB_COLORS, 
            SRCCOPY );

        EndPaint(hwndStill, &ps);
        ReleaseDC( hwndStill, hdcStill );    

        return TRUE;
    }

    // This is the implementation function that writes the captured video
    // data onto a bitmap on the user's disk.
    //
    BOOL CopyBitmap( double dblSampleTime, BYTE * pBuffer, long lBufferSize , bool save_as_file)
    {
//        if( !g_bOneShot )
//            return 0;

        // we only take one at a time
        //
//        g_bOneShot = FALSE;

		//if not captred will be return.
		if(lBufferSize < (lWidth * lHeight * 3))
			return 0;

        // figure out where to capture to
        //
		//get Date Time
		CTime t = CTime::GetCurrentTime();
		time_t time = t.GetTime();


		struct _timeb timebuffer;
		char *timeline;

		_ftime( &timebuffer );
		timeline = ctime( & ( timebuffer.time ) );

		char szPrint[300];
		sprintf(szPrint, "%.4d-%.2d-%d-%.2d-%.2d-%.2d-%.2hu", t.GetYear()
			,t.GetMonth(), t.GetDay(), t.GetHour(), t.GetMinute(), t.GetSecond()
			,(int)(timebuffer.millitm/10));



        TCHAR m_ShortName[MAX_PATH];
        wsprintf( m_szSnappedName, TEXT("%s%s.bmp"), 
                  m_szCapDir, szPrint);

		strcpy(m_ShortName, szPrint);

        // increment bitmap number if user requested it
        // otherwise, we'll reuse the filename next time
        if( pOwner->IsDlgButtonChecked( IDC_AUTOBUMP ) )
            pOwner->m_nCapTimes++;

		HANDLE hf;

		if(save_as_file == true) {
			// write out a BMP file
			//
			hf = CreateFile(
				m_szSnappedName, GENERIC_WRITE, 0, NULL,
				CREATE_ALWAYS, NULL, NULL );
			if( hf == INVALID_HANDLE_VALUE )
				return 0;
		}

        // write out the file header
        //
        BITMAPFILEHEADER bfh;
        memset( &bfh, 0, sizeof( bfh ) );
        bfh.bfType = 'MB';
        bfh.bfSize = sizeof( bfh ) + lBufferSize + sizeof( BITMAPINFOHEADER );
        bfh.bfOffBits = sizeof( BITMAPINFOHEADER ) + sizeof( BITMAPFILEHEADER );

        DWORD dwWritten = 0;
		
		if(save_as_file == true) {
			WriteFile( hf, &bfh, sizeof( bfh ), &dwWritten, NULL );
		}
        // and the bitmap format
        //
        BITMAPINFOHEADER bih;
        memset( &bih, 0, sizeof( bih ) );
        bih.biSize = sizeof( bih );
        bih.biWidth = lWidth;
        bih.biHeight = lHeight;
        bih.biPlanes = 1;
        bih.biBitCount = 24;

        dwWritten = 0;

		if(save_as_file == true) {
			WriteFile( hf, &bih, sizeof( bih ), &dwWritten, NULL );
		
		
			// and the bits themselves
			//
			dwWritten = 0;
			WriteFile( hf, pBuffer, lBufferSize, &dwWritten, NULL );
			CloseHandle( hf );

		}

		bFileWritten = TRUE;

        // Display the bitmap bits on the dialog's preview window
        DisplayCapturedBits(pBuffer, &bih);

        // Save bitmap header for later use when repainting the window
        memcpy(&(cb.bih), &bih, sizeof(bih));        

        // show where it captured
        //
        pOwner->SetDlgItemText( IDC_SNAPNAME, m_ShortName );

        // Enable the 'View Still' button
        HWND hwndButton = NULL;
        pOwner->GetDlgItem( IDC_BUTTON_VIEWSTILL, &hwndButton );
        ::EnableWindow(hwndButton, TRUE);

        return 0;

    }

};

//
//
//		  IIIIII	MM		MM
//			II		MMM	   MMM
//			II		MMMM  MMMM	
//			II		MM MMMM	MM	
//			II		MM	MM	MM
//			II		MM		MM
//			II		MM		MM
//			II		MM		MM
//		  IIIIII	MM		MM
//
//
//

const int W_SIZE = 3;
const int THRESHOLD = 120;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CImgProcess::CImgProcess(int ID)
{
	m_nID = ID;
}

CImgProcess::~CImgProcess()
{

}

/*	
**	Method name :	OnTurnLeft
**	Description :	Get most top of the object
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
int CImgProcess::getTop()
{
	for(int j=0; j<(m_nHeight-W_SIZE); j+=W_SIZE) 
		for(int i=0; i<(m_nWidth-W_SIZE); i+=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return j;
		}


	return -1;
}



/*	
**	Method name :	OnTurnLeft
**	Description :	Get most bottom of the object
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
int CImgProcess::getBottom()
{
	for(int j=m_nHeight-1-W_SIZE; j>=0; j-=W_SIZE) 
		for(int i=m_nWidth-1-W_SIZE; i>=0; i-=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return j;
		}

	return -1;
}



/*	
**	Method name :	OnTurnLeft
**	Description :	Get most left of the object.
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
int CImgProcess::getLeft()
{
	for(int i=0; i<(m_nWidth-1-W_SIZE); i+=W_SIZE) 
		for(int j=0; j<(m_nHeight-1-W_SIZE); j+=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return i;
		}

	return -1;
}



/*	
**	Method name :	OnTurnLeft
**	Description :	Get most right of the object.
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
int CImgProcess::getRight()
{
	for(int i=(m_nWidth-1-W_SIZE); i>=0; i-=W_SIZE) 
		for(int j=0; j<m_nHeight; j+=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return i;
		}

	return -1;
} 



/*	
**	Method name :	OnTurnLeft
**	Description :	Starting process 
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CImgProcess::start()
{
     if(m_bRunning == true) return;
	 m_bRunning = true;
     AfxBeginThread(run, this);
}



/*	
**	Method name :	OnTurnLeft
**	Description :	Will be running.
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
UINT CImgProcess::run(LPVOID p)
{
    CImgProcess * me = (CImgProcess *)p;
    me->run();
	return 0;
}



/*	
**	Method name :	OnTurnLeft
**	Description :	Running the process.
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CImgProcess::run() 
{
	CRect rect;
	rect.top = getTop();
	rect.bottom = getBottom();
	rect.left = getLeft();
	rect.right = getRight();
	m_cRect = rect;
    PostMessage(g_hwnd, WM_PROCEED_BITMAP, 0, m_nID);
	m_bRunning = false;

}


/*	
**	Method name :	IsSimilar
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
bool CImgProcess::IsSimilar(int x, int y)
{
	int count = 0;
	for(int j=y; j<y+W_SIZE; j++)
		for(int i=x; i<x+W_SIZE; i++) {
			int r1 = st[(j*m_nWidth*3) + (i*3)   ];
			int g1 = st[(j*m_nWidth*3) + (i*3) +1];
			int b1 = st[(j*m_nWidth*3) + (i*3) +2];
			int r2 = nd[(j*m_nWidth*3) + (i*3)   ];
			int g2 = nd[(j*m_nWidth*3) + (i*3) +1];
			int b2 = nd[(j*m_nWidth*3) + (i*3) +2];
			int sum_abs_dif = abs(r1-r2) + abs(g1-g2) + abs(b1-b2);
			if(sum_abs_dif > g_threshold) count ++;
		}
	if(count > (int)(W_SIZE*W_SIZE/2)) return false;
	return true;
}


/*	
**	Method name :	makeInfo
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CImgProcess::makeInfo(BYTE *st, BYTE *nd, int width, int height)
{
	this->st = st;
	this->nd = nd;
	this->m_nWidth = width;
	this->m_nHeight = height;
}


/*	
**	Method name :	makeInfo
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CImgProcess::makeInfo(BYTE *st, BYTE *nd)
{
	this->st = st;
	this->nd = nd;
}


/*	
**	Method name :	makeInfo
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CImgProcess::makeInfo(int width, int height)
{
	this->m_nWidth = width;
	this->m_nHeight = height;
}



//
//
//		  IIIIII	MM		MM
//			II		MMM	   MMM
//			II		MMMM  MMMM	
//			II		MM MMMM	MM	
//			II		MM	MM	MM
//			II		MM		MM
//			II		MM		MM
//			II		MM		MM
//		  IIIIII	MM		MM
//
//
//


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CControlHardware::CControlHardware(int port_number)
{
	this->m_port_number = port_number;
	if(m_port_number != 1 || m_port_number != 2)
		m_port_number = 1;
	running = false;
}

CControlHardware::~CControlHardware()
{

}

bool CControlHardware::turn_left()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'A') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "1";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
			//MessageBox(action);
		}
		delete []NotDown;
		return true;
	}
	return false;
}

bool CControlHardware::turn_right()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'B') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "2";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
			//MessageBox(action);
		}
		delete []NotDown;
		return true;
	}	
	return false;
}

bool CControlHardware::turn_up()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'C') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "3";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
			//MessageBox(action);
		}
		delete []NotDown;
		return true;
	}
	return false;
}

bool CControlHardware::turn_down()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'D') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "4";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
		}
		delete []NotDown;
		return true;
	}
	return false;
}

bool CControlHardware::open()
{
	return true;
}


void CControlHardware::close()
{
//	this->m_serial.Close();
}

void CControlHardware::set_port_number(int port_number)
{
	if(port_number == 2) 
		 this->m_port_number = port_number;
	else this->m_port_number = 1;
}

/*	
**	Method name :	move
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::move(int msg, int step)
{
	if(running == true) return;
	m_turn_type = msg;
	m_step = step;
	this->start();
}

/*	
**	Method name :	start
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::start() 
{
	running = true;
    AfxBeginThread(run, this);
}


/*	
**	Method name :	run
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::run()
{
	for(int i=0; i<m_step; i++) {
		switch(m_turn_type) {
		case TURN_UP	:	this->turn_up();	break;
		case TURN_DOWN	:	this->turn_down();	break;
		case TURN_LEFT  :	this->turn_left();	break;
		case TURN_RIGHT :	this->turn_right();	break;
		}
		Sleep(30);
	}
	running = false;
}


/*	
**	Method name :	run(LPVOID p)
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
UINT CControlHardware::run(LPVOID p)
{
     CControlHardware * me = (CControlHardware *)p;
     me->run();
     return 0;
}


/*	
**	Method name :	move(const CPoint the_vector)
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::move(const CPoint the_vector)
{
	if(running == true) return;
	this->m_the_vector = the_vector;
	this->start_controller();	
}


/*	
**	Method name :	start_controller
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::start_controller()
{
	running = true;
    AfxBeginThread(run_controller, this);

}


/*	
**	Method name :	run_controller
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::run_controller()
{
	int n_pan  = this->m_the_vector.x / 15;
	int n_tilt = this->m_the_vector.y / 16;
	int msg;
	msg = (n_pan > 0) ? TURN_LEFT : TURN_RIGHT;
	int n = (n_pan < 0) ? -n_pan : n_pan;
	if(n != 0) {
		for(int i=0; i<n+2; i++)  {
			switch(msg) {
			case TURN_LEFT  : this->turn_left();		break;
			case TURN_RIGHT : this->turn_right();		break;
			}
			Sleep(30);
		}
	}

	msg = (n_tilt < 0) ? TURN_UP : TURN_DOWN;
	n = (n_tilt < 0) ? -n_tilt : n_tilt;

	for(int i=0; i<n; i++) {
		switch(msg) {
		case TURN_UP   : this->turn_up();		break;
		case TURN_DOWN : this->turn_down();		break;
		}
		Sleep(30);
	}

	Sleep(300);
    PostMessage(g_hwnd, WM_CONTROLLED, 0, 0);
	running = false;
}


/*	
**	Method name :	run_controller(LPVOID p)
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
UINT CControlHardware::run_controller(LPVOID p)
{
     CControlHardware * me = (CControlHardware *)p;
     me->run_controller();
     return 0;
}


//			
//
//			DDDDDDDD	  IIIIII
//			DD	   DD		II
//			DD		DD		II
//			DD		DD		II
//			DD		DD		II
//			DD		DD		II
//			DD		DD		II
//			DD	   DD		II
//			DDDDDDDD	  IIIIII
//
//





// this semi-COM object will receive sample callbacks for us
//
CSampleGrabberCB mCB;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog

CStillCapDlg::CStillCapDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CStillCapDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CStillCapDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	// Initial member variable.
	running = false;
	frame_st = NULL;
	frame_nd = NULL;
	frame_rd = NULL;
	m_bAutoSaving = false;
	m_bAutoControling = false;
	m_pImg1 = NULL;
	m_pImg2 = NULL;
	this->m_ctr_hw = new CControlHardware();
	this->m_ctr_hw->set_port_number(2);
	this->m_controlled = true;

//	this->m_ptr_file_out = new CFile();
//	m_ptr_file_out->Open("C:\\test.txt", CFile::modeWrite | CFile::modeCreate);
}


CStillCapDlg::~CStillCapDlg()
{
	if(frame_st != NULL) delete [] frame_st;
	if(frame_nd != NULL) delete [] frame_nd;
	if(frame_rd != NULL) delete [] frame_rd;
	if(m_pImg1  != NULL) delete m_pImg1;
	if(m_pImg2  != NULL) delete m_pImg2;
	delete m_ctr_hw;


//	m_ptr_file_out->Close();
}


void CStillCapDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStillCapDlg)
	DDX_Control(pDX, IDC_STATUS, m_StrStatus);
	DDX_Control(pDX, IDC_STILL, m_StillScreen);
	DDX_Control(pDX, IDC_PREVIEW, m_PreviewScreen);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CStillCapDlg, CDialog)
	//{{AFX_MSG_MAP(CStillCapDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SNAP, OnSnap)
	ON_BN_CLICKED(IDC_CAPSTILLS, OnCapstills)
	ON_BN_CLICKED(IDC_CAPVID, OnCapvid)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_VIEWSTILL, OnButtonViewstill)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_SAVESTART, OnSavestart)
	ON_BN_CLICKED(IDC_SAVESTOP, OnSavestop)
	ON_BN_CLICKED(IDC_CON_AU_START, OnConAuStart)
	ON_BN_CLICKED(IDC_CON_AU_STOP, OnConAuStop)
	ON_BN_CLICKED(IDC_TURN_UP, OnTurnUp)
	ON_BN_CLICKED(IDC_TURN_LEFT, OnTurnLeft)
	ON_BN_CLICKED(IDC_TURN_DOWN, OnTurnDown)
	ON_BN_CLICKED(IDC_TURN_RIGHT, OnTurnRight)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg message handlers

void CStillCapDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}


// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CStillCapDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();

        // Update the bitmap preview window, if we have
        // already captured bitmap data
        mCB.DisplayCapturedBits(cb.pBuffer, &(cb.bih));
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStillCapDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CStillCapDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

    // StillCap-specific initialization
    CoInitialize( NULL );

    // default to this capture directory
    //
    SetDlgItemText( IDC_CAPDIR, TEXT("c:\\Captured\\") );

    // default to capturing stills
    //
    CheckDlgButton( IDC_CAPSTILLS, 1 );
    m_bCapStills = true;
    m_nCapState = 0;
    m_nCapTimes = 0;
    g_hwnd = GetSafeHwnd();

    // start up the still image capture graph
    //
    HRESULT hr = InitStillGraph( );
    if (FAILED(hr))
        Error( TEXT("Failed to initialize StillGraph!"));

    // Modify the window style of the capture and still windows
    // to prevent excessive repainting
    m_PreviewScreen.ModifyStyle(0, WS_CLIPCHILDREN);
    m_StillScreen.ModifyStyle(0, WS_CLIPCHILDREN);

	// Initilize amount frames per second
	SetDlgItemInt(IDC_FPERSEC, 10);

	// Initialize m_process_img_state is starting state.
	m_process_img_state = 0;

	// Initialize m_process_bmp_state is starting state.
	m_process_bmp_state = 0;

	m_count1 = 0;
	m_count2 = 0;
	m_count3 = 0;
	m_count5 = 0;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CStillCapDlg::ClearGraphs( )
{
    // Destroy capture graph
    if( m_pGraph )
    {
        // have to wait for the graphs to stop first
        //
        CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
        if( pControl ) 
            pControl->Stop( );

        // make the window go away before we release graph
        // or we'll leak memory/resources
        // 
        CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
        if( pWindow )
        {
            pWindow->put_Visible( OAFALSE );
            pWindow->put_Owner( NULL );
        }

#ifdef REGISTER_FILTERGRAPH
        // Remove filter graph from the running object table   
        if (g_dwGraphRegister)
            RemoveGraphFromRot(g_dwGraphRegister);
#endif

        m_pGraph.Release( );
        m_pGrabber.Release( );
    }

    // Destroy playback graph, if it exists
    if( m_pPlayGraph )
    {
        CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pPlayGraph;
        if( pControl ) 
            pControl->Stop( );

        CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pPlayGraph;
        if( pWindow )
        {
            pWindow->put_Visible( OAFALSE );
            pWindow->put_Owner( NULL );
        }

        m_pPlayGraph.Release( );
    }
}

HRESULT CStillCapDlg::InitStillGraph( )
{
    HRESULT hr;

    // create a filter graph
    //
    hr = m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error( TEXT("Could not create filter graph") );
        return E_FAIL;
    }

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    GetDefaultCapDevice( &pCap );
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return E_FAIL;
    }

    // create a sample grabber
    //
    hr = m_pGrabber.CoCreateInstance( CLSID_SampleGrabber );
    if( !m_pGrabber )
    {
        Error( TEXT("Could not create SampleGrabber (is qedit.dll registered?)"));
        return hr;
    }
    CComQIPtr< IBaseFilter, &IID_IBaseFilter > pGrabBase( m_pGrabber );

    // force it to connect to video, 24 bit
    //
    CMediaType VideoType;
    VideoType.SetType( &MEDIATYPE_Video );
    VideoType.SetSubtype( &MEDIASUBTYPE_RGB24 );
    hr = m_pGrabber->SetMediaType( &VideoType ); // shouldn't fail
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set media type"));
        return hr;
    }

    // add the grabber to the graph
    //
    hr = m_pGraph->AddFilter( pGrabBase, L"Grabber" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put sample grabber in graph"));
        return hr;
    }

    // find the two pins and connect them
    //
    IPin * pCapOut = GetOutPin( pCap, 0 );
    IPin * pGrabIn = GetInPin( pGrabBase, 0 );
    hr = m_pGraph->Connect( pCapOut, pGrabIn );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin #0 to grabber.\r\n")
               TEXT("Is the capture device being used by another application?"));
        return hr;
    }

    // render the sample grabber output pin, so we get a preview window
    //
    IPin * pGrabOut = GetOutPin( pGrabBase, 0 );
    hr = m_pGraph->Render( pGrabOut );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render sample grabber output pin"));
        return hr;
    }

    // ask for the connection media type so we know how big
    // it is, so we can write out bitmaps
    //
    AM_MEDIA_TYPE mt;
    hr = m_pGrabber->GetConnectedMediaType( &mt );
    if ( FAILED( hr) )
    {
        Error( TEXT("Could not read the connected media type"));
        return hr;
    }
    
    VIDEOINFOHEADER * vih = (VIDEOINFOHEADER*) mt.pbFormat;
    mCB.pOwner = this;
    mCB.lWidth  = vih->bmiHeader.biWidth;
    mCB.lHeight = vih->bmiHeader.biHeight;
    FreeMediaType( mt );

    // don't buffer the samples as they pass through
    //
    m_pGrabber->SetBufferSamples( FALSE );

    // only grab one at a time, stop stream after
    // grabbing one sample
    //
    m_pGrabber->SetOneShot( FALSE );

    // set the callback, so we can grab the one sample
    //
    m_pGrabber->SetCallback( &mCB, 1 );

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_PREVIEW, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
    
    // Add our graph to the running object table, which will allow
    // the GraphEdit application to "spy" on our graph
#ifdef REGISTER_FILTERGRAPH
    hr = AddGraphToRot(m_pGraph, &g_dwGraphRegister);
    if (FAILED(hr))
    {
        Error(TEXT("Failed to register filter graph with ROT!"));
        g_dwGraphRegister = 0;
    }
#endif

    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }
	if(g_bCapturing == false) 
		UpdateStatus(_T("Previewing Live Video"));
    return 0;
}

HRESULT CStillCapDlg::InitCaptureGraph( TCHAR * pFilename )
{
    HRESULT hr;

    // make a filter graph
    //
    m_pGraph.CoCreateInstance( CLSID_FilterGraph );
    if( !m_pGraph )
    {
        Error(TEXT("Could not create filter graph"));
        return E_FAIL;
    }

    // get whatever capture device exists
    //
    CComPtr< IBaseFilter > pCap;
    GetDefaultCapDevice( &pCap );
    if( !pCap )
    {
        Error( TEXT("No video capture device was detected on your system.\r\n\r\n")
               TEXT("This sample requires a functional video capture device, such\r\n")
               TEXT("as a USB web camera.") );
        return E_FAIL;
    }

    // add the capture filter to the graph
    //
    hr = m_pGraph->AddFilter( pCap, L"Cap" );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not put capture device in graph"));
        return hr;
    }

    // make a capture builder graph (for connecting help)
    //
    CComPtr< ICaptureGraphBuilder2 > pBuilder;
    hr = pBuilder.CoCreateInstance( CLSID_CaptureGraphBuilder2 );
    if( !pBuilder )
    {
        Error( TEXT("Could not create capture graph builder2"));
        return hr;
    }

    hr = pBuilder->SetFiltergraph( m_pGraph );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not set filtergraph on graphbuilder2"));
        return hr;
    }

    CComPtr< IBaseFilter > pMux;
    CComPtr< IFileSinkFilter > pSink;
    USES_CONVERSION;

    hr = pBuilder->SetOutputFileName( &MEDIASUBTYPE_Avi,
        T2W( pFilename ),
        &pMux,
        &pSink );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not create/hookup mux and writer"));
        return hr;
    }

    hr = pBuilder->RenderStream( &PIN_CATEGORY_CAPTURE,
        &MEDIATYPE_Video,
        pCap,
        NULL,
        pMux );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not connect capture pin"));
        return hr;
    }

    hr = pBuilder->RenderStream( &PIN_CATEGORY_PREVIEW,
        &MEDIATYPE_Video,
        pCap,
        NULL,
        NULL );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not render capture pin"));
        return hr;
    }
    if( hr == VFW_S_NOPREVIEWPIN )
    {
        // preview was faked up using the capture pin, so we can't
        // turn capture on and off at will.
        hr = 0;
    }

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return hr;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_PREVIEW, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );
    
    // run the graph
    //
    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl = m_pGraph;
    hr = pControl->Run( );
    if( FAILED( hr ) )
    {
        Error( TEXT("Could not run graph"));
        return hr;
    }

	if(g_bCapturing == false) 	
		UpdateStatus(_T("Capturing Video To Disk"));
    return 0;
}

HRESULT CStillCapDlg::InitPlaybackGraph( TCHAR * pFilename )
{
    m_pPlayGraph.CoCreateInstance( CLSID_FilterGraph );
    USES_CONVERSION;

    HRESULT hr = m_pPlayGraph->RenderFile( T2W( pFilename ), NULL );
    if (FAILED(hr))
        return hr;

    // find the video window and stuff it in our window
    //
    CComQIPtr< IVideoWindow, &IID_IVideoWindow > pWindow = m_pPlayGraph;
    if( !pWindow )
    {
        Error( TEXT("Could not get video window interface"));
        return E_FAIL;
    }

    // set up the preview window to be in our dialog
    // instead of floating popup
    //
    HWND hwndPreview = NULL;
    GetDlgItem( IDC_STILL, &hwndPreview );
    RECT rc;
    ::GetWindowRect( hwndPreview, &rc );
    pWindow->put_Owner( (OAHWND) hwndPreview );
    pWindow->put_Left( 0 );
    pWindow->put_Top( 0 );
    pWindow->put_Width( rc.right - rc.left );
    pWindow->put_Height( rc.bottom - rc.top );
    pWindow->put_Visible( OATRUE );
    pWindow->put_WindowStyle( WS_CHILD | WS_CLIPSIBLINGS );

    CComQIPtr< IMediaControl, &IID_IMediaControl > pControl;
    pControl = m_pPlayGraph;

    // Play back the recorded video
    pControl->Run( );
	
	if(g_bCapturing == false) 
		UpdateStatus(_T("Playing Back Recorded Video"));
    return 0;
}

void CStillCapDlg::GetDefaultCapDevice( IBaseFilter ** ppCap )
{
    HRESULT hr;

    *ppCap = NULL;

    // create an enumerator
    //
    CComPtr< ICreateDevEnum > pCreateDevEnum;
    pCreateDevEnum.CoCreateInstance( CLSID_SystemDeviceEnum );
    if( !pCreateDevEnum )
        return;

    // enumerate video capture devices
    //
    CComPtr< IEnumMoniker > pEm;
    pCreateDevEnum->CreateClassEnumerator( CLSID_VideoInputDeviceCategory, &pEm, 0 );
    if( !pEm )
        return;

    pEm->Reset( );
 
    // go through and find first video capture device
    //
    while( 1 )
    {
        ULONG ulFetched = 0;
        CComPtr< IMoniker > pM;
        hr = pEm->Next( 1, &pM, &ulFetched );
        if( hr != S_OK )
            break;

        // get the property bag interface from the moniker
        //
        CComPtr< IPropertyBag > pBag;
        hr = pM->BindToStorage( 0, 0, IID_IPropertyBag, (void**) &pBag );
        if( hr != S_OK )
            continue;

        // ask for the english-readable name
        //
        CComVariant var;
        var.vt = VT_BSTR;
        hr = pBag->Read( L"FriendlyName", &var, NULL );
        if( hr != S_OK )
            continue;

        // set it in our UI
        //
        USES_CONVERSION;
        SetDlgItemText( IDC_CAPOBJ, W2T( var.bstrVal ) );

        // ask for the actual filter
        //
        hr = pM->BindToObject( 0, 0, IID_IBaseFilter, (void**) ppCap );
        if( *ppCap )
            break;
    }

    return;
}

void CStillCapDlg::OnSnap() 
{
    CString CapDir;
    GetDlgItemText( IDC_CAPDIR, CapDir );

    // Snap a still picture?
    if( m_bCapStills )
    {
        _tcscpy( mCB.m_szCapDir, CapDir );
        g_bOneShot = TRUE;
    }

    // Start capturing video
    else
    {
        if( m_nCapState == 0 )
        {
            if( IsDlgButtonChecked( IDC_AUTOBUMP ) )
                m_nCapTimes++;
        }

        // Determine AVI filename
        TCHAR szFilename[MAX_PATH], szFile[MAX_PATH];
        wsprintf( szFilename, TEXT("%sStillCap%04d.avi"), CapDir, m_nCapTimes );
        wsprintf( szFile, TEXT("StillCap%04d.avi"), m_nCapTimes );

        // start capturing, show playing button
        //
        if( m_nCapState == 0 )
        {
            ClearGraphs( );
            InitCaptureGraph( szFilename );
            SetDlgItemText( IDC_SNAP, TEXT("&Start Playback"));
            m_nCapState = 1;
        }
        else if( m_nCapState == 1 )
        {
            // show us where it captured to
            //
            SetDlgItemText( IDC_SNAPNAME, szFile );

            ClearGraphs( );
            InitPlaybackGraph( szFilename );
            SetDlgItemText( IDC_SNAP, TEXT("&Start Capture"));
            m_nCapState = 0;
        }
    }
}

BOOL CStillCapDlg::DestroyWindow() 
{
    ClearGraphs( );

    return CDialog::DestroyWindow();
}

void CStillCapDlg::Error( TCHAR * pText )
{
    GetDlgItem( IDC_SNAP )->EnableWindow( FALSE );
    ::MessageBox( NULL, pText, TEXT("Error!"), MB_OK | MB_TASKMODAL | MB_SETFOREGROUND );
}

void CStillCapDlg::OnCapstills() 
{
    if( m_bCapStills )
        return;

    SetDlgItemText( IDC_SNAP, TEXT("&Snap Still"));
    m_bCapStills = true;

    ClearGraphs( );
    InitStillGraph( );

    // Update the bitmap preview window, if we have
    // already captured bitmap data
    mCB.DisplayCapturedBits(cb.pBuffer, &(cb.bih));
}

void CStillCapDlg::OnCapvid() 
{
    if( !m_bCapStills )
        return;

    ClearGraphs( );
    m_bCapStills = false;
    m_nCapState = 0;

    // use OnSnap to set the UI state and the graphs
    //
    OnSnap( );
}

void CStillCapDlg::OnButtonReset() 
{
    // Reset bitmap counter to reset at zero
    m_nCapTimes = 0;
}

void CStillCapDlg::OnButtonViewstill() 
{
    // Open the bitmap with the system-default application
    ShellExecute(this->GetSafeHwnd(), TEXT("open\0"), mCB.m_szSnappedName, 
                 NULL, NULL, SW_SHOWNORMAL);
}

void CStillCapDlg::UpdateStatus(TCHAR *szStatus)
{
    m_StrStatus.SetWindowText(szStatus);
}



/*	
**	Method name :	WindowProc
**	Description :	Window procedure for main dialog.
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
LRESULT CStillCapDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
    // Field the message posted by our SampleGrabber callback function.
    if (message == WM_CAPTURE_BITMAP) {

		initial_process_image();
		m_count3 ++;
		CString s;
		s.Format("0#%d called", m_count3);
		SetDlgItemText(IDC_RATE, s);


		if(m_bAutoSaving == true) {
			 g_bOneShot = FALSE;
			 mCB.CopyBitmap(cb.dblSampleTime, cb.pBuffer, cb.lBufferSize, true);        
		}
		else 
			if(m_bAutoControling == true) {	
		        g_bOneShot = FALSE;
				automatical_controlling_process();
			}
		
		g_bCaptured = true;
	}

	if(message == WM_PROCEED_BITMAP) {
		on_proceed_bitmap(lParam);
	}

	if(message == WM_CONTROLLED) {
//		CString s = this->get_current_time();
//		SetDlgItemText(IDC_VECTOR, s);
		CString s;
		s.Format("#%d contrlled", m_count5);
		SetDlgItemText(IDC_CONTROLLED, s);
		m_count5++;
		this->m_controlled = true;

//		CString cur_date = s + this->get_current_time();
//		cur_date += "\r\n";
//		this->m_ptr_file_out->Write(cur_date, cur_date.GetLength());

	}
	return CDialog::WindowProc(message, wParam, lParam);
}

void CStillCapDlg::OnClose() 
{
    // Free the memory allocated for our bitmap data buffer
    if (cb.pBuffer != 0)
    {
        delete cb.pBuffer;
        cb.pBuffer = 0;
    }
    	
	CDialog::OnClose();
}

// start save automatically thread.
void CStillCapDlg::start()
{
     running = true;
     AfxBeginThread(run, this);
}

// start the thread.
UINT CStillCapDlg::run(LPVOID p)
{
     CStillCapDlg * me = (CStillCapDlg *)p;
     me->run();
     return 0;
}
 
// run for the save automatically thread.
void CStillCapDlg::run()
{
	//read m_dFrames
	g_bCapturing = true;

	int n_frames = GetDlgItemInt(IDC_FPERSEC);
	if(n_frames < 0)  n_frames = 1;
	if(n_frames > 10) n_frames = 10;

	DWORD delay = calSleep(n_frames);
	
	//initialize the status.
	DWORD count_frames = 0;
	CString szStatus;
	szStatus.Format("Captured frame %d", count_frames);
    m_StrStatus.SetWindowText(szStatus);
	
	while(running) {

		CString CapDir;
		GetDlgItemText( IDC_CAPDIR, CapDir );

        _tcscpy( mCB.m_szCapDir, CapDir );
        g_bOneShot = TRUE;
		g_bCaptured = false;


		long remain_delay = delay;
		while(g_bCaptured != true) {		
			Sleep(50);
			remain_delay -= 50;
		}
		
		//Update the status.
		count_frames ++;
		szStatus.Format("Captured frame %d", count_frames);
	    m_StrStatus.SetWindowText(szStatus);

		if(remain_delay > 0) Sleep(remain_delay);
	}
	g_bCapturing = false;
}

// stop the save automatically thread.
void CStillCapDlg::stop()
{
    running = false;
}


void CStillCapDlg::OnSavestart() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoControling == false && m_bAutoSaving == false) {
		m_bAutoSaving = true;
		this->start();
	}
}

void CStillCapDlg::OnSavestop() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoSaving == true) {
		this->stop();
		m_bAutoSaving = false;
	}	
}

DWORD CStillCapDlg::calSleep(double frames)
{
	return (long)(1000/frames);
}

void CStillCapDlg::OnConAuStart() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoSaving == false && m_bAutoControling == false) {
		Sleep(700);
		m_bAutoControling = true;	
		this->start();
	}
}


void CStillCapDlg::OnConAuStop() 
{
	// TODO: Add your control notification handler code here
	if(m_bAutoControling == true) {
		Sleep(700);
		this->stop();
		m_bAutoControling = false;
	}
}



/*	
**	Method name :	OnTurnUp
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CStillCapDlg::OnTurnUp() 
{
	// TODO: Add your control notification handler code here
	m_ctr_hw->move(TURN_DOWN, 4);
}	


/*	
**	Method name :	OnTurnLeft
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CStillCapDlg::OnTurnLeft() 
{
	// TODO: Add your control notification handler code here
	m_ctr_hw->move(TURN_LEFT, 16);
}


/*	
**	Method name :	OnTurnDown
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CStillCapDlg::OnTurnDown() 
{
	m_ctr_hw->move(TURN_UP, 4);
}


/*	
**	Method name :	OnTurnRight
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 11, 2003
*/
void CStillCapDlg::OnTurnRight() 
{
	// TODO: Add your control notification handler code here
	m_ctr_hw->move(TURN_RIGHT, 8);
}


/*	
**	Method name :	automatical_controlling_process
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::automatical_controlling_process()
{
	if(this->m_controlled == false) {
		m_process_img_state = 0;
		return;
	}
	switch(m_process_img_state) {
	case 0  :	process_img_state_O();	m_process_img_state = 1;	break;
	case 1  :	process_img_state_I();	m_process_img_state = 2;	break;
	case 2  :	process_img_state_II();	m_process_img_state = 0;	break;
	default :	m_process_img_state = 0;							break;
	}
}


/*	
**	Method name :	process_img_state_O
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::process_img_state_O()
{
	memcpy(frame_st, cb.pBuffer, cb.lBufferSize);
}


/*	
**	Method name :	process_img_state_I
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::process_img_state_I()
{
	memcpy(frame_nd, cb.pBuffer, cb.lBufferSize);
	m_pImg1->makeInfo(frame_st, frame_nd, mCB.lWidth, mCB.lHeight);

//		CString cur_date = "img1 starting ..: "  + this->get_current_time();
//		cur_date += "\r\n";
//		this->m_ptr_file_out->Write(cur_date, cur_date.GetLength());

	m_pImg1->start();
	m_count1 ++;
	CString s;
	s.Format("1#%d starting..", m_count1);
	SetDlgItemText(IDC_BMP1, s);
}


/*	
**	Method name :	process_img_state_II
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::process_img_state_II()
{
	memcpy(frame_rd, cb.pBuffer, cb.lBufferSize);
	m_pImg2->makeInfo(frame_nd, frame_st, mCB.lWidth, mCB.lHeight);
	m_pImg2->start();
	m_count2 ++;
	CString s;
	s.Format("1#%d starting..", m_count2);
	SetDlgItemText(IDC_BMP2, s);
}



/*	
**	Method name :	initial_process_image
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::initial_process_image()
{		
	if(frame_st == NULL) frame_st = new BYTE[cb.lBufferSize];
	if(frame_nd == NULL) frame_nd = new BYTE[cb.lBufferSize];
	if(frame_rd == NULL) frame_rd = new BYTE[cb.lBufferSize];
	if(m_pImg1  == NULL) m_pImg1  = new CImgProcess(1);
	if(m_pImg2  == NULL) m_pImg2  = new CImgProcess(2);					
}



/*	
**	Method name :	initial_process_image
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::on_proceed_bitmap(int id)
{
	switch(m_process_bmp_state) {
	case 0 :	if(id == 1) {
					process_bmp_state_I(); 
					m_process_bmp_state = 1;
				}
				else {
					process_bmp_state_II();
					m_process_bmp_state = 2;
				}
				break;

	case 1 :	if(id == 1) {
					m_process_bmp_state = 1; 
				}
				else {
					process_bmp_state_II();
					image_process_form_the_frames();
					m_process_bmp_state = 0;
				}
				break;

	case 2 :	if(id == 1) {
					process_bmp_state_I(); 
					image_process_form_the_frames();
					m_process_bmp_state = 0; 
				}
				else {
					m_process_bmp_state = 2;
				}
				break;

	default:	m_process_bmp_state = 0;	break;
	}
	
}



/*	
**	Method name :	process_bmp_state_I
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::process_bmp_state_I()
{
	CString s;
	CRect r = m_pImg1->m_cRect;
	//m_count1 ++;
//		CString cur_date = "img1 stopped : " + this->get_current_time();
//		cur_date += "\r\n";
//		this->m_ptr_file_out->Write(cur_date, cur_date.GetLength());

	s.Format("#%d :l%d, t%d, r%d, b%d  ", m_count1, r.left, r.top, r.right,r.bottom);
	SetDlgItemText(IDC_IMGI, s);	
}


/*	
**	Method name :	process_bmp_state_II
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 12, 2003 II
*/
void CStillCapDlg::process_bmp_state_II()
{
	CString s;
	CRect r = m_pImg2->m_cRect;
	//m_count2 ++;

	s.Format("#%d :l%d, t%d, r%d, b%d", m_count2, r.left, r.top, r.right,r.bottom);
	SetDlgItemText(IDC_IMGII, s);
}


/*	
**	Method name :	image_process_form_the_frames
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 13, 2003 II
*/
void CStillCapDlg::image_process_form_the_frames()
{
	CPoint size_object(0, 0);
	this->calculate_size_of_the_object(size_object);
	
	CPoint center_object(0, 0);
	this->calculate_current_center_of_the_object(size_object, center_object);

	this->mark_center_of_the_object(center_object);
	CString s;
	s.Format("center x%d, y%d", center_object.x, center_object.y);
	SetDlgItemText(IDC_CENTER, s);

    mCB.CopyBitmap(cb.dblSampleTime, cb.pBuffer, cb.lBufferSize, false);        

	CPoint the_vector(0, 0);
	this->get_direction(center_object, the_vector);
	s.Format("x%d, y%d", (int)the_vector.x / 22, (int)the_vector.y / 16);
	SetDlgItemText(IDC_VECTOR, s);
	this->controlling_hardware(the_vector);
}		


/*	
**	Method name :	calculate_size_of_the_object
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 13, 2003 II
*/
void CStillCapDlg::calculate_size_of_the_object(CPoint &size_obj)
{
	CRect r1 = m_pImg1->m_cRect;
	CRect r2 = m_pImg2->m_cRect;

	int width_object = (r1.left < r2.left) ? abs(r1.right - r2.left) : abs(r2.right - r1.left);
	if(r1.left < r2.left && r1.right > r2.right) width_object = abs(r2.right - r2.left);
	if(r2.left < r1.left && r2.right > r1.right) width_object = abs(r2.right - r2.left);

	int height_object = (r1.top < r2.top) ? abs(r1.bottom - r2.top) : abs(r2.bottom - r1.top);
	if(r1.top < r2.top && r1.bottom > r2.bottom) height_object = abs(r2.bottom - r2.top);
	if(r2.top < r1.top && r2.bottom > r1.bottom) height_object = abs(r2.bottom - r2.top);
	
	size_obj.x = width_object;
	size_obj.y = height_object;
}


/*	
**	Method name :	calculate_current_center_of_the_object
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 13, 2003 II
*/
void CStillCapDlg::calculate_current_center_of_the_object(const CPoint size_obj, CPoint &the_position)
{
	CRect r1 = m_pImg1->m_cRect;
	CRect r2 = m_pImg2->m_cRect;
	
	// 1 is left, 2 is right, left and right are 3.
	int left_right = (r1.left < r2.left) ? 2 : 1;	
	if(r1.left < r2.left && r1.right > r2.right) left_right = 3;
	if(r2.left < r1.left && r2.right > r1.right) left_right = 3;
	
	// 1 is top, 2 is bottom, top and bottom are 3.
	int top_bottom = (r1.top  < r2.top ) ? 2 : 1;
	if(r1.top < r2.top && r1.bottom > r2.bottom) top_bottom = 3;
	if(r2.top < r1.top && r2.bottom > r1.bottom) top_bottom = 3;

	int half_x = size_obj.x / 2;
	int half_y = size_obj.y / 2;

	switch(left_right) {
	case 3 : the_position.x = r2.right - half_x;	break;
	case 2 : the_position.x = r2.right - half_x;	break;
	case 1 : the_position.x = r2.left  + half_x;	break;
	}

	switch(top_bottom) {
	case 3 : the_position.y = r2.bottom - half_y;	break;
	case 2 : the_position.y = r2.bottom - half_y;	break;
	case 1 : the_position.y = r2.top + half_y;		break;
	}

}


/*	
**	Method name :	mark_center_of_the_object
**	Description :	Used in testing. 
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 13, 2003 II
*/
void CStillCapDlg::mark_center_of_the_object(const CPoint center_obj)
{
	int pos = ((center_obj.y * 3) * m_pImg1->m_nWidth) + (center_obj.x * 3);
	if(pos >= cb.lBufferSize - 20) return;
	pos --;
	cb.pBuffer[pos++] = 0xFF;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0xFF;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0xFF;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0xFF;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0xFF;
	cb.pBuffer[pos++] = 0;
	cb.pBuffer[pos++] = 0;

}


/*	
**	Method name :	get_direction
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003 II
*/
void CStillCapDlg::get_direction(const CPoint center_obj, CPoint& the_vector)
{
	if(center_obj.x < 5 && center_obj.y < 5) return;

	int center_x  = this->m_pImg1->m_nWidth / 2;
	int center_y  = this->m_pImg1->m_nHeight / 2;
	the_vector.x  = center_obj.x - center_x;
	the_vector.y  = center_obj.y - center_y;	
}



/*	
**	Method name :	controlling_hardware
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 17, 2003 II
*/
void CStillCapDlg::controlling_hardware(const CPoint the_vector)
{
	if(this->m_controlled == true) {
		this->m_ctr_hw->move(the_vector);
		this->m_controlled = false;
	}
}


/*	
**	Method name :	controlling_hardware
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 17, 2003 II
*/
CString CStillCapDlg::get_current_time()
{
	CTime t = CTime::GetCurrentTime();
	time_t time = t.GetTime();


	struct _timeb timebuffer;
	char *timeline;

	_ftime( &timebuffer );
	timeline = ctime( & ( timebuffer.time ) );

	char szPrint[300];
	sprintf(szPrint, "%.4d-%.2d-%d-%.2d-%.2d-%.2d-%.2hu", t.GetYear()
		,t.GetMonth(), t.GetDay(), t.GetHour(), t.GetMinute(), t.GetSecond()
		,(int)(timebuffer.millitm/10));
	return szPrint;
}
