// ImageHandle.h: interface for the CImageHandle class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IMAGEHANDLE_H__2D60F3DB_3970_42CD_A391_9C49D2B1E7B6__INCLUDED_)
#define AFX_IMAGEHANDLE_H__2D60F3DB_3970_42CD_A391_9C49D2B1E7B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CImageHandle : public CObject  
{
public:
	CImageHandle();
	virtual ~CImageHandle(); 

};

#endif // !defined(AFX_IMAGEHANDLE_H__2D60F3DB_3970_42CD_A391_9C49D2B1E7B6__INCLUDED_)
