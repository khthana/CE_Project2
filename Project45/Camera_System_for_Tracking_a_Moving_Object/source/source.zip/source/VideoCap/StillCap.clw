; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CStillCapDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "stillcap.h"
LastPage=0

ClassCount=3
Class1=CStillCapApp
Class2=CAboutDlg
Class3=CStillCapDlg

ResourceCount=2
Resource1=IDD_ABOUTBOX
Resource2=IDD_STILLCAP_DIALOG (Neutral (Sys. Default))

[CLS:CStillCapApp]
Type=0
BaseClass=CWinApp
HeaderFile=StillCap.h
ImplementationFile=StillCap.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=StillCapDlg.cpp
ImplementationFile=StillCapDlg.cpp

[CLS:CStillCapDlg]
Type=0
BaseClass=CDialog
HeaderFile=StillCapDlg.h
ImplementationFile=StillCapDlg.cpp
Filter=D
VirtualFilter=dWC
LastObject=IDC_TURN_UP

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,static,1342308352

[DLG:IDD_STILLCAP_DIALOG (Neutral (Sys. Default))]
Type=1
Class=CStillCapDlg
ControlCount=45
Control1=IDC_CAPSTILLS,button,1342242825
Control2=IDC_CAPVID,button,1342177289
Control3=IDC_STATIC,static,1342308352
Control4=IDC_CAPDIR,edit,1350631552
Control5=IDC_SNAPNAME,static,1342312448
Control6=IDC_AUTOBUMP,button,1208033283
Control7=IDC_SNAP,button,1342242817
Control8=IDC_STATIC,static,1342308353
Control9=IDC_CAPOBJ,static,1342308353
Control10=IDC_STATIC,button,1342177287
Control11=IDC_STATIC,static,1342308353
Control12=IDC_PREVIEW,static,1342177284
Control13=IDC_STATIC,static,1342308353
Control14=IDC_STILL,static,1342177284
Control15=IDC_STATIC,static,1342308352
Control16=IDC_STATIC,static,1342308352
Control17=IDC_BUTTON_RESET,button,1208025088
Control18=IDC_STATIC,static,1342308353
Control19=IDC_STATUS,static,1342308353
Control20=IDC_STATIC,button,1342177287
Control21=IDC_BUTTON_VIEWSTILL,button,1208025088
Control22=IDC_FPERSEC,edit,1342242944
Control23=IDC_STATIC,static,1342308352
Control24=IDC_STATIC,button,1342177287
Control25=IDC_SAVESTART,button,1342242816
Control26=IDC_SAVESTOP,button,1342242816
Control27=IDC_PRINT,static,1073872896
Control28=IDC_STATIC,button,1342177287
Control29=IDC_CON_AU_START,button,1342242816
Control30=IDC_CON_AU_STOP,button,1342242816
Control31=IDC_TURN_UP,button,1342242816
Control32=IDC_TURN_LEFT,button,1342242816
Control33=IDC_TURN_RIGHT,button,1342242817
Control34=IDC_TURN_DOWN,button,1342242816
Control35=IDC_IMGI,static,1073872897
Control36=IDC_IMGII,static,1073872897
Control37=IDC_BMP1,static,1073872896
Control38=IDC_BMP2,static,1073872896
Control39=IDC_RATE,static,1073872896
Control40=IDC_CENTER,static,1073872897
Control41=IDC_VECTOR,static,1073872897
Control42=IDC_CONTROLLED,static,1073872897
Control43=IDC_STATIC,static,1342308353
Control44=IDC_STATIC,static,1342308353
Control45=IDC_MESSAGE,static,1073872897

