// ControlHardwareImp.cpp: implementation of the CControlHardware class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ControlHardwareImp.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CControlHardware::CControlHardware(int port_number)
{
	this->m_port_number = port_number;
	if(m_port_number != 1 || m_port_number != 2)
		m_port_number = 1;
	running = false;
}

CControlHardware::~CControlHardware()
{

}

bool CControlHardware::turn_left()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'A') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "1";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
			//MessageBox(action);
		}
		delete []NotDown;
		return true;
	}
	return false;
}

bool CControlHardware::turn_right()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'B') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "2";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
			//MessageBox(action);
		}
		delete []NotDown;
		return true;
	}	
	return false;
}

bool CControlHardware::turn_up()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'C') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "3";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
			//MessageBox(action);
		}
		delete []NotDown;
		return true;
	}
	return false;
}

bool CControlHardware::turn_down()
{
	const int nBaud = 9600;
	if(serial.Open(this->m_port_number, nBaud))
	{
		char* NotDown = new char[1];
		int nBytesRead = serial.ReadData(NotDown, 1);
		if(NotDown[0] == 'D') {
			delete [] NotDown;
			return false;
		}
		else
		{
			const char action[] = "4";
			int nBytesSend = serial.SendData(action, strlen(action));
			ASSERT(nBytesSend == (int)strlen(action));
		}
		delete []NotDown;
		return true;
	}
	return false;
}

bool CControlHardware::open()
{
	return true;
}


void CControlHardware::close()
{
//	this->m_serial.Close();
}

void CControlHardware::set_port_number(int port_number)
{
	if(port_number == 2) 
		 this->m_port_number = port_number;
	else this->m_port_number = 1;
}

/*	
**	Method name :	move
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::move(int msg, int step)
{
	if(running == true) return;
	m_turn_type = msg;
	m_step = step;
	this->start();
}

/*	
**	Method name :	start
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::start() 
{
	running = true;
    AfxBeginThread(run, this);
}


/*	
**	Method name :	run
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::run()
{
	for(int i=0; i<m_step; i++) {
		switch(m_turn_type) {
		case TURN_UP	:	this->turn_up();	break;
		case TURN_DOWN	:	this->turn_down();	break;
		case TURN_LEFT  :	this->turn_left();	break;
		case TURN_RIGHT :	this->turn_right();	break;
		}
		Sleep(50);
	}
	running = false;
}


/*	
**	Method name :	run(LPVOID p)
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
UINT CControlHardware::run(LPVOID p)
{
     CControlHardware * me = (CControlHardware *)p;
     me->run();
     return 0;
}


/*	
**	Method name :	move(const CPoint the_vector)
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::move(const CPoint the_vector)
{
	if(running == true) return;
	this->m_the_vector = the_vector;
	this->start_controller();	
}


/*	
**	Method name :	start_controller
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::start_controller()
{
	running = true;
    AfxBeginThread(run_controller, this);

}


/*	
**	Method name :	run_controller
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
void CControlHardware::run_controller()
{
	int n_pan  = this->m_the_vector.x / 22;
	int n_tilt = this->m_the_vector.y / 16;
	int msg;
	msg = (n_pan > 0) ? TURN_LEFT : TURN_RIGHT;
	int n = (n_pan < 0) ? -n_pan : n_pan;
	for(int i=0; i<n; i++)  {
		switch(msg) {
		case TURN_LEFT  : this->turn_left();		break;
		case TURN_RIGHT : this->turn_right();		break;
		}
		Sleep(50);
	}

	msg = (n_tilt < 0) ? TURN_UP : TURN_DOWN;
	n = (n_tilt < 0) ? -n_tilt : n_tilt;
	for(i=0; i<n; i++) {
		switch(msg) {
		case TURN_UP   : this->turn_up();		break;
		case TURN_DOWN : this->turn_down();		break;
		}
		Sleep(50);
	}
    PostMessage(g_hwnd, WM_CONTROLLED, 0, 0);
	running = false;
}


/*	
**	Method name :	run_controller(LPVOID p)
**	Description :	
**	Author		:	metee_tee@hotmail.com
**	Updated		:	March 16, 2003
*/
UINT CControlHardware::run_controller(LPVOID p)
{
     CControlHardware * me = (CControlHardware *)p;
     me->run_controller();
     return 0;
}
