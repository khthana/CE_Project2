// ImgProcess.cpp: implementation of the CImgProcess class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stillcap.h"
#include "ImgProcess.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//
const int W_SIZE = 3;
const int THRESHOLD = 120;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CImgProcess::CImgProcess(int ID)
{
	m_nID = ID;
}

CImgProcess::~CImgProcess()
{

}

// Get most top of the object
int CImgProcess::getTop()
{
	for(int j=0; j<(m_nHeight-W_SIZE); j+=W_SIZE) 
		for(int i=0; i<(m_nWidth-W_SIZE); i+=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return j;
		}


	return 0;
}

// Get most bottom of the object
int CImgProcess::getBottom()
{
	for(int j=m_nHeight-1-W_SIZE; j>=0; j-=W_SIZE) 
		for(int i=m_nWidth-1-W_SIZE; i>=0; i-=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return j;
		}

	return 0;
}

// Get most left of the object.
int CImgProcess::getLeft()
{
	for(int i=0; i<(m_nWidth-1-W_SIZE); i+=W_SIZE) 
		for(int j=0; j<(m_nHeight-1-W_SIZE); j+=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return i;
		}

	return 0;
}

// Get most right of the object.
int CImgProcess::getRight()
{
	for(int i=(m_nWidth-1-W_SIZE); i>=0; i-=W_SIZE) 
		for(int j=0; j<m_nHeight; j+=W_SIZE) {
			if(IsSimilar(i, j) == false)
				return i;
		}

	return 0;
} 

// Starting process 
void CImgProcess::start()
{
     if(m_bRunning == true) return;
	 m_bRunning = true;
     AfxBeginThread(run, this);
}

// Will be run.
UINT CImgProcess::run(LPVOID p)
{
    CImgProcess * me = (CImgProcess *)p;
    me->run();
	return 0;
}

// Run the process.
void CImgProcess::run() 
{
	CRect rect;
	rect.top = getTop();
	rect.bottom = getBottom();
	rect.left = getLeft();
	rect.right = getRight();
	m_cRect = rect;
 //   PostMessage(g_hwnd, WM_CAPTURE_BITMAP, 0, 0L);
	m_bRunning = false;

}

bool CImgProcess::IsSimilar(int x, int y)
{
	for(int j=y; j<y+W_SIZE; j++)
		for(int i=x; i<x+W_SIZE; i++) {
			int r1 = st[(j*m_nWidth*3) + (i*3)   ];
			int g1 = st[(j*m_nWidth*3) + (i*3) +1];
			int b1 = st[(j*m_nWidth*3) + (i*3) +2];
			int r2 = nd[(j*m_nWidth*3) + (i*3)   ];
			int g2 = nd[(j*m_nWidth*3) + (i*3) +1];
			int b2 = nd[(j*m_nWidth*3) + (i*3) +2];
			int sum_abs_dif = abs(r1-r2) + abs(g1-g2) + abs(b1-b2);
			if(sum_abs_dif > 120) return false;
		}

	return true;
}
