//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StillCap.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_STILLCAP_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_CAPDIR                      1000
#define IDC_CAPOBJ                      1001
#define IDC_SNAP                        1002
#define IDC_PREVIEW                     1003
#define IDC_STILL                       1004
#define IDC_SNAPNAME                    1005
#define IDC_CAPSTILLS                   1006
#define IDC_CAPVID                      1007
#define IDC_AUTOBUMP                    1008
#define IDC_BUTTON_RESET                1009
#define IDC_PLAYSOUND                   1010
#define IDC_FPERSEC                     1010
#define IDC_STATUS                      1011
#define IDC_BUTTON_VIEWSTILL            1012
#define IDC_SAVESTART                   1014
#define IDC_SAVESTOP                    1015
#define IDC_CON_AU_START                1016
#define IDC_PRINT                       1017
#define IDC_CON_AU_STOP                 1018
#define IDC_TURN_UP                     1022
#define IDC_TURN_LEFT                   1023
#define IDC_TURN_RIGHT                  1024
#define IDC_TURN_DOWN                   1025
#define IDC_IMGI                        1026
#define IDC_IMGII                       1027
#define IDC_BMP1                        1028
#define IDC_BMP2                        1029
#define IDC_RATE                        1030
#define IDC_CENTER                      1031
#define IDC_VECTOR                      1032
#define IDC_CONTROLLED                  1033
#define IDC_MESSAGE                     1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
