// ImageHandle.cpp: implementation of the CImageHandle class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stillcap.h"
#include "ImageHandle.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CImageHandle::CImageHandle()
{

}

CImageHandle::~CImageHandle()
{

}
