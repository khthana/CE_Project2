//------------------------------------------------------------------------------
// File: StillCapDlg.h
//
// Desc: DirectShow sample code - definition of callback and dialog
//       classes for StillCap application.
//
// Copyright (c) 1999-2001 Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------


#if !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
#define AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CStillCapDlg dialog



class CSampleGrabberCB;
class CImgProcess;
class CControlHardware;

class CStillCapDlg : public CDialog
{
    friend class CSampleGrabberCB;
public:
	// on ower thread
	void start(); 
	void run();
	void stop();
	static UINT run(LPVOID p);

	BYTE* frame_st, *frame_nd, *frame_rd;

protected:
	// my define member variable
	volatile bool running;


    // either the capture live graph, or the capture still graph
    CComPtr< IGraphBuilder > m_pGraph;

    // the playback graph when capturing video
    CComPtr< IGraphBuilder > m_pPlayGraph;

    // the sample grabber for grabbing stills
    CComPtr< ISampleGrabber > m_pGrabber;

    // if you're in still mode or capturing video mode
    bool m_bCapStills;

    // when in video mode, whether capturing or playing back
    int m_nCapState;

    // how many times you've captured
    int m_nCapTimes;

    void GetDefaultCapDevice( IBaseFilter ** ppCap );
    HRESULT InitStillGraph( );
    HRESULT InitCaptureGraph( TCHAR * pFilename );
    HRESULT InitPlaybackGraph( TCHAR * pFilename ); 
    void ClearGraphs( );
    void UpdateStatus(TCHAR *szStatus);
    void Error( TCHAR * pText );

// Construction
public:
//	CFile* m_ptr_file_out;
	bool m_bAutoControling;
	bool m_bAutoSaving;
	CStillCapDlg(CWnd* pParent = NULL);	// standard constructor
	~CStillCapDlg();
// Dialog Data
	//{{AFX_DATA(CStillCapDlg)
	enum { IDD = IDD_STILLCAP_DIALOG };
	CStatic	m_StrStatus;
	CStatic	m_StillScreen;
	CStatic	m_PreviewScreen;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStillCapDlg)
	public:
	virtual BOOL DestroyWindow();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:

	DWORD calSleep(double frames);
	
	
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CStillCapDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSnap();
	afx_msg void OnCapstills();
	afx_msg void OnCapvid();
	afx_msg void OnButtonReset();
	afx_msg void OnButtonViewstill();
	afx_msg void OnClose();
	afx_msg void OnSavestart();
	afx_msg void OnSavestop();
	afx_msg void OnConAuStart();
	afx_msg void OnConAuStop();
	afx_msg void OnTurnUp();
	afx_msg void OnTurnLeft();
	afx_msg void OnTurnDown();
	afx_msg void OnTurnRight();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString get_current_time();
	DWORD m_count5;
	bool m_controlled;
	void controlling_hardware(const CPoint the_vector);
	
	void get_direction(const CPoint center_obj , CPoint& the_vector);
	void mark_center_of_the_object(const CPoint center_obj);
	void calculate_current_center_of_the_object(const CPoint size_obj, CPoint& the_position);
	void calculate_size_of_the_object(CPoint& size_obj);
	void image_process_form_the_frames();
	int m_count3;
	int m_count2;
	int m_count1;
	void process_bmp_state_II();
	void process_bmp_state_I();
	int m_process_bmp_state;
	void on_proceed_bitmap(int id);
	void initial_process_image();
	void process_img_state_O();
	void process_img_state_II();
	void process_img_state_I();
	int m_process_img_state;
	void automatical_controlling_process();
	CImgProcess* m_pImg1;
	CImgProcess* m_pImg2;
	CControlHardware* m_ctr_hw;
};

class CImgProcess : public CObject  
{
	friend class CStillCapDlg;
public:
	void makeInfo(int width, int height);
	void makeInfo(BYTE* st, BYTE* nd);
	void makeInfo(BYTE* st, BYTE* nd, int width,  int height);
	CRect m_cRect;
	CImgProcess(int ID);
	virtual ~CImgProcess();
	void start();

protected:
	BYTE* nd;
	BYTE* st;
	int m_nWidth;
	int m_nHeight;
	void run();

	static UINT  run(LPVOID p);
	int getRight();
	int getLeft();
	int getBottom();
	int getTop();
private:
	bool IsSimilar(int x, int y);
	int m_nID;
	bool m_bRunning;
};



#include "Serial.h"
#define TURN_UP		1
#define TURN_DOWN	2
#define TURN_LEFT	3
#define	TURN_RIGHT	4

class CControlHardware : public CObject  
{
public:
	void move(const CPoint the_vector);
	void move(int msg, int step);
	void set_port_number(int port_number);
	void close();
	bool open();
	CControlHardware(int port_number = 2);
	virtual ~CControlHardware();

private:
	CPoint m_the_vector;
	int m_step;
	int m_turn_type;
	void start(); 
	void run();
	static UINT run(LPVOID p);

	void start_controller(); 
	void run_controller();
	static UINT run_controller(LPVOID p);

	bool running;
	bool turn_down();
	bool turn_up();
	bool turn_right();
	bool turn_left();
	int m_port_number;
	CSerial serial;

};
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STILLCAPDLG_H__3067E9D2_B94C_4ED1_99AB_53034129A0DD__INCLUDED_)
