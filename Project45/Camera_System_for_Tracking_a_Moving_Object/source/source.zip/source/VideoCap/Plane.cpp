// Plane.cpp: implementation of the CPlane class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stillcap.h"
#include "Plane.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPlane::CPlane(BYTE* ptr, int width, int height)
{
	m_ptr = new BYTE[width*height];
	memcpy(m_ptr, ptr, width*height);
	m_nHeight = height;
	m_nWidth  = width;
}

CPlane::CPlane(const CPlane &p)
{
	m_ptr = new BYTE[p.m_nHeight*p.m_nWidth];
	m_nWidth = p.m_nWidth;
	m_nHeight = p.m_nHeight;

	memcpy(m_ptr, p.m_ptr, m_nWidth * m_nHeight);
}

CPlane::~CPlane()
{
	delete [] m_ptr;
}

const CPlane& CPlane::operator =(const CPlane &p) 
{
	if(&p == this) return *this;
	delete [] m_ptr;
	m_ptr = new BYTE[p.m_nHeight*p.m_nWidth];
	m_nWidth = p.m_nWidth;
	m_nHeight = p.m_nHeight;

	memcpy(m_ptr, p.m_ptr, m_nWidth * m_nHeight);
	return *this;
}

