// Plane.h: interface for the CPlane class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLANE_H__BFF78EB6_FC99_4A1E_BC9C_001603B82018__INCLUDED_)
#define AFX_PLANE_H__BFF78EB6_FC99_4A1E_BC9C_001603B82018__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPlane : public CObject  
{
public:
	CPlane(const CPlane& p);
	CPlane(BYTE* ptr, int width, int height);
	virtual ~CPlane();
	const CPlane& operator =(const CPlane &p);
protected:
	int m_nHeight;
	int m_nWidth;
	BYTE* m_ptr;
};

#endif // !defined(AFX_PLANE_H__BFF78EB6_FC99_4A1E_BC9C_001603B82018__INCLUDED_)
