// ControlHardwareImp.h: interface for the CControlHardware class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONTROLHARDWAREIMP_H__A5616EFF_E4F8_4BBD_97FA_C536C0BC9A45__INCLUDED_)
#define AFX_CONTROLHARDWAREIMP_H__A5616EFF_E4F8_4BBD_97FA_C536C0BC9A45__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Serial.h"
#define TURN_UP		1
#define TURN_DOWN	2
#define TURN_LEFT	3
#define	TURN_RIGHT	4

class CControlHardware : public CObject  
{
public:
	void move(const CPoint the_vector);
	void move(int msg, int step);
	void set_port_number(int port_number);
	void close();
	bool open();
	CControlHardware(int port_number = 2);
	virtual ~CControlHardware();

private:
	CPoint m_the_vector;
	int m_step;
	int m_turn_type;
	void start(); 
	void run();
	static UINT run(LPVOID p);

	void start_controller(); 
	void run_controller();
	static UINT run_controller(LPVOID p);

	bool running;
	bool turn_down();
	bool turn_up();
	bool turn_right();
	bool turn_left();
	int m_port_number;
	CSerial serial;

};

#endif // !defined(AFX_CONTROLHARDWAREIMP_H__A5616EFF_E4F8_4BBD_97FA_C536C0BC9A45__INCLUDED_)
