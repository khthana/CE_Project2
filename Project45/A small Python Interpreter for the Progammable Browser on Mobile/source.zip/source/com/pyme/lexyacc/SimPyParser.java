/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
*
* You are on day 1 of your 30 day trial period.
*
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
*
* http://www.bumblebeesoftware.com
*
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* SimPyParser.java
* Java source file generated from SimPyParser.y.
*
* Date: 04/13/03
* Time: 12:40:14
*
* AYACC Version: 1.98 (Beta Release)
****************************************************************************/

// line 1 ".\\SimPyParser.y"

/****************************************************************************
SimPyParser.y
ParserWizard generated YACC file.

Date: Tuesday, October 01, 2002
****************************************************************************/
package com.pyme.lexyacc;

import java.util.Hashtable;
import java.util.Vector;

import com.pyme.lexyacc.yl.*;
import com.pyme.execute.*;
import com.pyme.Py;

// line 45 "SimPyParser.java"
//import yl.*;

/////////////////////////////////////////////////////////////////////////////
// SimPyParser

public class SimPyParser extends yyfparser {
// line 25 ".\\SimPyParser.y"

	// place any extra class members here
	public SymbolValue pTree;
	private Py main;
	private int compound = 0;
	private boolean execErr = false;

// line 60 "SimPyParser.java"
	public SimPyParser() {
		yytables();
// line 34 ".\\SimPyParser.y"

	// place any extra initialisation code here

// line 67 "SimPyParser.java"
	}

	public class YYSTYPE extends yyattribute {
// line 39 ".\\SimPyParser.y"

		public int value;
		public SymbolValue tBuff = new SymbolValue();
		private boolean BOOLEAN_ = false;
		private int INTEGER_ = 0;
		private Hashtable HASHTABLE_ = null;
		private Vector VECTOR_ = null;

		public int intValue;
		public long longValue;
		public String strValue;
		public String timeValue;
//		public String dateValue;
		public int secValue;
		public int minValue;
		public int hrValue;
		public int dayValue;
		public int mtValue;
		public int yrValue;

		public String ident;

		public void yycopy(yyattribute source, boolean move) {
			YYSTYPE yy = (YYSTYPE)source;
			value = yy.value;

			intValue = yy.intValue;
			longValue = yy.longValue;
			strValue = yy.strValue;
			timeValue = yy.timeValue;
//			dateValue = yy.dateValue;
			secValue = yy.secValue;
			minValue = yy.minValue;
			hrValue = yy.hrValue;
			dayValue = yy.dayValue;
			mtValue = yy.mtValue;
			yrValue = yy.yrValue;

			ident = yy.ident;
			tBuff = yy.tBuff;

			BOOLEAN_ = yy.BOOLEAN_;
			INTEGER_ = yy.INTEGER_;
			HASHTABLE_ = yy.HASHTABLE_;
			VECTOR_ = yy.VECTOR_;
		}

// line 119 "SimPyParser.java"
	}

	public static final int OR = 65537;
	public static final int AND = 65538;
	public static final int EQU = 65539;
	public static final int NE1 = 65540;
	public static final int NE2 = 65541;
	public static final int GTE = 65542;
	public static final int LTE = 65543;
	public static final int NEWLINE = 65544;
	public static final int INDENT = 65545;
	public static final int DEDENT = 65546;
	public static final int IDENTIFIER = 65547;
	public static final int INTEGER = 65548;
	public static final int LONGINTEGER = 65549;
	public static final int STRING = 65550;
	public static final int TIME = 65551;
	public static final int SECOND = 65552;
	public static final int MINUTE = 65553;
	public static final int HOUR = 65554;
	public static final int DAY = 65555;
	public static final int MONTH = 65556;
	public static final int YEAR = 65557;
	public static final int ADDE = 65558;
	public static final int SUBE = 65559;
	public static final int MULE = 65560;
	public static final int DIVE = 65561;
	public static final int POWE = 65562;
	public static final int MODE = 65563;
	public static final int IF = 65564;
	public static final int ELSE = 65565;
	public static final int ELIF = 65566;
	public static final int WHILE = 65567;
	public static final int FOR = 65568;
	public static final int PRINT = 65569;
	public static final int URL = 65570;
	public static final int MAIL = 65571;
	public static final int DEL = 65572;
	public static final int BREAK = 65573;
	public static final int CONTINUE = 65574;
	public static final int PASS = 65575;
	public static final int RETURN = 65576;
	public static final int RANGE = 65577;
	public static final int LEN = 65578;
	public static final int IS = 65579;
	public static final int IN = 65580;
	public static final int NOT = 65581;
	public static final int POW = 65582;
	protected final YYSTYPE yyattribute(int index) {
		YYSTYPE attribute = (YYSTYPE)yyattributestackref[yytop + index];
		return attribute;
	}

	protected final yyattribute yynewattribute() {
		return new YYSTYPE();
	}

	protected final YYSTYPE[] yyinitdebug(int count) {
		YYSTYPE a[] = new YYSTYPE[count];
		for (int i = 0; i < count; i++) {
			a[i] = (YYSTYPE)yyattributestackref[yytop + i - (count - 1)];
		}
		return a;
	}

	public final void yyaction(int action) {
		switch (action) {
		case 0:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 236 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.STMT, yyattribute(1 - 2).tBuff, yyattribute(2 - 2).tBuff), SymbolValue.TREE);
// line 195 "SimPyParser.java"
			}
			break;
		case 1:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 237 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 206 "SimPyParser.java"
			}
			break;
		case 2:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 241 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 2).tBuff;
// line 217 "SimPyParser.java"
			}
			break;
		case 3:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 242 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(3 - 4).tBuff;
// line 228 "SimPyParser.java"
			}
			break;
		case 4:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 252 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.STMT, yyattribute(1 - 2).tBuff, yyattribute(2 - 2).tBuff), SymbolValue.TREE);
// line 239 "SimPyParser.java"
			}
			break;
		case 5:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 253 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 250 "SimPyParser.java"
			}
			break;
		case 6:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 257 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 2).tBuff;
// line 261 "SimPyParser.java"
			}
			break;
		case 7:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 258 ".\\SimPyParser.y"

										   compound--;
										   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
										   /*1else {
										     new SimPyExec($1, main);

										     System.out.println("compound_stmt");
										   }*/
										   else if (!execErr) {
										     new SimPyExec(yyattribute(1 - 1).tBuff, main, this);
										   }

// line 283 "SimPyParser.java"
			}
			break;
		case 8:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 270 ".\\SimPyParser.y"

										   if (yylexerref.dedent == 0) {
										     //System.out.println("ERROR");
										     //System.exit(0);
										     //1new SimPyExec(null, main);
										     new SimPyExec(null, main, this);
										   }
										   else {
										     compound -= yylexerref.dedent;
										     //if (compound != 0) $$ = tBuff;
										     //else {
										     //  new SimPyExec($1, main);
											   System.out.println("compound_stmt");
											 //}
										   }

// line 309 "SimPyParser.java"
			}
			break;
		case 9:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 289 ".\\SimPyParser.y"

														   if (yyattribute(2 - 2).tBuff == null) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 2).tBuff;
														   else ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.STMT, yyattribute(1 - 2).tBuff, yyattribute(2 - 2).tBuff), SymbolValue.TREE);

// line 323 "SimPyParser.java"
			}
			break;
		case 10:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 297 ".\\SimPyParser.y"

												   if (yyattribute(3 - 3).tBuff == null) ((YYSTYPE)yyvalref).tBuff = yyattribute(2 - 3).tBuff;
												   else ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.STMT, yyattribute(2 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);

// line 337 "SimPyParser.java"
			}
			break;
		case 11:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 301 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 348 "SimPyParser.java"
			}
			break;
		case 12:
			{
// line 302 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 355 "SimPyParser.java"
			}
			break;
		case 13:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 311 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main); System.out.println("expression_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this); System.out.println("expression_stmt"); }

// line 370 "SimPyParser.java"
			}
			break;
		case 14:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 317 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main); System.out.println("assignment_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this); System.out.println("assignment_stmt"); }

// line 385 "SimPyParser.java"
			}
			break;
		case 15:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 322 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main);  System.out.println("augmented_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this);  System.out.println("augmented_stmt"); }

// line 400 "SimPyParser.java"
			}
			break;
		case 16:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 327 ".\\SimPyParser.y"

									   SymbolValue s1 = new SymbolValue(null, SymbolValue.BREAK);
									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = s1;
									   //1else { new SimPyExec(s1, main);  System.out.println("break_stmt"); }
									   else if (!execErr) { new SimPyExec(s1, main, this);  System.out.println("break_stmt"); }

// line 416 "SimPyParser.java"
			}
			break;
		case 17:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 333 ".\\SimPyParser.y"

									   SymbolValue s1 = new SymbolValue(null, SymbolValue.CONTINUE);
									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = s1;
									   //1else { new SimPyExec(s1, main);  System.out.println("continue_stmt"); }
									   else if (!execErr) { new SimPyExec(s1, main, this);  System.out.println("continue_stmt"); }

// line 432 "SimPyParser.java"
			}
			break;
		case 18:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 339 ".\\SimPyParser.y"

									   SymbolValue s1 = new SymbolValue(null, SymbolValue.PASS);
									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = s1;
									   //1else { new SimPyExec(s1, main);  System.out.println("pass_stmt"); }
									   else if (!execErr) { new SimPyExec(s1, main, this);  System.out.println("pass_stmt"); }

// line 448 "SimPyParser.java"
			}
			break;
		case 19:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 345 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main);  System.out.println("return_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this);  System.out.println("return_stmt"); }

// line 463 "SimPyParser.java"
			}
			break;
		case 20:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 350 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main);  System.out.println("del_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this);  System.out.println("del_stmt"); }

// line 478 "SimPyParser.java"
			}
			break;
		case 21:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 355 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main);  System.out.println("print_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this);  System.out.println("print_stmt"); }

// line 493 "SimPyParser.java"
			}
			break;
		case 22:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 365 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main);  System.out.println("url_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this);  System.out.println("url_stmt"); }

// line 508 "SimPyParser.java"
			}
			break;
		case 23:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 370 ".\\SimPyParser.y"

									   if (compound != 0) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
									   //1else { new SimPyExec($1, main);  System.out.println("mail_stmt"); }
									   else if (!execErr) { new SimPyExec(yyattribute(1 - 1).tBuff, main, this);  System.out.println("mail_stmt"); }

// line 523 "SimPyParser.java"
			}
			break;
		case 24:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 382 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 534 "SimPyParser.java"
			}
			break;
		case 25:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 387 ".\\SimPyParser.y"

							   if (yyattribute(2 - 2).tBuff == null) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 2).tBuff;
							   else ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.EXPRLIST, yyattribute(1 - 2).tBuff, yyattribute(2 - 2).tBuff),SymbolValue.TREE);

// line 548 "SimPyParser.java"
			}
			break;
		case 26:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 394 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.EXPRLIST, yyattribute(2 - 3).tBuff, yyattribute(3 - 3).tBuff),SymbolValue.TREE);
// line 559 "SimPyParser.java"
			}
			break;
		case 27:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 395 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 570 "SimPyParser.java"
			}
			break;
		case 28:
			{
// line 396 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 577 "SimPyParser.java"
			}
			break;
		case 29:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 405 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 588 "SimPyParser.java"
			}
			break;
		case 30:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 410 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 599 "SimPyParser.java"
			}
			break;
		case 31:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 411 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.OR, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 610 "SimPyParser.java"
			}
			break;
		case 32:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 415 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 621 "SimPyParser.java"
			}
			break;
		case 33:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 416 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.AND, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 632 "SimPyParser.java"
			}
			break;
		case 34:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 419 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 643 "SimPyParser.java"
			}
			break;
		case 35:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 420 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.NOT, yyattribute(2 - 2).tBuff, null), SymbolValue.TREE);
// line 654 "SimPyParser.java"
			}
			break;
		case 36:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 429 ".\\SimPyParser.y"

							   SymbolValue sBuff = yyattribute(1 - 2).tBuff;
							   if (yyattribute(2 - 2).HASHTABLE_ != null) {
							     int treeType = ((Integer)yyattribute(2 - 2).HASHTABLE_.get("comp_operator")).intValue();
							     sBuff = new SymbolValue(new ParseTree(treeType, yyattribute(1 - 2).tBuff,(SymbolValue)yyattribute(2 - 2).HASHTABLE_.get("a_expr")), SymbolValue.TREE);
						       }

						       ((YYSTYPE)yyvalref).tBuff = sBuff;

// line 673 "SimPyParser.java"
			}
			break;
		case 37:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 443 ".\\SimPyParser.y"

						       Hashtable hBuff = new Hashtable();
						       SymbolValue sBuff = yyattribute(2 - 3).tBuff;
						       if (yyattribute(3 - 3).HASHTABLE_ != null) {
							     int treeType = ((Integer)yyattribute(3 - 3).HASHTABLE_.get("comp_operator")).intValue();
							     sBuff = new SymbolValue(new ParseTree(treeType, yyattribute(2 - 3).tBuff,(SymbolValue)yyattribute(3 - 3).HASHTABLE_.get("a_expr")), SymbolValue.TREE);
						       }

							   hBuff.put("comp_operator", new Integer(yyattribute(1 - 3).INTEGER_));
							   hBuff.put("a_expr", sBuff);
							   ((YYSTYPE)yyvalref).HASHTABLE_ = hBuff;

// line 695 "SimPyParser.java"
			}
			break;
		case 38:
			{
// line 455 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).HASHTABLE_ = null;
// line 702 "SimPyParser.java"
			}
			break;
		case 39:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 459 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.LT;
// line 713 "SimPyParser.java"
			}
			break;
		case 40:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 460 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.GT;
// line 724 "SimPyParser.java"
			}
			break;
		case 41:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 461 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.EQU;
// line 735 "SimPyParser.java"
			}
			break;
		case 42:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 462 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.GTE;
// line 746 "SimPyParser.java"
			}
			break;
		case 43:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 463 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.LTE;
// line 757 "SimPyParser.java"
			}
			break;
		case 44:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 464 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.NE;
// line 768 "SimPyParser.java"
			}
			break;
		case 45:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 465 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.NE;
// line 779 "SimPyParser.java"
			}
			break;
		case 46:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 466 ".\\SimPyParser.y"
 if (yyattribute(2 - 2).BOOLEAN_) ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.ISNOT; else ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.IS;
// line 790 "SimPyParser.java"
			}
			break;
		case 47:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 467 ".\\SimPyParser.y"
 if (yyattribute(1 - 2).BOOLEAN_) ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.NOTIN; else ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.IN;
// line 801 "SimPyParser.java"
			}
			break;
		case 48:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 471 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).BOOLEAN_ = true;
// line 812 "SimPyParser.java"
			}
			break;
		case 49:
			{
// line 472 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).BOOLEAN_ = false;
// line 819 "SimPyParser.java"
			}
			break;
		case 50:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 491 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 830 "SimPyParser.java"
			}
			break;
		case 51:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 492 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.ADD, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 841 "SimPyParser.java"
			}
			break;
		case 52:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 493 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.SUB, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 852 "SimPyParser.java"
			}
			break;
		case 53:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 497 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 863 "SimPyParser.java"
			}
			break;
		case 54:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 498 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.MUL, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 874 "SimPyParser.java"
			}
			break;
		case 55:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 500 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.DIV, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 885 "SimPyParser.java"
			}
			break;
		case 56:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 501 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.MOD, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 896 "SimPyParser.java"
			}
			break;
		case 57:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 505 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 907 "SimPyParser.java"
			}
			break;
		case 58:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 506 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.SUB, new SymbolValue(new Integer(0), SymbolValue.INTEGER), yyattribute(2 - 2).tBuff), SymbolValue.TREE);
// line 918 "SimPyParser.java"
			}
			break;
		case 59:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 507 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.ADD, new SymbolValue(new Integer(0), SymbolValue.INTEGER), yyattribute(2 - 2).tBuff), SymbolValue.TREE);
// line 929 "SimPyParser.java"
			}
			break;
		case 60:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 508 ".\\SimPyParser.y"

										   SymbolValue s2 = new SymbolValue(new ParseTree(ParseTree.ADD, yyattribute(2 - 2).tBuff, new SymbolValue(new Integer(1), SymbolValue.INTEGER)), SymbolValue.TREE);
										   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.SUB, new SymbolValue(new Integer(0), SymbolValue.INTEGER), s2), SymbolValue.TREE);

// line 943 "SimPyParser.java"
			}
			break;
		case 61:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 515 ".\\SimPyParser.y"

									   if (yyattribute(2 - 2).tBuff == null) ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 2).tBuff;
									   else ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.POW, yyattribute(1 - 2).tBuff, yyattribute(2 - 2).tBuff), SymbolValue.TREE);

// line 957 "SimPyParser.java"
			}
			break;
		case 62:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 522 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(2 - 2).tBuff;
// line 968 "SimPyParser.java"
			}
			break;
		case 63:
			{
// line 523 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 975 "SimPyParser.java"
			}
			break;
		case 64:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 527 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 986 "SimPyParser.java"
			}
			break;
		case 65:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 528 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 997 "SimPyParser.java"
			}
			break;
		case 66:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 536 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.SUBSCRIPT, yyattribute(1 - 4).tBuff, yyattribute(3 - 4).tBuff), SymbolValue.TREE);
// line 1008 "SimPyParser.java"
			}
			break;
		case 67:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 541 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1019 "SimPyParser.java"
			}
			break;
		case 68:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 542 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1030 "SimPyParser.java"
			}
			break;
		case 69:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 543 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1041 "SimPyParser.java"
			}
			break;
		case 70:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 544 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1052 "SimPyParser.java"
			}
			break;
		case 71:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 548 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(2 - 3).tBuff;
// line 1063 "SimPyParser.java"
			}
			break;
		case 72:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 549 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(2 - 3).tBuff;
// line 1074 "SimPyParser.java"
			}
			break;
		case 73:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 556 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1085 "SimPyParser.java"
			}
			break;
		case 74:
			{
// line 557 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 1092 "SimPyParser.java"
			}
			break;
		case 75:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 561 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).intValue), SymbolValue.INTEGER);
// line 1103 "SimPyParser.java"
			}
			break;
		case 76:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 563 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new String(yyattribute(1 - 1).strValue), SymbolValue.STRING);
// line 1114 "SimPyParser.java"
			}
			break;
		case 77:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 564 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Long(yyattribute(1 - 1).longValue), SymbolValue.LONGINTEGER);
// line 1125 "SimPyParser.java"
			}
			break;
		case 78:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 567 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new String(yyattribute(1 - 1).timeValue), SymbolValue.TIME); System.out.println("TIME");
// line 1136 "SimPyParser.java"
			}
			break;
		case 79:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 569 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).secValue), SymbolValue.SECOND); System.out.println("SECOND");
// line 1147 "SimPyParser.java"
			}
			break;
		case 80:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 570 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).minValue), SymbolValue.MINUTE); System.out.println("MINUTE");
// line 1158 "SimPyParser.java"
			}
			break;
		case 81:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 571 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).hrValue), SymbolValue.HOUR); System.out.println("HOUR");
// line 1169 "SimPyParser.java"
			}
			break;
		case 82:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 572 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).dayValue), SymbolValue.DAY); System.out.println("DAY");
// line 1180 "SimPyParser.java"
			}
			break;
		case 83:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 573 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).mtValue), SymbolValue.MONTH); System.out.println("MONTH");
// line 1191 "SimPyParser.java"
			}
			break;
		case 84:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 574 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new Integer(yyattribute(1 - 1).yrValue), SymbolValue.YEAR); System.out.println("YEAR");
// line 1202 "SimPyParser.java"
			}
			break;
		case 85:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 579 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.ASSIGN, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 1213 "SimPyParser.java"
			}
			break;
		case 86:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 583 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1224 "SimPyParser.java"
			}
			break;
		case 87:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 584 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1235 "SimPyParser.java"
			}
			break;
		case 88:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 588 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(yyattribute(2 - 3).INTEGER_, yyattribute(1 - 3).tBuff, yyattribute(3 - 3).tBuff), SymbolValue.TREE);
// line 1246 "SimPyParser.java"
			}
			break;
		case 89:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 592 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.ADDASSIGN;
// line 1257 "SimPyParser.java"
			}
			break;
		case 90:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 593 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.SUBASSIGN;
// line 1268 "SimPyParser.java"
			}
			break;
		case 91:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 594 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.MULASSIGN;
// line 1279 "SimPyParser.java"
			}
			break;
		case 92:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 595 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.DIVASSIGN;
// line 1290 "SimPyParser.java"
			}
			break;
		case 93:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 596 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.POWASSIGN;
// line 1301 "SimPyParser.java"
			}
			break;
		case 94:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 597 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).INTEGER_ = ParseTree.MODASSIGN;
// line 1312 "SimPyParser.java"
			}
			break;
		case 95:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 631 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(yyattribute(1 - 1).ident, SymbolValue.IDENTIFIER);
// line 1323 "SimPyParser.java"
			}
			break;
		case 96:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 634 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1334 "SimPyParser.java"
			}
			break;
		case 97:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 640 ".\\SimPyParser.y"

												   SymbolValue s2 = new SymbolValue(yyattribute(2 - 3).ident, SymbolValue.IDENTIFIER);
												   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.IDENLIST, s2, yyattribute(3 - 3).tBuff), SymbolValue.TREE);

// line 1348 "SimPyParser.java"
			}
			break;
		case 98:
			{
// line 644 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 1355 "SimPyParser.java"
			}
			break;
		case 99:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 648 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.RETURN, yyattribute(2 - 2).tBuff, null), SymbolValue.TREE);
// line 1366 "SimPyParser.java"
			}
			break;
		case 100:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(3);
				}
// line 652 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.PRINT, yyattribute(2 - 2).tBuff, null), SymbolValue.TREE);
// line 1377 "SimPyParser.java"
			}
			break;
		case 101:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 659 ".\\SimPyParser.y"

									   SymbolValue s1 = new SymbolValue(yyattribute(2 - 3).ident, SymbolValue.IDENTIFIER);
									   SymbolValue s2;
									   if (yyattribute(3 - 3).tBuff == null) s2 = s1;
									   else s2 = new SymbolValue(new ParseTree(ParseTree.IDENLIST, s1, yyattribute(3 - 3).tBuff), SymbolValue.TREE);

									   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.DELETE, s2, null) ,SymbolValue.TREE);

// line 1395 "SimPyParser.java"
			}
			break;
		case 102:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 682 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1406 "SimPyParser.java"
			}
			break;
		case 103:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 683 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1417 "SimPyParser.java"
			}
			break;
		case 104:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 684 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(1 - 1).tBuff;
// line 1428 "SimPyParser.java"
			}
			break;
		case 105:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 691 ".\\SimPyParser.y"
 compound++;
// line 1439 "SimPyParser.java"
			}
			break;
		case 106:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(8);
				}
// line 692 ".\\SimPyParser.y"

									   if (yyattribute(7 - 7).tBuff == null)
									     ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.IF, yyattribute(5 - 7).tBuff, yyattribute(6 - 7).tBuff, yyattribute(3 - 7).tBuff), SymbolValue.TREE);
									   else if (yyattribute(6 - 7).tBuff == null)
									     ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.IF, yyattribute(5 - 7).tBuff, yyattribute(7 - 7).tBuff, yyattribute(3 - 7).tBuff), SymbolValue.TREE);
									   else {
									     SymbolValue sBuff = new SymbolValue(new ParseTree(ParseTree.ELIF, yyattribute(6 - 7).tBuff, yyattribute(7 - 7).tBuff), SymbolValue.TREE);
									     ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.IF, yyattribute(5 - 7).tBuff, sBuff, yyattribute(3 - 7).tBuff), SymbolValue.TREE);
									   }

// line 1459 "SimPyParser.java"
			}
			break;
		case 107:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(6);
				}
// line 705 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.IF, yyattribute(4 - 5).tBuff, yyattribute(5 - 5).tBuff, yyattribute(2 - 5).tBuff), SymbolValue.TREE);
// line 1470 "SimPyParser.java"
			}
			break;
		case 108:
			{
// line 706 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 1477 "SimPyParser.java"
			}
			break;
		case 109:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(4);
				}
// line 710 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = yyattribute(3 - 3).tBuff;
// line 1488 "SimPyParser.java"
			}
			break;
		case 110:
			{
// line 711 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = null;
// line 1495 "SimPyParser.java"
			}
			break;
		case 111:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 715 ".\\SimPyParser.y"
 compound++;
// line 1506 "SimPyParser.java"
			}
			break;
		case 112:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(7);
				}
// line 716 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.WHILE, yyattribute(5 - 6).tBuff, yyattribute(6 - 6).tBuff, yyattribute(3 - 6).tBuff), SymbolValue.TREE);
// line 1517 "SimPyParser.java"
			}
			break;
		case 113:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(2);
				}
// line 720 ".\\SimPyParser.y"
 compound++;
// line 1528 "SimPyParser.java"
			}
			break;
		case 114:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(9);
				}
// line 721 ".\\SimPyParser.y"

								   SymbolValue s3 = new SymbolValue(new ParseTree(ParseTree.IN, yyattribute(3 - 8).tBuff, yyattribute(5 - 8).tBuff),SymbolValue.TREE);
//								   SymbolValue s3 = new SymbolValue(new ParseTree(ParseTree.IN, new SymbolValue($3, SymbolValue.IDENTIFIER), $5),SymbolValue.TREE);
								   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.FOR, yyattribute(7 - 8).tBuff, yyattribute(8 - 8).tBuff, s3), SymbolValue.TREE);

// line 1543 "SimPyParser.java"
			}
			break;
		case 115:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 730 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.RANGE, yyattribute(3 - 4).tBuff, null), SymbolValue.TREE);
// line 1554 "SimPyParser.java"
			}
			break;
		case 116:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(7);
				}
// line 732 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.RANGE, yyattribute(3 - 6).tBuff, yyattribute(5 - 6).tBuff), SymbolValue.TREE);
// line 1565 "SimPyParser.java"
			}
			break;
		case 117:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(9);
				}
// line 734 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.RANGE, yyattribute(3 - 8).tBuff, yyattribute(5 - 8).tBuff, yyattribute(7 - 8).tBuff), SymbolValue.TREE);
// line 1576 "SimPyParser.java"
			}
			break;
		case 118:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 739 ".\\SimPyParser.y"
 ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.LEN, yyattribute(3 - 4).tBuff, null), SymbolValue.TREE);
// line 1587 "SimPyParser.java"
			}
			break;
		case 119:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(5);
				}
// line 754 ".\\SimPyParser.y"

								   SymbolValue s3 = new SymbolValue(yyattribute(3 - 4).strValue, SymbolValue.STRING);
								   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.URL, s3, null), SymbolValue.TREE);

// line 1601 "SimPyParser.java"
			}
			break;
		case 120:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(7);
				}
// line 759 ".\\SimPyParser.y"

								   SymbolValue s3 = new SymbolValue(yyattribute(3 - 6).strValue, SymbolValue.STRING);
								   SymbolValue s5 = new SymbolValue(yyattribute(5 - 6).timeValue, SymbolValue.TIME);
								   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.URL, s3, s5), SymbolValue.TREE);

// line 1616 "SimPyParser.java"
			}
			break;
		case 121:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(11);
				}
// line 768 ".\\SimPyParser.y"

								   SymbolValue s3 = new SymbolValue(yyattribute(3 - 10).strValue + ',' + yyattribute(5 - 10).strValue + ',' + yyattribute(7 - 10).strValue + ',' + yyattribute(9 - 10).strValue, SymbolValue.STRING);
								   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.MAIL, s3, null), SymbolValue.TREE);

// line 1630 "SimPyParser.java"
			}
			break;
		case 122:
			{
				YYSTYPE yya[];
				if (YYDEBUG) {
					yya = yyinitdebug(13);
				}
// line 773 ".\\SimPyParser.y"

								   SymbolValue s3 = new SymbolValue(yyattribute(3 - 12).strValue + ',' + yyattribute(5 - 12).strValue + ',' + yyattribute(7 - 12).strValue + ',' + yyattribute(9 - 12).strValue, SymbolValue.STRING);
								   SymbolValue s11 = new SymbolValue(yyattribute(11 - 12).timeValue, SymbolValue.TIME);
								   ((YYSTYPE)yyvalref).tBuff = new SymbolValue(new ParseTree(ParseTree.MAIL, s3, s11), SymbolValue.TREE);

// line 1645 "SimPyParser.java"
			}
			break;
		default:
			break;
		}
	}

	protected final void yytables() {
		yysstack_size = 100;
		yystack_max = 0;

		if (YYDEBUG) {
			final yysymbol symbol[] = {
				new yysymbol("$end", 0),
				new yysymbol("\'%\'", 37),
				new yysymbol("\'(\'", 40),
				new yysymbol("\')\'", 41),
				new yysymbol("\'*\'", 42),
				new yysymbol("\'+\'", 43),
				new yysymbol("\',\'", 44),
				new yysymbol("\'-\'", 45),
				new yysymbol("\'/\'", 47),
				new yysymbol("\':\'", 58),
				new yysymbol("\';\'", 59),
				new yysymbol("\'<\'", 60),
				new yysymbol("\'=\'", 61),
				new yysymbol("\'>\'", 62),
				new yysymbol("\'[\'", 91),
				new yysymbol("\']\'", 93),
				new yysymbol("\'~\'", 126),
				new yysymbol("error", 65536),
				new yysymbol("OR", 65537),
				new yysymbol("AND", 65538),
				new yysymbol("EQU", 65539),
				new yysymbol("NE1", 65540),
				new yysymbol("NE2", 65541),
				new yysymbol("GTE", 65542),
				new yysymbol("LTE", 65543),
				new yysymbol("NEWLINE", 65544),
				new yysymbol("INDENT", 65545),
				new yysymbol("DEDENT", 65546),
				new yysymbol("IDENTIFIER", 65547),
				new yysymbol("INTEGER", 65548),
				new yysymbol("LONGINTEGER", 65549),
				new yysymbol("STRING", 65550),
				new yysymbol("TIME", 65551),
				new yysymbol("SECOND", 65552),
				new yysymbol("MINUTE", 65553),
				new yysymbol("HOUR", 65554),
				new yysymbol("DAY", 65555),
				new yysymbol("MONTH", 65556),
				new yysymbol("YEAR", 65557),
				new yysymbol("ADDE", 65558),
				new yysymbol("SUBE", 65559),
				new yysymbol("MULE", 65560),
				new yysymbol("DIVE", 65561),
				new yysymbol("POWE", 65562),
				new yysymbol("MODE", 65563),
				new yysymbol("IF", 65564),
				new yysymbol("ELSE", 65565),
				new yysymbol("ELIF", 65566),
				new yysymbol("WHILE", 65567),
				new yysymbol("FOR", 65568),
				new yysymbol("PRINT", 65569),
				new yysymbol("URL", 65570),
				new yysymbol("MAIL", 65571),
				new yysymbol("DEL", 65572),
				new yysymbol("BREAK", 65573),
				new yysymbol("CONTINUE", 65574),
				new yysymbol("PASS", 65575),
				new yysymbol("RETURN", 65576),
				new yysymbol("RANGE", 65577),
				new yysymbol("LEN", 65578),
				new yysymbol("IS", 65579),
				new yysymbol("IN", 65580),
				new yysymbol("NOT", 65581),
				new yysymbol("POW", 65582),
				new yysymbol(null, 0)
			};
			yysymbol = symbol;

			final String rule[] = {
				"$accept: file",
				"file: statement file",
				"file: statement",
				"suite: stmt_list NEWLINE",
				"suite: NEWLINE INDENT statement_ DEDENT",
				"statement_: statement statement_",
				"statement_: statement",
				"statement: stmt_list NEWLINE",
				"statement: compound_stmt",
				"statement: error",
				"stmt_list: simple_stmt simple_stmt_",
				"simple_stmt_: \';\' simple_stmt simple_stmt_",
				"simple_stmt_: \';\'",
				"simple_stmt_:",
				"simple_stmt: expression_stmt",
				"simple_stmt: assignment_stmt",
				"simple_stmt: augmented_stmt",
				"simple_stmt: BREAK",
				"simple_stmt: CONTINUE",
				"simple_stmt: PASS",
				"simple_stmt: return_stmt",
				"simple_stmt: del_stmt",
				"simple_stmt: print_stmt",
				"simple_stmt: url_stmt",
				"simple_stmt: mail_stmt",
				"expression_stmt: expression_list",
				"expression_list: expression expression_",
				"expression_: \',\' expression expression_",
				"expression_: \',\'",
				"expression_:",
				"expression: or_test",
				"or_test: and_test",
				"or_test: or_test OR and_test",
				"and_test: not_test",
				"and_test: and_test AND not_test",
				"not_test: comparison",
				"not_test: NOT not_test",
				"comparison: a_expr comp_operator_",
				"comp_operator_: comp_operator a_expr comp_operator_",
				"comp_operator_:",
				"comp_operator: \'<\'",
				"comp_operator: \'>\'",
				"comp_operator: EQU",
				"comp_operator: GTE",
				"comp_operator: LTE",
				"comp_operator: NE1",
				"comp_operator: NE2",
				"comp_operator: IS not_",
				"comp_operator: not_ IN",
				"not_: NOT",
				"not_:",
				"a_expr: m_expr",
				"a_expr: a_expr \'+\' m_expr",
				"a_expr: a_expr \'-\' m_expr",
				"m_expr: u_expr",
				"m_expr: m_expr \'*\' u_expr",
				"m_expr: m_expr \'/\' u_expr",
				"m_expr: m_expr \'%\' u_expr",
				"u_expr: power",
				"u_expr: \'-\' u_expr",
				"u_expr: \'+\' u_expr",
				"u_expr: \'~\' u_expr",
				"power: primary power_",
				"power_: POW u_expr",
				"power_:",
				"primary: atom",
				"primary: target",
				"subscription: primary \'[\' expression_list \']\'",
				"atom: literal",
				"atom: enclosure",
				"atom: range_stmt",
				"atom: len_stmt",
				"enclosure: \'(\' expression_list_ \')\'",
				"enclosure: \'[\' expression_list_ \']\'",
				"expression_list_: expression_list",
				"expression_list_:",
				"literal: INTEGER",
				"literal: STRING",
				"literal: LONGINTEGER",
				"literal: TIME",
				"literal: SECOND",
				"literal: MINUTE",
				"literal: HOUR",
				"literal: DAY",
				"literal: MONTH",
				"literal: YEAR",
				"assignment_stmt: target \'=\' assignment_stmt_",
				"assignment_stmt_: assignment_stmt",
				"assignment_stmt_: expression_list",
				"augmented_stmt: target augop expression_list",
				"augop: ADDE",
				"augop: SUBE",
				"augop: MULE",
				"augop: DIVE",
				"augop: POWE",
				"augop: MODE",
				"target: IDENTIFIER",
				"target: subscription",
				"identifier_: \',\' IDENTIFIER identifier_",
				"identifier_:",
				"return_stmt: RETURN expression_list_",
				"print_stmt: PRINT expression_list",
				"del_stmt: DEL IDENTIFIER identifier_",
				"compound_stmt: if_stmt",
				"compound_stmt: while_stmt",
				"compound_stmt: for_stmt",
				"$$1:",
				"if_stmt: IF $$1 expression \':\' suite elif_stmt else_stmt",
				"elif_stmt: ELIF expression \':\' suite elif_stmt",
				"elif_stmt:",
				"else_stmt: ELSE \':\' suite",
				"else_stmt:",
				"$$2:",
				"while_stmt: WHILE $$2 expression \':\' suite else_stmt",
				"$$3:",
				"for_stmt: FOR $$3 target IN expression_list \':\' suite else_stmt",
				"range_stmt: RANGE \'(\' expression \')\'",
				"range_stmt: RANGE \'(\' expression \',\' expression \')\'",
				"range_stmt: RANGE \'(\' expression \',\' expression \',\' expression \')\'",
				"len_stmt: LEN \'(\' expression_list \')\'",
				"url_stmt: URL \'(\' STRING \')\'",
				"url_stmt: URL \'(\' STRING \',\' TIME \')\'",
				"mail_stmt: MAIL \'(\' STRING \',\' STRING \',\' STRING \',\' STRING \')\'",
				"mail_stmt: MAIL \'(\' STRING \',\' STRING \',\' STRING \',\' STRING \',\' TIME \')\'"
			};
			yyrule = rule;
		}

		final yyreduction reduction[] = {
			new yyreduction(0, 1, -1),
			new yyreduction(1, 2, 0),
			new yyreduction(1, 1, 1),
			new yyreduction(2, 2, 2),
			new yyreduction(2, 4, 3),
			new yyreduction(3, 2, 4),
			new yyreduction(3, 1, 5),
			new yyreduction(4, 2, 6),
			new yyreduction(4, 1, 7),
			new yyreduction(4, 1, 8),
			new yyreduction(5, 2, 9),
			new yyreduction(6, 3, 10),
			new yyreduction(6, 1, 11),
			new yyreduction(6, 0, 12),
			new yyreduction(7, 1, 13),
			new yyreduction(7, 1, 14),
			new yyreduction(7, 1, 15),
			new yyreduction(7, 1, 16),
			new yyreduction(7, 1, 17),
			new yyreduction(7, 1, 18),
			new yyreduction(7, 1, 19),
			new yyreduction(7, 1, 20),
			new yyreduction(7, 1, 21),
			new yyreduction(7, 1, 22),
			new yyreduction(7, 1, 23),
			new yyreduction(8, 1, 24),
			new yyreduction(9, 2, 25),
			new yyreduction(10, 3, 26),
			new yyreduction(10, 1, 27),
			new yyreduction(10, 0, 28),
			new yyreduction(11, 1, 29),
			new yyreduction(12, 1, 30),
			new yyreduction(12, 3, 31),
			new yyreduction(13, 1, 32),
			new yyreduction(13, 3, 33),
			new yyreduction(14, 1, 34),
			new yyreduction(14, 2, 35),
			new yyreduction(15, 2, 36),
			new yyreduction(16, 3, 37),
			new yyreduction(16, 0, 38),
			new yyreduction(17, 1, 39),
			new yyreduction(17, 1, 40),
			new yyreduction(17, 1, 41),
			new yyreduction(17, 1, 42),
			new yyreduction(17, 1, 43),
			new yyreduction(17, 1, 44),
			new yyreduction(17, 1, 45),
			new yyreduction(17, 2, 46),
			new yyreduction(17, 2, 47),
			new yyreduction(18, 1, 48),
			new yyreduction(18, 0, 49),
			new yyreduction(19, 1, 50),
			new yyreduction(19, 3, 51),
			new yyreduction(19, 3, 52),
			new yyreduction(20, 1, 53),
			new yyreduction(20, 3, 54),
			new yyreduction(20, 3, 55),
			new yyreduction(20, 3, 56),
			new yyreduction(21, 1, 57),
			new yyreduction(21, 2, 58),
			new yyreduction(21, 2, 59),
			new yyreduction(21, 2, 60),
			new yyreduction(22, 2, 61),
			new yyreduction(23, 2, 62),
			new yyreduction(23, 0, 63),
			new yyreduction(24, 1, 64),
			new yyreduction(24, 1, 65),
			new yyreduction(25, 4, 66),
			new yyreduction(26, 1, 67),
			new yyreduction(26, 1, 68),
			new yyreduction(26, 1, 69),
			new yyreduction(26, 1, 70),
			new yyreduction(27, 3, 71),
			new yyreduction(27, 3, 72),
			new yyreduction(28, 1, 73),
			new yyreduction(28, 0, 74),
			new yyreduction(29, 1, 75),
			new yyreduction(29, 1, 76),
			new yyreduction(29, 1, 77),
			new yyreduction(29, 1, 78),
			new yyreduction(29, 1, 79),
			new yyreduction(29, 1, 80),
			new yyreduction(29, 1, 81),
			new yyreduction(29, 1, 82),
			new yyreduction(29, 1, 83),
			new yyreduction(29, 1, 84),
			new yyreduction(30, 3, 85),
			new yyreduction(31, 1, 86),
			new yyreduction(31, 1, 87),
			new yyreduction(32, 3, 88),
			new yyreduction(33, 1, 89),
			new yyreduction(33, 1, 90),
			new yyreduction(33, 1, 91),
			new yyreduction(33, 1, 92),
			new yyreduction(33, 1, 93),
			new yyreduction(33, 1, 94),
			new yyreduction(34, 1, 95),
			new yyreduction(34, 1, 96),
			new yyreduction(35, 3, 97),
			new yyreduction(35, 0, 98),
			new yyreduction(36, 2, 99),
			new yyreduction(37, 2, 100),
			new yyreduction(38, 3, 101),
			new yyreduction(39, 1, 102),
			new yyreduction(39, 1, 103),
			new yyreduction(39, 1, 104),
			new yyreduction(41, 0, 105),
			new yyreduction(40, 7, 106),
			new yyreduction(42, 5, 107),
			new yyreduction(42, 0, 108),
			new yyreduction(43, 3, 109),
			new yyreduction(43, 0, 110),
			new yyreduction(45, 0, 111),
			new yyreduction(44, 6, 112),
			new yyreduction(47, 0, 113),
			new yyreduction(46, 8, 114),
			new yyreduction(48, 4, 115),
			new yyreduction(48, 6, 116),
			new yyreduction(48, 8, 117),
			new yyreduction(49, 4, 118),
			new yyreduction(50, 4, 119),
			new yyreduction(50, 6, 120),
			new yyreduction(51, 10, 121),
			new yyreduction(51, 12, 122)
		};
		yyreduction = reduction;

		final yytokenaction tokenaction[] = {
			new yytokenaction(217, YYAT_SHIFT, 6),
			new yytokenaction(195, YYAT_SHIFT, 1),
			new yytokenaction(201, YYAT_SHIFT, 203),
			new yytokenaction(213, YYAT_SHIFT, 118),
			new yytokenaction(195, YYAT_SHIFT, 2),
			new yytokenaction(201, YYAT_SHIFT, 204),
			new yytokenaction(195, YYAT_SHIFT, 3),
			new yytokenaction(173, YYAT_SHIFT, 183),
			new yytokenaction(205, YYAT_SHIFT, 206),
			new yytokenaction(204, YYAT_SHIFT, 205),
			new yytokenaction(173, YYAT_SHIFT, 184),
			new yytokenaction(217, YYAT_SHIFT, 7),
			new yytokenaction(217, YYAT_SHIFT, 8),
			new yytokenaction(217, YYAT_SHIFT, 9),
			new yytokenaction(217, YYAT_SHIFT, 10),
			new yytokenaction(217, YYAT_SHIFT, 11),
			new yytokenaction(217, YYAT_SHIFT, 12),
			new yytokenaction(217, YYAT_SHIFT, 13),
			new yytokenaction(217, YYAT_SHIFT, 14),
			new yytokenaction(217, YYAT_SHIFT, 15),
			new yytokenaction(217, YYAT_SHIFT, 16),
			new yytokenaction(217, YYAT_SHIFT, 17),
			new yytokenaction(185, YYAT_SHIFT, 1),
			new yytokenaction(200, YYAT_SHIFT, 175),
			new yytokenaction(75, YYAT_ERROR, 0),
			new yytokenaction(185, YYAT_SHIFT, 2),
			new yytokenaction(75, YYAT_ERROR, 0),
			new yytokenaction(185, YYAT_SHIFT, 3),
			new yytokenaction(217, YYAT_SHIFT, 18),
			new yytokenaction(198, YYAT_SHIFT, 201),
			new yytokenaction(192, YYAT_SHIFT, 199),
			new yytokenaction(217, YYAT_SHIFT, 19),
			new yytokenaction(217, YYAT_SHIFT, 20),
			new yytokenaction(217, YYAT_SHIFT, 21),
			new yytokenaction(217, YYAT_SHIFT, 22),
			new yytokenaction(217, YYAT_SHIFT, 23),
			new yytokenaction(217, YYAT_SHIFT, 24),
			new yytokenaction(217, YYAT_SHIFT, 25),
			new yytokenaction(217, YYAT_SHIFT, 26),
			new yytokenaction(217, YYAT_SHIFT, 27),
			new yytokenaction(217, YYAT_SHIFT, 28),
			new yytokenaction(217, YYAT_SHIFT, 29),
			new yytokenaction(217, YYAT_SHIFT, 30),
			new yytokenaction(210, YYAT_SHIFT, 6),
			new yytokenaction(130, YYAT_SHIFT, 158),
			new yytokenaction(217, YYAT_SHIFT, 31),
			new yytokenaction(191, YYAT_SHIFT, 198),
			new yytokenaction(130, YYAT_SHIFT, 159),
			new yytokenaction(145, YYAT_SHIFT, 100),
			new yytokenaction(57, YYAT_SHIFT, 100),
			new yytokenaction(145, YYAT_SHIFT, 101),
			new yytokenaction(57, YYAT_SHIFT, 101),
			new yytokenaction(195, YYAT_SHIFT, 4),
			new yytokenaction(190, YYAT_SHIFT, 178),
			new yytokenaction(210, YYAT_SHIFT, 7),
			new yytokenaction(210, YYAT_SHIFT, 8),
			new yytokenaction(210, YYAT_SHIFT, 9),
			new yytokenaction(210, YYAT_SHIFT, 10),
			new yytokenaction(210, YYAT_SHIFT, 11),
			new yytokenaction(210, YYAT_SHIFT, 12),
			new yytokenaction(210, YYAT_SHIFT, 13),
			new yytokenaction(210, YYAT_SHIFT, 14),
			new yytokenaction(210, YYAT_SHIFT, 15),
			new yytokenaction(210, YYAT_SHIFT, 16),
			new yytokenaction(210, YYAT_SHIFT, 17),
			new yytokenaction(145, YYAT_SHIFT, 102),
			new yytokenaction(57, YYAT_SHIFT, 102),
			new yytokenaction(145, YYAT_SHIFT, 103),
			new yytokenaction(57, YYAT_SHIFT, 103),
			new yytokenaction(126, YYAT_SHIFT, 154),
			new yytokenaction(187, YYAT_SHIFT, 195),
			new yytokenaction(210, YYAT_SHIFT, 18),
			new yytokenaction(126, YYAT_SHIFT, 155),
			new yytokenaction(185, YYAT_SHIFT, 4),
			new yytokenaction(210, YYAT_SHIFT, 19),
			new yytokenaction(210, YYAT_SHIFT, 20),
			new yytokenaction(210, YYAT_SHIFT, 21),
			new yytokenaction(210, YYAT_SHIFT, 22),
			new yytokenaction(210, YYAT_SHIFT, 23),
			new yytokenaction(210, YYAT_SHIFT, 24),
			new yytokenaction(210, YYAT_SHIFT, 25),
			new yytokenaction(210, YYAT_SHIFT, 26),
			new yytokenaction(210, YYAT_SHIFT, 27),
			new yytokenaction(210, YYAT_SHIFT, 28),
			new yytokenaction(210, YYAT_SHIFT, 29),
			new yytokenaction(210, YYAT_SHIFT, 30),
			new yytokenaction(218, YYAT_SHIFT, 165),
			new yytokenaction(195, YYAT_SHIFT, 5),
			new yytokenaction(210, YYAT_SHIFT, 31),
			new yytokenaction(218, YYAT_SHIFT, 7),
			new yytokenaction(218, YYAT_SHIFT, 8),
			new yytokenaction(218, YYAT_SHIFT, 9),
			new yytokenaction(218, YYAT_SHIFT, 10),
			new yytokenaction(218, YYAT_SHIFT, 11),
			new yytokenaction(218, YYAT_SHIFT, 12),
			new yytokenaction(218, YYAT_SHIFT, 13),
			new yytokenaction(218, YYAT_SHIFT, 14),
			new yytokenaction(218, YYAT_SHIFT, 15),
			new yytokenaction(218, YYAT_SHIFT, 16),
			new yytokenaction(218, YYAT_SHIFT, 17),
			new yytokenaction(211, YYAT_SHIFT, 89),
			new yytokenaction(211, YYAT_SHIFT, 90),
			new yytokenaction(211, YYAT_SHIFT, 91),
			new yytokenaction(211, YYAT_SHIFT, 92),
			new yytokenaction(211, YYAT_SHIFT, 93),
			new yytokenaction(211, YYAT_SHIFT, 94),
			new yytokenaction(186, YYAT_SHIFT, 194),
			new yytokenaction(75, YYAT_ERROR, 0),
			new yytokenaction(185, YYAT_SHIFT, 5),
			new yytokenaction(182, YYAT_SHIFT, 191),
			new yytokenaction(178, YYAT_SHIFT, 189),
			new yytokenaction(218, YYAT_SHIFT, 21),
			new yytokenaction(218, YYAT_SHIFT, 22),
			new yytokenaction(218, YYAT_SHIFT, 23),
			new yytokenaction(218, YYAT_SHIFT, 24),
			new yytokenaction(218, YYAT_SHIFT, 25),
			new yytokenaction(218, YYAT_SHIFT, 26),
			new yytokenaction(218, YYAT_SHIFT, 27),
			new yytokenaction(218, YYAT_SHIFT, 28),
			new yytokenaction(218, YYAT_SHIFT, 29),
			new yytokenaction(218, YYAT_SHIFT, 30),
			new yytokenaction(176, YYAT_SHIFT, 178),
			new yytokenaction(171, YYAT_SHIFT, 182),
			new yytokenaction(218, YYAT_SHIFT, 31),
			new yytokenaction(214, YYAT_SHIFT, 7),
			new yytokenaction(214, YYAT_SHIFT, 8),
			new yytokenaction(214, YYAT_SHIFT, 9),
			new yytokenaction(214, YYAT_SHIFT, 10),
			new yytokenaction(214, YYAT_SHIFT, 11),
			new yytokenaction(214, YYAT_SHIFT, 12),
			new yytokenaction(214, YYAT_SHIFT, 13),
			new yytokenaction(214, YYAT_SHIFT, 14),
			new yytokenaction(214, YYAT_SHIFT, 15),
			new yytokenaction(214, YYAT_SHIFT, 16),
			new yytokenaction(214, YYAT_SHIFT, 17),
			new yytokenaction(215, YYAT_SHIFT, 7),
			new yytokenaction(215, YYAT_SHIFT, 8),
			new yytokenaction(215, YYAT_SHIFT, 9),
			new yytokenaction(215, YYAT_SHIFT, 10),
			new yytokenaction(215, YYAT_SHIFT, 11),
			new yytokenaction(215, YYAT_SHIFT, 12),
			new yytokenaction(215, YYAT_SHIFT, 13),
			new yytokenaction(215, YYAT_SHIFT, 14),
			new yytokenaction(215, YYAT_SHIFT, 15),
			new yytokenaction(215, YYAT_SHIFT, 16),
			new yytokenaction(215, YYAT_SHIFT, 17),
			new yytokenaction(214, YYAT_SHIFT, 21),
			new yytokenaction(214, YYAT_SHIFT, 22),
			new yytokenaction(214, YYAT_SHIFT, 23),
			new yytokenaction(214, YYAT_SHIFT, 24),
			new yytokenaction(214, YYAT_SHIFT, 25),
			new yytokenaction(214, YYAT_SHIFT, 26),
			new yytokenaction(214, YYAT_SHIFT, 27),
			new yytokenaction(214, YYAT_SHIFT, 28),
			new yytokenaction(214, YYAT_SHIFT, 29),
			new yytokenaction(214, YYAT_SHIFT, 30),
			new yytokenaction(96, YYAT_SHIFT, 1),
			new yytokenaction(86, YYAT_SHIFT, 1),
			new yytokenaction(214, YYAT_SHIFT, 31),
			new yytokenaction(96, YYAT_SHIFT, 2),
			new yytokenaction(86, YYAT_SHIFT, 2),
			new yytokenaction(96, YYAT_SHIFT, 3),
			new yytokenaction(86, YYAT_SHIFT, 3),
			new yytokenaction(170, YYAT_SHIFT, 181),
			new yytokenaction(169, YYAT_SHIFT, 180),
			new yytokenaction(215, YYAT_SHIFT, 29),
			new yytokenaction(215, YYAT_SHIFT, 30),
			new yytokenaction(168, YYAT_SHIFT, 178),
			new yytokenaction(167, YYAT_SHIFT, 177),
			new yytokenaction(215, YYAT_SHIFT, 31),
			new yytokenaction(209, YYAT_SHIFT, 7),
			new yytokenaction(209, YYAT_SHIFT, 8),
			new yytokenaction(209, YYAT_SHIFT, 9),
			new yytokenaction(209, YYAT_SHIFT, 10),
			new yytokenaction(209, YYAT_SHIFT, 11),
			new yytokenaction(209, YYAT_SHIFT, 12),
			new yytokenaction(209, YYAT_SHIFT, 13),
			new yytokenaction(209, YYAT_SHIFT, 14),
			new yytokenaction(209, YYAT_SHIFT, 15),
			new yytokenaction(209, YYAT_SHIFT, 16),
			new yytokenaction(209, YYAT_SHIFT, 17),
			new yytokenaction(208, YYAT_SHIFT, 7),
			new yytokenaction(208, YYAT_SHIFT, 8),
			new yytokenaction(208, YYAT_SHIFT, 9),
			new yytokenaction(208, YYAT_SHIFT, 10),
			new yytokenaction(208, YYAT_SHIFT, 11),
			new yytokenaction(208, YYAT_SHIFT, 12),
			new yytokenaction(208, YYAT_SHIFT, 13),
			new yytokenaction(208, YYAT_SHIFT, 14),
			new yytokenaction(208, YYAT_SHIFT, 15),
			new yytokenaction(208, YYAT_SHIFT, 16),
			new yytokenaction(208, YYAT_SHIFT, 17),
			new yytokenaction(166, YYAT_SHIFT, 175),
			new yytokenaction(37, YYAT_SHIFT, 1),
			new yytokenaction(28, YYAT_SHIFT, 1),
			new yytokenaction(165, YYAT_SHIFT, 174),
			new yytokenaction(37, YYAT_SHIFT, 2),
			new yytokenaction(28, YYAT_SHIFT, 2),
			new yytokenaction(37, YYAT_SHIFT, 3),
			new yytokenaction(28, YYAT_SHIFT, 3),
			new yytokenaction(209, YYAT_SHIFT, 29),
			new yytokenaction(209, YYAT_SHIFT, 30),
			new yytokenaction(157, YYAT_SHIFT, 128),
			new yytokenaction(156, YYAT_SHIFT, 171),
			new yytokenaction(209, YYAT_SHIFT, 31),
			new yytokenaction(155, YYAT_SHIFT, 170),
			new yytokenaction(149, YYAT_SHIFT, 164),
			new yytokenaction(96, YYAT_SHIFT, 4),
			new yytokenaction(86, YYAT_SHIFT, 4),
			new yytokenaction(139, YYAT_SHIFT, 99),
			new yytokenaction(138, YYAT_SHIFT, 96),
			new yytokenaction(208, YYAT_SHIFT, 29),
			new yytokenaction(208, YYAT_SHIFT, 30),
			new yytokenaction(133, YYAT_SHIFT, 88),
			new yytokenaction(132, YYAT_SHIFT, 86),
			new yytokenaction(208, YYAT_SHIFT, 31),
			new yytokenaction(207, YYAT_SHIFT, 7),
			new yytokenaction(207, YYAT_SHIFT, 8),
			new yytokenaction(207, YYAT_SHIFT, 9),
			new yytokenaction(207, YYAT_SHIFT, 10),
			new yytokenaction(207, YYAT_SHIFT, 11),
			new yytokenaction(207, YYAT_SHIFT, 12),
			new yytokenaction(207, YYAT_SHIFT, 13),
			new yytokenaction(207, YYAT_SHIFT, 14),
			new yytokenaction(207, YYAT_SHIFT, 15),
			new yytokenaction(207, YYAT_SHIFT, 16),
			new yytokenaction(207, YYAT_SHIFT, 17),
			new yytokenaction(4, YYAT_SHIFT, 1),
			new yytokenaction(142, YYAT_SHIFT, 114),
			new yytokenaction(131, YYAT_SHIFT, 160),
			new yytokenaction(4, YYAT_SHIFT, 2),
			new yytokenaction(1, YYAT_SHIFT, 1),
			new yytokenaction(4, YYAT_SHIFT, 3),
			new yytokenaction(142, YYAT_SHIFT, 115),
			new yytokenaction(1, YYAT_SHIFT, 2),
			new yytokenaction(128, YYAT_SHIFT, 157),
			new yytokenaction(1, YYAT_SHIFT, 3),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(142, YYAT_SHIFT, 116),
			new yytokenaction(127, YYAT_SHIFT, 156),
			new yytokenaction(125, YYAT_SHIFT, 117),
			new yytokenaction(124, YYAT_SHIFT, 153),
			new yytokenaction(96, YYAT_SHIFT, 5),
			new yytokenaction(86, YYAT_SHIFT, 5),
			new yytokenaction(37, YYAT_SHIFT, 4),
			new yytokenaction(28, YYAT_SHIFT, 4),
			new yytokenaction(207, YYAT_SHIFT, 29),
			new yytokenaction(207, YYAT_SHIFT, 30),
			new yytokenaction(123, YYAT_SHIFT, 152),
			new yytokenaction(122, YYAT_SHIFT, 151),
			new yytokenaction(207, YYAT_SHIFT, 31),
			new yytokenaction(216, YYAT_SHIFT, 104),
			new yytokenaction(216, YYAT_SHIFT, 105),
			new yytokenaction(216, YYAT_SHIFT, 106),
			new yytokenaction(216, YYAT_SHIFT, 107),
			new yytokenaction(216, YYAT_SHIFT, 108),
			new yytokenaction(212, YYAT_SHIFT, 104),
			new yytokenaction(212, YYAT_SHIFT, 105),
			new yytokenaction(212, YYAT_SHIFT, 106),
			new yytokenaction(212, YYAT_SHIFT, 107),
			new yytokenaction(212, YYAT_SHIFT, 108),
			new yytokenaction(118, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(184, YYAT_ERROR, 0),
			new yytokenaction(111, YYAT_SHIFT, 144),
			new yytokenaction(109, YYAT_SHIFT, 110),
			new yytokenaction(79, YYAT_SHIFT, 128),
			new yytokenaction(174, YYAT_SHIFT, 6),
			new yytokenaction(78, YYAT_SHIFT, 127),
			new yytokenaction(77, YYAT_SHIFT, 126),
			new yytokenaction(71, YYAT_SHIFT, 121),
			new yytokenaction(68, YYAT_SHIFT, 120),
			new yytokenaction(4, YYAT_SHIFT, 4),
			new yytokenaction(37, YYAT_SHIFT, 5),
			new yytokenaction(28, YYAT_SHIFT, 5),
			new yytokenaction(174, YYAT_ERROR, 0),
			new yytokenaction(1, YYAT_SHIFT, 4),
			new yytokenaction(61, YYAT_SHIFT, 117),
			new yytokenaction(141, YYAT_SHIFT, 114),
			new yytokenaction(58, YYAT_SHIFT, 114),
			new yytokenaction(54, YYAT_SHIFT, 99),
			new yytokenaction(53, YYAT_SHIFT, 98),
			new yytokenaction(52, YYAT_SHIFT, 96),
			new yytokenaction(141, YYAT_SHIFT, 115),
			new yytokenaction(58, YYAT_SHIFT, 115),
			new yytokenaction(216, YYAT_SHIFT, 109),
			new yytokenaction(216, YYAT_REDUCE, 50),
			new yytokenaction(216, YYAT_SHIFT, 110),
			new yytokenaction(141, YYAT_SHIFT, 116),
			new yytokenaction(58, YYAT_SHIFT, 116),
			new yytokenaction(212, YYAT_SHIFT, 109),
			new yytokenaction(212, YYAT_REDUCE, 50),
			new yytokenaction(212, YYAT_SHIFT, 110),
			new yytokenaction(40, YYAT_SHIFT, 88),
			new yytokenaction(39, YYAT_SHIFT, 86),
			new yytokenaction(174, YYAT_SHIFT, 18),
			new yytokenaction(38, YYAT_SHIFT, 85),
			new yytokenaction(32, YYAT_ACCEPT, 0),
			new yytokenaction(174, YYAT_SHIFT, 19),
			new yytokenaction(174, YYAT_SHIFT, 20),
			new yytokenaction(30, YYAT_SHIFT, 82),
			new yytokenaction(29, YYAT_SHIFT, 81),
			new yytokenaction(24, YYAT_SHIFT, 79),
			new yytokenaction(23, YYAT_SHIFT, 78),
			new yytokenaction(22, YYAT_SHIFT, 77),
			new yytokenaction(-1, YYAT_ERROR, 0),
			new yytokenaction(-1, YYAT_ERROR, 0),
			new yytokenaction(4, YYAT_SHIFT, 5),
			new yytokenaction(-1, YYAT_ERROR, 0),
			new yytokenaction(-1, YYAT_ERROR, 0),
			new yytokenaction(-1, YYAT_ERROR, 0),
			new yytokenaction(1, YYAT_SHIFT, 5)
		};
		yytokenaction = tokenaction;

		final yystateaction stateaction[] = {
			new yystateaction(0, false, YYAT_DEFAULT, 174),
			new yystateaction(191, true, YYAT_DEFAULT, 207),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(187, true, YYAT_DEFAULT, 208),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_REDUCE, 9),
			new yystateaction(0, false, YYAT_REDUCE, 96),
			new yystateaction(0, false, YYAT_REDUCE, 76),
			new yystateaction(0, false, YYAT_REDUCE, 78),
			new yystateaction(0, false, YYAT_REDUCE, 77),
			new yystateaction(0, false, YYAT_REDUCE, 79),
			new yystateaction(0, false, YYAT_REDUCE, 80),
			new yystateaction(0, false, YYAT_REDUCE, 81),
			new yystateaction(0, false, YYAT_REDUCE, 82),
			new yystateaction(0, false, YYAT_REDUCE, 83),
			new yystateaction(0, false, YYAT_REDUCE, 84),
			new yystateaction(0, false, YYAT_REDUCE, 85),
			new yystateaction(0, false, YYAT_REDUCE, 106),
			new yystateaction(0, false, YYAT_REDUCE, 112),
			new yystateaction(0, false, YYAT_REDUCE, 114),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(270, true, YYAT_ERROR, 0),
			new yystateaction(269, true, YYAT_ERROR, 0),
			new yystateaction(-65239, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 17),
			new yystateaction(0, false, YYAT_REDUCE, 18),
			new yystateaction(0, false, YYAT_REDUCE, 19),
			new yystateaction(154, true, YYAT_DEFAULT, 209),
			new yystateaction(267, true, YYAT_ERROR, 0),
			new yystateaction(266, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(303, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 8),
			new yystateaction(0, false, YYAT_REDUCE, 103),
			new yystateaction(0, false, YYAT_REDUCE, 104),
			new yystateaction(0, false, YYAT_REDUCE, 105),
			new yystateaction(153, true, YYAT_DEFAULT, 210),
			new yystateaction(-65242, true, YYAT_ERROR, 0),
			new yystateaction(241, true, YYAT_REDUCE, 13),
			new yystateaction(238, true, YYAT_DEFAULT, 211),
			new yystateaction(0, false, YYAT_REDUCE, 15),
			new yystateaction(0, false, YYAT_REDUCE, 16),
			new yystateaction(0, false, YYAT_REDUCE, 22),
			new yystateaction(0, false, YYAT_REDUCE, 70),
			new yystateaction(0, false, YYAT_REDUCE, 71),
			new yystateaction(0, false, YYAT_REDUCE, 23),
			new yystateaction(0, false, YYAT_REDUCE, 24),
			new yystateaction(0, false, YYAT_REDUCE, 20),
			new yystateaction(0, false, YYAT_REDUCE, 21),
			new yystateaction(0, false, YYAT_REDUCE, 14),
			new yystateaction(0, false, YYAT_REDUCE, 25),
			new yystateaction(244, true, YYAT_REDUCE, 29),
			new yystateaction(-65250, true, YYAT_REDUCE, 30),
			new yystateaction(-65252, true, YYAT_REDUCE, 31),
			new yystateaction(0, false, YYAT_REDUCE, 33),
			new yystateaction(0, false, YYAT_REDUCE, 35),
			new yystateaction(6, true, YYAT_DEFAULT, 212),
			new yystateaction(248, true, YYAT_REDUCE, 51),
			new yystateaction(0, false, YYAT_REDUCE, 54),
			new yystateaction(0, false, YYAT_REDUCE, 58),
			new yystateaction(192, true, YYAT_DEFAULT, 213),
			new yystateaction(0, false, YYAT_REDUCE, 65),
			new yystateaction(0, false, YYAT_REDUCE, 97),
			new yystateaction(0, false, YYAT_REDUCE, 69),
			new yystateaction(0, false, YYAT_REDUCE, 68),
			new yystateaction(0, false, YYAT_REDUCE, 66),
			new yystateaction(0, false, YYAT_REDUCE, 74),
			new yystateaction(236, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 60),
			new yystateaction(0, false, YYAT_REDUCE, 59),
			new yystateaction(183, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 61),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(-19, true, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_REDUCE, 101),
			new yystateaction(-65275, true, YYAT_ERROR, 0),
			new yystateaction(-65276, true, YYAT_ERROR, 0),
			new yystateaction(228, true, YYAT_REDUCE, 99),
			new yystateaction(0, false, YYAT_REDUCE, 100),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_REDUCE, 36),
			new yystateaction(0, false, YYAT_REDUCE, 1),
			new yystateaction(0, false, YYAT_REDUCE, 7),
			new yystateaction(117, true, YYAT_DEFAULT, 214),
			new yystateaction(0, false, YYAT_REDUCE, 10),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_REDUCE, 90),
			new yystateaction(0, false, YYAT_REDUCE, 91),
			new yystateaction(0, false, YYAT_REDUCE, 92),
			new yystateaction(0, false, YYAT_REDUCE, 93),
			new yystateaction(0, false, YYAT_REDUCE, 94),
			new yystateaction(0, false, YYAT_REDUCE, 95),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(116, true, YYAT_DEFAULT, 215),
			new yystateaction(0, false, YYAT_REDUCE, 26),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_REDUCE, 40),
			new yystateaction(0, false, YYAT_REDUCE, 41),
			new yystateaction(0, false, YYAT_REDUCE, 42),
			new yystateaction(0, false, YYAT_REDUCE, 45),
			new yystateaction(0, false, YYAT_REDUCE, 46),
			new yystateaction(0, false, YYAT_REDUCE, 43),
			new yystateaction(0, false, YYAT_REDUCE, 44),
			new yystateaction(-65310, true, YYAT_REDUCE, 50),
			new yystateaction(0, false, YYAT_REDUCE, 49),
			new yystateaction(-65310, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_REDUCE, 37),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_DEFAULT, 118),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(-65320, true, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_REDUCE, 62),
			new yystateaction(0, false, YYAT_REDUCE, 72),
			new yystateaction(0, false, YYAT_REDUCE, 73),
			new yystateaction(191, true, YYAT_ERROR, 0),
			new yystateaction(190, true, YYAT_ERROR, 0),
			new yystateaction(-65339, true, YYAT_REDUCE, 66),
			new yystateaction(149, true, YYAT_ERROR, 0),
			new yystateaction(28, true, YYAT_ERROR, 0),
			new yystateaction(195, true, YYAT_ERROR, 0),
			new yystateaction(-65312, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 102),
			new yystateaction(3, true, YYAT_ERROR, 0),
			new yystateaction(188, true, YYAT_ERROR, 0),
			new yystateaction(155, true, YYAT_REDUCE, 13),
			new yystateaction(152, true, YYAT_REDUCE, 66),
			new yystateaction(0, false, YYAT_REDUCE, 87),
			new yystateaction(0, false, YYAT_REDUCE, 86),
			new yystateaction(0, false, YYAT_REDUCE, 88),
			new yystateaction(0, false, YYAT_REDUCE, 89),
			new yystateaction(166, true, YYAT_REDUCE, 29),
			new yystateaction(-65329, true, YYAT_REDUCE, 32),
			new yystateaction(0, false, YYAT_REDUCE, 34),
			new yystateaction(247, true, YYAT_REDUCE, 52),
			new yystateaction(191, true, YYAT_REDUCE, 53),
			new yystateaction(0, false, YYAT_REDUCE, 47),
			new yystateaction(0, false, YYAT_REDUCE, 48),
			new yystateaction(5, true, YYAT_DEFAULT, 216),
			new yystateaction(0, false, YYAT_REDUCE, 57),
			new yystateaction(0, false, YYAT_REDUCE, 55),
			new yystateaction(0, false, YYAT_REDUCE, 56),
			new yystateaction(113, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 63),
			new yystateaction(0, false, YYAT_DEFAULT, 195),
			new yystateaction(0, false, YYAT_DEFAULT, 195),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_REDUCE, 120),
			new yystateaction(-65346, true, YYAT_ERROR, 0),
			new yystateaction(-65347, true, YYAT_ERROR, 0),
			new yystateaction(158, true, YYAT_REDUCE, 99),
			new yystateaction(0, false, YYAT_REDUCE, 116),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(0, false, YYAT_REDUCE, 119),
			new yystateaction(0, false, YYAT_REDUCE, 11),
			new yystateaction(0, false, YYAT_REDUCE, 27),
			new yystateaction(0, false, YYAT_REDUCE, 38),
			new yystateaction(0, false, YYAT_REDUCE, 67),
			new yystateaction(-65350, true, YYAT_ERROR, 0),
			new yystateaction(-65374, true, YYAT_REDUCE, 109),
			new yystateaction(-65376, true, YYAT_ERROR, 0),
			new yystateaction(-65398, true, YYAT_REDUCE, 111),
			new yystateaction(106, true, YYAT_ERROR, 0),
			new yystateaction(122, true, YYAT_ERROR, 0),
			new yystateaction(78, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 98),
			new yystateaction(-34, true, YYAT_ERROR, 0),
			new yystateaction(-65263, true, YYAT_DEFAULT, 195),
			new yystateaction(0, false, YYAT_DEFAULT, 184),
			new yystateaction(-65444, true, YYAT_REDUCE, 111),
			new yystateaction(0, false, YYAT_REDUCE, 3),
			new yystateaction(52, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 113),
			new yystateaction(0, false, YYAT_DEFAULT, 195),
			new yystateaction(0, false, YYAT_REDUCE, 121),
			new yystateaction(-65441, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 117),
			new yystateaction(-65307, true, YYAT_DEFAULT, 195),
			new yystateaction(-18, true, YYAT_DEFAULT, 217),
			new yystateaction(-65440, true, YYAT_ERROR, 0),
			new yystateaction(12, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 107),
			new yystateaction(0, false, YYAT_DEFAULT, 195),
			new yystateaction(-65512, true, YYAT_REDUCE, 111),
			new yystateaction(2, true, YYAT_ERROR, 0),
			new yystateaction(-11, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 5),
			new yystateaction(0, false, YYAT_REDUCE, 4),
			new yystateaction(-39, true, YYAT_DEFAULT, 218),
			new yystateaction(0, false, YYAT_REDUCE, 110),
			new yystateaction(0, false, YYAT_REDUCE, 115),
			new yystateaction(-65521, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 118),
			new yystateaction(-65543, true, YYAT_REDUCE, 109),
			new yystateaction(-39, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 108),
			new yystateaction(0, false, YYAT_REDUCE, 122),
			new yystateaction(-65542, true, YYAT_ERROR, 0),
			new yystateaction(-33, true, YYAT_ERROR, 0),
			new yystateaction(0, false, YYAT_REDUCE, 123),
			new yystateaction(-65331, true, YYAT_REDUCE, 75),
			new yystateaction(-65366, true, YYAT_REDUCE, 75),
			new yystateaction(-65377, true, YYAT_REDUCE, 75),
			new yystateaction(-65493, true, YYAT_REDUCE, 2),
			new yystateaction(-65458, true, YYAT_REDUCE, 66),
			new yystateaction(-65283, true, YYAT_REDUCE, 39),
			new yystateaction(-65579, true, YYAT_REDUCE, 64),
			new yystateaction(-65423, true, YYAT_REDUCE, 12),
			new yystateaction(-65412, true, YYAT_REDUCE, 28),
			new yystateaction(-65288, true, YYAT_REDUCE, 39),
			new yystateaction(-65536, true, YYAT_REDUCE, 6),
			new yystateaction(-65458, true, YYAT_ERROR, 0)
		};
		yystateaction = stateaction;

		final yynontermgoto nontermgoto[] = {
			new yynontermgoto(195, 200),
			new yynontermgoto(75, -1),
			new yynontermgoto(75, -1),
			new yynontermgoto(195, 167),
			new yynontermgoto(75, 125),
			new yynontermgoto(195, 39),
			new yynontermgoto(195, 50),
			new yynontermgoto(195, 51),
			new yynontermgoto(200, 202),
			new yynontermgoto(195, 52),
			new yynontermgoto(195, 53),
			new yynontermgoto(195, 54),
			new yynontermgoto(195, 55),
			new yynontermgoto(195, 56),
			new yynontermgoto(75, 124),
			new yynontermgoto(112, 145),
			new yynontermgoto(112, 58),
			new yynontermgoto(195, 57),
			new yynontermgoto(195, 58),
			new yynontermgoto(195, 59),
			new yynontermgoto(195, 60),
			new yynontermgoto(28, 67),
			new yynontermgoto(195, 61),
			new yynontermgoto(195, 63),
			new yynontermgoto(195, 62),
			new yynontermgoto(195, 64),
			new yynontermgoto(86, -1),
			new yynontermgoto(195, 65),
			new yynontermgoto(195, 41),
			new yynontermgoto(86, -1),
			new yynontermgoto(195, 42),
			new yynontermgoto(86, 132),
			new yynontermgoto(195, 40),
			new yynontermgoto(88, 136),
			new yynontermgoto(195, 48),
			new yynontermgoto(195, 43),
			new yynontermgoto(195, 49),
			new yynontermgoto(184, -1),
			new yynontermgoto(184, -1),
			new yynontermgoto(184, -1),
			new yynontermgoto(28, 80),
			new yynontermgoto(184, 192),
			new yynontermgoto(37, 84),
			new yynontermgoto(190, 197),
			new yynontermgoto(37, -1),
			new yynontermgoto(37, 37),
			new yynontermgoto(195, 44),
			new yynontermgoto(195, 45),
			new yynontermgoto(195, 46),
			new yynontermgoto(195, 47),
			new yynontermgoto(185, -1),
			new yynontermgoto(185, 193),
			new yynontermgoto(185, 185),
			new yynontermgoto(185, 38),
			new yynontermgoto(88, 134),
			new yynontermgoto(88, 135),
			new yynontermgoto(99, 140),
			new yynontermgoto(99, 56),
			new yynontermgoto(88, 133),
			new yynontermgoto(189, 196),
			new yynontermgoto(184, -1),
			new yynontermgoto(99, 57),
			new yynontermgoto(184, -1),
			new yynontermgoto(153, 169),
			new yynontermgoto(184, 66),
			new yynontermgoto(153, 52),
			new yynontermgoto(184, -1),
			new yynontermgoto(184, -1),
			new yynontermgoto(184, -1),
			new yynontermgoto(118, -1),
			new yynontermgoto(118, -1),
			new yynontermgoto(118, -1),
			new yynontermgoto(118, -1),
			new yynontermgoto(118, -1),
			new yynontermgoto(145, 163),
			new yynontermgoto(145, 112),
			new yynontermgoto(145, 111),
			new yynontermgoto(118, -1),
			new yynontermgoto(118, -1),
			new yynontermgoto(118, 150),
			new yynontermgoto(184, -1),
			new yynontermgoto(184, -1),
			new yynontermgoto(101, 142),
			new yynontermgoto(101, 59),
			new yynontermgoto(98, 139),
			new yynontermgoto(98, 55),
			new yynontermgoto(180, 190),
			new yynontermgoto(185, 33),
			new yynontermgoto(185, 34),
			new yynontermgoto(176, 188),
			new yynontermgoto(175, 187),
			new yynontermgoto(174, 186),
			new yynontermgoto(185, 35),
			new yynontermgoto(168, 179),
			new yynontermgoto(185, 36),
			new yynontermgoto(166, 176),
			new yynontermgoto(159, 173),
			new yynontermgoto(157, 172),
			new yynontermgoto(152, 168),
			new yynontermgoto(151, 166),
			new yynontermgoto(138, 162),
			new yynontermgoto(132, 161),
			new yynontermgoto(117, 149),
			new yynontermgoto(116, 148),
			new yynontermgoto(115, 147),
			new yynontermgoto(114, 146),
			new yynontermgoto(109, 143),
			new yynontermgoto(100, 141),
			new yynontermgoto(96, 138),
			new yynontermgoto(95, 137),
			new yynontermgoto(82, 131),
			new yynontermgoto(81, 130),
			new yynontermgoto(79, 129),
			new yynontermgoto(74, 123),
			new yynontermgoto(73, 122),
			new yynontermgoto(61, 119),
			new yynontermgoto(57, 113),
			new yynontermgoto(52, 97),
			new yynontermgoto(40, 95),
			new yynontermgoto(39, 87),
			new yynontermgoto(31, 83),
			new yynontermgoto(21, 76),
			new yynontermgoto(20, 75),
			new yynontermgoto(19, 74),
			new yynontermgoto(18, 73),
			new yynontermgoto(5, 72),
			new yynontermgoto(4, 71),
			new yynontermgoto(3, 70),
			new yynontermgoto(2, 69),
			new yynontermgoto(1, 68),
			new yynontermgoto(0, 32)
		};
		yynontermgoto = nontermgoto;

		final yystategoto stategoto[] = {
			new yystategoto(129, 37),
			new yystategoto(101, 28),
			new yystategoto(107, 118),
			new yystategoto(106, 118),
			new yystategoto(98, 28),
			new yystategoto(104, 118),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(83, -1),
			new yystategoto(78, -1),
			new yystategoto(75, -1),
			new yystategoto(112, 153),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(12, 153),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(106, 99),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(41, 185),
			new yystategoto(0, -1),
			new yystategoto(113, -1),
			new yystategoto(85, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(107, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(100, 145),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(92, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(103, 184),
			new yystategoto(102, 184),
			new yystategoto(-20, 118),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(77, -1),
			new yystategoto(0, -1),
			new yystategoto(100, 184),
			new yystategoto(101, 153),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(24, 195),
			new yystategoto(0, -1),
			new yystategoto(24, 153),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(100, 153),
			new yystategoto(97, 184),
			new yystategoto(0, -1),
			new yystategoto(71, 99),
			new yystategoto(42, 112),
			new yystategoto(87, 101),
			new yystategoto(62, 118),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(88, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(-4, 101),
			new yystategoto(0, -1),
			new yystategoto(84, 118),
			new yystategoto(83, 118),
			new yystategoto(82, 118),
			new yystategoto(93, 153),
			new yystategoto(58, 184),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(95, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(90, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(58, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(97, 195),
			new yystategoto(96, 195),
			new yystategoto(54, 184),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(62, -1),
			new yystategoto(0, -1),
			new yystategoto(85, 184),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(53, -1),
			new yystategoto(0, -1),
			new yystategoto(50, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(88, 185),
			new yystategoto(79, 184),
			new yystategoto(46, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(84, 195),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(30, 86),
			new yystategoto(48, 195),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(57, 195),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(-2, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(-34, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1),
			new yystategoto(0, -1)
		};
		yystategoto = stategoto;

		yydestructorref = null;

		yytokendestref = null;

		yytokendestbaseref = null;
	}
// line 859 ".\\SimPyParser.y"


/////////////////////////////////////////////////////////////////////////////
// programs section

	public void lexerError() {
		execErr = true;
		new SimPyExec(null, main, this);
	}

	public void execError() {
		execErr = true;
	}

	public SimPyParser(Py main) {
		yytables();
		this.main = main;
	}
}
