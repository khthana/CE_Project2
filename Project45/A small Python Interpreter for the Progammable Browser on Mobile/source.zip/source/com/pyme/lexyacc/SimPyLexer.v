#############################################################################
#                     U N R E G I S T E R E D   C O P Y
# 
# You are on day 1 of your 30 day trial period.
# 
# This file was produced by an UNREGISTERED COPY of Parser Generator. It is
# for evaluation purposes only. If you continue to use Parser Generator 30
# days after installation then you are required to purchase a license. For
# more information see the online help or go to the Bumble-Bee Software
# homepage at:
# 
# http://www.bumblebeesoftware.com
# 
# This notice must remain present in the file. It cannot be removed.
#############################################################################

#############################################################################
# SimPyLexer.v
# Lex verbose file generated from SimPyLexer.l.
# 
# Date: 03/15/03
# Time: 10:38:29
# 
# ALex Version: 1.98 (Beta Release)
#############################################################################


#############################################################################
# Expressions
#############################################################################

    1  "=="

    2  ">="

    3  "<="

    4  "<>"

    5  "!="

    6  "<"

    7  ">"

    8  "or"

    9  "and"

   10  "+="

   11  "-="

   12  "*="

   13  "/="

   14  "**="

   15  "%="

   16  "**"

   17  "="

   18  "+"

   19  "-"

   20  "~"

   21  "*"

   22  "/"

   23  "%"

   24  ";"

   25  ":"

   26  "("

   27  ")"

   28  "["

   29  "]"

   30  ","

   31  "is"

   32  "in"

   33  "not"

   34  "if"

   35  "else"

   36  "elif"

   37  "while"

   38  "for"

   39  "break"

   40  "continue"

   41  "pass"

   42  "return"

   43  "print"

   44  "del"

   45  "range"

   46  "len"

   47  "openURL"

   48  "sendMail"

   49  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)"sec"

   50  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)"min"

   51  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)"hr"

   52  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)"day"

   53  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)"mt"

   54  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)"yr"

   55  (([a-z]|[A-Z])|"_")(([a-z]|[A-Z])|[0-9]|"_")*

   56  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)[lL]

   57  ([1-9][0-9]*|0|0[0-7]+|0[xX]([0-9]|[a-f]|[A-F])+)

   58  \'([^\\\'\n]|"\\"[\40-\176])*\'|\"([^\\\"\n]|"\\"[\40-\176])*\"

   59  "["([0-1]?[0-9]|"2"[0-3])":"[0-5]?[0-9]":"[0-5]?[0-9]"|"(([0]?[1-9]|[1-2][0-9])"/"[0]?"2/"[0]*[1-9][0-9]*|(([0]?[1-9]|[1-2][0-9])|"30")"/"([0]?[469]|"11")"/"[0]*[1-9][0-9]*|(([0]?[1-9]|[1-2][0-9])|"3"[0-1])"/"([0]?[13578]|"10"|"12")"/"[0]*[1-9][0-9]*)"]"

   60  \n

   61  [ ]+

   62  [ \t]

   63  [^{second}{minute}{hour}{day}{month}{year}{identifier}{longinteger}{integer}{string}{time}]


#############################################################################
# States
#############################################################################

state 1
	INITIAL

	0x0000 - 0x0008 (9)      goto 3
	0x0009                   goto 4
	0x000a                   goto 5
	0x000b - 0x001f (21)     goto 3
	0x0020                   goto 6
	0x0021                   goto 7
	0x0022                   goto 8
	0x0023 - 0x0024 (2)      goto 3
	0x0025                   goto 9
	0x0026                   goto 3
	0x0027                   goto 10
	0x0028                   goto 11
	0x0029                   goto 12
	0x002a                   goto 13
	0x002b                   goto 14
	0x002c                   goto 15
	0x002d                   goto 16
	0x002e                   goto 3
	0x002f                   goto 17
	0x0030                   goto 18
	0x0031 - 0x0039 (9)      goto 19
	0x003a                   goto 20
	0x003b                   goto 21
	0x003c                   goto 22
	0x003d                   goto 23
	0x003e                   goto 24
	0x003f - 0x0040 (2)      goto 3
	0x0041 - 0x005a (26)     goto 25
	0x005b                   goto 26
	0x005c                   goto 3
	0x005d                   goto 27
	0x005e                   goto 3
	0x005f                   goto 25
	0x0060                   goto 3
	0x0061                   goto 28
	0x0062                   goto 29
	0x0063                   goto 30
	0x0064                   goto 31
	0x0065                   goto 32
	0x0066                   goto 33
	0x0067 - 0x0068 (2)      goto 25
	0x0069                   goto 34
	0x006a - 0x006b (2)      goto 25
	0x006c                   goto 35
	0x006d                   goto 25
	0x006e                   goto 36
	0x006f                   goto 37
	0x0070                   goto 38
	0x0071                   goto 25
	0x0072                   goto 39
	0x0073                   goto 40
	0x0074 - 0x0075 (2)      goto 25
	0x0076                   goto 25
	0x0077                   goto 41
	0x0078                   goto 25
	0x0079                   goto 25
	0x007a                   goto 25
	0x007c                   goto 3
	0x007e                   goto 42
	0x007f - 0xffff (65409)  goto 3


state 2
	^INITIAL

	0x0000 - 0x0008 (9)      goto 3
	0x0009                   goto 4
	0x000a                   goto 5
	0x000b - 0x001f (21)     goto 3
	0x0020                   goto 6
	0x0021                   goto 7
	0x0022                   goto 8
	0x0023 - 0x0024 (2)      goto 3
	0x0025                   goto 9
	0x0026                   goto 3
	0x0027                   goto 10
	0x0028                   goto 11
	0x0029                   goto 12
	0x002a                   goto 13
	0x002b                   goto 14
	0x002c                   goto 15
	0x002d                   goto 16
	0x002e                   goto 3
	0x002f                   goto 17
	0x0030                   goto 18
	0x0031 - 0x0039 (9)      goto 19
	0x003a                   goto 20
	0x003b                   goto 21
	0x003c                   goto 22
	0x003d                   goto 23
	0x003e                   goto 24
	0x003f - 0x0040 (2)      goto 3
	0x0041 - 0x005a (26)     goto 25
	0x005b                   goto 26
	0x005c                   goto 3
	0x005d                   goto 27
	0x005e                   goto 3
	0x005f                   goto 25
	0x0060                   goto 3
	0x0061                   goto 28
	0x0062                   goto 29
	0x0063                   goto 30
	0x0064                   goto 31
	0x0065                   goto 32
	0x0066                   goto 33
	0x0067 - 0x0068 (2)      goto 25
	0x0069                   goto 34
	0x006a - 0x006b (2)      goto 25
	0x006c                   goto 35
	0x006d                   goto 25
	0x006e                   goto 36
	0x006f                   goto 37
	0x0070                   goto 38
	0x0071                   goto 25
	0x0072                   goto 39
	0x0073                   goto 40
	0x0074 - 0x0075 (2)      goto 25
	0x0076                   goto 25
	0x0077                   goto 41
	0x0078                   goto 25
	0x0079                   goto 25
	0x007a                   goto 25
	0x007c                   goto 3
	0x007e                   goto 42
	0x007f - 0xffff (65409)  goto 3


state 3
	match 63


state 4
	match 62


state 5
	match 60


state 6
	0x0020                   goto 6

	match 61


state 7
	0x003d                   goto 43

	match 63


state 8
	0x0000 - 0x0009 (10)     goto 44
	0x000b - 0x0021 (23)     goto 44
	0x0022                   goto 45
	0x0023 - 0x005b (57)     goto 44
	0x005c                   goto 46
	0x005d - 0xffff (65443)  goto 44

	match 63


state 9
	0x003d                   goto 47

	match 23


state 10
	0x0000 - 0x0009 (10)     goto 48
	0x000b - 0x0026 (28)     goto 48
	0x0027                   goto 45
	0x0028 - 0x005b (52)     goto 48
	0x005c                   goto 49
	0x005d - 0xffff (65443)  goto 48

	match 63


state 11
	match 26


state 12
	match 27


state 13
	0x002a                   goto 50
	0x003d                   goto 51

	match 21


state 14
	0x003d                   goto 52

	match 18


state 15
	match 30


state 16
	0x003d                   goto 53

	match 19


state 17
	0x003d                   goto 54

	match 22


state 18
	0x0030 - 0x0037 (8)      goto 19
	0x004c                   goto 55
	0x0058                   goto 56
	0x0064                   goto 57
	0x0068                   goto 58
	0x006c                   goto 55
	0x006d                   goto 59
	0x0073                   goto 60
	0x0078                   goto 56
	0x0079                   goto 61

	match 57


state 19
	0x0030 - 0x0039 (10)     goto 19
	0x004c                   goto 55
	0x0064                   goto 57
	0x0068                   goto 58
	0x006c                   goto 55
	0x006d                   goto 59
	0x0073                   goto 60
	0x0079                   goto 61

	match 57


state 20
	match 25


state 21
	match 24


state 22
	0x003d                   goto 62
	0x003e                   goto 63

	match 6


state 23
	0x003d                   goto 64

	match 17


state 24
	0x003d                   goto 65

	match 7


state 25
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 55


state 26
	0x0030 - 0x0031 (2)      goto 66
	0x0032                   goto 66
	0x0033 - 0x0039 (7)      goto 67

	match 28


state 27
	match 29


state 28
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 68
	0x006f - 0x007a (12)     goto 25

	match 55


state 29
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0071 (17)     goto 25
	0x0072                   goto 69
	0x0073 - 0x007a (8)      goto 25

	match 55


state 30
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006e (14)     goto 25
	0x006f                   goto 70
	0x0070 - 0x007a (11)     goto 25

	match 55


state 31
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 71
	0x0066 - 0x007a (21)     goto 25

	match 55


state 32
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006b (11)     goto 25
	0x006c                   goto 72
	0x006d - 0x007a (14)     goto 25

	match 55


state 33
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006e (14)     goto 25
	0x006f                   goto 73
	0x0070 - 0x007a (11)     goto 25

	match 55


state 34
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0065 (5)      goto 25
	0x0066                   goto 74
	0x0067 - 0x006d (7)      goto 25
	0x006e                   goto 75
	0x006f - 0x0072 (4)      goto 25
	0x0073                   goto 76
	0x0074 - 0x007a (7)      goto 25

	match 55


state 35
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 77
	0x0066 - 0x007a (21)     goto 25

	match 55


state 36
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006e (14)     goto 25
	0x006f                   goto 78
	0x0070 - 0x007a (11)     goto 25

	match 55


state 37
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006f (15)     goto 25
	0x0070                   goto 79
	0x0071                   goto 25
	0x0072                   goto 80
	0x0073 - 0x007a (8)      goto 25

	match 55


state 38
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061                   goto 81
	0x0062 - 0x0071 (16)     goto 25
	0x0072                   goto 82
	0x0073 - 0x007a (8)      goto 25

	match 55


state 39
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061                   goto 83
	0x0062 - 0x0064 (3)      goto 25
	0x0065                   goto 84
	0x0066 - 0x007a (21)     goto 25

	match 55


state 40
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 85
	0x0066 - 0x007a (21)     goto 25

	match 55


state 41
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0067 (7)      goto 25
	0x0068                   goto 86
	0x0069 - 0x007a (18)     goto 25

	match 55


state 42
	match 20


state 43
	match 5


state 44
	0x0000 - 0x0009 (10)     goto 44
	0x000b - 0x0021 (23)     goto 44
	0x0022                   goto 45
	0x0023 - 0x005b (57)     goto 44
	0x005c                   goto 46
	0x005d - 0xffff (65443)  goto 44


state 45
	match 58


state 46
	0x0020                   goto 44
	0x0030 - 0x007e (79)     goto 44


state 47
	match 15


state 48
	0x0000 - 0x0009 (10)     goto 48
	0x000b - 0x0026 (28)     goto 48
	0x0027                   goto 45
	0x0028 - 0x005b (52)     goto 48
	0x005c                   goto 49
	0x005d - 0xffff (65443)  goto 48


state 49
	0x0020                   goto 48
	0x0030 - 0x007e (79)     goto 48


state 50
	0x003d                   goto 87

	match 16


state 51
	match 12


state 52
	match 10


state 53
	match 11


state 54
	match 13


state 55
	match 56


state 56
	0x0030 - 0x0039 (10)     goto 88
	0x0041 - 0x0046 (6)      goto 88
	0x0061 - 0x0066 (6)      goto 88


state 57
	0x0061                   goto 89


state 58
	0x0072                   goto 90


state 59
	0x0069                   goto 91
	0x0074                   goto 92


state 60
	0x0065                   goto 93


state 61
	0x0072                   goto 94


state 62
	match 3


state 63
	match 4


state 64
	match 1


state 65
	match 2


state 66
	0x0030 - 0x0039 (10)     goto 67
	0x003a                   goto 95


state 67
	0x003a                   goto 95


state 68
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0063 (3)      goto 25
	0x0064                   goto 96
	0x0065 - 0x007a (22)     goto 25

	match 55


state 69
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 97
	0x0066 - 0x007a (21)     goto 25

	match 55


state 70
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 98
	0x006f - 0x007a (12)     goto 25

	match 55


state 71
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006b (11)     goto 25
	0x006c                   goto 99
	0x006d - 0x007a (14)     goto 25

	match 55


state 72
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0068 (8)      goto 25
	0x0069                   goto 100
	0x006a - 0x0072 (9)      goto 25
	0x0073                   goto 101
	0x0074 - 0x007a (7)      goto 25

	match 55


state 73
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0071 (17)     goto 25
	0x0072                   goto 102
	0x0073 - 0x007a (8)      goto 25

	match 55


state 74
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 34


state 75
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 32


state 76
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 31


state 77
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 103
	0x006f - 0x007a (12)     goto 25

	match 55


state 78
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0073 (19)     goto 25
	0x0074                   goto 104
	0x0075 - 0x007a (6)      goto 25

	match 55


state 79
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 105
	0x0066 - 0x007a (21)     goto 25

	match 55


state 80
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 8


state 81
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0072 (18)     goto 25
	0x0073                   goto 106
	0x0074 - 0x007a (7)      goto 25

	match 55


state 82
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0068 (8)      goto 25
	0x0069                   goto 107
	0x006a - 0x007a (17)     goto 25

	match 55


state 83
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 108
	0x006f - 0x007a (12)     goto 25

	match 55


state 84
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0073 (19)     goto 25
	0x0074                   goto 109
	0x0075 - 0x007a (6)      goto 25

	match 55


state 85
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 110
	0x006f - 0x007a (12)     goto 25

	match 55


state 86
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0068 (8)      goto 25
	0x0069                   goto 111
	0x006a - 0x007a (17)     goto 25

	match 55


state 87
	match 14


state 88
	0x0030 - 0x0039 (10)     goto 88
	0x0041 - 0x0046 (6)      goto 88
	0x004c                   goto 55
	0x0061 - 0x0063 (3)      goto 88
	0x0064                   goto 112
	0x0065 - 0x0066 (2)      goto 88
	0x0068                   goto 58
	0x006c                   goto 55
	0x006d                   goto 59
	0x0073                   goto 60
	0x0079                   goto 61

	match 57


state 89
	0x0079                   goto 113


state 90
	match 51


state 91
	0x006e                   goto 114


state 92
	match 53


state 93
	0x0063                   goto 115


state 94
	match 54


state 95
	0x0030 - 0x0035 (6)      goto 116
	0x0036 - 0x0039 (4)      goto 117


state 96
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 9


state 97
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061                   goto 118
	0x0062 - 0x007a (25)     goto 25

	match 55


state 98
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0073 (19)     goto 25
	0x0074                   goto 119
	0x0075 - 0x007a (6)      goto 25

	match 55


state 99
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 44


state 100
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0065 (5)      goto 25
	0x0066                   goto 120
	0x0067 - 0x007a (20)     goto 25

	match 55


state 101
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 121
	0x0066 - 0x007a (21)     goto 25

	match 55


state 102
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 38


state 103
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 46


state 104
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 33


state 105
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 122
	0x006f - 0x007a (12)     goto 25

	match 55


state 106
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0072 (18)     goto 25
	0x0073                   goto 123
	0x0074 - 0x007a (7)      goto 25

	match 55


state 107
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 124
	0x006f - 0x007a (12)     goto 25

	match 55


state 108
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0066 (6)      goto 25
	0x0067                   goto 125
	0x0068 - 0x007a (19)     goto 25

	match 55


state 109
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0074 (20)     goto 25
	0x0075                   goto 126
	0x0076 - 0x007a (5)      goto 25

	match 55


state 110
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0063 (3)      goto 25
	0x0064                   goto 127
	0x0065 - 0x007a (22)     goto 25

	match 55


state 111
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006b (11)     goto 25
	0x006c                   goto 128
	0x006d - 0x007a (14)     goto 25

	match 55


state 112
	0x0030 - 0x0039 (10)     goto 88
	0x0041 - 0x0046 (6)      goto 88
	0x004c                   goto 55
	0x0061                   goto 129
	0x0062 - 0x0063 (2)      goto 88
	0x0064                   goto 112
	0x0065 - 0x0066 (2)      goto 88
	0x0068                   goto 58
	0x006c                   goto 55
	0x006d                   goto 59
	0x0073                   goto 60
	0x0079                   goto 61

	match 57


state 113
	match 52


state 114
	match 50


state 115
	match 49


state 116
	0x0030 - 0x0039 (10)     goto 117
	0x003a                   goto 130


state 117
	0x003a                   goto 130


state 118
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006a (10)     goto 25
	0x006b                   goto 131
	0x006c - 0x007a (15)     goto 25

	match 55


state 119
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0068 (8)      goto 25
	0x0069                   goto 132
	0x006a - 0x007a (17)     goto 25

	match 55


state 120
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 36


state 121
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 35


state 122
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x0054 (20)     goto 25
	0x0055                   goto 133
	0x0056 - 0x005a (5)      goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 55


state 123
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 41


state 124
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0073 (19)     goto 25
	0x0074                   goto 134
	0x0075 - 0x007a (6)      goto 25

	match 55


state 125
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 135
	0x0066 - 0x007a (21)     goto 25

	match 55


state 126
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0071 (17)     goto 25
	0x0072                   goto 136
	0x0073 - 0x007a (8)      goto 25

	match 55


state 127
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x004c (12)     goto 25
	0x004d                   goto 137
	0x004e - 0x005a (13)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 55


state 128
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 138
	0x0066 - 0x007a (21)     goto 25

	match 55


state 129
	0x0030 - 0x0039 (10)     goto 88
	0x0041 - 0x0046 (6)      goto 88
	0x004c                   goto 55
	0x0061 - 0x0063 (3)      goto 88
	0x0064                   goto 112
	0x0065 - 0x0066 (2)      goto 88
	0x0068                   goto 58
	0x006c                   goto 55
	0x006d                   goto 59
	0x0073                   goto 60
	0x0079                   goto 139

	match 57


state 130
	0x0030 - 0x0035 (6)      goto 140
	0x0036 - 0x0039 (4)      goto 141


state 131
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 39


state 132
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 142
	0x006f - 0x007a (12)     goto 25

	match 55


state 133
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x0051 (17)     goto 25
	0x0052                   goto 143
	0x0053 - 0x005a (8)      goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 55


state 134
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 43


state 135
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 45


state 136
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006d (13)     goto 25
	0x006e                   goto 144
	0x006f - 0x007a (12)     goto 25

	match 55


state 137
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061                   goto 145
	0x0062 - 0x007a (25)     goto 25

	match 55


state 138
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 37


state 139
	0x0072                   goto 94

	match 52


state 140
	0x0030 - 0x0039 (10)     goto 141
	0x007c                   goto 146


state 141
	0x007c                   goto 146


state 142
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0074 (20)     goto 25
	0x0075                   goto 147
	0x0076 - 0x007a (5)      goto 25

	match 55


state 143
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x004b (11)     goto 25
	0x004c                   goto 148
	0x004d - 0x005a (14)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 55


state 144
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 42


state 145
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0068 (8)      goto 25
	0x0069                   goto 149
	0x006a - 0x007a (17)     goto 25

	match 55


state 146
	0x0030                   goto 150
	0x0031 - 0x0032 (2)      goto 151
	0x0033                   goto 152
	0x0034 - 0x0039 (6)      goto 153


state 147
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x0064 (4)      goto 25
	0x0065                   goto 154
	0x0066 - 0x007a (21)     goto 25

	match 55


state 148
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 47


state 149
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x006b (11)     goto 25
	0x006c                   goto 155
	0x006d - 0x007a (14)     goto 25

	match 55


state 150
	0x0031 - 0x0039 (9)      goto 153


state 151
	0x002f                   goto 156
	0x0030 - 0x0039 (10)     goto 153


state 152
	0x002f                   goto 156
	0x0030                   goto 157
	0x0031                   goto 158


state 153
	0x002f                   goto 156


state 154
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 40


state 155
	0x0030 - 0x0039 (10)     goto 25
	0x0041 - 0x005a (26)     goto 25
	0x005f                   goto 25
	0x0061 - 0x007a (26)     goto 25

	match 48


state 156
	0x0030                   goto 159
	0x0031                   goto 160
	0x0032                   goto 161
	0x0033                   goto 161
	0x0034                   goto 161
	0x0035                   goto 161
	0x0036                   goto 161
	0x0037 - 0x0038 (2)      goto 161
	0x0039                   goto 161


state 157
	0x002f                   goto 162


state 158
	0x002f                   goto 163


state 159
	0x0031                   goto 161
	0x0032                   goto 161
	0x0033                   goto 161
	0x0034                   goto 161
	0x0035                   goto 161
	0x0036                   goto 161
	0x0037 - 0x0038 (2)      goto 161
	0x0039                   goto 161


state 160
	0x002f                   goto 164
	0x0030                   goto 161
	0x0031                   goto 161
	0x0032                   goto 161


state 161
	0x002f                   goto 164


state 162
	0x0030                   goto 165
	0x0031                   goto 160
	0x0033                   goto 161
	0x0034                   goto 161
	0x0035                   goto 161
	0x0036                   goto 161
	0x0037 - 0x0038 (2)      goto 161
	0x0039                   goto 161


state 163
	0x0030                   goto 166
	0x0031                   goto 167
	0x0033                   goto 161
	0x0035                   goto 161
	0x0037 - 0x0038 (2)      goto 161


state 164
	0x0030                   goto 164
	0x0031 - 0x0039 (9)      goto 168


state 165
	0x0031                   goto 161
	0x0033                   goto 161
	0x0034                   goto 161
	0x0035                   goto 161
	0x0036                   goto 161
	0x0037 - 0x0038 (2)      goto 161
	0x0039                   goto 161


state 166
	0x0031                   goto 161
	0x0033                   goto 161
	0x0035                   goto 161
	0x0037 - 0x0038 (2)      goto 161


state 167
	0x002f                   goto 164
	0x0030                   goto 161
	0x0032                   goto 161


state 168
	0x0030 - 0x0039 (10)     goto 168
	0x005d                   goto 169


state 169
	match 59


#############################################################################
# Summary
#############################################################################

1 start state(s)
63 expression(s), 169 state(s)


#############################################################################
# End of File
#############################################################################
