%{
/****************************************************************************
SimPyParser.y
ParserWizard generated YACC file.

Date: Tuesday, October 01, 2002
****************************************************************************/
package com.pyme.lexyacc;

import java.util.Hashtable;
import java.util.Vector;

import com.pyme.lexyacc.yl.*;
import com.pyme.execute.*;
import com.pyme.Py;
%}

/////////////////////////////////////////////////////////////////////////////
// declarations section

// parser name
%name SimPyParser

// class members
{
	// place any extra class members here
	public SymbolValue pTree;
	private Py main;
	private int compound = 0;
	private boolean execErr = false;
}

// constructor
{
	// place any extra initialisation code here
}

// attribute type
%union {
		public int value;
		public SymbolValue tBuff = new SymbolValue();
		private boolean BOOLEAN_ = false;
		private int INTEGER_ = 0; 
		private Hashtable HASHTABLE_ = null;
		private Vector VECTOR_ = null;
		
		public int intValue;
		public long longValue;
		public String strValue;
		public String timeValue;
//		public String dateValue;
		public int secValue;
		public int minValue;
		public int hrValue;
		public int dayValue;
		public int mtValue;
		public int yrValue;
		
		public String ident;
		
		public void yycopy(yyattribute source, boolean move) {
			YYSTYPE yy = (YYSTYPE)source;
			value = yy.value;

			intValue = yy.intValue;
			longValue = yy.longValue;
			strValue = yy.strValue;
			timeValue = yy.timeValue;
//			dateValue = yy.dateValue;
			secValue = yy.secValue;
			minValue = yy.minValue;
			hrValue = yy.hrValue;
			dayValue = yy.dayValue;
			mtValue = yy.mtValue;
			yrValue = yy.yrValue;
			
			ident = yy.ident;
			tBuff = yy.tBuff;
			
			BOOLEAN_ = yy.BOOLEAN_;
			INTEGER_ = yy.INTEGER_;
			HASHTABLE_ = yy.HASHTABLE_;
			VECTOR_ = yy.VECTOR_;
		}
}

// place any declarations here
%type <tBuff> file
%type <tBuff> suite
%type <tBuff> compound_stmt
%type <tBuff> if_stmt
%type <tBuff> elif_stmt
%type <tBuff> else_stmt
%type <tBuff> while_stmt
%type <tBuff> for_stmt
//%type <tBuff> try_stmt
//%type <INTEGER_> exc_fin
%type <tBuff> statement
%type <tBuff> statement_
%type <tBuff> stmt_list
%type <tBuff> simple_stmt 
%type <tBuff> simple_stmt_
//%type <tBuff> target_list_
//%type <tBuff> target_list
//%type <tBuff> target_
%type <tBuff> target
%type <tBuff> assignment_stmt
%type <tBuff> assignment_stmt_
%type <tBuff> augmented_stmt
%type <tBuff> print_stmt
%type <tBuff> range_stmt
%type <tBuff> len_stmt
%type <tBuff> url_stmt
%type <tBuff> mail_stmt
%type <tBuff> return_stmt
%type <tBuff> del_stmt
//%type <tBuff> global_stmt
%type <tBuff> identifier_
%type <tBuff> expression_stmt 
%type <tBuff> expression_list 
%type <tBuff> expression_list_ 
%type <tBuff> expression 
%type <tBuff> expression_
%type <tBuff> or_test 
%type <tBuff> and_test 
%type <tBuff> not_test 
%type <tBuff> comparison
%type <BOOLEAN_> not_
%type <INTEGER_> augop
%type <INTEGER_> comp_operator
%type <HASHTABLE_> comp_operator_
%type <tBuff> a_expr
%type <tBuff> m_expr
%type <tBuff> u_expr
%type <tBuff> power
%type <tBuff> power_
%type <tBuff> primary
%type <tBuff> atom
%type <tBuff> subscription
%type <tBuff> enclosure
%type <tBuff> literal

/*
%type <tBuff> funcdef 
%type <tBuff> parameter_list 
%type <tBuff> defparameter_
%type <tBuff> identifier_star
%type <tBuff> defparameter 
%type <tBuff> expression_def
%type <tBuff> parameter 
%type <tBuff> sublist 
%type <tBuff> parameter_
*/

%left '+', '-', '~'
%left '*', '/', '%'//, DIV2

%left OR
%left AND

%left EQU, NE1, NE2, '>', '<', GTE, LTE

%right '='

%token NEWLINE
%token INDENT
%token DEDENT

%token <ident> IDENTIFIER
%token <intValue> INTEGER
%token <longValue> LONGINTEGER
//%token <floatValue> FLOATNUMBER
%token <strValue> STRING
%token <timeValue> TIME
//%token <dateValue> DATE
%token <secValue> SECOND
%token <minValue> MINUTE
%token <hrValue> HOUR
%token <dayValue> DAY
%token <mtValue> MONTH
%token <yrValue> YEAR

%token ADDE
%token SUBE
%token MULE
%token DIVE
%token POWE
%token MODE

// reserve word
%token IF
%token ELSE
%token ELIF
%token WHILE
%token FOR
//%token TRY
//%token EXCEPT
//%token FINALLY

// built-in function
%token PRINT
%token URL
%token MAIL
%token DEL
%token BREAK
%token CONTINUE
%token PASS
%token RETURN
//%token GLOBAL
%token RANGE
%token LEN

// condition
%token EQU
%token GTE
%token LTE
%token NE1
%token NE2

%token AND
%token OR
%token IS
%token IN
%token NOT
%token POW

// define function
//%token DEF

%%

/////////////////////////////////////////////////////////////////////////////
// rules section

file		
				: statement file	{ $$ = new SymbolValue(new ParseTree(ParseTree.STMT, $1, $2), SymbolValue.TREE); }
				| statement			{ $$ = $1; }
				;

suite	
				: stmt_list NEWLINE					{ $$ = $1; }		
				| NEWLINE INDENT statement_ DEDENT	{ $$ = $3; }
//				| NEWLINE INDENT statement_ dedent_	{ $$ = $3; }
				;

//dedent_
//				: DEDENT
//				|
//				;

statement_		// statement+
				: statement statement_	{ $$ = new SymbolValue(new ParseTree(ParseTree.STMT, $1, $2), SymbolValue.TREE); }
				| statement				{ $$ = $1; }
				;
				
statement 
				: stmt_list NEWLINE		{ $$ = $1; }
				| compound_stmt			{ 
										   compound--;
										   if (compound != 0) $$ = $1; 
										   /*1else {
										     new SimPyExec($1, main);

										     System.out.println("compound_stmt"); 
										   }*/
										   else if (!execErr) {
										     new SimPyExec($1, main, this);
										   }
										}
				| error					{ 
										   if (yylexerref.dedent == 0) {
										     //System.out.println("ERROR"); 
										     //System.exit(0); 
										     //1new SimPyExec(null, main);
										     new SimPyExec(null, main, this);
										   }
										   else {
										     compound -= yylexerref.dedent;
										     //if (compound != 0) $$ = tBuff;
										     //else {
										     //  new SimPyExec($1, main);
											   System.out.println("compound_stmt");
											 //}
										   }
										}
				;
  
stmt_list 
				: simple_stmt simple_stmt_ /*semi_*/	{ 
														   if ($2 == null) $$ = $1;
														   else $$ = new SymbolValue(new ParseTree(ParseTree.STMT, $1, $2), SymbolValue.TREE); 
														}
				;


simple_stmt_	// (";" simple_stmt)*
				: ';' simple_stmt simple_stmt_	{ 
												   if ($3 == null) $$ = $2;
												   else $$ = new SymbolValue(new ParseTree(ParseTree.STMT, $2, $3), SymbolValue.TREE); 
												}
				| ';'							{ $$ = null; }
				|								{ $$ = null; }
				;

//semi_			//[";"]				
//				: ';'
//				|
//				;
				
simple_stmt 
				: expression_stmt	{ 
									   if (compound != 0) $$ = $1; 
									   //1else { new SimPyExec($1, main); System.out.println("expression_stmt"); }
									   else if (!execErr) { new SimPyExec($1, main, this); System.out.println("expression_stmt"); }
									}
//              | assert_stmt
                | assignment_stmt	{ 
									   if (compound != 0) $$ = $1; 
									   //1else { new SimPyExec($1, main); System.out.println("assignment_stmt"); }
									   else if (!execErr) { new SimPyExec($1, main, this); System.out.println("assignment_stmt"); }
									}
                | augmented_stmt	{ 
									   if (compound != 0) $$ = $1; 
									   //1else { new SimPyExec($1, main);  System.out.println("augmented_stmt"); }
									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("augmented_stmt"); }
									}
				| BREAK				{ 
									   SymbolValue s1 = new SymbolValue(null, SymbolValue.BREAK);
									   if (compound != 0) $$ = s1; 
									   //1else { new SimPyExec(s1, main);  System.out.println("break_stmt"); }
									   else if (!execErr) { new SimPyExec(s1, main, this);  System.out.println("break_stmt"); }
									}
				| CONTINUE			{ 
									   SymbolValue s1 = new SymbolValue(null, SymbolValue.CONTINUE);
									   if (compound != 0) $$ = s1; 
									   //1else { new SimPyExec(s1, main);  System.out.println("continue_stmt"); }
									   else if (!execErr) { new SimPyExec(s1, main, this);  System.out.println("continue_stmt"); }
									}
				| PASS				{ 
									   SymbolValue s1 = new SymbolValue(null, SymbolValue.PASS);
									   if (compound != 0) $$ = s1; 
									   //1else { new SimPyExec(s1, main);  System.out.println("pass_stmt"); }
									   else if (!execErr) { new SimPyExec(s1, main, this);  System.out.println("pass_stmt"); }
									}
				| return_stmt		{ 
									   if (compound != 0) $$ = $1; 
									   //1else { new SimPyExec($1, main);  System.out.println("return_stmt"); }
									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("return_stmt"); }
									}
				| del_stmt			{ 
									   if (compound != 0) $$ = $1; 
									   //1else { new SimPyExec($1, main);  System.out.println("del_stmt"); } 
									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("del_stmt"); } 
									}
                | print_stmt		{ 
									   if (compound != 0) $$ = $1; 
									   //1else { new SimPyExec($1, main);  System.out.println("print_stmt"); } 
									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("print_stmt"); } 
									}
//				| global_stmt		{ 
//									   if (compound != 0) $$ = $1; 
//									   //1else { new SimPyExec($1, main);  System.out.println("global_stmt"); } 
//									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("global_stmt"); } 
//									}
				| url_stmt			{
									   if (compound != 0) $$ = $1;
									   //1else { new SimPyExec($1, main);  System.out.println("url_stmt"); }
									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("url_stmt"); }
									}
				| mail_stmt			{
									   if (compound != 0) $$ = $1;
									   //1else { new SimPyExec($1, main);  System.out.println("mail_stmt"); }
									   else if (!execErr) { new SimPyExec($1, main, this);  System.out.println("mail_stmt"); }
									}
//              | yield_stmt
//              | raise_stmt
//              | import_stmt
//              | exec_stmt
                ;

expression_stmt 
				: expression_list	{ $$ = $1; }
				;
				
expression_list 
				: expression expression_ /*comma_*/		
							{
							   if ($2 == null) $$ = $1;
							   else $$ = new SymbolValue(new ParseTree(ParseTree.EXPRLIST, $1, $2),SymbolValue.TREE);
							}  
				;

expression_		// ( "," expression )*
				: ',' expression expression_	{ $$ = new SymbolValue(new ParseTree(ParseTree.EXPRLIST, $2, $3),SymbolValue.TREE); }
				| ','							{ $$ = null; }		
				|								{ $$ = null; }		
				;                

//comma_			// [","]
//				: ','
//				|
//				;				

expression 
				: or_test				{ $$ = $1; }
//				| lambda_form
				;
  
or_test 
				: and_test				{ $$ = $1; }
				| or_test OR and_test	{ $$ = new SymbolValue(new ParseTree(ParseTree.OR, $1, $3), SymbolValue.TREE); }	
				;
  
and_test 
				: not_test				{ $$ = $1; }
				| and_test AND not_test	{ $$ = new SymbolValue(new ParseTree(ParseTree.AND, $1, $3), SymbolValue.TREE); }
				;
not_test 
				: comparison	{ $$ = $1; }
				| NOT not_test	{ $$ = new SymbolValue(new ParseTree(ParseTree.NOT, $2, null), SymbolValue.TREE); }
				;
  
//lambda_form ::= 
//             "lambda" [parameter_list]: expression

comparison 
//				: or_expr comp_operator_	// original grammar
				: a_expr comp_operator_		// own grammar
							{
							   SymbolValue sBuff = $1;
							   if ($2 != null) {
							     int treeType = ((Integer)$2.get("comp_operator")).intValue();
							     sBuff = new SymbolValue(new ParseTree(treeType, $1,(SymbolValue)$2.get("a_expr")), SymbolValue.TREE);
						       }
						       
						       $$ = sBuff;
						    }
				;
  
comp_operator_	// ( comp_operator or_expr )*
//				: comp_operator or_expr comp_operator_	// original grammar
				: comp_operator a_expr comp_operator_	// own grammar
							{
						       Hashtable hBuff = new Hashtable();
						       SymbolValue sBuff = $2;
						       if ($3 != null) {
							     int treeType = ((Integer)$3.get("comp_operator")).intValue();
							     sBuff = new SymbolValue(new ParseTree(treeType, $2,(SymbolValue)$3.get("a_expr")), SymbolValue.TREE);
						       }
						       
							   hBuff.put("comp_operator", new Integer($1));
							   hBuff.put("a_expr", sBuff);
							   $$ = hBuff;
							}
				|			{ $$ = null; }
				;  
  
comp_operator 
				: '<'		{ $$ = ParseTree.LT; }
				| '>'		{ $$ = ParseTree.GT; } 
				| EQU 		{ $$ = ParseTree.EQU; }
				| GTE 		{ $$ = ParseTree.GTE; }
				| LTE 		{ $$ = ParseTree.LTE; }
				| NE1 		{ $$ = ParseTree.NE; }
				| NE2		{ $$ = ParseTree.NE; }
                | IS not_ 	{ if ($2) $$ = ParseTree.ISNOT; else $$ = ParseTree.IS; }
                | not_ IN	{ if ($1) $$ = ParseTree.NOTIN; else $$ = ParseTree.IN; }
                ;

not_			// ["not"]
				: NOT	{ $$ = true; }
				|		{ $$ = false; }
				;                

/*
or_expr ::= 
             xor_expr | or_expr "|" xor_expr

xor_expr ::= 
             and_expr | xor_expr "\textasciicircum" and_expr

and_expr ::= 
             shift_expr | and_expr "\;SPMamp;" shift_expr

shift_expr ::= 
             a_expr
              | shift_expr ( "<<" | ">>" ) a_expr
*/
  
a_expr 
				: m_expr 				{ $$ = $1; }
				| a_expr '+' m_expr		{ $$ = new SymbolValue(new ParseTree(ParseTree.ADD, $1, $3), SymbolValue.TREE); }
				| a_expr '-' m_expr		{ $$ = new SymbolValue(new ParseTree(ParseTree.SUB, $1, $3), SymbolValue.TREE); }
				; 

m_expr	
				: u_expr				{ $$ = $1; } 
				| m_expr '*' u_expr		{ $$ = new SymbolValue(new ParseTree(ParseTree.MUL, $1, $3), SymbolValue.TREE); }
//				| m_expr DIV2 u_expr	{ $$ = new SymbolValue(new ParseTree(ParseTree.DIV2, $1, $3), SymbolValue.TREE); }
	            | m_expr '/' u_expr		{ $$ = new SymbolValue(new ParseTree(ParseTree.DIV, $1, $3), SymbolValue.TREE); }
				| m_expr '%' u_expr		{ $$ = new SymbolValue(new ParseTree(ParseTree.MOD, $1, $3), SymbolValue.TREE); }
				;

u_expr			
				: power					{ $$ = $1; } 
				| '-' u_expr			{ $$ = new SymbolValue(new ParseTree(ParseTree.SUB, new SymbolValue(new Integer(0), SymbolValue.INTEGER), $2), SymbolValue.TREE); }
				| '+' u_expr			{ $$ = new SymbolValue(new ParseTree(ParseTree.ADD, new SymbolValue(new Integer(0), SymbolValue.INTEGER), $2), SymbolValue.TREE); } 
				| '~' u_expr			{
										   SymbolValue s2 = new SymbolValue(new ParseTree(ParseTree.ADD, $2, new SymbolValue(new Integer(1), SymbolValue.INTEGER)), SymbolValue.TREE);
										   $$ = new SymbolValue(new ParseTree(ParseTree.SUB, new SymbolValue(new Integer(0), SymbolValue.INTEGER), s2), SymbolValue.TREE); 
										}
				;

power			
				: primary power_	{
									   if ($2 == null) $$ = $1; 
									   else $$ = new SymbolValue(new ParseTree(ParseTree.POW, $1, $2), SymbolValue.TREE);
									}	
				;

power_			// ["**" u_expr]
				: POW u_expr		{ $$ = $2; }
				|					{ $$ = null; }
				;
  
primary			
				: atom				{ $$ = $1; }
				| target			{ $$ = $1; }
//				| subscription		{ $$ = $1; }
//				| attributeref
//				| slicing 
//				| call
				;

subscription 
				: primary '[' expression_list ']'	{ $$ = new SymbolValue(new ParseTree(ParseTree.SUBSCRIPT, $1, $3), SymbolValue.TREE); }
				;

atom	
//				: IDENTIFIER	{ $$ = new SymbolValue(new String($1), SymbolValue.IDENTIFIER); }
				: literal		{ $$ = $1; }	
				| enclosure		{ $$ = $1; }
				| range_stmt	{ $$ = $1; }
				| len_stmt		{ $$ = $1; }
				;

enclosure 
				: '(' expression_list_ ')'	{ $$ = $2; }
				| '[' expression_list_ ']'	{ $$ = $2; }
//				| list_display
//				| dict_display 
//				| string_conversion
				;

expression_list_
				: expression_list	{ $$ = $1; }
				|					{ $$ = null; }
				;

literal 
				: INTEGER	 					{ $$ = new SymbolValue(new Integer($1), SymbolValue.INTEGER); }
//				| stringliteral 
				| STRING	/* own grammar*/	{ $$ = new SymbolValue(new String($1), SymbolValue.STRING); }
				| LONGINTEGER					{ $$ = new SymbolValue(new Long($1), SymbolValue.LONGINTEGER); }
//	            | FLOATNUMBER					{ $$ = new SymbolValue(new Float($1), SymbolValue.FLOATNUMBER); }
//				| imagnumber
				| TIME							{ $$ = new SymbolValue(new String($1), SymbolValue.TIME); System.out.println("TIME");}
//				| DATE							{ $$ = new SymbolValue(new String($1), SymbolValue.DATE); }
				| SECOND						{ $$ = new SymbolValue(new Integer($1), SymbolValue.SECOND); System.out.println("SECOND");}
				| MINUTE						{ $$ = new SymbolValue(new Integer($1), SymbolValue.MINUTE); System.out.println("MINUTE");}
				| HOUR							{ $$ = new SymbolValue(new Integer($1), SymbolValue.HOUR); System.out.println("HOUR");}
				| DAY							{ $$ = new SymbolValue(new Integer($1), SymbolValue.DAY); System.out.println("DAY");}
				| MONTH							{ $$ = new SymbolValue(new Integer($1), SymbolValue.MONTH); System.out.println("MONTH");}
				| YEAR							{ $$ = new SymbolValue(new Integer($1), SymbolValue.YEAR); System.out.println("YEAR");}
                ;

assignment_stmt
//				: target_list '=' target_list_	{ $$ = new SymbolValue(new ParseTree(ParseTree.ASSIGN, $1, $3), SymbolValue.TREE); }												
				: target '=' assignment_stmt_	{ $$ = new SymbolValue(new ParseTree(ParseTree.ASSIGN, $1, $3), SymbolValue.TREE); }												
				;

assignment_stmt_
				: assignment_stmt				{ $$ = $1; }
				| expression_list				{ $$ = $1; }
				;

augmented_stmt 
				: target augop expression_list	{ $$ = new SymbolValue(new ParseTree($2, $1, $3), SymbolValue.TREE); }
				;
				
augop 
				: ADDE		{ $$ = ParseTree.ADDASSIGN; }
				| SUBE		{ $$ = ParseTree.SUBASSIGN; }
				| MULE		{ $$ = ParseTree.MULASSIGN; }
				| DIVE		{ $$ = ParseTree.DIVASSIGN; }
				| POWE 		{ $$ = ParseTree.POWASSIGN; }
				| MODE		{ $$ = ParseTree.MODASSIGN; }
//              | ">>=" 
//              | "<<=" 
//              | "\&=" 
//              | "\textasciicircum=" 
//              | "|="
                ;


                
/*
target_list_
				: target_list '=' target_list_	{ $$ = new SymbolValue(new ParseTree(ParseTree.ASSIGN, $1, $3), SymbolValue.TREE); }
				| expression_list				{ $$ = $1; }
				;

*/
/*
target_list		
				: target target_
										{ 
										   if ($2 == null) $$ = $1;
										   else $$ = new SymbolValue(new ParseTree(ParseTree.TARGLIST, $1, $2), SymbolValue.TREE);
										}
				;
				
target_			// ("," target)*
				: ',' target target_	{ $$ = new SymbolValue(new ParseTree(ParseTree.TARGLIST, $2, $3), SymbolValue.TREE); }
				| ','					{ $$ = null; }
				|						{ $$ = null; }
				;				
*/
  
target 
				: IDENTIFIER			{ $$ = new SymbolValue($1, SymbolValue.IDENTIFIER); }
//                | '(' target_list ')'	{ $$ = $2; }
//                | '[' target_list ']'	{ $$ = $2; }
				| subscription			{ $$ = $1; }
//				| attributeref	
//				| slicing
                ;

identifier_		// ("," identifier)*
				: ',' IDENTIFIER identifier_	{ 
												   SymbolValue s2 = new SymbolValue($2, SymbolValue.IDENTIFIER);
												   $$ = new SymbolValue(new ParseTree(ParseTree.IDENLIST, s2, $3), SymbolValue.TREE);
												}
				|								{ $$ = null; }
				;

return_stmt 
				: RETURN expression_list_	{ $$ = new SymbolValue(new ParseTree(ParseTree.RETURN, $2, null), SymbolValue.TREE); }
				;

print_stmt 
				: PRINT expression_list	{ $$ = new SymbolValue(new ParseTree(ParseTree.PRINT, $2, null), SymbolValue.TREE); }
//				: "print" ( \optionalexpression ("," expression)* \optional","		// original grammar
//				| ">\code>" expression \optional("," expression)+ \optional"," )	// original grammar
                ;

del_stmt 
				: DEL IDENTIFIER identifier_
									{
									   SymbolValue s1 = new SymbolValue($2, SymbolValue.IDENTIFIER);
									   SymbolValue s2;
									   if ($3 == null) s2 = s1;
									   else s2 = new SymbolValue(new ParseTree(ParseTree.IDENLIST, s1, $3), SymbolValue.TREE);
									   
									   $$ = new SymbolValue(new ParseTree(ParseTree.DELETE, s2, null) ,SymbolValue.TREE);
									}
				;

//global_stmt 
//				: GLOBAL IDENTIFIER identifier_
//									{
//									   SymbolValue s1 = new SymbolValue($2, SymbolValue.IDENTIFIER);
//									   SymbolValue s2;
//									   if ($3 == null) s2 = s1;
//									   else s2 = new SymbolValue(new ParseTree(ParseTree.IDENLIST, s1, $3), SymbolValue.TREE);
//									   
//									   $$ = new SymbolValue(new ParseTree(ParseTree.GLOBAL, s2, null) ,SymbolValue.TREE);
//									}
//				;

compound_stmt 
				: if_stmt		{ $$ = $1; }
				| while_stmt	{ $$ = $1; }
				| for_stmt		{ $$ = $1; }
//				| try_stmt		{ $$ = $1; }
//				| funcdef		{ $$ = $1; }
//              | classdef
                ;

if_stmt 
				: IF { compound++; } expression  ':' suite elif_stmt else_stmt 
									{										
									   if ($7 == null)
									     $$ = new SymbolValue(new ParseTree(ParseTree.IF, $5, $6, $3), SymbolValue.TREE);
									   else if ($6 == null) 
									     $$ = new SymbolValue(new ParseTree(ParseTree.IF, $5, $7, $3), SymbolValue.TREE);
									   else {
									     SymbolValue sBuff = new SymbolValue(new ParseTree(ParseTree.ELIF, $6, $7), SymbolValue.TREE);
									     $$ = new SymbolValue(new ParseTree(ParseTree.IF, $5, sBuff, $3), SymbolValue.TREE);
									   }
									}
				;

elif_stmt		// ( "elif" expression ":" suite )* 
				: ELIF expression ':' suite elif_stmt	{ $$ = new SymbolValue(new ParseTree(ParseTree.IF, $4, $5, $2), SymbolValue.TREE); }
				|										{ $$ = null; }
				;
				
else_stmt		// ["else" ":" suite]
				: ELSE ':' suite	{ $$ = $3; }
				|					{ $$ = null; }
				;				

while_stmt 
				: WHILE { compound++; } expression ':' suite else_stmt	
								{ $$ = new SymbolValue(new ParseTree(ParseTree.WHILE, $5, $6, $3), SymbolValue.TREE); }
				;
                
for_stmt 
				: FOR { compound++; } target IN expression_list ':' suite else_stmt	
								{ 
								   SymbolValue s3 = new SymbolValue(new ParseTree(ParseTree.IN, $3, $5),SymbolValue.TREE);
//								   SymbolValue s3 = new SymbolValue(new ParseTree(ParseTree.IN, new SymbolValue($3, SymbolValue.IDENTIFIER), $5),SymbolValue.TREE);
								   $$ = new SymbolValue(new ParseTree(ParseTree.FOR, $7, $8, s3), SymbolValue.TREE); 
								}
                ;

range_stmt
				: RANGE '(' expression ')'	
								{ $$ = new SymbolValue(new ParseTree(ParseTree.RANGE, $3, null), SymbolValue.TREE); }
				| RANGE '(' expression ',' expression ')'			
								{ $$ = new SymbolValue(new ParseTree(ParseTree.RANGE, $3, $5), SymbolValue.TREE); }
				| RANGE '(' expression ',' expression ',' expression ')'	
								{ $$ = new SymbolValue(new ParseTree(ParseTree.RANGE, $3, $5, $7), SymbolValue.TREE); }
				;

len_stmt
				: LEN '(' expression_list ')'
								{ $$ = new SymbolValue(new ParseTree(ParseTree.LEN, $3, null), SymbolValue.TREE); }
				;

//try_stmt 
//				: TRY { compound++; } ':' suite exc_fin ':' suite
//								{ $$ = new SymbolValue(new ParseTree($5, $4, $7), SymbolValue.TREE); }
//				;

//exc_fin 
//				: EXCEPT		{ $$ = ParseTree.TRYEXC; }
//				| FINALLY		{ $$ = ParseTree.TRYFIN; }
//				;

url_stmt
				: URL '(' STRING ')'					
								{ 
								   SymbolValue s3 = new SymbolValue($3, SymbolValue.STRING);
								   $$ = new SymbolValue(new ParseTree(ParseTree.URL, s3, null), SymbolValue.TREE); 
								}
				| URL '(' STRING ',' TIME ')'			
								{ 
								   SymbolValue s3 = new SymbolValue($3, SymbolValue.STRING);
								   SymbolValue s5 = new SymbolValue($5, SymbolValue.TIME);
								   $$ = new SymbolValue(new ParseTree(ParseTree.URL, s3, s5), SymbolValue.TREE); 
								}
				;				

mail_stmt
				: MAIL '(' STRING ',' STRING ',' STRING ',' STRING ')'					
								{ 
								   SymbolValue s3 = new SymbolValue($3 + ',' + $5 + ',' + $7 + ',' + $9, SymbolValue.STRING);
								   $$ = new SymbolValue(new ParseTree(ParseTree.MAIL, s3, null), SymbolValue.TREE); 
								}
				| MAIL '(' STRING ',' STRING ',' STRING ',' STRING ',' TIME ')'			
								{ 
								   SymbolValue s3 = new SymbolValue($3 + ',' + $5 + ',' + $7 + ',' + $9, SymbolValue.STRING);
								   SymbolValue s11 = new SymbolValue($11, SymbolValue.TIME);
								   $$ = new SymbolValue(new ParseTree(ParseTree.MAIL, s3, s11), SymbolValue.TREE); 
								}
				;				
				
/*				

funcdef 
				: DEF { compound++; } IDENTIFIER '(' parameter_list ')' ':' suite
								{ 
								   SymbolValue s3 = new SymbolValue($3, SymbolValue.IDENTIFIER); 
								   $$ = new SymbolValue(new ParseTree(ParseTree.FUNCDEF, s3, $8, $5), SymbolValue.TREE); 
								}
				;
				
parameter_list 
				: defparameter defparameter_
										{ 
										   if ($2 == null) $$ = $1;
										   else 
										     $$ = new SymbolValue(new ParseTree(ParseTree.PARAMLIST, $1, $2), SymbolValue.TREE); 
										}
				| '*' IDENTIFIER identifier_star
										{
										   SymbolValue s2 = new SymbolValue($2, SymbolValue.STAR1);
										   if ($3 == null) $$ = s2;
										   else $$ = new SymbolValue(new ParseTree(ParseTree.PARAMLIST, s2, $3), SymbolValue.TREE);
										}
				| POW IDENTIFIER		{ $$ = new SymbolValue($2, SymbolValue.STAR2); }
				|						{ $$ = null; }
				;
  
defparameter_	// (defparameter ",")*
				: ',' defparameter defparameter_	
										{ $$ = new SymbolValue(new ParseTree(ParseTree.PARAMLIST, $2, $3), SymbolValue.TREE); }
				| ',' '*' IDENTIFIER identifier_star
										{
										   SymbolValue s3 = new SymbolValue($3, SymbolValue.STAR1);
										   if ($4 == null) $$ = s3;
										   else $$ = new SymbolValue(new ParseTree(ParseTree.PARAMLIST, s3, $4), SymbolValue.TREE);
										}
				| ',' POW IDENTIFIER	{ $$ = new SymbolValue($3, SymbolValue.STAR2); }
				| ','					{ $$ = null; }
				|						{ $$ = null; }
				;

identifier_star
				: ',' POW IDENTIFIER	{ $$ = new SymbolValue($3, SymbolValue.STAR2); }
				|						{ $$ = null; }
				;
				 
defparameter 
				: parameter expression_def
							{
							   if ($2 == null) $$ = $1;
							   else 
							     $$ = new SymbolValue(new ParseTree(ParseTree.ASSIGN, $1, $2), SymbolValue.TREE); 
							}
				;

expression_def
				: '=' expression	{ $$ = $2; }
				|					{ $$ = null; }
				;

parameter 
				: IDENTIFIER		{ $$ = new SymbolValue($1, SymbolValue.IDENTIFIER); }  
				| '(' sublist ')'	{ $$ = $2; }
				;

sublist 
				: parameter parameter_	{ $$ = new SymbolValue(new ParseTree(ParseTree.IDENLIST, $1, $2), SymbolValue.TREE); }
				;
  
parameter_		// ("," parameter)* [","]
				: ',' parameter parameter_	
							{ $$ = new SymbolValue(new ParseTree(ParseTree.IDENLIST, $2, $3), SymbolValue.TREE); }
				| ','		{ $$ = null; }
				|			{ $$ = null; }
				;

*/
// place your YACC rules here (there must be at least one)

%%

/////////////////////////////////////////////////////////////////////////////
// programs section

	public void lexerError() {
		execErr = true;
		new SimPyExec(null, main, this);
	}

	public void execError() {
		execErr = true;
	}

	public SimPyParser(Py main) {
		yytables();
		this.main = main;
	}
}