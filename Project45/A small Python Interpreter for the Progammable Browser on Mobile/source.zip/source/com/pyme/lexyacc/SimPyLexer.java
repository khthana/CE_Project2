/****************************************************************************
*                     U N R E G I S T E R E D   C O P Y
*
* You are on day 1 of your 30 day trial period.
*
* This file was produced by an UNREGISTERED COPY of Parser Generator. It is
* for evaluation purposes only. If you continue to use Parser Generator 30
* days after installation then you are required to purchase a license. For
* more information see the online help or go to the Bumble-Bee Software
* homepage at:
*
* http://www.bumblebeesoftware.com
*
* This notice must remain present in the file. It cannot be removed.
****************************************************************************/

/****************************************************************************
* SimPyLexer.java
* Java source file generated from SimPyLexer.l.
*
* Date: 03/15/03
* Time: 10:38:29
*
* ALex Version: 1.98 (Beta Release)
****************************************************************************/

// line 1 ".\\SimPyLexer.l"

/****************************************************************************
SimPyLexer.l
ParserWizard generated Lex file.

Date: Tuesday, October 01, 2002
****************************************************************************/
package com.pyme.lexyacc;

import java.util.Stack;

import com.pyme.lexyacc.yl.*;
import com.pyme.execute.*;

// line 43 "SimPyLexer.java"
//import yl.*;

/////////////////////////////////////////////////////////////////////////////
// SimPyLexer

public class SimPyLexer extends yyflexer {
// line 23 ".\\SimPyLexer.l"

		// place any extra class members here
		private Stack indent = new Stack();
		private int in = 1;
		private boolean newLine = true;
		private SimPyParser parser;
		private boolean error = false;

// line 59 "SimPyLexer.java"
	public SimPyLexer() {
		yytables();
// line 33 ".\\SimPyLexer.l"

		// place any extra initialisation code here

// line 66 "SimPyLexer.java"
	}

// line 70 ".\\SimPyLexer.l"

// line 72 ".\\SimPyLexer.l"

// line 74 ".\\SimPyLexer.l"

// line 84 ".\\SimPyLexer.l"

// line 86 ".\\SimPyLexer.l"

// line 88 ".\\SimPyLexer.l"

// line 90 ".\\SimPyLexer.l"

// line 92 ".\\SimPyLexer.l"

// line 98 ".\\SimPyLexer.l"

// line 100 ".\\SimPyLexer.l"

// line 102 ".\\SimPyLexer.l"

// line 104 ".\\SimPyLexer.l"

// line 108 ".\\SimPyLexer.l"

// line 110 ".\\SimPyLexer.l"

// line 112 ".\\SimPyLexer.l"

// line 114 ".\\SimPyLexer.l"

// line 116 ".\\SimPyLexer.l"

// line 103 "SimPyLexer.java"
	public static final int INITIAL = 0;

	public final int yyaction(int action) {
// line 128 ".\\SimPyLexer.l"

		// extract yylval for use later on in actions
		SimPyParser.YYSTYPE yylval = (SimPyParser.YYSTYPE)yyparserref.yylvalref;

// line 112 "SimPyLexer.java"
		yyreturnflg = true;
		switch (action) {
		case 1:
			{
// line 138 ".\\SimPyLexer.l"
 checking(); return SimPyParser.EQU;
// line 119 "SimPyLexer.java"
			}
		case 2:
			{
// line 139 ".\\SimPyLexer.l"
 checking(); return SimPyParser.GTE;
// line 125 "SimPyLexer.java"
			}
		case 3:
			{
// line 140 ".\\SimPyLexer.l"
 checking(); return SimPyParser.LTE;
// line 131 "SimPyLexer.java"
			}
		case 4:
			{
// line 141 ".\\SimPyLexer.l"
 checking(); return SimPyParser.NE1;
// line 137 "SimPyLexer.java"
			}
		case 5:
			{
// line 142 ".\\SimPyLexer.l"
 checking(); return SimPyParser.NE2;
// line 143 "SimPyLexer.java"
			}
		case 6:
			{
// line 143 ".\\SimPyLexer.l"
 checking(); return '<';
// line 149 "SimPyLexer.java"
			}
		case 7:
			{
// line 144 ".\\SimPyLexer.l"
 checking(); return '>';
// line 155 "SimPyLexer.java"
			}
		case 8:
			{
// line 145 ".\\SimPyLexer.l"
 checking(); return SimPyParser.OR;
// line 161 "SimPyLexer.java"
			}
		case 9:
			{
// line 146 ".\\SimPyLexer.l"
 checking(); return SimPyParser.AND;
// line 167 "SimPyLexer.java"
			}
		case 10:
			{
// line 150 ".\\SimPyLexer.l"
 checking(); return SimPyParser.ADDE;
// line 173 "SimPyLexer.java"
			}
		case 11:
			{
// line 151 ".\\SimPyLexer.l"
 checking(); return SimPyParser.SUBE;
// line 179 "SimPyLexer.java"
			}
		case 12:
			{
// line 152 ".\\SimPyLexer.l"
 checking(); return SimPyParser.MULE;
// line 185 "SimPyLexer.java"
			}
		case 13:
			{
// line 153 ".\\SimPyLexer.l"
 checking(); return SimPyParser.DIVE;
// line 191 "SimPyLexer.java"
			}
		case 14:
			{
// line 154 ".\\SimPyLexer.l"
 checking(); return SimPyParser.POWE;
// line 197 "SimPyLexer.java"
			}
		case 15:
			{
// line 155 ".\\SimPyLexer.l"
 checking(); return SimPyParser.MODE;
// line 203 "SimPyLexer.java"
			}
		case 16:
			{
// line 156 ".\\SimPyLexer.l"
 checking(); return SimPyParser.POW;
// line 209 "SimPyLexer.java"
			}
		case 17:
			{
// line 159 ".\\SimPyLexer.l"
 checking(); return '=';
// line 215 "SimPyLexer.java"
			}
		case 18:
			{
// line 160 ".\\SimPyLexer.l"
 checking(); return '+';
// line 221 "SimPyLexer.java"
			}
		case 19:
			{
// line 161 ".\\SimPyLexer.l"
 checking(); return '-';
// line 227 "SimPyLexer.java"
			}
		case 20:
			{
// line 162 ".\\SimPyLexer.l"
 checking(); return '~';
// line 233 "SimPyLexer.java"
			}
		case 21:
			{
// line 163 ".\\SimPyLexer.l"
 checking(); return '*';
// line 239 "SimPyLexer.java"
			}
		case 22:
			{
// line 164 ".\\SimPyLexer.l"
 checking(); return '/';
// line 245 "SimPyLexer.java"
			}
		case 23:
			{
// line 165 ".\\SimPyLexer.l"
 checking(); return '%';
// line 251 "SimPyLexer.java"
			}
		case 24:
			{
// line 166 ".\\SimPyLexer.l"
 checking(); return ';';
// line 257 "SimPyLexer.java"
			}
		case 25:
			{
// line 167 ".\\SimPyLexer.l"
 checking(); return ':';
// line 263 "SimPyLexer.java"
			}
		case 26:
			{
// line 168 ".\\SimPyLexer.l"
 checking(); return '(';
// line 269 "SimPyLexer.java"
			}
		case 27:
			{
// line 169 ".\\SimPyLexer.l"
 checking(); return ')';
// line 275 "SimPyLexer.java"
			}
		case 28:
			{
// line 170 ".\\SimPyLexer.l"
 checking(); return '[';
// line 281 "SimPyLexer.java"
			}
		case 29:
			{
// line 171 ".\\SimPyLexer.l"
 checking(); return ']';
// line 287 "SimPyLexer.java"
			}
		case 30:
			{
// line 172 ".\\SimPyLexer.l"
 checking(); return ',';
// line 293 "SimPyLexer.java"
			}
		case 31:
			{
// line 177 ".\\SimPyLexer.l"
 checking(); return SimPyParser.IS;
// line 299 "SimPyLexer.java"
			}
		case 32:
			{
// line 178 ".\\SimPyLexer.l"
 checking(); return SimPyParser.IN;
// line 305 "SimPyLexer.java"
			}
		case 33:
			{
// line 179 ".\\SimPyLexer.l"
 checking(); return SimPyParser.NOT;
// line 311 "SimPyLexer.java"
			}
		case 34:
			{
// line 181 ".\\SimPyLexer.l"
 checking(); return SimPyParser.IF;
// line 317 "SimPyLexer.java"
			}
		case 35:
			{
// line 182 ".\\SimPyLexer.l"
 checking(); return SimPyParser.ELSE;
// line 323 "SimPyLexer.java"
			}
		case 36:
			{
// line 183 ".\\SimPyLexer.l"
 checking(); return SimPyParser.ELIF;
// line 329 "SimPyLexer.java"
			}
		case 37:
			{
// line 184 ".\\SimPyLexer.l"
 checking(); return SimPyParser.WHILE;
// line 335 "SimPyLexer.java"
			}
		case 38:
			{
// line 185 ".\\SimPyLexer.l"
 checking(); return SimPyParser.FOR;
// line 341 "SimPyLexer.java"
			}
		case 39:
			{
// line 190 ".\\SimPyLexer.l"
 checking(); return SimPyParser.BREAK;
// line 347 "SimPyLexer.java"
			}
		case 40:
			{
// line 191 ".\\SimPyLexer.l"
 checking(); return SimPyParser.CONTINUE;
// line 353 "SimPyLexer.java"
			}
		case 41:
			{
// line 192 ".\\SimPyLexer.l"
 checking(); return SimPyParser.PASS;
// line 359 "SimPyLexer.java"
			}
		case 42:
			{
// line 193 ".\\SimPyLexer.l"
 checking(); return SimPyParser.RETURN;
// line 365 "SimPyLexer.java"
			}
		case 43:
			{
// line 194 ".\\SimPyLexer.l"
 checking(); return SimPyParser.PRINT;
// line 371 "SimPyLexer.java"
			}
		case 44:
			{
// line 195 ".\\SimPyLexer.l"
 checking(); return SimPyParser.DEL;
// line 377 "SimPyLexer.java"
			}
		case 45:
			{
// line 197 ".\\SimPyLexer.l"
 checking(); return SimPyParser.RANGE;
// line 383 "SimPyLexer.java"
			}
		case 46:
			{
// line 198 ".\\SimPyLexer.l"
 checking(); return SimPyParser.LEN;
// line 389 "SimPyLexer.java"
			}
		case 47:
			{
// line 199 ".\\SimPyLexer.l"
 checking(); return SimPyParser.URL;
// line 395 "SimPyLexer.java"
			}
		case 48:
			{
// line 200 ".\\SimPyLexer.l"
 checking(); return SimPyParser.MAIL;
// line 401 "SimPyLexer.java"
			}
		case 49:
			{
// line 204 ".\\SimPyLexer.l"
 yylval.secValue = getInteger(new String(yytext, 0, yyleng-3)); checking(); return SimPyParser.SECOND;
// line 407 "SimPyLexer.java"
			}
		case 50:
			{
// line 206 ".\\SimPyLexer.l"
 yylval.minValue = getInteger(new String(yytext, 0, yyleng-3)); checking(); return SimPyParser.MINUTE;
// line 413 "SimPyLexer.java"
			}
		case 51:
			{
// line 208 ".\\SimPyLexer.l"
 yylval.hrValue = getInteger(new String(yytext, 0, yyleng-2)); checking(); return SimPyParser.HOUR;
// line 419 "SimPyLexer.java"
			}
		case 52:
			{
// line 210 ".\\SimPyLexer.l"
 yylval.dayValue = getInteger(new String(yytext, 0, yyleng-3)); checking(); return SimPyParser.DAY;
// line 425 "SimPyLexer.java"
			}
		case 53:
			{
// line 212 ".\\SimPyLexer.l"
 yylval.mtValue = getInteger(new String(yytext, 0, yyleng-2)); checking(); return SimPyParser.MONTH;
// line 431 "SimPyLexer.java"
			}
		case 54:
			{
// line 214 ".\\SimPyLexer.l"
 yylval.yrValue = getInteger(new String(yytext, 0, yyleng-2)); checking(); return SimPyParser.YEAR;
// line 437 "SimPyLexer.java"
			}
		case 55:
			{
// line 216 ".\\SimPyLexer.l"
 yylval.ident = getIdentifier(); checking(); return SimPyParser.IDENTIFIER;
// line 443 "SimPyLexer.java"
			}
		case 56:
			{
// line 218 ".\\SimPyLexer.l"
 yylval.longValue = getLongInteger(); checking(); return SimPyParser.LONGINTEGER;
// line 449 "SimPyLexer.java"
			}
		case 57:
			{
// line 220 ".\\SimPyLexer.l"
 yylval.intValue = getInteger(); checking(); return SimPyParser.INTEGER;
// line 455 "SimPyLexer.java"
			}
		case 58:
			{
// line 222 ".\\SimPyLexer.l"
 yylval.strValue = getString(); checking(); return SimPyParser.STRING;
// line 461 "SimPyLexer.java"
			}
		case 59:
			{
// line 224 ".\\SimPyLexer.l"
 yylval.timeValue = getTime(); checking(); return SimPyParser.TIME;
// line 467 "SimPyLexer.java"
			}
		case 60:
			{
// line 227 ".\\SimPyLexer.l"

					   newLine = true;
					   return SimPyParser.NEWLINE;

// line 476 "SimPyLexer.java"
			}
// line 231 ".\\SimPyLexer.l"

// line 480 "SimPyLexer.java"
		case 61:
			{
// line 232 ".\\SimPyLexer.l"

					   if (newLine) {
					     if (yyleng > in) {
					       indent.push(new Integer(in));
					       in = yyleng;
  						   checking();
					       return SimPyParser.INDENT;
					     }
					     else if (yyleng < in) {
							do {
								int	de = ((Integer)indent.pop()).intValue();
								if (yyleng == de) {
									in = yyleng;
									checking();
									return SimPyParser.DEDENT;
								}
								else dedent++;

							}
							while (!indent.isEmpty());
// 					        System.out.println("ERROR111");
//							System.exit(0);
							parser.lexerError();
					     }
					   }

// line 510 "SimPyLexer.java"
			}
		case 62:
			{
// line 264 ".\\SimPyLexer.l"
 /* do nothing */
// line 516 "SimPyLexer.java"
			}
			break;
		case 63:
			{
// line 266 ".\\SimPyLexer.l"
 if (!error) {
						error = true;
						parser.lexerError();
					  }

// line 527 "SimPyLexer.java"
			}
			break;
		default:
			break;
		}
		yyreturnflg = false;
		return 0;
	}

	protected final void yytables() {
		yystext_size = 100;
		yysunput_size = 100;
		yytext_max = 0;
		yyunput_max = 0;

		final short match[] = {
			0
		};
		yymatch = match;

		final yytransition transition[] = {
			new yytransition(0, 0),
			new yytransition(4, 1),
			new yytransition(5, 1),
			new yytransition(50, 13),
			new yytransition(0, 44),
			new yytransition(91, 59),
			new yytransition(81, 38),
			new yytransition(74, 34),
			new yytransition(140, 130),
			new yytransition(140, 130),
			new yytransition(140, 130),
			new yytransition(140, 130),
			new yytransition(140, 130),
			new yytransition(140, 130),
			new yytransition(69, 29),
			new yytransition(75, 34),
			new yytransition(92, 59),
			new yytransition(66, 26),
			new yytransition(66, 26),
			new yytransition(66, 26),
			new yytransition(76, 34),
			new yytransition(93, 60),
			new yytransition(51, 13),
			new yytransition(82, 38),
			new yytransition(6, 1),
			new yytransition(7, 1),
			new yytransition(8, 1),
			new yytransition(0, 26),
			new yytransition(45, 44),
			new yytransition(9, 1),
			new yytransition(70, 30),
			new yytransition(10, 1),
			new yytransition(11, 1),
			new yytransition(12, 1),
			new yytransition(13, 1),
			new yytransition(14, 1),
			new yytransition(15, 1),
			new yytransition(16, 1),
			new yytransition(95, 67),
			new yytransition(17, 1),
			new yytransition(18, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(19, 1),
			new yytransition(20, 1),
			new yytransition(21, 1),
			new yytransition(22, 1),
			new yytransition(23, 1),
			new yytransition(24, 1),
			new yytransition(157, 152),
			new yytransition(158, 152),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(26, 1),
			new yytransition(0, 130),
			new yytransition(27, 1),
			new yytransition(46, 44),
			new yytransition(25, 1),
			new yytransition(96, 68),
			new yytransition(28, 1),
			new yytransition(29, 1),
			new yytransition(30, 1),
			new yytransition(31, 1),
			new yytransition(32, 1),
			new yytransition(33, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(34, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(35, 1),
			new yytransition(25, 1),
			new yytransition(36, 1),
			new yytransition(37, 1),
			new yytransition(38, 1),
			new yytransition(25, 1),
			new yytransition(39, 1),
			new yytransition(40, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(41, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(25, 1),
			new yytransition(0, 1),
			new yytransition(44, 46),
			new yytransition(0, 1),
			new yytransition(42, 1),
			new yytransition(116, 95),
			new yytransition(116, 95),
			new yytransition(116, 95),
			new yytransition(116, 95),
			new yytransition(116, 95),
			new yytransition(116, 95),
			new yytransition(161, 165),
			new yytransition(79, 37),
			new yytransition(161, 165),
			new yytransition(80, 37),
			new yytransition(0, 95),
			new yytransition(161, 165),
			new yytransition(97, 69),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(44, 46),
			new yytransition(48, 49),
			new yytransition(100, 72),
			new yytransition(161, 166),
			new yytransition(83, 39),
			new yytransition(161, 166),
			new yytransition(98, 70),
			new yytransition(161, 166),
			new yytransition(84, 39),
			new yytransition(161, 166),
			new yytransition(161, 166),
			new yytransition(99, 71),
			new yytransition(101, 72),
			new yytransition(150, 146),
			new yytransition(151, 146),
			new yytransition(151, 146),
			new yytransition(152, 146),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(48, 49),
			new yytransition(0, 48),
			new yytransition(164, 164),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(168, 168),
			new yytransition(71, 31),
			new yytransition(0, 18),
			new yytransition(0, 18),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(153, 151),
			new yytransition(161, 167),
			new yytransition(159, 156),
			new yytransition(161, 167),
			new yytransition(161, 156),
			new yytransition(45, 48),
			new yytransition(0, 150),
			new yytransition(0, 150),
			new yytransition(62, 22),
			new yytransition(63, 22),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(102, 73),
			new yytransition(56, 18),
			new yytransition(0, 164),
			new yytransition(169, 168),
			new yytransition(165, 162),
			new yytransition(160, 162),
			new yytransition(103, 77),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(56, 18),
			new yytransition(166, 163),
			new yytransition(167, 163),
			new yytransition(104, 78),
			new yytransition(25, 155),
			new yytransition(49, 48),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(25, 155),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(19, 19),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(67, 66),
			new yytransition(105, 79),
			new yytransition(106, 81),
			new yytransition(107, 82),
			new yytransition(108, 83),
			new yytransition(109, 84),
			new yytransition(110, 85),
			new yytransition(111, 86),
			new yytransition(61, 88),
			new yytransition(55, 19),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(113, 89),
			new yytransition(114, 91),
			new yytransition(115, 93),
			new yytransition(72, 32),
			new yytransition(118, 97),
			new yytransition(119, 98),
			new yytransition(120, 100),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(57, 19),
			new yytransition(121, 101),
			new yytransition(122, 105),
			new yytransition(123, 106),
			new yytransition(58, 19),
			new yytransition(124, 107),
			new yytransition(125, 108),
			new yytransition(126, 109),
			new yytransition(55, 19),
			new yytransition(59, 19),
			new yytransition(0, 56),
			new yytransition(127, 110),
			new yytransition(128, 111),
			new yytransition(129, 112),
			new yytransition(73, 33),
			new yytransition(60, 19),
			new yytransition(130, 117),
			new yytransition(131, 118),
			new yytransition(132, 119),
			new yytransition(133, 122),
			new yytransition(134, 124),
			new yytransition(61, 19),
			new yytransition(135, 125),
			new yytransition(136, 126),
			new yytransition(137, 127),
			new yytransition(138, 128),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(112, 129),
			new yytransition(88, 129),
			new yytransition(88, 129),
			new yytransition(53, 16),
			new yytransition(77, 35),
			new yytransition(88, 56),
			new yytransition(142, 132),
			new yytransition(143, 133),
			new yytransition(144, 136),
			new yytransition(0, 56),
			new yytransition(145, 137),
			new yytransition(94, 139),
			new yytransition(78, 36),
			new yytransition(0, 56),
			new yytransition(0, 56),
			new yytransition(146, 141),
			new yytransition(147, 142),
			new yytransition(148, 143),
			new yytransition(149, 145),
			new yytransition(54, 17),
			new yytransition(0, 56),
			new yytransition(139, 129),
			new yytransition(154, 147),
			new yytransition(155, 149),
			new yytransition(43, 7),
			new yytransition(47, 9),
			new yytransition(0, 56),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(117, 116),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(141, 140),
			new yytransition(85, 40),
			new yytransition(156, 153),
			new yytransition(86, 41),
			new yytransition(6, 6),
			new yytransition(162, 157),
			new yytransition(163, 158),
			new yytransition(161, 159),
			new yytransition(161, 160),
			new yytransition(164, 161),
			new yytransition(64, 23),
			new yytransition(65, 24),
			new yytransition(52, 14),
			new yytransition(87, 50),
			new yytransition(68, 28),
			new yytransition(89, 57),
			new yytransition(90, 58)
		};
		yytransition = transition;

		final yystate state[] = {
			new yystate(0, 0, 0),
			new yystate(-3, -8, 0),
			new yystate(1, 0, 0),
			new yystate(0, 0, 63),
			new yystate(0, 0, 62),
			new yystate(0, 0, 60),
			new yystate(0, 514, 61),
			new yystate(0, 459, 63),
			new yystate(44, 0, 63),
			new yystate(0, 460, 23),
			new yystate(48, 0, 63),
			new yystate(0, 0, 26),
			new yystate(0, 0, 27),
			new yystate(0, -39, 21),
			new yystate(0, 493, 18),
			new yystate(0, 0, 30),
			new yystate(0, 438, 19),
			new yystate(0, 454, 22),
			new yystate(19, 263, 57),
			new yystate(0, 367, 57),
			new yystate(0, 0, 25),
			new yystate(0, 0, 24),
			new yystate(0, 277, 6),
			new yystate(0, 491, 17),
			new yystate(0, 492, 7),
			new yystate(155, 0, 55),
			new yystate(66, -31, 28),
			new yystate(0, 0, 29),
			new yystate(155, 446, 55),
			new yystate(155, -100, 55),
			new yystate(155, -81, 55),
			new yystate(155, 217, 55),
			new yystate(155, 349, 55),
			new yystate(155, 370, 55),
			new yystate(155, -95, 55),
			new yystate(155, 399, 55),
			new yystate(155, 397, 55),
			new yystate(155, 14, 55),
			new yystate(155, -91, 55),
			new yystate(155, 117, 55),
			new yystate(155, 442, 55),
			new yystate(155, 441, 55),
			new yystate(0, 0, 20),
			new yystate(0, 0, 5),
			new yystate(-44, -6, 0),
			new yystate(0, 0, 58),
			new yystate(0, 84, 0),
			new yystate(0, 0, 15),
			new yystate(-48, 296, 0),
			new yystate(0, 179, 0),
			new yystate(0, 494, 16),
			new yystate(0, 0, 12),
			new yystate(0, 0, 10),
			new yystate(0, 0, 11),
			new yystate(0, 0, 13),
			new yystate(0, 0, 56),
			new yystate(129, 401, 0),
			new yystate(0, 460, 0),
			new yystate(0, 444, 0),
			new yystate(0, -100, 0),
			new yystate(0, -80, 0),
			new yystate(139, 0, 0),
			new yystate(0, 0, 3),
			new yystate(0, 0, 4),
			new yystate(0, 0, 1),
			new yystate(0, 0, 2),
			new yystate(67, 377, 0),
			new yystate(0, -20, 0),
			new yystate(155, -12, 55),
			new yystate(155, 30, 55),
			new yystate(155, 106, 55),
			new yystate(155, 113, 55),
			new yystate(155, 107, 55),
			new yystate(155, 236, 55),
			new yystate(155, 0, 34),
			new yystate(155, 0, 32),
			new yystate(155, 0, 31),
			new yystate(155, 246, 55),
			new yystate(155, 270, 55),
			new yystate(155, 334, 55),
			new yystate(155, 0, 8),
			new yystate(155, 321, 55),
			new yystate(155, 332, 55),
			new yystate(155, 328, 55),
			new yystate(155, 323, 55),
			new yystate(155, 330, 55),
			new yystate(155, 336, 55),
			new yystate(0, 0, 14),
			new yystate(129, 321, 57),
			new yystate(0, 333, 0),
			new yystate(0, 0, 51),
			new yystate(0, 345, 0),
			new yystate(0, 0, 53),
			new yystate(0, 357, 0),
			new yystate(0, 0, 54),
			new yystate(116, 71, 0),
			new yystate(155, 0, 9),
			new yystate(155, 361, 55),
			new yystate(155, 343, 55),
			new yystate(155, 0, 44),
			new yystate(155, 358, 55),
			new yystate(155, 367, 55),
			new yystate(155, 0, 38),
			new yystate(155, 0, 46),
			new yystate(155, 0, 33),
			new yystate(155, 359, 55),
			new yystate(155, 355, 55),
			new yystate(155, 362, 55),
			new yystate(155, 370, 55),
			new yystate(155, 357, 55),
			new yystate(155, 378, 55),
			new yystate(155, 371, 55),
			new yystate(88, 383, 57),
			new yystate(0, 0, 52),
			new yystate(0, 0, 50),
			new yystate(0, 0, 49),
			new yystate(117, 475, 0),
			new yystate(0, 425, 0),
			new yystate(155, 377, 55),
			new yystate(155, 380, 55),
			new yystate(155, 0, 36),
			new yystate(155, 0, 35),
			new yystate(155, 401, 55),
			new yystate(155, 0, 41),
			new yystate(155, 371, 55),
			new yystate(155, 388, 55),
			new yystate(155, 376, 55),
			new yystate(155, 414, 55),
			new yystate(155, 391, 55),
			new yystate(19, 396, 57),
			new yystate(140, -40, 0),
			new yystate(155, 0, 39),
			new yystate(155, 392, 55),
			new yystate(155, 421, 55),
			new yystate(155, 0, 43),
			new yystate(155, 0, 45),
			new yystate(155, 394, 55),
			new yystate(155, 409, 55),
			new yystate(155, 0, 37),
			new yystate(0, 393, 52),
			new yystate(141, 485, 0),
			new yystate(0, 387, 0),
			new yystate(155, 395, 55),
			new yystate(155, 437, 55),
			new yystate(155, 0, 42),
			new yystate(155, 409, 55),
			new yystate(150, 175, 0),
			new yystate(155, 417, 55),
			new yystate(155, 0, 47),
			new yystate(155, 411, 55),
			new yystate(151, 289, 0),
			new yystate(153, 273, 0),
			new yystate(153, 7, 0),
			new yystate(0, 497, 0),
			new yystate(155, 0, 40),
			new yystate(0, 292, 48),
			new yystate(162, 284, 0),
			new yystate(0, 500, 0),
			new yystate(0, 501, 0),
			new yystate(165, 499, 0),
			new yystate(167, 501, 0),
			new yystate(0, 504, 0),
			new yystate(165, 306, 0),
			new yystate(166, 336, 0),
			new yystate(168, 259, 0),
			new yystate(166, 73, 0),
			new yystate(0, 164, 0),
			new yystate(161, 283, 0),
			new yystate(0, 260, 0),
			new yystate(0, 0, 59)
		};
		yystate = state;

		final boolean backup[] = {
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false,
			false
		};
		yybackup = backup;
	}
// line 272 ".\\SimPyLexer.l"


/////////////////////////////////////////////////////////////////////////////
// programs section

	protected void checking() {
		newLine = false;
	}



	protected int getInteger() {
		String strValue = new String(yytext, 0, yyleng);
		try {
			if (strValue.length() < 2) {
				return Integer.parseInt(strValue);
			}
			else if (strValue.substring(0,2).equals("0X") || strValue.substring(0,2).equals("0x")) {
				return getHexInteger(strValue);
			}
			else if (strValue.substring(0,1).equals("0")) {
				return getOctInteger(strValue);
			}
			else return Integer.parseInt(strValue);
		}
		catch (NumberFormatException e) {
			return 0;
		}
	}

	protected int getInteger(String strValue) {
		try {
			if (strValue.length() < 2) {
				return Integer.parseInt(strValue);
			}
			else if (strValue.substring(0,2).equals("0X") || strValue.substring(0,2).equals("0x")) {
				return getHexInteger(strValue);
			}
			else if (strValue.substring(0,1).equals("0")) {
				return getOctInteger(strValue);
			}
			else return Integer.parseInt(strValue);
		}
		catch (NumberFormatException e) {
			return 0;
		}
	}


	protected long getLongInteger() {
		String strValue = new String(yytext, 0, yyleng-1);
		try {
			return Long.parseLong(strValue);
		}
		catch (NumberFormatException e) {
			return 0;
		}
	}

	protected int getHexInteger(String val) {
          val = val.toLowerCase();
          val = val.substring(val.indexOf("0x")+2);
          while(val.charAt(0) == '0') val = val.substring(1);

          int result = 0;
          for (int i=0; i<val.length(); i++) {
            int col = 1;
            int value = 0;
            for (int j=0; j<i; j++) col *= 16;

            if (val.charAt(val.length()-1-i) == 'a') value = 10;
            else if (val.charAt(val.length()-1-i) == 'b') value = 11;
            else if (val.charAt(val.length()-1-i) == 'c') value = 12;
            else if (val.charAt(val.length()-1-i) == 'd') value = 13;
            else if (val.charAt(val.length()-1-i) == 'e') value = 14;
            else if (val.charAt(val.length()-1-i) == 'f') value = 15;
            else value = Integer.parseInt("" + val.charAt(val.length()-1-i));
            result += value * col;
          }
          return result;
	}

	protected int getOctInteger(String val) {
          while (val.charAt(0) == '0') {
            val = val.substring(1);
            if (val.length() == 0) break;
          }

          int result = 0;
          for (int i=0; i<val.length(); i++) {
            int col = 1;
            for (int j=0; j<i; j++) col *= 8;
            result += Integer.parseInt("" + (val.charAt(val.length()-1-i))) * col;
         }
          return result;
	}

	protected String getString() {
		String buff = new String(yytext, 0, yyleng-1);
		return buff.substring(1);
	}

	protected String getTime() {
		return new String(yytext, 0, yyleng);
	}

	protected String getDate() {
		return new String(yytext, 0, yyleng);
	}

	protected String getIdentifier() {
		return new String(yytext, 0, yyleng);
	}


	public SimPyLexer(SimPyParser parser) {
		yytables();
		this.parser = parser;
	}

}


