#############################################################################
#                     U N R E G I S T E R E D   C O P Y
# 
# You are on day 1 of your 30 day trial period.
# 
# This file was produced by an UNREGISTERED COPY of Parser Generator. It is
# for evaluation purposes only. If you continue to use Parser Generator 30
# days after installation then you are required to purchase a license. For
# more information see the online help or go to the Bumble-Bee Software
# homepage at:
# 
# http://www.bumblebeesoftware.com
# 
# This notice must remain present in the file. It cannot be removed.
#############################################################################

#############################################################################
# SimPyParser.v
# YACC verbose file generated from SimPyParser.y.
# 
# Date: 04/13/03
# Time: 12:40:14
# 
# AYACC Version: 1.98 (Beta Release)
#############################################################################


##############################################################################
# Rules
##############################################################################

    0  $accept : file $end

    1  file : statement file
    2       | statement

    3  suite : stmt_list NEWLINE
    4        | NEWLINE INDENT statement_ DEDENT

    5  statement_ : statement statement_
    6             | statement

    7  statement : stmt_list NEWLINE
    8            | compound_stmt
    9            | error

   10  stmt_list : simple_stmt simple_stmt_

   11  simple_stmt_ : ';' simple_stmt simple_stmt_
   12               | ';'
   13               |

   14  simple_stmt : expression_stmt
   15              | assignment_stmt
   16              | augmented_stmt
   17              | BREAK
   18              | CONTINUE
   19              | PASS
   20              | return_stmt
   21              | del_stmt
   22              | print_stmt
   23              | url_stmt
   24              | mail_stmt

   25  expression_stmt : expression_list

   26  expression_list : expression expression_

   27  expression_ : ',' expression expression_
   28              | ','
   29              |

   30  expression : or_test

   31  or_test : and_test
   32          | or_test OR and_test

   33  and_test : not_test
   34           | and_test AND not_test

   35  not_test : comparison
   36           | NOT not_test

   37  comparison : a_expr comp_operator_

   38  comp_operator_ : comp_operator a_expr comp_operator_
   39                 |

   40  comp_operator : '<'
   41                | '>'
   42                | EQU
   43                | GTE
   44                | LTE
   45                | NE1
   46                | NE2
   47                | IS not_
   48                | not_ IN

   49  not_ : NOT
   50       |

   51  a_expr : m_expr
   52         | a_expr '+' m_expr
   53         | a_expr '-' m_expr

   54  m_expr : u_expr
   55         | m_expr '*' u_expr
   56         | m_expr '/' u_expr
   57         | m_expr '%' u_expr

   58  u_expr : power
   59         | '-' u_expr
   60         | '+' u_expr
   61         | '~' u_expr

   62  power : primary power_

   63  power_ : POW u_expr
   64         |

   65  primary : atom
   66          | target

   67  subscription : primary '[' expression_list ']'

   68  atom : literal
   69       | enclosure
   70       | range_stmt
   71       | len_stmt

   72  enclosure : '(' expression_list_ ')'
   73            | '[' expression_list_ ']'

   74  expression_list_ : expression_list
   75                   |

   76  literal : INTEGER
   77          | STRING
   78          | LONGINTEGER
   79          | TIME
   80          | SECOND
   81          | MINUTE
   82          | HOUR
   83          | DAY
   84          | MONTH
   85          | YEAR

   86  assignment_stmt : target '=' assignment_stmt_

   87  assignment_stmt_ : assignment_stmt
   88                   | expression_list

   89  augmented_stmt : target augop expression_list

   90  augop : ADDE
   91        | SUBE
   92        | MULE
   93        | DIVE
   94        | POWE
   95        | MODE

   96  target : IDENTIFIER
   97         | subscription

   98  identifier_ : ',' IDENTIFIER identifier_
   99              |

  100  return_stmt : RETURN expression_list_

  101  print_stmt : PRINT expression_list

  102  del_stmt : DEL IDENTIFIER identifier_

  103  compound_stmt : if_stmt
  104                | while_stmt
  105                | for_stmt

  106  $$1 :

  107  if_stmt : IF $$1 expression ':' suite elif_stmt else_stmt

  108  elif_stmt : ELIF expression ':' suite elif_stmt
  109            |

  110  else_stmt : ELSE ':' suite
  111            |

  112  $$2 :

  113  while_stmt : WHILE $$2 expression ':' suite else_stmt

  114  $$3 :

  115  for_stmt : FOR $$3 target IN expression_list ':' suite else_stmt

  116  range_stmt : RANGE '(' expression ')'
  117             | RANGE '(' expression ',' expression ')'
  118             | RANGE '(' expression ',' expression ',' expression ')'

  119  len_stmt : LEN '(' expression_list ')'

  120  url_stmt : URL '(' STRING ')'
  121           | URL '(' STRING ',' TIME ')'

  122  mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING ')'
  123            | MAIL '(' STRING ',' STRING ',' STRING ',' STRING ',' TIME ')'


##############################################################################
# States
##############################################################################

state 0
	$accept : . file $end

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	error  shift 6
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	IF  shift 18
	WHILE  shift 19
	FOR  shift 20
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	file  goto 32
	compound_stmt  goto 33
	if_stmt  goto 34
	while_stmt  goto 35
	for_stmt  goto 36
	statement  goto 37
	stmt_list  goto 38
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 1
	enclosure : '(' . expression_list_ ')'
	expression_list_ : .  (75)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 75

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 67
	expression_list_  goto 68
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 2
	u_expr : '+' . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 69
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 3
	u_expr : '-' . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 70
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 4
	enclosure : '[' . expression_list_ ']'
	expression_list_ : .  (75)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 75

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 67
	expression_list_  goto 71
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 5
	u_expr : '~' . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 72
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 6
	statement : error .  (9)

	.  reduce 9


state 7
	target : IDENTIFIER .  (96)

	.  reduce 96


state 8
	literal : INTEGER .  (76)

	.  reduce 76


state 9
	literal : LONGINTEGER .  (78)

	.  reduce 78


state 10
	literal : STRING .  (77)

	.  reduce 77


state 11
	literal : TIME .  (79)

	.  reduce 79


state 12
	literal : SECOND .  (80)

	.  reduce 80


state 13
	literal : MINUTE .  (81)

	.  reduce 81


state 14
	literal : HOUR .  (82)

	.  reduce 82


state 15
	literal : DAY .  (83)

	.  reduce 83


state 16
	literal : MONTH .  (84)

	.  reduce 84


state 17
	literal : YEAR .  (85)

	.  reduce 85


state 18
	if_stmt : IF . $$1 expression ':' suite elif_stmt else_stmt
	$$1 : .  (106)

	.  reduce 106

	$$1  goto 73


state 19
	while_stmt : WHILE . $$2 expression ':' suite else_stmt
	$$2 : .  (112)

	.  reduce 112

	$$2  goto 74


state 20
	for_stmt : FOR . $$3 target IN expression_list ':' suite else_stmt
	$$3 : .  (114)

	.  reduce 114

	$$3  goto 75


state 21
	print_stmt : PRINT . expression_list

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 76
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 22
	url_stmt : URL . '(' STRING ')'
	url_stmt : URL . '(' STRING ',' TIME ')'

	'('  shift 77


state 23
	mail_stmt : MAIL . '(' STRING ',' STRING ',' STRING ',' STRING ')'
	mail_stmt : MAIL . '(' STRING ',' STRING ',' STRING ',' STRING ',' TIME ')'

	'('  shift 78


state 24
	del_stmt : DEL . IDENTIFIER identifier_

	IDENTIFIER  shift 79


state 25
	simple_stmt : BREAK .  (17)

	.  reduce 17


state 26
	simple_stmt : CONTINUE .  (18)

	.  reduce 18


state 27
	simple_stmt : PASS .  (19)

	.  reduce 19


state 28
	return_stmt : RETURN . expression_list_
	expression_list_ : .  (75)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 75

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 67
	expression_list_  goto 80
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 29
	range_stmt : RANGE . '(' expression ')'
	range_stmt : RANGE . '(' expression ',' expression ')'
	range_stmt : RANGE . '(' expression ',' expression ',' expression ')'

	'('  shift 81


state 30
	len_stmt : LEN . '(' expression_list ')'

	'('  shift 82


state 31
	not_test : NOT . not_test

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	not_test  goto 83
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 32
	$accept : file . $end  (0)

	$end  accept


state 33
	statement : compound_stmt .  (8)

	.  reduce 8


state 34
	compound_stmt : if_stmt .  (103)

	.  reduce 103


state 35
	compound_stmt : while_stmt .  (104)

	.  reduce 104


state 36
	compound_stmt : for_stmt .  (105)

	.  reduce 105


state 37
	file : statement . file
	file : statement .  (2)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	error  shift 6
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	IF  shift 18
	WHILE  shift 19
	FOR  shift 20
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 2

	file  goto 84
	compound_stmt  goto 33
	if_stmt  goto 34
	while_stmt  goto 35
	for_stmt  goto 36
	statement  goto 37
	stmt_list  goto 38
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 38
	statement : stmt_list . NEWLINE

	NEWLINE  shift 85


state 39
	stmt_list : simple_stmt . simple_stmt_
	simple_stmt_ : .  (13)

	';'  shift 86
	.  reduce 13

	simple_stmt_  goto 87


state 40
	primary : target .  (66)
	assignment_stmt : target . '=' assignment_stmt_
	augmented_stmt : target . augop expression_list

	'='  shift 88
	ADDE  shift 89
	SUBE  shift 90
	MULE  shift 91
	DIVE  shift 92
	POWE  shift 93
	MODE  shift 94
	.  reduce 66

	augop  goto 95


state 41
	simple_stmt : assignment_stmt .  (15)

	.  reduce 15


state 42
	simple_stmt : augmented_stmt .  (16)

	.  reduce 16


state 43
	simple_stmt : print_stmt .  (22)

	.  reduce 22


state 44
	atom : range_stmt .  (70)

	.  reduce 70


state 45
	atom : len_stmt .  (71)

	.  reduce 71


state 46
	simple_stmt : url_stmt .  (23)

	.  reduce 23


state 47
	simple_stmt : mail_stmt .  (24)

	.  reduce 24


state 48
	simple_stmt : return_stmt .  (20)

	.  reduce 20


state 49
	simple_stmt : del_stmt .  (21)

	.  reduce 21


state 50
	simple_stmt : expression_stmt .  (14)

	.  reduce 14


state 51
	expression_stmt : expression_list .  (25)

	.  reduce 25


state 52
	expression_list : expression . expression_
	expression_ : .  (29)

	','  shift 96
	.  reduce 29

	expression_  goto 97


state 53
	expression : or_test .  (30)
	or_test : or_test . OR and_test

	OR  shift 98
	.  reduce 30


state 54
	or_test : and_test .  (31)
	and_test : and_test . AND not_test

	AND  shift 99
	.  reduce 31


state 55
	and_test : not_test .  (33)

	.  reduce 33


state 56
	not_test : comparison .  (35)

	.  reduce 35


state 57
	comparison : a_expr . comp_operator_
	a_expr : a_expr . '+' m_expr
	a_expr : a_expr . '-' m_expr
	comp_operator_ : .  (39)
	not_ : .  (50)

	'+'  shift 100
	'-'  shift 101
	'<'  shift 102
	'>'  shift 103
	EQU  shift 104
	NE1  shift 105
	NE2  shift 106
	GTE  shift 107
	LTE  shift 108
	IS  shift 109
	NOT  shift 110
	IN  reduce 50
	.  reduce 39

	not_  goto 111
	comp_operator  goto 112
	comp_operator_  goto 113


state 58
	a_expr : m_expr .  (51)
	m_expr : m_expr . '*' u_expr
	m_expr : m_expr . '/' u_expr
	m_expr : m_expr . '%' u_expr

	'%'  shift 114
	'*'  shift 115
	'/'  shift 116
	.  reduce 51


state 59
	m_expr : u_expr .  (54)

	.  reduce 54


state 60
	u_expr : power .  (58)

	.  reduce 58


state 61
	power : primary . power_
	subscription : primary . '[' expression_list ']'
	power_ : .  (64)

	'['  shift 117
	POW  shift 118
	.  reduce 64

	power_  goto 119


state 62
	primary : atom .  (65)

	.  reduce 65


state 63
	target : subscription .  (97)

	.  reduce 97


state 64
	atom : enclosure .  (69)

	.  reduce 69


state 65
	atom : literal .  (68)

	.  reduce 68


state 66
	primary : target .  (66)

	.  reduce 66


state 67
	expression_list_ : expression_list .  (74)

	.  reduce 74


state 68
	enclosure : '(' expression_list_ . ')'

	')'  shift 120


state 69
	u_expr : '+' u_expr .  (60)

	.  reduce 60


state 70
	u_expr : '-' u_expr .  (59)

	.  reduce 59


state 71
	enclosure : '[' expression_list_ . ']'

	']'  shift 121


state 72
	u_expr : '~' u_expr .  (61)

	.  reduce 61


state 73
	if_stmt : IF $$1 . expression ':' suite elif_stmt else_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 122
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 74
	while_stmt : WHILE $$2 . expression ':' suite else_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 123
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 75
	for_stmt : FOR $$3 . target IN expression_list ':' suite else_stmt

	'('  shift 1
	'['  shift 4
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 124
	range_stmt  goto 44
	len_stmt  goto 45
	primary  goto 125
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 76
	print_stmt : PRINT expression_list .  (101)

	.  reduce 101


state 77
	url_stmt : URL '(' . STRING ')'
	url_stmt : URL '(' . STRING ',' TIME ')'

	STRING  shift 126


state 78
	mail_stmt : MAIL '(' . STRING ',' STRING ',' STRING ',' STRING ')'
	mail_stmt : MAIL '(' . STRING ',' STRING ',' STRING ',' STRING ',' TIME ')'

	STRING  shift 127


state 79
	del_stmt : DEL IDENTIFIER . identifier_
	identifier_ : .  (99)

	','  shift 128
	.  reduce 99

	identifier_  goto 129


state 80
	return_stmt : RETURN expression_list_ .  (100)

	.  reduce 100


state 81
	range_stmt : RANGE '(' . expression ')'
	range_stmt : RANGE '(' . expression ',' expression ')'
	range_stmt : RANGE '(' . expression ',' expression ',' expression ')'

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 130
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 82
	len_stmt : LEN '(' . expression_list ')'

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 131
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 83
	not_test : NOT not_test .  (36)

	.  reduce 36


state 84
	file : statement file .  (1)

	.  reduce 1


state 85
	statement : stmt_list NEWLINE .  (7)

	.  reduce 7


state 86
	simple_stmt_ : ';' . simple_stmt simple_stmt_
	simple_stmt_ : ';' .  (12)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 12

	simple_stmt  goto 132
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 87
	stmt_list : simple_stmt simple_stmt_ .  (10)

	.  reduce 10


state 88
	assignment_stmt : target '=' . assignment_stmt_

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 133
	assignment_stmt  goto 134
	assignment_stmt_  goto 135
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 136
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 89
	augop : ADDE .  (90)

	.  reduce 90


state 90
	augop : SUBE .  (91)

	.  reduce 91


state 91
	augop : MULE .  (92)

	.  reduce 92


state 92
	augop : DIVE .  (93)

	.  reduce 93


state 93
	augop : POWE .  (94)

	.  reduce 94


state 94
	augop : MODE .  (95)

	.  reduce 95


state 95
	augmented_stmt : target augop . expression_list

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 137
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 96
	expression_ : ',' . expression expression_
	expression_ : ',' .  (28)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 28

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 138
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 97
	expression_list : expression expression_ .  (26)

	.  reduce 26


state 98
	or_test : or_test OR . and_test

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	and_test  goto 139
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 99
	and_test : and_test AND . not_test

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	not_test  goto 140
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 100
	a_expr : a_expr '+' . m_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	m_expr  goto 141
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 101
	a_expr : a_expr '-' . m_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	m_expr  goto 142
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 102
	comp_operator : '<' .  (40)

	.  reduce 40


state 103
	comp_operator : '>' .  (41)

	.  reduce 41


state 104
	comp_operator : EQU .  (42)

	.  reduce 42


state 105
	comp_operator : NE1 .  (45)

	.  reduce 45


state 106
	comp_operator : NE2 .  (46)

	.  reduce 46


state 107
	comp_operator : GTE .  (43)

	.  reduce 43


state 108
	comp_operator : LTE .  (44)

	.  reduce 44


state 109
	comp_operator : IS . not_
	not_ : .  (50)

	NOT  shift 110
	.  reduce 50

	not_  goto 143


state 110
	not_ : NOT .  (49)

	.  reduce 49


state 111
	comp_operator : not_ . IN

	IN  shift 144


state 112
	comp_operator_ : comp_operator . a_expr comp_operator_

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	a_expr  goto 145
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 113
	comparison : a_expr comp_operator_ .  (37)

	.  reduce 37


state 114
	m_expr : m_expr '%' . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 146
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 115
	m_expr : m_expr '*' . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 147
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 116
	m_expr : m_expr '/' . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 148
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 117
	subscription : primary '[' . expression_list ']'

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 149
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 118
	power_ : POW . u_expr

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	u_expr  goto 150
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 119
	power : primary power_ .  (62)

	.  reduce 62


state 120
	enclosure : '(' expression_list_ ')' .  (72)

	.  reduce 72


state 121
	enclosure : '[' expression_list_ ']' .  (73)

	.  reduce 73


state 122
	if_stmt : IF $$1 expression . ':' suite elif_stmt else_stmt

	':'  shift 151


state 123
	while_stmt : WHILE $$2 expression . ':' suite else_stmt

	':'  shift 152


state 124
	primary : target .  (66)
	for_stmt : FOR $$3 target . IN expression_list ':' suite else_stmt

	IN  shift 153
	.  reduce 66


state 125
	subscription : primary . '[' expression_list ']'

	'['  shift 117


state 126
	url_stmt : URL '(' STRING . ')'
	url_stmt : URL '(' STRING . ',' TIME ')'

	')'  shift 154
	','  shift 155


state 127
	mail_stmt : MAIL '(' STRING . ',' STRING ',' STRING ',' STRING ')'
	mail_stmt : MAIL '(' STRING . ',' STRING ',' STRING ',' STRING ',' TIME ')'

	','  shift 156


state 128
	identifier_ : ',' . IDENTIFIER identifier_

	IDENTIFIER  shift 157


state 129
	del_stmt : DEL IDENTIFIER identifier_ .  (102)

	.  reduce 102


state 130
	range_stmt : RANGE '(' expression . ')'
	range_stmt : RANGE '(' expression . ',' expression ')'
	range_stmt : RANGE '(' expression . ',' expression ',' expression ')'

	')'  shift 158
	','  shift 159


state 131
	len_stmt : LEN '(' expression_list . ')'

	')'  shift 160


state 132
	simple_stmt_ : ';' simple_stmt . simple_stmt_
	simple_stmt_ : .  (13)

	';'  shift 86
	.  reduce 13

	simple_stmt_  goto 161


state 133
	primary : target .  (66)
	assignment_stmt : target . '=' assignment_stmt_

	'='  shift 88
	.  reduce 66


state 134
	assignment_stmt_ : assignment_stmt .  (87)

	.  reduce 87


state 135
	assignment_stmt : target '=' assignment_stmt_ .  (86)

	.  reduce 86


state 136
	assignment_stmt_ : expression_list .  (88)

	.  reduce 88


state 137
	augmented_stmt : target augop expression_list .  (89)

	.  reduce 89


state 138
	expression_ : ',' expression . expression_
	expression_ : .  (29)

	','  shift 96
	.  reduce 29

	expression_  goto 162


state 139
	or_test : or_test OR and_test .  (32)
	and_test : and_test . AND not_test

	AND  shift 99
	.  reduce 32


state 140
	and_test : and_test AND not_test .  (34)

	.  reduce 34


state 141
	a_expr : a_expr '+' m_expr .  (52)
	m_expr : m_expr . '*' u_expr
	m_expr : m_expr . '/' u_expr
	m_expr : m_expr . '%' u_expr

	'%'  shift 114
	'*'  shift 115
	'/'  shift 116
	.  reduce 52


state 142
	a_expr : a_expr '-' m_expr .  (53)
	m_expr : m_expr . '*' u_expr
	m_expr : m_expr . '/' u_expr
	m_expr : m_expr . '%' u_expr

	'%'  shift 114
	'*'  shift 115
	'/'  shift 116
	.  reduce 53


state 143
	comp_operator : IS not_ .  (47)

	.  reduce 47


state 144
	comp_operator : not_ IN .  (48)

	.  reduce 48


state 145
	comp_operator_ : comp_operator a_expr . comp_operator_
	a_expr : a_expr . '+' m_expr
	a_expr : a_expr . '-' m_expr
	comp_operator_ : .  (39)
	not_ : .  (50)

	'+'  shift 100
	'-'  shift 101
	'<'  shift 102
	'>'  shift 103
	EQU  shift 104
	NE1  shift 105
	NE2  shift 106
	GTE  shift 107
	LTE  shift 108
	IS  shift 109
	NOT  shift 110
	IN  reduce 50
	.  reduce 39

	not_  goto 111
	comp_operator  goto 112
	comp_operator_  goto 163


state 146
	m_expr : m_expr '%' u_expr .  (57)

	.  reduce 57


state 147
	m_expr : m_expr '*' u_expr .  (55)

	.  reduce 55


state 148
	m_expr : m_expr '/' u_expr .  (56)

	.  reduce 56


state 149
	subscription : primary '[' expression_list . ']'

	']'  shift 164


state 150
	power_ : POW u_expr .  (63)

	.  reduce 63


state 151
	if_stmt : IF $$1 expression ':' . suite elif_stmt else_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	NEWLINE  shift 165
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	suite  goto 166
	stmt_list  goto 167
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 152
	while_stmt : WHILE $$2 expression ':' . suite else_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	NEWLINE  shift 165
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	suite  goto 168
	stmt_list  goto 167
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 153
	for_stmt : FOR $$3 target IN . expression_list ':' suite else_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression_list  goto 169
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 154
	url_stmt : URL '(' STRING ')' .  (120)

	.  reduce 120


state 155
	url_stmt : URL '(' STRING ',' . TIME ')'

	TIME  shift 170


state 156
	mail_stmt : MAIL '(' STRING ',' . STRING ',' STRING ',' STRING ')'
	mail_stmt : MAIL '(' STRING ',' . STRING ',' STRING ',' STRING ',' TIME ')'

	STRING  shift 171


state 157
	identifier_ : ',' IDENTIFIER . identifier_
	identifier_ : .  (99)

	','  shift 128
	.  reduce 99

	identifier_  goto 172


state 158
	range_stmt : RANGE '(' expression ')' .  (116)

	.  reduce 116


state 159
	range_stmt : RANGE '(' expression ',' . expression ')'
	range_stmt : RANGE '(' expression ',' . expression ',' expression ')'

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 173
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 160
	len_stmt : LEN '(' expression_list ')' .  (119)

	.  reduce 119


state 161
	simple_stmt_ : ';' simple_stmt simple_stmt_ .  (11)

	.  reduce 11


state 162
	expression_ : ',' expression expression_ .  (27)

	.  reduce 27


state 163
	comp_operator_ : comp_operator a_expr comp_operator_ .  (38)

	.  reduce 38


state 164
	subscription : primary '[' expression_list ']' .  (67)

	.  reduce 67


state 165
	suite : NEWLINE . INDENT statement_ DEDENT

	INDENT  shift 174


state 166
	if_stmt : IF $$1 expression ':' suite . elif_stmt else_stmt
	elif_stmt : .  (109)

	ELIF  shift 175
	.  reduce 109

	elif_stmt  goto 176


state 167
	suite : stmt_list . NEWLINE

	NEWLINE  shift 177


state 168
	while_stmt : WHILE $$2 expression ':' suite . else_stmt
	else_stmt : .  (111)

	ELSE  shift 178
	.  reduce 111

	else_stmt  goto 179


state 169
	for_stmt : FOR $$3 target IN expression_list . ':' suite else_stmt

	':'  shift 180


state 170
	url_stmt : URL '(' STRING ',' TIME . ')'

	')'  shift 181


state 171
	mail_stmt : MAIL '(' STRING ',' STRING . ',' STRING ',' STRING ')'
	mail_stmt : MAIL '(' STRING ',' STRING . ',' STRING ',' STRING ',' TIME ')'

	','  shift 182


state 172
	identifier_ : ',' IDENTIFIER identifier_ .  (98)

	.  reduce 98


state 173
	range_stmt : RANGE '(' expression ',' expression . ')'
	range_stmt : RANGE '(' expression ',' expression . ',' expression ')'

	')'  shift 183
	','  shift 184


state 174
	suite : NEWLINE INDENT . statement_ DEDENT

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	error  shift 6
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	IF  shift 18
	WHILE  shift 19
	FOR  shift 20
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	compound_stmt  goto 33
	if_stmt  goto 34
	while_stmt  goto 35
	for_stmt  goto 36
	statement  goto 185
	statement_  goto 186
	stmt_list  goto 38
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 175
	elif_stmt : ELIF . expression ':' suite elif_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 187
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 176
	if_stmt : IF $$1 expression ':' suite elif_stmt . else_stmt
	else_stmt : .  (111)

	ELSE  shift 178
	.  reduce 111

	else_stmt  goto 188


state 177
	suite : stmt_list NEWLINE .  (3)

	.  reduce 3


state 178
	else_stmt : ELSE . ':' suite

	':'  shift 189


state 179
	while_stmt : WHILE $$2 expression ':' suite else_stmt .  (113)

	.  reduce 113


state 180
	for_stmt : FOR $$3 target IN expression_list ':' . suite else_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	NEWLINE  shift 165
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	suite  goto 190
	stmt_list  goto 167
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 181
	url_stmt : URL '(' STRING ',' TIME ')' .  (121)

	.  reduce 121


state 182
	mail_stmt : MAIL '(' STRING ',' STRING ',' . STRING ',' STRING ')'
	mail_stmt : MAIL '(' STRING ',' STRING ',' . STRING ',' STRING ',' TIME ')'

	STRING  shift 191


state 183
	range_stmt : RANGE '(' expression ',' expression ')' .  (117)

	.  reduce 117


state 184
	range_stmt : RANGE '(' expression ',' expression ',' . expression ')'

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	target  goto 66
	range_stmt  goto 44
	len_stmt  goto 45
	expression  goto 192
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 185
	statement_ : statement . statement_
	statement_ : statement .  (6)

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	error  shift 6
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	IF  shift 18
	WHILE  shift 19
	FOR  shift 20
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31
	.  reduce 6

	compound_stmt  goto 33
	if_stmt  goto 34
	while_stmt  goto 35
	for_stmt  goto 36
	statement  goto 185
	statement_  goto 193
	stmt_list  goto 38
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 186
	suite : NEWLINE INDENT statement_ . DEDENT

	DEDENT  shift 194


state 187
	elif_stmt : ELIF expression . ':' suite elif_stmt

	':'  shift 195


state 188
	if_stmt : IF $$1 expression ':' suite elif_stmt else_stmt .  (107)

	.  reduce 107


state 189
	else_stmt : ELSE ':' . suite

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	NEWLINE  shift 165
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	suite  goto 196
	stmt_list  goto 167
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 190
	for_stmt : FOR $$3 target IN expression_list ':' suite . else_stmt
	else_stmt : .  (111)

	ELSE  shift 178
	.  reduce 111

	else_stmt  goto 197


state 191
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING . ',' STRING ')'
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING . ',' STRING ',' TIME ')'

	','  shift 198


state 192
	range_stmt : RANGE '(' expression ',' expression ',' expression . ')'

	')'  shift 199


state 193
	statement_ : statement statement_ .  (5)

	.  reduce 5


state 194
	suite : NEWLINE INDENT statement_ DEDENT .  (4)

	.  reduce 4


state 195
	elif_stmt : ELIF expression ':' . suite elif_stmt

	'('  shift 1
	'+'  shift 2
	'-'  shift 3
	'['  shift 4
	'~'  shift 5
	NEWLINE  shift 165
	IDENTIFIER  shift 7
	INTEGER  shift 8
	LONGINTEGER  shift 9
	STRING  shift 10
	TIME  shift 11
	SECOND  shift 12
	MINUTE  shift 13
	HOUR  shift 14
	DAY  shift 15
	MONTH  shift 16
	YEAR  shift 17
	PRINT  shift 21
	URL  shift 22
	MAIL  shift 23
	DEL  shift 24
	BREAK  shift 25
	CONTINUE  shift 26
	PASS  shift 27
	RETURN  shift 28
	RANGE  shift 29
	LEN  shift 30
	NOT  shift 31

	suite  goto 200
	stmt_list  goto 167
	simple_stmt  goto 39
	target  goto 40
	assignment_stmt  goto 41
	augmented_stmt  goto 42
	print_stmt  goto 43
	range_stmt  goto 44
	len_stmt  goto 45
	url_stmt  goto 46
	mail_stmt  goto 47
	return_stmt  goto 48
	del_stmt  goto 49
	expression_stmt  goto 50
	expression_list  goto 51
	expression  goto 52
	or_test  goto 53
	and_test  goto 54
	not_test  goto 55
	comparison  goto 56
	a_expr  goto 57
	m_expr  goto 58
	u_expr  goto 59
	power  goto 60
	primary  goto 61
	atom  goto 62
	subscription  goto 63
	enclosure  goto 64
	literal  goto 65


state 196
	else_stmt : ELSE ':' suite .  (110)

	.  reduce 110


state 197
	for_stmt : FOR $$3 target IN expression_list ':' suite else_stmt .  (115)

	.  reduce 115


state 198
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' . STRING ')'
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' . STRING ',' TIME ')'

	STRING  shift 201


state 199
	range_stmt : RANGE '(' expression ',' expression ',' expression ')' .  (118)

	.  reduce 118


state 200
	elif_stmt : ELIF expression ':' suite . elif_stmt
	elif_stmt : .  (109)

	ELIF  shift 175
	.  reduce 109

	elif_stmt  goto 202


state 201
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING . ')'
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING . ',' TIME ')'

	')'  shift 203
	','  shift 204


state 202
	elif_stmt : ELIF expression ':' suite elif_stmt .  (108)

	.  reduce 108


state 203
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING ')' .  (122)

	.  reduce 122


state 204
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING ',' . TIME ')'

	TIME  shift 205


state 205
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING ',' TIME . ')'

	')'  shift 206


state 206
	mail_stmt : MAIL '(' STRING ',' STRING ',' STRING ',' STRING ',' TIME ')' .  (123)

	.  reduce 123


Symbols never pushed
	assignment_stmt  (30)
	assignment_stmt_  (31)
	augmented_stmt  (32)
	print_stmt  (37)
	range_stmt  (48)
	len_stmt  (49)
	expression_stmt  (8)
	expression_list  (9)
	expression  (11)
	expression_  (10)
	or_test  (12)
	subscription  (25)
	OR  (65537)
	AND  (65538)


##############################################################################
# Summary
##############################################################################

64 token(s), 52 nonterminal(s)
124 grammar rule(s), 219 state(s)


##############################################################################
# End of File
##############################################################################
