
package com.pyme.execute;

import com.pyme.Py;
import java.util.Date;
import java.util.Calendar;

public class MailThread implements Runnable {

  private Py main;
  private String mail;
  private String time;
  private String date;
  private int shour;
  private int sminute;
  private int ssecond;

  public MailThread(Py main, String mail, String timeDate) {
    this.main = main;
    this.mail = mail;

    time = timeDate.substring(1, timeDate.indexOf("|"));
    System.out.println(time);
    date = timeDate.substring(timeDate.indexOf("|") + 1, timeDate.length() - 1);
    System.out.println(date);
    System.out.println("[" + time + "|" + date + "]");

    int i1 = time.indexOf(":");
    shour = Integer.parseInt(time.substring(0, i1));
    System.out.println(shour + " hr");

    time = new String(time.substring(i1 + 1, time.length()));
    i1 = time.indexOf(":");
    sminute = Integer.parseInt(time.substring(0, i1));
    System.out.println(sminute + " min");

    ssecond = Integer.parseInt(time.substring(i1 + 1, time.length()));
    System.out.println(ssecond + " sec");
  }

  public void run () {
    while (true) {
      Date date = new Date();
      Calendar currentTime = Calendar.getInstance();
      currentTime.setTime(date);
      String year = String.valueOf(currentTime.get(Calendar.YEAR));
      String mount = String.valueOf(currentTime.get(Calendar.MONTH));
      String day = String.valueOf(currentTime.get(Calendar.DAY_OF_MONTH));
      String hour = String.valueOf(currentTime.get(Calendar.HOUR));
      String minute = String.valueOf(currentTime.get(Calendar.MINUTE));
      String second = String.valueOf(currentTime.get(Calendar.SECOND));

      int mt = Integer.parseInt(mount)+1;
      int hr = Integer.parseInt(hour)+7;
      System.out.println("[" + hr + ":" + minute + ":" + second + "|" + day + "/" + mt + "/" + year + "]");

      String currentDate = day + "/" + mt + "/" + year;

      if (!currentDate.trim().equals(date)) {
        System.out.println("date");
        if (hr >= shour) {
          System.out.println("hour");
          if (Integer.parseInt(minute) >= sminute) {
            System.out.println("minute");
            if (Integer.parseInt(second) >= ssecond) {
               main.pyEvent(Py.SENDMAIL, mail);
               System.out.println("SendMail");
               break;
            }
          }
        }
      }
      try { Thread.sleep(1000); } catch (Exception e) { System.out.println("exception"); };
    }
  }
}



