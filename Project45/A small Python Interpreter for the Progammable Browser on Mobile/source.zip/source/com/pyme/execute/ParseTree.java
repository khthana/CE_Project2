package com.pyme.execute;

import java.io.*;

public class ParseTree {
  public static final int NULL = -1;
  public static final int ASSIGN = 0;
  public static final int ADDASSIGN = 10;
  public static final int SUBASSIGN = 11;
  public static final int MULASSIGN = 12;
  public static final int DIVASSIGN = 13;
  public static final int POWASSIGN = 32;
  public static final int MODASSIGN = 33;

  public static final int ADD = 3;
  public static final int SUB = 4;
  public static final int MUL = 5;
  public static final int DIV = 6;
  public static final int DIV2 = 30;
  public static final int MOD = 31;
//  public static final int UNARY = 7;
  public static final int POW = 7;
  public static final int PAREN = 8;

  public static final int STMT = 14;
  public static final int EXPRLIST = 33;
//  public static final int TARGLIST = 34;
  public static final int SUBSCRIPT = 35;

  // compound
  public static final int IF = 15;
  public static final int ELIF = 29;
  public static final int WHILE = 32;
  public static final int FOR = 36;
  public static final int TRYEXC = 37;
  public static final int TRYFIN = 38;

  // built-in function
  public static final int PRINT = 9;
  public static final int DELETE = 39;
  public static final int RETURN = 40;
  public static final int GLOBAL = 41;
  public static final int URL = 45;
  public static final int MAIL = 48;
  public static final int RANGE = 46;
  public static final int LEN = 47;

  // define fuction
  public static final int FUNCDEF = 42;
  public static final int PARAMLIST = 43;
  public static final int IDENLIST = 44;

  // condition
  public static final int EQU = 16;
  public static final int GT = 17;
  public static final int LT = 18;
  public static final int GTE = 19;
  public static final int LTE = 20;
  public static final int NE = 21;
  public static final int AND = 22;
  public static final int OR = 23;
  public static final int NOT = 24;
  public static final int IS = 25;
  public static final int ISNOT = 26;
  public static final int IN = 27;
  public static final int NOTIN = 28;


  public static final int ROOT = 0;
  public static final int LEFT = 1;
  public static final int RIGHT = 2;
  public static final int CENTER = 3;

  private int root;
  // simple tree
  private SymbolValue left;
  private SymbolValue right;

  // if tree
  private SymbolValue center;
  // stmt tree

  public ParseTree() {
    root = NULL;
    left = null;
    right = null;

    center = null;
  }

  public ParseTree (int root, SymbolValue left, SymbolValue right, SymbolValue center) {  // conpound tree
    this.root = root;
    this.left = left;
    this.right = right;
    this.center = center;
  }

  public ParseTree (int root, SymbolValue left, SymbolValue right) {  // simple tree
    this.root = root;
    this.left = left;
    this.right = right;
    this.center = null;
  }

  public SymbolValue getChild(int LRC) {
    // simple tree
    if (LRC == LEFT) return left;
    else if (LRC == RIGHT) return right;
    // compound tree
    else if (LRC == CENTER) return center;
    return null;
  }

  public int getRoot() {
    return root;
  }
/*
  public ParseTree cloning() {
    ParseTree tBuff = new ParseTree();
    tBuff.addTree(root, left, right);
    return tBuff;
  }
*/
}