package com.pyme.execute;

public class SymbolValue {
  public static final int NULL = -1;

  public static final int TREE = 0;
  public static final int IDENTIFIER = 1;
  public static final int INTEGER = 2;
  public static final int LONGINTEGER = 3;
//  public static final int FLOATNUMBER = 4;
  public static final int STRING = 5;
  public static final int TIME = 13;
//  public static final int DATE = 14;

  public static final int SECOND = 14;
  public static final int MINUTE = 15;
  public static final int HOUR = 16;
  public static final int DAY = 17;
  public static final int MONTH = 18;
  public static final int YEAR = 19;

  public static final int BREAK = 6;
  public static final int CONTINUE = 7;
  public static final int PASS = 8;

  public static final int BOOLEAN = 9;

  public static final int STAR1 = 10;
  public static final int STAR2 = 11;

  public static final int EXPRLIST = 12;

  public static final int ERROR = 20;

  public int type;
  public Object value = null;

  public SymbolValue () {
    type = NULL;
  }

  public SymbolValue (int type) {
    this.type = type;
  }

  public SymbolValue (SymbolValue symValue) {
    if (symValue == null)
      type = NULL;
    else
      type = symValue.type;

    switch (type) {
      case IDENTIFIER :
      case STRING :
      case TIME :
        value = new String((String) symValue.value);
        break;
      case INTEGER :
      case SECOND :
      case MINUTE :
      case HOUR :
      case DAY :
      case MONTH :
      case YEAR :
        value = new Integer(Integer.parseInt(((Integer) symValue.value).toString()));
        break;
      case LONGINTEGER :
        value = new Long(Long.parseLong(((Long) symValue.value).toString()));
        break;
      case BOOLEAN :
        try {
          value = new Long(Long.parseLong(((Long) symValue.value).toString()));
        } catch (Exception e) {
          value = new String((String) symValue.value);
        }
        break;
    }
  }

  public SymbolValue (Object value, int type) {
    this.type = type;
    this.value = value;
  }

}
