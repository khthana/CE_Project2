package com.pyme.execute;

import java.util.Hashtable;

public class SymbolTable extends Hashtable {
  private SymbolTable lowLevelSymbolTable;
  private int level;

  public SymbolTable () {   // public constructor
    super();
    level = 0;
    lowLevelSymbolTable = null;
  }

  private SymbolTable(int level) {   // private construtor
    super();
    this.level = level + 1; // lowwer level
  }

  public int createTable () {
    if (lowLevelSymbolTable != null)
      lowLevelSymbolTable.createTable();

    lowLevelSymbolTable = new SymbolTable(level);
    return level + 1;
  }

  public SymbolValue getValue (String name) {
    SymbolValue tmp = null;
    if (lowLevelSymbolTable != null)    // lowLevelSymbolTable has created.
      tmp = (SymbolValue) lowLevelSymbolTable.getValue(name);   // Go down.

    if (tmp == null)   // The name hasn't found in lowLevel.
      return (SymbolValue) get(name);   // Try to find in this level and return getting value.
    else
      return tmp;     // The name has found in lowLevel.
  }

  public boolean addValue (int level, String name, SymbolValue value) {
    if ((this.level < level) && (lowLevelSymbolTable != null))
      lowLevelSymbolTable.addValue(level, name, value);

    if (this.level == level) {
      put(name, value);
      return true;
    } else
      return false;
  }
}
