
package com.pyme.execute;

import com.pyme.Py;
import com.pyme.lexyacc.SimPyParser;

import java.util.Vector;
import java.util.Enumeration;

public class SimPyExec {
  private SymbolTable symTable;
  private Py main;
  private int level;
//  private SimPyParser pyParse;

  public SimPyExec () {
    symTable = new SymbolTable();
  }

  public SimPyExec(SymbolValue symValue, Py main, SimPyParser pyParse) {
    this.main = main;

    if (symValue != null) {
        this.symTable = main.getTable();
        SymbolValue result = execution(symValue);
        if (result.type == SymbolValue.ERROR) {
          System.out.println("Program have an error");
          pyParse.execError();
        }
    }
    else {
      main.pyEvent(Py.STDOUT, "SyntaxError : invalid syntax");
    }
  }


  public SymbolValue execution (SymbolValue symValue) {
    if (symValue == null)
      return new SymbolValue(SymbolValue.ERROR);

    switch (symValue.type) {
      case SymbolValue.TREE :
        ParseTree pTree = (ParseTree) symValue.value;
        switch (pTree.getRoot()) {
          case ParseTree.ASSIGN : {
            String id = (String) (pTree.getChild(ParseTree.LEFT)).value;
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return assign(id, R);
          }
          case ParseTree.ADD : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return calculating(ParseTree.ADD, L, R);
          }
          case ParseTree.SUB : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return calculating(ParseTree.SUB, L, R);
          }
          case ParseTree.MUL : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return calculating(ParseTree.MUL, L, R);
          }
          case ParseTree.DIV : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return calculating(ParseTree.DIV, L, R);
          }
          case ParseTree.MOD : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return calculating(ParseTree.MOD, L, R);
          }
          case ParseTree.POW : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return calculating(ParseTree.POW, L, R);
          }
          case ParseTree.ADDASSIGN : {
            String id = (String) (pTree.getChild(ParseTree.LEFT)).value;
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return assign(id, calculating(ParseTree.ADD, new SymbolValue(id, SymbolValue.IDENTIFIER), R));
          }
          case ParseTree.SUBASSIGN : {
            String id = (String) (pTree.getChild(ParseTree.LEFT)).value;
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return assign(id, calculating(ParseTree.SUB, new SymbolValue(id, SymbolValue.IDENTIFIER), R));
          }
          case ParseTree.MULASSIGN : {
            String id = (String) (pTree.getChild(ParseTree.LEFT)).value;
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return assign(id, calculating(ParseTree.MUL, new SymbolValue(id, SymbolValue.IDENTIFIER), R));
          }
          case ParseTree.DIVASSIGN : {
            String id = (String) (pTree.getChild(ParseTree.LEFT)).value;
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            return assign(id, calculating(ParseTree.DIV, new SymbolValue(id, SymbolValue.IDENTIFIER), R));
          }
          case ParseTree.PRINT : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            return println(L);
          }
          case ParseTree.IF : {
            boolean bool;
            SymbolValue tmp = pTree.getChild(ParseTree.CENTER);
            SymbolValue bl;
            switch (tmp.type) {
              case SymbolValue.TREE :
                ParseTree tmp1 = (ParseTree) tmp.value;
                switch (tmp1.getRoot()) {
                  case ParseTree.EQU :
                  case ParseTree.GT :
                  case ParseTree.LT :
                  case ParseTree.GTE :
                  case ParseTree.LTE :
                  case ParseTree.NE :
                  case ParseTree.AND :
                  case ParseTree.OR :
                  case ParseTree.NOT :
                  case ParseTree.IS :
                  case ParseTree.ISNOT :
                  case ParseTree.IN :
                  case ParseTree.NOTIN :
                    bl = test(tmp1);
                    if (bl.type == SymbolValue.ERROR)
                      return bl;
                    bool = testBl(bl);
                    break;
                  default :
                    bl = execution(tmp);
                    if (bl.type == SymbolValue.ERROR)
                      return bl;
                    bool = testBl(bl);
                }
                break;
              case SymbolValue.IDENTIFIER :
                SymbolValue L = symTable.getValue((String) tmp.value);
                if (L == null) {
                  main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + tmp.value + "'");
                  return new SymbolValue(SymbolValue.ERROR);
                }
                if (L.type == SymbolValue.INTEGER)
                  L.value = new Long(Long.parseLong(((Integer) L.value).toString()));
                bool = testBl(L);
                break;
              case SymbolValue.INTEGER :
                tmp.value = new Long(Long.parseLong(((Integer) tmp.value).toString()));
              case SymbolValue.LONGINTEGER :
                bool = testBl(tmp);
                break;
              default : bool = false;
            }
            if (bool)
              return execution(pTree.getChild(ParseTree.LEFT));
            else {
              if (pTree.getChild(ParseTree.RIGHT) == null)
                return new SymbolValue();
              return execution(pTree.getChild(ParseTree.RIGHT));
            }
          }
          case ParseTree.ELIF : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));

            if (L.type == SymbolValue.NULL)
              return execution(pTree.getChild(ParseTree.RIGHT));
            else
              return L;
          }
          case ParseTree.STMT : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));

            if (L == null)
              ;
            else if (L.type == SymbolValue.ERROR)
              return L;
            else if (L.type == SymbolValue.BREAK)
              return L;
            else if (L.type == SymbolValue.CONTINUE)
              return L;

            SymbolValue R = pTree.getChild(ParseTree.RIGHT);
            if (R != null)
              return execution(R);

            return L;
          }
          case ParseTree.WHILE : {
            SymbolValue result;
            while (testBl(test((ParseTree) (pTree.getChild(ParseTree.CENTER).value)))) {
              result = execution(pTree.getChild(ParseTree.LEFT));

              if (result == null)
                ;
              else if (result.type == SymbolValue.ERROR)
                return result;
              else if (result.type == SymbolValue.BREAK)
                return new SymbolValue();
            }
            if (pTree.getChild(ParseTree.RIGHT) != null)
              return execution(pTree.getChild(ParseTree.RIGHT));
            else
              return new SymbolValue();
          }
          case ParseTree.EQU :
          case ParseTree.GT :
          case ParseTree.LT :
          case ParseTree.GTE :
          case ParseTree.LTE :
          case ParseTree.NE :
          case ParseTree.AND :
          case ParseTree.OR :
          case ParseTree.NOT :
            return test(pTree);
          case ParseTree.EXPRLIST : {
            Vector v = new Vector(1, 1);
            SymbolValue sv = makeList(pTree, v);
            if(sv.type != SymbolValue.ERROR)
              return new SymbolValue(v, SymbolValue.EXPRLIST);
            else
              return sv;
          }
          case ParseTree.SUBSCRIPT : {
            SymbolValue L = pTree.getChild(ParseTree.LEFT);
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));
            SymbolValue tmp = symTable.getValue((String) L.value);
            if (tmp == null) {
              main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + L.value + "'");
              return new SymbolValue(SymbolValue.ERROR);
            }
            L = tmp;
            switch (R.type) {
              case SymbolValue.INTEGER :
                if ((((Integer) R.value).intValue()) < (((Vector) L.value).size()))
                  return (SymbolValue) ((Vector) L.value).elementAt(((Integer) R.value).intValue());
                else {
                  main.pyEvent(Py.STDOUT, "IndexError: list index out of range");
                  return new SymbolValue(SymbolValue.ERROR);
                }
              case SymbolValue.LONGINTEGER :
                if ((((Long) R.value).longValue()) < (((Vector) L.value).size()))
                  return (SymbolValue) ((Vector) L.value).elementAt(Integer.parseInt(("" + (Long) R.value)));
                else
                  main.pyEvent(Py.STDOUT, "IndexError: list index out of range");
                  return new SymbolValue(SymbolValue.ERROR);
              default : return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case ParseTree.IN : {
            SymbolValue L = pTree.getChild(ParseTree.LEFT);
            SymbolValue R = execution(pTree.getChild(ParseTree.RIGHT));

            if (R.type == SymbolValue.ERROR)
              return R;

            SymbolValue tmp;
            if (L.type == SymbolValue.IDENTIFIER) {
                tmp = symTable.getValue((String) L.value);
                if (tmp == null) {
                  main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + L.value + "'");
                  return new SymbolValue(SymbolValue.ERROR);
                }
                L = tmp;
            }

            if (R.type == SymbolValue.IDENTIFIER) {
              tmp = symTable.getValue((String) R.value);
              if (tmp == null) {
                main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + R.value + "'");
                return new SymbolValue(SymbolValue.ERROR);
              }
              R = tmp;
            }

            Enumeration enum = ((Vector) R.value).elements();
            while (enum.hasMoreElements()) {
              ParseTree pTest = new ParseTree(ParseTree.EQU, L, (SymbolValue) enum.nextElement());
              SymbolValue bl = test(pTest);
              if (((Long) bl.value).longValue() > 0)
                return getSymBoolean(true);
            }
            return getSymBoolean(false);
          }
          case ParseTree.NOTIN : {
            SymbolValue L = pTree.getChild(ParseTree.LEFT);
            SymbolValue R = pTree.getChild(ParseTree.RIGHT);

            SymbolValue tmp;
            if (L.type == SymbolValue.IDENTIFIER) {
                tmp = symTable.getValue((String) L.value);
                if (tmp == null) {
                  main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + L.value + "'");
                  return new SymbolValue(SymbolValue.ERROR);
                }
                L = tmp;
            }

            tmp = symTable.getValue((String) R.value);
            if (tmp == null) {
              main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + R.value + "'");
              return new SymbolValue(SymbolValue.ERROR);
            }
            R = tmp;

            Enumeration enum = ((Vector) R.value).elements();
            while (enum.hasMoreElements()) {
              ParseTree pTest = new ParseTree(ParseTree.EQU, L, (SymbolValue) enum.nextElement());
              SymbolValue bl = test(pTest);
              if (((Long) bl.value).longValue() > 0)
                return getSymBoolean(false);
            }
            return getSymBoolean(true);
          }
          case ParseTree.IS : {

            break;
          }
          case ParseTree.ISNOT : {

            break;
          }
          case ParseTree.RANGE : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            SymbolValue R = execution(pTree.getChild(ParseTree.CENTER));
            SymbolValue C = execution(pTree.getChild(ParseTree.RIGHT));

            if (C.type == SymbolValue.ERROR && R.type == SymbolValue.ERROR) {
              int upper = ((Integer) L.value).intValue();
              Vector v = new Vector(1, 1);
              for (int i = 0; i < upper; i++)
                v.addElement(new SymbolValue(new Integer(i), SymbolValue.INTEGER));
              return new SymbolValue(v, SymbolValue.EXPRLIST);
            } else if (R.type == SymbolValue.ERROR) {
              int lower = ((Integer) L.value).intValue();
              int upper = ((Integer) C.value).intValue();
              Vector v = new Vector(1, 1);
              if (lower < upper) {
                for (int i = lower; i < upper; i++)
                  v.addElement(new SymbolValue(new Integer(i), SymbolValue.INTEGER));
                return new SymbolValue(v, SymbolValue.EXPRLIST);
              } else if (lower == upper) {
                return new SymbolValue(v, SymbolValue.EXPRLIST);
              } else {
                for (int i = lower; i > upper; i--)
                  v.addElement(new SymbolValue(new Integer(i), SymbolValue.INTEGER));
                return new SymbolValue(v, SymbolValue.EXPRLIST);
              }
            } else {
              int lower = ((Integer) L.value).intValue();
              int upper = ((Integer) C.value).intValue();
              int step = ((Integer) R.value).intValue();
              Vector v = new Vector(1, 1);
              if (lower < upper) {
                if (step < 1)
                  return new SymbolValue(v, SymbolValue.EXPRLIST);
                for (int i = lower; i < upper; i += step)
                  v.addElement(new SymbolValue(new Integer(i), SymbolValue.INTEGER));
                return new SymbolValue(v, SymbolValue.EXPRLIST);
              } else if (lower == upper) {
                return new SymbolValue(v, SymbolValue.EXPRLIST);
              } else {
                if (step > -1)
                  return new SymbolValue(v, SymbolValue.EXPRLIST);
                for (int i = lower; i > upper; i += step)
                  v.addElement(new SymbolValue(new Integer(i), SymbolValue.INTEGER));
                return new SymbolValue(v, SymbolValue.EXPRLIST);
              }
            }
          }
          case ParseTree.LEN : {
            SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
            switch (L.type) {
              case SymbolValue.STRING :
                return new SymbolValue(new Integer(((String) L.value).length()), SymbolValue.INTEGER);
              case SymbolValue.EXPRLIST :
                return new SymbolValue(new Integer(((Vector) L.value).size()) , SymbolValue.INTEGER);
            }
          }
          case ParseTree.FOR : {
              SymbolValue target = ((ParseTree) pTree.getChild(ParseTree.CENTER).value).getChild(ParseTree.LEFT);
              Vector list = (Vector) execution(((ParseTree) pTree.getChild(ParseTree.CENTER).value).getChild(ParseTree.RIGHT)).value;
              Enumeration enum = list.elements();
              SymbolValue result = new SymbolValue();
              while (enum.hasMoreElements()) {
                symTable.addValue(level, (String) target.value, (SymbolValue) enum.nextElement());
                result = execution(pTree.getChild(ParseTree.LEFT));

                if (result == null)
                  ;
                else if (result.type == SymbolValue.ERROR)
                  return result;
                else if (result.type == SymbolValue.BREAK)
                  return new SymbolValue();
              }
              if (pTree.getChild(ParseTree.RIGHT) != null)
                return execution(pTree.getChild(ParseTree.RIGHT));
              else
                return new SymbolValue();
          }
          case ParseTree.DELETE : {
            SymbolValue id = pTree.getChild(ParseTree.LEFT);
            symTable.remove((String) id.value);
            return new SymbolValue();
          }
          case ParseTree.URL : {
            if (pTree.getChild(ParseTree.RIGHT) == null)
              main.pyEvent(Py.OPENURL, (String) pTree.getChild(ParseTree.LEFT).value);
            else {
              TimeThread t = new TimeThread(main, (String) pTree.getChild(ParseTree.LEFT).value
                                                , (String) pTree.getChild(ParseTree.RIGHT).value);
              (new Thread(t)).start();
            }
            return new SymbolValue();
          }
          case ParseTree.MAIL : {
            if (pTree.getChild(ParseTree.RIGHT) == null)
              main.pyEvent(Py.SENDMAIL, (String) pTree.getChild(ParseTree.LEFT).value);
            else {
              MailThread t = new MailThread(main, (String) pTree.getChild(ParseTree.LEFT).value
                                                , (String) pTree.getChild(ParseTree.RIGHT).value);
              (new Thread(t)).start();
            }
            return new SymbolValue();
          }
      }
      case SymbolValue.IDENTIFIER :
      case SymbolValue.INTEGER :
      case SymbolValue.LONGINTEGER :
      case SymbolValue.STRING :
      case SymbolValue.EXPRLIST :
      case SymbolValue.SECOND :
      case SymbolValue.MINUTE :
      case SymbolValue.HOUR :
      case SymbolValue.DAY :
      case SymbolValue.MONTH :
      case SymbolValue.YEAR :
      case SymbolValue.TIME :
        return symValue;
      case SymbolValue.BREAK :
        return new SymbolValue(SymbolValue.BREAK);
      case SymbolValue.CONTINUE :
        return new SymbolValue(SymbolValue.CONTINUE);
      case SymbolValue.PASS :
        return new SymbolValue(SymbolValue.PASS);
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }


  private SymbolValue makeList (ParseTree pTree, Vector v) {
    SymbolValue L = execution(pTree.getChild(ParseTree.LEFT));
    if (L.type != SymbolValue.ERROR)
      v.addElement(L);
    else
      return L;

    if (pTree.getChild(ParseTree.RIGHT) != null)
      makeList((ParseTree) pTree.getChild(ParseTree.RIGHT).value, v);

    return new SymbolValue();
  }


  private boolean testBl (SymbolValue C) {
    switch (C.type) {
      case SymbolValue.BOOLEAN :
      case SymbolValue.LONGINTEGER :
        try {
          if (((Long) C.value).longValue() == 0)
            return false;
          else
            return true;
        } catch (Exception e) {
          return true;
        }
      case SymbolValue.INTEGER :
        try {
          if (((Integer) C.value).intValue() == 0)
            return false;
          else
            return true;
        } catch (Exception e) {
          return true;
        }
      default :
        return false;
    }
  }


  private SymbolValue test (ParseTree C) {
    int test = C.getRoot();
    SymbolValue valueL = new SymbolValue(execution((SymbolValue) C.getChild(ParseTree.LEFT)));
    SymbolValue valueR = new SymbolValue(execution((SymbolValue) C.getChild(ParseTree.RIGHT)));

    SymbolValue L, R;
    if (valueL.type == SymbolValue.IDENTIFIER) {
      L = symTable.getValue((String) valueL.value);
      if (L == null) {
        main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + valueL.value + "'");
        return new SymbolValue(SymbolValue.ERROR);
      }
      valueL = new SymbolValue(L);
    }

    if (valueR.type == SymbolValue.IDENTIFIER) {
      R = symTable.getValue((String) valueR.value);
      if (R == null) {
        main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + valueR.value + "'");
        return new SymbolValue(SymbolValue.ERROR);
      }
      valueR = new SymbolValue(R);
    }

    switch (valueL.type) {
       case SymbolValue.STRING :
         switch (valueR.type) {
           case SymbolValue.INTEGER :
           case SymbolValue.LONGINTEGER :
             return getSymBoolean(false);
           case SymbolValue.STRING :
           case SymbolValue.BOOLEAN :
             switch (test) {
               case ParseTree.EQU :
                 try  {
                   if (((String) valueL.value).equals((String) valueR.value)) {
                     return new SymbolValue(new String((String) valueL.value), SymbolValue.BOOLEAN);
                   }
                   else
                     return getSymBoolean(false);
                 } catch (Exception e) {
                   return getSymBoolean(false);
                 }
               default :
                   return getSymBoolean(false);
             }
         }
       case SymbolValue.INTEGER :
//         valueL.type = SymbolValue.LONGINTEGER;
         valueL.value = new Long(Long.parseLong(((Integer) valueL.value).toString()));
         break;
       case SymbolValue.BOOLEAN :
         try {
           if (((Long) valueR.value).longValue() == 0)
             valueR.value = new Long(0);
           else
             valueR.value = new Long(1);
         } catch (Exception e) {
           valueR.value = new Long(1);
         }
         break;
       case SymbolValue.LONGINTEGER :
         break;
       default :
         return new SymbolValue(SymbolValue.ERROR);
     }

     switch (valueR.type) {
       case SymbolValue.STRING :
         return getSymBoolean(false);
       case SymbolValue.INTEGER :
         valueR.value = new Long(Long.parseLong(((Integer) valueR.value).toString()));
         break;
       case SymbolValue.BOOLEAN :
         try {
           if (((Long) valueR.value).longValue() == 0)
             valueR.value = new Long(0);
           else
             valueR.value = new Long(1);
         } catch (Exception e) {
           valueR.value = new Long(1);
         }
         break;
       case SymbolValue.LONGINTEGER :
         break;
     }

     switch (test) {
       case ParseTree.EQU :
         if (((Long) valueL.value).longValue() == ((Long) valueR.value).longValue()) {
           valueL.type = SymbolValue.BOOLEAN;
           return new SymbolValue(valueL);
         }
         else
           return getSymBoolean(false);
       case ParseTree.GT :
         if (((Long) valueL.value).longValue() > ((Long) valueR.value).longValue())
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.LT :
         if (((Long) valueL.value).longValue() < ((Long) valueR.value).longValue())
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.GTE :
         if (((Long) valueL.value).longValue() >= ((Long) valueR.value).longValue())
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.LTE :
         if (((Long) valueL.value).longValue() <= ((Long) valueR.value).longValue())
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.NE :
         if (((Long) valueL.value).longValue() != ((Long) valueR.value).longValue())
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.AND :
         if ((((Long) valueL.value).longValue() > 0) && (((Long) valueR.value).longValue() > 0))
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.OR :
         if ((((Long) valueL.value).longValue() > 0) || (((Long) valueR.value).longValue() > 0))
           return getSymBoolean(true);
         else
           return getSymBoolean(false);
       case ParseTree.NOT :
         if (((Long) valueL.value).longValue() > 0)
           return getSymBoolean(false);
         else
           return getSymBoolean(true);
       default :
           return getSymBoolean(false);
     }
  }


  private SymbolValue getSymBoolean (boolean bl) {
    if (bl)
      return new SymbolValue(new Long(1), SymbolValue.BOOLEAN);
    else
      return new SymbolValue(new Long(0), SymbolValue.BOOLEAN);
  }


  private SymbolValue println (SymbolValue symValue) {
    if (symValue == null)
      return new SymbolValue(SymbolValue.ERROR);

    SymbolValue L;
    switch (symValue.type) {
      case SymbolValue.IDENTIFIER :
        L = symTable.getValue((String) symValue.value);
        if (L == null) {
          main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + symValue.value + "'");
          return new SymbolValue(SymbolValue.ERROR);
        }
        symValue = L;
        break;
      case SymbolValue.BOOLEAN :
        try {
         if (((Long) symValue.value).longValue() == 0)
           symValue.value = new Long(0);
         else
           symValue.value = new Long(1);
        } catch (Exception e) {
          symValue.value = new Long(1);
        }
        break;
      case SymbolValue.EXPRLIST :
        Enumeration enum = ((Vector) symValue.value).elements();
        Vector tmp = new Vector();
        while (enum.hasMoreElements()) {
          SymbolValue sym = (SymbolValue) enum.nextElement();

          if (sym.type != SymbolValue.IDENTIFIER) {
            tmp.addElement(sym);
            continue;
          }

          L = symTable.getValue((String) sym.value);
          if (L == null) {
            main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + symValue.value + "'");
            return new SymbolValue(SymbolValue.ERROR);
          }

          tmp.addElement(L);
        }
        symValue.value = tmp;
    }

    switch (symValue.type) {
      case SymbolValue.INTEGER : main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value); break;
      case SymbolValue.LONGINTEGER : main.pyEvent(Py.STDOUT, "" + (Long) symValue.value + "L"); break;
      case SymbolValue.BOOLEAN : main.pyEvent(Py.STDOUT, "" + (Long) symValue.value); break;
      case SymbolValue.STRING : main.pyEvent(Py.STDOUT, (String) symValue.value); break;
      case SymbolValue.SECOND :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " second"); break;
      case SymbolValue.MINUTE :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " minute"); break;
      case SymbolValue.HOUR :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " hour"); break;
      case SymbolValue.DAY :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " day"); break;
      case SymbolValue.MONTH :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " mouth"); break;
      case SymbolValue.YEAR :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " year"); break;
      case SymbolValue.TIME :   main.pyEvent(Py.STDOUT, "" + (String) symValue.value); break;
      case SymbolValue.EXPRLIST :
        Enumeration enum = ((Vector) symValue.value).elements();
        String tmp = new String("[");
        if (enum.hasMoreElements()) {
          SymbolValue element = (SymbolValue) enum.nextElement();
          switch (element.type) {
            case SymbolValue.INTEGER : tmp += (Integer) element.value; break;
            case SymbolValue.LONGINTEGER : tmp += (Long) element.value; break;
            case SymbolValue.STRING : tmp += (String) element.value; break;
            case SymbolValue.SECOND :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " second"); break;
            case SymbolValue.MINUTE :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " minute"); break;
            case SymbolValue.HOUR :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " hour"); break;
            case SymbolValue.DAY :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " day"); break;
            case SymbolValue.MONTH :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " mouth"); break;
            case SymbolValue.YEAR :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " year"); break;
          }
          while (enum.hasMoreElements()) {
            tmp += ",";
            element = (SymbolValue) enum.nextElement();
            switch (element.type) {
              case SymbolValue.INTEGER : tmp += (Integer) element.value; break;
              case SymbolValue.LONGINTEGER : tmp += (Long) element.value; break;
              case SymbolValue.STRING : tmp += (String) element.value; break;
              case SymbolValue.SECOND :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " second"); break;
              case SymbolValue.MINUTE :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " minute"); break;
              case SymbolValue.HOUR :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " hour"); break;
              case SymbolValue.DAY :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " day"); break;
              case SymbolValue.MONTH :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " mouth"); break;
              case SymbolValue.YEAR :   main.pyEvent(Py.STDOUT, "" + (Integer) symValue.value + " year"); break;
            }
          }
        }
        tmp += "]";
        main.pyEvent(Py.STDOUT, tmp);
        break;
    }

    return symValue;
  }


  private SymbolValue assign (String id, SymbolValue symValue) {
    if (symValue == null)
      return new SymbolValue(SymbolValue.ERROR);

    switch (symValue.type) {
      case SymbolValue.BOOLEAN :
        try {
          if (((Long) symValue.value).longValue() == 0)
            symValue.value = new Long(0);
          else
            symValue.value = new Long(1);
        } catch (Exception e) {
          symValue.value = new Long(1);
        }
        break;
      case SymbolValue.IDENTIFIER :
        SymbolValue L;
        L = symTable.getValue((String) symValue.value);
        if (L == null) {
          main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + symValue.value + "'");
          return new SymbolValue(SymbolValue.ERROR);
        }
        symValue = L;
        break;
    }

    symTable.addValue(level, id, symValue);
    return symValue;
  }


  private SymbolValue calculating (int oper, SymbolValue valueL, SymbolValue valueR) {
    SymbolValue L = new SymbolValue();
    SymbolValue R = new SymbolValue();
    if (valueL.type == SymbolValue.IDENTIFIER) {
      L = symTable.getValue((String) valueL.value);
      if (L == null) {
        main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + valueL.value + "'");
        return new SymbolValue(SymbolValue.ERROR);
      }
      valueL = L;
    }

    if (valueR.type == SymbolValue.IDENTIFIER) {
      R = symTable.getValue((String) valueR.value);
      if (R == null) {
        main.pyEvent(Py.STDOUT, "NameError: There is no variable named '" + valueR.value + "'");
        return new SymbolValue(SymbolValue.ERROR);
      }
      valueR = R;
    }

    if (valueL.type == SymbolValue.BOOLEAN)
      try {
         if (((Long) valueL.value).longValue() == 0)
           valueL.value = new Integer(0);
      else
           valueL.value = new Integer(1);
      } catch (Exception e) {
          valueL.value = new Integer(1);
      }
    if (valueR.type == SymbolValue.BOOLEAN)
      try {
        if (((Long) valueR.value).longValue() == 0)
          valueR.value = new Integer(0);
        else
          valueR.value = new Integer(1);
      } catch (Exception e) {
        valueR.value = new Integer(1);
      }

      SymbolValue tmp;
      switch (valueL.type) {
        case SymbolValue.INTEGER :
        case SymbolValue.BOOLEAN :
          switch (valueR.type) {
            case SymbolValue.INTEGER :
            case SymbolValue.BOOLEAN :
              return calculate(oper, (Integer) valueL.value, (Integer) valueR.value);
            case SymbolValue.LONGINTEGER :
              return calculate(oper, (Integer) valueL.value, (Long) valueR.value);
            case SymbolValue.STRING :
            case SymbolValue.SECOND :
            case SymbolValue.MINUTE :
            case SymbolValue.HOUR :
            case SymbolValue.DAY :
            case SymbolValue.MONTH :
            case SymbolValue.YEAR :
            case SymbolValue.TIME :
              main.pyEvent(Py.STDOUT, "TypeError: number coercion failed");
              return new SymbolValue(SymbolValue.ERROR);
          }
        case SymbolValue.LONGINTEGER :
          switch (valueR.type) {
            case SymbolValue.INTEGER :
            case SymbolValue.BOOLEAN :
              return calculate(oper, (Long) valueL.value, (Integer) valueR.value);
            case SymbolValue.LONGINTEGER :
              return calculate(oper, (Long) valueL.value, (Long) valueR.value);
            case SymbolValue.STRING :
            case SymbolValue.SECOND :
            case SymbolValue.MINUTE :
            case SymbolValue.HOUR :
            case SymbolValue.DAY :
            case SymbolValue.MONTH :
            case SymbolValue.YEAR :
            case SymbolValue.TIME :
              main.pyEvent(Py.STDOUT, "TypeError: number coercion failed");
              return new SymbolValue(SymbolValue.ERROR);
          }
        case SymbolValue.STRING :
          switch (valueR.type) {
            case SymbolValue.STRING :
              return calculate(oper, (String) valueL.value, (String) valueR.value);
            case SymbolValue.INTEGER :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"int\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.LONGINTEGER :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"long\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.BOOLEAN :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"boolean\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.SECOND :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"second\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.MINUTE :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"minute\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.HOUR :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"hour\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.DAY :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"day\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.MONTH :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"month\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.YEAR :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"year\" to string");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.TIME :
              main.pyEvent(Py.STDOUT, "TypeError: cannot add type \"time\" to string");
              return new SymbolValue(SymbolValue.ERROR);
          }
        case SymbolValue.EXPRLIST :
          switch (valueR.type) {
            case SymbolValue.EXPRLIST :
              return calculate(oper, (Vector) valueL.value, (Vector) valueR.value);
            case SymbolValue.INTEGER :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"int\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.LONGINTEGER :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"long\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.STRING :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"string\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.BOOLEAN :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"boolean\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.SECOND :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"second\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.MINUTE :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"minute\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.HOUR :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"hour\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.DAY :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"day\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.MONTH :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"mouth\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.YEAR :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"year\") to list");
              return new SymbolValue(SymbolValue.ERROR);
            case SymbolValue.TIME :
              main.pyEvent(Py.STDOUT, "TypeError: can only concatenate tuple (not \"time\") to list");
              return new SymbolValue(SymbolValue.ERROR);
          }
          case SymbolValue.SECOND : {
            switch (valueR.type) {
              case SymbolValue.SECOND :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MINUTE :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 60));
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.HOUR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 60 * 60));
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.DAY :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 24 * 60 * 60));
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MONTH :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 30 * 24 * 60 * 60));
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.YEAR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 365 * 24 * 60 * 60));
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.INTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.LONGINTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Long) valueR.value);
                tmp.type = SymbolValue.SECOND;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case SymbolValue.MINUTE : {
            switch (valueR.type) {
              case SymbolValue.SECOND :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60));
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
              case SymbolValue.MINUTE :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.HOUR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 60));
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.DAY :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 24 * 60));
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MONTH :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 30 * 24 * 60));
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.YEAR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 365 * 24 * 60));
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.INTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.LONGINTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Long) valueR.value);
                tmp.type = SymbolValue.MINUTE;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case SymbolValue.HOUR : {
            switch (valueR.type) {
              case SymbolValue.SECOND :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 60));
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MINUTE :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60));
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.HOUR :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.DAY :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 24));
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MONTH :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 30 * 24));
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.YEAR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 365 * 24));
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.INTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.LONGINTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Long) valueR.value);
                tmp.type = SymbolValue.HOUR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case SymbolValue.DAY : {
            switch (valueR.type) {
              case SymbolValue.SECOND :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 60 / 24));
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MINUTE :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 24));
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.HOUR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 24));
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.DAY :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MONTH :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 30));
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.YEAR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 365));
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.INTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.DAY;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.LONGINTEGER :
                  tmp = calculate(oper , (Integer) valueL.value, (Long) valueR.value);
                  tmp.type = SymbolValue.LONGINTEGER;
                  if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case SymbolValue.MONTH : {
            switch (valueR.type) {
              case SymbolValue.SECOND :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 60 / 24 / 30));
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MINUTE :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 24 / 30));
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.HOUR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 24 / 30));
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.DAY :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 30));
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MONTH :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.YEAR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() * 12));
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.INTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.LONGINTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Long) valueR.value);
                tmp.type = SymbolValue.MONTH;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case SymbolValue.YEAR : {
            switch (valueR.type) {
              case SymbolValue.SECOND :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 60 / 24 / 365));
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MINUTE :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 60 / 24 / 365));
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.HOUR :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 24 / 365));
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.DAY :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 365));
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.MONTH :
                tmp = calculate(oper , (Integer) valueL.value,
                                       new Integer(((Integer) valueR.value).intValue() / 12));
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.YEAR :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.INTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Integer) valueR.value);
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              case SymbolValue.LONGINTEGER :
                tmp = calculate(oper , (Integer) valueL.value, (Long) valueR.value);
                tmp.type = SymbolValue.YEAR;
                if (oper == ParseTree.DIV || oper == ParseTree.MOD)
                  tmp.type = SymbolValue.INTEGER;
                return tmp;
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
          case SymbolValue.TIME : {
            switch (valueR.type) {
              case SymbolValue.TIME :
                return calculate(oper, valueL, valueR);
              case SymbolValue.SECOND :
              case SymbolValue.MINUTE :
              case SymbolValue.HOUR :
              case SymbolValue.DAY :
              case SymbolValue.MONTH :
              case SymbolValue.YEAR :
                return calculate(oper, valueL, valueR);
              default :
                main.pyEvent(Py.STDOUT, "TypeError:");
              return new SymbolValue(SymbolValue.ERROR);
            }
          }
      }
      return new SymbolValue(SymbolValue.ERROR);;
  }


  private SymbolValue calculate (int oper, Integer IR, Integer IL) {
    switch (oper) {
      case ParseTree.ADD :
        return new SymbolValue(new Integer(IR.intValue() + IL.intValue()), SymbolValue.INTEGER);
      case ParseTree.SUB :
        return new SymbolValue(new Integer(IR.intValue() - IL.intValue()), SymbolValue.INTEGER);
      case ParseTree.MUL :
        return new SymbolValue(new Integer(IR.intValue() * IL.intValue()), SymbolValue.INTEGER);
      case ParseTree.DIV :
        if (IL.intValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: integer division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Integer(IR.intValue() / IL.intValue()), SymbolValue.INTEGER);
      case ParseTree.MOD :
        if (IL.intValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: integer division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Integer(IR.intValue() % IL.intValue()), SymbolValue.INTEGER);
      case ParseTree.POW :
        return Pow(IR, IL);
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }

  private SymbolValue calculate (int oper, Integer IR, Long LL) {
    switch (oper) {
      case ParseTree.ADD :
        return new SymbolValue(new Long(IR.intValue() + LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.SUB :
        return new SymbolValue(new Long(IR.intValue() - LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.MUL :
        return new SymbolValue(new Long(IR.intValue() * LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.DIV :
        if (LL.longValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: integer division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Long(IR.intValue() / LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.MOD :
        if (LL.longValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: integer division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Long(IR.intValue() % LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.POW :
        return Pow(new Long(IR.longValue()), LL);
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }


  private SymbolValue calculate (int oper, Long LR, Integer IL) {
    switch (oper) {
      case ParseTree.ADD :
        return new SymbolValue(new Long(LR.longValue() + IL.intValue()), SymbolValue.LONGINTEGER);
      case ParseTree.SUB :
        return new SymbolValue(new Long(LR.longValue() - IL.intValue()), SymbolValue.LONGINTEGER);
      case ParseTree.MUL :
        return new SymbolValue(new Long(LR.longValue() * IL.intValue()), SymbolValue.LONGINTEGER);
      case ParseTree.DIV :
        if (IL.intValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: long division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Long(LR.longValue() / IL.intValue()), SymbolValue.LONGINTEGER);
      case ParseTree.MOD :
        if (IL.intValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: long division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Long(LR.longValue() % IL.intValue()), SymbolValue.LONGINTEGER);
      case ParseTree.POW :
        return Pow(LR, new Long(IL.longValue()));
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }


  private SymbolValue calculate (int oper, Long LR, Long LL) {
    switch (oper) {
      case ParseTree.ADD :
        return new SymbolValue(new Long(LR.longValue() + LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.SUB :
        return new SymbolValue(new Long(LR.longValue() - LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.MUL :
        return new SymbolValue(new Long(LR.longValue() * LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.DIV :
        if (LL.longValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: long division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Long(LR.longValue() / LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.MOD :
        if (LL.longValue() == 0) {
          main.pyEvent(Py.STDOUT, "ZeroDivisionError: long division or modulo");
          return new SymbolValue(SymbolValue.ERROR);
        }
        return new SymbolValue(new Long(LR.longValue() % LL.longValue()), SymbolValue.LONGINTEGER);
      case ParseTree.POW :
        return Pow(LR, LL);
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }



  private SymbolValue calculate (int oper, String SR, String SL) {
    switch (oper) {
      case ParseTree.ADD :
        return new SymbolValue(new String(SR + SL), SymbolValue.STRING);
      case ParseTree.SUB :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for -");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.MUL :
        main.pyEvent(Py.STDOUT, "TypeError: can't multiply sequence with non-int");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.DIV :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for /");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.MOD :
        main.pyEvent(Py.STDOUT, "TypeError: not all arguments converted");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.POW :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for **");
        return new SymbolValue(SymbolValue.ERROR);
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }


  private SymbolValue calculate (int oper, Vector VL, Vector VR) {
    switch (oper) {
      case ParseTree.ADD :
        Enumeration enum = VR.elements();
        while (enum.hasMoreElements())
          VL.addElement(enum.nextElement());
        return new SymbolValue(VL, SymbolValue.EXPRLIST);
      case ParseTree.SUB :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for -");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.MUL :
        main.pyEvent(Py.STDOUT, "TypeError: can't multiply sequence with non-int");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.DIV :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for /");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.MOD :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for %");
        return new SymbolValue(SymbolValue.ERROR);
      case ParseTree.POW :
        main.pyEvent(Py.STDOUT, "TypeError: bad operand type(s) for **");
        return new SymbolValue(SymbolValue.ERROR);
      default :
        return new SymbolValue(SymbolValue.ERROR);
    }
  }


  private SymbolValue calculate (int oper, SymbolValue VL, Integer VR) {
    return null;
  }



  private SymbolValue calculate (int oper, SymbolValue VL, SymbolValue VR) {
    String time, date;
    int hour, minute, second, day, mount, year;

    String timeDate = (String) VL.value;
    time = timeDate.substring(1, timeDate.indexOf("|"));
    date = timeDate.substring(timeDate.indexOf("|") + 1, timeDate.length() - 1);

    int i1 = time.indexOf(":");
    hour = Integer.parseInt(time.substring(0, i1));
    time = new String(time.substring(i1 + 1, time.length()));
    i1 = time.indexOf(":");
    minute = Integer.parseInt(time.substring(0, i1));
    second = Integer.parseInt(time.substring(i1 + 1, time.length()));

    i1 = date.indexOf("/");
    day = Integer.parseInt(date.substring(0, i1));
    date = new String(date.substring(i1 + 1, date.length()));
    i1 = date.indexOf("/");
    mount = Integer.parseInt(date.substring(0, i1));
    year = Integer.parseInt(date.substring(i1 + 1, date.length()));

    switch (VR.type) {
      case SymbolValue.SECOND :
        second += ((Integer) VR.value).intValue();
        break;
      case SymbolValue.MINUTE :
        minute += ((Integer) VR.value).intValue();
        break;
      case SymbolValue.HOUR :
        hour += ((Integer) VR.value).intValue();
        break;
      case SymbolValue.DAY :
        day += ((Integer) VR.value).intValue();
        break;
      case SymbolValue.MONTH :
        mount += ((Integer) VR.value).intValue();
        break;
      case SymbolValue.YEAR :
        year += ((Integer) VR.value).intValue();
        break;
      case SymbolValue.TIME :
        if (oper != ParseTree.SUB)
          return new SymbolValue(SymbolValue.ERROR);

        String timer, dater;
        int hourr, minuter, secondr, dayr, mountr, yearr;

        String timeDater = (String) VR.value;
        timer = timeDater.substring(1, timeDater.indexOf("|"));
        dater = timeDater.substring(timeDater.indexOf("|") + 1, timeDater.length() - 1);

        int i1r = timer.indexOf(":");
        hourr = Integer.parseInt(timer.substring(0, i1r));
        timer = new String(timer.substring(i1r + 1, timer.length()));
        i1r = timer.indexOf(":");
        minuter = Integer.parseInt(timer.substring(0, i1r));
        secondr = Integer.parseInt(timer.substring(i1r + 1, timer.length()));

        i1r = dater.indexOf("/");
        dayr = Integer.parseInt(dater.substring(0, i1r));
        dater = new String(dater.substring(i1r + 1, dater.length()));
        i1r = dater.indexOf("/");
        mountr = Integer.parseInt(dater.substring(0, i1r));
        yearr = Integer.parseInt(dater.substring(i1r + 1, dater.length()));
        second -= secondr;
        minute -= minuter;
        hour -= hourr;
        day -= dayr;
        mount -= mountr;
        year -= yearr;

        second += minute * 60;
        second += hour * 60 * 60;
        second += day * 24 * 60 * 60;
        second += mount * 30 * 24 * 60 * 60;
        second += year * 12 * 30 * 24 * 60 * 60;

        return new SymbolValue(new Integer(second), SymbolValue.SECOND);
    }

    boolean bl = true;
    while (bl) {
      bl = false;
      if (second >= 60) {
        minute += 1;
        second -= 60;
        bl = true;
      }
      if (minute >= 60) {
        hour += 1;
        minute -= 60;
        bl = true;
      }
      if (hour >= 24) {
        day += 1;
        hour -= 24;
        bl = true;
      }
      if (day >= 30) {
        mount += 1;
        day -= 30;
        bl = true;
      }
      if (mount >= 12) {
        year += 1;
        mount -= 12;
        bl = true;
      }
    }

    String tmp = "[" + hour + ":" + minute + ":" + second + "|" + day + "/" + mount + "/" + year  + "]";
    return new SymbolValue(tmp, SymbolValue.TIME);
  }


  private SymbolValue Pow (Long L1, Long L2) {
    long ans = 1;

    if (L2.longValue() < 0)
      return new SymbolValue(SymbolValue.ERROR);

    for (long l = 1; l <= L2.longValue(); l++)
      ans *= L1.longValue();

    return new SymbolValue(new Long(ans), SymbolValue.LONGINTEGER);
  }


  private SymbolValue Pow (Integer I1, Integer I2) {
    int ans = 1;

    if (I2.intValue() < 0)
      return new SymbolValue(SymbolValue.ERROR);

    for (int i = 1; i <= I2.intValue(); i++)
      ans *= I1.intValue();

    return new SymbolValue(new Integer(ans), SymbolValue.INTEGER);
  }
}

