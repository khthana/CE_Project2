package com.pyme;

import java.io.*;
import com.pyme.execute.*;
import com.pyme.lexyacc.*;

public abstract class Py {
  public static final int STDOUT = 0;
  public static final int OPENURL = 1;
  public static final int SENDMAIL = 2;

//  private BufferedReader filebuffer;
  private String source = "";
//  public static SymbolTable symTable = new SymbolTable();
  private SymbolTable symTable = new SymbolTable();

  public abstract void pyEvent(int eventType, String eventMsg);

  public Py(String source) {
    this.source = source;
  }

  public SymbolTable getTable() {
    return symTable;
  }

  private String readInput() {
    String lineCode = "";
    while (!source.equals("")) {
      String buff = "";
      int index = -1;
      if ((index = source.indexOf('\n')) != -1 || (index = source.indexOf(8233)) != -1) {
        buff = source.substring(0, index);
        source = source.substring(index+1);
      }
      else {
        buff = source;
        source = "";
      }
      if (!spaceLine(buff)) return buff + "\n ";
    }
    return null;
  }

  private boolean spaceLine(String lineCode) {
    int space = 0;
    if (!lineCode.equals("")) {
      if (lineCode.indexOf(' ') == -1) return false;
      while ((space = lineCode.indexOf(' ')) != -1) {
        if (space != 0) return false;
        lineCode = lineCode.substring(1);
      }
      if (lineCode.equals("")) return true;
      else return false;
    }
    else return true;
  }

  public void Interprete() {
//    for (int i=0; i<source.length(); i++) {
//      pyEvent(STDOUT, "" + (int)source.charAt(i));
//    }

    String fetch = " ";
    String lineCode = "";
    while ((lineCode = readInput()) != null) fetch += lineCode;
//    System.out.println(fetch);
    parseSyntax(fetch);
  }

  private void parseSyntax(String fetch) {
    SimPyParser parser = new SimPyParser(this);
    SimPyLexer lexer = new SimPyLexer(parser);
    if (parser.yycreate(lexer))
      if (lexer.yycreate(parser, fetch)) parser.yyparse();
  }

}