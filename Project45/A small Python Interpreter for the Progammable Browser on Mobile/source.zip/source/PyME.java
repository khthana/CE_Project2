import javax.microedition.lcdui.*;
import com.pyme.Py;

public class PyME extends Py {
  private MainControl main;

  public PyME(String source, MainControl main) {
    super(source);
    this.main = main;
  }

  public void pyEvent(int eventType, String eventMsg) {
    if (eventType == STDOUT) {
      ((StdOut)main.getDisplay(MainControl.STDOUT)).append(eventMsg + "\n");
      main.show(MainControl.STDOUT);
      System.out.println(eventMsg);
    }
    else if (eventType == OPENURL) {
      ((StdOut)main.getDisplay(MainControl.STDOUT)).append("OPEN URL >> " + eventMsg + "\n");
      main.show(MainControl.STDOUT);
      System.out.println(eventMsg);
    }
    else if (eventType == SENDMAIL) {
      String mail = "SEND MAIL >>\n";

      String to = eventMsg.substring(0,eventMsg.indexOf(","));
      eventMsg = eventMsg.substring(eventMsg.indexOf(",")+1);
      String from = eventMsg.substring(0,eventMsg.indexOf(","));
      eventMsg = eventMsg.substring(eventMsg.indexOf(",")+1);
      String subj = eventMsg.substring(0,eventMsg.indexOf(","));
      eventMsg = eventMsg.substring(eventMsg.indexOf(",")+1);
      String msg = eventMsg;

      mail += "TO      : " + to + "\n" +
              "FROM    : " + from + "\n" +
              "SUBJECT : " + subj + "\n" +
              "MESSAGE : " + msg;
      ((StdOut)main.getDisplay(MainControl.STDOUT)).append(mail);
      main.show(MainControl.STDOUT);
      System.out.println(eventMsg);
    }
  }

}