
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class PyMIDlet extends MIDlet {
  public Display disp;
  private MainControl main;

  public PyMIDlet() {
    disp = Display.getDisplay(this);
    main = new MainControl(this);
  }

  public void startApp() {
//    disp.setCurrent(screen[EDITOR]);
  }

  public void pauseApp() {
  }

  public void destroyApp(boolean unconditional) {
  }

}
