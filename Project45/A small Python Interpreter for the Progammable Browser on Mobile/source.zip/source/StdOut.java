import javax.microedition.lcdui.*;

public class StdOut extends Form implements CommandListener {
  private MainControl main;

  public StdOut(MainControl main) {
    super("Standard Output");
    this.main = main;
    addCommand(new Command("Close", Command.BACK, 1));
    setCommandListener(this);
  }

  public void commandAction(Command cmd, Displayable d) {
    if (cmd.getLabel().equals("Close")) {
      for (int i=size()-1; i >= 0; i--) delete(i);
      main.show(MainControl.EDITOR);
    }
  }

}
