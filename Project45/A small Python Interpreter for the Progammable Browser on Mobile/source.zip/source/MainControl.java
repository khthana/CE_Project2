import javax.microedition.lcdui.*;

public class MainControl {
  public static final int EDITOR = 0;
  public static final int STDOUT = 1;

  private PyMIDlet pyme;
  private Displayable[] screen = new Displayable[2];

  public MainControl(PyMIDlet pyme) {
    this.pyme = pyme;
    screen[EDITOR] = new PyEditor(this);
    screen[STDOUT] = new StdOut(this);

    pyme.disp.setCurrent(screen[EDITOR]);
  }

  public void show(Displayable screen) {
    pyme.disp.setCurrent(screen);
  }

  public void show(int index) {
    pyme.disp.setCurrent(screen[index]);
  }

  public Displayable getDisplay(int index) {
    return screen[index];
  }

  public void exitProgram() {
    pyme.destroyApp(false);
    pyme.notifyDestroyed();
  }

}