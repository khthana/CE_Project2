
import javax.microedition.lcdui.*;

public class PyEditor extends TextBox implements CommandListener {
  private MainControl main;
  private PyME py = null;

  public PyEditor(MainControl main) {
    super("PYTHON EDITOR", "", 1000, 0);
    this.main = main;
    setCommandListener(this);
    addCommand(new Command("Script01", Command.ITEM, 0));
    addCommand(new Command("Script02", Command.ITEM, 0));
    addCommand(new Command("Script03", Command.ITEM, 0));
    addCommand(new Command("Script04", Command.ITEM, 0));
    addCommand(new Command("Script05", Command.ITEM, 0));
    addCommand(new Command("Script06", Command.ITEM, 0));
    addCommand(new Command("Script07", Command.ITEM, 0));
    addCommand(new Command("Script08", Command.ITEM, 0));
    addCommand(new Command("Interprete", Command.BACK, 1));
    addCommand(new Command("Exit", Command.BACK, 1));
  }

  public void commandAction(Command cmd, Displayable d) {
    if (cmd.getLabel().equals("Exit")) {
      main.exitProgram();
    }
    else if (cmd.getLabel().equals("Script01")) {
      setString("a = 10\n" +
                "b = 025\n" +
                "c = 0x2ad\n" +
                "print a\n" +
                "print b,c, 235,c\n" +
                "print range(10)\n" +
                "print range(5,15)\n" +
                "print range(5,30,3)");
    }
    else if (cmd.getLabel().equals("Script02")) {
      setString("x = [10,15,20]\n" +
                "y = range(10)\n" +
                "z = x[2]+ y[5]\n" +
                "print z");
    }
    else if (cmd.getLabel().equals("Script03")) {
      setString("a=100\n" +
                "if a==1 :\n" +
                "  print \"a==1\" \n" +
                "elif a==10: \n" +
                "  print \"a==10\" \n" +
                "else: \n" +
                "  print \"else\"");
    }
    else if (cmd.getLabel().equals("Script04")) {
      setString("a=0 \n" +
                "while a<10: \n" +
                "  if a%2: \n" +
                "    print a \n" +
                "  elif a==2 or a==6 : \n" +
                "    print a \n" +
                "  a += 1 \n" +
                "print \"end\"");
    }
    else if (cmd.getLabel().equals("Script05")) {
      setString("a = 5 \n" +
                "for a in range(0,10): \n" +
                "  print a");
    }
    else if (cmd.getLabel().equals("Script06")) {
      setString("a=5day \n" +
                "b = 50mt \n" +
                "c = 24yr \n" +
                "d= 30sec \n" +
                "e = 60mt \n" +
                "print a+24hr \n" +
                "print b-1day \n" +
                "print c*12mt \n" +
                "print d/1hr \n" +
                "print e**120sec");
    }
    else if (cmd.getLabel().equals("Script07")) {
      setString("openURL(\"http://www.kmitl.ac.th\")");
    }
    else if (cmd.getLabel().equals("Script08")) {
      setString("sendMail(\"kritchai_v@yahoo.com\",\"aae2k\",\"test\",\"message\")");
    }
    else if (cmd.getLabel().equals("Interprete")) {
      py = new PyME(getString(), main);
      py.Interprete();
    }
  }

}
