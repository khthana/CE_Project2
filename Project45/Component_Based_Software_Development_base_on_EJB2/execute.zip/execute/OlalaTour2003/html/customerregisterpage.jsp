<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Register</TITLE>
<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(customerregisterpageLayout, 747, 961))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    <%
  //get parameter
  String username = "";
  if ( request.getParameter("username") != null )
    username = new String(request.getParameter("username").getBytes("UTF-8"),"UTF-8");
  String password = "";
  if ( request.getParameter("password") != null )
    password = new String(request.getParameter("password").getBytes("UTF-8"),"UTF-8");
  String repassword = "";
  if ( request.getParameter("repassword") != null )
    repassword = new String(request.getParameter("repassword").getBytes("UTF-8"),"UTF-8");
  String email = "";
  if ( request.getParameter("email") != null )
    email = new String(request.getParameter("email").getBytes("UTF-8"),"UTF-8");
  String name = "";
  if ( request.getParameter("name") != null )
    name = new String(request.getParameter("name").getBytes("UTF-8"),"UTF-8");
  String lastname = "";
  if ( request.getParameter("lastname") != null )
    lastname = new String(request.getParameter("lastname").getBytes("UTF-8"),"UTF-8");
  String address = "";
  if ( request.getParameter("address") != null )
    address = new String(request.getParameter("address").getBytes("UTF-8"),"UTF-8");
%>

<%
  //check before AddCustomer
  CustomerResult rs = null;
  int customer_id = 0;
  boolean incorrect = true;
  if(username!="" && password!="" && (password.equals(repassword)) ){
    rs = soapProxy.addcustomer(name,lastname,email,username,password,address);
    incorrect = false;
  }
%>
<%
  String result = "";
//set session & result
  if (incorrect){
    result = "Incorrect user or password.";
  }
  else if(rs==null){
    result = "username exist.";
  }
%>
    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=125 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=125>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=125>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton5',1)" onMouseOut="F_roll('NavigationButton5',0)"><IMG ID="NavigationButton5" NAME="NavigationButton5" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton6',1)" onMouseOut="F_roll('NavigationButton6',0)"><IMG ID="NavigationButton6" NAME="NavigationButton6" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Search_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Search_NRcitybut2.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton7',1)" onMouseOut="F_roll('NavigationButton7',0)"><IMG ID="NavigationButton7" NAME="NavigationButton7" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Package_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Package_NRcitybut2.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton8',1)" onMouseOut="F_roll('NavigationButton8',0)"><IMG ID="NavigationButton8" NAME="NavigationButton8" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=23 HEIGHT=33><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=23 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=703>
                            <FORM NAME="Table1FORM" ENCTYPE="MS874" ACTION="customerregisterpage.jsp" METHOD=POST>
                                <%
if(result!=""){
%>
                                <TABLE ID="Table27" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TH COLSPAN=2 BGCOLOR="#FFCCFF" HEIGHT=22>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF0000" SIZE="+1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Rigister fail</FONT></P>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF0000" SIZE="+1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Please fill the valid Information</FONT></P>
                                        </TH>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#000000" HEIGHT=18>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Account Information</FONT></P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#F0FFFF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>1-20 char with[a-z,A-Z,0-9]</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ex. johnny , gato , chun </B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </B></FONT><FONT COLOR="#2A00FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> username</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#F0FFFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=TE>
                                                    <TR>
                                                        <TD ALIGN="LEFT"><INPUT ID="FormsEditField11" TYPE=TEXT NAME="username" VALUE="" SIZE=20 MAXLENGTH=20></TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#D2F0FF" HEIGHT=24>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>1-20 char with[a-z,A-Z,0-9] and must be the same value with below</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ex. group2 , goldfish , sausage</B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>&nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </B></FONT><FONT COLOR="#2A00FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>password</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#D2F0FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=TE>
                                                    <TR>
                                                        <TD ALIGN="LEFT"><INPUT ID="FormsEditField12" TYPE=PASSWORD NAME="password" VALUE="" SIZE=20 MAXLENGTH=20></TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#B4DCFF" HEIGHT=24>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>1-20 char with[a-z,A-Z,0-9] and must be the same value with below</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ex. group2 , goldfish , sausage</B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#2A00FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>re-password</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#B4DCFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=TE>
                                                    <TR>
                                                        <TD ALIGN="LEFT"><INPUT ID="FormsEditField13" TYPE=PASSWORD NAME="repassword" VALUE="" SIZE=20 MAXLENGTH=20></TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#000000">
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Profile Information</FONT></P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#78B4FF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>1-20 char with[a-z,A-Z,0-9]</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ex. worapon , viroj</B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>First Name</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#78B4FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField14" TYPE=TEXT NAME="name" VALUE="" SIZE=30 MAXLENGTH=30></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#5AA0FF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>1-20 char with[a-z,A-Z,0-9]</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ex. mungmee , smith</B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Last Name</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#5AA0FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField15" TYPE=TEXT NAME="lastname" VALUE="" SIZE=30 MAXLENGTH=30></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#3C8CFF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><A HREF="mailto:yourmail@yourhost"><B><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">yourmail@yourhost</FONT></B></A></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ex. roticagas@hotmail.com, chiewchan@hotmail.com </B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>E-mail Address</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#3C8CFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField16" TYPE=TEXT NAME="email" VALUE="" SIZE=30 MAXLENGTH=30></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=463 BGCOLOR="#1E78FF" HEIGHT=70>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=463 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Address</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=240 BGCOLOR="#3C8CFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><TEXTAREA WRAP=PHYSICAL ID="FormsMultiLine2" NAME="address" ROWS=4 COLS=25></TEXTAREA></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#0066FF" HEIGHT=25>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT TYPE=SUBMIT NAME="FormsButton1" VALUE="OK!" ID="FormsButton17">&nbsp;<INPUT TYPE=RESET NAME="FormsButton1" VALUE="Reset" ID="FormsButton18"></FONT></TD>
                                    </TR>
                                </TABLE>
                                <%}%>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=724 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=23><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=23 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=701><%
if(result==""){
%>
                            <P ALIGN=CENTER><B><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register Success</FONT></B><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">. </FONT></P>
                            <P ALIGN=LEFT><B><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></B><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  to test your username and password click <B>login</B> below it will bring you to Your Profile page.</FONT></P>
                            <%}%></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=23><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=23 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=702>
                            <FORM NAME="Table3FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                <INPUT TYPE=HIDDEN NAME="username" VALUE="<%=username%>"><INPUT TYPE=HIDDEN NAME="password" VALUE="<%=password%>"><%
if(result==""){
%>
                                <TABLE ID="Table3" BORDER=0 BGCOLOR="#99FF99" CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TH WIDTH=702 BGCOLOR="#0066FF" HEIGHT=22>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="+1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Login</FONT></P>
                                        </TH>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=702 BGCOLOR="#1478FF" HEIGHT=23>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=TE>
                                                    <TR>
                                                        <TD ALIGN="CENTER"><INPUT TYPE=SUBMIT NAME="FormsButton4" VALUE="Login" ID="Forms Button4"></TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                </TABLE>
                                <%}%>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=89></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/packagelistpage.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package&nbsp;List</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/search.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Search&nbsp;Package</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 