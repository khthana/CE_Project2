<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Package List</TITLE>
<META CONTENT="NetObjects Fusion 7 for Windows" NAME="Generator">
<META CONTENT="NetObjects Fusion MX for Windows" NAME="Generator">
<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(packagelistpageLayout, 747, 320))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    <%
  //get parameter
  int resultperpage = 10;
  int requestpage = 1;//default
  if( request.getParameter("page")!= null )
    if ( request.getParameter("page").length() > 0 )
      requestpage = Integer.parseInt(request.getParameter("page"));
%>
<%
  //getPackaeList
  SearchResult rs = soapProxy.getPackageList(requestpage,resultperpage);
%>

<%
//get result
  int totalresult = 0;
  int currentpage = 0;
  int totalpage =  0;
  int ar[] = null;
  if(rs!=null){
    totalresult = rs.getTotalresult();
    currentpage = rs.getCurrentpage();
    totalpage =  rs.getTotalpage();
    ar = rs.getPackageId();
  }
%>

    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=126 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=126>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=126>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton1',1)" onMouseOut="F_roll('NavigationButton1',0)"><IMG ID="NavigationButton1" NAME="NavigationButton1" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton2',1)" onMouseOut="F_roll('NavigationButton2',0)"><IMG ID="NavigationButton2" NAME="NavigationButton2" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Search_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Search_NRcitybut2.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton3',1)" onMouseOut="F_roll('NavigationButton3',0)"><IMG ID="NavigationButton3" NAME="NavigationButton3" HEIGHT=27 WIDTH=126 SRC="../assets/images/autogen/Package_Hcitybut2.jpg" onLoad="F_loadRollover(this,'Package_HRcitybut1.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton4',1)" onMouseOut="F_roll('NavigationButton4',0)"><IMG ID="NavigationButton4" NAME="NavigationButton4" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=724 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=24 HEIGHT=33><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=24 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=700><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=700 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=700>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp; if you logged in you can reserve package&nbsp; by select your Cart and click <B>Book!</B></FONT><B></B></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp; if you want to reserve in new Cart&nbsp; select <B>new</B> in Cart Select List</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                            <%
//loop show
  for(int i=0;i<ar.length;i++){
    PackageDetail pd =soapProxy.getPackageDetail(ar[i]);
   int package_id = ar[i];
  String name = pd.getPackageName();
  String start = pd.getStartdate();
  String finish = pd.getFinishdate();
  String deadline = pd.getDeadline();
  int price = pd.getCost();
    %>
</TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=24><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=24 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=705>
                            <FORM NAME="Table27FORM<%=package_id%>" ACTION="jobreservepage.jsp" METHOD=GET>
                                <INPUT TYPE=HIDDEN NAME="package_id" VALUE="<%=package_id%>">

                                <TABLE ID="Table27" BORDER=0 CELLSPACING=1 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TD WIDTH=37 BGCOLOR="#0066FF" HEIGHT=16>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ID</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=164 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Name</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=85 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Deadline</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=76 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Start</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=81 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Finish</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=54 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>price</B></FONT><B></B></P>
                                        </TD>
                                        <%
if(SScustomer_id>0){
%>
                                        <TD WIDTH=77 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Cart</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=60 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>quantity</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=61 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Booking</B></FONT><B></B></P>
                                        </TD>
                                        <%}%>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=37 BGCOLOR="#96C8FF" HEIGHT=24>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="51%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table28" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%=package_id%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=164 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="11%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table29" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><A href="packagedetail.jsp?package_id=<%=package_id%>"><%=name%></a></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=85 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="22%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table30" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><%=deadline%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=76 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="25%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table31" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><%=start%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=81 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="23%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table32" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><%=finish%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=54 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="35%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table33" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%=price%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        
<%
if(SScustomer_id>0){
%>
                                        <TD WIDTH=77 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="24%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table34" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <select name="contact_id" ><%
      CustomerContactResult crs[] = soapProxy.getCustomerContact(SScustomer_id);
      for(int j=0;j<SScontact_id.length;j++){
        if(crs[j].getContactStatus()<3){
          %><option value="<%=SScontact_id[j]%>">Cart #<%=j+1%> : <%=SScontact_id[j]%></option><%
        }
      }
      %><option value="0">new</option></select></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=60 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Edit Field19" TYPE=TEXT NAME="quantity" VALUE="1" SIZE=5 MAXLENGTH=10></FONT></TD>
                                        <TD WIDTH=61 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT TYPE=SUBMIT NAME="FormsButton17" VALUE="Book!" ID="Forms Button17"></FONT></TD>
                                        <%}%>
                                    </TR>
                                </TABLE>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=362 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=24 HEIGHT=16><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=24 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=338><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=338 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=338>    <%
  }//end for
%><br>
<%
//link panel
if(currentpage>1){%><a href="packagelistpage.jsp?page=1">|&lt;</a>&nbsp;<%}
if(currentpage>1){%><a href="packagelistpage.jsp?page=<%=currentpage-1%>">&lt;&lt;</a>&nbsp;<%}
int p = 1;
for(p=1; p <= totalpage; p++){
  if(p!=currentpage){
    %><a href="packagelistpage.jsp?page=<%=p%>"><%=p%></a>&nbsp;<%
  }
  else{
    %> [<b><%=p%></b>] <%
  }
}
if(currentpage<totalpage){%><a href="packagelistpage.jsp?page=<%=currentpage+1%>">&gt;&gt;</a>&nbsp;<%}
if(currentpage<totalpage){%><a href="packagelistpage.jsp?page=<%=totalpage%>">&gt;|</a>&nbsp;<%}
%>
                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=135></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [Package&nbsp;List] [</FONT></B><A HREF="../html/search.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Search&nbsp;Package</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 