<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Package Search</TITLE>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT SRC="file:///C:/Program Files/NetObjects Fusion 7/NetObjects System/rollover.js" LANGUAGE="JavaScript1.2"></SCRIPT>

<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
<NOLAYER>
<STYLE ID="NOF_STYLE_SHEET">
<!--
DIV#Table13LYR { position:relative; visibility:hidden; float:left; top:0; left:0; width:103; height:0; z-index:1; }
DIV#Table15LYR { position:relative; visibility:hidden; float:left; top:0; left:0; width:107; height:0; z-index:2; }
DIV#Table16LYR { position:relative; visibility:hidden; float:left; top:0; left:0; width:129; height:0; z-index:3; }
-->
</STYLE>

</NOLAYER>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(packagesearchpageLayout, 747, 769))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=126 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=126>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=126>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton5',1)" onMouseOut="F_roll('NavigationButton5',0)"><IMG ID="NavigationButton5" NAME="NavigationButton5" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton6',1)" onMouseOut="F_roll('NavigationButton6',0)"><IMG ID="NavigationButton6" NAME="NavigationButton6" HEIGHT=27 WIDTH=126 SRC="../assets/images/autogen/Search_Hcitybut2.jpg" onLoad="F_loadRollover(this,'Search_HRcitybut1.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton7',1)" onMouseOut="F_roll('NavigationButton7',0)"><IMG ID="NavigationButton7" NAME="NavigationButton7" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Package_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Package_NRcitybut2.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=126 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton8',1)" onMouseOut="F_roll('NavigationButton8',0)"><IMG ID="NavigationButton8" NAME="NavigationButton8" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=747 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 HEIGHT=9><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=747 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747>
                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#0066FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Olala Tour Search System.</B></FONT><B></B></P>
                            <UL>
                            </UL>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=725 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD COLSPAN=2 WIDTH=369><%
  //get parameter
  String place_id = "";
  if ( request.getParameter("place_id") != null )
    place_id = new String(request.getParameter("place_id").getBytes("ISO8859_1"),"MS874");
  String region = "";
  if ( request.getParameter("region") != null )
    region = new String(request.getParameter("region").getBytes("ISO8859_1"),"MS874");
  String city_id = "";
  if ( request.getParameter("city_id") != null )
    city_id = new String(request.getParameter("city_id").getBytes("ISO8859_1"),"MS874");
  String country_id = "";
  if ( request.getParameter("country_id") != null )
    country_id = new String(request.getParameter("country_id").getBytes("ISO8859_1"),"MS874");
  String continent_id = "";
  if ( request.getParameter("continent_id") != null )
    continent_id = new String(request.getParameter("continent_id").getBytes("ISO8859_1"),"MS874");
  String vehicle_id = "";
  if ( request.getParameter("vehicle_id") != null )
    vehicle_id = new String(request.getParameter("vehicle_id").getBytes("ISO8859_1"),"MS874");
  String vehicle_grade = "";
  if ( request.getParameter("vehicle_grade") != null )
    vehicle_grade = new String(request.getParameter("vehicle_grade").getBytes("ISO8859_1"),"MS874");
  String Hotel_id = "";
  if ( request.getParameter("Hotel_id") != null )
    Hotel_id = new String(request.getParameter("Hotel_id").getBytes("ISO8859_1"),"MS874");
  String Hotel_grade = "";
  if ( request.getParameter("Hotel_grade") != null )
    Hotel_grade = new String(request.getParameter("Hotel_grade").getBytes("ISO8859_1"),"MS874");
  String act_id = "";
  if ( request.getParameter("act_id") != null )
    act_id = new String(request.getParameter("act_id").getBytes("ISO8859_1"),"MS874");

  String type = "";
  if ( request.getParameter("type") != null )
    type = new String(request.getParameter("type").getBytes("ISO8859_1"),"MS874");

  int minquota = 0;
  if ( request.getParameter("minquota") != null )
    if ( request.getParameter("minquota").length() > 0 )
      minquota = Integer.parseInt(request.getParameter("minquota"));
  int maxquota = 0;
  if ( request.getParameter("maxquota") != null )
    if ( request.getParameter("maxquota").length() > 0 )
      maxquota = Integer.parseInt(request.getParameter("maxquota"));
  int minrequire = 0;
  if ( request.getParameter("minrequire") != null )
    if ( request.getParameter("minrequire").length() > 0 )
      minrequire = Integer.parseInt(request.getParameter("minrequire"));
  int maxrequire = 0;
  if ( request.getParameter("maxrequire") != null )
    if ( request.getParameter("maxrequire").length() > 0 )
      maxrequire = Integer.parseInt(request.getParameter("maxrequire"));
  int mincost = 0;
  if ( request.getParameter("mincost") != null )
    if ( request.getParameter("mincost").length() > 0 )
      mincost = Integer.parseInt(request.getParameter("mincost"));
  int maxcost = 0;
  if ( request.getParameter("maxcost") != null )
    if ( request.getParameter("maxcost").length() > 0 )
      maxcost = Integer.parseInt(request.getParameter("maxcost"));

  int minstartday = 0;
  if ( request.getParameter("minstartday") != null )
    minstartday = Integer.parseInt(request.getParameter("minstartday"));
  int minstartmonth = 0;
  if ( request.getParameter("minstartmonth") != null )
    minstartmonth = Integer.parseInt(request.getParameter("minstartmonth"));
  int minstartyear = 0;
  if ( request.getParameter("minstartyear") != null )
    minstartyear = Integer.parseInt(request.getParameter("minstartyear"));
  int maxstartday = 0;
  if ( request.getParameter("maxstartday") != null )
    maxstartday = Integer.parseInt(request.getParameter("maxstartday"));
  int maxstartmonth = 0;
  if ( request.getParameter("maxstartmonth") != null )
    maxstartmonth = Integer.parseInt(request.getParameter("maxstartmonth"));
  int maxstartyear = 0;
  if ( request.getParameter("maxstartyear") != null )
    maxstartyear = Integer.parseInt(request.getParameter("maxstartyear"));
  int minfinishday = 0;
  if ( request.getParameter("minfinishday") != null )
    minfinishday = Integer.parseInt(request.getParameter("minfinishday"));
  int minfinishmonth = 0;
  if ( request.getParameter("minfinishmonth") != null )
    minfinishmonth = Integer.parseInt(request.getParameter("minfinishmonth"));
  int minfinishyear = 0;
  if ( request.getParameter("minfinishyear") != null )
    minfinishyear = Integer.parseInt(request.getParameter("minfinishyear"));
  int maxfinishday = 0;
  if ( request.getParameter("maxfinishday") != null )
    maxfinishday = Integer.parseInt(request.getParameter("maxfinishday"));
  int maxfinishmonth = 0;
  if ( request.getParameter("maxfinishmonth") != null )
    maxfinishmonth = Integer.parseInt(request.getParameter("maxfinishmonth"));
  int maxfinishyear = 0;
  if ( request.getParameter("maxfinishyear") != null )
    maxfinishyear = Integer.parseInt(request.getParameter("maxfinishyear"));

  //count search time (trick)
  int time = 0;
  if ( request.getParameter("time") != null )
    time = Integer.parseInt(request.getParameter("time"));
  int currentpage = 1;
  if ( request.getParameter("currentpage") != null )
    currentpage = Integer.parseInt(request.getParameter("currentpage"));
  int resultperpage = 10;
  if ( request.getParameter("resultperpage") != null )
    resultperpage = Integer.parseInt(request.getParameter("resultperpage"));
%>

                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                            <%
  //search
  SearchResult rs = null;
  int totalresult = 0;
  int totalpage =  0;
  int ar[] = null;
  //1st time don't search
  if(time > 0){
    rs = soapProxy.search( place_id,region,city_id,country_id,continent_id,
                           vehicle_id,vehicle_grade,
                           Hotel_id,Hotel_grade,
                           act_id,
                           type,
                           minquota,maxquota,
                           minrequire,maxrequire,
                           mincost,maxcost,
                           minstartday,minstartmonth,minstartyear,
                           maxstartday,maxstartmonth,maxstartyear,
                           minfinishday,minfinishmonth,minfinishyear,
                           maxfinishday,maxfinishmonth,maxfinishyear,
                           currentpage,resultperpage );
    if(rs!=null){
      totalresult = rs.getTotalresult();
      currentpage = rs.getCurrentpage();
      totalpage =  rs.getTotalpage();
      // 0 result case
      if(rs.getPackageId() != null)
        ar = rs.getPackageId();
    }
  }
%></TD>
                        <TD></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=1 HEIGHT=14><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=1 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=24><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=24 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=345><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=345 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=355><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=355 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD COLSPAN=2></TD>
                        <TD COLSPAN=2 WIDTH=700>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp; leave other field blank or -Not Select- if you don’t want to use that value to <B>search</B></FONT><B></B></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=25><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=25 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=701>
                            <FORM NAME="Table5FORM" ACTION="" METHOD=POST>
                                <INPUT TYPE=HIDDEN NAME="time" VALUE="1"><INPUT TYPE=HIDDEN NAME="currentpage" VALUE="1"><INPUT TYPE=HIDDEN NAME="resultperpage" VALUE="10">
                                <TABLE ID="Table5" BORDER=0 CELLSPACING=1 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TD WIDTH=17 BGCOLOR="#0066FF" HEIGHT=25>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Continent</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="continent1" NAME="continent_id">
                                                    <OPTION VALUE="">- Not Select -</OPTION>
                                                    <OPTION VALUE="1">Asia</OPTION>
                                                    <OPTION VALUE="2">Australia</OPTION>
                                                    <OPTION VALUE="3">North America</OPTION>
                                                    <OPTION VALUE="4">Europe</OPTION>
                                                </SELECT>
                                                </FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#96C8FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Country</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="Forms Combo Box4" NAME="country_id">
                                                    <OPTION VALUE="">- Not Select -</OPTION>
                                                    <OPTION VALUE="1">Thai</OPTION>
                                                    <OPTION VALUE="2">Japan</OPTION>
                                                    <OPTION VALUE="3">China</OPTION>
                                                    <OPTION VALUE="4">North Korea</OPTION>
                                                    <OPTION VALUE="5">South Korea</OPTION>
                                                    <OPTION VALUE="6">India</OPTION>
                                                    <OPTION VALUE="7">Russia</OPTION>
                                                    <OPTION VALUE="8">Singapore</OPTION>
                                                    <OPTION VALUE="9">New Zealand</OPTION>
                                                    <OPTION VALUE="10">Australia</OPTION>
                                                    <OPTION VALUE="11">Canada</OPTION>
                                                    <OPTION VALUE="12">Mexico</OPTION>
                                                    <OPTION VALUE="13">United States</OPTION>
                                                    <OPTION VALUE="14">Belgium</OPTION>
                                                    <OPTION VALUE="15">Denmark</OPTION>
                                                    <OPTION VALUE="16">France</OPTION>
                                                    <OPTION VALUE="17">Germany</OPTION>
                                                    <OPTION VALUE="18">Ireland</OPTION>
                                                    <OPTION VALUE="19">Italy</OPTION>
                                                    <OPTION VALUE="20">Netherlands</OPTION>
                                                    <OPTION VALUE="21">Norway</OPTION>
                                                    <OPTION VALUE="22">Spain</OPTION>
                                                    <OPTION VALUE="23">Sweden</OPTION>
                                                    <OPTION VALUE="24">Switzerland</OPTION>
                                                    <OPTION VALUE="25">Turkey</OPTION>
                                                    <OPTION VALUE="26">United Kingdoms</OPTION>
                                                </SELECT>
                                                </FONT>
                                                <TABLE WIDTH="17%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD><DIV ID="Table13LYR"><ILAYER ID="Table13LYR" VISIBILITY=HIDDEN WIDTH=103 HEIGHT=0 Z-INDEX=1>
                                                            <TABLE ID="Table13" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            </ILAYER></DIV>
                                                        </TD>
                                                    </TR>
                                                </TABLE>
                                                <FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="17%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD><DIV ID="Table15LYR"><ILAYER ID="Table15LYR" VISIBILITY=HIDDEN WIDTH=107 HEIGHT=0 Z-INDEX=2>
                                                            <TABLE ID="Table15" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            </ILAYER></DIV>
                                                        </TD>
                                                    </TR>
                                                </TABLE>
                                                <FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="21%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD><DIV ID="Table16LYR"><ILAYER ID="Table16LYR" VISIBILITY=HIDDEN WIDTH=129 HEIGHT=0 Z-INDEX=3>
                                                            <TABLE ID="Table16" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            </ILAYER></DIV>
                                                        </TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Vehicle</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="Forms Combo Box3" NAME="vehicle_id">
                                                    <OPTION VALUE="">- Not Select -</OPTION>
                                                    <OPTION VALUE="1or2or3">Plane</OPTION>
                                                    <OPTION VALUE="4or5or6">Bus</OPTION>
                                                    <OPTION VALUE="7or8or9">Ship</OPTION>
                                                    <OPTION VALUE="10or11or12">Train</OPTION>
                                                </SELECT>
                                                </FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#96C8FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Grade</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="FormsComboBox11" NAME="vehicle_grade">
                                                    <OPTION VALUE="">- Not Select - </OPTION>
                                                    <OPTION VALUE="3">Economics</OPTION>
                                                    <OPTION VALUE="2">Normal</OPTION>
                                                    <OPTION VALUE="1">Special</OPTION>
                                                </SELECT>
                                                </FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Activity</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="FormsComboBox10" NAME="act_id">
                                                    <OPTION VALUE="">- Not Select -</OPTION>
                                                    <OPTION VALUE="1">Mountain</OPTION>
                                                    <OPTION VALUE="2">Waterfall</OPTION>
                                                    <OPTION VALUE="3">Sea</OPTION>
                                                    <OPTION VALUE="4">Riding</OPTION>
                                                    <OPTION VALUE="5">Sight Seeing</OPTION>
                                                    <OPTION VALUE="6">Fishing</OPTION>
                                                    <OPTION VALUE="7">Claim Mountain </OPTION>
                                                    <OPTION VALUE="8">Boat</OPTION>
                                                    <OPTION VALUE="9">Natural</OPTION>
                                                    <OPTION VALUE="10">Ski</OPTION>
                                                    <OPTION VALUE="11">Shopping</OPTION>
                                                    <OPTION VALUE="12">Old Culture</OPTION>
                                                    <OPTION VALUE="13">Museum</OPTION>
                                                    <OPTION VALUE="14">Scuba</OPTION>
                                                </SELECT>
                                                </FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#96C8FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Hotel Grade</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="Forms Combo Box1" NAME="Hotel_grade">
                                                    <OPTION VALUE="">- Not Select -</OPTION>
                                                    <OPTION VALUE="1">1</OPTION>
                                                    <OPTION VALUE="2">2</OPTION>
                                                    <OPTION VALUE="3">3</OPTION>
                                                    <OPTION VALUE="4">4</OPTION>
                                                    <OPTION VALUE="5">5</OPTION>
                                                </SELECT>
                                                </FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Type</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="Forms Combo Box12" NAME="FormsComboBox12">
                                                    <OPTION VALUE="">- Not Select -</OPTION>
                                                    <OPTION VALUE="1">Normal</OPTION>
                                                    <OPTION VALUE="2">Honey Moon</OPTION>
                                                </SELECT>
                                                </FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#96C8FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Quota</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;min <INPUT ID="Forms Edit Field4" TYPE=TEXT NAME="minquota" VALUE="" SIZE=8 MAXLENGTH=8> - max <INPUT ID="Forms Edit Field5" TYPE=TEXT NAME="maxquota" VALUE="" SIZE=8 MAXLENGTH=8></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Require</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;min <INPUT ID="Forms Edit Field6" TYPE=TEXT NAME="minrequire" VALUE="" SIZE=8 MAXLENGTH=8> - max <INPUT ID="Forms Edit Field7" TYPE=TEXT NAME="maxrequire" VALUE="" SIZE=8 MAXLENGTH=8></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#96C8FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Price</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;min <INPUT ID="Forms Edit Field8" TYPE=TEXT NAME="mincost" VALUE="" SIZE=8 MAXLENGTH=8> - max <INPUT ID="Forms Edit Field9" TYPE=TEXT NAME="maxcost" VALUE="" SIZE=8 MAXLENGTH=8></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Start</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="Forms Combo Box6" NAME="minstartday">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">01</OPTION>
                                                    <OPTION VALUE="2">02</OPTION>
                                                    <OPTION VALUE="3">03</OPTION>
                                                    <OPTION VALUE="4">04</OPTION>
                                                    <OPTION VALUE="5">05</OPTION>
                                                    <OPTION VALUE="6">06</OPTION>
                                                    <OPTION VALUE="7">07</OPTION>
                                                    <OPTION VALUE="8">08</OPTION>
                                                    <OPTION VALUE="9">09</OPTION>
                                                    <OPTION VALUE="10">10</OPTION>
                                                    <OPTION VALUE="11">11</OPTION>
                                                    <OPTION VALUE="12">12</OPTION>
                                                    <OPTION VALUE="13">13</OPTION>
                                                    <OPTION VALUE="14">14</OPTION>
                                                    <OPTION VALUE="15">15</OPTION>
                                                    <OPTION VALUE="16">16</OPTION>
                                                    <OPTION VALUE="17">17</OPTION>
                                                    <OPTION VALUE="18">18</OPTION>
                                                    <OPTION VALUE="19">19</OPTION>
                                                    <OPTION VALUE="20">20</OPTION>
                                                    <OPTION VALUE="21">21</OPTION>
                                                    <OPTION VALUE="22">22</OPTION>
                                                    <OPTION VALUE="23">23</OPTION>
                                                    <OPTION VALUE="24">24</OPTION>
                                                    <OPTION VALUE="25">25</OPTION>
                                                    <OPTION VALUE="26">26</OPTION>
                                                    <OPTION VALUE="27">27</OPTION>
                                                    <OPTION VALUE="28">28</OPTION>
                                                    <OPTION VALUE="29">29</OPTION>
                                                    <OPTION VALUE="30">30</OPTION>
                                                    <OPTION VALUE="31">31</OPTION>
                                                </SELECT>
                                                <SELECT ID="Forms Combo Box7" NAME="minstartmonth">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">January</OPTION>
                                                    <OPTION VALUE="2">Febuary</OPTION>
                                                    <OPTION VALUE="3">March</OPTION>
                                                    <OPTION VALUE="4">April</OPTION>
                                                    <OPTION VALUE="5">May</OPTION>
                                                    <OPTION VALUE="6">June</OPTION>
                                                    <OPTION VALUE="7">July</OPTION>
                                                    <OPTION VALUE="8">August</OPTION>
                                                    <OPTION VALUE="9">September</OPTION>
                                                    <OPTION VALUE="10">October</OPTION>
                                                    <OPTION VALUE="11">November</OPTION>
                                                    <OPTION VALUE="12">December</OPTION>
                                                </SELECT>
                                                <SELECT ID="Forms Combo Box8" NAME="minstartyear">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="2003">2003</OPTION>
                                                    <OPTION VALUE="2004">2004</OPTION>
                                                </SELECT>
                                                </FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;- begin - **package start after this day</FONT>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="FormsComboBox1" NAME="maxstartday">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">01</OPTION>
                                                    <OPTION VALUE="2">02</OPTION>
                                                    <OPTION VALUE="3">03</OPTION>
                                                    <OPTION VALUE="4">04</OPTION>
                                                    <OPTION VALUE="5">05</OPTION>
                                                    <OPTION VALUE="6">06</OPTION>
                                                    <OPTION VALUE="7">07</OPTION>
                                                    <OPTION VALUE="8">08</OPTION>
                                                    <OPTION VALUE="9">09</OPTION>
                                                    <OPTION VALUE="10">10</OPTION>
                                                    <OPTION VALUE="11">11</OPTION>
                                                    <OPTION VALUE="12">12</OPTION>
                                                    <OPTION VALUE="13">13</OPTION>
                                                    <OPTION VALUE="14">14</OPTION>
                                                    <OPTION VALUE="15">15</OPTION>
                                                    <OPTION VALUE="16">16</OPTION>
                                                    <OPTION VALUE="17">17</OPTION>
                                                    <OPTION VALUE="18">18</OPTION>
                                                    <OPTION VALUE="19">19</OPTION>
                                                    <OPTION VALUE="20">20</OPTION>
                                                    <OPTION VALUE="21">21</OPTION>
                                                    <OPTION VALUE="22">22</OPTION>
                                                    <OPTION VALUE="23">23</OPTION>
                                                    <OPTION VALUE="24">24</OPTION>
                                                    <OPTION VALUE="25">25</OPTION>
                                                    <OPTION VALUE="26">26</OPTION>
                                                    <OPTION VALUE="27">27</OPTION>
                                                    <OPTION VALUE="28">28</OPTION>
                                                    <OPTION VALUE="29">29</OPTION>
                                                    <OPTION VALUE="30">30</OPTION>
                                                    <OPTION VALUE="31">31</OPTION>
                                                </SELECT>
                                                <SELECT ID="FormsComboBox2" NAME="maxstartmonth">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">January</OPTION>
                                                    <OPTION VALUE="2">Febuary</OPTION>
                                                    <OPTION VALUE="3">March</OPTION>
                                                    <OPTION VALUE="4">April</OPTION>
                                                    <OPTION VALUE="5">May</OPTION>
                                                    <OPTION VALUE="6">June</OPTION>
                                                    <OPTION VALUE="7">July</OPTION>
                                                    <OPTION VALUE="8">August</OPTION>
                                                    <OPTION VALUE="9">September</OPTION>
                                                    <OPTION VALUE="10">October</OPTION>
                                                    <OPTION VALUE="11">November</OPTION>
                                                    <OPTION VALUE="12">December</OPTION>
                                                </SELECT>
                                                <SELECT ID="FormsComboBox3" NAME="maxstartyear">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="2003">2003</OPTION>
                                                    <OPTION VALUE="2004">2004</OPTION>
                                                </SELECT>
                                                </FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;- end -</FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#96C8FF">
                                            <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Finish</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=602 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="FormsComboBox4" NAME="minfinishday">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">01</OPTION>
                                                    <OPTION VALUE="2">02</OPTION>
                                                    <OPTION VALUE="3">03</OPTION>
                                                    <OPTION VALUE="4">04</OPTION>
                                                    <OPTION VALUE="5">05</OPTION>
                                                    <OPTION VALUE="6">06</OPTION>
                                                    <OPTION VALUE="7">07</OPTION>
                                                    <OPTION VALUE="8">08</OPTION>
                                                    <OPTION VALUE="9">09</OPTION>
                                                    <OPTION VALUE="10">10</OPTION>
                                                    <OPTION VALUE="11">11</OPTION>
                                                    <OPTION VALUE="12">12</OPTION>
                                                    <OPTION VALUE="13">13</OPTION>
                                                    <OPTION VALUE="14">14</OPTION>
                                                    <OPTION VALUE="15">15</OPTION>
                                                    <OPTION VALUE="16">16</OPTION>
                                                    <OPTION VALUE="17">17</OPTION>
                                                    <OPTION VALUE="18">18</OPTION>
                                                    <OPTION VALUE="19">19</OPTION>
                                                    <OPTION VALUE="20">20</OPTION>
                                                    <OPTION VALUE="21">21</OPTION>
                                                    <OPTION VALUE="22">22</OPTION>
                                                    <OPTION VALUE="23">23</OPTION>
                                                    <OPTION VALUE="24">24</OPTION>
                                                    <OPTION VALUE="25">25</OPTION>
                                                    <OPTION VALUE="26">26</OPTION>
                                                    <OPTION VALUE="27">27</OPTION>
                                                    <OPTION VALUE="28">28</OPTION>
                                                    <OPTION VALUE="29">29</OPTION>
                                                    <OPTION VALUE="30">30</OPTION>
                                                    <OPTION VALUE="31">31</OPTION>
                                                </SELECT>
                                                <SELECT ID="FormsComboBox5" NAME="minfinishmonth">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">January</OPTION>
                                                    <OPTION VALUE="2">Febuary</OPTION>
                                                    <OPTION VALUE="3">March</OPTION>
                                                    <OPTION VALUE="4">April</OPTION>
                                                    <OPTION VALUE="5">May</OPTION>
                                                    <OPTION VALUE="6">June</OPTION>
                                                    <OPTION VALUE="7">July</OPTION>
                                                    <OPTION VALUE="8">August</OPTION>
                                                    <OPTION VALUE="9">September</OPTION>
                                                    <OPTION VALUE="10">October</OPTION>
                                                    <OPTION VALUE="11">November</OPTION>
                                                    <OPTION VALUE="12">December</OPTION>
                                                </SELECT>
                                                <SELECT ID="FormsComboBox6" NAME="minfinishyear">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="2003">2003</OPTION>
                                                    <OPTION VALUE="2004">2004</OPTION>
                                                </SELECT>
                                                </FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;- begin -</FONT>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">
                                                <SELECT ID="FormsComboBox7" NAME="maxfinishday">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">01</OPTION>
                                                    <OPTION VALUE="2">02</OPTION>
                                                    <OPTION VALUE="3">03</OPTION>
                                                    <OPTION VALUE="4">04</OPTION>
                                                    <OPTION VALUE="5">05</OPTION>
                                                    <OPTION VALUE="6">06</OPTION>
                                                    <OPTION VALUE="7">07</OPTION>
                                                    <OPTION VALUE="8">08</OPTION>
                                                    <OPTION VALUE="9">09</OPTION>
                                                    <OPTION VALUE="10">10</OPTION>
                                                    <OPTION VALUE="11">11</OPTION>
                                                    <OPTION VALUE="12">12</OPTION>
                                                    <OPTION VALUE="13">13</OPTION>
                                                    <OPTION VALUE="14">14</OPTION>
                                                    <OPTION VALUE="15">15</OPTION>
                                                    <OPTION VALUE="16">16</OPTION>
                                                    <OPTION VALUE="17">17</OPTION>
                                                    <OPTION VALUE="18">18</OPTION>
                                                    <OPTION VALUE="19">19</OPTION>
                                                    <OPTION VALUE="20">20</OPTION>
                                                    <OPTION VALUE="21">21</OPTION>
                                                    <OPTION VALUE="22">22</OPTION>
                                                    <OPTION VALUE="23">23</OPTION>
                                                    <OPTION VALUE="24">24</OPTION>
                                                    <OPTION VALUE="25">25</OPTION>
                                                    <OPTION VALUE="26">26</OPTION>
                                                    <OPTION VALUE="27">27</OPTION>
                                                    <OPTION VALUE="28">28</OPTION>
                                                    <OPTION VALUE="29">29</OPTION>
                                                    <OPTION VALUE="30">30</OPTION>
                                                    <OPTION VALUE="31">31</OPTION>
                                                </SELECT>
                                                <SELECT ID="FormsComboBox8" NAME="maxfinishmonth">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="1">January</OPTION>
                                                    <OPTION VALUE="2">Febuary</OPTION>
                                                    <OPTION VALUE="3">March</OPTION>
                                                    <OPTION VALUE="4">April</OPTION>
                                                    <OPTION VALUE="5">May</OPTION>
                                                    <OPTION VALUE="6">June</OPTION>
                                                    <OPTION VALUE="7">July</OPTION>
                                                    <OPTION VALUE="8">August</OPTION>
                                                    <OPTION VALUE="9">September</OPTION>
                                                    <OPTION VALUE="10">October</OPTION>
                                                    <OPTION VALUE="11">November</OPTION>
                                                    <OPTION VALUE="12">December</OPTION>
                                                </SELECT>
                                                <SELECT ID="FormsComboBox9" NAME="maxfinishyear">
                                                    <OPTION VALUE="0">--</OPTION>
                                                    <OPTION VALUE="2003">2003</OPTION>
                                                    <OPTION VALUE="2004">2004</OPTION>
                                                </SELECT>
                                                </FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;- end - **package finish before this day</FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                        <TD WIDTH=78 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT TYPE=SUBMIT NAME="FormsButton4" VALUE="Search" ID="FormsButton9"></FONT></TD>
                                        <TD BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                        </TD>
                                    </TR>
                                </TABLE>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=747 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30 VALIGN=MIDDLE WIDTH=747><HR ID="HRRule1" WIDTH=747 SIZE=1></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=193 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=193 HEIGHT=13><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=193 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=193>
                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                            <%if(time>0){%><b>result</b> total:<%=totalresult%> page:<%=currentpage%>/<%=totalpage%><HR><%}%>
<%
//loop show
if(time > 0 && ar != null){
  for(int i=0;i<ar.length;i++){
    PackageDetail pd =soapProxy.getPackageDetail(ar[i]);
   int package_id = ar[i];
  String name = pd.getPackageName();
  String start = pd.getStartdate();
  String finish = pd.getFinishdate();
  String deadline = pd.getDeadline();
  int price = pd.getCost();
    %>
</TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=24><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=24 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=703>
                            <FORM NAME="Table27FORM" ACTION="jobreservepage.jsp" METHOD=GET>
                                <INPUT TYPE=HIDDEN NAME="package_id" VALUE="<%=package_id%>">

                                <TABLE ID="Table27" BORDER=0 CELLSPACING=1 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TD WIDTH=37 BGCOLOR="#0066FF" HEIGHT=16>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ID</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=164 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Name</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=85 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Deadline</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=76 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Start</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=81 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Finish</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=54 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>price</B></FONT><B></B></P>
                                        </TD>
                                        <%
if(SScustomer_id>0){
%>
                                        <TD WIDTH=76 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Cart</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=59 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>quantity</B></FONT><B></B></P>
                                        </TD>
                                        <TD WIDTH=61 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Booking</B></FONT><B></B></P>
                                        </TD>
                                        <%}%>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=37 BGCOLOR="#96C8FF" HEIGHT=24>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="51%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table28" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%=package_id%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=164 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="11%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table29" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><A href="packagedetail.jsp?package_id=<%=package_id%>"><%=name%></a></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=85 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="22%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table30" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><%=deadline%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=76 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="25%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table31" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><%=start%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=81 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="23%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table32" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <nobr><%=finish%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=54 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="35%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table33" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%=price%></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        
<%
if(SScustomer_id>0){
%>
                                        <TD WIDTH=76 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="25%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                    <TR>
                                                        <TD>
                                                            <TABLE ID="Table34" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH="100%">
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                    </TD>
                                                                </TR>
                                                            </TABLE>
                                                            <select name="contact_id" ><%
        CustomerContactResult crs[] = soapProxy.getCustomerContact(SScustomer_id);
      for(int j=0;j<SScontact_id.length;j++){
        if(crs[j].getContactStatus()<3){
          %><option value="<%=SScontact_id[j]%>">Cart #<%=j+1%> : <%=SScontact_id[j]%></option><%
        }
      }
      %><option value="0">new</option></select></TD>
                                                    </TR>
                                                </TABLE>
                                                &nbsp;</TD>
                                        <TD WIDTH=59 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Edit Field19" TYPE=TEXT NAME="quantity" VALUE="1" SIZE=5 MAXLENGTH=10></FONT></TD>
                                        <TD WIDTH=61 BGCOLOR="#96C8FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT TYPE=SUBMIT NAME="FormsButton17" VALUE="Book!" ID="Forms Button17"></FONT></TD>
                                        <%}%>
                                    </TR>
                                </TABLE>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=19></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747>    <%
  }//end for
}//end if
%><br>
                            <TABLE ID="Table36" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=134 HEIGHT=16>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=19 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                                        <table>
<tr>
<td>
<%
//link panel
if(currentpage>1){
%>
<nobr><form NAME="Search" METHOD="POST">
<INPUT TYPE=hidden NAME="place_id" VALUE="<%=place_id%>">
<INPUT TYPE=hidden NAME="region" VALUE="<%=region%>">
<INPUT TYPE=hidden NAME="city_id" VALUE="<%=city_id%>">
<INPUT TYPE=hidden NAME="country_id" VALUE="<%=country_id%>">
<INPUT TYPE=hidden NAME="continent_id" VALUE="<%=continent_id%>">
<INPUT TYPE=hidden NAME="vehicle_id" VALUE="<%=vehicle_id%>">
<INPUT TYPE=hidden NAME="vehicle_grade" VALUE="<%=vehicle_grade%>">
<INPUT TYPE=hidden NAME="Hotel_id" VALUE="<%=Hotel_id%>">
<INPUT TYPE=hidden NAME="Hotel_grade" VALUE="<%=Hotel_grade%>">
<INPUT TYPE=hidden NAME="act_id" VALUE="<%=act_id%>">
<INPUT TYPE=hidden NAME="type" VALUE="<%=type%>">
<INPUT TYPE=hidden NAME="minquota" VALUE="<%if(minquota>0){%><%=minquota%><%}%>">
<INPUT TYPE=hidden NAME="maxquota" VALUE="<%if(maxquota>0){%><%=maxquota%><%}%>">
<INPUT TYPE=hidden NAME="minrequire" VALUE="<%if(minrequire>0){%><%=minrequire%><%}%>">
<INPUT TYPE=hidden NAME="maxrequire" VALUE="<%if(maxrequire>0){%><%=maxrequire%><%}%>">
<INPUT TYPE=hidden NAME="mincost" VALUE="<%if(mincost>0){%><%=mincost%><%}%>">
<INPUT TYPE=hidden NAME="maxcost" VALUE="<%if(maxcost>0){%><%=maxcost%><%}%>">
<INPUT TYPE=hidden NAME="minstartday" VALUE="<%=minstartday%>">
<INPUT TYPE=hidden NAME="minstartmonth" VALUE="<%=minstartmonth%>">
<INPUT TYPE=hidden NAME="minstartyear" VALUE="<%=minstartyear%>">
<INPUT TYPE=hidden NAME="maxstartday" VALUE="<%=maxstartday%>">
<INPUT TYPE=hidden NAME="maxstartmonth" VALUE="<%=maxstartmonth%>">
<INPUT TYPE=hidden NAME="maxstartyear" VALUE="<%=maxstartyear%>">
<INPUT TYPE=hidden NAME="minfinishday" VALUE="<%=minfinishday%>">
<INPUT TYPE=hidden NAME="minfinishmonth" VALUE="<%=minfinishmonth%>">
<INPUT TYPE=hidden NAME="minfinishyear" VALUE="<%=minfinishyear%>">
<INPUT TYPE=hidden NAME="maxfinishday" VALUE="<%=maxfinishday%>">
<INPUT TYPE=hidden NAME="maxfinishmonth" VALUE="<%=maxfinishmonth%>">
<INPUT TYPE=hidden NAME="maxfinishyear" VALUE="<%=maxfinishyear%>">
<INPUT TYPE=hidden NAME="time" VALUE="1">
<INPUT TYPE=hidden NAME="currentpage" VALUE="1">
<INPUT TYPE=hidden NAME="resultperpage" VALUE="<%=resultperpage%>">
<input TYPE=submit VALUE="|<">
</form>
<%}%></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                    <TD WIDTH=136>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=21 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                                        <table>
<tr>
<td>
<%
if(currentpage>1){
%>
<nobr><form NAME="Search" METHOD="POST">
<INPUT TYPE=hidden NAME="place_id" VALUE="<%=place_id%>">
<INPUT TYPE=hidden NAME="region" VALUE="<%=region%>">
<INPUT TYPE=hidden NAME="city_id" VALUE="<%=city_id%>">
<INPUT TYPE=hidden NAME="country_id" VALUE="<%=country_id%>">
<INPUT TYPE=hidden NAME="continent_id" VALUE="<%=continent_id%>">
<INPUT TYPE=hidden NAME="vehicle_id" VALUE="<%=vehicle_id%>">
<INPUT TYPE=hidden NAME="vehicle_grade" VALUE="<%=vehicle_grade%>">
<INPUT TYPE=hidden NAME="Hotel_id" VALUE="<%=Hotel_id%>">
<INPUT TYPE=hidden NAME="Hotel_grade" VALUE="<%=Hotel_grade%>">
<INPUT TYPE=hidden NAME="act_id" VALUE="<%=act_id%>">
<INPUT TYPE=hidden NAME="type" VALUE="<%=type%>">
<INPUT TYPE=hidden NAME="minquota" VALUE="<%if(minquota>0){%><%=minquota%><%}%>">
<INPUT TYPE=hidden NAME="maxquota" VALUE="<%if(maxquota>0){%><%=maxquota%><%}%>">
<INPUT TYPE=hidden NAME="minrequire" VALUE="<%if(minrequire>0){%><%=minrequire%><%}%>">
<INPUT TYPE=hidden NAME="maxrequire" VALUE="<%if(maxrequire>0){%><%=maxrequire%><%}%>">
<INPUT TYPE=hidden NAME="mincost" VALUE="<%if(mincost>0){%><%=mincost%><%}%>">
<INPUT TYPE=hidden NAME="maxcost" VALUE="<%if(maxcost>0){%><%=maxcost%><%}%>">
<INPUT TYPE=hidden NAME="minstartday" VALUE="<%=minstartday%>">
<INPUT TYPE=hidden NAME="minstartmonth" VALUE="<%=minstartmonth%>">
<INPUT TYPE=hidden NAME="minstartyear" VALUE="<%=minstartyear%>">
<INPUT TYPE=hidden NAME="maxstartday" VALUE="<%=maxstartday%>">
<INPUT TYPE=hidden NAME="maxstartmonth" VALUE="<%=maxstartmonth%>">
<INPUT TYPE=hidden NAME="maxstartyear" VALUE="<%=maxstartyear%>">
<INPUT TYPE=hidden NAME="minfinishday" VALUE="<%=minfinishday%>">
<INPUT TYPE=hidden NAME="minfinishmonth" VALUE="<%=minfinishmonth%>">
<INPUT TYPE=hidden NAME="minfinishyear" VALUE="<%=minfinishyear%>">
<INPUT TYPE=hidden NAME="maxfinishday" VALUE="<%=maxfinishday%>">
<INPUT TYPE=hidden NAME="maxfinishmonth" VALUE="<%=maxfinishmonth%>">
<INPUT TYPE=hidden NAME="maxfinishyear" VALUE="<%=maxfinishyear%>">
<INPUT TYPE=hidden NAME="time" VALUE="1">
<INPUT TYPE=hidden NAME="currentpage" VALUE="<%=currentpage-1%>">
<INPUT TYPE=hidden NAME="resultperpage" VALUE="<%=resultperpage%>">
<input TYPE=submit VALUE="<<">
</form>
<%}%>
</td></tr></table></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                    <TD WIDTH=187>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=24 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD><table>
<tr>
<%
int p = 1;
for(p=1; p <= totalpage; p++){
%>
<td><form NAME="Search" METHOD="POST">
<INPUT TYPE=hidden NAME="place_id" VALUE="<%=place_id%>">
<INPUT TYPE=hidden NAME="region" VALUE="<%=region%>">
<INPUT TYPE=hidden NAME="city_id" VALUE="<%=city_id%>">
<INPUT TYPE=hidden NAME="country_id" VALUE="<%=country_id%>">
<INPUT TYPE=hidden NAME="continent_id" VALUE="<%=continent_id%>">
<INPUT TYPE=hidden NAME="vehicle_id" VALUE="<%=vehicle_id%>">
<INPUT TYPE=hidden NAME="vehicle_grade" VALUE="<%=vehicle_grade%>">
<INPUT TYPE=hidden NAME="Hotel_id" VALUE="<%=Hotel_id%>">
<INPUT TYPE=hidden NAME="Hotel_grade" VALUE="<%=Hotel_grade%>">
<INPUT TYPE=hidden NAME="act_id" VALUE="<%=act_id%>">
<INPUT TYPE=hidden NAME="type" VALUE="<%=type%>">
<INPUT TYPE=hidden NAME="minquota" VALUE="<%if(minquota>0){%><%=minquota%><%}%>">
<INPUT TYPE=hidden NAME="maxquota" VALUE="<%if(maxquota>0){%><%=maxquota%><%}%>">
<INPUT TYPE=hidden NAME="minrequire" VALUE="<%if(minrequire>0){%><%=minrequire%><%}%>">
<INPUT TYPE=hidden NAME="maxrequire" VALUE="<%if(maxrequire>0){%><%=maxrequire%><%}%>">
<INPUT TYPE=hidden NAME="mincost" VALUE="<%if(mincost>0){%><%=mincost%><%}%>">
<INPUT TYPE=hidden NAME="maxcost" VALUE="<%if(maxcost>0){%><%=maxcost%><%}%>">
<INPUT TYPE=hidden NAME="minstartday" VALUE="<%=minstartday%>">
<INPUT TYPE=hidden NAME="minstartmonth" VALUE="<%=minstartmonth%>">
<INPUT TYPE=hidden NAME="minstartyear" VALUE="<%=minstartyear%>">
<INPUT TYPE=hidden NAME="maxstartday" VALUE="<%=maxstartday%>">
<INPUT TYPE=hidden NAME="maxstartmonth" VALUE="<%=maxstartmonth%>">
<INPUT TYPE=hidden NAME="maxstartyear" VALUE="<%=maxstartyear%>">
<INPUT TYPE=hidden NAME="minfinishday" VALUE="<%=minfinishday%>">
<INPUT TYPE=hidden NAME="minfinishmonth" VALUE="<%=minfinishmonth%>">
<INPUT TYPE=hidden NAME="minfinishyear" VALUE="<%=minfinishyear%>">
<INPUT TYPE=hidden NAME="maxfinishday" VALUE="<%=maxfinishday%>">
<INPUT TYPE=hidden NAME="maxfinishmonth" VALUE="<%=maxfinishmonth%>">
<INPUT TYPE=hidden NAME="maxfinishyear" VALUE="<%=maxfinishyear%>">
<INPUT TYPE=hidden NAME="time" VALUE="1">
<INPUT TYPE=hidden NAME="currentpage" VALUE="<%=p%>">
<INPUT TYPE=hidden NAME="resultperpage" VALUE="<%=resultperpage%>">
<input TYPE=submit VALUE="<%=p%>">
</form></td>
<%
}
%>
</tr></table>

                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                    <TD WIDTH=136>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=20 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                                        <table>
<tr>
<td>
<%
if(currentpage<totalpage){
%>
<nobr><form NAME="Search" METHOD="POST">
<INPUT TYPE=hidden NAME="place_id" VALUE="<%=place_id%>">
<INPUT TYPE=hidden NAME="region" VALUE="<%=region%>">
<INPUT TYPE=hidden NAME="city_id" VALUE="<%=city_id%>">
<INPUT TYPE=hidden NAME="country_id" VALUE="<%=country_id%>">
<INPUT TYPE=hidden NAME="continent_id" VALUE="<%=continent_id%>">
<INPUT TYPE=hidden NAME="vehicle_id" VALUE="<%=vehicle_id%>">
<INPUT TYPE=hidden NAME="vehicle_grade" VALUE="<%=vehicle_grade%>">
<INPUT TYPE=hidden NAME="Hotel_id" VALUE="<%=Hotel_id%>">
<INPUT TYPE=hidden NAME="Hotel_grade" VALUE="<%=Hotel_grade%>">
<INPUT TYPE=hidden NAME="act_id" VALUE="<%=act_id%>">
<INPUT TYPE=hidden NAME="type" VALUE="<%=type%>">
<INPUT TYPE=hidden NAME="minquota" VALUE="<%if(minquota>0){%><%=minquota%><%}%>">
<INPUT TYPE=hidden NAME="maxquota" VALUE="<%if(maxquota>0){%><%=maxquota%><%}%>">
<INPUT TYPE=hidden NAME="minrequire" VALUE="<%if(minrequire>0){%><%=minrequire%><%}%>">
<INPUT TYPE=hidden NAME="maxrequire" VALUE="<%if(maxrequire>0){%><%=maxrequire%><%}%>">
<INPUT TYPE=hidden NAME="mincost" VALUE="<%if(mincost>0){%><%=mincost%><%}%>">
<INPUT TYPE=hidden NAME="maxcost" VALUE="<%if(maxcost>0){%><%=maxcost%><%}%>">
<INPUT TYPE=hidden NAME="minstartday" VALUE="<%=minstartday%>">
<INPUT TYPE=hidden NAME="minstartmonth" VALUE="<%=minstartmonth%>">
<INPUT TYPE=hidden NAME="minstartyear" VALUE="<%=minstartyear%>">
<INPUT TYPE=hidden NAME="maxstartday" VALUE="<%=maxstartday%>">
<INPUT TYPE=hidden NAME="maxstartmonth" VALUE="<%=maxstartmonth%>">
<INPUT TYPE=hidden NAME="maxstartyear" VALUE="<%=maxstartyear%>">
<INPUT TYPE=hidden NAME="minfinishday" VALUE="<%=minfinishday%>">
<INPUT TYPE=hidden NAME="minfinishmonth" VALUE="<%=minfinishmonth%>">
<INPUT TYPE=hidden NAME="minfinishyear" VALUE="<%=minfinishyear%>">
<INPUT TYPE=hidden NAME="maxfinishday" VALUE="<%=maxfinishday%>">
<INPUT TYPE=hidden NAME="maxfinishmonth" VALUE="<%=maxfinishmonth%>">
<INPUT TYPE=hidden NAME="maxfinishyear" VALUE="<%=maxfinishyear%>">
<INPUT TYPE=hidden NAME="time" VALUE="1">
<INPUT TYPE=hidden NAME="currentpage" VALUE="<%=currentpage+1%>">
<INPUT TYPE=hidden NAME="resultperpage" VALUE="<%=resultperpage%>">
<input TYPE=submit VALUE=">>">
</form>
<%}%>
</td></tr></table></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                    <TD WIDTH=136>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=20 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                                        <table>
<tr>
<td>
<%
if(currentpage<totalpage){
%>
<nobr><form NAME="Search" METHOD="POST">
<INPUT TYPE=hidden NAME="place_id" VALUE="<%=place_id%>">
<INPUT TYPE=hidden NAME="region" VALUE="<%=region%>">
<INPUT TYPE=hidden NAME="city_id" VALUE="<%=city_id%>">
<INPUT TYPE=hidden NAME="country_id" VALUE="<%=country_id%>">
<INPUT TYPE=hidden NAME="continent_id" VALUE="<%=continent_id%>">
<INPUT TYPE=hidden NAME="vehicle_id" VALUE="<%=vehicle_id%>">
<INPUT TYPE=hidden NAME="vehicle_grade" VALUE="<%=vehicle_grade%>">
<INPUT TYPE=hidden NAME="Hotel_id" VALUE="<%=Hotel_id%>">
<INPUT TYPE=hidden NAME="Hotel_grade" VALUE="<%=Hotel_grade%>">
<INPUT TYPE=hidden NAME="act_id" VALUE="<%=act_id%>">
<INPUT TYPE=hidden NAME="type" VALUE="<%=type%>">
<INPUT TYPE=hidden NAME="minquota" VALUE="<%if(minquota>0){%><%=minquota%><%}%>">
<INPUT TYPE=hidden NAME="maxquota" VALUE="<%if(maxquota>0){%><%=maxquota%><%}%>">
<INPUT TYPE=hidden NAME="minrequire" VALUE="<%if(minrequire>0){%><%=minrequire%><%}%>">
<INPUT TYPE=hidden NAME="maxrequire" VALUE="<%if(maxrequire>0){%><%=maxrequire%><%}%>">
<INPUT TYPE=hidden NAME="mincost" VALUE="<%if(mincost>0){%><%=mincost%><%}%>">
<INPUT TYPE=hidden NAME="maxcost" VALUE="<%if(maxcost>0){%><%=maxcost%><%}%>">
<INPUT TYPE=hidden NAME="minstartday" VALUE="<%=minstartday%>">
<INPUT TYPE=hidden NAME="minstartmonth" VALUE="<%=minstartmonth%>">
<INPUT TYPE=hidden NAME="minstartyear" VALUE="<%=minstartyear%>">
<INPUT TYPE=hidden NAME="maxstartday" VALUE="<%=maxstartday%>">
<INPUT TYPE=hidden NAME="maxstartmonth" VALUE="<%=maxstartmonth%>">
<INPUT TYPE=hidden NAME="maxstartyear" VALUE="<%=maxstartyear%>">
<INPUT TYPE=hidden NAME="minfinishday" VALUE="<%=minfinishday%>">
<INPUT TYPE=hidden NAME="minfinishmonth" VALUE="<%=minfinishmonth%>">
<INPUT TYPE=hidden NAME="minfinishyear" VALUE="<%=minfinishyear%>">
<INPUT TYPE=hidden NAME="maxfinishday" VALUE="<%=maxfinishday%>">
<INPUT TYPE=hidden NAME="maxfinishmonth" VALUE="<%=maxfinishmonth%>">
<INPUT TYPE=hidden NAME="maxfinishyear" VALUE="<%=maxfinishyear%>">
<INPUT TYPE=hidden NAME="time" VALUE="1">
<INPUT TYPE=hidden NAME="currentpage" VALUE="<%=totalpage%>">
<INPUT TYPE=hidden NAME="resultperpage" VALUE="<%=resultperpage%>">
<input TYPE=submit VALUE=">|">
</form>
<%
}
%>
</td></tr></table></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=14></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/packagelistpage.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package&nbsp;List</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [Search&nbsp;Package] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 