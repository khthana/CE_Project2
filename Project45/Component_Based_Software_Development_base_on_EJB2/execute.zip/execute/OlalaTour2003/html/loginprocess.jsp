<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<%
//getParameter
  String username = "";
  if ( request.getParameter("username") != null )
    username = new String(request.getParameter("username").getBytes("UTF-8"),"UTF-8");
  String password = "";
  if ( request.getParameter("password") != null )
    password = new String(request.getParameter("password").getBytes("UTF-8"),"UTF-8");
%>
<%
//logIn
  CustomerResult rs = soapProxy.logIn(username,password);
%>
<%
  int contact_array[] = null;
  //get contact array
  if (rs != null){
    CustomerContactResult crs[] = soapProxy.getCustomerContact(rs.getCustomerId());
    contact_array = new int[crs.length];
    for(int i=0;i<crs.length;i++){
      contact_array[i] = crs[i].getTourContactId();
    }
  }

//set session & redirect
  if (rs != null){
    session.putValue("customer_id",Integer.toString(rs.getCustomerId()));
    session.putValue("contact_id",contact_array);
    session.putValue("username",rs.getUsername());
    session.removeValue("notice");
    response.sendRedirect("customerdetail.jsp");
  }else{
    session.removeValue("customer_id");
    session.removeValue("contact_id");
    session.removeValue("username");
    session.putValue("notice","Incorect username or password.");
    response.sendRedirect("loginpage.jsp");
  }
%>