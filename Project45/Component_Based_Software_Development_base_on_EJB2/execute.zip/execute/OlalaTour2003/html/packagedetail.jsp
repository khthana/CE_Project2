<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Package Detail</TITLE>
<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(packagedetailLayout, 747, 458))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    <%
  //get parameter
  int package_id = 0;
  if ( request.getParameter("package_id") != null )
    package_id = Integer.parseInt(request.getParameter("package_id"));
%>
<%
      PackageDetail pd = null;
      pd = soapProxy.getPackageDetail(package_id);
%>
    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=125 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=125>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=125>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton1',1)" onMouseOut="F_roll('NavigationButton1',0)"><IMG ID="NavigationButton1" NAME="NavigationButton1" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton2',1)" onMouseOut="F_roll('NavigationButton2',0)"><IMG ID="NavigationButton2" NAME="NavigationButton2" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Search_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Search_NRcitybut2.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton3',1)" onMouseOut="F_roll('NavigationButton3',0)"><IMG ID="NavigationButton3" NAME="NavigationButton3" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Package_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Package_NRcitybut2.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton4',1)" onMouseOut="F_roll('NavigationButton4',0)"><IMG ID="NavigationButton4" NAME="NavigationButton4" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=286 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=28 HEIGHT=32><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=28 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=258><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=258 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=258>
                            <P><B><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#000096" SIZE="+2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package Detail.</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=26 HEIGHT=4><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=26 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=700>
                            <TABLE ID="Table27" BORDER=1 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#000096" HEIGHT=16>
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>ID</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#000096">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table29" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getPackageId()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Name</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table30" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getPackageName()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Descript</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table31" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
 <%=pd.getPackageDescript()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Type</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table32" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getType()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Deadline</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table33" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getDeadline()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Start</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table34" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getStartdate()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF" HEIGHT=16>
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Finish</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table35" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getFinishdate()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Price</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table36" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getCost()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#78B4FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Quantity</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table37" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%=pd.getQuantity()%> / <%=pd.getQuota()%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#5AA0FF" HEIGHT=16>
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Place</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#5AA0FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table38" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%
//place_name , region , city_name , country_name , continent_name
  String place_name[] = pd.getPlaceName();
  String region[] = pd.getRegion();
  String city_name[] = pd.getCityName();
  String country_name[] = pd.getCountryName();
  String continent_name[] = pd.getContinentName();
  for(int i=0;i<place_name.length;i++){
    %><%=city_name[i]+"/"+country_name[i]%> - <%
  }
%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#3C8CFF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Vehicle</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#3C8CFF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table39" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%
 String vclass[] = {""," Special Class "," Normal Class "," Economy Class "};
//vehicle_name , vehicle_grade 
  String vehicle_name[] = pd.getVehicleName();
  int vehicle_grade[] = pd.getVehicleGrade();
  for(int i=0;i<vehicle_name.length;i++){
  if(vehicle_name!=null&&vehicle_grade!=null){
    %><%=vehicle_name[i]+":"+vclass[vehicle_grade[i]]%> - <%}
  }
%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#0066FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Activity</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#0066FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table41" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr>
<%
//act_name
  String act_name[] = pd.getActName();;
  if(act_name!=null){
  for(int i=0;i<act_name.length;i++){
    %><%=act_name[i]%> - <%}
  }
%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <%
if(SScustomer_id>0){
%>
<form action="jobreservepage.jsp">
<input type="hidden" name="package_id" value="<%=package_id%>">
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#000096">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Cart :</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#000096">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="3%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table28" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <nobr><%
    if(SScontact_id!=null){
      CustomerContactResult crs[] = soapProxy.getCustomerContact(SScustomer_id);
      %><select name="contact_id" ><%
      for(int j=0;j<SScontact_id.length;j++){
        if(crs[j].getContactStatus()<3){
          %><option value="<%=SScontact_id[j]%>">Cart # <%=j+1%>:<%=SScontact_id[j]%></option><%
        }
      }
      %><option value="0">new</option></select><%
    }
%></TD>
                                                </TR>
                                            </TABLE>
                                            &nbsp;</TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#000096" HEIGHT=16>
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Quantity :</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=492 BGCOLOR="#000096">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField20" TYPE=TEXT NAME="quantity" VALUE="1" SIZE=10 MAXLENGTH=10> <INPUT TYPE="button" onclick="form.FormsEditField20.value = eval(form.FormsEditField20.value)+1" value="+">
<INPUT TYPE="button" onclick="form.FormsEditField20.value = eval(form.FormsEditField20.value)-1" value="-"></FONT></TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=202 BGCOLOR="#000096">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT TYPE=SUBMIT NAME="FormsButton18" VALUE="Reserve" ID="Forms Button18"></FONT></TD>
                                    <TD BGCOLOR="#000096">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                    </TD>
                                </TR>
                                </form>
<%}%>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=458 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=25 HEIGHT=29><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=25 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=433><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=433 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=433>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  if you want to reserve this package click <B>Reserve</B></FONT><B></B></P>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=69></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/packagelistpage.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package&nbsp;List</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/search.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Search&nbsp;Package</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 