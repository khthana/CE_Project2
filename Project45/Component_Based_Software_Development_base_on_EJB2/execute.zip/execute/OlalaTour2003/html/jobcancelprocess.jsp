<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<%
//get parameter
  int contact_id = 0;
  if ( request.getParameter("contact_id") != null )
    if ( request.getParameter("contact_id").length() > 0 )
      contact_id = Integer.parseInt(request.getParameter("contact_id"));
  int job_id = 0;
  if ( request.getParameter("job_id") != null )
    if ( request.getParameter("job_id").length() > 0 )
      job_id = Integer.parseInt(request.getParameter("job_id"));
%>
<%
//cancel
  BookingResult br = null;
  br = soapProxy.cancelBooking(contact_id,job_id) ;
%>
<%
  if(br!=null){
    session.putValue("notice","Cancel your job complete.");
  }
  else{
    session.putValue("notice","Cancel your job fail.");
  }
  //redirect
  response.sendRedirect("contactlistpage.jsp");
%>