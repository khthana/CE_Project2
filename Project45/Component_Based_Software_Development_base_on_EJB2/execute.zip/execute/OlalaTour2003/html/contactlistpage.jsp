<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Your Shopping Cart</TITLE>
<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function rusure(){ return confirm("Are You Sure ?"); }
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(contactlistpageLayout, 747, 615))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    <%
//list
  CustomerContactResult  rs[] = null;
  rs = soapProxy.getCustomerContact(SScustomer_id) ;
%>


    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=125 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=125>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=125>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton1',1)" onMouseOut="F_roll('NavigationButton1',0)"><IMG ID="NavigationButton1" NAME="NavigationButton1" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton2',1)" onMouseOut="F_roll('NavigationButton2',0)"><IMG ID="NavigationButton2" NAME="NavigationButton2" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Search_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Search_NRcitybut2.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton3',1)" onMouseOut="F_roll('NavigationButton3',0)"><IMG ID="NavigationButton3" NAME="NavigationButton3" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Package_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Package_NRcitybut2.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton4',1)" onMouseOut="F_roll('NavigationButton4',0)"><IMG ID="NavigationButton4" NAME="NavigationButton4" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=724 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=23 HEIGHT=31><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=23 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=701><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=701 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=701><%
if(rs.length<=0){
%>
                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF0000" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>No item in your Cart.</B> </FONT></P>
                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                            <%}%></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=724 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=22><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=22 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=702><%
if(SSnotice!=""){
%>
                            <P ALIGN=CENTER><B><FONT COLOR="#FF0000" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><IMG ID="Picture1" HEIGHT=32 WIDTH=32 SRC="../assets/images/autogen/a_warn.gif" VSPACE=0 HSPACE=0 ALIGN="TOP" BORDER=0 ALT=""><%=SSnotice%></FONT></B><%}%></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=22><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=22 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=700><%
//show
if(rs!=null){
  for(int i=0;i<rs.length;i++){
    int tour_contact_id = rs[i].getTourContactId();
    String contact_deadline = rs[i].getDeadline();
    int total_pay_amount = rs[i].getTotalPayRemain();
    int contact_status = rs[i].getContactStatus();
%>






                            <TABLE ID="Table3" BORDER=0 CELLSPACING=0 CELLPADDING=2 WIDTH="100%">
                                <TR>
                                    <TD COLSPAN=3 BGCOLOR="#000096" HEIGHT=26>
                                        <P><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<IMG ID="Picture10" HEIGHT=26 WIDTH=26 SRC="../assets/images/cart1.gif" VSPACE=0 HSPACE=0 ALIGN="MIDDLE" BORDER=0 ALT="Cart ID : <%=tour_contact_id%>"><FONT COLOR="#FFFFFF" > <%=i+1%>. ID : <b><%=tour_contact_id%></b></FONT>
</FONT></TD>
                                    <TD COLSPAN=4 BGCOLOR="#000096">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><%if(contact_status==1){%><B>Cancel This Cart Click Here.</B><%}%> <%
if(contact_status==1){
%><A HREF="contactcancelprocess.jsp?contact_id=<%=tour_contact_id%>"><IMG ID="Picture11" HEIGHT=26 WIDTH=26 SRC="../assets/images/autogen/a_stop.gif" VSPACE=0 HSPACE=0 ALIGN="MIDDLE" BORDER=0  onclick="return(rusure())" ALT="Cancel Cart : <%=tour_contact_id%>"></A><%}%></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"> </FONT></TD>
                                </TR>
                                <%
        ContactJobResult cjr[] = null;
        cjr = soapProxy.getContactJob(tour_contact_id);
        for(int j=0;j<cjr.length;j++){

          int job_id = cjr[j].getJobId();
	  String startdate = cjr[j].getStartdate();
	  String package_name = cjr[j].getPackageName();	

	  BookingResult br = soapProxy.getJobDetail(job_id);

	  int package_id = br.getPackageId();		
	  String reserve_date = br.getReserveDate();		
	  String reserve_deadline = br.getDeadline();			
	  int reserve_price = br.getReservePrice();		
 	  int reserve_status = br.getReserveStatus();
	  int reserve_quantity = br.getReserveQuantity();	
%>

                                <TR>
                                    <TD COLSPAN=3 BGCOLOR="#0066FF" HEIGHT=26>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>&nbsp;<A HREF="jobdetail.jsp?job_id=<%=job_id%>" TARGET="_blank"><IMG ID="Picture12" HEIGHT=26 WIDTH=26 SRC="../assets/images/info.jpg" VSPACE=0 HSPACE=0 ALIGN="TOP" BORDER=0 ALT="Job Detail : <%=job_id%>"></A><A HREF="jobdetail.jsp?job_id=<%=job_id%>" TARGET="_blank"><FONT COLOR="#FFFFFF"> Job <%=j+1%>. ID : <b><%=job_id%></b></FONT></a>  ...</B></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>click i to see info.</B></FONT><B></B></TD>
                                    <TD COLSPAN=4 BGCOLOR="#0066FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><%if(reserve_status==1){ %><B>Cancel This Job Click Here.</B><%}%> <%
if(reserve_status==1){
%><A HREF="jobcancelprocess.jsp?contact_id=<%=tour_contact_id%>&job_id=<%=job_id%>"><IMG ID="Picture13" HEIGHT=26 WIDTH=26 SRC="../assets/images/autogen/a_stop.gif" VSPACE=0 HSPACE=0 ALIGN="TOP" BORDER=0  onclick="return(rusure())" ALT="Cancel Job : <%=job_id%>"></A><%}%></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"> </FONT></TD>
                                </TR>
                                <TR>
                                    <form action="jobeditprocess.jsp" method="post" >
<input type="hidden" name="contact_id" value="<%=tour_contact_id%>">
<input type="hidden" name="job_id" value="<%=job_id%>">
                                    <TD WIDTH=136 BGCOLOR="#1E78FF" HEIGHT=18>
                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<A HREF="packagedetail.jsp?package_id=<%=package_id%>" TARGET="_blank"><IMG ID="Picture14" HEIGHT=26 WIDTH=26 SRC="../assets/images/info.jpg" VSPACE=0 HSPACE=0 ALIGN="MIDDLE" BORDER=0 ALT="Package Detail : <%=package_id%>"></A><A HREF="packagedetail.jsp?package_id=<%=package_id%>" TARGET="_blank"><FONT COLOR="#FFFFFF"><b><%=package_name%></b></FONT></a> </FONT></TD>
                                    <TD WIDTH=142 BGCOLOR="#1E78FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>package ID : <INPUT ID="FormsEditField6" TYPE=TEXT NAME="package_id" VALUE="<%=package_id%>" SIZE=4 MAXLENGTH=15></B></FONT><B></B></TD>
                                    <TD COLSPAN=2 BGCOLOR="#1E78FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>quantity :</B></FONT><B></B></P>
                                    </TD>
                                    <TD WIDTH=154 BGCOLOR="#1E78FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField5" TYPE=TEXT NAME="quantity" VALUE="<%=reserve_quantity%>" SIZE=4 MAXLENGTH=21> <INPUT TYPE="button" onclick="form.FormsEditField5.value = eval(form.FormsEditField5.value)+1" value="+">
<INPUT TYPE="button" onclick="form.FormsEditField5.value = eval(form.FormsEditField5.value)-1" value="-"></FONT></TD>
                                    <TD WIDTH=51 BGCOLOR="#1E78FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                    </TD>
                                    <TD WIDTH=101 BGCOLOR="#1E78FF">
                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><%
if(reserve_status<3){
%><INPUT TYPE=SUBMIT NAME="FormsButton4" VALUE="Change!" ID="FormsButton7"  onclick="return(rusure())"><%}%> </FONT></TD>
                                    </form>
                                </TR>
                                <TR>
                                    <TD WIDTH=136 BGCOLOR="#3C8CFF" HEIGHT=18>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">deadline</FONT></P>
                                    </TD>
                                    <TD COLSPAN=4 BGCOLOR="#3C8CFF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="4%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table27" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <b><nobr><%=reserve_deadline%></b></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                    <TD WIDTH=51 BGCOLOR="#3C8CFF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">price</FONT></P>
                                    </TD>
                                    <TD WIDTH=101 BGCOLOR="#3C8CFF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="18%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table28" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <b><%=reserve_price%></b></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <%
}
%>
                                <TR>
                                    <TD WIDTH=136 BGCOLOR="#5AA0FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">deadline</FONT></P>
                                    </TD>
                                    <TD COLSPAN=4 BGCOLOR="#5AA0FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="4%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table9" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <b><nobr><%=contact_deadline%></b></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                    <TD WIDTH=51 BGCOLOR="#5AA0FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">remain</FONT></P>
                                    </TD>
                                    <TD WIDTH=101 BGCOLOR="#5AA0FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH="18%" BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <TABLE ID="Table10" BORDER=0 CELLSPACING=3 CELLPADDING=0 WIDTH="100%">
                                                            <TR>
                                                                <TD WIDTH="100%">
                                                                    <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                                                </TD>
                                                            </TR>
                                                        </TABLE>
                                                        <b><%=total_pay_amount%></b></TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=136 BGCOLOR="#78B4FF" HEIGHT=24>
                                        <FORM NAME="Cell70FORM" ACTION="contactconfirmprocess.jsp" METHOD=POST>
                                            <INPUT TYPE=HIDDEN NAME="contact_id" VALUE="<%=tour_contact_id%>">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><%
if(contact_status==1){
%><INPUT TYPE=SUBMIT NAME="FormsButton5" VALUE="confirm" ID="Forms Button5"  onclick="return(rusure())"><%}%></FONT>
                                        </FORM>
                                    </TD>
                                    <TD BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                    </TD>
                                    <TD COLSPAN=2 BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                    </TD>
                                    <TD BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                    </TD>
                                    <TD BGCOLOR="#78B4FF">
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT></P>
                                    </TD>
                                    <TD WIDTH=101 BGCOLOR="#78B4FF">
                                        <FORM NAME="Cell65FORM" ACTION="pay_form.jsp" METHOD=POST>
                                            <INPUT TYPE=HIDDEN NAME="contact_id" VALUE="<%=tour_contact_id%>"><INPUT TYPE=HIDDEN NAME="account_id" VALUE="2225554446661011"><INPUT TYPE=HIDDEN NAME="totalpayamount" VALUE="<%=total_pay_amount%>">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><%
if(contact_status==4){
%><INPUT TYPE=SUBMIT NAME="FormsButton6" VALUE="-pay-" ID="Forms Button6"  onclick="return(rusure())"><%}%><%if(contact_status==5){%><FONT COLOR=#FF0000>already pay!</FONT><%}%></FONT>
                                        </FORM>
                                    </TD>
                                </TR>
                            </TABLE>
                            <BR><%
  }
}
%></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=712 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=24 HEIGHT=19><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=24 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=688><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=688 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=688>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp; to see your reserve information click icon <B>I</B></FONT><B></B></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp; to see your reserve package detail click icon <B>I</B></FONT><B></B></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp; to change your reserve enter new package or new quantity then click <B>change</B> button.</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  if you sure to pay please <B>confirm</B> and <B>pay</B> by click the button.</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  please confirm and pay before <B><U>deadline</U></B></FONT><B><U></U></B></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  <U>simple step.</U> </FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  1. <B>change</B> until you’re satisfied. you can cancel before this step only.</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  2. <B>confirm</B> reserve.</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  3. <B>pay</B> money</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=1></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/packagelistpage.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package&nbsp;List</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/search.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Search&nbsp;Package</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 