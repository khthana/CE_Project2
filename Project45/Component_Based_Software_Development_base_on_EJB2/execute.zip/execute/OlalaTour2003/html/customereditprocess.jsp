<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<%
  //get parameter
  String password = "";
  if ( request.getParameter("password") != null )
    password = new String(request.getParameter("password").getBytes("UTF-8"),"UTF-8");
  String repassword = "";
  if ( request.getParameter("repassword") != null )
    repassword = new String(request.getParameter("repassword").getBytes("UTF-8"),"UTF-8");
  String email = "";
  if ( request.getParameter("email") != null )
    email = new String(request.getParameter("email").getBytes("UTF-8"),"UTF-8");
  String name = "";
  if ( request.getParameter("name") != null )
    name = new String(request.getParameter("name").getBytes("UTF-8"),"UTF-8");
  String lastname = "";
  if ( request.getParameter("lastname") != null )
    lastname = new String(request.getParameter("lastname").getBytes("UTF-8"),"UTF-8");
  String address = "";
  if ( request.getParameter("address") != null )
    address = new String(request.getParameter("address").getBytes("UTF8"),"UTF8");
%>

<%

  //check before editCustomer
  CustomerResult rs = null;
  if(password.equals(repassword)){
    rs = soapProxy.editCustomer(SScustomer_id, name, lastname, email, password, address);
  }
%>
<%
  if(rs != null){
    session.putValue("notice","Edit success.");
  }
  else{
    session.putValue("notice","Edit fail.");
  }
  //redirect
  response.sendRedirect("customerdetail.jsp");

%>