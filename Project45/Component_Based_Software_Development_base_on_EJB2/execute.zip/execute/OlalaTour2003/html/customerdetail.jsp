<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Edit Your Profile</TITLE>
<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(customerdetailLayout, 747, 636))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    <%
  if(SScustomer_id <= 0)
    response.sendRedirect("loginpage.jsp");
  CustomerResult rs = null;
 rs =  soapProxy.getCustomerDetail(SScustomer_id);
  if(rs==null)
    response.sendRedirect("loginpage.jsp");
%>
<%
    //set result
    int customer_id = rs.getCustomerId();
    String name = rs.getName();
    String lastname = rs.getSurname();
    String email = rs.getEmail();
    String username = rs.getUsername();
    String address = rs.getAddress();
%>

    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=125 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=125>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=125>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton1',1)" onMouseOut="F_roll('NavigationButton1',0)"><IMG ID="NavigationButton1" NAME="NavigationButton1" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton2',1)" onMouseOut="F_roll('NavigationButton2',0)"><IMG ID="NavigationButton2" NAME="NavigationButton2" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Search_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Search_NRcitybut2.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton3',1)" onMouseOut="F_roll('NavigationButton3',0)"><IMG ID="NavigationButton3" NAME="NavigationButton3" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Package_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Package_NRcitybut2.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton4',1)" onMouseOut="F_roll('NavigationButton4',0)"><IMG ID="NavigationButton4" NAME="NavigationButton4" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=722 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=26 HEIGHT=9><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=26 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=696><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=696 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=696><%
if(SSnotice!=""){
%>
                            <P ALIGN=CENTER><B><FONT COLOR="#FF0000" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><IMG ID="Picture1" HEIGHT=32 WIDTH=32 SRC="../assets/images/autogen/a_warn.gif" VSPACE=0 HSPACE=0 ALIGN="TOP" BORDER=0 ALT=""><%=SSnotice%></FONT></B><%}%></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=26><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=26 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=697>
                            <FORM NAME="Table1FORM" ACTION="customereditprocess.jsp" METHOD=POST>
                                <INPUT TYPE=HIDDEN NAME="customer_id" VALUE="<%=customer_id%>">
                                <TABLE ID="Table1" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TH COLSPAN=2 BGCOLOR="#000096" HEIGHT=16>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="+1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Edit Profile</FONT></P>
                                        </TH>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#000000">
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Edit Account Information</FONT></P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#F0FFFF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#2A00FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>username</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#F0FFFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><%=username%></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#D2F0FF" HEIGHT=24>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>if you don’t wat to change your password</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>leave this field blank.</B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#2A00FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>password</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#D2F0FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField12" TYPE=PASSWORD NAME="password" VALUE="" SIZE=20 MAXLENGTH=20></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#B4DCFF" HEIGHT=24>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>if you don't wat to change your password</B></FONT><B></B></P>
                                                        <P ALIGN=LEFT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF3399" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>leave this field blank.</B></FONT><B></B></P>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#2A00FF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>re-password</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#B4DCFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Edit Field3" TYPE=PASSWORD NAME="repassword" VALUE="" SIZE=20 MAXLENGTH=20></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#000000">
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Edit Profile Information</FONT></P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#78B4FF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>First Name</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#78B4FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField8" TYPE=TEXT NAME="name" VALUE="<%=name%>" SIZE=30 MAXLENGTH=30></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#5AA0FF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Last Name</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#5AA0FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsEditField9" TYPE=TEXT NAME="lastname" VALUE="<%=lastname%>" SIZE=30 MAXLENGTH=30></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#3C8CFF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>E-mail Address</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#3C8CFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Edit Field2" TYPE=TEXT NAME="email" VALUE="<%=email%>" SIZE=30 MAXLENGTH=30></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=400 BGCOLOR="#1E78FF" HEIGHT=70>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=400 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#F0FFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Address</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=297 BGCOLOR="#3C8CFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><TEXTAREA WRAP=PHYSICAL ID="FormsMultiLine2" NAME="address" ROWS=4 COLS=25><%=address%></TEXTAREA></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#0066FF" HEIGHT=25>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT TYPE=SUBMIT NAME="FormsButton1" VALUE="Edit!" ID="FormsButton2">&nbsp;<INPUT TYPE=RESET NAME="FormsButton1" VALUE="Reset" ID="Forms Button1"></FONT></TD>
                                    </TR>
                                </TABLE>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=722 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=25 HEIGHT=11><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=25 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=697><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=697 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=697>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  to see all tour package list click <B>Package</B> at the left panel or <B>Package List</B> below.</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  to search your wanted package click <B>Search</B> at the left panel or <B>Search Package</B> below.</FONT></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  to see you reserved package click <B>Your Cart</B></FONT><B></B></P>
                            <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;&nbsp; &nbsp; &nbsp;  and return to this page by click <B>Your Profile</B></FONT><B></B></P>
                            <UL>
                                <P><FONT COLOR="#000096" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;</FONT></P>
                            </UL>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=1></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/packagelistpage.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package&nbsp;List</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/search.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Search&nbsp;Package</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 