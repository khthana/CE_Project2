<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">
<META NAME="Generator" CONTENT="NetObjects Fusion 7 for Windows">
<TITLE>Olala Tour : Log In</TITLE>
<%@ page import="weblogic.jws.proxies.*"%>
<%@ page contentType = "text/html;charset=UTF-8" language="java"%>
<%@ page import="org.openuri.www.BookingResult" %>
<%@ page import="org.openuri.www.ContactJobResult" %>
<%@ page import="org.openuri.www.CustomerContactResult" %>
<%@ page import="org.openuri.www.CustomerResult " %>
<%@ page import="org.openuri.www.PackageDetail " %>
<%@ page import="org.openuri.www.SearchResult" %>
<% Service_Impl proxy = new Service_Impl(); %>
<% ServiceSoap soapProxy  = proxy.getserviceSoap(); %>
<%
//get value from session
  int SScustomer_id = 0;
  if ( session.getValue("customer_id") != null )
    SScustomer_id = Integer.parseInt((String)session.getValue("customer_id"));
  int SScontact_id[] = null;
  if ( session.getValue("contact_id") != null )
    SScontact_id = (int [])session.getValue("contact_id");
  String SSusername = "";
  if ( session.getValue("username") != null )
    SSusername = (String)session.getValue("username");
  String SSnotice = "";
  if ( session.getValue("notice") != null )
    SSnotice = (String)session.getValue("notice");
  session.removeValue("notice");
%>
<SCRIPT>
<!--
function F_loadRollover(){} function F_roll(){}
//-->
</SCRIPT>
<SCRIPT LANGUAGE="JavaScript1.2" SRC="../assets/rollover.js"></SCRIPT>
</HEAD>
<BODY NOF="(MB=(DefaultMasterBorder, 102, 89, 126, 0), L=(loginpageLayout, 747, 500))" BGCOLOR="#FFFFFF" BACKGROUND="../assets/images/lame-sky3.jpg" TEXT="#000000" TOPMARGIN=0 LEFTMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
    
<%
//getParameter
  String username = "";
  if ( request.getParameter("username") != null )
    username = new String(request.getParameter("username").getBytes("UTF-8"),"UTF-8");
%>
<%
//if logged in then goto customer
  if(SScustomer_id > 0)
    response.sendRedirect("customerdetail.jsp");
%>
    <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD WIDTH=124 HEIGHT=8><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=124 HEIGHT=1 BORDER=0 ALT=""></TD>
            <TD></TD>
        </TR>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD HEIGHT=85></TD>
            <TD WIDTH=749><IMG ID="Banner1" HEIGHT=85 WIDTH=749 SRC="../TITLE.JPG" BORDER=0 ALT="Untitled14" NOF=B_H></TD>
        </TR>
    </TABLE>
    <TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=873 NOF=LY>
        <TR VALIGN=TOP ALIGN=LEFT>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=125 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=9></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=108 WIDTH=125>
                            <TABLE ID="NavigationBar1" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=NB_UYVPNY120 WIDTH=125>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../index.jsp" onMouseOver="F_roll('NavigationButton5',1)" onMouseOut="F_roll('NavigationButton5',0)"><IMG ID="NavigationButton5" NAME="NavigationButton5" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Home_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Home_NRcitybut2.jpg',0)" BORDER=0 ALT="Home"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/search.jsp" onMouseOver="F_roll('NavigationButton6',1)" onMouseOut="F_roll('NavigationButton6',0)"><IMG ID="NavigationButton6" NAME="NavigationButton6" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Search_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Search_NRcitybut2.jpg',0)" BORDER=0 ALT="Search"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/packagelistpage.jsp" onMouseOver="F_roll('NavigationButton7',1)" onMouseOut="F_roll('NavigationButton7',0)"><IMG ID="NavigationButton7" NAME="NavigationButton7" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Package_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Package_NRcitybut2.jpg',0)" BORDER=0 ALT="Package"></A></TD>
                                </TR>
                                <TR VALIGN=TOP ALIGN=LEFT>
                                    <TD WIDTH=125 HEIGHT=27><A HREF="../html/customerform.jsp" onMouseOver="F_roll('NavigationButton8',1)" onMouseOut="F_roll('NavigationButton8',0)"><IMG ID="NavigationButton8" NAME="NavigationButton8" HEIGHT=27 WIDTH=125 SRC="../assets/images/autogen/Register_Ncitybut1.jpg" onLoad="F_loadRollover(this,'Register_NRcitybut2.jpg',0)" BORDER=0 ALT="Register"></A></TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=30></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=126>
                            <TABLE ID="Table26" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=126 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table20FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id <= 0){
%>
                                                            <TABLE ID="Table20" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field18" TYPE=TEXT NAME="username" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  User</B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126 BACKGROUND="../assets/images/citybut1.jpg" HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">&nbsp;<INPUT ID="Forms Edit Field17" TYPE=PASSWORD NAME="password" VALUE="" SIZE=6 MAXLENGTH=10></FONT><FONT COLOR="#FFFFFF" SIZE="-2" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B> &nbsp;  Pass </B></FONT><B></B></TD>
                                                                </TR>
                                                                <TR>
                                                                    <TD WIDTH=126>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button12" NAME="FormsButton12" TYPE=IMAGE BORDER=0 SRC="../assets/images/Login_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table21FORM" ACTION="logoutprocess.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table21" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=27>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button13" NAME="FormsButton13" TYPE=IMAGE BORDER=0 SRC="../assets/images/Logout_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table23FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/contactlistpage.jsp" METHOD=POST>
                                                            <%
if(SScontact_id!=null){
%>
                                                            <TABLE ID="Table23" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="FormsButton16" NAME="FormsButton14" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Cart_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                                <TR>
                                    <TD WIDTH=126>
                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                            <TABLE WIDTH=125 BORDER=0 CELLSPACING=0 CELLPADDING=0 ALIGN=LEFT NOF=TE>
                                                <TR>
                                                    <TD>
                                                        <FORM NAME="Table24FORM" ACTION="/OlalaWebTour/OlalaTour2003/html/customerdetail.jsp" METHOD=POST>
                                                            <%
if(SScustomer_id>0){
%>
                                                            <TABLE ID="Table24" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                                                <TR>
                                                                    <TD WIDTH=125 HEIGHT=28>
                                                                        <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Button15" NAME="FormsButton15" TYPE=IMAGE BORDER=0 SRC="../assets/images/Your_Profile_Ncitybut1.jpg"></FONT></TD>
                                                                </TR>
                                                            </TABLE>
                                                            <%}%>
                                                        </FORM>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                    </TD>
                                </TR>
                            </TABLE>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
            <TD>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=722 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=25 HEIGHT=9><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=25 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=697><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=697 HEIGHT=1 BORDER=0 ALT=""></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD></TD>
                        <TD WIDTH=697><%
if(SSnotice!=""){
%>
                            <P ALIGN=CENTER><B><FONT COLOR="#FF0000" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><IMG ID="Picture1" HEIGHT=32 WIDTH=32 SRC="../assets/images/autogen/a_warn.gif" VSPACE=0 HSPACE=0 ALIGN="TOP" BORDER=0 ALT=""><%=SSnotice%></FONT></B><%}%></TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=25><IMG SRC="../assets/images/autogen/clearpixel.gif" WIDTH=25 HEIGHT=1 BORDER=0 ALT=""></TD>
                        <TD WIDTH=697>
                            <FORM NAME="Table5FORM" ACTION="loginprocess.jsp" METHOD=POST>
                                <TABLE ID="Table5" BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH="100%">
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#FFCCFF">
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF0000" SIZE="+1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>Please enter the correct </B></FONT><B></B></P>
                                            <P ALIGN=CENTER><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FF0000" SIZE="+1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>username and Passwrod</B></FONT><B></B></P>
                                        </TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=483 BGCOLOR="#3C8CFF">
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=483 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>username</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=214 BGCOLOR="#3C8CFF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Edit Field4" TYPE=TEXT NAME="username" VALUE="<%=username%>" SIZE=20 MAXLENGTH=20></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD WIDTH=483 BGCOLOR="#1E78FF" HEIGHT=24>
                                            <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=483 NOF=TI>
                                                <TR>
                                                    <TD>
                                                        <P ALIGN=RIGHT><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT><FONT COLOR="#FFFFFF" SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><B>password</B></FONT><B></B></P>
                                                    </TD>
                                                </TR>
                                            </TABLE>
                                        </TD>
                                        <TD WIDTH=214 BGCOLOR="#1E78FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"><INPUT ID="Forms Edit Field5" TYPE=PASSWORD NAME="password" VALUE="" SIZE=20 MAXLENGTH=20></FONT></TD>
                                    </TR>
                                    <TR>
                                        <TD COLSPAN=2 BGCOLOR="#0066FF">
                                            <P><FONT SIZE="-1" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif"></FONT>
                                                <TABLE WIDTH="100%" BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=TE>
                                                    <TR>
                                                        <TD ALIGN="CENTER"><INPUT TYPE=SUBMIT NAME="FormsButton7" VALUE="Login" ID="Forms Button7"></TD>
                                                    </TR>
                                                </TABLE>
                                        </TD>
                                    </TR>
                                </TABLE>
                            </FORM>
                        </TD>
                    </TR>
                </TABLE>
                <TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0 NOF=LY>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD HEIGHT=334></TD>
                    </TR>
                    <TR VALIGN=TOP ALIGN=LEFT>
                        <TD WIDTH=747 NOF="NB_UYHTNN120">
                            <P ALIGN=CENTER><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">[</FONT></B><A HREF="../index.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Home</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/packagelistpage.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Package&nbsp;List</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/search.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Search&nbsp;Package</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">] [</FONT></B><A HREF="../html/customerform.jsp"><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">Register&nbsp;New&nbsp;Customer</FONT></B></A><B><FONT COLOR="#009900" FACE="Verdana,Tahoma,Arial,Helvetica,Sans-serif,sans-serif">]</FONT></B></P>
                        </TD>
                    </TR>
                </TABLE>
            </TD>
        </TR>
    </TABLE>
</BODY>
</HTML>
 