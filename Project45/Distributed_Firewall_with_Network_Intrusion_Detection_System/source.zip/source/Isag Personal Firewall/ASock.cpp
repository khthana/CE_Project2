// ASock.cpp : implementation file
//

#include "stdafx.h"
#include "FirewallAgent.h"
#include "ASock.h"

#include "FirewallAgentDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CASock

CASock::CASock()
{
}

CASock::~CASock()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CASock, CAsyncSocket)
	//{{AFX_MSG_MAP(CASock)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CASock member functions

void CASock::OnConnect(int nErrorCode) 
{
	if (0 != nErrorCode)
	{
		switch( nErrorCode )
		{
         case WSAEADDRINUSE: 
            AfxMessageBox("The specified address is already in use.\n");
            break;
         case WSAEADDRNOTAVAIL: 
            AfxMessageBox("The specified address is not available from the local machine.\n");
            break;
         case WSAEAFNOSUPPORT: 
            AfxMessageBox("Addresses in the specified family cannot be used with this socket.\n");
            break;
         case WSAECONNREFUSED: 
            AfxMessageBox("The attempt to connect was forcefully rejected.\n");
            break;
         case WSAEDESTADDRREQ: 
            AfxMessageBox("A destination address is required.\n");
            break;
         case WSAEFAULT: 
            AfxMessageBox("The lpSockAddrLen argument is incorrect.\n");
            break;
         case WSAEINVAL: 
            AfxMessageBox("The socket is already bound to an address.\n");
            break;
         case WSAEISCONN: 
            AfxMessageBox("The socket is already connected.\n");
            break;
         case WSAEMFILE: 
            AfxMessageBox("No more file descriptors are available.\n");
            break;
         case WSAENETUNREACH: 
            AfxMessageBox("The network cannot be reached from this host at this time.\n");
            break;
         case WSAENOBUFS: 
            AfxMessageBox("No buffer space is available. The socket cannot be connected.\n");
            break;
         case WSAENOTCONN: 
            AfxMessageBox("The socket is not connected.\n");
            break;
         case WSAENOTSOCK: 
            AfxMessageBox("The descriptor is a file, not a socket.\n");
            break;
         case WSAETIMEDOUT: 
            AfxMessageBox("The attempt to connect timed out without establishing a connection. \n");
            break;
         default:
            TCHAR szError[256];
            wsprintf(szError, "OnConnect error: %d", nErrorCode);
            AfxMessageBox(szError);
            break;
		}
		AfxMessageBox("Please click disconnect and try connect again.");
		((CFirewallAgentDlg*)m_pDwnd)->m_listMessage.AddString("Status:> Can't connect to server.");
	}
	else	((CFirewallAgentDlg*)m_pDwnd)->Connected();
	
	CAsyncSocket::OnConnect(nErrorCode);
}

void CASock::SetParent(CDialog *pDwnd)
{
	m_pDwnd = pDwnd;
}

void CASock::OnClose(int nErrorCode) 
{
	if ( nErrorCode == 0 )
		((CFirewallAgentDlg*)m_pDwnd)->Closed();
	
	CAsyncSocket::OnClose(nErrorCode);
}

void CASock::OnReceive(int nErrorCode) 
{
	CString strRecvMsg;
	char buffer[MAX_BUFFER];
	int nRecv;
	int length, command;

	nRecv = Receive(buffer, MAX_BUFFER); 
	
	switch (nRecv)
	{
		case 0: // connection has been closed.
			Close();
			break;
		case SOCKET_ERROR: // Error occured
			if (GetLastError() != WSAEWOULDBLOCK)
			{
				AfxMessageBox ("Error occurred!!!");
				Close();
			}
			break;
		default: // No Error
			buffer[nRecv] = 0; 
			CString strTemp(buffer);
			strRecvMsg = "Status:> " + strTemp;
//			((CFirewallAgentDlg*)m_pDwnd)->m_listMessage.AddString(strRecvMsg);		// show receive message

			length = buffer[0];
			command = buffer[1];		// command : 3 = ok, 4 = false, 7 = update rule

			((CFirewallAgentDlg*)m_pDwnd)->MsgQuery(buffer);

			//if(command == 3)
			//{
			//	((CFirewallAgentDlg*)m_pDwnd)->m_authenticated = TRUE;
			//}
	}
	
	CAsyncSocket::OnReceive(nErrorCode);
}
