// FilterRule.h: interface for the CFilterRule class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTERRULE_H__C1522E3E_447C_46EF_B55C_B23D876B6D5C__INCLUDED_)
#define AFX_FILTERRULE_H__C1522E3E_447C_46EF_B55C_B23D876B6D5C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFilterRule  : public CObject
{
public:
	static CFilterRule* CreateRule(CString ruleString);
	static BOOL SameIP(PBYTE, PBYTE);
	static BYTE *StringToIP(CString IPString);

	void SetProtocol(const CString);
	void SetSrcPortRange(const CString);
	void SetSrcPort(const CString);
	void SetSrcMask(const CString SrcMask);
	void SetSrcAddr(const CString SrcAddr);
	void SetDstPortRange(const CString);
	void SetDstPort(const CString);
	void SetDstMask(const CString SrcMask);
	void SetDstAddr(const CString SrcAddr);
	void SetRuleNo(const CString RuleNo);

	CString GetProtocol();
	WORD GetDstPortRange();
	WORD GetDstPort();
	PBYTE GetDstMask();
	PBYTE GetDstAddr();
	WORD GetSrcPortRange();
	WORD GetSrcPort();
	PBYTE GetSrcMask();
	PBYTE GetSrcAddr();
	int GetRuleNo();

	CFilterRule();
	virtual ~CFilterRule();

protected:
	static void FormatPortRange(CString portString, CString& portLowRange, CString& portHighRange);

	int m_RuleNo;
	BYTE m_SrcAddr[4];
	BYTE m_SrcMask[4];
	WORD m_SrcPort;
	WORD m_SrcPortRange;
	BYTE m_DstAddr[4];
	BYTE m_DstMask[4];
	WORD m_DstPort;
	WORD m_DstPortRange;
	CString m_Protocol;
};

#endif // !defined(AFX_FILTERRULE_H__C1522E3E_447C_46EF_B55C_B23D876B6D5C__INCLUDED_)
