// W2kFilter.h: interface for the CW2kFilter class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_W2KFILTER_H__C85BC090_14A1_4F71_A44A_825BE98F80E7__INCLUDED_)
#define AFX_W2KFILTER_H__C85BC090_14A1_4F71_A44A_825BE98F80E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Fltdefs.h"  // Windows2000 Packet Filter API

class CW2kFilter  
{
public:
	void GetRealAddr(PBYTE &);
	void SetLocalIP();
	BOOL StartFilter(CObList* ruleSet);
	BOOL StopFilter();
	void SetLocalIP(PBYTE localIP);
	CString IPToString(PBYTE ip);
	CString GetStatsString();
	void GetStats();

	CW2kFilter();
	virtual ~CW2kFilter();
	
	CString log;

protected:
	INTERFACE_HANDLE s_hIf;
	
	HANDLE hEvent;
	PF_INTERFACE_STATS m_iStats;

private:
	CObList* currentRuleSet;
	BYTE m_LocalIP[4];
};

#endif // !defined(AFX_W2KFILTER_H__C85BC090_14A1_4F71_A44A_825BE98F80E7__INCLUDED_)
