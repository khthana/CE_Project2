// FirewallAgentDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FirewallAgent.h"
#include "FirewallAgentDlg.h"

#include "FilterRule.h"
#include "W2kFilter.h"

#include "LoginDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// NIDS Section

#include "Sniff.h"
#include "SelectAdapter.h"
#include "Analysis.h"

#define TIME_ELAP 1000
#define WM_SYSTRAYNOTIFY (WM_USER + 200)

CSniff Sniffer;
BOOL StatusStop = TRUE;
CAnalysis AnalyPacket;

char SERVER_IP[16];
int SERVER_PORT;

UINT Thread_Analysis(LPVOID pParam)
{
	CString T_Type,T_Src,T_Dst,T_Time;
	while((!StatusStop))
	{
		Header_Packet Packet;
		if (::Sniffer.GetPacket(Packet))
		{
			if (::AnalyPacket.Check(Packet))
			{
				::Sniffer.ClearSniff();
			}
		}
		else
			Sleep(1);
	}
	return 0;
}

UINT Thread_Sniff(LPVOID pParam)
{
	while((!StatusStop))
	{
		::Sniffer.PacketFromDevice();
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFirewallAgentDlg dialog

CFirewallAgentDlg::CFirewallAgentDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFirewallAgentDlg::IDD, pParent)
{
	LoadConfig();
	//{{AFX_DATA_INIT(CFirewallAgentDlg)
	m_strServerIP = SERVER_IP;
	m_intServerPort = SERVER_PORT;
	m_strClientIP = _T("");
	m_strClientPort = _T("");
	m_strConnectionStatus = _T("Offline");
	m_strFirewallStatus = _T("Disable");
	m_strNidsStatus = _T("Disable");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDI_MAIN);

	m_authenticated = FALSE;

	RestartFlag = FALSE;

	m_RuleSet = new CObList();
	m_FilterEngine = new CW2kFilter();
}

void CFirewallAgentDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFirewallAgentDlg)
	DDX_Control(pDX, IDOK, m_IDOK);
	DDX_Control(pDX, IDC_LIST, m_List);
	DDX_Control(pDX, IDC_LISTMESSAGES, m_listMessage);
	DDX_Text(pDX, IDC_SERVERIP, m_strServerIP);
	DDX_Text(pDX, IDC_SERVERPORT, m_intServerPort);
	DDX_Text(pDX, IDC_CLIENTIP, m_strClientIP);
	DDX_Text(pDX, IDC_CLIENTPORT, m_strClientPort);
	DDX_Text(pDX, IDC_CONNECTSTATUS, m_strConnectionStatus);
	DDX_Text(pDX, IDC_FIREWALLSTATUS, m_strFirewallStatus);
	DDX_Text(pDX, IDC_NIDSSTATUS, m_strNidsStatus);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CFirewallAgentDlg, CDialog)
	//{{AFX_MSG_MAP(CFirewallAgentDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_STARTFILTER, OnStartFilter)
	ON_BN_CLICKED(IDC_STOPFILTER, OnStopFilter)
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_DISCONNECT, OnDisconnect)
	ON_COMMAND(ID_CLOSE, OnSysTrayClose)
	ON_COMMAND(ID_OPEN, OnSysTrayOpen)
	ON_WM_TIMER()
	ON_WM_SIZE()
	ON_COMMAND(ID_SELECTADAPTER, OnSelectAdapter)
	ON_COMMAND(ID_HELP_ABOUT, OnHelpAbout)
	ON_COMMAND(ID_CLEARLOG, OnClearlog)
	ON_COMMAND(ID_LOGIN, OnLogin)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_SYSTRAYNOTIFY, OnSystrayNotify)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFirewallAgentDlg message handlers

BOOL CFirewallAgentDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

//--------------- NIDS Section ---------------
	NumberAdapter = -1 ;
	m_notifyIconData.cbSize	= sizeof(NOTIFYICONDATA);
	m_notifyIconData.hWnd	= GetSafeHwnd();
	m_notifyIconData.uID	= IDI_TRAY;
	m_notifyIconData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	m_notifyIconData.uCallbackMessage = WM_SYSTRAYNOTIFY;
	m_notifyIconData.hIcon	= (HICON) LoadImage(AfxGetApp()->m_hInstance, 
		MAKEINTRESOURCE(IDI_TRAY), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR); //AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	strcpy(m_notifyIconData.szTip, "Isag Personal Firewall");
//	Shell_NotifyIcon(NIM_ADD, &m_notifyIconData);

	(void)m_List.SetExtendedStyle( LVS_EX_FULLROWSELECT );
	m_List.SetHeadings( _T("Type,120;Source,120;Dest,120;Time,79") );
	m_List.LoadColumnInfo();
	
	FileFlag  = 0 ;
	OpenAdapter = 0 ;
	SetDlgItemText( IDOK , "Start NIDS" ) ;
	ButtonFlag = 0 ;

//---------- Firewall Agent Section ----------
//	m_FilterEngine = new CW2kFilter();

	m_connectSock.SetParent(this);

//	OnSize(1, 0, 0);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFirewallAgentDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CFirewallAgentDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFirewallAgentDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CFirewallAgentDlg::OnStartFilter() 
{
	CObList* ruleSet = new CObList;
	CString buffer;
	CString IPString;

	buffer = "1 127.0.0.0 255.255.255.255 0 65535 161.246.4.7 255.255.255.255 80 80 TCP";	// work
	
	CFilterRule* newRule = CFilterRule::CreateRule(buffer);
//	CObject* newObjectRule = (CObject*) newRule;	//modify

	ruleSet->AddTail(newRule);

//// -Add second rule- /////////////////////////////////////////////////////////

	buffer = "1 127.0.0.0 255.255.255.255 0 65535 161.246.5.25 255.255.255.255 80 80 TCP";	// work

	newRule = CFilterRule::CreateRule(buffer);

	ruleSet->AddTail(newRule);
////////////////////////////////////////////////////////////////////////////////

//	CString IPString = m_ClientAgent->GetLocalIP();

	WSADATA p;
    WSAStartup ((2<<8) | 2, &p);

	char szHostName[128];
	CString str;
	if( gethostname(szHostName, 128) != SOCKET_ERROR )
	{
		// Get host adresses
		struct hostent * pHost;
		int i;
 
		pHost = gethostbyname(szHostName);
		for( i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++ )
 		{
 			int j;
	 		for( j = 0; j < pHost->h_length; j++ )
 			{
				CString addr;
				if( j > 0 )
 					str += ".";
	 			addr.Format("%u", (unsigned int)((unsigned
				 	char*)pHost->h_addr_list[i])[j]);
				str += addr;
 			}
  		// str now contains one local IP address - do whatever you want to do with it (probably add it to a list)
 		}
	}
	IPString = str;  // return the last one if has more than 1 ip address

	PBYTE IP = CFilterRule::StringToIP(IPString);
	BYTE localIP[4];
	localIP[0] = *IP;
	localIP[1] = *(IP+1);
	localIP[2] = *(IP+2);
	localIP[3] = *(IP+3);

	m_FilterEngine->SetLocalIP(localIP);
//	m_FilterEngine->SetLocalIP();	// for test program

	if (m_FilterEngine->StartFilter(m_RuleSet) == TRUE)
	{
		if(RestartFlag == FALSE)
			m_listMessage.AddString("Status:> Starting Filter...");
		//MessageBox("Starting Filter", "Firewall Agent", MB_OK | MB_ICONINFORMATION);

		UpdateData(TRUE);

		m_strFirewallStatus = _T("Enable");
		GetDlgItem(IDC_STARTFILTER)->EnableWindow(FALSE);

		UpdateData(FALSE);
	}
	else
	{
		MessageBox("Error!", "Firewall Agent", MB_OK | MB_ICONEXCLAMATION);
	}

}

void CFirewallAgentDlg::OnStopFilter() 
{
	if ( m_FilterEngine->StopFilter() == TRUE)
	{
		if(RestartFlag == FALSE)
			m_listMessage.AddString("Status:> Filter has been stop.");
		//MessageBox("Filter has been stop", "Firewall Agent", MB_OK | MB_ICONINFORMATION);

		UpdateData(TRUE);

		m_strFirewallStatus = _T("Disable");
		GetDlgItem(IDC_STARTFILTER)->EnableWindow(TRUE);

		UpdateData(FALSE);
	}
	else
	{
		MessageBox("Can not stop Filter!", "Firewall Agent", MB_OK | MB_ICONEXCLAMATION);	
	}
}

CFirewallAgentDlg::~CFirewallAgentDlg()
{
	delete m_FilterEngine;
	delete m_RuleSet;
//	MessageBox("Delete", "Firewall Agent", MB_OK | MB_ICONINFORMATION);
}

void CFirewallAgentDlg::OnConnect() 
{	
	m_intCountSentByte = 0;
	UpdateData(TRUE);
	GetDlgItem(IDC_CONNECT)->EnableWindow(FALSE);

	// create the windows socket
	m_connectSock.Create();

	// establish a connection
	m_connectSock.Connect(m_strServerIP, m_intServerPort);
	m_listMessage.AddString("Status:> Connecting to server...");

//	m_strSentTotalMessages.Format("%lu", m_intCountSentByte);
//	m_listMessage.ResetContent();	// clear all message in listBox

	UpdateData(FALSE);
}

void CFirewallAgentDlg::OnDisconnect() 
{
	if(!strcmp(m_strConnectionStatus, "Online"))
	{
		char data[128];
		sprintf(data, "%c%c", 9, 1);	// 9 = connection close
		SendData(data);

		m_listMessage.AddString("Status:> Connection closed.");
	}
	Closed();

	UpdateData(FALSE);
}

void CFirewallAgentDlg::Closed()
{
	m_connectSock.Close();
	m_strClientIP = _T("");
	m_strClientPort = _T("");
	m_strConnectionStatus = _T("Offline");
//	m_strSentTotalMessages 	= _T("");

//	GetDlgItem(IDC_BUTTON_SEND)->EnableWindow(FALSE);
	GetDlgItem(IDC_CONNECT)->EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CFirewallAgentDlg::Connected()
{
	//m_strConnectionStatus = _T("Online");
	m_listMessage.AddString("Status:> Connected successfully.");

	if(m_authenticated == FALSE)
	{
		CLoginDlg dlg;
		int nResponse = dlg.DoModal();
		if (nResponse == IDOK)
		{
			m_Username = dlg.GetUsername();
			m_Password = dlg.GetPassword();

			Authenticate();
		}
		else if (nResponse == IDCANCEL)
		{

		}
	}

	SetClientIP();

	UINT ClientPort = 0;
	CString ClientIP;
	m_connectSock.GetSockName(ClientIP, ClientPort);
	m_strClientPort.Format("%lu", ClientPort);

	m_strConnectionStatus = _T("Online");

	UpdateData(FALSE);
}

void CFirewallAgentDlg::Authenticate()
{
	UpdateData(TRUE);
	
	int BytesSent;
	CString AuthenticateMsg;

	m_listMessage.AddString("Status:> Authenticating...");

	char tmp[128];
//	sprintf(tmp, "%c%s%c%s%c%s%c", 2, "zest", 1, "hello", 1, "2", 1);
	sprintf(tmp, "%c%s%c%s%c%s%c", 2, m_Username, 1, m_Password, 1, "2", 1);
	AuthenticateMsg = tmp;
	BytesSent = AuthenticateMsg.GetLength();
	sprintf(tmp, "%c", BytesSent);

//	CString strBytes;
//	strBytes.Format(_T(BytesSent));

	CString Msg(tmp + AuthenticateMsg);
	BytesSent = Msg.GetLength();

 	if (AuthenticateMsg != "")
	{
		int dwBytes;
		dwBytes = m_connectSock.Send((LPCTSTR)Msg, BytesSent);
		
		if (dwBytes == SOCKET_ERROR)
		{
			if (m_connectSock.GetLastError() != WSAEWOULDBLOCK)
			{
				char strError[256];
				wsprintf(strError, "Socket failed to send, Error Code: %d", m_connectSock.GetLastError());
				Closed();
				AfxMessageBox (strError);
			}
		}
		else
		{
//			CString strTemp = "S: ";
			m_intCountSentByte += BytesSent;
//			m_strSentTotalMessages.Format("%lu", m_intCountSentByte);
//			strTemp += m_strSendMessages;
//			m_listMessage.AddString(strTemp);

//			m_authenticated = TRUE;

			UpdateData(FALSE);
		}
	}
}

void CFirewallAgentDlg::SetClientIP()
{
	char szHostName[128];
	CString str;
	if( gethostname(szHostName, 128) != SOCKET_ERROR )
	{
		// Get host adresses
		struct hostent * pHost;
		int i;
 
		pHost = gethostbyname(szHostName);
		for( i = 0; pHost!= NULL && pHost->h_addr_list[i]!= NULL; i++ )
 		{
 			int j;
	 		for( j = 0; j < pHost->h_length; j++ )
 			{
				CString addr;
				if( j > 0 )
 					str += ".";
	 			addr.Format("%u", (unsigned int)((unsigned char*)pHost->h_addr_list[i])[j]);
				str += addr;
 			}
  		// str now contains one local IP address - do whatever you want to do with it (probably add it to a list)
 		}
	}

	m_strClientIP = str;  // return the last one if has more than 1 ip address
}

void CFirewallAgentDlg::MsgQuery(char *msg)
{
	int length, command, toggle;
//	char *ruleNo;
	CString rule;
	CString RuleNo;
	CString Src;
	CString Dest;
	CString Protocol;
	length = msg[0];
	command = msg[1];		// command : 3 = ok, 4 = false, 7 = update rule
//	ruleNo = &msg[2];
	toggle = msg[2];

	if(command == 3)
	{
		m_authenticated = TRUE;
		m_listMessage.AddString("Status:> Authenticated successfully.");
	}
	else if(command == 4)
	{
		m_authenticated = FALSE;
		m_listMessage.AddString("Status:> Authentication failure.");
	}
	else if((command == 7)&&(length > 2))
	{
		rule = msg;
//		int l = rule.GetLength();
//		rule.Remove(length);		// remove length
		rule.TrimLeft(length);
		rule.Remove(7);			// remove command
		rule.Remove(1);			// remove separete

		// begin add new rule into list

//		CObList* ruleSet = new CObList;
//		CString buffer;

//		buffer = rule;	// work
	
		CFilterRule* newRule = CFilterRule::CreateRule(rule);
		m_RuleSet->AddTail(newRule);

		char tmp[128];
		sprintf(tmp, "%s","Status:> Rule receive.");
		m_listMessage.AddString(tmp);

		m_listMessage.AddString("Firewall:> Adding rule...", RGB(0xFF, 0x66, 0x00));

//		Src = rule.SpanExcluding(" ");
//		m_listMessage.AddString(Src, RGB(0xFF, 0x66, 0x00));

//------- Display Rule -------
		int ruleLength = rule.GetLength();
		int n, sep = 0;
		int j = 0;
		int iHead = 0;
		int iTail = 0;
		char text[128];
		char No[5], srcAddr[32], srcMask[32], destAddr[32], destMask[32];
		char srcPort[8], srcPRange[8], destPort[8], destPRange[8], protocol[5];

		CString ruleTmp = rule;
		ruleTmp += ' ';
		while(sep < 10)
		{
			iHead = iTail;
			n = ruleTmp.Find(' ', iTail);
			sep++;	// inc separate
			
			for(int i=iHead ; i<n ; i++)
			{
				//Src.SetAt(j, rule[i]);
				text[j] = ruleTmp[i];
				j++;
			}
			text[j] = '\0';

			if(sep == 1)
			{
				strcpy(No, text);
				//sprintf(text, "Rule# %s", tmp);
				//m_listMessage.AddString(text, RGB(0xFF, 0x66, 0x00));
			}
			else if(sep == 2)
			{
				strcpy(srcAddr, text);
			}
			else if(sep == 3)
			{
				strcpy(srcMask, text);
				if(!strcmp(srcMask, "255.255.255.255"))
					sprintf(srcMask, "32");
				else if(!strcmp(srcMask, "255.255.255.0"))
					sprintf(srcMask, "24");
				else if(!strcmp(srcMask, "255.255.0.0"))
					sprintf(srcMask, "16");
				else if(!strcmp(srcMask, "255.0.0.0"))
					sprintf(srcMask, "8");
			}
			else if(sep == 4)
			{
				strcpy(srcPort, text);
			}
			else if(sep == 5)
			{
				strcpy(srcPRange, text);
			}
			else if(sep == 6)
			{
				strcpy(destAddr, text);
			}
			else if(sep == 7)
			{
				strcpy(destMask, text);
				if(!strcmp(destMask, "255.255.255.255"))
					sprintf(destMask, "32");
				else if(!strcmp(destMask, "255.255.255.0"))
					sprintf(destMask, "24");
				else if(!strcmp(destMask, "255.255.0.0"))
					sprintf(destMask, "16");
				else if(!strcmp(destMask, "255.0.0.0"))
					sprintf(destMask, "8");
			}
			else if(sep == 8)
			{
				strcpy(destPort, text);
			}
			else if(sep == 9)
			{
				strcpy(destPRange, text);
			}
			else if(sep == 10)
			{
				strcpy(protocol, text);
			}

			Src += text;
			if(sep < 10)
				Src += ' ';

			j = 0;
			iTail = n + 1;
		}

		int r = atoi(No);
		r++;
		_itoa( r, No, 10 );

		RuleNo = "     Rule : " + CString(No);

		Src = "     Source IP : " + CString(srcAddr) + "/" + CString(srcMask) 
			+ " Port : " + CString(srcPort) + "-" + CString(srcPRange);

		Dest = "     Destination IP : " + CString(destAddr) + "/" + CString(destMask) 
			+ " Port : " + CString(destPort) + "-" + CString(destPRange);

		Protocol = "     Protocol : " + CString(protocol);

		m_listMessage.AddString(RuleNo, RGB(0xFF, 0x66, 0x00));
		m_listMessage.AddString(Src, RGB(0xFF, 0x66, 0x00));
		m_listMessage.AddString(Dest, RGB(0xFF, 0x66, 0x00));
		m_listMessage.AddString(Protocol, RGB(0xFF, 0x66, 0x00));
//----------------------------

		RestartFilter();	// restart filter

	}

//-------- Remote Control --------

	else if((command == 0x0A)&&(toggle == 1))
	{
		m_listMessage.AddString("Status:> [Remote Control] Setting firewall filter 'ON'", RGB(0x33, 0xCC, 0x00));

		if(!strcmp(m_strFirewallStatus, "Enable") == 0)		// if not enable
		{
			OnStartFilter();
		}
	}
	else if((command == 0x0A)&&(toggle == 0))
	{
		m_listMessage.AddString("Status:> [Remote Control] Setting firewall filter 'OFF'", RGB(0x33, 0xCC, 0x00));

		if(!strcmp(m_strFirewallStatus, "Disable") == 0)	// if not disable
		{
			OnStopFilter();
		}
	}
	else if((command == 0x0B)&&(toggle == 1))
	{
		m_listMessage.AddString("Status:> [Remote Control] Setting NIDS 'ON'", RGB(0x33, 0xCC, 0x00));

		KillTimer(1);
		StatusStop = TRUE;
		if ( ::Sniffer.GetStatusPromiscuous() == TRUE )
		{
			::Sniffer.ClearSniff();
			::Sniffer.ClosePromiscuous();
		}
//		CSelectAdapter dlg;
//		int nResponse = dlg.DoModal();

		NumberAdapter = 0;
		OpenAdapter = 1;

		if(!strcmp(m_strNidsStatus, "Enable") == 0)		// if not enable
		{
			OnStart();
		}
	}
	else if((command == 0x0B)&&(toggle == 0))
	{
		m_listMessage.AddString("Status:> [Remote Control] Setting NIDS 'OFF'", RGB(0x33, 0xCC, 0x00));

		if(!strcmp(m_strNidsStatus, "Disable") == 0)	// if not disable
		{
			OnStop();
		}
	}

	else
	{
		m_listMessage.AddString("Status:> Command error.");
	}
}

void CFirewallAgentDlg::SendData(char *data)
{
	UpdateData(TRUE);
	
	int BytesSent;
	CString Message;
	char tmp[128];

	strcpy(tmp, data);
//	sprintf(tmp, "%c%s%c%s%c%s%c", 2, "zest", 1, "hello", 1, "2", 1);
	Message = tmp;

	BytesSent = Message.GetLength();	// get length of message
	BytesSent++;

	sprintf(tmp, "%c", BytesSent);

	CString Msg(tmp + Message);
	BytesSent = Msg.GetLength();

 	if (Message != "")
	{
		int dwBytes;
		dwBytes = m_connectSock.Send((LPCTSTR)Msg, BytesSent);
		
		if (dwBytes == SOCKET_ERROR)
		{
			if (m_connectSock.GetLastError() != WSAEWOULDBLOCK)
			{
				char strError[256];
				wsprintf(strError, "Socket failed to send, Error Code: %d", m_connectSock.GetLastError());
				//Closed();
				AfxMessageBox (strError);
			}
		}
		else
		{
//			CString strTemp = "S: ";
			m_intCountSentByte += BytesSent;
//			m_strSentTotalMessages.Format("%lu", m_intCountSentByte);
//			strTemp += m_strSendMessages;
//			m_listMessage.AddString(strTemp);

//			m_authenticated = TRUE;
//			m_listMessage.AddString("Status:> Command sent...");

			UpdateData(FALSE);
		}
	}
}

LONG CFirewallAgentDlg::OnSystrayNotify(WPARAM wParam, LPARAM lParam)
{
	POINT pt;
	CMenu menu;
	CMenu* subMenu;

	switch(lParam)
	{
		case WM_LBUTTONDBLCLK:
			OnSysTrayOpen();
		break;

		case WM_RBUTTONUP:
			::GetCursorPos(&pt);
			menu.LoadMenu(IDR_MENUTRAY);
			subMenu = menu.GetSubMenu(0);
			subMenu->SetDefaultItem(0, TRUE);
			subMenu->TrackPopupMenu(TPM_LEFTBUTTON | TPM_RIGHTBUTTON | TPM_LEFTALIGN, pt.x, pt.y, this, NULL);
			menu.DestroyMenu();
			break;

		default:
			return FALSE;
	}

	return 0;
}

void CFirewallAgentDlg::OnSysTrayClose() 
{
	Shell_NotifyIcon(NIM_DELETE, &m_notifyIconData);
	PostMessage(WM_QUIT, 0, 0);
	CFirewallAgentDlg::OnCancel();
}

void CFirewallAgentDlg::OnSysTrayOpen() 
{
	SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_SHOWWINDOW | SWP_NOSIZE);
	ShowWindow(SW_RESTORE);
	Shell_NotifyIcon(NIM_DELETE, &m_notifyIconData);
}

void CFirewallAgentDlg::OnTimer(UINT nIDEvent) 
{
	CString Type,Src,Dst,Time;
	if (::AnalyPacket.GetResult(Type,Src,Dst,Time))
	{

		(void)m_List.AddItem( _T(Type), _T(Src), _T(Dst) , _T(Time) );

		AttackAlert(Type, Src);

		m_notifyIconData.hIcon	= (HICON) LoadImage(AfxGetApp()->m_hInstance, 
		MAKEINTRESOURCE(IDI_ALERT), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR); //AfxGetApp()->LoadIcon(IDR_MAINFRAME);
//		strcpy(m_notifyIconData.szTip, "Nids For Windows");
		Shell_NotifyIcon(NIM_MODIFY, &m_notifyIconData);
//		::Attack = FALSE;
	}
	
	CDialog::OnTimer(nIDEvent);
}

void CFirewallAgentDlg::OnSize(UINT nType, int cx, int cy) 
{
	switch(nType)
	{
		case SIZE_MINIMIZED :
			m_notifyIconData.hIcon	= (HICON) LoadImage(AfxGetApp()->m_hInstance, 
			MAKEINTRESOURCE(IDI_TRAY), IMAGE_ICON, 16, 16, LR_DEFAULTCOLOR); //AfxGetApp()->LoadIcon(IDR_MAINFRAME);
			Shell_NotifyIcon(NIM_ADD, &m_notifyIconData);
			SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_HIDEWINDOW | SWP_NOSIZE);
		break;
	}

	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	
}

void CFirewallAgentDlg::OnStop() 
{
	if ( ::Sniffer.GetStatusPromiscuous() == TRUE )
	{
		KillTimer(1);
		StatusStop = TRUE;
		//MessageBox("NIDS has been stop", "Isag PFW", MB_OK | MB_ICONINFORMATION);
		m_listMessage.AddString("Status:> NIDS has been stop.");
		m_strNidsStatus = _T("Disable");
		UpdateData(FALSE);

		::Sniffer.ClearSniff();
		::Sniffer.ClosePromiscuous();
	}
}

void CFirewallAgentDlg::OnCancel() 
{
	KillTimer(1);
	StatusStop = TRUE;
	if ( ::Sniffer.GetStatusPromiscuous() == TRUE )
	{
		char show_buffer[350];
		LONG SumPacket,SumLost;
		::Sniffer.GetStatusPacket(SumPacket,SumLost);
		sprintf(show_buffer,"%ld Packets received.\r\n%ld Packets lost.\r\n",SumPacket,SumLost);
		MessageBox(show_buffer, "Isag PFW", MB_OK | MB_ICONINFORMATION);
		UpdateData(FALSE);
		::Sniffer.ClearSniff();
		::Sniffer.ClosePromiscuous();
	}
	Shell_NotifyIcon(NIM_DELETE, &m_notifyIconData);
//	SetWindowPos(&wndTop, 0, 0, 0, 0, SWP_NOMOVE | SWP_HIDEWINDOW | SWP_NOSIZE);
	
	CDialog::OnCancel();
}

void CFirewallAgentDlg::OnOK() 
{
	if(OpenAdapter == 0)
	{
		MessageBox("Please Select Device first.", "Isag PFW", MB_OK | MB_ICONWARNING);
		OnSelectAdapter() ;
	}
	else
	{
			if(ButtonFlag == 0)	
			{
					SetDlgItemText( IDOK , "Stop NIDS" ) ;
					OnStart() ;
					ButtonFlag = 1 ;
			}
			else if(ButtonFlag == 1)
			{
					SetDlgItemText( IDOK , "Start NIDS" ) ;
					OnStop() ;
					ButtonFlag = 0 ;
			}
	}   
	
	//CDialog::OnOK();
}

void CFirewallAgentDlg::OnStart()
{
	if(::Sniffer.GetStatusPromiscuous() == FALSE )
	{
		UpdateData(FALSE);
		if(::Sniffer.OpenPromiscuous(NumberAdapter))
		{
			SetTimer(1,TIME_ELAP,NULL);
			StatusStop = FALSE;

			m_listMessage.AddString("Status:> Starting NIDS...", RGB(0, 0, 0));
			m_strNidsStatus = _T("Enable");
			UpdateData(FALSE);
		}
		AfxBeginThread((AFX_THREADPROC)Thread_Analysis,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
		AfxBeginThread((AFX_THREADPROC)Thread_Sniff,GetSafeHwnd(),THREAD_PRIORITY_IDLE);
	}
}

void CFirewallAgentDlg::OnSelectAdapter() 
{
	KillTimer(1);
	StatusStop = TRUE;
	if ( ::Sniffer.GetStatusPromiscuous() == TRUE )
	{
		::Sniffer.ClearSniff();
		::Sniffer.ClosePromiscuous();
	}
	CSelectAdapter dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		NumberAdapter = dlg.GetNumAdapSelect();
		OpenAdapter = 1 ;
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}
	// TODO: Add your command handler code here
	
	SetDlgItemText( IDOK , "Start NIDS");	
}

void CFirewallAgentDlg::OnHelpAbout() 
{
	CAboutDlg About;
	About.DoModal();	
}

void CFirewallAgentDlg::RestartFilter()
{
	RestartFlag = TRUE;
	if(!strcmp(m_strFirewallStatus, "Disable") == 0)
	{
		OnStopFilter();
	}
	OnStartFilter();
	RestartFlag = FALSE;
	m_listMessage.AddString("Firewall:> Restart filter.", RGB(0xFF, 0x66, 0x00));
}

void CFirewallAgentDlg::AttackAlert(CString Type, CString Src)
{
	char data[128];

	if(strcmp(Type, "ICMP Bomb") == 0)
	{
		Type = "1";
	}
	else if(strcmp(Type, "ICMP IP Loop") == 0)
	{
		Type = "2";
	}
	else if(strcmp(Type, "Ping Sweeps") == 0)
	{
		Type = "3";
	}
	else if(strcmp(Type, "ICMP OverLap") == 0)
	{
		Type = "4";
	}
	else if(strcmp(Type, "IP Bomb") == 0)
	{
		Type = "5";
	}
	else if(strcmp(Type, "IP IP Loop") == 0)
	{
		Type = "6";
	}
	else if(strcmp(Type, "IP OverLap") == 0)
	{
		Type = "7";
	}
	else if(strcmp(Type, "IP Gap") == 0)
	{
		Type = "8";
	}
	else if(strcmp(Type, "TCP Scan Port") == 0)
	{
		Type = "9";
	}
	else if(strcmp(Type, "Sync Flood") == 0)
	{
		Type = "10";
	}
	else if(strcmp(Type, "Os Finger Print") == 0)
	{
		Type = "11";
	}
	else if(strcmp(Type, "UDP Scan Port") == 0)
	{
		Type = "12";
	}

	sprintf(data, "%c%s%c%s%c", 5, Type, 1, Src, 1);	// 5 = attack alert
	SendData(data);
	m_listMessage.AddString("NIDS:> Send attack alert to server.", RGB(0xFF, 0x00, 0x00));
}

void CFirewallAgentDlg::OnClearlog() 
{
	m_listMessage.ResetContent();
}

void CFirewallAgentDlg::OnLogin() 
{
	OnConnect();
}

void CFirewallAgentDlg::LoadConfig()
{
	FILE *f;
	char ip[16];
	int port;
	f = fopen("isagpfw.cfg","r");
	if(!f)
		return;
	fscanf(f, "%s %d",&ip, &port);
	strcpy(SERVER_IP, ip);
	SERVER_PORT = port;
	fclose(f);
}
