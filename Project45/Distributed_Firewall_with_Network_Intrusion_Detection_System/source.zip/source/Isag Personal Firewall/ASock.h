#if !defined(AFX_ASOCK_H__CEBB9561_51F8_485A_B7A8_9DF3AB009E4E__INCLUDED_)
#define AFX_ASOCK_H__CEBB9561_51F8_485A_B7A8_9DF3AB009E4E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ASock.h : header file
//

#define MAX_BUFFER 256

/////////////////////////////////////////////////////////////////////////////
// CASock command target

class CASock : public CAsyncSocket
{
// Attributes
public:

// Operations
public:
	CASock();
	virtual ~CASock();

// Overrides
public:
	void SetParent(CDialog *pDwnd);
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CASock)
	public:
	virtual void OnConnect(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CASock)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
	CDialog* m_pDwnd;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ASOCK_H__CEBB9561_51F8_485A_B7A8_9DF3AB009E4E__INCLUDED_)
