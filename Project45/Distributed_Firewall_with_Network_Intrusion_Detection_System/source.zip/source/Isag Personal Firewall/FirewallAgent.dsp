# Microsoft Developer Studio Project File - Name="FirewallAgent" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=FirewallAgent - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "FirewallAgent.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "FirewallAgent.mak" CFG="FirewallAgent - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "FirewallAgent - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "FirewallAgent - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "FirewallAgent - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x41e /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "FirewallAgent - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 5
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MTd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /FR /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x41e /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 IPHlpApi.Lib WSock32.Lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "FirewallAgent - Win32 Release"
# Name "FirewallAgent - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\Analy_ICMP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_IP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_TCP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analy_UDP.cpp
# End Source File
# Begin Source File

SOURCE=.\Analysis.cpp
# End Source File
# Begin Source File

SOURCE=.\ASock.cpp
# End Source File
# Begin Source File

SOURCE=.\Bomb_Packet.cpp
# End Source File
# Begin Source File

SOURCE=.\ColorListBox.cpp
# End Source File
# Begin Source File

SOURCE=.\DeviceList.cpp
# End Source File
# Begin Source File

SOURCE=.\FilterRule.cpp
# End Source File
# Begin Source File

SOURCE=.\FirewallAgent.cpp
# End Source File
# Begin Source File

SOURCE=.\FirewallAgent.rc
# End Source File
# Begin Source File

SOURCE=.\FirewallAgentDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\Fragment.cpp
# End Source File
# Begin Source File

SOURCE=.\GetFin.cpp
# End Source File
# Begin Source File

SOURCE=.\GetPort.cpp
# End Source File
# Begin Source File

SOURCE=.\Header_Packet.cpp
# End Source File
# Begin Source File

SOURCE=.\Link_Fragment.cpp
# End Source File
# Begin Source File

SOURCE=.\LoginDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\PingSweeps.cpp
# End Source File
# Begin Source File

SOURCE=.\Registry.cpp
# End Source File
# Begin Source File

SOURCE=.\Result.cpp
# End Source File
# Begin Source File

SOURCE=.\SelectAdapter.cpp
# End Source File
# Begin Source File

SOURCE=.\Sniff.cpp
# End Source File
# Begin Source File

SOURCE=.\SortHeaderCtrl.cpp
# End Source File
# Begin Source File

SOURCE=.\SortListCtrl.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\W2kFilter.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\Analy_ICMP.h
# End Source File
# Begin Source File

SOURCE=.\Analy_IP.h
# End Source File
# Begin Source File

SOURCE=.\Analy_TCP.h
# End Source File
# Begin Source File

SOURCE=.\Analy_UDP.h
# End Source File
# Begin Source File

SOURCE=.\Analysis.h
# End Source File
# Begin Source File

SOURCE=.\ASock.h
# End Source File
# Begin Source File

SOURCE=.\Bomb_Packet.h
# End Source File
# Begin Source File

SOURCE=.\ColorListBox.h
# End Source File
# Begin Source File

SOURCE=.\DeviceList.h
# End Source File
# Begin Source File

SOURCE=.\FilterRule.h
# End Source File
# Begin Source File

SOURCE=.\FirewallAgent.h
# End Source File
# Begin Source File

SOURCE=.\FirewallAgentDlg.h
# End Source File
# Begin Source File

SOURCE=.\Fragment.h
# End Source File
# Begin Source File

SOURCE=.\GetFin.h
# End Source File
# Begin Source File

SOURCE=.\GetPort.h
# End Source File
# Begin Source File

SOURCE=.\Header_Packet.h
# End Source File
# Begin Source File

SOURCE=.\Link_Fragment.h
# End Source File
# Begin Source File

SOURCE=.\LoginDlg.h
# End Source File
# Begin Source File

SOURCE=.\PingSweeps.h
# End Source File
# Begin Source File

SOURCE=.\Registry.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\Result.h
# End Source File
# Begin Source File

SOURCE=.\SelectAdapter.h
# End Source File
# Begin Source File

SOURCE=.\Sniff.h
# End Source File
# Begin Source File

SOURCE=.\SortHeaderCtrl.h
# End Source File
# Begin Source File

SOURCE=.\SortListCtrl.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\W2kFilter.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=".\res\Firewall - 1.ico"
# End Source File
# Begin Source File

SOURCE=".\res\Firewall - 2.ico"
# End Source File
# Begin Source File

SOURCE=.\res\Firewall_AlertIcon.ico
# End Source File
# Begin Source File

SOURCE=.\res\Firewall_MainIcon.ico
# End Source File
# Begin Source File

SOURCE=.\res\Firewall_TrayIcon.ico
# End Source File
# Begin Source File

SOURCE=.\res\FirewallAgent.ico
# End Source File
# Begin Source File

SOURCE=.\res\FirewallAgent.rc2
# End Source File
# Begin Source File

SOURCE=".\res\Logo - 1.bmp"
# End Source File
# Begin Source File

SOURCE=".\res\Logo - 3.bmp"
# End Source File
# End Group
# Begin Source File

SOURCE=.\ReadMe.txt
# End Source File
# Begin Source File

SOURCE=.\lib\Packet.lib
# End Source File
# End Target
# End Project
