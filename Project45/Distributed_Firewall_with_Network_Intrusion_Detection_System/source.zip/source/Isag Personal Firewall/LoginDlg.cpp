// LoginDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FirewallAgent.h"
#include "LoginDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg dialog


CLoginDlg::CLoginDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLoginDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLoginDlg)
	m_strPassword = _T("");
	m_strUser = _T("");
	m_bRemember = FALSE;
	//}}AFX_DATA_INIT
}


void CLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLoginDlg)
	DDX_Text(pDX, IDC_PASSWD, m_strPassword);
	DDX_Text(pDX, IDC_USER, m_strUser);
	DDX_Check(pDX, IDC_REMEMBER, m_bRemember);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLoginDlg, CDialog)
	//{{AFX_MSG_MAP(CLoginDlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLoginDlg message handlers

CString CLoginDlg::GetUsername()
{
	return m_strUser;	
}

CString CLoginDlg::GetPassword()
{
	return m_strPassword;
}

BOOL CLoginDlg::GetRemember()
{
	return m_bRemember;
}
