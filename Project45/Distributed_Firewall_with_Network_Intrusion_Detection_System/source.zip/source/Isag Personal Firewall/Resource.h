//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FirewallAgent.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FIREWALLAGENT_DIALOG        102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_SELECT_ADAP                 131
#define IDB_LOGO1                       132
#define IDR_MENUTRAY                    134
#define IDR_MAINMENU                    135
#define IDI_ALERT                       136
#define IDI_TRAY                        137
#define IDI_MAIN                        138
#define IDB_LOGO2                       139
#define IDD_LOGIN                       140
#define IDC_STARTFILTER                 1004
#define IDC_STOPFILTER                  1005
#define IDC_CONNECT                     1006
#define IDC_DISCONNECT                  1007
#define IDC_CLIENTPORT                  1013
#define IDC_CLIENTIP                    1014
#define IDC_SERVERIP                    1015
#define IDC_SERVERPORT                  1016
#define IDC_CONNECTSTATUS               1019
#define IDC_FIREWALLSTATUS              1020
#define IDC_NIDSSTATUS                  1021
#define IDC_LISTMESSAGES                1023
#define IDC_LIST_ADAP                   1024
#define IDC_LIST                        1025
#define IDC_USER                        1028
#define IDC_PASSWD                      1029
#define IDC_REMEMBER                    1031
#define ID_OPEN                         32771
#define ID_CLOSE                        32772
#define ID_HELP_ABOUT                   32774
#define ID_SELECTADAPTER                32775
#define ID_CLEARLOG                     32776
#define ID_LOGIN                        32777
#define ID_LOGOUT                       32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
