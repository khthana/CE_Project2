// Registry.h: interface for the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REGISTRY_H__6AFE1D5B_BFDC_4F1F_A719_2A3822CC274D__INCLUDED_)
#define AFX_REGISTRY_H__6AFE1D5B_BFDC_4F1F_A719_2A3822CC274D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define CLASS_NAME_LENGTH 255

class CRegistry  
{
public:
	CRegistry();
	virtual ~CRegistry();

protected:
	HKEY m_hRootKey;
	CString m_CurrentKey;

public:
	BOOL OpenReg(CString KeyStr);
	BOOL CreateKey(CString strKey);
	BOOL AddValue(CString value,CString data);
	BOOL DeleteValue(const CString strName);
	int GetValueCount();
	BOOL GetRegistryList(CStringArray &);

};

#endif // !defined(AFX_REGISTRY_H__6AFE1D5B_BFDC_4F1F_A719_2A3822CC274D__INCLUDED_)
