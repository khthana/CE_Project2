; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CFirewallAgentDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "FirewallAgent.h"

ClassCount=6
Class1=CFirewallAgentApp
Class2=CFirewallAgentDlg
Class3=CAboutDlg

ResourceCount=9
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_FIREWALLAGENT_DIALOG
Resource4=IDD_FIREWALLAGENT_DIALOG (English (U.S.))
Class4=CASock
Resource5=IDD_LOGIN (English (U.S.))
Class5=CSelectAdapter
Resource6=IDR_MENUTRAY (English (U.S.))
Resource7=IDD_SELECT_ADAP (English (U.S.))
Resource8=IDD_ABOUTBOX (English (U.S.))
Class6=CLoginDlg
Resource9=IDR_MAINMENU (English (U.S.))

[CLS:CFirewallAgentApp]
Type=0
HeaderFile=FirewallAgent.h
ImplementationFile=FirewallAgent.cpp
Filter=N
LastObject=CFirewallAgentApp

[CLS:CFirewallAgentDlg]
Type=0
HeaderFile=FirewallAgentDlg.h
ImplementationFile=FirewallAgentDlg.cpp
Filter=W
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CFirewallAgentDlg

[CLS:CAboutDlg]
Type=0
HeaderFile=FirewallAgentDlg.h
ImplementationFile=FirewallAgentDlg.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_FIREWALLAGENT_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CFirewallAgentDlg

[DLG:IDD_FIREWALLAGENT_DIALOG (English (U.S.))]
Type=1
Class=CFirewallAgentDlg
ControlCount=26
Control1=IDC_CONNECT,button,1342242816
Control2=IDC_DISCONNECT,button,1342242816
Control3=IDC_STARTFILTER,button,1342242816
Control4=IDC_STOPFILTER,button,1342242816
Control5=IDOK,button,1342242817
Control6=IDCANCEL,button,1342242816
Control7=IDC_STATIC,button,1342177287
Control8=IDC_STATIC,static,1342308352
Control9=IDC_STATIC,static,1342308352
Control10=IDC_CLIENTIP,static,1342308352
Control11=IDC_CLIENTPORT,static,1342308352
Control12=IDC_STATIC,button,1342177287
Control13=IDC_STATIC,static,1342308352
Control14=IDC_STATIC,static,1342308352
Control15=IDC_SERVERIP,static,1342308352
Control16=IDC_SERVERPORT,static,1342308352
Control17=IDC_STATIC,button,1342177287
Control18=IDC_STATIC,static,1342308352
Control19=IDC_STATIC,static,1342308352
Control20=IDC_CONNECTSTATUS,static,1342308352
Control21=IDC_FIREWALLSTATUS,static,1342308352
Control22=IDC_LISTMESSAGES,listbox,1352728913
Control23=IDC_LIST,SysListView32,1350631425
Control24=IDC_STATIC,static,1342308352
Control25=IDC_STATIC,static,1342177294
Control26=IDC_NIDSSTATUS,static,1342308352

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=1
Control1=IDC_STATIC,static,1342177294

[CLS:CASock]
Type=0
HeaderFile=ASock.h
ImplementationFile=ASock.cpp
BaseClass=CAsyncSocket
Filter=N
LastObject=CASock
VirtualFilter=q

[DLG:IDD_SELECT_ADAP (English (U.S.))]
Type=1
Class=CSelectAdapter
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_LIST_ADAP,SysListView32,1350631425

[CLS:CSelectAdapter]
Type=0
HeaderFile=SelectAdapter.h
ImplementationFile=SelectAdapter.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_LIST_ADAP

[MNU:IDR_MENUTRAY (English (U.S.))]
Type=1
Class=?
Command1=ID_OPEN
Command2=ID_CLOSE
CommandCount=2

[MNU:IDR_MAINMENU (English (U.S.))]
Type=1
Class=?
Command1=ID_LOGIN
Command2=ID_LOGOUT
Command3=IDCANCEL
Command4=ID_SELECTADAPTER
Command5=ID_CLEARLOG
Command6=ID_HELP_ABOUT
CommandCount=6

[DLG:IDD_LOGIN (English (U.S.))]
Type=1
Class=CLoginDlg
ControlCount=8
Control1=IDC_USER,edit,1350631552
Control2=IDC_PASSWD,edit,1350631584
Control3=IDC_REMEMBER,button,1342242819
Control4=IDOK,button,1342242817
Control5=IDCANCEL,button,1342242816
Control6=IDC_STATIC,static,1342308352
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352

[CLS:CLoginDlg]
Type=0
HeaderFile=LoginDlg.h
ImplementationFile=LoginDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=IDC_PASSWD
VirtualFilter=dWC

