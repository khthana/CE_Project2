// Fragment.cpp: implementation of the Fragment class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "FirewallAgent.h"
#include "Fragment.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Fragment::Fragment()
{

}

Fragment::~Fragment()
{

}
