// FirewallAgentDlg.h : header file
//

#if !defined(AFX_FIREWALLAGENTDLG_H__FB7E511B_F22C_4434_98B6_9FDA96DC4CAD__INCLUDED_)
#define AFX_FIREWALLAGENTDLG_H__FB7E511B_F22C_4434_98B6_9FDA96DC4CAD__INCLUDED_

#include "ASock.h"	// Added by ClassView
#include "W2kFilter.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SortListCtrl.h"
#include "ColorListBox.h"

/////////////////////////////////////////////////////////////////////////////
// CFirewallAgentDlg dialog

class CFirewallAgentDlg : public CDialog
{
// Construction
public:
	void LoadConfig();
	void SendData(char *data);
	void MsgQuery(char *msg);
	void Authenticate();
	void Connected();
	void Closed();
	~CFirewallAgentDlg();
	CFirewallAgentDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFirewallAgentDlg)
	enum { IDD = IDD_FIREWALLAGENT_DIALOG };
	CButton	m_IDOK;
	CSortListCtrl	m_List;
	CColorListBox	m_listMessage;
	CString	m_strServerIP;
	UINT	m_intServerPort;
	CString	m_strClientIP;
	CString	m_strClientPort;
	CString	m_strConnectionStatus;
	CString	m_strFirewallStatus;
	CString	m_strNidsStatus;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFirewallAgentDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	NOTIFYICONDATA m_notifyIconData;
	int NumberAdapter;

	CObList* m_RuleSet;
	BOOL m_authenticated;
	void SetClientIP();
	int m_intCountSentByte;
	CASock m_connectSock;
	CW2kFilter *m_FilterEngine;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFirewallAgentDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStartFilter();
	afx_msg void OnStopFilter();
	afx_msg void OnConnect();
	afx_msg void OnDisconnect();
	afx_msg void OnSysTrayClose();
	afx_msg void OnSysTrayOpen();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg LONG OnSystrayNotify(WPARAM wParam, LPARAM lParam);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnStop();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnSelectAdapter();
	afx_msg void OnHelpAbout();
	afx_msg void OnClearlog();
	afx_msg void OnLogin();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_Password;
	CString m_Username;
	void AttackAlert(CString Type, CString Src);
	void RestartFilter();
	BOOL RestartFlag;
	void OnStart();
	int OpenAdapter;
	int ButtonFlag;
	int FileFlag;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIREWALLAGENTDLG_H__FB7E511B_F22C_4434_98B6_9FDA96DC4CAD__INCLUDED_)
