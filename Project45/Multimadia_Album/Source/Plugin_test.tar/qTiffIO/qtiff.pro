TEMPLATE = lib
CONFIG = qt warn_on release
HEADERS = qtiffio.h
SOURCES = qtiffio.cpp
TARGET = qtiffio
LIBS = -lqpe -lqte -ltiff
