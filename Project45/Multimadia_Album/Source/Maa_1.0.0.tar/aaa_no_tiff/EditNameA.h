/****************************************************************************
** Form interface generated from reading ui file 'EditProp.ui'
**
** Created: Sun Feb 16 22:21:54 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef EDITFORM_H
#define EDITFORM_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;

class EditForm : public QDialog
{ 
    Q_OBJECT

public:
    EditForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~EditForm();

    QLabel* RowID;
    QLineEdit* NameLineEdit;
    QLabel* NameLabel;
    QLabel* IDLabel;

    QString AlbumID;
    QString Name;
    QTimer *timer;

public slots:
    virtual void genProp();

};

#endif // EDITFORM_H
