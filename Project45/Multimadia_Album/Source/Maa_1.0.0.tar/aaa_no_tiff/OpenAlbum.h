/****************************************************************************
** Form interface generated from reading ui file '/tmp/Dev4Project/aaa/OpenAlbum.ui'
**
** Created: Sat Feb 1 04:14:52 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef OPENALBUMFORM_H
#define OPENALBUMFORM_H

#include <qvariant.h>
#include <qdialog.h>
#include <qstring.h>

#include "sqlite.h"

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QLineEdit;
class QListView;
class QListViewItem;
class QToolButton;

class OpenAlbumForm : public QDialog
{
    Q_OBJECT

public:
    OpenAlbumForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~OpenAlbumForm();

    QLineEdit* AlbumNameLine;
    QListView* AlbumDB;
    QString AlbumName;
    QString NameAlbum;
    QToolButton* EditButton;
    QToolButton* NewButton;

    sqlite *db;
    QTimer *timer;




public slots:
    virtual void openAlbum(QListViewItem*);
    virtual void genList();
    virtual void New1Album();
    virtual void EditAlbumName();

protected:
    QVBoxLayout* Layout;
};

#endif // OPENALBUMFORM_H
