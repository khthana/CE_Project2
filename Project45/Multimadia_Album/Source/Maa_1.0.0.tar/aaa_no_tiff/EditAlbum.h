/****************************************************************************
** Form interface generated from reading ui file 'EditAlbum.ui'
**
** Created: Fri Dec 20 22:21:30 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef EDITALBUMFORM_H
#define EDITALBUMFORM_H

#include <qvariant.h>
#include <qdialog.h>
#include <qdir.h>
#include <qwidgetstack.h>
#include <qurloperator.h>
#include <qgroupbox.h>
#include <qpe/ir.h>

#include "sqlite.h"



class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;
class QListView;
class QListViewItem;
class QPushButton;
class QToolButton;

class EditAlbumForm : public QDialog
{
    Q_OBJECT

public:
    EditAlbumForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~EditAlbumForm();
    QFileInfo *fileInfoe;
    QFileInfoList *fileListe;
    QLabel* AlbumText;
    QPushButton* DelAlbumButton;
    //QToolButton* BackButton;
    //QToolButton* UpButton;
    QListView* FileList;
    QListView* Listinvi;
    QListView* AlbumList;
    QListView* List2Export;
    QListView* inAlbum;
    QLineEdit* AlbumPath;
    QToolButton* SearchAlbum;
    QPushButton* AddFileButton;
    QPushButton* DelFileButton;
    QPushButton* XportButton;
    QPushButton* SaveAlbumButton;
    QPushButton* EditAlbumButton;
    QPushButton* removeFileButton;
    QPushButton* SaveIndexButton;
    QPushButton* RenameButton;
    QPushButton* OpenButton;
    QPushButton* UpButton;
    QPushButton* DownButton;
    QLabel* FileText;
    QPushButton* CloseAlbumButton;
    QWidgetStack* optional;
    QWidgetStack* optional2;
    QGroupBox* privateLayout;
    QString str;
    QString Path;
    QString NameinAlbum;
    void loadAlbum( const QString &filename );

    QGroupBox* XGroup;
    QToolButton* AddXButton;
    QToolButton* DelXButton;
    QToolButton* OKXButton3;


    QString Album2Open;
    QString Albumnow;
    sqlite* db;
    QTimer *timer;
    QString ID2load;

    void reloadAlbum();
    void gen();

    bool copyFile( const QString & dest, const QString & src );

public slots:
    virtual void viewe(QListViewItem *);
    virtual void getNameA(QListViewItem *);
    virtual void add();
    virtual void del();
    virtual void findAlbum();
    virtual void edit();
    virtual void genList();
    virtual void showXport();
    virtual void saveIndex();
    virtual void delFileDB();
    virtual void Add2Xport();
    virtual void getItemXport();
    virtual void DelXport();
    virtual void XportOK();
    virtual void Op2F();
    virtual void goUp();
    virtual void goDown();

protected:
    QVBoxLayout* ButtonLayout;
    QVBoxLayout* ListLayout;
    QHBoxLayout* AlbumLayout;
};

#endif // EDITALBUMFORM_H
