/****************************************************************************
** Form implementation generated from reading ui file 'FileConvert.ui'
**
** Created: Fri Dec 20 23:05:10 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "FileConvert.h"

#include <qbuttongroup.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a FileConvertForm which is a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
FileConvertForm::FileConvertForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "FileConvertForm" );
    resize( 221, 150 );
    setCaption( tr( "Change Image Format" ) );
    SaveYes='0';

    QWidget* privateLayoutWidget = new QWidget( this, "ButtonLayout" );
    privateLayoutWidget->setGeometry( QRect( 25, 95, 180, 38 ) );
    ButtonLayout = new QHBoxLayout( privateLayoutWidget );
    ButtonLayout->setSpacing( 6 );
    ButtonLayout->setMargin( 0 );

    SaveOK = new QPushButton( privateLayoutWidget, "SaveOK" );
    SaveOK->setText( tr( "OK" ) );
    ButtonLayout->addWidget( SaveOK );
    connect(SaveOK, SIGNAL(clicked()), this, SLOT(SaySave()));

    SaveCancel = new QPushButton( privateLayoutWidget, "SaveCancel" );
    SaveCancel->setText( tr( "Cancel" ) );
    ButtonLayout->addWidget( SaveCancel );
    connect(SaveCancel, SIGNAL(clicked()), this, SLOT(reject()));

    FileType = new QButtonGroup( this, "FileType" );
    FileType->setGeometry( QRect( 10, 5, 201, 80 ) );
    FileType->setTitle( tr( "New Format" ) );

    gif = new QRadioButton( FileType, "gif" );
    gif->setGeometry( QRect( 50, 45, 40, 20 ) );
    gif->setText( tr( "GIF" ) );

    xpm = new QRadioButton( FileType, "xpm" );
    xpm->setGeometry( QRect( 125, 45, 40, 20 ) );
    xpm->setText( tr( "XPM" ) );

    png = new QRadioButton( FileType, "png" );
    png->setGeometry( QRect( 145, 20, 40, 20 ) );
    png->setText( tr( "PNG" ) );

    jpg = new QRadioButton( FileType, "jpg" );
    jpg->setGeometry( QRect( 10, 20, 85, 20 ) );
    jpg->setText( tr( "JPEG" ) );
    jpg->setChecked( TRUE );

    bmp = new QRadioButton( FileType, "bmp" );
    bmp->setGeometry( QRect( 83, 20, 40, 20 ) );
    bmp->setText( tr( "BMP" ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
FileConvertForm::~FileConvertForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void FileConvertForm::SaySave()
{
    SaveYes='1';
    if (gif->isChecked())
       Type = "1";
    else if (xpm->isChecked())
       Type = "2";
    else if (png->isChecked())
       Type = "3";
    else if (jpg->isChecked())
       Type = "4";
    else if (bmp->isChecked())
       Type = "5";
    this->close();
}

