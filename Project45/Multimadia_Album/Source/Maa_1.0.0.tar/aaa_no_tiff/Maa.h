/****************************************************************************
** Form interface generated from reading ui file 'Maa.ui'
**
** Created: Sat Dec 14 09:02:02 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef MAAFORM_H
#define MAAFORM_H

#include <qvariant.h>
#include <qwidget.h>
#include <qdir.h>
#include <qwidgetstack.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qgroupbox.h>
#include <qpe/qpemenubar.h>
#include <qpe/qpetoolbar.h>
#include <qpe/ir.h>
#include <qpe/qlibrary.h>
#include <qmainwindow.h>
#include <qframe.h>
#include <qpe/qlibrary.h>
#include <qpe/mediaplayerplugininterface.h>
#include <qscrollview.h>
#include "sqlite.h"
class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QFrame;
class QGroupBox;
class QListView;
class QListViewItem;
class QSlider;
class QToolButton;





class MaaForm : public QWidget
{
    Q_OBJECT

public:
    MaaForm( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~MaaForm();
    
    QListView* AlbumListView;
    QListView* AlbumIndex;
    QListView* List4import;
    QListView* List4maa;
    QToolButton* SaveButton;
    QToolButton* NextButton;
    QToolButton* BackButton;
    QToolButton* EditAButton;
    QToolButton* PropButton;
    QToolButton* UpButton;
    QToolButton* DownButton;
    QListView* FileListView;
    QWidget* FrameShow;
    QListViewItem *item1;
    int AandF;
    QString AlbumName;
    QWidgetStack* optionals;
    QWidgetStack* optional1;
    QTimer *timer;
    QTimer *timer2;
    QString fileName2Do;
    QString FName;
    QString ImageName;
    QWidget* frameFull;
    QFileInfo *fileInfoE;
    QFileInfoList *fileListE;
    QGroupBox* Layout1st;
    QGroupBox* Layout2nd;
    bool isFullScreen;
    bool isSlide;
    bool copyFile( const QString & dest, const QString & src );
    void ImportAlbum( const QString & path );
    void loadA();
    QPEMenuBar *mb;
    bool loadImage( const char *fileName );
    void        openFile(const char *newfilename);
    void        paintEvent( QPaintEvent * );
    void        scale();
    int         conversion_flags;
    int         alloc_context;
    bool        convertEvent( QMouseEvent* e, int& x, int& y );
    const char* filename;
    QImage      image;                  // the loaded image
    QPixmap     pm;                     // the converted pixmap
    QPixmap     pmScaled;               // the scaled pixmap
    bool        reconvertImage();
    int         pickx, picky;
    int         clickx, clicky;
    bool        may_be_other;
    void        setImage(const QImage& newimage);
    void resizeContents(int w, int h);
    sqlite *db;
    char *zErrMsg;
    int rc;
    static int callback(void *NotUsed, int argc, char **argv, char **azColName);
    void toggleFullscreen();
    void normalView();
    QString Album2Open;
    void reloadA();
    void Slide();
    QString 	filepath;
    QScrollView* vp;
    int zoomlv;
    QLibrary *runn[30];

public slots:
    virtual void fileNew();
    virtual void fileOpen();
    virtual void Exit();
    virtual void Vflip();
    virtual void Hflip();
    virtual void Rotate();
    virtual void ZoomIn();
    virtual void ZoomOut();
    virtual void viewAlbum(QListViewItem *);
    virtual void EditA();
    virtual void Convert();
    virtual void fullScreen();
    virtual void importA();
    virtual void ShowSlide();
    virtual void swap();
    virtual bool nextFile();
    virtual void prevFile();
    virtual void timerDone();
    virtual void timerDone2();
    virtual void screenFullShow();
    virtual void ShowEdit();
    virtual void editProp();
    virtual void upFile();
    virtual void downFile();
    virtual void saveFileIndex();
    virtual void XportA();
    virtual void LoadPlugIn();
    virtual void About();



protected:
    QVBoxLayout* Layout1;
    QVBoxLayout* Layout2;
    QVBoxLayout* Layout3;
    QHBoxLayout* CntrolLayout;

};

#endif // MAAFORM_H

