#include "Maa.h"
#include <qpe/qpeapplication.h>

int main( int argc, char **argv )
{
    QPEApplication a( argc, argv );


    MaaForm qpp;
    a.showMainDocumentWidget(&qpp);
    a.exec();
}
