/****************************************************************************
** Form implementation generated from reading ui file 'MoveTo.ui'
**
** Created: Sat Dec 21 01:30:56 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "MoveTo.h"
#include "OpenPath.h"

#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a MoveToForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
MoveToForm::MoveToForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "MoveToForm" );
    resize( 236, 98 ); 
    setCaption( tr( "Move To" ) );

    checkMove = '0' ;//0 = no 1 = ok
    QWidget* privateLayoutWidget = new QWidget( this, "ButtonLayout" );
    privateLayoutWidget->setGeometry( QRect( 35, 60, 168, 28 ) );
    ButtonLayout = new QHBoxLayout( privateLayoutWidget ); 
    ButtonLayout->setSpacing( 6 );
    ButtonLayout->setMargin( 0 );

    MoveOK = new QPushButton( privateLayoutWidget, "MoveOK" );
    MoveOK->setText( tr( "OK" ) );
    ButtonLayout->addWidget( MoveOK );
    connect(MoveOK, SIGNAL(clicked()), this, SLOT(MoveYes()));

    MoveCancel = new QPushButton( privateLayoutWidget, "MoveCancel" );
    MoveCancel->setText( tr( "Cancel" ) );
    ButtonLayout->addWidget( MoveCancel );
    connect( MoveCancel, SIGNAL(clicked()), this, SLOT(MoveNo()));

    QWidget* privateLayoutWidget_2 = new QWidget( this, "PathLayout" );
    privateLayoutWidget_2->setGeometry( QRect( 10, 25, 215, 24 ) ); 
    PathLayout = new QHBoxLayout( privateLayoutWidget_2 ); 
    PathLayout->setSpacing( 6 );
    PathLayout->setMargin( 0 );

    MovePath = new QLineEdit( privateLayoutWidget_2, "MovePath" );
    PathLayout->addWidget( MovePath );

    Search = new QToolButton( privateLayoutWidget_2, "Search" );
    Search->setText( tr( "..." ) );
    PathLayout->addWidget( Search );
    connect(Search, SIGNAL(clicked()), this, SLOT(searchPath()));

    Move2 = new QLabel( this, "Move2" );
    Move2->setGeometry( QRect( 15, 5, 53, 13 ) ); 
    Move2->setFrameShape( QLabel::MShape );
    Move2->setFrameShadow( QLabel::MShadow );
    Move2->setText( tr( "Move to :" ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
MoveToForm::~MoveToForm()
{
    // no need to delete child widgets, Qt does it all for us
}
void MoveToForm::searchPath()
{
    OpenPathForm* openPath = new OpenPathForm(this, NULL, true, true);
    openPath->exec();
    LinePath = openPath->Path2Sent;
    MovePath->setText(LinePath);
    QString pathCheck = LinePath.right(2);
    int pathL = LinePath.length();
    if (pathCheck == "..")
    {LinePath.replace( pathL-2, 2, "" );
     MovePath->setText(LinePath);
    }
    else {
     LinePath = LinePath + "/";
     MovePath->setText(LinePath);
    }
}
void MoveToForm::MoveYes()
{
    checkMove = '1';//Copy ok!
    this->close();
}
void MoveToForm::MoveNo()
{
    this->close();//don't copy -> checkCopy = 0
}
