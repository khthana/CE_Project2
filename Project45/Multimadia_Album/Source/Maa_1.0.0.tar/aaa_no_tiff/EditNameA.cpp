/****************************************************************************
** Form implementation generated from reading ui file 'EditProp.ui'
**
** Created: Sun Feb 16 22:22:05 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "EditNameA.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a EditForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
EditForm::EditForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "EditForm" );
    resize( 204, 96 ); 
    setCaption( tr( "Form1" ) );
    
    timer = new QTimer(this );
    connect( timer, SIGNAL(timeout()), this, SLOT(genProp()) );

    RowID = new QLabel( this, "RowID" );
    RowID->setGeometry( QRect( 10, 5, 60, 16 ) ); 
    RowID->setText( tr( "Album ID :" ) );

    NameLineEdit = new QLineEdit( this, "NameLineEdit" );
    NameLineEdit->setGeometry( QRect( 5, 50, 195, 22 ) );
    NameLineEdit->setMaxLength( 100 );

    NameLabel = new QLabel( this, "Name" );
    NameLabel->setGeometry( QRect( 10, 30, 35, 16 ) );
    NameLabel->setText( tr( "Name" ) );

    IDLabel = new QLabel( this, "IDLabel" );
    IDLabel->setGeometry( QRect( 70, 5, 100, 16 ) );
    IDLabel->setText( tr( "" ) );

    timer->start( 10,true );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
EditForm::~EditForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void EditForm::genProp()
{
    IDLabel->setText( AlbumID );
    NameLineEdit->setText(Name);
}

