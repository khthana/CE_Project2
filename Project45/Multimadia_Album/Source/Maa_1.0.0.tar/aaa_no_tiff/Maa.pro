TEMPLATE	= app
#CONFIG		= qt warn_on debug
CONFIG		= qt warn_on release
HEADERS		= Maa.h EditAlbum.h FileConvert.h NewAlbum.h  SearchAlbum.h OpenAlbum.h EditProp.h newXport.h EditNameA.h xportvia.h about.h
SOURCES		= main.cpp Maa.cpp EditAlbum.cpp FileConvert.cpp NewAlbum.cpp SearchAlbum.cpp OpenAlbum.cpp EditProp.cpp newXport.cpp EditNameA.cpp xportvia.cpp about.cpp
INCLUDEPATH	+= $(QPEDIR)/include
DEPENDPATH	+= $(QPEDIR)/include
LIBS            += -lqpe -lsqlite
TARGET		= Maa

