/****************************************************************************
** Form implementation generated from reading ui file 'newXport.ui'
**
** Created: Sat Feb 8 21:51:41 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "newXport.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qmessagebox.h>

/* 
 *  Constructs a XportForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
XportForm::XportForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "XportForm" );
    resize( 205, 91 ); 
    setCaption( tr( "Name for Export" ) );
    
    ok = 0;

    OKButton = new QPushButton( this, "OKButton" );
    OKButton->setGeometry( QRect( 25, 55, 75, 28 ) );
    OKButton->setText( tr( "OK" ) );
    connect(OKButton, SIGNAL(clicked()), this, SLOT(oknew()));

    CancelButton = new QPushButton( this, "CancelButton" );
    CancelButton->setGeometry( QRect( 110, 55, 75, 28 ) );
    CancelButton->setText( tr( "Cancel" ) );
    connect(CancelButton, SIGNAL(clicked()), this, SLOT(reject()));

    Name = new QLabel( this, "Name" );
    Name->setGeometry( QRect( 5, 0, 55, 16 ) );
    Name->setText( tr( "Name" ) );

    NameLine = new QLineEdit( this, "NameLine" );
    NameLine->setGeometry( QRect( 5, 20, 195, 22 ) ); 
    NameLine->setMaxLength( 100 );
    NameLine->setText("");

}

/*  
 *  Destroys the object and frees any allocated resources
 */
XportForm::~XportForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void XportForm::oknew()
{
    NameX = NameLine->text();
    if (NameX == "")
       QMessageBox::information( this, "Multimedia Album",
                            "Please insert the Name to create a Description file for yuor export files.");
    else
    {
       ok = 1;
       this->accept();
    }
}

