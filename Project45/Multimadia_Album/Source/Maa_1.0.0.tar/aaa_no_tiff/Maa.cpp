/****************************************************************************
** Form implementation generated from reading ui file 'Maa.ui'
**
** Created: Sat Dec 14 09:02:17 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "Maa.h"
#include "EditAlbum.h"
#include "FileConvert.h"
#include "CopyTo.h"
#include "MoveTo.h"
#include "NewAlbum.h"
#include "SlideShow.h"
#include "SearchAlbum.h"
#include "OpenAlbum.h"
#include "sqlite.h"
#include "EditProp.h"
#include "xportvia.h"
#include "about.h"

#include <qscrollbar.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qslider.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qstring.h>
#include <qlabel.h>
#include <qaction.h>
#include <qpe/qpemenubar.h>
#include <qpe/qpetoolbar.h>
#include <qstringlist.h>
#include <qfileinfo.h>
#include <qdialog.h>
#include <qtextstream.h>
#include <qwidgetstack.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qwidget.h>
#include <qpainter.h>
#include <qmessagebox.h>
#include <qdir.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qstringlist.h>
#include <qfileinfo.h>
#include <qdialog.h>
#include <qpe/qpeapplication.h>
#include <qpe/qlibrary.h>
#include <qpe/resource.h>
#include <qpe/config.h>
#include <qpe/applnk.h>
#include <qpe/qcopenvelope_qws.h>

#include <qmainwindow.h>
#include <qmessagebox.h>
#include <qwidgetstack.h>
#include <qfile.h>
#include <qpalette.h>

static const char* const image0_data[] = {
"14 14 19 1",
"a c None",
". c None",
"# c #000000",
"n c #9c999c",
"p c #a4a1a4",
"m c #b4aeb4",
"j c #b4b2b4",
"k c #b4b6b4",
"q c #bdb6bd",
"o c #c5c2c5",
"i c #cdcacd",
"l c #d5d6d5",
"e c #ded6de",
"f c #dedade",
"g c #dedede",
"d c #e6e2e6",
"c c #f6f6f6",
"h c #fff6ff",
"b c #ffffff",
"....#####aa...",
"....#bbb#aa...",
"....#bbc##a...",
"....#bbd##a...",
"....#bbe##a...",
"....#bbf##a...",
"....#bbg##a...",
"..###bbf###aa.",
"..#bbbhijk#aa.",
"..a#bblmn##aa.",
"..aa#dop###aa.",
"...aa#q###aa..",
"....aa###aa...",
".....aaaaa...."};

static const char* const image1_data[] = { 
"14 14 19 1",
"a c None",
". c None",
"# c #000000",
"q c #b4b2b4",
"n c #b4b6b4",
"f c #bdb6bd",
"e c #bdbabd",
"j c #bdbebd",
"k c #c5bec5",
"h c #c5c2c5",
"p c #cdcacd",
"d c #dedade",
"m c #eeeaee",
"o c #eeeeee",
"i c #f6f2f6",
"g c #f6f6f6",
"l c #fff6ff",
"c c #fffaff",
"b c #ffffff",
"......#aa.....",
".....#b#aa....",
"....#bbb#aa...",
"...#bbbcd#aa..",
"..#bbbbdef#aa.",
"..###bgh###aa.",
"..aa#bij###aa.",
"..aa#bik##aaa.",
"....#blh##a...",
"....#bmj##a...",
"....#bdn##a...",
"....#opq##a...",
"....######a...",
"....aa###aa..."};

static const char* const image2_data[] = {
"14 14 121 2",
".i c None",
".F c #000000",
"#. c #181c10",
".X c #313020",
"#i c #313031",
"#R c #313418",
"#F c #413c39",
"#S c #414041",
".C c #414429",
"#0 c #414441",
"#Z c #414c18",
"#K c #4a5518",
"#G c #525052",
".U c #525520",
"#r c #525918",
".N c #525920",
"#Q c #525929",
".7 c #525d08",
"#E c #525d18",
"#j c #5a6120",
".r c #5a6131",
"#d c #5a6141",
"## c #5a6518",
"#H c #62616a",
".2 c #626552",
".Y c #626d20",
".O c #627118",
"#n c #6a695a",
".M c #6a6d73",
".3 c #6a7152",
"#u c #6a7520",
".J c #6a7531",
"#P c #6a7920",
".o c #6a7939",
"#k c #737573",
".E c #737920",
".u c #737d18",
"#v c #7b757b",
".h c #7b8520",
"#f c #7b8908",
".g c #7b8918",
"#A c #7b8929",
".e c #7b8d31",
".y c #838541",
"#g c #83857b",
".f c #838d29",
".c c #838d41",
"#Y c #839110",
".d c #839139",
".Z c #83914a",
".K c #8b8d8b",
".b c #8b914a",
".a c #8b9152",
".# c #8b915a",
"Qt c #8b955a",
".D c #8b9918",
"#X c #8ba100",
"#o c #948d8b",
".p c #94918b",
".q c #949594",
"#e c #94a110",
"#O c #94a118",
"#a c #94a14a",
".s c #94aa10",
".z c #9c999c",
"#q c #9c99a4",
".9 c #9c9da4",
"#W c #9cb608",
"#y c #a49da4",
".W c #a4a1ac",
"#T c #a4a5ac",
".4 c #a4b639",
".P c #a4b65a",
"#N c #a4ba08",
"#D c #a4ba10",
"#V c #a4be00",
"#b c #aca5ac",
".B c #acaeb4",
".T c #acbe20",
".t c #acc208",
"#1 c #b4b2bd",
".Q c #b4c25a",
"#M c #b4ce00",
".6 c #b4d200",
"#C c #b4d208",
"#h c #bdb6c5",
"#m c #bdbac5",
"#L c #bdd200",
".5 c #bdd220",
".I c #bdd24a",
".V c #c5becd",
"#x c #c5c2d5",
"#w c #c5c6cd",
".1 c #c5d25a",
"#t c #c5d629",
".S c #c5d639",
".n c #c5d662",
"#B c #c5da20",
"#s c #c5da31",
".8 c #cdc6cd",
"#c c #cdc6d5",
"#z c #cdcad5",
".x c #cdda62",
".R c #cdde4a",
".H c #cde25a",
".G c #cde262",
"#p c #d5d6de",
".0 c #d5e26a",
".m c #d5e273",
".w c #d5e673",
".k c #d5e67b",
".L c #dedae6",
"#2 c #dedeee",
".l c #dee67b",
".j c #dee683",
".v c #deea83",
"#l c #e6e2ee",
"#I c #e6e6ee",
".A c #eee6f6",
"#J c #f6eef6",
"#U c #f6f6ff",
"Qt.#Qt.#Qt.a.b.c.d.e.f.g.h.i",
".#.j.k.l.m.n.o.p.q.r.s.t.u.i",
"Qt.k.v.k.w.x.y.z.A.B.C.D.E.F",
".a.l.w.w.G.H.I.J.K.L.M.N.O.F",
"Qt.w.w.P.Q.R.S.T.U.V.W.X.Y.F",
".Z.0.1.2.3.4.5.6.7.8.9#.##.F",
".b.H#a#b#c#d#e#f#g.L#h#i#j.F",
".c.R.4#k#l#m#n#o#p#m.B#q#r.F",
".d#s#t#u#v#w.L#l#x#y#z#z.N.F",
"#A#B#C#D#E#F#G#H.9.V#I#J#K.F",
".f#L#M#N#O#P#Q#R#S#T.L#U.U.F",
".g#M#V#W#X#Y.u#u#Z#0#1#2#K.F",
".h.u.E.O.Y###j#E.N#K.U#K.N.F",
".i.i.F.F.F.F.F.F.F.F.F.F.F.i"};

static const char* const image3_data[] = {
"16 16 5 1",
". c None",
"# c #000000",
"c c #c5c200",
"a c #ffffc5",
"b c #ffffff",
"......##........",
"......#a###.....",
".....#ababa###..",
".....#bcbbbaba##",
"....#abbcccbaba#",
"....#abbbabccaa#",
"...#abcbababaaa#",
"...#babcccbabac#",
"..#babababccaa#.",
".#aacaaabaaaaa#.",
"#aaaacccababaa#.",
"#caaaaaacccaac#.",
".##caaaaaaaaa#..",
"...###caaaaac#..",
"......###cac#...",
".........###...."};

static const char* const image4_data[] = {
"14 14 98 2",
"#F c None",
"#v c None",
"#C c None",
"#D c None",
"#n c None",
"#A c None",
".f c None",
".A c None",
".# c None",
".g c None",
"Qt c None",
"#E c #004800",
"#B c #004c00",
"#u c #005000",
"#z c #005500",
"#h c #005900",
"#a c #005d00",
"#g c #006100",
".3 c #006500",
"## c #006900",
"#m c #006d00",
"#w c #007100",
"#o c #007500",
"#f c #007900",
"#l c #008100",
"#i c #107110",
"#j c #107910",
"#p c #108110",
".Y c #18ae18",
"#b c #206120",
".4 c #295929",
".P c #29b629",
".U c #316931",
".p c #319131",
".Z c #31b231",
".o c #398939",
".x c #399939",
".O c #39b639",
".c c #416141",
".d c #416d41",
".n c #418941",
".w c #41a541",
".G c #41b641",
".b c #4a714a",
".e c #4a814a",
".V c #4a8d4a",
".H c #4ab24a",
".F c #4aba4a",
".M c #528552",
".m c #529152",
".l c #529552",
".v c #52ae52",
".E c #52be52",
".T c #5a955a",
".a c #628d62",
".2 c #629162",
".j c #629562",
".k c #629962",
".u c #62b662",
".D c #62be62",
".i c #6a9d6a",
".q c #6aa56a",
".B c #6aaa6a",
".N c #6ab26a",
".r c #73a573",
".h c #73aa73",
".s c #73ae73",
".t c #73b673",
".C c #73ba73",
".5 c #7b997b",
"#y c #7ba57b",
"#. c #7bae7b",
".L c #83ae83",
"#t c #83b683",
"#e c #83ba83",
"#c c #8b9d8b",
".z c #94b294",
".y c #9caa9c",
"#x c #9cb69c",
".W c #9cc29c",
"#k c #a4bea4",
".K c #acaaac",
"#q c #acc2ac",
".J c #bdbabd",
".I c #bdcabd",
".X c #c5d6c5",
".7 c #c5dac5",
".S c #cdcacd",
".1 c #cdcecd",
".6 c #d5d2d5",
".Q c #d5ded5",
".8 c #d5e2d5",
".R c #dedade",
"#s c #dedede",
"#r c #e6dee6",
".0 c #e6e2e6",
"#d c #e6e6e6",
".9 c #eee6ee",
"QtQtQt.#.a.b.c.d.e.fQtQtQtQt",
"Qt.g.h.i.j.k.l.m.n.o.p.gQtQt",
"Qt.q.r.s.t.u.u.v.w.x.y.zQtQt",
".A.k.B.C.D.E.F.G.H.I.J.K.LQt",
".M.m.N.D.E.O.P.G.Q.R.S.K.TQt",
".U.V.W.X.O.Y.Z.Q.0.0.1.2.3Qt",
".4.5.6.0.7.G.8.0.9.0#.###aQt",
"#b#c.1.0.0.0.0#d.0#e#f#g#hQt",
"#i#j#k.R.0.0.9.0#e#l#m#h#hQt",
"#n#o#p#q.R#r#s#t#f#m#a#u#vQt",
"Qt#f#w#j#x#x#y#w###h#u#zQtQt",
"Qt#A#w.3#a#g#h#z#B#B#u#CQtQt",
"QtQtQt#D#g#u#B#E#B#FQtQtQtQt",
"QtQtQtQtQtQtQtQtQtQtQtQtQtQt"};
/*
*  Constructs a MaaForm which is a child of 'parent', with the
*  name 'name' and widget flags set to 'f'
*/
MaaForm::MaaForm( QWidget* parent,  const char* name, WFlags fl )
    : QWidget( parent, name, fl ),
    conversion_flags( PreferDither )
{
    QPixmap image0( ( const char** ) image0_data );
    QPixmap image1( ( const char** ) image1_data );
    QPixmap image2( ( const char** ) image2_data );
    QPixmap image3( ( const char** ) image3_data );
    QPixmap image4( ( const char** ) image4_data );

    if ( !name )
        setName( "MaaForm" );
    setEnabled( TRUE );
    resize( 237, 310 );

    Album2Open = "0";
    isFullScreen = FALSE;
    isSlide = FALSE;

////Check Plugin Folder in /root/Documents
    int checkDIR = 0;
    QDir dirOnS( "/root/Documents" );
    const QFileInfoList * fileList2Make = dirOnS.entryInfoList();
    QFileInfoListIterator itt2Make( *fileList2Make);
    QFileInfo *FileInfo2Make;
    while( (FileInfo2Make=itt2Make.current()) != 0)
    {
      ++itt2Make;
      if (FileInfo2Make->fileName()==".." || FileInfo2Make->fileName()==".")
        ;
      else if (FileInfo2Make->isDir())
      {
        if (FileInfo2Make->fileName() == "Plugins")
	   checkDIR = 1;
      }
      else
        ;
    }
    if (checkDIR == 0)
    {
      QDir PluginPath("/root/Documents");
      PluginPath.mkdir("Plugins");
    }

/////////////
//// Load Plugin QLibrary
    typedef void (*foofunction)();
    foofunction foo;
    int PI = 0;
    QDir PluginLoad("/root/Documents/Plugins");
    const QFileInfoList * fileListPlugin = PluginLoad.entryInfoList();
    QFileInfoListIterator ittPlugin( *fileListPlugin);
    QFileInfo *FileInfoPlugin;
    while( (FileInfoPlugin=ittPlugin.current()) != 0)
    {
      ++ittPlugin;
      if (FileInfoPlugin->fileName()==".." || FileInfoPlugin->fileName()==".")
        ;
      else if (FileInfoPlugin->isDir())
        ;
      else
      {
        if ((FileInfoPlugin->extension(FALSE)).lower() == "so")
	{
	   runn[PI] = new QLibrary(FileInfoPlugin->filePath(),QLibrary::Immediately);
           foo = (foofunction) runn[PI]->resolve("Init");
           if (foo)
             foo();
           else
             qWarning("Failed");
	   PI++;
	}
      }
    }



 ////End Load Plugin




    zErrMsg = 0;
    db = sqlite_open("MaaDB.db", 0, &zErrMsg);
    if( db==0 ){
      //fprintf(stderr, "Can't open database: %s\n", zErrMsg);
      return;
    }
    rc = sqlite_exec(db, "create table FILEDB (FileID integer auto_increment primary key, FilePath varchar (100));", callback, 0, &zErrMsg);
    rc = sqlite_exec(db, "create table ALBUMDB (AlbumID integer auto_increment primary key, AlbumName varchar (50));", callback, 0, &zErrMsg);
    rc = sqlite_exec(db, "create table LINKDB (AlbumID integer not null, FileID integer not null, Name varchar(100), Description varchar(200), FIndex integer);", callback, 0, &zErrMsg);
    rc = sqlite_exec(db, "create table Xport (Name varchar(100), Description varchar(200), FilePath varchar(200));", callback, 0, &zErrMsg);
    setCaption( tr( "Multimedia Album" ) );
    pickx = -1;
    picky = -1;
    clickx = -1;
    clicky = -1;
    alloc_context = 0;
    AandF='1';
    AlbumName="";

    optional1 = new QWidgetStack(this);
    optional1->setGeometry( QRect( 209, 209, 30, 69 ) );
    timer = new QTimer(this );
    connect( timer, SIGNAL(timeout()), this, SLOT(timerDone()) );
    timer2 = new QTimer(this );
    connect( timer2, SIGNAL(timeout()), this, SLOT(timerDone2()) );

    mb = new QPEMenuBar( this );
    QPopupMenu *mnFile = new QPopupMenu( this );
    QPopupMenu *mnEdit = new QPopupMenu( this );
    QPopupMenu *mnImage = new QPopupMenu( this );
    QPopupMenu *mnAlbum = new QPopupMenu( this );
    QPopupMenu *mnPlugIn = new QPopupMenu( this );
    QPopupMenu *mnAbout = new QPopupMenu( this );

    QAction *a = new QAction( tr( "Exit" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( Exit() ) );
    a->addTo( mnFile );

    //a = new QAction( tr( "Import File" ), QString::null, 0, this, 0 );
    //connect( a, SIGNAL( activated() ), this, SLOT( importFile() ) );
    //a->addTo( mnEdit );

    a = new QAction( tr( "Import Album" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( importA() ) );
    a->addTo( mnEdit );

    a = new QAction( tr( "Export Album" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( XportA() ) );
    a->addTo( mnEdit );

    a = new QAction( tr( "Full Screen" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( fullScreen() ) );
    a->addTo( mnImage );


    a = new QAction( tr( "Make Slide Show" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( ShowSlide() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "Vertical Flip" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( Vflip() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "Horizontal Flip" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( Hflip() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "Rotate" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( Rotate() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "Zoom In" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( ZoomIn() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "Zoom Out" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( ZoomOut() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "Convert Image Format" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( Convert() ) );
    a->addTo( mnImage );

    a = new QAction( tr( "New" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( fileNew() ) );
    a->addTo( mnAlbum );

    a = new QAction( tr( "Edit" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( EditA() ) );
    a->addTo( mnAlbum );

    a = new QAction( tr( "Open.." ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( fileOpen() ) );
    a->addTo( mnAlbum );

    a = new QAction( tr( "Load Plugin" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( LoadPlugIn() ) );
    a->addTo( mnPlugIn );

    a = new QAction( tr( "About" ), QString::null, 0, this, 0 );
    connect( a, SIGNAL( activated() ), this, SLOT( About() ) );
    a->addTo( mnAbout );

    //ChangeListButton = new QToolButton( this, "ChangeListButton" );
    //ChangeListButton->setText( tr( "A/F" ) );
    //ChangeListButton->setGeometry( QRect( 209, 180, 30, 21 ) );

    List4import = new QListView( this, "List4import" );
    List4import->addColumn( tr( "Name" ) );
    List4import->setGeometry( QRect( 0, 181, 10,10));

    List4maa = new QListView( this, "AlbumIndex" );
    List4maa->addColumn( tr( "Name" ) );
    List4maa->addColumn( tr( "Des" ) );
    List4maa->addColumn( tr( "FileID" ) );
    List4maa->setGeometry( QRect( 0, 181, 20, 10 ) );

    EditAButton = new QToolButton( this, "EditAButton" );
    EditAButton->setText( tr( "EDIT" ) );
    EditAButton->setPixmap( image2 );
    EditAButton->setToggleButton( TRUE );
    EditAButton->setEnabled( FALSE );
    EditAButton->setGeometry( QRect( 209, 185, 30, 21 ) );
    connect( EditAButton, SIGNAL(clicked()), this, SLOT(ShowEdit()));

    Layout1st = new QGroupBox( this, "Layout1st" );
    Layout1st->setGeometry( QRect( 209, 209, 30, 69 ) );
    Layout1st->setLineWidth( 0 );
    Layout1st->setTitle( tr( "" ) );

    NextButton = new QToolButton( Layout1st, "Nextbutton" );
    NextButton->setText( tr(  "" ) );
    NextButton->setPixmap( image0 );
    NextButton->setEnabled( FALSE );
    NextButton->setGeometry( QRect( 0, 24, 30, 21 ) );
    connect( NextButton, SIGNAL(clicked()), this, SLOT(nextFile()));

    BackButton = new QToolButton( Layout1st, "BackButton" );
    BackButton->setText( tr( "" ) );
    BackButton->setPixmap( image1 );
    BackButton->setEnabled( FALSE );
    BackButton->setGeometry( QRect( 0, 0, 30, 21 ) );
    connect( BackButton, SIGNAL(clicked()), this, SLOT(prevFile()));

    PropButton = new QToolButton( Layout1st, "PropButton" );
    PropButton->setText( tr(  "" ) );
    PropButton->setPixmap( image3 );
    PropButton->setEnabled( FALSE );
    PropButton->setGeometry( QRect( 0, 48, 30, 21 ) );
    connect( PropButton, SIGNAL(clicked()), this, SLOT(editProp()));

    Layout2nd = new QGroupBox( this, "Layout2nd" );
    Layout2nd->setGeometry( QRect( 209, 209, 30, 69 ) );
    Layout2nd->setLineWidth( 0 );
    Layout2nd->setTitle( tr( "" ) );

    SaveButton = new QToolButton( Layout2nd, "SaveButton" );
    SaveButton->setText( tr( "" ) );
    SaveButton->setPixmap( image4 );
    SaveButton->setGeometry( QRect( 0, 0, 30, 21 ) );
    connect( SaveButton, SIGNAL(clicked()), this, SLOT(saveFileIndex()));

    UpButton = new QToolButton( Layout2nd, "UpButton" );
    UpButton->setText( tr( "" ) );
    UpButton->setPixmap( image1 );
    UpButton->setGeometry( QRect( 0, 24, 30, 21 ) );
    connect( UpButton, SIGNAL(clicked()), this, SLOT(upFile()));

    DownButton = new QToolButton( Layout2nd, "DownButton" );
    DownButton->setText( tr(  "" ) );
    DownButton->setPixmap( image0 );
    DownButton->setGeometry( QRect( 0, 48, 30, 21 ) );
    connect( DownButton, SIGNAL(clicked()), this, SLOT(downFile()));

    AlbumIndex = new QListView( this, "AlbumIndex" );
    AlbumIndex->addColumn( tr( "InDeX" ) );
    AlbumIndex->addColumn( tr( "FileID" ) );
    AlbumIndex->setGeometry( QRect( 0, 181, 205, 104 ) );

    optionals = new QWidgetStack(this);
    optionals->setGeometry( QRect( 0, 181, 205, 104 ) );

    FileListView = new QListView( optionals, "FileListView" );
    FileListView->addColumn( tr( "Index" ) );
    FileListView->addColumn( tr( "File Name") );
    FileListView->addColumn( tr( "File Description") );
    FileListView->setGeometry( QRect( 0, 181, 205, 104 ) );
    FileListView->setSorting(0);
    connect( FileListView, SIGNAL( clicked(QListViewItem*)), this, SLOT( viewAlbum(QListViewItem*)));

    AlbumListView = new QListView( optionals, "AlbumListView" );
    AlbumListView->addColumn( tr( "Index" ) );
    AlbumListView->addColumn( tr( "File Name" ) );
    AlbumListView->addColumn( tr( "File Description" ) );
    AlbumListView->setGeometry( QRect( 0, 181, 205, 104 ) );

    optionals->addWidget(FileListView,0);
    optionals->addWidget(AlbumListView,1);
    optionals->raiseWidget(1);

    optional1->addWidget(Layout1st,0);
    optional1->addWidget(Layout2nd,1);
    optional1->raiseWidget(0);

    //FrameShow = new QWidget( this, "FrameShow" );
    //FrameShow->setGeometry( QRect(0, 0, 240, 170) );
    //connect( FrameShow, SIGNAL( �clicked()�), this, SLOT( normalView()));
    vp = new QScrollView(this);
    vp->setGeometry( QRect(0, 25, 240, 155) );
    FrameShow = new QFrame(0);//(vp->viewport());
    FrameShow->setGeometry( QRect(0, 0, 0, 0) );
    vp->addChild(FrameShow);
    FrameShow->setAcceptDrops(TRUE);

    mb->insertItem( tr( "File" ), mnFile );
    mb->insertItem( tr( "Edit" ), mnEdit );
    mb->insertItem( tr( "Image" ), mnImage );
    mb->insertItem( tr( "Album" ), mnAlbum );
    mb->insertItem( tr( "Plug-in" ), mnPlugIn );
    mb->insertItem( tr( "Help" ), mnAbout );
	zoomlv=4;

    connect( vp->horizontalScrollBar(), SIGNAL( sliderPressed()), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( sliderPressed()), this, SLOT( timerDone()));
    connect( vp->horizontalScrollBar(), SIGNAL( sliderReleased()), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( sliderReleased()), this, SLOT( timerDone()));
    connect( vp->horizontalScrollBar(), SIGNAL( sliderMoved(int)), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( sliderMoved(int)), this, SLOT( timerDone()));
    //connect( vp->horizontalScrollBar(), SIGNAL( valueChanged()), this, SLOT( timerDone()));
    //connect( vp->verticalScrollBar(), SIGNAL( valueChanged()), this, SLOT( timerDone()));
    connect( vp->horizontalScrollBar(), SIGNAL( nextPage()), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( nextPage()), this, SLOT( timerDone()));
    connect( vp->horizontalScrollBar(), SIGNAL( prevPage()), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( prevPage()), this, SLOT( timerDone()));
    connect( vp->horizontalScrollBar(), SIGNAL( nextLine()), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( nextLine()), this, SLOT( timerDone()));
    connect( vp->horizontalScrollBar(), SIGNAL( prevLine()), this, SLOT( timerDone()));
    connect( vp->verticalScrollBar(), SIGNAL( prevLine()), this, SLOT( timerDone()));

}

/*
*  Destroys the object and frees any allocated resources
*/
MaaForm::~MaaForm()
{
    // no need to delete child widgets, Qt does it all for us
    if(isFullScreen)
    delete FrameShow;
}




void MaaForm::viewAlbum(QListViewItem *item)
{
     if (item == NULL) return;
     QString getPath = item->text(0);
     bool ok;
     int temp = getPath.toInt(&ok,10);
     //getPath = getPath.number(temp);
     QListViewItemIterator it(AlbumIndex);
     for (; it.current(); ++it)
     {
       int idp = (it.current()->text(0)).toInt(&ok,10);
       if (temp == idp)
          getPath = it.current()->text(1);
     }
     //setCaption(getPath);
     openFile(getPath);
}

void MaaForm::fileNew()
{
   NewAlbumForm* na = new NewAlbumForm(this, NULL, true, true);
   na->db = db;
   na->exec();
   timer->start( 10, TRUE );
}
void MaaForm::fileOpen()
{
   OpenAlbumForm* OA = new OpenAlbumForm(this, NULL, true, true);
   OA->db = db;
   OA->exec();
   Album2Open = OA->AlbumName;
   if (Album2Open == "0") return;
   setCaption("Album Name : " + OA->NameAlbum);
   bool ok;
   int temp = Album2Open.toInt(&ok,10);
   Album2Open = Album2Open.number(temp);
   PropButton->setEnabled( TRUE );
   EditAButton->setEnabled( TRUE );
   NextButton->setEnabled( TRUE );
   BackButton->setEnabled( TRUE );
   loadA();
   FrameShow->erase();
   vp->setHScrollBarMode(QScrollView::AlwaysOff);
   vp->setVScrollBarMode(QScrollView::AlwaysOff);
   //timer->start( 10,true );

}
void MaaForm::Exit()
{
   sqlite_close(db);
   this->close();
}
void MaaForm::Vflip()
{
   setImage(image.mirror(FALSE,TRUE));
   timer->start( 10, TRUE );
}
void MaaForm::Hflip()
{
   setImage(image.mirror(TRUE,FALSE));
   timer->start( 10, TRUE );
}
void MaaForm::Rotate()
{
   setImage(image.mirror(TRUE,TRUE));
   timer->start( 10, TRUE );
}


void MaaForm::ZoomIn()
{	int scaledWidth;
    int scaledHeight;
    zoomlv = zoomlv+1;
    if(zoomlv<8)
    {
        scaledWidth = (pm.width() * zoomlv)/4;
        scaledHeight = (pm.height() * zoomlv)/4;
        pmScaled.convertFromImage( image.smoothScale( scaledWidth, scaledHeight ) );

	resizeContents(scaledWidth, scaledHeight);
    }
    else
	zoomlv=7;
    timer->start( 10, TRUE );
        //isScaled = true;//tmp
}
void MaaForm::resizeContents(int w, int h)
{
    int ws = vp->verticalScrollBar()->width();
    int hs = vp->horizontalScrollBar()->height();
    if(h + hs < 170)
        vp->setHScrollBarMode(QScrollView::AlwaysOff);
    else
        vp->setHScrollBarMode(QScrollView::AlwaysOn);
    if(w + ws < 240)
        vp->setVScrollBarMode(QScrollView::AlwaysOff);
    else
        vp->setVScrollBarMode(QScrollView::AlwaysOn);
    vp->resizeContents(w, h);

}
void MaaForm::ZoomOut()
{	int scaledWidth;
    int scaledHeight;
    zoomlv = zoomlv-1;
    if(zoomlv>0)
    {
        scaledWidth = (pm.width() * zoomlv)/4;
        scaledHeight = (pm.height() * zoomlv)/4;
        pmScaled.convertFromImage( image.smoothScale( scaledWidth, scaledHeight ) );

	resizeContents(scaledWidth, scaledHeight);
    }
    else
	zoomlv=1;
    timer->start( 10, TRUE );
}
void MaaForm::Convert()
{
   FileConvertForm* fc = new FileConvertForm(this, NULL, true, true);
   fc->exec();
   int change = fc->SaveYes;
   if (change == 0) return;
   if(!image.load(ImageName,0)) return;
   else 
   {
      QString Type = fc->Type;
      if (Type == "1")
         Type = "gif";
      else if (Type == "2")
         Type = "xpm";
      else if (Type == "3")
         Type = "png";
      else if (Type == "4")
         Type = "jpg";
      else if (Type == "5")
         Type = "bmp";
      int rc;
      char **result = new char*;
      int *nrow = new int;
      int *ncolumn = new int;
      char **errmsg = new char*;
      const char *setText = ImageName.latin1();
      rc = sqlite_get_table_printf( db, "select FileID from FILEDB where FilePath = '%q';",&result,nrow,ncolumn,errmsg,setText);
      QString IDFile = result[1];
      QFileInfo fi2(ImageName);
      QString ext2 = fi2.extension(FALSE);
      ext2 = "."+ext2;
      int len = ext2.length();
      int NameL = ImageName.length();
      QString ImageNameBefore = ImageName;
      QString ImageNameAfter = ImageNameBefore.remove(NameL-len,len);
      ImageNameAfter = ImageNameAfter + "." + Type;
      QDir dir("/");
      bool ok = dir.rename(ImageName,ImageNameAfter);
      image.save(ImageNameAfter,(Type.upper()).latin1());
      //setCaption(IDFile + "___" + ImageNameAfter);
      setText = IDFile.latin1();
      const char *setText1 = ImageNameAfter.latin1();
      rc = sqlite_get_table_printf( db, "update FILEDB set FilePath = '%q' where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText1,setText);
      sqlite_free_table(result);
   }
   timer->start( 10, TRUE );
}

void MaaForm::EditA()
{
   EditAlbumForm* ea = new EditAlbumForm(this, NULL, true, true);
   ea->db = db;
   ea->exec();
   timer->start( 10, TRUE );
}
void MaaForm::importA() //temporary unused
{
   /*SearchAlbumForm* ImpF = new SearchAlbumForm(this, NULL, true, true);
   ImpF->exec();
   timer->start( 10, TRUE );
   QString Name2Sent;
   Name2Sent = ImpF->Name2Sent;
   int rc;
   char ***result = new char**;
   int *nrow = new int;
   int *ncolumn = new int;
   char **errmsg = new char*;
   if (Name2Sent != ""){
     const char *setText = Name2Sent.latin1();
     rc = sqlite_get_table_printf( db, "insert into FILEDB (FilePath) values ('%q');",result,nrow,ncolumn,errmsg,setText);}
*/
   List4import->clear();
   List4maa->clear();
   ImportAlbum( "/mnt/hda");
}
void MaaForm::ImportAlbum( const QString & pathNow ) //dirOnCF -> start = "/home/tmp"
{
   QDir dirOnCF( pathNow );
   QString Path2Save = "/root/Documents/";
   int found = 0;
   int Index = 1;
   int check2 = 0;
   QString IDAlbum;
   QString IDAlbum2;
   bool ok;
   int rc;
   char **result = new char*;
   int *nrow = new int;
   int *ncolumn = new int;
   char **errmsg = new char*;
   const QFileInfoList * fileListES = dirOnCF.entryInfoList();
   // Add more
     QFileInfoListIterator itt( *fileListES);
     QFileInfo *FileInfo;
   QString name2;
   QString MaaName;
   QString DirAdd;
    while( (FileInfo=itt.current()) != 0)
    {
      ++itt;
      name2 = FileInfo->filePath();
      if (FileInfo->fileName()==".." || FileInfo->fileName()==".")
        ;
      else if (FileInfo->isDir())
      {
        DirAdd = FileInfo->filePath();
        ImportAlbum( DirAdd );
      }
      else if(!FileInfo->isDir())
      {
        //QString nameAFTER = "/tmp/" + FileInfo->fileName();
        //copyFile(nameAFTER,name2);
        QListViewItem *item = new QListViewItem( List4import );
        item->setText(0,name2);
      }

    }
    if (pathNow != "/mnt/hda") return;
    //setCaption("xxxxxx");
    //setCaption(pathNow);
    QListViewItemIterator it(List4import);
    for (; it.current(); ++it)
    {
       QString CheckMaa = (it.current()->text(0)).right(4);
       if (CheckMaa.lower() == ".maa")
       {
          found = 1;
	  MaaName = it.current()->text(0);
	  //setCaption(MaaName);
	  List4import->removeItem(it.current());
       }
    }
   //setCaption(QString::number(found));
   if (found == 0)
   {
      QString IDFile0;
      rc = sqlite_get_table_printf( db, "select max(AlbumID) from ALBUMDB;",&result,nrow,ncolumn,errmsg);
      QString NewAID = result[1];
      int inttemp = NewAID.toInt(&ok,10);
      inttemp++;
      NewAID = NewAID.number(inttemp);
      const char *setText = NewAID.latin1();
      rc = sqlite_get_table_printf( db, "insert into ALBUMDB (AlbumName) values ('%q');",&result,nrow,ncolumn,errmsg,setText);
      rc = sqlite_get_table_printf( db, "select max(AlbumID) from ALBUMDB;",&result,nrow,ncolumn,errmsg);
      IDAlbum = result[1];
      QString name2;
      QListViewItemIterator it0(List4import);
      for (; it0.current(); ++it0)
      {
        name2 = it0.current()->text(0);
	rc = sqlite_get_table_printf( db, "select count(FileID) from FILEDB;",&result,nrow,ncolumn,errmsg);
	QString NameLast;
	bool ok;
	QString countID = result[1];
	int a = countID.toInt(&ok,10);
	//setCaption(countID);
	if (a == 0)
	{
	     QFileInfo fi(name2);
	     QString ext = fi.extension(FALSE);
	     NameLast = "1." + ext;
	}
	else if(a>0)
	{
	     rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = (select max(FileID) from FILEDB);",&result,nrow,ncolumn,errmsg);
	     QString FilePath = result[1];
	     QFileInfo fi2(FilePath);
	     NameLast = fi2.fileName();
	     QFileInfo fi3(name2);
	     QString ext2 = fi3.extension(FALSE);
	     ext2 = "."+ext2;
	     int len = ext2.length();
	     int NameL = NameLast.length();
	     NameLast = NameLast.remove(NameL-len,len);
	     int NameLastHex = NameLast.toInt(&ok,16);
	     NameLastHex++;
	     NameLast = NameLast.number(NameLastHex,16);
	     NameLast = NameLast + ext2;
	}
	  QString Namefile = NameLast;
	  NameLast = Path2Save + NameLast;
	  copyFile(NameLast,name2);
          const char* setText = NameLast.latin1();
          rc = sqlite_get_table_printf( db, "insert into FILEDB (FilePath) values ('%q');",&result,nrow,ncolumn,errmsg,setText);
	  rc = sqlite_get_table_printf( db, "select FileID from FILEDB where FilePath = '%q';",&result,nrow,ncolumn,errmsg,setText);
	  IDFile0 = result[1];
	  setText = IDAlbum.latin1();
	  QString IndexNo = IndexNo.number(Index);
	  const char* setText1 = IDFile0.latin1();
	  const char* setText2 = Namefile.latin1();
	  const char* setText3 = IndexNo.latin1();
	  rc = sqlite_get_table_printf( db, "insert into LINKDB values ('%q','%q','%q','-','%q');",&result,nrow,ncolumn,errmsg,setText,setText1,setText2,setText3);
	  Index++;
      }
   }
   else
   {
      QString NameLast;
      QString name1;
      //setCaption("enter maa found");
      rc = sqlite_get_table_printf( db, "select count(FileID) from FILEDB;",&result,nrow,ncolumn,errmsg);
      QString first = result[1];
      int is1 = first.toInt(&ok,10);
      //setCaption(QString::number(is1,10));
      rc = sqlite_get_table_printf( db, "select max(AlbumID) from ALBUMDB;",&result,nrow,ncolumn,errmsg);
      QString NewAID1 = result[1];
      int inttemp = NewAID1.toInt(&ok,10);
      inttemp++;
      NewAID1 = NewAID1.number(inttemp);
      const char *setText = NewAID1.latin1();
      rc = sqlite_get_table_printf( db, "insert into ALBUMDB (AlbumName) values ('%q');",&result,nrow,ncolumn,errmsg,setText);
      rc = sqlite_get_table_printf( db, "select max(AlbumID) from ALBUMDB;",&result,nrow,ncolumn,errmsg);
      IDAlbum = result[1];
      QString name2;
      QFile f1( MaaName );
      if ( !f1.open( IO_ReadOnly ) )
        return;
      QTextStream t1( &f1 );
      while ( !t1.eof() ) 
      {
        QString Check1 = t1.readLine();
        QListViewItem *item = new QListViewItem( List4maa );
        item->setText(0,Check1);
	Check1 = t1.readLine();
        item->setText(1,Check1);
	Check1 = t1.readLine();
        item->setText(2,Check1);
      }
      f1.close();
      //i=0;
      QListViewItemIterator it4maa(List4maa);
      for (; it4maa.current(); ++it4maa)
      {
            QString NameLast5;
	    QString NameinMaa = it4maa.current()->text(0);
	    QString DesinMaa = it4maa.current()->text(1);
	    QString File2DB = it4maa.current()->text(2);
	    //setCaption(File2DB);
	    QListViewItemIterator it4import(List4import);
            for (; it4import.current(); ++it4import)
            {
	      QFileInfo fiim(it4import.current()->text(0));
	      QString FO = fiim.fileName();
	      if (FO == File2DB)
	      {
	      //File2DB = Path2Save + File2DB;
	       if (is1 == 0)
	       {
	         QFileInfo fi(File2DB);
	         QString ext = fi.extension(FALSE);
	         NameLast5 = Path2Save + "1." + ext; //=   ->   /Path2Save/1.ert
	         is1++;

	       }
	       else if(is1 > 0)
	       {
	         rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = (select max(FileID) from FILEDB);",&result,nrow,ncolumn,errmsg);
	         QString FilePath = result[1];
	         QFileInfo fi2(FilePath);
	         NameLast5 = fi2.fileName();
	         QFileInfo fi3(File2DB);
	         QString ext2 = fi3.extension(FALSE);
	         ext2 = "."+ext2;
	         int len = ext2.length();
	         int NameL = NameLast5.length();
	         NameLast5 = NameLast5.remove(NameL-len,len);
	         int NameLastHex = NameLast5.toInt(&ok,16);
	         NameLastHex++;
	         NameLast5 = NameLast5.number(NameLastHex,16);
	         NameLast5 = Path2Save + NameLast5 + ext2;
	       }
	       //QDir dir("/");
	       //ok = dir.rename(File2DB,NameLast5);
	       copyFile(NameLast5,it4import.current()->text(0));
	       const char* setText = NameLast5.latin1();
	       rc = sqlite_get_table_printf( db, "insert into FILEDB (FilePath) values ('%q');",&result,nrow,ncolumn,errmsg,setText);
	       rc = sqlite_get_table_printf( db, "select FileID from FILEDB where FilePath = '%q';",&result,nrow,ncolumn,errmsg,setText);
	       QString IDFile = result[1];
	       setText = IDAlbum.latin1();
	       QString IndexNo = IndexNo.number(Index,10);
	       const char* setText1 = IDFile.latin1();
	       const char* setText2 = NameinMaa.latin1();
	       const char* setText3 = DesinMaa.latin1();
	       const char* setText4 = IndexNo.latin1();
	       rc = sqlite_get_table_printf( db, "insert into LINKDB values ('%q','%q','%q','%q','%q');",&result,nrow,ncolumn,errmsg,setText,setText1,setText2,setText3,setText4);
	    // i=i+3;
	       Index++;
	       List4import->removeItem(it4import.current());
	      }
            }
        }
	int nextID = IDAlbum.toInt(&ok,10);
	nextID++;
	Index = 1;
	IDAlbum2 = IDAlbum2.number(nextID,10);
	setText = IDAlbum2.latin1();
	QListViewItemIterator it4import1(List4import);
	if (it4import1.current()!=NULL)
	{
	rc = sqlite_get_table_printf( db, "insert into ALBUMDB (AlbumName) values ('%q');",&result,nrow,ncolumn,errmsg,setText);

        for (; it4import1.current(); ++it4import1)
	{
           name2 = it4import1.current()->text(0);
	   rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = (select max(FileID) from FILEDB);",&result,nrow,ncolumn,errmsg);
	   QString FilePath = result[1];
	   QFileInfo fi2(FilePath);
	   NameLast = fi2.fileName();
	   QFileInfo fi3(name2);
	   QString ext2 = fi3.extension(FALSE);
	   ext2 = "."+ext2;
	   int len = ext2.length();
	   int NameL = NameLast.length();
	   NameLast = NameLast.remove(NameL-len,len);
	   int NameLastHex = NameLast.toInt(&ok,16);
	   NameLastHex++;
	   NameLast = NameLast.number(NameLastHex,16);
	   NameLast = NameLast + ext2;
	   QString Namefile = NameLast;
	   NameLast = Path2Save + NameLast;
	   copyFile(NameLast,name2);
           const char* setText = NameLast.latin1();
           rc = sqlite_get_table_printf( db, "insert into FILEDB (FilePath) values ('%q');",&result,nrow,ncolumn,errmsg,setText);
	   rc = sqlite_get_table_printf( db, "select FileID from FILEDB where FilePath = '%q';",&result,nrow,ncolumn,errmsg,setText);
	   QString IDFile0 = result[1];
	   setText = IDAlbum2.latin1();
	   QString IndexNo = IndexNo.number(Index);
	   const char* setText1 = IDFile0.latin1();
	   const char* setText2 = Namefile.latin1();
	   const char* setText3 = IndexNo.latin1();
	   rc = sqlite_get_table_printf( db, "insert into LINKDB values ('%q','%q','%q','-','%q');",&result,nrow,ncolumn,errmsg,setText,setText1,setText2,setText3);
	   Index++;
	   check2 = 1;
	}
        }

   }
   sqlite_free_table(result);
   //QDir dir2(Path2Save);
   //dir2.remove(Path2Save+MaaName);
   if (check2 == 0)
   QMessageBox::information( this, "Multimedia Album",
                            "Import Progress.\n"
			    "Make Album Name : '" + IDAlbum + "'.\n"
                            "Transfer finished." );
   else
   QMessageBox::information( this, "Multimedia Album",
                            "Import Progress.\n"
			    "Make Album Name : '" + IDAlbum + "' and '" + IDAlbum2 + "'.\n"
                            "Transfer finished." );

}
void MaaForm::ShowSlide()
{
    if (isSlide)
    {	isSlide=FALSE;
    	fullScreen();
    }
    else
    {	isSlide=TRUE;
    	if(isFullScreen==FALSE)
    		fullScreen();
	QListViewItem* Next=FileListView->firstChild();
        FileListView->setCurrentItem(Next);
        viewAlbum(Next);
        Slide();
    }
}
void MaaForm::Slide()
{
	QListViewItem* Next = FileListView->currentItem();
	if (Next == NULL) return;
     QString getPath = Next->text(0);
     bool ok;
     int temp = getPath.toInt(&ok,10);
     QListViewItemIterator it(AlbumIndex);
     for (; it.current(); ++it)
     {
       int idp = (it.current()->text(0)).toInt(&ok,10);
       if (temp == idp)
          getPath = it.current()->text(1);
     }
     //openFile(getPath);
     int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = getPath;
    rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    QString Path = result[1];
    ImageName = Path;
    filepath = Path;
    QFileInfo fi(Path);
    QImage imageornot;
    if(imageornot.load(Path,0))
	timer2->start( 2000 );
    else
    {
	bool bl=nextFile();
	if(!bl)
	{  fullScreen();
	   return;
	}
    }//timer2->start( 2000 );
}
void MaaForm::swap()
{
    optionals->raiseWidget(0);
}

void MaaForm::loadA()
{
    swap();
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = Album2Open.latin1();
    rc = sqlite_get_table_printf( db, "select Name,Description,FIndex,FileID from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    int j = ((*nrow)+1)*(*ncolumn);
    FileListView->clear();
    AlbumIndex->clear();
    QString test[j];
    for (int i = 4 ; i<j; i=i+4)
	{
	test[i] = result[i];
	test[i+1] = result[i+1];
	test[i+2] = result[i+2];
	QString Fid = result[i+3];
	QListViewItem *item3 = new QListViewItem( FileListView );
        item3->setText(1,test[i] );
        item3->setText(0,test[i+2].rightJustify(4,'0'));
        item3->setText(2,test[i+1] );
	QListViewItem *item4 = new QListViewItem( AlbumIndex );
        item4->setText(0,test[i+2]);
        item4->setText(1,Fid);
	}
    sqlite_free_table(result);
}

bool MaaForm::nextFile()
{
    QListViewItem* Next = FileListView->currentItem();
    if(Next == NULL)
        return FALSE;
    Next = Next->itemBelow();
    if(Next == NULL)
        return FALSE;
    FileListView->setCurrentItem(Next);
    viewAlbum(Next);
    return TRUE;
}

void MaaForm::prevFile()
{
    QListViewItem* Next = FileListView->currentItem();
    if(Next == NULL)
        return;
    Next = Next->itemAbove();
    if(Next == NULL)
        return;
    FileListView->setCurrentItem(Next);
    viewAlbum(Next);
}

void MaaForm::openFile(const char *newfilename)
{   zoomlv=4;
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = newfilename;
    rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    QString Path = result[1];
    ImageName = Path;
    filepath = Path;
    QFileInfo fi(Path);
    QImage imageornot;
    if(imageornot.load(Path,0))
    {  loadImage(Path) ;
       int scaledWidth;
    	int scaledHeight;
    	scaledWidth = pm.width();
    	scaledHeight = pm.height();
    	//pmScaled.convertFromImage( image.smoothScale( scaledWidth, scaledHeight ) );
    	resizeContents(scaledWidth, scaledHeight);
    	repaint();
	timer->start( 10,true );
    }
    else
    {
       if(isSlide==FALSE)
	{
       DocLnk doc(Path,FALSE);
       doc.execute();}
       else
          return;
    }
                         // show image in widget
    sqlite_free_table(result);

}

bool MaaForm::loadImage( const char *fileName )
{
    filename = fileName;
    bool ok = FALSE;
    if ( filename ) {
        ok = image.load(filename, 0);
        pickx = -1;
        clickx = -1;
        if ( ok )
            ok = reconvertImage();
        if ( ok ) {
            int w = pm.width();
            int h = pm.height();

            const int reasonable_width = 128;
            if ( w < reasonable_width ) {

                int multiply = ( reasonable_width + w - 1 ) / w;
                w *= multiply;
                h *= multiply;
            }

            //h += menubar->heightForWidth(w) + status->height();
            //resize( w, h );                             // we resize to fit image
        } else {
            pm.resize(0,0);                             // couldn't load image
            update();
        }

    }
    //updateStatus();
    //setMenuItemFlags();

    return ok;
}

bool MaaForm::reconvertImage()
{
    bool success = FALSE;

    if ( image.isNull() ) return FALSE;

    if ( alloc_context ) {
        QColor::destroyAllocContext( alloc_context );
        alloc_context = 0;
    }
    if ( pm.convertFromImage(image, conversion_flags) )
    {
        pmScaled = QPixmap();
        scale();
        resize( width(), height() );
        success = TRUE;                         // load successful
    } else {
        pm.resize(0,0);                         // couldn't load image
    }
    //updateStatus();

    //QApplication::restoreOverrideCursor();      // restore original cursor

    return success;                             // TRUE if loaded OK
}

void MaaForm::scale()
{
    int h = height();// - menubar->heightForWidth( width() ) - status->height();

    //if ( image.isNull() ) return;
    /*if ( width() == pm.width() && h == pm.height() )
    {                                           // no need to scale if widget
        pmScaled = pm;                          // size equals pixmap size
    } else {

            QWMatrix m;                         // transformation matrix
            m.scale(((double)width())/pm.width(),// define scale factors
                    ((double)h)/pm.height());
            pmScaled = pm.xForm( m );           // create scaled pixmap

    }*/pmScaled = pm;
    //QApplication::restoreOverrideCursor();      // restore original cursor
}


void MaaForm::paintEvent( QPaintEvent *e )
{
    if ( pm.size() != QSize( 0, 0 ) ) {         // is an image loaded?
         if(isFullScreen == TRUE)
	 {double x;
	 double y;
	 x=pmScaled.width()/240;
	 y=pmScaled.height()/280;
	 int x1=x+0.75;
	 int y1=y+0.75;
	 int scaledWidth;
    int scaledHeight;
    //setCaption(QString::number(pmScaled.width(),10));
    if((x>0)||(y>0))
	{	if(x>y)
        	{scaledWidth = pm.width()/(x+0.80);
        	scaledHeight = pm.height()/(x+0.80);}
		else
		{scaledWidth = pm.width()/(y+0.80);
        	scaledHeight = pm.height()/(y+0.80);}
        pmScaled.convertFromImage( image.smoothScale( scaledWidth, scaledHeight ) );
	vp->setHScrollBarMode(QScrollView::AlwaysOff);
   vp->setVScrollBarMode(QScrollView::AlwaysOff);
	//resizeContents(scaledWidth, scaledHeight);
	 }}
	FrameShow->resize(pmScaled.width(),pmScaled.height());
        QPainter painter(FrameShow);
        painter.setClipRect(e->rect());
        painter.drawPixmap(0, 0, pmScaled);
    }//mb->heightForWidth( width() )
}
void MaaForm::setImage(const QImage& newimage)
{
    image = newimage;

    pickx = -1;
    clickx = -1;
    int w = image.width();
    int h = image.height();
    if ( !w )
        return;

    const int reasonable_width = 128;
    if ( w < reasonable_width ) {
        // Integer scale up to something reasonable
        int multiply = ( reasonable_width + w - 1 ) / w;
        w *= multiply;
        h *= multiply;
    }

    //h += menubar->heightForWidth(w) + status->height();
    // resize( w, h );                             // we resize to fit image

    reconvertImage();
    repaint( image.hasAlphaBuffer() );

    //updateStatus();

}
void MaaForm::timerDone()
{	//repaint();
    FrameShow->erase();//setPalette( QPalette( QColor(255, 255, 255) ) );

    repaint();//timer->start( 1,true );
}
void MaaForm::timerDone2()
{
    //FrameShow->erase();
    //repaint();

    if(isSlide)
    {//nextFile();

	bool bl=nextFile();
	if(!bl)
	{	fullScreen();
		return;
	}
	Slide();}

}
void MaaForm::screenFullShow()
{
    frameFull->showFullScreen();
    repaint();
}

int MaaForm::callback(void *NotUsed, int argc, char **argv, char **azColName){
  int i;
  for(i=0; i<argc; i++){
    printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
  }
  printf("\n");
  return 0;
}

bool MaaForm::copyFile( const QString & dest, const QString & src )
{
    char bf[ 50000 ];
    int  bytesRead;
    bool success = TRUE;

    QFile s( src );
    QFile d( dest );

    if( s.open( IO_ReadOnly | IO_Raw ) &&
		d.open( IO_WriteOnly | IO_Raw ) )
    {
		while( (bytesRead = s.readBlock( bf, sizeof( bf ) )) ==
			   sizeof( bf ) )
		{
			if( d.writeBlock( bf, sizeof( bf ) ) != sizeof( bf ) ){
				success = FALSE;
				break;
			}
		}
		if( success && (bytesRead > 0) ){
			d.writeBlock( bf, bytesRead );
		}
    } else {
		success = FALSE;
    }
    return success;
}

void MaaForm::ShowEdit()
{
    if(EditAButton->isOn())
        optional1->raiseWidget(1);
    else
        optional1->raiseWidget(0);
}

void MaaForm::editProp()
{
    if(FileListView->currentItem() == NULL)
       return;
    EditPropertyForm* EP = new EditPropertyForm(this, NULL, true, true);
    QListViewItem* item2edit = FileListView->currentItem();
    QString Row2edit = item2edit->text(0);
    bool ok;
    int temp = Row2edit.toInt(&ok,10);
    Row2edit = Row2edit.number(temp);
    QString Name2edit = item2edit->text(1);
    QString Des2edit = item2edit->text(2);
    EP->RowID = Row2edit;
    EP->RowName = Name2edit;
    EP->RowDes = Des2edit;
    EP->exec();
    //setCaption(Row2edit);
    QListViewItemIterator it(AlbumIndex);
    QString FID;
    for (; it.current(); ++it)
    {
       if (Row2edit == it.current()->text(0))
          FID = it.current()->text(1);
    }
    Name2edit = EP->NameLineEdit->text();
    Des2edit = EP->DesLineEdit->text();
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = FID.latin1();
    const char *setText1 = Name2edit.latin1();
    const char *setText2 = Des2edit.latin1();
    const char *setText3 = Album2Open.latin1();
    //setCaption(Album2Open);
    rc = sqlite_get_table_printf( db, "update LINKDB set Name = '%q', Description = '%q' where FileID = '%q' and AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText1,setText2,setText,setText3);
    repaint();
    reloadA();
}

void MaaForm::upFile()
{
    QListViewItem* itemUp = FileListView->currentItem();
    if (itemUp == NULL) return;
    if (itemUp->itemAbove() == NULL)
       return;
    QString IDBefore = itemUp->text(0);
    itemUp = itemUp->itemAbove();
    QString IDAfter = itemUp->text(0);
    itemUp->setText(0,IDBefore);
    itemUp = itemUp->itemBelow();
    itemUp->setText(0,IDAfter);
    bool ok;
    int ID1st = IDBefore.toInt(&ok,10);
    int ID2nd = IDAfter.toInt(&ok,10);
    IDBefore = IDBefore.number(ID1st,10);
    IDAfter = IDAfter.number(ID2nd,10);
    QListViewItemIterator it(AlbumIndex);
    for (; it.current(); ++it)
    {
       if (IDAfter == it.current()->text(0))
          it.current()->setText(0,IDBefore);
       else if (IDBefore == it.current()->text(0))
          it.current()->setText(0,IDAfter);
    }
    FileListView->sort();
}

void MaaForm::downFile()
{
    QListViewItem* itemDown = FileListView->currentItem();
    if (itemDown == NULL) return;
    if (itemDown->itemBelow() == NULL)
       return;
    QString IDBefore = itemDown->text(0);
    itemDown = itemDown->itemBelow();
    QString IDAfter = itemDown->text(0);
    itemDown->setText(0,IDBefore);
    itemDown = itemDown->itemAbove();
    itemDown->setText(0,IDAfter);
    bool ok;
    int ID1st = IDBefore.toInt(&ok,10);
    int ID2nd = IDAfter.toInt(&ok,10);
    IDBefore = IDBefore.number(ID1st,10);
    IDAfter = IDAfter.number(ID2nd,10);
    QListViewItemIterator it(AlbumIndex);
    for (; it.current(); ++it)
    {
       if (IDAfter == it.current()->text(0))
          it.current()->setText(0,IDBefore);
       else if (IDBefore == it.current()->text(0))
          it.current()->setText(0,IDAfter);
    }
    FileListView->sort();
}

void MaaForm::saveFileIndex()
{
   int rc;
   char ***result = new char**;
   int *nrow = new int;
   int *ncolumn = new int;
   char **errmsg = new char*;
   const char *setText = new char;
   const char *setText1 = new char;
   const char *setText2 = Album2Open.latin1();
   QString FIndex;
   QString FID;
   QListViewItemIterator it(AlbumIndex);
   for (; it.current(); ++it)
   {
       FIndex = it.current()->text(0);
       FID = it.current()->text(1);
       setText = FIndex.latin1();
       setText1 = FID.latin1();
       rc = sqlite_get_table_printf( db, "update LINKDB set FIndex = '%q' where FileID = '%q' and AlbumID = '%q';",result,nrow,ncolumn,errmsg,setText,setText1,setText2);
   }
}

void MaaForm::reloadA()
{
    FileListView->clear();

    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = Album2Open.latin1();
    rc = sqlite_get_table_printf( db, "select Name,Description,FileID from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    int j = ((*nrow)+1)*(*ncolumn);
    QString test[j];
    //setCaption(QString::number(j,10));
    for (int i = 3 ; i<j; i=i+3)
    {
	test[i] = result[i];
	test[i+1] = result[i+1];
	test[i+2] = result[i+2];
	//setCaption(test[i]);
	QListViewItemIterator it(AlbumIndex);
	QString FID;
	for (; it.current(); ++it)
	{
	   if (test[i+2] == it.current()->text(1))
	      FID = it.current()->text(0);
	}
	QListViewItem *item3 = new QListViewItem( FileListView );
        item3->setText(1,test[i]);
        item3->setText(2,test[i+1] );
        item3->setText(0,FID.rightJustify(4,'0') );
    }
    sqlite_free_table(result);
}

void MaaForm::XportA()
{
    if (Album2Open == "0") return;
    QString xportname = "/root/Documents/export.maa";
    QString xfrom = "export.maa";//XP->NameLine->text();
    XportF* XF = new XportF(this, NULL, true, true);
    XF->exec();
    int okX = XF->okX;
    int via = XF->via;
    if (okX == 0) return;
    QString xportpath = "/mnt/hda/";
    //xportname = xportpath + xportname;
    QListViewItemIterator it(FileListView);
    QString FID;
    QString FPath;

    QStringList list;
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = Album2Open.latin1();
    bool ok;
    QString FName;
    for (; it.current(); ++it)
    {
       QListViewItemIterator it1(AlbumIndex);
       for (; it1.current(); ++it1)
       {
           if ((it1.current()->text(0)).toInt(&ok,10) == (it.current()->text(0)).toInt(&ok,10))
           {
              FID = it1.current()->text(1);
	      setText = FID.latin1();
              rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText);
	      FPath = result[1];
	      QFileInfo fi(FPath);
	      FName = fi.fileName();
	      list.append(FPath);
	   }
       }
       QListViewItem *insX = new QListViewItem(AlbumListView);
       insX->setText(0,it.current()->text(1));
       insX->setText(1,it.current()->text(2));
       insX->setText(2,FName);
    }
    QFile f( xportname );
    if ( !f.open( IO_WriteOnly ) )
        return;
    QTextStream t( &f );
    QListViewItemIterator it2( AlbumListView );
    for ( ; it2.current(); ++it2 )
        for ( unsigned int i = 0; i < 3; i++ )
            t << it2.current()->text( i ) << "\n";
    f.close();


    if (okX == 1)
    {
       if(via == 0)
       {
	  Ir test;
          if(!test.supported())
	  {
	     QMessageBox::critical(this, "Export via IrDa", "The IrDa not support"  ,QString("Ok") );
	     return;
	  }
	  Ir *fileIR = new Ir(this, "IR");
	  for ( QStringList::Iterator it4 = list.begin(); it4 != list.end(); ++it4 )
          {
             QString FNameSource = *it4;
	     fileIR->send(FNameSource, FNameSource);
          }
  	  fileIR->send(xportname, xportname);
       }
       else
       {
          for ( QStringList::Iterator it3 = list.begin(); it3 != list.end(); ++it3 )
          {
             QString FNameSource = *it3;
             QFileInfo fi( *it3 );
             QString FNameDestination = fi.fileName();
             FNameDestination = xportpath + FNameDestination;
             copyFile(FNameDestination,FNameSource);
          }
	  copyFile(xportpath + xfrom,xportname);
       }
    }
    QDir dir("/");
    dir.remove(xportname);
    sqlite_free_table(result);
    QMessageBox::information( this, "Multimedia Album",
                            "Export Progress.\n"
                            "Transfer finished." );
}

void MaaForm::LoadPlugIn()
{
   int foundPlugin = 0;
   QDir dirOnCF( "/mnt/hda" );
   QString Path2Save = "/root/Documents/Plugins/";
   QStringList List2Plugin;
   const QFileInfoList * fileListES = dirOnCF.entryInfoList();
   QFileInfoListIterator itt( *fileListES);
   QFileInfo *FileInfo;
   while( (FileInfo=itt.current()) != 0)
   {
      ++itt;
      QString namePlugin = FileInfo->filePath();
      if (FileInfo->fileName()==".." || FileInfo->fileName()==".")
        ;
      else if (FileInfo->isDir())
        ;
      else
      {
         QString ext = FileInfo->extension(FALSE);
	 if (ext.lower() == "so")
	 { List2Plugin.append(namePlugin); foundPlugin = 1;}
      }

   }
   for ( QStringList::Iterator it4 = List2Plugin.begin(); it4 != List2Plugin.end(); ++it4 )
   {
      QFileInfo Plugin(*it4);
      QString checkName = Plugin.baseName();
      const QFileInfoList * fileListES1 = dirOnCF.entryInfoList();
      QFileInfoListIterator itt1( *fileListES1);
      QFileInfo *FileInfo1;
      while( (FileInfo1=itt1.current()) != 0)
      {
        ++itt1;
        QString namePluginCheck = FileInfo1->baseName();
	QString PluginCopyPath = FileInfo1->filePath();
	QString PluginCopyName = FileInfo1->fileName();
        if (FileInfo1->fileName()==".." || FileInfo1->fileName()==".")
          ;
        else if (FileInfo1->isDir())
          ;
        else
        {
           if (checkName == namePluginCheck)
	   copyFile(Path2Save+PluginCopyName,PluginCopyPath);
        }

      }
   }
   if (foundPlugin == 1)
      QMessageBox::information( this, "Multimedia Album",
                            "This Plugin will be activated \n"
			    "after reopen program.");
}


void MaaForm::toggleFullscreen()
{
	fullScreen();
}

void MaaForm::normalView()
{

    if (isFullScreen == TRUE)
    {
        vp->setGeometry( QRect(0, 25, 240, 155) );
	isFullScreen = FALSE;
	isSlide = FALSE;

	timer->start( 10,true );
	resizeContents(pm.width(), pm.height());
    }
}

void MaaForm::fullScreen()
{

    if (isFullScreen == TRUE)
    {
       normalView();
       return;
    }
	isFullScreen = TRUE;
	vp->resize(qApp->desktop()->width(), qApp->desktop()->height()-40);
	timer->start( 10,true );

}
void MaaForm::About()
{
   AboutDialog* ab = new AboutDialog(this, NULL, true, true);
   ab->exec();
   timer->start( 10, TRUE );
}
