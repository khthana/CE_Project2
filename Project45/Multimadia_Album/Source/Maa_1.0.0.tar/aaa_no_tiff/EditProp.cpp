/****************************************************************************
** Form implementation generated from reading ui file 'EditProp.ui'
**
** Created: Mon Feb 3 00:53:36 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "EditProp.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a EditPropertyForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
EditPropertyForm::EditPropertyForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "EditPropertyForm" );
    resize( 208, 140 );
    setCaption( tr( "Show Property" ) );
    
    timer = new QTimer(this );
    connect( timer, SIGNAL(timeout()), this, SLOT(genProp()) );

    RowID2show = new QLabel( this, "RowID2show" );
    RowID2show->setGeometry( QRect( 10, 5, 50, 16 ) );
    RowID2show->setText( tr( "Row ID :" ) );

    Name = new QLabel( this, "Name" );
    Name->setGeometry( QRect( 10, 30, 35, 16 ) );
    Name->setText( tr( "Name" ) );

    NameLineEdit = new QLineEdit( this, "NameLineEdit" );
    NameLineEdit->setGeometry( QRect( 5, 50, 195, 22 ) );
    NameLineEdit->setMaxLength( 100 );

    TextLabel4 = new QLabel( this, "TextLabel4" );
    TextLabel4->setGeometry( QRect( 10, 80, 75, 16 ) );
    TextLabel4->setText( tr( "Description" ) );

    DesLineEdit = new QLineEdit( this, "DesLineEdit" );
    DesLineEdit->setGeometry( QRect( 5, 100, 195, 22 ) );
    DesLineEdit->setMaxLength( 200 );

    RowLabel = new QLabel( this, "RowLabel" );
    RowLabel->setGeometry( QRect( 60, 5, 100, 16 ) );
    //RowLabel->setText( "" );

    timer->start( 10,true );

}

/*  
 *  Destroys the object and frees any allocated resources
 */
EditPropertyForm::~EditPropertyForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void EditPropertyForm::genProp()
{
    RowLabel->setText( RowID );
    DesLineEdit->setText(RowDes);
    NameLineEdit->setText(RowName);
}

