/**************************************************************************
** Form interface generated from reading ui file 'EditProp.ui'
**
** Created: Mon Feb 3 00:53:23 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef EDITPROPERTYFORM_H
#define EDITPROPERTYFORM_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;

class EditPropertyForm : public QDialog
{ 
    Q_OBJECT

public:
    EditPropertyForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~EditPropertyForm();

    QLabel* RowID2show;
    QLabel* Name;
    QLineEdit* NameLineEdit;
    QLabel* TextLabel4;
    QLineEdit* DesLineEdit;
    QLabel* RowLabel;
    
    QString RowID;
    QString RowName;
    QString RowDes;
    
    QTimer *timer;

public slots:
    virtual void genProp();
};

#endif // EDITPROPERTYFORM_H
