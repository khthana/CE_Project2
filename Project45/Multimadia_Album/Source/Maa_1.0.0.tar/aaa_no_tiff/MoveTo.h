/****************************************************************************
** Form interface generated from reading ui file 'MoveTo.ui'
**
** Created: Sat Dec 21 01:30:47 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef MOVETOFORM_H
#define MOVETOFORM_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;
class QPushButton;
class QToolButton;

class MoveToForm : public QDialog
{ 
    Q_OBJECT

public:
    MoveToForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~MoveToForm();

    QPushButton* MoveOK;
    QPushButton* MoveCancel;
    QLineEdit* MovePath;
    QToolButton* Search;
    QLabel* Move2;
    QString LinePath;
    int checkMove;

public slots:
    virtual void searchPath();
    virtual void MoveYes();
    virtual void MoveNo();

protected:
    QHBoxLayout* ButtonLayout;
    QHBoxLayout* PathLayout;
};

#endif // MOVETOFORM_H
