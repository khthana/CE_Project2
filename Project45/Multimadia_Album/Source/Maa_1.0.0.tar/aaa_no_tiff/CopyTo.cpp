/****************************************************************************
** Form implementation generated from reading ui file 'CopyTo.ui'
**
** Created: Sat Dec 21 00:59:28 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "CopyTo.h"
#include "OpenPath.h"

#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a CopyToForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
CopyToForm::CopyToForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "CopyToForm" );
    resize( 229, 98 ); 
    setCaption( tr( "Copy File to" ) );

    checkCopy = '0';//0 = don't copy/1 = copy
    QWidget* privateLayoutWidget = new QWidget( this, "Layout1" );
    privateLayoutWidget->setGeometry( QRect( 10, 25, 210, 24 ) ); 
    Layout1 = new QHBoxLayout( privateLayoutWidget ); 
    Layout1->setSpacing( 6 );
    Layout1->setMargin( 0 );

    CopyPath = new QLineEdit( privateLayoutWidget, "CopyPath" );
    Layout1->addWidget( CopyPath );

    Search = new QToolButton( privateLayoutWidget, "Search" );
    Search->setText( tr( "..." ) );
    Layout1->addWidget( Search );
    connect(Search, SIGNAL(clicked()), this, SLOT(searchPath()));

    Copy2 = new QLabel( this, "Copy2" );
    Copy2->setGeometry( QRect( 15, 5, 53, 13 ) ); 
    Copy2->setText( tr( "Copy to :" ) );

    QWidget* privateLayoutWidget_2 = new QWidget( this, "Layout3" );
    privateLayoutWidget_2->setGeometry( QRect( 30, 60, 168, 28 ) ); 
    Layout3 = new QHBoxLayout( privateLayoutWidget_2 ); 
    Layout3->setSpacing( 6 );
    Layout3->setMargin( 0 );

    CopyOK = new QPushButton( privateLayoutWidget_2, "CopyOK" );
    CopyOK->setText( tr( "OK" ) );
    Layout3->addWidget( CopyOK );
    connect( CopyOK, SIGNAL(clicked()), this, SLOT(CopyYes()));

    CopyCancel = new QPushButton( privateLayoutWidget_2, "CopyCancel" );
    CopyCancel->setText( tr( "Cancel" ) );
    Layout3->addWidget( CopyCancel );
    connect( CopyCancel, SIGNAL(clicked()), this, SLOT(CopyNo()));
}

/*
 *  Destroys the object and frees any allocated resources
 */
CopyToForm::~CopyToForm()
{
    // no need to delete child widgets, Qt does it all for us
}
void CopyToForm::searchPath()
{
    OpenPathForm* openPath = new OpenPathForm(this, NULL, true, true);
    openPath->exec();
    LinePath = openPath->Path2Sent;
    CopyPath->setText(LinePath);
    QString pathCheck = LinePath.right(2);
    int pathL = LinePath.length();
    if (pathCheck == "..")
    {LinePath.replace( pathL-2, 2, "" );
     CopyPath->setText(LinePath);
    }
    else {
     LinePath = LinePath + "/";
     CopyPath->setText(LinePath);
    }
}
void CopyToForm::CopyYes()
{
    checkCopy = '1';//Copy ok!
    this->close();
}
void CopyToForm::CopyNo()
{
    this->close();//don't copy -> checkCopy = 0
}
