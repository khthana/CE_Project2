/****************************************************************************
** Form implementation generated from reading ui file 'SearchAlbum.ui'
**
** Created: Mon Jan 6 21:38:37 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "SearchAlbum.h"

#include <qheader.h>
#include <qlineedit.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qfileinfo.h>


/* 
 *  Constructs a SearchAlbumForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f'
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
SearchAlbumForm::SearchAlbumForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "SearchAlbumForm" );
    resize( 219, 210 );
    setCaption( tr( "Import File" ) );
    QDir *dir = new QDir( "/" ); // provides access to the directory
    //dir->setNameFilter("*.Maa");
    fileListE = (QFileInfoList*)(dir->entryInfoList());

    QWidget* privateLayoutWidget = new QWidget( this, "Layout" );
    privateLayoutWidget->setGeometry( QRect( 5, 5, 210, 195 ) ); 
    Layout = new QVBoxLayout( privateLayoutWidget ); 
    Layout->setSpacing( 6 );
    Layout->setMargin( 0 );

    AlbumNameLine = new QLineEdit( privateLayoutWidget, "AlbumNameLine" );
    Layout->addWidget( AlbumNameLine );

    FileListView = new QListView( privateLayoutWidget, "FileListView" );
    FileListView->addColumn( tr( "File Name" ) );
    FileListView->addColumn( tr( "File Type" ) );
    FileListView->addColumn( tr( "File Path" ) );
    Layout->addWidget( FileListView );
    fileE();
    // signals and slots connections
    connect( FileListView, SIGNAL( clicked(QListViewItem*) ), this, SLOT( viewE(QListViewItem*) ) );

}

/*
 *  Destroys the object and frees any allocated resources
 */
SearchAlbumForm::~SearchAlbumForm()
{
    // no need to delete child widgets, Qt does it all for us
}

/*void SearchAlbumForm::AddFileAlbum()
{
    //qWarning( "SearchAlbumForm::AddFileAlbum(): Not implemented yet!" );
    QListViewItem *item = new QListViewItem(FileListView);
    AlbumNameLine->setText(item->text(0));
    Name2Sent = AlbumNameLine->text();
}*/

void SearchAlbumForm::fileE()
{
    fileInfoE = fileListE->first();
    //fileInfo = fileList->next();
    fileInfoE = fileListE->next();
    while(fileInfoE != 0)
    {
    QString name = fileInfoE->fileName();
    QString name1 = fileInfoE->extension(FALSE);
    QString name2 = fileInfoE->filePath();
    QListViewItem *item = new QListViewItem(FileListView);
    item->setText(0,name);
    item->setText(1,name1);
    item->setText(2,name2);
    fileInfoE = fileListE->next();
    }
}
void SearchAlbumForm::viewE(QListViewItem *item)
{
    if ( !item )
	return;
    item->setSelected( TRUE );
    item->repaint();

    //check(item->text(0));
    fileInfoE = fileListE->first();
    fileInfoE = fileListE->next();
    while(fileInfoE->fileName() != item->text(0))
    {
    	fileInfoE = fileListE->next();
    }
    if (fileInfoE->isDir())
    {
    	QDir *dir = new QDir( fileInfoE->filePath() ); // provides access to the directory
	//dir->setNameFilter("* *.MAA *.maa *.Maa *.MAa *.mAa *.maA");
    	fileListE = (QFileInfoList*)(dir->entryInfoList());
    	FileListView->clear();
    	fileE();
	//setCaption( "dir" );
    }
    else
    {
    	//str=fileInfoE->filePath();

        AlbumNameLine->setText(fileInfoE->filePath());
        Name2Sent = AlbumNameLine->text();
    }
}
