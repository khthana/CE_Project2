/****************************************************************************
** Form interface generated from reading ui file '/tmp/Dev4Project/aaa/OpenPath.ui'
**
** Created: Sat Jan 11 18:56:50 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef OPENPATHFORM_H
#define OPENPATHFORM_H

#include <qvariant.h>
#include <qdialog.h>
#include <qdir.h>
class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QLineEdit;
class QListView;
class QListViewItem;

class OpenPathForm : public QDialog
{
    Q_OBJECT

public:
    OpenPathForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~OpenPathForm();

    QLineEdit* PathLine;
    QListView* PathListView;
    QFileInfoList *fileListPath;
    QFileInfo *fileInfoPath;
    QString Path2Sent;
    void filePath();

public slots:
    //virtual void AddFileAlbum();
    virtual void viewPath(QListViewItem *);

protected:
    QVBoxLayout* Layout3;
};

#endif // OPENPATHFORM_H
