/****************************************************************************
** Form interface generated from reading ui file 'about.ui'
**
** Created: Thu Mar 27 14:39:48 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef ABOUTDIALOG_H
#define ABOUTDIALOG_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;

class AboutDialog : public QDialog
{ 
    Q_OBJECT

public:
    AboutDialog( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~AboutDialog();

    QLabel* TextLabel1;
    QLabel* TextLabel5;
    QLabel* PixmapLabel1;
    QLabel* PixmapLabel1_2;


protected:
};

#endif // ABOUTDIALOG_H
