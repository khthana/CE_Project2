/****************************************************************************
** Form implementation generated from reading ui file '/tmp/Dev4Project/aaa/OpenPath.ui'
**
** Created: Sat Jan 11 18:57:17 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "OpenPath.h"

#include <qvariant.h>
#include <qheader.h>
#include <qlineedit.h>
#include <qlistview.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qstring.h>

/*
 *  Constructs a OpenPathForm which is a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
OpenPathForm::OpenPathForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "OpenPathForm" );
    resize( 213, 207 );
    setCaption( tr( "Open Path" ) );
    QDir *dirPath = new QDir( "/" ); // provides access to the directory
    //dirPath->setNameFilter("");
    fileListPath = (QFileInfoList*)(dirPath->entryInfoList());

    QWidget* privateLayoutWidget = new QWidget( this, "Layout3" );
    privateLayoutWidget->setGeometry( QRect( 0, 5, 210, 195 ) );
    Layout3 = new QVBoxLayout( privateLayoutWidget, 0, 6, "Layout3");

    PathLine = new QLineEdit( privateLayoutWidget, "PathLine" );
    Layout3->addWidget( PathLine );

    PathListView = new QListView( privateLayoutWidget, "PathListView" );
    PathListView->addColumn( tr( "File Name" ) );
    PathListView->addColumn( tr( "File Type" )) ;
    PathListView->addColumn( tr( "File Path" ) );
    Layout3->addWidget( PathListView );
    filePath();
    connect( PathListView, SIGNAL( clicked(QListViewItem*) ), this, SLOT( viewPath(QListViewItem*) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
OpenPathForm::~OpenPathForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void OpenPathForm::filePath()
{
    fileInfoPath = fileListPath->first();
    //fileInfo = fileList->next();
    fileInfoPath = fileListPath->next();
    while(fileInfoPath != 0)
    {
    QString name = fileInfoPath->fileName();
    QString name2 = fileInfoPath->filePath();
    QString name1 = fileInfoPath->extension(FALSE);
    //if (name1 = ""){name1 = "File";}
    QListViewItem *item = new QListViewItem(PathListView);
    item->setText(0,name);
    item->setText(1,name1);
    item->setText(2,name2);
    fileInfoPath = fileListPath->next();
    }
}
void OpenPathForm::viewPath(QListViewItem *itemPath)
{
    if ( !itemPath )
	return;
    itemPath->setSelected( TRUE );
    itemPath->repaint();

    //check(item->text(0));
    fileInfoPath = fileListPath->first();
    fileInfoPath = fileListPath->next();
    while(fileInfoPath->fileName() != itemPath->text(0))
    {
    	fileInfoPath = fileListPath->next();
    }
    if (fileInfoPath->isDir())
    {
	QString Path2Open = fileInfoPath->filePath();
	QString PathCheck = Path2Open.right(2);
        int pathL = Path2Open.length();
        if (PathCheck == "..")
        {Path2Open.replace( pathL-3, 3, "" );
         /*pathL = Path2Open.length();
	 int I = Path2Open.findRev('/',-1);
	 Path2Open.replace( pathL-I, I, "" );*/
	 PathLine->setText(Path2Open);
        }
	else
	 PathLine->setText(fileInfoPath->filePath());
        Path2Sent = PathLine->text();
	QDir *dirTemp = new QDir( fileInfoPath->filePath() ); // provides access to the directory
	//dirTemp->setNameFilter("");
    	fileListPath = (QFileInfoList*)(dirTemp->entryInfoList());
    	PathListView->clear();
    	filePath();
	//setCaption( "dir" );
    }
    else
    {
    	//str=fileInfoPath->filePath();

        //PathLine->setText(fileInfoPath->filePath());
        //Path2Sent = AlbumNameLine->text();
    }
}


