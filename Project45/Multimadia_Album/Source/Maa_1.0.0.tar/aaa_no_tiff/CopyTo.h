/****************************************************************************
** Form interface generated from reading ui file 'CopyTo.ui'
**
** Created: Sat Dec 21 00:59:21 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef COPYTOFORM_H
#define COPYTOFORM_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;
class QPushButton;
class QToolButton;

class CopyToForm : public QDialog
{ 
    Q_OBJECT

public:
    CopyToForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~CopyToForm();

    QLineEdit* CopyPath;
    QToolButton* Search;
    QLabel* Copy2;
    QPushButton* CopyOK;
    QPushButton* CopyCancel;
    QString LinePath;
    int checkCopy;
    
public slots:
    virtual void searchPath();
    virtual void CopyYes();
    virtual void CopyNo();

protected:
    QHBoxLayout* Layout1;
    QHBoxLayout* Layout3;
};

#endif // COPYTOFORM_H
