/****************************************************************************
** Form interface generated from reading ui file 'SearchAlbum.ui'
**
** Created: Mon Jan 6 21:38:26 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef SEARCHALBUMFORM_H
#define SEARCHALBUMFORM_H

#include <qvariant.h>
#include <qdialog.h>
#include <qdir.h>

class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLineEdit;
class QListView;
class QListViewItem;

class SearchAlbumForm : public QDialog
{ 
    Q_OBJECT

public:
    SearchAlbumForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~SearchAlbumForm();

    QLineEdit* AlbumNameLine;
    QListView* FileListView;
    QString Name2Sent;
    QFileInfo *fileInfoE;
    QFileInfoList *fileListE;
    void fileE();
    
public slots:
    //virtual void AddFileAlbum();
    virtual void viewE(QListViewItem *);
protected:
    QVBoxLayout* Layout;
};

#endif // SEARCHALBUMFORM_H
