/****************************************************************************
** Form implementation generated from reading ui file 'SlideShow.ui'
**
** Created: Sat Dec 21 02:06:32 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "SlideShow.h"

#include <qheader.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qstring.h>
#include <qdir.h>
#include <qfileinfo.h>
#include <qfile.h>
#include <qtextstream.h>



/*
 *  Constructs a SlideShowForm which is a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'
 *
 *  The dialog will by default be modeless, unless you set 'modal' to

 *  TRUE to construct a modal dialog.
 */
SlideShowForm::SlideShowForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "SlideShowForm" );
    resize( 226, 252 );
    setCaption( tr( "Make a Slide Show" ) );
    QDir *dirS = new QDir( "/" ); // provides access to the directory
    fileListDIR = (QFileInfoList*)(dirS->entryInfoList());

    MakeSlide='0';
    /*UpButton = new QToolButton( this, "UpButton" );
    UpButton->setGeometry( QRect( 15, 10, 16, 20 ) );
    UpButton->setText( tr( "..." ) );*/

    AddButton = new QPushButton( this, "AddButton" );
    AddButton->setGeometry( QRect( 45, 3, 70, 25 ) );
    AddButton->setText( tr( "Add" ) );
    connect( AddButton, SIGNAL( clicked() ), this, SLOT( addSlide() ) );

    DeleteButton = new QPushButton( this, "DeleteButton" );
    DeleteButton->setGeometry( QRect( 135, 3, 70, 25 ) );
    DeleteButton->setText( tr( "Delete" ) );
    connect( DeleteButton, SIGNAL( clicked() ), this, SLOT( delFromSlide() ) );

    QWidget* privateLayoutWidget = new QWidget( this, "Layout7" );
    privateLayoutWidget->setGeometry( QRect( 20, 223, 185, 30 ) );
    Layout7 = new QHBoxLayout( privateLayoutWidget );
    Layout7->setSpacing( 6 );
    Layout7->setMargin( 0 );

    ShowSlideButton = new QPushButton( privateLayoutWidget, "ShowSlideButton" );
    ShowSlideButton->setText( tr( "Show Slide" ) );
    Layout7->addWidget( ShowSlideButton );
    connect( ShowSlideButton, SIGNAL( clicked() ), this, SLOT( letShow() ) );

    CloseButton = new QPushButton( privateLayoutWidget, "CloseButton" );
    CloseButton->setText( tr( "Close" ) );
    Layout7->addWidget( CloseButton );
    connect( CloseButton, SIGNAL( clicked() ), this, SLOT( donShow() ) );

    FileListView = new QListView( this, "FileListView" );
    FileListView->addColumn( tr( "File Name" ) );
    FileListView->setGeometry( QRect( 5, 33, 215, 92 ) );

    SlideListView = new QListView( this, "SlideListView" );
    SlideListView->addColumn( tr( "File Name" ) );
    SlideListView->addColumn( tr( "File Type") );
    SlideListView->addColumn( tr( "File Path" ) );
    SlideListView->setGeometry( QRect( 5, 127, 215, 97 ) );
    fileDIR();
    connect( SlideListView, SIGNAL( clicked(QListViewItem*) ), this, SLOT( viewDIR(QListViewItem*) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
SlideShowForm::~SlideShowForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void SlideShowForm::fileDIR()
{
    fileInfoDIR = fileListDIR->first();
    //fileInfo = fileList->next();
    fileInfoDIR = fileListDIR->next();
    while(fileInfoDIR != 0)
    {
    QString name1 = fileInfoDIR->fileName();
    QString name0 = fileInfoDIR->extension(FALSE);
    QString name2 = fileInfoDIR->filePath();
    QListViewItem *itemS = new QListViewItem(SlideListView);
    itemS->setText(0,name1);
    itemS->setText(1,name0);
    itemS->setText(2,name2);
    fileInfoDIR = fileListDIR->next();
    }
}
void SlideShowForm::viewDIR(QListViewItem *itemSlide)
{
    if ( !itemSlide )
	return;
    itemSlide->setSelected( TRUE );
    itemSlide->repaint();

    //check(item->text(0));
    fileInfoDIR = fileListDIR->first();
    fileInfoDIR = fileListDIR->next();
    while(fileInfoDIR->fileName() != itemSlide->text(0))
    {
    	fileInfoDIR = fileListDIR->next();
    }
    if (fileInfoDIR->isDir())
    {
    	QDir *dirS = new QDir( fileInfoDIR->filePath() ); // provides access to the directory
    	fileListDIR = (QFileInfoList*)(dirS->entryInfoList());
    	SlideListView->clear();
    	fileDIR();
	//setCaption( "dir" );
    }
    else
    {
    	strS=fileInfoDIR->filePath();
    }
}
void SlideShowForm::addSlide()
{
    QListViewItem *item2Add = new QListViewItem(FileListView);
    item2Add->setText(0,strS);
}
void SlideShowForm::delFromSlide()
{

       QListViewItem* item2del = FileListView->currentItem();
       delete item2del;

}
void SlideShowForm::letShow()
{
    MakeSlide='1';
    this->close();
}
void SlideShowForm::donShow()
{
    MakeSlide='0';
    this->close();
}
