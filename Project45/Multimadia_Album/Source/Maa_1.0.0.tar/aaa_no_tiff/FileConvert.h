/****************************************************************************
** Form interface generated from reading ui file 'FileConvert.ui'
**
** Created: Fri Dec 20 23:05:07 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef FILECONVERTFORM_H
#define FILECONVERTFORM_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QButtonGroup;
class QLineEdit;
class QPushButton;
class QRadioButton;
class QToolButton;

class FileConvertForm : public QDialog
{ 
    Q_OBJECT

public:
    FileConvertForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~FileConvertForm();

    QPushButton* SaveOK;
    QPushButton* SaveCancel;
    QButtonGroup* FileType;
    QRadioButton* bmp;
    QRadioButton* gif;
    QRadioButton* xpm;
    QRadioButton* png;
    QRadioButton* jpg;
    int SaveYes;
    QString Type;


public slots:
    virtual void SaySave();

protected:
    QHBoxLayout* ButtonLayout;
    QHBoxLayout* PathLayout;
};

#endif // FILECONVERTFORM_H
