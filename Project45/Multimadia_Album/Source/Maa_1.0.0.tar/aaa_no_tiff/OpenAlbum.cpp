/****************************************************************************
** Form implementation generated from reading ui file '/tmp/Dev4Project/aaa/OpenAlbum.ui'
**
** Created: Sat Feb 1 04:15:10 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "OpenAlbum.h"
#include "NewAlbum.h"
#include "EditNameA.h"

#include <qheader.h>
#include <qlineedit.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qstring.h>
#include <qtoolbutton.h>

#include "sqlite.h"

/* 
 *  Constructs a OpenAlbumForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
OpenAlbumForm::OpenAlbumForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "OpenAlbumForm" );
    resize( 215, 210 ); 
    setCaption( tr( "Choose Album" ) );
    timer = new QTimer(this );
    connect( timer, SIGNAL(timeout()), this, SLOT(genList()) );

    AlbumNameLine = new QLineEdit( this, "AlbumNameLine" );
    AlbumNameLine->setEnabled(FALSE);
    AlbumNameLine->setGeometry( QRect( 5, 5, 138, 21 ) );
    
    NewButton = new QToolButton( this, "NewButton" );
    NewButton->setGeometry( QRect( 146, 5, 28, 21 ) );
    NewButton->setText( tr( "Add" ) );
    connect( NewButton, SIGNAL( clicked() ), this, SLOT(New1Album()));

    EditButton = new QToolButton( this, "EditButton" );
    EditButton->setGeometry( QRect( 179, 5, 28, 21 ) );
    EditButton->setEnabled(FALSE);
    EditButton->setText( tr( "Edit" ) );
    connect( EditButton, SIGNAL( clicked() ), this, SLOT(EditAlbumName()));

    AlbumDB = new QListView( this, "AlbumDB" );
    AlbumDB->addColumn( tr( "Album ID" ) );
    AlbumDB->addColumn( tr( "Album Name" ) );
    AlbumDB->setGeometry( QRect( 5, 30, 205, 165 ) );

    // signals and slots connections
    connect( AlbumDB, SIGNAL( clicked(QListViewItem*) ), this, SLOT( openAlbum(QListViewItem*) ) );
    timer->start( 10,true );
}

/*
 *  Destroys the object and frees any allocated resources
 */
OpenAlbumForm::~OpenAlbumForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void OpenAlbumForm::genList()
{
    AlbumDB->clear();
    AlbumName= "0";
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    rc = sqlite_get_table_printf( db, "select * from ALBUMDB;",&result,nrow,ncolumn,errmsg);
    int j = ((*nrow)+1)*(*ncolumn);
    QString test[j];
    for (int i = 2 ; i<j; i=i+2)
	{//printf("%s \n", result[i]);
	test[i] = result[i];
	test[i+1] = result[i+1];
	QListViewItem *item3 = new QListViewItem( AlbumDB );
	item3->setText(1,test[i+1]);
        item3->setText(0,test[i].rightJustify(4,'0') );
	}
    sqlite_free_table(result);
}

void OpenAlbumForm::openAlbum(QListViewItem *item)
{
    if ( !item )
	return;
    item->setSelected( TRUE );
    EditButton->setEnabled(TRUE);
    AlbumNameLine->setText(item->text(1));
    AlbumName = item->text(0);
    NameAlbum = AlbumNameLine->text();
}

void OpenAlbumForm::New1Album()
{
   NewAlbumForm* na = new NewAlbumForm(this, NULL, true, true);
   na->db = db;
   na->exec();
   genList();
}

void OpenAlbumForm::EditAlbumName()
{
   EditForm* EP = new EditForm(this, NULL, true, true);
   QListViewItem* item2edit = AlbumDB->currentItem();
   QString ID2edit = item2edit->text(0);
   QString Name2edit = item2edit->text(1);
   EP->AlbumID = ID2edit;
   EP->Name = Name2edit;
   EP->exec();
   Name2edit = EP->NameLineEdit->text();
   bool ok;
   int temp = ID2edit.toInt(&ok,10);
   ID2edit = ID2edit.number(temp);
   int rc;
   char **result = new char*;
   int *nrow = new int;
   int *ncolumn = new int;
   char **errmsg = new char*;
   const char *setText = ID2edit.latin1();
   const char *setText1 = Name2edit.latin1();
   rc = sqlite_get_table_printf( db, "update ALBUMDB set AlbumName = '%q' where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText1,setText);
   genList();
   AlbumNameLine->setText(Name2edit);
}



