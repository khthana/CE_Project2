/****************************************************************************
** Form interface generated from reading ui file 'newXport.ui'
**
** Created: Sat Feb 8 21:51:31 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef XPORTFORM_H
#define XPORTFORM_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;
class QPushButton;

class XportForm : public QDialog
{ 
    Q_OBJECT

public:
    XportForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~XportForm();

    QPushButton* OKButton;
    QPushButton* CancelButton;
    QLabel* Name;
    QLineEdit* NameLine;
    int ok;
    QString NameX;

public slots:
    virtual void oknew();

};

#endif // XPORTFORM_H
