/****************************************************************************
** Form interface generated from reading ui file 'SlideShow.ui'
**
** Created: Sat Dec 21 02:06:26 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef SLIDESHOWFORM_H
#define SLIDESHOWFORM_H

#include <qvariant.h>
#include <qdialog.h>
#include <qdir.h>
class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QListView;
class QListViewItem;
class QPushButton;
class QToolButton;

class SlideShowForm : public QDialog
{
    Q_OBJECT

public:
    SlideShowForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~SlideShowForm();

    QToolButton* UpButton;
    QPushButton* AddButton;
    QPushButton* DeleteButton;
    QPushButton* ShowSlideButton;
    QPushButton* CloseButton;
    QListView* FileListView;
    QListView* SlideListView;
    QFileInfo* fileInfoDIR;
    QFileInfoList* fileListDIR;
    QString strS;
    void fileDIR();
    int MakeSlide;

public slots:
    virtual void viewDIR(QListViewItem *);
    virtual void addSlide();
    virtual void delFromSlide();
    virtual void letShow();
    virtual void donShow();

protected:
    QHBoxLayout* Layout7;
};

#endif // SLIDESHOWFORM_H
