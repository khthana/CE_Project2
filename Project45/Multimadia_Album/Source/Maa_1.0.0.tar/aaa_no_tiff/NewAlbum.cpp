/****************************************************************************
** Form implementation generated from reading ui file 'NewAlbum.ui'
**
** Created: Sat Dec 21 01:49:13 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "NewAlbum.h"
#include "EditAlbum.h"

#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qtextstream.h>
#include <qmessagebox.h>

#include "sqlite.h"

/* 
 *  Constructs a NewAlbumForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
NewAlbumForm::NewAlbumForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "NewAlbumForm" );
    resize( 230, 100 );
    setCaption( tr( "Make New Album" ) );

    QWidget* privateLayoutWidget_2 = new QWidget( this, "ButtonLayout" );
    privateLayoutWidget_2->setGeometry( QRect( 30, 65, 175, 28 ) );
    ButtonLayout = new QHBoxLayout( privateLayoutWidget_2 );
    ButtonLayout->setSpacing( 6 );
    ButtonLayout->setMargin( 0 );

    NewOK = new QPushButton( privateLayoutWidget_2, "NewOK" );
    NewOK->setText( tr( "OK" ) );
    ButtonLayout->addWidget( NewOK );
    connect( NewOK, SIGNAL( clicked() ), this, SLOT( saveNew())  );

    NewCancel = new QPushButton( privateLayoutWidget_2, "NewCancel" );
    NewCancel->setText( tr( "Cancel" ) );
    ButtonLayout->addWidget( NewCancel );
    connect( NewCancel, SIGNAL( clicked() ), this, SLOT( reject())  );

    QWidget* privateLayoutWidget_3 = new QWidget( this, "AlbumNameLayout" );
    privateLayoutWidget_3->setGeometry( QRect( 15, 30, 210, 24 ) ); 
    AlbumNameLayout = new QHBoxLayout( privateLayoutWidget_3 );
    AlbumNameLayout->setSpacing( 6 );
    AlbumNameLayout->setMargin( 0 );

    TextName = new QLabel( privateLayoutWidget_3, "TextName" );
    TextName->setText( tr( "Name" ) );
    AlbumNameLayout->addWidget( TextName );

    NameNewAlbum = new QLineEdit( privateLayoutWidget_3, "NameNewAlbum" );
    AlbumNameLayout->addWidget( NameNewAlbum );

    TextNew = new QLabel( this, "TextNew" );
    TextNew->setGeometry( QRect( 15, 5, 80, 16 ) ); 
    TextNew->setText( tr( "New Album" ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
NewAlbumForm::~NewAlbumForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void NewAlbumForm::saveNew()
{
    //NameA = NameNewAlbum->text();
    if ((NameNewAlbum->text()).length() < 1)
    {
        QMessageBox::information( this, "Multimedia Album",
                            "Adding new Album.\n"
			    "You don't enter the name.");
        return;
    }
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = NameNewAlbum->text().latin1();
    rc = sqlite_get_table_printf( db, "insert into ALBUMDB (AlbumName) values ('%q');",&result,nrow,ncolumn,errmsg,setText);
    if (rc == 0)
    {
      
      rc = sqlite_get_table_printf( db, "select AlbumID from ALBUMDB where AlbumName = '%q';",&result,nrow,ncolumn,errmsg,setText);
      ID2load = result[1];
      //EditAlbumForm* ea = new EditAlbumForm(this, NULL, true, true);
      //ea->db = db;
      //ea->AlbumPath->setText(NameNewAlbum->text());

      //ea->exec();
    }
   
    this->accept();
}
