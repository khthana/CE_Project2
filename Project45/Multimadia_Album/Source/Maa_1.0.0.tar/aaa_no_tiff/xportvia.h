/****************************************************************************
** Form interface generated from reading ui file 'xportvia.ui'
**
** Created: Sat Mar 8 06:00:20 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef XPORTF_H
#define XPORTF_H

#include <qvariant.h>
#include <qdialog.h>
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QButtonGroup;
class QLabel;
class QPushButton;
class QRadioButton;

class XportF : public QDialog
{ 
    Q_OBJECT

public:
    XportF( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~XportF();

    QLabel* TextLabel;
    QButtonGroup* ButtonGroup;
    QRadioButton* cardButton;
    QRadioButton* irButton;
    QPushButton* okButton;
    QPushButton* cancelButton;
    int okX;
    int via;

public slots:
    virtual void cancelXport();
    virtual void okXport();

protected:
    QHBoxLayout* ButtonLayout;
};

#endif // XPORTFORM_H
