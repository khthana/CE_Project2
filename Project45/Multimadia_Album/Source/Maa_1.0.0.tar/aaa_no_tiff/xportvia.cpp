/****************************************************************************
** Form implementation generated from reading ui file 'xportvia.ui'
**
** Created: Sat Mar 8 06:00:31 2003
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#include "xportvia.h"

#include <qbuttongroup.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/* 
 *  Constructs a XportForm which is a child of 'parent', with the 
 *  name 'name' and widget flags set to 'f' 
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
XportF::XportF( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "XportForm" );
    resize( 201, 132 ); 
    setCaption( tr( "Export This Album via :" ) );
    
    okX=0;

    TextLabel = new QLabel( this, "TextLabel" );
    TextLabel->setGeometry( QRect( 10, 5, 65, 16 ) ); 
    TextLabel->setText( tr( "Export via :" ) );

    ButtonGroup = new QButtonGroup( this, "ButtonGroup" );
    ButtonGroup->setGeometry( QRect( 25, 30, 140, 55 ) ); 
    ButtonGroup->setLineWidth( 0 );
    ButtonGroup->setTitle( tr( "" ) );

    cardButton = new QRadioButton( ButtonGroup, "cardButton" );
    cardButton->setGeometry( QRect( 10, 30, 120, 19 ) ); 
    cardButton->setText( tr( "PCMCIA Card" ) );

    irButton = new QRadioButton( ButtonGroup, "irButton" );
    irButton->setGeometry( QRect( 10, 5, 94, 19 ) );
    irButton->setText( tr( "Infrared" ) );
    irButton->setChecked( TRUE );

    QWidget* privateLayoutWidget = new QWidget( this, "ButtonLayout" );
    privateLayoutWidget->setGeometry( QRect( 15, 90, 168, 30 ) ); 
    ButtonLayout = new QHBoxLayout( privateLayoutWidget ); 
    ButtonLayout->setSpacing( 6 );
    ButtonLayout->setMargin( 0 );

    okButton = new QPushButton( privateLayoutWidget, "okButton" );
    okButton->setText( tr( "OK" ) );
    ButtonLayout->addWidget( okButton );

    cancelButton = new QPushButton( privateLayoutWidget, "cancelButton" );
    cancelButton->setText( tr( "Cancel" ) );
    ButtonLayout->addWidget( cancelButton );

    // signals and slots connections
    connect( okButton, SIGNAL( clicked() ), this, SLOT( okXport() ) );
    connect( cancelButton, SIGNAL( clicked() ), this, SLOT( cancelXport() ) );
}

/*  
 *  Destroys the object and frees any allocated resources
 */
XportF::~XportF()
{
    // no need to delete child widgets, Qt does it all for us
}

void XportF::cancelXport()
{
    okX = 0;
    this->reject();
}

void XportF::okXport()
{
    if (cardButton->isChecked())
       via = 1;
    else if(irButton->isChecked())
       via = 0;
    okX = 1;
    this->accept();
}

