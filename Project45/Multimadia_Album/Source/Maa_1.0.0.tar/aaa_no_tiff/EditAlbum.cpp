/****************************************************************************
** Form implementation generated from reading ui file 'EditAlbum.ui'
**
** Created: Fri Dec 20 22:21:33 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "EditAlbum.h"
#include "SearchAlbum.h"
#include "OpenAlbum.h"
#include "EditProp.h"
//#include "newXport.h"
#include "OpenPath.h"
#include "xportvia.h"

#include <qheader.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qvariant.h>
#include <qtooltip.h>
#include <qwhatsthis.h>
#include <qimage.h>
#include <qpixmap.h>
#include <qfileinfo.h>
#include <qfile.h>
#include <qtextstream.h>
#include <qmessagebox.h>
#include <qwidgetstack.h>
#include <qgroupbox.h>
#include <qstringlist.h>
#include <qdir.h>


#include "sqlite.h"

static const char* const image0_data[] = {
"14 14 19 1",
"a c None",
". c None",
"# c #000000",
"n c #9c999c",
"p c #a4a1a4",
"m c #b4aeb4",
"j c #b4b2b4",
"k c #b4b6b4",
"q c #bdb6bd",
"o c #c5c2c5",
"i c #cdcacd",
"l c #d5d6d5",
"e c #ded6de",
"f c #dedade",
"g c #dedede",
"d c #e6e2e6",
"c c #f6f6f6",
"h c #fff6ff",
"b c #ffffff",
"....#####aa...",
"....#bbb#aa...",
"....#bbc##a...",
"....#bbd##a...",
"....#bbe##a...",
"....#bbf##a...",
"....#bbg##a...",
"..###bbf###aa.",
"..#bbbhijk#aa.",
"..a#bblmn##aa.",
"..aa#dop###aa.",
"...aa#q###aa..",
"....aa###aa...",
".....aaaaa...."};

static const char* const image1_data[] = { 
"14 14 19 1",
"a c None",
". c None",
"# c #000000",
"q c #b4b2b4",
"n c #b4b6b4",
"f c #bdb6bd",
"e c #bdbabd",
"j c #bdbebd",
"k c #c5bec5",
"h c #c5c2c5",
"p c #cdcacd",
"d c #dedade",
"m c #eeeaee",
"o c #eeeeee",
"i c #f6f2f6",
"g c #f6f6f6",
"l c #fff6ff",
"c c #fffaff",
"b c #ffffff",
"......#aa.....",
".....#b#aa....",
"....#bbb#aa...",
"...#bbbcd#aa..",
"..#bbbbdef#aa.",
"..###bgh###aa.",
"..aa#bij###aa.",
"..aa#bik##aaa.",
"....#blh##a...",
"....#bmj##a...",
"....#bdn##a...",
"....#opq##a...",
"....######a...",
"....aa###aa..."};

static const char* const image2_data[] = {
"16 16 9 1",
". c None",
"# c #000000",
"g c #313031",
"c c #5a595a",
"f c #838183",
"b c #a4a1a4",
"e c #c5c2c5",
"a c #dedede",
"d c #ffffff",
".....##a#.......",
"..###ab#c####...",
".#dddeeef#eeb#..",
".#abedddeeccc#..",
"..#faabbbbff#...",
"..#bbbffccfg#...",
"..#bdbabffcg#...",
"..#bdbabffcg#...",
"..#bdbabffcg#...",
"..#bdbabffcg#...",
"..#bdbabffcg#...",
"..#bdbabffcg#...",
"..#bdbabffcg#...",
"..#adbabffcg#...",
"...##aabbf##....",
".....#####......"};

static const char* const image3_data[] = {
"16 16 5 1",
". c None",
"# c #000000",
"c c #c5c200",
"a c #ffffc5",
"b c #ffffff",
"......##........",
"......#a###.....",
".....#ababa###..",
".....#bcbbbaba##",
"....#abbcccbaba#",
"....#abbbabccaa#",
"...#abcbababaaa#",
"...#babcccbabac#",
"..#babababccaa#.",
".#aacaaabaaaaa#.",
"#aaaacccababaa#.",
"#caaaaaacccaac#.",
".##caaaaaaaaa#..",
"...###caaaaac#..",
"......###cac#...",
".........###...."};

static const char* const image4_data[] = {
"14 14 98 2",
"#F c None",
"#v c None",
"#C c None",
"#D c None",
"#n c None",
"#A c None",
".f c None",
".A c None",
".# c None",
".g c None",
"Qt c None",
"#E c #004800",
"#B c #004c00",
"#u c #005000",
"#z c #005500",
"#h c #005900",
"#a c #005d00",
"#g c #006100",
".3 c #006500",
"## c #006900",
"#m c #006d00",
"#w c #007100",
"#o c #007500",
"#f c #007900",
"#l c #008100",
"#i c #107110",
"#j c #107910",
"#p c #108110",
".Y c #18ae18",
"#b c #206120",
".4 c #295929",
".P c #29b629",
".U c #316931",
".p c #319131",
".Z c #31b231",
".o c #398939",
".x c #399939",
".O c #39b639",
".c c #416141",
".d c #416d41",
".n c #418941",
".w c #41a541",
".G c #41b641",
".b c #4a714a",
".e c #4a814a",
".V c #4a8d4a",
".H c #4ab24a",
".F c #4aba4a",
".M c #528552",
".m c #529152",
".l c #529552",
".v c #52ae52",
".E c #52be52",
".T c #5a955a",
".a c #628d62",
".2 c #629162",
".j c #629562",
".k c #629962",
".u c #62b662",
".D c #62be62",
".i c #6a9d6a",
".q c #6aa56a",
".B c #6aaa6a",
".N c #6ab26a",
".r c #73a573",
".h c #73aa73",
".s c #73ae73",
".t c #73b673",
".C c #73ba73",
".5 c #7b997b",
"#y c #7ba57b",
"#. c #7bae7b",
".L c #83ae83",
"#t c #83b683",
"#e c #83ba83",
"#c c #8b9d8b",
".z c #94b294",
".y c #9caa9c",
"#x c #9cb69c",
".W c #9cc29c",
"#k c #a4bea4",
".K c #acaaac",
"#q c #acc2ac",
".J c #bdbabd",
".I c #bdcabd",
".X c #c5d6c5",
".7 c #c5dac5",
".S c #cdcacd",
".1 c #cdcecd",
".6 c #d5d2d5",
".Q c #d5ded5",
".8 c #d5e2d5",
".R c #dedade",
"#s c #dedede",
"#r c #e6dee6",
".0 c #e6e2e6",
"#d c #e6e6e6",
".9 c #eee6ee",
"QtQtQt.#.a.b.c.d.e.fQtQtQtQt",
"Qt.g.h.i.j.k.l.m.n.o.p.gQtQt",
"Qt.q.r.s.t.u.u.v.w.x.y.zQtQt",
".A.k.B.C.D.E.F.G.H.I.J.K.LQt",
".M.m.N.D.E.O.P.G.Q.R.S.K.TQt",
".U.V.W.X.O.Y.Z.Q.0.0.1.2.3Qt",
".4.5.6.0.7.G.8.0.9.0#.###aQt",
"#b#c.1.0.0.0.0#d.0#e#f#g#hQt",
"#i#j#k.R.0.0.9.0#e#l#m#h#hQt",
"#n#o#p#q.R#r#s#t#f#m#a#u#vQt",
"Qt#f#w#j#x#x#y#w###h#u#zQtQt",
"Qt#A#w.3#a#g#h#z#B#B#u#CQtQt",
"QtQtQt#D#g#u#B#E#B#FQtQtQtQt",
"QtQtQtQtQtQtQtQtQtQtQtQtQtQt"};

static const char* const image5_data[] = {
"14 14 43 1",
"E c None",
". c None",
"# c #000000",
"N c #100c08",
"O c #202020",
"I c #313029",
"x c #4a4839",
"M c #4a4c41",
"C c #524c41",
"q c #525041",
"B c #5a594a",
"u c #7bff7b",
"y c #83856a",
"D c #838573",
"v c #94917b",
"t c #a4a18b",
"A c #a4a58b",
"p c #b46d31",
"F c #b47131",
"J c #b4ae94",
"m c #b4b2b4",
"H c #bdb69c",
"l c #bdb6bd",
"g c #cd9d73",
"d c #d5a562",
"f c #d5aa62",
"w c #d5ceac",
"L c #d5d2b4",
"e c #deaa6a",
"n c #ded6de",
"z c #dedabd",
"k c #dedade",
"s c #e6e2bd",
"h c #eed6b4",
"a c #eed6bd",
"o c #f6eef6",
"G c #f6f2cd",
"K c #f6f6cd",
"r c #fffad5",
"j c #fffaff",
"b c #ffffd5",
"c c #ffffde",
"i c #ffffff",
"..............",
"..............",
".######.......",
"#abcbcd####...",
"#aefefedede#g.",
"#ade##########",
"#he#iijklmnoj#",
"#apqbrstuuvwxy",
"#a#irzABuuCD#E",
"#FqbGHuuuuuuIE",
"#fibGJuuuuuu#E",
"#ibcKLvMuuNO#E",
".#######uu##EE",
".EEEEEE####EEE"};

static const char* const image6_data[] = {
"14 14 99 2",
"Qt c None",
".# c None",
".l c #000000",
"#y c #080808",
"#G c #101008",
"#r c #101010",
"#j c #101410",
"#a c #101810",
".n c #181818",
".4 c #181c18",
".J c #182018",
".U c #202420",
"#E c #202820",
"#z c #292c29",
".d c #293029",
".e c #313031",
"#F c #313429",
"#s c #313831",
".k c #393c31",
"#k c #394039",
"#D c #414841",
".x c #4a554a",
".b c #4a594a",
".a c #525052",
".m c #52594a",
"#g c #525952",
"#w c #525d52",
".P c #5a4c4a",
"#. c #5a595a",
".B c #5a5d52",
".C c #624c52",
".1 c #625552",
"#p c #626562",
".S c #626962",
"## c #626d5a",
"#q c #626d62",
".3 c #627162",
"#i c #6a6d62",
"#A c #6a7562",
"#x c #6a756a",
".D c #73656a",
".Q c #73696a",
"#b c #737d6a",
".V c #738573",
".F c #7b817b",
"#C c #7b857b",
"#t c #7b897b",
"#o c #7b917b",
".c c #838d83",
".8 c #839583",
".o c #8b7d7b",
"#h c #8b8583",
".h c #8b858b",
".s c #8b898b",
".t c #8b8d8b",
".j c #8b9183",
".9 c #8b918b",
"#B c #8b9d8b",
".T c #8ba183",
".0 c #94918b",
".O c #949994",
".G c #949d94",
".y c #94a18b",
".w c #94a194",
".Z c #94aa94",
".i c #9c999c",
".R c #9ca19c",
"#v c #9ca59c",
".I c #9caa9c",
"#f c #9cb29c",
"#n c #a4b29c",
"#u c #a4b2a4",
".N c #a4b69c",
"#m c #a4b6a4",
".A c #a4baa4",
".g c #aca5ac",
".r c #acaaac",
"#e c #acbeac",
".7 c #acc2ac",
".p c #b4b2b4",
".u c #b4beb4",
"#l c #b4c2ac",
".6 c #b4cab4",
".E c #bdb6bd",
".H c #bdc6b4",
"#d c #bdceb4",
".Y c #bdd2bd",
".5 c #bdd6bd",
".2 c #c5bec5",
".f c #c5c2c5",
".v c #c5cac5",
"#c c #c5d6c5",
".K c #c5dec5",
".q c #cdcacd",
".X c #cddecd",
".M c #cde2cd",
".L c #d5eacd",
".W c #d5ead5",
".z c #d5eed5",
"QtQtQtQtQtQtQtQtQtQtQtQtQtQt",
"QtQt.#.a.b.c.dQtQtQtQtQtQtQt",
"QtQt.e.f.g.h.i.j.d.k.eQt.lQt",
".b.m.n.o.p.q.r.s.t.u.v.w.xQt",
".y.z.A.B.C.D.E.q.r.F.G.H.I.J",
".J.K.L.M.N.O.P.Q.p.q.R.S.T.U",
"Qt.V.W.M.X.Y.Z.0.1.Q.2.t.3.4",
"Qt.4.Y.X.5.Y.6.7.8.9#..t###a",
"QtQt#b.Y#c#d.6.7#e#f#g#h#i#j",
"QtQtQt#k.8#l.7#e#m#n#o#p#q#r",
"QtQtQtQt.l#s#t#n#u.I#v#w#x#y",
"QtQtQtQtQtQt.l#z#A.w#B#C#D#y",
"QtQtQtQtQtQtQtQt.l#E.x#t#F.l",
"QtQtQtQtQtQtQtQtQtQtQt#y#GQt"};


/*
 *  Constructs a EditAlbumForm which is a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
EditAlbumForm::EditAlbumForm( QWidget* parent,  const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    QPixmap image0( ( const char** ) image0_data );
    QPixmap image1( ( const char** ) image1_data );
    QPixmap image2( ( const char** ) image2_data );
    QPixmap image3( ( const char** ) image3_data );
    QPixmap image4( ( const char** ) image4_data );
    QPixmap image5( ( const char** ) image5_data );
    QPixmap image6( ( const char** ) image6_data );

    if ( !name )
	setName( "EditAlbumForm" );
    resize( 229, 251 );
    setCaption( tr( "Edit Album" ) );
    ID2load = "";
    timer = new QTimer(this );
    connect( timer, SIGNAL(timeout()), this, SLOT(genList()) );


    optional = new QWidgetStack(this);
    optional->setGeometry( QRect( 48, 136, 180, 105 ) );

    optional2 = new QWidgetStack(this);
    optional2->setGeometry( QRect( 2, 139, 40, 100 ) );

    UpButton = new QPushButton( this, "UpButton" );
    UpButton->setGeometry( QRect( 5, 23, 35, 21 ) );
    UpButton->setEnabled(FALSE);
    UpButton->setText( tr( "" ) );
    UpButton->setPixmap( image1 );
    connect( UpButton, SIGNAL( clicked() ), this, SLOT( goUp() ) );

    DownButton = new QPushButton( this, "DownButton" );
    DownButton->setGeometry( QRect( 5, 45, 35, 21 ) );
    DownButton->setEnabled(FALSE);
    DownButton->setText( tr( "" ) );
    DownButton->setPixmap( image0 );
    connect( DownButton, SIGNAL( clicked() ), this, SLOT( goDown() ) );

    DelAlbumButton = new QPushButton( this, "DelAlbumButton" );
    DelAlbumButton->setGeometry( QRect( 5, 67, 35, 22 ) );
    DelAlbumButton->setEnabled(FALSE);
    DelAlbumButton->setText( tr( "" ) );
    DelAlbumButton->setPixmap( image2 );
    connect( DelAlbumButton, SIGNAL( clicked() ), this, SLOT( del() ) );



    EditAlbumButton = new QPushButton( this, "EditAlbumButton" );
    EditAlbumButton->setGeometry( QRect( 5, 89, 35, 22 ) );
    EditAlbumButton->setEnabled(FALSE);
    EditAlbumButton->setText( tr( "" ) );
    EditAlbumButton->setPixmap( image3 );
    connect( EditAlbumButton, SIGNAL( clicked() ), this, SLOT( edit() ) );
    //ButtonLayout->addWidget( DelAlbumButton );

    XportButton = new QPushButton( this, "XportButton" );
    XportButton->setGeometry( QRect( 1, 112, 42, 23 ) );
    XportButton->setToggleButton( TRUE );
    XportButton->setEnabled(FALSE);
    XportButton->setText( tr( "X-port" ) );
    connect( XportButton, SIGNAL( clicked() ), this, SLOT( showXport() ) );



    Listinvi = new QListView( this/*privateLayoutWidget_2*/, "Listinvi" );
    Listinvi->addColumn( tr( "Index" ) );
    Listinvi->addColumn( tr( "FileID" ) );
    Listinvi->setSorting(0);
    Listinvi->setGeometry( QRect( 48, 25, 180, 105 ) );

    FileList = new QListView( this/*privateLayoutWidget_2*/, "FileList" );
    FileList->addColumn( tr( "Index" ) );
    FileList->addColumn( tr( "Name" ) );
    FileList->addColumn( tr( "Description" ) );
    FileList->setSorting(0);
    FileList->setGeometry( QRect( 48, 25, 180, 105 ) );
    //ListLayout->addWidget( FileList );

    AlbumList = new QListView( optional/*privateLayoutWidget_2*/, "AlbumList" );
    AlbumList->addColumn( tr( "Album ID"));
    AlbumList->addColumn( tr( "Album Name" ) );
    AlbumList->setGeometry( QRect( 48, 136, 180, 105 ) );
    connect( AlbumList, SIGNAL( clicked(QListViewItem*) ), this, SLOT( viewe(QListViewItem*) ) );

    List2Export = new QListView( optional/*privateLayoutWidget_2*/, "List2Export" );
    List2Export->addColumn( tr( "Name" ) );
    List2Export->addColumn( tr( "Description"));
    List2Export->addColumn( tr( "File Name"));
    List2Export->setGeometry( QRect( 48, 136, 180, 105 ) );
    connect( List2Export, SIGNAL( clicked(QListViewItem*) ), this, SLOT( getItemXport() ) );

    inAlbum = new QListView( optional/*privateLayoutWidget_2*/, "inAlbum" );
    inAlbum->addColumn( tr( "Index"));
    inAlbum->addColumn( tr( "Name" ) );
    inAlbum->addColumn( tr( "Description"));
    inAlbum->setGeometry( QRect( 48, 136, 180, 105 ) );
    inAlbum->setSorting(0);
    connect( inAlbum, SIGNAL( clicked(QListViewItem*) ), this, SLOT( getNameA(QListViewItem*) ) );

    optional->addWidget(List2Export,0);
    optional->addWidget(AlbumList,1);
    optional->addWidget(inAlbum,2);
    optional->raiseWidget(1);

    QWidget* privateLayoutWidget_3 = new QWidget( this, "AlbumLayout" );
    privateLayoutWidget_3->setGeometry( QRect( 10, 0, 210, 24 ) );
    AlbumLayout = new QHBoxLayout( privateLayoutWidget_3 );
    AlbumLayout->setSpacing( 6 );
    AlbumLayout->setMargin( 0 );

    AlbumPath = new QLineEdit( privateLayoutWidget_3, "AlbumPath" );
    AlbumLayout->addWidget( AlbumPath );

    SearchAlbum = new QToolButton( privateLayoutWidget_3, "SearchAlbum" );
    SearchAlbum->setText( tr( "..." ) );
    AlbumLayout->addWidget( SearchAlbum );
    connect( SearchAlbum, SIGNAL( clicked() ), this, SLOT(findAlbum()));

    XGroup = new QGroupBox( this, "XGroup" );
    XGroup->setGeometry( QRect( 1, 127, 44, 140 ) );
    XGroup->setTitle( tr( "" ) );

    AddXButton = new QToolButton( XGroup, "AddXButton" );
    AddXButton->setGeometry( QRect( 5, 10, 28, 21 ) );
    AddXButton->setText( tr( "" ) );
    AddXButton->setPixmap( image5 );
    connect( AddXButton, SIGNAL( clicked() ), this, SLOT(Add2Xport()));

    DelXButton = new QToolButton( XGroup, "DelXButton" );
    DelXButton->setGeometry( QRect( 5, 40, 28, 21 ) );
    DelXButton->setEnabled(FALSE);
    DelXButton->setText( tr( "" ) );
    DelXButton->setPixmap( image2 );
    connect( DelXButton, SIGNAL( clicked() ), this, SLOT(DelXport()));

    OKXButton3 = new QToolButton( XGroup, "OKXButton3" );
    OKXButton3->setGeometry( QRect( 5, 70, 28, 21 ) );
    OKXButton3->setText( tr( "OK" ) );
    OKXButton3->setEnabled(FALSE);
    connect( OKXButton3, SIGNAL( clicked() ), this, SLOT(XportOK()));

    privateLayout = new QGroupBox( this, "privateLayout" );
    privateLayout->setGeometry( QRect( 0, 127, 45, 140 ) );
    privateLayout->setLineWidth( 0 );
    privateLayout->setTitle( tr( "" ) );

    /*removeFileButton = new QPushButton( privateLayout, "removeFileButton" );
    removeFileButton->setGeometry( QRect( 4, 0, 30, 21 ) );
    removeFileButton->setText( tr( "Del" ) );
    removeFileButton->setEnabled(FALSE);
    connect( removeFileButton, SIGNAL( clicked() ), this, SLOT(delFileDB()));*/

    SaveIndexButton = new QPushButton( privateLayout, "SaveIndexButton" );
    SaveIndexButton->setGeometry( QRect( 3, 28, 35, 23 ) );
    SaveIndexButton->setText( tr( "" ) );
    SaveIndexButton->setPixmap( image4 );
    SaveIndexButton->setEnabled(FALSE);
    connect( SaveIndexButton, SIGNAL( clicked() ), this, SLOT(saveIndex()));

    OpenButton = new QPushButton( privateLayout, "OpenButton" );
    OpenButton->setGeometry( QRect( 3, 73, 35, 23 ) );
    OpenButton->setText( tr( "" ) );
    OpenButton->setPixmap( image6 );
    OpenButton->setToggleButton( TRUE );
    OpenButton->setEnabled(FALSE);
    connect( OpenButton, SIGNAL( clicked() ), this, SLOT(Op2F()));

    FileText = new QLabel( privateLayout, "FileText" );
    FileText->setGeometry( QRect( 3, 56, 42, 10 ) );
    FileText->setText( tr( "Album :" ) );


    AddFileButton = new QPushButton( privateLayout, "AddFileButton" );
    AddFileButton->setGeometry( QRect( 3, 0, 35, 23 ) );
    AddFileButton->setEnabled(FALSE);
    AddFileButton->setText( tr( "" ) );
    AddFileButton->setPixmap( image5 );
    connect( AddFileButton, SIGNAL( clicked() ), this, SLOT( add() ) );

    optional2->addWidget(XGroup,0);
    optional2->addWidget(privateLayout,1);
    optional2->raiseWidget(1);
    
    timer->start( 10,true );

}

/*
 *  Destroys the object and frees any allocated resources
 */
EditAlbumForm::~EditAlbumForm()
{
    // no need to delete child widgets, Qt does it all for us
}

void EditAlbumForm::viewe(QListViewItem *item)
{
        //removeFileButton->setEnabled(TRUE);
	if (item == NULL) return;
        OpenButton->setEnabled(TRUE);
    	str = item->text(0);
	Path = item->text(1);
	bool ok;
	int temp = str.toInt(&ok,10);
	str = str.number(temp);


}

void EditAlbumForm::getNameA(QListViewItem *item)
{
        if (item == 0) return;
	NameinAlbum = item->text(0);
	bool ok;
	int temp = NameinAlbum.toInt(&ok,10);
	NameinAlbum = NameinAlbum.number(temp);
	AddFileButton->setEnabled(TRUE);

}

void EditAlbumForm::add()
{
    //setCaption("in loop");
    if(inAlbum->currentItem() == NULL) return;
    int check = 0;
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText1 = NameinAlbum.latin1();
    const char *setText = str.latin1();
    //setCaption(NameinAlbum +"+"+ str);
    rc = sqlite_get_table_printf( db, "select FileID,Name,Description from LINKDB where AlbumID = '%q' and FIndex = '%q';",&result,nrow,ncolumn,errmsg,setText,setText1);
    QString FID1 = result[3];
    QString FName = result[4];
    QString FDescription = result[5];
    const char *setText2 = FName.latin1();
    const char *setText3 = FDescription.latin1();
    rc = sqlite_get_table_printf( db, "select AlbumID, FileID from LINKDB;",&result,nrow,ncolumn,errmsg);
    int j = ((*nrow)+1)*(*ncolumn);
    setText1 = Album2Open.latin1();
    setText = FID1.latin1();
    for (int i=2; i<j ; i = i+2){
        if ((QString(result[i]) == QString(setText1)) && (QString(result[i+1]) == QString(setText)))
	    check = 1;
    }
    //setCaption(QString::number(check));
    if (check == 0)
    {
        rc = sqlite_get_table_printf( db, "select max(FIndex) from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText1);
	QString FIndex = result[1];
	bool ok;
	int temp = FIndex.toInt(&ok,10);
	temp++;
	FIndex = FIndex.number(temp);
	const char *setText4 = FIndex.latin1();
	//setCaption(Album2Open+"+"+FID+"+"+FName+"+"+FDescription+"+"+FIndex);
        rc = sqlite_get_table_printf( db, "insert into LINKDB values ('%q','%q','%q','%q','%q');",&result,nrow,ncolumn,errmsg,setText1,setText,setText2,setText3,setText4);
	QListViewItem* item2Add = new QListViewItem(Listinvi);
        item2Add->setText(0,FIndex);
	item2Add->setText(1,FID1);
    }
    else
    {
        QMessageBox::information( this, "Multimedia Album",
                            "Unable to add new file.\n"
                            "The system abort your request." );
    }
    sqlite_free_table(result);
    reloadAlbum();
}
void EditAlbumForm::del()
{
    switch( QMessageBox::warning( this, "Delete file from Album",
                                "You want to delete this from Album.\n"
                                "Are you sure???\n\n",
                                "Yes", "No", 0, 1 ))
    {
    case 0:
      break;
    case 1:
      {
        return;
	break;
      }
    }
    QListViewItem* item2del = FileList->currentItem();
    QString Row2del = item2del->text(0);
    QString Name2del = item2del->text(1);
    QString Des2del = item2del->text(2);
    bool ok;
    int id = Row2del.toInt(&ok,10);
    Row2del = Row2del.number(id);
    QListViewItemIterator it(Listinvi);
    QString FID;
    for (; it.current(); ++it)
    {
       if (Row2del == it.current()->text(0))
          FID = it.current()->text(1);
    }
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = FID.latin1();
    const char *setText3 = Album2Open.latin1();
    rc = sqlite_get_table_printf( db, "delete from LINKDB where FileID = '%q' and AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText,setText3);
    rc = sqlite_get_table_printf( db, "select FilePath from FILEDB where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    const char *setText2 = result[1];
    setText = Name2del.latin1();
    setText3 = Des2del.latin1();
    rc = sqlite_get_table_printf( db, "delete from Xport where Name = '%q' and Description = '%q' and FilePath = '%q';",&result,nrow,ncolumn,errmsg,setText,setText3,setText2);
    QListViewItemIterator it1(Listinvi);
    rc = sqlite_get_table_printf( db, "select count(*) from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText3);
    QString countZero = result[1];
    int countZ = countZero.toInt(&ok,10);
    if(countZ>0)
    for (; it1.current(); ++it1)
    {
       if (FID == it1.current()->text(1))
          Listinvi->removeItem(it1.current());
       int check = (it1.current()->text(0)).toInt(&ok,10);
       if ((check-id) == 1)
       {
          it1.current()->setText(0,QString::number(id,10));
	  id = check;
       }
    }
    else
    Listinvi->clear();
    sqlite_free_table(result);
    saveIndex();
    reloadAlbum();
    //setCaption(result[1]);

}
void EditAlbumForm::findAlbum()
{
    OpenAlbumForm* OA = new OpenAlbumForm(this, NULL, true, true);
    OA->db = db;
    OA->exec();
    Album2Open = OA->AlbumName;
    if (Album2Open == "0") return;
    AlbumPath->setText(OA->NameAlbum);
    Albumnow = OA->NameAlbum;
    bool ok;
    int temp = Album2Open.toInt(&ok,10);
    Album2Open = Album2Open.number(temp);
    loadAlbum(Album2Open);

}
void EditAlbumForm::loadAlbum( const QString &filename )
{
    FileList->clear();
    Listinvi->clear();
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = filename.latin1();
    setCaption("Album Name : " + Albumnow);
    DelAlbumButton->setEnabled(TRUE);
    EditAlbumButton->setEnabled(TRUE);
    UpButton->setEnabled(TRUE);
    DownButton->setEnabled(TRUE);
    XportButton->setEnabled(TRUE);
    SaveIndexButton->setEnabled(TRUE);
    rc = sqlite_get_table_printf( db, "select Name,Description,FIndex,FileID from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    int j = ((*nrow)+1)*(*ncolumn);
    FileList->clear();
    QString test[j];
    for (int i = 4 ; i<j; i=i+4)
	{//printf("%s \n", result[i]);
	test[i] = result[i];
	test[i+1] = result[i+1];
	test[i+2] = result[i+2];
	QString FID = result[i+3];
	QListViewItem *item3 = new QListViewItem( FileList );
        item3->setText(1,test[i]);
        item3->setText(2,test[i+1] );
        item3->setText(0,test[i+2].rightJustify(4,'0') );
	QListViewItem *item4 = new QListViewItem( Listinvi );
        item4->setText(0,test[i+2]);
	item4->setText(1,FID);
	}
    sqlite_free_table(result);
    rc = sqlite_get_table_printf( db, "delete from Xport;",&result,nrow,ncolumn,errmsg);
}

void EditAlbumForm::edit()
{
    EditPropertyForm* EP = new EditPropertyForm(this, NULL, true, true);
    QListViewItem* item2edit = FileList->currentItem();
    QString Row2edit = item2edit->text(0);
    bool ok;
    int temp = Row2edit.toInt(&ok,10);
    Row2edit = Row2edit.number(temp,10);
    QString Name2edit = item2edit->text(1);
    QString Des2edit = item2edit->text(2);
    EP->RowID = Row2edit;
    EP->RowName = Name2edit;
    EP->RowDes = Des2edit;
    EP->exec();
    //setCaption(Row2edit);
    QListViewItemIterator it(Listinvi);
    QString FID;
    for (; it.current(); ++it)
    {
       if (Row2edit == it.current()->text(0))
          FID = it.current()->text(1);
    }
    Name2edit = EP->NameLineEdit->text();
    Des2edit = EP->DesLineEdit->text();
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = FID.latin1();
    const char *setText1 = Name2edit.latin1();
    const char *setText2 = Des2edit.latin1();
    const char *setText3 = Album2Open.latin1();
    //setCaption(FID);
    rc = sqlite_get_table_printf( db, "update LINKDB set Name = '%q', Description = '%q' where FileID = '%q' and AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText1,setText2,setText,setText3);
    reloadAlbum();


}

void EditAlbumForm::genList()
{
    gen();
}

void EditAlbumForm::reloadAlbum()
{
    FileList->clear();

    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = Album2Open.latin1();
    rc = sqlite_get_table_printf( db, "select Name,Description,FileID from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText);
    int j = ((*nrow)+1)*(*ncolumn);
    QString test[j];
    //setCaption(QString::number(j,10));
    for (int i = 3 ; i<j; i=i+3)
    {
	test[i] = result[i];
	test[i+1] = result[i+1];
	test[i+2] = result[i+2];
	//setCaption(test[i]);
	QListViewItemIterator it(Listinvi);
	QString FID;
	for (; it.current(); ++it)
	{
	   if (test[i+2] == it.current()->text(1))
	      FID = it.current()->text(0);
	}
	QListViewItem *item3 = new QListViewItem( FileList );
        item3->setText(1,test[i]);
        item3->setText(2,test[i+1] );
        item3->setText(0,FID.rightJustify(4,'0') );
    }
    sqlite_free_table(result);
}

void EditAlbumForm::showXport()
{
    if (XportButton->isOn())
    {
       optional->raiseWidget(0);
       optional2->raiseWidget(0);
       EditAlbumButton->setEnabled(FALSE);
       AddFileButton->setEnabled(FALSE);
       DelAlbumButton->setEnabled(FALSE);
       int rc;
       char **result = new char*;
       int *nrow = new int;
       int *ncolumn = new int;
       char **errmsg = new char*;
       QString Filename;
       rc = sqlite_get_table_printf( db, "select distinct * from Xport;",&result,nrow,ncolumn,errmsg);
       int j = ((*nrow)+1)*(*ncolumn);
       List2Export->clear();
       for (int i = 3 ; i<j; i=i+3)
	{
	  QFileInfo fi( result[i+2] );
	  Filename = fi.fileName();
	  QListViewItem *item3 = new QListViewItem( List2Export );
	  item3->setText(0,QString::QString(result[i]));
          item3->setText(1,QString::QString(result[i+1]));
	  item3->setText(2,Filename);
	}
       sqlite_free_table(result);
    }else
    {
       optional->raiseWidget(1);
       optional2->raiseWidget(1);
       EditAlbumButton->setEnabled(TRUE);
       AddFileButton->setEnabled(TRUE);
       DelAlbumButton->setEnabled(TRUE);
    }
}

void EditAlbumForm::saveIndex()
{
   int rc;
   char ***result = new char**;
   int *nrow = new int;
   int *ncolumn = new int;
   char **errmsg = new char*;
   const char *setText = new char;
   const char *setText1 = new char;
   const char *setText2 = Album2Open.latin1();
   QString FIndex;
   QString FID;
   QListViewItemIterator it(Listinvi);
   for (; it.current(); ++it)
   {
       FIndex = it.current()->text(0);
       FID = it.current()->text(1);
       setText = FIndex.latin1();
       setText1 = FID.latin1();
       rc = sqlite_get_table_printf( db, "update LINKDB set FIndex = '%q' where FileID = '%q' and AlbumID = '%q';",result,nrow,ncolumn,errmsg,setText,setText1,setText2);
   }
}

void EditAlbumForm::gen()
{
    AlbumList->clear();
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    rc = sqlite_get_table_printf( db, "select * from ALBUMDB;",&result,nrow,ncolumn,errmsg);
    int j = ((*nrow)+1)*(*ncolumn);
    QString test[j];
    for (int i = 2 ; i<j; i=i+2)
	{//printf("%s \n", result[i]);
	test[i] = result[i];
	test[i+1] = result[i+1];
	QListViewItem *item3 = new QListViewItem( AlbumList );
	item3->setText(1,test[i+1]);
        item3->setText(0,test[i].rightJustify(4,'0') );
	}
    sqlite_free_table(result);
}

void EditAlbumForm::delFileDB()  //don't use anymore-- just right now
{
    switch( QMessageBox::warning( this, "Delete file from Database",
                                "You want to delete this file from Database.\n"
                                "Are you sure???\n\n",
                                "Yes", "No", 0, 1 ))
    {
    case 0:
      {
      int rc;
      char **result = new char*;
      int *nrow = new int;
      int *ncolumn = new int;
      char **errmsg = new char*;
      const char *setText = str.latin1();
      rc = sqlite_get_table_printf( db, "delete from FILEDB where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText);
      rc = sqlite_get_table_printf( db, "delete from LINKDB where FileID = '%q';",&result,nrow,ncolumn,errmsg,setText);
      gen();
      reloadAlbum();
      //removeFileButton->setEnabled(FALSE);
      OpenButton->setEnabled(FALSE);
      break;
      }
    case 1:
      break;
    }

}

void EditAlbumForm::Add2Xport()
{
    OKXButton3->setEnabled(TRUE);
    QListViewItem* item2edit = FileList->currentItem();
    QString ID2Xport = item2edit->text(0);
    bool ok;
    int temp = ID2Xport.toInt(&ok,10);
    ID2Xport = ID2Xport.number(temp);
    QListViewItemIterator it(Listinvi);
    QString FID;
    for (; it.current(); ++it)
    {
       if (ID2Xport == it.current()->text(0))
          FID = it.current()->text(1);
    }
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = FID.latin1();
    const char *setText1 = Album2Open.latin1();
    rc = sqlite_get_table_printf( db, "select LINKDB.Name,LINKDB.Description,FILEDB.FilePath from FILEDB,LINKDB where LINKDB.AlbumID='%q' and LINKDB.FileID = '%q' and FILEDB.FileID='%q';",&result,nrow,ncolumn,errmsg,setText1,setText,setText);
    QString Filename;
    setText = result[3];
    setText1 = result[4];
    char *setText2 = result[5];
    rc = sqlite_get_table_printf( db, "select count(FilePath) from Xport where FilePath='%q';",&result,nrow,ncolumn,errmsg,setText2);
    QString countt = result[1];
    int countFP = countt.toInt(&ok,10);
    if (countFP > 0)
    {
       QMessageBox::information( this, "Multimedia Album",
                            "Unable to add new file.\n"
                            "There is exist file in Xport." );
       return;
    }
    rc = sqlite_get_table_printf( db, "insert into Xport values('%q','%q','%q');",&result,nrow,ncolumn,errmsg,setText,setText1,setText2);
    rc = sqlite_get_table_printf( db, "select distinct * from Xport;",&result,nrow,ncolumn,errmsg);
    int j = ((*nrow)+1)*(*ncolumn);
    List2Export->clear();
    for (int i = 3 ; i<j; i=i+3)
	{
	  QFileInfo fi( result[i+2] );
	  Filename = fi.fileName();
	  QListViewItem *item3 = new QListViewItem( List2Export );
	  item3->setText(0,QString::QString(result[i]));
          item3->setText(1,QString::QString(result[i+1]));
	  item3->setText(2,Filename);
	}
    sqlite_free_table(result);

}

void EditAlbumForm::getItemXport()
{
    DelXButton->setEnabled(TRUE);
}

void EditAlbumForm::DelXport()
{
    QListViewItem* item2del = List2Export->currentItem();
    QString Namedel = item2del->text(0);
    QString Desdel = item2del->text(1);
    QString FileNamedel = item2del->text(2);
    DelXButton->setEnabled(FALSE);
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    const char *setText = Namedel.latin1();
    const char *setText1 = Desdel.latin1();
    rc = sqlite_get_table_printf( db, "select FilePath from Xport where Name = '%q' and Description = '%q';",&result,nrow,ncolumn,errmsg,setText,setText1);
    int j = (*nrow)+1;
    for (int h=1; h<j; h++)
    {
       QString FileP = result[h];
       QFileInfo PFile(FileP);
       QString PathofFile = FileP;
       FileP = PFile.fileName();
       if(FileP == FileNamedel)
          FileNamedel = PathofFile;
    }
    const char *setText2 = FileNamedel.latin1();
    rc = sqlite_get_table_printf( db, "delete from Xport where Name = '%q' and Description = '%q' and FilePath = '%q';",&result,nrow,ncolumn,errmsg,setText,setText1,setText2);
    rc = sqlite_get_table_printf( db, "select distinct * from Xport;",&result,nrow,ncolumn,errmsg);
    j = ((*nrow)+1)*(*ncolumn);
    QString Filename;
    List2Export->clear();
    for (int i = 3 ; i<j; i=i+3)
	{
	  QFileInfo fi( result[i+2] );
	  Filename = fi.fileName();
	  QListViewItem *item3 = new QListViewItem( List2Export );
	  item3->setText(0,QString::QString(result[i]));
          item3->setText(1,QString::QString(result[i+1]));
	  item3->setText(2,Filename);
	}
    sqlite_free_table(result);
}

void EditAlbumForm::XportOK()
{
    XportF* XF = new XportF(this, NULL, true, true);
    XF->exec();
    int okX = XF->okX;
    int via = XF->via;
    if (okX == 0) return;
    //XportForm* XP = new XportForm(this, NULL, true, true);
    //XP->exec();
    QString xportname = "export.maa";//XP->NameLine->text();
    //QString NameCheck = xportname.right(4);
    //if (NameCheck != ".maa")
    //   xportname = xportname + ".maa";
    //OpenPathForm* OP = new OpenPathForm(this, NULL, true, true);
    //OP->exec();
    QString xportpath = "/mnt/hda/";//OP->Path2Sent;
    //QString pathCheck = xportpath.right(2);
    //int pathL = xportpath.length();
    //if (pathCheck == "..")
    //{
    // xportpath.replace( pathL-2, 2, "" );
    //}
    //else {
    // xportpath = xportpath + "/";
    //}
    QString NameMaa = "/root/Documents/export.maa";
    xportname = xportpath + xportname;
    QFile f( NameMaa );
    if ( !f.open( IO_WriteOnly ) )
        return;
    QTextStream t( &f );
    QListViewItemIterator it( List2Export );
    for ( ; it.current(); ++it )
        for ( unsigned int i = 0; i < 3; i++ )
            t << it.current()->text( i ) << "\n";
    f.close();
    QStringList list;
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;
    rc = sqlite_get_table_printf( db, "select distinct FilePath from Xport;",&result,nrow,ncolumn,errmsg);
    int j = (*nrow)+1;
    for (int i = 1;i<j;i++)
       list.append( QString::QString(result[i]) );

    if (okX == 1)
    {
       if(via == 0)
       {
	  Ir test;
          if(!test.supported())
	  {
	     QMessageBox::critical(this, "Export via IrDa", "The IrDa not support"  ,QString("Ok") );
	     return;
	  }
	  Ir *fileIR = new Ir(this, "IR");
	  for ( QStringList::Iterator it4 = list.begin(); it4 != list.end(); ++it4 )
          {
             QString FNameSource = *it4;
	     fileIR->send(FNameSource, FNameSource);
          }
  	  fileIR->send(xportname, xportname);
       }
       else
       {
          for ( QStringList::Iterator it3 = list.begin(); it3 != list.end(); ++it3 )
          {
             QString FNameSource = *it3;
             QFileInfo fi( *it3 );
             QString FNameDestination = fi.fileName();
             FNameDestination = xportpath + FNameDestination;
             copyFile(FNameDestination,FNameSource);
          }
	  copyFile(xportname,NameMaa);
       }
    }

    QDir dir("/");
    dir.remove(NameMaa);
    sqlite_free_table(result);
    QMessageBox::information( this, "Multimedia Album",
                            "Export Progress.\n"
                            "Transfer finished." );
}

void EditAlbumForm::Op2F()
{
    int rc;
    char **result = new char*;
    int *nrow = new int;
    int *ncolumn = new int;
    char **errmsg = new char*;

    if (OpenButton->isOn())
    {
       inAlbum->clear();
       optional->raiseWidget(2);
       const char *setText = str.latin1();
       rc = sqlite_get_table_printf( db, "select Name, Description, FIndex from LINKDB where AlbumID = '%q';",&result,nrow,ncolumn,errmsg,setText);
       int j = ((*nrow)+1)*(*ncolumn);
       QString eachFile[j];
       for (int i = 3 ; i<j; i=i+3)
	{
	  eachFile[i] = result[i];
	  eachFile[i+1] = result[i+1];
	  eachFile[i+2] = result[i+2];
	  QListViewItem *item3 = new QListViewItem( inAlbum );
	  item3->setText(1,eachFile[i]);
          item3->setText(2,eachFile[i+1]);
	  item3->setText(0,eachFile[i+2].rightJustify(4,'0'));
	}
       sqlite_free_table(result);
       /*QListViewItem* item = AlbumList->currentItem();
       if (item == 0)
          setCaption("Error");
       else{
          item = item->itemAbove();
	  setCaption(item->text(1));
       }*/
    }
    else
    {
       optional->raiseWidget(1);
        /*QListViewItem* item = AlbumList->currentItem();
       if (item == 0)
          setCaption("Error");
       else {
          item = item->itemBelow();
          setCaption(item->text(1));
       }*/
    }
    gen();


    //removeFileButton->setEnabled(FALSE);
}

bool EditAlbumForm::copyFile( const QString & dest, const QString & src )
{
    char bf[ 50000 ];
    int  bytesRead;
    bool success = TRUE;

    QFile s( src );
    QFile d( dest );

    if( s.open( IO_ReadOnly | IO_Raw ) &&
		d.open( IO_WriteOnly | IO_Raw ) )
    {
		while( (bytesRead = s.readBlock( bf, sizeof( bf ) )) ==
			   sizeof( bf ) )
		{
			if( d.writeBlock( bf, sizeof( bf ) ) != sizeof( bf ) ){
				success = FALSE;
				break;
			}
		}
		if( success && (bytesRead > 0) ){
			d.writeBlock( bf, bytesRead );
		}
    } else {
		success = FALSE;
    }
    return success;
}

void EditAlbumForm::goUp()
{
    QListViewItem* itemUp = FileList->currentItem();
    if (itemUp == NULL) return;
    if (itemUp->itemAbove() == NULL)
       return;
    QString IDBefore = itemUp->text(0);
    itemUp = itemUp->itemAbove();
    QString IDAfter = itemUp->text(0);
    itemUp->setText(0,IDBefore);
    itemUp = itemUp->itemBelow();
    itemUp->setText(0,IDAfter);
    bool ok;
    int ID1st = IDBefore.toInt(&ok,10);
    int ID2nd = IDAfter.toInt(&ok,10);
    IDBefore = IDBefore.number(ID1st,10);
    IDAfter = IDAfter.number(ID2nd,10);
    QListViewItemIterator it(Listinvi);
    for (; it.current(); ++it)
    {
       if (IDAfter == it.current()->text(0))
          it.current()->setText(0,IDBefore);
       else if (IDBefore == it.current()->text(0))
          it.current()->setText(0,IDAfter);
    }
    FileList->sort();
}

void EditAlbumForm::goDown()
{
    QListViewItem* itemDown = FileList->currentItem();
    if (itemDown == NULL) return;
    if (itemDown->itemBelow() == NULL)
       return;
    QString IDBefore = itemDown->text(0);
    itemDown = itemDown->itemBelow();
    QString IDAfter = itemDown->text(0);
    itemDown->setText(0,IDBefore);
    itemDown = itemDown->itemAbove();
    itemDown->setText(0,IDAfter);
    bool ok;
    int ID1st = IDBefore.toInt(&ok,10);
    int ID2nd = IDAfter.toInt(&ok,10);
    IDBefore = IDBefore.number(ID1st,10);
    IDAfter = IDAfter.number(ID2nd,10);
    QListViewItemIterator it(Listinvi);
    for (; it.current(); ++it)
    {
       if (IDAfter == it.current()->text(0))
          it.current()->setText(0,IDBefore);
       else if (IDBefore == it.current()->text(0))
          it.current()->setText(0,IDAfter);
    }
    FileList->sort();
}
