/****************************************************************************
** Form interface generated from reading ui file 'NewAlbum.ui'
**
** Created: Sat Dec 21 01:49:04 2002
**      by:  The User Interface Compiler (uic)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/
#ifndef NEWALBUMFORM_H
#define NEWALBUMFORM_H

#include <qvariant.h>
#include <qdialog.h>

#include "sqlite.h"
class QVBoxLayout; 
class QHBoxLayout; 
class QGridLayout; 
class QLabel;
class QLineEdit;
class QPushButton;
class QToolButton;

class NewAlbumForm : public QDialog
{ 
    Q_OBJECT

public:
    NewAlbumForm( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~NewAlbumForm();

    QPushButton* NewOK;
    QPushButton* NewCancel;
    QLabel* TextName;
    QLineEdit* NameNewAlbum;
    QLabel* TextNew;
    QString NameA;
    QString ID2load;
    sqlite *db;

public slots:
    virtual void saveNew();

protected:
    QHBoxLayout* PathLayout;
    QHBoxLayout* ButtonLayout;
    QHBoxLayout* AlbumNameLayout;
};

#endif // NEWALBUMFORM_H
