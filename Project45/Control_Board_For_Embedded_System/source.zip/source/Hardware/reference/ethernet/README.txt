Schematic reference of Ethernet controller
