<?php
	$dbconfig["DBdomain"]		= "localhost";							// Your Domain Name 
	$dbconfig["DBuser"]			= "root";								// Your User Name
	$dbconfig["DBpass"]			= "sangaroon";									// Your Password
	$dbconfig["DBname"]			= "OlalaDB";							// DabaseName
	$dbconfig["DBAuth"]			= "userpass";							// Table Authentication	
	$dbconfig["DBkmail"]		= "mail_keep";							// Table Keep Mail		
	$dbconfig["DBkattach"]		= "mail_attach";						// Table Keep Mail Attach		
    $dbconfig["DBbook"]		= "addrbook";
    $dbconfig["DBboard1"]    ="boardpost";
    $dbconfig["DBboard2"]    ="boardposter";
    						// Table addr book
?>
