<?php
	$config["domain"]		= "olala02.ce.kmitl.ac.th";		// Your Domain Name
//	$config["domain"]		= "161.246.6.92";		// Your Domain Name
    $config["folder"]		= "/project";							// Your Folder Store
	$config["filename"]		= "/index.php";							// Your Folder Store			
	 // $config["mailserver"]	= "161.246.6.92";				// Your Mail Server
    $config["mailserver"]	= "olala02.ce.kmitl.ac.th";				// Your Mail Server
	$config["mailuser"]		= "chy";								// Your Mail User
	$config["mailpass"]		= "chy";								// Your Mail Password
	$config["mailatt"]		= "attach/";							// Attachment Position
?>
