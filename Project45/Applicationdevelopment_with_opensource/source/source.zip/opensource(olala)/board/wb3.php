<?php
$ttmp =urldecode($auto);
$stmp =urldecode($qid);
//echo $ttmp;
if($ttmp==1) {
header("location:http://$config[domain]$config[folder]$config[filename]?page=300&&subpage=800&&qid=$stmp&&auto=0");

}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">
<?php
 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

$tmp = URLDecode($qid);
include ("board/date1.php");
$today = dateth();
$ip= $REMOTE_ADDR;
////////////////
if($answer!=""){
$tmp = URLDecode($qid);
  $sql="INSERT INTO boardpost(olalaqid,olalatext,olalaposter,olalaip,whenpost)VALUES('$tmp','$post','$answer','$ip','$today')";
  $result = mysql_query($sql);

$sql="update  boardposter set olalalast='$today',olalacount=olalacount+1 where olalaqid='$tmp'";
$result = mysql_query($sql);

}
else {
$query = "select * from boardposter where olalaqid = '$tmp'"; //order rows
$result =mysql_query($query);  // oder rows
$row = mysql_fetch_array($result); //push to array form result
echo "<b><center>��з������� <br><br></center></b>";
echo"<table width=90% >
<tr>
<th width = 20%>����
<th width = 60%> �������ͧ &nbsp &nbsp$row[olalatitlepost]
</table><br>";

$query = "select * from boardposter where olalaqid = '$tmp' "; //order rows
$result =mysql_query($query);  // oder rows
$num = mysql_num_rows($result); //count row
echo"<table  width=90% >";
echo "<tr>";
echo "<td width = 30% >����駡�з�� &nbsp : &nbsp$row[olalaposter] ";
echo "<td width = 70%>
      <hr align= left width = 70% >��駢�ͤ���������ѹ���&nbsp&nbsp $row[olalacreate]";
echo "<tr><td width = 30% rowspan=2 >";
echo "<td width = 70%> $row[olalapost]   ";
echo "<tr>";
echo  "<td width = 70%><B align=right>IP : $row[olalaip]<hr align=left width = 70%>   ";
echo "</table>";



$query = "select * from boardpost where olalaqid = '$tmp'  "; //order rows
$result =mysql_query($query);  // oder rows
$num = mysql_num_rows($result); //count row
echo"<table  width=90% >";
for($i=0;$i<$num;$i++)
{
 $row = mysql_fetch_array($result); //push to array form result
echo "<tr>";
echo "<td width = 30% >$row[olalaposter] ";
echo "<td width = 70%><hr align= left width = 70% >�ͺ��ͤ���������ѹ���&nbsp&nbsp $row[whenpost]";
echo "<tr>";
echo "<td width = 30% rowspan=2 >";
echo "<td width = 70%> $row[olalatext]   ";
echo "<tr>";
echo  "<td width = 70%><B align=right>IP : $row[olalaip]<hr align=left width = 70%>   ";

echo "<tr><tr><tr><tr><tr><tr>";

}
echo "</table><br><Br><br>";


echo "<a href=$config[folder]$config[filename]?page=300&&subpage=600><center>��Ѻ���˹�ҡ�з����ѡ</a>";
echo "<center><br>��駡�з������ <br><br>";

echo "<form action=$config[folder]$config[filename]?page=300&&subpage=800&&qid=$tmp&&auto=1  method =post >";

echo "<br>��ͤ���<br><textarea  rows=10 cols=60 wrap=medium style=font:16pt ms sans serif; name=post></textarea><br>";
echo "���ͺ &nbsp<input type=text size=30 name =answer>";
echo "<br><input type=Submit value=ok> &nbsp";
echo "<input type=Reset value=cancel>";
echo "</form>";
}
mysql_close();
?>
</td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
