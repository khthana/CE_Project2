<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	
					<BR>
	</TR>
	</TABLE><BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		
    <td bgcolor="#FFFFFF">
	<BR>
<div align="center">
<table><tr>
<td><IMG SRC="<?php echo $config["folder"];?>/pic/pigeon.gif" ></td>
<td><font color="#3300FF" size="+1" face="MS Sans Serif, Tahoma, sans-serif">Check Your Group</font></td>
<td><IMG SRC="<?php echo $config["folder"];?>/pic/pigeon.gif" ></td>
</tr>
</table>
</div>
<BR>
<?php
$tgro = urldecode($gro);
$open = urldecode($open);

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
 $bb=$HTTP_COOKIE_VARS["user"];

$query = "select * from insidegroup where username = '$bb'"; //order rows
$result =mysql_query($query);  // oder rows
$num = mysql_num_rows($result); //count row

for($i=0;$i<$num;$i++)
{
$row = mysql_fetch_array($result); //push to array form result
$tmpg = $row[groupname];

$qu = "select * from insidegroup where groupname = '$tmpg' and username<>'$bb' "; //order rows
$re =mysql_query($qu);  // oder rows
$nu = mysql_num_rows($re); //count row

if($tgro==NULL){
 if($nu!=0)  echo "<a href=$config[folder]$config[filename]?page=300&&subpage=900&&gro=$tmpg&&open=1 style=text-decoration:none ><font size = 5>&gt  </font></a>&nbsp<font color =gray> Group :&nbsp<font color =red size =5>$row[groupname]</font><br>";
}

else{
if($nu!=0) echo "<a href=$config[folder]$config[filename]?page=300&&subpage=900&&gro=$tmpg&&open=1 style=text-decoration:none ><font size = 5>&gt</font></a>&nbsp<font color =gray> Group :&nbsp<font color =red size =5>$row[groupname]</font><br>";
}

if(($open==1)and($tgro==$tmpg))
{
$qu1 = "select * from insidegroup where groupname = '$tgro' and username<>'$bb' "; //order rows
$re1 =mysql_query($qu1);  // oder rows
$nu1 = mysql_num_rows($re1); //count row

for($ii=0;$ii<$nu1;$ii++)
{
$ro = mysql_fetch_array($re1); //push to array form result
$tmpu = $ro[username];
echo "<font color =red>&nbsp&nbsp*&nbsp&nbsp&nbsp<font color =green>User :</font><font color =orange>&nbsp&nbsp$tmpu</font></font>";

$que1 = "select * from useronline where user='$tmpu' "; //order rows
$res1 =mysql_query($que1);  // oder rows
$nuu1 = mysql_num_rows($res1); //count row
if($nuu1!=0)  { echo "&nbsp&nbsp&nbsp <font color = red>Online</font> &nbsp &nbsp";  
echo "<a href=$config[folder]$config[filename]?page=400&&subpage=500&&to=$tmpu style=text-decoration:none >sendfile</a>";

//
$qu = "select * from filetomem where userrecive=0 and fromuser='$tmpu' "; //order rows
$re =mysql_query($qu);  // oder rows
$nu= mysql_num_rows($re); //count row
if($nu>0) { 
echo "&nbsp &nbsp &nbsp<a href=$config[folder]$config[filename]?page=400&&subpage=700&&from=$tmpu style=text-decoration:none >recive file</a><br>";
}
else echo "<br>";
//

}

else {  echo "&nbsp&nbsp&nbsp Offline &nbsp &nbsp"; 
echo "<a href=$config[folder]$config[filename]?page=400&&subpage=500&&to=$tmpu style=text-decoration:none >sendfile</a>";
//
$qu = "select * from filetomem where userrecive=0 and fromuser='$tmpu'"; //order rows
$re =mysql_query($qu);  // oder rows
$nu= mysql_num_rows($re); //count row
if($nu>0) { 
echo "&nbsp &nbsp &nbsp <a href=$config[folder]$config[filename]?page=400&&subpage=700&&from=$tmpu style=text-decoration:none >recive file</a><br>";
}
else echo "<br>";
//
}

}//for
}//tgro

}//for


mysql_close();
?>

      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>





