<?
function dateth() {

$x = "";
$a = date("w");
$b = date("n");
$c = date("j");
$d = date("Y") + 543;
$e = date("H:i:s");

switch ($a) {
	case 0:
		$a = "��";
		break;
	case 1:
		$a = "�";
		break;
	case 2:
		$a = "�";
		break;
	case 3:
		$a = "�";
		break;
	case 4:
		$a = "��";
		break;
	case 5:
		$a = "�";
		break;
	case 6:
		$a = "�";
		break;
}

switch ($b) {
	case 1:
		$b = "��";
		break;
	case 2:
		$b = "��";
		break;
	case 3:
		$b = "�դ";
		break;
	case 4:
		$b = "���";
		break;
	case 5:
		$b = "��";
		break;
	case 6:
		$b = "���";
		break;
	case 7:
		$b = "��";
		break;
	case 8:
		$b = "ʤ";
		break;
	case 9:
		$b = "��";
		break;
	case 10:
		$b = "��";
		break;
	case 11:
		$b = "��";
		break;
	case 12:
		$b = "��";
		break;
}
$x = "$a $c $b $d$e";
return $x;
}
?>
