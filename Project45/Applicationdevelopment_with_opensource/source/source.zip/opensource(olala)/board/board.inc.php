<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>


<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	
	</TR><BR>
</TABLE><BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                  <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		
    <td bgcolor="#FFFFFF" align="center">


    <table width="95%" border="0" align="center">	
    <?php
       $bb=$HTTP_COOKIE_VARS["user"];
    mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
    $query = "select * from insidegroup where username='$bb'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
if($num!=0) {
        $tdate = getdate(time());
        $tt=$tdate["mon"];
		echo"<div align=\"right\">";
		echo date("j");	
echo "&nbsp&nbsp&nbsp&nbsp";
if($tt==1) echo "���Ҥ� ";
if($tt==2) echo"����Ҿѹ�";
if($tt==3) echo "�չҤ�";
if($tt==4) echo "����¹" ;
if($tt==5) echo "���Ҥ�"  ;
if($tt==6) echo "�Զع�¹" ;
if($tt==7) echo "�á�Ҥ�"   ;
if($tt==8) echo "�ԧ�Ҥ�" ;
if($tt==9) echo "�ѹ��¹" ;
if($tt==10) echo "���Ҥ� " ;
if($tt==11) echo "��Ȩԡ�¹";
if($tt==12) echo "�ѹ�Ҥ�" ;
echo "  &nbsp;&nbsp;2003  &nbsp;&nbsp;&nbsp;&nbsp;";
echo "</div>";
echo "<BR>";
   selectmonth($mont,0,0);
 echo "<BR><font size = \"+1\">";  
if($mont==1) echo "���Ҥ� ";
if($mont==2) echo"����Ҿѹ�� ";
if($mont==3) echo "�չҤ�";
if($mont==4) echo "����¹" ;
if($mont==5) echo "���Ҥ�"  ;
if($mont==6) echo "�Զع�¹" ;
if($mont==7) echo "�á�Ҥ�"   ;
if($mont==8) echo "�ԧ�Ҥ�" ;
if($mont==9) echo "�ѹ��¹" ;
if($mont==10) echo "���Ҥ� " ;
if($mont==11) echo "��Ȩԡ�¹";
if($mont==12) echo "�ѹ�Ҥ�" ;
 echo "</font >";  
    ?>
 <form action  method=post>
<font color="#6666FF">���͡��͹�������ʴ�㹵��ҧ :</font>  <select name ="mont">
<option value=0>��͹�Ѩ�غѹ</option>
<option value=1>���Ҥ�</option>
<option value=2>����Ҿѹ��</option>
<option value=3>�չҤ�</option>
<option value=4>����¹</option>
<option value=5>���Ҥ�</option>
<option value=6>�Զع�¹</option>
<option value=7>�á�Ҥ�</option>
<option value=8>�ԧ�Ҥ�</option>
<option value=9>�ѹ��¹</option>
<option value=10>���Ҥ�</option>
<option value=11>��Ȩԡ�¹</option>
<option value=12>�ѹ�Ҥ�</option>
</select>
<input type=submit value = ok>
</form>
<div align="left">
<table><tr>
<td>		<IMG SRC="<?php echo $config["folder"];?>/pic/pigeon.gif" ></td>
<?php
echo "<td><a href = http://$config[domain]$config[folder]$config[filename]?page=300&&subpage=900 ><font color=\"#3333FF\" size=\"+1\">Check Other user</font></a></td>";
}
  $bb=$HTTP_COOKIE_VARS["user"];
  $tdate = getdate(time());
  $tmon=$tdate["mon"];
 $tday = $tdate["mday"];

//�դ��ҡ��
$query = "select * from messtomem where touser='$bb' and (
 ( dayshow <= '$tday'and monthshow='$tmon'  ) or (dayshow > '$tday' and monthshow < '$tmon' ) )";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
$row = mysql_fetch_array($result);
if($num!=0) echo "<a href=$config[folder]$config[filename]?page=300&&subpage=300 ><font color =red><h3>�բ�ͤ����֧�س  &nbsp <b> $bb</b></h3></font> </a>";

//��Ǩ�ͺ��ҷ����令��Ѻ��ҹ�ѧ
$query = "select * from checkread where  fromuser='$bb'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
$row = mysql_fetch_array($result);

if($num!=0) echo "<a href=$config[folder]$config[filename]?page=300&&subpage=250 ><font color =red><h3>��Ǩ�ͺ��ͤ��������� </h3></font> </a>";

?>
</tr></table>

	<table><tr><td>
	<IMG SRC="<?php echo $config["folder"];?>/pic/human_read_news.gif" ></td>
    <td><a href = "<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=600" ><font color="#3333FF" size="+1">Enter To Public Grouup </font></a></td>
	</tr>
	</table>
	</div>
</table>

</td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
