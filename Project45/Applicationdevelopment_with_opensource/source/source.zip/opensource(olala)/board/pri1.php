<?php
session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF"><?php
 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
	   $bb=$HTTP_COOKIE_VARS["user"];

if($ggroup=="ok")  { $sess_tmptogroup = $togroup;  session_register("sess_tmptogroup"); $sess_tmptoname="";  }
if($ugroup=="ok") { $sess_tmptoname = $toname; session_register("sess_tmptoname"); }
if(($submit=="ok")and($post!="")and($sess_tmptogroup!="")and($sess_tmptoname!="")){

    $tday =urldecode($day);
   $tmon =urldecode($month);


if($sess_tmptoname != "�ء���group")
{
    $id5 = rand(1,9999);
    $id6 = rand(1,9999);
	$id1 = rand(1,9999);
    $id2 = rand(1,9999);
    $id3 = rand(1,9999);	
    $id4 = rand(1,9999);	
    $id = ($id5 * 100000)+($id6 * 10000)+ ($id1 * 1000)+ ($id2*100) + ($id3*10)+ $id4;
	
   $sql="INSERT INTO messtomem(fromuser,fromgroup,touser,messtext,dayshow,monthshow,randmessid)VALUES('$bb','$sess_tmptogroup','$sess_tmptoname','$post','$tday','$tmon','$id')";
 $result = mysql_query($sql);}

else {
  $query = "select * from insidegroup where groupname='$sess_tmptogroup'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
for($i=0;$i<$num;$i++){
$row = mysql_fetch_array($result);
$eachuser = $row[username];
		 $id5 = rand(1,9999);
    $id6 = rand(1,9999);
        $id1 = rand(1,9999);
    $id2 = rand(1,9999);
    $id3 = rand(1,9999);	
    $id4 = rand(1,9999);	
 $id = ($id5 * 100000)+($id6 * 10000)+ ($id1 * 1000)+ ($id2*100) + ($id3*10)+ $id4;
       sendallgroup($eachuser,$bb,$sess_tmptogroup,$post,$tday,$tmon,$id);
   } //for

 } //else      �ء��� group

$sess_tmptogroup="";$sess_tmptoname="";
session_unregister("sess_tmptogroup");
session_unregister("sess_tmptoname");
 echo "<center><a href=$config[folder]$config[filename]?page=300&&subpage=100 >��Ѻ��ѧ˹�ҵ��ҧ</a></center>";
}

else {                     // else submit
$check= 0;
  $tdate = getdate(time());
 $ttmon=$tdate["mon"];
 $ttday = $tdate["mday"];
   $tday =urldecode($day);
   $tmon =urldecode($month);
   if($tmon>$ttmon) $check=1;
   if(($tmon==$ttmon)and($tday>=$ttday)) $check=1;

if($check==1) {
echo "<center><a href=$config[folder]$config[filename]?page=300&&subpage=100 >��Ѻ��ѧ˹�ҵ��ҧ</a></center>";
if($bb !=$sess_tmptoname){  echo "<br>�觶֧  &nbsp &nbsp <font color = green> $sess_tmptoname </font>&nbsp &nbsp
 ����� group &nbsp &nbsp <font color = green> $sess_tmptogroup</font> <br>";}
else {  echo "<br>�觶֧  &nbsp &nbsp <font color = green>��͹�����ӵ���ͧ </font>&nbsp &nbsp
 ����� group &nbsp &nbsp <font color = green> $sess_tmptogroup</font> <br>"; }

echo "<form action=$config[folder]$config[filename]?page=300&&subpage=200&&day=$tday&&month=$tmon method =post>";


$query = "select * from insidegroup where username='$bb'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
echo "���͡ group : <select name =togroup>";
for($i=0;$i<$num;$i++){
 $row = mysql_fetch_array($result); //push to array form result
echo "<option value=$row[groupname]>$row[groupname]</option>";
}
echo "</select> ";
echo "<input type=submit name = ggroup value=ok> &nbsp";

$query = "select * from insidegroup where groupname='$sess_tmptogroup'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
echo "���͡ �� : <select name =toname>";
for($i=0;$i<$num;$i++){
 $row = mysql_fetch_array($result); //push to array form result
if($row[username]!=$bb) {
  echo "<option value=$row[username]>$row[username]</option>";}
else {echo "<option value=$row[username]>��͹������</option>"; }

if($i+1==$num)echo "<option value=�ء���group>�ء��� group</option>";
}
echo "</select> ";
echo "<input type=submit name = ugroup value=ok> &nbsp";

echo "<br><br><br>��������´<br><textarea rows=10 cols=60 wrap=medium style=font:16pt ms sans serif; name=post></textarea><br>";
echo "<br><input type=Submit name= submit value=ok> &nbsp";
echo "<input type=Reset value=cancel>";
echo "</form>";
}//check
else { echo " ����͹��ѧ������Ѻ ";  //else check

 echo "<a href=$config[folder]$config[filename]?page=300&&subpage=100 >��Ѻ��ѧ˹�ҵ��ҧ</a>";}
}//else post

mysql_close();
?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
