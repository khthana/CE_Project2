<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>

</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">

<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
	   $bb=$HTTP_COOKIE_VARS["user"];
 $tdate = getdate(time());
 $tmon=$tdate["mon"];
 $tday = $tdate["mday"];

$query = "select * from checkread where fromuser='$bb' and  touser<>'$bb' ";

$result = mysql_query($query);
$num = mysql_num_rows($result); //count row

echo "<center><a href=$config[folder]$config[filename]?page=300&&subpage=100 >��Ѻ��ѧ˹�ҵ��ҧ</a></center>";
 echo "<b><center>��ͤ��������  �Դ��ҹ���� <br><br></center></b>";

 echo"<table width=80% border=1 >
<tr>
<th width = 8%>��ͤ�����������س
<th width = 8%>group
<th width = 7%>���ѹ���
<th width = 7%>���Դ��ҹ�ѹ���
<th width = 7%>ź";
 for($i=0;$i<$num;$i++){
 $row = mysql_fetch_array($result); //push to array form result

echo " <tr><td><center>$row[touser]";
echo " <td><center>$row[fromgroup]";
echo " <td><center>$row[dayshow]/$row[monthshow]";
echo " <td><center>$row[dateread]";
echo "<td><center><a href=$config[folder]$config[filename]?page=300&&subpage=450&&id=$row[randmessid] style=text-decoration:none>***</a>";

}  //for



mysql_close();
?>

</td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>


