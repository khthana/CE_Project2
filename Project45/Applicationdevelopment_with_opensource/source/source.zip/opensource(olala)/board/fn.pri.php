<?php
function insertallread($fuser,$tuser,$fgroup,$ds,$ms,$rmid,$date)
{
 $query = "select * from checkread where randmessid='$rmid'";
$re = mysql_query($query);
$num = mysql_num_rows($re); //count row

if($num==0){
  $sql="INSERT INTO checkread (fromuser,touser,fromgroup,dayshow,monthshow,randmessid,dateread)VALUES('$fuser','$tuser','$fgroup','$ds','$ms','$rmid','$date')";
  mysql_query($sql);
}

}
?>

