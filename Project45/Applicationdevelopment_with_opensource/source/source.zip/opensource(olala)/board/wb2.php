<?php
$ttmp =urldecode($auto);
if($ttmp==1) {
header("location: http://$config[domain]$config[folder]$config[filename]?page=300&&subpage=600&&auto=0");
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">
<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

include ("board/date1.php");
if(($poster!="")and($titlepost!="")){

$today = dateth();
$ip= $REMOTE_ADDR;

  $sql="INSERT INTO boardposter(olalatitlepost,olalapost,olalaposter,olalacreate,olalalast,olalaip)VALUES('$titlepost','$post','$poster','$today','$today','$ip')";
  $result = mysql_query($sql);
}

else {
     echo "<BR><a href=$config[folder]$config[filename]?page=300&&subpage=600 ><font color=\"#3333FF\" size=\"+1\">��Ѻ��� Public Group</font></a>";
echo "<center><table><tr><td><IMG SRC=\" ".$config["folder"]."/pic/pugun.gif\" ></td><td><font  size=\"+2\" color=\"#0000CC\">��駡�з������ </font></td></tr></table><br><br>";
echo "<form action=$config[folder]$config[filename]?page=300&&subpage=700&&auto=1 method =post>";
echo "<font color=\"#FF00FF\">���ͤ���� </font>&nbsp<input type=text size=30 name =poster>";
echo "<br><font color=\"#FF00FF\">��Ǣ��</font>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<input type=text size=30 name =titlepost>";
echo "<br><font color=\"#FF00FF\">��������´</font><br><textarea rows=10 cols=60 wrap=medium style=font:16pt ms sans serif; name=post></textarea><br>";
echo "<br><input type=Submit value=ok> &nbsp";
echo "<input type=Reset value=cancel>";
echo "</form>";
}


mysql_close();
?>

      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>





