<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">
<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
 $limit =urldecode($li);

if($limit=="") $limit=0;
if($limit!="") $limit =$limit -1;
$query = "select * from boardposter order by olalaqid"; //order rows
$result =mysql_query($query);  // oder rows
$tmpnum = mysql_num_rows($result); //count row

$query = "select * from boardposter order by olalaqid desc limit $limit,10"; //order rows
$result =mysql_query($query);  // oder rows
$num = mysql_num_rows($result); //count row
echo "<center><table><tr><td>	<IMG SRC=\"".$config["folder"]."/pic/human_read_news.gif\" ></td><td><font color=\"#3300FF\" size=\"+1\" face=\"MS Sans Serif, Tahoma, sans-serif\"><strong>Public Group</strong></font></td><td><IMG SRC=\"".$config["folder"]."/pic/human_read_news.gif\" ></td></tr></table>";
echo "<div align=\"left\"><a href=$config[folder]$config[filename]?page=300&&subpage=700><font color=\"#3333FF\" size=\"+1\">��駡�з������</font></a></div>";
echo"<BR>
<table width=\"98%\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bordercolor=\"black\" bgcolor=\"#FFFFCC\">
<tr valign=\"top\" bgcolor=\"#0099FF\" align=\"center\">
<th><font size=\"+2\"><b>Create</b></font>
<th> <font size=\"+2\"><b>Title</b></font>
<th> <font size=\"+2\"><b>Poster</b></font>
<th><font size=\"+2\"><b>&nbsp;Last Post&nbsp;</b></font>
<th><font size=\"+2\"><b>&nbsp;Visite&nbsp;</b></font>
";

for($i=0;$i<$num;$i++)
{ $row = mysql_fetch_array($result); //push to array form result

echo "<tr><td width = 15%><center><font color=\"#FF00CC\"> $row[olalacreate]</font>";
echo "<td width = 45%><center><a href=$config[folder]$config[filename]?page=300&&subpage=800&&qid=$row[olalaqid] style=text-decoration:none> <font color=\"#FF3333\" >$row[olalatitlepost]</font></a>";
echo "<td width = 15%><center> <font color=\"#0033CC\">$row[olalaposter]</font>";
echo "<td width = 15%><center> <font color=\"#FF00CC\">$row[olalalast]</font>";
echo "<td width =10%><center> <font color=\"#FF00CC\">$row[olalacount]</font>";
}

echo"</table>";
$tmpnum = (($tmpnum / 10)-(($tmpnum %10)/10))+1 ;
echo "page  ";
for($i=0;$i<$tmpnum;$i++)
{
$ii=$i*10+1;
$iii=$i+1;
echo "<a href=$config[folder]$config[filename]?page=300&&subpage=600&&li=$ii><font color=gray>$iii </a>&nbsp";
}

//echo $tmpnum;
mysql_close();
?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>




