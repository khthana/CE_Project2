<?php
function sendallgroup($touser,$bb,$sess_tmptogroup,$post,$tday,$tmon,$id)
{	
      $sql="INSERT INTO messtomem(fromuser,fromgroup,touser,messtext,dayshow,monthshow,randmessid)VALUES('$bb','$sess_tmptogroup','$touser','$post','$tday','$tmon','$id')";
  $result = mysql_query($sql);
 }
?>

