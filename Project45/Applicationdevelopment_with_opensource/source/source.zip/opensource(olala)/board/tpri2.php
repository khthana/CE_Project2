<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

 $id=urldecode($id);

$query = "delete from messtomem where randmessid = '$id' ";
$result =mysql_query($query);  // oder rows
header("location:http://$config[domain]$config[folder]$config[filename]?page=300&&subpage=300");


?>

