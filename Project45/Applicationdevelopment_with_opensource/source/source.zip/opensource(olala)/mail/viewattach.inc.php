<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="#FFCC00" background="<?php echo $config["folder"];?>/pic/bg.gif" text="#0000FF" topmargin="0"  >
<table width="100%" >
<tr>
<td valign="bottom">
<table width="100%" border="0" >
  <tr>
          <td width="0" height="0"><img src="<?php echo $config["folder"];?>/pic/logo.gif" width="212" height="75"></td>
  </tr>
</table>
<table width="100%" border="0" align="center" bgcolor="#FFFFFF">
  <tr>
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#5795F5">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%">&nbsp;</td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	
	</TR>
</TABLE>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		
    <td bgcolor="#FFFFFF">
	<table width="80%" border="1">
<tr>
<td>	
<?php		
$filename = urldecode	($filename);
$user = $HTTP_COOKIE_VARS["user"];
?>
<IMG src = "<?php echo "attach/".$user."/tmp/".$filename ?>" >
</td>
</tr>
	</td>
	</tr>
</table>
	</td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>