<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

 $user=urldecode($duser);
 $own=urldecode($own);

$query = "delete from addrbook where bookaddr = '$user' and usersource ='$own@olala02.ce.kmitl.ac.th'  ";
$result =mysql_query($query);  // oder rows
header("location:http://$config[domain]$config[folder]$config[filename]?page=200&&subpage=400");


?>

