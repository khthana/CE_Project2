<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
				<BR>
</TABLE>				<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		
    <td bgcolor="#FFFFFF">



<?php
    /*///////////////////////////////////////////////// */

$max_att = 15;
$basedir = "/var/www/html";
//$upload_dir= "$basedir/upload\\";
$upload_dir= "$basedir";

$bb=$HTTP_COOKIE_VARS["user"];


if (!isset($id))  {
	srand((double) microtime() * 1000000);
	$id = rand(1000,9999); #
}
#echo "ID: $id <br>";
     

switch ( trim($action) ) {
	case "Send" :
		echo "<center>";
		if  ($rcpt == "") {
			echo "<b>�ѧ��͡���������ú���</b><p>";
		    echo '<input type="button"  value="��ԡ�����"   '.
						' onclick="history.back();"> ���͡�Ѻ仡�͡����!' ;

			die;
		}

		if ($subj == "") $subj="����к���Ǩ�����";
		$ans=mimemail($rcpt, $subj, $msg, $att_str  );
		unlink_all_file ($att_str );
		$hide_form = true;	
		if($ans!=0){print " <h3>Thankyou</h3><hr>";
		echo "<a href=$config[folder]$config[filename]?page=200&&subpage=100>complete</a>";}
        else {  echo "<a href=$config[folder]$config[filename]?page=200&&subpage=100>��سҵ�Ǩ�ͺ���·ҧ����</a>";}
        break;

    case "Add" :
        add_attachment(  $userfile, $upload_dir);
        break;

    case "Remove" :
		if (($attach == "" ) || ($attach == "-Attachments List-" )) {
			echo "�ѧ��������͡����������͡�ҡ��¡��<br>";
		} else {
			$att_str = eregi_replace("\[", "zzxxx", $att_str);
			$att_str = eregi_replace("\]", "xxxzz", $att_str);

			$attach = eregi_replace("\[", "zzxxx", $attach);
			$attach = eregi_replace("\]", "xxxzz", $attach);

			$att_str = eregi_replace("$attach;", "", $att_str);

			$att_str = eregi_replace("zzxxx","[",  $att_str);
			$att_str = eregi_replace("xxxzz","]",  $att_str);
	
		   list ($fname, $size)  = split ("~", $attach); 
		   if ( file_exists("$upload_dir$fname") ) {
				unlink("$upload_dir$fname");
		   }
		
			#	echo "�������¡�� ���� : $att_str<br>";
		} // if == ""
        break;
}

//**********************************

function build_mime_att ($att_str ) {
	global $upload_dir;
	$att_list = split(";", $att_str);

	foreach ($att_list as $attach) {

		if ( $attach != "" ) {
			list ($fname, $size_type)  = split ("~", $attach); 
			list ($size, $type) = split ("@", $size_type); 


			$fpath = "$upload_dir$fname";


			$fname = substr_replace ($fname, "", 0, 4); 
			if ( !file_exists($fpath) ) {
				echo "<br>��辺��� $fname, ";
				echo " ��੾�� message �������ö��  file Attach ��� ";
				return;
			}  else if (!$fp=fopen($fpath, "rb")  ) 	{
				echo "Error! can't open file";
				return;
			} else {
				$data = fread($fp, filesize($fpath));
				$data = base64_encode($data);
				$data = chunk_split($data);
			}


			$base64_txt .="\r\n--abcd0123\r\n".
			

            "Content-Type: $type;".
			"\tname=\"$fname\"\r\n".	
			"Content-Transfer-Encoding: base64\r\n".
			"Content-Disposition: attachment;\r\n".
			"\tfilename=\"$fname\"\r\n".	
			"\r\n".$data."\r\n\r\n";
	
		}
	} 
	if ($base64_txt != "") {
		$base64_txt .= "--abcd0123--\r\n";
	
    }
	
	return $base64_txt;
} # function build_mime

function checkstatus($code)
{   //echo "$code <br>";
   if(eregi("^[23]",$code))
     { return 0; }
  else { return 1; }

}

function validmail($rcpt)
{
global $bb;
$rcpt = trim($rcpt);

list($user,$domain) = split("@",$rcpt);


getmxrr($domain,$mxhosts);
$q=count($mxhosts);

if($q==0)  {
          $mxhosts[0]=$domain ;
              }

//echo $mxhosts[0]."gjygjjhrhjtrhjtr<br>";

            $mxhosts[0]="diamond.ce.kmitl.ac.th" ;

   $sock =  fsockopen ($mxhosts[0],25);
           if(!$sock)  {  return 0; exit;  }
              else {
 	$reply=fgets($sock,1024);
	$ans=checkstatus($reply);

if($ans==0) {
//echo "1";
fputs($sock,"HELO olala02.ce.kmitl.ac.th\r\n");
$reply=fgets($sock,1024);
$ans=checkstatus($reply);
}

if($ans==0) {
//echo "2";
fputs($sock,"MAIL FROM: <$bb@olala02.ce.kmitl.ac.th>\r\n");
$reply=fgets($sock,1024);
$ans=checkstatus($reply);
}

if($ans==0) {
fputs($sock,"RCPT TO:<$rcpt>\r\n");
$reply=fgets($sock,1024);
$ans=checkstatus($reply);
}

if($ans==0) {
fputs($sock,"DATA\r\n");
$reply=fgets($sock,1024);
$ans=checkstatus($reply);
}
//echo $ans;
if($ans==1) fputs($sock,"QUIT\r\n");

if($ans==0 ) return $sock;

} //else meet host

} //fn


function mimemail($rcpt, $subj, $msg, $att_str  ) {
global $bb;

  if(!$att_str)
 {   $header =  "TO:$rcpt\r\n".
	"From: $bb@olala02.ce.kmitl.ac.th\r\n".
	"Subject:$subj\r\n".
    "\r\n$msg\r\n" ;      }
    
if($att_str)
   {$header =  "TO:$rcpt\r\n".
	"From: $bb@olala02.ce.kmitl.ac.th\r\n".
	"Subject:$subj\r\n".
	"MIME-Version: 1.0\r\n".
   	"Content-Type: multipart/mixed;\r\n".
    "\t boundary=\"abcd0123\"\r\n".
    "X-Priority: 1\r\n".
    "\r\n".
    "--abcd0123\r\n".	
    "\r\n$msg\r\n".
     build_mime_att ($att_str ) ;}

$sock=validmail($rcpt) ;
if($sock!=0) {
$body = "$header\r\n";
fputs($sock,"$body\r\n.\r\n");
$reply=fgets($sock,1024);
  if(checkstatus($reply)==1) {   echo "<input type=button  value=��ԡ����� ".
	" onclick=history.back();> ����� mail ���� host ���" ;return 0;}

//fputs($sock,"QUIT\r\n");

 return 1;}
else { return 0;}
} // mimemail


function add_attachment ( $userfile, $upload_dir) {
	 global $att_str,$userfile_name,$userfile_size,
				$max_att ,$userfile_type,$id ;
	if ( count_att($att_str) > $max_att ) {
          	echo "<center><b>���Ṻ ͹حҵ������ $max_att !</b><br>";
		} else if ($userfile_name == "" ) {
			echo "�ѧ��������͡������Ṻ (��ԡ browse ���͡���¡�͹)<br>";
		} else if ($userfile_size == 0) {
			echo "��辺��� ���͢�Ҵ����˭���ҷ��͹حҵ�";
		} else if (eregi($userfile_name, $att_str)) {
			echo "����ӡѹ";
		} else  {

            	$userfile_name = $id.$userfile_name;

         if (copy( $userfile, "$upload_dir$userfile_name") ) {
			$att_str .= "$userfile_name~[$userfile_size]@$userfile_type;" ;  
       	} else {
			echo "��ͻ����������к������ ";
		}
	} // if == ""
} 



function unlink_all_file ($att_str ) {
	global $upload_dir;
	$att_list = split(";", $att_str);

	foreach ($att_list as $attach) {

		if ( $attach != "" ) {
			list ($fname, $size)  = split ("~", $attach); 

		  if ( file_exists("$upload_dir$fname") ) {
				unlink("$upload_dir$fname");
		  }
		}
	} 
} # 



function dsp_att_list ($att_str ) {
	$att_list = split(";", $att_str);


	echo "<select name=attach size=4>";
	echo "<option>-Attachments List-";
	foreach ($att_list as $value) {

		$option = eregi_replace("([ -_[:alnum:].]*)@([-[:alnum:]\/]*)$", "\\1", $value); 
		$option = substr_replace ($option, "", 0, 4); 
		echo "<option value=\"$value\">$option";
	} 
	echo "</select>";
} # dsp_att_list


function count_att ($att_str ) {
	$att_list = split(";", $att_str);
	return count($att_list );
} # count_att
?>

<?php
if ( !$hide_form ) {
?>


<form method=post enctype="multipart/form-data">
<TABLE cellpadding=8 width="100%" cellspacing=0>
<tr><td align=center colspan=2 ><IMG SRC="<?php echo $config["folder"];?>/pic/pencil.gif" ><font  size="+2" color="#0000CC">&nbsp;&nbsp;&nbsp;<b>Compose Mail&nbsp;&nbsp;&nbsp;<IMG SRC="<?php echo $config["folder"];?>/pic/pencil1.gif" >

</b></font></td></tr>

<tr><td>
<Table cellspacing=0 cellpadding=0>
<tr><td><font color="#0066FF" size="+1"><strong>From : </strong></font></td>
<td><font color="#FF0000"><?php echo "&nbsp&nbsp$bb@".$config["domain"];?></font>
</tr>
<tr><td><font color="#0066FF" size="+1"><strong>	To : </strong></font></td>
<td><input type="text" name=rcpt size=35 value=<?=$rcpt?>></td>
</tr>

<tr><td><font color="#0066FF" size="+1"><strong>Subj : </strong></font></td><td>
<input type="text" name=subj size=35 value="<?=$subj?>"></td>
</tr>
<tr><td valign=top align=center><br></td><td>
<textarea name=msg rows=9 cols=42 style="font-family:MS Sans serif;font-size:10pt"><?=$msg?></textarea>

<br><center><input type="submit" value="   Send   " name="action">&nbsp;&nbsp;
 </td></tr>

</table>
</td>
<td>
<p>&nbsp;
	<b><font color="#0066FF" size="-1" face="MS Sans Serif, Tahoma, sans-serif"><strong>Ṻ��� Attachments</strong></font><br>
<input type="hidden" name="MAX_FILE_SIZE" value="124000"><!-- �����˭� -->
<input type="file" size=20 name=userfile>
<input type="submit" value=" Add " name="action"><br>
<p>
<b>&nbsp;
<font color="#0066FF" size="-1" face="MS Sans Serif, Tahoma, sans-serif"><strong>���ҧ�ʴ��������������</strong></font></b><br>
<?php
	dsp_att_list ($att_str )
?>&nbsp;&nbsp;
<input type="submit" value="Remove" name="action">

</p>
<input type="hidden" name="att_str" value="<?=$att_str?>">
<input type="hidden" name="id" value="<?=$id?>">
</td>
</tr>
</Table>
</form>

  </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
<?php  }  ?>
