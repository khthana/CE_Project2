<?php
$filename = urldecode($filename);
$realfile = urldecode($realfile);
$user = $HTTP_COOKIE_VARS["user"];
copy("../attach/".$user."/".$realfile,"../attach/".$user."/tmp/".$filename);		
$s_expose = explode(".",$filename);
if( ($s_expose[1]=="jpg") or ($s_expose[1]=="gif") or ($s_expose[1]=="bmp") )
{	header("Location: ".$config["../domain"]."/project/index.php?page=200&&subpage=700&&filename=".$filename);
}else
{	header("Location: ".$config["../domain"]."/project/attach/".$user."/tmp/".$filename);
}
?>
