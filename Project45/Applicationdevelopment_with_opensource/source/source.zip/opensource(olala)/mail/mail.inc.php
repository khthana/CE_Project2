<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<script language="JavaScript">
function checkall(){	
//newWindow = window.open("","","HEIGHT = 300 , WIDTH = 300")
//document.form[0].1072.checked = true
}
</script>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	
	<BR>
	</TR>
	</TABLE><BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		
    <td bgcolor="#FFFFFF">
	<BR>
	<table width="95%" border="1" cellpadding="0" cellspacing="0" bordercolor="black" bgcolor="#FFFFCC">
<tr valign="top" bgcolor="#0099FF" align="center"><td><font size="+1"><b>Status</b></font></td><td><font size="+1"><b>Subject</b></font></td><td><font size="+1"><b>From</b></font></td><td><font size="+1"><b>Date</b></font></td><td><font size="+1"><b>Size</b></font></td></tr>
<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=300"><font color="#3333FF" size="+1">Write Mail</font></a>&nbsp;&nbsp;&nbsp;
<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=400"><font color="#3333FF" size="+1">Management Contract</font></a>
<BR><BR>
<?php

echo "<form action= http://$config[domain]$config[folder]$config[filename]?page=200&&subpage=800  method=post>";
echo " <input name=delete type=submit value=Delete>";
echo " <input name=deleteall type=submit value=DeleteAll>";

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
 $bb=$HTTP_COOKIE_VARS["user"];

$query = "select * from userpass where username = '$bb'"; //order rows
$result =mysql_query($query);  // oder rows
$row = mysql_fetch_array($result); //push to array form result
$tmppass = $row[password];


	$mbox = imap_open ("{".$config["mailserver"].":110/pop3}INBOX","".$bb."","".$tmppass."")


	//$mbox = imap_open ("{".$config["mailserver"].":110/pop3}INBOX","".user."","".vkwigouhp."")
	or die("Cannot open Your Mailbox".imap_last_error());
	$check = imap_mailboxmsginfo($mbox);
	require("function/fndb.fn.php");
if ( $check->Nmsgs == 0 )
	{   // ==================== No Email in Server Than Show email alive in Database ======================
		   connectDB();
		   $query =  "SELECT * FROM `".$dbconfig["DBkmail"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  ORDER BY mdate,mtime";
$result = mysql_query($query);
$number = mysql_num_rows($result);
	for($i=0; $i<$number; $i++)
	{	$row = mysql_fetch_array($result);
		echo "<tr>";
		echo "<td align=\"center\"><input type=\"checkbox\" name=\" ".$row[mmsgid]."\" ></td>";
		echo "<td>&nbsp;<a href=".$config["../domain"].$config["folder"].$config["filename"]."?page=200&&subpage=200&&issue=".$row[mmsgid].">".$row[msubject]."</a></td>";
		echo "<td>&nbsp;".$row[mfromaddr]."</td>";
		$row[mdate]=substr($row[mdate],5,strlen($row[mdate]));
		echo "<td>&nbsp;".$row[mdate]." (".$row[mtime].")</td>";
		echo "<td>&nbsp;".$row[msize]."</td>";		
		echo "</tr>";
	}
mysql_close();
imap_close($mbox);
   // ==================== No Email in Server Than Show email alive in Database ======================		   
	}else
	{	
	   connectDB();
require("function/mread.fn.php");
				for($i=1; $i<=$check->Nmsgs;$i++)
				{  $ran=0;	
				   notdumsgid();
				   $headinfo=imap_headerinfo($mbox,$i);
					$structure=imap_fetchstructure($mbox,$i);
		  		    $mdate = date(" Y-m-d",$headinfo->udate);
					$mtime = date("h:i:s ",$headinfo->udate);					
					$body =  "" ;$filename = "";
					gettmsg($i);
					$status = 1;
					if( $filename != "")$havefile = 1;
					else $havefile = 0;
					$tmpfrom = htmlspecialchars($headinfo->fromaddress) ;
					//echo  $tmpfrom;
					$query="INSERT INTO `".$dbconfig["DBkmail"]."` (`muser`, `mmsgid`, `mfromaddr`, `mcc`, `msubject`, `msize`, `mdate`, `mtime`, `mbody`, `mstatus`, `mattach`) VALUES ('".$HTTP_COOKIE_VARS["user"]."', '".$ran."', '".$tmpfrom."', '".$headinfo->ccaddress."', '".$headinfo->subject."', '".ceil($structure->bytes/1024)."', '".$mdate."', '".$mtime."', '".$body."', '".$status."', '".$havefile."');"; 					
					mysql_query($query);
					imap_delete($mbox,$i);
				}
imap_expunge($mbox);
$query =  "SELECT * FROM `".$dbconfig["DBkmail"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  ORDER BY mdate,mtime";
$result = mysql_query($query);
$number = mysql_num_rows($result);
	for($i=0; $i<$number; $i++)
	{	$row = mysql_fetch_array($result);
		echo "<tr>";
		echo "<td><input type=\"checkbox\" name=\" ".$row[mmsgid]."\" ></td>";
		echo "<td><a href=".$config["../domain"].$config["folder"].$config["filename"]."?page=200&&subpage=200&&issue=".$row[mmsgid].">".$row[msubject]."</a></td>";
		echo "<td>".$row[mfromaddr]."</td>";
		$row[mdate]=substr($row[mdate],5,strlen($row[mdate]));
		echo "<td>".$row[mdate]." (".$row[mtime].")</td>";
		echo "<td>".$row[msize]."</td>";		
		echo "</tr>";
	}
imap_close($mbox);	
mysql_close();
	}
	?>
	</form>
	</td>
	</tr>
</table>
	</td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
