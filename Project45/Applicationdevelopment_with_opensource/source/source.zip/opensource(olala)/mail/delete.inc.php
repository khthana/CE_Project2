<?php
require("function/fndb.fn.php");
connectDB();
$query =  "SELECT * FROM `".$dbconfig["DBkmail"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  ORDER BY mdate,mtime";
$result = mysql_query($query);
$number = mysql_num_rows($result);
if ($HTTP_POST_VARS['delete'] == true)
{
	for($i=0; $i<$number; $i++)
	{	$row = mysql_fetch_array($result);
		if ($user = $HTTP_POST_VARS[$row[mmsgid]]== true)
		{	$query =  "DELETE FROM `".$dbconfig["DBkmail"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  AND mmsgid = '".$row[mmsgid]."' ";
			mysql_query($query);
			$query =  "DELETE FROM `".$dbconfig["DBkattach"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  AND mmsgid = '".$row[mmsgid]."' ";			
			mysql_query($query);
		}
	}
}else if ($HTTP_POST_VARS['deleteall'] == true)
{
	for($i=0; $i<$number; $i++)
	{	$row = mysql_fetch_array($result);
		$query =  "DELETE FROM `".$dbconfig["DBkmail"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  AND mmsgid = '".$row[mmsgid]."' ";
		mysql_query($query);
		$query =  "DELETE FROM `".$dbconfig["DBkattach"]."` WHERE muser = '".$HTTP_COOKIE_VARS["user"]."'  AND mmsgid = '".$row[mmsgid]."' ";			
		mysql_query($query);
		
	}
}
mysql_close();
header("Location: ".$config["../domain"]."/project/index.php?page=200&&subpage=100");
/*echo "HELLO";
if ($HTTP_POST_VARS['367'] == true)
echo "WORK";
else
echo "NOT WORK";*/
?>