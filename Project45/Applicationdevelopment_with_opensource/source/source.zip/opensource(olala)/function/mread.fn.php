<?php
function gettmsg($issue)
{ 	global $mbox;
    global $body,$filename,$config,$dbconfig,$ran,$HTTP_COOKIE_VARS;
	$structure = @imap_fetchstructure($mbox,$issue);
	$totalpart = sizeof($structure->parts);		
    if($totalpart > 0 )
	{ 		$total = sizeof($structure->parts);
			for($i = 0; $i < $total; $i++)
			{  	if($structure->subtype != 'ALTERNATIVE')
				{	if($structure->parts[$i]->type == 1)
					{		$body = imap_fetchbody($mbox,$issue,1.2);
							$body = imap_qprint($body);							
					}else if($structure->parts[$i]->encoding == 3)
					{	 
//====================== Function Get File Name From TWIG ====================
 $tmp = $structure;
$structure = $structure->parts[$i];
if( $structure->ifparameters )
		{
       		while( list( $key, $val ) = each( $structure->parameters ) ) 
			{
        		if( strtoupper( $val->attribute ) == "NAME" || strtoupper( $val->attribute ) == "FILENAME" )
				{
         			$filename = $val->value;
        			}

        		if( strtoupper( $val->attribute ) == "CHARSET" )
				{
         			$charset = $val->value;
        			}
       			}
   		}

   	if( $structure->ifdparameters )
		{
       		while( list( $key, $val ) = each( $structure->dparameters ) ) 
			{
        		if( empty( $filename ) && ( strtoupper( $val->attribute ) == "NAME" || strtoupper( $val->attribute ) == "FILENAME" ) )
				{
         			$filename = $val->value;
        			}

        		if( empty( $charset ) && strtoupper( $val->attribute ) == "CHARSET" )
				{
         			$charset = $val->value;
        			}
       			}
   		}
$structure = $tmp;
//====================== END Function Get File Name From TWIG ====================
$file = imap_fetchbody($mbox,$issue,$i+1);
$file = imap_base64($file);
$ranfile = notdufilename();
$s_expose = explode(".",$filename);
$ranfile = $ranfile.".$s_expose[1]";
$position = $config["mailatt"].$HTTP_COOKIE_VARS["user"]."/".$ranfile;
if($fp = fopen("$position","wb"))
{ fwrite($fp,$file);
	fclose($fp);
}else {echo "ERROR";}
if($body == "")
{	$body = imap_fetchbody($mbox,$issue,1);
	$body = imap_qprint($body);							
}
$query="INSERT INTO `".$dbconfig["DBkattach"]."` (`muser`, `msid`, `folder`, `filename`, `rfilename`) VALUES ('".$HTTP_COOKIE_VARS["user"]."', '".$ran."', '".$HTTP_COOKIE_VARS["user"]."', '".$ranfile."', '".$filename."');"; 					
mysql_query($query);
				}
				}else
				{	$body = imap_fetchbody($mbox,$issue,2);
					$body = imap_qprint($body);
				return $body;
				break;
				}
			}
	}else
	{  if($structure->encoding == 4 )
		{		$body = imap_fetchbody($mbox,$issue,1);
				$body = imap_qprint($body);
				return ;
		}else
		{		$body = imap_fetchbody($mbox,$issue,1);
				return ;
		}
}
}
function notdumsgid()
{ //============= Check Duplicate then random again =====================
global $dbconfig,$ran,$HTTP_COOKIE_VARS;
	$notdu = false;					// For Check random not duplicate with in table
do
	{		$ran = rand(-2000,30000);
			$notdu=false;
    $query = "select * from ".$dbconfig["DBkmail"] ." where muser = '" .$HTTP_COOKIE_VARS["user"]."'";
    $result =mysql_query($query);
    $num = mysql_num_rows($result);
	for($i=0; $i<=$num;$i++)
{	$row = mysql_fetch_array($result);
	if ( $row[msgid] == $ran) 
	{$notdu=true;	}
	}
	}	while($notdu == true );
//============= END Check Duplicate then random again =====================
}

function notdufilename()
{ //============= Check Duplicate then random again =====================
global $dbconfig,$HTTP_COOKIE_VARS;
	$notdu = false;					// For Check random not duplicate with in table
do{
			$ranfile = rand(0,30000);
			$notdu=false;
    $query = "select * from ".$dbconfig["DBkattach"] ." where folder = '" .$HTTP_COOKIE_VARS["user"]."and filename = ".$ranfile."'";
    $result =mysql_query($query);
    $num = mysql_num_rows($result);
   }while ($num != 0);
 return $ranfile;
//============= END Check Duplicate then random again =====================
}

?>