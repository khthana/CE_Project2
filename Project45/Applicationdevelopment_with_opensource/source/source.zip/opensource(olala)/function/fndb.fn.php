<?php
function connectDB()
{	global $dbconfig;
    mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
    mysql_select_db($dbconfig["DBname"]);
}
function checkauth($tuser,$tpass)
{	global $dbconfig;
	connectDB();
    $query = "select * from ".$dbconfig["DBAuth"]." where username = '$tuser' ";
    $result =mysql_query($query);
    $num = mysql_num_rows($result);
if ($num==0) 
{  mysql_close(); 
   return $num; 
}
if($num==1) 
{ $row = mysql_fetch_array($result);
  if ($row[password] ==$tpass) { mysql_close(); return $num;}
  else { $num=2; mysql_close(); return $num;}
 }
mysql_close();
}
?>