<?php

function selectmonth($amo,$ho,$hho)
{  $tdate = getdate(time());
 $tt=$tdate["mon"];
 $tt1 = $tdate["mday"];
if($amo==0) {$amo=$tt;}
if($ho==1) { $amo=$tt; }
       /// make a year
 $a=range(1,12) ;
 $a[1]=31;$a[2]=28;$a[3]=31;$a[4]=30;
 $a[5]=31;$a[6]=30;$a[7]=31;$a[8]=31;
 $a[9]=30;$a[10]=31;$a[11]=30;$a[12]=31;
                      // begin day of month
 $b=range(1,12) ;
 $b[1]="�";$b[2]="�";$b[3]="�";$b[4]="�";
 $b[5]="��";$b[6]="��";$b[7]="�";$b[8]="�";
 $b[9]="�";$b[10]="�";$b[11]="�";$b[12]="�";
                                 // count day of week
 $d=range(1,12) ;
 $d[1]=4;$d[2]=7;$d[3]=7;$d[4]=3;
 $d[5]=5;$d[6]=1;$d[7]=3;$d[8]=6;
 $d[9]=2;$d[10]=4;$d[11]=7;$d[12]=2;
                           // count week of month
 $e=range(1,12) ;
 $e[1]=5;$e[2]=5;$e[3]=6;$e[4]=5;
 $e[5]=5;$e[6]=5;$e[7]=5;$e[8]=6;
 $e[9]=5;$e[10]=5;$e[11]=6;$e[12]=5;

$c=range(1,7);
 $c[1]="��";$c[2]="�";$c[3]="�";$c[4]="�";
 $c[5]="��";$c[6]="�";$c[7]="�";

     $tmp=$a[$amo];
     $tda = $d[$amo];
    $qq=0;
     echo "<table width=\"60%\" border=\"1\" cellspacing=\"0\" cellpadding=\"0\" bordercolor=\"#0099FF\" bgcolor=\"#FFFFCC\">";

      echo"<tr>";
        for($b=1;$b<8;$b++)
         {
           if($c[$b]!="��") {  echo  "<td><center><font color = green size =\"+2\">$c[$b]" ;}
           else {   echo  "<td><center><font color = red size =\"+2\">$c[$b]" ;}
             }  // �ʴ��ѹ �� - �����

          echo "<tr>";
          for($b=1;$b<$tda;$b++)  //��ͧ��ҧ ����͹
          {
             echo "<td>&nbsp ";
             $qq=$qq+1;
          }
      $tmper = 0;
           for($b=1;$b<=$tmp;$b++)
    {    $qq=$qq+1;
      if($tt1==$b) $tmper=1;
      if($tt1!=$b) $tmper=0;
      if(($ho==0)and($tmper==1)){ 
              if(($amo==$tt)and($tt1==$b)) {echo "<td><b><center><a href =$config[folder]$config[filename]?page=300&&subpage=200&&day=$b&&month=$amo  style=text-decoration:none><font color = red size =\"+2\">$b</font></a><b>"; }
              else {    echo "<td><center><a href =$config[folder]$config[filename]?page=300&&subpage=200&&day=$b&&month=$amo  style=text-decoration:none><font color = gray size =\"+2\"> $b</a>";} 
}
                                                                  
      if(($ho==0)and($tmper==0)) {   echo "<td><center><a href =$config[folder]$config[filename]?page=300&&subpage=200&&day=$b&&month=$amo  style=text-decoration:none><font color = gray size =\"+2\"> $b</a>";}
      if(($ho==1)and($tmper==1)) {if($tt1==$b) {echo "<td><b><center><font color = red size =\"+2\">$b<b></font>"; }}
      if(($ho==1)and($tmper==0)) {echo "<td><center><font color = gray size =\"+2\">$b";}


     if($tda==1) { if(($b % 7) == 0 ) echo "<tr>";}
    if($tda==2) { if(($b % 7) == 6 ) echo "<tr>";}
    if($tda==3) { if(($b % 7) == 5 ) echo "<tr>";}
    if($tda==4) { if(($b % 7) == 4 ) echo "<tr>";}
    if($tda==5) { if(($b % 7) == 3 ) echo "<tr>";}
    if($tda==6) { if(($b % 7) == 2 ) echo "<tr>";}
    if($tda==7) { if(($b % 7) == 1 ) echo "<tr>";}

    }
           for($b=$e[$amo]*7;$b>$qq;$b--) {   echo "<td>&nbsp ";}

echo "</table>";
}

?>

