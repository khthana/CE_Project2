<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="#74d4f7" text="#0000FF" topmargin="0">
<?php
require("../config/config.inc.php");
require("../config/dbconfig.inc.php");

if($logpass!=$relogpass) {  echo "password both not math"; $check =0;}
else {$check =1;}
if(($login =="Sign new")and($loguser!=null)and($logpass!=null)and($relogpass!=null)and($check==1))
{

require("../function/fndb.fn.php");
$tnum=checkauth($loguser,$logpass)   ;

if($tnum==0)   { 

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

 $sql="INSERT INTO userpass(username,password)VALUES('$loguser','$logpass')";
 $result = mysql_query($sql);

$ex="/tmp/adduser $loguser  $logpass";
shell_exec($ex);
@mkdir("../disk/$loguser",0777);
@mkdir("../tmpdisk/$loguser",0777);
@mkdir("../attach/$loguser",0777);
@mkdir("../attach/$loguser/tmp",0777);
@mkdir("../savefavorite/$loguser",0777);

echo "<BR><BR><BR><BR><center><a href = http://$config[domain]$config[folder]$config[filename]>Back To Login Page</a><BR><BR>";
echo "<a href = http://$config[domain]$config[folder]/OtwigSetup/Otwig_Setup.exe>Install Favorite Client Program</a></center>";

}//if


}else {

?>

<table width="97%" border="0" align="center" background="../pic/signup.jpg" height="425">
  <tr  valign="top">
    <td><table width="100%" border="0" align="center" height="430">
  <tr>
    <td width="57%">&nbsp;</td>

    <td valign="bottom"><form  method="post" action="newlog.php">
              <font face="MS Sans Serif, Tahoma, sans-serif"><strong>FirstName &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LastName</strong></font><BR>
			<input name="loguser" type="text">			<input name="loguser" type="text">

              <font face="MS Sans Serif, Tahoma, sans-serif"><strong>UserName</strong></font><BR>
			<input name="loguser" type="text">
              <BR><font face="MS Sans Serif, Tahoma, sans-serif"><strong>Password</strong></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font face="MS Sans Serif, Tahoma, sans-serif"><strong>RePassword</strong></font><BR>
			<input name="logpass" type="password">
			

			<input name="relogpass" type="password">
			<BR>			
			<input name="login" type="submit" value="Sign new">&nbsp;&nbsp;&nbsp;<input name="clear" type="reset" value="Clear">
			</form>
			</td>
          </tr>
</table>
</td>
  </tr>
</table>
<?php

}
?>