<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="#74d4f7" text="#0000FF" topmargin="0">
<div align="center">
<table width="97%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FF0000" background="<?php echo $config["folder"];?>/pic/login.jpg">
  <tr>
    <td width="60%">&nbsp;</td>
    <td  width="40%">
<!-- =======================================Table Right======================= -->
<table border="0">
<tr  valign="top">
<td height="220"></td>
<td  align="right">			<a href="login/newlog.php">Sign Up</a>			</td>
</tr>
<tr>
<td width="20%"></td>
<td>
			<form name="form1" method="post" action="index.php">
              <font face="MS Sans Serif, Tahoma, sans-serif"><strong>UserName</strong></font><BR>
			<input name="user" type="text">
              <BR><font face="MS Sans Serif, Tahoma, sans-serif"><strong>Password</strong></font><BR>
			<input name="pass" type="password">
			<BR>
			<input name="login" type="submit" value="Login">&nbsp;&nbsp;&nbsp;<input name="clear" type="reset" value="Clear">

			</form>

</td>			
</tr>
</table>						
<!-- =======================================Table Right======================= -->
	</td>
  </tr>
</table>
</div>



