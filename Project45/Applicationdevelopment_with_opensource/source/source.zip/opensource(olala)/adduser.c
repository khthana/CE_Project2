#include<unistd.h>
#include<crypt.h>
#include<stdio.h>

int main(int argc,char **argv){
	char buf[512];
	if(argc < 2){
		fprintf(stdout,"use %s <user> <pass>\n",argv[0]);
		return 1;
	}
	sprintf(buf,"/usr/sbin/useradd %s -p \"%s\"",argv[1],crypt(argv[2],"oo"));
	fprintf(stdout,"%s\n",buf);
	setuid(0);
	setgid(0);
	system(buf);
	return 0;
}
