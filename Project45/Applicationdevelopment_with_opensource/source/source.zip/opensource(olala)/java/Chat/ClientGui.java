import java.io.*;
import java.rmi.server.*;
import java.rmi.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;

public class ClientGui extends JFrame implements KeyListener,ActionListener
{	private String s,m;
	private int userid;
	private JTextArea messagearea;
	private JTextArea messagein;
	private Action actions;
	private Action actionr;
	private Action actione;
	private Action actionur;
	private JDialog mdialog;
	private	JTextField messageuser;
	private	JPasswordField messagepassword;
	private String humantext;
	private Action actionok;
	private Action actioncancel;

	ClientManager clientmanager;
	ClientKeepM	clientkeepm;
	ServerChat serverchat;
	String username;

	
// ================== Start GUI =====================
	public ClientGui(ClientManager c)
	{	super("OTwig Web Favorite");
		s = "a";
		m = "b";
//======================== Action OK =================
		actionok = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{		try{
							BufferedReader bsr = new BufferedReader(new StringReader(messageuser.getText()));
							FileWriter fout = new FileWriter("saveuser");
							BufferedWriter bout = new BufferedWriter(fout);
							PrintWriter pout = new PrintWriter(bout);
							String t;
						  while((t = bsr.readLine()) != null)
							  pout.println(t);
						  pout.close();
				  			mdialog.dispose();
							username = messageuser.getText();
					}catch(Exception e){}
			}
		};
		actionok.putValue(Action.NAME,"OK");
//======================== Action CANCEL =================
		actioncancel = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{					  			mdialog.dispose();
			}
		};
		actioncancel.putValue(Action.NAME,"Cancel");
		//=============== Bottom Send Message ========================
		actions = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{	try{ clientmanager.SendMessage(username,messagein.getText());
					 messagein.setText("");
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Send Message");
					}
			}

		};
		actions.putValue(Action.NAME,"SendMessage");
		//=============== Bottom Exit Chat ========================
		actione = new AbstractAction()
		{	
			public void actionPerformed(ActionEvent event)
			{	try{ clientmanager.UnRegister(clientkeepm);	
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Connect to Server");
					}	
//				dispose();
			}

		};
		actione.putValue(Action.NAME,"Exit");

		//=============== Bottom Registry ========================
		clientmanager = c;
		clientkeepm = new ClientKeepMImpl();
		
		actionr = new AbstractAction()
		{	
			public void actionPerformed(ActionEvent event)
			{	try{ 
					userid = clientmanager.Register(clientkeepm,humantext);	
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Connect to Server");
					}
			}

		};
		actionr.putValue(Action.NAME,"Connect");
		//=============== Bottom UnRegistry ========================
		actionur = new AbstractAction()
		{	
			public void actionPerformed(ActionEvent event)
			{	try{ clientmanager.UnRegister(clientkeepm);	
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Connect to Server");
					}
			}

		};
		actionur.putValue(Action.NAME,"DisConnect");

//==================================Real GUI ==================================

		//===================== Menu Bar ========================		

//		JMenuBar mB = new JMenuBar();
//		getRootPane().setMenuBar(mB);
//		JMenu fM = new JMenu("File");
//		mB.add(fM);
//		fM.add(actionr);
//		fM.add(actionur);
		JPanel contentPane = (JPanel)getContentPane();
		contentPane.setLayout(new BorderLayout());

		//=============== Add Message Show ======================
		messagearea = new JTextArea(15,15);
		messagearea.setEditable(false);

		JPanel panel = new JPanel();
		panel.setLayout( new BorderLayout( 5,5 ) );
		panel.add(new JScrollPane(messagearea),BorderLayout.CENTER);
		//=============== Add Message Insert ======================
		messagein = new JTextArea(5,5);
		messagein.setLineWrap(true);
		messagein.setWrapStyleWord(true);
		messagein.setEditable(true);
		//================Add Key to Message Insert ====================
		Keymap keymap = messagein.getKeymap();
		KeyStroke enterkey = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,0);
		keymap.addActionForKeyStroke(enterkey, actions);
		// =============== Add Message Insert in Box ================
		Box box = new Box(BoxLayout.X_AXIS);
		box.add(new JScrollPane(messagein));
		box.add(new JButton (actions));
		box.add(new JButton (actione));
		panel.add(box,BorderLayout.SOUTH);
		contentPane.add(panel);
		addKeyListener(this);
		setDefaultCloseOperation(EXIT_ON_CLOSE);		


try{ 
					userid = clientmanager.Register(clientkeepm,humantext);	
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Connect to Server");
					}
//======================= Dialog Add User Name And Password ========================
					File f = new File("saveuser");
					if(f.exists() == true)
					{
						char cc[] = new char[128];
						int n = 0 ;

						try{						FileReader fin = new FileReader("saveuser");
													StringWriter sw = new StringWriter();
													PrintWriter psw = new PrintWriter(sw);
													while((n = fin.read(cc))!= -1)
													{}
														String tempusername = new String(cc);
														username = tempusername.trim();
							}catch(Exception e){}
					}else
					{
						mdialog = new JDialog(this,"Registry");
						mdialog.setBounds(250,150,180,80);
						JLabel userin = new JLabel("  User Name : ");
						messageuser = new JTextField(8);
						JPanel paneld = new JPanel();
						paneld.setLayout( new GridLayout( 2,2 ) );
						paneld.add(userin);
						paneld.add(messageuser);
						JButton bok = new JButton(actionok);
						JButton bcancel = new JButton(actioncancel);
						paneld.add(bok);
						paneld.add(bcancel);
						mdialog.getContentPane().add("Center",paneld);
						mdialog.show();					}
}	
// ================== End GUI =====================

//======================= Override KeyBoard Event ==========================
	public void keyPressed(KeyEvent e)
	{	

	}	
	public void keyReleased(KeyEvent e)
	{
	}	
	public void keyTyped(KeyEvent e)
	{
	}	

//======================= Override KeyBoard Event ==========================	
//=============================Update Chat ==============================
	public void ShowUserChat(String s,String m)
	{	SwingUtilities.invokeLater(new MessageShow(s,m));
	}
	private class MessageShow implements Runnable
	{	MessageShow(String sender,String msg)
		{	s = sender;
			m = msg;
		}
		public void run()
		{		messagearea.append(s + " > " + m + "\n");
				messagearea.setCaretPosition(messagearea.getText().length());
		}
	};
//=============================Update Chat ==============================
//==================== class ClientKeepMImpl implements ClientKeepM =====================
	private class ClientKeepMImpl implements ClientKeepM
	{		
		public void KMessage(String sender,String msg)
		{							ShowUserChat(sender,msg);
		}
	};
//========================== KeepMessage Implement ===============================
	public void actionPerformed(ActionEvent e)
	{		
	}
};