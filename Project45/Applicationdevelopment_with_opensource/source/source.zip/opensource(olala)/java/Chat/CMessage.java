import java.io.*;
public class CMessage implements Serializable
{	private String sender,message;
	public CMessage()
	{	this("","");
	}
	public CMessage(String s,String m)
	{	sender = s;
		message = m;
	}
	public String getS()
	{	return sender;
	}
	public String getM()
	{	return message;
	}
}