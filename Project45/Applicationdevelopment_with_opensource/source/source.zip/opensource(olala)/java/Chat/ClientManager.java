import javax.swing.*;
import java.awt.*;
public interface ClientManager
{	public int Register(ClientKeepM c,String ht)
		throws Exception;
	public void UnRegister(ClientKeepM c)
		throws Exception;
	public void SendMessage(String f,String m)
		throws Exception;
	public ServerChat GetServer()
		throws Exception;
}