import java.rmi.*;
import javax.swing.*;
import java.awt.*;

public interface ServerChat extends Remote
{	public int AddClient(ClientChat  c ,String ht)
		throws RemoteException;
	public void DelClient(ClientChat  c)
		throws RemoteException;
	public void SendMessage(CMessage cm)
		throws RemoteException;		
}