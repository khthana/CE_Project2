import java.rmi.*;
public 	interface ClientChat extends Remote
{	public void ReceiveM(CMessage ms)
		throws RemoteException;
}