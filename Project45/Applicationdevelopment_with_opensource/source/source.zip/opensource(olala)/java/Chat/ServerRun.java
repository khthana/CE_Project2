import java.rmi.Naming;
import java.rmi.RMISecurityManager;
public class ServerRun
{
	public ServerRun()
	{try{
		ServerChatImpl s = new ServerChatImpl();
		Naming.rebind("rmi://161.246.6.92:2099/ChatService",s);
		}
	  catch(Exception e)
	     {	System.out.println("Troble:" + e);
		}	
	}
	public static void main(String args[])
	{	new ServerRun();
		System.out.println("Server Running");
	}
}