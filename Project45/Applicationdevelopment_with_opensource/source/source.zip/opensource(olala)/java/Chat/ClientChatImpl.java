import java.rmi.*;
import java.rmi.server.*;
import javax.swing.*;
import java.awt.*;
public class  ClientChatImpl extends UnicastRemoteObject implements ClientChat,ClientManager
{	private ClientKeepM ckm;
	private ServerChat serverchat;
	public  ClientChatImpl() throws RemoteException
	{	super();
	}
	public void ReceiveM(CMessage ms)
		throws RemoteException
		{	if(ckm != null)
			ckm.KMessage(ms.getS(),ms.getM());
		}
	public int Register(ClientKeepM c,String ht)
		throws Exception
		{	serverchat = (ServerChat) Naming.lookup("rmi://161.246.6.92:2099/ChatService");
			int amount = serverchat.AddClient(this,ht);
			ckm = c;
			return amount;
		}
	public void UnRegister(ClientKeepM c)
		throws Exception
		{	if( serverchat == null) return;
			serverchat.DelClient(this);
			serverchat = null;
		}
	public void SendMessage(String f,String m)
		throws Exception
		{	if( serverchat == null) return;
			CMessage chatmessage = new CMessage(f,m);
			serverchat.SendMessage(chatmessage);
		}
	public ServerChat GetServer()
		{	return(serverchat);
		}
}