import java.rmi.Naming;
import java.awt.*;
import java.awt.event.*;
class ClientRun
{
	public static void main(String args[]) throws Exception
	{	
		ClientManager cm;
		cm = new ClientChatImpl();
		ClientGui cg = new ClientGui(cm);
		cg.setBounds(125,10,500,550);
		cg.show();
		
	}
}