public interface ClientKeepM
{	public void KMessage(String sender,String msg);
}