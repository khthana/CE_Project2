import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.net.*;

public class ServerChatImpl extends UnicastRemoteObject	implements ServerChat
{	private Set clientreg = new HashSet();
	private int amountuser;
	private Map mp;
	private ImageIcon  userpic1;
	private String iconimageuser[];
	private Vector reg = new Vector();
	private Vector regnum = new Vector();
	public ServerChatImpl() throws RemoteException
	{	super();
		amountuser = 0;
	}
	public int AddClient(ClientChat  c,String ht)
		throws RemoteException
	{	synchronized (clientreg)
		{	reg.addElement(c);
			amountuser++;
			regnum.addElement(ht);
			return amountuser;
		}
	}
	public void DelClient(ClientChat  c)
		throws RemoteException
	{	synchronized (clientreg)
		{	clientreg.remove(c);
			amountuser--;
		}
	}


	public void SendMessage(CMessage cm)
		throws RemoteException
	{	
	Enumeration e = reg.elements();
	Enumeration enum = regnum.elements();
	while(e.hasMoreElements())
		{	ClientChat client = ( ClientChat ) e.nextElement();
			try{	client.ReceiveM(cm);
				}
			catch(Exception ee)
				{	System.err.println("Not Found Client");
				}	
		}
	}
	

}