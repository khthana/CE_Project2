import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.border.*;
import javax.swing.text.*;

public class ServerRun extends JFrame
{	private Action actionok;
	private Action actioncancel;
    private static final String SERVERNAME = "rmi://161.246.6.92/fileserver";
	private JButton human1;
	private JButton human2;
    private JTextField msgadduser;
    private JTextField msgaddgroup;
    private JTextField msgaddinfo;
    private JPasswordField msgaddpass;
    FavorImpl server;
    public ServerRun()throws Exception
    {        super("M_View_Server");
			 server = new FavorImpl();
        Naming.rebind( SERVERNAME, server );
    }
    public static void main(String args[])
    {
        try
        {
            new ServerRun();
            System.out.println("Server Ready.....");
        }
        catch( Exception e)
        {
            System.out.println("Troble:" + e);
            System.out.println("Server can't start.");
            System.exit(0);
            
        }
        
        
    }
}