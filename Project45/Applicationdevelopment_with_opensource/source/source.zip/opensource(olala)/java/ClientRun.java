import java.rmi.Naming;
import java.awt.*;
import java.awt.event.*;
class ClientRun
{
	public static void main(String args[]) throws Exception
	{	
	ClientGui cg = new ClientGui();

//		ClientDown cg = new ClientDown();
	
	}
}