import java.io.*;
import java.rmi.server.*;
import java.rmi.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
class  ClientDown extends JFrame 
{	private ClientManageImpl client;
	private Favor server;
	private ClientMsg cm;
	private String keepfile = new String("folder");
	private String pathname = new String("/var/www/html/project/savefavorite/");

	private JTextField messageuser;
	private JTextField messagepass;
	private JTextField messageuserser;
	private Action actionok;
	private Action actioncancel;
	private JCheckBox savepw;
	private String username;
	private String usernameser;

	private void conserver()
	{try{
				client = new ClientManageImpl();
				client.Login();
				server=client.GetServer();
				FileTranfer fav = server.DownloadFile(pathname);
				int leng = server.GetNumDir(pathname);
				String sfn[] = server.GetNameDir(pathname);
				keepfile = "/Documents and Settings/"+username+"/Favorites";
				for(int i = 0 ; i < leng;i++)
					{	boolean whattype = server.IsDir(pathname+"/"+sfn[i]);
						if (whattype == false)
						{	try{		       FileTranfer file= new FileTranfer(keepfile + "/" + sfn[i]);
									           FileOutputStream fout = new FileOutputStream(file);
								        	   fout.close();             
       FileReader in = new FileReader(fav);
        FileWriter out = new FileWriter(file);
        int c;
       while ((c = in.read()) != -1)
           out.write(c);

        in.close();
        out.close();
								}
							catch(Exception e){System.out.println("Can't Upload");}
						}else
						{	
							try{	int lenglocal = server.GetNumDir(pathname+"/"+sfn[i]);
									String sfnlocal[] = server.GetNameDir(pathname+"/"+sfn[i]);
									FileTranfer filelocal= new FileTranfer(keepfile + "/" + sfn[i]);
									filelocal.mkdir(); 
									for(int j = 0 ; j < lenglocal;j++)
									{			//FileTranfer favii = server.DownloadFile(pathname+ temp.getName()+ni[j]);
												FileTranfer file= new FileTranfer(keepfile + "/" + sfn[i]+"/"+ sfnlocal[j]);
												FileOutputStream fout = new FileOutputStream(file);
								        		fout.close();                
       FileReader in = new FileReader(fav);
        FileWriter out = new FileWriter(file);
        int c;
       while ((c = in.read()) != -1)
           out.write(c);

        in.close();
        out.close();

									}
							}
							catch(Exception e){System.out.println("Can't Upload");}
						}
					}
/*				String n[] = fav.list();
				for(int i = 0 ; i < n.length;i++)
				{	FileTranfer temp = server.DownloadFile(pathname+n[i]);
					if(temp.isDirectory() == false)
					{		try{		       FileTranfer file= new FileTranfer(keepfile + "/" + temp.getName());
									           FileOutputStream fout = new FileOutputStream(file);
								        	   fout.close();             
								}
							catch(Exception e){System.out.println("Can't Upload");}
					}else
					{	try{		FileTranfer favi = server.DownloadFile(pathname + temp.getName());
									String ni[] = favi.list();
								   File fupload = new File(keepfile + "/" + favi.getName());
									fupload.mkdir(); 
									for(int j = 0 ; j < ni.length;j++)
									{			FileTranfer favii = server.DownloadFile(pathname+ temp.getName()+ni[j]);
												FileTranfer file= new FileTranfer(keepfile + "/" + temp.getName()+"/"+ favii.getName());
												FileOutputStream fout = new FileOutputStream(file);
								        		fout.close();                
									}
							}
							catch(Exception e){System.out.println("Can't Upload");}
					}
				}*/
					}	catch(Exception ee){System.out.println("CAN't");}
}
	
	public ClientDown()throws RemoteException
    {		       super("Favorite");
	//=============== Bottom OK ========================
		actionok = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{	try{	
				username = messageuser.getText();
				usernameser = messageuserser.getText();
  			    keepfile = new String( "/Documents and Settings/"+username+"/Favorites");
				pathname = new String( "/var/www/html/project/savefavorite/"+usernameser+"/");
				conserver();
				if (  savepw.isSelected() == true)
						{ 
							BufferedReader bsr = new BufferedReader(new StringReader(messageuser.getText()));
							FileWriter fout = new FileWriter("saveuser");
							BufferedWriter bout = new BufferedWriter(fout);
							PrintWriter pout = new PrintWriter(bout);
							String t;
						  while((t = bsr.readLine()) != null)
							  pout.println(t);
						  pout.close();
						
							BufferedReader bsr1 = new BufferedReader(new StringReader(messagepass.getText()));
							FileWriter fout1 = new FileWriter("savepw");
							BufferedWriter bout1 = new BufferedWriter(fout1);
							PrintWriter pout1 = new PrintWriter(bout1);
							String t1;
						  while((t1 = bsr1.readLine()) != null)
							  pout1.println(t1);
						  pout1.close();
						}
						System.exit(0);
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientDown.this,"Cann't Send Message");
					}
			}

		};
		actionok.putValue(Action.NAME,"OK");
//==============================================================
	//=============== Bottom Cancel ========================
		actioncancel = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{	try{						System.exit(0);
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientDown.this,"Cann't Send Message");
					}
			}

		};
		actioncancel.putValue(Action.NAME,"Cancel");
//==============================================================
				File f = new File("saveuser");
					if(f.exists() == true)
					{	
						char c[] = new char[128];
						int n = 0 ;

						try{						FileReader fin = new FileReader("saveuser");
													StringWriter sw = new StringWriter();
													PrintWriter psw = new PrintWriter(sw);
													while((n = fin.read(c))!= -1)
													{}
														String tempusername = new String(c);
														username = tempusername.trim();
							pathname = new String( "/var/www/html/project/savefavorite/"+username+"/");
							conserver();
							System.exit(0);
							}catch(Exception e){}
					}else
					{	JPanel contentPane = (JPanel)getContentPane();
						JPanel panel = new JPanel();
						panel.setLayout( new GridLayout( 5,2 ) );
						JLabel userin = new JLabel("  User Client : ");
						JLabel userser = new JLabel("  User Server : ");
						JLabel userpass = new JLabel("  Password : ");
						JLabel mempass = new JLabel("  Save Password : ");
						messageuser = new JTextField(8);
						messagepass = new JPasswordField(8);
						messageuserser = new JTextField(8);
						savepw = new JCheckBox();
						panel.add(userin);
						panel.add(messageuser);
					panel.add(userser);
						panel.add(messageuserser);
							panel.add(userpass);
						panel.add(messagepass);
						panel.add(mempass);
						panel.add(savepw);
						JButton bok = new JButton(actionok);
						JButton bcancel = new JButton(actioncancel);
						panel.add(bok);
						panel.add(bcancel);
						contentPane.add(panel);
						setBounds(250,200,220,120);
						show();
					}
	}

}
