import java.rmi.*;
import javax.swing.*;
public 	interface ClientManage extends Remote {
    public void  Login()
		    throws RemoteException;
}