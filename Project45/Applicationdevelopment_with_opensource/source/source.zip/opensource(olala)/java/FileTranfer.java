import java.io.*;
public class FileTranfer extends File implements Serializable
{	public String pathname;
    public FileTranfer(File parent, String child)
    {
        super( parent, child );
    }
	public void SetPath(String a)
	{	pathname = a;
	}
	public String GetPath()
	{	return pathname;
	}

    // Creates a new File instance by converting the given pathname string into an abstract pathname.
    public FileTranfer(String pathname)
    {
        super( pathname );
    }
    // Creates a new File instance from a parent pathname string and a child pathname string.
    public FileTranfer(String parent, String child)
    {
        super( parent, child );
    }
    // Creates a new File instance
    
    public FileTranfer(File file)
    {
        super(file.getPath());
    }
    /*public byte[] getBytes()
    {
        return data;
    }
    public void Empty()
    {
        data = null;
    }
    public boolean isEmpty()
    {
        return (data == null);
    }
    public int read( File file)
    {
        if( file.exists() )
        {
            try
            {
                FileInputStream fin = new FileInputStream( file );
                int cnt = fin.available();
                data = new byte[cnt];
                fin.read(data);
                fin.close();
                return CtrlStatus.COMPLETE;
            }
            catch( IOException ioex )
            {
                return CtrlStatus.INCOMPLETE;
            }
     
        }
        else
        {
            return CtrlStatus.NOT_FOUND;
        }
    }
    public int write( File file ,boolean overwrite)
    {
        if( file.exists() && overwrite )
        {
            try
            {
     
                FileOutputStream fout = new FileOutputStream( file );
                fout.write(data);
                fout.close();
                return CtrlStatus.COMPLETE;
            }
            catch( IOException ioex )
            {
                return CtrlStatus.INCOMPLETE;
            }
     
        }
        else
        {
            return CtrlStatus.NOT_FOUND;
        }
     */
}