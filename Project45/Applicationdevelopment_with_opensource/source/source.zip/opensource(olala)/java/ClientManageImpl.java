import java.rmi.*;
import java.rmi.server.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;

class ClientManageImpl extends UnicastRemoteObject implements ClientManage
{	   private String URL = "rmi://161.246.6.92:1099/fileserver";
	   private Favor server = null;
	   public  ClientManageImpl() throws RemoteException
    {    super();
    }

		public void  Login()
		    throws RemoteException
		{	        try{	server = (Favor) Naming.lookup(URL);
						}
					catch(Exception e){System.out.println("Cann't Connect To Server");}
		}

		public Favor  GetServer()
		{	        return server;
		}

}
