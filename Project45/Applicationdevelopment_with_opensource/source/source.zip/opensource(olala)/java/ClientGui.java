import java.io.*;
import java.rmi.server.*;
import java.rmi.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;
class  ClientGui extends JFrame 
{	private ClientManageImpl client;
	private Favor server;
	private String pathname;
	private JTextField messageuser;
	private JTextField messagepass;
	private JTextField messageuserser;
	private Action actionok;
	private Action actioncancel;
	private JCheckBox savepw;
	private String username;
	private void DirSend(String a)
	{			File fav = new File(a);
				String n[] = fav.list();
				for(int i = 0 ; i < n.length;i++)
				{	File temp = new File(n[i]);
					if(temp.isDirectory() == false)
					{		try{		FileTranfer chosen = new FileTranfer(pathname+a+temp.getName());
//										server.UploadFile( chosen);
								}
							catch(Exception e){System.out.println("Can't Upload");}
					}else
					{	try{
						FileTranfer chosen = new FileTranfer(pathname+temp.getName());
						server.ChangeDir( chosen);
						DirSend(pathname+temp.getName());
							}
							catch(Exception e){System.out.println("Can't Upload");}
					}
				}
	}
	private void conserver()
	{//===================================================Connect Server=====================				
				try{			client = new ClientManageImpl();
								client.Login();
								server=client.GetServer();
								server.Login(messageuser.getText());
				}catch(Exception ee){System.out.println("Cant");}
				File fav = new File(pathname);

				String n[] = fav.list();
				for(int i = 0 ; i < n.length;i++)
				{	File temp = new File(pathname+n[i]);
					if(temp.isDirectory() == false)
					{		try{		FileTranfer chosen = new FileTranfer(pathname+temp.getName());
										byte infile[];
										FileInputStream fin = new FileInputStream(pathname+temp.getName());
										ByteArrayOutputStream bout = new ByteArrayOutputStream();
										int c;
										while((c = fin.read())!= -1)	 bout.write((byte)c);
										bout.close();
										fin.close();
//										System.out.println(new String(bout.toByteArray(),0,10));
//										System.out.println(bout.toByteArray());
//										ByteArrayInputStream fin1 = new ByteArrayInputStream(bout.toByteArray());
//										FileOutputStream bin = new FileOutputStream("tmp");										
//										while((c = fin1.read())!= -1)	 bin.write((byte)c);
										server.UploadFile( chosen,bout.toByteArray() );
									}
							catch(Exception e){System.out.println("Can't Upload");}
					}else
					{	try{			FileTranfer chosen = new FileTranfer(pathname+temp.getName());
										chosen.SetPath(temp.getName());
										server.ChangeDir( chosen);
										DirSend(pathname+temp.getName());
										server.ResetDir(messageuserser.getText());
								}
							catch(Exception e){System.out.println("Can't Upload");}

					}
				}
		//===================================================
	}
	public ClientGui()throws RemoteException
    {	       super("Favorite");
	//=============== Bottom OK ========================
		actionok = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{	try{	
				username = messageuser.getText();
				pathname = new String( "/Documents and Settings/"+username+"/Favorites/");
				System.out.println(pathname);
				conserver();
				if (  savepw.isSelected() == true)
						{ 
							BufferedReader bsr = new BufferedReader(new StringReader(messageuser.getText()));
							FileWriter fout = new FileWriter("saveuser");
							BufferedWriter bout = new BufferedWriter(fout);
							PrintWriter pout = new PrintWriter(bout);
							String t;
						  while((t = bsr.readLine()) != null)
							  pout.println(t);
						  pout.close();
						
							BufferedReader bsr1 = new BufferedReader(new StringReader(messagepass.getText()));
							FileWriter fout1 = new FileWriter("savepw");
							BufferedWriter bout1 = new BufferedWriter(fout1);
							PrintWriter pout1 = new PrintWriter(bout1);
							String t1;
						  while((t1 = bsr1.readLine()) != null)
							  pout1.println(t1);
						  pout1.close();
						}
						System.exit(0);
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Send Message");
					}
			}

		};
		actionok.putValue(Action.NAME,"OK");
//==============================================================
	//=============== Bottom Cancel ========================
		actioncancel = new AbstractAction()
		{
			public void actionPerformed(ActionEvent event)
			{	try{						System.exit(0);
					}
				catch(Exception e)
					{	JOptionPane.showMessageDialog(ClientGui.this,"Cann't Send Message");
					}
			}

		};
		actioncancel.putValue(Action.NAME,"Cancel");
//==============================================================
					File f = new File("saveuser");
					if(f.exists() == true)
					{	
						char c[] = new char[128];
						int n = 0 ;

						try{						FileReader fin = new FileReader("saveuser");
													StringWriter sw = new StringWriter();
													PrintWriter psw = new PrintWriter(sw);
													while((n = fin.read(c))!= -1)
													{}
														String tempusername = new String(c);
														username = tempusername.trim();
							pathname = new String( "/Documents and Settings/"+username+"/Favorites/");
							conserver();
							System.exit(0);
							}catch(Exception e){}
					}else
					{	JPanel contentPane = (JPanel)getContentPane();
						JPanel panel = new JPanel();
						panel.setLayout( new GridLayout( 5,2 ) );
						JLabel userin = new JLabel("  User Client : ");
						JLabel userser = new JLabel("  User Server : ");
						JLabel userpass = new JLabel("  Password : ");
						JLabel mempass = new JLabel("  Save Password : ");
						messageuser = new JTextField(8);
						messageuserser = new JTextField(8);
						messagepass = new JPasswordField(8);
						savepw = new JCheckBox();
						panel.add(userin);
						panel.add(messageuser);
						panel.add(userser);
						panel.add(messageuserser);
						panel.add(userpass);
						panel.add(messagepass);
						panel.add(mempass);
						panel.add(savepw);
						JButton bok = new JButton(actionok);
						JButton bcancel = new JButton(actioncancel);
						panel.add(bok);
						panel.add(bcancel);
						contentPane.add(panel);
						setBounds(250,200,220,120);
						show();
					}
	}
}
