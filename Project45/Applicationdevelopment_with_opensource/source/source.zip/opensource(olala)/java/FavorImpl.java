import java.rmi.*;
import java.rmi.server.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.io.File.*;

class FavorImpl extends UnicastRemoteObject implements Favor 
{     	private String keepfile = new String("/var/www/html/project/savefavorite");
		private int maxinfolder;
   public FavorImpl() throws RemoteException
	{        super();
			maxinfolder = 0;
   }

	public void UploadFile(FileTranfer filetranfer,byte ina[])
		    throws RemoteException
	{			     
		try
			{	 
		int datum;
//				FileInputStream fin = new FileInputStream(filetranfer);
//				File fupload = new File( filetranfer.getName());
//				String n[] = filetranfer.list();
//				fupload.mkdir(); 
//				for(int i = 0 ; i < n.length;i++)
//				{	FileOutputStream fout = new FileOutputStream("file\\"+n[i]);
//					fout.close();
//					System.out.println(n[i]);
//				}
				// save file to Folder
				int cc;
//				File file= new File(keepfile  + "/" + filetranfer.getName());
//	            FileOutputStream fout = new FileOutputStream(file);
				ByteArrayInputStream fin1 = new ByteArrayInputStream(ina);
				FileOutputStream bin = new FileOutputStream(keepfile  + "/" + filetranfer.getName());										
				while((cc = fin1.read())!= -1)	 bin.write((byte)cc);
				bin.close();                
				fin1.close();                
//       FileReader in = new FileReader(filetranfer);
  //      FileWriter out = new FileWriter(file);
    //    int c;
      // while ((c = in.read()) != -1)
        //   out.write(c);

//        in.close();
  //      out.close();

	        }
        catch( Exception ex )
        { System.out.println(" failedupload.");}
	}
    public FileTranfer DownloadFile(String fname)
		    throws RemoteException
	{		FileTranfer fav = new FileTranfer(fname);
			return fav;
	}
    public int GetNumDir(String folname)
		    throws RemoteException
	{	File fav = new File(folname);	
		String n[] = fav.list();
		return n.length;
	}
    public boolean IsDir(String typename)
		    throws RemoteException
	{	File fav = new File(typename);	
		if(fav.isDirectory() == true)
		return true;
		else 
		return false;
	}
    public String[] GetNameDir(String folname)
		    throws RemoteException
	{	File fav = new File(folname);	
		String n[] = fav.list();
		return n;
	}
	public void ChangeDir(FileTranfer filetranfer)
		    throws RemoteException
	{				
		try{	File fupload = new File(keepfile  + "/" +  filetranfer.getName());
				fupload.mkdir(); 
	//            File file= new File(keepfile + "/" + filetranfer.getName());
//	            FileOutputStream fout = new FileOutputStream(file);
  //      	    fout.close();                
			keepfile = keepfile+"/"+filetranfer.GetPath();
			}catch(Exception e){System.out.println("error");};
	}
	public void ResetDir(String usern)
	    throws RemoteException
	{	keepfile = "/var/www/html/project/savefavorite/"+usern;
	}
	public void ResetDirReal()
	    throws RemoteException
	{	//keepfile = "file/"+usern;
keepfile = "/var/www/html/project/savefavorite";
	}
	
	public void Login(String usern)
		    throws RemoteException
	{	keepfile = keepfile+"/"+usern;
	}

public byte[] DownData(String fname)
		    throws RemoteException
	{		ByteArrayOutputStream bout = new ByteArrayOutputStream();
			try {  					FileTranfer chosen = new FileTranfer(fname);
										byte infile[];
										FileInputStream fin = new FileInputStream(fname);
										int c;
										while((c = fin.read())!= -1)	 bout.write((byte)c);
										bout.close();
										fin.close();
				}catch(Exception e){System.out.println("NOT HAVE FILE");}
			return bout.toByteArray() ;
	}
}

