import java.rmi.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
public interface Favor extends Remote{
    public void UploadFile(FileTranfer filetranfer,byte a[])
		    throws RemoteException;
    public void Login(String usern)
		    throws RemoteException;
    public FileTranfer DownloadFile(String fname)
		    throws RemoteException;
    public int GetNumDir(String folname)
		    throws RemoteException;
    public String[] GetNameDir(String folname)
		    throws RemoteException;
    public boolean IsDir(String typename)
		    throws RemoteException;
	public void ChangeDir(FileTranfer filetranfer)
		    throws RemoteException;
	public void ResetDir(String usern)
		    throws RemoteException;
	public void ResetDirReal()
		    throws RemoteException;
	public byte[] DownData(String fname)
		    throws RemoteException;
}