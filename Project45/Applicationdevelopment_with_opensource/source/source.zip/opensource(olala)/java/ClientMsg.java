import java.rmi.*;
public interface ClientMsg extends Remote{
    public void ReceiveFile(FileTranfer filetranfer)
		    throws RemoteException;
}