<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

 $dir=urldecode($dir);
 $fi=urldecode($file);
 $touser=urldecode($to);
$size =urldecode($size);
   $bb=$HTTP_COOKIE_VARS["user"];

if($dir =="standard" ) $dfile = $bb;
else $dfile = "$bb/$dir";


$ex="cp /var/www/html/project/disk/$dfile/$fi  /var/www/html/project/tmpdisk/$touser/$fi";
shell_exec($ex);


mysql_query("DELETE FROM filetomem WHERE userrecive<>0");

$sql="INSERT INTO filetomem(fromuser,touser,filename,filesize)VALUES('$bb','$touser','$fi','$size')";
$result = mysql_query($sql);




header("location:http://$config[domain]$config[folder]$config[filename]?page=400&&subpage=500&&d=1&&dir=$dir&&to=$touser");
mysql_close();




//echo $file."<br>";
//echo $touser."<br>";
//echo $dfile;
?>

