<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

 $file=urldecode($file);
 $from=urldecode($from);
$ok =urldecode($ok);
$size=urldecode($size);
$bb=$HTTP_COOKIE_VARS["user"];

if($ok==1) {


$query = "select * from userpass where username='$bb'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row

$row = mysql_fetch_array($result); //push to array form result

$sp = $row[udisk];
$sp =$size+$sp;   

if($sp>=11000000)
{
echo "file �բ�Ҵ�˭��Թ� �����§�͡Ѻ���ͷ��������� ";
}

if($sp<=11000000)
{
$ex="mv /var/www/html/project/tmpdisk/$bb/$file  /var/www/html/project/disk/$bb/$file";
//$ex="cp /var/www/html/project/disk/$dfile/$fi  /var/www/html/project/tmpdisk/$touser/$fi";
mysql_query("update filetomem set userrecive=1 where touser ='$bb'  and fromuser= '$from' and filename ='$file' "  );

$sql="update  userpass set udisk=udisk+$size where username = '$bb'";
$result = mysql_query($sql);

shell_exec($ex);
} //if   sp

}

if($ok==0) {

$ex="rm /var/www/html/project/tmpdisk/$bb/$file";

mysql_query("update filetomem set userrecive=1 where touser ='$bb'  and fromuser= '$from' and filename ='$file' "  );

shell_exec($ex);
}

mysql_query("DELETE FROM filetomem WHERE userrecive<>0");


header("location:http://$config[domain]$config[folder]$config[filename]?page=400&&subpage=700&&from=$from");
mysql_close();

?>

