<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);

 $dir=urldecode($dir);
 $fi=urldecode($file);
$size = urldecode($size);

$sql="update  userpass set udisk=udisk-$size where username = '$bb'";
$result = mysql_query($sql);

if($dir =="standard" ) $dfile = $bb;
else $dfile = "$bb/$dir";


unlink("/var/www/html/project/disk/$dfile/$fi");
header("location:http://$config[domain]$config[folder]$config[filename]?page=400&&subpage=300&&d=1&&dir=$dir");
mysql_close();
?>

