<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">
<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
  $bb=$HTTP_COOKIE_VARS["user"];

 $d=urldecode($d);
 $adir=urldecode($dir);
$touser = urldecode($to);
 echo"  <A HREF=$config[folder]$config[filename]?page=300&&subpage=900><h3>Main</h3></a>";
 echo"  <A HREF=$config[folder]$config[filename]?page=400&&subpage=500&&to=$touser><h3>Back</h3></a>";

if($d!=null) echo "<font color =red>File sended </font><br>";





if(($udir!=null)or($d!=null)) {

if($adir!=null) 
{
   if($adir=="standard")  { $tdir = $bb;  echo "send file at folder $bb"; }
  else {  $tdir = "$bb"."/"."$dir";  echo "send file at folder $adir";  }
 
$todir = $adir;
 $adir =null;
}

else {
if($todir=="standard")  { $tdir = $bb;  echo "send file at folder $bb"; }
else {  $tdir = "$bb"."/"."$todir";  echo "send file at folder $todir";  }
}

echo "<table border =1 width = 60%>";
echo "<tr> <td><center><font color = green> filename ";
echo "<td><center><font color = green><b> size</b>";
echo "<td><center> Send ";


$my = opendir("/var/www/html/project/disk/$tdir"); 

while($en = readdir($my)){

if(($en==".")or($en=="..")) continue;


$y = "/var/www/html/project/disk/$tdir/$en"; 
if(is_dir($y))  {
echo "<tr> <td> \ $en<br> ";
echo "<td> &nbsp </td>";
echo "<td> &nbsp </td>"; }


else { 


$a = "$tdir/$en";

$b = null;
$yy = strlen($a);

for($i=0;$i<$yy;$i++)
{ 

$t = bin2hex($a[$i]);
$tt = bin2hex('�');

if($t>=$tt)   {
$b = "$b"."%$t"; 
} //if

if($t<$tt)   {
$b = "$b"."$a[$i]"; 
} //if

} //for 

$a = $b;

$gg = filesize($y);


echo "<tr> <td>  <A HREF=$config[folder]/disk/$a  target = blank style=text-decoration:none>$en</a>   ";

echo "<td align = right><font color = red> $gg";
echo "<td> <center> <A HREF=$config[folder]$config[filename]?page=400&&subpage=600&&dir=$todir&&file=$en&&to=$touser&&size=$gg  style=text-decoration:none>Ok</a> ";
}//else

} //while
closedir($my);
$d = null;  
} //if

else {

$query = "select * from userdir where username='$bb'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row


echo "<form action = http://$config[domain]$config[folder]$config[filename]?page=400&&subpage=500&&to=$touser method=post >";


echo "<br>view file at  directory : <select name =todir>";
for($i=0;$i<$num;$i++)
{
 $row = mysql_fetch_array($result); //push to array form result
 echo "<option value=$row[dirname]>Sub folder $row[dirname]</option>";
}
echo "<option value=standard>Folder $bb</option>";
echo "</select>";
echo "<input type=submit name = udir value=ok><br> ";
}
?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>