<?php
session_start();
$user = $HTTP_POST_VARS['user'];
$pass = $HTTP_POST_VARS['pass'];

if(session_is_registered("reg_id"))
$gen_id = $reg_id;
else $gen_id = 8;

require("config/config.inc.php");
require("config/dbconfig.inc.php");
if(($user ==null) or ($pass==null))
{  
   if($HTTP_COOKIE_VARS["s_id"] != $gen_id)
   { require("login/login.inc.php"); 

    }
   else
   {   $page = urldecode($page);
	  $subpage = urldecode($subpage);
	  setcookie ("s_id", $gen_id,time()+3600);
	  setcookie ("user", $HTTP_COOKIE_VARS["user"],time()+3600);		
	   $bb=$HTTP_COOKIE_VARS["user"];

                  switch($page)
	  { case 100; 	{ 
               require("main/online.php");
           require("main/main.inc.php");
	  			           break;
	  		     	}
	
        case 200;
        	{
		                switch($subpage)
						{case 100;	{	require("mail/mail.inc.php");	

										break;
									}
						 case 200;	{	require("mail/read.inc.php");

						 				break;
						 			}
						case 300; {  require ("mail/minemail.php");
						 break;}
						 
                        case 400; { require ("mail/book.php"); break;}
						    case 450; { require ("mail/tbook.php"); break;}
                        case 500; { require("mail/book1.php");break;}
						case 600; { require("mail/book2.php");break;}
                   	 case 700;	{	require("mail/viewattach.inc.php");

						 				break;
						 			}
						 case 800;	{	require("mail/delete.inc.php");

						 				break;
						 			}
                        }
	  				        require("main/online.php");
                          	break;
	  				}
		case 300;
        	{	
                switch($subpage)
						{case 100;	{	require("function/calen.fn.php");	
										require("board/board.inc.php");
									    break;
									}
				 		 	case 200;	{ require("board/fn.wb.php");
                                  require("board/pri1.php");
						 				break;	
                                     }
	                        case 250;	{	require("board/priread.php");
						 				break;	
                                   }

                             case 300;	{  require("board/fn.pri.php");	
                                 require("board/pri2.php");
						 			break;	
                                    }
                           case 350;	{	require("board/tpri2.php");
						 			break;	
                                    }
                            case 450;	{	require("board/tpri1.php");
						 			break;	
                                    }

                          case 600;	{	require("board/wb1.php");
						 				break;	
                                     }
                       	case 700;	{	require("board/wb2.php");
						 				break;	
                                     }
                         	case 800;	{	require("board/wb3.php");
						 				break;	
                                     }
                         	case 900;	{	require("board/checkonline.php");
					 				break;	
                                     }
                        }					
						require("main/online.php");
                        break;
	  			
                      	}								
		case 400; 	{
            	switch($subpage)
		{
	case 200;	{	require("site_manage/copy.php");	
				break;	}

	case 100;	{	require("site_manage/smain.php");	
				break;	}
	case 300;	{	require("site_manage/listdir.php");	
				break;	}
	case 400;	{	require("site_manage/dlistdir.php");	
				break;	}
	case 500;	{	require("site_manage/sendfile.php");	
				break;	}
	case 600;	{	require("site_manage/sfile.php");	
				break;	}
	case 700;	{	require("site_manage/refile.php");	
				break;	}
	case 800;	{	require("site_manage/arkrecive.php");	
				break;	}

	
         	  				}
                       require("main/online.php");
                               	break;
	  				}								
		
        case 500;
         	{	
                 switch($subpage)
						{case 100;	{	require("c_panel/group.php");	
										break;
									}
					     case 200;	{	require("c_panel/g3.php");
						 				break;
						 			}
	  					case 300;	{	require("c_panel/g4.php");
						 				break;
						 			}
	                     case 400;	{	require("c_panel/g2.php");
						 				break;
						 			}
                        case 500;	{	require("c_panel/g5.php");
						 				break;
						 			}
	                     case 600;	{	require("c_panel/g6.php");
						 				break;
						 			}
                        case 700;	{	require("c_panel/g1.php");
						 				break;
						 			}
                    case 800;	{	require("c_panel/g7.php");
						 				break;
						 			}
 case 850;	{	require("c_panel/g8.php");
						 				break;
						 			}
	          

                           }
                          require("main/online.php");
                            break;
                             }	  				
        case 600;       {   setcookie ("s_id", $s_id,time()+0);
						session_destroy();
						require("login/login.inc.php");
	  					break;
	  				}								

	  }
   }
}else 
{ 
require("function/fndb.fn.php");
$tnum=checkauth($user,$pass)   ;
if($tnum==0) {require("login/login.inc.php"); echo "no user"; }
if($tnum==2) {require("login/login.inc.php"); echo "worng"; }
if($tnum==1) 
{ $gen_id = session_id();
setcookie ("s_id", $gen_id,time()+3600);
setcookie ("user", $user,time()+3600);

  $reg_id = $gen_id;	
  session_register("reg_id");
  require("main/main.inc.php");
  require("main/newonline.php"); 
}
}
?>
