<?php

$ex="/tmp/adduser num  num";
shell_exec($ex);
echo "gfgf";
?>

