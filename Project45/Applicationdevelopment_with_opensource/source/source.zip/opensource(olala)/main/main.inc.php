<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" align="center">
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR>
		<TD>

			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">
    <?php
            require("function/calen.fn.php");
        $tdate = getdate(time());
        $tt=$tdate["mon"];
		echo"<div align=\"right\">";
		echo date("j");
echo "&nbsp&nbsp&nbsp&nbsp";
if($tt==1) echo "���Ҥ� ";
if($tt==2) echo"����Ҿѹ�";
if($tt==3) echo "�չҤ�";
if($tt==4) echo "����¹" ;
if($tt==5) echo "���Ҥ�"  ;
if($tt==6) echo "�Զع�¹" ;
if($tt==7) echo "�á�Ҥ�"   ;
if($tt==8) echo "�ԧ�Ҥ�" ;
if($tt==9) echo "�ѹ��¹" ;
if($tt==10) echo "���Ҥ� " ;
if($tt==11) echo "��Ȩԡ�¹";
if($tt==12) echo "�ѹ�Ҥ�" ;
echo "  &nbsp;&nbsp;2003  &nbsp;&nbsp;&nbsp;&nbsp;";
echo "</div>";
?>
<IMG SRC="<?php echo $config["folder"];?>/pic/taotu.gif" >
<?php
if ($HTTP_POST_VARS["user"] != null)
$userhi = $HTTP_POST_VARS["user"];
else
$userhi = $HTTP_COOKIE_VARS["user"];
echo "<font color=\"blue\" size=\"+1\">���ʴդس </font><font color=\"#FF0000\" size=\"+2\"><B>".$userhi."</B></font>";
echo "<BR><BR>";
echo "<DIV align=\"center\">";
selectmonth(0,1,0);
echo "</div>";
    ?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>