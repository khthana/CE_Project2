<?php
//echo "$bb<br>";
mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
mysql_select_db($dbconfig["DBname"]);

$timeoutseconds = 120; //�����������Ѻ�礤��͹�Ź� ���Թҷ� 300= 5 �ҷ�
$timestamp=time();
$timeout=$timestamp-$timeoutseconds;

mysql_query("DELETE FROM useronline WHERE timestamp<$timeout");
$result= mysql_query("select * from useronline where user ='$bb' ");
$num1 = mysql_num_rows($result);

if($num1==0)
{ mysql_query("INSERT INTO useronline VALUES ('$bb','$timestamp')");}
else
{ mysql_query("update useronline set timestamp='$timestamp' where user ='$bb'");}

mysql_close();
?>


