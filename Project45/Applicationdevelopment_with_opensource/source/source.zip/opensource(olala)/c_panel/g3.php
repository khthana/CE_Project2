<?php
//session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>
<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF"><BR>
	  	  <div align="center"><table><tr><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td><td><font color="#3300FF" size="+1" face="MS Sans Serif, Tahoma, sans-serif"><strong>&nbsp;&nbsp;Create Your Group&nbsp;&nbsp;</strong></font></td><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td></tr></table></div><BR>
<?php
$ex=0;
 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
$tmpuser = $HTTP_COOKIE_VARS["user"];
if($cgroup!="")
 {
$query = "select * from usergroup where groupname='$cgroup'" ;
$result =mysql_query($query);
$num = mysql_num_rows($result);

if($num==0) {
 $sql = "insert into insidegroup(username,groupname)values('$tmpuser','$cgroup')" ;
$result = mysql_query($sql);

 $sql = "insert into usergroup(groupname,usercreate)values('$cgroup','$tmpuser')" ;
 $result = mysql_query($sql);
}
else { echo " this group has created by another people  please try again  ";  }

echo "<br><a href =$config[folder]$config[filename]?page=500&&subpage=200> back to create </a> ";
} //if

else  {
echo "<form action=$config[folder]$config[filename]?page=500&&subpage=200 method=post>
<font color=\"#000099\" size=\"+2\">Room Name :</font> <BR><input type=text name=cgroup size=20><br><BR>
<input type=submit value=ok>
<input type=reset value=cancel> ";
}
MYSQL_CLOSE();
?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
