<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>
<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF"><BR>
	  	  <div align="center"><table><tr><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td><td><font color="#3300FF" size="+1" face="MS Sans Serif, Tahoma, sans-serif"><strong>&nbsp;&nbsp;Forward mail&nbsp;&nbsp;</strong></font></td><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td></tr></table></div><BR>

<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
$bb = $HTTP_COOKIE_VARS["user"];
//echo $user;

$query = "select * from formail where user='$bb'" ;
$result =mysql_query($query);
$num = mysql_num_rows($result);
if($num==1)
{

$query = "select * from formail where user = '$bb'"; //order rows
$result =mysql_query($query);  // oder rows
$num = mysql_num_rows($result); //count row
$ch=0;$i =0;

echo "<table width=\"95%\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" bordercolor=\"black\" bgcolor=\"#FFFFCC\">";
echo "<tr valign=\"top\" bgcolor=\"#0099FF\" align=\"center\">";
echo" <td><center><font size=\"+1\"><b> user</b></font>";
echo "<td><center><font size=\"+1\"><b> forward to</b></font>";
echo "<td><center><font size=\"+1\"><b> disable</b></font>";

while ($i<$num){
$row = mysql_fetch_array($result); //push to array form result
$user = $row[user];
$dest = $row[destmail];
echo "<tr><td><center>$user";
 echo "<td><center>  $dest";
echo "<td><center><a href=$config[folder]$config[filename]?page=500&&subpage=850 style=text-decoration:none>***</a>";
$i++;}


}


if($formail!=null)
{

$wri = "$bb@olala02.ce.kmitl.ac.th  $fmail\n";
$fp = fopen("/etc/mail/virtusertable","a+");
fwrite($fp,$wri);
fclose($fp); 
echo "�к��ӡ��  Forward mail  ���س���� ����ö��ҹ����ѹ���� ";
echo "<a href=$config[folder]$config[filename]?page=500&&subpage=800 style=text-decoration:none>��Ǩ�ͺ��÷ӧҹ</a>";

  $sql="INSERT INTO formail(user,destmail)VALUES('$bb','$fmail')";
  $result = mysql_query($sql);
//header("location:http://$config[domain]$config[folder]$config[filename]?page=500&&subpage=800");

}

if(($formail==null)and($num==0))
{

echo "<form action=$config[folder]$config[filename]?page=500&&subpage=800 method=post>
<font color=\"#000099\" size=\"+2\">Destination mail :</font>
 <BR><input type=text name=fmail size=30><br><BR>
<input type=submit name=formail value=ok>
<input type=reset value=cancel> ";
}

MYSQL_CLOSE();
?>

      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
