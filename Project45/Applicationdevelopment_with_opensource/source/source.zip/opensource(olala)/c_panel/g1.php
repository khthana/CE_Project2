
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF"><BR>
	  	  <div align="center"><table><tr><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td><td><font color="#3300FF" size="+1" face="MS Sans Serif, Tahoma, sans-serif"><strong>&nbsp;&nbsp;Infomation About Your Space&nbsp;&nbsp;</strong></font></td><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td></tr></table></div>
<?php
 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
 $bb=$HTTP_COOKIE_VARS["user"];

echo "<center>Limit Space Are 10 MB</center>"; 



$query = "select * from userpass where username='$bb'";
$result =mysql_query($query);
 $row = mysql_fetch_array($result); //push to array form result
$userspace = $row[udisk];
echo "<font color=\"blue\" size=\"+2\">Disk of </font> <font color=\"#FF0000\" size=\"+1\" face=\"MS Sans Serif, Tahoma, sans-serif\"><strong> $bb</strong></font> <BR><BR>";


echo "<font color=\"#0000FF\" size=\"+1\">Use Space  &nbsp &nbsp &nbsp &nbsp  :</font>";
$userspace = $userspace/1000 + 1 ; 
$tmp = split("\.",$userspace);

$userspace = $tmp[0];
echo "<font color=\"#FF0000\" size=\"+2\"> &nbsp $userspace KB<br></font>";

$remain = 10000 - $userspace ;
echo "<font color=\"#0000FF\" size=\"+1\">Remain  Space &nbsp &nbsp   :</font>";
echo " <font color=\"#FF0000\" size=\"+2\">&nbsp $remain KB<br></font>";

$p = ($userspace / 10000)  *100;

$tmp = split("\.",$p);

$p =  $tmp[0]+1;

echo "<font color=\"#0000FF\" size=\"+1\">Use  Space % </font>&nbsp &nbsp    :";

echo " <font color=\"#FF0000\" size=\"+2\">&nbsp &nbsp $p % </font><br>" ;

$p = 100 - $p;

echo "<font color=\"#0000FF\" size=\"+1\">Remain  Space % &nbsp   :</font>";

echo " <font color=\"#FF0000\" size=\"+2\">&nbsp  &nbsp $p %</font>" ;




MYSQL_CLOSE();

?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>

