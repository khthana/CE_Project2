<?php

 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
$bb = $HTTP_COOKIE_VARS["user"];
$query = "delete from formail where user='$bb' ";
$result =mysql_query($query);  // oder rows



$query = "select * from formail "; //order rows
$result =mysql_query($query);  // oder rows
$num = mysql_num_rows($result); //count row
$wri ="";
for($i=0;$i<$num;$i++)
{
$row = mysql_fetch_array($result); //push to array form result

$user = $row[user];
$dest = $row[destmail];
$wri = $wri."$user"."@olala02.ce.kmitl.ac.th"."  $dest\n";

}
//$wri = "$bb@olala02.ce.kmitl.ac.th  $fmail\n";
$fp = fopen("/etc/mail/virtusertable","w");
fwrite($fp,$wri);
fclose($fp); 

header("location:http://$config[domain]$config[folder]$config[filename]?page=500&&subpage=800");

?>

