<?php
session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
	<BR>
</TABLE>	<BR>
</td>	
  </tr>
</table>
            <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
                <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF">
	  	  <div align="center"><table><tr><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td><td><font color="#3300FF" size="+1" face="MS Sans Serif, Tahoma, sans-serif"><strong>&nbsp;&nbsp;Eraser Member In Your Group&nbsp;&nbsp;</strong></font></td><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td></tr></table></div><BR>

<?php
 mysql_connect($dbconfig["DBdomain"],$dbconfig["DBuser"],$dbconfig["DBpass"]);
 mysql_select_db($dbconfig["DBname"]);
	   $bb=$HTTP_COOKIE_VARS["user"];
if($ggroup=="ok") { $sess_delgroup = $togroup;session_register("sess_delgroup"); $sess_delname="";}
if($ugroup=="ok") { $sess_delname = $toname; session_register("sess_delname"); }
if(($submit=="ok")and($sess_delgroup!="")and($sess_delname!="")){

   $sql="delete from insidegroup where groupname = '$sess_delgroup' and username = '$sess_delname'" ;
 $result = mysql_query($sql);


$sess_delgroup="";$sess_delname="";
session_unregister("sess_delgroup");
session_unregister("sess_delname");
echo "<center><a href=$config[folder]$config[filename]?page=500&&subpage=100 >��Ѻ��ѧ˹�� panel</a></center>";
}
else {
 echo "<br>ź  &nbsp &nbsp <font color = green> $sess_delname </font>&nbsp &nbsp
 ����� group &nbsp &nbsp <font color = green> $sess_delgroup</font> ";

echo "<form action=$config[folder]$config[filename]?page=500&&subpage=500 method =post>";
$query = "select * from usergroup where usercreate='$bb'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
echo "<br>���͡ group : <select name =togroup>";
for($i=0;$i<$num;$i++){
 $row = mysql_fetch_array($result); //push to array form result
echo "<option value=$row[groupname]>$row[groupname]</option>";
}
echo "</select> ";
echo "<input type=submit name = ggroup value=ok> &nbsp";




$query = "select * from insidegroup where groupname='$sess_delgroup'";
$result = mysql_query($query);
$num = mysql_num_rows($result); //count row
echo "���͡ ������ź : <select name =toname>";
for($i=0;$i<$num;$i++){
 $row = mysql_fetch_array($result); //push to array form result
if($row[username]!=$bb) {
  echo "<option value=$row[username]>$row[username]</option>";}

//if($i+1==$num)echo "<option value=�ء���group>�ء��� group</option>";
}
echo "</select> ";
echo "<input type=submit name = ugroup value=ok> &nbsp";

echo "<br><input type=Submit name= submit value=ok> &nbsp";
echo "</form>";



}
mysql_close();
?>


      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>
