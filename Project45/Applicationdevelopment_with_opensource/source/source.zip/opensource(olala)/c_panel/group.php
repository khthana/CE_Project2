<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Otwig Project</title>
<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
</head>

<body bgcolor="black"  >
<table width="100%" border="0" align="center" bgcolor="#FFFFFF" height="500" >
  <tr valign="top">
    <td> 
      <table width="99%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#7CD3F7">
	<tr>
	<td>
	<table width="100%" border="0" >
  <tr>
                      <td  width="20%"><IMG SRC="<?php echo $config["folder"];?>/pic/logonew.gif" ></td>
                      <td  width="5%">&nbsp;</td>					  
                      <td><TABLE WIDTH=500 BORDER=0 CELLPADDING=0 CELLSPACING=0>
	<TR >
		<TD>			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_01.gif" WIDTH=60 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=200&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_02.gif" WIDTH=58 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=300&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_03.gif" WIDTH=87 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=400&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_04.gif" WIDTH=107 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=100">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_05.gif" WIDTH=106 HEIGHT=26 BORDER=0 ALT=""></A></TD>
		<TD>
			<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=600">
				<IMG SRC="<?php echo $config["folder"];?>/pic/images/mix_menu_06.gif" WIDTH=82 HEIGHT=26 BORDER=0 ALT=""></A></TD>	</TR>
				<BR>
</TABLE>				<BR>
</td>	
  </tr>
</table>
                <table width="98%" border="0" align="center" cellpadding="0" cellspacing="0" height="500">
  <tr  valign="top">
            <td width="20%">&nbsp;</td>
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>	
    <td width="2%" bgcolor="#FFFFFF">&nbsp;</td>		

      <td bgcolor="#FFFFFF"><BR>
	  <div align="center"><table><tr><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td><td><font color="#3300FF" size="+1" face="MS Sans Serif, Tahoma, sans-serif"><strong>&nbsp;&nbsp;Manage Your Web Favorite&nbsp;&nbsp;</strong></font></td><td><IMG SRC="<?php echo $config["folder"];?>/pic/rat.gif" ></td></tr></table></div><BR>

<?php
session_unregister("sess_delgroup");
session_unregister("sess_delname");
?>
<table><tr>
<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
<td><A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=200"><font size="+1" color ="blue">Create Group</font></a></td>
</tr><tr>
<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
    <td>&nbsp<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=300"><font size="+1" color ="blue">Add Member to Group</font></a></td>
</tr><tr>	
	<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
    <td>&nbsp<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=400"><font size="+1" color ="blue">Eraser Group</font></a></td>	
</tr><tr>	
	<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
    <td>&nbsp<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=500"><font size="+1" color ="blue">Eraser Member In Group</font></a>	</td>
</tr><tr>	
	<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
    <td>&nbsp<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=600"><font size="+1" color ="blue">Create Folder</font></a></td>	
</tr><tr>	
	<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
    <td>&nbsp<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=800"><font size="+1" color ="blue">Forward Mail</font></a></td>	
</tr><tr>	
	<td>    <IMG SRC="<?php echo $config["folder"];?>/pic/stall.gif" ><td>
    <td>&nbsp<A HREF="<?php echo $config["../domain"].$config["folder"].$config["filename"]?>?page=500&&subpage=700"><font size="+1" color ="blue">Check Space Of Disk</font></a></td>	
</tr></table>
      </td>
  </tr>
</table>
</td>
</tr>
</table>

	</td>
  </tr>
</table>
</td>
</tr>
</table>



	

