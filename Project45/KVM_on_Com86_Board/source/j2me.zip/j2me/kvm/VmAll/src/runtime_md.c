#define MEM_COMMIT 0x1000
#define PAGE_READWRITE 0x04
#define MEM_RELEASE 0x8000
#define PAGE_NOACCESS 0x01
#define PAGE_READONLY 0x02
#define PAGE_READWRITE 0x04

/*
 * Copyright (c) 1998-2002 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of Sun
 * Microsystems, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Sun.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
 * SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR ANY DAMAGES
 * SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
 * THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * Use is subject to license terms.
 */

/*=========================================================================
 * KVM
 *=========================================================================
 * SYSTEM:    KVM
 * SUBSYSTEM: Machine-specific implementations needed by virtual machine
 * FILE:      runtime_md.c
 * AUTHOR:    Frank Yellin
 *=======================================================================*/

/*=========================================================================
 * Include files
 *=======================================================================*/

#include <global.h>
#include <async.h>

#include <stdlib.h>
#include <string.h>
#include <time.h>

/*=========================================================================
 * Functions
 *=======================================================================*/

/*=========================================================================
 * FUNCTION:      alertUser()
 * TYPE:          error handling operation
 * OVERVIEW:      Show an alert dialog to the user and wait for
 *                confirmation before continuing execution.
 * INTERFACE:
 *   parameters:  message string
 *   returns:     <nothing>
 *=======================================================================*/

void AlertUser(const char* message)
{
    fprintf(stderr, "ALERT: %s\n", message);
}

/*=========================================================================
 * FUNCTION:      allocateHeap()
 * TYPE:          allocates memory
 * OVERVIEW:      Show an alert dialog to the user and wait for
 *                confirmation before continuing execution.
 * INTERFACE:
 *   parameters:  *sizeptr:  INPUT:   Pointer to size of heap to allocate
 *                           OUTPUT:  Pointer to actually size of heap
 *                *realresultptr: Returns pointer to actual pointer than
 *                           was allocated, before any adjustments for
 *                           memory alignment.  This is the value that
 *                           must be passed to "free()"
 *
 *  returns:      pointer to aligned memory.
 *
 *  Note that "sizeptr" reflects the size of the "aligned" memory, and
 *  note the actual size of the memory that has been allocated.
 *=======================================================================*/
void allocateHeapKMITL(long *space, void **realresultptr){
        *realresultptr = space;
}



/* Virtual memory allocation and protection operations. */
/* Used for testing the correctness of the garbage collector */

int getpagesize() {
/*  �ѹ���¡��ҡ� windows.h �ҡ���������������Ǩ�������ҡѺ 
	SYSTEM_INFO sysInfo;
    GetSystemInfo(&sysInfo);
    return sysInfo.dwPageSize;
*/ 
	return 4096;
}

void*
allocateVirtualMemory_md(long size) {
   printf("Windowwwwwwwwwwwwwwwwwwwwwwwwwwwww\n"); //M Debug
//    return VirtualAlloc(NULL, size, MEM_COMMIT, PAGE_READWRITE);
}

void
freeVirtualMemory_md(void *address, long size) {
   printf("Windowwwwwwwwwwwwwwwwwwwwwwwwwwwww\n"); //M Debug
   //    VirtualFree(address, size, MEM_RELEASE);
}

void
protectVirtualMemory_md(void *address, long size, int protection)
{
    long o;                     /* old protection value */
    int flag;
    switch (protection) {
	case PVM_NoAccess:  flag = PAGE_NOACCESS; break;
        case PVM_ReadOnly:  flag = PAGE_READONLY; break;
        case PVM_ReadWrite: flag = PAGE_READWRITE; break;
        default:            fatalError("Bad argument");
   printf("Windowwwwwwwwwwwwwwwwwwwwwwwwwwwww\n"); //M Debug

	}
//    VirtualProtect(address, size, flag, &o);
}
cell *XXXXXallocateHeap(long *sizeptr, void **realresultptr) {
        void *space = malloc(*sizeptr + sizeof(cell) - 1);
        *realresultptr = space;
        return (void *) ((((long)space) + (sizeof(cell) - 1)) & ~(sizeof(cell) - 1));
}
/*=========================================================================
 * FUNCTION:      CurrentTime_md
 * TYPE:          Public link routine
 * OVERVIEW:      Get the system time in ms since 1970
 * INTERFACE:
 *   parameters:  none
 *   returns:     time
 *=======================================================================*/

ulong64
CurrentTime_md(void) {
    return sysTimeMillis();
}

/*=========================================================================
 * FUNCTION:      InitializeNativeCode
 * TYPE:          initialization
 * OVERVIEW:      Called at start up to perform machine-specific
 *                initialization.
 * INTERFACE:
 *   parameters:  none
 *   returns:     none
 *=======================================================================*/

void InitializeNativeCode() {
    extern void runtime2_md_init(void);
    runtime2_md_init();
}

/*=========================================================================
 * FUNCTION:      nativeFinalization
 * TYPE:          initialization
 * OVERVIEW:      Called at start up to perform machine-specific
 *                finalization.
 * INTERFACE:
 *   parameters:  none
 *   returns:     none
 *=======================================================================*/

void FinalizeNativeCode() {
}

/*=========================================================================
 * Asynchronous (non-blocking) I/O Routines
 *=======================================================================*/

#if ASYNCHRONOUS_NATIVE_FUNCTIONS

/*
 * Parameters to processAcyncThread
 */
static ASYNCIOCB *nextIocb;
static void (*nextRoutine)(ASYNCIOCB *);

/*
 * Routine called from runtime2_md.c when a thread is unblocked
 */
void processAcyncThread(void) {

    /*
     * Pick up parameters
     */
    ASYNCIOCB *iocb          = nextIocb;
    void (*rtn)(ASYNCIOCB *) = nextRoutine;

    /*
     * Clear input queue
     */
    nextRoutine = 0;
    nextIocb    = 0;

    /*
     * Sanity check
     */
    if (iocb == 0 || rtn == 0) {
        fatalError("processAcyncThread problem");
    }

    /*
     * Execute async function
     */
    (rtn)(iocb);
}

/*=========================================================================
 * FUNCTION:      CallAsyncNativeFunction_md()
 * TYPE:          Public link routine for asynchronous native methods
 * OVERVIEW:      Call an asynchronous native method
 * INTERFACE:
 *   parameters:  thread pointer, native function pointer
 *   returns:     <nothing>
 *
 * Note: This is just an example implementation for demonstration purposes.
 *       and does not actually work very well because eventually the WIN32
 *       program seems to run out of thread resources and no new threads
 *       seem to run. Typically no error code is ever returned!
 *=======================================================================*/

void CallAsyncNativeFunction_md(ASYNCIOCB *iocb, void (*afp)(ASYNCIOCB *)) {

    /*
     * Sanity check
     */
    if (nextRoutine != 0 || nextIocb != 0 || iocb == 0 || afp == 0) {
        fatalError("CallAsyncNativeFunction_md problem");
    }

    /*
     * Save the thread parameters
     */
    nextRoutine = afp;
    nextIocb    = iocb;

    /*
     * Release a thread. This function will cause
     * processAcyncThread to be called
     */
    releaseAsyncThread();

    /*
     * Wait until it is running and has taken the queued request
     */
    while (nextIocb != 0) {
        Yield_md();
    }
}

#endif /* ASYNCHRONOUS_NATIVE_FUNCTIONS */
