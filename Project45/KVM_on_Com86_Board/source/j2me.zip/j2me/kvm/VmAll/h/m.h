/*=========================================================================
 * FUNCTION:      internString
 * OVERVIEW:      Returns a unique Java String that corresponds to a
 *                particular char* C string
 * INTERFACE:
 *   parameters:  string:  A C string
 *   returns:     A unique Java String, such that if strcmp(x,y) == 0, then
 *                internString(x) == internString(y).
 *=======================================================================*/

INTERNED_STRING_INSTANCE
internString(const char *utf8string, int length)
{ 
    HASHTABLE table = InternStringTable;
    unsigned int hash = stringHash(utf8string, length);
    unsigned int index = hash % table->bucketCount;
    unsigned int utfLength = utfStringLength(utf8string, length);

    INTERNED_STRING_INSTANCE string, *stringPtr;

    stringPtr = (INTERNED_STRING_INSTANCE *)&table->bucket[index];
    
    for (string = *stringPtr; string != NULL; string = string->next) { 
        if (string->length == utfLength) { 
            SHORTARRAY chars = string->array;
            int offset = string->offset;
            const char *p = utf8string;
            unsigned int i;
            for (i = 0; i < utfLength; i++) { 
                short unichar = utf2unicode(&p);
                if (unichar != chars->sdata[offset + i]) { 
                    /* We want to do "continue  <outerLoop>", but this is C */;
                    goto continueOuterLoop;
                }
            }
#if EXCESSIVE_GARBAGE_COLLECTION && !ASYNCHRONOUS_NATIVE_FUNCTIONS
            if (excessivegc) {
                /* We might garbage collect, so we do  */
                garbageCollect(0);
            }
#endif /* EXCESSIVE_GARBAGE_COLLECTION && !ASYNCHRONOUS_NATIVE_FUNCTIONS */
            return string;
        }
    continueOuterLoop:
        ;
    }

    
    string = instantiateInternedString(utf8string, length);
    string->next = *stringPtr;
    *stringPtr = string;
    return string;
}
