/* This is a generated file.  Do not modify.
 * Generated on Sun Jan 19 23:52:54 GMT+07:00 2003
 */


#include <global.h>

#if !ROMIZING
extern void Java_java_lang_Object_getClass(void);
extern void Java_java_lang_Object_hashCode(void);
extern void Java_java_lang_Object_notify(void);
extern void Java_java_lang_Object_notifyAll(void);
extern void Java_java_lang_Object_wait(void);
extern void Java_java_lang_Throwable_printStackTrace0(void);
extern void Java_java_lang_System_currentTimeMillis(void);
extern void Java_java_lang_System_arraycopy(void);
extern void Java_java_lang_System_identityHashCode(void);
extern void Java_java_lang_System_getProperty0(void);
extern void Java_com_sun_cldc_io_GeneralBase_iowait(void);
extern void Java_com_sun_cldc_io_j2me_comm_Protocol_native_1openByNumber(void);
extern void Java_com_sun_cldc_io_j2me_comm_Protocol_native_1openByName(void);
extern void Java_com_sun_cldc_io_j2me_comm_Protocol_native_1close(void);
extern void Java_com_sun_cldc_io_j2me_comm_Protocol_native_1readBytes(void);
extern void Java_com_sun_cldc_io_j2me_comm_Protocol_native_1available(void);
extern void Java_com_sun_cldc_io_j2me_comm_Protocol_native_1writeBytes(void);
extern void Java_com_sun_cldc_io_NetworkConnectionBase_initializeInternal(void);
extern void Java_java_lang_Class_forName(void);
extern void Java_java_lang_Class_newInstance(void);
extern void Java_java_lang_Class_isInstance(void);
extern void Java_java_lang_Class_isAssignableFrom(void);
extern void Java_java_lang_Class_isInterface(void);
extern void Java_java_lang_Class_isArray(void);
extern void Java_java_lang_Class_getName(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_open0(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_send0(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_receive0(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_getHostByAddr(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_getIpNumber(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_getMaximumLength0(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_getNominalLength0(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_close0(void);
extern void Java_com_sun_cldc_io_j2me_datagram_Protocol_registerCleanup(void);
extern void Java_com_sun_cldc_io_j2me_socket_Protocol_open0(void);
extern void Java_com_sun_cldc_io_j2me_socket_Protocol_read0(void);
extern void Java_com_sun_cldc_io_j2me_socket_Protocol_write0(void);
extern void Java_com_sun_cldc_io_j2me_socket_Protocol_available0(void);
extern void Java_com_sun_cldc_io_j2me_socket_Protocol_close0(void);
extern void Java_com_sun_cldc_io_j2me_socket_Protocol_registerCleanup(void);
extern void Java_java_lang_StringBuffer_append__Ljava_lang_String_2(void);
extern void Java_java_lang_StringBuffer_append__I(void);
extern void Java_java_lang_StringBuffer_toString(void);
extern void Java_java_lang_Thread_currentThread(void);
extern void Java_java_lang_Thread_yield(void);
extern void Java_java_lang_Thread_sleep(void);
extern void Java_java_lang_Thread_start(void);
extern void Java_java_lang_Thread_isAlive(void);
extern void Java_java_lang_Thread_activeCount(void);
extern void Java_java_lang_Thread_setPriority0(void);
extern void Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_open(void);
extern void Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_read(void);
extern void Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_close(void);
extern void Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_readBytes(void);
extern void Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_available(void);
extern void Java_com_sun_cldc_io_j2me_debug_PrivateOutputStream_putchar(void);
extern void Java_java_lang_Runtime_exitInternal(void);
extern void Java_java_lang_Runtime_freeMemory(void);
extern void Java_java_lang_Runtime_totalMemory(void);
extern void Java_java_lang_Runtime_gc(void);
extern void Java_java_lang_String_charAt(void);
extern void Java_java_lang_String_equals(void);
extern void Java_java_lang_String_indexOf__I(void);
extern void Java_java_lang_String_indexOf__II(void);
extern void Java_com_sun_cldc_io_j2me_events_PrivateInputStream_open(void);
extern void Java_com_sun_cldc_io_j2me_events_PrivateInputStream_readInt(void);
extern void Java_com_sun_cldc_io_j2me_events_PrivateInputStream_readByteArray(void);
extern void Java_com_sun_cldc_io_j2me_events_PrivateInputStream_close(void);
extern void Java_com_sun_cldc_io_j2me_events_PrivateInputStream_readUTF(void);
extern void Java_com_sun_cldc_io_j2me_serversocket_Protocol_open0(void);
extern void Java_com_sun_cldc_io_j2me_serversocket_Protocol_accept(void);
extern void Java_com_sun_cldc_io_j2me_serversocket_Protocol_close(void);
extern void Java_com_sun_cldc_io_j2me_serversocket_Protocol_registerCleanup(void);


const NativeImplementationType java_lang_Object_natives[] = {
    { "getClass",            NULL, Java_java_lang_Object_getClass},
    { "hashCode",            NULL, Java_java_lang_Object_hashCode},
    { "notify",              NULL, Java_java_lang_Object_notify},
    { "notifyAll",           NULL, Java_java_lang_Object_notifyAll},
    { "wait",                NULL, Java_java_lang_Object_wait},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_Throwable_natives[] = {
    { "printStackTrace0",    NULL, Java_java_lang_Throwable_printStackTrace0},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_System_natives[] = {
    { "currentTimeMillis",   NULL, Java_java_lang_System_currentTimeMillis},
    { "arraycopy",           NULL, Java_java_lang_System_arraycopy},
    { "identityHashCode",    NULL, Java_java_lang_System_identityHashCode},
    { "getProperty0",        NULL, Java_java_lang_System_getProperty0},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_GeneralBase_natives[] = {
    { "iowait",              NULL, Java_com_sun_cldc_io_GeneralBase_iowait},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_comm_Protocol_natives[] = {
    { "native_openByNumber", NULL, Java_com_sun_cldc_io_j2me_comm_Protocol_native_1openByNumber},
    { "native_openByName",   NULL, Java_com_sun_cldc_io_j2me_comm_Protocol_native_1openByName},
    { "native_close",        NULL, Java_com_sun_cldc_io_j2me_comm_Protocol_native_1close},
    { "native_readBytes",    NULL, Java_com_sun_cldc_io_j2me_comm_Protocol_native_1readBytes},
    { "native_available",    NULL, Java_com_sun_cldc_io_j2me_comm_Protocol_native_1available},
    { "native_writeBytes",   NULL, Java_com_sun_cldc_io_j2me_comm_Protocol_native_1writeBytes},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_NetworkConnectionBase_natives[] = {
    { "initializeInternal",  NULL, Java_com_sun_cldc_io_NetworkConnectionBase_initializeInternal},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_Class_natives[] = {
    { "forName",             NULL, Java_java_lang_Class_forName},
    { "newInstance",         NULL, Java_java_lang_Class_newInstance},
    { "isInstance",          NULL, Java_java_lang_Class_isInstance},
    { "isAssignableFrom",    NULL, Java_java_lang_Class_isAssignableFrom},
    { "isInterface",         NULL, Java_java_lang_Class_isInterface},
    { "isArray",             NULL, Java_java_lang_Class_isArray},
    { "getName",             NULL, Java_java_lang_Class_getName},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_datagram_Protocol_natives[] = {
    { "open0",               NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_open0},
    { "send0",               NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_send0},
    { "receive0",            NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_receive0},
    { "getHostByAddr",       NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_getHostByAddr},
    { "getIpNumber",         NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_getIpNumber},
    { "getMaximumLength0",   NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_getMaximumLength0},
    { "getNominalLength0",   NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_getNominalLength0},
    { "close0",              NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_close0},
    { "registerCleanup",     NULL, Java_com_sun_cldc_io_j2me_datagram_Protocol_registerCleanup},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_socket_Protocol_natives[] = {
    { "open0",               NULL, Java_com_sun_cldc_io_j2me_socket_Protocol_open0},
    { "read0",               NULL, Java_com_sun_cldc_io_j2me_socket_Protocol_read0},
    { "write0",              NULL, Java_com_sun_cldc_io_j2me_socket_Protocol_write0},
    { "available0",          NULL, Java_com_sun_cldc_io_j2me_socket_Protocol_available0},
    { "close0",              NULL, Java_com_sun_cldc_io_j2me_socket_Protocol_close0},
    { "registerCleanup",     NULL, Java_com_sun_cldc_io_j2me_socket_Protocol_registerCleanup},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_StringBuffer_natives[] = {
    { "append",              "(Ljava/lang/String;)Ljava/lang/StringBuffer;", Java_java_lang_StringBuffer_append__Ljava_lang_String_2},
    { "append",              "(I)Ljava/lang/StringBuffer;", Java_java_lang_StringBuffer_append__I},
    { "toString",            NULL, Java_java_lang_StringBuffer_toString},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_Thread_natives[] = {
    { "currentThread",       NULL, Java_java_lang_Thread_currentThread},
    { "yield",               NULL, Java_java_lang_Thread_yield},
    { "sleep",               NULL, Java_java_lang_Thread_sleep},
    { "start",               NULL, Java_java_lang_Thread_start},
    { "isAlive",             NULL, Java_java_lang_Thread_isAlive},
    { "activeCount",         NULL, Java_java_lang_Thread_activeCount},
    { "setPriority0",        NULL, Java_java_lang_Thread_setPriority0},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_resource_PrivateInputStream_natives[] = {
    { "open",                NULL, Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_open},
    { "read",                NULL, Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_read},
    { "close",               NULL, Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_close},
    { "readBytes",           NULL, Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_readBytes},
    { "available",           NULL, Java_com_sun_cldc_io_j2me_resource_PrivateInputStream_available},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_debug_PrivateOutputStream_natives[] = {
    { "putchar",             NULL, Java_com_sun_cldc_io_j2me_debug_PrivateOutputStream_putchar},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_Runtime_natives[] = {
    { "exitInternal",        NULL, Java_java_lang_Runtime_exitInternal},
    { "freeMemory",          NULL, Java_java_lang_Runtime_freeMemory},
    { "totalMemory",         NULL, Java_java_lang_Runtime_totalMemory},
    { "gc",                  NULL, Java_java_lang_Runtime_gc},
    NATIVE_END_OF_LIST
};

const NativeImplementationType java_lang_String_natives[] = {
    { "charAt",              NULL, Java_java_lang_String_charAt},
    { "equals",              NULL, Java_java_lang_String_equals},
    { "indexOf",             "(I)I", Java_java_lang_String_indexOf__I},
    { "indexOf",             "(II)I", Java_java_lang_String_indexOf__II},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_events_PrivateInputStream_natives[] = {
    { "open",                NULL, Java_com_sun_cldc_io_j2me_events_PrivateInputStream_open},
    { "readInt",             NULL, Java_com_sun_cldc_io_j2me_events_PrivateInputStream_readInt},
    { "readByteArray",       NULL, Java_com_sun_cldc_io_j2me_events_PrivateInputStream_readByteArray},
    { "close",               NULL, Java_com_sun_cldc_io_j2me_events_PrivateInputStream_close},
    { "readUTF",             NULL, Java_com_sun_cldc_io_j2me_events_PrivateInputStream_readUTF},
    NATIVE_END_OF_LIST
};

const NativeImplementationType com_sun_cldc_io_j2me_serversocket_Protocol_natives[] = {
    { "open0",               NULL, Java_com_sun_cldc_io_j2me_serversocket_Protocol_open0},
    { "accept",              NULL, Java_com_sun_cldc_io_j2me_serversocket_Protocol_accept},
    { "close",               NULL, Java_com_sun_cldc_io_j2me_serversocket_Protocol_close},
    { "registerCleanup",     NULL, Java_com_sun_cldc_io_j2me_serversocket_Protocol_registerCleanup},
    NATIVE_END_OF_LIST
};

const ClassNativeImplementationType nativeImplementations[] = {
    { "java/lang",                "Object",                   java_lang_Object_natives },
    { "java/lang",                "Throwable",                java_lang_Throwable_natives },
    { "java/lang",                "System",                   java_lang_System_natives },
    { "com/sun/cldc/io",          "GeneralBase",              com_sun_cldc_io_GeneralBase_natives },
    { "com/sun/cldc/io/j2me/comm", "Protocol",                 com_sun_cldc_io_j2me_comm_Protocol_natives },
    { "com/sun/cldc/io",          "NetworkConnectionBase",    com_sun_cldc_io_NetworkConnectionBase_natives },
    { "java/lang",                "Class",                    java_lang_Class_natives },
    { "com/sun/cldc/io/j2me/datagram", "Protocol",                 com_sun_cldc_io_j2me_datagram_Protocol_natives },
    { "com/sun/cldc/io/j2me/socket", "Protocol",                 com_sun_cldc_io_j2me_socket_Protocol_natives },
    { "java/lang",                "StringBuffer",             java_lang_StringBuffer_natives },
    { "java/lang",                "Thread",                   java_lang_Thread_natives },
    { "com/sun/cldc/io/j2me/resource", "PrivateInputStream",       com_sun_cldc_io_j2me_resource_PrivateInputStream_natives },
    { "com/sun/cldc/io/j2me/debug", "PrivateOutputStream",      com_sun_cldc_io_j2me_debug_PrivateOutputStream_natives },
    { "java/lang",                "Runtime",                  java_lang_Runtime_natives },
    { "java/lang",                "String",                   java_lang_String_natives },
    { "com/sun/cldc/io/j2me/events", "PrivateInputStream",       com_sun_cldc_io_j2me_events_PrivateInputStream_natives },
    { "com/sun/cldc/io/j2me/serversocket", "Protocol",                 com_sun_cldc_io_j2me_serversocket_Protocol_natives },
NATIVE_END_OF_LIST
};
#endif
