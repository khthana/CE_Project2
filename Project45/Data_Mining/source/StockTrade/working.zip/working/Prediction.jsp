<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<body>
<%@ page import = "java.sql.*" %>
<%@ page import = "StockTrade.*" %>

<table width="71%" border="2" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
  <tr bgcolor="#6666FF">
    <td colspan="6"><font color="#66FF99" size="3"><strong>���Ţͧ�ҧ���Ѵ��</strong></font></td>
  </tr>
  <tr>
    <td height="40" colspan="6">&nbsp;</td>
  </tr>
  <tr bgcolor="#6699FF">
    <td colspan="6"><font color="#66FF99" size="3"><strong>���Ţͧ��.�ѭ�� �����մ�</strong></font></td>
  </tr>
  <tr>
    <td height="40" colspan="6">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3" bgcolor="#6699FF"><div align="center"><font size="2"><strong></strong></font><font size="2"><strong></strong></font><font color="#66FF99" size="2"><strong>Exponential
        Moving Average</strong></font><font size="2"><strong></strong></font></div></td>
    <td colspan="3" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>Exponential
        Moving Average Result</strong></font></div></td>
  </tr>
  <tr>
    <td width="15%" bgcolor="#FFFFCC"><div align="center"><font size="2"><strong><font color="#6666FF">ema
        10 </font></strong></font></div></td>
    <td width="17%" bgcolor="#FFFFCC"><div align="center"><font size="2"><strong><font color="#6666FF">ema
        25 </font></strong></font></div></td>
    <td width="15%" bgcolor="#FFFFCC"><div align="center"><font color="#6666FF" size="2"><strong>ema
        75 </strong></font></div></td>
    <td width="17%" bgcolor="#FFFFCC"> <div align="center"><font size="2"><strong><font color="#6666FF">ST</font></strong></font></div></td>
    <td width="18%" bgcolor="#FFFFCC"> <div align="center"><font size="2"><strong><font color="#6666FF">ST-MT</font></strong></font></div></td>
    <td width="18%" bgcolor="#FFFFCC"> <div align="center"><font size="2"><strong><font color="#6666FF">MT</font></strong></font></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFCC">
    <td colspan="6"><font size="2"><strong><font color="#6666FF">ST</font></strong>
      <font color="#6666FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>�������</strong></font></font></td>
  </tr>
  <tr>
    <td colspan="6"><font color="#6699FF" size="2"><strong>Bullish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = closed price &gt; eam 10
      </font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">������鹴�</font> </strong></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="6"><font color="#6699FF" size="2"><strong>Bearish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = closed price &lt; eam 10
      </font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">�����������</font> </strong></font></strong></font></td>
  </tr>
  <tr bgcolor="#FFFFCC">
    <td colspan="6"><font size="2"><strong><font color="#6666FF">ST-MT</font></strong>
      <font color="#6666FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>�������-���С�ҧ</strong></font></font></td>
  </tr>
  <tr>
    <td colspan="6"><font color="#6699FF" size="2"><strong>Bullish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = closed price &gt; eam 25</font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">�������-���С�ҧ��</font> </strong></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="6"><font color="#6699FF" size="2"><strong>Bearish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = closed price &lt; eam 25</font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">�������<font size="2"><strong><font size="2"><strong>-���С�ҧ</strong></font></strong></font>����</font>
      </strong></font></strong></font></td>
  </tr>
  <tr bgcolor="#FFFFCC">
    <td colspan="6"><font size="2"><strong><font color="#6666FF">MT </font><font size="2"><font color="#6666FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>���С�ҧ</strong></font></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="6"><font color="#6699FF" size="2"><strong>Bullish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = closed price &gt; eam 75</font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">���С�ҧ��</font> </strong></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="6"><font color="#6699FF" size="2"><strong>Bearish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = closed price &lt; eam 75</font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF"><font size="2"><strong><font size="2"><strong>���С�ҧ</strong></font></strong></font>����</font>
      </strong></font></strong></font></td>
  </tr>
</table>
<p>&nbsp;</p>
<table width="548" border="2" cellpadding="0" cellspacing="0" bordercolor="#FF9900">
  <tr bgcolor="#6699FF">
    <td width="53" rowspan="2"> <div align="center"><font color="#66FF99" size="2"><strong>14RSI</strong></font></div></td>
    <td colspan="2"> <div align="center"><font color="#66FF99" size="2"><strong>Stochastic</strong></font></div></td>
    <td colspan="2"> <div align="center"><font color="#66FF99" size="2"><strong>MACD</strong></font></div></td>
    <td colspan="3"> <div align="center"><font color="#66FF99" size="2"><strong>Oscillators
        Result</strong></font></div></td>
  </tr>
  <tr>
    <td width="52" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>%K</strong></font></div></td>
    <td width="52" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>%D</strong></font></div></td>
    <td width="61" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>MACD</strong></font></div></td>
    <td width="59" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>Signal</strong></font></div></td>
    <td width="83" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>RSI</strong></font></div></td>
    <td width="84" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>Stochastic</strong></font></div></td>
    <td width="84" bgcolor="#6699FF"> <div align="center"><font color="#66FF99" size="2"><strong>MACD</strong></font></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr bgcolor="#FFFFCC">
    <td colspan="8"><font size="2"><strong><font color="#6666FF">Stochastic</font></strong>
      <font color="#6666FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>�ѭ�ҳ�������</strong></font></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>+Overbought = %K &gt;
      80% and %K &gt;%D = </strong></font><font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>��������͢��</strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>-Overbought</strong></font>
      <font color="#6699FF" size="2"><strong>=</strong></font> <font color="#6699FF" size="2"><strong>%K
      &gt; 80% and %K &lt; %D</strong></font> <font color="#6699FF" size="2"><strong>=</strong></font>
      <font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>������ͷӡ���</strong></font>
    </td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>+O</strong></font>
      <font color="#6699FF" size="2"><strong>=</strong></font> <font color="#6699FF" size="2"><strong>%K
      <font size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">���������ҧ
      </font>20-80% and %K &gt; %D</strong></font> <font color="#6699FF" size="2"><strong>=</strong></font>
      <font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>����
      ��� ���ŧ�ع</strong></font> </td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>-O = %K <strong><font size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">���������ҧ</font></strong><font face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">
      </font>20-80% and %K &lt; %D = <font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">����
      ��ж���Թʴ </font></strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>+Oversold = %K &lt;
      20% and %K &gt; %D = <font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"></font></strong></font><font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>�ѭ�ҳ�������ŧ�ع</strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>-Oversold</strong></font>
      <font color="#6699FF" size="2"><strong>=</strong></font> <font color="#6699FF" size="2"><strong>%K
      &lt; 20% and %K &lt; %D</strong></font> <font color="#6699FF" size="2"><strong>=</strong></font>
      <font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>���ѭ�ҳ����</strong></font>
    </td>
  </tr>
  <tr>
    <td colspan="8" bgcolor="#FFFFCC"><font size="2"><strong><font color="#6666FF">14
      RSI </font><font size="2"><font color="#6666FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>�ѭ�ҳ�������</strong></font></font><font color="#6666FF" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">
      -<font size="3"> ��ҧ</font></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>Overbought = <font color="#6699FF" size="2">14
      RSI &gt; 80%</font> = </strong></font><font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>��������§�дѺ�٧</strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>O = <font color="#6699FF" size="2">14
      RSI <font color="#6699FF" size="2"><strong><strong><font size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">���������ҧ</font></strong><font face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"></font></strong></font><font face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif">
      </font>20-80% <strong>=</strong> </font><font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>��������§�дѺ�ҹ��ҧ</strong></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>Oversold = <font color="#6699FF" size="2">14
      RSI &lt; 20%</font> <font color="#6699FF" size="2"><strong>=</strong></font>
      </strong></font><font color="#6699FF" size="3" face="AngsanaUPC, BrowalliaUPC, CordiaUPC, MS Serif"><strong>��������§�дѺ���</strong></font><font color="#6699FF" size="2"><strong>
      </strong></font></td>
  </tr>
  <tr bgcolor="#FFFFCC">
    <td height="22" colspan="8"><font color="#6666FF" size="2"><strong>MACD </strong>�ѭ�ҳ���С�ҧ</font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>+Bullish</strong></font>
      <font size="2"><strong><font color="#6699FF"> = MACD &gt; 0 &amp; MACD &gt;
      signal </font><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">�Ң�����С�ҧ �������ŧ�ع</font></strong></font></strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font color="#6699FF" size="2"><strong>-Bullish</strong></font>
      <font size="2"><strong><font color="#6699FF">= MACD &gt;0 &amp; MACD &lt;signal
      </font><font size="2"><strong><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font></strong></font></strong></font>
      <font color="#6699FF">��Ѻ���㹢Ң�����С�ҧ Ŵ����</font> <font color="#6699FF">
      </font></strong></font></td>
  </tr>
  <tr>
    <td colspan="8"><font size="2"><strong><font color="#6699FF" size="2">+Bearish
      </font><font size="2"><strong><font color="#6699FF">=</font></strong></font>
      <font color="#6699FF">MACD &lt; 0 &amp; MACD &gt; signal </font><font size="2"><strong><font size="2"><strong><font size="2"><strong><font size="2"><strong><font color="#6699FF">=</font></strong></font></strong></font></strong></font></strong></font>
      </strong></font><font color="#6699FF" size="2"><strong>�մ��Ѻ㹢�ŧ���С�ҧ
      �����秡���</strong></font><font size="2"><strong> <font color="#6699FF" size="2">
      </font></strong></font></td>
  </tr>
  <tr>
    <td colspan="8" bgcolor="#6699FF">&nbsp;</td>
  </tr>
</table>

</body>
</html>
