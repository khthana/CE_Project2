<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
A:link { text-decoration: none; color:#0088FF}
A:active { text-decoration: none}
A:visited { text-decoration: none; color:#0088FF } 
A:hover {text-decoration: none}
-->
</style>
<script language="JavaScript1.2">
function borderize(what,color){
what.style.borderColor=color
}

function borderize_on(e){
if (document.all)
source3=event.srcElement
else if (document.getElementById)
source3=e.target
if (source3.className=="menulines"){
borderize(source3,"ffff3333" )
}
else{
while(source3.tagName!="TABLE"){
source3=document.getElementById? source3.parentNode : source3.parentElement
if (source3.className=="menulines")
borderize(source3,"#ff3333")
}
}
}

function borderize_off(e){
if (document.all)
source4=event.srcElement
else if (document.getElementById)
source4=e.target
if (source4.className=="menulines")
borderize(source4,"white")
else{
while(source4.tagName!="TABLE"){
source4=document.getElementById? source4.parentNode : source4.parentElement
if (source4.className=="menulines")
borderize(source4,"white")
}
}
}
var rate = 20; // Increase amount(The degree of the transmutation)
var obj; // The object which event occured in
var act = 0; // Flag during the action
var elmH = 0; // Hue
var elmS = 128; // Saturation
var elmV = 255; // Value
var clrOrg; // A color before the change
var TimerID; // Timer ID
if (navigator.appName.indexOf("Microsoft",0) != -1 && parseInt(navigator.appVersion) >= 4) {
Browser = true;
} else {
Browser = false;
}
if (Browser) {
document.onmouseover = doRainbowAnchor;
document.onmouseout = stopRainbowAnchor;
}
function doRainbow()
{
if (Browser && act != 1) {
act = 1;
obj = event.srcElement;
clrOrg = obj.style.color;
TimerID = setInterval("ChangeColor()",100);
}
}
function stopRainbow()
{
if (Browser && act != 0) {
obj.style.color = clrOrg;
clearInterval(TimerID);
act = 0;
}
}
function doRainbowAnchor()
{
if (Browser && act != 1) {
obj = event.srcElement;
while (obj.tagName != 'A' && obj.tagName != 'BODY') {
obj = obj.parentElement;
if (obj.tagName == 'A' || obj.tagName == 'BODY')
break;
}
if (obj.tagName == 'A' && obj.href != '') {
act = 1;
clrOrg = obj.style.color;
TimerID = setInterval("ChangeColor()",100);
}
}
}
function stopRainbowAnchor()
{
if (Browser && act != 0) {
if (obj.tagName == 'A') {
obj.style.color = clrOrg;
clearInterval(TimerID);
act = 0;
}
}
}
function ChangeColor()
{
obj.style.color = makeColor();
}
function makeColor()
{
if (elmS == 0) {
elmR = elmV; elmG = elmV; elmB = elmV;
}
else {
t1 = elmV;
t2 = (255 - elmS) * elmV / 255;
t3 = elmH % 60;
t3 = (t1 - t2) * t3 / 60;
if (elmH < 60) {
elmR = t1; elmB = t2; elmG = t2 + t3;
}
else if (elmH < 120) {
elmG = t1; elmB = t2; elmR = t1 - t3;
}
else if (elmH < 180) {
elmG = t1; elmR = t2; elmB = t2 + t3;
}
else if (elmH < 240) {
elmB = t1; elmR = t2; elmG = t1 - t3;
}
else if (elmH < 300) {
elmB = t1; elmG = t2; elmR = t2 + t3;
}
else if (elmH < 360) {
elmR = t1; elmG = t2; elmB = t1 - t3;
}
else {
elmR = 0; elmG = 0; elmB = 0;
}
}
elmR = Math.floor(elmR);
elmG = Math.floor(elmG);
elmB = Math.floor(elmB);
clrRGB = '#' + elmR.toString(16) + elmG.toString(16) + elmB.toString(16);
elmH = elmH + rate;
if (elmH >= 360)
elmH = 0;
return clrRGB;
}
</script>
</head>
<body>
	<table width="70%" height="90" border="0" cellpadding="0" cellspacing="0">
        <tr> 
          <td height="70" colspan="5"><img src="PIC/BarFinal.jpg" width="700" height="70"></td>
        </tr>
        <tr bordercolor="#000000" bgcolor="#CCCC99" > 
          <td width="19%" height="20"><div align="center"><a href="Index.jsp" target="_blank"><font face="System">HOME</font></a> 
      </div></td>
          <td width="18%"><div align="center"><a href="Graphs.jsp" target="_parent">��ҿ�Ҥ����</a></div></td>
          <td width="22%"><div align="center"><a href="Index.jsp" target="_self">�ټš�÷ӹ��</a></div></td>
          <td width="21%"><div align="center"><a href="Technical.htm" target="_blank">ͧ��������</a></div></td>
          <td width="20%"><div align="center"><a href="Index.jsp" target="_self"><font face="System">ABOUT 
        US</font></a></div></td>
        </tr>
      </table> 
<form name="SelectGraph" action="Graphs.jsp" method="get">
  <table width="600" border="0" cellspacing="0" cellpadding="0">
  <tr>
  <td valign="top" align="center">
    <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
      <tr>
        <td><font color="#999933" face="Courier New, Courier, mono"><strong>�١�ҿ�Ҥ����</strong></font></td>
      </tr>
      <tr>
        <td bgcolor="#ADCBF7"    height="1" ></td>
      </tr>
      <tr>
        <td bgcolor = "#FFFFFF"height="1" ></td>
      </tr>
      <tr>
        <td bgcolor="#ADCBF7"  height="1"></td>
      </tr>
    </table>
    <table width="100%" height="493" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td width="30%" height="60" valign="top">
           <table width="100%" border="0" cellspacing="0" cellpadding="0">

              <tr>
                <td height="28"><font color="#3366FF">Stock Symbol</font></td>
                <td height="28"><input name="type" type="text" id="type" value="s" size="15"></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td width="43%" height="28"><font color="#3366FF">Enter Stock</font></td>
                <td width="47%" height="28">
                  <div align="left">
                    <input name="stock" type="text" id="stock" size="15">
                  </div></td>
                <td width="10%">
                  <div align="center">
                    <input name="go" type="image" src="PIC/go2.gif" width="21" height="17" border="0">
                  </div></td>
              </tr>

          </table>
        </td>
        <td width="70%" rowspan="2" valign="top">
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
              <td>
              <% String type = "s";
                String stock = "SCB";
                try{
                  type = request.getParameter("type");
                  stock = request.getParameter("stock");
                }
                catch( Exception nn ){
                  type = "s";
                  stock = "ASL";
                }
%>
              <applet
          		codebase = "/stocktrade/."
                code = "stocktrade.IntradayApplet.class"
                name = "TestApplet"
                width=435
                height=240
                align = "middle"
                 >
                 <%out.println("<param name=\"type\"  value=\""+type+"\" >");%>
                <%out.println("<param name=\"stock\" value=\""+stock+"\" >");%>
                </applet>
			</td>
            </tr>
            <tr>
              <td height="215">&nbsp;</td>
            </tr>
          </table>

        </td>
      </tr>
      <tr>
        <td height="358">&nbsp;</td>
      </tr>
    </table>
</table>
    </form>
    <p align="center">&nbsp;</p></body>
</html>
