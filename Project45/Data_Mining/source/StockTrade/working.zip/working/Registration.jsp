<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body>
<table width="600" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td valign="top"> <form name='registration' method='post' action='S01_RegistrationTrialConfirm.jsp?txtBrokerId=IPO' onsubmit='return validate();'>
        <table width='600' border='0' cellspacing='0' cellpadding='0'>
          <tr> 
            <td valign='top' align='center' height='733'> <br> <table width='96%' border='0' cellspacing='0' cellpadding='0'>
                <tr> 
                  <td width='28%'><img src='PIC/point.gif' width='102' height='25'> 
                  </td>
                  <td width='40%'><img src='PIC/menu2_off.gif' width='178' height='25'></td>
                  <td width='32%'>&nbsp; </td>
                </tr>
              </table>
              <br> 
              <table width='96%' border='0' cellspacing='0' cellpadding='2'>
                <tr>
                  <td height='28' colspan="3"><b><font size='3' color='#999999'>��س����͡���ʼ�ҹ</font></b></td>
                </tr>
				<tr valign='middle'> 
                  <td colspan='4' height='2' bgcolor='#CBE7A5'></td>
                </tr>
                <tr> 
                  <td width='26%' height='64'><font color='#000000'>���ͼ���� 
                    (Login Name)</font></td>
                  <td width='25%' height='64'><font color='#000000'> 
                    <input type='text' name='loginName' size='15' class='text_box' maxlength='15' value=''>
                    </font></td>
                  <td width='49%' height='64'><font color='#999999'>����ѡ�������ѧ��� 
                    �դ����������Թ 15 ����ѡ��<br>
                    �������������ä</font></td>
                </tr>
                <tr> 
                  <td width='26%' height='30'><font color='#000000'>���ʼ�ҹ (Password)</font></td>
                  <td width='25%' height='30'><font color='#000000'> 
                    <input type='password' name='passwd' size='15' class='text_box' maxlength='10'>
                    </font></td>
                  <td width='49%' height='30' valign='bottom'><font color='#999999'>����ӡѺ���ͼ����, 
                    �繵���ѡ�������ѧ��� 6-10 ����ѡ��<br>
                    �������������ä</font></td>
                </tr>
                <tr> 
                  <td width='26%' height='30'><font color='#000000'>������ʼ�ҹ�ա����˹�� 
                    </font></td>
                  <td width='25%' height='30'><font color='#000000'> 
                    <input type='password' name='rePasswd' size='15' class='text_box' maxlength='10'>
                    </font></td>
                  <td width='49%' height='30'><font color='#000000'>&nbsp;</font></td>
                </tr>
              </table>
              <br> <table width='96%' border='0' cellspacing='0' cellpadding='0'>
                <tr valign='middle'> 
                  <td colspan='4' height='26'><font color='#000000'><b><font size='3' color='#999999'>��������ǹ�ؤ��</font></b> 
                    <font color='#999999'>(��سҡ�͡��������������)</font></font></td>
                </tr>
                <tr valign='middle'> 
                  <td colspan='4' height='2' bgcolor='#CBE7A5'></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>�ӹ�˹�Ҫ���</font></td>
                  <td width='25%' height='35'><font color='#000000'> 
                    <select name='title' class='text_box' onchange='definedSex();'>
                      <option value='-'>- - - - -</option>
                      <option value='101'>�硪��</option>
                      <option value='102'>��˭ԧ</option>
                      <option value='103'>���</option>
                      <option value='104'>�ҧ</option>
                      <option value='105'>�ҧ���</option>
                    </select>
                    </font></td>
                  <td width='21%' height='35' align='right'><font color='#000000'>��&nbsp;&nbsp;</font></td>
                  <td width='33%' height='35'><font color='#000000'> 
                    <input type='text' name='sex' size='13' class='text_box' disabled value=''>
                    </font></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>����</font></td>
                  <td width='25%' height='35'><font color='#000000'> 
                    <input type='text' name='name' maxlength='40' value='' class='text_box'>
                    </font></td>
                  <td width='21%' height='35' align='right'><font color='#000000'>���ʡ��&nbsp;&nbsp;</font></td>
                  <td width='33%' height='35'><font color='#000000'> 
                    <input type='text' name='surname' maxlength='110' value='' class='text_box'>
                    </font></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>�������</font></td>
                  <td colspan='3' height='35'><font color='#000000'>&nbsp;</font><font color='#000000'>&nbsp;</font><font color='#000000'> 
                    <input type='text' name='address1' size='64' class='text_box' value='' maxlength='70' align="left"><br>
                    <input type='text' name='address2' size='64' class='text_box' value='' maxlength='70' align="left">
                    </font></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>������ɳ���</font></td>
                  <td width='25%' height='35'><font color='#000000'> 
                    <input type='text' name='postCode' size='9' class='text_box' value='' maxlength='5'>
                    </font></td>
                  <td width='21%' height='35'><font color='#000000'>&nbsp;</font></td>
                  <td width='33%' height='35'><font color='#000000'>&nbsp;</font></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>�����Ţ���Ѿ�� 
                    (��ҹ)</font></td>
                  <td width='25%' height='35'><font color='#000000'> 
                    <input type='text' name='telHome' value='' size='10' class='text_box' maxlength='30'>
                    </font></td>
                  <td width='21%' height='35'><font color='#000000'>&nbsp;</font></td>
                  <td width='33%' height='35'><font color='#000000'>&nbsp;</font></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>����ȵ���������</font></td>
                  <td width='25%' height='35'><font color='#000000'> 
                    <input type='text' name='country' value='��' size='15' class='text_box' disabled>
                    </font></td>
                  <td width='21%' height='35' align='right'><font color='#000000'>�ѭ�ҵ�&nbsp;&nbsp;</font></td>
                  <td width='33%' height='35'><font color='#000000'> 
                    <input type='text' name='nationality' value='��' size='15' class='text_box' disabled>
                    </font></td>
                </tr>
                <tr> 
                  <td width='21%' height='35'><font color='#000000'>�ѹ�Դ</font></td>
                  <td colspan='3' height='35' valign='top'><font color='#000000'>&nbsp;</font><font color='#000000'>&nbsp;</font> 
                    <table width='100%' border='0' cellspacing='0' cellpadding='0' height='30'>
                      <tr> 
                        <td width='13%'> <select name='birthDate' class='text_box'>
                            <option value=''>- -</option>
                            <option value='01'>01</option>
                            <option value='02'>02</option>
                            <option value='03'>03</option>
                            <option value='04'>04</option>
                            <option value='05'>05</option>
                            <option value='06'>06</option>
                            <option value='07'>07</option>
                            <option value='08'>08</option>
                            <option value='09'>09</option>
                            <option value='10'>10</option>
                            <option value='11'>11</option>
                            <option value='12'>12</option>
                            <option value='13'>13</option>
                            <option value='14'>14</option>
                            <option value='15'>15</option>
                            <option value='16'>16</option>
                            <option value='17'>17</option>
                            <option value='18'>18</option>
                            <option value='19'>19</option>
                            <option value='20'>20</option>
                            <option value='21'>21</option>
                            <option value='22'>22</option>
                            <option value='23'>23</option>
                            <option value='24'>24</option>
                            <option value='25'>25</option>
                            <option value='26'>26</option>
                            <option value='27'>27</option>
                            <option value='28'>28</option>
                            <option value='29'>29</option>
                            <option value='30'>30</option>
                            <option value='31'>31</option>
                          </select> </td>
                        <td width='6%'><font color='#000000'>��͹</font></td>
                        <td width='21%'> <select name='birthMonth' class='text_box'>
                            <option value=''>- - - - - - </option>
                            <option value='01'>���Ҥ�</option>
                            <option value='02'>����Ҿѹ��</option>
                            <option value='03'>�չҤ�</option>
                            <option value='04'>����¹</option>
                            <option value='05'>����Ҥ�</option>
                            <option value='06'>�Զع�¹</option>
                            <option value='07'>�á�Ҥ�</option>
                            <option value='08'>�ԧ�Ҥ�</option>
                            <option value='09'>�ѹ��¹</option>
                            <option value='10'>���Ҥ�</option>
                            <option value='11'>��Ȩԡ�¹</option>
                            <option value='12'>�ѹ�Ҥ�</option>
                          </select> </td>
                        <td width='10%'><font color='#000000'>�� (�.�.)</font></td>
                        <td width='50%'> <input type='text' name='birthYear' size='4' class='text_box' value='' maxlength='4'>	
                        </td>
                      </tr>
                    </table></td>
                </tr>
              </table>
              <br> <br> <table width='96%' border='0' cellspacing='0' cellpadding='0'>
                <tr> 
                  <td colspan='3' height='25'><font color='#999999'><b><font size='3'>�����ŵԴ��͡Ѻ��ҹ</font> 
                    </b> </font></td>
                </tr>
                <tr> 
                  <td colspan='3' height='2' bgcolor='#CBE7A5'></td>
                </tr>
                <tr valign='middle'> 
                  <td width='26%' height='35'><font color='#000000'>�������ʹ���</font></td>
                  <td width='26%' height='35'><font color='#000000'> 
                    <input type='text' name='eMail' class='text_box' value='' maxlength='50'>
                    </font></td>
                  <td width='48%' height='35'><font color='#999999'>�� (abc@yahoo.com) 
                    </font></td>
                  <input type='hidden' name='telMobile' value=''>
                  <input type='hidden' name='mobileAlert' value=''>
                </tr>
                <tr align='center'> 
                  <td colspan='3' height='35'> <input type='image' border='0' name='imageField2' src='PIC/btn_ok.gif' width='51' height='23'>	
                    &nbsp; <a href='#' onClick='document.registration.reset();'>	
                    <img src='PIC/btn_clearT.gif' width='54' height='26' border='0'></a>	
                  </td>
                </tr>
              </table>
              <br> </td>
          </tr>
        </table>
      </form>
      <table width='600' border='0' cellspacing='0' cellpadding='0'>
        <tr> 
          <td bgcolor='#5483E0' height='1'><img src='brokerpage/IPO/images/pic/1pixel.gif' width='1' height='1'></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>
