<%@ page contentType="text/html; charset=MS874" %>
<html>
<head>
<title>
StockChart
</title>
</head>
<jsp:useBean id="StockChartBeanId" scope="session" class="stocktrade.StockChartBean" />
<jsp:setProperty name="StockChartBeanId" property="*" />
<body>
<h1>
JBuilder Generated JSP
</h1>
<% String type = "s";
   String stock = "SCB";
  try{
    type = request.getParameter("type");
    stock = request.getParameter("stock");
    out.print( type );out.println( stock );
   }
   catch( Exception nn ){
     out.println( nn );
   }
%>
<div align = "middle">
<applet
    codebase = "/stocktrade/."
    code     = "stocktrade.IntradayApplet.class"
    name     = "TestApplet"
    width=435
    height=240
    align = "middle"
>
<%out.println("<param name=\"type\"  value=\""+type+"\" >");%>
<%out.println("<param name=\"stock\" value=\""+stock+"\" >");%>
</applet>
</div>
</body>
</html>
