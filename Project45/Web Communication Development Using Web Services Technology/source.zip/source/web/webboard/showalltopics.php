<?php
// file showalltopics.php
	session_start();
	// database services
	require('../database/services/retrieve_db.php');		// use retrieve_db - Retrieve data from database
	require('../database/services/inupdel_db.php');			// use inupdel_db - Insert, Update, Delete data in database
	// passport services
	require('../passport/services/validate.php');		// use validate - Validate current user

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	// get total page
	if(empty($page)) {
		$page = 1;
	} // end if
	$question_sql = "SELECT * FROM board_question";
	$question_query = retrieve_db('webservices', $question_sql);
	if(is_array($question_query)) {
		$num_row = count($question_query);
		if(($num_rows % 30) != 0) {
			$totalpage = floor($num_rows / 30) + 1;
		} else {
			$totalpage = floor($num_rows / 30); 
		}
		$goto = ($page - 1) * 30;
	} // end if
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>��� � ��ͧ � ���͹ � ��¡ѹ�š����¹�����������ǤԴ</title>
		<style type="text/css">
			a:link { color: #005177; background-color: transparent; text-decoration: none }
			a:visited { color: #005177; background-color: transparent; text-decoration: none }
			a:hover { color: #cc3333; background-color: transparent; text-decoration: none }
			.nav { color: #000000; background-color: transparent; text-decoration: none }
			.nav:link { color: #000000; background-color: transparent; text-decoration: none }
			.nav:visited { color: #000000; background-color: transparent; text-decoration: none }
			.nav:hover { font-weight: bold; color: #cc3333; background-color: transparent; text-decoration: underline }
			body { font-size: 12px; font-family: MS Sans Serif }
			table { empty-cells: show }
			td { font-size: 12px; color: #000000; font-family: MS Sans Serif }
			input { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			textarea { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			select { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			.windowbg { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			.windowbg2 { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #f8f8f8 }
			.windowbg3 { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #6394bd }
			.hr { color: #6394bd; background-color: transparent }
			.titlebg { color: #ffffff; background-color: #6e94b7 }
			.text1 { font-weight: bold; font-size: 12px; color: #ffffff; font-style: normal; background-color: transparent }
			.catbg { font-weight: bold; font-size: 13px; background-IMAGE: url(YaBBImages/catbg.jpg); color: #000000 }
			.bordercolor { font-size: 12px; font-family: MS Sans Serif; background-color: #6394bd }
			.quote { font-size: 10px; color: #000000; font-family: MS Sans Serif; background-color: #dee7ef }
			.code { font-size: 10px; color: #000000; font-family: MS Sans Serif; background-color: #cccccc }
			.help { cursor: help; background-color: transparent }
			.meaction { color: red; background-color: transparent }
			.editor { width : 100% }
		</style>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
	</head>
	<body text="#000000" link="#0033FF" bgcolor="#F5F5F5">
		<table class="bordercolor" bgcolor="#6394BD" border="0" width="90%" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" width="100%" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr><td>
								<table border="0" width="100%" align="center" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td bgcolor="#FFFFFF" align="left" valign="center">
												<img src="images/logo.gif" alt="logo" />
											</td>
											<td bgcolor="#FFFFFF" valign="center">
												<font size="2">�Թ�յ�͹�Ѻ�س <?php if(validate($ip)) echo $_SESSION['username']; ?> �������дҹ���-�ͺ�ͧ�Ҥ�Ԫ����ǡ�������������<br />ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ��Ѻ</font>
											</td>
										</tr>
									</tbody>
								</table>
							</td></tr>
							<tr bgcolor="#B7BBDA" align="middle" valign="center">
								<td bgcolor="#AFC6DB">
									<font size="1">
										<a href="../index.php">˹���á | </a>
<?php
	if(validate($ip)) {
?>
										<a href="../passport/change_pwd_form.php?services=webboard/">����¹���ʼ�ҹ | </a>
										<a href="../passport/view_profile.php">�ʴ���������ǹ��� | </a>
										<a href="../passport/edit_profile_form.php">��䢢�������ǹ��� | </a>
										<a href="../passport/del_profile_form.php">ź��������ǹ��� | </a>
										<a href="../passport/index.php?passport=�͡�ҡ�к�&services=webboard/">�͡�ҡ�к�</a>
<?php
	} else {
?>
										<a href="../passport/register_form.php?services=webboard/">ŧ����¹��������� | </a>
										<a href="../passport/signin_form.php?services=webboard/">�������к� | </a>
										<a href="../passport/forget_pwd_form.php">������ʼ�ҹ</a>
<?php
	} // end if
?>
									</font>
								</td>
							</tr>
						</tbody>
					</table>
				</td></tr>
			</tbody>
		</table><br />
		<table class="bordercolor" bgcolor="#6394BD" width="90%" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" border="0" width="100%" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr><td>
								<table bgcolor="#FFFFFF" border="0" width="100%" align="center" cellpadding="10" cellspacing="0">
									<tbody>
										<tr>
											<td width="100%" valign="top">
												<table width="100%" cellpadding="0" cellspacing="0">
													<tr>
														<td>
															<a name="top"></a><a href="" class="nav"><font class="nav" size="1"><b>��дҹ���-�ͺ</b></a> | <b><a href="../news/index.php" class="nav">��С�Ȣ�����������Ҥ�Ԫ��</a></font>
														</td>
														<td align="right">
															<a href="help.php" class="nav"><font size="1"><b>Help</b></font></a>
														</td>
													</tr>
												</table>
												<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="0" cellspacing="0">
													<tr><td>
														<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="3" cellspacing="1">
															<tr><td class="catbg" bgcolor="#DEE7EF" width="100%" height="30" align="left">
																<table width="100%" cellpadding="1" cellspacing="0">
																	<tr>
																		<td align="left" nowrap><font size="-1"><b><a href="question_form.php">�����Ǣ������</a></b></font></td>
																		<td></td>
																	</tr>
																</table>
															</td></tr>
														</table>
													</td></tr>
												</table>
												<!-- show order link -->
												<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="0" cellspacing="0">
													<tr><td>
														<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="4" cellspacing="1">
															<tr>
																<td class="titlebg" bgcolor="#6E94B7" width="5%" ><font class="text1" color="#FFFFFF" size="2"><b>ʶҹ�</b></font></td>
																<td class="titlebg" bgcolor="#6E94B7" width="10%" align="center">
																<a href="showalltopics.php"><font class="text1" color="#FFFFFF" size="2"><b>�ʵ�����á</b></font></td>
																<td class="titlebg" bgcolor="#6E94B7" width="50%" align="center">
																<a href="showalltopics.php?order=t"><font class="text1" color="#FFFFFF" size="2"><b>��Ǣ��</b></font></td>
																<td class="titlebg" bgcolor="#6E94B7" width="10%" align="center">
																<a href="showalltopics.php?order=s"><font class="text1" color="#FFFFFF" size="2"><b>�������</b></font></a></td>
																<td class="titlebg" bgcolor="#6E94B7" width="5%" align="center">
																<a href="showalltopics.php?order=r"><font class="text1" color="#FFFFFF" size="2"><b>�ͺ</b></font></a></td>
																<td class="titlebg" bgcolor="#6E94B7" width="10%" align="center">
																<a href="showalltopics.php?order=l"><font size="2" class="text1" color="#FFFFFF" size="2"><b>�ʵ�����ش</b></font></a></td>
															</tr>

<?php
	// get order sql
	if(isset($order)) {
		switch($order) {
			case "t" :
				$question_sql1 = "SELECT * FROM board_question ORDER BY q_topic ASC, q_id DESC LIMIT $goto, 30";
				break;
			case "s" :
				$question_sql1 = "SELECT * FROM board_question ORDER BY q_name ASC, q_id DESC LIMIT $goto, 30";
				break;
			case "l" :
				$question_sql1 = "SELECT * FROM board_question ORDER BY q_update DESC, q_id DESC LIMIT $goto, 30";
				break;
			case "r" :
				$question_sql1 = "SELECT * FROM board_question ORDER BY q_reng DESC, q_id DESC LIMIT $goto, 30";
				break;
		} // end case
	} else {
		$question_sql1 = "SELECT * FROM board_question ORDER BY q_id DESC LIMIT $goto, 30";
	} // end if
	$question_query1 = retrieve_db('webservices', $question_sql1);
	if(is_array($question_query1)) {
		while(list($question_key1, $question_val1) = each($question_query1)) {
			$q_id = $question_val1['q_id'];
			$q_post = $question_val1['q_post'];
			$q_topic = $question_val1['q_topic'];
			$q_name = $question_val1['q_name'];
			$q_email = $question_val1['q_email'];
			$q_ip = $question_val1['q_ip'];
			$q_date = $question_val1['q_date'];
			$q_time = $question_val1['q_time'];
			$q_update = $question_val1['q_update'];
			$q_reng = $question_val1['q_reng'];
			$q_member = $question_val1['q_member'];
// ==================================================
//				$q_message = $question_val1['q_message'];
//				$q_icq = $question_val1['q_icq'];
// ==================================================

			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);
			$q_date = stripslashes($q_date);
			$q_time = stripslashes($q_time);

			// get last post
			$answer_sql = "SELECT MAX(a_datetime) FROM board_answer WHERE a_qid='$q_id'";
			$answer_query = retrieve_db('webservices', $answer_sql);
			if(is_array($answer_query)) {
				$q_update1 = $answer_query[0];
			} else {
				$q_update1 = "$q_date:$q_time";
				$q_reng = "0";
			} // end if

			// get current time
			setlocale(LC_TIME, "th");	//������Ẻ��
			$a1 = date("j") * 1440;
			$b1 = strftime("%m") * 44640;	
			$c1 = (strftime("%Y") + 543) * 535680;
			$d1 = date("H") * 60;	 // ���Ҫ������
			$e1 = date("i");				// ���ҹҷ�
			$current = $a1 + $b1 + $c1 + $d1 + $e1;

			$up = $current - $q_update;
			if($up > 21600) {
				$del_question_sql = 'DELETE FROM board_question WHERE q_id=\'' . $q_id . '\'';
				inupdel_db('webservices', $del_question_sql);
				$del_answer_sql = 'DELETE FROM board_answer WHERE a_qid=\'' . $q_id . '\'';
				inupdel_db('webservices', $del_answer_sql);
			} else {
				if($up <= 4320) {
					print "<tr><td bgcolor=\"#F7F7F7\" width=\"5%\" align=\"center\"><img src=\"images/new.gif\" /></td>";
				} else {
					print "<tr><td bgcolor=\"#F7F7F7\" width=\"5%\" align=\"center\"><img src=\"images/normal.gif\" /></td>";
				} // end if
				print "<td class=\"windowbg2\" bgcolor=\"#F8F8F8\" width=\"10%\" align=\"center\" valign=\"middle\"><font size=\"1\">�ѹ��� $q_date<br />���� $q_time</font></td>";
				print "<td class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"50%\" valign=\"middle\"><font size=\"2\"><a href=\"answer_form.php?q_id=$q_id\" target=\"_blank\">$q_topic</a></font></td>";
				print "<td class=\"windowbg2\" bgcolor=\"#F8F8F8\" width=\"10%\" align = \"center\" valign=\"middle\"><font size=\"2\">$q_name</font>";
				if($q_member == "y") {
					print " <img src=\"images/member.gif\" width=\"15\" height=\"15\" border=\"0\" />";
				} // end if
				print "</td>";
				print "<td class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"5%\" align=\"center\" valign=\"middle\"><font size=\"2\">$q_reng</font></td>";
				print "<td class=\"windowbg2\" bgcolor=\"#F8F8F8\" width=\"10%\" align=\"center\" valign=\"middle\"><font size=\"1\">";
				if(isset($q_update1)) echo "�ѹ��� ";
				print "$q_update1</font></td></tr>";
			} // end if
		} // end while
	} // end if
?>

														</table>
													</td></tr>
												</table>
												<table class="bordercolor" bgcolor="#6394BD" border="0" width="100%" cellpadding="0" cellspacing="0">
													<tr><td>
														<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="3" cellspacing="1">
															<tr>
																<td class="catbg" bgcolor="#DEE7EF" width="100%" height="30" align="left">
																	<table width="100%" cellpadding="1" cellspacing="0">
																		<tr>
																			<td></td>
																			<td align="right" nowrap><font size="-1"><a href="question_form.php">�����Ǣ������</a></font></td>
																		</tr>
																	</table>
																</td>
															</tr>
														</table>
													</td></tr>
												</table>
												<table width="100%" cellpadding="0" cellspacing="0">
													<tr></tr>
													<tr>
														<td align="left" valign="middle">
															<img src="images/new.gif" alt="" /><font size="1"> ��Ǣ������ (��з���ա������¹�ŧ���� 3 �ѹ)</font><br />
															<img src="images/normal.gif" alt="" /><font size="1"> ��Ǣ�� (��з������ա������¹�ŧ�������Թ 3 �ѹ)</font>
														</td>
														<td align="right">
															<font size="2"><b>˹��: [</b></font>
<?php
	for($i = 1; $i < $page; $i++) {
		print "<a href=\"$PHP_SELF?page=$i\"><font size=\"2\">$i </font></a>";
	} // end for
	print "<font color=\"red\" size=\"2\"><b>$page </b></font>";
	for($i = $page + 1; $i <= $totalpage; $i++) {
		print "<a href=\"$PHP_SELF?page=$i\"><font size=\"2\">$i </font></a> ";
	} // end for
?>
															<font size="2"><b>]</b></font>
														</td>
													</tr>
												</table>
											</td>
										</tr>
									</tbody>
								</table>
							</td></tr>
						</tbody>
					</table>
				</td></tr>
			</tbody>
		</table>
		<table class="bordercolor" bgcolor="#6394BD" width="90%" border="0" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr>
								<td bgcolor="#FFFFFF" width="75%" align="middle" valign="center"><font face="Verdana, Arial" size="1">Department of Computer Engineering, Faculty of Engineering, King Mongkut's Institute of Technology Ladkrabang<br />Chalongkrung Road, Ladkrabang Bangkok 10520, Thailand.<br />Tel. +662-739-2400-1 Fax.+662-7392404<br />
								<img src="../images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('../passport/signin_form.php', '_top');" />
								</td>
							</tr>
						</tbody>
					</table>
				</td></tr>
			</tbody>
		</table>
	</body>
</html>