<?php
// file view.php
	print "<meta http-equiv=\"refresh\" content=\"0; URL=answer_form.php?q_id=$q_id\" />";
// end file view.php
?>