<?php
// file question_form.php
	session_start();
	// passport services
	require('../passport/services/validate.php');		// use validate - Validate current user

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
		$q_username = $_SESSION['username'];
		$q_passhash = $_SESSION['passhash'];
	} else {
		$q_username = "";
		$q_passhash = "";
	} // end if
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>��駡�з��</title>
		<style type="text/css">
			a:link { color: #005177; background-color: transparent; text-decoration: none }
			a:visited { color: #005177; background-color: transparent; text-decoration: none }
			a:hover { color: #cc3333; background-color: transparent; text-decoration: none }
			.nav { color: #000000; background-color: transparent; text-decoration: none }
			.nav:link { color: #000000; background-color: transparent; text-decoration: none }
			.nav:visited { color: #000000; background-color: transparent; text-decoration: none }
			.nav:hover { font-weight: bold; color: #cc3333; background-color: transparent; text-decoration: underline }
			body { font-size: 12px; font-family: MS Sans Serif }
			table { empty-cells: show }
			td { font-size: 12px; color: #000000; font-family: MS Sans Serif }
			input { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			textarea { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			select { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			.windowbg { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			.windowbg2 { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #f8f8f8 }
			.windowbg3 { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #6394bd }
			.hr { color: #6394bd; background-color: transparent }
			.titlebg { color: #ffffff; background-color: #6e94b7 }
			.text1 { font-weight: bold; font-size: 12px; color: #ffffff; font-style: normal; background-color: transparent }
			.catbg { font-weight: bold; font-size: 13px; background-IMAGE: url(YaBBImages/catbg.jpg); color: #000000 }
			.bordercolor { font-size: 12px; font-family: MS Sans Serif; background-color: #6394bd }
			.quote { font-size: 10px; color: #000000; font-family: MS Sans Serif; background-color: #dee7ef }
			.code { font-size: 10px; color: #000000; font-family: MS Sans Serif; background-color: #cccccc }
			.help { cursor: help; background-color: transparent }
			.meaction { color: red; background-color: transparent }
			.editor { width : 100% }
		</style>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
	</head>
	<body text="#000000" link="#0033FF" bgcolor="#F5F5F5">
		<table class="bordercolor" bgcolor="#6394BD" border="0" width="90%" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" width="100%" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr><td>
								<table border="0" width="100%" align="center" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td bgcolor="#FFFFFF" align="left" valign="center">
												<img src="images/logo.gif" alt="logo" />
											</td>
											<td bgcolor="#FFFFFF" valign="center">
												<font size="2">�Թ�յ�͹�Ѻ�س <?php if(validate($ip)) echo $_SESSION['username']; ?> �������дҹ���-�ͺ�ͧ�Ҥ�Ԫ����ǡ�������������<br />ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ��Ѻ</font>
											</td>
										</tr>
									</tbody>
								</table>
							</td></tr>
							<tr bgcolor="#B7BBDA" align="middle" valign="center">
								<td bgcolor="#AFC6DB">
									<font size="1">
										<a href="../index.php">˹���á | </a>
<?php
	if(validate($ip)) {
?>
										<a href="../passport/change_pwd_form.php?services=webboard/">����¹���ʼ�ҹ | </a>
										<a href="../passport/view_profile.php">�ʴ���������ǹ��� | </a>
										<a href="../passport/edit_profile_form.php">��䢢�������ǹ��� | </a>
										<a href="../passport/del_profile_form.php">ź��������ǹ��� | </a>
										<a href="../passport/index.php?passport=�͡�ҡ�к�&services=webboard/">�͡�ҡ�к�</a>
<?php
	} else {
?>
										<a href="../passport/register_form.php?services=webboard/">ŧ����¹��������� | </a>
										<a href="../passport/signin_form.php?services=webboard/">�������к� | </a>
										<a href="../passport/forget_pwd_form.php">������ʼ�ҹ</a>
<?php
	} // end if
?>
									</font>
								</td>
							</tr>
						</tbody>
					</table>
				</td></tr>
			</tbody>
		</table><br />
		<table class="bordercolor" bgcolor="#6394BD" width="90%" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" border="0" width="100%" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr><td>
								<table bgcolor="#FFFFFF" border="0" width="100%" align="center" cellpadding="10" cellspacing="0">
									<tbody>
										<tr>
											<td width="100%" valign="top">
												<table width="100%" cellpadding="0" cellspacing="0">
													<tr>
														<td>
															<a name="top"></a><a href="" class="nav"><font class="nav" size="1"><b>��дҹ���-�ͺ</b></a> | <b><a href="../news/index.php" class="nav">��С�Ȣ�����������Ҥ�Ԫ��</a></font>
														</td>
														<td align="right">
															<a href="help.php" class="nav"><font size="1"><b>Help</b></font></a>
														</td>
													</tr>
												</table>
												<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="0" cellspacing="0">
													<tr><td>
														<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="3" cellspacing="1">
															<tr><td class="catbg" bgcolor="#DEE7EF" width="100%" height="30" align="left">
																<table width="100%" cellpadding="1" cellspacing="0">
																	<tr>
																		<td>
																			<font size="2"><b>��駡�з������</a></b></font>
																		</td>
<?php
	if(validate($ip)) {
?>
																		<td align="right" nowrap><font size="-1">��ҵ�ͧ�������ա������͹������դ��ҵͺ���Ǣ�͹�� ��������ͧ���¶١㹪�ͧ��������ҹ��ҧ�ͧ��з��</font></td>
<?php
	} else {
?>
																		<td></td>
<?php
	} // end if
?>
																		<td></td>
																	</tr>
																</table>
															</td></tr>
														</table>
													</td></tr>
												</table>
												<!-- form for post question -->
												<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
													<tr>
														<td class="catbg" bgcolor="#DEE7EF" width="100%" height="30" align="center">
															<form name="question" action="index.php" method="POST" onsubmit="return check()" autocomplete="off">
																<table width="100%" align="center" cellpadding="3" cellspacing="0">
																	<tr><td></td><td></td><td></td><td></td></tr>
																	<tr><td align="center" valign="top" colspan="5">
																		<font color="blue" size="4"><b>��Ǣ�͡�з������</b></font>
																	</td></tr>
																	<tr><td align="center" valign="top" colspan="5">
																		<font size="4"><b>&nbsp;</b></font>
																	</td></tr>
																	<tr>
																		<td width="20%" align="right" valign="top">
<?php
	if(validate($ip)) {
?>
																			<font color="red" size="2">&nbsp;&nbsp;</font>
<?php
	} else {
?>
																			<font color="red" size="2">* </font>
<?php
	} // end if
?>
																			<font size="2"><b>���� : </b></font>
																		</td>
																		<td width="20%" align="left" valign="top">
																			<input type="text" name="q_name" size="25" maxlength="50" />
																		</td>
																		<td width="20%" align="right" valign="top">
																			<font size="2"><b>���������駡�з�� : </b></font>
																		</td>
																		<td width="20%" align="left" valign="top">
																			<input type="text" name="q_email" size="25" maxlength="50" />
																		</td>
																		<td width="20%" align="left" valign="top">
																		</td>
																	</tr>
<?php
	if(validate($ip)) {
		print "<tr><td width=\"20%\" align=\"right\" valign=\"top\">";
		print "<font size=\"2\"><b>���ͼ���� : </b></font>";
		print "</td>";
		print "<td align=\"left\" valign=\"top\" colspan=\"4\"><font size=\"2\"><b>$q_username</b>";
		print "<font color=\"#FF0000\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;* </font>������������ͨ�����ͼ����᷹㹡�õ�駡�з��Ф�Ѻ</font>";
		print "</td></tr>";
	} else {
		print "<tr><td width=\"20%\" align=\"right\" valign=\"top\"></td><td width=\"20%\" align=\"left\" valign=\"top\"></td>";
		print "<td width=\"20%\" align=\"right\" valign=\"top\"></td><td width=\"20%\" align=\"left\" valign=\"top\"></td>";
		print "<td width=\"20%\" align=\"right\" valign=\"top\"></td></tr>";
	} // end if
?>
																	<tr>
																		<td width="20%" align="right" valign="top">
																			<font color="red" size="2"><b>* </b></font>
																			<font size="2"><b>������Ǣ�� : </b></font>
																		</td>
																		<td align="left" colspan="4">
																			<input type="text" name="q_topic" size="40" />
																		</td>
																	</tr>
																	<tr>
																		<td width="20%" align="right" valign="top">
																			<font color="red" size="2"><b>* </b></font>
																			<font size="2"><b>��ͤ��� : </b></font>
																		</td>
																		<td align="left" colspan="4">
																			<textarea name="q_message" rows="12" cols="80"></textarea>
																		</td>
																	</tr>
<?php
	if(validate($ip)) {
?>
								<tr>
									<td align="right" nowrap><font size="2"><b>����͹������ռ��ͺ : </b></font></td>
									<td align="left" colspan="4"><font size="2"><input type="checkbox" name="q_alert" value="y" /></font><font size="1"> ���͡������ҡ��ͧ�������ա������͹����͡�з���ա������¹�ŧ</font></td>
								</tr>
<?php
	} else {
		echo "<input type=\"hidden\" name=\"q_alert\" value=\"n\" />";
	} // end if
?>
							</table>
							<table width="100%" cellpadding="3" cellspacing="0">
								<tr><td>
									<div align="center">
										<a href="javascript:setsmile(':smile:')"><img src="pics/smile.gif" border="0" /></a>
										<a href="javascript:setsmile(':sad:')"><img src="pics/frown.gif" border="0" /></a>
										<a href="javascript:setsmile(':red:')"><img src="pics/redface.gif" border="0" /></a>
										<a href="javascript:setsmile(':big:')"><img src="pics/biggrin.gif" border="0" /></a>
										<a href="javascript:setsmile(':ent:')"><img src="pics/blue.gif" border="0" /></a>
										<a href="javascript:setsmile(':shy:')"><img src="pics/shy.gif" border="0" /></a>
										<a href="javascript:setsmile(':sleepy:')"><img src="pics/sleepy.gif" border="0" /></a>
										<a href="javascript:setsmile(':sun:')"><img src="pics/sunglasses.gif" border="0" /></a>
										<a href="javascript:setsmile(':sg:')"><img src="pics/supergrin.gif" border="0" /></a>
										<a href="javascript:setsmile(':embarass:')"><img src="pics/embarass.gif" border="0" /></a>
										<a href="javascript:setsmile(':dead:')"><img src="pics/dead.gif" border="0" /></a>
										<a href="javascript:setsmile(':cool:')"><img src="pics/cool.gif" border="0" /></a>
										<a href="javascript:setsmile(':clown:')"><img src="pics/clown.gif" border="0" /></a>
										<a href="javascript:setsmile(':pukey:')"><img src="pics/pukey.gif" border="0" /></a><br />
										<a href="javascript:setsmile(':eek:')"><img src="pics/eek.gif" border="0" /></a>
										<a href="javascript:setsmile(':roll:')"><img src="pics/sarcblink.gif" border="0" /></a>
										<a href="javascript:setsmile(':smoke:')"><img src="pics/smokin.gif" border="0" /></a>
										<a href="javascript:setsmile(':angry:')"><img src="pics/reallymad.gif" border="0" /></a>
										<a href="javascript:setsmile(':confused:')"><img src="pics/confused.gif" border="0" /></a>
										<a href="javascript:setsmile(':cry:')"><img src="pics/crying.gif" border="0" /></a>
										<a href="javascript:setsmile(':lol:')"><img src="pics/lol.gif" border="0" /></a>
										<a href="javascript:setsmile(':yawn:')"><img src="pics/yawn.gif" border="0" /></a>
										<a href="javascript:setsmile(':devil:')"><img src="pics/devil.gif" border="0" /></a>
										<a href="javascript:setsmile(':tongue:')"><img src="pics/tongue.gif" border="0" /></a>
										<a href="javascript:setsmile(':alien:')"><img src="pics/aysmile.gif" border="0" /></a>
										<a href="javascript:setsmile(':tasty:')"><img src="pics/tasty.gif" border="0" /></a>
										<a href="javascript:setsmile(':crazy:')"><img src="pics/crazy.gif" border="0" /></a><br />
										<font color="blue"><b>��ԡ����ٻ�����á�ٻŧ㹢�ͤ���</b></font>
									</div>
								</td></tr>
								<tr>
									<td width="100%" align="center" valign="top">
										<input type="submit" name="action" value="post_question" />
										<input type="reset" name="clear" value="clear" />
									</td>
								</tr>
							</table>
							<input type="hidden" name="max_file_size" value="50*1024*1024" />		<!-- 50 Mbyte-->
<?php
	echo "<input type=\"hidden\" name=\"q_username\" value=\"$q_username\" />";
	echo "<input type=\"hidden\" name=\"q_passhash\" value=\"$q_passhash\" />";
?>
						</form>
					</td></tr>
				</tbody> 
			</table>
		</center>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.question.q_name.value;
		var v2 = document.question.q_email.value;
		var v3 = document.question.q_username.value;
		var v4 = document.question.q_topic.value;
		var v5 = document.question.q_message.value;
		var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i

		if(v3.length==0) {
			if(v1.length==0) {
				alert("��سһ�͹���ͼ���駡�з��");
				document.question.q_name.focus();
				return false;
			} else if(v2.length==0) {
			} else {
				if(document.layers||document.getElementById||document.all) {
					if(filter.test(v2)) {
					} else {
						alert("��سһ�͹���������١��ͧ");
						document.question.q_email.focus();
						return false;
					} // end if
				} // end if
			} // end if
		} // end if
		if(v4.length==0) {
			alert("��سһ�͹������Ǣ�͡�з��");
			document.question.q_topic.focus();    
			return false;
		} else if(v5.length==0) {
			alert("��سһ�͹��ͤ���");
			document.question.q_message.focus();
			return false;
		} // end if
	} // end function
	function setsmile(what) {
		document.question.q_message.value = document.question.elements.q_message.value + " " + what;
		document.question.q_message.focus();
	} // end function
//-->
		</script>
	</body>
</html>

<?php
// end file question_form.php
?>