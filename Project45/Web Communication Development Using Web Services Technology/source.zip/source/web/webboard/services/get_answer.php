<?php
// file get_answer.php
	##########################################################################
	# Function Name		: get_answer
	# Function Purpose	 	: Return answer array from database
	# Receive					: $q_id - id of question
	# Return					: $answer if success, "" otherwise
	##########################################################################
	function get_answer($q_id) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('q_id'=>$q_id);
		$soapclient = new soapclient('http://161.246.6.54/services/webboard/get_answer.php');		// create soap client
		$answer = $soapclient->call('get_answer', $parameters);		// call get_answer services

		return $answer;
	} // end function get_answer
// end file get_answer.php
?>