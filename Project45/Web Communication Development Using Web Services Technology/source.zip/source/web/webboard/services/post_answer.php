<?php
// file post_answer.php
	##########################################################################
	# Function Name		: post_answer
	# Function Purpose		: Post answer to database
	# Recieves					: $q_id - id of question that post answer
	#								  $a_message - message of post answer
	#								  $a_username - the username of sign in user that post answer
	#								  $a_passhash - the passhash of sign in user that post answer
	#								  $a_name - name of user that post answer
	#								  $a_email - email address of user that post answer
	#								  $a_ip - ip of user that post answer
	#								  $a_date - date of post answer
	#								  $q_update - time of post answer in minute
	#								  $a_alert - flag of alert
	# Returns					: true if success, true otherwise
	##########################################################################
	function post_answer($q_id, $a_message, $a_username, $a_passhash, $a_name, $a_email, $a_ip, $a_date, $q_update, $a_alert) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('q_id'=>$q_id, 'a_message'=>$a_message, 'a_username'=>$a_username, 'a_passhash'=>$a_passhash, 'a_name'=>$a_name, 'a_email'=>$a_email, 'a_ip'=>$a_ip, 'a_date'=>$a_date, 'q_update'=>$q_update, 'a_alert'=>$a_alert);
		$soapclient = new soapclient('http://161.246.6.54/services/webboard/post_answer.php');		// create soap client
		$flag = $soapclient->call('post_answer', $parameters);		// call post_answer services

		return $flag;
	} // end function post_answer
// end file post_answer.php
?>