<?php
// file post_question.php
	##########################################################################
	# Function Name		: post_question
	# Function Purpose		: Post question to database
	# Recieves					: $q_topic - topic of post question
	#								  $q_message - message of post question
	#								  $q_username - username of sign in user that post question
	#								  $q_passhash - passhash of sign in user that post question
	#								  $q_name - name of user that post question
	#								  $q_email - email address of user that post question
	#								  $q_ip - ip of user that post question
	#								  $q_date - date of post question
	#								  $q_time - time of post question
	#								  $q_update - time of update question in minute
	#								  $q_reng - number of reply question
	#								  $q_alert - flag of alert
	# Returns					: success text if success, error text otherwise
	##########################################################################
	function post_question($q_topic, $q_message, $q_username, $q_passhash, $q_name, $q_email, $q_ip, $q_date, $q_time, $q_update, $q_reng, $q_alert) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('q_topic'=>$q_topic, 'q_message'=>$q_message, 'q_username'=>$q_username, 'q_passhash'=>$q_passhash, 'q_name'=>$q_name, 'q_email'=>$q_email, 'q_ip'=>$q_ip, 'q_date'=>$q_date, 'q_time'=>$q_time, 'q_update'=>$q_update, 'q_reng'=>$q_reng, 'q_alert'=>$q_alert);
		$soapclient = new soapclient('http://161.246.6.54/services/webboard/post_question.php');		// create soap client
		$result = $soapclient->call('post_question', $parameters);		// call post_question services

		return $result;
	} // end function post_question
// end file post_question.php
?>