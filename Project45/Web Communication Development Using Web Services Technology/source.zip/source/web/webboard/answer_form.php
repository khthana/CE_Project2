<?php
// file answer_form.php
	session_start();
	// database services
	require('../database/services/retrieve_db.php');		// use retrieve_db - Retrieve data from database
	// passport services
	require('../passport/services/validate.php');		// use validate - Validate current user
	// webboard services
	require('services/get_question.php');		// use get_question - Get question from database

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
		$a_username = $_SESSION['username'];
		$a_passhash = $_SESSION['passhash'];
	} else {
		$a_username = "";
		$a_passhash = "";
	} // end if

	if(isset($q_id)) {
		$question = get_question($q_id);
		if(is_array($question)) {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>�ͺ��з��</title>
		<style type="text/css">
			a:link { color: #005177; background-color: transparent; text-decoration: none }
			a:visited { color: #005177; background-color: transparent; text-decoration: none }
			a:hover { color: #cc3333; background-color: transparent; text-decoration: none }
			.nav { color: #000000; background-color: transparent; text-decoration: none }
			.nav:link { color: #000000; background-color: transparent; text-decoration: none }
			.nav:visited { color: #000000; background-color: transparent; text-decoration: none }
			.nav:hover { font-weight: bold; color: #cc3333; background-color: transparent; text-decoration: underline }
			body { font-size: 12px; font-family: MS Sans Serif }
			table { empty-cells: show }
			td { font-size: 12px; color: #000000; font-family: MS Sans Serif }
			input { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			textarea { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			select { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			.windowbg { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #afc6db }
			.windowbg2 { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #f8f8f8 }
			.windowbg3 { font-size: 12px; color: #000000; font-family: MS Sans Serif; background-color: #6394bd }
			.hr { color: #6394bd; background-color: transparent }
			.titlebg { color: #ffffff; background-color: #6e94b7 }
			.text1 { font-weight: bold; font-size: 12px; color: #ffffff; font-style: normal; background-color: transparent }
			.catbg { font-weight: bold; font-size: 13px; background-IMAGE: url(YaBBImages/catbg.jpg); color: #000000 }
			.bordercolor { font-size: 12px; font-family: MS Sans Serif; background-color: #6394bd }
			.quote { font-size: 10px; color: #000000; font-family: MS Sans Serif; background-color: #dee7ef }
			.code { font-size: 10px; color: #000000; font-family: MS Sans Serif; background-color: #cccccc }
			.help { cursor: help; background-color: transparent }
			.meaction { color: red; background-color: transparent }
			.editor { width : 100% }
		</style>
		<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
	</head>
	<body text="#000000" link="#0033FF" bgcolor="#F5F5F5">
		<table class="bordercolor" bgcolor="#6394BD" border="0" width="90%" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" width="100%" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr><td>
								<table border="0" width="100%" align="center" cellpadding="0" cellspacing="0">
									<tbody>
										<tr>
											<td bgcolor="#FFFFFF" align="left" valign="center">
												<img src="images/logo.gif" alt="logo" />
											</td>
											<td bgcolor="#FFFFFF" valign="center">
												<font size="2">�Թ�յ�͹�Ѻ�س <?php if(validate($ip)) echo $_SESSION['username']; ?> �������дҹ���-�ͺ�ͧ�Ҥ�Ԫ����ǡ�������������<br />ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ��Ѻ</font>
											</td>
										</tr>
									</tbody>
								</table>
							</td></tr>
							<tr bgcolor="#B7BBDA" align="middle" valign="center">
								<td bgcolor="#AFC6DB">
									<font size="1">
										<a href="../index.php">˹���á | </a>
<?php
	if(validate($ip)) {
?>
										<a href="../passport/change_pwd_form.php?services=webboard/">����¹���ʼ�ҹ | </a>
										<a href="../passport/view_profile.php">�ʴ���������ǹ��� | </a>
										<a href="../passport/edit_profile_form.php">��䢢�������ǹ��� | </a>
										<a href="../passport/del_profile_form.php">ź��������ǹ��� | </a>
										<a href="../passport/index.php?passport=�͡�ҡ�к�&services=webboard/">�͡�ҡ�к�</a>
<?php
	} else {
?>
										<a href="../passport/register_form.php?services=webboard/">ŧ����¹��������� | </a>
										<a href="../passport/signin_form.php?services=webboard/">�������к� | </a>
										<a href="../passport/forget_pwd_form.php">������ʼ�ҹ</a>
<?php
	} // end if
?>
									</font>
								</td>
							</tr>
						</tbody>
					</table>
				</td></tr>
			</tbody>
		</table><br />
		<table class="bordercolor" bgcolor="#6394BD" width="90%" align="center" cellpadding="0" cellspacing="0">
			<tbody>
				<tr><td>
					<table class="bordercolor" bgcolor="#6394BD" border="0" width="100%" align="center" cellpadding="0" cellspacing="1">
						<tbody>
							<tr><td>
								<table bgcolor="#FFFFFF" border="0" width="100%" align="center" cellpadding="10" cellspacing="0">
									<tr>
										<td width="100%" valign="top">
											<table width="100%" cellpadding="0" cellspacing="0">
												<tr>
													<td>
														<a name="top"></a><a href="" class="nav"><font class="nav" size="1"><b>��дҹ���-�ͺ</b></a> | <b><a href="../news/index.php" class="nav">��С�Ȣ�����������Ҥ�Ԫ��</a></font>
													</td>
													<td align="right">
														<a href="help.php" class="nav"><font size="1"><b>Help</b></font></a>
													</td>
												</tr>
											</table>
											<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="0" cellspacing="0">
												<tr><td>
													<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" cellpadding="3" cellspacing="1">
														<tr><td class="catbg" bgcolor="#DEE7EF" width="100%" height="30" align="left">
															<table width="100%" cellpadding="3" cellspacing="0">
																<tr>
																	<td>
																		<font size="2"><b><a href="#ansfrm">�ͺ��з��</a></b></font>
																	</td>
																	<td align="right" nowrap><font size="-1">��ҵ�ͧ�������ա������͹������դ��ҵͺ���Ǣ�͹�� ��������ͧ���¶١㹪�ͧ��������ҹ��ҧ�ͧ��з��</font></td>
																</tr>
															</table>
														</td></tr>
													</table>
												</td></tr>
											</table>

<?php
			$q_topic = $question['q_topic'];
			$q_message = $question['q_message'];
			$q_name = $question['q_name'];
			$q_email = $question['q_email'];
			$q_icq = $question['q_icq'];
			$q_ip = $question['q_ip'];
			$q_date = $question['q_date'];
			$q_time = $question['q_time'];
			$q_update = $question['q_update'];
			$q_member = $question['q_member'];
// ==================================================
//			$q_post = $question['q_post'];
//			$q_reng = $question['q_reng'];
// ==================================================
			$q_topic = stripslashes($q_topic);
			$q_name = stripslashes($q_name);
			$q_email = stripslashes($q_email);
			$q_ip = stripslashes($q_ip);

			// question topic
			print "<table class=\"bordercolor\" bgcolor=\"#6394BD\" width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"0\" cellspacing=\"0\"><tr><td><table width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\"><tr>";
			print "<td class=\"titlebg\" bgcolor=\"#6E94B7\" width=\"15%\" align=\"left\" valign=\"middle\"><font class=\"text1\" color=\"#FFFFFF\" size=\"2\">&nbsp;&nbsp;<b>�����¹</b></font></td>";
			print "<td class=\"titlebg\" bgcolor=\"#6E94B7\" width=\"85%\" align=\"left\" valign=\"middle\"><font class=\"text1\" color=\"#FFFFFF\" size=\"2\"><b>&nbsp;��Ǣ��: $q_topic</b>&nbsp;</font></td>";
			print "</tr></table></td></tr></table>";
			// question detail
			print "<table class=\"bordercolor\" bgcolor=\"#6394BD\" width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\"><tr><td class=\"windowbg\" bgcolor=\"#AFC6DB\">";
			print "<table class=\"windowbg\" bgcolor=\"#AFC6DB\ width=\"100%\" cellpadding=\"4\" cellspacing=\"1\"><tr>";
			print "<td class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"15%\" valign=\"top\" rowspan=\"2\">";
			if($q_email == "") {
				print "<img src=\"images/mail.gif\" width=\"33\" height=\"11\" border=\"0\" alt=\"������֧����駡�з��\" />";
			} else {
				print "<a href=\"mailto:$q_email\"><img src=\"images/mail.gif\" width=\"33\" height=\"11\" border=\"0\" alt=\"������֧����駡�з��\" /></a>";
			} // end if
			print "<font size=\"1\"><b>$q_name</b></font><br />";
			if($q_member == "y") {
				print " <img src=\"images/member.gif\" width=\"15\" height=\"15\" border=\"0\" alt=\"��Ҫԡ\" />";
			} // end if
			print "</td>";
			print "<td class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"85%\" valign=\"top\"><table border=\"0\" width=\"100%\"><tr><td align=\"left\" valign=\"middle\"></td><td align=\"left\" valign=\"middle\">";
			print "<img src=\"images/post.gif\" align=\"texttop\" />";
			print "<font size=\"2\"><b>$q_topic</b></font><br />";
			print "<font size=\"1\"><b>�����:</b> �ѹ��� $q_date ���� $q_time</font></td>";
			print "<td height=\"20\" align=\"right\" valign=\"bottom\"><font size=\"-1\"></font></td></tr></table>";
			print "<hr class=\"windowbg3\" width=\"100%\" size=\"1\">";
			print "<font size=\"2\">$q_message</font>";
			print "</td></tr>";
			print "<tr><td class=\"windowbg\" bgcolor=\"#AFC6DB\" align=\"right\" valign=\"bottom\">";
			print "<table width=\"100%\" border=\"0\"><tr>";
			print "<td align=\"left\"><font size=\"1\"></font></td>";
			print "<td align=\"right\"><img src=\"images/ip.gif\" align=\"texttop\" /><font size=\"1\">$q_ip</font>";
			print "</td></tr></table></td></tr></table></td></tr></table></td></tr>";

			$answer_sql = "SELECT * FROM board_answer WHERE a_qid='$q_id' ORDER BY a_id ASC";
			$answer_query = retrieve_db('webservices', $answer_sql);
			if(is_array($answer_query)) {
				$i = 0;
				while(list($answer_key, $answer_val) = each($answer_query)) {
					$a_message = $answer_val['a_message'];
					$a_name = $answer_val['a_name'];
					$a_email = $answer_val['a_email'];
					$a_icq = $answer_val['a_icq'];
					$a_ip = $answer_val['a_ip'];
					$a_date = $answer_val['a_datetime'];
					$a_member = $answer_val['a_member'];
// ==================================================
//					$a_id = $answer_val['a_id'];
//					$a_qid = $answer_val['a_qid'];
//					$a_update = $answer_val['a_update'];
// ==================================================
					$a_name = stripslashes($a_name);
					$a_email = stripslashes($a_email);
					$a_icq = stripslashes($a_icq);
					$a_ip = stripslashes($a_ip);
					$a_date = stripslashes($a_date);

					// answer detail
					if(($i % 2) == 0) {
						print "<tr><td><table width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\"><tr><td class=\"windowbg2\" bgcolor=\"#F8F8F8\">";
						print "<table class=\"windowbg2\" bgcolor=\"#F8F8F8\" width=\"100%\" cellpadding=\"4\" cellspacing=\"1\"><tr>";
						print "<td class=\"windowbg2\" bgcolor=\"#F8F8F8\" width=\"15%\" valign=\"top\" rowspan=\"2\">";
					} else {
						print "<tr><td><table width=\"100%\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\"><tr><td class=\"windowbg\" bgcolor=\"#AFC6DB\">";
						print "<table class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"100%\" cellpadding=\"4\" cellspacing=\"1\"><tr>";
						print "<td class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"15%\" valign=\"top\" rowspan=\"2\">";
					} // end if
					if($a_email == "") {
						print "<img src=\"images/mail.gif\" width=\"33\" height=\"11\" border=\"0\" alt=\"������֧���ͺ��з��\" />";
					} else {
						print "<a href=\"mailto:$a_email\"><img src=\"images/mail.gif\" width=\"33\" height=\"11\" border=\"0\" alt=\"������֧���ͺ��з��\" /></a>";
					} // end if
					print "<font size=\"1\"><b>$a_name</b></font>";
					if($a_member == "y") {
						print " <img src=\"images/member.gif\" width=\"15\" height=\"15\" border=\"0\" alt=\"��Ҫԡ\" />";
					} // end if
					print "</td>";
					if(($i % 2) == 0) {
						print "<td class=\"windowbg2\" bgcolor=\"#F8F8F8\" width=\"85%\" height=\"100%\" valign=\"top\"><table width=\"100%\" border=\"0\"><tr><td align=\"left\" valign=\"middle\"><img src=\"images/answer.gif\" alt=\"\"></td>";
					} else {
						print "<td class=\"windowbg\" bgcolor=\"#AFC6DB\" width=\"85%\" height=\"100%\" valign=\"top\"><table width=\"100%\" border=\"0\"><tr><td align=\"left\" valign=\"middle\"><img src=\"images/answer.gif\" alt=\"\"></td>";
					} // end if
					print "<td align=\"left\" valign=\"middle\"><font size=\"1\"><b>�ͺ�� </b>$a_name <b>�����:</b> �ѹ��� $a_date</font></td>";
					print "<td height=\"20\" align=\"right\" valign=\"bottom\" nowrap><font size=\"-1\"></font></td></tr></table>";
					print "<hr class=\"windowbg3\" width=\"100%\" size=\"1\">";
					print "$a_message</td></tr><tr>";
					if(($i % 2) == 0) {
						print "<td  class=\"windowbg2\" bgcolor=\"#F8F8F8\" valign=\"bottom\">";
					} else {
						print "<td  class=\"windowbg\" bgcolor=\"#AFC6DB\" valign=\"bottom\">";
					} // end if
					print "<table width=\"100%\" border=\"0\"><tr>";
					print "<td align=\"left\"><font size=\"1\"></font></td>";
					print "<td align=\"right\"><font size=\"1\"><font size=\"1\"><img src=\"images/ip.gif\" />$q_ip</font>&nbsp;&nbsp;</font></td>";
					print "</tr></table></td></tr></table></td></tr></table></td></tr>";
					$i++;
				} // end while
				print "</table>";
			} // end if
?>

			<!-- form for post answer -->
			<a name="ansfrm"></a>
			<table class="bordercolor" bgcolor="#6394BD" width="100%" border="0" align="center" cellpadding="3" cellspacing="1">
				<tr>
					<td class="catbg" bgcolor="#DEE7EF" width="100%" height="30" align="center">
						<form name="answer" action="index.php?q_id=<?php echo $q_id; ?>" method="POST" onsubmit="return check()">
							<table width="100%" align="center" cellpadding="3" cellspacing="0">
								<tr><td></td><td></td><td></td><td></td></tr>
								<tr><td align="center" valign="top" colspan="5">
									<font color="blue" size="4"><b>�����ʴ������Դ���</b></font>
								</td></tr>
								<tr>
									<td width="20%" align="right" valign="top">
<?php
	if(validate($ip)) {
?>
										<font color="red" size="2">* </font>
<?php
	} else {
?>
										<font color="red" size="2">&nbsp;&nbsp;</font>
<?php
	} // end if
?>
										<font size="2"><b>���� : </b></font>
									</td>
									<td width="20%" align="left" valign="top">
										<input type="text" name="a_name" size="25" maxlength="50" />
									</td>
									<td width="20%" align="right" valign="top">
										<font size="2"><b>��������ͺ : </b></font>
									</td>
									<td width="20%" align="left" valign="top">
										<input type="text" name="a_email" size="25" maxlength="50" />
									</td>
									<td width="20%" align="left" valign="top">
									</td>
								</tr>
<?php
	if(validate($ip)) {
		print "<tr><td width=\"20%\" align=\"right\" valign=\"top\">";
		print "<font size=\"2\"><b>���ͼ���� : </b></font>";
		print "</td>";
		print "<td align=\"left\" valign=\"top\" colspan=\"4\"><font size=\"2\"><b>$a_username</b>";
		print "<font color=\"#FF0000\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;* </font>������������ͨ�����ͼ����᷹㹡�õͺ�Ф�Ѻ</font>";
		print "</td></tr>";
	} else {
		print "<tr><td width=\"20%\" align=\"right\" valign=\"top\"></td><td width=\"20%\" align=\"left\" valign=\"top\"></td>";
		print "<td width=\"20%\" align=\"right\" valign=\"top\"></td><td width=\"20%\" align=\"left\" valign=\"top\"></td>";
		print "<td width=\"20%\" align=\"right\" valign=\"top\"></td></tr>";
	} // end if
?>
								<tr>
									<td width="20%" align="right" valign="top">
										<font color="red" size="2"><b>* </b></font>
										<font size="2"><b>��ͤ��� : </b></font>
									</td>
									<td align="left" colspan="4">
										<textarea name="a_message" rows="12" cols="80"></textarea>
									</td>
								</tr>
<?php
	if(validate($ip)) {
?>
								<tr>
									<td align="right" nowrap><font size="2"><b>����͹������ռ��ͺ : </b></font></td>
									<td align="left" colspan="4"><font size="2"><input type="checkbox" name="a_alert" value="y" /></font><font size="1"> ���͡������ҡ��ͧ�������յ�ͧ�������ա������͹����͡�з���ա������¹�ŧ</font></td>
								</tr>
<?php
	} else {
		echo "<input type=\"hidden\" name=\"a_alert\" value=\"n\" />";
	} // end if
?>
							</table>
							<table width="100%" cellpadding="3" cellspacing="0">
								<tr><td>
									<div align="center">
										<a href="javascript:setsmile(':smile:')"><img src="pics/smile.gif" border="0" /></a>
										<a href="javascript:setsmile(':sad:')"><img src="pics/frown.gif" border="0" /></a>
										<a href="javascript:setsmile(':red:')"><img src="pics/redface.gif" border="0" /></a>
										<a href="javascript:setsmile(':big:')"><img src="pics/biggrin.gif" border="0" /></a>
										<a href="javascript:setsmile(':ent:')"><img src="pics/blue.gif" border="0" /></a>
										<a href="javascript:setsmile(':shy:')"><img src="pics/shy.gif" border="0" /></a>
										<a href="javascript:setsmile(':sleepy:')"><img src="pics/sleepy.gif" border="0" /></a>
										<a href="javascript:setsmile(':sun:')"><img src="pics/sunglasses.gif" border="0" /></a>
										<a href="javascript:setsmile(':sg:')"><img src="pics/supergrin.gif" border="0" /></a>
										<a href="javascript:setsmile(':embarass:')"><img src="pics/embarass.gif" border="0" /></a>
										<a href="javascript:setsmile(':dead:')"><img src="pics/dead.gif" border="0" /></a>
										<a href="javascript:setsmile(':cool:')"><img src="pics/cool.gif" border="0" /></a>
										<a href="javascript:setsmile(':clown:')"><img src="pics/clown.gif" border="0" /></a>
										<a href="javascript:setsmile(':pukey:')"><img src="pics/pukey.gif" border="0" /></a><br />
										<a href="javascript:setsmile(':eek:')"><img src="pics/eek.gif" border="0" /></a>
										<a href="javascript:setsmile(':roll:')"><img src="pics/sarcblink.gif" border="0" /></a>
										<a href="javascript:setsmile(':smoke:')"><img src="pics/smokin.gif" border="0" /></a>
										<a href="javascript:setsmile(':angry:')"><img src="pics/reallymad.gif" border="0" /></a>
										<a href="javascript:setsmile(':confused:')"><img src="pics/confused.gif" border="0" /></a>
										<a href="javascript:setsmile(':cry:')"><img src="pics/crying.gif" border="0" /></a>
										<a href="javascript:setsmile(':lol:')"><img src="pics/lol.gif" border="0" /></a>
										<a href="javascript:setsmile(':yawn:')"><img src="pics/yawn.gif" border="0" /></a>
										<a href="javascript:setsmile(':devil:')"><img src="pics/devil.gif" border="0" /></a>
										<a href="javascript:setsmile(':tongue:')"><img src="pics/tongue.gif" border="0" /></a>
										<a href="javascript:setsmile(':alien:')"><img src="pics/aysmile.gif" border="0" /></a>
										<a href="javascript:setsmile(':tasty:')"><img src="pics/tasty.gif" border="0" /></a>
										<a href="javascript:setsmile(':crazy:')"><img src="pics/crazy.gif" border="0" /></a><br />
										<font color="blue"><b>��ԡ����ٻ�����á�ٻŧ㹢�ͤ���</b></font>
									</div>
								</td></tr>
								<tr>
									<td width="100%" align="center" valign="top">
										<input type="submit" name="action" value="post_answer" />
										<input type="reset" name="clear" value="clear" />
									</td>
								</tr>
							</table>
							<input type="hidden" name="max_file_size" value="50*1024*1024" />		<!-- 50 Mbyte-->
<?php
	echo "<input type=\"hidden\" name=\"a_username\" value=\"$a_username\" />";
	echo "<input type=\"hidden\" name=\"a_passhash\" value=\"$a_passhash\" />";
?>
						</form>
					</td></tr>
				</tbody>
			</table>
			<script language="javascript">
<!--
function check() {
		var v1 = document.answer.a_name.value;
		var v2 = document.answer.a_email.value;
		var v3 = document.answer.a_username.value;
		var v4 = document.answer.a_message.value;
		var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i

		if((v3.length==0)) {
			if(v1.length==0) {
				alert("��سһ�͹���ͼ��ͺ��з��");
				document.answer.a_name.focus();
				return false;
			} else if(v2.length==0) {
			} else {
				if(document.layers||document.getElementById||document.all) {
					if(filter.test(v2)) {
					} else {
						alert("��سһ�͹���������١��ͧ");
						document.answer.a_email.focus();
						return false;
					} // end if
				} // end if
			} // end if
		} // end if
		if(v4.length==0) {
			alert("��سһ�͹��ͤ���");
			document.answer.a_message.focus();
			return false;
		} // end if
	} // end function
	function setsmile(what) {
		document.answer.a_message.value = document.answer.elements.a_message.value + " " + what;
		document.answer.a_message.focus();
	} // end function
//-->
			</script>
		</center>
	</body>
</html>

<?php
		} // end if
	} else {
		print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
	} // end if
// end file answer_form.php
?>