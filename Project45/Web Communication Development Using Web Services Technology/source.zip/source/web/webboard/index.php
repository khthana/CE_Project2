<?php
// file index.php
	session_start();
	// webboard services
	require('services/get_question.php');		// use get_question - 	Get question from database
	require('services/post_question.php');		// use post_question - Post new question
	require('services/post_answer.php');		// use post_answer - Post answer
	// functions
	require("functions/thai.php");
	require("functions/censor.php");

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	// do webboard services
	$flag = true;
	if(isset($action)) {
		// get time
		setlocale(LC_TIME, "th");
		$day = date("j");							// �ѹ���
		$months = date("m") - 1;				// �������͹����ѡ�Ժ
		$month = $ThaiShortMonth[$months];
		$year = strftime("%Y") + 543;		// �� �.�.
		$time = date("H:i");						// ����

		$timeInMinute = date("j") * 1440;															// �ѹ
		$timeInMinute = $timeInMinute + (strftime("%m") * 44640);						// ��͹
		$timeInMinute = $timeInMinute + ((strftime("%Y") + 543) * 535680);			// ��
		$timeInMinute = $timeInMinute + (date("H") * 60);									// �������
		$timeInMinute = $timeInMinute + date("i");												// �ҷ�

		$ip = $ip . " -->" . gethostbyaddr($ip);

		switch($action) {
			case "post_question" :		// Post question
				// check every variable must be set
				if((isset($q_topic)) && (isset($q_message)) && (isset($q_username)) && (isset($q_passhash)) && (isset($q_name)) && (isset($q_email))) {
					// delete whitespace
					$topic = trim($q_topic);
					$message = trim($q_message);
					$username = trim($q_username);
					$passhash = trim($q_passhash);
					$name = trim($q_name);
					$topic = eregi_replace(" ", "", $topic);
					$message = eregi_replace(" ", "", $message);
					$username = eregi_replace(" ", "", $username);
					$passhash = eregi_replace(" ", "", $passhash);
					$name = eregi_replace(" ", "", $name);
					if(isset($q_alert) && $q_alert == "y") {
						$q_alert = "y";
					} else {
						$q_alert = "n";
					} // end if


					if(($topic == "") || ($message == "")) {
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
						print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
						$flag = false;
					} else {
						// check string in variable
						$q_topic = htmlspecialchars($q_topic);
						$q_message = htmlspecialchars($q_message);
						$q_topic = censor($q_topic);
						$q_message = censor($q_message);
						$q_message = nl2br($q_message);

						// put images to message
						$txt = array(":smile:", ":sad:", ":red:", ":big:", ":ent:", ":shy:", ":sleepy:", ":sun:", ":sg:", ":embarass:", ":dead:", ":cool:", ":clown:", ":pukey:", ":eek:", ":roll:", ":smoke:", ":angry:", ":confused:", ":cry:", ":lol:", ":yawn:", ":devil:", ":tongue:", ":alien:", ":tasty:", ":crazy:");
						$pic = array("smile.gif", "frown.gif", "redface.gif", "biggrin.gif", "blue.gif", "shy.gif", "sleepy.gif", "sunglasses.gif", "supergrin.gif", "embarass.gif", "dead.gif", "cool.gif", "clown.gif", "pukey.gif", "eek.gif", "sarcblink.gif", "smokin.gif", "reallymad.gif", "confused.gif", "crying.gif", "lol.gif", "yawn.gif", "devil.gif", "tongue.gif", "aysmile.gif", "tasty.gif", "crazy.gif");
						for ($a = 0; $a < sizeof($txt); $a++) {
							$q_message = eregi_replace($txt[$a], "<img src=\"pics/$pic[$a]\">", $q_message);
						} // end for

						// ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
						$q_message = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])", "<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>", $q_message);
						$q_message = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>", $q_message);
						$q_message = preg_replace('#\[b](.+?)\[/b]#is', '<b>\\1</b>', $q_message);
						$q_message = preg_replace('#\[i](.+?)\[/i]#is', '<i>\\1</i>', $q_message);
						$q_message = preg_replace('#\[u](.+?)\[/u]#is', '<u>\\1</u>', $q_message);

						$q_ip = $ip;
						$q_date = "$day $month $year";
						$q_time = $time;
						$q_update = $timeInMinute;
						$q_reng = "0";

						if(($name == "")) {
							if(($username == "") && ($passhash == "")) {
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
								print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
								$flag = false;
							} else {
								// check string in variable
								$q_username = htmlspecialchars($q_username);
								$q_passhash = htmlspecialchars($q_passhash);
								$q_username = censor($q_username);
								$q_passhash = censor($q_passhash);

								$result = post_question($q_topic, $q_message, $q_username, $q_passhash, "", "", $q_ip, $q_date, $q_time, $q_update, $q_reng, $q_alert);
							} // end if
						} else {
							// check string in variable
							$q_name = htmlspecialchars($q_name);
							$q_email = htmlspecialchars($q_email);
							$q_name = censor($q_name);
							$q_email = censor($q_email);

							if($q_email == "") {
								$result = post_question($q_topic, $q_message, "", "", $q_name, "", $q_ip, $q_date, $q_time, $q_update, $q_reng, $q_alert);
							} else {
								if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]]+)(\.([[:alnum:]]+)+)", $q_email)) {
									$result = post_question($q_topic, $q_message, "", "", $q_name, $q_email, $q_ip, $q_date, $q_time, $q_update, $q_reng, $q_alert);
								} else {
									print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������١��ͧ</font></div>";
									print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��سҡ�͡������ͧ��ҹ����</font></div>";
									print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
									$flag = false;
								} // end if
							} // end if
						} // end if
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
			case "post_answer" :		// Post answer
				// check every variable must be set
				if((isset($q_id)) && (isset($a_message)) && (isset($a_username)) && (isset($a_passhash)) && (isset($a_name))) {
					$question = get_question($q_id);
					if(is_array($question)) {
						$num_row = count($question);
						// delete whitespace
						$message = trim($a_message);
						$username = trim($a_username);
						$passhash = trim($a_passhash);
						$name = trim($a_name);
						$message = eregi_replace(" ", "", $message);
						$username = eregi_replace(" ", "", $username);
						$passhash = eregi_replace(" ", "", $passhash);
						$name = eregi_replace(" ", "", $name);
						if(isset($a_alert) && ($a_alert == "y")) {
							$a_alert = "y";
						} else {
							$a_alert = "n";
						} // end if

						if(($message == "") || ($num_row == 0)) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} else {
							$q_topic = $question['q_topic'];
							$q_message = $question['q_message'];
							$q_name = $question['q_name'];
							$q_email = $question['q_email'];
							$q_update = $question['q_update'];
						} // end while

						// check string in variable
						$a_message = htmlspecialchars($a_message);
						$a_message = censor($a_message);
						$a_message = nl2br($a_message);

						// put images to message
						$txt = array(":smile:", ":sad:", ":red:", ":big:", ":ent:", ":shy:", ":sleepy:", ":sun:", ":sg:", ":embarass:", ":dead:", ":cool:", ":clown:", ":pukey:", ":eek:", ":roll:", ":smoke:", ":angry:", ":confused:", ":cry:", ":lol:", ":yawn:", ":devil:", ":tongue:", ":alien:", ":tasty:", ":crazy:");
						$pic = array("smile.gif","frown.gif","redface.gif","biggrin.gif","blue.gif","shy.gif","sleepy.gif","sunglasses.gif","supergrin.gif","embarass.gif","dead.gif","cool.gif","clown.gif","pukey.gif","eek.gif","sarcblink.gif","smokin.gif","reallymad.gif","confused.gif","crying.gif","lol.gif","yawn.gif","devil.gif","tongue.gif","aysmile.gif","tasty.gif","grazy.gif");
						for ($a = 0; $a < sizeof($txt); $a++) {
							$a_message = eregi_replace($txt[$a], "<img src=\"pics/$pic[$a]\">", $a_message);
						} // end for

						// ��Ǩ�ͺ��� �ա�û�͹ url ���� email ��������� ��������� link
						$a_message = eregi_replace("([[:alnum:]]+)://([^[:space:]]*)([[:alnum:]#?/&=])", "<a href=\"\\1://\\2\\3\" target=\"\\2\\3\">\\1://\\2\\3</a>", $a_message);
						$a_message = eregi_replace("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]])","<a href=mailto:\\1@\\2\\3>\\1@\\2\\3</a>", $a_message);
						$a_message = preg_replace('#\[b](.+?)\[/b]#is', '<b>\\1</b>', $a_message);
						$a_message = preg_replace('#\[i](.+?)\[/i]#is', '<i>\\1</i>', $a_message);
						$a_message = preg_replace('#\[u](.+?)\[/u]#is', '<u>\\1</u>', $a_message);

						$a_ip = $ip;
						$a_date = "$day $month $year ���� $time";
						$q_update = $timeInMinute;

						if(($name == "")) {
							if(($username == "") || ($passhash == "")) {
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
								print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
								$flag = false;
							} else {
								// check string in variable
								$a_username = htmlspecialchars($a_username);
								$a_passhash = htmlspecialchars($a_passhash);
								$a_username = censor($a_username);
								$a_passhash = censor($a_passhash);

								$result = post_answer($q_id, $a_message, $a_username, $a_passhash, "", "", $a_ip, $a_date, $q_update, $a_alert);
							} // end if
						} else {
							// check string in variable
							$a_name = htmlspecialchars($a_name);
							$a_email = htmlspecialchars($a_email);
							$a_name = censor($a_name);
							$a_email = censor($a_email);

							if($a_email == "") {
								$result = post_answer($q_id, $a_message, "", "", $a_name, "", $a_ip, $a_date, $q_update, $a_alert);
							} else {
								if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]]+)(\.([[:alnum:]]+)+)", $a_email)) {
									$result = post_answer($q_id, $a_message, "", "", $a_name, $a_email, $a_ip, $a_date, $q_update, $a_alert);
								} else {
									print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������١��ͧ</font></div>";
									print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��سҡ�͡������ͧ��ҹ����</font></div>";
									print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
									$flag = false;
								} // end if
							} // end if
						} // end if
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
		} // end case
	} // end if

	if($flag == true) {
		if(isset($action)) {
			if(($action == "post_question") || ($action == "post_answer")) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>
<?php
				if($action == "post_question") echo "��駡�з������";
				elseif($action == "post_answer") echo "�ͺ��з��";
?>
		</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#000080; text-decoration:none }
			a:visited {	color:#000080; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table bgcolor="#F5F5F5" width="600" border="1" bordercolor="#F5F5F5" align="center" cellspacing="0">
			<tr><td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td height="10" width="30%">&nbsp;</td>
					</tr>
				</table>
			</td></tr>
			<tr height="30"><td bgcolor="#3366FF" align="center">
				<font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#FFFFFF" size="3"><b><?php echo $result; ?></b></font>
			</td></tr>
		</table>
	</body>
</html>

<?php
			} // end if
			if($action == "post_answer") {
				print "<meta http-equiv=\"refresh\" content=\"1; URL=answer_form.php?q_id=$q_id\" />";
			} // end if
		} // end if
		print "<meta http-equiv=\"refresh\" content=\"1; URL=showalltopics.php\" />";
	} // end if
// end file index.php
?>