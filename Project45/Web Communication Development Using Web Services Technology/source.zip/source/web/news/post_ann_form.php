<?php
// file post_ann_form.php
	session_start();
	// passport services
	require('../passport/services/validate.php');			// use validate - Validate current user
	require('../passport/services/get_profile.php');		// use get_profile - Get profile from database
	// functions
	require('functions/thaidate.php');

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
		$profile = get_profile($_SESSION['username']);
		$position = $profile['position'];
		$date_ann = time();
		$date_exp = $date_ann + (14 * 86400);		// date expired by default | note --->86400 sec = 1 day
		$date_last_ann = date(('d/m/Y'), $date_exp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>������С������</title>
		<meta http-equiv="content-type" content="text/html;charset=tis-620" />
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<form name="post" action="index.php" method="POST" enctype="multipart/form-data" onsubmit="return check()" autocomplete="off">
			<table border="1" cellpadding="2" cellspacing="2">
				<tbody>
					<tr bgcolor="#C0C0C0" valign="center">
						<td>
							<input type="submit" name="action" value="post" />
						</td>
						<td>
							<input type="reset" name="clear" value="clear" />
						</td>
					</tr>
				</tbody>
			</table>
			<hr>
			<img src="images/note.gif" width="65" height="39" align="middle" />
			<font face="MS Sans Serif" color="#0000FF">��С�ȶ֧ </font>
			<b><font face="MS Sans Serif" color="#0000FF">
				<select name="postto">

<?php
	if(($position == "lecturer") || $position == "authority") { print "<option value=\"0\">�ء��</option>"; }
	if(($position == "lecturer") || ($position == "1P")) { print "<option value=\"1\">1P</option>"; }
	if(($position == "lecturer") || ($position == "2P")) { print "<option value=\"2\">2P</option>"; }
	if(($position == "lecturer") || ($position == "3P")) { print "<option value=\"3\">3P</option>"; }
	if(($position == "lecturer") || ($position == "2D")) { print "<option value=\"4\">2D</option>"; }
	if(($position == "lecturer") || ($position == "3D")) { print "<option value=\"5\">3D</option>"; }
	if(($position == "lecturer") || ($position == "4D")) { print "<option value=\"6\">4D</option>"; }
?>

				</select>
			</font></b>
			<font face="MS Sans Serif" color="#0000FF">����ͧ </font>
			<b><font face="MS Sans Serif" color="#0000FF"><input type="text" name="title" size="55" /></font></b>
			<font face="MS Sans Serif" color="#0000FF">��С��������ѹ��� <?php  echo thaidate(time());  ?></font>
			<br /><br />
			<font face="MS Sans Serif" color="#0000FF">��С�ȶ֧�ѹ��� </font>
			<font face="MS Sans Serif" color="#FF0000">
				<input type="text" name="date_expired" value="<?php echo $date_last_ann; ?>" />
			</font>
			<font face="MS Sans Serif" color="#0000FF"> [dd/mm/yyyy (�.�.)] </font>
			<font face="MS Sans Serif" color="#FF0000">* �ѹ�ش���·�������С�ȹ������˹���á</font><br />
			<p />
			<font face="MS Sans Serif"><textarea name="content" rows="15" cols="100"></textarea></font>
			<font color="#FF0000">*</font>
			<div align="right">
				<img src="images/write.gif" width="32" height="32" align="middle" />
				<font face="MS Sans Serif" color="#0060A0" size="2">����С�� </font>
				<font face="MS Sans Serif" color="#0060A0" size="2">

<?php
	if($position == "lecturer") {
		$postname = "�." . $profile['name'] . " " . $profile['surname'];
	} elseif($position == "authority") {
		$postname = "���˹�ҷ���Ҥ�Ԫ����ǡ�������������";
	} elseif($profile['sex'] == "m") {
		$postname =  "���" . $profile['name'] . " " . $profile['surname'];
	} else {
		$postname = "�ҧ���" . $profile['name'] . " " . $profile['surname'];
	} // end if
	echo $postname;
?>

				</font>
			</div>
			<br />
			<b><font color="#0060A0" size="2">Attach file ������� Download </font></b>
			<input type="file" name="upfile" maxlength="40" />
			<br />
			<br />
			<hr />
			<b>
				<font face="MS Sans Serif" color="#FF0000" size="2">TIP </font>
				<font face="MS Sans Serif" color="#006699" size="2">��������ͧ��س������������ҡ���Шз����˹���á�����§��</font>
			</b>
			<br />
			<b><font face="MS Sans Serif" color="#0060A0" size="2"><font color="#FF0000">TIP</font>��èѴ�ٻẺ�ͧ�͡��������§�� ����ѧ��� </font></b>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- ��鹺ѹ�Ѵ���� "&lt;br&gt;" ���� �� Enter</font></b></dd>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- ���˹�� "&lt;dd&gt;"</font></b></dd>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- � text plan &nbsp;���ö�ʴ��� HTML TAG ��� � �����ҧ����ó�</font></b></dd>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- ����ҡ��ͧ������� link ������ö�����¡����� link Ẻ &lt;a href=&quot;http://www.ce.kmitl.ac.th&quot;/&gt;ce&lt;/a&gt;</font></b></dd>
			<br />
			<input type="hidden" name="max_file_size" value="50*1024*1024" />		<!-- 50 Mbyte-->
			<?php echo "<input type=\"hidden\" name=\"postname\" value=\"$postname\" />"; ?>

		</form>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.post.title.value;
		var v2 = document.post.content.value;
		var v3 = document.post.date_expired.value;

		if (v1.length==0) {
			alert("��سһ�͹��������ͧ");
			document.post.title.focus();
			return false;
		} else if (v2.length==0) {
			alert("��سһ�͹��ͤ������л�С��");
			document.post.content.focus();
			return false;
		} else if (v3.length==0) {
			alert("��سһ�͹�ѹ�ش���·�������С�ȹ������˹���á");
			document.post.date_expired.focus();
			return false;
		} // end if
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
	} else {
		print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
	} // end if
// end file post_ann_form.php
?>