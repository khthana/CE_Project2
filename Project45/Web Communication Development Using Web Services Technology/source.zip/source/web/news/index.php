<?php
// file index.php
	session_start();
	// passport services
	require('../passport/services/validate.php');			// use validate - Validate current user
	// news services
	require('services/delete_ann.php');		// use delete_ann - Delete announce
	require('services/download.php');		// use download - Download file
	require('services/post_ann.php');			// use post_ann - Post new announce
	require('services/get_ann.php');			// use get_ann - Get announce from database
	require('services/edit_ann.php');			// use edit_ann - Edit announce

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	// do news services
	$flag = true;
	if(isset($action)) {
		switch($action) {
			case "post" :		// Post announce
				// must be signed in
				if(validate($ip)) {
					// check every variable must be set
					if((isset($postto)) && (isset($title)) && (isset($content)) && (isset($postname)) && (isset($date_expired)) && (isset($upfile))) {
						// day/month/year is expired
						$day_exp = "$date_expired[0]$date_expired[1]";
						$mon_exp = "$date_expired[3]$date_expired[4]";
						$year_exp = "$date_expired[6]$date_expired[7]$date_expired[8]$date_expired[9]";
						// day/month/year is posted
						$day_ann = date('d');
						$mon_ann = date('m');
						$year_ann = date('Y');
						// check date is expired
						if(!(checkdate($mon_exp, $day_exp, $year_exp))) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">�Դ��ͼԴ��Ҵ��к���û�С�Ȣ���</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">�ѹ����С���ѹ�ش�������������㹻�ԷԹ</font></div><br />";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						// check date is expired must later date is posted
						} elseif(($year_exp < $year_ann) || ((($mon_exp * 30) + $day_exp) < (($mon_ann * 30) + $day_ann))) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">�Դ��ͼԴ��Ҵ��к���û�С�Ȣ���</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">�ѹ����С���ѹ�ش���µ�ͧ<b>�ҡ����</b>�ѹ��� " . date("d/m/Y") . "</font></div><br />";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						// check every variable that is not null
						} elseif(($title == "") || ($content == "") || ($postname == "") || ($date_expired == "0")) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} else {
							// have upfile
							if($upfile != "") {
								$filename = $upfile_name;
							} else {
								$filename = "";
							} // end if
							// post announce
							$result = post_ann($postto, $title, $content, $postname, $date_expired, $filename, $upfile);
						} // end if
					} else {
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
						print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
						$flag = false;
					} // end if
				} else {
					print "<meta http-equiv=\"refresh\" content=\"0; URL=http://161.246.6.54/passport/signin_form.php?services=news/\" />";
				} // end if
				break;
			case "edit" :		// Edit announce
				// must be signed in
				if(validate($ip)) {
					// check every variable must be set
					if((isset($edit_topicid)) && (isset($edit_postto)) && (isset($edit_title)) && (isset($edit_content)) && (isset($edit_postname)) && (isset($edit_date_expired)) && (isset($edit_file_add))) {
						// day/month/year is expired
						$day_exp = "$edit_date_expired[0]$edit_date_expired[1]";
						$mon_exp = "$edit_date_expired[3]$edit_date_expired[4]";
						$year_exp = "$edit_date_expired[6]$edit_date_expired[7]$edit_date_expired[8]$edit_date_expired[9]";
						// day/month/year is posted
						$day_ann = date('d');
						$mon_ann = date('m');
						$year_ann = date('Y');
						// check date is expired
						if(!(checkdate($mon_exp, $day_exp, $year_exp))) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">�Դ��ͼԴ��Ҵ��к������䢻�С��</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">�ѹ����С���ѹ�ش�������������㹻�ԷԹ</font></div><br />";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						// check date is expired must later date is posted
						} elseif(($year_exp < $year_ann) || ((($mon_exp * 30) + $day_exp) < (($mon_ann * 30) + $day_ann))) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">�Դ��ͼԴ��Ҵ��к������䢻�С��</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">�ѹ����С���ѹ�ش���µ�ͧ<b>�ҡ����</b>�ѹ��� " . date("d/m/Y") . "</font></div><br />";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						// check every variable that is not null
						} elseif(($edit_title == "") || ($edit_content == "") || ($edit_postname == "") || ($edit_date_expired == "")) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} else {
							// have edit_fileadd
							if($edit_file_add != "") {
								$edit_filename = $edit_file_add_name;
							// no have edit_fileadd
							} else {
								$edit_filename = "";
							} // end if
							// edit announce and check flag
							$result = edit_ann($edit_topicid, $edit_postto, $edit_title, $edit_content, $edit_postname, $edit_date_expired, $edit_filename, $edit_file_add, $edit_delfile);
						} // end if
					} else {
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
						print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
						$flag = false;
					} // end if
				} else {
					print "<meta http-equiv=\"refresh\" content=\"0; URL=http://161.246.6.54/passport/signin_form.php?services=news/\" />";
				} // end if
				break;
			case "delete" :		// Delete announce
				// must be signed in
				if(validate($ip)) {
					// check every variable must be set
					if((isset($delete_topicid))) {
						// check every variable that is not null
						if($delete_topicid != "") {
							// delete announce and check flag
							$result = delete_ann($delete_topicid);
						} // end if
					} // end if
				} else {
					print "<meta http-equiv=\"refresh\" content=\"0; URL=http://161.246.6.54/passport/signin_form.php?services=news/\" />";
				} // end if
				break;
			case "download" :		// Download
				// check every variable must be set
				if(isset($fileid)) {
					// check every variable that is not null
					if($fileid != "") {
						$result = download($fileid);
						header($result['header']);
						readfile($result['downloadpath']);
						$flag = false;
					} // end if
				} // end if
				break;
		} // end case
	} // end if

	if($flag == true) {
		if(isset($action)) {
			if(($action == "post") || ($action == "edit")) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>
<?php
				if($action == "post") echo "��С�Ȣ�������";
				elseif($action == "edit") echo "��䢢���";
?>
		</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#000080; text-decoration:none }
			a:visited {	color:#000080; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table bgcolor="#F5F5F5" width="600" border="1" bordercolor="#F5F5F5" align="center" cellspacing="0">
			<tr><td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td height="10" width="30%">&nbsp;</td>
					</tr>
				</table>
			</td></tr>
			<tr height="30"><td bgcolor="#3366FF" align="center">
				<font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#FFFFFF" size="3"><b><?php echo $result; ?></b></font>
			</td></tr>
		</table>
	</body>
</html>

<?php
			} // end if
			if($action == "edit") {
				print "<meta http-equiv=\"refresh\" content=\"1; URL=view.php?topicid=$edit_topicid\" />";
			} // end if
		} // end if
		print "<meta http-equiv=\"refresh\" content=\"1; URL=showalltopics.php\" />";
	} // end if
// end file index.php
?>