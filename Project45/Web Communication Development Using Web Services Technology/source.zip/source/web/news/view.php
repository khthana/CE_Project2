<?php
// file view.php
	session_start();
	// database services
	require('../database/services/retrieve_db.php');		// use retrieve_db - Retrieve data from database
	// passport services
	require('../passport/services/validate.php');			// use validate - Validate current user
	require('../passport/services/get_profile.php');		// use get_profile - Get profile from database
	// news services
	require('services/get_ann.php');		// use get_ann - Get announce from database
	// functions
	require('functions/thaidate.php');

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(isset($topicid)) {
		$announce = get_ann($topicid);
		if(is_array($announce)) {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>���ǻ�С�� <?php echo $announce['title'] . "-" . thaidate($announce['date_ann']); ?></title>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table border="1" cellpadding="2" cellspacing="2">
			<tbody>
				<tr bgcolor="#C0C0C0" valign="center">
					<td><a href="showalltopics.php">�ٻ�С�ȷ�����</a></td>

<?php
// ------------------------- If signed in ------------------------- //
			if(validate($ip)) {
				$profile = get_profile($_SESSION['username']);
				if(is_array($profile)) {
					$position = $profile['position'];
					if($position == "lecturer") {
						$postname = "�." . $profile['name'] . " " . $profile['surname'];
					} elseif($position == "authority") {
						$postname = "���˹�ҷ���Ҥ�Ԫ����ǡ�������������";
					} elseif($profile['sex'] == "m") {
						$postname =  "���" . $profile['name'] . " " . $profile['surname'];
					} else {
						$postname = "�ҧ���" . $profile['name'] . " " . $profile['surname'];
					} // end if
				} // end if

				if($postname == $announce['postname']) {
?>

					<td><a href="edit_ann_form.php?topicid=<?php echo $topicid; ?>" target="_self"><img src="images/edit.gif" width="21" height="21" border="0" />��䢻�С��</a></td>
					<td><a href="index.php?action=delete&delete_topicid=<?php echo $topicid; ?>" onclick="return check()"><img src="images/delete.gif" width="21" height="21" border="0">ź��С��</a></td>

<?php
				} // end if
			} // end if
// ------------------------- If signed in ------------------------- //
?>

				</tr>
			</tbody>
		</table>
		<hr /><br />
		<img src="images/note.gif" width="65" height="39" align="middle" />
		<font face="MS Sans Serif" color="#0000FF"><b>����ͧ</b></font>
		<font face="MS Sans Serif" color="#0000FF"><?php echo $announce["title"]; ?></font>
		<font face="MS Sans Serif" color="#0000FF" align="right">
			<b>&nbsp;��С������� �ѹ���&nbsp;</b><?php echo thaidate($announce['date_ann']); ?>
		</font>
		<p><dd>

<?php
			// for content
			$content = $announce['content'];
			$content = nl2br($content);
			echo $content;
?>

		</dd></p><br />
		<div align="right">
			<img src="images/write.gif" width="32" height="32" align="middle" />
			<font face="MS Sans Serif" color="#0060A0" size="2">����С�� <?php echo $announce['postname']; ?></font>
		</div>

<?php
		// file to download
		$file_sql = "SELECT fileid, filename FROM newsfileattach WHERE topicid =$topicid";
		$file_query = retrieve_db('webservices', $file_sql);
		if(is_array($file_query)) {
			$num_file = count($file_query);
			if($num_file > 0) {
				echo "<hr /><br />\n";
				echo "��ԡ���ʹ�ǹ���Ŵ���<br />\n";
				echo "<table><tbody><tr>";
				while(list($file_key, $file_val) = each($file_query)) {
					echo "<td align=\"middle\">";
					echo "<a href=\"index.php?action=download&fileid=" . $file_val['fileid'] . "\">";
					echo "<img src=\"images/fileatt.gif\" border=\"0\" /><br />" . $file_val['filename'] . "</a>";
					echo "</td>";
				} // end while
				echo "</tr></tbody></table>";
			} // end if
		} // end if
?>

		<script language="javascript">
<!--
	function check() {
		return window.confirm('Are you want to delete this announce?')
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
		} else {
			print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
		} // end if
	} else {
		print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
	} // end if
// end file view.php
?>