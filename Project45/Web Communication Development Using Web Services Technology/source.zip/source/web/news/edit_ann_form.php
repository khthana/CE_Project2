<?php
// file edit_ann_form.php
	session_start();
	// database services
	require('../database/services/retrieve_db.php');		// use retrieve_db - Retrieve data from database
	// passport services
	require('../passport/services/validate.php');			// use validate - Validate current user
	require('../passport/services/get_profile.php');		// use get_profile - Get profile from database
	// news services
	require('services/get_ann.php');		// use get_ann - Get announce from database
	// functions
	require('functions/thaidate.php');

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
		$profile = get_profile($_SESSION['username']);
		if(is_array($profile)) {
			$position = $profile['position'];
			if($position == "lecturer") {
				$postname = "�." . $profile['name'] . " " . $profile['surname'];
			} elseif($position == "authority") {
				$postname = "���˹�ҷ���Ҥ�Ԫ����ǡ�������������";
			} elseif($profile['sex'] == "m") {
				$postname =  "���" . $profile['name'] . " " . $profile['surname'];
			} else {
				$postname = "�ҧ���" . $profile['name'] . " " . $profile['surname'];
			} // end if
		} // end if

		if(isset($topicid)) {
			$announce = get_ann($topicid);
			if(is_array($announce)) {
				if($postname == $announce['postname']) {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>���ǻ�С�� <?php echo $announce['title'] . "-" . thaidate($announce['date_ann']); ?></title>
		<meta http-equiv="content-type" content="text/html; tis-620" />
	</head>
	<body bgcolor="#FFFFFF" text="#000000">
		<form name="edit" action="index.php" method="POST" enctype="multipart/form-data" onsubmit="return check()">
			<input type="hidden" name="edit_topicid"  value="<?php echo $topicid; ?>" />
			<input type="submit" name="action" value="edit" />
			<input type="reset" name="clear" value="clear" />
			<hr /><br />
			<img src="images/note.gif" width="65" height="39" align="middle" />
			<font face="MS Sans Serif" color="#0000FF">��С�ȶ֧ </font>
			<b><font face="MS Sans Serif" color="#0000FF">
				<select name="edit_postto">

<?php
	if(($position == "lecturer") || ($position == "authority")) { print "<option value=\"0\""; if($announce['postto'] == "�ء��") echo "selected"; print ">�ء��</option>"; }
	if(($position == "lecturer") || ($position == "1P")) { print "<option value=\"1\""; if($announce['postto'] == "1P") echo "selected"; print ">1P</option>"; }
	if(($position == "lecturer") || ($position == "2P")) { print "<option value=\"2\""; if($announce['postto'] == "2P") echo "selected"; print  ">2P</option>"; }
	if(($position == "lecturer") || ($position == "3P")) { print "<option value=\"3\""; if($announce['postto'] == "3P") echo "selected"; print  ">3P</option>"; }
	if(($position == "lecturer") || ($position == "2D")) { print "<option value=\"4\""; if($announce['postto'] == "2D") echo "selected"; print  ">2D</option>"; }
	if(($position == "lecturer") || ($position == "3D")) { print "<option value=\"5\""; if($announce['postto'] == "3D") echo "selected"; print  ">3D</option>"; }
	if(($position == "lecturer") || ($position == "4D")) { print "<option value=\"6\""; if($announce['postto'] == "4D") echo "selected"; print  ">4D</option>"; }
?>

				</select>
			</font></b>
			<font face="MS Sans Serif" color="#0000FF">����ͧ </font>
			<b><font face="MS Sans Serif" color="#0000FF"><input type="text" name="edit_title" size="55" value="<?php echo $announce['title']; ?>" /></font></b>
			<font face="MS Sans Serif" color="#0000FF">��С��������ѹ��� <?php echo thaidate($announce['date_ann']); ?></font>
			<br /><br />
			<font face="MS Sans Serif" color="#0000FF">��С�ȶ֧�ѹ��� </font>
			<input type="text" name="edit_date_expired" value="<?php $expired = date( ('d/m/Y'), $announce['date_expired']); echo $expired;?>" />
			<font face="MS Sans Serif" color="#FF0000"> [dd/mm/yyyy (�.�.)] </font>
			<font face="MS Sans Serif" color="#808080">* �ѹ�ش���·�������С�ȹ������˹���á</font><br />
			<p />
			<textarea name="edit_content" rows="15" cols="100"><?php echo $announce['content']; ?></textarea>
			<div align="right">
				<img src="images/write.gif" width="32" height="32" align="middle" />
				<font face="MS Sans Serif" color="#0060A0" size="2">����С�� </font>
				<font face="MS Sans Serif" color="#0060A0" size="2"><?php echo $announce['postname']; ?></font>
			</div>
			<br />
			<b><font color="#0060A0" size="2">Attach file ������� Download </font></b>
			<input type="file" name="edit_file_add" />
			<input type="hidden" name="max_file_size" value="50*1024*1024" />		<!-- 50 Mbyte-->
			<br /><br />

<?php
					$file_sql = "SELECT fileid, filename FROM newsfileattach WHERE topicid='$topicid'";
					$file_query = retrieve_db('webservices', $file_sql);
					if(is_array($file_query)) {
						$num_file = count($file_query);
						if($num_file > 0) {
							echo "<hr><b>Mark attachments for delete</b><br />\n";
							echo "<table border=\"1\"><tbody><tr>\n";
							$i = 1;
							while(list($file_key, $file_val) = each($file_query)) {
								echo "<td align=\"middle\">";
								echo "<label for=\"filelist" . $file_val['fileid'] . "\">";
								echo "<img src=\"images/fileatt.gif\" border=\"0\" /><br />";
								echo "<font size=\"-1\">" . $file_val['filename'] . " <br /></font>";
								echo "</label>";
								echo "<input type=\"checkbox\" name=\"edit_delfile[]\" value=\"" . $file_val['fileid'] . "\" id=\"filelist" . $file_val['fileid'] . "\">";
								echo "</td>\n";
								$i++;
							} // end while
							echo "</tr></tbody></table>";
						} // end if
					} // end if
?>

			<hr />
			<b>
				<font face="MS Sans Serif" color="#FF0000" size="2">TIP </font>
				<font face="MS Sans Serif" color="#006699" size="2">��������ͧ��س������������ҡ���Шз����˹���á�����§��</font>
			</b>
			<br />
			<b><font face="MS Sans Serif" color="#0060A0" size="2"><font color="#FF0000">TIP</font>��èѴ�ٻẺ�ͧ�͡��������§�� ����ѧ��� </font></b>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- ��鹺ѹ�Ѵ���� "&lt;br&gt;" ���� �� Enter</font></b></dd>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- ���˹�� "&lt;dd&gt;"</font></b></dd>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- � text plan &nbsp;���ö�ʴ��� HTML TAG ��� � �����ҧ����ó�</font></b></dd>
			<br />
			<dd><b><font face="MS Sans Serif" color="#0060A0" size="2">- ����ҡ��ͧ������� link ������ö�����¡����� link Ẻ &lt;a href=&quot;http://www.ce.kmitl.ac.th&quot;/&gt;ce&lt;/a&gt;</font></b></dd>
			<br />
			<input type="hidden" name="edit_postname" value="<?php echo $announce['postname']; ?>" />
		</form>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.edit.edit_title.value;
		var v2 = document.edit.edit_content.value;
		var v3 = document.edit.edit_date_expired.value;

		if (v1.length==0) {
			alert("��سһ�͹��������ͧ");
			document.edit.edit_title.focus();
			return false;
		} else if (v2.length==0) {
			alert("��سһ�͹��ͤ������л�С��");
			document.edit.edit_content.focus();
			return false;
		} else if (v3.length==0) {
			alert("��سһ�͹�ѹ�ش���·�������С�ȹ������˹���á");
			document.edit.edit_date_expired.focus();
			return false;
		}
	}
//-->
		</script>
	</body>
</html>

<?php
				} else {
					print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
				} // end if
			} else {
				print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
			} // end if
		} else {
			print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
		} // end if
	} else {
		print "<meta http-equiv=\"refresh\" content=\"0; URL=index.php\" />";
	} // end if
// end file edit_ann_form.php
?>