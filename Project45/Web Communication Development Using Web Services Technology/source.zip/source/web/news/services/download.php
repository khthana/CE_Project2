<?php
// file download.php
	##########################################################################
	# Function Name		: download
	# Function Purpose		: Download file from server
	# Recieves					: $fileid - fileid of download file
	# Returns					: download path if success, false otherwise
	##########################################################################
	function download($fileid) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('fileid'=>$fileid);
		$soapclient = new soapclient('http://161.246.6.54/services/news/download.php');		// create soap client
		$result = $soapclient->call('download', $parameters);		// call download services

		return $result;
	} // end function download
// end file download.php
?>