<?php
// file post_ann.php
	##########################################################################
	# Function Name		: post_ann
	# Function Purpose		: Post announce to database
	# Recieves					: $postto - user that post announce to of post announce
	#								  $title - title of post announce
	#								  $content - content of post announce
	#								  $postname - postname of post announce
	#								  $date_expired - date expired of post announce
	#								  $filename - file name that add of post announce
	#								  $upfile - temp file that add of post announce
	# Returns					: true if success, false otherwise
	##########################################################################
	function post_ann($postto, $title, $content, $postname, $date_expired, $filename, $upfile) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$posttos = array('0'=>'�ء��', '1'=>'1P', '2'=>'2P', '3'=>'3P', '4'=>'2D', '5'=>'3D', '6'=>'4D');
		$postto = $posttos[$postto];

		$parameters = array('postto'=>$postto, 'title'=>$title, 'content'=>$content, 'postname'=>$postname, 'date_expired'=>$date_expired, 'filename'=>$filename, 'upfile'=>$upfile);
		$soapclient = new soapclient('http://161.246.6.54/services/news/post_ann.php');		// create soap client
		$flag = $soapclient->call('post_ann', $parameters);		// call post_ann services

		return $flag;
	} // end function post_ann
// end file post_ann.php
?>