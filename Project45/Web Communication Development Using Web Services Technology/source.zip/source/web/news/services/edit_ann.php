<?php
// file edit_ann.php
	##########################################################################
	# Function Name		: edit_ann
	# Function Purpose		: Edit announce in database
	# Recieves					: $edit_topicid - topic id of edit announce
	#								  $edit_postto - user that post announce to of edit announce
	#								  $edit_title - title of edit announce
	#								  $edit_content - content of edit announce
	#								  $edit_postname - postname of edit announce
	#								  $edit_date_expired - date expired of edit announce
	#								  $edit_filename - file name that add of edit announce
	#								  $edit_file_add - temp file that add of edit announce
	#								  $edit_delfile - file that delete of edit announce
	# Returns					: true if success, false otherwise
	##########################################################################
	function edit_ann($edit_topicid, $edit_postto, $edit_title, $edit_content, $edit_postname, $edit_date_expired, $edit_filename, $edit_file_add, $edit_delfile) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$posttos = array('0'=>'�ء��', '1'=>'1P', '2'=>'2P', '3'=>'3P', '4'=>'2D', '5'=>'3D', '6'=>'4D');
		$edit_postto = $posttos[$edit_postto];

		$parameters = array('edit_topicid'=>$edit_topicid, 'edit_postto'=>$edit_postto, 'edit_title'=>$edit_title, 'edit_content'=>$edit_content, 'edit_postname'=>$edit_postname, 'edit_date_expired'=>$edit_date_expired, 'edit_filename'=>$edit_filename, 'edit_file_add'=>$edit_file_add, 'edit_delfile'=>$edit_delfile);
		$soapclient = new soapclient('http://161.246.6.54/services/news/edit_ann.php');		// create soap client
		$flag = $soapclient->call('edit_ann', $parameters);		// call edit_ann services

		return $flag;
	} // end function edit_ann
// end file edit_ann.php
?>