<?php
// file get_ann.php
	##########################################################################
	# Function Name		: get_ann
	# Function Purpose	 	: Return announce from database
	# Receive					: $topicid - topicid of announce
	# Return					: $announce if success, "" otherwise
	##########################################################################
	function get_ann($topicid) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('topicid'=>$topicid);
		$soapclient = new soapclient('http://161.246.6.54/services/news/get_ann.php');		// create soap client
		$result = $soapclient->call('get_ann', $parameters);		// call get_ann services

		return $result;
	} // end function get_ann
// end file get_ann.php
?>