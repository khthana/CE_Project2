<?php
// file delete_ann.php
	##########################################################################
	# Function Name		: delete_ann
	# Function Purpose		: Delete announce from database
	# Recieves					: $delete_topicid - topicid of delete announce
	# Returns					: true if success, false otherwise
	##########################################################################
	function delete_ann($delete_topicid) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('delete_topicid'=>$delete_topicid);
		$soapclient = new soapclient('http://161.246.6.54/services/news/delete_ann.php');		// create soap client
		$flag = $soapclient->call('delete_ann', $parameters);		// call delete_ann services

		return $flag;
	} // end function delete_ann
// end file delete_ann.php
?>