<?php
// file showalltopics.php
	session_start();
	// database services
	require('../database/services/retrieve_db.php');		// use retrieve_db - Retrieve data from database
	// passport services
	require('../passport/services/validate.php');			// use validate - Validate current user
	require('../passport/services/get_profile.php');		// use get_profile - Get profile from database

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
		$profile = get_profile($_SESSION['username']);
		if(is_array($profile)) {
			$position = $profile['position'];
			if($position == "lecturer") {
				$postname = "�." . $profile['name'] . " " . $profile['surname'];
			} elseif($position == "authority") {
				$postname = "���˹�ҷ���Ҥ�Ԫ����ǡ�������������";
			} elseif($profile['sex'] == "m") {
				$postname =  "���" . $profile['name'] . " " . $profile['surname'];
			} else {
				$postname = "�ҧ���" . $profile['name'] . " " . $profile['surname'];
			} // end if
		} // end if
	} // end if
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>��С�ȷ�����</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#2D2F25; text-decoration:none }
			a:visited {	color:#2D2F25; text-decoration:none }
			a:hover { color:blue; text-decoration:underline }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<div align="center">
			<table bgcolor="#F5F5F5" width="754" border="0" cellpadding="0" cellspacing="0">
				<tr>
<?php
	if(validate($ip)) {
?>
					<td bgcolor="#F5F5F5" align="center"><a href="../index.php"><font color="#2D2F25" size="3">˹���á</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/change_pwd_form.php?services=news/"><font color="#2D2F25" size="3">����¹���ʼ�ҹ</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/view_profile.php"><font color="#2D2F25" size="3">�ʴ���������ǹ���</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/edit_profile_form.php"><font color="#2D2F25" size="3">��䢢�������ǹ���</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/del_profile_form.php"><font color="#2D2F25" size="3">ź��������ǹ���</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/index.php?passport=�͡�ҡ�к�&services=news/"><font color="#2D2F25" size="3">�͡�ҡ�к�</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td>
<?php
	} else {
?>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td>
					<td bgcolor="#F5F5F5" align="center"><a href="../index.php"><font color="#2D2F25" size="3">˹���á</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/register_form.php?services=news/"><font color="#2D2F25" size="3">ŧ����¹���������</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/signin_form.php?services=news/"><font color="#2D2F25" size="3">�������к�</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3">|</td>
					<td bgcolor="#F5F5F5" align="center"><a href="../passport/forget_pwd_form.php"><font color="#2D2F25" size="3">������ʼ�ҹ</font></a></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td>
<?php
	} // end if
?>
				</tr>
				<tr>
					<td bgcolor="#F5F5F5" align="center"><font color = "#2D2F25">&nbsp;</td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color = "#2D2F25">&nbsp;</td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color = "#2D2F25">&nbsp;</td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color = "#2D2F25">&nbsp;</td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color = "#6699ff">&nbsp;</td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color = "#2D2F25">&nbsp;</td><td bgcolor="#F5F5F5"></td>
					<td bgcolor="#F5F5F5" align="center"><font color="#2D2F25" size="3"></td><td bgcolor="#F5F5F5"></td>
				</tr>
			</table>

<?php
// ------------------------- If signed in ------------------------- //
	if(validate($ip)) {
?>

			<table width="754" border="0" cellspacing="1" cellpadding="0">
				<tr bgcolor="#F5F5F5" valign="middle">
					<td width="122"><a href="post_ann_form.php" target="_self"><img src="images/add.gif" width="22" height="25" border="0" /><img src="images/post.gif" width="100" height="25" border="0" /></a></td>
					<td bgcolor="#F5F5F5" width="622"></td>
				</tr>
			</table>

<?php
	} // end if
// ------------------------- If signed in ------------------------- //
?>

			<table bgcolor="#F5F5F5" width="754" border="0" cellpadding="0" cellspacing="1">
				<tr>
					<td bgcolor="#BEBBAB" width="19" height="16"><img src="images/announce.gif" width="21" height="21" /></td>
					<td bgcolor="#BEBBAB" width="112" height="16">
						<div align="center"><font face="MS Sans Serif" size="2">�ѹ����С��</font></div>
					</td>
					<td bgcolor="#BEBBAB" width="619" height="16">
						<div align="center"><font face="MS Sans Serif" color="#000000" size="2">����ͧ</font></div>
					</td>
				</tr>

<?php
	$date_current = time();
	if(validate($ip)) {
		$topic_sql = "SELECT * FROM newstopic WHERE (postto='�ء��' OR postto='$position' OR postname='$postname')";
	} else {
		// retrieve all topics from datebase
		$topic_sql = "SELECT * FROM newstopic WHERE postto='�ء��'";
	} // end if
	$topic_query = retrieve_db('webservices', $topic_sql);
	if(is_array($topic_query)) {
		$num_rows = count($topic_query);
	} else {
		$num_rows = 0;
	} // end if
	$remain = $num_rows % 30;
	if($remain >= 15) {			// garantee remain >= 50% of page display
		$totalpage = round($num_rows / 30);
	} else {
		$totalpage = round($num_rows / 30) + 1;
	} // end if
	if(!isset($current)) {
		$current = 0;
		$page = 1;
	} // end if
	switch($page) {
		case "˹���á" :
			$current = 0;
			$page = 1;
			break;
		case "˹�ҷ������" :
			$page = ($current - 1 <= 0)?1:$current - 1;
			break;
		case "˹�ҵ���" :
			$page = ($current + 1 >= $totalpage)?$totalpage:$current + 1;
			break;
		case "˹���ش����" :
			$page = $totalpage;
			break;
	} // end case
	$goto = ($page - 1) * 30;
	if(validate($ip)) {
		$topic_sql = "SELECT title, date_ann, topicid FROM newstopic WHERE ((postto='�ء��' OR postto='$position' OR postname='$postname') AND del='n') ORDER BY topicid DESC LIMIT $goto, 30";
	} else {
		$topic_sql = "SELECT title, date_ann, topicid FROM newstopic WHERE (postto='�ء��' AND del='n') ORDER BY topicid DESC LIMIT $goto, 30";
	} // end if
	$topic_query = retrieve_db('webservices', $topic_sql);
	if(is_array($topic_query)) {
		while(list($topic_key, $topic_val) = each($topic_query)) {
			$d_ann = $topic_val['date_ann'];
			$date_announce = date(('d/m/Y'), $d_ann);
			echo"<tr>\n";
			$d_ann = $d_ann + (3 * 86400);			// 86400  is one day

			if($d_ann >= $date_current) {
				echo "<td width=\"0\" bgcolor=\"#FFFFFF\">";
				echo "<img src=\"images/ann_new.gif\" width=\"13\" height=\"11\" border=\"0\" /></td>\n";
			} else {
				echo "<td width=\"0\" bgcolor=\"#FFFFFF\">";
				echo "<img src=\"images/ann_old.gif\" width=\"13\" height=\"11\" border=\"0\" /></td>\n";
			} // end if

			echo "<td bgcolor=\"#FFFFFF\" width=\"100\"><font face=\"MS Sans Serif\" color=\"red\" size=\"2\"><center>$date_announce</center></font></td>\n";
			echo "<td bgcolor=\"#FFFFFF\" width=\"588\">";
			echo "<font face=\"MS Sans Serif\" size=\"1\"><a href=\"view.php?topicid=" . $topic_val['topicid'] . "\">" . $topic_val['title'] . "</a></font></td>\n";
			echo "</tr>\n";
		} // end while
	} // end if
  ?>

			</table>
			<form action="showalltopics.php" method="POST">
				<input type="hidden" name="current" value="<?php echo $page; ?>" />
				<table width="754" height="13" cellpadding="0" cellspacing="1">
					<tr>
						<td align="right" colspan="7"><font align="left" face="MS Sans Serif" color="red" size="1">˹�ҷ��:<font color="black">
						<?php echo $page, " / ", $totalpage; ?></font></font>
						</td>
					</tr>
					<tr>
						<td width="9%" height="20">
							<input type="submit" name="page" value="˹���á" />
						</td>
						<td width="34%" height="20"></td>
						<td width="7%" height="20">
							<input type="submit" name="page" value="˹�ҷ������" />
						</td>
						<td height="20">&nbsp;</td>
						<td width="9%" height="20">
							<input type="submit" name="page" value="˹�ҵ���" />
						</td>
						<td width="31%" height="20"></td>
						<td width="10%" height="20">
							<input type="submit" name="page" value="˹���ش����" />
						</td>
					</tr>
				</table>
			</form>
		</div>
	</body>
</html>

<?php
// end file showalltopics.php
?>