var marqueewidth = 160
var marqueeheight = 30
var speed = 1
var marqueecontents = '<center><font face="MS Sans Serif, EucrosiaUPC" color="#FF6633" size="1">�͵�͹�Ѻ��ҹ������<br />�Ҥ�Ԫ���ȡ�������������<br />ʶҺѹ෤����վ�Ш������<br />��Ҥس�����Ҵ��кѧ<br /></font></center>'
if(document.all) document.write('<marquee direction="up" scrollAmount=' + speed + ' style="width:' + marqueewidth + ';height:' + marqueeheight + '">' + marqueecontents + '</marquee>')
function regenerate() {
	window.location.reload()
} // end function
function regenerate2() {
	if(document.layers) {
		setTimeout("window.onresize=regenerate", 450)
		intializemarquee()
	} // end if
} // end function
function intializemarquee() {
	document.cmarquee01.document.cmarquee02.document.write(marqueecontents)
	document.cmarquee01.document.cmarquee02.document.close()
	thelength = document.cmarquee01.document.cmarquee02.document.height
	scrollit()
} // end function
function scrollit() {
	if(document.cmarquee01.document.cmarquee02.top >= thelength*(-1)) {
		document.cmarquee01.document.cmarquee02.top -= speed
		setTimeout("scrollit()", 100)
	} else {
		document.cmarquee01.document.cmarquee02.top=marqueeheight
		scrollit()
	} // end if
} // end function
window.onload = regenerate2