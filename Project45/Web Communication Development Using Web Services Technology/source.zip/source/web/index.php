<?php
// file index.php
	session_start();
	// database services
	require('database/services/retrieve_db.php');		// use retrieve_db - Retrieve data from database
	// passport services
	require('passport/services/validate.php');		// use validate - Validate current user

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
?>

<html>
	<head>
		<title>�Ҥ�Ԫ����ǡ�������������</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#3333FF; text-decoration:none }
			a:visited {	color:#3333FF; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
		<script language="javascript" src='script/copyerror.js'></script>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<form>
			<center>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tbody>
						<tr valign="top"><td width="939" colspan="2">
							<div align="center">
								<img src="images/CElogo.gif" width="590" height="100" border="0" />
							</div>
						</td></tr>
						<tr><td colspan="2">
							<table width="100%" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td height="10" width="30%">&nbsp;</td>
								</tr>
							</table>
						</td></tr>
						<tr valign="top">
							<td width="160">
								<div align="center">
									<table width="100%" border="0" cellpadding="0" cellspacing="0">
										<tr><td><script language="javascript" src='script/showcredit.js'></script></td><td></td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
<?php
	if(validate($ip)) {
?>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/change_pwd_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>����¹���ʼ�ҹ</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/view_profile.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�ʴ���������ǹ���</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/edit_profile_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��䢢�������ǹ���</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/del_profile_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>ź��������ǹ���</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/index.php?passport=�͡�ҡ�к�"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�͡�ҡ�к�</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
<?php
	} else {
?>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/register_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>ŧ����¹���������</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/signin_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�������к�</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="passport/forget_pwd_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>������ʼ�ҹ</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
<?php
	} // end if
?>
										<tr><td width="100%">
											<img src="images/barrow.gif" />
											<a href="webboard/showalltopics.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��дҹ���-�ͺ</b></font></a>
										</td></tr>
										<tr><td width="100%">
											&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/line.gif" width="100" height="2" border="0" />
										</td></tr>
									</table>
								</div>
							</td>
							<td width="600">
								<div align="center">
									<a href="news/showalltopics.php">
										<font face="MS Sans Serif" color="#FF0000" size="3">��С��</font>
									</a><br />
									<hr align="center" width="70%" color="#666666" size="2" />
								</div>
								<table>
									<tbody>

<?php
//------------------------ Topics Display ------------------------//
	$date_cur = time();
	$topic_sql = "SELECT * FROM newstopic WHERE (postto='�ء��' AND del='n') AND (date_expired>=$date_cur) ORDER BY  topicid DESC";
	$topic_query = retrieve_db('webservices', $topic_sql);
	if(is_array($topic_query)) {
		while(list($topic_key, $topic_val) = each($topic_query)) {
			echo "\t\t<tr>\n";
			echo "\t\t<td noWrap><img src=\"images/viewicon.gif\" width=\"13\" height =\"11\" border=\"0\" /></td>\n";
			echo "\t\t<td noWrap><font face=\"MS Sans Serif\" size=\"2\">\n";
			echo "\t\t<a href=\"news/view.php?topicid=" . $topic_val["topicid"] . "\" target=\"_blank\">" . $topic_val["title"] . "</a>";

			$date_ann = $topic_val['date_ann'] + (14 * 86400);
			if($date_ann > $date_cur) {
				echo"<img src=\"images/new.gif\" border=\"0\" />";
				echo"</a></td></tr>";
			} // end if
			echo "</font>\n\t\t</td></tr>\n";
		} // end while
	} // end if
//------------------------ Topics Display ------------------------//
?>

									</tbody>
								</table><br />
								<div align="right"><font face="MS Sans Serif" color="#000080" size="2"><a href="news/showalltopics.php">�ٻ�С�ȷ�����&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></font></div>
							</td>
						</tr>
					</tbody>
				</table>
			</center>
			<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
				<tbody>
					<tr>
						<td width="75%" align="middle" valign="center"><font face="Verdana, Arial" size="1">Department of Computer Engineering, Faculty of Engineering, King Mongkut's Institute of Technology Ladkrabang<br />Chalongkrung Road, Ladkrabang Bangkok 10520, Thailand.<br />Tel. +662-739-2400-1 Fax.+662-7392404<br />
						<img src="images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('passport/signin_form.php', '_top');" />
						</td>
					</tr>
				</tbody>
			</table>
		</form>
		<script language='javascript' src='script/clock.js'></script>
		<script language="javascript" src='script/showstatus.js'></script>
	</body>
</html>

<?php
// end file index.php
?>