<?php
// file sicq.php
	##########################################################################
	# Function Name		: sicq
	# Function Purpose	 	: Send message to icq
	# Recieves					: $uin - uin of icq that receive message
	#								  $from - name of user that send message
	#								  $email - email of user that send message
	#								  $msg - message that use for send
	# Returns					: true if success, false otherwise
	##########################################################################
	function sicq($uin, $from, $email, $msg) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('uin'=>$uin, 'from'=>$from, 'email'=>$email, 'msg'=>$msg);
		$soapclient = new soapclient('http://161.246.6.54/services/alert/sicq.php');		// create soap client
		$flag = $soapclient->call('sicq', $parameters);		// call sicq services

		return $flag;
	} // end function sicq
// end file sicq.php
?>