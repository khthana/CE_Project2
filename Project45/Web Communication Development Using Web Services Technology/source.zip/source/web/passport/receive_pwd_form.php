<?php
// file receive_pwd_form.php
	session_start();
	// passport services
	require('services/get_question.php');		// use get_question - Get question from database
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>�Ѻ���ʼ�ҹ</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#3333FF; text-decoration:none }
			a:visited {	color:#3333FF; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#EEFFFF" text="#000000">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr valign="top"><td width="939" colspan="2">
					<div align="center">
						<img src="../images/CElogo.gif" width="590" height="100" border="0" />
					</div>
				</td></tr>
				<tr><td colspan="2">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td height="10" width="30%">&nbsp;</td>
						</tr>
					</table>
				</td></tr>
				<tr valign="top">
					<td width="160">
						<div align="center">
							<table width="100%" border="0" cellpadding="0" cellspacing="0">
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../index.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>˹���á</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="register_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>ŧ����¹���������</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="signin_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�������к�</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../webboard/showalltopics.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��дҹ���-�ͺ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
							</table>
						</div>
					</td>
					<td width="600">
						<center>
							<form name="receivepass" action="index.php" method="POST" onsubmit="return check()">
								<table bgcolor="#BBDDFF" width="300" border="0" bordercolor="#3366FF" align="center" cellpadding="0" cellspacing="0">
									<tr height="30"><td bgcolor="#88AAFF" align="center" colspan="2">
										<font face="MS Sans Serif" color="#FFFFFF" size="3"><b>�Ѻ���ʼ�ҹ����ҧ������ͧ�Ҥ�Ԫ�</b></font>
									</td></tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�Ӷ�� :</b></font></td>
										<td><font face="MS Sans Serif" color="#000000" size="2"><?php echo get_question($id); ?></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�����Ѻ : </b></font></td>
										<td><input type="text" name="secret" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td align="center" colspan="2">
											<input type="submit" name="passport" value="�Ѻ���ʼ�ҹ" />
											<input type="reset" name="clear" value="¡��ԡ" />
										</td>
									</tr>
								</table>
								<input type="hidden" name="id" value="<?php echo $id; ?>" />
							</form>
						</center>
					</td>
				</tr>
			</tbody>
		</table>
		<div align="center">
			<font face="MS Sans Serif" color="#000080" size="2"><br />Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<br />Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404</font><br />
			<img src="../images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('signin_form.php', '_top');" />
		</div>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.receivepass.secret.value;

		if (v1.length==0) {
			alert("��سһ�͹�����Ѻ");
			document.receivepass.secret.focus();
			return false;
		} // end if
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
// end file receive_pwd_form.php
?>