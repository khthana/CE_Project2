<?php
// file signin_form.php
	session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>�������к�</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#3333FF; text-decoration:none }
			a:visited {	color:#3333FF; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr valign="top"><td width="939" colspan="2">
					<div align="center">
						<img src="../images/CElogo.gif" width="590" height="100" border="0" />
					</div>
				</td></tr>
				<tr><td colspan="2">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td height="10" width="30%">&nbsp;</td>
						</tr>
					</table>
				</td></tr>
				<tr valign="top">
					<td width="160">
						<div align="center">
							<table width="100%" border="0" cellpadding="0" cellspacing="0">
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../index.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>˹���á</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="register_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>ŧ����¹���������</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="forget_pwd_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>������ʼ�ҹ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../webboard/showalltopics.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��дҹ���-�ͺ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
							</table>
						</div>
					</td>
					<td width="600">
						<center>
							<form name="sign" action="index.php" method="POST" onsubmit="return check()">
								<table bgcolor="#AFC6DB" width="300" border="0" bordercolor="#3366FF" align="center" cellpadding="0" cellspacing="0">
									<tr height="30"><td bgcolor="#6E94B7" align="center" colspan="2">
										<font face="MS Sans Serif" color="#FFFFFF" size="3"><b>�������к�</b></font>
									</td></tr>
									<tr height="30">
										<td width="30%" align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ͼ���� : </b></font></td>
										<td width="70%">&nbsp;<input type="text" name="signin_username" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td width="30%" align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ʼ�ҹ : </b></font></td>
										<td width="70%">&nbsp;<input type="password" name="signin_password" size="20" maxlength="50" value="" /></td>
									</tr>
									<tr height="30">
										<td align="center" colspan="2">
											<input type="submit" name="passport" value="�������к�" />
											<input type="reset" name="clear" value="¡��ԡ" />
										</td>
									</tr>
								</table>

<?php
	if(isset($services)) {
		print "<input type=\"hidden\" name=\"services\" value=\"$services\" />";
	} // end if
?>

							</form>
						</center>
					</td>
				</tr>
			</tbody>
		</table>
		<div align="center">
			<font face="MS Sans Serif" color="#000080" size="2"><br />Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<br />Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404</font><br />
			<img src="../images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('signin_form.php', '_top');" /><br /><br /><br />
		</div>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.sign.signin_username.value;
		var v2 = document.sign.signin_password.value;

		if (v1.length==0) {
			alert("��سһ�͹���ͼ����");
			document.sign.signin_username.focus();
			return false;
		} else if (v2.length==0) {
			alert("��سһ�͹���ʼ�ҹ");
			document.sign.signin_password.focus();
			return false;
		} // end if
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
// end file signin_form.php
?>