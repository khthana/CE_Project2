<?php
// file edit_profile.php
	##########################################################################
	# Function Name		: edit_profile
	# Function Purpose		: Edit and keep the user's information into database
	# Receives					: $id - id of edit user
	#								  $edit_name - name of edit user
	#								  $edit_surname - surname of edit user
	#								  $edit_birthdate - birthdate of edit user
	#								  $edit_phone - phone number of edit user
	#								  $edit_mobile - mobile number of edit user
	#								  $edit_email - current email address of edit user
	#								  $edit_icq - icq number of edit user
	#								  $edit_username - username of edit user
	#								  $edit_password - password of edit user
	#								  $edit_question - question of edit user
	#								  $edit_secret - secret of edit user
	# Returns					: success text if success, error text otherwise
	##########################################################################
	function edit_profile($id, $edit_name, $edit_surname, $edit_day, $edit_month, $edit_year, $edit_phone, $edit_mobile, $edit_email, $edit_icq, $edit_username, $edit_password, $edit_question, $edit_secret) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$months = array('01'=>'���Ҥ�', '02'=>'����Ҿѹ��', '03'=>'�չҤ�', '04'=>'����¹', '05'=>'����Ҥ�', '06'=>'�Զع�¹', '07'=>'�á�Ҥ�', '08'=>'�ԧ�Ҥ�', '09'=>'�ѹ��¹', '10'=>'���Ҥ�', '11'=>'��Ȩԡ�¹', '12'=>'�ѹ�Ҥ�');
		$edit_birthdate = $edit_day . " " . $months[$edit_month] . " �.�." . $edit_year;

		$parameters = array('id'=>$id, 'edit_name'=>$edit_name, 'edit_surname'=>$edit_surname, 'edit_birthdate'=>$edit_birthdate, 'edit_phone'=>$edit_phone, 'edit_mobile'=>$edit_mobile, 'edit_email'=>$edit_email, 'edit_icq'=>$edit_icq, 'edit_username'=>$edit_username, 'edit_password'=>md5($edit_password), 'edit_question'=>$edit_question, 'edit_secret'=>$edit_secret);
		$soapclient = new soapclient('http://161.246.6.54/services/passport/edit_profile.php');		// create soap client
		$result = $soapclient->call('edit_profile', $parameters);		// call edit_profile services

		return $result;
	} // end function edit_profile
// end file edit_profile.php
?>