<?php
// file register.php
	##########################################################################
	# Function Name		: register
	# Function Purpose	 	: Register the user and keep the user's information into database
	# Receives					: $id - id of register user
	#								  $register_position - position of register user
	#								  $register_sex - sex of register user
	#								  $register_name - name of register user
	#								  $register_surname - surname of register user
	#								  $register_birthdate - birthdate of register user
	#								  $register_phone - phone number of register user
	#								  $register_mobile - mobile number of register user
	#								  $register_email - email address of register user
	#								  $register_icq - icq number of register user
	#								  $register_username - username of register user
	#								  $register_question - question of register user
	#								  $register_secret - secret of register user
	# Returns					: success text if success, error text otherwise
	##########################################################################
	function register($id, $register_position, $register_sex, $register_name, $register_surname, $register_day, $register_month, $register_year, $register_phone, $register_mobile, $register_email, $register_icq, $register_username, $register_question, $register_secret) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$positions = array('1'=>'1P', '2'=>'2P', '3'=>'3P', '4'=>'2D', '5'=>'3D', '6'=>'4D', '7'=>'lecturer', '8'=>'authority');
		$register_position = $positions[$register_position];

		$months = array('01'=>'���Ҥ�', '02'=>'����Ҿѹ��', '03'=>'�չҤ�', '04'=>'����¹', '05'=>'����Ҥ�', '06'=>'�Զع�¹', '07'=>'�á�Ҥ�', '08'=>'�ԧ�Ҥ�', '09'=>'�ѹ��¹', '10'=>'���Ҥ�', '11'=>'��Ȩԡ�¹', '12'=>'�ѹ�Ҥ�');
		$register_birthdate = $register_day . " " . $months[$register_month] . " �.�." . $register_year;

		$parameters = array('id'=>$id, 'register_position'=>$register_position, 'register_sex'=>$register_sex, 'register_name'=>$register_name, 'register_surname'=>$register_surname, 'register_birthdate'=>$register_birthdate, 'register_phone'=>$register_phone, 'register_mobile'=>$register_mobile, 'register_email'=>$register_email, 'register_icq'=>$register_icq, 'register_username'=>$register_username, 'register_question'=>$register_question, 'register_secret'=>$register_secret);
		$soapclient = new soapclient('http://161.246.6.54/services/passport/register.php');		// create soap client
		$result = $soapclient->call('register', $parameters);		// call register services

		return $result;
	} // end function register
// end file register.php
?>