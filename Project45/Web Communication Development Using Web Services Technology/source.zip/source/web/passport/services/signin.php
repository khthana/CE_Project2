<?php
// file signin.php
	##########################################################################
	# Function Name		: signin
	# Function Purpose	 	: Sign in the user and give the user's ticket
	# Receives					: $username - username of sign in user
	#								  $password - password of sign in user
	# Returns					: user's ticket if success, error text otherwise
	##########################################################################
	function signin($signin_username, $signin_password, $ip) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('signin_username'=>$signin_username, 'signin_password'=>md5($signin_password));
		$soapclient = new soapclient('http://161.246.6.54/services/passport/signin.php');		// create soap client
		$result = $soapclient->call('signin', $parameters);		// call signin services

		if(isset($result['username']) && isset($result['session_key']) && isset($result['expiration_time']) && isset($result['hash']) && isset($result['passhash'])) {
			$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
			$fp = fopen($filename, "w");
			fputs($fp, $result['username'] . "\n");
			fputs($fp, $result['session_key'] . "\n");
			fputs($fp, $result['expiration_time'] . "\n");
			fputs($fp, $result['hash'] . "\n");
			fputs($fp, $result['passhash']);
			fclose($fp);
		} // end if
		return $result;
	} // end function signin
// end file signin.php
?>