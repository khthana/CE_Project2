<?php
// file update_sess.php
	##########################################################################
	# Function Name		: update_sess
	# Function Purpose	 	: Update expiration time of current session
	# Recieves					: $ip - ip of client
	# Returns					: user's ticket if success, error text otherwise
	##########################################################################
	function update_sess($ip) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('username'=>"", 'session_key'=>"", 'expiration_time'=>"", 'hash'=>"", 'passhash'=>"");
		if(session_is_registered("username") && session_is_registered("session_key") && session_is_registered("expiration_time") && session_is_registered("hash") && session_is_registered("passhash")) {
			$parameters = array('username'=>$_SESSION['username'], 'session_key'=>$_SESSION['session_key'], 'expiration_time'=>$_SESSION['expiration_time'], 'hash'=>$_SESSION['hash'], 'passhash'=>$_SESSION['passhash']);
		} else {
			$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
			if(file_exists($filename)) {
				$fp = fopen($filename, "r");
				$username = fgets($fp);
				$session_key = fgets($fp);
				$expiration_time = fgets($fp);
				$hash = fgets($fp);
				$passhash = fgets($fp);
				fclose($fp);

				$username = trim($username);
				$session_key = trim($session_key);
				$expiration_time = trim($expiration_time);
				$hash = trim($hash);
				$passhash = trim($passhash);

				$parameters = array('username'=>$username, 'session_key'=>$session_key, 'expiration_time'=>$expiration_time, 'hash'=>$hash, 'passhash'=>$passhash);
			} // end if
		} // end if

		if(($parameters['username'] != "") && ($parameters['session_key'] != "") && ($parameters['expiration_time'] != "") && ($parameters['hash'] != "") && ($parameters['passhash'] != "")) {
			$soapclient = new soapclient('http://161.246.6.54/services/passport/update_sess.php');		// create soap client
			$auth = $soapclient->call('update_sess', $parameters);		// call validate services

			if(isset($auth['username']) && isset($auth['session_key']) && isset($auth['expiration_time']) && isset($auth['hash']) && isset($auth['passhash'])) {
				$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
				$fp = fopen($filename, "w");
				fputs($fp, $auth['username'] . "\n");
				fputs($fp, $auth['session_key'] . "\n");
				fputs($fp, $auth['expiration_time'] . "\n");
				fputs($fp, $auth['hash'] . "\n");
				fputs($fp, $auth['passhash']);
				fclose($fp);
			} // end if
			return $auth;
		} // end if
		$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
		if(file_exists($filename)) {
			unlink($filename);
		} // end if
		session_unset();
		session_destroy();
		return false;
	} // end function update_sess
// end file update_sess.php
?>