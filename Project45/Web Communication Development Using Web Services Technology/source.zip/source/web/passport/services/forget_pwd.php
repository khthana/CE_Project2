<?php
// file forget_pwd.php
	##########################################################################
	# Function Name		: forget_pwd
	# Function Purpose	 	: Keep new user's password into database and send it to user
	# Receives					: $id - id of forget password user
	#								  $secret - secret of forget password user
	# Returns					: success text if success, error text otherwise
	##########################################################################
	function forget_pwd($id, $secret) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('id'=>$id, 'secret'=>$secret);
		$soapclient = new soapclient('http://161.246.6.54/services/passport/forget_pwd.php');		// create soap client
		$result = $soapclient->call('forget_pwd', $parameters);		// call forget_pwd services

		return $result;
	} // end function forget_pwd
// end file forget_pwd.php
?>