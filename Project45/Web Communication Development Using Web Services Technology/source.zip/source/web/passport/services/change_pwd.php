<?php
// file change_pwd.php
	##########################################################################
	# Function Name		: change_pwd
	# Function Purpose	 	: Change password of the user
	# Receives					: $change_username - change_username of change password user
	#								  $old_password - old password of change password user
	#								  $new_password - new password of change password user
	# Returns					: success text if success, error text otherwise
	##########################################################################
	function change_pwd($change_username, $old_password, $new_password) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('change_username'=>$change_username, 'old_password'=>md5($old_password), 'new_password'=>md5($new_password));
		$soapclient = new soapclient('http://161.246.6.54/services/passport/change_pwd.php');		// create soap client
		$result = $soapclient->call('change_pwd', $parameters);		// call change_pwd services

		return $result;
	} // end function change_pwd
// end file change_pwd.php
?>