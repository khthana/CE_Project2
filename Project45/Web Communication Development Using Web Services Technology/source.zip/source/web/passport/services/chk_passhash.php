<?php
// file chk_passhash.php
	##########################################################################
	# Function Name		: chk_passhash
	# Function Purpose	 	: Check passhash and make sure that is validate
	# Receives					: $username - username of check passhash user
	#								  $passhash - passhash of check passhash user
	# Returns					: true if success, false otherwise
	##########################################################################
	function chk_passhash($username, $passhash) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('username'=>$username, 'passhash'=>$passhash);
		$soapclient = new soapclient('http://161.246.6.54/services/passport/chk_passhash.php');		// create soap client
		$flag = $soapclient->call('chk_passhash', $parameters);		// call chk_passhash services

		return $flag;
	} // end function chk_passhash
// end file chk_passhash.php
?>