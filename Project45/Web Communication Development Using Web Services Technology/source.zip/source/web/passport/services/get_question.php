<?php
// file get_question.php
	##########################################################################
	# Function Name		: get_question
	# Function Purpose	 	: Return question from database
	# Receive					: $id - id of user
	# Return					: $question if success, "" otherwise
	##########################################################################
	function get_question($id) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('id'=>$id);
		$soapclient = new soapclient('http://161.246.6.54/services/passport/get_question.php');		// create soap client
		$question = $soapclient->call('get_question', $parameters);		// call get_question services

		return $question;
	} // end function get_question
// end file get_question.php
?>