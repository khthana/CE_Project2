<?php
// file validate.php
	##########################################################################
	# Function Name		: validate
	# Function Purpose		: Validates the user's ticket and makes sure they are logged in
	# Recieves					: $ip - ip of client
	# Returns					: true if validated, false otherwise
	##########################################################################
	function validate($ip) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('username'=>"", 'session_key'=>"", 'expiration_time'=>"", 'hash'=>"", 'passhash'=>"");
		if(session_is_registered("username") && session_is_registered("session_key") && session_is_registered("expiration_time") && session_is_registered("hash") && session_is_registered("passhash")) {
			$parameters = array('username'=>$_SESSION['username'], 'session_key'=>$_SESSION['session_key'], 'expiration_time'=>$_SESSION['expiration_time'], 'hash'=>$_SESSION['hash'], 'passhash'=>$_SESSION['passhash']);
		} else {
			$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
			if(file_exists($filename)) {
				$fp = fopen($filename, "r");
				$username = fgets($fp);
				$session_key = fgets($fp);
				$expiration_time = fgets($fp);
				$hash = fgets($fp);
				$passhash = fgets($fp);
				fclose($fp);

				$username = trim($username);
				$session_key = trim($session_key);
				$expiration_time = trim($expiration_time);
				$hash = trim($hash);
				$passhash = trim($passhash);

				$parameters = array('username'=>$username, 'session_key'=>$session_key, 'expiration_time'=>$expiration_time, 'hash'=>$hash, 'passhash'=>$passhash);
			} // end if
		} // end if
		if(($parameters['username'] != "") && ($parameters['session_key'] != "") && ($parameters['expiration_time'] != "") && ($parameters['hash'] != "") && ($parameters['passhash'] != "")) {
			$soapclient = new soapclient('http://161.246.6.54/services/passport/validate.php');		// create soap client
			$flag = $soapclient->call('validate', $parameters);		// call validate services

			if($flag) {
				return $flag;
			} // end if
		} // end if
		$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
		if(file_exists($filename)) {
			unlink($filename);
		} // end if
		return false;
	} // end function validate
// end file validate.php
?>