<?php
// file del_profile.php
	##########################################################################
	# Function Name		: del_profile
	# Function Purpose		: Delete the user's information from database
	# Receives					: $id - id of delete user
	#								  $del_password - password of delete user
	# Returns					: success text if success, error text otherwise
	##########################################################################
	function del_profile($id, $del_password) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('id'=>$id, 'del_password'=>md5($del_password));
		$soapclient = new soapclient('http://161.246.6.54/services/passport/del_profile.php');		// create soap client
		$result = $soapclient->call('del_profile', $parameters);		// call del_profile services

		return $result;
	} // end function del_profile
// end file del_profile.php
?>