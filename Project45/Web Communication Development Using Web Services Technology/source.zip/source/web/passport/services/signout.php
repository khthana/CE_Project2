<?php
// file signout.php
	##########################################################################
	# Function Name		: signout
	# Function Purpose	 	: Sign out user and delete cookie
	# Recieves					: $ip - ip of client
	# Returns					: signout if success, do nothing otherwise
	##########################################################################
	function signout($ip) {
		$filename = "f:\\passport\\cookies\\" . $ip . ".txt";
		if(file_exists($filename)) {
			unlink($filename);
		} // end if
		session_unset();
		session_destroy();
	} // end function signout
// end file signout.php
?>