<?php
// file get_profile.php
	##########################################################################
	# Function Name		: get_profile
	# Function Purpose	 	: Return profile from database
	# Receive					: $username - username of user
	# Return					: $profile if success, "" otherwise
	##########################################################################
	function get_profile($username) {
		require_once('../../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('username'=>$username);
		$soapclient = new soapclient('http://161.246.6.54/services/passport/get_profile.php');		// create soap client
		$profile = $soapclient->call('get_profile', $parameters);		// call get_profile services

		return $profile;
	} // end function get_profile
// end file get_profile.php
?>