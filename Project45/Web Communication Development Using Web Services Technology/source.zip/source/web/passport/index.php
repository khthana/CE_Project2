<?php
// file index.php
	session_start();
	// passport services
	require('services/change_pwd.php');		// use change_pwd - Change password current user
	require('services/del_profile.php');			// use del_profile - Delete user's profile
	require('services/edit_profile.php');			// use edit_profile - Edit user's profile
	require('services/forget_pwd.php');			// use forget_pwd - Send new password
	require('services/register.php');				// use register - Register new user
	require('services/signin.php');					// use signin - Sign in current user
	require('services/signout.php');				// use signout - Sign out current user
	require('services/update_sess.php');		// use update_sess - Update current session
	require('services/validate.php');				// use validate - Validate current user

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	// update session
	$auth = update_sess($ip);
	if(isset($auth['username']) && isset($auth['session_key']) && isset($auth['expiration_time']) && isset($auth['hash']) && isset($auth['passhash'])) {
		$username = $auth['username'];
		$session_key = $auth['session_key'];
		$expiration_time = $auth['expiration_time'];
		$hash = $auth['hash'];
		$passhash = $auth['passhash'];
		session_register("username");
		session_register("session_key");
		session_register("expiration_time");
		session_register("hash");
		session_register("passhash");
	} // end if
	// do passport services
	$flag = true;
	if(isset($passport)) {
		switch($passport) {
			case "ŧ����¹" :		// Register
				// check every variable must be set
				if((isset($id)) && (isset($register_position)) && (isset($register_sex)) && (isset($register_name)) && (isset($register_surname)) && (isset($register_day)) && (isset($register_month)) && (isset($register_year)) && (isset($register_phone)) && (isset($register_mobile)) && (isset($register_email)) && (isset($register_icq)) && (isset($register_username)) && (isset($register_question)) && (isset($register_secret))) {
					// if signed in then sign out before register
					if(validate($ip)) {
						signout($ip);
					} // end if
					// check every variable that is not null
					if(($id == "") || ($register_position == "0") || ($register_sex == "") || ($register_name == "") || ($register_surname == "") || ($register_day == "0") || ($register_month == "0") || ($register_year == "") || ($register_email == "") || ($register_username == "") || ($register_question == "") || ($register_secret == "")) {
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
						print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
						$flag = false;
					} else {
						if(ereg("([0-9]{4})", $register_year)) {
							if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]]+)(\.([[:alnum:]]+)+)", $register_email)) {
								// register
								$result = register($id, $register_position, $register_sex, $register_name, $register_surname, $register_day, $register_month, $register_year, $register_phone, $register_mobile, $register_email, $register_icq, $register_username, $register_question, $register_secret);
							} else {
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������١��ͧ</font></div>";
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��سҡ�͡������ͧ��ҹ����</font></div>";
								print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
								$flag = false;
							} // end if
						} else {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������١��ͧ</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��سҡ�͡���Դ�������١��ͧ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} // end if
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
			case "�������к�" :		// Sign in
				// check every variable must be set
				if((isset($signin_username)) && (isset($signin_password))) {
					// if signed in then sign out before sign in new user
					if(validate($ip)) {
						signout($ip);
					} // end if
					// check every variable that is not null
					if(($signin_username == "") || ($signin_password == "")) {
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
						print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
						print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
						$flag = false;
					} else {
						// sign in
						$result = signin($signin_username, $signin_password, $ip);
						if(is_array($result)) {
							if(isset($result['username']) && isset($result['session_key']) && isset($result['expiration_time']) && isset($result['hash']) && isset($result['passhash'])) {
								$username = $result['username'];
								$session_key = $result['session_key'];
								$expiration_time = $result['expiration_time'];
								$hash = $result['hash'];
								$passhash = $result['passhash'];
								session_register("username");
								session_register("session_key");
								session_register("expiration_time");
								session_register("hash");
								session_register("passhash");
								$result = "�Թ�յ�͹�Ѻ��ҹ�������к���Ѻ";
							} // end if
						} // end if
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
			case "��䢢�����" :		// Edit Profile
				// check every variable must be set
				if((isset($id)) && (isset($edit_name)) && (isset($edit_surname)) && (isset($edit_day)) && (isset($edit_month)) && (isset($edit_year)) && (isset($edit_phone)) && (isset($edit_mobile)) && (isset($edit_email)) && (isset($edit_icq)) && (isset($edit_username)) && (isset($edit_password)) && (isset($edit_question)) && (isset($edit_secret))) {
					// if signed in then sign out before edit profile
					if(validate($ip)) {
						// check every variable that is not null
						if(($id == "") || ($edit_name == "") || ($edit_surname == "") || ($edit_day == "0") || ($edit_month == "0") || ($edit_year == "") || ($edit_email == "") || ($edit_username == "") || ($edit_password == "") || ($edit_question == "") || ($edit_secret == "")) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} else {
							if(ereg("([[:alnum:]]+)@([^[:space:]]*)([[:alnum:]]+)(\.([[:alnum:]]+)+)", $edit_email)) {
								// edit profile
								$result = edit_profile($id, $edit_name, $edit_surname, $edit_day, $edit_month, $edit_year, $edit_phone, $edit_mobile, $edit_email, $edit_icq, $edit_username, $edit_password, $edit_question, $edit_secret);
							} else {
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������١��ͧ</font></div>";
								print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��سҡ�͡������ͧ��ҹ����</font></div>";
								print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
								$flag = false;
							} // end if
						} // end if
					} else {
						print "<meta http-equiv=\"refresh\" content=\"0; URL=signin_form.php\" />";
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
			case "ź������" :		// Delete Profile
				// check every variable must be set
				if((isset($id)) && (isset($del_password))) {
					// if signed in then sign out before delete profile
					if(validate($ip)) {
						signout($ip);
						// check every variable that is not null
						if(($id == "") || ($del_password == "")) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} else {
							// delete profile
							$result = del_profile($id, $del_password);
						} // end if
					} else {
						print "<meta http-equiv=\"refresh\" content=\"0; URL=signin_form.php\" />";
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
			case "����¹���ʼ�ҹ" :		// Change password
				// check every variable must be set
				if((isset($change_username)) && (isset($old_password)) && (isset($new_password))) {
					// if signed in then sign out before change password
					if(validate($ip)) {
						signout($ip);
						// check every variable that is not null
						if(($change_username == "") || ($old_password == "") || ($new_password == "")) {
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
							print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"5\">��ҹ��ͧ��͡�����ŷ��������ͧ���� * ���ú��͹�Ф�Ѻ</font></div>";
							print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
							$flag = false;
						} else {
							// change password
							$result = change_pwd($change_username, $old_password, $new_password);
						} // end if
					} else {
						print "<meta http-equiv=\"refresh\" content=\"0; URL=signin_form.php\" />";
					} // end if
				} else {
					print "<div align=\"center\"><font face=\"MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep\" color=\"red\" size=\"7\">���������ú�������˹�</font></div>";
					print "<div align=\"center\"><input type=\"button\" value=\"<--back\" onclick=\"history.back();\"></div>";
					$flag = false;
				} // end if
				break;
			case "�Ѻ���ʼ�ҹ" :		// Send new password
				if(!validate($ip)) {
					// receive password
					$result = forget_pwd($id, $secret);
				} // end if
				break;
			case "�͡�ҡ�к�" :		// Sign out
				signout($ip);
				$result = "��ҹ���͡�ҡ�к����º�������Ǥ�Ѻ";
				break;
		} // end case
	} // end if

	if($flag == true) {
		if(isset($passport)) {
			if(($passport == "ŧ����¹") || ($passport == "�������к�") || ($passport == "��䢢�����") || ($passport == "ź������") || ($passport == "����¹���ʼ�ҹ") || ($passport == "�Ѻ���ʼ�ҹ") || ($passport == "�͡�ҡ�к�")) {
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>
<?php
				if($passport == "ŧ����¹") echo "ŧ����¹���������";
				elseif($passport == "�������к�") echo "�������к�";
				elseif($passport == "��䢢�����") echo "��䢢�������ǹ���";
				elseif($passport == "ź������") echo "ź��������ǹ���";
				elseif($passport == "����¹���ʼ�ҹ") echo "����¹���ʼ�ҹ";
				elseif($passport == "�Ѻ���ʼ�ҹ") echo "�����ʼ�ҹ";
				elseif($passport == "�͡�ҡ�к�") echo "�͡�ҡ�к�";
?>
		</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#000080; text-decoration:none }
			a:visited {	color:#000080; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table bgcolor="#F5F5F5" width="600" border="1" bordercolor="#F5F5F5" align="center" cellspacing="0">
			<tr><td>
				<table width="100%" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td height="10" width="30%">&nbsp;</td>
					</tr>
				</table>
			</td></tr>
			<tr height="30"><td bgcolor="#5A8CC6" align="center">
				<font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#FFFFFF" size="3"><b><?php echo $result; ?></b></font>
			</td></tr>
		</table>
	</body>
</html>

<?php
			} // end if
			if($passport == "��䢢�����") {
				print "<meta http-equiv=\"refresh\" content=\"2; URL=view_profile.php\" />";
			} // end if
			if(isset($services)) {
				if($services == "passport") {
					print "<meta http-equiv=\"refresh\" content=\"2; URL=view_profile.php\" />";
				} else {
					print "<meta http-equiv=\"refresh\" content=\"2; URL=../" . $services . "index.php\" />";
				} // end if
			} // end if
		} // end if
		print "<meta http-equiv=\"refresh\" content=\"2; URL=../index.php\" />";
	} // end if
// end file index.php
?>