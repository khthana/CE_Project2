<?php
// file change_pwd_form.php
	session_start();
	// passport services
	require('services/validate.php');				// use validate - Validate current user

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>����¹���ʼ�ҹ</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#3333FF; text-decoration:none }
			a:visited {	color:#3333FF; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr valign="top"><td width="939" colspan="2">
					<div align="center">
						<img src="../images/CElogo.gif" width="590" height="100" border="0" />
					</div>
				</td></tr>
				<tr><td colspan="2">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td height="10" width="30%">&nbsp;</td>
						</tr>
					</table>
				</td></tr>
				<tr valign="top">
					<td width="160">
						<div align="center">
							<table width="100%" border="0" cellpadding="0" cellspacing="0">
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../index.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>˹���á</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="view_profile.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�ʴ���������ǹ���</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="edit_profile_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��䢢�������ǹ���</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="del_profile_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>ź��������ǹ���</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="index.php?passport=�͡�ҡ�к�"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�͡�ҡ�к�</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../webboard/showalltopics.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��дҹ���-�ͺ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
							</table>
						</div>
					</td>
					<td width="600">
						<center>
							<form name="change" action="index.php" method="POST" onsubmit="return check()">
								<table bgcolor="#AFC6DB" width="400" border="0" bordercolor="#3366FF" align="center" cellpadding="0" cellspacing="0">
									<tr height="30"><td bgcolor="#6e94b7" align="center" colspan="2">
										<font face="MS Sans Serif" color="#FFFFFF" size="3"><b>����¹���ʼ�ҹ</b></font>
									</td></tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ͼ���� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2"><?php echo $_SESSION['username']; ?></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ʼ�ҹ��� : </b></font></td>
										<td>&nbsp;<input type="password" name="old_password" size="20" maxlength="50" value="" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ʼ�ҹ���� : </b></font></td>
										<td>&nbsp;<input type="password" name="new_password" size="20" maxlength="50" value="" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�׹�ѹ���ʼ�ҹ���� : </b></font></td>
										<td>&nbsp;<input type="password" name="confirm_password" size="20" maxlength="50" value="" /></td>
									</tr>
									<tr height="30">
										<td align="center" colspan="2">
											<input type="submit" name="passport" value="����¹���ʼ�ҹ" />
											<input type="reset" name="clear" value="¡��ԡ" />
										</td>
									</tr>
								</table>
								<input type="hidden" name="change_username" value="<?php echo $_SESSION['username']; ?>" />
<?php
	if(isset($services)) {
		print "<input type=\"hidden\" name=\"services\" value=\"$services\" />";
	} // end if
?>
							</form>
						</center>
					</td>
				</tr>
			</tbody>
		</table>
		<div align="center">
			<font face="MS Sans Serif" color="#000080" size="2"><br />Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<br />Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404</font><br />
			<img src="../images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('signin_form.php', '_top');" />
		</div>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.change.old_password.value;
		var v2 = document.change.new_password.value;
		var v3 = document.change.confirm_password.value;

		if (v1.length==0) {
			alert("��سһ�͹���ʼ�ҹ���");
			document.change.old_password.focus();
			return false;
		} else if (v2.length==0) {
			alert("��سһ�͹���ʼ�ҹ����");
			document.change.new_password.focus();
			return false;
		} else if (v3.length==0) {
			alert("��سһ�͹�׹�ѹ���ʼ�ҹ����");
			document.change.confirm_password.focus();
			return false;
		} else if (v2!=v3) {
			alert("���ʼ�ҹ��������׹�ѹ���ʼ�ҹ�������ç�ѹ");
			document.change.new_password.value = "";
			document.change.confirm_password.value = "";
			document.change.new_password.focus();
			return false;
		} // end if
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
	} else {
		print "<meta http-equiv=\"refresh\" content=\"0; URL=signin_form.php\" />";
	} // end if
// end file change_pwd_form.php
?>