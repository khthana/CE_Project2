<?php
// file register_form.php
	session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>ŧ����¹���������</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#3333FF; text-decoration:none }
			a:visited {	color:#3333FF; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5f5f5" text="#000000">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr valign="top"><td width="939" colspan="2">
					<div align="center">
						<img src="../images/CElogo.gif" width="590" height="100" border="0" />
					</div>
				</td></tr>
				<tr><td colspan="2">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td height="10" width="30%">&nbsp;</td>
						</tr>
					</table>
				</td></tr>
				<tr valign="top">
					<td width="160">
						<div align="center">
							<table width="100%" border="0" cellpadding="0" cellspacing="0">
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../index.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>˹���á</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="signin_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�������к�</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="forget_pwd_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>������ʼ�ҹ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../webboard/showalltopics.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��дҹ���-�ͺ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
							</table>
						</div>
					</td>
					<td width="600">
						<center>
							<form name="regis" action="index.php" method="POST" onsubmit="return check()">
								<table bgcolor="#AFC6DB" width="400" border="0" bordercolor="#3366FF" align="center" cellpadding="0" cellspacing="0">
									<tr height="30"><td bgcolor="#6E94B7" align="center" colspan="2">
										<font face="MS Sans Serif" color="#f5f5f5" size="3"><b>ŧ����¹���������</b></font>
									</td></tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���ʻ�Шӵ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="id" size="15" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���˹� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2">
											<select name="register_position">
												<option value="0">(���˹�)</option>
												<option value="1">1P</option>
												<option value="2">2P</option>
												<option value="3">3P</option>
												<option value="4">2D</option>
												<option value="5">3D</option>
												<option value="6">4D</option>
												<option value="7">�Ҩ����</option>
												<option value="8">���˹�ҷ��</option>
											</select>
										</font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2">
											<input type="radio" name="register_sex" value="m" checked />��� 
											<input type="radio" name="register_sex" value="f" />˭ԧ 
										</font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_name" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���ʡ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_surname" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�ѹ�Դ : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2">
											<select name="register_day">
												<option value="0">(�ѹ���)</option>
												<option value="01">1</option>
												<option value="02">2</option>
												<option value="03">3</option>
												<option value="04">4</option>
												<option value="05">5</option>
												<option value="06">6</option>
												<option value="07">7</option>
												<option value="08">8</option>
												<option value="09">9</option>
												<option value="10">10</option>
												<option value="11">11</option>
												<option value="12">12</option>
												<option value="13">13</option>
												<option value="14">14</option>
												<option value="15">15</option>
												<option value="16">16</option>
												<option value="17">17</option>
												<option value="18">18</option>
												<option value="19">19</option>
												<option value="20">20</option>
												<option value="21">21</option>
												<option value="22">22</option>
												<option value="23">23</option>
												<option value="24">24</option>
												<option value="25">25</option>
												<option value="26">26</option>
												<option value="27">27</option>
												<option value="28">28</option>
												<option value="29">29</option>
												<option value="30">30</option>
												<option value="31">31</option>
											</select>
											<select name="register_month">
												<option value="0">(��͹)</option>
												<option value="01">���Ҥ�</option>
												<option value="02">����Ҿѹ��</option>
												<option value="03">�չҤ�</option>
												<option value="04">����¹</option>
												<option value="05">����Ҥ�</option>
												<option value="06">�Զع�¹</option>
												<option value="07">�á�Ҥ�</option>
												<option value="08">�ԧ�Ҥ�</option>
												<option value="09">�ѹ��¹</option>
												<option value="10">���Ҥ�</option>
												<option value="11">��Ȩԡ�¹</option>
												<option value="12">�ѹ�Ҥ�</option>
											</select>
											�.�. <input type="text" name="register_year" size="4" maxlength="4" /> (�� 2524)
										</font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�������Ѿ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_phone" size="10" maxlength="10" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>������Ͷ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_mobile" size="10" maxlength="10" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>������ : </b></font></td>
										<td>&nbsp;<input type="text" name="register_email" size="30" maxlength="30" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�����ͫդ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_icq" size="10" maxlength="10" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���ͼ���� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_username" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�Ӷ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="register_question" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�����Ѻ : </b></font></td>
										<td>&nbsp;<input type="text" name="register_secret" size="20" maxlength="50" /></td>
									</tr>
									<tr height="30"><td align="center" colspan="2">
										<font face="MS Sans Serif" color="#FF0000" size="2"><b>�Ӷ����������Ѻ����㹡���Ѻ���ʼ�ҹ��������ͷ�ҹ������ʼ�ҹ���<br />***��ҹ��ͧ��͡��ͧ���������ͧ���� * ���ú�ء��ͧ***</b></font>
									</td></tr>
									<tr height="30">
										<td align="center" colspan="2">
											<input type="submit" name="passport" value="ŧ����¹" />
											<input type="reset" name="clear" value="¡��ԡ" />
										</td>
									</tr>
								</table>
<?php
	if(isset($services)) {
		print "<input type=\"hidden\" name=\"services\" value=\"$services\" />";
	} // end if
?>
							</form>
						</center>
					</td>
				</tr>
			</tbody>
		</table>
		<div align="center">
			<font face="MS Sans Serif" color="#000080" size="2"><br />Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<br />Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404</font><br />
			<img src="../images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('signin_form.php', '_top');" />
		</div>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.regis.id.value;
		var v2 = document.regis.register_position.value;
		var v3 = document.regis.register_name.value;
		var v4 = document.regis.register_surname.value;
		var v5 = document.regis.register_day.value;
		var v6 = document.regis.register_month.value;
		var v7 = document.regis.register_year.value;
		var v8 = document.regis.register_email.value;
		var v9 = document.regis.register_question.value;
		var v10 = document.regis.register_secret.value;
		var v11 = document.regis.register_username.value;
		var filter = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i;
		var filteryear = /^([0-9]{4})$/i;

		if(v1.length==0) {
			alert("��سһ�͹���ʻ�Шӵ��");
			document.regis.id.focus();
			return false;
		} else if(v2=="0") {
			alert("��س����͡���˹�");
			document.regis.register_position.focus();
			return false;
		} else if(v3.length==0) {
			alert("��سһ�͹����");
			document.regis.register_name.focus();
			return false;
		} else if(v4.length==0) {
			alert("��سһ�͹���ʡ��");
			document.regis.register_surname.focus();
			return false;
		} else if(v5=="0") {
			alert("��س����͡�ѹ�Դ");
			document.regis.register_day.focus();
			return false;
		} else if(v6=="0") {
			alert("��س����͡��͹�Դ");
			document.regis.register_month.focus();
			return false;
		} else if(v7.length==0) {
			alert("��سһ�͹���Դ�繻վط��ѡ�Ҫ");
			document.regis.register_year.focus();
			return false;
		} else if(v8.length==0) {
			alert("��سһ�͹������");
			document.regis.register_email.focus();
			return false;
		} else if(v9.length==0) {
			alert("��سһ�͹�Ӷ��");
			document.regis.register_question.focus();
			return false;
		} else if(v10.length==0) {
			alert("��سһ�͹�����Ѻ");
			document.regis.register_secret.focus();
			return false;
		} else if(v11.length==0) {
			alert("��سһ�͹���ͼ����");
			document.regis.register_username.focus();
			return false;
		} else if(document.layers||document.getElementById||document.all) {
			if(filteryear.test(v7)) {
			} else {
				alert("��سһ�͹���Դ�������١��ͧ");
				document.regis.register_year.value = "";
				document.regis.register_year.focus();
				return false;
			} // end if
			if(filter.test(v8)) {
			} else {
				alert("��سһ�͹���������١��ͧ");
				document.regis.register_email.value = "";
				document.regis.register_email.focus();
				return false;
			} // end if
		} // end if
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
// end file register_form.php
?>