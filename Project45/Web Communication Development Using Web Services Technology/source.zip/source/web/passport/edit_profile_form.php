<?php
// file edit_profile_form.php
	session_start();
	// passport services
	require('services/validate.php');				// use validate - Validate current user
	require('services/get_profile.php');			// use get_profile - Get profile from database

	// get ip from client
	$ip = getenv("REMOTE_ADDR");
	if(validate($ip)) {
		$profile = get_profile($_SESSION['username']);

		$birthdate = $profile['birthdate'];
		$months = array('���'=>'01', '���'=>'02', '�չ'=>'03', '���'=>'04', '���'=>'05', '�Զ'=>'06', '�á'=>'07', '�ԧ'=>'08', '�ѹ'=>'09', '���'=>'10', '���'=>'11', '�ѹ'=>'12');
		$day = "$birthdate[0]$birthdate[1]";
		$month = $months["$birthdate[3]$birthdate[4]$birthdate[5]"];
		switch($month) {
			case "01" :
				$year = "$birthdate[14]$birthdate[15]$birthdate[16]$birthdate[17]";
				break;
			case "02" :
				$year = "$birthdate[18]$birthdate[19]$birthdate[20]$birthdate[21]";
				break;
			case "03" :
				$year = "$birthdate[14]$birthdate[15]$birthdate[16]$birthdate[17]";
				break;
			case "04" :
				$year = "$birthdate[14]$birthdate[15]$birthdate[16]$birthdate[17]";
				break;
			case "05" :
				$year = "$birthdate[15]$birthdate[16]$birthdate[17]$birthdate[18]";
				break;
			case "06" :
				$year = "$birthdate[16]$birthdate[17]$birthdate[18]$birthdate[19]";
				break;
			case "07" :
				$year = "$birthdate[15]$birthdate[16]$birthdate[17]$birthdate[18]";
				break;
			case "08" :
				$year = "$birthdate[15]$birthdate[16]$birthdate[17]$birthdate[18]";
				break;
			case "09" :
				$year = "$birthdate[15]$birthdate[16]$birthdate[17]$birthdate[18]";
				break;
			case "10" :
				$year = "$birthdate[14]$birthdate[15]$birthdate[16]$birthdate[17]";
				break;
			case "11" :
				$year = "$birthdate[17]$birthdate[18]$birthdate[19]$birthdate[20]";
				break;
			case "12" :
				$year = "$birthdate[15]$birthdate[16]$birthdate[17]$birthdate[18]";
				break;
		} // end case
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>��䢢�������ǹ���</title>
		<meta http-equiv="content-type" content="text/html; charset=tis-620" />
		<meta content="MSHTML 6.00.2800.1106" name="generator" />
		<style>
			a:link { color:#3333FF; text-decoration:none }
			a:visited {	color:#3333FF; text-decoration:none }
			a:hover { color:blue; text-decoration:none }
		</style>
	</head>
	<body bgcolor="#F5F5F5" text="#000000">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tbody>
				<tr valign="top"><td width="939" colspan="2">
					<div align="center">
						<img src="../images/CElogo.gif" width="590" height="100" border="0" />
					</div>
				</td></tr>
				<tr><td colspan="2">
					<table width="100%" border="0" cellspacing="0" cellpadding="0">
						<tr>
							<td height="10" width="30%">&nbsp;</td>
						</tr>
					</table>
				</td></tr>
				<tr valign="top">
					<td width="160">
						<div align="center">
							<table width="100%" border="0" cellpadding="0" cellspacing="0">
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../index.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>˹���á</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="change_pwd_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>����¹���ʼ�ҹ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="view_profile.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�ʴ���������ǹ���</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="del_profile_form.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>ź��������ǹ���</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="index.php?passport=�͡�ҡ�к�"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>�͡�ҡ�к�</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
								<tr><td width="100%">
									<img src="../images/barrow.gif" />
									<a href="../webboard/showalltopics.php"><font face="MS Sans Serif, EucrosiaUPC, Thonburi, Krungthep" color="#000000" size="3"><b>��дҹ���-�ͺ</b></font></a>
								</td></tr>
								<tr><td width="100%">
									&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<img src="../images/line.gif" width="100" height="2" border="0" />
								</td></tr>
							</table>
						</div>
					</td>
					<td width="600">
						<center>
							<form name="edit" action="index.php" method="POST" onsubmit="return check()">
								<table bgcolor="#AFC6DB" width="500" border="0" bordercolor="#3366FF" align="center" cellpadding="0" cellspacing="0">
									<tr height="30"><td bgcolor="#6e94b7" align="center" colspan="2">
										<font face="MS Sans Serif" color="#FFFFFF" size="3"><b>��������ǹ���</b></font>
									</td></tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ʻ�Шӵ�� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2"><?php echo $profile['id']; ?></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���˹� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2"><?php echo $profile['position']; ?></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="2"><?php if($profile['sex'] == "m") echo "���"; else echo "˭ԧ"; ?></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���� : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_name" size="20" maxlength="50" value="<?php echo $profile['name']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���ʡ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_surname" size="20" maxlength="50" value="<?php echo $profile['surname']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�ѹ�Դ : </b></font></td>
										<td>&nbsp;
											<select name="edit_day">
												<option value="0">(�ѹ���)</option>
												<option value="01" <?php if($day == "01") echo "selected"; ?>>1</option>
												<option value="02" <?php if($day == "02") echo "selected"; ?>>2</option>
												<option value="03" <?php if($day == "03") echo "selected"; ?>>3</option>
												<option value="04" <?php if($day == "04") echo "selected"; ?>>4</option>
												<option value="05" <?php if($day == "05") echo "selected"; ?>>5</option>
												<option value="06" <?php if($day == "06") echo "selected"; ?>>6</option>
												<option value="07" <?php if($day == "07") echo "selected"; ?>>7</option>
												<option value="08" <?php if($day == "08") echo "selected"; ?>>8</option>
												<option value="09" <?php if($day == "09") echo "selected"; ?>>9</option>
												<option value="10" <?php if($day == "10") echo "selected"; ?>>10</option>
												<option value="11" <?php if($day == "11") echo "selected"; ?>>11</option>
												<option value="12" <?php if($day == "12") echo "selected"; ?>>12</option>
												<option value="13" <?php if($day == "13") echo "selected"; ?>>13</option>
												<option value="14" <?php if($day == "14") echo "selected"; ?>>14</option>
												<option value="15" <?php if($day == "15") echo "selected"; ?>>15</option>
												<option value="16" <?php if($day == "16") echo "selected"; ?>>16</option>
												<option value="17" <?php if($day == "17") echo "selected"; ?>>17</option>
												<option value="18" <?php if($day == "18") echo "selected"; ?>>18</option>
												<option value="19" <?php if($day == "19") echo "selected"; ?>>19</option>
												<option value="20" <?php if($day == "20") echo "selected"; ?>>20</option>
												<option value="21" <?php if($day == "21") echo "selected"; ?>>21</option>
												<option value="22" <?php if($day == "22") echo "selected"; ?>>22</option>
												<option value="23" <?php if($day == "23") echo "selected"; ?>>23</option>
												<option value="24" <?php if($day == "24") echo "selected"; ?>>24</option>
												<option value="25" <?php if($day == "25") echo "selected"; ?>>25</option>
												<option value="26" <?php if($day == "26") echo "selected"; ?>>26</option>
												<option value="27" <?php if($day == "27") echo "selected"; ?>>27</option>
												<option value="28" <?php if($day == "28") echo "selected"; ?>>28</option>
												<option value="29" <?php if($day == "29") echo "selected"; ?>>29</option>
												<option value="30" <?php if($day == "30") echo "selected"; ?>>30</option>
												<option value="31" <?php if($day == "31") echo "selected"; ?>>31</option>
											</select>
											<select name="edit_month">
												<option value="0">(��͹)</option>
												<option value="01" <?php if($month == "01") echo "selected"; ?>>���Ҥ�</option>
												<option value="02" <?php if($month == "02") echo "selected"; ?>>����Ҿѹ��</option>
												<option value="03" <?php if($month == "03") echo "selected"; ?>>�չҤ�</option>
												<option value="04" <?php if($month == "04") echo "selected"; ?>>����¹</option>
												<option value="05" <?php if($month == "05") echo "selected"; ?>>����Ҥ�</option>
												<option value="06" <?php if($month == "06") echo "selected"; ?>>�Զع�¹</option>
												<option value="07" <?php if($month == "07") echo "selected"; ?>>�á�Ҥ�</option>
												<option value="08" <?php if($month == "08") echo "selected"; ?>>�ԧ�Ҥ�</option>
												<option value="09" <?php if($month == "09") echo "selected"; ?>>�ѹ��¹</option>
												<option value="10" <?php if($month == "10") echo "selected"; ?>>���Ҥ�</option>
												<option value="11" <?php if($month == "11") echo "selected"; ?>>��Ȩԡ�¹</option>
												<option value="12" <?php if($month == "12") echo "selected"; ?>>�ѹ�Ҥ�</option>
											</select>
											<font face="MS Sans Serif" color="#000000" size="2">�.�. <input type="text" name="edit_year" size="4" maxlength="4" value="<?php echo $year; ?>" /> (�� 2524)</font>
										</td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�������Ѿ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_phone" size="10" maxlength="10" value="<?php echo $profile['phone']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>������Ͷ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_mobile" size="10" maxlength="10" value="<?php echo $profile['mobile']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>������ : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_email" size="30" maxlength="30" value="<?php echo $profile['email']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>�����ͫդ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_icq" size="10" maxlength="10" value="<?php echo $profile['icq']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b>���ͼ���� : </b></font></td>
										<td>&nbsp;<font face="MS Sans Serif" color="#000000" size="3"><?php echo $profile['username']; ?></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�Ӷ�� : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_question" size="20" maxlength="50" value="<?php echo $profile['question']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>�����Ѻ : </b></font></td>
										<td>&nbsp;<input type="text" name="edit_secret" size="20" maxlength="50" value="<?php echo $profile['secret']; ?>" /></td>
									</tr>
									<tr height="30">
										<td align="center" colspan="2"><font face="MS Sans Serif" color="#FF0000" size="2"><b>��ҹ��ͧ��͡���ʼ�ҹ�����׹�ѹ�����䢢�������ǹ���</b></font></td>
									</tr>
									<tr height="30">
										<td align="right"><font face="MS Sans Serif" color="#000000" size="2"><b><font color="#FF0000">* </font>���ʼ�ҹ : </b></font></td>
										<td>&nbsp;<input type="password" name="edit_password" size="20"maxlength="20" /></td>
									</tr>
									<tr height="30"><td align="center" colspan="2">
										<font face="MS Sans Serif" color="#FF0000" size="2"><b>�Ӷ����������Ѻ����㹡���Ѻ���ʼ�ҹ��������ͷ�ҹ������ʼ�ҹ���<br />***��ҹ��ͧ��͡��ͧ���������ͧ���� * ���ú�ء��ͧ***</b></font>
									</td></tr>
									<tr height="30">
										<td colspan="2" align="center">
											<input type="submit" name="passport" value="��䢢�����" />
											<input type="reset" name="clear" value="¡��ԡ" />
										</td>
									</tr>
								</table>
								<input type="hidden" name="id" value="<?php echo $profile['id']; ?>" />
								<input type="hidden" name="edit_username" value="<?php echo $profile['username']; ?>" />
							</form>
						</center>
					</td>
				</tr>
			</tbody>
		</table>
		<div align="center">
			<font face="MS Sans Serif" color="#000080" size="2"><br />Department of Computer Engineering Faculty of Engineering King Mongkut's Institute of Technology<br />Ladkrabang BKK 10520, Thailand. Tel. +662-739-2400-1 Fax.+662-7392404</font><br />
			<img src="../images/CE.gif" width="24" height="20" border="0" onmouseover="style.cursor='hand';" onclick="self.open('signin_form.php', '_top');" />
		</div>
		<script language="javascript">
<!--
	function check() {
		var v1 = document.edit.edit_name.value;
		var v2 = document.edit.edit_surname.value;
		var v3 = document.edit.edit_day.value;
		var v4 = document.edit.edit_month.value;
		var v5 = document.edit.edit_year.value;
		var v6 = document.edit.edit_email.value;
		var v7 = document.edit.edit_question.value;
		var v8 = document.edit.edit_secret.value;
		var v9 = document.edit.edit_password.value;
		var filter=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i

		if(v1.length==0) {
			alert("��سһ�͹����");
			document.edit.edit_name.focus();
			return false;
		} else if(v2.length==0) {
			alert("��سһ�͹���ʡ��");
			document.edit.edit_surname.focus();
			return false;
		} else if(v3=="0") {
			alert("��س����͡�ѹ�Դ");
			document.edit.edit_day.focus();
			return false;
		} else if(v4=="0") {
			alert("��س����͡��͹�Դ");
			document.edit.edit_month.focus();
			return false;
		} else if(v5.length==0) {
			alert("��سһ�͹���Դ�繻վط��ѡ�Ҫ");
			document.edit.edit_year.focus();
			return false;
		} else if(v6.length==0) {
			alert("��سһ�͹������");
			document.edit.edit_email.focus();
			return false;
		} else if(v7.length==0) {
			alert("��سһ�͹�Ӷ��");
			document.edit.edit_question.focus();
			return false;
		} else if(v8.length==0) {
			alert("��سһ�͹�����Ѻ");
			document.edit.edit_secret.focus();
			return false;
		} else if(v9.length==0) {
			alert("��سһ�͹���ʼ�ҹ");
			document.edit.edit_password.focus();
			return false;
		} else if(document.layers||document.getElementById||document.all) {
			if(filter.test(v6)) {
			} else {
				alert("��سһ�͹���������١��ͧ");
				document.edit.edit_email.value = "";
				document.edit.edit_email.focus();
				return false;
			} // end if
		} // end if
	} // end function check
//-->
		</script>
	</body>
</html>

<?php
	} else {
		print "<meta http-equiv=\"refresh\" content=\"0; URL=signin_form.php\" />";
	} // end if
// end file edit_profile_form.php
?>