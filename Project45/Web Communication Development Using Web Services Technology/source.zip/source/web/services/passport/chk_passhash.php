<?php
// file chk_passhash.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	require_once('../secret.php');			// use secret - Private key
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;					// create soap server
	$soapserver->register('chk_passhash');		// register chk_passhash services

	##########################################################################
	# Function Name		: chk_passhash
	# Function Purpose	 	: Check passhash and make sure that is validate
	# Receives					: $username - username of check passhash user
	#								  $passhash - passhash of check passhash user
	# Returns					: true if success, false otherwise
	##########################################################################
	function chk_passhash($username, $passhash) {
		$password_sql = "SELECT password FROM user WHERE username='$username'";
		$password_query = retrieve_db('webservices', $password_sql);
		if(is_array($password_query)) {
			if(md5($password_query['0'] . $secret) == $passhash) {
				return true;
			} // end if
		} // end if
		return false;
	} // end function chk_passhash

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file chk_passhash.php
?>