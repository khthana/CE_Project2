<?php
// file signin.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	require_once('../secret.php');			// use secret - Private key
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;			// create soap server
	$soapserver->register('signin');			// register signin services

	##########################################################################
	# Function Name		: signin
	# Function Purpose	 	: Sign in the user and give the user's ticket
	# Receives					: $username - username of sign in user
	#								  $password - password of sign in user
	# Returns					: user's ticket if success, error code otherwise
	##########################################################################
	function signin($signin_username, $signin_password) {
		$password_sql = "SELECT password FROM user WHERE username='$signin_username'";
		$password_query = retrieve_db('webservices', $password_sql);
		if(is_array($password_query)) {
			if($password_query['0'] == $signin_password) {
				$session_key = microtime( ) . $signin_username;
				$expiration_time = time( ) + 600;
				$passhash = md5($signin_password . $secret);
				$hash = md5($signin_username .
									$session_key .
									$expiration_time .
									$secret .
									$passhash);
				$result = array('username'=>$signin_username, 'session_key'=>$session_key, 'expiration_time'=>$expiration_time, 'hash'=>$hash, 'passhash'=>$passhash);
				return $result;
			} // end if
		} // end if
		return "��ҹ�������ö�������к����Ѻ<br />��سҵ�Ǩ�ͺ���ͼ����������ʼ�ҹ���١��ͧ�Ф�Ѻ";
	} // end function signin

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file signin.php
?>