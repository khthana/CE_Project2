<?php
// file update_sess.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	require_once('../secret.php');		// use secret - Private key
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('update_sess');		// register update_sess services

	##########################################################################
	# Function Name		: update_sess
	# Function Purpose	 	: Update expiration time of current session
	# Recieves					: $username - username of sign in user
	#								  $session_key - session key of the user;
	#								  $expiration_time - how long till the ticket expires?;
	#								  $hash - hash of all three of those + server secret;
	#								  $passhash - password of current user
	# Returns					: user's ticket if success, false otherwise
	##########################################################################
	function update_sess($username, $session_key, $expiration_time, $hash, $passhash) {
		$temp_hash = md5($username .
									$session_key .
									$expiration_time .
									$secret .
									$passhash);
		if($hash == $temp_hash && time( ) < $expiration_time) {
			$password_sql = "SELECT password FROM user WHERE username='$username'";
			$password_query = retrieve_db('webservices', $password_sql);
			if(is_array($password_query)) {
				if(md5($password_query['0'] . $secret) == $passhash) {
					$session_key = microtime( ) . $username;
					$expiration_time = time( ) + 600;
					$hash = md5($username .
										$session_key .
										$expiration_time .
										$secret .
										$passhash);
					$result = array('username'=>$username, 'session_key'=>$session_key, 'expiration_time'=>$expiration_time, 'hash'=>$hash, 'passhash'=>$passhash);
					return $result;
				} // end if
			} // end if
		} // end if
		return false;
	} // end function update_sess

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file update_sess.php
?>