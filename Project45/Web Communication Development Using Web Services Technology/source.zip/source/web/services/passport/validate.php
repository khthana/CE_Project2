<?php
// file validate.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	require_once('../secret.php');		// use secret - Private key
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;			// create soap server
	$soapserver->register('validate');		// register validate services

	##########################################################################
	# Function Name		: validate
	# Function Purpose		: Validates the user's ticket and makes sure they are logged in
	# Recieves					: $username - username of current user;
	#								  $session_key - session key of the user;
	#								  $expriation_time - how long till the ticket expires?;
	#								  $hash - hash of all three of those + server secret;
	#								  $passhash - password of current user
	# Returns					: true if validated, false otherwise
	##########################################################################
	function validate($username, $session_key, $expiration_time, $hash, $passhash) {
		$temp_hash = md5($username .
									$session_key .
									$expiration_time .
									$secret .
									$passhash);
		if($hash == $temp_hash && time( ) < $expiration_time) {
			$password_sql = "SELECT password FROM user WHERE username='$username'";
			$password_query = retrieve_db('webservices', $password_sql);
			if(is_array($password_query)) {
				if(md5($password_query['0'] . $secret) == $passhash) {
					return true;
				} // end if
			} // end if
		} // end if
		return false;
	} // end function validate

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file validate.php
?>