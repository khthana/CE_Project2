<?php
// file get_question.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('get_question');		// register get_question services

	##########################################################################
	# Function Name		: get_question
	# Function Purpose	 	: Return question from database
	# Receive					: $id - id of user
	# Return					: $question if success, "" otherwise
	##########################################################################
	function get_question($id) {
		$question_sql = "SELECT question FROM user WHERE id='$id'";
		$question_query = retrieve_db('webservices', $question_sql);
		if(is_array($question_query)) {
			return $question_query['0'];
		} else {
			return "";
		} // end if
	} // end function get_question

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file get_question.php
?>