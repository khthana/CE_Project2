<?php
// file get_profile.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('get_profile');		// register get_profile services

	##########################################################################
	# Function Name		: get_profile
	# Function Purpose	 	: Return profile from database
	# Receive					: $username - username of user
	# Return					: $profile if success, "" otherwise
	##########################################################################
	function get_profile($username) {
		$profile_sql = "SELECT * FROM user WHERE username='$username'";
		$profile_query = retrieve_db('webservices', $profile_sql);
		if(is_array($profile_query)) {
			while(list($profile_key, $profile_val) = each($profile_query)) {
				$profile = array('id'=>$profile_val['id'], 'position'=>$profile_val['position'], 'sex'=>$profile_val['sex'], 'name'=>$profile_val['name'], 'surname'=>$profile_val['surname'], 'birthdate'=>$profile_val['birthdate'], 'phone'=>$profile_val['phone'], 'mobile'=>$profile_val['mobile'], 'email'=>$profile_val['email'], 'icq'=>$profile_val['icq'], 'username'=>$profile_val['username'], 'question'=>$profile_val['question'], 'secret'=>$profile_val['secret']);
			} // end while
			return $profile;
		} else {
			return "";
		} // end if
	} // end function get_profile

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file get_profile.php
?>