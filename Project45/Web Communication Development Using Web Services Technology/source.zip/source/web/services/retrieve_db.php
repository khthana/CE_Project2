<?php
// file retrieve_db.php
	##########################################################################
	# Function Name		: retrieve_db
	# Function Purpose	 	: Retrieve data from database
	# Recieves					: $database - current database
	#								  $sql - sql query
	# Returns					: array of data if success, 0 otherwise
	##########################################################################
	function retrieve_db($database, $sql) {
		require_once('nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('database'=>$database, 'sql'=>$sql);
		$soapclient = new soapclient('http://161.246.6.54/services/database/retrieve_db.php');		// create soap client
		$data = $soapclient->call('retrieve_db', $parameters);		// call retrieve_db services
		return $data;
	} // end function retrieve_db
// end file retrieve_db.php
?>