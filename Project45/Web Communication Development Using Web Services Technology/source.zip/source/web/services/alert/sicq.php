<?php
// file sicq.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

	$soapserver = new soap_server;		// create soap server
	$soapserver->register('sicq');		// register sicq services

	##########################################################################
	# Function Name		: sicq
	# Function Purpose	 	: Send message to icq
	# Recieves					: $uin - uin of icq that receive message
	#								  $from - name of user that send message
	#								  $email - email of user that send message
	#								  $msg - message that use for send
	# Returns					: true if success, false otherwise
	##########################################################################
	function sicq($uin, $from, $email, $msg) {
		# host that send to
		$host = "web.icq.com";
		# the recipient
		// $uin = "94927870";
		# the sender name
		// $from = "webmaster
		# the sender email address
		// $email = "webmaster@ce.kmitl.ac.th";
		# the message for send
		// $msg = "Test send message to icq";

		# open socket
		$fp = fsockopen("$host", 80, &$errno, &$errdesc);
		$page = "/whitepages/page_me/1,,,00.html?to=$uin&from=$from&fromemail=$email&body=$msg";
		if($fp) {
			$request = "GET $page HTTP/1.0\r\n";
			$request .= "Host: $host\r\n";
			$request .= "Referer: http://www.ce.kmitl.ac.th/index.php\r\n";
			$request .= "User-Agent: PHP client\r\n\r\n";
			# send message to icq
			$flag = fputs($fp, $request);
			fclose($fp);
			return $flag;
		} else {
			return false;
		} // end if
	} // end function sicq

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file sicq.php
?>