<?php
// file get_answer.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('get_answer');		// register get_answer services

	##########################################################################
	# Function Name		: get_answer
	# Function Purpose	 	: Return answer array from database
	# Receive					: $q_id - id of question
	# Return					: $answer if success, "" otherwise
	##########################################################################
	function get_answer($q_id) {
		$answer_sql = "SELECT * FROM board_answer WHERE a_qid='$q_id'";
		$answer_query = retrieve_db('webservices', $answer_sql);
		if(is_array($answer_query)) {
			return $answer_query;
		} else {
			return "";
		} // end if
	} // end function get_answer

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file get_answer.php
?>