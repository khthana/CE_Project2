<?php
// file get_question.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('get_question');		// register get_question services

	##########################################################################
	# Function Name		: get_question
	# Function Purpose	 	: Return question from database
	# Receive					: $q_id - id of question
	# Return					: $question if success, "" otherwise
	##########################################################################
	function get_question($q_id) {
		$question_sql = "SELECT * FROM board_question WHERE q_id='$q_id'";
		$question_query = retrieve_db('webservices', $question_sql);
		if(is_array($question_query)) {
			while(list($question_key, $question_val) = each($question_query)) {
				$question = array('q_topic'=>$question_val['q_topic'], 'q_message'=>$question_val['q_message'], 'q_name'=>$question_val['q_name'], 'q_email'=>$question_val['q_email'], 'q_icq'=>$question_val['q_icq'], 'q_ip'=>$question_val['q_ip'], 'q_date'=>$question_val['q_date'], 'q_time'=>$question_val['q_time'], 'q_update'=>$question_val['q_update'], 'q_reng'=>$question_val['q_reng'], 'q_member'=>$question_val['q_member'], 'q_alert'=>$question_val['q_alert']);
			} // end while
			return $question;
		} else {
			return "";
		} // end if
	} // end function get_question

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file get_question.php
?>