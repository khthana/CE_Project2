<?php
// file post_answer.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database
	require_once('../inupdel_db.php');		// use inupdel_db - Insert, Update, Delete data in database
	// passport services
	require_once('../chk_passhash.php');		// use chk_passhash - Check passhash in database
	require_once('../get_profile.php');			// use get_profile - Get profile from database
	// alert services
	require_once('../smail.php');		// use smail - Send mail
	require_once('../sicq.php');		// use sicq - Send icq
	// webboard services
	require_once('../get_question.php');		// use get_question - Get question from database
	require_once('../get_answer.php');		// use get_answer - Get answer array from database

	$soapserver = new soap_server;					// create soap server
	$soapserver->register('post_answer');		// register post_answer services

	##########################################################################
	# Function Name		: post_answer
	# Function Purpose		: Post answer to database
	# Recieves					: $q_id - id of question that post answer
	#								  $a_message - message of post answer
	#								  $a_username - the username of sign in user that post answer
	#								  $a_passhash - the passhash of sign in user that post answer
	#								  $a_name - name of user that post answer
	#								  $a_email - email address of user that post answer
	#								  $a_ip - ip of user that post answer
	#								  $a_date - date of post answer
	#								  $q_update - time of post answer in minute
	#								  $a_alert - flag of alert
	# Returns					: true if success, true otherwise
	##########################################################################
	function post_answer($q_id, $a_message, $a_username, $a_passhash, $a_name, $a_email, $a_ip, $a_date, $q_update, $a_alert) {
		if($a_username != "") {
			if(chk_passhash($a_username, $a_passhash)) {
				$profile = get_profile($a_username);
				if($a_alert == "y") {
					$a_alert = "y";
				} else {
					$a_alert = "n";
				} // end if
				$a_member = "y";
				$answer_sql = "SELECT * FROM board_answer WHERE (a_qid='$q_id' AND a_message='$a_message' AND a_name='$a_username')";
				$answer_query = retrieve_db('webservices', $answer_sql);
				if(is_array($answer_query)) {
					return "��ҹ�������ö�ͺ��з�����Ѻ<br />���Фӵͺ���������㹰ҹ���������Ǥ�Ѻ";
				} else {
					// get number of reply question
					$answer_sql = "SELECT * FROM board_answer WHERE a_qid = '$q_id'";
					$answer_query = retrieve_db('webservices', $answer_sql);
					if(is_array($answer_query)) {
						$q_reng = count($answer_query) + 1;
					} else {
						$q_reng = 0;
					} // end if

					// update question has q_reng = $q_reng
					$up_question_sql = 'UPDATE board_question SET q_update=\'' . $q_update . '\', q_reng=\'' . $q_reng . '\' WHERE q_id=\'' . $q_id . '\'';
					$flag1 = inupdel_db('webservices', $up_question_sql);
					if($flag1) {
						// insert answer has a_qid = $q_id
						$inst_answer_sql = 'INSERT INTO board_answer (a_id, a_qid, a_message, a_name, a_email, a_icq, a_ip, a_datetime, a_update, a_member, a_alert) VALUES (\'0\', \'' . $q_id . '\', \'' . $a_message . '\', \'' . $a_username . '\', \'' . $profile['email'] . '\', \'' . $profile['icq'] . '\', \'' . $a_ip . '\', \'' . $a_date . '\', \'' . $q_update . '\', \'' . $a_member . '\', \'' . $a_alert . '\')';
						$flag = inupdel_db('webservices', $inst_answer_sql);
						if($flag) {
							$question = get_question($q_id);
							if(($question['q_member'] == 'y') && ($question['q_alert'] == 'y')) {
								$alert1 = get_profile($question['q_name']);
								$alert_sql1 = "SELECT * FROM alert WHERE (userID=\"" . $alert1['id'] . "\" AND qID=\"" . $q_id . "\")";
								$alert_query1 = retrieve_db('webservices', $alert_sql1);
								if(!is_array($alert_query1)) {
									$inst_alert_sql1 = 'INSERT INTO alert (userID, qID) VALUES (\'' . $alert1['id'] . '\', \'' . $q_id . '\')';
									inupdel_db('webservices', $inst_alert_sql1);
								} // end if
							} // end if

							if($question['q_alert'] == 'y') {
								$alertmail[0] = $question['q_email'];
								$alerticq[0] = $question['q_icq'];
							} else {
								$alertmail[0] = "";
								$alerticq[0] = "";
							} // end if
							// send mail to user
							$from = "webmaster@ce.kmitl.ac.th";
							$subject = "Webboard update";
							$q_topic = $question['q_topic'];
							$msg = "�բ���������¹�ŧ㹡�з��\n������Ǣ�͡�з�� : $q_topic\n�����ҷ��ͺ : $a_message\n���ͼ��ͺ : $a_username\n�ӡ�����仵�Ǩ�ͺ�������¹�ŧ�������Ѻ http://161.246.6.54/webboard/view.php?q_id=$q_id";
							$from1 = "webmaster";
							$email1 = "webmaster@kmitl.ac.th";
							$msg1 = "�բ���������¹�ŧ㹡�з��  ������Ǣ�͡�з�� : $q_topic";

							$answer = get_answer($q_id);
							$i = 1;
							$a = 1;
							$b = 1;
							while(list($answer_key, $answer_val) = each($answer)) {
								if($answer_val['a_alert'] == 'y') {
									$flag = true;
									$flag1 = true;
									for($j = 0; $j <= $i; $j++) {
										if($alertmail[$j] == $answer_val['a_email']) {
											$flag = false;
										} // end if
										if($alerticq[$j] == $answer_val['a_icq']) {
											$flag1 = false;
										} // end if
									} // end for
									if($flag) {
										if(($answer_val['a_member'] == 'y') && ($answer_val['a_alert'] == 'y')) {
											$alert2 = get_profile($answer_val['a_name']);
											$alert_sql2 = "SELECT * FROM alert WHERE (userID=\"" . $alert2['id'] . "\" AND qID=\"" . $q_id . "\")";
											$alert_query2 = retrieve_db('webservices', $alert_sql2);
											if(!is_array($alert_query2)) {
												$inst_alert_sql2 = 'INSERT INTO alert (userID, qID) VALUES (\'' . $alert2['id'] . '\', \'' . $q_id . '\')';
												inupdel_db('webservices', $inst_alert_sql2);
											} // end if
										} // end if
										$alertmail[$a] = $answer_val['a_email'];
										$a++;
									} // end if
									if($flag1) {
										$alerticq[$b] = $answer_val['a_icq'];
										$b++;
									} // end if
									$i++;
								} // end if
							} // end while

							for($j = 0; $j <= $a; $j++) {
								$mailto = $alertmail[$j];
								if(($mailto != "") && ($mailto != $profile['email'])) {
									smail($from, $mailto, $subject, $msg);
								} // end if
							} // end for
							for($j = 0; $j <= $b; $j++) {
								$uin = $alerticq[$j];
								if(($uin != "") && ($uin != $profile['icq'])) {
									sicq($uin, $from1, $email1, $msg1);
								} // end if
							} // end for
							return "��õͺ��з����������ó����Ǥ�Ѻ<br />�ӵͺ�����١�Ѵ��ŧ㹰ҹ���������Ǥ�Ѻ";
						} else {
							$up_question_sql = 'UPDATE board_question SET q_reng=\'' . ($q_reng - 1) . '\'';
							inupdel_db('webservices', $up_question_sql);
							return "��õͺ��з��Դ��Ҵ��Ѻ<br />�к��������ö����������ŧ㹰ҹ���������Ѻ";
						} // end if
					} else {
						return "��õͺ��з��Դ��Ҵ��Ѻ<br />�к��������ö��䢢�����㹰ҹ���������Ѻ";
					} // end if
				} // end if
			} // end if
		} elseif($a_name != "") {
			$a_alert = "n";
			$a_member = "n";
			$answer_sql = "SELECT * FROM board_answer WHERE (a_qid='$q_id' AND a_message='$a_message' AND a_name='$a_name')";
			$answer_query = retrieve_db('webservices', $answer_sql);
			if(is_array($answer_query)) {
				return "��ҹ�������ö�ͺ��з�����Ѻ<br />���Фӵͺ���������㹰ҹ���������Ǥ�Ѻ";
			} else {
				// get number of reply question
				$answer_sql = "SELECT * FROM board_answer WHERE a_qid = '$q_id'";
				$answer_query = retrieve_db('webservices', $answer_sql);
				if(is_array($answer_query)) {
					$q_reng = count($answer_query) + 1;
				} else {
					$q_reng = 0;
				} // end if

				// update question has q_reng = $q_reng
				$up_question_sql = 'UPDATE board_question SET q_update=\'' . $q_update . '\', q_reng=\'' . $q_reng . '\' WHERE q_id=\'' . $q_id . '\'';
				$flag1 = inupdel_db('webservices', $up_question_sql);
				if($flag1) {
					// insert answer has a_qid = $q_id
					$inst_answer_sql = 'INSERT INTO board_answer (a_id, a_qid, a_message, a_name, a_email, a_ip, a_datetime, a_update, a_member) VALUES (\'0\', \'' . $q_id . '\', \'' . $a_message . '\', \'' . $a_name . '\', \'' . $a_email . '\', \'' . $a_ip . '\', \'' . $a_date . '\', \'' . $q_update . '\', \'' . $a_member . '\')';
					$flag = inupdel_db('webservices', $inst_answer_sql);
					if($flag) {
						$question = get_question($q_id);
						if(($question['q_member'] == 'y') && ($question['q_alert'] == 'y')) {
							$alert1 = get_profile($question['q_name']);
							$alert_sql1 = "SELECT * FROM alert WHERE (userID=\"" . $alert1['id'] . "\" AND qID=\"" . $q_id . "\")";
							$alert_query1 = retrieve_db('webservices', $alert_sql1);
							if(!is_array($alert_query1)) {
								$inst_alert_sql1 = 'INSERT INTO alert (userID, qID) VALUES (\'' . $alert1['id'] . '\', \'' . $q_id . '\')';
								inupdel_db('webservices', $inst_alert_sql1);
							} // end if
						} // end if
						if($question['q_alert'] == 'y') {
							$alertmail[0] = $question['q_email'];
							$alerticq[0] = $question['q_icq'];
						} else {
							$alertmail[0] = "";
							$alerticq[0] = "";
						} // end if
						// send mail to user
						$from = "webmaster@ce.kmitl.ac.th";
						$subject = "Webboard update";
						$q_topic = $question['q_topic'];
						$msg = "�բ���������¹�ŧ㹡�з��\n������Ǣ�͡�з�� : $q_topic\n�����ҷ��ͺ : $a_message\n���ͼ��ͺ : $a_name\n�ӡ�����仵�Ǩ�ͺ�������¹�ŧ�������Ѻ http://161.246.6.54/webboard/view.php?q_id=$q_id";
						$from1 = "webmaster";
						$email1 = "webmaster@kmitl.ac.th";
						$msg1 = "�բ���������¹�ŧ㹡�з��  ������Ǣ�͡�з�� : $q_topic";

						$answer = get_answer($q_id);
						$i = 1;
						$a = 1;
						$b = 1;
						while(list($answer_key, $answer_val) = each($answer)) {
							if($answer_val['a_alert'] == 'y') {
								$flag = true;
								$flag1 = true;
								for($j = 0; $j <= $i; $j++) {
									if($alertmail[$j] == $answer_val['a_email']) {
										$flag = false;
									} // end if
									if($alerticq[$j] == $answer_val['a_icq']) {
										$flag1 = false;
									} // end if
								} // end for
								if($flag) {
									if(($answer_val['a_member'] == 'y') && ($answer_val['a_alert'] == 'y')) {
										$alert2 = get_profile($answer_val['a_name']);
										$alert_sql2 = "SELECT * FROM alert WHERE (userID=\"" . $alert2['id'] . "\" AND qID=\"" . $q_id . "\")";
										$alert_query2 = retrieve_db('webservices', $alert_sql2);
										if(!is_array($alert_query2)) {
											$inst_alert_sql2 = 'INSERT INTO alert (userID, qID) VALUES (\'' . $alert2['id'] . '\', \'' . $q_id . '\')';
											inupdel_db('webservices', $inst_alert_sql2);
										} // end if
									} // end if
									$alertmail[$a] = $answer_val['a_email'];
									$a++;
								} // end if
								if($flag1) {
									$alerticq[$b] = $answer_val['a_icq'];
									$b++;
								} // end if
								$i++;
							} // end if
						} // end while

						for($j = 0; $j <= $a; $j++) {
							$mailto = $alertmail[$j];
							if(($mailto != "") && ($mailto != $profile['email'])) {
								smail($from, $mailto, $subject, $msg);
							} // end if
						} // end for
						for($j = 0; $j <= $b; $j++) {
							$uin = $alerticq[$j];
							if(($uin != "") && ($uin != $profile['icq'])) {
								sicq($uin, $from1, $email1, $msg1);
							} // end if
						} // end for
						return "��õͺ��з����������ó����Ǥ�Ѻ<br />�ӵͺ�����١�Ѵ��ŧ㹰ҹ���������Ǥ�Ѻ";
					} else {
						$up_question_sql = 'UPDATE board_question SET q_reng=\'' . ($q_reng - 1) . '\'';
						inupdel_db('webservices', $up_question_sql);
						return "��õͺ��з��Դ��Ҵ��Ѻ<br />�к��������ö����������ŧ㹰ҹ���������Ѻ";
					} // end if
				} else {
					return "��õͺ��з��Դ��Ҵ��Ѻ<br />�к��������ö��䢢�����㹰ҹ���������Ѻ";
				} // end if
			} // end if
		} else {
			return "��ҹ�������ö�ͺ��з�����Ѻ<br />��������ժ��ͼ��ͺ��з���Ѻ";
		} // end if
		return "��ҹ�������ö�ͺ��з�����Ѻ<br />��س��駼������к��Ф�Ѻ";
	} // end function post_question

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file post_question.php
?>