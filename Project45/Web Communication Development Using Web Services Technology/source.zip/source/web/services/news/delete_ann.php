<?php
// file delete_ann.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../inupdel_db.php');		// use inupdel_db - Insert, Update, Delete data in database

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('delete_ann');		// register delete_ann services

	##########################################################################
	# Function Name		: delete_ann
	# Function Purpose		: Delete announce from database
	# Recieves					: $delete_topicid - topicid of delete announce
	# Returns					: true if success, false otherwise
	##########################################################################
	function delete_ann($delete_topicid) {
		// �ӡ�á�˹���� del �� y ��ҹ��
		$up_ann_sql = 'UPDATE newstopic SET del=\'y\' WHERE topicid=\'' . $delete_topicid . '\'';
		$flag = inupdel_db('webservices', $up_ann_sql);
/*
		// delete topic has topicid = $delete_topicid from table topics
		$del_ann_sql = 'DELETE FROM newstopic WHERE topicid=\'' . $delete_topicid . '\'';
		$flag = inupdel_db('webservices', $del_ann_sql);

		// delete every files have topicid = $delete_topicid
		$file_sql = "SELECT filename, timestamp FROM newsfileattach WHERE topicid='$delete_topicid'";
		$file_query = retrieve_db('webservices', $file_sql);
		if(is_array($file_query)) {
			$num_file = count($file_query);
			if($num_file > 0) {
				while(list($file_key, $file_val) = each($file_query)) {
					// delete file from server
					$filedelete = $file_val['timestamp'] . $file_val['filename'];
					$pathdelete = "f:\\news\\files\\" . $filedelete;
					unlink($pathdelete);
				} // end while
			} // end if

			// delete record files have topicid = $delete_topicid from table fileattach
			$del_file_sql = 'DELETE FROM newsfileattach WHERE topicid=\'' . $delete_topicid . '\'';
			$flag = inupdel_db('webservices', $del_file_sql);
		} // end if
*/
		return $flag;
	} // end function delete_ann

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file delete_ann.php
?>