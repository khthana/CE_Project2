<?php
// file get_ann.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;			// create soap server
	$soapserver->register('get_ann');		// register get_ann services

	##########################################################################
	# Function Name		: get_ann
	# Function Purpose	 	: Return announce from database
	# Receive					: $topicid - topicid of announce
	# Return					: $announce if success, "" otherwise
	##########################################################################
	function get_ann($topicid) {
		$ann_sql = "SELECT * FROM newstopic WHERE topicid='$topicid'";
		$ann_query = retrieve_db('webservices', $ann_sql);
		if(is_array($ann_query)) {
			while(list($ann_key, $ann_val) = each($ann_query)) {
				$announce = $ann_val;
			} // end while
			return $announce;
		} else {
			return "";
		} // end if
	} // end function get_ann

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file get_ann.php
?>