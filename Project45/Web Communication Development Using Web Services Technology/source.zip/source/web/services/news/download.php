<?php
// file download.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP
	// database services
	require_once('../retrieve_db.php');		// use retrieve_db - Retrieve data from database

	$soapserver = new soap_server;			// create soap server
	$soapserver->register('download');		// register download services

	##########################################################################
	# Function Name		: download
	# Function Purpose		: Download file from server
	# Recieves					: $fileid - fileid of download file
	# Returns					: download path if success, false otherwise
	##########################################################################
	function download($fileid) {
		$file_sql = "SELECT filename, timestamp FROM newsfileattach WHERE fileid='$fileid'";
		$file_query = retrieve_db('webservices', $file_sql);
		if(is_array($file_query)) {
			$num_file = count($file_query);
			if($num_file > 0) {
				while(list($file_key, $file_val) = each($file_query)) {
					$filedownload =  $file_val['timestamp'] . $file_val['filename'];
					$downloadpath = "f:\\news\\files\\" . $filedownload;
					$filesize = filesize($downloadpath);
					$result['header'] = "Content-Disposition:attachment; filename=" . $file_val["filename"] . "\nContent-Length:$filesize\nContent-Type:application/octet-stream\nExpires: 0\nCache-Control: must-revalidate, post-check=0, pre-check=0\nPragma: public";
					$result['downloadpath'] = $downloadpath;
				} // end while
			} // end if
		} else {
			$result = false;
		} // end if
		return $result;
	} // end function download

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file download.php
?>