<?php
// file inupdel_db.php
	##########################################################################
	# Function Name		: inupdel_db
	# Function Purpose	 	: Insert, Update, Delete data in database
	# Recieves					: $database - current database
	#								  $sql - sql query
	# Returns					: true if success, false otherwise
	##########################################################################
	function inupdel_db($database, $sql) {
		require_once('nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('database'=>$database, 'sql'=>$sql);
		$soapclient = new soapclient('http://161.246.6.54/services/database/inupdel_db.php');		// create soap client
		$flag = $soapclient->call('inupdel_db', $parameters);		// call inupdel_db services
		return $flag;
	} // end function inupdel_db
// end file inupdel_db.php
?>