<?php
// file secret.php
	$secret = md5("sdfkjsdkflhkh23hkjsdk#$@%$#%DSF");		// Private key
// end file secret.php
?>