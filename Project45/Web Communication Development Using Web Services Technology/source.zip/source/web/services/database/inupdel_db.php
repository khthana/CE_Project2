<?php
// file inupdel_db.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('inupdel_db');		// register inupdel_db services

	##########################################################################
	# Function Name		: inupdel_db
	# Function Purpose		: Insert, Update, Delete data in database
	# Recieves					: $database - current database
	#								  $sql - sql query
	# Returns					: true if success, false otherwise
	##########################################################################
	function inupdel_db($database, $sql) {
		// connect to database
		$connect = mysql_pconnect('localhost', 'root', '123456');
		if($connect) {
			if(mysql_select_db($database)) {
				mysql_query($sql);
				if(mysql_affected_rows() >= 1) {
					return true;
				} // end if
			} // end if
		} // end if
		return false;
	} // end function inupdel_db

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file inupdel_db.php
?>