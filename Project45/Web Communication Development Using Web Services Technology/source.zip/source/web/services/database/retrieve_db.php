<?php
// file retrieve_db.php
	require_once('../nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

	$soapserver = new soap_server;				// create soap server
	$soapserver->register('retrieve_db');		// register retrieve_db services

	##########################################################################
	# Function Name		: retrieve_db
	# Function Purpose	 	: Retrieve data from database
	# Recieves					: $database - current database
	#								  $sql - sql query
	# Returns					: Array of data if success, false otherwise
	##########################################################################
	function retrieve_db($database, $sql) {
		// connect to database
		$connect = mysql_pconnect('localhost', 'root', '123456');
		if($connect) {
			if(mysql_select_db($database)) {
				$query = mysql_query($sql);
				$i = 1;
				while($row = mysql_fetch_array($query)) {
					$flag = false;
					while(list($key, $val) = each($row)) {
						if($flag) {
							$row_array[$key] = $val;
							$flag = false;
						} else {
							$flag = true;
						} // end if
					} // end while

					if(count($row_array) == 1) {
						while(list($key, $val) = each($row_array)) {
							$result[$i] = $val;
						} // end while
					} else {
						$result[$i] = $row_array;
					} // end if
					$i++;
				} // end while
				return $result;
			} // end if
		} // end if
		return false;
	} // end function retrieve_db

	$soapserver->service($HTTP_RAW_POST_DATA);
// end file retrieve_db.php
?>