<?php
// file get_question.php
	##########################################################################
	# Function Name		: get_question
	# Function Purpose	 	: Return question from database
	# Receive					: $q_id - id of question
	# Return					: $question if success, "" otherwise
	##########################################################################
	function get_question($q_id) {
		require_once('nusoap.php');		// use NuSOAP - Web Services Toolkit for PHP

		$parameters = array('q_id'=>$q_id);
		$soapclient = new soapclient('http://161.246.6.54/services/webboard/get_question.php');		// create soap client
		$question = $soapclient->call('get_question', $parameters);		// call get_question services

		return $question;
	} // end function get_question
// end file get_question.php
?>