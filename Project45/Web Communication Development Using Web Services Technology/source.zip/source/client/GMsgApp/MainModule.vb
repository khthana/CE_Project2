Module MainModule

    Public uName As String
    Public uSes As String
    Public uWkst As String
    Public uDsp As String
    Public pUID As String
    Public pPSW As String
    Public iAlert As Boolean
    Public lAlert As Alert
    Public iNewsAlert As Boolean
    Public lNewsAlert As NewsAlert
    Public shwNotify(3) As Boolean
    Public aList As New SortedList()

    Sub main()

        Dim i As Long
        For i = 0 To 3
            shwNotify(i) = False
        Next i

        Dim l As New Login()
        l.ShowDialog()
        aList.Clear()

    End Sub

    Public Sub LoadMain()

        GetUserDisplay()

        Dim m As New Main()
        m.Text = "CE.Messenger - " + uDsp
        m.ShowDialog()

    End Sub

    Public Sub GetUserDisplay()

        Dim svr As New WebReference1.Service1()
        Dim tDS As DataSet

        If svr.GetUserInfo(uName, tDS) = False Then
            uDsp = ""
            MsgBox("Unable to gather user information...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
        Else
            uDsp = tDS.Tables(0).Rows(0)(1)
        End If

    End Sub

    Public Function RegisterMessage(ByVal desUsrID As String, ByVal desUsrName As String) As GMsgApp.Message

        If aList.ContainsKey(desUsrID) = False Then   'Not Found

            Dim m As New GMsgApp.Message()
            m.DesUserID = desUsrID
            m.DesUserName = desUsrName

            aList.Add(desUsrID, m)

            Return m

        Else
            Return aList.GetByIndex(aList.IndexOfKey(desUsrID))
        End If

    End Function

    Public Function RemoveMessage(ByVal desUsrID As String) As Boolean

        If aList.ContainsKey(desUsrID) = True Then  'Found
            aList.RemoveAt(aList.IndexOfKey(desUsrID))
            Return True
        Else
            Return False
        End If

    End Function

    Public Sub GetMessage()

        Dim svr As New WebReference1.Service1()
        Dim tDS As DataSet
        Dim zDS As DataSet
        Dim m As GMsgApp.Message

        If svr.GetMessage(uName, tDS) = False Then
            MsgBox("Unable to get message from server...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
        Else
            If tDS.Tables(0).Rows.Count > 0 Then

                Dim dr As DataRow
                For Each dr In tDS.Tables(0).Rows

                    If aList.ContainsKey(dr(2)) = False Then
                        m = RegisterMessage(dr(2), dr(7))
                        m.Show()

                        m.SendToBack()
                        m.WindowState = FormWindowState.Minimized
                        m.RichTextBox2.AppendText(dr(7) + ": " + Format(dr(1), "yyyy.MM.dd HH:mm:ss") + Chr(13) + Chr(10) + dr(4) + Chr(13) + Chr(10))
                        m.RichTextBox2.Refresh()
                    Else
                        m = RegisterMessage(dr(2), dr(7))
                        m.Show()
                    End If

                    m.RichTextBox2.AppendText(dr(7) + ": " + Format(dr(1), "yyyy.MM.dd HH:mm:ss") + Chr(13) + Chr(10) + dr(4) + Chr(13) + Chr(10))
                    m.RichTextBox2.Refresh()
                Next dr

                If svr.GetMessageConfirm(uName, tDS.Tables(0).Rows(0)(6)) = False Then
                    MsgBox("Unable to confirm message received...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                End If

            End If
        End If

    End Sub

    Public Function StatusInfo(ByVal s As Byte) As String
        Select Case s
            Case Is = 1
                Return "Online"
            Case Is = 2
                Return "Away"
            Case Is = 3
                Return "Invisible"
            Case Else
                Return "Offline"
        End Select
    End Function

    Public Function myHEX(ByVal ip As Byte) As String
        Dim s As String
        s = Hex(ip)
        If Len(s) = 1 Then s = "0" + s
        Return s
    End Function

    Public Function myMD5(ByVal ip As String) As String

        Dim data(Len(ip) - 1) As Byte
        Dim i As Long

        For i = 0 To Len(ip) - 1
            data(i) = Asc(ip.Chars(i))
        Next i

        Dim md5 As New System.Security.Cryptography.MD5CryptoServiceProvider()

        Dim result As Byte() = md5.ComputeHash(data)

        Dim op As String

        op = ""
        For i = 0 To result.Length - 1
            op += myHEX(result(i))
        Next

        Return op
    End Function

    Public Sub NotifySignin(ByVal desUSR As String, ByVal desUSRName As String)

        Dim i As Long
        For i = 0 To 3
            If shwNotify(i) = False Then
                shwNotify(i) = True
                Dim ns As New Notify()
                ns.DesUserID = desUSR
                ns.DesUserName = desUSRName
                ns.index = i
                ns.Show()
                ns.Left = 0
                ns.Top = i * 112
                ns.LinkLabel1.Text = desUSRName + Chr(13) + Chr(10) + "has just signed in"
                Exit For
            End If
        Next i
    End Sub
End Module
