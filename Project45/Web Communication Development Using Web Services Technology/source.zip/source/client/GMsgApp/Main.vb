Public Class Main
    Inherits System.Windows.Forms.Form

    Private Status As Byte

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents Timer1 As System.Timers.Timer
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Timer2 As System.Timers.Timer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem18 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem19 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem20 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem21 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem22 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem23 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem24 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem25 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem26 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem27 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem28 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem29 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem30 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem31 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem32 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem33 As System.Windows.Forms.MenuItem
    Friend WithEvents Timer3 As System.Timers.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Main))
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.MenuItem22 = New System.Windows.Forms.MenuItem()
        Me.MenuItem18 = New System.Windows.Forms.MenuItem()
        Me.MenuItem30 = New System.Windows.Forms.MenuItem()
        Me.MenuItem31 = New System.Windows.Forms.MenuItem()
        Me.MenuItem24 = New System.Windows.Forms.MenuItem()
        Me.MenuItem23 = New System.Windows.Forms.MenuItem()
        Me.MenuItem20 = New System.Windows.Forms.MenuItem()
        Me.MenuItem19 = New System.Windows.Forms.MenuItem()
        Me.MenuItem21 = New System.Windows.Forms.MenuItem()
        Me.MenuItem17 = New System.Windows.Forms.MenuItem()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.MenuItem5 = New System.Windows.Forms.MenuItem()
        Me.MenuItem6 = New System.Windows.Forms.MenuItem()
        Me.MenuItem7 = New System.Windows.Forms.MenuItem()
        Me.MenuItem8 = New System.Windows.Forms.MenuItem()
        Me.MenuItem9 = New System.Windows.Forms.MenuItem()
        Me.MenuItem10 = New System.Windows.Forms.MenuItem()
        Me.MenuItem11 = New System.Windows.Forms.MenuItem()
        Me.MenuItem25 = New System.Windows.Forms.MenuItem()
        Me.MenuItem33 = New System.Windows.Forms.MenuItem()
        Me.MenuItem32 = New System.Windows.Forms.MenuItem()
        Me.MenuItem26 = New System.Windows.Forms.MenuItem()
        Me.MenuItem27 = New System.Windows.Forms.MenuItem()
        Me.MenuItem28 = New System.Windows.Forms.MenuItem()
        Me.MenuItem29 = New System.Windows.Forms.MenuItem()
        Me.MenuItem12 = New System.Windows.Forms.MenuItem()
        Me.MenuItem13 = New System.Windows.Forms.MenuItem()
        Me.MenuItem14 = New System.Windows.Forms.MenuItem()
        Me.MenuItem15 = New System.Windows.Forms.MenuItem()
        Me.MenuItem16 = New System.Windows.Forms.MenuItem()
        Me.Timer1 = New System.Timers.Timer()
        Me.Timer2 = New System.Timers.Timer()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Timer3 = New System.Timers.Timer()
        CType(Me.Timer1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Timer2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Timer3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TreeView1
        '
        Me.TreeView1.AllowDrop = True
        Me.TreeView1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(254, Byte), CType(251, Byte))
        Me.TreeView1.ContextMenu = Me.ContextMenu1
        Me.TreeView1.ImageList = Me.ImageList1
        Me.TreeView1.Location = New System.Drawing.Point(8, 32)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.ShowRootLines = False
        Me.TreeView1.Size = New System.Drawing.Size(224, 320)
        Me.TreeView1.TabIndex = 0
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem22, Me.MenuItem18, Me.MenuItem30, Me.MenuItem31, Me.MenuItem24, Me.MenuItem23, Me.MenuItem20, Me.MenuItem19, Me.MenuItem21, Me.MenuItem17})
        '
        'MenuItem22
        '
        Me.MenuItem22.Index = 0
        Me.MenuItem22.Text = "&Send Message"
        '
        'MenuItem18
        '
        Me.MenuItem18.Index = 1
        Me.MenuItem18.Text = "-"
        '
        'MenuItem30
        '
        Me.MenuItem30.Index = 2
        Me.MenuItem30.Text = "&Contact Info"
        '
        'MenuItem31
        '
        Me.MenuItem31.Index = 3
        Me.MenuItem31.Text = "-"
        '
        'MenuItem24
        '
        Me.MenuItem24.Index = 4
        Me.MenuItem24.Text = "&Block Contact"
        '
        'MenuItem23
        '
        Me.MenuItem23.Index = 5
        Me.MenuItem23.Text = "&Unblock Contact"
        '
        'MenuItem20
        '
        Me.MenuItem20.Index = 6
        Me.MenuItem20.Text = "&Change Contact Group"
        '
        'MenuItem19
        '
        Me.MenuItem19.Index = 7
        Me.MenuItem19.Text = "&Delete Contact"
        '
        'MenuItem21
        '
        Me.MenuItem21.Index = 8
        Me.MenuItem21.Text = "-"
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 9
        Me.MenuItem17.Text = "&Add New Contact"
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem6, Me.MenuItem12, Me.MenuItem16})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem5})
        Me.MenuItem1.Text = "&CE.Msg"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "&Change My Profile"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "-"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 2
        Me.MenuItem5.Text = "&Quit"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem7, Me.MenuItem8, Me.MenuItem9, Me.MenuItem10, Me.MenuItem11, Me.MenuItem25, Me.MenuItem33, Me.MenuItem32, Me.MenuItem26})
        Me.MenuItem6.Text = "&Contact"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 0
        Me.MenuItem7.Text = "&Add New Contact"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 1
        Me.MenuItem8.Text = "&Delete Contact"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 2
        Me.MenuItem9.Text = "-"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 3
        Me.MenuItem10.Text = "&Block Contact"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 4
        Me.MenuItem11.Text = "&Unblock Contact"
        '
        'MenuItem25
        '
        Me.MenuItem25.Index = 5
        Me.MenuItem25.Text = "-"
        '
        'MenuItem33
        '
        Me.MenuItem33.Index = 6
        Me.MenuItem33.Text = "&Contact Info"
        '
        'MenuItem32
        '
        Me.MenuItem32.Index = 7
        Me.MenuItem32.Text = "-"
        '
        'MenuItem26
        '
        Me.MenuItem26.Index = 8
        Me.MenuItem26.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem27, Me.MenuItem28, Me.MenuItem29})
        Me.MenuItem26.Text = "&Contact Group"
        '
        'MenuItem27
        '
        Me.MenuItem27.Index = 0
        Me.MenuItem27.Text = "&Add New Group"
        '
        'MenuItem28
        '
        Me.MenuItem28.Index = 1
        Me.MenuItem28.Text = "&Rename Group"
        '
        'MenuItem29
        '
        Me.MenuItem29.Index = 2
        Me.MenuItem29.Text = "&Delete Group"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 2
        Me.MenuItem12.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem13, Me.MenuItem14, Me.MenuItem15})
        Me.MenuItem12.Text = "&Mode"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 0
        Me.MenuItem13.Text = "&Online"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 1
        Me.MenuItem14.Text = "&Away"
        '
        'MenuItem15
        '
        Me.MenuItem15.Index = 2
        Me.MenuItem15.Text = "&Invisible"
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 3
        Me.MenuItem16.Text = "About"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 15000
        Me.Timer1.SynchronizingObject = Me
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 3000
        Me.Timer2.SynchronizingObject = Me
        '
        'Label1
        '
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(224, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Label1"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer3
        '
        Me.Timer3.Enabled = True
        Me.Timer3.Interval = 5000
        Me.Timer3.SynchronizingObject = Me
        '
        'Main
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(247, Byte), CType(232, Byte))
        Me.ClientSize = New System.Drawing.Size(240, 325)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.TreeView1})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.MainMenu1
        Me.Name = "Main"
        Me.Text = "CE.Messenger"
        CType(Me.Timer1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Timer2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Timer3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        iAlert = False
        iNewsAlert = False

        LoadGroupList()
        ChangeStatus(1)
        CreateContactList()

    End Sub

    Public Sub CreateContactList()
        Dim i As Long
        Dim svr As New WebReference1.Service1()
        Dim tDS As DataSet

        TreeView1.Nodes.Clear()

        Try
            If svr.GetContactList(uName, tDS) = True Then
                If tDS.Tables(0).Rows.Count > 0 Then
                    Dim tb As DataTable
                    Dim rw As DataRow
                    Dim cg As String
                    Dim nd As TreeNode
                    Dim sn As TreeNode

                    cg = ""
                    tb = tDS.Tables(0)
                    For i = 0 To tb.Rows.Count - 1

                        rw = tb.Rows(i)
                        If cg <> rw(0) Then 'Change Group
                            If cg <> "" Then
                                TreeView1.Nodes.Add(nd)
                            End If
                            cg = rw(0)
                            nd = New TreeNode(rw(0), 0, 0)
                        End If

                        If rw(6) Is DBNull.Value Then
                            If rw(4) = False Then
                                sn = New TreeNode(rw(3), 3, 3)
                                sn.Tag = rw(2)
                                nd.Nodes.Add(sn)
                            Else
                                sn = New TreeNode(rw(3), 17, 17)
                                sn.Tag = rw(2)
                                nd.Nodes.Add(sn)
                            End If
                        Else
                            If rw(4) = False Then
                                Select Case rw(6)
                                    Case Is = 1 'Online
                                        sn = New TreeNode(rw(3), 5, 5)
                                        sn.Tag = rw(2)
                                        nd.Nodes.Add(sn)
                                    Case Is = 2 'Away
                                        sn = New TreeNode(rw(3), 2, 2)
                                        sn.Tag = rw(2)
                                        nd.Nodes.Add(sn)
                                    Case Else
                                        sn = New TreeNode(rw(3), 3, 3)
                                        sn.Tag = rw(2)
                                        nd.Nodes.Add(sn)
                                End Select
                            Else
                                Select Case rw(6)
                                    Case Is = 1 'Online
                                        sn = New TreeNode(rw(3), 19, 19)
                                        sn.Tag = rw(2)
                                        nd.Nodes.Add(sn)
                                    Case Is = 2 'Away
                                        sn = New TreeNode(rw(3), 16, 16)
                                        sn.Tag = rw(2)
                                        nd.Nodes.Add(sn)
                                    Case Else
                                        sn = New TreeNode(rw(3), 17, 17)
                                        sn.Tag = rw(2)
                                        nd.Nodes.Add(sn)
                                End Select
                            End If
                        End If
                    Next i

                    TreeView1.Nodes.Add(nd)
                    TreeView1.ExpandAll()
                End If
            Else
                MsgBox("Fail to create contact list...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Public Sub RefreshContactList()
        Dim i As Long
        Dim svr As New WebReference1.Service1()
        Dim tDS As DataSet

        Try
            If svr.GetContactList(uName, tDS) = True Then
                If tDS.Tables(0).Rows.Count > 0 Then
                    Dim tb As DataTable
                    Dim rw As DataRow
                    Dim cg As String
                    Dim nd As TreeNode
                    Dim sn As TreeNode

                    cg = ""
                    tb = tDS.Tables(0)
                    For i = 0 To tb.Rows.Count - 1

                        rw = tb.Rows(i)

                        Dim xn As TreeNode
                        Dim xc As TreeNode
                        Dim pn As TreeNode
                        Dim fd As Boolean

                        'Traverse Tree
                        For Each xn In TreeView1.Nodes
                            For Each xc In xn.Nodes
                                If xc.Tag = rw(2) Then

                                    xc.Text = rw(3)
                                    If rw(6) Is DBNull.Value Then
                                        If rw(4) = False Then
                                            xc.ImageIndex = 3
                                            xc.SelectedImageIndex = 3
                                        Else
                                            xc.ImageIndex = 17
                                            xc.SelectedImageIndex = 17
                                        End If
                                    Else
                                        If rw(4) = False Then
                                            Select Case rw(6)
                                                Case Is = 1
                                                    If xc.ImageIndex <> 5 Then NotifySignin(rw(2), rw(3))
                                                    xc.ImageIndex = 5
                                                    xc.SelectedImageIndex = 5
                                                Case Is = 2
                                                    xc.ImageIndex = 2
                                                    xc.SelectedImageIndex = 2
                                                Case Else
                                                    xc.ImageIndex = 3
                                                    xc.SelectedImageIndex = 3
                                            End Select
                                        Else
                                            Select Case rw(6)
                                                Case Is = 1
                                                    If xc.ImageIndex <> 19 Then NotifySignin(rw(2), rw(3))
                                                    xc.ImageIndex = 19
                                                    xc.SelectedImageIndex = 19
                                                Case Is = 2
                                                    xc.ImageIndex = 16
                                                    xc.SelectedImageIndex = 16
                                                Case Else
                                                    xc.ImageIndex = 17
                                                    xc.SelectedImageIndex = 17
                                            End Select
                                        End If
                                    End If

                                    If xn.Text <> rw(0) Then 'Change Group                                   'Change Group
                                        fd = False
                                        For Each pn In TreeView1.Nodes
                                            If pn.Text = rw(0) Then
                                                pn.Nodes.Add(xc)
                                                fd = True
                                            End If
                                        Next pn
                                        If fd = False Then
                                            nd = New TreeNode(rw(0), 0, 0)
                                            nd.Nodes.Add(xc)
                                            TreeView1.Nodes.Add(nd)
                                        End If

                                        xn.Nodes.Remove(xc)

                                    End If
                                End If
                            Next xc
                        Next xn

                    Next i
                    TreeView1.Refresh()
                End If
            Else
                MsgBox("Fail to refresh contact list...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Timer1_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles Timer1.Elapsed

        Dim svr As New WebReference1.Service1()
        Dim sesID As String

        Try
            If svr.UserReActivate(uSes, uName, uWkst) = False Then
                Me.Timer1.Enabled = False
                MsgBox("Fail to reactivate this session..." + Chr(13) + Chr(10) + "Program is automatically forced to log off...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                Me.Dispose()
            End If
            RefreshContactList()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub Main_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed

        Dim svr As New WebReference1.Service1()
        Dim sesID As String

        Try
            svr.UserLogOff(uSes, uName, uWkst)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        Me.Dispose()
    End Sub

    Private Sub TreeView1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles TreeView1.DoubleClick

        If TreeView1.SelectedNode.SelectedImageIndex <> 0 Then
            Dim m As GMsgApp.Message
            m = RegisterMessage(TreeView1.SelectedNode.Tag, TreeView1.SelectedNode.Text)
            m.Show()
        End If
    End Sub

    Private Sub Main_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Resize

        TreeView1.Width = Me.Width - 24
        TreeView1.Height = Me.Height - 105

    End Sub

    Private Sub Timer2_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles Timer2.Elapsed
        GetMessage()
    End Sub

    Private Sub ChangeStatus(ByVal s As Byte)
        Dim svr As New WebReference1.Service1()

        Try
            If svr.UpdateStatus(uSes, uName, s) = True Then
                Status = s
                Label1.Text = StatusInfo(Status)
            Else
                Status = 0
                Label1.Text = StatusInfo(Status)
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub MenuItem13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem13.Click
        ChangeStatus(1)
    End Sub

    Private Sub MenuItem14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem14.Click
        ChangeStatus(2)
    End Sub

    Private Sub MenuItem15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem15.Click
        ChangeStatus(3)
    End Sub

    Private Sub MenuItem22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem22.Click
        TreeView1_DoubleClick(sender, e)
    End Sub

    Private Sub MenuItem24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem24.Click

        If TreeView1.SelectedNode.SelectedImageIndex <> 0 Then
            If TreeView1.SelectedNode.SelectedImageIndex < 14 Then

                Dim svr As New WebReference1.Service1()

                Try

                    If svr.UpdateBlockContact(uName, TreeView1.SelectedNode.Tag, True) = False Then
                        MsgBox("Unable to block this contact...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                    Else
                        MsgBox("Contact has been blocked...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                        RefreshContactList()
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            Else
                MsgBox("This contact has already been blocked...", MsgBoxStyle.Exclamation + MsgBoxStyle.OKOnly)
            End If
        End If

    End Sub

    Private Sub MenuItem23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem23.Click

        If TreeView1.SelectedNode.SelectedImageIndex <> 0 Then
            If TreeView1.SelectedNode.SelectedImageIndex > 14 Then

                Dim svr As New WebReference1.Service1()

                Try

                    If svr.UpdateBlockContact(uName, TreeView1.SelectedNode.Tag, False) = False Then
                        MsgBox("Unable to unblock this contact...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                    Else
                        MsgBox("Contact has been unblocked...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                        RefreshContactList()
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            Else
                MsgBox("This contact has already been unblocked...", MsgBoxStyle.Exclamation + MsgBoxStyle.OKOnly)
            End If
        End If

    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        MenuItem24_Click(sender, e)
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
        MenuItem23_Click(sender, e)
    End Sub

    Private Sub MenuItem19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem19.Click

        If TreeView1.SelectedNode.SelectedImageIndex <> 0 Then

            If MsgBox("Do you want to delete this contact?", MsgBoxStyle.Exclamation + MsgBoxStyle.YesNo) = MsgBoxResult.Yes Then

                Dim svr As New WebReference1.Service1()

                Try

                    If svr.DeleteContact(uName, TreeView1.SelectedNode.Tag) = False Then
                        MsgBox("Unable to delete this contact...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                    Else
                        MsgBox("Contact has been deleted...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                        CreateContactList()
                    End If

                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try

            End If
        End If
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        MenuItem19_Click(sender, e)
    End Sub

    Private Sub MenuItem17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem17.Click
        Dim ac As New AddContact()
        ac.ShowDialog(Me)
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        MenuItem17_Click(sender, e)
    End Sub

    Private Sub MenuItem30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem30.Click

        If TreeView1.SelectedNode.SelectedImageIndex <> 0 Then

            Dim svr As New WebReference1.Service1()
            Dim tDS As DataSet

            Try

                If svr.GetContactInfo(uName, TreeView1.SelectedNode.Tag, tDS) = False Then
                    MsgBox("Unable to get this contact info...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                Else
                    Dim ci As New ContactInfo()
                    ci.Label3.Text = tDS.Tables(0).Rows(0)(0)
                    ci.Label4.Text = tDS.Tables(0).Rows(0)(1)
                    ci.Label5.Text = tDS.Tables(0).Rows(0)(2)
                    ci.ShowDialog(Me)
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If

    End Sub

    Private Sub MenuItem33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem33.Click
        MenuItem30_Click(sender, e)
    End Sub

    Private Sub MenuItem27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem27.Click
        Dim NG As String
        NG = InputBox("Enter New Group Name", "Add Contact Group")

        If NG <> "" Then

            Dim svr As New WebReference1.Service1()

            Try
                If svr.AddGroup(uName, NG) = False Then
                    MsgBox("Unable to add this contact group...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                Else
                    MsgBox("Contact Group has been added...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                    LoadGroupList()
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub MenuItem28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem28.Click
        Dim OG As String
        Dim NG As String

        OG = InputBox("Enter Old Group Name", "Rename Contact Group")
        NG = InputBox("Enter New Group Name", "Rename Contact Group")

        If OG <> "" And NG <> "" Then

            Dim svr As New WebReference1.Service1()

            Try
                If svr.RenameGroup(uName, OG, NG) = False Then
                    MsgBox("Unable to rename this contact group...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                Else
                    MsgBox("Contact Group has been renamed...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                    LoadGroupList()
                    CreateContactList()
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub MenuItem29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem29.Click
        Dim NG As String
        NG = InputBox("Enter Group Name", "Delete Contact Group")

        If NG <> "" Then

            Dim svr As New WebReference1.Service1()

            Try
                If svr.DeleteGroup(uName, NG) = False Then
                    MsgBox("Unable to delete this contact group..." + Chr(10) + Chr(13) + "Contact Group must be empty to be deleted. 'Other' Group cannot be deleted.", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                Else
                    MsgBox("Contact Group has been deleted...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                    LoadGroupList()
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Public Sub LoadGroupList()

        Dim svr As New WebReference1.Service1()
        Dim tDS As DataSet
        Dim rw As DataRow

        MenuItem20.MenuItems.Clear()

        Try
            If svr.GetContactGroupList(uName, tDS) = False Then
                MsgBox("Unable to get contact group list...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
            Else

                For Each rw In tDS.Tables(0).Rows

                    MenuItem20.MenuItems.Add(rw(1), New EventHandler(AddressOf menuItem22s_Click))

                Next rw

            End If

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub

    Private Sub menuItem22s_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim mn As System.Windows.Forms.MenuItem = sender

        If TreeView1.SelectedNode.SelectedImageIndex <> 0 Then

            Dim svr As New WebReference1.Service1()

            Try
                If svr.ChangeContactGroup(uName, TreeView1.SelectedNode.Tag, mn.Text) = False Then
                    MsgBox("Unable to change this contact...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
                Else
                    MsgBox("Contact has been changed...", MsgBoxStyle.Information + MsgBoxStyle.OKOnly)
                    CreateContactList()
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub Timer3_Elapsed(ByVal sender As System.Object, ByVal e As System.Timers.ElapsedEventArgs) Handles Timer3.Elapsed

        Dim svr As New WebReference1.Service1()
        Dim tDS As DataSet

        If pUID <> "" Then

            Try
                If svr.GetAlert(pUID, pPSW, tDS) = True Then
                    Dim rw As DataRow

                    If iAlert = False Then

                        lAlert = New Alert()
                        lAlert.Show()
                        iAlert = True

                    End If

                    Dim nd As TreeNode
                    nd = New TreeNode(Format(Now, "dd/MM/yyyy HH:mm:ss"))
                    nd.Tag = 0

                    For Each rw In tDS.Tables(0).Rows

                        Dim sd As TreeNode
                        sd = New TreeNode(rw("qTopic"))
                        sd.Tag = rw("qid")

                        nd.Nodes.Add(sd)

                        Try
                            svr.GetAlertConfirm(pUID, pPSW, rw("qid"))
                        Catch ex3 As Exception
                        End Try
                    Next rw

                    lAlert.TreeView1.Nodes.Insert(0, nd)
                    lAlert.TreeView1.ExpandAll()

                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

            Try
                If svr.GetNewsAlert(pUID, pPSW, tDS) = True Then
                    Dim rw2 As DataRow

                    If iNewsAlert = False Then

                        lNewsAlert = New NewsAlert()
                        lNewsAlert.Show()
                        iNewsAlert = True

                    End If

                    Dim nd As TreeNode
                    nd = New TreeNode(Format(Now, "dd/MM/yyyy HH:mm:ss"))
                    nd.Tag = 0

                    For Each rw2 In tDS.Tables(0).Rows

                        Dim sd As TreeNode
                        sd = New TreeNode(rw2("title"))
                        sd.Tag = rw2("topicID")

                        nd.Nodes.Add(sd)

                        Try
                            svr.GetNewsAlertConfirm(pUID, pPSW, rw2("topicID"))
                        Catch ex4 As Exception
                        End Try
                    Next rw2

                    lNewsAlert.TreeView1.Nodes.Insert(0, nd)
                    lNewsAlert.TreeView1.ExpandAll()

                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

        End If
    End Sub

    Private Sub MenuItem16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem16.Click
        Dim ab As New About()
        ab.ShowDialog()
    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        System.Diagnostics.Process.Start("http://161.246.6.64/cemsgweb/editprofile.aspx")
    End Sub
End Class
