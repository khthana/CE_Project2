Public Class Message
    Inherits System.Windows.Forms.Form

    Private dUserID As String
    Private dUserName As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Message))
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'RichTextBox1
        '
        Me.RichTextBox1.Location = New System.Drawing.Point(16, 216)
        Me.RichTextBox1.MaxLength = 1024
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(416, 48)
        Me.RichTextBox1.TabIndex = 0
        Me.RichTextBox1.Text = "RichTextBox1"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Contact :"
        '
        'Label2
        '
        Me.Label2.ForeColor = System.Drawing.Color.RoyalBlue
        Me.Label2.Location = New System.Drawing.Point(72, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(360, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Label2"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(360, 272)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(72, 24)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "&Send"
        '
        'RichTextBox2
        '
        Me.RichTextBox2.Location = New System.Drawing.Point(16, 40)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.ReadOnly = True
        Me.RichTextBox2.Size = New System.Drawing.Size(416, 168)
        Me.RichTextBox2.TabIndex = 4
        Me.RichTextBox2.Text = "RichTextBox2"
        '
        'Message
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 310)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.RichTextBox2, Me.Button1, Me.Label2, Me.Label1, Me.RichTextBox1})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Message"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Message"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Property DesUserID() As String
        Get
            Return dUserID
        End Get
        Set(ByVal Value As String)
            dUserID = Value
        End Set
    End Property

    Public Property DesUserName() As String
        Get
            Return dUserName
        End Get
        Set(ByVal Value As String)
            dUserName = Value
        End Set
    End Property

    Private Sub Message_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Label2.Text = dUserName
        Me.Text = "Message - " + dUserName
        RichTextBox1.Text = ""
        RichTextBox2.Text = ""

    End Sub

    Private Sub Message_Closed(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Closed
        RemoveMessage(dUserID)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim svr As New WebReference1.Service1()

        Try
            If svr.SendMessage(uName, dUserID, RichTextBox1.Text) = True Then
                RichTextBox2.AppendText(uDsp + ": " + Format(Now, "yyyy.MM.dd HH:mm:ss") + Chr(13) + Chr(10) + RichTextBox1.Text + Chr(13) + Chr(10))
                RichTextBox2.Refresh()
            Else
                MsgBox("Fail to send this message to receipient...", MsgBoxStyle.Critical + MsgBoxStyle.OKOnly)
            End If
            RichTextBox1.Text = ""
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

    End Sub
End Class
