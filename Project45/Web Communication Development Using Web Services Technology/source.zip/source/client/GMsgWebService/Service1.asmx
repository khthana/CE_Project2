<%@ WebService Language="vb" Codebehind="Service1.asmx.vb" Class="GMsgWebService.Service1" %>
