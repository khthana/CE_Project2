Imports System.Data.SqlTypes
Imports System.Data.SqlClient
Imports System.Web.Services

<WebService(Namespace:="http://tempuri.org/")> _
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "


    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents conSql As System.Data.SqlClient.SqlConnection
    Friend WithEvents cmdSql As System.Data.SqlClient.SqlCommand
    Friend WithEvents adpSql As System.Data.SqlClient.SqlDataAdapter
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.conSql = New System.Data.SqlClient.SqlConnection()
        Me.cmdSql = New System.Data.SqlClient.SqlCommand()
        Me.adpSql = New System.Data.SqlClient.SqlDataAdapter()
        '
        'conSql
        '
        Me.conSql.ConnectionString = "data source=localhost;initial catalog=GMessenger;password=witoons;persist securit" & _
        "y info=True;user id=witoons;workstation id=HW-GAP;packet size=4096"
        '
        'cmdSql
        '
        Me.cmdSql.Connection = Me.conSql
        '
        'adpSql
        '
        Me.adpSql.SelectCommand = Me.cmdSql

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region

    <WebMethod()> Public Function UserLogin(ByVal UserID As String, ByVal Password As String, ByVal WorkStation As String, ByRef sesID As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_user_login]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@WorkStation", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = Password
        adpSql.SelectCommand.Parameters(3).Value = WorkStation
        Try
            adpSql.Fill(Temp)
            If Temp.Tables(0).Rows.Count = 0 Then
                sesID = "Unable to verify this user..."
                Return False
            End If
        Catch ex As SqlException
            sesID = ex.Message
            Return False
        End Try
        sesID = Convert.ToString(Temp.Tables(0).Rows(0).Item(0))
        Return True
    End Function

    <WebMethod()> Public Function UserLogOff(ByVal SesID As String, ByVal UserID As String, ByVal WorkStation As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_user_session_finish]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@sesID", System.Data.SqlDbType.UniqueIdentifier))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@WorkStation", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        Try
            adpSql.SelectCommand.Parameters(1).Value = New System.Guid(SesID)
        Catch ex0 As Exception
            Return False
        End Try
        adpSql.SelectCommand.Parameters(2).Value = UserID
        adpSql.SelectCommand.Parameters(3).Value = WorkStation
        Try
            adpSql.Fill(Temp)
        Catch ex As SqlException
            Return False
        End Try
        Return True
    End Function

    <WebMethod()> Public Function UserReActivate(ByVal SesID As String, ByVal UserID As String, ByVal WorkStation As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_user_session_active_confirm]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@sesID", System.Data.SqlDbType.UniqueIdentifier))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@WorkStation", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        Try
            adpSql.SelectCommand.Parameters(1).Value = New System.Guid(SesID)
        Catch ex0 As Exception
            Return False
        End Try
        adpSql.SelectCommand.Parameters(2).Value = UserID
        adpSql.SelectCommand.Parameters(3).Value = WorkStation
        Try
            adpSql.Fill(Temp)

            If Temp.Tables(0).Rows.Count = 0 Then
                Return False
            Else
                Return Temp.Tables(0).Rows(0).Item(0)
            End If
        Catch ex As SqlException
            Return False
        End Try
        Return True
    End Function

    <WebMethod()> Public Function GetContactList(ByVal UserID As String, ByRef Result As DataSet) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_get_contact_list]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        Try
            adpSql.Fill(Temp)

            Result = Temp
            Return True

        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetUserInfo(ByVal UserID As String, ByRef Result As DataSet) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_get_user_info]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        Try
            adpSql.Fill(Temp)

            Result = Temp
            Return True

        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function SendMessage(ByVal UserID As String, ByVal DesUserID As String, ByVal Msg As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_send_message]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DesUserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Msg", System.Data.SqlDbType.VarChar, 1024))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = DesUserID
        adpSql.SelectCommand.Parameters(3).Value = Msg
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetMessage(ByVal UserID As String, ByRef Result As DataSet) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_get_message]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        Try
            adpSql.Fill(Temp)

            Result = Temp
            Return True

        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetMessageConfirm(ByVal UserID As String, ByVal TimeStamp As DateTime) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_get_message_confirm]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@TimeStamp", System.Data.SqlDbType.DateTime))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = TimeStamp
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function UpdateStatus(ByVal SesID As String, ByVal UserID As String, ByVal Status As Byte) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_update_status]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@sesID", System.Data.SqlDbType.UniqueIdentifier))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Status", System.Data.SqlDbType.TinyInt))

        adpSql.SelectCommand = cmdSql
        Try
            adpSql.SelectCommand.Parameters(1).Value = New System.Guid(SesID)
        Catch ex0 As Exception
            Return False
        End Try
        adpSql.SelectCommand.Parameters(2).Value = UserID
        adpSql.SelectCommand.Parameters(3).Value = Status
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try
        Return True
    End Function

    <WebMethod()> Public Function UpdateBlockContact(ByVal UserID As String, ByVal DesUserID As String, ByVal Blocked As Boolean) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_update_block_contact]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DesUserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Blocked", System.Data.SqlDbType.Bit))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = DesUserID
        adpSql.SelectCommand.Parameters(3).Value = Blocked
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function DeleteContact(ByVal UserID As String, ByVal DesUserID As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_delete_contact]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DesUserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = DesUserID
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function AddContact(ByVal UserID As String, ByVal DesUserID As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_add_contact]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DesUserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = DesUserID
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function AddGroup(ByVal UserID As String, ByVal ContactGroupCode As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_add_group]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactGroupCode", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = ContactGroupCode
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function RenameGroup(ByVal UserID As String, ByVal oldContactGroupCode As String, ByVal ContactGroupCode As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_rename_group]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@oldContactGroupCode", System.Data.SqlDbType.VarChar, 20))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactGroupCode", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = oldContactGroupCode
        adpSql.SelectCommand.Parameters(3).Value = ContactGroupCode
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function DeleteGroup(ByVal UserID As String, ByVal ContactGroupCode As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_delete_group]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactGroupCode", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = ContactGroupCode
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetContactInfo(ByVal UserID As String, ByVal DesUserID As String, ByRef Result As DataSet) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_get_contact_info]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DesUserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = DesUserID
        Try
            adpSql.Fill(Temp)
            Result = Temp
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetContactGroupList(ByVal UserID As String, ByRef Result As DataSet) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_get_contact_group_list]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        Try
            adpSql.Fill(Temp)
            Result = Temp
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function ChangeContactGroup(ByVal UserID As String, ByVal DesUserID As String, ByVal ContactGroupCode As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_change_contact_group]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@DesUserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ContactGroupCode", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = DesUserID
        adpSql.SelectCommand.Parameters(3).Value = ContactGroupCode
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetAlert(ByVal aUserID As String, ByVal aUserPassword As String, ByRef Result As DataSet) As Boolean

        Dim sConn As New ADODB.Connection()
        Dim sCmd As New ADODB.Command()
        Dim sRs As New ADODB.Recordset()
        Dim Temp As New DataSet()

        Temp.Tables.Add(New DataTable("alert"))
        Dim tb As DataTable = Temp.Tables(0)
        Dim rw As DataRow
        tb.Columns.Add(New DataColumn("userID", System.Type.GetType("System.String")))
        tb.Columns.Add(New DataColumn("qID", System.Type.GetType("System.Int32")))
        tb.Columns.Add(New DataColumn("qTopic", System.Type.GetType("System.String")))

        Try
            sConn.ConnectionString = "DSN=Passport;user id=gap;password=gap;"

            sConn.Open()

            sCmd.ActiveConnection = sConn
            sCmd.CommandText = "select a.*, q.q_topic from alert a, user u, board_question q where a.userID = u.id and u.id = '" + aUserID + "' and u.Password = '" + myMD5(aUserPassword) + "' and a.qID = q.q_id"

            sRs = sCmd.Execute

            If sRs.EOF = False Then

                Do While sRs.EOF = False

                    rw = tb.NewRow()
                    rw(0) = sRs(0).Value
                    rw(1) = sRs(1).Value
                    rw(2) = sRs(2).Value
                    tb.Rows.Add(rw)

                    sRs.MoveNext()
                Loop

                Result = Temp

                Return True
            Else
                Return False
            End If

            sConn.Close()

        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Function myHEX(ByVal ip As Byte) As String
        Dim s As String
        s = Hex(ip)
        If Len(s) = 1 Then s = "0" + s
        Return s
    End Function

    Public Function myMD5(ByVal ip As String) As String

        Dim data(Len(ip) - 1) As Byte
        Dim i As Long

        For i = 0 To Len(ip) - 1
            data(i) = Asc(ip.Chars(i))
        Next i

        Dim md5 As New System.Security.Cryptography.MD5CryptoServiceProvider()

        Dim result As Byte() = md5.ComputeHash(data)

        Dim op As String

        op = ""
        For i = 0 To result.Length - 1
            op += myHEX(result(i))
        Next

        Return op
    End Function

    <WebMethod()> Public Function GetAlertConfirm(ByVal aUserID As String, ByVal aUserPassword As String, ByVal qID As Int32) As Boolean

        Dim sConn As New ADODB.Connection()
        Dim sCmd As New ADODB.Command()
        Dim sRs As New ADODB.Recordset()

        Try
            sConn.ConnectionString = "DSN=Passport;user id=gap;password=gap;"

            sConn.Open()

            sCmd.ActiveConnection = sConn
            sCmd.CommandText = "select u.* from user u where u.id = '" + aUserID + "' and u.Password = '" + myMD5(aUserPassword) + "'"

            sRs = sCmd.Execute

            If sRs.EOF = True Then
                Return False
            End If

            sConn.Close()

        Catch ex As Exception
            Return False
        End Try

        Try
            sConn.ConnectionString = "DSN=Passport;user id=gap;password=gap;"

            sConn.Open()

            sCmd.ActiveConnection = sConn
            sCmd.CommandText = "delete from alert where userID = '" + aUserID + "' and qID = " + Format(qID, "0")

            sRs = sCmd.Execute

            Return True

            sConn.Close()

        Catch ex As Exception
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetNewsAlert(ByVal aUserID As String, ByVal aUserPassword As String, ByRef Result As DataSet) As Boolean

        Dim sConn As New ADODB.Connection()
        Dim sCmd As New ADODB.Command()
        Dim sRs As New ADODB.Recordset()
        Dim Temp As New DataSet()

        Temp.Tables.Add(New DataTable("alert"))
        Dim tb As DataTable = Temp.Tables(0)
        Dim rw As DataRow
        tb.Columns.Add(New DataColumn("userID", System.Type.GetType("System.String")))
        tb.Columns.Add(New DataColumn("topicID", System.Type.GetType("System.Int32")))
        tb.Columns.Add(New DataColumn("title", System.Type.GetType("System.String")))

        Try
            sConn.ConnectionString = "DSN=Passport;user id=gap;password=gap;"

            sConn.Open()

            sCmd.ActiveConnection = sConn
            sCmd.CommandText = "select a.*, q.title from newsalert a, user u, newstopic q where a.userID = u.id and u.id = '" + aUserID + "' and u.Password = '" + myMD5(aUserPassword) + "' and a.topicID = q.topicid"

            sRs = sCmd.Execute

            If sRs.EOF = False Then

                Do While sRs.EOF = False

                    rw = tb.NewRow()
                    rw(0) = sRs(0).Value
                    rw(1) = sRs(1).Value
                    rw(2) = sRs(2).Value
                    tb.Rows.Add(rw)

                    sRs.MoveNext()
                Loop

                Result = Temp

                Return True
            Else
                Return False
            End If

            sConn.Close()

        Catch ex As Exception
            Return False
        End Try

    End Function

    <WebMethod()> Public Function GetNewsAlertConfirm(ByVal aUserID As String, ByVal aUserPassword As String, ByVal topicID As Int32) As Boolean

        Dim sConn As New ADODB.Connection()
        Dim sCmd As New ADODB.Command()
        Dim sRs As New ADODB.Recordset()

        Try
            sConn.ConnectionString = "DSN=Passport;user id=gap;password=gap;"

            sConn.Open()

            sCmd.ActiveConnection = sConn
            sCmd.CommandText = "select u.* from user u where u.id = '" + aUserID + "' and u.Password = '" + myMD5(aUserPassword) + "'"

            sRs = sCmd.Execute

            If sRs.EOF = True Then
                Return False
            End If

            sConn.Close()

        Catch ex As Exception
            Return False
        End Try

        Try
            sConn.ConnectionString = "DSN=Passport;user id=gap;password=gap;"

            sConn.Open()

            sCmd.ActiveConnection = sConn
            sCmd.CommandText = "delete from newsalert where userID = '" + aUserID + "' and topicID = " + Format(topicID, "0")

            sRs = sCmd.Execute

            Return True

            sConn.Close()

        Catch ex As Exception
            Return False
        End Try

    End Function

    <WebMethod()> Public Function InsertUser(ByVal UserID As String, ByVal UserName As String, ByVal Password As String, ByVal NeedAuthorization As Boolean, ByVal pspUserID As String, ByVal pspPassword As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_user_insert]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NeedAuthorization", System.Data.SqlDbType.Bit))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pspUserID", System.Data.SqlDbType.VarChar, 20))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pspPassword", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = UserName
        adpSql.SelectCommand.Parameters(3).Value = Password
        adpSql.SelectCommand.Parameters(4).Value = NeedAuthorization
        adpSql.SelectCommand.Parameters(5).Value = pspUserID
        adpSql.SelectCommand.Parameters(6).Value = pspPassword
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

    <WebMethod()> Public Function ModifyUser(ByVal UserID As String, ByVal oldPassword As String, ByVal UserName As String, ByVal Password As String, ByVal NeedAuthorization As Boolean, ByVal pspUserID As String, ByVal pspPassword As String) As Boolean
        Dim Temp As New DataSet()
        cmdSql.CommandText = "[app_user_mdoify]"
        cmdSql.CommandType = System.Data.CommandType.StoredProcedure
        cmdSql.Connection = Me.conSql
        cmdSql.Parameters.Clear()
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, False, CType(10, Byte), CType(0, Byte), "", System.Data.DataRowVersion.Current, Nothing))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.VarChar, 10))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@oldPassword", System.Data.SqlDbType.VarChar, 50))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.VarChar, 50))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Password", System.Data.SqlDbType.VarChar, 50))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@NeedAuthorization", System.Data.SqlDbType.Bit))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pspUserID", System.Data.SqlDbType.VarChar, 20))
        cmdSql.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pspPassword", System.Data.SqlDbType.VarChar, 20))

        adpSql.SelectCommand = cmdSql
        adpSql.SelectCommand.Parameters(1).Value = UserID
        adpSql.SelectCommand.Parameters(2).Value = oldPassword
        adpSql.SelectCommand.Parameters(3).Value = UserName
        adpSql.SelectCommand.Parameters(4).Value = Password
        adpSql.SelectCommand.Parameters(5).Value = NeedAuthorization
        adpSql.SelectCommand.Parameters(6).Value = pspUserID
        adpSql.SelectCommand.Parameters(7).Value = pspPassword
        Try
            adpSql.Fill(Temp)
            Return True
        Catch ex As SqlException
            Return False
        End Try

    End Function

End Class
