<%@ Page Language="vb" AutoEventWireup="false" Codebehind="EditProfile.aspx.vb" Inherits="CEMsgWeb.EditProfile"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>EditProfile</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma">
				<asp:Image id="Image1" style="Z-INDEX: 101; LEFT: 0px; POSITION: absolute; TOP: 0px" runat="server" ImageUrl="Web-Banner1.jpg" Height="100px" Width="800px"></asp:Image>
				<asp:button id="Button3" style="Z-INDEX: 126; LEFT: 432px; POSITION: absolute; TOP: 208px" runat="server" Width="80px" Text="OK" tabIndex="2"></asp:button>
				<asp:textbox id="Textbox7" style="Z-INDEX: 125; LEFT: 208px; POSITION: absolute; TOP: 168px" runat="server" Width="304px" Font-Size="X-Small" TextMode="Password" MaxLength="50" ForeColor="Teal" tabIndex="1">aaa</asp:textbox>
				<asp:label id="Label8" style="Z-INDEX: 124; LEFT: 64px; POSITION: absolute; TOP: 176px" runat="server" Height="16px" Width="88px" Font-Size="Smaller">Password :</asp:label>
				<asp:textbox id="Textbox6" style="Z-INDEX: 123; LEFT: 64px; POSITION: absolute; TOP: 536px" runat="server" Height="84px" Width="448px" Font-Size="X-Small" Visible="False" TextMode="MultiLine" MaxLength="20" ForeColor="#C00000" tabIndex="11">aaa</asp:textbox>
				<asp:radiobutton id="RadioButton2" style="Z-INDEX: 120; LEFT: 272px; POSITION: absolute; TOP: 328px" runat="server" Height="16px" Width="48px" Font-Size="Smaller" Text="No" Enabled="False" tabIndex="6"></asp:radiobutton>
				<asp:textbox id="TextBox5" style="Z-INDEX: 118; LEFT: 208px; POSITION: absolute; TOP: 424px" runat="server" Width="153px" Font-Size="X-Small" TextMode="Password" MaxLength="20" ForeColor="Teal" Enabled="False" tabIndex="8">aaa</asp:textbox>
				<asp:textbox id="TextBox4" style="Z-INDEX: 117; LEFT: 208px; POSITION: absolute; TOP: 400px" runat="server" Width="153px" Font-Size="X-Small" MaxLength="20" ForeColor="Teal" Enabled="False" tabIndex="7">aaa</asp:textbox>
				<asp:textbox id="TextBox3" style="Z-INDEX: 116; LEFT: 208px; POSITION: absolute; TOP: 296px" runat="server" Width="304px" Font-Size="X-Small" TextMode="Password" MaxLength="50" ForeColor="Teal" Enabled="False" tabIndex="4">aaa</asp:textbox>
				<asp:textbox id="TextBox2" style="Z-INDEX: 115; LEFT: 208px; POSITION: absolute; TOP: 272px" runat="server" Width="304px" Font-Size="X-Small" MaxLength="50" ForeColor="Teal" Enabled="False" tabIndex="3">aaa</asp:textbox>
				<asp:label id="Label7" style="Z-INDEX: 112; LEFT: 64px; POSITION: absolute; TOP: 376px" runat="server" Height="16px" Width="336px" Font-Size="Smaller" ForeColor="#FF8000">For CE - Web Board and News Alert Service</asp:label>
				<asp:label id="Label6" style="Z-INDEX: 111; LEFT: 64px; POSITION: absolute; TOP: 432px" runat="server" Height="16px" Width="88px" Font-Size="Smaller">psp Password :</asp:label>
				<asp:label id="Label5" style="Z-INDEX: 110; LEFT: 64px; POSITION: absolute; TOP: 408px" runat="server" Height="16px" Width="88px" Font-Size="Smaller">psp UserID :</asp:label>
				<asp:label id="Label4" style="Z-INDEX: 109; LEFT: 64px; POSITION: absolute; TOP: 328px" runat="server" Height="16px" Width="120px" Font-Size="Smaller">Need Authorization :</asp:label>
				<asp:label id="Label3" style="Z-INDEX: 108; LEFT: 64px; POSITION: absolute; TOP: 304px" runat="server" Height="16px" Width="120px" Font-Size="Smaller">New Password :</asp:label>
				<asp:label id="Label2" style="Z-INDEX: 107; LEFT: 64px; POSITION: absolute; TOP: 280px" runat="server" Height="16px" Width="88px" Font-Size="Smaller">User Name :</asp:label>
				<asp:label id="Label1" style="Z-INDEX: 105; LEFT: 64px; POSITION: absolute; TOP: 152px" runat="server" Height="16px" Width="88px" Font-Size="Smaller">UserID :</asp:label>
				<asp:hyperlink id="HyperLink5" style="Z-INDEX: 113; LEFT: 64px; POSITION: absolute; TOP: 456px" runat="server" Height="16px" Width="88px" NavigateUrl="http://161.246.6.54/passport/register_form.php" Font-Size="Smaller" Target="_blank">Register Now!</asp:hyperlink>
				<asp:textbox id="TextBox1" style="Z-INDEX: 114; LEFT: 208px; POSITION: absolute; TOP: 144px" runat="server" Width="153px" Font-Size="X-Small" MaxLength="10" ForeColor="Teal">aaa</asp:textbox>
				<asp:radiobutton id="RadioButton1" style="Z-INDEX: 119; LEFT: 208px; POSITION: absolute; TOP: 328px" runat="server" Height="16px" Width="48px" Font-Size="Smaller" Text="Yes" Checked="True" Enabled="False" tabIndex="5"></asp:radiobutton>
				<asp:button id="Button1" style="Z-INDEX: 121; LEFT: 64px; POSITION: absolute; TOP: 496px" runat="server" Width="80px" Text="Clear" Enabled="False" tabIndex="9"></asp:button>
				<asp:button id="Button2" style="Z-INDEX: 122; LEFT: 152px; POSITION: absolute; TOP: 496px" runat="server" Width="80px" Text="Submit" Enabled="False" tabIndex="10"></asp:button>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 106; LEFT: 0px; POSITION: absolute; TOP: 96px" runat="server" Height="24px" Width="88px" NavigateUrl="http://161.246.6.64/CEMsgWeb/index.aspx" BackColor="#E7FFDD" Font-Size="X-Small">Home</asp:HyperLink>
				<asp:HyperLink id="HyperLink2" style="Z-INDEX: 102; LEFT: 88px; POSITION: absolute; TOP: 96px" runat="server" Height="24px" Width="88px" NavigateUrl="http://161.246.6.64/CEMsgWeb/register.aspx" BackColor="#E7FFDD" Font-Size="X-Small">Register!</asp:HyperLink>
				<asp:HyperLink id="HyperLink3" style="Z-INDEX: 103; LEFT: 176px; POSITION: absolute; TOP: 96px" runat="server" Height="24px" Width="88px" NavigateUrl="http://161.246.6.64/CEMsgWeb/editprofile.aspx" BackColor="#E7FFDD" Font-Size="X-Small">Edit Profile</asp:HyperLink>
				<asp:HyperLink id="HyperLink4" style="Z-INDEX: 104; LEFT: 264px; POSITION: absolute; TOP: 96px" runat="server" Height="24px" Width="536px" NavigateUrl="http://161.246.6.64/CEMsgWeb/GMsgApp.exe" BackColor="#E7FFDD" Font-Size="X-Small" Target="_blank">Download</asp:HyperLink>
				<asp:Label id="Label9" style="Z-INDEX: 127; LEFT: 528px; POSITION: absolute; TOP: 304px" runat="server" Height="16px" Width="160px" Font-Size="Smaller">Leave blank for unchange</asp:Label></FONT>
		</form>
	</body>
</HTML>
