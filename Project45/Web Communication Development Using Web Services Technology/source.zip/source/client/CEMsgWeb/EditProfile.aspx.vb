Public Class EditProfile
    Inherits System.Web.UI.Page
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents RadioButton1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents RadioButton2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Textbox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Textbox7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button3 As System.Web.UI.WebControls.Button
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label

    Private oldpsw As String
    Private psw As String
    Private psw2 As String

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If IsPostBack = False Then
            TextBox1.Text = ""
            Textbox7.Text = ""
            Button1_Click(sender, e)
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        Textbox6.Text = ""
        RadioButton1.Checked = True
        Textbox6.Visible = False
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

        Dim svr As New WebReference1.Service1()
        Dim tDs As DataSet

        oldpsw = Textbox7.Text

        Try
            If svr.GetUserInfo(TextBox1.Text, tDs) = True Then
                If tDs.Tables(0).Rows(0)("Password") = myMD5(oldpsw) Then

                    TextBox2.Text = tDs.Tables(0).Rows(0)("UserName")
                    TextBox3.Text = psw
                    RadioButton1.Checked = tDs.Tables(0).Rows(0)("NeedAuthorization")
                    TextBox4.Text = tDs.Tables(0).Rows(0)("pspUserID")
                    TextBox5.Text = tDs.Tables(0).Rows(0)("pspPassword")
                    psw = tDs.Tables(0).Rows(0)("Password")
                    psw2 = tDs.Tables(0).Rows(0)("pspPassword")

                    TextBox1.Enabled = False
                    Textbox7.Enabled = False

                    Button3.Enabled = False

                    TextBox2.Enabled = True
                    TextBox3.Enabled = True
                    TextBox4.Enabled = True
                    TextBox5.Enabled = True

                    RadioButton1.Enabled = True
                    RadioButton2.Enabled = True

                    Button1.Enabled = True
                    Button2.Enabled = True

                    Textbox6.Enabled = False

                Else
                    Textbox6.Visible = True
                    Textbox6.Text = "Invalid user name or password..."
                End If
            Else
                Textbox6.Visible = True
                Textbox6.Text = "Invalid user name or password..."
            End If

        Catch ex As Exception
            Textbox6.Visible = True
            Textbox6.Text = ex.Message
        End Try

    End Sub

    Public Function myHEX(ByVal ip As Byte) As String
        Dim s As String
        s = Hex(ip)
        If Len(s) = 1 Then s = "0" + s
        Return s
    End Function

    Public Function myMD5(ByVal ip As String) As String

        Dim data(Len(ip) - 1) As Byte
        Dim i As Long

        For i = 0 To Len(ip) - 1
            data(i) = Asc(ip.Chars(i))
        Next i

        Dim md5 As New System.Security.Cryptography.MD5CryptoServiceProvider()

        Dim result As Byte() = md5.ComputeHash(data)

        Dim op As String

        op = ""
        For i = 0 To result.Length - 1
            op += myHEX(result(i))
        Next

        Return op
    End Function

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim svr As New WebReference1.Service1()

        If TextBox3.Text <> "" Then psw = TextBox3.Text
        If TextBox5.Text <> "" Then psw2 = TextBox5.Text
        Try
            If svr.ModifyUser(TextBox1.Text, myMD5(oldpsw), TextBox2.Text, myMD5(psw), RadioButton1.Checked, TextBox4.Text, psw2) = False Then
                Textbox6.Visible = True
                Textbox6.Text = "Fail to update this user... Please check your information."
            Else
                Server.Transfer("index.aspx")
            End If

        Catch ex As Exception
            Textbox6.Visible = True
            Textbox6.Text = ex.Message
        End Try
    End Sub
End Class

