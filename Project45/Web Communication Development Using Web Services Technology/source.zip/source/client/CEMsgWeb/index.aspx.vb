Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Public Function myHEX(ByVal ip As Byte) As String
        Dim s As String
        s = Hex(ip)
        If Len(s) = 1 Then s = "0" + s
        Return s
    End Function

    Public Function myMD5(ByVal ip As String) As String

        Dim data(Len(ip) - 1) As Byte
        Dim i As Long

        For i = 0 To Len(ip) - 1
            data(i) = Asc(ip.Chars(i))
        Next i

        Dim md5 As New System.Security.Cryptography.MD5CryptoServiceProvider()

        Dim result As Byte() = md5.ComputeHash(data)

        Dim op As String

        op = ""
        For i = 0 To result.Length - 1
            op += myHEX(result(i))
        Next

        Return op
    End Function

End Class
