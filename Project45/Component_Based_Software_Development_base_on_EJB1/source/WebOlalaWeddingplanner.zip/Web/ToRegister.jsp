<%@ page contentType = "text/html;charset=WINDOWS-874" import="weblogic.jws.proxies.*" %>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>

<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body  bgcolor="F9F9EF">
<% 	int chklog = 0;
		boolean flag = true;
	   	String username = (String)request.getParameter("username");
		String byteuser = new String(username.getBytes("ISO8859_1"),"MS874");
		String password = (String)request.getParameter("password");
		String bytepwd = new String(password.getBytes("ISO8859_1"),"MS874");
		String passwd = (String)request.getParameter("confirmpwd");
		String byteconfirmpwd = new String(passwd.getBytes("ISO8859_1"),"MS874");

		String M_name =  (String)request.getParameter("M_name");
		String byteM_name = new String(M_name.getBytes("ISO8859_1"),"MS874");
		String M_surname = (String)request.getParameter("M_surname");
		String byteM_surname = new String(M_surname.getBytes("ISO8859_1"),"MS874");

        String M_date = (String)request.getParameter("M_date");
		String byteM_date = new String(M_date.getBytes("ISO8859_1"),"MS874");
        String M_month = (String)request.getParameter("M_month");
        String byteM_month = new String(M_month.getBytes("ISO8859_1"),"MS874");
        String M_year = (String)request.getParameter("M_year");
        String byteM_year = new String(M_year.getBytes("ISO8859_1"),"MS874");
        String byteM_birthdate = byteM_date + "/" + byteM_month + "/" + byteM_year;

         String M_address = (String)request.getParameter("M_address");
         String byteM_address = new String(M_address.getBytes("ISO8859_1"),"MS874");
		String M_address1 = (String)request.getParameter("M_address1");
		String byteM_address1 = new String(M_address1.getBytes("ISO8859_1"),"MS874");
		byteM_address = byteM_address + " " + byteM_address1;

         String M_phone = (String)request.getParameter("M_phone");
		String byteM_phone = new String(M_phone.getBytes("ISO8859_1"),"MS874");
		String M_email = (String)request.getParameter("M_email");
		String byteM_email = new String(M_email.getBytes("ISO8859_1"),"MS874");

		String F_name = (String)request.getParameter("F_name");
		String byteF_name = new String(F_name.getBytes("ISO8859_1"),"MS874");
		String F_surname = (String)request.getParameter("F_surname");
		String byteF_surname = new String(F_surname.getBytes("ISO8859_1"),"MS874");
		String F_date = (String)request.getParameter("F_date");
        String byteF_date = new String(F_date.getBytes("ISO8859_1"),"MS874");
        String F_month = (String)request.getParameter("F_month");
        String byteF_month = new String(F_month.getBytes("ISO8859_1"),"MS874");
        String F_year = (String)request.getParameter("F_year");
        String byteF_year = new String(F_year.getBytes("ISO8859_1"),"MS874");
        String byteF_birthdate = byteF_date + "/" + byteF_month + "/" + byteF_year;

        String F_address = (String)request.getParameter("F_address");
		String byteF_address = new String(F_address.getBytes("ISO8859_1"),"MS874");
		String F_address1 = (String)request.getParameter("F_address1");
		String byteF_address1 = new String(F_address1.getBytes("ISO8859_1"),"MS874");
		byteF_address = byteF_address + " " + byteF_address1;

        String F_phone = (String)request.getParameter("F_phone");
		String byteF_phone = new String(F_phone.getBytes("ISO8859_1"),"MS874");
		String F_email = (String)request.getParameter("F_email");
		String byteF_email = new String(F_email.getBytes("ISO8859_1"),"MS874");
		%>
<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
  <tr> 
    <td align= "center"> 
      <%	if ((username == null)||(username.equals("")))
		{
                  out.println("��سҡ�͡���ͼ����!");
				flag = false;
		}%>
      <p></p>
      <%if ((password.equals(""))||(passwd.equals("")))
                  {
                    out.println("��سҡ�͡���ʼ�ҹ����׹�ѹ���ʼ�ҹ");
					flag = false;%>
      <p></p>
      <%}
                  if (password.length() < 6)
                  {
                    out.println("���ʼ�ҹ��ͧ�ҡ���� 6 ����ѡ��");
					flag = false;%>
      <p></p>
      <%}
                  if (!bytepwd.equals(byteconfirmpwd))
                  {
                    out.println("���ʼ�ҹ�����ҡѺ�׹�ѹ���ʼ�ҹ");
					flag = false;%>
      <p></p>
      <%}
                  if ((M_name.equals(""))||(M_surname.equals(""))||(M_address.equals(""))||(M_phone.equals(""))||(M_email.equals(""))||(F_name.equals(""))||(F_surname.equals(""))||(F_address.equals(""))||(F_phone.equals(""))||(F_email.equals("")))
                  {
                    out.println("��سҡ�͡���������ú�ء��ͧ.");
					flag = false;
                  }%>
      <p></p>
      <%if (flag == true)
		{
			chklog = soapProxy.register(byteM_name,byteM_surname,byteM_birthdate,byteM_phone,byteM_address,byteM_email,byteF_name,byteF_surname,byteF_birthdate,byteF_phone,byteF_address,byteF_email,byteuser,bytepwd);%>
      <%if (chklog!=0)
			{
			response.sendRedirect("Login.jsp");%>
      <br> 
      <%}else
			{
				out.println("Username is Invalid");
			}
		}%>
      <center>
      </center></td>
  </tr>
  <tr> 
    <td width="467"> 
      <%	if ((username == null)||(username.equals(""))||
           (password.length() < 6)||
           (!bytepwd.equals(byteconfirmpwd))||
           (!M_name.equals(""))||(!M_surname.equals(""))||(M_address.equals(""))||(M_phone.equals(""))||(M_email.equals(""))||
           (!F_name.equals(""))||(!F_surname.equals(""))||(F_address.equals(""))||(F_phone.equals(""))||(F_email.equals("")))
        {%>
            <form name="form1" method="post" action="ToRegister.jsp" target = "mainFrame">
              <table align="center" border=0 cellpadding="0" cellspacing="0" width="467">
                <tr>
                  <td align= "left"><center><p><font color="#000099" size="4"> ��سҡ�͡������</font></p>
                    </center>
                    <table width="457" >
                      <tr>
                        <td width="130">���ͼ����</td>
                        <td width="315" ><input type="text" name="username"></td>
                      </tr>
                      <tr>
                        <td>���ʼ�ҹ</td>
                        <td><input type="password" name="password">(���ҧ���� 6 ����ѡ��)</td>
                      </tr>
                      <tr>
                        <td>�׹�ѹ���ʼ�ҹ</td>
                        <td><input type="password" name="confirmpwd">(���ҧ���� 6 ����ѡ��)</td>
                      </tr>
                    </table>
                    <p></p></td>
                </tr>
                <tr>
                    <td width="467"><div align="center"><font color="#000099" size="3">����Ѻ��Һ���</font><BR>
                      </div>
                      <table width="455" border="0">
                        <tr>
                          <td width="123">����</td>
                          <td width="322"> <input width="300" type="text" name="M_name">
                          </td>
                        </tr>
                        <tr>
                          <td>���ʡ��</td>
                          <td><input width="300" name="M_surname" type="text"></td>
                        </tr>
                        <tr>
                          <td>�������</td>
                          <td> <input width="300" type="text" name="M_address">
                          </td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <input width="300" type="text" name="M_address1">
                          </td>
                        </tr>
                        <tr>
                          <td>�ѹ�Դ</td>
                          <td><select name="M_date">
                          <%int i;
                          for (i = 1; i <= 31; i++)
                          {
                          %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                          <%}%>
                            </select>
                            /
                            <select name="M_month">
                            <OPTION value=1 selected>���Ҥ�
                            <OPTION value=2>����Ҿѹ��
                            <OPTION value=3>�չҤ�
                            <OPTION value=4>����¹
                            <OPTION value=5>����Ҥ�
                            <OPTION value=6>�Զع�¹
                            <OPTION value=7>�á�Ҥ�
                            <OPTION value=8>�ԧ�Ҥ�
                            <OPTION value=9>�ѹ��¹
                            <OPTION value=10>���Ҥ�
                            <OPTION value=11>��Ȩԡ�¹
                            <OPTION value=12>�ѹ�Ҥ�
                            </select>
                            /
                            <select name="M_year">
                            <%
                            for (i = 1920;i < 2006; i++)
                            {
                            %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                            <%}%>
                            </select> </td>
                        </tr>
                        <tr>
                          <td height="33">�������Ѿ��</td>
                          <td><input type="text" name="M_phone"> </td>
                        </tr>
                        <tr>
                          <td>�������ʹ���</td>
                          <td><input type="text" name="M_email"></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td>&nbsp; </td>
                        </tr>
                      </table>
                      <div align="center"><font color="#000099" size="3">����Ѻ������</font></div></td>
                </tr>
                <tr>
                  <td><table width="460" border="0">
                        <tr>
                          <td width="122">����</td>
                          <td width="328"> <input width="300" type="text" name="F_name">
                          </td>
                        </tr>
                        <tr>
                          <td>���ʡ��</td>
                          <td><input width="300" type="text" name="F_surname"></td>
                        </tr>
                        <tr>
                          <td>�������</td>
                          <td> <input width="300" type="text" name="F_address">
                          </td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <input width="300" type="text" name="F_address1">
                          </td>
                        </tr>
                        <tr>
                          <td>�ѹ�Դ</td>
                          <td><select name="F_date">
                          <%
                          for (i = 1;i <= 31; i++)
                          {
                          %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                          <%}%>
                            </select>
                            /
                            <select name="F_month">
                            <OPTION value=1 selected>���Ҥ�
                            <OPTION value=2>����Ҿѹ��
                            <OPTION value=3>�չҤ�
                            <OPTION value=4>����¹
                            <OPTION value=5>����Ҥ�
                            <OPTION value=6>�Զع�¹
                            <OPTION value=7>�á�Ҥ�
                            <OPTION value=8>�ԧ�Ҥ�
                            <OPTION value=9>�ѹ��¹
                            <OPTION value=10>���Ҥ�
                            <OPTION value=11>��Ȩԡ�¹
                            <OPTION value=12>�ѹ�Ҥ�
                            </select>
                            /
                            <select name="F_year">
                            <%
                            for (i = 1920;i < 2006; i++)
                            {
                            %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                            <%}%>
                            </select> </td>
                        </tr>
                        <tr>
                          <td>�������Ѿ��</td>
                          <td><input type="text" name="F_phone"> </td>
                        </tr>
                        <tr>
                          <td>�������ʹ���</td>
                          <td><input type="text" name="F_email"></td>
                        </tr>
                      </table></td>
                </tr>
                <tr>
                  <td align="center"><br>
                      <input type="submit" name="Submit" value="ŧ����¹">
                    </td>
                </tr>
              </table>
			 </form>
			 <%}%>
		</td>
  </tr>
</table>
</body>
</html>