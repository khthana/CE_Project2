<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.WeddingContactDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body bgcolor="F9F9EF">
  <%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
  <%		
		int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		String	weddingContactName =(String)session.getAttribute("weddingContactName");
	/*	int weddingID = Integer.parseInt((String)session.getAttribute("weddingContactID"));
		out.print("custID="+Customer_id+"wedding="+weddingContactName+"weddingID="+weddingID);*/
//		String DeadLine = null;
		Date now = new Date();	
		org.openuri.www.WeddingContactDetail[] detail = soapProxy.find_Wedding_Contact(Customer_id);
		%>
<center>
<BR>
	<div align="center">Now You are Choose Contact :<%=weddingContactName%></div><BR>
<table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
  <tr  bgcolor="#FFCCFF">
    <td width="6%">&nbsp;</td>
    <td width="24%"><div align="center">Contact Name</div></td>
    <td width="34%"><div align="center">Deadline Confirm</div></td>
    <td width="18%"><div align="center">�Ҥ�</div></td>
    <td width="18%"><div align="center">&nbsp;</div></td>
    <td width="18%"><div align="center">&nbsp;</div></td>
    </tr>
<%boolean display;int n=0;
	//out.print(detail.length);
	if ((detail != null)&&(detail.length != 0)){
		for (int i = 0 ; i < detail.length ; i ++ ){	
			display=false;
			if(detail[i].getDeadline().equals("-1")||detail[i].getDeadline().equals("0")) 
				{display=true;}
			else
			{	Date deadline=new Date(detail[i].getDeadline());
				if(now.before(deadline)) display=true;
			}//if
			if(display)
		{n++;%>
	<tr>
      <td height="23"><div align="center"><%out.print(n);%>.</div></td>
      <td><div align="center"><a href = "ShowJob.jsp?Wedding_Contact_ID=<%=detail[i].getWeddingContactID()%>&Wedding_Contact_Name=<%=detail[i].getWeddingContactName()%>"><%=detail[i].getWeddingContactName()%></a></div></td>
      <td><div align="center">
	  <%if((detail[i].getDeadline()).equals("-1")) {%>		�����Թ���º����
		<%}else if((detail[i].getDeadline()).equals("0")){%>	contact ����
		  <%}  else{%>	<%=detail[i].getDeadline()%><%}%>
	  </div></td>
      <td><div align="center"><%=detail[i].getAllprice()%></div></td>
	<form name="form1" method="post" action="./CancelWeddingContact.jsp">
	  <td><div align="center">
			<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=detail[i].getWeddingContactID()%>">
			<input type = "hidden" name = "Wedding_Contact_Name" value = "<%=weddingContactName%>">
			<input type = "submit" value = "¡��ԡ��¡�èͧ" name = "cancel" 	 <%if(detail[i].getDeadline().equals("-1")){%> disabled<%}%>>
	</div></td>
	</form>
	<form name="form2" method="post" action="./Payment.jsp">
	  <td><div align="center">
						<%if((detail[i].getDeadline()).equals("-1")){%>
			<input type = "submit" value = "�����Թ" name = "cancel" disabled>
						<%}else{//���%>
			<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=detail[i].getWeddingContactID()%>">
			<input type = "hidden" name = "Wedding_Contact_Name" value = "<%=weddingContactName%>">
			<input type = "hidden" name = "Price" value = "<%=detail[i].getAllprice()%>">
			<input type = "submit" value = "�����Թ" name = "cancel"  <%if(detail[i].getAllprice()==0){%>disabled<%}%>>
						<%}//�ѧ�������Թ%>
	</div></td>
	</form>



</tr>
		<%}}}//for+if%>
  </table>
</center>


<div align="center">
  <p>&nbsp;</p>
  <form name="form3" method="post" action="./CreateWedding.jsp">
    ���ҧ Contact ����&nbsp;:&nbsp;
    <input type="text" name="Wedding_Contact_Name">
	&nbsp;&nbsp;
    <input type="submit" name="Submit" value="��ŧ">
  </form>
  <p>&nbsp;</p>
</div>
</body>
</html>