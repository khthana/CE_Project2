<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.WeddingContactDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>

<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body bgcolor="F9F9EF">
  <%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
  <%
		int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		String tempstr = (String)request.getParameter("Wedding_Contact_Name");
		String Wedding_Contact_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		//int create_Wedding_Contact_ID(int customerID, java.lang.String weddingContactName)
        int Wedding_Contact_ID = soapProxy.create_Wedding_Contact_ID(Customer_id,Wedding_Contact_Name);
		if (Wedding_Contact_ID == 0)
		{
			response.sendRedirect("./Error.htm");
		}
		else response.sendRedirect("./ShowContact.jsp");
		%>
</body>
</html>
