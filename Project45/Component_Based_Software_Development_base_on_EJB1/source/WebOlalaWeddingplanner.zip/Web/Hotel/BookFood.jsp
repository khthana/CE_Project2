<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="java.util.*"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
		String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("hotelD");
		int hotelID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("seminarJobID");
		int seminarJobID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("foodPackageID");
		int foodPackageID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("amount");
		short amount =   Short.parseShort(Temp_Str);

////
		String hour= (String)request.getParameter("Hour");
		String minute= (String)request.getParameter("minute");
		if (hour.length() ==1)
			hour = "0" + hour;
		if (minute.length() == 1)
			minute = "0" + minute;
        String time=hour+":"+minute+":00";
		org.openuri.www.Hotelcontact contact=Hotel.hotel_Contact_List(customerID,weddingContactID);
		int hotelContact=0;
		boolean create = false;
		if ((contact==null)||(contact.getHotelcontact() == 0))   {hotelContact=Hotel.hotelCreateContact("OlalaHotelReserve",hotelID,weddingContactID,customerID);
		create = true;}else
		{hotelContact=contact.getHotelcontact();}

		if (hotelContact !=0){
 //public int hotelCreateContact(java.lang.String contactName, int hotelNumber, int customerId, int weddingContactId)
//        out.print("custID "+customerID+",hotelContact "+hotelContact+",seminarJobID "+seminarJobID+",foodPackageID "+foodPackageID+",serveTime "+time+",amount "+amount+",hotelID "+hotelID+",wedding "+weddingContactID);

org.openuri.www.ReturnReserve result=Hotel.hotelReserveFood(customerID,hotelContact,seminarJobID,foodPackageID,time,amount,hotelID,weddingContactID);
//<!--- public org.openuri.www.ReturnReserve hotelReserveFood(int customerId, int hotelContactId, int seminarRoomJobId, int foodPackageId, java.lang.String sfoodServeTime, short serveAmount, int hotelID, int weddingContactID)

  //public org.openuri.www.Hotelcontact hotel_Contact_List(int customerId, int weddingContactId)
		if(result!=null)
  		if (result.getStrError().equals("success")){
			response.sendRedirect("../ShowJob.jsp#food");
		}else if (create == true){
			boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);	}%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#food">��Ѻ�˹���ʴ���������´ contact</a></center>
			<%}else if (create == true){
				boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#food">��Ѻ�˹���ʴ���������´ contact</a></center>
						<%}%>
</body>
</html>