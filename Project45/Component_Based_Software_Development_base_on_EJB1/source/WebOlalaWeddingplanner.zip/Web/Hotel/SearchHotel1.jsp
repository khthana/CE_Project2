<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
	<title>Olala Wedding Planner : Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<p>&nbsp;</p>
<form name="form1" method="post" action="ResultSearch.jsp">
<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
        <tr> 
          <td align= "left"><p>&nbsp;</p></td>
        </tr>
        <tr> 
          <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                <tr bgcolor="#FFCCFF"> 
                  <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ��ͧ�Ѵ����§</div></td>
                </tr>
                <tr> 
                  <td width="17" height="29">1.</td>
                  <td width="116">Place_Stype</td>
                  <td width="303"> <select name="place_style">
                      <option value="all">-All-</option>
                      <option value="poolside">Poolside</option>
                      <option value="garden">Garden</option>
                      <option value="room">Room</option>
                    </select></td>
                </tr>
                <tr> 
                  <td>2.</td>
                  <td>Dec_Style</td>
                  <td><select name="dec_style">
                      <option value="all">-All-</option>
                      <option value="thai">thai</option>
                      <option value="international">international</option>
                      <option value="chinese">chinese</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>3.</td>
                  <td>RoomSize</td>
                  <td> <input type="text" name="seminar_room_size_min"> between <input type="text" name="seminar_room_size_max"> 
                  </td>
                </tr>
                <tr> 
                  <td>4.</td>
                  <td>Price</td>
                  <td><input type="text" name="seminarminprice"> between <input type="text" name="seminarmaxprice"> 
                  </td>
                </tr>
                <tr> 
                  <td>5.</td>
                  <td>ReserveDate</td>
                  <td><p> 
                      <select name="date">
                        <%
						Date now = new Date();%>
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>01</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>02</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>03</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>04</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>05</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>06</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>07</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>08</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>09</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>10</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>11</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>12</option>
                      <option value = "13" <%if (now.getMonth() == 12) { %><%="selected"%><%}%>>13</option>
                      <option value = "14" <%if (now.getMonth() == 13) { %><%="selected"%><%}%>>14</option>
                      <option value = "15" <%if (now.getMonth() == 14) { %><%="selected"%><%}%>>15</option>
                      <option value = "16" <%if (now.getMonth() == 15) { %><%="selected"%><%}%>>16</option>
                      <option value = "17" <%if (now.getMonth() == 16) { %><%="selected"%><%}%>>17</option>
                      <option value = "18" <%if (now.getMonth() == 17) { %><%="selected"%><%}%>>18</option>
                      <option value = "19" <%if (now.getMonth() == 18) { %><%="selected"%><%}%>>19</option>
                      <option value = "20" <%if (now.getMonth() == 19) { %><%="selected"%><%}%>>20</option>
                      <option value = "21" <%if (now.getMonth() == 20) { %><%="selected"%><%}%>>21</option>
                      <option value = "22" <%if (now.getMonth() == 21) { %><%="selected"%><%}%>>22</option>
                      <option value = "23" <%if (now.getMonth() == 22) { %><%="selected"%><%}%>>23</option>
                      <option value = "24" <%if (now.getMonth() == 23) { %><%="selected"%><%}%>>24</option>
                      <option value = "25" <%if (now.getMonth() == 24) { %><%="selected"%><%}%>>25</option>
                      <option value = "26" <%if (now.getMonth() == 25) { %><%="selected"%><%}%>>26</option>
                      <option value = "27" <%if (now.getMonth() == 26) { %><%="selected"%><%}%>>27</option>
                      <option value = "28" <%if (now.getMonth() == 27) { %><%="selected"%><%}%>>28</option>
                      <option value = "29" <%if (now.getMonth() == 28) { %><%="selected"%><%}%>>29</option>
                      <option value = "30" <%if (now.getMonth() == 29) { %><%="selected"%><%}%>>30</option>
                      <option value = "31" <%if (now.getMonth() == 30) { %><%="selected"%><%}%>>31</option>
                      </select>
                      / 
                      <select name="month">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="year">
                        <option value="2003" selected>2546</option>
                        <option value="2004">2547</option>
                        <option value="2005">2548</option>
                      </select>
                    </p>
                    <p> 
                      <select name="section">
                        <option value="1" selected>6:00 - 11:00</option>
                        <option value="2">12:00 - 17:00</option>
                        <option value="3">18:00 - 23:00</option>
                      </select>
                    </p></td>
                </tr>
                <tr> 
                  <td>6.</td>
                  <td>Cheap</td>
                  <td><input type="radio" name="cheap" value="true">
                    yes 
                    <input type="radio" name="cheap" value="false">
                    no</td>
                </tr>
                <tr> 
                  <td>7.</td>
                  <td><input type="radio" name="region" value="true">
                    Region</td>
                  <td><select name="region">
                  <option value = "0">-- �Ҥ --</option>
                  <option value = "1">�˹��</option>
                  <option value = "2">��ҧ</option>
                  <option value = "3">���ѹ�͡</option>
                  <option value = "4">���ѹ�͡��§�˹��</option>
                  <option value = "5">��</option>
                  <option value = "6">���ѹ��</option>
</select> </td>
                </tr>
                <tr> 
                  <td>8.</td>
                  <td><input type="radio" name="radiobutton" value="radiobutton">
                    District</td>
                  <td><select name="district">
                <option value = "0">-- ࢵ --</option>
                <option value = "1">	��ͧ��	</option>
                <option value = "2">	��ͧ�ҹ	</option>
                <option value = "3">	��ͧ�����	</option>
                <option value = "4">	�ѹ�����	</option>
                <option value = "5">	��بѡ�	</option>
                <option value = "6">	����ͧ	</option>
                <option value = "7">	�͹���ͧ	</option>
                <option value = "8">	�Թᴧ	</option>
                <option value = "9">	���Ե	</option>
                <option value = "10">	���觪ѹ	</option>
                <option value = "11">	����Ѳ��	</option>
                <option value = "12">	��觤��	</option>
                <option value = "13">	������	</option>
                <option value = "14">	�ҧ�͡����	</option>
                <option value = "15">	�ҧ�͡�˭�	</option>
                <option value = "16">	�ҧ�л�	</option>
                <option value = "17">	�ҧ�ع��¹	</option>
                <option value = "18">	�ҧࢹ	</option>
                <option value = "19">	�ҧ������	</option>
                <option value = "20">	�ҧ�	</option>
                <option value = "21">	�ҧ����	</option>
                <option value = "22">	�ҧ��	</option>
                <option value = "23">	�ҧ�͹	</option>
                <option value = "24">	�ҧ��Ѵ	</option>
                <option value = "25">	�ҧ�ѡ	</option>
                <option value = "26">	��觡���	</option>
                <option value = "27">	�����ѹ	</option>
                <option value = "28">	������	</option>
                <option value = "29">	������Һ	</option>
                <option value = "30">	����	</option>
                <option value = "31">	���⢹�	</option>
                <option value = "32">	��й��	</option>
                <option value = "33">	������ԭ	</option>
                <option value = "34">	�չ����	</option>
                <option value = "35">	�ҹ����	</option>
                <option value = "36">	�Ҫ���	</option>
                <option value = "37">	��ɮ���ó�	</option>
                <option value = "38">	�Ҵ��кѧ	</option>
                <option value = "39">	�Ҵ�����	</option>
                <option value = "40">	�ѧ�ͧ��ҧ	</option>
                <option value = "41">	�Ѳ��	</option>
                <option value = "42">	�ǹ��ǧ	</option>
                <option value = "43">	�оҹ�٧	</option>
                <option value = "44">	����ѹ�ǧ��	</option>
                <option value = "45">	�Ҹ�	</option>
                <option value = "46">	������	</option>
                <option value = "47">	˹ͧ��	</option>
                <option value = "48">	˹ͧ�͡	</option>
                <option value = "49">	��ѡ���	</option>
                <option value = "50">	���¢�ҧ	</option>
				</select></td>
                </tr>
                <tr> 
                  <td height="27">9</td>
                  <td>Hotel</td>
                  <td><select name="hotelnumber1">
                      <option value="0" selected>-ALL-</option>
                      <option value="1" >ENTERTAIN1</option>
                      <option value="2">ENTERTAIN2</option>
                      <option value="3">ENTERTAIN3</option>
                      <option value="4">ENTERTAIN4</option>
                      <option value="5">ENTERTAIN5</option>
                      <option value="6">ENTERTAIN6</option>
                      <option value="7">ENTERTAIN7</option>
                      <option value="8">ENTERTAIN8</option>
                      <option value="9">ENTERTAIN9</option>
                      <option value="10">ENTERTAIN10</option>
                    </select></td>
                </tr>
              </table>
            </td>
        </tr>
          <tr> 
            <td colspan="3" align="center">&nbsp;</td>
        </tr>
      </table></td>
  <p align="center">
    <input type="submit" name="Submit4" value="Search">
  </p>

<!----------------------------------------------End Search Seminar------------------------------------------------------------------------------------------>

<!----------------------------------------------Begin Search Room------------------------------------------------------------------------------------------>
	<form name="form1" method="post" action="ResultSearch.jsp">
	<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
        <tr bgcolor="#FFCCFF"> 
          <td align= "left"><p>&nbsp;</p></td>
        </tr>
        <tr> 
          <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                <tr bgcolor="#FFCCFF"> 
                  <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ��ͧ�ѡ</div></td>
                </tr>
                <tr> 
                  <td width="17">1.</td>
                  <td width="116">��Դ�ͧ��ͧ�ѡ:</td>
                  <td width="303"> <select name="room_type">
                      <option value="1">Single</option>
                      <option value="2">twin</option>
                      <option value="3">suite</option>
                    </select></td>
                </tr>
                <tr> 
                  <td>2.</td>
                  <td> �Ҥҵ���ش :</td>
                  <td> <input type="text" name="minpriceroom"> </td>
                </tr>
                <tr> 
                  <td>3.</td>
                  <td>�Ҥ��٧�ش :</td>
                  <td><input type="text" name="maxpriceroom"> </td>
                </tr>
                <tr> 
                  <td>4.</td>
                  <td>Checkindate</td>
                  <td> <select name="date_checkindate">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>01</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>02</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>03</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>04</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>05</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>06</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>07</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>08</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>09</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>10</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>11</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>12</option>
                      <option value = "13" <%if (now.getMonth() == 12) { %><%="selected"%><%}%>>13</option>
                      <option value = "14" <%if (now.getMonth() == 13) { %><%="selected"%><%}%>>14</option>
                      <option value = "15" <%if (now.getMonth() == 14) { %><%="selected"%><%}%>>15</option>
                      <option value = "16" <%if (now.getMonth() == 15) { %><%="selected"%><%}%>>16</option>
                      <option value = "17" <%if (now.getMonth() == 16) { %><%="selected"%><%}%>>17</option>
                      <option value = "18" <%if (now.getMonth() == 17) { %><%="selected"%><%}%>>18</option>
                      <option value = "19" <%if (now.getMonth() == 18) { %><%="selected"%><%}%>>19</option>
                      <option value = "20" <%if (now.getMonth() == 19) { %><%="selected"%><%}%>>20</option>
                      <option value = "21" <%if (now.getMonth() == 20) { %><%="selected"%><%}%>>21</option>
                      <option value = "22" <%if (now.getMonth() == 21) { %><%="selected"%><%}%>>22</option>
                      <option value = "23" <%if (now.getMonth() == 22) { %><%="selected"%><%}%>>23</option>
                      <option value = "24" <%if (now.getMonth() == 23) { %><%="selected"%><%}%>>24</option>
                      <option value = "25" <%if (now.getMonth() == 24) { %><%="selected"%><%}%>>25</option>
                      <option value = "26" <%if (now.getMonth() == 25) { %><%="selected"%><%}%>>26</option>
                      <option value = "27" <%if (now.getMonth() == 26) { %><%="selected"%><%}%>>27</option>
                      <option value = "28" <%if (now.getMonth() == 27) { %><%="selected"%><%}%>>28</option>
                      <option value = "29" <%if (now.getMonth() == 28) { %><%="selected"%><%}%>>29</option>
                      <option value = "30" <%if (now.getMonth() == 29) { %><%="selected"%><%}%>>30</option>
                      <option value = "31" <%if (now.getMonth() == 30) { %><%="selected"%><%}%>>31</option>
                    </select>
                    / 
                    <select name="month_checkindate">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                    </select>
                    / 
                    <select name="year_checkindate">
                      <option value="2003" selected>2546</option>
                      <option value="2004">2547</option>
                      <option value="2005">2548</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>5.</td>
                  <td>Checkoutdate:</td>
                  <td><select name="date_checkoutdate">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>01</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>02</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>03</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>04</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>05</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>06</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>07</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>08</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>09</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>10</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>11</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>12</option>
                      <option value = "13" <%if (now.getMonth() == 12) { %><%="selected"%><%}%>>13</option>
                      <option value = "14" <%if (now.getMonth() == 13) { %><%="selected"%><%}%>>14</option>
                      <option value = "15" <%if (now.getMonth() == 14) { %><%="selected"%><%}%>>15</option>
                      <option value = "16" <%if (now.getMonth() == 15) { %><%="selected"%><%}%>>16</option>
                      <option value = "17" <%if (now.getMonth() == 16) { %><%="selected"%><%}%>>17</option>
                      <option value = "18" <%if (now.getMonth() == 17) { %><%="selected"%><%}%>>18</option>
                      <option value = "19" <%if (now.getMonth() == 18) { %><%="selected"%><%}%>>19</option>
                      <option value = "20" <%if (now.getMonth() == 19) { %><%="selected"%><%}%>>20</option>
                      <option value = "21" <%if (now.getMonth() == 20) { %><%="selected"%><%}%>>21</option>
                      <option value = "22" <%if (now.getMonth() == 21) { %><%="selected"%><%}%>>22</option>
                      <option value = "23" <%if (now.getMonth() == 22) { %><%="selected"%><%}%>>23</option>
                      <option value = "24" <%if (now.getMonth() == 23) { %><%="selected"%><%}%>>24</option>
                      <option value = "25" <%if (now.getMonth() == 24) { %><%="selected"%><%}%>>25</option>
                      <option value = "26" <%if (now.getMonth() == 25) { %><%="selected"%><%}%>>26</option>
                      <option value = "27" <%if (now.getMonth() == 26) { %><%="selected"%><%}%>>27</option>
                      <option value = "28" <%if (now.getMonth() == 27) { %><%="selected"%><%}%>>28</option>
                      <option value = "29" <%if (now.getMonth() == 28) { %><%="selected"%><%}%>>29</option>
                      <option value = "30" <%if (now.getMonth() == 29) { %><%="selected"%><%}%>>30</option>
                      <option value = "31" <%if (now.getMonth() == 30) { %><%="selected"%><%}%>>31</option>
                    </select>
                    / 
                    <select name="month_checkoutdate">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                    </select>
                    / 
                    <select name="year_checkoutdate">
                      <option value="2003" selected>2546</option>
                      <option value="2004">2547</option>
                      <option value="2005">2548</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>6.</td>
                  <td>cheap</td>
                  <td> <input type="radio" name="cheap" value="Yes">
                    YES 
                    <input type="radio" name="cheap" value="No">
                    NO </td>
                </tr>
                <tr> 
                  <td height="27">7.</td>
                  <td><input type="radio" name="checkregion" value="true">
                    Region </td>
                  <td> <select name="region">
                      <option value = "0">-- �Ҥ --</option>
                      <option value = "1">�˹��</option>
                      <option value = "2">��ҧ</option>
                      <option value = "3">���ѹ�͡</option>
                      <option value = "4">���ѹ�͡��§�˹��</option>
                      <option value = "5">��</option>
                      <option value = "6">���ѹ��</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>8.</td>
                  <td><input type="radio" name="check_district" value="ture">
                    District </td>
                  <td> <select name="district">
                      <option value = "0">-- ࢵ --</option>
                      <option value = "1"> ��ͧ�� </option>
                      <option value = "2"> ��ͧ�ҹ </option>
                      <option value = "3"> ��ͧ����� </option>
                      <option value = "4"> �ѹ����� </option>
                      <option value = "5"> ��بѡ� </option>
                      <option value = "6"> ����ͧ </option>
                      <option value = "7"> �͹���ͧ </option>
                      <option value = "8"> �Թᴧ </option>
                      <option value = "9"> ���Ե </option>
                      <option value = "10"> ���觪ѹ </option>
                      <option value = "11"> ����Ѳ�� </option>
                      <option value = "12"> ��觤�� </option>
                      <option value = "13"> ������ </option>
                      <option value = "14"> �ҧ�͡���� </option>
                      <option value = "15"> �ҧ�͡�˭� </option>
                      <option value = "16"> �ҧ�л� </option>
                      <option value = "17"> �ҧ�ع��¹ </option>
                      <option value = "18"> �ҧࢹ </option>
                      <option value = "19"> �ҧ������ </option>
                      <option value = "20"> �ҧ� </option>
                      <option value = "21"> �ҧ���� </option>
                      <option value = "22"> �ҧ�� </option>
                      <option value = "23"> �ҧ�͹ </option>
                      <option value = "24"> �ҧ��Ѵ </option>
                      <option value = "25"> �ҧ�ѡ </option>
                      <option value = "26"> ��觡��� </option>
                      <option value = "27"> �����ѹ </option>
                      <option value = "28"> ������ </option>
                      <option value = "29"> ������Һ </option>
                      <option value = "30"> ���� </option>
                      <option value = "31"> ���⢹� </option>
                      <option value = "32"> ��й�� </option>
                      <option value = "33"> ������ԭ </option>
                      <option value = "34"> �չ���� </option>
                      <option value = "35"> �ҹ���� </option>
                      <option value = "36"> �Ҫ��� </option>
                      <option value = "37"> ��ɮ���ó� </option>
                      <option value = "38"> �Ҵ��кѧ </option>
                      <option value = "39"> �Ҵ����� </option>
                      <option value = "40"> �ѧ�ͧ��ҧ </option>
                      <option value = "41"> �Ѳ�� </option>
                      <option value = "42"> �ǹ��ǧ </option>
                      <option value = "43"> �оҹ�٧ </option>
                      <option value = "44"> ����ѹ�ǧ�� </option>
                      <option value = "45"> �Ҹ� </option>
                      <option value = "46"> ������ </option>
                      <option value = "47"> ˹ͧ�� </option>
                      <option value = "48"> ˹ͧ�͡ </option>
                      <option value = "49"> ��ѡ��� </option>
                      <option value = "50"> ���¢�ҧ </option>
                    </select></td>
                </tr>
				<tr> 
                  <td height="27">7.</td>
                  <td>HotelName</td>
                  <td><select name="hotelnumber2">
                      <option value="0" selected>-ALL-</option>
                      <option value="1" >ENTERTAIN1</option>
                      <option value="2">ENTERTAIN2</option>
                      <option value="3">ENTERTAIN3</option>
                      <option value="4">ENTERTAIN4</option>
                      <option value="5">ENTERTAIN5</option>
                      <option value="6">ENTERTAIN6</option>
                      <option value="7">ENTERTAIN7</option>
                      <option value="8">ENTERTAIN8</option>
                      <option value="9">ENTERTAIN9</option>
                      <option value="10">ENTERTAIN10</option>
                    </select></td>
        </tr>
          <tr> 
            <td colspan="3" align="center">&nbsp;</td>
        </tr>
      </table>

  <p align="center">
    <input type="submit" name="Submit4" value="Search">
  </p>

</form>

  <!----------------------------------------------Begin Search Room------------------------------------------------------------------------------------------>


<table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
  <tr bgcolor="#FFCCFF"> 
    <td colspan="2">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ�����</td>
  </tr>
  <tr> 
    <td width="51%">������</td>
    <td width="49%"><form name="form2">
        <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr>
    <td>����</td>
    <td><form name="form4">
        <select name="menu2" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>�Ҥ�</td>
    <td><form name="form3" method="post" action="">
        <input type="text" name="textfield1" size="10">
        - 
        <input type="text" name="textfield2" size="10">
      </form></td>
  </tr>
  <tr> 
    <td>��ͧ���Ẻ�١�ش</td>
    <td><form name="form5" method="post" action="">
        <input type="radio" name="radiobutton" value="radiobutton">��ͧ���
        <input type="radio" name="radiobutton" value="radiobutton">����ͧ���
      </form></td>
  </tr>
  <tr> 
    <td>��������������</td>
    <td><form name="form6">
        <select name="menu3" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>�ԸդԴ�Ҥ�</td>
    <td><form name="form7">
        <select name="menu4" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>�����ç���</td>
    <td><form name="form8">
        <select name="menu5" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
</table>
  <p align="center">
    <input type="submit" name="Submit4" value="Search">
  </p>
  <!----------------------------------------------Begin Search Room------------------------------------------------------------------------------------------>


<table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
  <tr bgcolor="#FFCCFF"> 
    <td colspan="2">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ��</td>
  </tr>
  <tr> 
    <td width="51%">������</td>
    <td width="49%"><form name="form2">
        <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>�Ҥ�</td>
    <td><form name="form3" method="post" action="">
        <input type="text" name="textfield1" size="10">
        - 
        <input type="text" name="textfield2" size="10">
      </form></td>
  </tr>
  <tr> 
    <td>��ͧ���Ẻ�١�ش</td>
    <td><form name="form5" method="post" action="">
        <input type="radio" name="radiobutton" value="radiobutton">��ͧ���
        <input type="radio" name="radiobutton" value="radiobutton">����ͧ���
      </form></td>
  </tr>
  <tr> 
    <td>�ӹǹ���</td>
    <td><form name="form6">
        <select name="menu3" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>��</td>
    <td><form name="form7">
        <select name="menu4" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
  <tr> 
    <td>��Ҵ</td>
    <td><form name="form7">
        <select name="menu4" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>�����ç���</td>
    <td><form name="form8">
        <select name="menu5" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
</table>
  <p align="center">
    <input type="submit" name="Submit4" value="Search">
  </p>
  <!----------------------------------------------Begin Search Room------------------------------------------------------------------------------------------>


<table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
  <tr bgcolor="#FFCCFF"> 
    <td colspan="2">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ�͡���</td>
  </tr>
  <tr> 
    <td width="51%">������ͧ�����</td>
    <td width="49%"><form name="form2">
        <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
          <option selected>--������--</option>
        </select>
      </form></td>
  </tr>
  <tr> 
    <td>�Ҥ�</td>
    <td><form name="form3" method="post" action="">
        <input type="text" name="textfield1" size="10">
        - 
        <input type="text" name="textfield2" size="10">
      </form></td>
  </tr>
  <tr> 
    <td>��ͧ���Ẻ�١�ش</td>
    <td><form name="form5" method="post" action="">
        <input type="radio" name="radiobutton" value="radiobutton">��ͧ���
        <input type="radio" name="radiobutton" value="radiobutton">����ͧ���
      </form></td>
  </tr>
</table>
  <p align="center">
    <input type="submit" name="Submit4" value="Search">
  </p>

</body>
</html>
