<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;
		
		String cakeStyle = (String)request.getParameter("cakeStyle");

		Temp_Str = (String)request.getParameter("minPrice");
		double minPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("maxPrice");
		double maxPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("layer");
		int layer = Integer.parseInt(Temp_Str);

		String flavour = (String)request.getParameter("flavour");
   	    
		Temp_Str = (String)request.getParameter("cakeSize");
		int cakeSize = Integer.parseInt(Temp_Str);

		boolean cheap=false;
		Temp_Str = (String)request.getParameter("cheap");
		if(Temp_Str.equals("true")) cheap=true;

		Temp_Str = (String)request.getParameter("hotelNumber");
		int hotelNumber = Integer.parseInt(Temp_Str);
org.openuri.www.SearchCakeResult[] rs = Hotel2.hotelSearchCake(cakeStyle,minPrice,maxPrice,layer,flavour,cakeSize,cheap,hotelNumber,0,0);
%>
<center>
<table border="1" bordercolor="#CCCCCC" width = "85%">
  <tr  bgcolor="#FFCCFF"> 
    <td align = "center">����</td>
    <td align = "center">����</td>
    <td align = "center">��Ҵ</td>
    <td align = "center">�ӹǹ���</td>
    <td align = "center">��</td>
    <td align = "center">�����ç���</td>
    <td align = "center">�Ҥ�</td>
  </tr>
<%
	if(rs!=null){
		for(int i=0;i<rs.length;i++)
			if(rs[i]!=null)
		{%>
	  <tr> 
		<td align = "center"><%=rs[i].getCakename()%></td>
		<td align = "center"><%=rs[i].getCakestyle()%></td>
		<td align = "center"><%=rs[i].getCakeSize()%></td>
		<td align = "center"><%=rs[i].getLayer()%></td>
		<td align = "center"><%=rs[i].getFlavour()%></td>
		<td align = "center"><%=rs[i].getCakePrice()%></td>
		<td align = "center"><%=rs[i].getHotelName()%></td>
	 </tr>
</form>
<%
		}}//for
%>
</table>
<form name="form1" method="post" action="./SearchNoLog.jsp" target = "mainFrame">
    <input type="submit" name="Submit" value="Back">
  </form>
</center>
</body>
</html>