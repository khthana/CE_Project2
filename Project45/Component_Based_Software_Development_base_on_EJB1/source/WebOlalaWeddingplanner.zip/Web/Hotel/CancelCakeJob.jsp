<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head><title>Olala Wedding Planner : Cancel Job Room</title></head>
<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String tempstr = (String)request.getParameter("Hotel_Contact_ID");
    int Hotel_Contact_ID = Integer.parseInt(tempstr);
    tempstr = (String)request.getParameter("Cake_Job_ID");
    int Cake_Job_ID = Integer.parseInt(tempstr);
	tempstr =(String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);
    tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	//boolean hotelCancelCake(int customerId, int hotelContactId, int cakeJobId, int weddingContactID)
    boolean cancel = Hotel.hotelCancelCake(Customer_id,Hotel_Contact_ID,Cake_Job_ID,Wedding_Contact_ID);
    if (cancel == true)
    {
		//org.openuri.www.ShowAllJobid hotelShowJobID(int customerId, int hotelContactId, int hotelNumber)
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(Customer_id,Hotel_Contact_ID,Hotel_ID);
		int[] roomjob = alljob.getRoomJobId();
		int[] seminarjob = alljob.getSeminarRoomJobId();
		int[] cakejob = alljob.getCakeJobId();
		int[] foodjob = alljob.getFoodJobId();
		int[] flowerjob = alljob.getFlowerJobId();
		if ((alljob == null)||((roomjob[0]==0)&&(seminarjob[0]==0)&&(cakejob[0]==0)&&(foodjob[0]==0)&&(flowerjob[0]==0)))
		{
			//boolean hotelCancelContact(int weddingContactID, int hotelContactId)
			boolean cancelcontact = Hotel.hotelCancelContact(Wedding_Contact_ID,Hotel_Contact_ID);
			if (cancelcontact == false)
			{
				response.sendRedirect("../Main.htm");
			}
		}
      response.sendRedirect("../ShowContact.jsp");
    }
	else response.sendRedirect("../Main.htm");
%>
</body>
</html>