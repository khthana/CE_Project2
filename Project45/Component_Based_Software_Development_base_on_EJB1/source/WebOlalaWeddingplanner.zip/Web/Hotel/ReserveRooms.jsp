<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.ReturnReserve"%>
<%@ page import = "java.lang.*"%>
  <%
  Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
  Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();
  %>
<html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body  bgcolor="F9F9EF">
<%        
//int customerId = Integer.parseInt((String)session.getAttribute("Customer_ID"));
//int Wedding_contact_Id = Integer.parseInt((String)session.getAttribute("weddingContactID"));


int amountRoom = Integer.parseInt((String)request.getParameter("amountRoom"));
String roomType = new String(request.getParameter("roomType").getBytes("ISO8859_1"),"MS874");
String scheckinDate = new String(request.getParameter("scheckinDate").getBytes("ISO8859_1"),"MS874");
String scheckoutDate = new String(request.getParameter("scheckoutDate").getBytes("ISO8859_1"),"MS874");
int hotelNumber = Integer.parseInt((String)request.getParameter("hotelNumber"));
String HotelName = new String(request.getParameter("HotelName").getBytes("ISO8859_1"),"MS874");
String HotelAddress = "sss";
//= new String(request.getParameter("HotelAddress").getBytes("ISO8859_1"),"MS874");

%>
<center>
<form name="form1" method="post" action="BookRoom.jsp">			
<table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ����ѷ�ç���</div></td>
      </tr>
	  <tr> 
        <td width="5%">1.</td>
        <td width="40%">���� contact :</td>
        <td width="60%"><INPUT TYPE="text" NAME="Contact_Name" value = "Wedding">&nbsp;</td>
      </tr>
	  <tr>
					<td>2.</td>
					<td>�ӹǹ��ͧ���Шͧ</td>
					<td><%=amountRoom%></td>
	  </tr>
	  <tr>
					<td>3.</td>
					<td>��Դ��ͧ</td>
					<% if (roomType.equals("single")){%><td>��ͧ��§����</td>
					<%}else if(roomType.equals("twin")){%><td>��ͧ��§���</td>
					<%}else {%><td>��ͧ�����</td><%}%>
	  </tr>
	  <tr>
					<td>4.</td>
					<td>�ѹ���Թ</td>
					<td><%=scheckinDate%></td>
	  </tr>
	  <tr>
					<td>5.</td>
					<td>�ѹ���͡</td>
					<td><%=scheckoutDate%></td>
	  </tr>
	  	  <tr>
					<td>6.</td>
					<td>�����ç���</td>
					<td><%=HotelName%></td>
	  </tr>
	  <tr>
					<td>7.</td>
					<td>��������ç���</td>
					<td><%=HotelAddress%></td>
	  </tr>
	  <tr>
					<td>8.</td>
					<td>��§����</td>
					<td><input type="radio" name="amountExtrabed" value="<%=amountRoom%>">
							   ��ͧ���
							<input type="radio" name="amountExtrabed" value="0" checked>
							  ����ͧ���
					</td>
	  </tr>
	  <tr>
					<td>9.</td>
					<td>��ͧ�����ͧ�ٺ�������</td>
					<td><input type="radio" name="smoke" value="1">
							       �ٺ�������
							<input type="radio" name="smoke" value="0" checked>
							      �ٺ����������
					</td>
	  </tr>
	  <tr> 
        <td colspan="3">&nbsp;<center><input type="submit" name="Submit" value="�ͧ"></center></td>
      </tr>
    </table>
		<input type="hidden"name="amountRoom" value = "<%=amountRoom%>">
		<input type="hidden"name="roomType" value = "<%=roomType%>">
		<input type="hidden"name="scheckinDate" value = "<%=scheckinDate%>">
		<input type="hidden"name="scheckoutDate" value = "<%=scheckoutDate%>">
		<input type="hidden"name="hotelNumber" value = "<%=hotelNumber%>">
</center>
</body>
</html>