<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="java.util.*"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
//		out.print(customerID);
		
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);
//		out.print(Temp_Str );

		String cakeName = (String)request.getParameter("cakeName");
//		out.print(cakeName+"1");

		String cakeStyle = (String)request.getParameter("cakeStyle");
//		out.print(cakeStyle);
		
		String cakeFlavour = (String)request.getParameter("cakeFlavour");
//		out.print(cakeFlavour);

		Temp_Str = (String)request.getParameter("cakeSize");
		int cakeSize = Integer.parseInt(Temp_Str);
//		out.print(Temp_Str );

		Temp_Str = (String)request.getParameter("cakeLayer");
		int cakeLayer = Integer.parseInt(Temp_Str);
//		out.print(Temp_Str );

		Temp_Str = (String)request.getParameter("cakePrice");
		double cakePrice = Double.parseDouble(Temp_Str);
//		out.print(Temp_Str );

		String hotelName = (String)request.getParameter("hotelName");
////
		Temp_Str = (String)request.getParameter("cakeID");
		int cakeID = Integer.parseInt(Temp_Str);
//		out.print(Temp_Str );

		Temp_Str = (String)request.getParameter("hotelD");
		int hotelID = Integer.parseInt(Temp_Str);
//		out.print(Temp_Str );

		short amount = 1;

		Temp_Str = (String)request.getParameter("seminarJobID");
	//	out.print(Temp_Str);

		int seminarJobID = Integer.parseInt(Temp_Str);
org.openuri.www.SeminarRoomReservationList	reserveList=Hotel.hotelShowReserveSeminar(seminarJobID,hotelID);
		String day=reserveList.getReserveDate();
           StringTokenizer tmpDate =new StringTokenizer(day," ");
            String date=tmpDate.nextToken();
			String month=tmpDate.nextToken();
			String year=tmpDate.nextToken();
			if(month.length()==1) month="0"+month;
			day=date+" "+month+" "+year;

		String hh = (String)request.getParameter("hh");
		String mm = (String)request.getParameter("mm");
	//	String ss = (String)request.getParameter("ss");
		String time=hh+":"+mm+":00";

		boolean create = false;
  		org.openuri.www.Hotelcontact contact=Hotel.hotel_Contact_List(customerID,weddingContactID);
		int hotelContact=0;
		if ((contact==null)||(contact.getHotelcontact() == 0))   {
			hotelContact=Hotel.hotelCreateContact("OlalaCakeReserve",hotelID,weddingContactID,customerID);
			create = true;}else
		{hotelContact=contact.getHotelcontact();}
		if (hotalContact != 0){
 //public int hotelCreateContact(java.lang.String contactName, int hotelNumber, int customerId, int weddingContactId)
//        out.print("custID "+customerID+",flavour "+cakeFlavour+",cakeID "+cakeID+",seminar "+seminarJobID+",contact "+hotelContact+",day "+day+",amount "+amount+",hotelID "+hotelID+",wedding "+weddingContactID);
//  public org.openuri.www.Hotelcontact hotel_Contact_List(int customerId, int weddingContactId)
		org.openuri.www.ReturnReserve rs=Hotel.hotelReserveCake(customerID,cakeFlavour,cakeID,seminarJobID,hotelContact,time,amount,hotelID,weddingContactID);

//	  public org.openuri.www.ReturnReserve hotelReserveCake(int customerId, java.lang.String cakeFlavour, int cakeId, int seminarRoomJobId, int hotelContactId, java.lang.String scakeServeTime, short cakeAmount, int hotelID, int weddingContactID)
		if(rs!=null)
  		if (rs.getStrError().equals("success")){
			response.sendRedirect("../ShowJob.jsp#cake");
		}else if (create == true){
			boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);	}%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#cake">��Ѻ�˹���ʴ���������´ contact</a></center>
		<%}else if (create == true){
				boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#cake">��Ѻ�˹���ʴ���������´ contact</a></center>
						<%}%>
</body>
</html>
