<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;
  		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

		
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

/////////////////////////////////////////////////////////////////////////////
	    org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(customerID, weddingContactID);
		int[] Seminar_Job_ID = null;
	//	out.print(hotelcontact);
	if (hotelcontact != null){
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(customerID,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null)
			if(alljob.getSeminarRoomJobId()!=null)
				if( alljob.getSeminarRoomJobId()[0]>0)
						Seminar_Job_ID =  alljob.getSeminarRoomJobId();
		}

//////////////////////////////////////////////////////////////////////////////

		
	org.openuri.www.SeminarRoomReservationList reserveList=null;

	Temp_Str = (String)request.getParameter("seminarRoomName");
	String seminarRoomName; 
	int jobID=0,flowerTimeRange=0;
	if(Temp_Str!=null)	seminarRoomName = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		else {
			Temp_Str = (String)request.getParameter("seminarRoomJobID");
			jobID = Integer.parseInt(Temp_Str);
			 reserveList=Hotel.hotelShowReserveSeminar(jobID,hotelcontact.getHotelId());
			seminarRoomName =reserveList.getSeminarRoomName();
			if(reserveList.getTime6To11Am()==1) flowerTimeRange=1;
			if(reserveList.getTime12To5Pm()==1) flowerTimeRange=2;
			if(reserveList.getTime6To11Pm()==1) flowerTimeRange=3;
			}
		
		Temp_Str = (String)request.getParameter("minPrice");
		double minPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("maxPrice");
		double maxPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("cheap");
		boolean cheap=false;
		if(Temp_Str.equals("true")) cheap=true;

		Temp_Str = (String)request.getParameter("hotelID");
	//	out.print(Temp_Str);
		int hotelNumber = Integer.parseInt(Temp_Str);

org.openuri.www.SearchFlowerResult[] rs=Hotel2.hotelSearchFlower(seminarRoomName,minPrice,maxPrice,cheap,hotelNumber,0,0);

// public org.openuri.www.SearchFlowerResult[] hotelSearchFlower(java.lang.String seminarRoomName, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)

//org.openuri.www.SearchCakeResult[] rs=Hotel.hotelSearchCake(cakeStyle,minPrice,maxPrice,layer,flavour,cakeSize,cheap,hotelNumber,0,0);
%>
<table border="1" align="center">
  <tr  bgcolor="#FFCCFF"> 
    <td align="center">����ᾤࡨ</td>
    <td align="center">�����ç���</td>
    <td align="center">�Ҥ�</td>
   <%if(Seminar_Job_ID!=null){%>
    <td align="center">�ͧ</td>
	<%}%>
  </tr>
<%
	if(rs!=null)
		for(int i=0;i<rs.length;i++)
		{
%>
   <form name="formX" method="post" action="ReserveFlower.jsp"> 
	  <tr> 
		<td align="center"><%=rs[i].getFlowerPackageName()%></td>
		<td align="center"><%=rs[i].getHotelName()%></td>
		<td align="center"><%=rs[i].getFlowerPrice()%></td>
	   <%if(Seminar_Job_ID!=null){%>
        <td><div align="center"><input type = "submit" value = "Reserve" name = "�ͧ"></div></td>
	   <input type = "hidden" name = "seminarRoomJobID" value = "<%=jobID%>">
	   <input type = "hidden" name = "seminarRoomID" value = "<%=reserveList.getSeminarRoomId()%>">
	   <input type = "hidden" name = "hotelContactID" value = "<%=hotelcontact.getHotelcontact()%>">
	   <input type = "hidden" name = "flowerTimeRange" value = "<%=flowerTimeRange%>">
		<%}%>
	 </tr>
   <input type = "hidden" name = "weddingContactID" value = "<%=weddingContactID%>">
   <input type = "hidden" name = "flowerPackageID" value = "<%=rs[i].getFlowerPackageId()%>">
   <input type = "hidden" name = "hotelID" value = "<%=rs[i].getHotelID()%>">
   <input type = "hidden" name = "hotelName" value = "<%=rs[i].getHotelName()%>">
   <input type = "hidden" name = "price" value = "<%=rs[i].getFlowerPrice()%>">
   <input type = "hidden" name = "flowerPackageName" value = "<%=rs[i].getFlowerPackageName()%>">
</form>
<%
		}//for
%>
</table>
</body>
</html>