<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head><title>Olala Wedding Planner : Cancel Hotel Contact</title></head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Hotel_Contact_ID");
    int Hotel_Contact_ID = 0;
    if (tempstr != null)
    {
      Hotel_Contact_ID = Integer.parseInt(tempstr);
	  //boolean hotelCancelContact(int weddingContactID, int hotelContactId)
      boolean cancel = Hotel.hotelCancelContact(Wedding_Contact_ID,Hotel_Contact_ID);
      response.sendRedirect("../ShowContact.jsp");
    }
    else response.sendRedirect("../Main.htm");
	%>
</body>
</html>