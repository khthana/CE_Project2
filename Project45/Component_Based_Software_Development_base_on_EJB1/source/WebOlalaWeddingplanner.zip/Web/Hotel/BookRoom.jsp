<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
<%@ page import = "java.lang.*"%>
  <%
  Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
  Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();
  %>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>
<body  bgcolor="F9F9EF">
<%           int customerId = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	   			 int weddingContactID = Integer.parseInt((String)session.getAttribute("weddingContactID"));
//String	result  =null;

//  public org.openuri.www.ReturnReserve[] hotelReserveRoom(int customerId, int hotelContactId, int amountRoom, java.lang.String roomType, java.lang.String scheckinDate, java.lang.String scheckoutDate, int amountExtrabed, int smoke, int hotelID, int weddingContactID)

int amountRoom = Integer.parseInt((String)request.getParameter("amountRoom"));
String roomType = new String(request.getParameter("roomType").getBytes("ISO8859_1"),"MS874");
String scheckinDate = new String(request.getParameter("scheckinDate").getBytes("ISO8859_1"),"MS874");
String scheckoutDate = new String(request.getParameter("scheckoutDate").getBytes("ISO8859_1"),"MS874");
int hotelNumber = Integer.parseInt((String)request.getParameter("hotelNumber"));
int amountExtrabed = Integer.parseInt((String)request.getParameter("amountExtrabed"));
int smoke = Integer.parseInt((String)request.getParameter("smoke"));

org.openuri.www.Hotelcontact contact=Hotel.hotel_Contact_List(customerId,weddingContactID);
		int hotelContact=0;
		boolean create = false;
		if ((contact==null)||(contact.getHotelcontact() == 0)) 
			{hotelContact=Hotel.hotelCreateContact("OlalaSeminarReserve",hotelNumber,customerId,weddingContactID);
			create = true;}
		else
			{hotelContact=contact.getHotelcontact();}
			if (hotelContact != 0){
org.openuri.www.ReturnReserve[] result =  Hotel.hotelReserveRoom(customerId,hotelContact,amountRoom,roomType,scheckinDate,scheckoutDate,amountExtrabed,smoke,hotelNumber,weddingContactID);

		if(result!=null){
   		//if (rs.getStrError().equals("success")){
			response.sendRedirect("http://161.246.6.99:7001/olalaweddingplanner/Web/ShowJob.jsp#room");
		}else if (create == true){
			boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);	}%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "http://161.246.6.99:7001/olalaweddingplanner/Web/ShowJob.jsp#room">��Ѻ�˹���ʴ���������´ contact</a></center>
			<%}else  if (create == true){
				boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "http://161.246.6.99:7001/olalaweddingplanner/Web/ShowJob.jsp#room">��Ѻ�˹���ʴ���������´ contact</a></center>
			<%}%>
</body>
</html>