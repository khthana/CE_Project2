<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); %>
<% WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); %>
<html>
<head>
<title>Olala Wedding Planner</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>
<table align="center" border=0 cellpadding="0" cellspacing="0" width="486">
  <tr> 
    <td align= "center"><p><font color="#000099" size="3">Reservation</font></p>
      <p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td width="486" align="center"><BR> <table width="480" border="1" bordercolor="#CCCCCC">
        <tr bgcolor="#FF99FF"> 
          <td colspan="3" align="center"><font color="#000099">Reservation Information</font></td>
        </tr>
        <tr> 
          <td>1.</td>
          <td>Hotel :</td>
          <td> <input type="text" name="textfield2"> </td>
        </tr>
        <tr> 
          <td width="23">2.</td>
          <td width="114">Type of room:</td>
          <td width="329"> <select name="select">
              <option value="single">Single</option>
              <option value="twin">Twin</option>
              <option value="suite">Suite</option>
            </select> </td>
        </tr>
        <tr> 
          <td>3.</td>
          <td>Arrival date:</td>
          <td> <select name="select2">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
              <option value="13">13</option>
              <option value="14">14</option>
              <option value="15">15</option>
              <option value="16">16</option>
              <option value="17">17</option>
              <option value="18">18</option>
              <option value="19">19</option>
              <option value="20">20</option>
              <option value="21">21</option>
              <option value="22">22</option>
              <option value="23">23</option>
              <option value="24">24</option>
              <option value="25">25</option>
              <option value="26">26</option>
              <option value="27">27</option>
              <option value="28">28</option>
              <option value="29">29</option>
              <option value="30">30</option>
              <option value="31">31</option>
            </select> <select name="select3">
              <OPTION value=0>January 
              <OPTION value=1>February 
              <OPTION value=2>March 
              <OPTION value=3>April 
              <OPTION value=4>May 
              <OPTION value=5>June 
              <OPTION value=6>July 
              <OPTION value=7>August 
              <OPTION value=8>September 
              <OPTION value=9>October 
              <OPTION value=10>November 
              <OPTION value=11>December </select> <select name="select4">
              <option value="2002">2002</option>
              <option value="2003">2003</option>
              <option value="2004">2004</option>
            </select> </td>
        </tr>
        <tr> 
          <td>4.</td>
          <td>Departure date:</td>
          <td> <select name="select6">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
              <option value="8">8</option>
              <option value="9">9</option>
              <option value="10">10</option>
              <option value="11">11</option>
              <option value="12">12</option>
              <option value="13">13</option>
              <option value="14">14</option>
              <option value="15">15</option>
              <option value="16">16</option>
              <option value="17">17</option>
              <option value="18">18</option>
              <option value="19">19</option>
              <option value="20">20</option>
              <option value="21">21</option>
              <option value="22">22</option>
              <option value="23">23</option>
              <option value="24">24</option>
              <option value="25">25</option>
              <option value="26">26</option>
              <option value="27">27</option>
              <option value="28">28</option>
              <option value="29">29</option>
              <option value="30">30</option>
              <option value="31">31</option>
            </select> <select name="select7">
              <OPTION value=0>January 
              <OPTION value=1>February 
              <OPTION value=2>March 
              <OPTION value=3>April 
              <OPTION value=4>May 
              <OPTION value=5>June 
              <OPTION value=6>July 
              <OPTION value=7>August 
              <OPTION value=8>September 
              <OPTION value=9>October 
              <OPTION value=10>November 
              <OPTION value=11>December </select> <select name="select5">
              <option value="2002">2002</option>
              <option value="2003">2003</option>
              <option value="2004">2004</option>
            </select> </td>
        </tr>
        <tr> 
          <td>5.</td>
          <td>Extrabed:</td>
          <td> <select name="select8">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
            </select> </td>
        </tr>
        <tr> 
          <td>6.</td>
          <td>Smoke:</td>
          <td> <input type="radio" name="radiobutton" value="radiobutton">
            yes 
            <input type="radio" name="radiobutton" value="radiobutton">
            no </td>
        </tr>
        <tr> 
          <td>7.</td>
          <td>Number of room:</td>
          <td><input type="text" name="textfield"> </td>
        </tr>
        <tr> 
          <td>8.</td>
          <td>Total Price</td>
          <td> <input type="text" name="textfield3"> </td>
        </tr>
      </table>
      <br> <table width="482" border="1" bordercolor="#CCCCCC">
        <tr bgcolor="#FF99FF"> 
          <td colspan="3" align="center"><font color="#000099" size="2">Credit 
            Card Information</font></td>
        </tr>
        <tr> 
          <td width="13">1.</td>
          <td width="110">Type:</td>
          <td width="336"> <p> 
              <input type="radio" name="radiobutton" value="radiobutton">
              <input name="imageField" type="image" src="INDEX/c_amex.gif" width="58" height="36" border="0">
              <input type="radio" name="radiobutton" value="radiobutton">
              <input name="imageField2" type="image" src="INDEX/c_visa.gif" width="58" height="36" border="0">
            </p>
            <p> 
              <input type="radio" name="radiobutton" value="radiobutton">
              <input name="imageField3" type="image" src="INDEX/c_master.gif" width="58" height="36" border="0">
              <input type="radio" name="radiobutton" value="radiobutton">
              <input name="imageField4" type="image" src="INDEX/c_jcb.gif" width="58" height="36" border="0">
            </p></tr>
        <tr> 
          <td>2.</td>
          <td>Number :</td>
          <td> <input type="text" name="textfield4"> </td>
        </tr>
        <tr> 
          <td>3.</td>
          <td>Security Code :</td>
          <td> <input name="textfield5" type="text" size="20"> <br> <font size="1">(required 
            for Amex&amp;Visa/MasterCard)</font> </td>
        </tr>
        <tr> 
          <td>4.</td>
          <td>Expiration Date:</td>
          <td> <select name="select10">
              <option value=0>January 
              <option value=1>February 
              <option value=2>March 
              <option value=3>April 
              <option value=4>May 
              <option value=5>June 
              <option value=6>July 
              <option value=7>August 
              <option value=8>September 
              <option value=9>October 
              <option value=10>November 
              <option value=11>December </option>
            </select> <select name="select9">
              <option value="2002">2002</option>
              <option value="2003">2003</option>
              <option value="2004">2004</option>
            </select> </td>
        </tr>
        <tr> 
          <td>5.</td>
          <td>Name on Card :</td>
          <td> <input type="text" name="textfield6"> </td>
        </tr>
        <tr> 
          <td colspan="3"><div align="center">This information is used to secure 
              your booking only</div></td>
        </tr>
      </table>
      <p>&nbsp;</p>
      <p> 
        <input type="submit" name="Submit" value="Submit">
      </p></td>
  </tr>
  <tr> 
    <td colspan="3"><br></td>
  </tr>
</table>
</body>
</html>