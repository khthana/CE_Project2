<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
 <html>
<head><title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	String Temp_Str = null;
   String place_style = new String(request.getParameter("place_style").getBytes("ISO8859_1"),"MS874");
  	    if(place_style.equals("all"))place_style=" ";
		
		Temp_Str = (String)request.getParameter("seminar_room_size_min");
		int seminar_room_size_min = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("seminar_room_size_max");
		int seminar_room_size_max = Integer.parseInt(Temp_Str);
		
		Temp_Str = (String)request.getParameter("seminarminprice");
		double seminarminprice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("seminarmaxprice");
		double seminarmaxprice = Double.parseDouble(Temp_Str);
   	    
		String date = (String)request.getParameter("date");
		String month = (String)request.getParameter("month");
		String year = (String)request.getParameter("year");
		String sreserve_date =date+" "+month+" "+year;
		
		short t0t11_am = 0;	short t12t5_pm = 0;
		short t6t11_pm = 0;
		Temp_Str = (String)request.getParameter("section");
		if(Temp_Str.equals("1"))
			{t0t11_am=1;}
		else if(Temp_Str.equals("2"))
			t12t5_pm = 1;
		else if(Temp_Str.equals("3"))
			t6t11_pm = 1;

		boolean cheap =false;
		Temp_Str = (String)request.getParameter("cheap");
		if(Temp_Str.equals("true"))
			{cheap = true;}

		Temp_Str = (String)request.getParameter("Hotel_ID");
		int hotelnumber1 = Integer.parseInt(Temp_Str);
		Temp_Str = (String)request.getParameter("district");
		int district = Integer.parseInt(Temp_Str);
		Temp_Str = (String)request.getParameter("region");
		int region = Integer.parseInt(Temp_Str);

org.openuri.www.SearchSeminarRoomResult[] a=Hotel2.hotelSearchSeminar(place_style," ",seminar_room_size_min,seminar_room_size_max,seminarminprice,seminarmaxprice,sreserve_date,t0t11_am,t12t5_pm,t6t11_pm,cheap,hotelnumber1,district,region);
%>
<center>
<table width="75%" border="1" bordercolor="#CCCCCC">
  <tr  bgcolor="#FFCCFF"> 
    <td rowspan="2">Seminar Room Name</td>
    <td rowspan="2">ʶҹ���</td>
    <td rowspan="2">��Ҵ��ͧ</td>
    <td rowspan="2">�Ҥ�</td>
    <td colspan="2">�ӹǹ������ͧ�Ѻ��</td>
    <td rowspan="2">�����ç���</td>
	<td rowspan="2">�������ͧ�ç���</td>
  </tr>
  <tr  bgcolor="#FFCCFF"> 
    <td>�����</td>
    <td>�Ѵ�ؿ��</td>
  </tr>
<%
if ((a != null)&&(a.length != 0))
for(int i=0;i<a.length;i++)
{
%>
  <tr> 
    <td><%=a[i].getSeminarRoomName()%></td>
    <td><%=a[i].getPlaceStyle()%></td>
    <td><%=a[i].getSeminarRoomSize()%></td>
    <td><%=a[i].getSeminarRoomPrice()%></td>
    <td><%=a[i].getMaxMenPerRoomBuffet()%></td>
    <td><%=a[i].getMaxMenPerRoomTable()%></td>
    <td><%=a[i].getHotelName()%></td>
    <td><%=a[i].getHotelAddress()%></td>
  </tr>
  <%}%>
</table>
<form name="form1" method="post" action="./SearchNoLog.jsp" target = "mainFrame">
    <input type="submit" name="Submit" value="Back">
  </form>
</center>
</body>
</html>