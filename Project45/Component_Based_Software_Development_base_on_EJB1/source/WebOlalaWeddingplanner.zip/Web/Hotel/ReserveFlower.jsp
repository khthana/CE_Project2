<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="java.util.*"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		//out.print(customerID);
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("flowerPackageID");
		int flowerPackageID = Integer.parseInt(Temp_Str);
	
		Temp_Str = (String)request.getParameter("seminarRoomID");
		int seminarRoomID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("seminarRoomJobID");
		int seminarRoomJobID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("hotelContactID");
		int hotelContactID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("flowerTimeRange");
		int flowerTimeRange = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("hotelID");
		int hotelID = Integer.parseInt(Temp_Str);

// public org.openuri.www.ReturnReserve hotelReserveFlower(int customerId, int flowerPackageId, int seminarRoomId, int seminarRoomJobId, int hotelContactId, int flowerTimeRange, int hotelID, int weddingContactID)
// out.print("customerID="+customerID+",flowerPackageID="+ flowerPackageID+",seminarRoomID="+seminarRoomID+",seminarRoomJobID="+seminarRoomJobID+",hotelContactID="+hotelContactID+",flowerTimeRange="+flowerTimeRange+",hotelID"+hotelID+",weddingContactID"+weddingContactID);
org.openuri.www.ReturnReserve rs=Hotel.hotelReserveFlower(customerID,flowerPackageID,seminarRoomID,seminarRoomJobID,hotelContactID,flowerTimeRange,hotelID, weddingContactID);
		if(rs!=null){
  	//	if (rs.getStrError().equals("success")){
			response.sendRedirect("../ShowJob.jsp#flower");
		}%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#flower">��Ѻ�˹���ʴ���������´ contact</a></center>
</body>
</html>