<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head><title>Olala Wedding Planner : Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<% 
  		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

		String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
		int weddingContactID = Integer.parseInt(Temp_Str);

/////////////////////////////////////////////////////////////////////////////
	    org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(customerID, weddingContactID);
		int[] Seminar_Job_ID = null;
	//	out.print(hotelcontact);
	if (hotelcontact != null){
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(customerID,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null)
			if(alljob.getSeminarRoomJobId()!=null)
				if( alljob.getSeminarRoomJobId()[0]>0)
						Seminar_Job_ID =  alljob.getSeminarRoomJobId();
		}
				org.openuri.www.SeminarRoomReservationList reserveList;

//////////////////////////////////////////////////////////////////////////////
  %>
  <form name="form1" method="post" action="ResultSearchFlower.jsp">

<table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
  <tr bgcolor="#FFCCFF"> 
    <td colspan="2" align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ�͡���</td>
  </tr>
  <tr> 
    <td width="51%"align="center">������ͧ�Ѵ����§</td>
    <td width="49%">
		<%if(Seminar_Job_ID==null){%>
        <select name="seminarRoomName" >
          <option value=" " selected>--������--</option>
          <option value="��Ҿ����">��Ҿ����</option>
          <option value="garden bar">garden bar</option>
          <option value="����ͧ">����ͧ</option>
          <option value="��⢷��">��⢷��</option>
          <option value="�ѵ���Թ���">�ѵ���Թ���</option>
          <option value="��ظ��">��ظ��</option>
          <option value="������1">������1</option>
          <option value="������2">������2</option>
          <option value="������3">������3</option>
        </select>
		<%}else{%>
		<select name="seminarRoomJobID">
		 <%
			for(int i=0;i<Seminar_Job_ID.length;i++){
			 reserveList=Hotel.hotelShowReserveSeminar(Seminar_Job_ID[i],hotelcontact.getHotelId());
		%>
			<option value="<%=Seminar_Job_ID[i]%>"><%=Seminar_Job_ID[i]%>:<%=reserveList.getSeminarRoomName()%></option>
		<%}//for%>
		</select>
		<%}%>
      </td>
  </tr>
  <tr> 
    <td align="center">�Ҥ�</td>
    <td>
        <input type="text" name="minPrice" size="10" value="0"> - <input type="text" name="maxPrice" size="10" value="10000">
    </td>
  </tr>
  <tr> 
    <td align="center">��ͧ���Ẻ�١�ش</td>
    <td>
        <input type="radio" name="cheap" value="true" checked>��ͧ���
        <input type="radio" name="cheap" value="false">����ͧ���
    </td>
  </tr>
  <tr> 
    <td width="51%"align="center">�����ç���</td>
   <td width="49%">
   <%if(Seminar_Job_ID==null){%>
        <select name="hotelID" >
          <option value="1" selected>Hotel1</option>
          <option value="2">Hotel2</option>
          <option value="3">Hotel3</option>
          <option value="4">Hotel4</option>
          <option value="5">Hotel5</option>
          <option value="6">Hotel6</option>
          <option value="7">Hotel7</option>
          <option value="8">Hotel8</option>
          <option value="9">Hotel9</option>
          <option value="10">Hotel10</option>
        </select>
	<%}else{%>
			<%=hotelcontact.getHotelName()%>
			<input type = "hidden" name = "hotelID" value = "<%=hotelcontact.getHotelId()%>">
<%}%>
	</select>
   </td>
  </tr>
</table>
  <p align="center">
   <input type = "hidden" name = "weddingContactID" value = "<%=weddingContactID%>">
    <input type="submit" name="Submit4" value="Search">
  </p>
</form>
 <!-- public org.openuri.www.SearchFlowerResult[] hotelSearchFlower(java.lang.String seminarRoomName, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)-->

</body>
</html>