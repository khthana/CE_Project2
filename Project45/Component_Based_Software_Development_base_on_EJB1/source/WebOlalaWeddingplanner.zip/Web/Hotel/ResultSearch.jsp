<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
 <html>
<head><title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	String Temp_Str = null;
   int Wedding_Contact_ID = Integer.parseInt((String)request.getParameter("Wedding_Contact_ID"));
   
   int Hotel_Contact_ID = Integer.parseInt((String)request.getParameter("Hotel_Contact_ID"));

   String place_style = new String(request.getParameter("place_style").getBytes("ISO8859_1"),"MS874");
  	    if(place_style.equals("all"))place_style=" ";
//   String dec_style = new String(request.getParameter("dec_style").getBytes("ISO8859_1"),"MS874");
//		if(dec_style.equals("all"))
//			dec_style=" ";
//		out.print("--------------"+dec_style+"--------------");
		
		Temp_Str = (String)request.getParameter("seminar_room_size_min");
		int seminar_room_size_min = Integer.parseInt(Temp_Str);
		//out.print(seminar_room_size_min);

		Temp_Str = (String)request.getParameter("seminar_room_size_max");
		int seminar_room_size_max = Integer.parseInt(Temp_Str);
		//out.print(seminar_room_size_max);
		
		Temp_Str = (String)request.getParameter("seminarminprice");
		double seminarminprice = Double.parseDouble(Temp_Str);
		//out.print(seminarminprice);

		Temp_Str = (String)request.getParameter("seminarmaxprice");
		double seminarmaxprice = Double.parseDouble(Temp_Str);
		//out.print(seminarmaxprice);
   	    
		String date = (String)request.getParameter("date");
		//out.print(date);
		String month = (String)request.getParameter("month");
		//out.print(month);
		String year = (String)request.getParameter("year");
		//out.print(year);
		String sreserve_date =date+" "+month+" "+year;
		
		short t0t11_am = 0;	short t12t5_pm = 0;
		short t6t11_pm = 0;
		Temp_Str = (String)request.getParameter("section");
		//out.print(Temp_Str);
		if(Temp_Str.equals("1"))
		{t0t11_am=1;}
		else if(Temp_Str.equals("2"))
		t12t5_pm = 1;
		else if(Temp_Str.equals("3"))
	t6t11_pm = 1;

		boolean cheap =false;
		Temp_Str = (String)request.getParameter("cheap");
		if(Temp_Str.equals("true"))
		{cheap = true;}
		//out.print(cheap);

	Temp_Str = (String)request.getParameter("Hotel_ID");
		int hotelnumber1 = Integer.parseInt(Temp_Str);
		//out.print(hotelnumber1);
		Temp_Str = (String)request.getParameter("district");
		int district = Integer.parseInt(Temp_Str);
		//out.print(district);
		Temp_Str = (String)request.getParameter("region");
		//out.print("11111111111111"+Temp_Str+"11111111111111");
		int region = Integer.parseInt(Temp_Str);
		//out.print(region);

org.openuri.www.SearchSeminarRoomResult[] a=Hotel2.hotelSearchSeminar(place_style," ",seminar_room_size_min,seminar_room_size_max,seminarminprice,seminarmaxprice,sreserve_date,t0t11_am,t12t5_pm,t6t11_pm,cheap,hotelnumber1,district,region);
%>
<center>
<table width="75%" border="1" bordercolor="#CCCCCC">
  <tr  bgcolor="#FFCCFF"> 
    <td rowspan="2">Seminar Room Name</td>
    <td rowspan="2">ʶҹ���</td>
    <td rowspan="2">��Ҵ��ͧ</td>
    <td rowspan="2">�Ҥ�</td>
    <td colspan="2">�ӹǹ������ͧ�Ѻ��</td>
    <td rowspan="2">�����ç���</td>
    <td rowspan="2">�ͧ</td>
  </tr>
  <tr  bgcolor="#FFCCFF"> 
    <td>�����</td>
    <td>�Ѵ�ؿ��</td>
  </tr>
<%
if ((a != null)&&(a.length != 0))
for(int i=0;i<a.length;i++)
{
%>
<form name="form1" method="post" action="ReserveSeminar.jsp">
  <tr> 
    <td><%=a[i].getSeminarRoomName()%></td>
    <td><%=a[i].getPlaceStyle()%></td>
    <td><%=a[i].getSeminarRoomSize()%></td>
    <td><%=a[i].getSeminarRoomPrice()%></td>
    <td><%=a[i].getMaxMenPerRoomBuffet()%></td>
    <td><%=a[i].getMaxMenPerRoomTable()%></td>
    <td><%=a[i].getHotelName()%></td>
    <td><input type = "submit" value = "�ͧ" name = "reserve"></td>
  <INPUT TYPE="hidden" name = "SeminarRoomName" value = "<%=a[i].getSeminarRoomName()%>">
  <INPUT TYPE="hidden" name = "PlaceStyle" value = "<%=a[i].getPlaceStyle()%>">
  <INPUT TYPE="hidden" name = "SeminarRoomSize" value = "<%=a[i].getSeminarRoomSize()%>">
  <INPUT TYPE="hidden" name = "SeminarRoomPrice" value = "<%=a[i].getSeminarRoomPrice()%>">
  <INPUT TYPE="hidden" name = "MaxMenPerRoomBuffet" value = "<%=a[i].getMaxMenPerRoomBuffet()%>">
  <INPUT TYPE="hidden" name = "MaxMenPerRoomTable" value = "<%=a[i].getMaxMenPerRoomTable()%>">
  <INPUT TYPE="hidden" name = "HotelName" value = "<%=a[i].getHotelName()%>">
  <INPUT TYPE="hidden" name = "HotelAddress" value = "<%=a[i].getHotelAddress()%>">
  <INPUT TYPE="hidden" name = "HotelID" value = "<%=a[i].getHotelID()%>">
  <INPUT TYPE="hidden" name = "SeminarRoomId" value = "<%=a[i].getSeminarRoomId()%>">
  </tr>
  <INPUT TYPE="hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
  <INPUT TYPE="hidden" name = "Hotel_Contact_ID" value = "<%=Hotel_Contact_ID%>">
  <INPUT TYPE="hidden" name = "t0t11_am" value = "<%=t0t11_am%>">
  <INPUT TYPE="hidden" name = "t12t5_pm" value = "<%=t12t5_pm%>"> 
  <INPUT TYPE="hidden" name = "t6t11_pm" value = "<%=t6t11_pm%>">
  <INPUT TYPE="hidden" name = "sreserve_date" value = "<%=sreserve_date%>">
</form>
<%}%>
</table>
</center>
</body>
</html>