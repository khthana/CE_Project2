<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
 <html>
<head><title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<body bgcolor="F9F9EF">
<%
int amountRoom = Integer.parseInt((String)request.getParameter("amountRoom"));
String roomType = new String(request.getParameter("roomType").getBytes("ISO8859_1"),"MS874");
String date_in = new String(request.getParameter("date_in").getBytes("ISO8859_1"),"MS874");
String month_in = new String(request.getParameter("month_in").getBytes("ISO8859_1"),"MS874");
String year_in = new String(request.getParameter("year_in").getBytes("ISO8859_1"),"MS874");
String date_out = new String(request.getParameter("date_out").getBytes("ISO8859_1"),"MS874");
String month_out = new String(request.getParameter("month_out").getBytes("ISO8859_1"),"MS874");
String year_out = new String(request.getParameter("year_out").getBytes("ISO8859_1"),"MS874");
String scheckinDate = date_in+" "+month_in+" "+year_in;
String scheckoutDate = date_out+" "+month_out+" "+year_out;
double minprice = Double.parseDouble((String)request.getParameter("minprice"));
double maxprice = Double.parseDouble((String)request.getParameter("maxprice"));
String Scheap = new String(request.getParameter("cheap").getBytes("ISO8859_1"),"MS874");
boolean cheap =false;
if(Scheap.equals("true"))
cheap = true;
int hotelNumber = Integer.parseInt((String)request.getParameter("hotelNumber"));
int region = Integer.parseInt((String)request.getParameter("region"));
int district = Integer.parseInt((String)request.getParameter("district"));
String near= new String(request.getParameter("Near"));
if(near.equals("Region")) district=0; else district=0;
//   int Wedding_Contact_ID = Integer.parseInt((String)request.getParameter("Wedding_Contact_ID"));
//   String place_style = new String(request.getParameter("place_style").getBytes("ISO8859_1"),"MS874");
int smoke =1;
//  public org.openuri.www.SearchRoomResult[] hotelSearchRoom(int amountRoom, java.lang.String roomType, java.lang.String scheckinDate, java.lang.String scheckoutDate, int smoke, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)

org.openuri.www.SearchRoomResult[] a = Hotel2.hotelSearchRoom(amountRoom,roomType,scheckinDate,scheckoutDate,smoke,minprice,maxprice,cheap,hotelNumber,region,district);
%>
<center>
<table width="75%" border="1" bordercolor="#CCCCCC">
  <tr  bgcolor="#FFCCFF"> 
    <td>��Դ��ͧ</td>
    <td>��Ҵ��ͧ</td>
    <td>�Ҥҵ�ͤ׹</td>
    <td>�ӹǹ�������ͧ</td>
    <td>�����ç���</td>
    <td>�ͧ</td>
  </tr>
<%if ((a != null)&&(a.length != 0)) {
for(int i=0;i<a.length;i++)
{%>
<tr><form name="form1" method="post" action="ReserveRooms.jsp">
 <td><% if(a[i].getRoomType().equals("single"))%>��ͧ��§����</td>
<td><%else if(roomType.equals("twin"))%>��ͧ��§���</td>
 <td><%else %>��ͧ�����</td>
<td><%=a[i].getRoomSize()%></td>
<td><%=a[i].getRoomPrice()%> �ҷ</td>
<td><%=a[i].getMaximumMenPerRoom()%></td>
<td><%=a[i].getHotelName()%></td>
<td><input type = "submit" value = "�ͧ" name = "reserve"></td> 
<input type = "hidden" name = "amountRoom" value="<%=amountRoom%>">
<input type = "hidden" name = "roomType" value="<%=a[i].getRoomType()%>">
<input type = "hidden" name = "scheckinDate" value="<%=scheckinDate%>">
<input type = "hidden" name = "scheckoutDate" value="<%=scheckoutDate%>">
<input type = "hidden" name = "hotelNumber" value="<%=a[i].getHotelID()%>">
<input type = "hidden" name = "HotelName" value="<%=a[i].getHotelName()%>">
<input type = "hidden" name = "HotelAddress" value="<%=a[i].getHotelAddress()%>">
</form>
</tr><%}}%>
</table>

</center>
</body>
</html>