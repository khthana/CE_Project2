<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="java.util.*"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

		String cakeName = (String)request.getParameter("cakeName");

		String cakeStyle = (String)request.getParameter("cakeStyle");
		
		String cakeFlavour = (String)request.getParameter("cakeFlavour");

		Temp_Str = (String)request.getParameter("cakeSize");
		int cakeSize = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("cakeLayer");
		int cakeLayer = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("cakePrice");
		double cakePrice = Double.parseDouble(Temp_Str);

		String hotelName = (String)request.getParameter("hotelName");
////
		Temp_Str = (String)request.getParameter("cakeID");
		int cakeID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("hotelD");
		int hotelID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("amount");
		int amount = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("seminarID");
		int seminarID = Integer.parseInt(Temp_Str);

		String date= (String)request.getParameter("date");
		String month= (String)request.getParameter("month");
		String year= (String)request.getParameter("year");
        String day=date+" "+month+" "+year;
		org.openuri.www.Hotelcontact contact=Hotel.hotel_Contact_List(customerID,weddingContactID);
		int hotelContact=0;
		if ((contact==null)||(contact.getHotelcontact() == 0))   {hotelContact=Hotel.hotelCreateContact("OlalaCakeReserve",hotelID,weddingContactID,customerID);}else
		{hotelContact=contact.getHotelcontact();}

 //public int hotelCreateContact(java.lang.String contactName, int hotelNumber, int customerId, int weddingContactId)
        out.print("custID "+customerID+",flavour "+cakeFlavour+",cakeID "+cakeID+",seminar "+seminarID+",contact "+hotelContact+",day "+day+" ,amount "+amount+",hotelID "+hotelID+",wedding "+weddingContactID);
//  public org.openuri.www.Hotelcontact hotel_Contact_List(int customerId, int weddingContactId)
//		org.openuri.www.ReturnReserve rs= Hotel.hotelReserveCake(customerID,cakeFlavour,cakeID,,hotelContact,day,amount,hotelID,weddingContactID);
%>
<!--- public org.openuri.www.ReturnReserve hotelReserveCake(int customerId, java.lang.String cakeFlavour, int cakeId, int seminarRoomJobId, int hotelContactId, java.lang.String scakeServeTime, short cakeAmount, int hotelID, int weddingContactID)
       throws java.rmi.RemoteException ;-->

</body>
</html>
