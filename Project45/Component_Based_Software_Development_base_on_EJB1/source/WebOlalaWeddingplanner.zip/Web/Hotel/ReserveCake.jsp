<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="java.util.*"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>

</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

		String cakeName = (String)request.getParameter("cakeName");

		String cakeStyle = (String)request.getParameter("cakeStyle");
		
		String cakeFlavour = (String)request.getParameter("cakeFlavour");

		Temp_Str = (String)request.getParameter("cakeSize");
		int cakeSize = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("cakeLayer");
		int cakeLayer = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("cakePrice");
		double cakePrice = Double.parseDouble(Temp_Str);

		String hotelName = (String)request.getParameter("hotelName");

		Temp_Str = (String)request.getParameter("cakeID");
		int cakeID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("hotelD");
		int hotelID = Integer.parseInt(Temp_Str);


	    org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(customerID, weddingContactID);
		int[] Seminar_Job_ID = null;
	//	out.print(hotelcontact);
	if (hotelcontact != null){
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(customerID,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null)
			if(alljob.getSeminarRoomJobId()!=null)
				if( alljob.getSeminarRoomJobId()[0]>0)
						Seminar_Job_ID =  alljob.getSeminarRoomJobId();
		}
		org.openuri.www.SeminarRoomReservationList reserveList;
		String day="",time="";
%>
<!--- public org.openuri.www.ReturnReserve hotelReserveCake(int customerId, java.lang.String cakeFlavour, int cakeId, int seminarRoomJobId, int hotelContactId, java.lang.String scakeServeTime, short cakeAmount, int hotelID, int weddingContactID)throws java.rmi.RemoteException ;-->
       
<div align="center">
<form name="form1" method="post" action="BookCake.jsp"> 
<table width=60%  border="1" align="center">

    <tr> 
    <td align="center">��ͧ�����</td>
	<td align="center">
	<%if(Seminar_Job_ID!=null){%>
		 <select name="seminarJobID"  >
		 <%
			for(int i=0;i<Seminar_Job_ID.length;i++){
			 reserveList=Hotel.hotelShowReserveSeminar(Seminar_Job_ID[i],hotelID);
		%>
			<option value="<%=Seminar_Job_ID[i]%>"><%=Seminar_Job_ID[i]%>:<%=reserveList.getSeminarRoomName()%></option>
		<%}%>
		</select>
	 <%}else{%>&nbsp;<%}%>
	 </td>
  
  </tr>
  
<tr> 
    <td align="center">����</td>
	<td align="center"><%=cakeName%></td>
  </tr>
  <tr> 
    <td align="center">����</td>
	<td align="center"><%=cakeStyle%></td>
  </tr>
  <tr> 
    <td align="center">��Ҵ</td>
	<td align="center"><%=cakeSize%></td>
  </tr>
  <tr> 
    <td align="center">�ӹǹ���</td>
	<td align="center"><%=cakeLayer%></td>
  </tr>
  <tr> 
    <td align="center">��</td>
	<td align="center"><%=cakeFlavour%></td>
  </tr>
  <tr> 
    <td align="center">�����ç���</td>
	<td align="center"><%=hotelName%></td>
  </tr>
  <tr> 
    <td align="center"> �Ҥ�</td>
	<td align="center"><%=cakePrice%></td>
  </tr>
    <tr> 
    <td align="center">�ӹǹ</td>
	<td align="center"><input name="amount" type="text" value="1" size="10" disabled></td>
  </tr>

  <tr> 
    <td align="center">�ѹ�Ѻ�ͧ</td>
	<%			int h1=0,h2=0,a=0,b=0;

			if(Seminar_Job_ID!=null){
			reserveList=Hotel.hotelShowReserveSeminar(Seminar_Job_ID[0],hotelID);
			day=reserveList.getReserveDate();
           StringTokenizer tmpDate =new StringTokenizer(day," ");
            day=tmpDate.nextToken()+"/"+tmpDate.nextToken()+"/"+tmpDate.nextToken();
			int t1=reserveList.getTime6To11Am();
			int t2=reserveList.getTime12To5Pm();
			int t3=reserveList.getTime6To11Pm(); 
			if(t1==1)  {time="06:00:00-11:00:00";a=6;b=11;}
			if(t1==2)  {time="12:00:00-17:00:00";a=12;b=17;}
			if(t1==3)  {time="18:00:00-23:00:00";a=18;b=23;}
  }
	%>
	<td align="center" ><%=day%>&nbsp;&nbsp;<%=time%></td>
  </tr>
  <tr> 
    <td align="center">����(<%=time%>)</td>
	<td align="center">
        <select name="hh" >
			<%for(int i=a;i<=b;i++){%>
			<option value="<%if(i<10)%>0<%=i%>"><%if(i<10)%>0<%=i%></option>
			<%}%>
		</select>:
        <select name="mm" >
			<%for(int i=0;i<60;i++){%>
			<option value="<%if(i<10)%>0<%=i%>"><%if(i<10)%>0<%=i%></option>
			<%}%>
		</select>
		
	</td>
  </tr>


        <input type="hidden"name="weddingContactID" value = "<%=weddingContactID%>">
        <input type="hidden"name="cakeName" value = "<%=cakeName%>">
        <input type="hidden"name="cakeStyle" value = "<%=cakeStyle%>">
	    <input type="hidden"name="cakeSize" value = "<%=cakeSize%>">
		<input type="hidden"name="cakeLayer" value = "<%=cakeLayer%>">
		<input type="hidden"name="cakeFlavour" value = "<%=cakeFlavour%>">
		<input type="hidden"name="cakePrice" value = "<%=cakePrice%>">
		<input type="hidden"name="hotelName" value = "<%=hotelName%>">
		<input type="hidden"name="cakeID" value = "<%=cakeID%>">
		<input type="hidden"name="hotelD" value = "<%=hotelID%>">
</table>
	<%if(Seminar_Job_ID!=null){%>
	    <BR>
		<input type = "submit" value = "�ͧ" name = "�ͧ">
	<%}%>

</form>
</div>
</body>
</html>