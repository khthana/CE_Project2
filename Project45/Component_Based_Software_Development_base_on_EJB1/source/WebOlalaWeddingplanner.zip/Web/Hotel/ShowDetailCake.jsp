<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Hotel_Contact_ID");
	int Hotel_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Cake_Job_ID");
	int Cake_Job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Hotel_Name");
	String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);

	//////////////////////////////////////////////////////////////find deadline//////////////////////////////////////
String deadline="";
boolean lockButton=false;
org.openuri.www.WeddingContactDetail[] detail = soapProxy.find_Wedding_Contact(Customer_id);
for(int j=0;j<detail.length;j++)
	if(detail[j].getWeddingContactID()==Wedding_Contact_ID) deadline=detail[j].getDeadline();
if(deadline.equals("-1")) lockButton=true;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//org.openuri.www.CakeReservationList hotelShowReserveCake(int cakeJobId, int hotelNumber)
	org.openuri.www.CakeReservationList list = Hotel.hotelShowReserveCake(Cake_Job_ID, Hotel_ID);
	if (list != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��������´��èͧ��</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">���ʡ�èͧ :</div></td>
      <td width="65%"><div align="center"><%=list.getCakeJobId()%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">���ʡ�èͧ��ͧ�Ѵ����§ :</div></td>
      <td><div align="center"><a href = "./ShowDetailSeminar.jsp?Hotel_Contact_ID=<%=Hotel_Contact_ID%>&Seminar_Job_ID=<%=list.getSeminarRoomJobId()%>&Wedding_Contact_ID=<%=Wedding_Contact_ID%>&Hotel_Name=<%=Hotel_Name%>&Hotel_ID=<%=Hotel_ID%>"><%=list.getSeminarRoomJobId()%></a></div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">�ʢͧ�� :</div></td>
      <td> <div align="center"><%=list.getCakeFlavour()%></div></td>
    </tr>
    <tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">������ :</div></td>
      <td><div align="center"><%=list.getCakeName()%></div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">����ͧ�� :</div></td>
      <td><div align="center"><%=list.getCakeStyle()%></div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">��Ҵ�� :</div></td>
      <td><div align="center"><%=list.getCakeSize()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">�ӹǹ��� :</div></td>
      <td><div align="center"><%=list.getCakeLayer()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">8.</div></td>
      <td><div align="center">���������:</div></td>
      <td><div align="center"><%=list.getCakeServeTime()%></div></td>
    </tr>
    <tr>
      <td><div align="center">9.</div></td>
      <td><div align="center">�ӹǹ��� :</div></td>
      <td><div align="center"><%=list.getCakeAmount()%></div></td>
    </tr>
    <tr>
      <td><div align="center">10.</div></td>
      <td><div align="center">�Ҥ��� :</div></td>
      <td><div align="center"><%=list.getJobTotalPrice()%>&nbsp;�ҷ</div></td>
    </tr>
    <tr>
      <td><div align="center">11.</div></td>
      <td><div align="center">�����ç��� :</div></td>
      <td><div align="center"><%=Hotel_Name%>&nbsp;</div></td>
    </tr>
  </table>
<center>
  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditCake.jsp">
          <div align="right">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Hotel_Contact_ID" value="<%=Hotel_Contact_ID%>">
			<input type="hidden" name="Cake_Job_ID" value="<%=list.getCakeJobId()%>">
			<input type="hidden" name="Seminar_Job_ID" value="<%=list.getSeminarRoomJobId()%>">
			<input type="hidden" name="Flavour" value="<%=list.getCakeFlavour()%>">
			<input type="hidden" name="Cake_Name" value="<%=list.getCakeName()%>">
			<input type="hidden" name="Cake_Style" value="<%=list.getCakeStyle()%>">
			<input type="hidden" name="Cake_Size" value="<%=list.getCakeSize()%>">
			<input type="hidden" name="Cake_Layer" value="<%=list.getCakeLayer()%>">
			<input type="hidden" name="Serve_Time" value="<%=list.getCakeServeTime()%>">
			<input type="hidden" name="Amount" value= "<%=list.getCakeAmount()%>">
			<input type="hidden" name="Price" value = "<%=list.getJobTotalPrice()%>">
			<input type="hidden" name="Hotel_Name" value= "<%=Hotel_Name%>">
			<input type="hidden" name="Hotel_ID" value="<%=Hotel_ID%>">
			<input type="submit" name="Submit" value="Edit">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelCakeJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Hotel_Contact_ID" value="<%=Hotel_Contact_ID%>">
			<input type="hidden" name="Cake_Job_ID" value="<%=list.getCakeJobId()%>">
			<input type = "hidden" name = "Hotel_ID" value = "<%=Hotel_ID%>">
          <input type="submit" name="Submit2" value="Cancel Job" <%if(lockButton){%>disabled<%}%>>
        </form></td>
    </tr>
  </table>
  </center>
  <p>&nbsp;</p>
</div>
  <%}else {%>
		<center>�������������´��èͧ</center>
<%  }%>
</body>
</html>