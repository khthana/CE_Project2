<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head><title>Olala Wedding Planner : Edit Food</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Hotel_Contact_ID");
	int Hotel_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Food_Job_ID");
	int Food_Job_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Seminar_Job_ID");
	int Seminar_Job_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Food_Package");
	int Food_Package = Integer.parseInt(tempstr);
	tempstr  = (String)request.getParameter("Serve_Style");
	String Serve_Style = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Food_Style");
	String Food_Style= new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Amount");
	int Amount = Integer.parseInt(tempstr);
	tempstr  = (String)request.getParameter("Price");
	double Price = Double.parseDouble(tempstr);
	tempstr = (String)request.getParameter("Hotel_Name");
	String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Hour");
	String Hour1 = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Minute");
	String Minute1 = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Second");
	String Second1 = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	if (Hour1.length() ==1)
		Hour1 = "0"+Hour1;
	if (Minute1.length()==1)
		Minute1 = "0"+Minute1;
	if (Second1.length() ==1)
		Second1 = "0"+Second1;
		String ServeTime = Hour1+":"+Minute1+":"+Second1;
		//boolean hotelEditFood(int customerId, int foodJobId, java.lang.String sfoodServeTime, int hotelNumber)
		boolean edit = Hotel.hotelEditFood(Customer_id,Food_Job_ID,ServeTime,Hotel_ID);
		if (edit == false){
	%>
			<p>&nbsp;</p>
			<center>�������ö�����
			<p>&nbsp;</p>
			<a href = "../ShowContact.jsp">˹���á</a></center>
		<%	}
		else
		{
%>
<div align="center">
<form name="form1" method="post" action="./Edit.jsp">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�÷������ͧ�����</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left" width = "30%">���ʡ�èͧ����� : </div></td>
      <td width="70%"> <div align="left"><%=Food_Job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">ᾤࡨ����� :</div></td>
      <td> <div align="left"><%=Food_Package%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">���������������� :</div></td>
      <td>  <div align="left"><%=Serve_Style%></div></td>
    </tr>

    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">���������:</div></td>
      <td> <div align="left"><%=Food_Style%></div></td>
    </tr>
    <tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">��������� :</div></td>
      <td><div align="left"><%=ServeTime%></div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">�ӹǹ :</div></td>
      <td> <div align="left"><%=Amount%></div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">�Ҥ� :</div></td>
      <td> <div align="left"><%=Price%></div></td>
    </tr>
    <tr> 
      <td><div align="center">8.</div></td>
      <td><div align="left">�����ç��� :</div></td>
      <td> <div align="left"><%=Hotel_Name%></div></td>
    </tr>

  </table>
  <p>&nbsp;</p>
������º��������
<a href = "../ShowContact.jsp">����������´ Contact</a>
	  <%}%>
</div>
</body>
</html>