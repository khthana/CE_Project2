<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
<%@ page import = "java.lang.*"%>
  <%
  Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
  Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();
  %>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>
<body  bgcolor="F9F9EF">
<%            int customerId = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    			String SeminarRoomName = new String(request.getParameter("SeminarRoomName").getBytes("ISO8859_1"),"MS874");
				String PlaceStyle = new String(request.getParameter("PlaceStyle").getBytes("ISO8859_1"),"MS874");
				int SeminarRoomSize = Integer.parseInt((String)request.getParameter("SeminarRoomSize"));
				double SeminarRoomPrice = Double.parseDouble((String)request.getParameter("SeminarRoomPrice"));
				int MaxMenPerRoomBuffet = Integer.parseInt((String)request.getParameter("MaxMenPerRoomBuffet"));
				int MaxMenPerRoomTable = Integer.parseInt((String)request.getParameter("MaxMenPerRoomTable"));
				String HotelName = new String(request.getParameter("HotelName").getBytes("ISO8859_1"),"MS874");
				int hotelID = Integer.parseInt((String)request.getParameter("HotelID"));
				int seminarRoomId = Integer.parseInt((String)request.getParameter("SeminarRoomId"));
				String sreserveDate  = new String(request.getParameter("sreserve_date").getBytes("ISO8859_1"),"MS874");
				int weddingContactID = Integer.parseInt((String)request.getParameter("Wedding_Contact_ID"));
				int hotelContactId = Integer.parseInt((String)request.getParameter("Hotel_Contact_ID"));
				short t6To11Am = Short.parseShort((String)request.getParameter("t0t11_am"));
				short t12To5Pm = Short.parseShort((String)request.getParameter("t12t5_pm"));
				short t6To11Pm = Short.parseShort((String)request.getParameter("t6t11_pm"));
				String decStyle = new String(request.getParameter("dec_Style").getBytes("ISO8859_1"),"MS874");
				short menPerRoom = Short.parseShort((String)request.getParameter("manperroom"));
				String tableLayout = new String(request.getParameter("tableLayout").getBytes("ISO8859_1"),"MS874");

		org.openuri.www.Hotelcontact contact=Hotel.hotel_Contact_List(customerId,weddingContactID);
		boolean create = false;
		int hotelContact=0;
		if((contact==null)||(contact.getHotelcontact() == 0))
			{hotelContact=Hotel.hotelCreateContact("OlalaSeminarReserve",hotelID,customerId,weddingContactID);
			create = true;}
		else
			{hotelContact=contact.getHotelcontact();}
			if (hotelContact != 0){
//			org.openuri.www.ReturnReserve result = Hotel.hotelReserveSeminar(customerId, hotelContact,seminarRoomId,decStyle,"03 05 2003",t6To11Am,t12To5Pm, t6To11Pm,menPerRoom,tableLayout,hotelID,weddingContactID);
			org.openuri.www.ReturnReserve result = Hotel.hotelReserveSeminar(customerId, hotelContact,seminarRoomId,decStyle,sreserveDate,t6To11Am,t12To5Pm, t6To11Pm,menPerRoom,tableLayout,hotelID,weddingContactID);
		if(result!=null){
   			if (result.getStrError().equals("success")){
				response.sendRedirect("../ShowJob.jsp#seminar");
			}else if (create == true){
			boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);	%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#seminar">��Ѻ�˹���ʴ���������´ contact</a></center>
			<%}}else{
				boolean cancel = Hotel.hotelCancelContact(weddingContactID,hotelContact);%>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#seminar">��Ѻ�˹���ʴ���������´ contact</a></center>
					<%}}%>
</body>
</html>