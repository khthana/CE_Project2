<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="java.util.*"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		//out.print(customerID);
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

		String foodStyle = (String)request.getParameter("foodStyle");

		Temp_Str = (String)request.getParameter("foodPackageID");
		int foodPackageID = Integer.parseInt(Temp_Str);
		//out.print(foodPackageID);
		Temp_Str = (String)request.getParameter("foodPricePerPerson");
		double foodPricePerPerson = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("foodPricePerTable");
		double foodPricePerTable = Double.parseDouble(Temp_Str);

		String hotelName = (String)request.getParameter("hotelName");

		Temp_Str = (String)request.getParameter("hotelID");
		int hotelID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("foodPer");
		int foodPer = Integer.parseInt(Temp_Str);

		 String[] fName= Hotel.hotelShowFoodPackage(hotelID,foodPackageID);
		 int foodNum=fName.length;	
	
	 org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(customerID, weddingContactID);
		int[] Seminar_Job_ID = null;
	if (hotelcontact != null){
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(customerID,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null)
			if(alljob.getSeminarRoomJobId()!=null)
				if( alljob.getSeminarRoomJobId()[0]>0)
						Seminar_Job_ID =  alljob.getSeminarRoomJobId();
		}
		org.openuri.www.SeminarRoomReservationList reserveList = null;

%>
<!--- public org.openuri.www.ReturnReserve hotelReserveFood(int customerId, int hotelContactId, int seminarRoomJobId, int foodPackageId, java.lang.String sfoodServeTime, short serveAmount, int hotelID, int weddingContactID)
 -->
<div align="center">
<form name="form1" method="post" action="BookFood.jsp"> 
<table width=60%  border="1" align="center">
  <tr> 
    <td align="center">��ͧ�Ѵ����§</td>
	<td align="center">
	<%if(Seminar_Job_ID!=null){%>
		 <select name="seminarJobID"  >
		 <%
			for(int i=0;i<Seminar_Job_ID.length;i++){
			 reserveList=Hotel.hotelShowReserveSeminar(Seminar_Job_ID[i],hotelID);
		%>
			<option value="<%=Seminar_Job_ID[i]%>"><%=Seminar_Job_ID[i]%>:<%=reserveList.getSeminarRoomName()%></option>
		<%}%>
		</select>
	 <%}else{%>&nbsp;<%}%>
	 </td>
  </tr>
  <tr> 
    <td align="center">������</td>
	<td align="center"><%=foodStyle%></td>
  </tr>
  <tr rowspan=foodNum> 
    <td align="center">��¡�������</td>
	<td align="center">
	<%for(int i=0;i<foodNum;i++){%>
	<div align="center"><%=fName[i]%></div>
	<%}%>
	</td>
  </tr>
<%if(foodPer==1){%>
  <tr> 
    <td align="center">�Ҥ�(Ẻ�ؿ��)</td>
	<td align="center"><%=foodPricePerPerson%></td>
  </tr>
<%}else{%>
  <tr> 
    <td align="center">�Ҥ�(Ẻ��Шչ)</td>
	<td align="center"><%=foodPricePerTable%></td>
  </tr>
<%}%>
  <tr> 
    <td align="center">�ӹǹ</td>
	<td align="center"><input name="amount" type="text" value="0" size="10"></td>
  </tr>
  <tr> 
    <td align="center">���ҷ�����������</td>
	<td align="center">
 <select name="Hour">
 <%if (reserveList.getTime6To11Am() ==1){
			for (int i = 6;i <=11;i ++){%>
                         <option value = "<%=i%>"><%=i%></option>             
			<%}}else if (reserveList.getTime12To5Pm() ==1){
						for (int i = 12;i<=17;i++){%>
	                         <option value = "<%=i%>"><%=i%></option>             
							 <%}}else for (int i = 18;i<=23;i++){%>
				                         <option value = "<%=i%>"><%=i%></option>             
										 <%}%>
			</select>
          : 
<select name="minute">
                         <option value = "00" selected>00</option>             
                        <option value = "15" >15</option>             
                        <option value = "30" >30</option>             
                        <option value = "45" >45</option>             
</select>	</td>
  </tr>
  <tr> 
    <td align="center">�����ç���</td>
	<td align="center"><%=hotelName%></td>
  </tr>
</table>
		<BR><BR>
        <input type="hidden"name="weddingContactID" value = "<%=weddingContactID%>">
		<input type="hidden"name="hotelName" value = "<%=hotelName%>">
		<input type="hidden"name="hotelD" value = "<%=hotelID%>">
		<input type="hidden"name="foodPackageID" value = "<%=foodPackageID%>">
		<input type = "submit" value = "�ͧ" name = "�ͧ">
</form>
</div>
</body>
</html>