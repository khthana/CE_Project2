<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Hotel_Contact_ID");
	int Hotel_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Seminar_Job_ID");
	int Seminar_Job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Hotel_Name");
	String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);

	//////////////////////////////////////////////////////////////find deadline//////////////////////////////////////
String deadline="";
boolean lockButton=false;
org.openuri.www.WeddingContactDetail[] detail = soapProxy.find_Wedding_Contact(Customer_id);
for(int j=0;j<detail.length;j++)
	if(detail[j].getWeddingContactID()==Wedding_Contact_ID) deadline=detail[j].getDeadline();
if(deadline.equals("-1")) lockButton=true;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//org.openuri.www.SeminarRoomReservationList hotelShowReserveSeminar(int seminarRoomJobId, int hotelNumber)
	org.openuri.www.SeminarRoomReservationList list = Hotel.hotelShowReserveSeminar(Seminar_Job_ID, Hotel_ID);
	if (list != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��������´��èͧ��ͧ������</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">���ʡ�èͧ :</div></td>
      <td width="65%"><div align="center"><%=list.getSeminarRoomJobId()%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">������ͧ :</div></td>
      <td><div align="center"><%=list.getSeminarRoomName()%></div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">�����õ�����ͧ :</div></td>
      <td> <div align="center"><%=list.getDecStyle()%></div></td>
    </tr>
    <tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">����ʶҹ���</div></td>
      <td><div align="center"><%=list.getPlaceStyle()%></div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">��èѴ��� :</div></td>
      <td><div align="center"><%=list.getTableLayout()%></div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ӹǹ�������ͧ :</div></td>
      <td><div align="center"><%=list.getMenPerRoom()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">�ѹ���ͧ :</div></td>
      <td><div align="center"><%=list.getReserveDate()%>&nbsp;
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">8.</div></td>
      <td><div align="center">��ǧ���Ҩͧ :</div></td>
      <td><div align="center">
	  <%if (list.getTime6To11Am() ==1){
				out.print("6:00 - 11:00 �.");}
			else if (list.getTime12To5Pm() ==1){
				out.print("12:00 - 17:00 �.");}
				else out.print("18:00 - 23:00 �.");
		  %>
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">9.</div></td>
      <td><div align="center">�Ҥҡ�èͧ :</div></td>
      <td><div align="center"><%=list.getJobTotalPrice()%>&nbsp;�ҷ</div></td>
    </tr>
    <tr>
      <td><div align="center">9.</div></td>
      <td><div align="center">�����ç��� :</div></td>
      <td><div align="center"><%=Hotel_Name%>&nbsp;</div></td>
    </tr>
  </table>
<center>
<form name="form2" method="post" action="./CancelSeminarJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Hotel_Contact_ID" value="<%=Hotel_Contact_ID%>">
			<input type="hidden" name="Seminar_Job_ID" value="<%=list.getSeminarRoomJobId()%>">
			<input type = "hidden" name = "Hotel_ID" value = "<%=Hotel_ID%>">
          <input type="submit" name="Submit2" value="Cancel Job" <%if(lockButton){%>disabled<%}%>>
        </form>
  </center>
  <p>&nbsp;</p>
</div>
  <%}else {%>
		<center>�������������´��èͧ</center>
<%  }%>
</body>
</html>