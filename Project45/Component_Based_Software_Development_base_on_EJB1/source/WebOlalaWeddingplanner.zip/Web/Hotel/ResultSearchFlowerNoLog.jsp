<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
<html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;
		Temp_Str = (String)request.getParameter("seminarRoomName");
		String seminarRoomName = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

		Temp_Str = (String)request.getParameter("minPrice");
		double minPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("maxPrice");
		double maxPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("cheap");
		boolean cheap=false;
		if(Temp_Str.equals("true")) cheap=true;

		Temp_Str = (String)request.getParameter("hotelID");
		int hotelNumber = Integer.parseInt(Temp_Str);

org.openuri.www.SearchFlowerResult[] rs=Hotel2.hotelSearchFlower(seminarRoomName,minPrice,maxPrice,cheap,hotelNumber,0,0);

// public org.openuri.www.SearchFlowerResult[] hotelSearchFlower(java.lang.String seminarRoomName, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)

//org.openuri.www.SearchCakeResult[] rs=Hotel.hotelSearchCake(cakeStyle,minPrice,maxPrice,layer,flavour,cakeSize,cheap,hotelNumber,0,0);
%>
<center>
<table border="1" align="center">
  <tr  bgcolor="#FFCCFF"> 
    <td align="center">����ᾤࡨ</td>
    <td align="center">�����ç���</td>
    <td align="center">�Ҥ�</td>
  </tr>
<%
	if(rs!=null)
		for(int i=0;i<rs.length;i++)
		{
%>
	  <tr> 
		<td align="center"><%=rs[i].getFlowerPackageName()%></td>
		<td align="center"><%=rs[i].getHotelName()%></td>
		<td align="center"><%=rs[i].getFlowerPrice()%></td>
	 </tr>
<%
		}//for
%>
</table>
<form name="form1" method="post" action="./SearchNoLog.jsp" target = "mainFrame">
    <input type="submit" name="Submit" value="Back">
  </form>
  </center>
</body>
</html>