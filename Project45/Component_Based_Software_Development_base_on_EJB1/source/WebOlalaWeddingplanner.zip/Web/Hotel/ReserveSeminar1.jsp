<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.ReturnReserve"%>
<%@ page import = "java.lang.*"%>
  <%
  Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
  Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();
  %>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>
<body  bgcolor="F9F9EF">
<%        
int customerId = Integer.parseInt((String)session.getAttribute("Customer_ID"));
String SeminarRoomName = new String(request.getParameter("SeminarRoomName").getBytes("ISO8859_1"),"MS874");
String PlaceStyle = new String(request.getParameter("PlaceStyle").getBytes("ISO8859_1"),"MS874");
int SeminarRoomSize = Integer.parseInt((String)request.getParameter("SeminarRoomSize"));
double SeminarRoomPrice = Double.parseDouble((String)request.getParameter("SeminarRoomPrice"));
int MaxMenPerRoomBuffet = Integer.parseInt((String)request.getParameter("MaxMenPerRoomBuffet"));
int MaxMenPerRoomTable = Integer.parseInt((String)request.getParameter("MaxMenPerRoomTable"));
String HotelName = new String(request.getParameter("HotelName").getBytes("ISO8859_1"),"MS874");
int hotelID = Integer.parseInt((String)request.getParameter("HotelID"));
int seminarRoomId = Integer.parseInt((String)request.getParameter("SeminarRoomId"));
String sreserveDate  = new String(request.getParameter("sreserve_date").getBytes("ISO8859_1"),"MS874");
int weddingContactID = Integer.parseInt((String)request.getParameter("Wedding_Contact_ID"));
int hotelContactId = Integer.parseInt((String)request.getParameter("Hotel_Contact_ID"));
short t6To11Am = Short.parseShort((String)request.getParameter("t0t11_am"));
short t12To5Pm = Short.parseShort((String)request.getParameter("t12t5_pm"));
short t6To11Pm = Short.parseShort((String)request.getParameter("t6t11_pm"));

//list box //
String decStyle ="thai";
short menPerRoom = 10;
String tableLayout = "buffet";
///////////


//			ReturnReserve result = Hotel.hotelReserveSeminar(customerId, hotelContactId,seminarRoomId,decStyle,sreserveDate,t6To11Am,t12To5Pm, t6To11Pm,menPerRoom,tableLayout,hotelID,weddingContactID); 
%>			
<table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ����ѷ�ç���</div></td>
      </tr>
      <tr> 
        <td width="5%">1.</td>
        <td width="40%">���� contact :</td>
        <td width="60%"><input type="text" name="Hotel_Contact_Name" value = "Olala">&nbsp;</td>
      </tr>
      <tr> 
        <td>2.</td>
        <td>����ʶҹ���Ѵ����§ :</td>
        <td align = "left"><%=SeminarRoomName%></td>
      </tr>
      <tr> 
        <td>3.</td>
        <td>�ٻẺʶҹ��� :</td>
        <td align = "left"><%=PlaceStyle%></td>
      </tr>
	 <tr> 
        <td>4.</td>
        <td>�ٻẺ��èѴ��ͧ :</td>
        <td align = "left"><form name="form1" method="post" action="">
        <select name="select">
        </select>
      </form></td>
	</tr>
	  <tr> 
        <td>5.</td>
        <td>��Ҵ��ͧ :</td>
        <td align = "left"><%=SeminarRoomSize%></td>
      </tr>
	  <tr> 
        <td>6.</td>
        <td>�ӹǹ�� :</td>
        <td align = "left"><form name="form2" method="post" action="">
        <input type="text" name="textfield">
      </form></td>
	  </tr>
	  <tr> 
        <td>7.</td>
        <td>�ѹ���ҷ��ͧ :</td>
        <td align = "left"><%String time = null;
										if(t6To11Am==1)
											{time = "    6:00-11:00 �";
											}
										else if(t12To5Pm==1)
											{time = "  12:00-17:00 �";
											}
										else
											{time = "  18:00-23:00 �"; 
											}
										%>
										<%=sreserveDate+time%></td>
      </tr>      
	  <tr> 
		<td>8.</td>
        <td>��èѴ��� :</td>
        <td align = "left"><form name="form3" method="post" action="">
        <select name="select2">
        </select>
      </form></td>
      </tr>
      <tr> 
        <td>9.</td>
        <td>�����ç��� :</td>
        <td align = "left"><%=HotelName%></td>
      </tr>
      <tr> 
        <td colspan="3">&nbsp;<center><input type="submit" name="Submit" value="�ͧ"></center></td>
      </tr>
    </table>
</body>
</html>