<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head>
	<title>Olala Wedding Planner : Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<% 
  		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

		String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
		int weddingContactID = Integer.parseInt(Temp_Str);

/////////////////////////////////////////////////////////////////////////////
	    org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(customerID, weddingContactID);
		int[] Seminar_Job_ID = null;
	//	out.print(hotelcontact);
	if (hotelcontact != null){
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(customerID,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null)
			if(alljob.getSeminarRoomJobId()!=null)
				if( alljob.getSeminarRoomJobId()[0]>0)
						Seminar_Job_ID =  alljob.getSeminarRoomJobId();
		}
				org.openuri.www.SeminarRoomReservationList reserveList;

//////////////////////////////////////////////////////////////////////////////

  %>
  <form name="form1" method="post" action="./ResultSearchCake.jsp">

<table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
  <tr bgcolor="#FFCCFF"> 
    <td colspan="2" align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ��</td>
  </tr>
  <tr> 
    <td width="51%" align="center">������</td>
    <td width="49%">
        <select name="cakeStyle" >
          <option value=" " selected>--------������--------</option>
          <option value="vanilla cream cake">vanilla cream cake</option>
          <option value="coffee cream cake">coffee cream cake</option>
          <option value="fruit cake">fruit cake</option>
          <option value="cream cake">cream cake</option>
          <option value="sugar cake">sugar cake</option>
          <option value="chocolate cake">chocolate cake</option>
		</select>
     </td>
  </tr>
  <tr> 
    <td align="center">�Ҥ�</td>
    <td>
        <input type="text" name="minPrice" size="10" value="0">
        - 
        <input type="text" name="maxPrice" size="10" value="10000">
    </td>
  </tr>
  <tr> 
    <td align="center">�ӹǹ���</td>
    <td>
        <select name="layer" >
          <option selected value="0">--������--</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
        </select>
      </td>
  </tr>
  <tr> 
    <td align="center">��</td>
    <td>
        <select name="flavour" >
          <option value=" " selected>--������--</option>
          <option value="banana">-��������-</option>
          <option value="butter">��</option>
          <option value="chocolate">��ͤ��ŵ</option>
          <option value="coffee">���</option>
          <option value="pandan">���</option>
          <option value="vanilla">�й���</option>
        </select>
     </td>
  </tr>
  <tr> 
    <td align="center">��Ҵ</td>
    <td>
        <select name="cakeSize" >
          <option selected value="0">--������--</option>
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
        </select>
      </td>
  </tr>
  <tr> 
    <td align="center">�����ç���</td>
    <td>
	   <%if(Seminar_Job_ID==null){%>
        <select name="hotelNumber" >
          <option value="1" selected>Hotel1</option>
          <option value="2">Hotel2</option>
          <option value="3">Hotel3</option>
          <option value="4">Hotel4</option>
          <option value="5">Hotel5</option>
          <option value="6">Hotel6</option>
          <option value="7">Hotel7</option>
          <option value="8">Hotel8</option>
          <option value="9">Hotel9</option>
          <option value="10">Hotel10</option>
        </select>
	<%}else{%>
			<%=hotelcontact.getHotelName()%>
			<input type = "hidden" name = "hotelNumber" value = "<%=hotelcontact.getHotelId()%>">
<%}%>

      </td>
  </tr>
  <tr> 
    <td align="center">��ͧ���Ẻ�١�ش</td>
    <td>
        <input type="radio" name="cheap" value="true" checked>��ͧ���
        <input type="radio" name="cheap" value="false">����ͧ���
      </td>
  </tr>
</table>
  <p align="center">
    <input type="submit" name="Submit4" value="Search">
   <input type = "hidden" name = "weddingContactID" value = "<%=weddingContactID%>">  </p>

</form>
 <!--public org.openuri.www.SearchCakeResult[] hotelSearchCake(java.lang.String cakeStyle, double minprice, double maxprice, int layer, java.lang.String flavour, int cakeSize, boolean cheap, int hotelNumber, int region, int district)  </form>-->
</body>
</html>