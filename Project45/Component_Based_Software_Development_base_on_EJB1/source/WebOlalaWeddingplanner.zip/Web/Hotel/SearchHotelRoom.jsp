<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page import="java.util.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head>	<title>Olala Wedding Planner : Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	//int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		//String tempstr = (String)request.getParameter("Wedding_Contact_ID");
        //int Wedding_Contact_ID = Integer.parseInt(tempstr);
		String tempstr = (String)request.getParameter("Hotel_Name");
		String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

		tempstr = (String)request.getParameter("Hotel_ID");
		int Hotel_ID = Integer.parseInt(tempstr);

%>
<form name="form1" method="post" action="./ResultSearchRoom.jsp">
  <table width="75%" border="1" align="center"  bordercolor="#CCCCCC">
    <tr bgcolor="#FFCCFF"> 
      <td colspan="2" align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ��ͧ�ѡ</td>
    </tr>
    <tr> 
      <td width="51%" align="center">��Դ��ͧ</td>
      <td><select name="roomType" >
          <option value = " " selected>--������--</option>
          <option value = "single">��ͧ��§�����</option>
          <option value = "twin">��ͧ��§���</option>
          <option value = "suite">��ͧ�ٷ</option>
        </select> </td>
    </tr>
    <tr> 
      <td align="center">���Թ</td>
      <td>
                      <select name="date_in">
                        <%
						Date now = new Date();%>
                      <option value = "01" <%if (now.getDate() == 0) { %><%="selected"%><%}%>>01</option>
                      <option value = "02" <%if (now.getDate() == 1) { %><%="selected"%><%}%>>02</option>
                      <option value = "03" <%if (now.getDate() == 2) { %><%="selected"%><%}%>>03</option>
                      <option value = "04" <%if (now.getDate() == 3) { %><%="selected"%><%}%>>04</option>
                      <option value = "05" <%if (now.getDate() == 4) { %><%="selected"%><%}%>>05</option>
                      <option value = "06" <%if (now.getDate() == 5) { %><%="selected"%><%}%>>06</option>
                      <option value = "07" <%if (now.getDate() == 6) { %><%="selected"%><%}%>>07</option>
                      <option value = "08" <%if (now.getDate() == 7) { %><%="selected"%><%}%>>08</option>
                      <option value = "09" <%if (now.getDate() == 8) { %><%="selected"%><%}%>>09</option>
                      <option value = "10" <%if (now.getDate() == 9) { %><%="selected"%><%}%>>10</option>
                      <option value = "11" <%if (now.getDate() == 10) { %><%="selected"%><%}%>>11</option>
                      <option value = "12" <%if (now.getDate() == 11) { %><%="selected"%><%}%>>12</option>
                      <option value = "13" <%if (now.getDate() == 12) { %><%="selected"%><%}%>>13</option>
                      <option value = "14" <%if (now.getDate() == 13) { %><%="selected"%><%}%>>14</option>
                      <option value = "15" <%if (now.getDate() == 14) { %><%="selected"%><%}%>>15</option>
                      <option value = "16" <%if (now.getDate() == 15) { %><%="selected"%><%}%>>16</option>
                      <option value = "17" <%if (now.getDate() == 16) { %><%="selected"%><%}%>>17</option>
                      <option value = "18" <%if (now.getDate() == 17) { %><%="selected"%><%}%>>18</option>
                      <option value = "19" <%if (now.getDate() == 18) { %><%="selected"%><%}%>>19</option>
                      <option value = "20" <%if (now.getDate() == 19) { %><%="selected"%><%}%>>20</option>
                      <option value = "21" <%if (now.getDate() == 20) { %><%="selected"%><%}%>>21</option>
                      <option value = "22" <%if (now.getDate() == 21) { %><%="selected"%><%}%>>22</option>
                      <option value = "23" <%if (now.getDate() == 22) { %><%="selected"%><%}%>>23</option>
                      <option value = "24" <%if (now.getDate() == 23) { %><%="selected"%><%}%>>24</option>
                      <option value = "25" <%if (now.getDate() == 24) { %><%="selected"%><%}%>>25</option>
                      <option value = "26" <%if (now.getDate() == 25) { %><%="selected"%><%}%>>26</option>
                      <option value = "27" <%if (now.getDate() == 26) { %><%="selected"%><%}%>>27</option>
                      <option value = "28" <%if (now.getDate() == 27) { %><%="selected"%><%}%>>28</option>
                      <option value = "29" <%if (now.getDate() == 28) { %><%="selected"%><%}%>>29</option>
                      <option value = "30" <%if (now.getDate() == 29) { %><%="selected"%><%}%>>30</option>
                      <option value = "31" <%if (now.getDate() == 30) { %><%="selected"%><%}%>>31</option>
                      </select>
                      / 
                      <select name="month_in">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="year_in">
                        <option value="2003" selected>2546</option>
                        <option value="2004">2547</option>
                        <option value="2005">2548</option>
                      </select>
                    </td>
    </tr>
    <tr> 
      <td align="center">���͡</td>
      <td>
                      <select name="date_out">
					  <option value = "01" <%if (now.getDate() == 0) { %><%="selected"%><%}%>>01</option>
                      <option value = "02" <%if (now.getDate() == 1) { %><%="selected"%><%}%>>02</option>
                      <option value = "03" <%if (now.getDate() == 2) { %><%="selected"%><%}%>>03</option>
                      <option value = "04" <%if (now.getDate() == 3) { %><%="selected"%><%}%>>04</option>
                      <option value = "05" <%if (now.getDate() == 4) { %><%="selected"%><%}%>>05</option>
                      <option value = "06" <%if (now.getDate() == 5) { %><%="selected"%><%}%>>06</option>
                      <option value = "07" <%if (now.getDate() == 6) { %><%="selected"%><%}%>>07</option>
                      <option value = "08" <%if (now.getDate() == 7) { %><%="selected"%><%}%>>08</option>
                      <option value = "09" <%if (now.getDate() == 8) { %><%="selected"%><%}%>>09</option>
                      <option value = "10" <%if (now.getDate() == 9) { %><%="selected"%><%}%>>10</option>
                      <option value = "11" <%if (now.getDate() == 10) { %><%="selected"%><%}%>>11</option>
                      <option value = "12" <%if (now.getDate() == 11) { %><%="selected"%><%}%>>12</option>
                      <option value = "13" <%if (now.getDate() == 12) { %><%="selected"%><%}%>>13</option>
                      <option value = "14" <%if (now.getDate() == 13) { %><%="selected"%><%}%>>14</option>
                      <option value = "15" <%if (now.getDate() == 14) { %><%="selected"%><%}%>>15</option>
                      <option value = "16" <%if (now.getDate() == 15) { %><%="selected"%><%}%>>16</option>
                      <option value = "17" <%if (now.getDate() == 16) { %><%="selected"%><%}%>>17</option>
                      <option value = "18" <%if (now.getDate() == 17) { %><%="selected"%><%}%>>18</option>
                      <option value = "19" <%if (now.getDate() == 18) { %><%="selected"%><%}%>>19</option>
                      <option value = "20" <%if (now.getDate() == 19) { %><%="selected"%><%}%>>20</option>
                      <option value = "21" <%if (now.getDate() == 20) { %><%="selected"%><%}%>>21</option>
                      <option value = "22" <%if (now.getDate() == 21) { %><%="selected"%><%}%>>22</option>
                      <option value = "23" <%if (now.getDate() == 22) { %><%="selected"%><%}%>>23</option>
                      <option value = "24" <%if (now.getDate() == 23) { %><%="selected"%><%}%>>24</option>
                      <option value = "25" <%if (now.getDate() == 24) { %><%="selected"%><%}%>>25</option>
                      <option value = "26" <%if (now.getDate() == 25) { %><%="selected"%><%}%>>26</option>
                      <option value = "27" <%if (now.getDate() == 26) { %><%="selected"%><%}%>>27</option>
                      <option value = "28" <%if (now.getDate() == 27) { %><%="selected"%><%}%>>28</option>
                      <option value = "29" <%if (now.getDate() == 28) { %><%="selected"%><%}%>>29</option>
                      <option value = "30" <%if (now.getDate() == 29) { %><%="selected"%><%}%>>30</option>
                      <option value = "31" <%if (now.getDate() == 30) { %><%="selected"%><%}%>>31</option>
                      </select>
                      / 
                      <select name="month_out">
                      <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="year_out">
                        <option value="2003" selected>2546</option>
                        <option value="2004">2547</option>
                        <option value="2005">2548</option>
                      </select>
                    </td>
    </tr> 

    <tr> 
      <td align="center">�ӹǹ��ͧ</td>
       <td><input type="text" name="amountRoom" value="1" size="5"></td>
	</tr>
    <tr> 
      <td align="center">�Ҥҷ���ͧ���</td>
       <td><input type="text" name="minprice" value="0" size="10"> �����ҧ <input type="text" name="maxprice" value="100000" size="10"> �ҷ</td>
	</tr>
    <tr> 
      <td align="center">���ҤҶ١�ش</td>
      <td> <input type="radio" name="cheap" value="true"> ��ͧ��� <input type="radio" name="cheap" value="false" checked> ����ͧ��� </td>
    </tr>

<%if (Hotel_Name.equals("null")){%>
    <tr> 
			<td align="center"><input type="radio" name="Near" value="Region" checked>�Ҥ :</td>
			<td> <select name="region">
							<option value = "0">-- �Ҥ --</option>
							<option value = "1">�˹��</option>
							<option value = "2">��ҧ</option>
							<option value = "3">���ѹ�͡</option>
							<option value = "4">���ѹ�͡��§�˹��</option>
							<option value = "5">��</option>
							<option value = "6">���ѹ��</option>
			</select> </td>
    </tr>
    <tr> 
      <td align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  <input type="radio" name="Near" value="District" > ࢵ㹡�ا෾ :</td>
      <td> <select name="district">
          <option value = "0">-- ࢵ --</option>
          <option value = "1"> ��ͧ�� </option>
          <option value = "2"> ��ͧ�ҹ </option>
          <option value = "3"> ��ͧ����� </option>
          <option value = "4"> �ѹ����� </option>
          <option value = "5"> ��بѡ� </option>
          <option value = "6"> ����ͧ </option>
          <option value = "7"> �͹���ͧ </option>
          <option value = "8"> �Թᴧ </option>
          <option value = "9"> ���Ե </option>
          <option value = "10"> ���觪ѹ </option>
          <option value = "11"> ����Ѳ�� </option>
          <option value = "12"> ��觤�� </option>
          <option value = "13"> ������ </option>
          <option value = "14"> �ҧ�͡���� </option>
          <option value = "15"> �ҧ�͡�˭�	</option>
          <option value = "16"> �ҧ�л� </option>
          <option value = "17"> �ҧ�ع��¹ </option>
          <option value = "18"> �ҧࢹ </option>
          <option value = "19"> �ҧ������ </option>
          <option value = "20"> �ҧ� </option>
          <option value = "21"> �ҧ���� </option>
          <option value = "22"> �ҧ�� </option>
          <option value = "23"> �ҧ�͹ </option>
          <option value = "24"> �ҧ��Ѵ </option>
          <option value = "25"> �ҧ�ѡ </option>
          <option value = "26"> ��觡��� </option>
          <option value = "27"> �����ѹ </option>
          <option value = "28"> ������ </option>
          <option value = "29"> ������Һ </option>
          <option value = "30"> ���� </option>
          <option value = "31"> ���⢹� </option>
          <option value = "32"> ��й�� </option>
          <option value = "33"> ������ԭ </option>
          <option value = "34"> �չ���� </option>
          <option value = "35"> �ҹ���� </option>
          <option value = "36"> �Ҫ��� </option>
          <option value = "37"> ��ɮ���ó� </option>
          <option value = "38"> �Ҵ��кѧ </option>
          <option value = "39"> �Ҵ����� </option>
          <option value = "40"> �ѧ�ͧ��ҧ </option>
          <option value = "41"> �Ѳ�� </option>
          <option value = "42"> �ǹ��ǧ </option>
          <option value = "43"> �оҹ�٧ </option>
          <option value = "44"> ����ѹ�ǧ��	</option>
          <option value = "45"> �Ҹ� </option>
          <option value = "46"> ������ </option>
          <option value = "47"> ˹ͧ�� </option>
          <option value = "48"> ˹ͧ�͡ </option>
          <option value = "49"> ��ѡ���	</option>
          <option value = "50"> ���¢�ҧ </option>
        </select> </td>
		<tr> 
      <td align="center">�����ç��� </td>
      <td><select name="hotelNumber">
                      <option value="0" selected>-������-</option>
                      <option value="1" >Hotel1</option>
                      <option value="2">Hotel2</option>
                      <option value="3">Hotel3</option>
                      <option value="4">Hotel4</option>
                      <option value="5">Hotel5</option>
                      <option value="6">Hotel6</option>
                      <option value="7">Hotel7</option>
                      <option value="8">Hotel8</option>
                      <option value="9">Hotel9</option>
                      <option value="10">Hotel10</option>
                    </select> </td>
    </tr>
	<%}else{%>
	
                <tr> 
                  <td align="center">�����ç���</td>
                  <td> <%=Hotel_Name%></td>
                </tr>
				<input type = "hidden" name = "hotelNumber" value = "<%=Hotel_ID%>">
				<input type = "hidden" name = "district" value = "0">
				<input type = "hidden" name = "region" value = "0">
				<input type="hidden" name="Near" value="Region" >
 				<%}%>


  </table>
  <%//public org.openuri.www.SearchRoomResult[] hotelSearchRoom(int amountRoom, java.lang.String roomType, java.lang.String scheckinDate, java.lang.String scheckoutDate, int smoke, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)%>
  <p align="center">
    <input type="submit" name="Submit4" value="����">
  </p>
  </form>
</body>
</html>