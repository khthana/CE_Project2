<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Seminar Room</title>
</head>
<body bgcolor="F9F9EF">

<%
		String Temp_Str=null;
		Temp_Str = (String)request.getParameter("hotelID");
		int hotelNumber = Integer.parseInt(Temp_Str);
		Temp_Str = (String)request.getParameter("jobID");
		int jobID = Integer.parseInt(Temp_Str);
//  public org.openuri.www.SeminarRoomReservationList hotelShowReserveSeminar(int seminarRoomJobId, int hotelNumber)
org.openuri.www.SeminarRoomReservationList reserveList=Hotel.hotelShowReserveSeminar(jobID,hotelNumber);
String time="0";
if(reserveList!=null)
{
int t1=reserveList.getTime6To11Am();
int t2=reserveList.getTime12To5Pm();
int t3=reserveList.getTime6To11Pm(); 
if(t1==1)  time="06:00:00-11:00:00";
if(t1==2)  time="12:00:00-17:00:00";
if(t1==3)  time="18:00:00-23:00:00";
}
%>
<div align="center">
<form name="form1" method="post" action="./Edit.jsp">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr> 
      <td ><div align="center"></div>Job ID</td>
      <td ><div align="center"></div><%=reserveList.getSeminarRoomJobId()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>���ͨѴ����§</td>
      <td ><div align="center"></div><%=reserveList.getSeminarRoomName()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>�����õ���</td>
      <td ><div align="center"></div><%=reserveList.getDecStyle()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>����ʶҹ���</td>
      <td ><div align="center"></div><%=reserveList.getPlaceStyle()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>�ѴẺ</td>
      <td ><div align="center"></div><%=reserveList.getTableLayout()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>�ӹǹ��</td>
      <td ><div align="center"></div><%=reserveList.getMenPerRoom()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>�ѹ�ͧ</td>
      <td ><div align="center"></div><%=reserveList.getReserveDate()%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>����</td>
      <td ><div align="center"></div><%=time%></td>
    </tr>
    <tr> 
      <td ><div align="center"></div>�Ҥ�</td>
      <td ><div align="center"></div><%=reserveList.getJobTotalPrice()%></td>
    </tr>
  </table>
</form>
</div>
</body>
</html>