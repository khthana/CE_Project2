<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Cake</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	Integer tempint = null;

	tempstr = (String)request.getParameter("Hotel_Contact_ID");
	int Hotel_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Cake_Job_ID");
	int Cake_Job_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Seminar_Job_ID");
	int Seminar_Job_ID = Integer.parseInt(tempstr);

	tempstr  = (String)request.getParameter("Flavour");
	String Flavour = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Cake_Name");
	String Cake_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Cake_Style");
	String Cake_Style = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Cake_Size");
	int Cake_Size = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Cake_Layer");
	int Cake_Layer = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Amount");
	int Amount = Integer.parseInt(tempstr);

	tempstr  = (String)request.getParameter("Price");
	double Price = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("Hotel_Name");
	String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Hour");
	String Hour1 = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Minute");
	String Minute1 = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Second");
	String Second1 = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	if (Hour1.length() ==1)
		Hour1 = "0"+Hour1;
	if (Minute1.length()==1)
		Minute1 = "0"+Minute1;
	if (Second1.length() ==1)
		Second1 = "0"+Second1;
		String ServeTime = Hour1+":"+Minute1+":"+Second1;
		//boolean hotelEditCake(int customerId, int cakeJobId, java.lang.String scakeServeTime, int hotelNumber)
		boolean edit = Hotel.hotelEditCake(Customer_id,Cake_Job_ID,ServeTime,Hotel_ID);
		if (edit == false){
	%>
			<p>&nbsp;</p>
			<center>�������ö�����
			<p>&nbsp;</p>
			<a href = "../ShowContact.jsp">˹���á</a></center>
		<%	}
		else
		{
%>
<div align="center">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�÷������ͧ��</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left" width = "30%">���ʡ�èͧ�� : </div></td>
      <td width="70%"> <div align="left"><%=Cake_Job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">������ :</div></td>
      <td> <div align="left"><%=Cake_Name%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">�� :</div></td>
      <td>  <div align="left"><%=Flavour%></div></td>
    </tr>

    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">���� :</div></td>
      <td> <div align="left"><%=Cake_Style%></div></td>
    </tr>
    <tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">��Ҵ :</div></td>
      <td><div align="left"><%=Cake_Size%></div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">�ӹǹ��� :</div></td>
      <td> <div align="left"><%=Cake_Layer%></div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">��������� :</div></td>
      <td> <div align="left"><%=ServeTime%></div></td>
    </tr>
    <tr> 
      <td><div align="center">8.</div></td>
      <td><div align="left">�ӹǹ :</div></td>
      <td> <div align="left"><%=Amount%></div></td>
    </tr>
    <tr> 
      <td><div align="center">9.</div></td>
      <td><div align="left">�Ҥ� :</div></td>
      <td> <div align="left"><%=Price%></div></td>
    </tr>
    <tr> 
      <td><div align="center">10.</div></td>
      <td><div align="left">�����ç��� :</div></td>
      <td> <div align="left"><%=Hotel_Name%></div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
������º��������
<a href = "../ShowContact.jsp">����������´ Contact</a>
	  <%}%>
</div>
</body>
</html>