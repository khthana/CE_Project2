<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Cake</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	Integer tempint = null;

	tempstr = (String)request.getParameter("Hotel_Contact_ID");
	int Hotel_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Cake_Job_ID");
	int Cake_Job_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Seminar_Job_ID");
	int Seminar_Job_ID = Integer.parseInt(tempstr);

	tempstr  = (String)request.getParameter("Flavour");
	String Flavour = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Cake_Name");
	String Cake_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Cake_Style");
	String Cake_Style = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Cake_Size");
	int Cake_Size = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Cake_Layer");
	int Cake_Layer = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Serve_Time");
	String Serve_Time = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Amount");
	int Amount = Integer.parseInt(tempstr);

	tempstr  = (String)request.getParameter("Price");
	double Price = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("Hotel_Name");
	String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);
	Date now = new Date();
	//org.openuri.www.SeminarRoomReservationList hotelShowReserveSeminar(int seminarRoomJobId, int hotelNumber)
	org.openuri.www.SeminarRoomReservationList list = Hotel.hotelShowReserveSeminar(Seminar_Job_ID,Hotel_ID);

	%>
<div align="center">
<form name="form1" method="post" action="./EditHotelCake.jsp">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�÷������ͧ��</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left" width = "30%">���ʡ�èͧ�� : </div></td>
      <td width="70%"> <div align="left"><%=Cake_Job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">������ :</div></td>
      <td> <div align="left"><%=Cake_Name%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">�� :</div></td>
      <td>  <div align="left"><%=Flavour%></div></td>
    </tr>

    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">���� :</div></td>
      <td> <div align="left"><%=Cake_Style%></div></td>
    </tr>
    <tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">��Ҵ :</div></td>
      <td><div align="left"><%=Cake_Size%></div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">�ӹǹ��� :</div></td>
      <td> <div align="left"><%=Cake_Layer%></div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">��������� :</div></td>
      <td> <div align="left">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = Serve_Time.toCharArray();
							for(int j = 0;  j < Serve_Time.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;
				<select name="Hour">
				<%if (list != null){
						if (list.getTime6To11Am() ==1){%>
                <%		for (int i = 6 ; i <= 11 ; i ++) {%>
					<option value = "<%=i%>"><%=i%></option>
                <%}}else if (list.getTime12To5Pm() ==1){
				for (int i = 12 ; i <= 17 ; i ++) {%>
                <option value = "<%=i%>"><%=i%></option>
                <%}}else {
					for (int i = 18 ; i <= 23 ; i ++) {%>
					<option value = "<%=i%>"><%=i%></option>
				<%}}%>
              </select>
              :
              <select name="Minute">
                <%
				for (int i = 0 ; i <= 59 ; i ++) {
				%>
                <option value = "<%=i%>"><%=i%></option>
                <%
				}
		%>
              </select>
			  :
              <select name="Second">
                <%
				for (int i = 0 ; i <= 59 ; i ++) {
				%>
                <option value = "<%=i%>"><%=i%></option>
                <%
				}
		%>
              </select>
		</div></td>
    </tr>
    <tr> 
      <td><div align="center">8.</div></td>
      <td><div align="left">�ӹǹ :</div></td>
      <td> <div align="left"><%=Amount%></div></td>
    </tr>
    <tr> 
      <td><div align="center">9.</div></td>
      <td><div align="left">�Ҥ� :</div></td>
      <td> <div align="left"><%=Price%></div></td>
    </tr>
    <tr> 
      <td><div align="center">10.</div></td>
      <td><div align="left">�����ç��� :</div></td>
      <td> <div align="left"><%=Hotel_Name%></div></td>
    </tr>
  </table>
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Hotel_Contact_ID" value="<%=Hotel_Contact_ID%>">
			<input type="hidden" name="Cake_Job_ID" value="<%=Cake_Job_ID%>">
			<input type="hidden" name="Seminar_Job_ID" value ="<%=Seminar_Job_ID%>">
			<input type="hidden" name="Flavour" value ="<%=Flavour%>">
			<input type="hidden" name="Cake_Name" value="<%=Cake_Name%>">
			<input type="hidden" name="Cake_Style" value="<%=Cake_Style%>">
			<input type="hidden" name="Cake_Size" value="<%=Cake_Size%>">
			<input type="hidden" name="Cake_Layer" value="<%=Cake_Layer%>">
			<input type="hidden" name="Amount" value="<%=Amount%>">
			<input type="hidden" name="Price" value="<%=Price%>">
			<input type="hidden" name="Hotel_Name" value="<%=Hotel_Name%>">
			<input type="hidden" name="Hotel_ID" value="<%=Hotel_ID%>">
<%				if (list != null){%>
			<center><input type = "Submit" value = "Edit"></center>
			<%}%>
</form>
  <p>&nbsp;</p>
</div>
<%}%>
</body>
</html>