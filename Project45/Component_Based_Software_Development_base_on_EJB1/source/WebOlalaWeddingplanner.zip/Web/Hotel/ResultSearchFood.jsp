<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
<%	Weddingplanner1_Impl proxyHotel1 = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel1.getweddingplanner1Soap();%>
        <html>
<head>
<title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;
 
		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("minPrice");
		double minPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("maxPrice");
		double maxPrice = Double.parseDouble(Temp_Str);

		String foodStyle = (String)request.getParameter("foodStyle");

		Temp_Str = (String)request.getParameter("foodName");
		String foodName = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

		boolean cheap=false;
		Temp_Str = (String)request.getParameter("cheap");
		if(Temp_Str.equals("true")) cheap=true;

		Temp_Str = (String)request.getParameter("serveType");
		int foodPer = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("hotelID");
		int hotelID = Integer.parseInt(Temp_Str);

 org.openuri.www.SearchFoodResult[] rs=Hotel2.hotelSearchFood(minPrice,maxPrice,foodStyle," ",foodName,cheap,hotelID, foodPer);
%>
<center>
<table border="1" bordercolor="#CCCCCC" width = "85%">
  <tr  bgcolor="#FFCCFF" > 
    <td align="center">������</td>
    <td align="center">��¡�������</td>
	<%if(foodPer==1){%>
    <td align="center">�Ҥ�(Ẻ�ؿ��)</td>
	<%}else{%>
    <td align="center">�Ҥ�(Ẻ��Шչ)</td>
	<%}%>
    <td  align="center">�����ç���</td>
    <td align="center">�ͧ</td>
<!--    public java.lang.String[] hotelShowFoodPackage(int hotelID, int foodPackageId)-->
  </tr>

  <%
		if(rs!=null)
		  for(int i=0;i<rs.length;i++){
 		 String[] fName= Hotel.hotelShowFoodPackage(hotelID,rs[i].getFoodPackageId());
		  %>
	  <form name="form1" method="post" action="ReserveFood.jsp">
		  <tr rowspan=<%=fName.length%>>
		  <td align="center"><%=rs[i].getFoodStyle()%></td>
		  <td>
					<% 
							// public java.lang.String[] hotelShowFoodPackage(int hotelID, int foodPackageId)
							for(int j=0;j<fName.length;j++){
					%>
					<div align="center"><%=fName[j]%></div>
					<%}%>
		  </td>
	<%if(foodPer==1){%>
		  <td align="center"><%=rs[i].getFoodPricePerPerson()%></td>
	<%}else{%>
		  <td align="center"><%=rs[i].getFoodPricePerTable()%></td>
	<%}%>
		  <td align="center"><%=rs[i].getHotelName()%></td>
		  <td align="center"> <input type="submit" name="Submit4" value="�ͧ"></td>
	   <input type = "hidden" name = "weddingContactID" value = "<%=weddingContactID%>">
	   <input type = "hidden" name = "foodStyle" value = "<%=rs[i].getFoodStyle()%>">
	   <input type = "hidden" name = "foodPackageID" value = "<%=rs[i].getFoodPackageId()%>">
	   <input type = "hidden" name = "foodPricePerPerson" value = "<%=rs[i].getFoodPricePerPerson()%>">
	   <input type = "hidden" name = "foodPricePerTable" value = "<%=rs[i].getFoodPricePerTable()%>">
	   <input type = "hidden" name = "hotelName" value = "<%=rs[i].getHotelName()%>">
	   <input type = "hidden" name = "hotelID" value = "<%=hotelID%>">
	   <input type = "hidden" name = "foodPer" value = "<%=foodPer%>">
		</form>
<%}%>
	</tr>
</table>
</center>
</body>
</html>