<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Hotel_Contact_ID");
	int Hotel_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Room_Job_ID");
	int Room_Job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Hotel_Name");
	String Hotel_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);
	//////////////////////////////////////////////////////////////find deadline//////////////////////////////////////
String deadline="";
boolean lockButton=false;
org.openuri.www.WeddingContactDetail[] detail = soapProxy.find_Wedding_Contact(Customer_id);
for(int j=0;j<detail.length;j++)
	if(detail[j].getWeddingContactID()==Wedding_Contact_ID) deadline=detail[j].getDeadline();
if(deadline.equals("-1")) lockButton=true;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	//org.openuri.www.RoomReservationList hotelShowReserveRoom(int roomJobId, int hotelNumber)
	org.openuri.www.RoomReservationList list = Hotel.hotelShowReserveRoom(Room_Job_ID, Hotel_ID);
	if (list != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��������´��èͧ��ͧ�ѡ</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">���ʡ�èͧ :</div></td>
      <td width="65%"><div align="center"><%=list.getRoomJobId()%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">�����Ţ��ͧ :</div></td>
      <td><div align="center"><%=list.getRoomId()%></div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">�������ͧ��ͧ :</div></td>
      <td> <div align="center"><%=list.getRoomType()%></div></td>
    </tr>
    <tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">��Ҵ��ͧ :</div></td>
      <td><div align="center"><%=list.getRoomSize()%></div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">�ӹǹ�������ͧ :</div></td>
      <td><div align="center"><%=list.getMaximumMenPerRoom()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ѹ��Ҿѡ :</div></td>
      <td><div align="center"><%=list.getCheckinDate()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">�ѹ�͡ :</div></td>
      <td><div align="center"><%=list.getCheckoutDate()%></div></td>
    </tr>
    <tr>
      <td><div align="center">8.</div></td>
      <td><div align="center">����§����� :</div></td>
      <td><div align="center"><%=list.getExtrabed()%></div></td>
    </tr>
    <tr>
      <td><div align="center">9.</div></td>
      <td><div align="center">�Ҥ���ͧ :</div></td>
      <td><div align="center"><%=list.getJobTotalPrice()%>&nbsp;�ҷ</div></td>
    </tr>
    <tr>
      <td><div align="center">10.</div></td>
      <td><div align="center">�����ç��� :</div></td>
      <td><div align="center"><%=Hotel_Name%>&nbsp;</div></td>
    </tr>
  </table>
<center>
<form name="form2" method="post" action="./CancelRoomJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Hotel_Contact_ID" value="<%=Hotel_Contact_ID%>">
			<input type="hidden" name="Room_Job_ID" value="<%=list.getRoomJobId()%>">
			<input type="hidden" name="Hotel_ID" value="<%=Hotel_ID%>">
          <input type="submit" name="Submit2" value="Cancel Job" <%if(lockButton){%>disabled<%}%>>
        </form>
  </center>
  <p>&nbsp;</p>
</div>
  <%}else {%>
		<center>�������������´��èͧ</center>
<%  }%>
</body>
</html>