<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
String Temp_Str = null;

		int customerID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

		Temp_Str = (String)request.getParameter("weddingContactID");
		int weddingContactID = Integer.parseInt(Temp_Str);
			
		
		String cakeStyle = (String)request.getParameter("cakeStyle");

		Temp_Str = (String)request.getParameter("minPrice");
		double minPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("maxPrice");
		double maxPrice = Double.parseDouble(Temp_Str);

		Temp_Str = (String)request.getParameter("layer");
		int layer = Integer.parseInt(Temp_Str);

		String flavour = (String)request.getParameter("flavour");
   	    
		Temp_Str = (String)request.getParameter("cakeSize");
		int cakeSize = Integer.parseInt(Temp_Str);

		boolean cheap=false;
		Temp_Str = (String)request.getParameter("cheap");
		if(Temp_Str.equals("true")) cheap=true;

		Temp_Str = (String)request.getParameter("hotelNumber");
		int hotelNumber = Integer.parseInt(Temp_Str);
/////////////////////////////////////////////////////////////////////////////
	    org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(customerID, weddingContactID);
		int[] Seminar_Job_ID = null;
	//	out.print(hotelcontact);
	if (hotelcontact != null){
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(customerID,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null)
			if(alljob.getSeminarRoomJobId()!=null)
				if( alljob.getSeminarRoomJobId()[0]>0)
						Seminar_Job_ID =  alljob.getSeminarRoomJobId();
		}
//////////////////////////////////////////////////////////////////////////////
/*public org.openuri.www.SearchCakeResult[] hotelSearchCake(java.lang.String cakeStyle, double minprice, double maxprice, int layer, java.lang.String flavour, int cakeSize, boolean cheap, int hotelNumber, int region, int district)  </form>-*/
//org.openuri.www.SearchSeminarRoomResult[] a=Hotel.hotelSearchSeminar(place_style,dec_style,seminar_room_size_min,seminar_room_size_max,seminarminprice,seminarmaxprice,sreserve_date,t0t11_am,t12t5_pm,t6t11_pm,cheap,hotelnumber1,district,region);
org.openuri.www.SearchCakeResult[] rs=Hotel2.hotelSearchCake(cakeStyle,minPrice,maxPrice,layer,flavour,cakeSize,cheap,hotelNumber,0,0);
%>
<center>
<table border="1" bordercolor="#CCCCCC" width = "85%">
  <tr  bgcolor="#FFCCFF"> 
    <td align = "center">����</td>
    <td align = "center">����</td>
    <td align = "center">��Ҵ</td>
    <td align = "center">�ӹǹ���</td>
    <td align = "center">��</td>
    <td align = "center">�����ç���</td>
    <td align = "center">�Ҥ�</td>
    <td align = "center">�ͧ</td>
  </tr>
<%
	if(rs!=null){
	//	out.print(rs.length);
		for(int i=0;i<rs.length;i++)
			if((rs[i]!=null)&&(rs[i].getCakePrice()!=0))
		{%>
   <form name="formX" method="post" action="ReserveCake.jsp"> 
	  <tr> 
		<td align = "center"><%=rs[i].getCakename()%></td>
		<td align = "center"><%=rs[i].getCakestyle()%></td>
		<td align = "center"><%=rs[i].getCakeSize()%></td>
		<td align = "center"><%=rs[i].getLayer()%></td>
		<td align = "center"><%=rs[i].getFlavour()%></td>
		<td align = "center"><%=rs[i].getHotelName()%></td>
		<td align = "center"><%=rs[i].getCakePrice()%></td>
		<%if(Seminar_Job_ID!=null){%>
        <td><div align="center"><input type = "submit" value = "Reserve" name = "�ͧ"></div></td>
		<%}%>
		 <input type="hidden"name="weddingContactID" value = "<%=weddingContactID%>">
		<input type="hidden"name="cakeStyle" value = "<%=rs[i].getCakestyle()%>">
		<input type="hidden"name="cakeName" value = "<%=rs[i].getCakename()%>">
	    <input type="hidden"name="cakeSize" value = "<%=rs[i].getCakeSize()%>">
		<input type="hidden"name="cakeLayer" value = "<%=rs[i].getLayer()%>">
		<input type="hidden"name="cakeFlavour" value = "<%=rs[i].getFlavour()%>">
		<input type="hidden"name="cakePrice" value = "<%=rs[i].getCakePrice()%>">
		<input type="hidden"name="hotelName" value = "<%=rs[i].getHotelName()%>">
		<input type="hidden"name="cakeID" value = "<%=rs[i].getCakeId()%>">
		<input type="hidden"name="hotelD" value = "<%=rs[i].getHotelID()%>">
<!--- public org.openuri.www.ReturnReserve hotelReserveCake(int customerId, java.lang.String cakeFlavour, int cakeId, int seminarRoomJobId, int hotelContactId, java.lang.String scakeServeTime, short cakeAmount, int hotelID, int weddingContactID)
       throws java.rmi.RemoteException ;-->
	 </tr>
</form>
<%
		}}//for
%>
</table>
</center>
</body>
</html>