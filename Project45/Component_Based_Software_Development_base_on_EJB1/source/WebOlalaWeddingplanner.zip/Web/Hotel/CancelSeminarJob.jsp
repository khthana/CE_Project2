<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head><title>Olala Wedding Planner : Cancel Job Room</title></head>
<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Hotel_Contact_ID");
    int Hotel_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Seminar_Job_ID");
    int Seminar_Job_ID = Integer.parseInt(tempstr);
	tempstr =(String)request.getParameter("Hotel_ID");
	int Hotel_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	//boolean hotelCancelSeminar(int customerId, int hotelContactId, int seminarRoomJobId, int weddingContactID)
    boolean cancel = Hotel.hotelCancelSeminar(Customer_id,Hotel_Contact_ID,Seminar_Job_ID,Wedding_Contact_ID);
    if (cancel == true)
    {
		//org.openuri.www.ShowAllJobid hotelShowJobID(int customerId, int hotelContactId, int hotelNumber)
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(Customer_id,Hotel_Contact_ID,Hotel_ID);
		int[] roomjob = alljob.getRoomJobId();
		int[] seminarjob = alljob.getSeminarRoomJobId();
		int[] cakejob = alljob.getCakeJobId();
		int[] foodjob = alljob.getFoodJobId();
		int[] flowerjob = alljob.getFlowerJobId();
		if(foodjob[0]>0) 
		for(int i=0;i<foodjob.length;i++) 
			Hotel.hotelCancelFood(Customer_id,Hotel_Contact_ID,foodjob[i],Wedding_Contact_ID);
		if(cakejob[0]>0) 
		for(int i=0;i<cakejob.length;i++) 
			Hotel.hotelCancelCake(Customer_id,Hotel_Contact_ID,cakejob[i],Wedding_Contact_ID);
		if(flowerjob[0]>0) 
		for(int i=0;i<flowerjob.length;i++) 
			Hotel.hotelCancelFlower(Customer_id,Hotel_Contact_ID,flowerjob[i],Wedding_Contact_ID);

      response.sendRedirect("../ShowJob.jsp#seminar");}
%>
</body>
</html>