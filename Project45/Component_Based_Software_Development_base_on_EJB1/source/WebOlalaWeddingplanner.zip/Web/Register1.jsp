<%@ page contentType = "text/html;charset=WINDOWS-874" import="weblogic.jws.proxies.*" %>
<html>

<!-- Mirrored from www.weddingchannel.com/cgi-bin/gx.cgi/AppLogic+com.wc.Utility.NavBarForStaticHTML?location=/templates/HomePage/Article30.html by HTTrack Website Copier/3.x [XR&CO'2002], Tue, 03 Dec 2002 11:10:22 GMT -->
<head>
<title>Olala Wedding Planner - Getting Started</title>
<!--Java Script that i don't understand-->
<script type="text/javascript">
<!--
if (navigator.userAgent.indexOf('Win') != -1)
{
	document.write('<link href="Index/PStyle.css" rel="stylesheet" type="text/css">');
}
else if (navigator.userAgent.indexOf('Mac') != -1)
{
	document.write('<link href="Index/MStyle.css" rel="stylesheet" type="text/css">');
}
// -->
</script>
<noscript>
<link href="Index/PStyle.css" rel="stylesheet" type="text/css">
</noscript>

<script language="javascript"><!--
function jumpToLocal(category) {
	var allcookies = document.cookie;

	var pos = allcookies.indexOf("LBD%5FLOCATION%5FCOOKIE=");

	if (pos != -1) {
		var start = pos + 24;
		var end = allcookies.indexOf(";", start);
		if (end == -1)
			end = allcookies.length;
		var LBD_cookie = allcookies.substring(start, end);



		window.location = "http://wedding.weddingchannel.com/local/featured_vendor_result.asp?category="+ category + "&ruid=&vuid=&search_type=regional&" + LBD_cookie;
	} else {
		window.open("http://wedding.weddingchannel.com/local/search_area.asp?category=" + category, "_popup", "width=379,height=270");
	}
}
//--></script>

<style type="text/css">
body, td, li, ol, p {color: #333333; font: 10pt verdana,geneva,arial,helvetica,sans-serif;}
.small {font-size: 8pt;}
.large {font-size: 11pt;}
.fulltime{color: #565692; font: 10pt verdana,geneva,arial,helvetica,sans-serif;}
a:link {color:#6666cc;}
a:active {color:#6666cc;}
a:visited {color:#666699;}
a:hover {color:#6699ff;}
.form {font-family: courier;}
.green{color: #366333; font: 10pt verdana,geneva,arial,helvetica,sans-serif; font-weight: bold;}
.red{color: #c15555; font: 10pt verdana,geneva,arial,helvetica,sans-serif; font-weight: bold;}
.red2{color: #CD2525; font: 12pt verdana,geneva,arial,helvetica,sans-serif; font-weight: bold;}
.quote{color: #CD2525; font: 10pt verdana,geneva,arial,helvetica,sans-serif; font-weight: bold;}
.quotetext{color: #CD2525; font: 10pt verdana,geneva,arial,helvetica,sans-serif;}
</style>
<script language="JavaScript">
<!--
var begin = new Date()
var startYear = new Date("January 1, 1970")
startYear.setYear(begin.getYear())
var random = (begin.getTime() - startYear.getTime())
// -->
</script>
</head>
<body marginwidth=0 marginheight=0 leftmargin=0 topmargin=0 rightmargin=0>
<SCRIPT language="JavaScript1.2" src="Index/Snow.js" type="text/javascript"></SCRIPT>
<CENTER>

 <table border=0 cellspacing="0" cellpadding="0">
	<TR VALIGN="BOTTOM">
		<TD><!--<iframe src="http://ad.doubleclick.net/adi/tips.wc.com/tales;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=468x60;tile=1;ord=1038909735618189?" name="frame1" width="468" height="60" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no"><script language="JavaScript1.1" src="http://ad.doubleclick.net/adj/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=468x60;tile=1;ord=1038909735618189?"></script><noscript><a href="http://ad.doubleclick.net/jump/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=468x60;tile=1;ord=1038909735618189?"><img src="http://ad.doubleclick.net/ad/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=468x60;tile=1;ord=1038909735618189?" border="0" width="468" height="60"></a></noscript></iframe>--></TD>
		<TD><!--<img src="Index/clear.gif" width=4 height=1 border=0>--></TD>
		<td><!--<iframe src="http://ad.doubleclick.net/adi/tips.wc.com/tales;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=234x60;tile=2;ord=1038909735618189?" name="frame1" width="234" height="60" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no"><script language="JavaScript1.1" src="http://ad.doubleclick.net/adj/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=234x60;tile=2;ord=1038909735618189?"></script><noscript><a href="http://ad.doubleclick.net/jump/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=234x60;tile=2;ord=1038909735618189?"><img src="http://ad.doubleclick.net/ad/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=234x60;tile=2;ord=1038909735618189?" border="0" width="234" height="60"></a></noscript></iframe>--></TD>
	</TR>
</TABLE>
<img src="index/clear.gif" width=1 height=3 border=0><br>


<script type="text/javascript">var g_strPopMenuGraphicsDir = "Index/";</script>

<script language="JavaScript1.2" src="Index/newnav.js" type="text/javascript"></script>
	<!-- begin menu.js -->
<script language="JavaScript1.2" src = "INDEX/Menu.js" type="text/javascript"></script>
<!-- end menu.js -->
<!-- begin menubar.js -->
<script language="JavaScript1.2" src = "INDEX/Menubar.js" type="text/javascript"></script>
</script>
<!-- end menubar.js -->

<table align=center width=770 cellspacing=0 cellpadding=0 border=0>

	<!-- clr.gif & ping -->
	<tr>
		<td bgcolor=#999999 colspan=4><img src="INDEX/clr.gif" width=1 height=1><img src="INDEX/clr.gif" width=1 height=1></td>
	</tr>

	<!-- formatting row -->
	<tr>
		<td width=1 rowspan=3 bgcolor=#999999><img src="INDEX/clr.gif" width=1 height=1></td>
		<td bgcolor=#F9F9EF colspan=2><img src="INDEX/clr.gif" width=768 height=1></td>
		<td width=1 rowspan=3 bgcolor=#999999><img src="INDEX/clr.gif" width=1 height=1></td>
	</tr>

	<!-- logo, guest & bride links -->
	<tr>
		<td bgcolor=#F9F9EF valign=bottom>
			<table cellspacing=0 cellpadding=0 border=0>
				<tr>
					<td valign=bottom><img src="INDEX/clr.gif" width=1 height=1><br>
              <img src="Index/Logo.JPG" width=256 height=30 border=0 hspace=8 vspace=4></td>
					<td rowspan=2 align=center id=smNoColor><img src="INDEX/clr.gif" width=1 height=1></td>
				</tr>
				<tr>

            <td><img src="Index/clr.gif" width=18 height=1><img src="INDEX/b_g_on_tab.gif" width=107 height=16 border=0></td>
				</tr>
			</table>
		</td>
		<td bgcolor=#F9F9EF align=right valign=bottom>
			<table align=right cellspacing=0 cellpadding=0 border=0>
				<tr>

            <td valign=middle nowrap id=sm><a target=_top href="http://wedding.weddingchannel.com/login/login.asp?pageid=bride&disr=true"><font color=#BB3002></font></a>
              |</td>

            <td valign=top>&nbsp;&nbsp;</td>
            <td nowrap valign=middle id=sm><a target=_top href="http://wedding.weddingchannel.com/search_purchase/shopping_bag_redirector.asp"></a>
            </td>
				</tr>
			</table>
			<br clear=all>
			<table align=right cellspacing=0 cellpadding=0 border=0>
				<tr>
					<td colspan=3><img src="Index/clr.gif" width=1 height=5></td>
				</tr>
				<tr><form target=_top action="http://wedding.weddingchannel.com/azIndex/search.asp" method=post>
					<td nowrap class=menubar><font color=#3366cc><b>Search:</b></font>&nbsp;<input type=text id=smallfont name=query size=10>&nbsp;</td>

              <td>&nbsp;</td>

              <td nowrap valign=bottom class=menubar>&nbsp;&nbsp;<br>
                <img src="Index/clr.gif" width=1 height=5></td></form>
				</tr>
				<tr>
					<td colspan=3><img src="Index/clr.gif" width=1 height=3></td>
				</tr>
			</table></td>
	</tr>
	<tr align=center>
<SCRIPT language="Javascript1.2" src="Index/linkmenu.js" type="text/javascript"></SCRIPT>
	</tr>

</table>
<!-- -----  End Top NavBar ------ -->

<img src="Index/clear.gif" width=1 height=4 border=0><br>

<table align="center" bgcolor="#aba4a4" cellpadding="0" cellspacing="0" height="498"  width="770" border=0>
<tr>
	<td><img src="Index/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
	<td width="768"><img src="Index/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
	<td><img src="Index/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
</tr>
<tr>
	<td height="496"><img src="Index/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
	<td bgcolor="#ffffff">
	<table align="center" border=0 cellpadding="0" cellspacing="0" height="496" width="768">
<tr>
	        <td width="132" bgcolor="#f9f9ef" align="left" valign="top"> <p>&nbsp; </p>

              <p> <br>
              </p>



              <p><br></p>
              <p>&nbsp; </p> </td>
	<td bgcolor="#aba4a4"><img src="Index/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
	        <td width="508" valign="top"> <br>

<% 	OlalaWeddingPlanner_Impl proxy = new OlalaWeddingPlanner_Impl();
	OlalaWeddingPlannerSoap soapProxy = proxy.getOlalaWeddingPlannerSoap(); %>

	<!-- Get parameter username for register -->
	<%
		if (request.getParameter("username") == null)
		{
	%>

            <form name="form1" method="post" action="ToRegister.jsp">
              <table align="center" border=0 cellpadding="0" cellspacing="0" width="467">
                <tr>
                  <td align= "left">
<center>
                        <p><font color="#000099" size="4"> ��سҡ�͡������
                          </font></p>
                    </center>
                    <table width="457" >
                      <tr>
                        <td width="130">���ͼ����</td>
                        <td width="315" >
                            <input type="text" name="username">
                          </td>
                      </tr>
                      <tr>
                        <td>���ʼ�ҹ</td>
                        <td>
                            <input type="password" name="password">(���ҧ���� 6 ����ѡ��)
                          </td>
                      </tr>
                      <tr>
                        <td>�׹�ѹ���ʼ�ҹ</td>
                        <td>
                            <input type="password" name="confirmpwd">(���ҧ���� 6 ����ѡ��)
                          </td>
                      </tr>
                    </table>

                    <p></p></td>
                </tr>
                <tr>
                    <td width="467"><div align="center"><font color="#000099" size="3">����Ѻ��Һ���</font><BR>
                      </div>
                      <table width="455" border="0">
                        <tr>
                          <td width="123">����</td>
                          <td width="322"> <input width="300" type="text" name="M_name">
                          </td>
                        </tr>
                        <tr>
                          <td>���ʡ��</td>
                          <td><input width="300" name="M_surname" type="text"></td>
                        </tr>
                        <tr>
                          <td>�������</td>
                          <td> <input width="300" type="text" name="M_address">
                          </td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <input width="300" type="text" name="M_address1">
                          </td>
                        </tr>
                        <tr>
                          <td>�ѹ�Դ</td>
                          <td><select name="M_date">
                          <%int i;
                          for (i = 1; i <= 31; i++)
                          {
                          %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                          <%}%>
                            </select>
                            /
                            <select name="M_month">
                            <OPTION value=1 selected>���Ҥ�
                            <OPTION value=2>����Ҿѹ��
                            <OPTION value=3>�չҤ�
                            <OPTION value=4>����¹
                            <OPTION value=5>����Ҥ�
                            <OPTION value=6>�Զع�¹
                            <OPTION value=7>�á�Ҥ�
                            <OPTION value=8>�ԧ�Ҥ�
                            <OPTION value=9>�ѹ��¹
                            <OPTION value=10>���Ҥ�
                            <OPTION value=11>��Ȩԡ�¹
                            <OPTION value=12>�ѹ�Ҥ�
                            </select>
                            /
                            <select name="M_year">
                            <%
                            for (i = 1920;i < 2006; i++)
                            {
                            %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                            <%}%>
                            </select> </td>
                        </tr>
                        <tr>
                          <td height="33">�������Ѿ��</td>
                          <td><input type="text" name="M_phone"> </td>
                        </tr>
                        <tr>
                          <td>�������ʹ���</td>
                          <td><input type="text" name="M_email"></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td>&nbsp; </td>
                        </tr>
                      </table>
                      <div align="center"><font color="#000099" size="3">����Ѻ������</font></div></td>
                </tr>
                <tr>
                  <td><table width="460" border="0">
                        <tr>
                          <td width="122">����</td>
                          <td width="328"> <input width="300" type="text" name="F_name">
                          </td>
                        </tr>
                        <tr>
                          <td>���ʡ��</td>
                          <td><input width="300" type="text" name="F_surname"></td>
                        </tr>
                        <tr>
                          <td>�������</td>
                          <td> <input width="300" type="text" name="F_address">
                          </td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <input width="300" type="text" name="F_address1">
                          </td>
                        </tr>
                        <tr>
                          <td>�ѹ�Դ</td>
                          <td><select name="F_date">
                          <%
                          for (i = 1;i <= 31; i++)
                          {
                          %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                          <%}%>
                            </select>
                            /
                            <select name="F_month">
                            <OPTION value=1 selected>���Ҥ�
                            <OPTION value=2>����Ҿѹ��
                            <OPTION value=3>�չҤ�
                            <OPTION value=4>����¹
                            <OPTION value=5>����Ҥ�
                            <OPTION value=6>�Զع�¹
                            <OPTION value=7>�á�Ҥ�
                            <OPTION value=8>�ԧ�Ҥ�
                            <OPTION value=9>�ѹ��¹
                            <OPTION value=10>���Ҥ�
                            <OPTION value=11>��Ȩԡ�¹
                            <OPTION value=12>�ѹ�Ҥ�
                            </select>
                            /
                            <select name="F_year">
                            <%
                            for (i = 1920;i < 2006; i++)
                            {
                            %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                            <%}%>
                            </select> </td>
                        </tr>
                        <tr>
                          <td>�������Ѿ��</td>
                          <td><input type="text" name="F_phone"> </td>
                        </tr>
                        <tr>
                          <td>�������ʹ���</td>
                          <td><input type="text" name="F_email"></td>
                        </tr>
                      </table></td>
                </tr>
                <tr>
                  <td align="center"><br>
                      <input type="submit" name="Submit" value="ŧ����¹">
                    </td>
                </tr>
              </table>
			 </form>
<%
	}
	else
	{

	}
%>




<img src="Index/clr.gif" align="" width="496" height="1" border="0" alt=""></td><td bgcolor="#aba4a4"><img src="INDEX/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
<!-- BEGIN COLUMN 3 -->
	        <td width="132" align="CENTER" valign="TOP" bgcolor="#F9F9EF">
              <!-- Banner number 1 -->
              <BR>
<img src="INDEX/barbar.gif" align="" width="132" height="1" border="0" alt="">
<img src="INDEX/clear.gif" align="" width="5" height="7" border="0" alt=""><BR>
<!-- BANNER AD 2 -->
<!--<iframe src="http://ad.doubleclick.net/adi/tips.wc.com/tales;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=120x240;tile=3;ord=1038909735618189?" name="frame1" width="120" height="240" frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no"><script language="JavaScript1.1" src="http://ad.doubleclick.net/adj/tips.wc.com/tales;abr=!ie;!category=weddingchannel;bp=weddingchannel;ruid=000;sz=120x240;tile=3;ord=1038909735618189?"></script><noscript>
              </noscript></iframe>-->
	<BR>
              <img src="INDEX/WEDSHOP120X90A.GIF" width="120" height="90">
            </td>
</tr>
</table>


</td>
	<td><img src="INDEX/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
</tr>
<tr>
	<td><img src="INDEX/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
	<td><img src="INDEX/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
	<td><img src="INDEX/clr.gif" align="" width="1" height="1" border="0" alt=""></td>
</tr>
</table>

  <span> </span>
</CENTER>
</body>

<!-- Mirrored from www.weddingchannel.com/cgi-bin/gx.cgi/AppLogic+com.wc.Utility.NavBarForStaticHTML?location=/templates/HomePage/Article30.html by HTTrack Website Copier/3.x [XR&CO'2002], Tue, 03 Dec 2002 11:11:10 GMT -->
</html>
