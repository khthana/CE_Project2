<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%Payment_Impl proxyPay = new Payment_Impl();
	PaymentSoap PaysoapProxy = proxyPay.getpaymentSoap();%>
<html>
<head><title>��è����Թ</title></head>

<body bgcolor="F9F9EF">
<%String tempstr = (String)request.getParameter("Wedding_Contact_ID");
	int Wedding_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Wedding_Contact_Name");
	String Wedding_Contact_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Price");
	double Price = Double.parseDouble(tempstr);
	Date now = new Date();
%>
<form name="form1" method="post" action="./Pay.jsp">
  <table width="75%" height="204" border="1" align="center"  bordercolor="#CCCCCC">
    <tr bgcolor="#FFCCFF"> 
      <td height="35" colspan="3"><div align="center">��è����Թ</div></td>
    </tr>
    <tr> 
      <td width="6%" height="35"> <div align="center">1.</div></td>
      <td width="32%">���� contact :</td>
      <td width="62%"><%=Wedding_Contact_Name%></td>
    </tr>
    <tr> 
      <td width="6%" height="30"> <div align="center">2.</div></td>
      <td width="32%">�Ҥҷ����� :</td>
      <td width="62%"><%=Price%>&nbsp;�ҷ</td>
    </tr>
    <tr> 
      <td width="6%" height="31"> <div align="center">3.</div></td>
      <td width="32%">�����Ţ�ѵ��ôԵ :</td>
      <td width="62%"> <input type="text" name="creditnumber"></td>
    </tr>
    <tr> 
      <td height="29"> <div align="center">4.</div></td>
      <td>�ѹ������� :</td>
      <td>��͹ 
        <select name="Month">
          <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
          <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
          <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
          <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
          <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
          <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
          <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
          <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
          <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
          <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
          <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
          <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
        </select>
        �� 
        <select name="Year">
          <option value="2003" selected>2546</option>
          <option value="2004">2547</option>
          <option value="2005">2548</option>
        </select> </td>
    </tr>
    <tr> 
      <td height="30"> <div align="center">5.</div></td>
      <td>���ʼ�ҹ :</td>
      <td><input type="password" name="password"> &nbsp;</td>
    </tr>
    <tr> 
      <td height="35" colspan="3"><div align="center"><input type="submit" name="Submit" value="�����Թ"></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
	<input type = "hidden" name = "Wedding_Contact_Name" value = "<%=Wedding_Contact_Name%>">
	<input type = "hidden" name = "Price" value = "<%=Price%>">
  </table>
</form>
</body>
</html>