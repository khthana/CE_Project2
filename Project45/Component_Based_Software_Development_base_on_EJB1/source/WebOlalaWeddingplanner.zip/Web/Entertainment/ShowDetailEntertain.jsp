<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.EntertainJobDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
  <%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");

	Integer tempint = new Integer(tempstr);
    int Wedding_contact_ID = tempint.intValue();

	tempstr = (String)request.getParameter("Entertain_Contact_ID");
	tempint = new Integer(tempstr);
	int Entertain_contact_ID = tempint.intValue();

	tempstr = (String)request.getParameter("Entertain_Name");
	String Entertain_name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Entertain_Address");
	String Entertain_address = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Entertain_Job_ID");
	tempint = new Integer(tempstr);
	int Entertain_job_ID = tempint.intValue();

	org.openuri.www.EntertainJobDetail list = soapProxy.entertainment_Job_Detail(Wedding_contact_ID,Entertain_contact_ID,Entertain_job_ID);
	if (list != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��¡�çҹ�������ͧ�͹����෹�����</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">���ʡ���ʴ�</div></td>
      <td width="65%"><div align="center"><%=Entertain_job_ID%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">����ǧ����� - ����ʴ�</div></td>
      <td><div align="center"><%=list.getBandName()%></div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">��������´</div></td>
      <td> <div align="center"><%=list.getDetail()%></div></td>
    </tr>
    <tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">�������������ʴ�</div></td>
      <td><div align="center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = list.getStartDatetime().toCharArray();
							for(int j = 0;  j < list.getStartDatetime().length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">��������ش����ʴ�</div></td>
      <td><div align="center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =list.getFinishDatetime().toCharArray();
							for(int j = 0;  j < list.getFinishDatetime().length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
		</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">ʶҹ���</div></td>
      <td><div align="center"><%=list.getPlace()%></div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">�Ҥ�</div></td>
      <td><div align="center"><%=list.getPrice()%>&nbsp;�ҷ</div></td>
    </tr>
    <tr>
      <td><div align="center">8.</div></td>
      <td><div align="center">�ѡɳТͧ�ҹ</div></td>
      <td><div align="center"><%=list.getFunctionType()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">9.</div></td>
      <td><div align="center">��������´�������</div></td>
      <td><div align="center"><%if(list.getAdditionalRequests()==null)
	  {
		out.print("�����");
	  }else out.print(list.getAdditionalRequests());%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">10.</div></td>
      <td><div align="center">�ѹ�׹�ѹ��èͧ</div></td>
      <td><div align="center"><%=list.getPayDate()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">11.</div></td>
      <td><div align="center">���ͺ���ѷ�͹����෹�����</div></td>
      <td><div align="center"><%=Entertain_name%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">12.</div></td>
      <td><div align="center">����������ѷ�͹����෹�����</div></td>
      <td><div align="center"><%=Entertain_address%>&nbsp;</div></td>
    </tr>
    <tr>
      <td width="5%"><div align="center"></div></td>
      <td width="30%"><div align="center"></div></td>
      <td><div align="center"></div></td>
    </tr>
  </table>

  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditEntertain.jsp">
          <div align="right">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
			<input type="hidden" name="Entertain_Contact_ID" value="<%=Entertain_contact_ID%>">
			<input type="hidden" name="Entertain_Job_ID" value="<%=Entertain_job_ID%>">
			<input type="hidden" name="Band_Type_ID" value="<%=list.getBandTypeId()%>">
          <input type="hidden" name="Additional_Requests" value="<%=list.getAdditionalRequests()%>">
          <input type="hidden" name="Band_ID" value="<%=list.getBandId()%>">
          <input type="hidden" name="Band_Name" value="<%=list.getBandName()%>">
          <input type="hidden" name="Detail" value="<%=list.getDetail()%>">
          <input type="hidden" name="Finish_Datetime" value="<%=list.getFinishDatetime()%>">
          <input type="hidden" name="Function_Type" value="<%=list.getFunctionType()%>">
          <input type="hidden" name="Place" value="<%=list.getPlace()%>">
          <input type="hidden" name="Start_Datetime" value="<%=list.getStartDatetime()%>">
		  <input type="hidden" name="PayDate" value="<%=list.getPayDate()%>">
		  <input type="hidden" name="Price" value="<%=list.getPrice()%>">
		  <input type="hidden" name="Entertain_name" value ="<%=Entertain_name%>">
		  <input type="hidden" name="Entertain_address" value="<%=Entertain_address%>">
			<input type="submit" name="Submit" value="Edit">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelEntertainJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
			<input type="hidden" name="Entertain_Contact_ID" value="<%=Entertain_contact_ID%>">
			<input type="hidden" name="Entertain_Job_ID" value="<%=Entertain_job_ID%>">
          <input type="submit" name="Submit2" value="Cancel">
        </form></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
  <%}else {%>
		<center>�������������´��èͧ</center>
<%  }%>
</body>
</html>