<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Search Entertainment</title>
</head>

<body bgcolor="F9F9EF">
<form name="form1" method="post" action="ResultSearchNoLog.jsp">
<%Date now = new Date();%>
<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
  <tr> 
    <td align= "left"><p>&nbsp;</p></td>
  </tr>
  <tr> 
    <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
          <tr bgcolor="#FFCCFF"> 
            <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ����ѷ�͹����෹�����</div></td>
          </tr>
          <tr> 
            <td width="12">1.</td>
            <td width="195">���� :</td>
            <td width="221"> <select name="Style">
                <option value="" selected>������</option>
                <option value="��">��</option>
                <option value= "�ҡ�">�ҡ� </option>
                <option value="�չ">�չ</option>
              </select></td>
          </tr>
          <tr> 
            <td>2.</td>
            <td>��Դ :</td>
            <td> <select name="Type">
                <option value = "0" selected>--- ������ ---</option>
                <option value="1">���ѹ��ҡ</option>
                <option value="2">ǧ�������</option>
                <option value="3">ǧ�����ʵ�ԧ</option>
                <option value="4">ǧ������ҡ�</option>
                <option value="5">ǧ����ըչ</option>
                <option value="6">�ѡ���ҡ�</option>
                <option value="7">������ش��꡵�</option>
                <option value="8">����Դ�ԧ�</option>
                <option value="9">�ػ�ҡèչ</option>
                <option value="10">����ǻ�Сͺ�ŧ</option>
              </select> </td>
          </tr>
          <tr> 
            <td rowspan="2">3.</td>
            <td rowspan="2">�ѹ - �������������ʴ� :</td>
            <td><select name="Date">
                <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
                <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                <%
				}
		%>
              </select>
              / 
              <select name="Month">
                <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
              </select>
              / 
              <select name="Year">
                <option value="2003" selected>2546</option>
                <option value="2004">2547</option>
                <option value="2005">2548</option>
              </select></td>
          </tr>
          <tr> 
            <td> <select name="Hour">
                <%
				for (int i = 0 ; i <= 23 ; i ++) {
				%>
                <option value = "<%=i%>"><%=i%></option>
                <%
				}
		%>
              </select>
              : 
              <select name="Minute">
                <option value = "00" selected>00</option>
                <option value = "30">30</option>
              </select> </td>
          </tr>
          <tr> 
            <td>4.</td>
            <td>�ӹǹ������� : </td>
            <td> <select name="Time">
                <option value="3600000" selected> 1 �������</option>
                <option value="7200000"> 2 ������� </option>
                <option value="10800000"> 3 ������� </option>
                <option value="14400000"> 4 ������� </option>
                <option value="18000000"> 5 ������� </option>
                <option value="21600000"> 6 ������� </option>
              </select> </td>
          </tr>
          <tr> 
            <td>5.</td>
            <td>�Ҥҵ���ش :</td>
            <td> <input name="Minprice" type="text" value="500" size="10">
              �ҷ </td>
          </tr>
          <tr> 
            <td>6.</td>
            <td>�Ҥ��٧�ش:</td>
            <td> <input name="Maxprice" type="text" value="10000" size="10"> �ҷ</td>
          </tr>
          <tr>
            <td height="27">7.</td>
            <td>��ͧ����ҤҶ١����ش :</td>
            <td><input name="cheap" type="radio" value="yes" checked>��ͧ���
              <input type="radio" name="cheap" value="no">����ͧ���</td>
          </tr>
          <tr> 
            <td height="27">8.</td>
            <td>���ʶҹ��� :</td>
            <td> <select name="Near">
                <option value = "">-- ʶҹ��� --</option>
                <option value = "����">����</option>
                <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                <option value = "�����ѹ">Patumwan</option>
              </select> </td>
          </tr>
          <tr> 
            <td>8.</td>
            <td>���ͺ���ѷ Entertainment:</td>
            <td> <select name="Entertain_name">
                <option value = "0">---- ���ͺ���ѷ----</option>
                <option value = "1">Entertainment1</option>
                <option value = "2">Entertainment2</option>
                <option value = "3">Entertainment3</option>
                <option value = "4">Entertainment4</option>
                <option value = "5">Entertainment5</option>
                <option value = "6">Entertainment6</option>
                <option value = "7">Entertainment7</option>
                <option value = "8">Entertainment8</option>
                <option value = "9">Entertainment9</option>
                <option value = "10">Entertainment10</option>
              </select> </td>
          </tr>
        </table>
      <BR>
    </td>
  </tr>
  <tr> 
    <td colspan="3" align="center"><br> <input type="submit" name="Submit" value="����"> 
    </td>
  </tr>
</table>
</form>
</body>
</html>