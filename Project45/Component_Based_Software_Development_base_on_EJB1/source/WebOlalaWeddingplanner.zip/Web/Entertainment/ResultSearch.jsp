<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.EntertainResultsearch"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Result Search Entertain</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	String Style = (String)request.getParameter("Style");
		String style = new String(Style.getBytes("ISO8859_1"),"MS874");

		String tempstr = (String)request.getParameter("Type");
		Integer tempint = new Integer(tempstr);
		int type = tempint.parseInt(tempstr);

        tempstr = (String)request.getParameter("Wedding_Contact_ID");
        int Wedding_Contact_ID = Integer.parseInt(tempstr);

		tempstr = (String)request.getParameter("Date");
		int date = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Month");
		int month = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Year");
		int year = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Hour");
		int hour = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Minute");
		int minute = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Time");
		tempint = new Integer(tempstr);
		long time = tempint.longValue();
		Date tempstartdate = new Date(year, month -1, date, hour, minute);
		String startdate = tempint.toString(date)+ " " + tempint.toString(month) + " " + tempint.toString(year) + " "  +tempint.toString(hour) + ":" + tempint.toString(minute) + ":00" ;

		long temptime = tempstartdate.getTime();
		Date tempfinishdate = new Date(time + temptime);
		String finishdate = tempint.toString(tempfinishdate.getDate()) + " " + tempint.toString(tempfinishdate.getMonth() + 1) + " " +  tempint.toString(tempfinishdate.getYear()) + " " + tempint.toString(tempfinishdate.getHours()) + ":" + tempint.toString(tempfinishdate.getMinutes()) + ":00";

		tempstr = (String)request.getParameter("Minprice");
		tempint = new Integer(tempstr);
		double minprice = tempint.doubleValue();

		tempstr = (String)request.getParameter("Maxprice");
		tempint = new Integer(tempstr);
		double maxprice = tempint.doubleValue();

         String Cheap =  (String)request.getParameter("cheap");
         boolean cheap = true;
         if (Cheap.equals("yes"))
         {
            cheap = true;
         }
         else
         {
            cheap = false;
         }

		tempstr = (String)request.getParameter("Near");
		String Near = new String(tempstr.getBytes("ISO8859_1"),"MS874");

//		tempstr = (String)request.getParameter("Entertainment_Name");
//        String Entertainment_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		String Entertainment_Name = "";
        tempstr = (String)request.getParameter("Entertainment_ID");
        int Entertainment_ID = Integer.parseInt(tempstr);
		switch (Entertainment_ID){
			case (1): Entertainment_Name = "Entertain1";break;
			case (2): Entertainment_Name = "Entertain2";break;
			case (3): Entertainment_Name = "Entertain3";break;
			case (4): Entertainment_Name = "Entertain4";break;
			case (5): Entertainment_Name = "Entertain5";break;
			case (6): Entertainment_Name = "Entertain6";break;
			case (7): Entertainment_Name = "Entertain7";break;
			case (8): Entertainment_Name = "Entertain8";break;
			case (9): Entertainment_Name = "Entertain9";break;
			case (10): Entertainment_Name = "Entertain10";break;
			case (0): Entertainment_Name = "";break;
		}
        tempstr = (String)request.getParameter("Entertain_Contact_ID");
        int Entertain_Contact_ID = Integer.parseInt(tempstr);

		org.openuri.www.EntertainResultsearch[] result = soapProxy.entertainment_Search(style,type,minprice,maxprice,startdate,finishdate,cheap,Near,Entertainment_ID);
		%>
<center>
  <table width="95%" height="143" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="8"><center>
          �š�ä���</center></td>
    </tr>
    <tr>
      <td><div align="center">��Դǧ����� - ����ʴ�</div></td>
      <td><div align="center">����ǧ����� - ����ʴ�</div></td>
      <td><div align="center">��������´</div></td>
      <td><div align="center">��Һ�ԡ�� (5:00 �. - 17:00 �.) / �ҷ</div></td>
      <td><div align="center">��Һ�ԡ�� (17:00 �. - 2:00 �.) / �ҷ</div></td>
      <td><div align="center">���ͺ���ѷ</div></td>
      <td><div align="center">����������ѷ</div></td>
      <td><div align="center">�ͧ</div></td>
    </tr>
    <%
    if (result != null){
                for (int i = 0 ; i < result.length ; i ++ )
                {
                        %>
    <form name="form1" method="post" action="ReserveEntertain.jsp">

      <tr>
        <td><div align="center"><%=result[i].getBandStyle()%></div></td>
        <td><div align="center"><%=result[i].getBandName()%></div></td>
        <td><div align="center"><%=result[i].getBandDetail()%></div></td>
        <td><div align="center"><%=result[i].getBandPriceAm()%></div></td>
        <td><div align="center"><%=result[i].getBandPricePm()%></div></td>
        <td><div align="center"><%=result[i].getEntertainmentName()%></div></td>
        <td><div align="center"><%=result[i].getEntertainmentAddress()%></div></td>
        <td align = "center"><div align="center"><input type = "submit" value = "�ͧ" name = "reserve"></div></td>
      </tr>
      <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
      <input type = "hidden" name = "Entertain_Contact_ID" value = "<%=Entertain_Contact_ID%>">
        <input type = "hidden" name = "Type_Name" value = "<%=result[i].getBandTypeName()%>">
        <input type = "hidden" name = "Band_Name" value = "<%=result[i].getBandName()%>">
        <input type = "hidden" name = "Band_ID" value = "<%=result[i].getBandId()%>">
        <input type = "hidden" name = "Type_ID" value = "<%=result[i].getBandTypeId()%>">
        <input type = "hidden" name = "Band_Detail" value = "<%=result[i].getBandDetail()%>">
        <input type = "hidden" name = "Band_Style" value = "<%=result[i].getBandStyle()%>">
        <input type = "hidden" name = "Start_Datetime" value = "<%=startdate%>">
        <input type = "hidden" name = "Finish_Datetime" value = "<%=finishdate%>">
        <input type = "hidden" name = "Price_AM" value = "<%=result[i].getBandPriceAm()%>">
        <input type = "hidden" name = "Price_PM" value = "<%=result[i].getBandPricePm()%>">
        <input type = "hidden" name = "Entertainment_Name" value = "<%=result[i].getEntertainmentName()%>">
                        <%
                        if (result[i].getEntertainmentName().equals("Entertain1"))
                        {
                          Entertainment_ID = 1;
                        }
                        else if (result[i].getEntertainmentName().equals("Entertain2"))
                          {
                            Entertainment_ID = 2;
                          }
                          else if (result[i].getEntertainmentName().equals("Entertain3"))
                            {
                              Entertainment_ID = 3;
                            }
                            else if (result[i].getEntertainmentName().equals("Entertain4"))
                              {
                                Entertainment_ID = 4;
                              }
                              else if (result[i].getEntertainmentName().equals("Entertain5"))
                                {
                                  Entertainment_ID = 5;
                                }
                                else if (result[i].getEntertainmentName().equals("Entertain6"))
                                  {
                                    Entertainment_ID = 6;
                                  }
                                  else if (result[i].getEntertainmentName().equals("Entertain7"))
                                    {
                                      Entertainment_ID = 7;
                                    }
                                    else if (result[i].getEntertainmentName().equals("Entertain8"))
                                      {
                                        Entertainment_ID = 8;
                                      }
                                      else if (result[i].getEntertainmentName().equals("Entertain9"))
                                        {
                                          Entertainment_ID = 9;
                                        }
                                        else if (result[i].getEntertainmentName().equals("Entertain10"))
                                          {
                                            Entertainment_ID = 10;
                                          }
%>
        <input type = "hidden" name= "Entertainment_ID" value = "<%=Entertainment_ID%>">
        <input type = "hidden" name = "Entertainment_Address" value = "<%=result[i].getEntertainmentAddress()%>">
    </form>
    <%
                }}
%>
  </table>
</center>
</body>
</html>