<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Entertain</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Entertain_Contact_ID");
    int Entertain_Contact_ID = 0;
    if (tempstr != null)
    {
      Entertain_Contact_ID = Integer.parseInt(tempstr);
      boolean cancel = soapProxy.entertainment_Cancel_Contact(Customer_id,Entertain_Contact_ID,Wedding_Contact_ID);
      response.sendRedirect("../ShowContact.jsp");
    }
    else response.sendRedirect("../Main.htm");
	%>
</body>
</html>