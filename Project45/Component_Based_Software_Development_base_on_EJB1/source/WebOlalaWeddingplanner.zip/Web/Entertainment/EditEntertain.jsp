<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.EntertainJobDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
  <%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_contact_ID = Integer.parseInt(tempstr);
	Integer tempint = null;

	tempstr = (String)request.getParameter("Entertain_Contact_ID");
	int Entertain_contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Entertain_Job_ID");
	int Entertain_job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Band_Type_ID");
	int Band_Type_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Additional_Requests");
	String Additional_Requests = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Band_ID");
	int Band_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Band_Name");
	String Band_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Detail");
	String Detail = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Function_Type");
	String Function_Type = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Place");
	String Place = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("PayDate");
	String PayDate = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Entertain_name");
	String Entertain_name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	
	tempstr =(String)request.getParameter("Price");
	Double Temp2 = new Double(tempstr);
	double Price = Temp2.doubleValue();

	tempstr = (String)request.getParameter("Entertain_address");
	String Entertain_address = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	String StartDatetime = (String)request.getParameter("Start_Datetime");
	String  FinishDatetime = (String)request.getParameter("Finish_Datetime");
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = StartDatetime.toCharArray();
							for(int j = 0;  j < StartDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
<%
							temp = "";
							int day2 = 0;
							int month2 = 0;
							int year2 = 0;
							count = 0;
							String hour2 = new String();
							minute1 = 0;
							String minute2 = new String();
							temp_date =FinishDatetime.toCharArray();
							for(int j = 0;  j < FinishDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day2 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month2 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year2 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour2 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute2 = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute2 = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year2 = year2 +543;
%>
<div align="center">
<form name="form1" method="post" action="./Edit.jsp">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�çҹ�������ͧ�͹����෹�����</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left">���ʡ���ʴ�</div></td>
      <td width="82%"> <div align="left"><%=Entertain_job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">����ǧ����� - ����ʴ�</div></td>
      <td> <div align="left"><%=Band_Name%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">��������´</div></td>
      <td>  <div align="left"><%=Detail%></div></td>
    </tr>

    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">�������������ʴ�</div></td>
      <td> <div align="left">
<select name = "day1" >
			<%
					for (int i = 1 ; i <= 31 ; i ++) {
			%>
					<option value = "<%=i%>" <% if ( i == day1) { %> <%="selected"%> <%}%>><%=i%></option>
			<%
				}
			%>
		</select>&nbsp;��͹ 
		 <select name = "month1">
		 <option value = "1" <%if (month1 == 1) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "2" <%if (month1 == 2) { %><%="selected"%><%}%>>����Ҿѹ��</option>
		 <option value = "3" <%if (month1 == 3) { %><%="selected"%><%}%>>�չҤ�</option>
		 <option value = "4" <%if (month1 == 4) { %><%="selected"%><%}%>>����¹</option>
		 <option value = "5" <%if (month1 == 5) { %><%="selected"%><%}%>>����Ҥ�</option>
		 <option value = "6" <%if (month1 == 6) { %><%="selected"%><%}%>>�Զع�¹</option>
		 <option value = "7" <%if (month1 == 7) { %><%="selected"%><%}%>>�á�Ҥ�</option>
		 <option value = "8" <%if (month1 == 8) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
		 <option value = "9" <%if (month1 == 9) { %><%="selected"%><%}%>>�ѹ��¹</option>
		 <option value = "10" <%if (month1 == 10) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "11" <%if (month1 == 11) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
		 <option value = "12" <%if (month1 == 12) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
		</select>&nbsp;�.�. 
		<select name = "year1">
		<option value = "2003">2546</option>
		<option value = "2004">2547</option>
		<option value = "2005">2548</option>
		</select>
		&nbsp;����		
		<select name = "hour1">
				<%
				for (int i = 0 ; i <= 23 ; i ++) {
				%>
				<option value = "<%=i%>" <%if (tempint.parseInt(hour1) == i) { %><%="selected"%><%}%> ><%=i%></option>
				<%
				}
		%>
		</select>&nbsp; : &nbsp;
		<select name = "minute">
		<option value = "00" <%if (minute.equals("00")) { %><%="selected"%><%}%>>00</option>
		<option value = "30" <%if (minute.equals("30")) { %><%="selected"%><%}%>>30</option>
		</select> �.
	</div></td>
    </tr>
		<%	Date startdate = new Date(year1,month1,day1, tempint.parseInt(hour1),tempint.parseInt(minute));
				Date finishdate = new Date(year2,month2,day2,tempint.parseInt(hour2),tempint.parseInt(minute2));
				long numofhour = finishdate.getTime()-startdate.getTime();
		%>
	<tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">�ӹǹ�������</div></td>
      <td> <div align="left">
		<select name = "numofhour">
            <option value="3600000" <%if (numofhour == 3600000) { %><%="selected"%><%}%>> 1 ������� </option>
            <option value="7200000" <%if (numofhour == 7200000) { %><%="selected"%><%}%>> 2 ������� </option>
            <option value="10800000" <%if (numofhour == 10800000) { %><%="selected"%><%}%>> 3 ������� </option>
            <option value="14400000" <%if (numofhour == 14400000) { %><%="selected"%><%}%>> 4 ������� </option>
            <option value="18000000" <%if (numofhour == 18000000) { %><%="selected"%><%}%>> 5 ������� </option>
            <option value="21600000" <%if (numofhour == 21600000) { %><%="selected"%><%}%>> 6 ������� </option>
			</select>	 </div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">ʶҹ���</div></td>
      <td><div align="left"><input type = "text" value ="<%=Place%>" name = "Place" size = "30" maxlength = "50"> </div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">�Ҥ�</div></td>
      <td><div align="left"><%=Price%>&nbsp;�ҷ</div></td>
    </tr>
    <tr> 
      <td><div align="center">8.</div></td>
      <td><div align="left">�ѡɳТͧ�ҹ</div></td>
      <td> <div align="left"><input type = "text" name = "Function_Type" value ="<%=Function_Type%>" size = "30" maxlength = "50"></div></td>
    </tr>
    <tr> 
      <td><div align="center">9.</div></td>
      <td><div align="left">��������´�������</div></td>
      <td> <div align="left"><textarea name = "Additional_Requests" cols = "30"  rows = "2"maxlength = "200">
	  <%=Additional_Requests%></textarea></div></td>
    </tr>
    <tr> 
      <td><div align="center">10.</div></td>
      <td><div align="left">�ѹ�׹�ѹ��èͧ</div></td>
      <td> <div align="left"><%=PayDate%></div></td>
    </tr>
    <tr> 
      <td><div align="center">11.</div></td>
      <td><div align="left">���ͺ���ѷ�͹����෹�����</div></td>
      <td><div align="left"><%=Entertain_name%> </div></td>
    </tr>
    <tr> 
      <td><div align="center">12.</div></td>
      <td><div align="left">����������ѷ�͹����෹�����</div></td>
      <td><div align="left"><%=Entertain_address%> </div></td>
    </tr>
    <tr> 
      <td width="5%"><div align="center"></div></td>
      <td width="30%"><div align="center"></div></td>
      <td><div align="center"></div></td>
    </tr>
  </table>
		<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
		<input type="hidden" name="Entertain_Contact_ID" value="<%=Entertain_contact_ID%>">
		<input type="hidden" name="Entertain_Job_ID" value="<%=Entertain_job_ID%>">
		<input type="hidden" name="Entertain_name" value ="<%=Entertain_name%>">
		<input type="hidden" name="Entertain_address" value="<%=Entertain_address%>">
		<input type = "hidden" name = "Band_ID" value = "<%=Band_ID%>">
		<input type = "hidden" name = "Band_Type_ID" value = "<%=Band_Type_ID%>">
		<input type = "hidden" name = "Band_Name" value = "<%=Band_Name%>">
		<input type = "hidden" name = "Detail" value = "<%=Detail%>">
		  <center><input type = "Submit" value = "Edit"></center>
</form>
  <p>&nbsp;</p>
</div>
</body>
</html>