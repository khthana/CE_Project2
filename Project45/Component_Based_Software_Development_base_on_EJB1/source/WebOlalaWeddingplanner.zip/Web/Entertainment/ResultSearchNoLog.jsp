<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.EntertainResultsearch"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Result Search Entertain</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	String Style = (String)request.getParameter("Style");
		String style = new String(Style.getBytes("ISO8859_1"),"MS874");

		String tempstr = (String)request.getParameter("Type");
		Integer tempint = new Integer(tempstr);
		int type = tempint.parseInt(tempstr);

		tempstr = (String)request.getParameter("Date");
		int date = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Month");
		int month = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Year");
		int year = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Hour");
		int hour = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Minute");
		int minute = tempint.parseInt(tempstr);
		tempstr = (String)request.getParameter("Time");
		tempint = new Integer(tempstr);
		long time = tempint.longValue();
		Date tempstartdate = new Date(year, month -1, date, hour, minute);
		String startdate = tempint.toString(date)+ " " + tempint.toString(month) + " " + tempint.toString(year) + " "  +tempint.toString(hour) + ":" + tempint.toString(minute) + ":00" ;

		long temptime = tempstartdate.getTime();
		Date tempfinishdate = new Date(time + temptime);
		String finishdate = tempint.toString(tempfinishdate.getDate()) + " " + tempint.toString(tempfinishdate.getMonth() + 1) + " " +  tempint.toString(tempfinishdate.getYear()) + " " + tempint.toString(tempfinishdate.getHours()) + ":" + tempint.toString(tempfinishdate.getMinutes()) + ":00";

		tempstr = (String)request.getParameter("Minprice");
		tempint = new Integer(tempstr);
		double minprice = tempint.doubleValue();

		tempstr = (String)request.getParameter("Maxprice");
		tempint = new Integer(tempstr);
		double maxprice = tempint.doubleValue();

         String Cheap =  (String)request.getParameter("cheap");
         boolean cheap = true;
         if (Cheap.equals("yes"))
         {
            cheap = true;
         }
         else
         {
            cheap = false;
         }

		String Near = (String)request.getParameter("Near");
		String near = new String(Near.getBytes("ISO8859_1"),"MS874");

		tempstr = (String)request.getParameter("Entertain_name");
		int entertain_name = tempint.parseInt(tempstr);
		out.println(style+", "+type+" ,"+minprice+", "+maxprice+","+startdate+", "+finishdate+", "+cheap+", "+near+", "+entertain_name);
		org.openuri.www.EntertainResultsearch[] result = soapProxy.entertainment_Search(style,type,minprice,maxprice,startdate,finishdate,cheap,near,entertain_name);
		out.println(result);
		%>
<center>
  <table width="95%" height="143" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="8"><center>
          �š�ä���</center></td>
    </tr>
    <tr>
      <td><div align="center">��Դǧ����� - ����ʴ�</div></td>
      <td><div align="center">����ǧ����� - ����ʴ�</div></td>
      <td><div align="center">��������´</div></td>
      <td><div align="center">��Һ�ԡ�� (5:00 �. - 17:00 �.) / �ҷ</div></td>
      <td><div align="center">��Һ�ԡ�� (17:00 �. - 2:00 �.) / �ҷ</div></td>
      <td><div align="center">���ͺ���ѷ</div></td>
      <td><div align="center">����������ѷ</div></td>
    </tr>
    <%
		for (int i = 0 ; i < result.length ; i ++ )
		{
			%>
      <tr>
        <td><div align="center"><%=result[i].getBandStyle()%></div></td>
        <td><div align="center"><%=result[i].getBandName()%></div></td>
        <td><div align="center"><%=result[i].getBandDetail()%></div></td>
        <td><div align="center"><%=result[i].getBandPriceAm()%></div></td>
        <td><div align="center"><%=result[i].getBandPricePm()%></div></td>
        <td><div align="center"><%=result[i].getEntertainmentName()%></div></td>
        <td><div align="center"><%=result[i].getEntertainmentAddress()%></div></td>
      </tr>
    <%
		}
%>
  </table>
  <form name="form1" method="post" action="./SearchNoLog.jsp" target = "mainFrame">
    <input type="submit" name="Submit" value="Back">
  </form>
  <p>&nbsp;</p>
</center>
</body>
</html>