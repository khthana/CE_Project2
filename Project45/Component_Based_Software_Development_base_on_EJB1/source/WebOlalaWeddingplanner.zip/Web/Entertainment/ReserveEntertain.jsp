<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner : Reserve Entertainment</title></head>

<body bgcolor="F9F9EF">
<%

    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

    Temp_Str = (String)request.getParameter("Entertainment_Name");
    String Entertainment_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

    Temp_Str = (String)request.getParameter("Entertainment_Address");
    String Entertainment_Address = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

    Temp_Str = (String)request.getParameter("Entertainment_ID");
    int Entertainment_ID = Integer.parseInt(Temp_Str);

    Temp_Str = (String)request.getParameter("Entertain_Contact_ID");
    int Entertain_Contact_ID = Integer.parseInt(Temp_Str);

		String Type_Name = request.getParameter("Type_Name");
		String Temp_Str1 = new String(Type_Name.getBytes("ISO8859_1") , "MS874");
		Type_Name = Temp_Str1;

		String Band_Name = request.getParameter("Band_Name");
		String Temp_Str2 = new String(Band_Name.getBytes("ISO8859_1") , "MS874");
		Band_Name = Temp_Str2;

		Temp_Str = (String)request.getParameter("Band_ID");
		int Band_ID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("Type_ID");
		int Type_ID = Integer.parseInt(Temp_Str);

		String Start_Datetime = request.getParameter("Start_Datetime");
		String Finish_Datetime = request.getParameter("Finish_Datetime");

		Temp_Str =(String)request.getParameter("Price_AM");
		Double Temp2 = new Double(Temp_Str);
		double Price_AM = Temp2.doubleValue();

		Temp_Str =(String)request.getParameter("Price_PM");
		Double Temp3 = new Double(Temp_Str);
		double Price_PM = Temp3.doubleValue();

                Temp_Str = (String)request.getParameter("Band_Detail");
                String Band_Detail = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

                Temp_Str = (String)request.getParameter("Band_Style");
                String Band_Style = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
%>

<center>
<form name="form1" method="post" action="BookEntertain.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF">
        <td colspan="3"><div align="center">��������´��èͧ����ѷ�͹����෹�����</div></td>
      </tr>
      <tr>
        <td width="5%"><div align="center">1.</div></td>
        <td width="47%"><div align="left">���� contact :</div></td>
        <td width="48%"> <div align="left">
            <input type="text" name="Entertain_Contact_Name" value = "Olala">
          </div></td>
      </tr>
      <tr>
        <td><div align="center">2.</div></td>
        <td><div align="left">�������ͧǧ����� - ����ʴ� :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr>
        <td><div align="center">3.</div></td>
        <td><div align="left">����ǧ����� - ����ʴ� :</div></td>
        <td><div align="left"><%=Band_Name%></div></td>
      </tr>
      <tr>
        <td><div align="left">4.</div></td>
        <td><div align="left">��������´</div></td>
        <td><div align="left"><%=Band_Detail%></div></td>
      </tr>
      <tr>
        <td><div align="center">5.</div></td>
        <td><div align="left">�ѹ���������ʴ� :</div></td>
        <td><div align="left">
            <%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = Start_Datetime.toCharArray();
							for(int j = 0;  j < Start_Datetime.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
            <%=day1%> &nbsp;
            <%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>
            &nbsp; <%=year1%> &nbsp;&nbsp; <%=hour1%> : <%=minute%> &nbsp;�. </div></td>
      </tr>
      <tr>
        <td><div align="center">6.</div></td>
        <td><div align="left">�ѹ����ش����ʴ� :</div></td>
        <td><div align="left">
            <%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =Finish_Datetime.toCharArray();
							for(int j = 0;  j < Finish_Datetime.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
            <%=day1%> &nbsp;
            <%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>
            &nbsp; <%=year1%> &nbsp;&nbsp; <%=hour1%> : <%=minute%> &nbsp;�. </div></td>
      </tr>
      <tr>
        <td><div align="center">7.</div></td>
        <td><div align="left">��Һ�ԡ�� (5:00 �. - 17:00 �.) :</div></td>
        <td><div align="left"><%=Price_AM%>�ҷ</div></td>
      </tr>
      <tr>
        <td><div align="center">8.</div></td>
        <td><div align="left">��Һ�ԡ�� (17:00 �. - 2:00 �.) :</div></td>
        <td><div align="left"><%=Price_PM%>�ҷ</div></td>
      </tr>
      <tr>
        <td><div align="center">9.</div></td>
        <td><div align="left">�ѡɳТͧ�ҹ :</div></td>
        <td><div align="left">
            <select name = "Function_Type">
              <option value = "�ҹ�觧ҹ">�ҹ�觧ҹ</option>
              <option value = "�ҹ����">�ҹ����</option>
              <option value = "���ѹ��ҡ">���ѹ��ҡ</option>
            </select>
          </div></td>
      </tr>
      <tr>
        <td><div align="center">10.</div></td>
        <td><div align="left">ʶҹ��� :</div></td>
        <td> <div align="left">
            <input type = "text" name = "Place" size = 30 maxlength = 50 value = "�ҧ�ѡ">
          </div></td>
      </tr>
      <tr>
        <td><div align="center">11.</div></td>
        <td><div align="left">��������´������� :</div></td>
        <td><div align="left">
            <textarea type = "text" name = "Additional_Requests" cols = 40 rows = 3 maxlength = 200 ></textarea>
          </div></td>
      </tr>
      <tr>
        <td><div align="center">12.</div></td>
        <td><div align="left">���ͺ���ѷ Entertainment :</div></td>
        <td><div align="left"><%=Entertainment_Name%></div></td>
      </tr>
      <tr>
        <td><div align="center">13.</div></td>
        <td><div align="left">����������ѷ Entertainment :</div></td>
        <td><div align="left"><%=Entertainment_Address%></div></td>
      </tr>
      <tr>
        <td colspan="3"><div align="center">
            <input type="submit" name="Submit" value="�ͧ">
          </div></td>
      </tr>
    </table>
<input type = "hidden" name ="Entertain_Contact_ID" value = "<%=Entertain_Contact_ID%>">
<input type = "hidden" name ="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
<input type = "hidden" name ="Entertainment_Name" value = "<%=Entertainment_Name%>">
<input type = "hidden" name ="Type_Name" value = "<%=Type_Name%>">
<input type = "hidden" name ="Band_Name" value = "<%=Band_Name%>">
<input type = "hidden" name ="Band_ID" value = "<%=Band_ID%>">
<input type = "hidden" name ="Type_ID" value = "<%=Type_ID%>">
<input type = "hidden" name ="Band_Detail" value = "<%=Band_Detail%>">
<input type = "hidden" name ="Start_Datetime" value = "<%=Start_Datetime%>">
<input type = "hidden" name ="Finish_Datetime" value = "<%=Finish_Datetime%>">
<input type = "hidden" name ="Price_AM" value = "<%=Price_AM%>">
<input type = "hidden" name ="Price_PM" value = "<%=Price_PM%>">
<input type = "hidden" name ="Entertainment_Address" value = "<%=Entertainment_Address%>">
<input type = "hidden" name ="Entertainment_ID" value = "<%=Entertainment_ID%>">
    </form>
  <p>&nbsp;</p>
</center>
</body>
</html>