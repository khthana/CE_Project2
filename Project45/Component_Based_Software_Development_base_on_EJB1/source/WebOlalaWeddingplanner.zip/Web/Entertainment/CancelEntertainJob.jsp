<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner : Cancel Job Entertain</title></head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Entertain_Contact_ID");
    int Entertain_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Entertain_Job_ID");
    int Entertain_Job_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

    boolean cancel = soapProxy.entertainment_Cancel_Job(Customer_id,Wedding_Contact_ID,Entertain_Contact_ID,Entertain_Job_ID);
    if (cancel == true)
    {
		org.openuri.www.EntertainListJob[] list = soapProxy.entertainment_Job_List(Customer_id,Wedding_Contact_ID);
		if ((list != null)&&(list.length == 0))
		{
			boolean cancelcontact = soapProxy.entertainment_Cancel_Contact(Customer_id,Entertain_Contact_ID,Wedding_Contact_ID);
		}
      response.sendRedirect("../ShowContact.jsp");
    }
%>
</body>
</html>