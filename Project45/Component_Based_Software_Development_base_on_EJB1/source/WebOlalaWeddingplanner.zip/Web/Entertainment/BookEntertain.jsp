<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body  bgcolor="F9F9EF">
<%
        String Temp_Str = null;
        int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

        Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
        int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

        Temp_Str = (String)request.getParameter("Entertainment_ID");
        int Entertainment_ID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("Entertain_Contact_ID");
		int Entertain_Contact_ID = Integer.parseInt(Temp_Str);

        Temp_Str = (String)request.getParameter("Entertainment_Name");
        String Entertainment_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

        Temp_Str = (String)request.getParameter("Entertainment_Address");
        String Entertainment_Address = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

        Temp_Str = (String)request.getParameter("Entertain_Contact_Name");
		String Entertain_Contact_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Type_Name");
		String Type_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Band_Name");
		String Band_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Band_ID");
		int Band_ID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("Type_ID");
		int Type_ID = Integer.parseInt(Temp_Str);

		String Start_Datetime = (String)request.getParameter("Start_Datetime");
		String Finish_Datetime = (String)request.getParameter("Finish_Datetime");

		Temp_Str = (String)request.getParameter("Function_Type");
		String Function_Type = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Place");
		String Place = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Additional_Requests");
		String Additional_Requests = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str =(String)request.getParameter("Price_AM");
		Double Temp4 = new Double(Temp_Str);
		double Price_AM = Temp4.doubleValue();

		Temp_Str =(String)request.getParameter("Price_PM");
		Double Temp5 = new Double(Temp_Str);
		double Price_PM = Temp5.doubleValue();

		boolean create = false;
		if (Entertain_Contact_ID == 0)
        {
                  Entertain_Contact_ID = soapProxy.entertainment_CreateContact(Wedding_Contact_ID,Entertainment_ID,Customer_ID);
				  create = true;
		}
        org.openuri.www.EntertainResultReserve reserve = soapProxy.entertainment_Reserve(Customer_ID, Wedding_Contact_ID, Entertain_Contact_ID, Band_ID, Type_ID, Start_Datetime, Finish_Datetime, Place, Function_Type, Price_AM, Price_PM, Additional_Requests, Entertainment_ID, Entertain_Contact_Name);
		if (((reserve == null)||(reserve.getEntertainJobID()==0))&&(create == true))
        {
			boolean cancel = soapProxy.entertainment_Cancel_Contact(Customer_ID,Entertain_Contact_ID,Wedding_Contact_ID);%>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
<center><a href = "../ShowJob.jsp#entertain">��Ѻ�˹���ʴ���������´ contact</a></center><%        } else {%>
<table width = "80%" align = "center" border = 1>
<tr><td align = "">���� Contact</td><td align = "center"><%=Entertain_Contact_Name%></td></tr>
<tr><td align = "">�������ͧǧ����� - ����ʴ�</td><td align = "center"><%=Type_Name%></td></tr>
<tr><td align = "">����ǧ����� - ����ʴ�</td><td align = "center"><%=Band_Name%></td></tr>
<tr><td align = "">�ѹ���������ʴ�</td><td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = Start_Datetime.toCharArray();
							for(int j = 0;  j < Start_Datetime.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "">�ѹ����ش����ʴ�</td><td align = "center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =Finish_Datetime.toCharArray();
							for(int j = 0;  j < Finish_Datetime.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "">�ѹ����ش��ê��Ф�Һ�ԡ��</td><td align = "center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							temp_date = reserve.getDeadlineConfirm().toCharArray();
							for(int j = 0;  j < reserve.getDeadlineConfirm().length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
</td></tr>
<tr><td align = "">��Һ�ԡ��</td><td align = "center"><%=reserve.getTotalPrice()%> �ҷ</td></tr>
<tr><td align = "">�ѡɳТͧ�ҹ</td><td align = "center"><%=Function_Type%></td></tr>
<tr><td align = "">ʶҹ���</td><td align = "center">&nbsp;<%=Place%></td></tr>
<tr><td align = "">��������´�������</td><td align = "center">&nbsp;<%=Additional_Requests%></td></tr>
<tr><td align = "">���ͺ���ѷ�͹����෹�����</td><td align = "center"><%=Entertainment_Name%></td></tr>
<tr><td align = "">����������ѷ�͹����෹�����</td><td align = "center"><%=Entertainment_Address%></td></tr>
</table>
<p>&nbsp;</p>
<center>��èͧ���º��������</center>
<center><a href = "../ShowJob.jsp#entertain">��Ѻ�˹���ʴ���������´ contact</a></center><%				}%>                 
</body>
</html>