<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Reserve Entertainment</title>
</head>

<body bgcolor="F9F9EF">
<%
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);
	Integer tempint = null;

    Temp_Str = (String)request.getParameter("Entertain_name");
    String Entertain_name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

    Temp_Str = (String)request.getParameter("Entertain_address");
    String Entertain_address = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

    Temp_Str = (String)request.getParameter("Entertain_Contact_ID");
    int Entertain_Contact_ID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("Entertain_Job_ID");
	int Entertain_Job_ID = Integer.parseInt(Temp_Str);

		String Band_Name = request.getParameter("Band_Name");
		String Temp_Str2 = new String(Band_Name.getBytes("ISO8859_1") , "MS874");
		Band_Name = Temp_Str2;

        Temp_Str = (String)request.getParameter("Band_ID");
	    int Band_ID = Integer.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("Band_Type_ID");
		int Band_Type_ID = Integer.parseInt(Temp_Str);

        Temp_Str = (String)request.getParameter("Detail");
        String Band_Detail = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Function_Type");
		String Function_Type = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Additional_Requests");
		String Additional_Requests = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

		Temp_Str = (String)request.getParameter("Place");
		String Place = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

	    String day1 = request.getParameter("day1");
		String month1 = request.getParameter("month1");
		String year1 = request.getParameter("year1");
		String hour1 = request.getParameter("hour1");
		String minute = request.getParameter("minute");
		String numofhour = request.getParameter("numofhour");

		String StartDatetime = day1 + " " + month1 + " " + year1 + " " + hour1 + ":" + minute + ":00"; 

		Integer tempint2 = new Integer(numofhour);
		long num_of_hour = tempint2.longValue();
		Date temp_start_date = new Date(tempint.parseInt(year1),tempint.parseInt(month1) - 1,tempint.parseInt(day1),tempint.parseInt(hour1),tempint.parseInt(minute));
	
		Date temp_finish_date = new Date(temp_start_date.getTime() + num_of_hour);

		String FinishDatetime = tempint.toString(temp_finish_date.getDate()) + " " + tempint.toString(temp_finish_date.getMonth() + 1) + " " + tempint.toString(temp_finish_date.getYear()) + " " + tempint.toString(temp_finish_date.getHours()) + ":" + tempint.toString(temp_finish_date.getMinutes()) + ":00" ;

		org.openuri.www.EntertainResultReserve result = soapProxy.entertainment_Editreserve(Customer_ID, Wedding_Contact_ID, Entertain_Contact_ID, Entertain_Job_ID, StartDatetime,FinishDatetime, Place, Function_Type, Additional_Requests, Band_ID, Band_Type_ID);
		if (result == null)
		{%>
			<p>&nbsp;</p>
			<center>�������������</center>
			<p>&nbsp;</p>
			<a href = "../ShowContact.jsp">˹���á</a>
		<%	}
		else
		{
%>
<center>
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF">
        <td colspan="3"><div align="center">��������´��èͧ����ѷ�͹����෹�����</div></td>
      </tr>
      <tr>
        <td width="5%"><div align="center">1.</div></td>
        <td width="47%"><div align="left">���ʡ���ʴ� :</div></td>
        <td width="48%"> <div align="left">
            <%=Entertain_Job_ID%>
          </div></td>
      </tr>
      <tr>
        <td><div align="center">2.</div></td>
        <td><div align="left">����ǧ����� - ����ʴ� :</div></td>
        <td><div align="left"><%=Band_Name%></div></td>
      </tr>
      <tr>
        <td><div align="left">3.</div></td>
        <td><div align="left">��������´</div></td>
        <td><div align="left"><%=Band_Detail%></div></td>
      </tr>
      <tr>
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ���������ʴ� :</div></td>
        <td><div align="left">
           <%=day1%>&nbsp;<%if (month1.equals("1")) out.print("�.�.");
														if (month1.equals("2")) out.print("�.�.");
														if (month1.equals("3")) out.print("��.�.");
														if (month1.equals("4")) out.print("��.�.");
														if (month1.equals("5")) out.print("�.�.");
														if (month1.equals("6")) out.print("��.�.");
														if (month1.equals("7")) out.print("�.�.");
														if (month1.equals("8")) out.print("�.�.");
														if (month1.equals("9")) out.print("�.�.");
														if (month1.equals("10")) out.print("�.�.");
														if (month1.equals("11")) out.print("�.�.");
														if (month1.equals("12")) out.print("�.�.");
											int years = tempint.parseInt(year1);
											years = years+543;
											%>&nbsp;<%=years%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�. </div></td>
      </tr>
      <tr>
        <td><div align="center">5.</div></td>
        <td><div align="left">�ѹ����ش����ʴ� :</div></td>
        <td><div align="left">
<%=temp_finish_date.getDate()%>&nbsp;<%if (temp_finish_date.getMonth() == 0) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 1) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 2) out.print("��.�.");
							 if (temp_finish_date.getMonth() == 3) out.print("��.�.");
							 if (temp_finish_date.getMonth() == 4) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 5) out.print("��.�.");
							 if (temp_finish_date.getMonth() == 6) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 7) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 8) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 9) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 10) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 11) out.print("�.�.");
							years = temp_finish_date.getYear() +543;
					%>&nbsp;<%=years%>&nbsp;&nbsp;<%=temp_finish_date.getHours()%>:<%
						if(temp_finish_date.getMinutes()==0)  out.print("00");
							 else out.print("30");
						%>&nbsp;�. </div></td>
      </tr>
      <tr>
        <td><div align="left">6.</div></td>
        <td><div align="left">�ѹ����ش��ê��Ф�Һ�ԡ��</div></td>
        <td><div align="left">
					<%
							String temp_paydate = "";
							int payday = 0;
							int paymonth = 0;
							int payyear = 0;
							int count = 0;
							char[] temp_date = result.getDeadlineConfirm().toCharArray();
							for(int j = 0;  j < result.getDeadlineConfirm().length(); j++)
							{	
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp_paydate);
													payday = temp_day.intValue();
													temp_paydate = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp_paydate);
													paymonth = temp_month.intValue();
													temp_paydate = "";
											}
									}
									else
									{
											temp_paydate = temp_paydate + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp_paydate);
													payyear = temp_year.intValue();
											}
									}
							}
							payyear = payyear +543;
					%>
					<%=payday%>&nbsp;<%if (paymonth == 1) out.print("�.�.");
														if (paymonth == 2) out.print("�.�.");
														if (paymonth == 3) out.print("��.�.");
														if (paymonth == 4) out.print("��.�.");
														if (paymonth == 5) out.print("�.�.");
														if (paymonth == 6) out.print("��.�.");
														if (paymonth == 7) out.print("�.�.");
														if (paymonth == 8) out.print("�.�.");
														if (paymonth == 9) out.print("�.�.");
														if (paymonth == 10) out.print("�.�.");
														if (paymonth == 11) out.print("�.�.");
														if (paymonth == 12) out.print("�.�.");
											%>&nbsp;<%=payyear%>
		</div></td>
      </tr>
      <tr>
        <td><div align="center">6.</div></td>
        <td><div align="left">ʶҹ��� :</div></td>
        <td><div align="left"><%=Place%></div></td>
      </tr>
      <tr>
        <td><div align="center">7.</div></td>
        <td><div align="left">�Ҥ� :</div></td>
        <td><div align="left"><%=result.getTotalPrice() %>&nbsp;�ҷ</div></td>
      </tr>
      <tr>
        <td><div align="center">8.</div></td>
        <td><div align="left">�ѡɳТͧ�ҹ :</div></td>
        <td><div align="left"><%=Function_Type%>&nbsp;</div></td>
      </tr>
      <tr>
        <td><div align="center">9.</div></td>
        <td><div align="left">ʶҹ��� :</div></td>
        <td> <div align="left"><%=Place%></div></td>
      </tr>
      <tr>
        <td><div align="center">10.</div></td>
        <td><div align="left">��������´������� :</div></td>
        <td><div align="left"><%=Additional_Requests%>&nbsp;</div></td>
      </tr>
      <tr>
        <td><div align="center">11.</div></td>
        <td><div align="left">���ͺ���ѷ Entertainment :</div></td>
        <td><div align="left"><%=Entertain_name%></div></td>
      </tr>
      <tr>
        <td><div align="center">12.</div></td>
        <td><div align="left">����������ѷ Entertainment :</div></td>
        <td><div align="left"><%=Entertain_address%></div></td>
      </tr>
    </table>
<p>&nbsp;</p>
<a href = "../ShowContact.jsp">˹���á</a>
	  <%}%>
</center>
</body>
</html>