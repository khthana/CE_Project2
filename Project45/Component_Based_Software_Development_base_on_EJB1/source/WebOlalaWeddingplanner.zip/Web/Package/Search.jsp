<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<html>
<head><title>Olala Wedding Planner : Search Hotel</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
%>
<form name="form1" method="post" action="./ResultSearch.jsp">
<table align="center" border=0 cellpadding="0" cellspacing="0" width="700">
        <tr> 
          <td align= "left"><p>&nbsp;</p></td>
        </tr>
        <tr> 
          <td width="700"><table width="700" border="1" bordercolor="#CCCCCC">
                <tr bgcolor="#FFCCFF"> 
                  <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ������ͨѴᾤࡨ</div></td>
                </tr>
	          <tr> 
		        <td width="17" height="29">1.</td>
			    <td width="116">�ٻẺ :</td>
				<td width="303"> <select name="style">
	                <option value="thai">��</option>
		            <option value="chinese">�չ</option>
			        <option value="international">�ҡ�</option>
				  </select> </td>
	          </tr>
                <tr> 
                  <td >2.</td>
                  <td >�ѡɳ�ʶҹ�����ͧ�Ѵ����§ :</td>
                  <td > <select name="place_style">
                      <option value="poolside">�Ѵ������</option>
                      <option value="garden">�Ѵ��ǹ</option>
                      <option value="room">�Ѵ���ͧ</option>
                    </select></td>
                </tr>
                <tr> 
                  <td>3.</td>
                  <td>��ǧ�ҤҢͧ��ͧ�Ѵ����§����ͧ��ä��� :</td>
                  <td><input type="text" name="seminarminprice" size="10" value = "0"> �����ҧ <input type="text" name="seminarmaxprice" size="10" value = "50000" > �ҷ 
                  </td>
                </tr>
                <tr> 
                  <td>4.</td>
                  <td>��ǧ�ҤҢͧ��ͧ�ѡ����ͧ��ä��� :</td>
                  <td><input type="text" name="roomminprice" size="10" value = "0"> �����ҧ <input type="text" name="roommaxprice" size="10" value = "50000" > �ҷ 
                  </td>
                </tr>
                <tr> 
                  <td>5.</td>
                  <td>��Դ��ͧ :</td>
                  <td><select name="roomType" >
			          <option value = "single">��ͧ��§�����</option>
			          <option value = "twin">��ͧ��§���</option>
			          <option value = "suite">��ͧ�ٷ</option>
				       </select> 
					</td>
                </tr>
                <tr> 
                  <td>6.</td>
                  <td>�ӹǹ��ͧ�ѡ :</td>
                  <td><input type="text" name="NumRoom" size="10" value = "1"> </td>
                </tr>
                <tr> 
                  <td>7.</td>
                  <td>��ǧ�ҤҢͧᾤࡨ����÷���ͧ��ä��� :</td>
                  <td><input type="text" name="foodminprice" size="10" value = "0"> �����ҧ <input type="text" name="foodmaxprice" size="10" value = "50000" > �ҷ 
                  </td>
                </tr>
                <tr> 
                  <td>8.</td>
                  <td>������������������� :</td>
                  <td>
			        <select name="serveType" >
					  <option value="1">�ؿ���</option>
					  <option value="2" selected>��Шչ</option>
					</select>
				  </td>
                </tr>
                <tr> 
                  <td>9.</td>
                  <td>��ǧ�ҤҢͧ��ҹ�����Ҿ����ͧ��ä��� :</td>
                  <td><input type="text" name="photominprice" size="10" value = "0"> �����ҧ <input type="text" name="photomaxprice" size="10" value = "50000" > �ҷ 
                  </td>
                </tr>
                <tr> 
                  <td>10.</td>
                  <td>�ѹ���ҨѴ�ҹ�觧ҹ :</td>
                  <td><p> 
                      <select name="date">
                        <%
						Date now = new Date();
						Date now1 = new Date();
						now1.setTime(now.getTime()+1000*10*60*60*24);%>
                      <option value = "01" <%if (now1.getDate() == 0) { %><%="selected"%><%}%>>01</option>
                      <option value = "02" <%if (now1.getDate() == 1) { %><%="selected"%><%}%>>02</option>
                      <option value = "03" <%if (now1.getDate() == 2) { %><%="selected"%><%}%>>03</option>
                      <option value = "04" <%if (now1.getDate() == 3) { %><%="selected"%><%}%>>04</option>
                      <option value = "05" <%if (now1.getDate() == 4) { %><%="selected"%><%}%>>05</option>
                      <option value = "06" <%if (now1.getDate() == 5) { %><%="selected"%><%}%>>06</option>
                      <option value = "07" <%if (now1.getDate() == 6) { %><%="selected"%><%}%>>07</option>
                      <option value = "08" <%if (now1.getDate() == 7) { %><%="selected"%><%}%>>08</option>
                      <option value = "09" <%if (now1.getDate() == 8) { %><%="selected"%><%}%>>09</option>
                      <option value = "10" <%if (now1.getDate() == 9) { %><%="selected"%><%}%>>10</option>
                      <option value = "11" <%if (now1.getDate() == 10) { %><%="selected"%><%}%>>11</option>
                      <option value = "12" <%if (now1.getDate() == 11) { %><%="selected"%><%}%>>12</option>
                      <option value = "13" <%if (now1.getDate() == 12) { %><%="selected"%><%}%>>13</option>
                      <option value = "14" <%if (now1.getDate() == 13) { %><%="selected"%><%}%>>14</option>
                      <option value = "15" <%if (now1.getDate() == 14) { %><%="selected"%><%}%>>15</option>
                      <option value = "16" <%if (now1.getDate() == 15) { %><%="selected"%><%}%>>16</option>
                      <option value = "17" <%if (now1.getDate() == 16) { %><%="selected"%><%}%>>17</option>
                      <option value = "18" <%if (now1.getDate() == 17) { %><%="selected"%><%}%>>18</option>
                      <option value = "19" <%if (now1.getDate() == 18) { %><%="selected"%><%}%>>19</option>
                      <option value = "20" <%if (now1.getDate() == 19) { %><%="selected"%><%}%>>20</option>
                      <option value = "21" <%if (now1.getDate() == 20) { %><%="selected"%><%}%>>21</option>
                      <option value = "22" <%if (now1.getDate() == 21) { %><%="selected"%><%}%>>22</option>
                      <option value = "23" <%if (now1.getDate() == 22) { %><%="selected"%><%}%>>23</option>
                      <option value = "24" <%if (now1.getDate() == 23) { %><%="selected"%><%}%>>24</option>
                      <option value = "25" <%if (now1.getDate() == 24) { %><%="selected"%><%}%>>25</option>
                      <option value = "26" <%if (now1.getDate() == 25) { %><%="selected"%><%}%>>26</option>
                      <option value = "27" <%if (now1.getDate() == 26) { %><%="selected"%><%}%>>27</option>
                      <option value = "28" <%if (now1.getDate() == 27) { %><%="selected"%><%}%>>28</option>
                      <option value = "29" <%if (now1.getDate() == 28) { %><%="selected"%><%}%>>29</option>
                      <option value = "30" <%if (now1.getDate() == 29) { %><%="selected"%><%}%>>30</option>
                      <option value = "31" <%if (now1.getDate() == 30) { %><%="selected"%><%}%>>31</option>
                      </select>
                      / 
                      <select name="month">
                      <option value = "01" <%if (now1.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "02" <%if (now1.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "03" <%if (now1.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "04" <%if (now1.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "05" <%if (now1.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "06" <%if (now1.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "07" <%if (now1.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "08" <%if (now1.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "09" <%if (now1.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now1.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now1.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now1.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="year">
                        <option value="2003" selected>2546</option>
                        <option value="2004">2547</option>
                        <option value="2005">2548</option>
                      </select>
                    </p>
                    <p> 
                      <select name="section">
                        <option value="1" selected>6:00 - 11:00</option>
                        <option value="2">12:00 - 17:00</option>
                        <option value="3">18:00 - 23:00</option>
                      </select>
                    </p></td>
                </tr>
                <tr> 
                  <td>12.</td>
                  <td>ࢵ : </td>
                  <td><select name="district">
                <option value = "1">	��ͧ��	</option>
                <option value = "2">	��ͧ�ҹ	</option>
                <option value = "3">	��ͧ�����	</option>
                <option value = "4">	�ѹ�����	</option>
                <option value = "5">	��بѡ�	</option>
                <option value = "6">	����ͧ	</option>
                <option value = "7">	�͹���ͧ	</option>
                <option value = "8">	�Թᴧ	</option>
                <option value = "9">	���Ե	</option>
                <option value = "10">	���觪ѹ	</option>
                <option value = "11">	����Ѳ��	</option>
                <option value = "12">	��觤��	</option>
                <option value = "13">	������	</option>
                <option value = "14">	�ҧ�͡����	</option>
                <option value = "15">	�ҧ�͡�˭�	</option>
                <option value = "16">	�ҧ�л�	</option>
                <option value = "17">	�ҧ�ع��¹	</option>
                <option value = "18">	�ҧࢹ	</option>
                <option value = "19">	�ҧ������	</option>
                <option value = "20">	�ҧ�	</option>
                <option value = "21">	�ҧ����	</option>
                <option value = "22">	�ҧ��	</option>
                <option value = "23">	�ҧ�͹	</option>
                <option value = "24">	�ҧ��Ѵ	</option>
                <option value = "25">	�ҧ�ѡ	</option>
                <option value = "26">	��觡���	</option>
                <option value = "27">	�����ѹ	</option>
                <option value = "28">	������	</option>
                <option value = "29">	������Һ	</option>
                <option value = "30">	����	</option>
                <option value = "31">	���⢹�	</option>
                <option value = "32">	��й��	</option>
                <option value = "33">	������ԭ	</option>
                <option value = "34">	�չ����	</option>
                <option value = "35">	�ҹ����	</option>
                <option value = "36">	�Ҫ���	</option>
                <option value = "37">	��ɮ���ó�	</option>
                <option value = "38">	�Ҵ��кѧ	</option>
                <option value = "39">	�Ҵ�����	</option>
                <option value = "40">	�ѧ�ͧ��ҧ	</option>
                <option value = "41">	�Ѳ��	</option>
                <option value = "42">	�ǹ��ǧ	</option>
                <option value = "43">	�оҹ�٧	</option>
                <option value = "44">	����ѹ�ǧ��	</option>
                <option value = "45">	�Ҹ�	</option>
                <option value = "46">	������	</option>
                <option value = "47">	˹ͧ��	</option>
                <option value = "48">	˹ͧ�͡	</option>
                <option value = "49">	��ѡ���	</option>
                <option value = "50">	���¢�ҧ	</option>
				</select></td>
                </tr>
              </table>
            </td>
        </tr>
        <tr> 
            <td colspan="3" align="center"><input type="submit" name="Submit4" value="����">&nbsp;</td>
        </tr>
      </table>
	  </form>
  <p align="center"> </p>
</body>
</html>