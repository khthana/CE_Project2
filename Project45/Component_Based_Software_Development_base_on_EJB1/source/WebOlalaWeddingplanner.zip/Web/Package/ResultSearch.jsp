<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page import="java.util.*"%>
<%@ page import="java.lang.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<% 




   int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
   int weddingContactID = Integer.parseInt((String)session.getAttribute("weddingContactID"));

	String tempstr = (String)request.getParameter("style");
	String style = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("place_style");
	String place_style = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("roomminprice");
	double roomminprice = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("roommaxprice");
	double roommaxprice = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("seminarminprice");
	double seminarminprice = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("seminarmaxprice");
	double seminarmaxprice = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("roomType");
	String roomType = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("NumRoom");
	int NumRoom = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("foodminprice");
	double foodminprice =Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("foodmaxprice");
	double foodmaxprice = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("serveType");
	int serveType = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("photominprice");
	int photominprice = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("photomaxprice");
	int photomaxprice = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("date");
	String date = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("month");
	String month = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("year");
	String year =  new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("section");
	short t0t11_am = 0;	short t12t5_pm = 0;
	short t6t11_pm = 0;
	if(tempstr.equals("1"))
		{t0t11_am=1;}
	else if(tempstr.equals("2"))
		{t12t5_pm = 1;}
	else if(tempstr.equals("3"))
		{t6t11_pm = 1;}
	String reservedate = date + " " +month + " "+year;
	int xx=Integer.parseInt(date);
	xx=xx+1;
	String checkoutdate =xx+" "+month+" "+year;
	if(xx<10) checkoutdate="0"+checkoutdate;
	tempstr = (String)request.getParameter("district");
	int district = Integer.parseInt(tempstr);

	org.openuri.www.SearchSeminarRoomResult[] seminarResult = Hotel2.hotelSearchSeminar(place_style,style,0,40000,seminarminprice,seminarmaxprice,reservedate,t0t11_am,t12t5_pm,t6t11_pm,false,0,district,0);
	//org.openuri.www.SearchSeminarRoomResult[] hotelSearchSeminar(java.lang.String placeStyle, java.lang.String decStyle, int seminarRoomSizeMin, int seminarRoomSizeMax, double minprice, double maxprice, java.lang.String sreserveDate, short t6To11Am, short t12To5Pm, short t61011Pm, boolean cheap, int hotelNumber, int district, int region)
	
	org.openuri.www.SearchRoomResult[] roomResult = Hotel2.hotelSearchRoom(NumRoom,roomType,reservedate,checkoutdate,0,roomminprice,roommaxprice,false,0,0,district);
	//org.openuri.www.SearchRoomResult[] hotelSearchRoom(int amountRoom, java.lang.String roomType, java.lang.String scheckinDate, java.lang.String scheckoutDate, int smoke, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)
	

	//org.openuri.www.SearchFoodResult[] hotelSearchFood(double minprice, double maxprice, java.lang.String foodStyle, java.lang.String serveType, java.lang.String foodName, boolean cheap, int hotelNumber, int foodPer)
	//org.openuri.www.SearchCakeResult[] hotelSearchCake(java.lang.String cakeStyle, double minprice, double maxprice, int layer, java.lang.String flavour, int cakeSize, boolean cheap, int hotelNumber, int region, int district)
	
	org.openuri.www.ServiceDetail[] photoResult = PhotosoapProxy.photo_SearchService(0,"3",photominprice,photomaxprice,false,district,0);
	org.openuri.www.ServiceDetail[] vdoResult = PhotosoapProxy.photo_SearchService(0,"5",photominprice,photomaxprice,false,district,0);
	//org.openuri.www.ServiceDetail[] photo_SearchService(int photoID, java.lang.String typeID, int minPrice, int maxPrice, boolean cheap, int district, int region)
%>
<table width="120%" border="1" align="center" bordercolor="#CCCCCC" >
  <tr bgcolor="#FFCCFF"> 
    <td height="24"> <div align="center">&nbsp;</div></td>
    <td colspan="7"><div align="center">�ç���&nbsp;</div></td>
    <td colspan="2" rowspan="2"><div align="center">��ҹ�����Ҿ&nbsp;</div></td>
    <td rowspan="2"><div align="center">&nbsp;</div></td>
  </tr>
  <tr bgcolor="#FFCCFF"> 
    <td width="10%"> <div align="center">&nbsp;</div></td>
    <td colspan="2"><div align="center">&nbsp;</div></td>
    <td colspan="2"><div align="center">��ͧ�Ѵ����§&nbsp;</div></td>
    <td colspan="2"><div align="center">��ͧ�ѡ</div></td>
    <td width="11%"> <div align="center">&nbsp;</div></td>
  </tr>
  <tr bgcolor="#FFCCFF"> 
    <td><div align="center">�����Ţᾤࡨ&nbsp;</div></td>
    <td width="1%"><div align="center">�����ç���&nbsp;</div></td>
    <td width="1%"><div align="center">��������ç���&nbsp;</div></td>
    <td width="12%"> <div align="center">������ͧ�Ѵ����§&nbsp;</div></td>
    <td width="10%"> <div align="center">�ӹǹ�������ͧ&nbsp;</div></td>
    <td width="10%"> <div align="center">��������ͧ�ѡ&nbsp;</div></td>
    <td width="9%"> <div align="center">�ӹǹ�������ͧ&nbsp;</div></td>
<!--    <td><div align="center">����ᾤࡨ�����&nbsp;</div></td>-->
    <td><div align="center">������ҹ�����Ҿ&nbsp;</div></td>
    <td><div align="center">�������Ҿ����&nbsp;</div></td>
    <td><div align="center">�����������մ���&nbsp;</div></td>
    <td><div align="center">�Ҥ�&nbsp;</div></td>
  </tr>

<%
					String hotelName;
					String hotelAddress;
					int hotelID;
					///////////////////////////////////////////////////seminar///////////////////////////////////////////////
					int seminarRoomID;
					String seminarRoomName="����ǧ��";
					String seminarDecStyle;
					String seminarPlaceStyle;
					int seminarSize=20;
					double seminarPrice;
					int seminarMenTable;
					int seminarMenBuffet;
					///////////////////////////////////////////////////seminar///////////////////////////////////////////////
					
					///////////////////////////////////////////////////room///////////////////////////////////////////////
					String roomTypex;
					int roomSize;
					double roomPrice;
					int maxMenPerRoom;
					double extraBedPrice;
					int smoke;
					///////////////////////////////////////////////////room///////////////////////////////////////////////
					double vdoPrice,photoPrice;
					int photoID,n=0;
					String vdoSubTypeName,vdoTypeName,vdoSubTypeDT,photoTypeName,photosubTypeName,photoSubTypeDT,photoAddress;
					String photoTypeID,photoSubTypeID,vdoSubTypeID,vdoTypeID;
					///////////////////////////////////////vdo/////////////////////////////////////
					double total=0;
	if((seminarResult!=null)&&(roomResult!=null)&&(photoResult!=null)&&(vdoResult!=null)){
	for(int i=0;i<seminarResult.length;i++){
		for(int j=0;j<roomResult.length;j++){
			for(int k=0;k<photoResult.length;k++){
				for(int l=0;l<vdoResult.length;l++)
				{
				if((seminarResult[i].getHotelID()==roomResult[j].getHotelID())&&(photoResult[k].getPhotoID()==vdoResult[k].getPhotoID()))
					{
					n++;
					hotelName=seminarResult[i].getHotelName();
					hotelAddress=seminarResult[i].getHotelAddress();
					hotelID=seminarResult[i].getHotelID();
					///////////////////////////////////////////////////seminar///////////////////////////////////////////////
					seminarRoomID=seminarResult[i].getSeminarRoomId();
					seminarRoomName=seminarResult[i].getSeminarRoomName();
					seminarDecStyle=seminarResult[i].getDecStyle();
					seminarPlaceStyle=seminarResult[i].getPlaceStyle();
					seminarSize=seminarResult[i].getSeminarRoomSize();
					seminarPrice=seminarResult[i].getSeminarRoomPrice();
					seminarMenTable=seminarResult[i].getMaxMenPerRoomTable();
					seminarMenBuffet=seminarResult[i].getMaxMenPerRoomBuffet();
					///////////////////////////////////////////////////seminar///////////////////////////////////////////////
					
					///////////////////////////////////////////////////room///////////////////////////////////////////////
					roomTypex=roomResult[j].getRoomType();
					roomSize=roomResult[j].getRoomSize();
					roomPrice=roomResult[j].getRoomPrice();
					maxMenPerRoom=roomResult[j].getMaximumMenPerRoom();
					extraBedPrice=roomResult[j].getExtrabedPrice();
					smoke=roomResult[j].getSmoke();
					//hotelName=roomResult[j].getHotelName()
					//hotelAddress=roomResult[j].getHotelAddress()
					//hotelID=roomResult[j].getHotelID()
					///////////////////////////////////////////////////room///////////////////////////////////////////////
					photoID=photoResult[k].getPhotoID();
					photoAddress=photoResult[k].getPhotoAddress();
					///////////////////////////////////////photo/////////////////////////////////////
					photoPrice=photoResult[k].getPrice();
					photoSubTypeDT=photoResult[k].getSubTypeDetail();
					photoSubTypeID=photoResult[k].getSubTypeID();
					photoTypeName=photoResult[k].getSubTypeName();
					photoTypeID=photoResult[k].getTypeID();
					photoTypeName=photoResult[k].getTypeName();
					photoAddress=photoResult[k].getPhotoAddress();
					///////////////////////////////////////photo/////////////////////////////////////
					///////////////////////////////////////vdo/////////////////////////////////////
					vdoPrice=photoResult[k].getPrice();
					vdoSubTypeDT=photoResult[k].getSubTypeDetail();
					vdoSubTypeID=photoResult[k].getSubTypeID();
					vdoSubTypeName=photoResult[k].getSubTypeName();
					vdoTypeID=photoResult[k].getTypeID();
					vdoTypeName=photoResult[k].getTypeName();
					///////////////////////////////////////vdo/////////////////////////////////////
					total=roomPrice+seminarPrice+vdoPrice+photoPrice;
%>
<form name="form1" method="post" action="./PackageDetail.jsp">
<tr>
<td ><input type="submit" value="<%=n%>"></td>
<td><%=hotelName%></td>
<td><%=hotelAddress%></td>
<td><%=seminarRoomName%></td>
<td><%=seminarMenTable%></td>
<td><%=roomTypex%></td>
<td><%=maxMenPerRoom%></td>
<td><%=photoAddress%></td>
<td><%=photoTypeName%></td>
<td><%=vdoTypeName%></td>
<td><%=total%></td>

<input type="hidden" name="photoID"  value="<%=photoID%>">
<input type="hidden" name="photoAddress"  value="<%=photoAddress%>">
<input type="hidden" name="photoPrice"  value="<%=photoPrice%>">
<input type="hidden" name="photoSubTypeID"  value="<%=photoSubTypeID%>">
<input type="hidden" name="photoTypeID"  value="<%=photoTypeID%>">
<input type="hidden" name="reservedate"  value="<%=reservedate %>">
<input type="hidden" name="round"  value="<%=1%>">
<input type = "hidden" name = "style" value ="<%=style%>">
<input type="hidden" name="weddingContactID"  value="<%=weddingContactID%>">
<input type="hidden" name="vdoTypeID"  value="<%=vdoTypeID%>">
<input type="hidden" name="vdoSubTypeID"  value="<%=vdoSubTypeID%>">

<input type="hidden" name="NumRoom"  value="<%=NumRoom%>">
<input type="hidden" name="roomType"  value="<%=roomType%>">
<input type="hidden" name="checkoutdate"  value="<%=checkoutdate%>">
<input type="hidden" name="hotelID"  value="<%=hotelID%>">
<input type="hidden" name="seminarRoomID"  value="<%=seminarRoomID%>">
<input type="hidden" name="seminarDecStyle"  value="<%=seminarDecStyle%>">
<input type="hidden" name="t6to11am"  value="<%=t0t11_am%>">
<input type="hidden" name="t12to5am"  value="<%=t12t5_pm%>">
<input type="hidden" name="t6to11pm"  value="<%=t6t11_pm%>">
<input type="hidden" name="tablelayout"  value="<%=serveType%>">
<input type="hidden" name="seminarRoomName"  value="<%=seminarRoomName%>">
<input type="hidden" name="seminarSize"  value="<%=seminarSize%>">


</tr>
</form>
<%
					}//if ��ͧ ID
				}//for cross package

	} }}}//if!=null
%>
</table><p align="center"> </p>
</body>
</html>