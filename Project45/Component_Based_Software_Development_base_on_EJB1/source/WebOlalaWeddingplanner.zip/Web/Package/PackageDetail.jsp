<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page import="java.util.*"%>
<%@ page import="java.lang.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%	Weddingplanner2_Impl proxyHotel2 = new Weddingplanner2_Impl() ;
	Weddingplanner2Soap Hotel2 = proxyHotel2.getweddingplanner2Soap();%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0;
	}
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		String tempstr = (String)request.getParameter("seminarRoomID");
		int seminarRoomID = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("seminarRoomName");
		String SeminarRoomName = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("seminarDecStyle");
		String DecStyle = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("NumRoom");
		int NumRoom = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("style");
		String PlaceStyle = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("seminarSize");
		int SeminarRoomSize = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("seminarPrice");
		double SeminarRoomPrice = Double.parseDouble(tempstr);
		tempstr = (String)request.getParameter("checkoutdate");
		String checkoutdate = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("reservedate");
		String reservedate = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("hotelID");
		
		
/*		
		int  hotelID = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("roomType");
		String roomType = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("photoID");
		int PhotoID = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("photoPrice");
		int photoPrice = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("photoSubTypeID");
		String photoSubTypeID = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		StringTokenizer strtoken = new StringTokenizer(photoSubTypeID," ");
		int photosubtype_id = Integer.parseInt(strtoken.nextToken());
		tempstr = (String)request.getParameter("vdoSubTypeID");
		String vdoSubTypeID = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		strtoken = new StringTokenizer(vdoSubTypeID," ");
		int vdosubtype_id = Integer.parseInt(strtoken.nextToken());
		tempstr = (String)request.getParameter("photoTypeID");
		String photoTypeID = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		strtoken = new StringTokenizer(photoTypeID," ");
		int phototype_id = Integer.parseInt(strtoken.nextToken());
		tempstr = (String)request.getParameter("vdoTypeID");
		String vdoTypeID = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		strtoken = new StringTokenizer(vdoTypeID," ");
		int vdotype_id = Integer.parseInt(strtoken.nextToken());*/
		//org.openuri.www.ReturnReserve[] result =  Hotel.hotelReserveRoom(customerId,hotelContact,amountRoom,roomType,scheckinDate,scheckoutDate,amountExtrabed,smoke,hotelNumber,weddingContactID);
/*		int Wedding_Contact_ID = soapProxy.create_Wedding_Contact_ID(Customer_id,"Package");
			if (Wedding_Contact_ID != 0){
				org.openuri.www.Hotelcontact contact=Hotel.hotel_Contact_List(Customer_id,Wedding_Contact_ID);
				if (contact != null){
					org.openuri.www.ReturnReserve[] result =  Hotel.hotelReserveRoom(Customer_id,contact.getHotelcontact(),NumRoom,roomType,reservedate,checkoutdate,0,0,hotelID,Wedding_Contact_ID);
					org.openuri.www.ReturnReserve result1 = Hotel.hotelReserveSeminar(Customer_id, contact.getHotelcontact(),seminarRoomID,seminarDecStyle,reservedate,t6to11am,t12to5am, t6to11pm,1,tablelayout,hotelID,Wedding_Contact_ID);
				double photoprice = PhotosoapProxy.photo_ReserveOutStudio(photoID,Wedding_Contact_ID,photoTypeID,photoSubTypeID,reservedate,round);
					double  vdoprice = PhotosoapProxy.photo_ReserveOutStudio(photoID,Wedding_Contact_ID,vdoTypeID,vdoSubTypeID,reservedate,round);

					session.setAttribute("weddingContactID",Wedding_Contact_ID);
					response.sendRedirect("../ShowContact.jsp");
		}}*/
	//org.openuri.www.ReturnReserve result = Hotel.hotelReserveSeminar(customerId, hotelContact,seminarRoomId,decStyle,sreserveDate,t6To11Am,t12To5Pm, t6To11Pm,menPerRoom,tableLayout,hotelID,weddingContactID);
	//price = PhotosoapProxy.photo_ReserveOutStudio(Photo_ID,Wedding_Contact_ID,type_id,subtype_id,reserveDate,Hour);
	%>
</body>
</html>