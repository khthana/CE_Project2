<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.EntertainResultsearch"%>
<%@ page import="org.openuri.www.*"%>
<%	Weddingplanner_Impl proxy = new Weddingplanner_Impl();
		WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>

</head>

<frameset rows="90,*" cols="*" frameborder="NO" border="0" framespacing="0">
  <frame src="Top.htm" name="topFrame" scrolling="NO" noresize >
  <frameset rows="*" cols="196,*" framespacing="0" frameborder="No" border="0">
    <frame src="Left.htm" name="leftFrame" scrolling="Yes" noresize>
    <frame src="Right.htm" name="mainFrame" scrolling="Yes">
  </frameset>
</frameset>
<noframes><body>
<%session.removeAttribute("Customer_ID");
  session.removeAttribute("Username");
  session.removeAttribute("Password");%>
<%response.sendRedirect("Index.htm");%>
</body></noframes>
</html>
