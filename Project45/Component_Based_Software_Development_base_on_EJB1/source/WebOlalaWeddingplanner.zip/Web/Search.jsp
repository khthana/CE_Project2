<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Search </title>
</head>

<body bgcolor="F9F9EF">
<%
        int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
          String tempstr = (String)request.getParameter("NewWedding_Contact_Name");
        String NewWedding_contact_name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
        int Wedding_contact_ID = soapProxy.create_Wedding_Contact_ID(Customer_ID,NewWedding_contact_name);
		<%Date now = new Date();%>
%>
	<form name="form1" method="post" action="ResultSearch.jsp">
	
  <table width="75%" border="0" align="center">
    <tr> 
      <td width="8%"><div align="right"> 
          <input type="checkbox" name="checkbox" value="checkbox">
        </div></td>
      <td width="92%"><div align="left"> 
          <table align="left" border=0 cellpadding="0" cellspacing="0" width="450">
            <tr> 
              <td align= "left"><p>&nbsp;</p></td>
            </tr>
            <tr> 
              <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                  <tr bgcolor="#FFCCFF"> 
                    <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä�����ͧ�Ѵ����§</div></td>
                  </tr>
                  <tr> 
                    <td width="12">1.</td>
                    <td width="195"> :</td>
                    <td width="221"> <select name="HotelSeminarPlace_Style">
						<option value="">������</option>
                        <option value="poolside">��ҧ��й��</option>
                        <option value= "garden">�ǹ</option>
                        <option value="room">��ͧ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>2.</td>
                    <td>����������ͧ :</td>
                    <td> <select name="HotelSeminarDec_Style">
                        <option value = "0" selected>������ </option>
                        <option value="thai">��</option>
                        <option value="chinese">�չ</option>
                        <option value="international">��ҧ�����</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td rowspan="2">3.</td>
                    <td rowspan="2">�ѹ���ҨѴ����§ :</td>
                    <td> <select name="HotelSeminarStart_Date">
                        <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                        <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                        <%
							}
						%>
                      </select>
                      / 
                      <select name="HotelSeminarStart_Month">
                        <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                        <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                        <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                        <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                        <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                        <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                        <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                        <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                        <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                        <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="HotelSeminarStart_Year">
                        <option value="2002" selected>2546</option>
                        <option value="2003">2547</option>
                        <option value="2004">2548</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td> <select name="HotelSeminarTime">
                        <option value = "t6to11_am" selected>6 am to 11 am</option>
                        <option value = "t12to5_pm">12 am to 5 pm</option>
                        <option value = "t6to11_pm">6 pm to 11 pm</option>
                      </select>
                    </td>
                  </tr>
                  <tr> 
                    <td>4.</td>
                    <td>��Ҵ��ͧ : </td>
                    <td> <input name="HotelSeminar_Room_Size_Min" type="text" value="100" size="10"> -
								<input name="HotelSeminar_Room_Size_Max" type="text" value="500" size="10">
					</td>
                  </tr>
                  <tr> 
                    <td>5.</td>
                    <td>�Ҥҵ���ش :</td>
                    <td> <input name="HotelSeminarMinprice" type="text" value="500" size="10"> 
                      �ҷ </td>
                  </tr>
                  <tr> 
                    <td>6.</td>
                    <td>�Ҥ��٧�ش:</td>
                    <td> <input name="HotelSeminarMaxprice" type="text" value="10000" size="10"> 
                      �ҷ</td>
                  </tr>
                  <tr> 
                    <td height="27">7.</td>
                    <td>��ͧ����ҤҶ١����ش :</td>
                    <td><input name="HotelSeminarCheap" type="radio" value="Yes" checked> 
                      ��ͧ��� <input type="radio" name="HotelSeminarCheap" value="No"> ����ͧ���</td>
                  </tr>
                  <tr> 
                    <td height="27">8.</td>
                    <td>���ʶҹ��� :</td>
                    <td> <select name="HotelSeminarNear">
                        <option value = "">-- ʶҹ��� --</option>
                        <option value = "����">����</option>
                        <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                        <option value = "�����ѹ">�����ѹ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>9.</td>
                    <td>�����ç���:</td>
                    <td> <select name="HotelSeminar_Name">
                        <option value = "0">---- ���ͺ���ѷ----</option>
                        <option value = "1">Hotel1</option>
                        <option value = "2">Hotel2</option>
                        <option value = "3">Hotel3</option>
                        <option value = "4">Hotel4</option>
                        <option value = "5">Hotel5</option>
                        <option value = "6">Hotel6</option>
                        <option value = "7">Hotel7</option>
                        <option value = "8">Hotel8</option>
                        <option value = "9">Hotel9</option>
                        <option value = "10">Hotel10</option>
                      </select> </td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </div></td>
    </tr>
    <tr>
      <td><div align="right">
          <input type="checkbox" name="checkbox6" value="checkbox">
        </div></td>
      <td><table align="left" border=0 cellpadding="0" cellspacing="0" width="450">
          <tr> 
            <td align= "left"><p>&nbsp;</p></td>
          </tr>
          <tr> 
            <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                <tr bgcolor="#FFCCFF"> 
                  <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä�����ͧ�ѡ</div></td>
                </tr>
                <tr> 
                  <td width="12">1.</td>
                  <td width="195">�ٻẺ��ͧ :</td>
                  <td width="221"> <select name="HotelRoom_Type">
                      <option value="" selected>--��ͧ --</option>
                      <option value="thai">��ͧ��§�����</option>
                      <option value= "twin">��ͧ��§���</option>
                      <option value="suite">��ͧ�ٷ</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>2.</td>
                  <td>�ӹǹ��ͧ :</td>
                  <td> <select name="HotelRoom_Amount">
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                      <option value="6">6</option>
                      <option value="7">7</option>
                      <option value="8">8</option>
                      <option value="9">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                      <option value="13">13</option>
                      <option value="14">14</option>
                      <option value="15">15</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>3.</td>
                  <td>�ѹ��Ҿѡ :</td>
                  <td> <select name="HotelRoom_Checkin_Date">
                      <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                      <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                      <%
							}
						%>
                    </select>
                    / 
                    <select name="HotelRoom_Checkin_Month">
                      <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                    </select>
                    / 
                    <select name="HotelRoom_Checkin_Year">
                      <option value="2002" selected>2546</option>
                      <option value="2003">2547</option>
                      <option value="2004">2548</option>
                    </select> </td>
                </tr>
                <tr>
                  <td>4.</td>
                  <td>�ѹ����͡ :</td>
                  <td> <select name="HotelRoom_Checkout_Date">
                      <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                      <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                      <%
							}
						%>
                    </select>
                    / 
                    <select name="HotelRoom_Checkout_Month">
                      <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                      <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                      <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                      <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                      <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                      <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                      <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                      <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                      <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                      <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                      <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                    </select>
                    / 
                    <select name="HotelRoom_Checkout_Year">
                      <option value="2002" selected>2546</option>
                      <option value="2003">2547</option>
                      <option value="2004">2548</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>5.</td>
                  <td>�Ҥҵ���ش :</td>
                  <td> <input name="HotelRoomMinprice" type="text" value="500" size="10">
                    �ҷ </td>
                </tr>
                <tr> 
                  <td>6.</td>
                  <td>�Ҥ��٧�ش:</td>
                  <td> <input name="HoteRoomMaxprice" type="text" value="10000" size="10">
                    �ҷ</td>
                </tr>
                <tr> 
                  <td height="27">7.</td>
                  <td>��ͧ����ҤҶ١����ش :</td>
                  <td><input name="HotelRoomCheap" type="radio" value="Yes" checked>
                    ��ͧ��� 
                    <input type="radio" name="HotelRoomCheap" value="No">
                    ����ͧ���</td>
                </tr>
                <tr> 
                  <td height="27">8.</td>
                  <td>���ʶҹ��� :</td>
                  <td> <select name="HotelRoomNear">
                      <option value = "">-- ʶҹ��� --</option>
                      <option value = "����">����</option>
                      <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                      <option value = "�����ѹ">Patumwan</option>
                    </select> </td>
                </tr>
                <tr> 
                  <td>9.</td>
                  <td>�����ç��� :</td>
                  <td> <select name="HotelRoom_Name">
                      <option value = "0">---- ���ͺ���ѷ----</option>
                      <option value = "1">Hotel1</option>
                      <option value = "2">Hotel2</option>
                      <option value = "3">Hotel3</option>
                      <option value = "4">Hotel4</option>
                      <option value = "5">Hotel5</option>
                      <option value = "6">Hotel6</option>
                      <option value = "7">Hotel7</option>
                      <option value = "8">Hotel8</option>
                      <option value = "9">Hotel9</option>
                      <option value = "10">Hotel10</option>
                    </select> </td>
                </tr>
              </table></td>
          </tr>
        </table></td>
    </tr>
    <tr> 
      <td><div align="right"> 
          <input type="checkbox" name="checkbox2" value="checkbox">
        </div></td>
      <td><div align="left"> 
          <table align="left" border=0 cellpadding="0" cellspacing="0" width="450">
            <tr> 
              <td align= "left"><p>&nbsp;</p></td>
            </tr>
            <tr> 
              <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                  <tr bgcolor="#FFCCFF"> 
                    <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Һ���ѷ�͹����෹�����</div></td>
                  </tr>
                  <tr> 
                    <td width="12">1.</td>
                    <td width="195">���� :</td>
                    <td width="221"> <select name="Entertain_Style">
                        <option value="" selected>������</option>
                        <option value="��">��</option>
                        <option value= "�ҡ�">�ҡ� </option>
                        <option value="�չ">�չ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>2.</td>
                    <td>��Դ :</td>
                    <td> <select name="Entertain_Type">
                        <option value = "0" selected>--- ������ ---</option>
                        <option value="1">���ѹ��ҡ</option>
                        <option value="2">ǧ�������</option>
                        <option value="3">ǧ�����ʵ�ԧ</option>
                        <option value="4">ǧ������ҡ�</option>
                        <option value="5">ǧ����ըչ</option>
                        <option value="6">�ѡ���ҡ�</option>
                        <option value="7">������ش��꡵�</option>
                        <option value="8">����Դ�ԧ�</option>
                        <option value="9">�ػ�ҡèչ</option>
                        <option value="10">����ǻ�Сͺ�ŧ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td rowspan="2">3.</td>
                    <td rowspan="2">�ѹ - �������������ʴ� :</td>
                    <td> <select name="Entertain_Date">
                        <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                        <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                        <%
							}
						%>
                      </select>
                      / 
                      <select name="Entertain_Month">
                        <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                        <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                        <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                        <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                        <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                        <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                        <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                        <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                        <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                        <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="Entertain_Year">
                        <option value="2002" selected>2546</option>
                        <option value="2003">2547</option>
                        <option value="2004">2548</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td> <select name="Entertain_Hour">
                        <%
							for (int i = 0 ; i <= 23 ; i ++) {
						%>
                        <option value = "<%=i%>"><%=i%></option>
                        <%
						}
						%>
                      </select>
                      : 
                      <select name="Entertain_Minute">
                        <option value = "00" selected>00</option>
                        <option value = "30">30</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>4.</td>
                    <td>�ӹǹ������� : </td>
                    <td> <select name="Entertain_Time">
                        <option value="3600000" selected> 1 �������</option>
                        <option value="7200000"> 2 ������� </option>
                        <option value="10800000"> 3 ������� </option>
                        <option value="14400000"> 4 ������� </option>
                        <option value="18000000"> 5 ������� </option>
                        <option value="21600000"> 6 ������� </option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>5.</td>
                    <td>�Ҥҵ���ش :</td>
                    <td> <input name="EntertainMinprice" type="text" value="500" size="10"> 
                      �ҷ </td>
                  </tr>
                  <tr> 
                    <td>6.</td>
                    <td>�Ҥ��٧�ش:</td>
                    <td> <input name="EntertainMaxprice" type="text" value="10000" size="10"> 
                      �ҷ</td>
                  </tr>
                  <tr> 
                    <td height="27">7.</td>
                    <td>��ͧ����ҤҶ١����ش :</td>
                    <td><input name="EntertainCheap" type="radio" value="Yes" checked> 
                      ��ͧ��� <input type="radio" name="EntertainCheap" value="No"> ����ͧ���</td>
                  </tr>
                  <tr> 
                    <td height="27">8.</td>
                    <td>���ʶҹ��� :</td>
                    <td> <select name="EntertainNear">
                        <option value = "">-- ʶҹ��� --</option>
                        <option value = "����">����</option>
                        <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                        <option value = "�����ѹ">Patumwan</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>9.</td>
                    <td>���ͺ���ѷ�͹����෹�����:</td>
                    <td> <select name="Entertain_Name">
                        <option value = "0">---- ���ͺ���ѷ----</option>
                        <option value = "1">Entertainment1</option>
                        <option value = "2">Entertainment2</option>
                        <option value = "3">Entertainment3</option>
                        <option value = "4">Entertainment4</option>
                        <option value = "5">Entertainment5</option>
                        <option value = "6">Entertainment6</option>
                        <option value = "7">Entertainment7</option>
                        <option value = "8">Entertainment8</option>
                        <option value = "9">Entertainment9</option>
                        <option value = "10">Entertainment10</option>
                      </select> </td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </div></td>
    </tr>
    <tr> 
      <td><div align="right"> 
          <input type="checkbox" name="checkbox3" value="checkbox">
        </div></td>
      <td><div align="left"> 
          <table align="left" border=0 cellpadding="0" cellspacing="0" width="450">
            <tr> 
              <td align= "left"><p>&nbsp;</p></td>
            </tr>
            <tr> 
              <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                  <tr bgcolor="#FFCCFF"> 
                    <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä�����ҹ�����Ҿ</div></td>
                  </tr>
                  <tr> 
                    <td width="12">1.</td>
                    <td width="195">�������ͧ������ :</td>
                    <td width="221"> <select name="Gift_Type_ID">
                        <option value="" selected>������</option>
                        <option value="1">��ǹ��</option>
                        <option value="2">����ͧ���</option>
                        <option value="3">������º�ҡ��</option>
                        <option value="4">��꡵�����Ԥ</option>
                        <option value="5">������硵Դ������</option>
                        <option value="6">�ͧ������</option>
                        <option value="8">��ش����¾ä��������</option>
                        <option value="9">���ͧ���ͧ˹�ҧҹ</option>
                        <option value="10">�����觧ҹ</option>
						<option value="11">���촢ͺ�س����������ҹ</option>
                        <option value="7">���� </option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>2.</td>
                    <td>����ͧ������ :</td>
                    <td> <select name="Gift_Style">
                        <option value = "0" selected>--- ������ ---</option>
                        <option value="1">���ѹ��ҡ</option>
                        <option value="2">ǧ�������</option>
                        <option value="3">ǧ�����ʵ�ԧ</option>
                        <option value="4">ǧ������ҡ�</option>
                        <option value="5">ǧ����ըչ</option>
                        <option value="6">�ѡ���ҡ�</option>
                        <option value="7">������ش��꡵�</option>
                        <option value="8">����Դ�ԧ�</option>
                        <option value="9">�ػ�ҡèչ</option>
                        <option value="10">����ǻ�Сͺ�ŧ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td rowspan="2">3.</td>
                    <td rowspan="2">�ѹ - �������������ʴ� :</td>
                    <td> <select name="select">
                        <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                        <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                        <%
							}
						%>
                      </select>
                      / 
                      <select name="select">
                        <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                        <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                        <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                        <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                        <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                        <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                        <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                        <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                        <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                        <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="select">
                        <option value="2002" selected>2546</option>
                        <option value="2003">2547</option>
                        <option value="2004">2548</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td> <select name="select">
                        <%
							for (int i = 0 ; i <= 23 ; i ++) {
						%>
                        <option value = "<%=i%>"><%=i%></option>
                        <%
						}
						%>
                      </select>
                      : 
                      <select name="select">
                        <option value = "00" selected>00</option>
                        <option value = "30">30</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>4.</td>
                    <td>�ӹǹ������� : </td>
                    <td> <select name="select">
                        <option value="3600000" selected> 1 �������</option>
                        <option value="7200000"> 2 ������� </option>
                        <option value="10800000"> 3 ������� </option>
                        <option value="14400000"> 4 ������� </option>
                        <option value="18000000"> 5 ������� </option>
                        <option value="21600000"> 6 ������� </option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>5.</td>
                    <td>�Ҥҵ���ش :</td>
                    <td> <input name="Minprice2" type="text" value="500" size="10"> 
                      �ҷ </td>
                  </tr>
                  <tr> 
                    <td>6.</td>
                    <td>�Ҥ��٧�ش:</td>
                    <td> <input name="Maxprice2" type="text" value="10000" size="10"> 
                      �ҷ</td>
                  </tr>
                  <tr> 
                    <td height="27">7.</td>
                    <td>��ͧ����ҤҶ١����ش :</td>
                    <td><input name="cheap" type="radio" value="yes" checked> 
                      ��ͧ��� <input type="radio" name="cheap" value="no"> ����ͧ���</td>
                  </tr>
                  <tr> 
                    <td height="27">8.</td>
                    <td>���ʶҹ��� :</td>
                    <td> <select name="select">
                        <option value = "">-- ʶҹ��� --</option>
                        <option value = "����">����</option>
                        <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                        <option value = "�����ѹ">Patumwan</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>9.</td>
                    <td>������ҹ�����Ҿ :</td>
                    <td> <select name="select">
                        <option value = "0">---- ���ͺ���ѷ----</option>
                        <option value = "1">Photo1</option>
                        <option value = "2">Photo2</option>
                        <option value = "3">Photo3</option>
                        <option value = "4">Photo4</option>
                        <option value = "5">Photo5</option>
                        <option value = "6">Photo6</option>
                        <option value = "7">Photo7</option>
                        <option value = "8">Photo8</option>
                        <option value = "9">Photo9</option>
                        <option value = "10">Photo10</option>
                      </select> </td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </div></td>
    </tr>
    <tr> 
      <td><div align="right"> 
          <input type="checkbox" name="checkbox4" value="checkbox">
        </div></td>
      <td><div align="left"> 
          <table align="left" border=0 cellpadding="0" cellspacing="0" width="450">
            <tr> 
              <td align= "left"><p>&nbsp;</p></td>
            </tr>
            <tr> 
              <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                  <tr bgcolor="#FFCCFF"> 
                    <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä�����ҹ��¢ͧ������</div></td>
                  </tr>
                  <tr> 
                    <td width="12">1.</td>
                    <td width="195">���� :</td>
                    <td width="221"> <select name="select2">
                        <option value="" selected>������</option>
                        <option value="��">��</option>
                        <option value= "�ҡ�">�ҡ� </option>
                        <option value="�չ">�չ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>2.</td>
                    <td>��Դ :</td>
                    <td> <select name="select2">
                        <option value = "0" selected>--- ������ ---</option>
                        <option value="1">���ѹ��ҡ</option>
                        <option value="2">ǧ�������</option>
                        <option value="3">ǧ�����ʵ�ԧ</option>
                        <option value="4">ǧ������ҡ�</option>
                        <option value="5">ǧ����ըչ</option>
                        <option value="6">�ѡ���ҡ�</option>
                        <option value="7">������ش��꡵�</option>
                        <option value="8">����Դ�ԧ�</option>
                        <option value="9">�ػ�ҡèչ</option>
                        <option value="10">����ǻ�Сͺ�ŧ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td rowspan="2">3.</td>
                    <td rowspan="2">�ѹ - �������������ʴ� :</td>
                    <td> <select name="select2">
                        <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                        <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                        <%
							}
						%>
                      </select>
                      / 
                      <select name="select2">
                        <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                        <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                        <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                        <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                        <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                        <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                        <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                        <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                        <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                        <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="select2">
                        <option value="2002" selected>2546</option>
                        <option value="2003">2547</option>
                        <option value="2004">2548</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td> <select name="select2">
                        <%
							for (int i = 0 ; i <= 23 ; i ++) {
						%>
                        <option value = "<%=i%>"><%=i%></option>
                        <%
						}
						%>
                      </select>
                      : 
                      <select name="select2">
                        <option value = "00" selected>00</option>
                        <option value = "30">30</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>4.</td>
                    <td>�ӹǹ������� : </td>
                    <td> <select name="select2">
                        <option value="3600000" selected> 1 �������</option>
                        <option value="7200000"> 2 ������� </option>
                        <option value="10800000"> 3 ������� </option>
                        <option value="14400000"> 4 ������� </option>
                        <option value="18000000"> 5 ������� </option>
                        <option value="21600000"> 6 ������� </option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>5.</td>
                    <td>�Ҥҵ���ش :</td>
                    <td> <input name="Minprice3" type="text" value="500" size="10"> 
                      �ҷ </td>
                  </tr>
                  <tr> 
                    <td>6.</td>
                    <td>�Ҥ��٧�ش:</td>
                    <td> <input name="Maxprice3" type="text" value="10000" size="10"> 
                      �ҷ</td>
                  </tr>
                  <tr> 
                    <td height="27">7.</td>
                    <td>��ͧ����ҤҶ١����ش :</td>
                    <td><input name="cheap" type="radio" value="yes" checked> 
                      ��ͧ��� <input type="radio" name="cheap" value="no"> ����ͧ���</td>
                  </tr>
                  <tr> 
                    <td height="27">8.</td>
                    <td>���ʶҹ��� :</td>
                    <td> <select name="select2">
                        <option value = "">-- ʶҹ��� --</option>
                        <option value = "����">����</option>
                        <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                        <option value = "�����ѹ">Patumwan</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>9.</td>
                    <td>������ҹ��¢ͧ������:</td>
                    <td> <select name="select2">
                        <option value = "0">---- ���ͺ���ѷ----</option>
                        <option value = "1">Gift1</option>
                        <option value = "2">Gift2</option>
                        <option value = "3">Gift3</option>
                        <option value = "4">Gift4</option>
                        <option value = "5">Gift5</option>
                        <option value = "6">Gift6</option>
                        <option value = "7">Gift7</option>
                        <option value = "8">Gift8</option>
                        <option value = "9">Gift9</option>
                        <option value = "10">Gift10</option>
                      </select> </td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </div></td>
    </tr>
    <tr> 
      <td><div align="right"> 
          <input type="checkbox" name="checkbox5" value="checkbox">
        </div></td>
      <td><div align="left"> 
          <table align="left" border=0 cellpadding="0" cellspacing="0" width="450">
            <tr> 
              <td align= "left"><p>&nbsp;</p></td>
            </tr>
            <tr> 
              <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
                  <tr bgcolor="#FFCCFF"> 
                    <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��ҷ����</div></td>
                  </tr>
                  <tr> 
                    <td width="12">1.</td>
                    <td width="195">���� :</td>
                    <td width="221"> <select name="select3">
                        <option value="" selected>������</option>
                        <option value="��">��</option>
                        <option value= "�ҡ�">�ҡ� </option>
                        <option value="�չ">�չ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>2.</td>
                    <td>��Դ :</td>
                    <td> <select name="select3">
                        <option value = "0" selected>--- ������ ---</option>
                        <option value="1">���ѹ��ҡ</option>
                        <option value="2">ǧ�������</option>
                        <option value="3">ǧ�����ʵ�ԧ</option>
                        <option value="4">ǧ������ҡ�</option>
                        <option value="5">ǧ����ըչ</option>
                        <option value="6">�ѡ���ҡ�</option>
                        <option value="7">������ش��꡵�</option>
                        <option value="8">����Դ�ԧ�</option>
                        <option value="9">�ػ�ҡèչ</option>
                        <option value="10">����ǻ�Сͺ�ŧ</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td rowspan="2">3.</td>
                    <td rowspan="2">�ѹ - �������������ʴ� :</td>
                    <td> <select name="select3">
                        <%
							for (int i = 1 ; i <= 31 ; i ++) {
						%>
                        <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                        <%
							}
						%>
                      </select>
                      / 
                      <select name="select3">
                        <option value = "1" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "2" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                        <option value = "3" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                        <option value = "4" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                        <option value = "5" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                        <option value = "6" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                        <option value = "7" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                        <option value = "8" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                        <option value = "9" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                        <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                        <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                        <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
                      </select>
                      / 
                      <select name="select3">
                        <option value="2002" selected>2546</option>
                        <option value="2003">2547</option>
                        <option value="2004">2548</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td> <select name="select3">
                        <%
							for (int i = 0 ; i <= 23 ; i ++) {
						%>
                        <option value = "<%=i%>"><%=i%></option>
                        <%
						}
						%>
                      </select>
                      : 
                      <select name="select3">
                        <option value = "00" selected>00</option>
                        <option value = "30">30</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>4.</td>
                    <td>�ӹǹ������� : </td>
                    <td> <select name="select3">
                        <option value="3600000" selected> 1 �������</option>
                        <option value="7200000"> 2 ������� </option>
                        <option value="10800000"> 3 ������� </option>
                        <option value="14400000"> 4 ������� </option>
                        <option value="18000000"> 5 ������� </option>
                        <option value="21600000"> 6 ������� </option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>5.</td>
                    <td>�Ҥҵ���ش :</td>
                    <td> <input name="Minprice4" type="text" value="500" size="10"> 
                      �ҷ </td>
                  </tr>
                  <tr> 
                    <td>6.</td>
                    <td>�Ҥ��٧�ش:</td>
                    <td> <input name="Maxprice4" type="text" value="10000" size="10"> 
                      �ҷ</td>
                  </tr>
                  <tr> 
                    <td height="27">7.</td>
                    <td>��ͧ����ҤҶ١����ش :</td>
                    <td><input name="cheap" type="radio" value="yes" checked> 
                      ��ͧ��� <input type="radio" name="cheap" value="no"> ����ͧ���</td>
                  </tr>
                  <tr> 
                    <td height="27">8.</td>
                    <td>���ʶҹ��� :</td>
                    <td> <select name="select3">
                        <option value = "">-- ʶҹ��� --</option>
                        <option value = "����">����</option>
                        <option value = "�ҧ�ѡ">�ҧ�ѡ</option>
                        <option value = "�����ѹ">Patumwan</option>
                      </select> </td>
                  </tr>
                  <tr> 
                    <td>9.</td>
                    <td>���ͺ���ѷ Tour:</td>
                    <td> <select name="select3">
                        <option value = "0">---- ���ͺ���ѷ----</option>
                        <option value = "1">Tour1</option>
                        <option value = "2">Tour2</option>
                        <option value = "3">Tour3</option>
                        <option value = "4">Tour4</option>
                        <option value = "5">Tour5</option>
                        <option value = "6">Tour6</option>
                        <option value = "7">Tour7</option>
                        <option value = "8">Tour8</option>
                        <option value = "9">Tour9</option>
                        <option value = "10">Tour10</option>
                      </select> </td>
                  </tr>
                </table></td>
            </tr>
          </table>
        </div></td>
    </tr>
  </table>
	</form>
</body>
</html>
