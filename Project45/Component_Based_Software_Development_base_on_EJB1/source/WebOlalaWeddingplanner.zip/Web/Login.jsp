<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); %>
<% WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body   bgcolor="F9F9EF">

<p>&nbsp;</p>

<table width="602" height="282" border="0">
  <tr> 
    <td width="123">&nbsp;</td>
    <td width="469">
	<form name="form1" method="post" action="ToLogin.jsp" target="_parent">
	<table width="338" border="0">
        <tr> 
          <td width="122">���ͼ���� :</td>
          <td width="206"><input type="text" name="username"></td>
        </tr>
        <tr> 
          <td>���ʼ�ҹ :</td>
          <td><input type="password" name="password"></td>
        </tr>
        <tr> 
          <td height="16" colspan="2">
              <div align="center">
                <input type="submit" name="Submit" value="�������к�">
              </div>
            </td>
        </tr>
        <tr> 
          <td height="17" colspan="2"><div align="center">����ѧ�����ŧ����¹ 
              <a href="Register.jsp">�������</a> </div></td>
        </tr>
      </table></form>
	  </td>
  </tr>
  <tr> 
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
<div align="center"></div>
<div align="center"></div>
</body>
</html>