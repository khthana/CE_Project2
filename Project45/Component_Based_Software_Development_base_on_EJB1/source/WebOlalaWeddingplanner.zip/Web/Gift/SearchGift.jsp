<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Search Gift</title>
</head>

<body bgcolor="F9F9EF">
<%
        int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

        String tempstr = (String)request.getParameter("Wedding_Contact_ID");
        int Wedding_Contact_ID = Integer.parseInt(tempstr);

        tempstr = (String)request.getParameter("Gift_Contact_ID");
		int Gift_Contact_ID;
        if (tempstr == "0")
        {
          Gift_Contact_ID = 0;
        }
        else
        {
          Gift_Contact_ID = Integer.parseInt(tempstr);
        }
        tempstr = (String)request.getParameter("Gift_Name");
		String Gift_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("Gift_ID");
		int Gift_ID = Integer.parseInt(tempstr);
%>
<form name="form1" method="post" action="./ResultSearch.jsp">
<%Date now = new Date();%>
<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
  <tr>
    <td align= "left"><p>&nbsp;</p></td>
  </tr>
  <tr>
    <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
          <tr bgcolor="#FFCCFF"> 
            <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ����ѷ�ͧ������</div></td>
          </tr>
          <tr> 
            <td width="12">1.</td>
            <td width="195"> ��Դ�Թ��� :</td>
            <td width="221"> <select name="type_id">
                <option value="0" selected>������</option>
                <option value= "1">��ͺ�ٻ</option>
                <option value="2">��ش</option>
                <option value="3">��¹</option>
                <option value="4">�ǧ�ح�</option>
                <option value="5">�ͧ�����</option>
                <option value="6">����</option>
                <option value="7">��ش����¾ä��������</option>
                <option value="8">���ͧ���ͧ˹�ҧҹ</option>
                <option value="9">����</option>
              </select></td>
          </tr>
          <tr> 
            <td>2.</td>
            <td>�ٻẺ :</td>
            <td> <select name="style">
                <option value =""selected>�ء�ٻẺ</option>
                <option value="thai">��</option>
                <option value="chinese">�չ</option>
                <option value="international">�ҡ�</option>
              </select> </td>
          </tr>
          <tr> 
            <td>3.</td>
            <td>�Ҥҵ���ش :</td>
            <td> <input name="Minprice" type="text" value="5" size="10">
              �ҷ </td>
          </tr>
          <tr> 
            <td>4.</td>
            <td>�Ҥ��٧�ش :</td>
            <td> <input name="Maxprice" type="text" value="100" size="10">
              �ҷ</td>
          </tr>
          <tr> 
            <td height="27">5.</td>
            <td>��ͧ����ҤҶ١����ش :</td>
            <td><input name="cheap" type="radio" value="yes" checked>
              ��ͧ��� 
              <input type="radio" name="cheap" value="no">
              ����ͧ���</td>
          </tr>
          <tr> 
            <td>6.</td>
            <td>������ҹ��¢ͧ������ :</td>
            <td>
             <%if (Gift_Name.equals("null")){%>
			<select name="Gift_ID">
                <option value = "0">�ء��ҹ</option>
                <option value = "1">Gift1</option>
                <option value = "2">Gift2</option>
                <option value = "3">Gift3</option>
                <option value = "4">Gift4</option>
                <option value = "5">Gift5</option>
                <option value = "6">Gift6</option>
                <option value = "7">Gift7</option>
                <option value = "8">Gift8</option>
                <option value = "9">Gift9</option>
                <option value = "10">Gift10</option>
              </select>  &nbsp; 
               <%switch (Gift_ID){
case 1: Gift_Name = "GIFT1";break;
case 2: Gift_Name = "GIFT2";break;
case 3: Gift_Name = "GIFT3";break;
case 4: Gift_Name = "GIFT4";break;
case 5: Gift_Name = "GIFT5";break;
case 6: Gift_Name = "GIFT6";break;
case 7: Gift_Name = "GIFT7";break;
case 8: Gift_Name = "GIFT8";break;
case 9: Gift_Name = "GIFT9";break;
case 10: Gift_Name = "GIFT10";break;
case 0: Gift_Name = "";break;
}%>
  <input type = "hidden" name = "Gift_Name" value = "<%=Gift_Name%>">
<%}  else
  {out.println(Gift_Name);%>
  <input type = "hidden" name = "Gift_Name" value = "<%=Gift_Name%>">
  <input type = "hidden" name = "Gift_ID" value = "<%=Gift_ID%>">
<%                } %>
			</td>
          </tr>
        </table>
  <BR>
    </td>
  </tr>
  <tr>
    <td colspan="3" align="center"><br> <input type="submit" name="Submit" value="����">
    </td>
  </tr>
</table>
<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
<input type = "hidden" name = "Gift_Contact_ID" value = "<%=Gift_Contact_ID%>">
</form>
</body>
</html>