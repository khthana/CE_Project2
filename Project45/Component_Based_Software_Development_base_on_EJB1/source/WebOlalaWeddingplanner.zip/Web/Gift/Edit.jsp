<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Gift Shop</title>
</head>

<body bgcolor="F9F9EF">
<%
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);
	Integer tempint = null;
	Temp_Str = (String)request.getParameter("Gift_Contact_ID");
	int Gift_Contact_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Gift_Job_ID");
	int Gift_Job_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Gift_ID");
	int Gift_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Gift_Name");
	String Gift_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("SubType_Name");
	String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Quantity");
	int Quantity = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Price");
	double Price = Double.parseDouble(Temp_Str);
	String day2 = (String)request.getParameter("day1");
	String month2 = (String)request.getParameter("month1");
	String year2 = (String)request.getParameter("year1");
	String hour2 = (String)request.getParameter("hour1");
	String minute2 = (String)request.getParameter("minute1");
	String ReceiveDate = day2 + " " + month2 + " " + year2 + " " + hour2 + ":" + minute2 + ":00"; 
	Temp_Str = (String)request.getParameter("Label");
	String Label = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Address");
	String Address = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	if (day2.length()==1)
	{day2 = "0"+day2;}
	String RecieveTime = day2+" "+month2+" "+year2+" "+hour2+":"+minute2+":00";

	org.openuri.www.ReturnReserve result = GiftsoapProxy.giftEditOrder(Customer_ID,Gift_Job_ID, RecieveTime, Address, Label, Gift_ID, Wedding_Contact_ID,Gift_Contact_ID);
	if (result == null)
	{%>
		<a href = "../ShowContact.jsp">˹���á</a>
<%	}
	else
	{
%>
<center>
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�÷������ͧ��ҹ��¢ͧ������</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left" width = "30%">�����Թ��� : </div></td>
      <td width="70%"> <div align="left"><%=Gift_Job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">��Դ�Թ��� :</div></td>
      <td> <div align="left"><%=SubType_Name%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">��������´ :</div></td>
      <td>  <div align="left"><%=SubType_Detail%></div></td>
    </tr>

    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">�ѹ���ШѴ���Թ����� � :</div></td>
      <td> <div align="left">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = ReceiveDate.toCharArray();
							for(int j = 0;  j < ReceiveDate.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
	</div></td>
    </tr>
    <tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">��ͤ������о����ŧ�ͧ������ :</div></td>
      <td><div align="left"><%=Label%></div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">ʶҹ����Ѻ�ͧ :</div></td>
      <td> <div align="left"><%=Address%></div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">�Ҥ��Թ��ҷ����� :</div></td>
      <td> <div align="left"><%=Price%></div></td>
    </tr>
    <tr> 
      <td><div align="center">8.</div></td>
      <td><div align="left">�ӹǹ�Թ��ҷ����� :</div></td>
      <td> <div align="left"><%=Quantity%></div></td>
    </tr>
    <tr> 
      <td><div align="center">9.</div></td>
      <td><div align="left">������ҹ��¢ͧ������ :</div></td>
      <td> <div align="left"><%=Gift_Name%></div></td>
    </tr>
  </table>
  <p>&nbsp;</p>
<a href = "../ShowContact.jsp">˹���á</a>
	  <%}%>
</center>
</body>
</html>
