<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
<%@ page import = "java.lang.*"%>
  <%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>
<body  bgcolor="F9F9EF">
<%         String Temp_Str = null;
                int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

                Temp_Str = (String)request.getParameter("Wedding_Contact_id");
                int Wedding_Contact_id = Integer.parseInt(Temp_Str);

                Temp_Str = (String)request.getParameter("GiftNumber");
                 int GiftNumber = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Gift_contact_id");
				int Gift_contact_id = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Gift_Contact_Name");
				String Gift_Contact_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

			 Temp_Str = (String)request.getParameter("GiftName");
             String GiftName = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
			 String type_id = (String)request.getParameter("type_id");
			 String subtype_id = (String)request.getParameter("Subtype_id");
			 String font_style = (String)request.getParameter("font_style");
			Temp_Str  = (String)request.getParameter("font_color");
			String font_color = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
			Temp_Str  = (String)request.getParameter("label");
			String label = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
			Temp_Str  = (String)request.getParameter("address");
			String address = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
			Temp_Str  = (String)request.getParameter("type_name");
			String type_name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
			Temp_Str  = (String)request.getParameter("subtype_name");
			String subtype_name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
			String quantityInt  = (String)request.getParameter("amount");
			int quantity = Integer.parseInt(quantityInt);
		String date = (String)request.getParameter("Date");
		String month = (String)request.getParameter("Month");
		String year = (String)request.getParameter("Year");
		String hour = (String)request.getParameter("Hour");
		String minute2 = (String)request.getParameter("Minute");
		if (date.length() == 1)
		{
			date = "0" +date;
		}
		String startdate  = new String(date+" " +month+" "+year+" "+hour+":"+minute2+":00");

		boolean create = false;
		if(Gift_contact_id==0){
			Gift_contact_id = GiftsoapProxy.giftCreateContact(Customer_ID,Gift_Contact_Name,GiftNumber,Wedding_Contact_id);
			create = true;
		}
			org.openuri.www.ReturnReserve result = GiftsoapProxy.giftOrder(Customer_ID,type_id,subtype_id,font_style,font_color,label,startdate,address,quantity,GiftNumber,Wedding_Contact_id,Gift_contact_id);
		if (((result == null)||(result.getJobId()==0))&&(create == true))
		{
			boolean cancel =GiftsoapProxy.giftCancelContact(Customer_ID,Gift_contact_id,Wedding_Contact_id);%>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
<center><a href = "../ShowJob.jsp#gift">��Ѻ�˹���ʴ���������´ 		<%}else if ((result == null )||(result.getJobId() == 0)){%>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<center>�������ö�ͧ��</center>
<center><a href = "../ShowJob.jsp#gift">��Ѻ�˹���ʴ���������´ <%		}else{
//GiftsoapProxy.giftOrder(Customer_ID,type_id,subtype_id,font_style,font_color,label,startdate,address,quantity,GiftNumber,Wedding_Contact_id,Gift_contact_id);
	%>
<table width = "80%" align = "center" border = 1>
<tr><td align = "left">���� Contact :</td><td align = "left"><%=Gift_Contact_Name%>&nbsp;</td></tr>
<tr><td align = "left">��Դ�Թ��� :</td><td align = "left"><%=type_name%></td></tr>
<tr><td align = "left">�ٻẺ :</td><td align = "left"><%=subtype_name%></td></tr>
<tr><td align = "left">��ͤ������о����ŧ�ͧ������ :</td><td align = "left"><%=label%></td></tr>
<tr><td align = "left">�ٻẺ����ѡ�� :</td><td align = "left"><%=font_style%></td></tr>
<tr><td align = "left">�բͧ����ѡ�� :</td><td align = "left"><%=font_color%></td></tr>
<tr><td align = "left">�ѹ���ШѴ���Թ����� � :</td><td align = "left">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = startdate.toCharArray();
							for(int j = 0;  j < startdate.length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "left">��ͤ������о����ŧ�ͧ������ :</td><td align = "left"><%=result.getPrice()%></td></tr>
<tr><td align = "left">�ӹǹ�Թ��ҷ����� :</td><td align = "left"><%=quantity%></td></tr>
<tr><td align = "left">ʶҹ����Ѻ�ͧ :</td><td align = "left"><%=address%></td></tr>
<tr><td align = "left">�ѹ�׹�ѹ�������Թ��� :</td><td align = "left">
					<%
							temp = new String();
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = new String();
							minute1 = 0;
							minute = new String();
							temp_date = result.getDeadline().toCharArray();
							for(int j = 0;  j < result.getDeadline().length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "left">������ҹ��¢ͧ������ :</td><td align = "left"><%=GiftName%></td></tr>
</table>

<center>��èͧ���º��������</center>
<center><a href = "../ShowJob.jsp#gift">��Ѻ�˹���ʴ���������´ 	<%}%>
</body>
</html>