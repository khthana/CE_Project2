<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Gift_Contact_ID");
	int Gift_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Gift_Job_ID");
	int Gift_Job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Gift_Name");
	String Gift_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Gift_ID");
	int Gift_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Sub_Type_Name");
	String Sub_Type_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("ReceiveDate");
	String ReceiveDate = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	org.openuri.www.JobDetail list = GiftsoapProxy.giftShowDetailJob(Wedding_Contact_ID, Gift_Contact_ID, Gift_Job_ID);
	if (list != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��¡�çҹ�������ͧ��ҹ��¢ͧ������</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">�����Թ��� :</div></td>
      <td width="65%"><div align="center"><%=list.getJobId()%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">��Դ�Թ��� :</div></td>
      <td><div align="center"><%=list.getSubtypeName()%></div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">��������´ :</div></td>
      <td> <div align="center"><%=list.getSubtypeDetail()%></div></td>
    </tr>
    <tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">��ͤ������о����ŧ�ͧ������ :</div></td>
      <td><div align="center"><%=list.getLabel()%></div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">�ѹ���ШѴ���Թ����� � :</div></td>
      <td><div align="center">
	  					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date =list.getReceiveDate().toCharArray();
							for(int j = 0;  j < list.getReceiveDate().length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
	</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ҤҢͧ������ :</div></td>
      <td><div align="center"><%=list.getJobTotalPrice()%>&nbsp;�ҷ</div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">�ӹǹ�Թ��ҷ����� :</div></td>
      <td><div align="center"><%=list.getQuantity()%>&nbsp;</div></td>
    </tr>
    <tr>
      <td><div align="center">8.</div></td>
      <td><div align="center">ʶҹ����Ѻ�ͧ :</div></td>
      <td><div align="center"><%=list.getAddress()%></div></td>
    </tr>
    <tr>
      <td><div align="center">9.</div></td>
      <td><div align="center">������ҹ��¢ͧ������ :</div></td>
      <td><div align="center"><%=Gift_Name%>&nbsp;</div></td>
    </tr>
  </table>
<center>
  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditGift.jsp">
          <div align="right">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Gift_Contact_ID" value="<%=list.getContactId()%>">
			<input type="hidden" name="Gift_Job_ID" value="<%=list.getJobId()%>">
			<input type="hidden" name="Type_ID" value="<%=list.getTypeId()%>">
			<input type="hidden" name="SubType_ID" value="<%=list.getSubtypeId()%>">
			<input type="hidden" name="SubType_Name" value="<%=list.getSubtypeName()%>">
			<input type="hidden" name="SubType_Detail" value="<%=list.getSubtypeDetail()%>">
			<input type="hidden" name="Label" value="<%=list.getLabel()%>">
			<input type="hidden" name="ReceiveDate" value="<%=list.getReceiveDate()%>">
			<input type="hidden" name="Address" value="<%=list.getAddress()%>">
			<input type="hidden" name="Quantity" value="<%=list.getQuantity()%>">
			<input type="hidden" name="Price" value = "<%=list.getJobTotalPrice()%>">
			<input type="hidden" name="Gift_Name" value= "<%=Gift_Name%>">
			<input type="hidden" name="Gift_ID" value="<%=Gift_ID%>">
			<input type="submit" name="Submit" value="Edit">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelGiftJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Gift_Contact_ID" value="<%=Gift_Contact_ID%>">
			<input type="hidden" name="Gift_Job_ID" value="<%=Gift_Job_ID%>">
          <input type="submit" name="Submit2" value="Cancel Job">
        </form></td>
    </tr>
  </table>
  </center>
  <p>&nbsp;</p>
</div>
  <%}else {%>
		<center>�������������´��èͧ</center>
<%  }%>
</body>
</html>