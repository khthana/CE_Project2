<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
  <%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Gift</title></head>

<body bgcolor="F9F9EF">
<%  String tempstr = null;
/////////////////////////////////////////////////initial parameter//////////////////////////////////////////////////////////////	
		int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		String type_id = (String)request.getParameter("type_id");
		String style = (String)request.getParameter("style");
		
        tempstr = (String)request.getParameter("Wedding_Contact_ID");
        int Wedding_Contact_ID = Integer.parseInt(tempstr);		

		tempstr = (String)request.getParameter("Minprice");
		double minprice = Double.parseDouble(tempstr);

		tempstr = (String)request.getParameter("Maxprice");
		double maxprice = Double.parseDouble(tempstr);

        String Cheap =  (String)request.getParameter("cheap");
        boolean cheap = true;
        if (Cheap.equals("no"))
            cheap = false;

		//////////////////////Get Gift_ID////////////////////////////////
		int Gift_ID = java.lang.Integer.parseInt((String)request.getParameter("Gift_ID"));
		tempstr = (String)request.getParameter("Gift_Name");
        String Gift_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

        tempstr = (String)request.getParameter("Gift_Contact_ID");
        int Gift_Contact_ID = Integer.parseInt(tempstr);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//org.openuri.www.GiftInfo[] giftSearch(java.lang.String typeId, java.lang.String style, double minPrice, double maxPrice, boolean cheap, int giftNumber)
		GiftInfo[] info = null;
		info = GiftsoapProxy.giftSearch(type_id,style,minprice,maxprice,cheap,Gift_ID);
		%>
<center>
  <table width="95%" height="143" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="8"><center>�š�ä���</center></td>
    </tr>
    <tr>
      <td>��Ǵ�Թ���</td>
      <td>��Դ</td>
      <td>��������´</td>
      <td>�Ҥ�</td>
      <td>�ٻ������ҧ</td>
      <td>������ҹ��¢ͧ������</td>
      <td>���������ҹ��¢ͧ������</td>
      <td>&nbsp;</td>
    </tr>
<%
		if ((info != null)&&(info.length != 0)){
		for (int i = 0 ; i < info.length ; i ++ )
		{
				%>
<form name="form1" method="post" action="ReserveGift.jsp">
    <tr>
		<td align = "center"><%=info[i].getTypeName()%></td>
		<td align = "center"><%=info[i].getSubtypeName()%></td>
		<td align = "center"><%=info[i].getSubtypeDetail()%></td>
		<td align = "center"><%=info[i].getPrice()%></td>
		<td align = "center"><a href =<%=info[i].getPicUrl()%>><img src =<%=info[i].getPicUrl()%>></a></td>
		<td align = "center"><%=info[i].getGiftName()%></td>
		<td align = "center"><%=info[i].getGiftAddress()%></td>
		<td align = "center"><input type = "submit" value = "�ͧ" name = "reserve"></td>    
	</tr>
    <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
    <input type = "hidden" name = "Gift_Contact_ID" value = "<%=Gift_Contact_ID%>">
	<input type = "hidden" name = "type_id" value = "<%=info[i].getTypeId()%>">
	<input type = "hidden" name = "type_name" value = "<%=info[i].getTypeName()%>">
	<input type = "hidden" name = "subtype_id" value = "<%=info[i].getSubtypeId()%>">
	<input type = "hidden" name = "subtype_name" value = "<%=info[i].getSubtypeName()%>">
	<input type = "hidden" name = "subtype_detail" value = "<%=info[i].getSubtypeDetail()%>">
	<input type = "hidden" name = "picurl" value = "<%=info[i].getPicUrl()%>">
	<input type = "hidden" name = "price" value = "<%=info[i].getPrice()%>">
	<input type = "hidden" name = "Gift_name" value = "<%=info[i].getGiftName()%>">
	<input type = "hidden" name = "Gift_Address" value = "<%=info[i].getGiftAddress()%>">
    <input type = "hidden" name= "Gift_ID" value = "<%=info[i].getGiftNumber()%>">
</form>
				<%
		}}
%>
  </table>
</center>
</body>
</html>