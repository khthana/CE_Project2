<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
  <%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Gift</title></head>

<body bgcolor="F9F9EF">
<%  String tempstr = null;
/////////////////////////////////////////////////initial parameter//////////////////////////////////////////////////////////////	
		String type_id = (String)request.getParameter("type_id");
		String style = (String)request.getParameter("style");
		
		tempstr = (String)request.getParameter("Minprice");
		double minprice = Double.parseDouble(tempstr);

		tempstr = (String)request.getParameter("Maxprice");
		double maxprice = Double.parseDouble(tempstr);

        String Cheap =  (String)request.getParameter("cheap");
        boolean cheap = true;
        if (Cheap.equals("no"))
            cheap = false;

		//////////////////////Get Gift_ID////////////////////////////////
		int Gift_ID = java.lang.Integer.parseInt((String)request.getParameter("Gift_ID"));

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//org.openuri.www.GiftInfo[] giftSearch(java.lang.String typeId, java.lang.String style, double minPrice, double maxPrice, boolean cheap, int giftNumber)
		GiftInfo[] info = null;
		info = GiftsoapProxy.giftSearch(type_id,style,minprice,maxprice,cheap,Gift_ID);
		%>
<center>
  <table width="95%" height="143" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="7"><center>�š�ä���</center></td>
    </tr>
    <tr>
      <td>��Ǵ�Թ���</td>
      <td>��Դ</td>
      <td>��������´</td>
      <td>�Ҥ�</td>
      <td>�ٻ������ҧ</td>
      <td>������ҹ��¢ͧ������</td>
      <td>���������ҹ��¢ͧ������</td>
    </tr>
<%
		if ((info != null)&&(info.length != 0)){
		for (int i = 0 ; i < info.length ; i ++ )
		{
				%>
    <tr>
		<td align = "center"><%=info[i].getTypeName()%></td>
		<td align = "center"><%=info[i].getSubtypeName()%></td>
		<td align = "center"><%=info[i].getSubtypeDetail()%></td>
		<td align = "center"><%=info[i].getPrice()%></td>
		<td align = "center"><a href =<%=info[i].getPicUrl()%>><img src =<%=info[i].getPicUrl()%>></a></td>
		<td align = "center"><%=info[i].getGiftName()%></td>
		<td align = "center"><%=info[i].getGiftAddress()%></td>
	</tr>
				<%
		}}
%>
  </table>
<form name="form1" method="post" action="./SearchNoLog.jsp" target = "mainFrame">
    <input type="submit" name="Submit" value="Back">
  </form>
</center>
</body>
</html>