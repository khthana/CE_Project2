<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page import="java.lang.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
  <%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>
<body bgcolor="F9F9EF">
<%		
String tempstr = null;
/////////////////////////////////////////////////initial parameter//////////////////////////////////////////////////////////////		
String type_id = null; 
String type_name = null;
String subtype_id = null;
String subtype_name = null;
String subtype_detail = null;
String pic_url =null;
double price = 0;
String GiftName = null;
String GiftAddress = null;
int GiftNumber = 0;
int Wedding_Contact_ID = 0;
int Gift_Contact_ID = 0;
int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
tempstr = (String)request.getParameter("Wedding_Contact_ID");
Wedding_Contact_ID = Integer.parseInt(tempstr);
tempstr = (String)request.getParameter("Gift_Contact_ID");
Gift_Contact_ID = Integer.parseInt(tempstr);
type_id = (String)request.getParameter("type_id");
tempstr = (String)request.getParameter("subtype_name");
subtype_name= new String(tempstr.getBytes("ISO8859_1"),"MS874");
subtype_id = (String)request.getParameter("subtype_id");
tempstr = (String)request.getParameter("type_name");
type_name= new String(tempstr.getBytes("ISO8859_1"),"MS874");
tempstr = (String)request.getParameter("subtype_detail");
subtype_detail = new String(tempstr.getBytes("ISO8859_1"),"MS874");
pic_url = (String)request.getParameter("picurl");
tempstr = (String)request.getParameter("price");
Double aaa = new Double(tempstr);
price = aaa.doubleValue();
GiftName = (String)request.getParameter("Gift_name");
GiftAddress = (String)request.getParameter("Gift_Address");
tempstr = (String)request.getParameter("Gift_ID");
GiftNumber = Integer.parseInt(tempstr);
Date now2 = new Date();
%>
<center>
<form name="form1" method="post" action="BookGift.jsp">
<%Date now = new Date();%>
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ����ѷ�͹����෹�����</div></td>
      </tr>
      <tr> 
        <td width="5%">1.</td>
        <td width="40%">���� contact :</td>
        <td width="60%"><input type="text" name="Gift_Contact_Name" value = "Olala">&nbsp;</td>
      </tr>
      <tr> 
        <td>2.</td>
        <td>��Դ�Թ��� :</td>
        <td align = "left"><%=type_name%></td>
      </tr>
      <tr> 
        <td>3.</td>
        <td>�ٻẺ :</td>
        <td align = "left"><%=subtype_name%></td>
      </tr>
	 <tr> 
        <td>4.</td>
        <td>��������´ :</td>
        <td align = "left"><%=subtype_detail%>	    
		</td>
	</tr>
	  <tr> 
        <td>5.</td>
        <td>��ͤ������о����ŧ�ͧ������ :</td>
        <td align = "left"><textarea name="label"></textarea> </td>
      </tr>
      <tr> 
        <td>6.</td>
        <td>�ٻẺ����ѡ�� :</td>
        <td align = "left"><select name="font_style">
                <option value = "Times New Roman">Times New Roman</option>
                <option value = "Angsana New">Angsana New</option>
                <option value = "Cordia New">Cordia New</option>
                <option value = "Arial Black">Arial Black</option>
          </select></td>
      </tr>
      <tr> 
        <td>7.</td>
        <td>�բͧ����ѡ�� :</td>
        <td align = "left"><select name="font_color">
                <option value = "ᴧ">ᴧ</option>
                <option value = "��">��</option>
                <option value = "����">����</option>
                <option value = "����Թ">����Թ</option>
          </select></td>
      </tr>
      <tr> 
        <td>8.</td>
        <td>ʶҹ����Ѻ�ͧ :</td>
        <td align = "left"><input type="text" name="address"></td>
      </tr>
      <tr> 
        <td>9.</td>
        <td>�ӹǹ�Թ��ҷ����� :</td>
        <td align = "left"><input type="text" name="amount" value = "10"></td>
      </tr>
      <tr> 
        <td>10.</td>
        <td>�Ҥ��Թ��� :</td>
        <td align = "left"><%= price%></td>
      </tr>
	  <tr>
		<td height="90">11.</td>
        <td>�ѹ����Ѻ�ͧ :</td>
        <td align = "left"><p>
		<%now2.setTime(now.getTime()+1000*10*60*60*24);%>
            <select name="Date">
              <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
              <option value = "<%=i%>" <% if ( i == now2.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
              <%
				}
		%>
            </select>
            /
            <select name="Month">
              <option value = "01" <%if (now2.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "02" <%if (now2.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
              <option value = "03" <%if (now2.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
              <option value = "04" <%if (now2.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
              <option value = "05" <%if (now2.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
              <option value = "06" <%if (now2.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
              <option value = "07" <%if (now2.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
              <option value = "08" <%if (now2.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
              <option value = "09" <%if (now2.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
              <option value = "10" <%if (now2.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "11" <%if (now2.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
              <option value = "12" <%if (now2.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
            </select>
            /
            <select name="Year">
              <option value="2003" selected>2546</option>
              <option value="2004">2547</option>
              <option value="2005">2548</option>
            </select>
          </p>
          <p>
            <select name="Hour">
              <option value = "10">10</option>
              <option value = "11">11</option>
              <option value = "12">12</option>
              <option value = "13">13</option>
              <option value = "14">14</option>
              <option value = "15">15</option>
            </select>
            :
            <select name="Minute">
              <option value = "00" selected>00</option>
              <option value = "30">30</option>
            </select>
          </p></td>
	  </tr>
      <tr> 
        <td>12.</td>
        <td>���ͺ���ѷ GIFT SHOP :</td>
        <td align = "left"><%= GiftName%></td>
      </tr>
      <tr> 
        <td colspan="3">&nbsp;<center><input type="submit" name="Submit" value="�ͧ"></center></td>
      </tr>
    </table>
<input type = "hidden" name = "type_id" value = "<%=type_id%>">
<input type = "hidden" name = "Subtype_id" value = "<%=subtype_id%>">
<input type = "hidden" name = "GiftNumber" value = "<%=GiftNumber%>">
<input type = "hidden" name = "Wedding_Contact_id" value = "<%=Wedding_Contact_ID%>">
<input type = "hidden" name = "Gift_contact_id" value = "<%=Gift_Contact_ID%>">
<input type = "hidden" name = "GiftName" value = "<%=GiftName%>">
<input type = "hidden" name = "subtype_name" value = "<%=subtype_name%>">
<input type = "hidden" name = "type_name" value = "<%=type_name%>">
  </form>
  <p>&nbsp;</p>
</center>
</body>
</html>