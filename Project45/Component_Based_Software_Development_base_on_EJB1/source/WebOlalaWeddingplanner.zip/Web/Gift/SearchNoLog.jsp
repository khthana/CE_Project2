<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Search Gift</title>
</head>

<body bgcolor="F9F9EF">
<form name="form1" method="post" action="./ResultSearchNoLog.jsp">
<%Date now = new Date();%>
<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
  <tr>
    <td align= "left"><p>&nbsp;</p></td>
  </tr>
  <tr>
    <td width="450"><table width="450" border="1" bordercolor="#CCCCCC">
          <tr bgcolor="#FFCCFF"> 
            <td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ����ѷ�ͧ������</div></td>
          </tr>
          <tr> 
            <td width="12">1.</td>
            <td width="195"> ��Դ�Թ��� :</td>
            <td width="221"> <select name="type_id">
                <option value="0" selected>������</option>
                <option value= "1">��ͺ�ٻ</option>
                <option value="2">��ش</option>
                <option value="3">��¹</option>
                <option value="4">�ǧ�ح�</option>
                <option value="5">�ͧ�����</option>
                <option value="6">����</option>
                <option value="7">��ش����¾ä��������</option>
                <option value="8">���ͧ���ͧ˹�ҧҹ</option>
                <option value="9">����</option>
              </select></td>
          </tr>
          <tr> 
            <td>2.</td>
            <td>�ٻẺ :</td>
            <td> <select name="style">
                <option value =""selected>�ء�ٻẺ</option>
                <option value="thai">��</option>
                <option value="chinese">�չ</option>
                <option value="international">�ҡ�</option>
              </select> </td>
          </tr>
          <tr> 
            <td>3.</td>
            <td>�Ҥҵ���ش :</td>
            <td> <input name="Minprice" type="text" value="5" size="10">
              �ҷ </td>
          </tr>
          <tr> 
            <td>4.</td>
            <td>�Ҥ��٧�ش :</td>
            <td> <input name="Maxprice" type="text" value="100" size="10">
              �ҷ</td>
          </tr>
          <tr> 
            <td height="27">5.</td>
            <td>��ͧ����ҤҶ١����ش :</td>
            <td><input name="cheap" type="radio" value="yes" checked>
              ��ͧ��� 
              <input type="radio" name="cheap" value="no">
              ����ͧ���</td>
          </tr>
          <tr> 
            <td>6.</td>
            <td>������ҹ��¢ͧ������ :</td>
            <td>
			<select name="Gift_ID">
                <option value = "0">�ء��ҹ</option>
                <option value = "1">Gift1</option>
                <option value = "2">Gift2</option>
                <option value = "3">Gift3</option>
                <option value = "4">Gift4</option>
                <option value = "5">Gift5</option>
                <option value = "6">Gift6</option>
                <option value = "7">Gift7</option>
                <option value = "8">Gift8</option>
                <option value = "9">Gift9</option>
                <option value = "10">Gift10</option>
              </select>  &nbsp; 
			</td>
          </tr>
        </table>
  <BR>
    </td>
  </tr>
  <tr>
    <td colspan="3" align="center"><br> <input type="submit" name="Submit" value="����">
    </td>
  </tr>
</table>
</form>
</body>
</html>