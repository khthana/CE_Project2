<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Gift</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	Integer tempint = null;

	tempstr = (String)request.getParameter("Gift_Contact_ID");
	int Gift_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Gift_Job_ID");
	int Gift_Job_ID = Integer.parseInt(tempstr);

	tempstr  = (String)request.getParameter("Type_ID");
	String type_id = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	StringTokenizer strtoken = new StringTokenizer(type_id," ");
	int Type_ID = Integer.parseInt(strtoken.nextToken());

	tempstr = (String)request.getParameter("SubType_ID");
	String subtype_id = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(strtoken.nextToken());

	tempstr = (String)request.getParameter("SubType_Name");
	String SubType_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Label");
	String Label = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("ReceiveDate");
	String ReceiveDate = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Address");
	String Address = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Quantity");
	int Quantity = Integer.parseInt(tempstr);
	tempstr  = (String)request.getParameter("Price");
	double Price = Double.parseDouble(tempstr);

	tempstr = (String)request.getParameter("Gift_Name");
	String Gift_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Gift_ID");
	int Gift_ID = Integer.parseInt(tempstr);
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = ReceiveDate.toCharArray();
							for(int j = 0;  j < ReceiveDate.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
<div align="center">
<form name="form1" method="post" action="./Edit.jsp">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�÷������ͧ��ҹ��¢ͧ������</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left" width = "30%">�����Թ��� : </div></td>
      <td width="70%"> <div align="left"><%=Gift_Job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">��Դ�Թ��� :</div></td>
      <td> <div align="left"><%=SubType_Name%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">��������´ :</div></td>
      <td>  <div align="left"><%=SubType_Detail%></div></td>
    </tr>

    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">�ѹ���ШѴ���Թ����� � :</div></td>
      <td> <div align="left">
<select name = "day1" >
			<%
					for (int i = 1 ; i <= 31 ; i ++) {
			%>
					<option value = "<%=i%>" <% if ( i == day1) { %> <%="selected"%> <%}%>><%=i%></option>
			<%
				}
			%>
		</select>&nbsp;��͹ 
		 <select name = "month1">
		 <option value = "01" <%if (month1 == 1) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "02" <%if (month1 == 2) { %><%="selected"%><%}%>>����Ҿѹ��</option>
		 <option value = "03" <%if (month1 == 3) { %><%="selected"%><%}%>>�չҤ�</option>
		 <option value = "04" <%if (month1 == 4) { %><%="selected"%><%}%>>����¹</option>
		 <option value = "05" <%if (month1 == 5) { %><%="selected"%><%}%>>����Ҥ�</option>
		 <option value = "06" <%if (month1 == 6) { %><%="selected"%><%}%>>�Զع�¹</option>
		 <option value = "07" <%if (month1 == 7) { %><%="selected"%><%}%>>�á�Ҥ�</option>
		 <option value = "08" <%if (month1 == 8) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
		 <option value = "09" <%if (month1 == 9) { %><%="selected"%><%}%>>�ѹ��¹</option>
		 <option value = "10" <%if (month1 == 10) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "11" <%if (month1 == 11) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
		 <option value = "12" <%if (month1 == 12) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
		</select>&nbsp;�.�. 
		<select name = "year1">
		<option value = "2003">2546</option>
		<option value = "2004">2547</option>
		<option value = "2005">2548</option>
		</select>
		&nbsp;����		
		<select name = "hour1">
				<%
				for (int i = 0 ; i <= 23 ; i ++) {
				%>
				<option value = "<%=i%>" <%if (tempint.parseInt(hour1) == i) { %><%="selected"%><%}%> ><%=i%></option>
				<%
				}
		%>
		</select>&nbsp; : &nbsp;
		<select name = "minute1">
		<option value = "00" <%if (minute.equals("00")) { %><%="selected"%><%}%>>00</option>
		<option value = "30" <%if (minute.equals("30")) { %><%="selected"%><%}%>>30</option>
		</select> �.
	</div></td>
    </tr>
		<%	Date Receivedate = new Date(year1,month1,day1, tempint.parseInt(hour1),tempint.parseInt(minute));
		%>
    <tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">��ͤ������о����ŧ�ͧ������ :</div></td>
      <td><div align="left"><textarea name="Label"></textarea>  </div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">ʶҹ����Ѻ�ͧ :</div></td>
      <td> <div align="left"><input type="text" name="Address"></div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">�Ҥ��Թ��ҷ����� :</div></td>
      <td> <div align="left"><%=Price%></div></td>
    </tr>
    <tr> 
      <td><div align="center">8.</div></td>
      <td><div align="left">�ӹǹ�Թ��ҷ����� :</div></td>
      <td> <div align="left"><%=Quantity%></div></td>
    </tr>
    <tr> 
      <td><div align="center">9.</div></td>
      <td><div align="left">������ҹ��¢ͧ������ :</div></td>
      <td> <div align="left"><%=Gift_Name%></div></td>
    </tr>
  </table>
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Gift_Contact_ID" value="<%=Gift_Contact_ID%>">
			<input type="hidden" name="Gift_Job_ID" value="<%=Gift_Job_ID%>">
			<input type="hidden" name="Gift_ID" value ="<%=Gift_ID%>">
			<input type="hidden" name="Gift_Name" value ="<%=Gift_Name%>">
			<input type="hidden" name="SubType_Name" value="<%=SubType_Name%>">
			<input type="hidden" name="SubType_Detail" value="<%=SubType_Detail%>">
			<input type="hidden" name="Quantity" value="<%=Quantity%>">
			<input type="hidden" name="Price" value="<%=Price%>">
			<center><input type = "Submit" value = "Edit"></center>
</form>
  <p>&nbsp;</p>
</div>
</body>
</html>