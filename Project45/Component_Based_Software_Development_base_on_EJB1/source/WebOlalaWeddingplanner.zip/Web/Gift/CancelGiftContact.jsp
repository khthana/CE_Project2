<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
  <%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Cancel Gift Contact</title>
</head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Gift_Contact_ID");
    int Gift_Contact_ID = 0;
    if (tempstr != null)
    {
      Gift_Contact_ID = Integer.parseInt(tempstr);
	  //boolean giftCancelContact(int customerId, int giftContactId, int weddingContactID)
      boolean cancel = GiftsoapProxy.giftCancelContact(Customer_id,Gift_Contact_ID,Wedding_Contact_ID);
      response.sendRedirect("../ShowContact.jsp");
    }
    else response.sendRedirect("../Main.htm");
	%>
</body>
</html>