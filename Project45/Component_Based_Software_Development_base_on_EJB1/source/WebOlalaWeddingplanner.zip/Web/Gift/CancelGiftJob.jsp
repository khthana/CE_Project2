<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Cancel Job Gift</title>
</head>
<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Gift_Contact_ID");
    int Gift_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Gift_Job_ID");
    int Gift_Job_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
//boolean giftCancelJob(int customerId, int giftContactId, int jobId, int weddingContactID)
    boolean cancel = GiftsoapProxy.giftCancelJob(Customer_id,Gift_Contact_ID,Gift_Job_ID,Wedding_Contact_ID);
    if (cancel == true)
    {
		org.openuri.www.Job[] GiftJobList =  GiftsoapProxy.giftListJob(Customer_id,Wedding_Contact_ID,Gift_Contact_ID);
		if ((GiftJobList != null)&&(GiftJobList.length == 0))
		{
			boolean cancelcontact = GiftsoapProxy.giftCancelContact(Customer_id,Gift_Contact_ID,Wedding_Contact_ID);
			if (cancelcontact == false)
			{
				response.sendRedirect("../Main.htm");
			}
		}
      response.sendRedirect("../ShowContact.jsp");
    }
	else response.sendRedirect("../Main.htm");
%>
</body>
</html>