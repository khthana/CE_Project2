<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.EntertainJobDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Tour_Contact_ID");
	int Tour_Contact_ID = Integer.parseInt(tempstr);
	tempstr =(String)request.getParameter("Tour_Job_ID");
	int Tour_Job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Package_Name");
	String Package_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Package_ID");
	int Package_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Tour_Name");
	String Tour_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Tour_ID");
	int Tour_ID = Integer.parseInt(tempstr);
	//org.openuri.www.PackageDetail tour_GetPackageDetail(int packageID, int tourID)
	org.openuri.www.PackageDetail detail = ToursoapProxy.tour_GetPackageDetail(Package_ID,Tour_ID);
	if (detail != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��������´ᾤࡨ�����</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">����ᾤࡨ :</div></td>
      <td width="65%"><div align="center"><%=Package_Name%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">����ȷ��� :</div></td>
      <td><div align="center">
	  <%if ((detail.getCountryName() != null)&&(detail.getCountryName().length != 0)){
			for (int i =0; i <detail.getCountryName().length;i++){
				String[]  CountryName = detail.getCountryName();
				out.println(CountryName[i]);}}%>
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">�ѹ�͡�Թ�ҧ :</div></td>
      <td> <div align="center">
				<%String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = detail.getStartDate().toCharArray();
							for(int j = 0;  j < detail.getStartDate().length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
		</div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">�ѹ��Ѻ :</div></td>
      <td> <div align="center">
				<%temp = new String();
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = new String();
							minute1 = 0;
							minute = new String();
							temp_date = detail.getFinishDate().toCharArray();
							for(int j = 0;  j < detail.getFinishDate().length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
		</div></td>
    </tr>
	<tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">�ѹ�׹�ѹ��èͧ:</div></td>
      <td><div align="center">
					<%
							temp = new String();
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = new String();
							minute1 = 0;
							minute = new String();
							temp_date = detail.getDeadline().toCharArray();
							for(int j = 0;  j < detail.getDeadline().length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">ʶҹ���� :</div></td>
      <td><div align="center">
	  <%if ((detail.getPlaceName() != null)&&(detail.getPlaceName().length != 0)){
			for (int i =0; i <detail.getPlaceName().length;i++){
				String[]  PlaceName = detail.getPlaceName();
				out.println(PlaceName[i]);}}%>
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">�ç������ѡ :</div></td>
      <td><div align="center">
	  <%if ((detail.getHotelName() != null)&&(detail.getHotelName().length != 0)){
			for (int i =0; i <detail.getHotelName().length;i++){
				String[]  PlaceName = detail.getHotelName();
				out.println(PlaceName[i]);}}%>
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ӹǹ :</div></td>
      <td><div align="center"><%=detail.getQuantity()%>&nbsp;��</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ӹǹ���������ҡ����ش :</div></td>
      <td><div align="center"><%=detail.getQuota()%>&nbsp;��</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�Ԩ�������� :</div></td>
      <td><div align="center">
	  <%if ((detail.getActName() != null)&&(detail.getActName().length != 0)){
			for (int i =0; i <detail.getActName().length;i++){
				String[]  PlaceName = detail.getActName();
				out.println(PlaceName[i]);}}%>
			</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">��������´�ͧᾤࡨ :</div></td>
      <td><div align="center"><%=detail.getPackageDescript()%></div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ҤҢͧᾤࡨ :</div></td>
      <td><div align="center"><%=detail.getCost()%></div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">���ͺ���ѷ����� :</div></td>
      <td><div align="center"><%=Tour_Name%>&nbsp;</div></td>
    </tr>
	<form name="form1" method="post" action="../ShowContact.jsp">
    <tr>
      <td colspan="3"><div align="center"><input type="submit" name="Submit" value="����������´ Contact"></div></td>
    </tr>
	</form>
  </table>
	
  <p>&nbsp;</p>
</div>
<%}%>
</body>
</html>
