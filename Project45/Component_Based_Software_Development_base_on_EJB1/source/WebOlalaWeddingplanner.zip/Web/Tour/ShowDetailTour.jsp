<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.EntertainJobDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Tour_Contact_ID");
	int Tour_Contact_ID = Integer.parseInt(tempstr);
	tempstr =(String)request.getParameter("Tour_Job_ID");
	int Tour_Job_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Package_Name");
	String Package_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("StartDate");
	String StartDate = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Tour_Name");
	String Tour_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Tour_ID");
	int Tour_ID = Integer.parseInt(tempstr);
//org.openuri.www.TourJobDetailHigh tour_GetJobDetail(int weddingContactID, int jobID)
	org.openuri.www.TourJobDetailHigh detail = ToursoapProxy.tour_GetJobDetail(Wedding_Contact_ID,Tour_Job_ID);
	if (detail != null){
%>
<div align="center">
  <table width="75%" border="1" bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="3"><div align="center">��¡�çҹ�������ͧ�����</div></td>
    </tr>
    <tr>
      <td><div align="center">1.</div></td>
      <td><div align="center">���ʡ�èͧ :</div></td>
      <td width="65%"><div align="center"><%=Tour_Job_ID%></div></td>
    </tr>
    <tr>
      <td><div align="center">2.</div></td>
      <td><div align="center">����ᾤࡨ :</div></td>
      <td><div align="center"><a href = "./ShowDetailPackage.jsp?Tour_Contact_ID=<%=Tour_Contact_ID%>&Tour_Job_ID=<%=Tour_Job_ID%>&Wedding_Contact_ID=<%=Wedding_Contact_ID%>&Package_ID=<%=detail.getPackageID()%>&Tour_ID=<%=Tour_ID%>&Tour_Name=<%=Tour_Name%>&Package_Name=<%=Package_Name%>"><%=Package_Name%></a></div></td>
    </tr>
    <tr>
      <td><div align="center">3.</div></td>
      <td><div align="center">�ѹ�Թ�ҧ :</div></td>
      <td> <div align="center">
				<%String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = detail.getReserveDate().toCharArray();
							for(int j = 0;  j < detail.getReserveDate().length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
		</div></td>
    </tr>
    <tr>
      <td><div align="center">4.</div></td>
      <td><div align="center">�ѹ�׹�ѹ��èͧ:</div></td>
      <td><div align="center">
					<%
							temp = new String();
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = new String();
							minute1 = 0;
							minute = new String();
							temp_date = detail.getDeadline().toCharArray();
							for(int j = 0;  j < detail.getDeadline().length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
	  </div></td>
    </tr>
    <tr>
      <td><div align="center">5.</div></td>
      <td><div align="center">�Ҥ� :</div></td>
      <td><div align="center"><%=detail.getPrice()%>&nbsp;�ҷ</div></td>
    </tr>
    <tr>
      <td><div align="center">6.</div></td>
      <td><div align="center">�ӹǹ :</div></td>
      <td><div align="center"><%=detail.getQuantity()%></div></td>
    </tr>
    <tr>
      <td><div align="center">7.</div></td>
      <td><div align="center">���ͺ���ѷ����� :</div></td>
      <td><div align="center"><%=Tour_Name%>&nbsp;</div></td>
    </tr>
  </table>

  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditTour.jsp">
          <div align="right">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Tour_Contact_ID" value="<%=Tour_Contact_ID%>">
			<input type="hidden" name="Tour_Job_ID" value="<%=Tour_Job_ID%>">
			<input type="hidden" name="Package_Name" value="<%=Package_Name%>">
			<input type="hidden" name="Package_ID" value="<%=detail.getPackageID()%>">
			<input type="hidden" name="ReserveDate" value="<%=detail.getReserveDate()%>">
			<input type="hidden" name="Deadline" value="<%=detail.getDeadline()%>">
			<input type="hidden" name="Price" value="<%=detail.getPrice()%>">
			<input type="hidden" name="Quantity" value="<%=detail.getQuantity()%>">
			<input type="hidden" name="Tour_Name" value ="<%=Tour_Name%>">
			<input type="hidden" name="Tour_ID" value="<%=Tour_ID%>">
			<input type="submit" name="Submit" value="���">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelTourJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Tour_Contact_ID" value="<%=Tour_Contact_ID%>">
			<input type="hidden" name="Tour_Job_ID" value="<%=Tour_Job_ID%>">
			<input type="hidden" name="Tour_ID" value="<%=Tour_ID%>">
          <input type="submit" name="Submit2" value="¡��ԡ">
        </form></td>
    </tr>
  </table>
  <p>&nbsp;</p>
</div>
<%}%>
</body>
</html>
