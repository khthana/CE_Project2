<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.EntertainResultsearch"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import="java.lang.*"%>
	<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Tour</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="F9F9EF">
<%	
		 int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
		String tempstr = (String)request.getParameter("Wedding_Contact_ID");
		int Wedding_Contact_ID = Integer.parseInt(tempstr);

		String tempstr1 = (String)request.getParameter("Tour_Contact_ID");
		int Tour_Contact_ID = Integer.parseInt(tempstr1);
		//out.print(Tour_Contact_ID);
		tempstr = (String)request.getParameter("Tour_ID");
		int Tour_ID = Integer.parseInt(tempstr);
		String Tour_Name=new String();
		if(Tour_ID==0)  Tour_Name="Tour0";
		if(Tour_ID==1)  Tour_Name="Tour1";
		if(Tour_ID==2)  Tour_Name="Tour2";
		if(Tour_ID==3)  Tour_Name="Tour3";
		if(Tour_ID==4)  Tour_Name="Tour4";
		if(Tour_ID==5)  Tour_Name="Tour5";
		if(Tour_ID==6)  Tour_Name="Tour6";
		if(Tour_ID==7)  Tour_Name="Tour7";
		if(Tour_ID==8)  Tour_Name="Tour8";
		if(Tour_ID==9)  Tour_Name="Tour9";
		if(Tour_ID==10)  Tour_Name="Tour10";

//    String Hotel_grade = new String(request.getParameter("Hotel_grade").getBytes("ISO8859_1"),"MS874");
    String act_id = new String(request.getParameter("act_id").getBytes("ISO8859_1"),"MS874");
 //   String place_id = new String(request.getParameter("place_id").getBytes("ISO8859_1"),"MS874");
//    String region = new String(request.getParameter("region").getBytes("ISO8859_1"),"MS874");
//    String Hotel_id = new String(request.getParameter("Hotel_id").getBytes("ISO8859_1"),"MS874");
//    String  type = new String(request.getParameter("type").getBytes("ISO8859_1"),"MS874");
    String country_id = new String(request.getParameter("country_id").getBytes("ISO8859_1"),"MS874");
    String continent_id = new String(request.getParameter("continent_id").getBytes("ISO8859_1"),"MS874");
    String city_id = new String(request.getParameter("city_id").getBytes("ISO8859_1"),"MS874");
	if(request.getParameter("RadioGroup1").equals("country")){
		continent_id="";
		city_id = "";}
	else if(request.getParameter("RadioGroup1").equals("city")){
		continent_id ="";
		country_id = "";}
	else {city_id = "";
			country_id = "";}
    String vehicle_id = new String(request.getParameter("vehicle_id").getBytes("ISO8859_1"),"MS874");
//    String vehicle_grade = new String(request.getParameter("vehicle_grade").getBytes("ISO8859_1"),"MS874");
//	int maxquota = Integer.parseInt((String)request.getParameter("maxquota"));
//	int minrequire = Integer.parseInt((String)request.getParameter("minrequire"));
	//int maxrequire = Integer.parseInt((String)request.getParameter("maxrequire"));
	int minquota = Integer.parseInt((String)request.getParameter("minquota"));
	int mincost = Integer.parseInt((String)request.getParameter("mincost"));
	int maxcost = Integer.parseInt((String)request.getParameter("maxcost"));
	int minstartday = Integer.parseInt((String)request.getParameter("minstartday"));
	int minstartmonth = Integer.parseInt((String)request.getParameter("minstartmonth"));
	int minstartyear = Integer.parseInt((String)request.getParameter("minstartyear"));
//	int maxstartday = Integer.parseInt((String)request.getParameter("maxstartday"));
//	int maxstartmonth = Integer.parseInt((String)request.getParameter("maxstartmonth"));
//	int maxstartyear = Integer.parseInt((String)request.getParameter("maxstartyear"));
//	int minfinishday = Integer.parseInt((String)request.getParameter("minfinishday"));
//	int minfinishmonth = Integer.parseInt((String)request.getParameter("minfinishmonth"));
//	int minfinishyear = Integer.parseInt((String)request.getParameter("minfinishyear"));
	int maxfinishday = Integer.parseInt((String)request.getParameter("maxfinishday"));
	int maxfinishmonth = Integer.parseInt((String)request.getParameter("maxfinishmonth"));
	int maxfinishyear = Integer.parseInt((String)request.getParameter("maxfinishyear"));
	//int currentpage = Integer.parseInt((String)request.getParameter("currentpage"));
	//int resultperpage = Integer.parseInt((String)request.getParameter("resultperpage"));
//	int  = Integer.parseInt((String)request.getParameter(""));

      String Cheap =  (String)request.getParameter("cheap");
      boolean cheap = true;
      if (Cheap.equals("yes"))
        {
            cheap = true;
         }
         else
         {
           cheap = false;
        }
		int tourID;
/*		out.print(Tour_ID+" "+" "+" "+country_id+continent_id+vehicle_id+vehicle_grade+""+Hotel_grade+act_id+""+minquota+maxquota+minrequire+maxrequire+mincost+maxcost+minstartday+minstartmonth+minstartyear+0+0+0+0+0+0+maxfinishday+maxfinishmonth+maxfinishyear+1+200000+cheap);*/
	org.openuri.www.PackageList result = ToursoapProxy.tour_Search(Tour_ID,"","",city_id,country_id,continent_id,vehicle_id,"","","",act_id,"",minquota,0,0,0,mincost,maxcost,minstartday,minstartmonth,minstartyear,0,0,0,0,0,0,maxfinishday,maxfinishmonth,maxfinishyear,0,0,cheap);
//org.openuri.www.PackageList tour_Search(int tourID, java.lang.String placeID, java.lang.String region, java.lang.String cityID, java.lang.String countryID, java.lang.String continentID, java.lang.String vehicleID, java.lang.String vehicleGrade, java.lang.String hotelID, java.lang.String hotelGrade, java.lang.String actID, java.lang.String type, int minQuota, int maxQuota, int minRequire, int maxRequire, int minCost, int maxCost, int minStartDay, int minStartMonth, int minstartYear, int maxStartDay, int maxStartMonth, int maxStartYear, int minFinishDay, int minFinishMonth, int minFinishYear, int maxFinishDay, int maxFinishMonth, int maxFinishYear, int currentPage, int resultPerPage, boolean cheap)
//out.print(result);
		%>

<center>
  <table width="95%" height="143" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF">
      <td colspan="8"><center>
          �š�ä���</center></td>
    </tr>
    <tr>
      <td><div align="center">Package ID</div></td>
      <td><div align="center">ʶҹ������</div></td>
      <td><div align="center">�ѹ�</div></td>
      <td><div align="center">�ѹ��Ѻ</div></td>
      <td><div align="center">�Ҥ�( �ҷ)</div></td>
      <td><div align="center">���ͺ���ѷ</div></td>
      <td><div align="center">����������ѷ</div></td>
      <td><div align="center">�ͧ</div></td>
    </tr>
    <%
   	if (result.getPackageID() != null){
			int[] a=result.getPackageID();
			int[] b=result.getPrice();
	  //out.print(" xxx  "+a.length+"xxx");
	 
                for (int i = 0 ; i <a.length ; i++ )
                {
						if(result.getTourName()[i].equals("Tour1")) tourID=1;
						if(result.getTourName()[i].equals("Tour2")) tourID=2;
						if(result.getTourName()[i].equals("Tour3")) tourID=3;
						if(result.getTourName()[i].equals("Tour4")) tourID=4;
						if(result.getTourName()[i].equals("Tour5")) tourID=5;
						if(result.getTourName()[i].equals("Tour6")) tourID=6;
						if(result.getTourName()[i].equals("Tour7")) tourID=7;
						if(result.getTourName()[i].equals("Tour8")) tourID=8;
						if(result.getTourName()[i].equals("Tour9")) tourID=9;
						if(result.getTourName()[i].equals("Tour10")) tourID=10;
					org.openuri.www.PackageDetail pDetail=ToursoapProxy.tour_GetPackageDetail(a[i],tourID);
					String startDate=pDetail.getStartDate();
					String finishDate=pDetail.getFinishDate();
					 startDate=startDate.replace(' ','/');
					 finishDate=finishDate.replace(' ','/');
					 int row;
					 if(pDetail.getCountryName()==null) row=1;else row=pDetail.getCountryName().length;
				  %>
    <form name="form1" method="post" action="./ReserveTour.jsp">
      <tr rowspan="<%=row%>">
        <td><div align="center"><%=a[i]%></div></td>
        <td>
                <%
		  //out.print("span"=pDetail.getCityName().length)
		  //out.print("num city="+pDetail.getCityName().length);
		 if(pDetail.getCountryName()!=null)
		  for (int j = 0 ; j <pDetail.getCountryName().length ; j++ )
                {
                        %>
				
				<div align="center"><%=pDetail.getCountryName()[j]%>(<%=pDetail.getContinentName()[j]%>)</div>
				
                <%
                }else{
                        %>
				<div align="center">-</div><%}%>
						</td>
        <td><div align="center"><%=startDate%></div></td>
        <td><div align="center"><%=finishDate%></div></td>
        <td><div align="center"><%=b[i]%></div></td>
        <td><div align="center"><%=result.getTourName()[i]%></div></td>
        <td><div align="center"><%=result.getTourAddress()[i]%></div></td>
		<%if(pDetail.getQuantity()>0){%>
        <td align = "center"><div align="center"><input type = "submit" value = "�ͧ" name = "reserve" ></div></td>
		<%}else{%>
        <td align = "center"><div align="center"><input type = "submit" value = "�ͧ" name = "reserve" disabled ></div></td>
		<%}%>
      </tr>
      <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
        <input type = "hidden" name = "Tour_ID" value = "<%=Tour_ID%>">
        <input type = "hidden" name = "Tour_Name" value = "<%=result.getTourName()[i]%>">
        <input type = "hidden" name = "packageID" value = "<%=a[i]%>">
        <input type = "hidden" name = "packagePrice" value = "<%=b[i]%>">
        <input type = "hidden" name = "startDate" value = "<%=startDate%>">
        <input type = "hidden" name = "finishDate" value = "<%=finishDate%>">
    </form>
    <% }}%>
  </table>
</center>
</body>
</html>