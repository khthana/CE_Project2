<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Cancel Job Entertain</title>

</head>
<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Tour_Contact_ID");
    int Tour_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Tour_Job_ID");
    int Tour_Job_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	//boolean tour_Cancel_jobID(int weddingContactID, int contactID, int jobID)
	boolean cancel = ToursoapProxy.tour_Cancel_jobID(Wedding_Contact_ID,Tour_Contact_ID,Tour_Job_ID);
    if (cancel == true)
    {
		//org.openuri.www.TourJobDetailLow[] tour_GetJobByContact(int contactID, int weddingContactID)
		org.openuri.www.TourJobDetailLow[] list = ToursoapProxy.tour_GetJobByContact(Tour_Contact_ID,Wedding_Contact_ID);
		if ((list != null)&&(list.length == 0))
		{
			boolean cancelcontact =  ToursoapProxy.tour_Cancel_Contact(Wedding_Contact_ID,Tour_Contact_ID);
		}
      response.sendRedirect("../ShowContact.jsp");
    }
%>
</body>
</html>