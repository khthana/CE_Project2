<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.EntertainJobDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	Integer tempint = null;
	tempstr = (String)request.getParameter("Tour_Contact_ID");
	int Tour_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Tour_Job_ID");
	int Tour_Job_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Package_ID");
	int Package_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Package_Name");
	String Package_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("ReserveDate");
	String ReserveDate = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Deadline");
	String Deadline = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Tour_Name");
	String Tour_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Tour_ID");
	int Tour_ID = Integer.parseInt(tempstr);
	
	tempstr =(String)request.getParameter("Price");
	double Price = Double.parseDouble(tempstr);
	tempstr = (String)request.getParameter("Quantity");
	int Quantity = Integer.parseInt(tempstr);%>
<div align="center">
<form name="form1" method="post" action="./Edit.jsp">
  <table width="90%" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"> 
      <td colspan="3"><div align="center">��¡�á�èͧ�����</div></td>
    </tr>
    <tr> 
      <td><div align="center">1.</div></td>
      <td><div align="left">���ʡ�èͧ :</div></td>
      <td width="82%"> <div align="left"><%=Tour_Job_ID%></div></td>
    </tr>
    <tr> 
      <td><div align="center">2.</div></td>
      <td><div align="left">����ᾤࡨ����� :</div></td>
      <td> <div align="left"><%=Package_Name%></div></td>
    </tr>
    <tr> 
      <td><div align="center">3.</div></td>
      <td><div align="left">�ѹ�͡�Թ�ҧ :</div></td>
      <td>  <div align="left">
<%							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = ReserveDate.toCharArray();
							for(int j = 0;  j < ReserveDate.length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
	  </div></td>
    </tr>
    <tr> 
      <td><div align="center">4.</div></td>
      <td><div align="left">�ѹ�׹�ѹ��èͧ</div></td>
      <td> <div align="left">
<%
							temp = "";
							int day2 = 0;
							int month2 = 0;
							int year2 = 0;
							count = 0;
							String hour2 = new String();
							int minute1 = 0;
							String minute2 = new String();
							temp_date = Deadline.toCharArray();
							for(int j = 0;  j < Deadline.length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day2 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month2 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year2= temp_year.intValue();
											}
									}
							}
							year2 = year2 +543;
%>					<%=day2%>&nbsp;<%if (month2 == 1) out.print("�.�.");
														if (month2 == 2) out.print("�.�.");
														if (month2 == 3) out.print("��.�.");
														if (month2 == 4) out.print("��.�.");
														if (month2 == 5) out.print("�.�.");
														if (month2 == 6) out.print("��.�.");
														if (month2 == 7) out.print("�.�.");
														if (month2 == 8) out.print("�.�.");
														if (month2 == 9) out.print("�.�.");
														if (month2 == 10) out.print("�.�.");
														if (month2 == 11) out.print("�.�.");
														if (month2 == 12) out.print("�.�.");
											%>&nbsp;<%=year2%>
	</div></td>
    </tr>
    <tr> 
      <td><div align="center">5.</div></td>
      <td><div align="left">�Ҥ� :</div></td>
      <td><div align="left"><%=Price%>&nbsp;�ҷ</div></td>
    </tr>
    <tr> 
      <td><div align="center">6.</div></td>
      <td><div align="left">�ӹǹ�� :</div></td>
      <td> <div align="left"><input type="text" name="Quantity"></div></td>
    </tr>
    <tr> 
      <td><div align="center">7.</div></td>
      <td><div align="left">���ͺ���ѷ�����</div></td>
      <td><div align="left"><%=Tour_Name%> </div></td>
    </tr>
    <tr> 
      <td width="5%"><div align="center"></div></td>
      <td width="30%"><div align="center"></div></td>
      <td><div align="center"></div></td>
    </tr>
  </table>
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Tour_Contact_ID" value="<%=Tour_Contact_ID%>">
			<input type="hidden" name="Tour_Job_ID" value="<%=Tour_Job_ID%>">
			<input type="hidden" name="Package_Name" value="<%=Package_Name%>">
			<input type="hidden" name="Package_ID" value="<%=Package_ID%>">
			<input type="hidden" name="ReserveDate" value="<%=ReserveDate%>">
			<input type="hidden" name="Deadline" value="<%=Deadline%>">
			<input type="hidden" name="Price" value="<%=Price%>">
			<input type="hidden" name="Tour_Name" value ="<%=Tour_Name%>">
			<input type="hidden" name="Tour_ID" value="<%=Tour_ID%>">
		  <center><input type = "Submit" value = "Edit"></center>
</form>
  <p>&nbsp;</p>
</div>
</body>
</html>
