<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Result Search Entertain</title>

</head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Tour_Contact_ID");
    int Tour_Contact_ID = 0;
    if (tempstr != null)
    {
      Tour_Contact_ID = Integer.parseInt(tempstr);
	  //boolean tour_Cancel_Contact(int weddingContactID, int contactID)
      boolean cancel = ToursoapProxy.tour_Cancel_Contact(Wedding_Contact_ID,Tour_Contact_ID);
      response.sendRedirect("../ShowContact.jsp");
    }
    else response.sendRedirect("../ShowContact.jsp");
	%>

</body>
</html>
