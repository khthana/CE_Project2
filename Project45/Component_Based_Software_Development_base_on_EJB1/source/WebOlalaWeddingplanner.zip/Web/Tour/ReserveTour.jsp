<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
	<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Reserve Tour</title>
</head>

<body bgcolor="F9F9EF">
<%

    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
//out.print(Customer_ID+"hhhhhhh");
	String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("Tour_ID");
    int tourID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("packagePrice");
    int price = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("packageID");
    int packageID = Integer.parseInt(Temp_Str);

    Temp_Str = (String)request.getParameter("Tour_Name");
    String tourName = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

	Temp_Str = (String)request.getParameter("startDate");
    String startDate = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
    Temp_Str = (String)request.getParameter("finishDate");
    String finishDate = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");


%>
<form name="form1" method="post" action="BookTour.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC" align="center">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF">
        <td colspan="3"><div align="center">��������´��èͧ����ѷ�����</div></td>
      </tr>
      <tr>
        <td width="5%"><div align="center">1.</div></td>
        <td width="47%"><div align="left">PackageID</div></td>
        <td width="48%"> <div align="left">
			<div align="center"><%=packageID%></div>
          </div></td>
      </tr>
      <tr>
        <td><div align="center">2.</div></td>
        <td><div align="left">���ͺ���ѷ�����</div></td>
        <td><div align="center"><%=tourName%></td></div>
      </tr>
      <tr>
        <td><div align="center">3.</div></td>
        <td><div align="left">�ѹ�͡�Թ�ҧ</div></td>
        <td><div align="center"><%=startDate%></td></div>
      </tr>
      <tr>
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ��Ѻ</div></td>
        <td><div align="center"><%=finishDate%></td></div>
      </tr>
      <tr>
        <td><div align="center">5.</div></td>
        <td><div align="left">�Ҥ�</div></td>
        <td><div align="center"><%=price%></td></div>
      </tr>
      <tr>
        <td><div align="center">6.</div></td>
        <td><div align="left">�ӹǹ�����</div></td></div>
        <td align="center"><input type="text" name="quantity" ></td>
      </tr>
    </table>
<BR><BR><BR>
		<div align= "center"><input type = "submit" value = "�ͧ" name = "reserve"></div>
      <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
        <input type = "hidden" name = "Tour_ID" value = "<%=tourID%>">
        <input type = "hidden" name = "Tour_Name" value = "<%=tourName%>">
        <input type = "hidden" name = "packageID" value = "<%=packageID%>">

    </form>

  <p>&nbsp;</p>
</center>
</body>
</html>
