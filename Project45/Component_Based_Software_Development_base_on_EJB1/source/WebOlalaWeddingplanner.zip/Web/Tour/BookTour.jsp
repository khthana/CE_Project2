<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
	<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body  bgcolor="F9F9EF">
<%
                String Temp_Str = null;
                int custID = Integer.parseInt((String)session.getAttribute("Customer_ID"));


                Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
                int weddingContactID = Integer.parseInt(Temp_Str);

                Temp_Str = (String)request.getParameter("Tour_ID");
                 int tourID = Integer.parseInt(Temp_Str);

			Temp_Str = (String)request.getParameter("packageID");
			int packageID = Integer.parseInt(Temp_Str);

			Temp_Str = (String)request.getParameter("quantity");
			int quantity= Integer.parseInt(Temp_Str);
			int tourContactID=ToursoapProxy.tour_HasContact(weddingContactID);
               if (tourContactID == 0)
                {
                  tourContactID =ToursoapProxy.tour_CreateContact(weddingContactID,custID,tourID);
				}
				org.openuri.www.ReserveTourRS rs=ToursoapProxy.tour_Reserve(custID,weddingContactID,tourContactID,tourID,packageID,quantity);
			//	out.print(weddingContactID);
  if (rs == null)
  {
	 %>
	  <center>�������ö�ͧ��</center>
	<center><a href = "../ShowJob.jsp#tour">��Ѻ�˹���ʴ���������´ contact</a></center>
	  <%
	//		response.sendRedirect("./ReserveNull.jsp");
  }  else
                    {	
								//		session.setAttribute("Customer_ID" , Integer.toString(5));

						response.sendRedirect("../ShowJob.jsp#tour");
		}
 %>                  
</body>
</html>
