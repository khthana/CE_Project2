<%@ page contentType = "text/html;charset=WINDOWS-874" import="weblogic.jws.proxies.*" %>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>

<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body  bgcolor="F9F9EF">

            <form name="form1" method="post" action="ToRegister.jsp" target = "mainFrame">
              <table align="center" border=0 cellpadding="0" cellspacing="0" width="467">
                <tr>
                  <td align= "left"><center><p><font color="#000099" size="4"> ��سҡ�͡������</font></p>
                    </center>
                    <table width="457" >
                      <tr>
                        <td width="130">���ͼ����</td>
                        <td width="315" ><input type="text" name="username"></td>
                      </tr>
                      <tr>
                        <td>���ʼ�ҹ</td>
                        <td><input type="password" name="password">(���ҧ���� 6 ����ѡ��)</td>
                      </tr>
                      <tr>
                        <td>�׹�ѹ���ʼ�ҹ</td>
                        <td><input type="password" name="confirmpwd">(���ҧ���� 6 ����ѡ��)</td>
                      </tr>
                    </table>
                    <p></p></td>
                </tr>
                <tr>
                    <td width="467"><div align="center"><font color="#000099" size="3">����Ѻ��Һ���</font><BR>
                      </div>
                      <table width="455" border="0">
                        <tr>
                          <td width="123">����</td>
                          <td width="322"> <input width="300" type="text" name="M_name">
                          </td>
                        </tr>
                        <tr>
                          <td>���ʡ��</td>
                          <td><input width="300" name="M_surname" type="text"></td>
                        </tr>
                        <tr>
                          <td>�������</td>
                          <td> <input width="300" type="text" name="M_address">
                          </td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <input width="300" type="text" name="M_address1">
                          </td>
                        </tr>
                        <tr>
                          <td>�ѹ�Դ</td>
                          <td><select name="M_date">
                          <%int i;
                          for (i = 1; i <= 31; i++)
                          {
                          %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                          <%}%>
                            </select>
                            /
                            <select name="M_month">
                            <OPTION value=1 selected>���Ҥ�
                            <OPTION value=2>����Ҿѹ��
                            <OPTION value=3>�չҤ�
                            <OPTION value=4>����¹
                            <OPTION value=5>����Ҥ�
                            <OPTION value=6>�Զع�¹
                            <OPTION value=7>�á�Ҥ�
                            <OPTION value=8>�ԧ�Ҥ�
                            <OPTION value=9>�ѹ��¹
                            <OPTION value=10>���Ҥ�
                            <OPTION value=11>��Ȩԡ�¹
                            <OPTION value=12>�ѹ�Ҥ�
                            </select>
                            /
                            <select name="M_year">
                            <%
                            for (i = 1920;i < 2006; i++)
                            {
                            %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                            <%}%>
                            </select> </td>
                        </tr>
                        <tr>
                          <td height="33">�������Ѿ��</td>
                          <td><input type="text" name="M_phone"> </td>
                        </tr>
                        <tr>
                          <td>�������ʹ���</td>
                          <td><input type="text" name="M_email"></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td>&nbsp; </td>
                        </tr>
                      </table>
                      <div align="center"><font color="#000099" size="3">����Ѻ������</font></div></td>
                </tr>
                <tr>
                  <td><table width="460" border="0">
                        <tr>
                          <td width="122">����</td>
                          <td width="328"> <input width="300" type="text" name="F_name">
                          </td>
                        </tr>
                        <tr>
                          <td>���ʡ��</td>
                          <td><input width="300" type="text" name="F_surname"></td>
                        </tr>
                        <tr>
                          <td>�������</td>
                          <td> <input width="300" type="text" name="F_address">
                          </td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <input width="300" type="text" name="F_address1">
                          </td>
                        </tr>
                        <tr>
                          <td>�ѹ�Դ</td>
                          <td><select name="F_date">
                          <%
                          for (i = 1;i <= 31; i++)
                          {
                          %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                          <%}%>
                            </select>
                            /
                            <select name="F_month">
                            <OPTION value=1 selected>���Ҥ�
                            <OPTION value=2>����Ҿѹ��
                            <OPTION value=3>�չҤ�
                            <OPTION value=4>����¹
                            <OPTION value=5>����Ҥ�
                            <OPTION value=6>�Զع�¹
                            <OPTION value=7>�á�Ҥ�
                            <OPTION value=8>�ԧ�Ҥ�
                            <OPTION value=9>�ѹ��¹
                            <OPTION value=10>���Ҥ�
                            <OPTION value=11>��Ȩԡ�¹
                            <OPTION value=12>�ѹ�Ҥ�
                            </select>
                            /
                            <select name="F_year">
                            <%
                            for (i = 1920;i < 2006; i++)
                            {
                            %>
                            <option value="<%out.println(i);%>"><%out.println(i);%></option>
                            <%}%>
                            </select> </td>
                        </tr>
                        <tr>
                          <td>�������Ѿ��</td>
                          <td><input type="text" name="F_phone"> </td>
                        </tr>
                        <tr>
                          <td>�������ʹ���</td>
                          <td><input type="text" name="F_email"></td>
                        </tr>
                      </table></td>
                </tr>
                <tr>
                  <td align="center"><br>
                      <input type="submit" name="Submit" value="ŧ����¹">
                    </td>
                </tr>
              </table>
			 </form>

</body>
</html>
