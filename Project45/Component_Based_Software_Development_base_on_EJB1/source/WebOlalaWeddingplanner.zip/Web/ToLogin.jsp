<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.WeddingContactDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>

<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();
	int Customer_ID = 0;%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body  bgcolor="F9F9EF">
		<%
		String username = (String)request.getParameter("username");
		String myuser = new String(username.getBytes("ISO8859_1"),"MS874");
		String password = (String)request.getParameter("password");
		String mypwd = new String(password.getBytes("ISO8859_1"),"MS874");
		Customer_ID = soapProxy.login(myuser,mypwd);%>
<%			if (Customer_ID == 0)
			{
				out.println("���ͼ�����������ʼ�ҹ���١��ͧ");%>
				<form name="form1" method="post" action="ToLogin.jsp">
        <table width="338" border="0">
          <tr>
            <td width="122">���ͼ���� :</td>
            <td width="206"><input type="text" name="username"></td>
          </tr>
          <tr>
            <td>���ʼ�ҹ :</td>
            <td><input type="password" name="password"></td>
          </tr>
          <tr>
            <td height="16" colspan="2"> <div align="center">
                <input type="submit" name="Submit" value="�������к�">
              </div></td>
          </tr>
        </table>
      </form>
<%	  response.sendRedirect("IndexLogin.htm");
				}else
{
				session.setAttribute("Customer_ID" , Integer.toString(Customer_ID));
				int xx=0;
				String con="None";
				session.setAttribute("weddingContactID" , Integer.toString(xx));
				session.setAttribute("weddingContactName" ,con);
				session.setAttribute("Username",myuser);
				session.setAttribute("Password",mypwd);
				response.sendRedirect("Index1.htm");
}			%>

<p>&nbsp;</p><table width="602" height="282" border="0">
  <tr>
    <td width="123">&nbsp;</td>
    <td width="469">
<%		if ((username == null)||(username.equals(""))||(password.equals("")))
		{
			out.println("��س������ͼ����");
	    }%>

	  </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>

</body></noframes>
</html>
