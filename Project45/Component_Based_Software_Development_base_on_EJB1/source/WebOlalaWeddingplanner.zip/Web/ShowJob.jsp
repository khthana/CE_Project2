<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.WeddingContactDetail"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import="java.util.*"%>
<%@ page import="java.lang.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner</title></head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
//////////////////////
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
  	if(tempstr!=null){
    int weddingContactIDNew = Integer.parseInt(tempstr);

tempstr=(String)session.getAttribute("weddingContactID");
String name;

	int weddingContactIDOld = Integer.parseInt(tempstr);
/*String weddingContactIDOld =(String)session.getAttribute("weddingContactID");
	out.print("New="+weddingContactIDNew +"Old="+weddingContactIDOld);*/
	if(weddingContactIDOld==0)	
		{
			session.setAttribute("weddingContactID" , Integer.toString(weddingContactIDNew));
		    name = (String)request.getParameter("Wedding_Contact_Name");
			String weddingName = new String(name.getBytes("ISO8859_1"),"MS874");
			session.setAttribute("weddingContactName" ,weddingName);
		}
		else if(weddingContactIDOld!=weddingContactIDNew) 
		{
			session.setAttribute("weddingContactID" , Integer.toString(weddingContactIDNew));
		    name = (String)request.getParameter("Wedding_Contact_Name");
			String weddingName = new String(name.getBytes("ISO8859_1"),"MS874");
			session.setAttribute("weddingContactName" ,weddingName);
		}
	}//wedding!=null
	int Wedding_contact_ID =Integer.parseInt((String)session.getAttribute("weddingContactID"));
	if(Wedding_contact_ID==0) response.sendRedirect("ShowContact.jsp");
		org.openuri.www.EntertainListJob[] list = soapProxy.entertainment_Job_List(Customer_id,Wedding_contact_ID);
//////////////////////////////////////////////////////////////find deadline//////////////////////////////////////
String deadline="";
boolean lockButton=false;
org.openuri.www.WeddingContactDetail[] detail = soapProxy.find_Wedding_Contact(Customer_id);
for(int j=0;j<detail.length;j++)
	if(detail[j].getWeddingContactID()==Wedding_contact_ID) deadline=detail[j].getDeadline();
if(deadline.equals("-1")) lockButton=true;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////Hotel/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////->

//	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
//    int  Wedding_contact_ID = Integer.parseInt(tempstr);
//	org.openuri.www.Hotelcontact hotel_Contact_List(int customerId, int weddingContactId);
//	org.openuri.www.EntertainListJob[] list = soapProxy.entertainment_Job_List(Customer_id,Wedding_contact_ID);
	
	org.openuri.www.Hotelcontact hotelcontact = Hotel.hotel_Contact_List(Customer_id,Wedding_contact_ID);
		int[] Room_Job_ID = null;
		int[] Seminar_Job_ID = null;
		int[] Cake_Job_ID = null;
		int[] Flower_Job_ID = null;
		int[] Food_Job_ID = null;
		org.openuri.www.SeminarRoomReservationList seminarlist;
		org.openuri.www.RoomReservationList roomlist;
		org.openuri.www.FoodReservationList foodlist;
		org.openuri.www.CakeReservationList cakelist;
		org.openuri.www.FlowerReservationList flowerlist;
	if (hotelcontact != null){
		//org.openuri.www.ShowAllJobid hotelShowJobID(int customerId, int hotelContactId, int hotelNumber)
		org.openuri.www.ShowAllJobid alljob = Hotel.hotelShowJobID(Customer_id,hotelcontact.getHotelcontact(),hotelcontact.getHotelId());
		if (alljob != null){
			Room_Job_ID = alljob.getRoomJobId();
			Seminar_Job_ID = alljob.getSeminarRoomJobId();
			Cake_Job_ID = alljob.getCakeJobId();
			Flower_Job_ID = alljob.getFlowerJobId();
			Food_Job_ID = alljob.getFoodJobId();
		}}
%>

<!--/////////////////////////////////////////////////////////////////////////////////////////////////////////////////Hotel/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////->
<!----------------------------------------------------------------------------Job Seminar---------------------------------------------------------------------------------------->
<a name="seminar"></a>
  <table width = "85%" border="1" bordercolor="#CCCCCC" align="center">
    <tr  bgcolor="#FFCCFF">
      <td colspan="8"><div align="center">��¡�çҹ�������ͧ��ͧ������</div></td>
    </tr>
    <tr>
      <td align="center">Job ID</td>
      <td align="center">������ͧ������</td>
      <td align="center">�����õ���</td>
      <td align="center">����ʶҹ���</td>
      <td align="center">�ӹǹ�������ͧ</td>
      <td align="center">�Ҥ�</td>
	  <td align="center">�����ç���</td>
      <td align="center">&nbsp;</td>
    </tr>
<%if( (hotelcontact != null)&&(Seminar_Job_ID!=null)){
			if (Seminar_Job_ID[0]!=0){
				for (int i = 0;  i< Seminar_Job_ID.length; i++){
				seminarlist = Hotel.hotelShowReserveSeminar(Seminar_Job_ID[i],hotelcontact.getHotelId());
			//org.openuri.www.SeminarRoomReservationList hotelShowReserveSeminar(int seminarRoomJobId, int hotelNumber)
%>
	<form name="form11" method="post" action="Hotel/CancelSeminarJob.jsp">
    <tr>
      <td align="center"><a href = "Hotel/ShowDetailSeminar.jsp?Hotel_Contact_ID=<%=hotelcontact.getHotelcontact()%>&Seminar_Job_ID=<%=seminarlist.getSeminarRoomJobId()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Hotel_Name=<%=hotelcontact.getHotelName()%>&Hotel_ID=<%=hotelcontact.getHotelId()%>"><%=seminarlist.getSeminarRoomJobId()%></a></td>
      <td align="center"><%=seminarlist.getSeminarRoomName()%>&nbsp;</td>
      <td align="center"><%=seminarlist.getDecStyle()%>&nbsp;</td>
      <td align="center"><%=seminarlist.getPlaceStyle()%>&nbsp;</td>
      <td align="center"><%=seminarlist.getMenPerRoom()%>&nbsp;</td>
      <td align="center"><%=seminarlist.getJobTotalPrice()%>&nbsp;</td>
	  <td align="center"><%=hotelcontact.getHotelName()%></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
	<input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
	<input type = "hidden" name = "Seminar_Job_ID" value = "<%=seminarlist.getSeminarRoomJobId()%>">
	<input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
	</form>
<%}}}%>
  </table>
<!---------------------------------------------------------------------------Job Seminar---------------------------------------------------------------------------------------->

  <!--------------------------------------------------------------------------Search Seminar------------------------------------------------------------------------------------>
      <form name="form12" method="post" action="Hotel/SearchHotelSeminar.jsp">
          <div align="center">
		  <%if (hotelcontact != null){
		  %>
		  <input type= "hidden" name = "Hotel_Name" value = "<%=hotelcontact.getHotelName()%>">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
		  <input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
		  <%}
		  else {%>
		  <input type= "hidden" name = "Hotel_Name" value = "null">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "0">
		  <input type = "hidden" name = "Hotel_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="������ͧ������" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>

  <!--------------------------------------------------------Search Seminar------------------------------------------------------------------------------------------>


<!------------------------------------------------------------------------------Job Room------------------------------------------------------------------------------------------>
<BR>
<a name="room"></a>
    <table border="1" bordercolor="#CCCCCC" align="center" width = "85%">
    <tr  bgcolor="#FFCCFF">
      <td colspan="8"><div align="center">��¡�çҹ�������ͧ��ͧ</div></td>
    </tr>
    <tr>
      <td align="center">Job ID</td>
      <td align="center">������</td>
      <td align="center">��Ҵ</td>
      <td align="center">�ҤҸ�����</td>
      <td align="center">�Ҥ���§�����</td>
      <td align="center">������(��)</td>
	  <td align="center">�����ç���</td>
      <td align="center">&nbsp;</td>
    </tr>
<%if( (hotelcontact != null)&&(Room_Job_ID!=null)){
			if (Room_Job_ID[0]!=0){
				for (int i = 0;  i< Room_Job_ID.length; i++){
				//if(Room_Job_ID[i]!=0)
				roomlist = Hotel.hotelShowReserveRoom(Room_Job_ID[i],hotelcontact.getHotelId());
				//org.openuri.www.RoomReservationList hotelShowReserveRoom(int roomJobId, int hotelNumber)
%>
	<form name="form14" method="post" action="Hotel/CancelRoomJob.jsp">
    <tr>
      <td align="center" ><a href = "Hotel/ShowDetailRoom.jsp?Hotel_Contact_ID=<%=hotelcontact.getHotelcontact()%>&Room_Job_ID=<%=roomlist.getRoomJobId()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Hotel_Name=<%=hotelcontact.getHotelName()%>&Hotel_ID=<%=hotelcontact.getHotelId()%>"><%=roomlist.getRoomJobId()%></a>&nbsp;</td>
      <td align="center"><%=roomlist.getRoomType()%>&nbsp;</td>
      <td align="center" ><%=roomlist.getRoomSize()%>&nbsp;</td>
      <td align="center"><%=roomlist.getJobTotalPrice()%>&nbsp;</td>
      <td align="center"><%=roomlist.getExtrabed()%>&nbsp;</td>
      <td align="center"><%=roomlist.getMaximumMenPerRoom()%>&nbsp;</td>
	  <td align="center"><%=hotelcontact.getHotelName()%></td>
     <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
	<input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
	<input type = "hidden" name = "Room_Job_ID" value = "<%=roomlist.getRoomJobId()%>">
	<input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
	</form>  
	<%}}}%>
	</table>
<!------------------------------------------------------------------------------Job Room------------------------------------------------------------------------------------------>

<!----------------------------------------------------------------------------Search Room--------------------------------------------------------------------------------------->
	  <form name="form15" method="post" action="Hotel/SearchHotelRoom.jsp">
          <div align="center">
		  <%if (hotelcontact != null){
		  %>
		  <input type= "hidden" name = "Hotel_Name" value = "<%=hotelcontact.getHotelName()%>">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
		  <input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
		  <%}
		  else {%>
		  <input type= "hidden" name = "Hotel_Name" value = "null">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "0">
		  <input type = "hidden" name = "Hotel_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="������ͧ" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
<!----------------------------------------------------------------------------Search Room--------------------------------------------------------------------------------------->

<!---------------------------------------------------------------------------------Job Food---------------------------------------------------------------------------------------->
<BR>
<a name = "food"></a>
    <table border="1" bordercolor="#CCCCCC" align="center" width = "85%">
    <tr  bgcolor="#FFCCFF">
      <td colspan="6"><div align="center">��¡�çҹ�������ͧ�����</div></td>
    </tr>
    <tr>
      <td align="center">Job ID</td>
      <td align="center">���������</td>
      <td align="center">�����������</td>
      <td align="center">�Ҥ�</td>
	  <td align="center">�����ç���</td>
      <td align="center">&nbsp;</td>
    </tr>
<%if( (hotelcontact != null)&&(Food_Job_ID!=null)){
			if (Food_Job_ID[0]!=0){
				for (int i = 0;  i< Food_Job_ID.length; i++){
				//org.openuri.www.FoodReservationList hotelShowReserveFood(int foodJobId, int hotelNumber)
				foodlist = Hotel.hotelShowReserveFood(Food_Job_ID[i],hotelcontact.getHotelId());
%>
	<form name="form17" method="post" action="Hotel/CancelFoodJob.jsp">
    <tr>
      <td align="center"><a href = "Hotel/ShowDetailFood.jsp?Hotel_Contact_ID=<%=hotelcontact.getHotelcontact()%>&Food_Job_ID=<%=foodlist.getFoodJobId()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Hotel_Name=<%=hotelcontact.getHotelName()%>&Hotel_ID=<%=hotelcontact.getHotelId()%>"><%=foodlist.getFoodJobId()%></a></td>
      <td align="center"><%=foodlist.getFoodStyle()%>&nbsp;</td>
      <td  align="center"><%=foodlist.getServeStyle()%>&nbsp;</td>
      <td align="center"><%=foodlist.getJobTotalPrice()%>&nbsp;</td>
	  <td align="center"><%=hotelcontact.getHotelName()%></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
	<input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
	<input type = "hidden" name = "Food_Job_ID" value = "<%=foodlist.getFoodJobId()%>">
	<input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
	</form>
	<%}}}%>
    </table>
<!------------------------------------------------------------------------------Job Food---------------------------------------------------------------------------------------->

<!-----------------------------------------------------------------------------Search Food--------------------------------------------------------------------------------------->
        <form name="form18" method="post" action="Hotel/SearchHotelFood.jsp">
          <div align="center">
		  <%if (hotelcontact != null){
		  %>
		  <input type= "hidden" name = "Hotel_Name" value = "<%=hotelcontact.getHotelName()%>">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
		  <input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
		  <%}
		  else {%>
		  <input type= "hidden" name = "Hotel_Name" value = "null">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "0">
		  <input type = "hidden" name = "Hotel_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="���������" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
<!-----------------------------------------------------------------------------Search Food--------------------------------------------------------------------------------------->

<!---------------------------------------------------------------------------------Job Cake---------------------------------------------------------------------------------------->
<BR>
<a name = "cake"></a>
  <table border="1" bordercolor="#CCCCCC" align="center" width = "85%">
    <tr  bgcolor="#FFCCFF">
      <td colspan="9"><div align="center">��¡�çҹ�������ͧ��</div></td>
    </tr>
    <tr>
      <td align="center">Job ID</td>
      <td align="center">������</td>
      <td align="center">�����õ���</td>
      <td align="center">��Ҵ</td>
      <td align="center">�ӹǹ���</td>
      <td align="center">��</td>
      <td align="center">�Ҥ�</td>
	  <td align="center">�����ç���</td>
      <td align="center">&nbsp;</td>
    </tr>
<%if( (hotelcontact != null)&&(Cake_Job_ID!=null)){
			if (Cake_Job_ID[0]!=0){
				for (int i = 0;  i<Cake_Job_ID.length; i++){
				//org.openuri.www.CakeReservationList hotelShowReserveCake(int cakeJobId, int hotelNumber)
				cakelist = Hotel.hotelShowReserveCake(Cake_Job_ID[i],hotelcontact.getHotelId());
%>
	<form name="form20" method="post" action="Hotel/CancelCakeJob.jsp">
    <tr>
      <td align="center"><a href = "Hotel/ShowDetailCake.jsp?Hotel_Contact_ID=<%=hotelcontact.getHotelcontact()%>&Cake_Job_ID=<%=cakelist.getCakeJobId()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Hotel_Name=<%=hotelcontact.getHotelName()%>&Hotel_ID=<%=hotelcontact.getHotelId()%>"><%=cakelist.getCakeJobId()%></a>&nbsp;</td>
      <td  align="center"><%=cakelist.getCakeName()%>&nbsp;</td>
      <td align="center"><%=cakelist.getCakeStyle()%>&nbsp;</td>
      <td align="center" ><%=cakelist.getCakeSize()%>&nbsp;</td>
      <td align="center"><%=cakelist.getCakeLayer()%>&nbsp;</td>
      <td align="center"><%=cakelist.getCakeFlavour()%>&nbsp;</td>
      <td align="center"><%=cakelist.getJobTotalPrice()%>&nbsp;</td>
	  <td align="center"><%=hotelcontact.getHotelName()%></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
	<input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
	<input type = "hidden" name = "Cake_Job_ID" value = "<%=cakelist.getCakeJobId()%>">
	<input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
	</form>
	<%}}}%>
<!---------------------------------------------------------------------------------Job Cake---------------------------------------------------------------------------------------->

<!-----------------------------------------------------------------------------Search Cake--------------------------------------------------------------------------------------->
  </table>
       <form name="form21" method="post" action="Hotel/SearchHotelCake.jsp">
          <div align="center">
		  <%if (hotelcontact != null){
		  %>
		  <input type= "hidden" name = "Hotel_Name" value = "<%=hotelcontact.getHotelName()%>">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
		  <input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
		  <%}
		  else {%>
		  <input type= "hidden" name = "Hotel_Name" value = "null">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "0">
		  <input type = "hidden" name = "Hotel_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="������" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
		  <p>&nbsp;</p>
<!-----------------------------------------------------------------------------Search Cake--------------------------------------------------------------------------------------->

<!-------------------------------------------------------------------------------Job Flower---------------------------------------------------------------------------------------->
<BR>
<a name = "flower"></a>
  <table border="1" bordercolor="#CCCCCC" align="center" width = "85%">
    <tr  bgcolor="#FFCCFF">
      <td colspan="5"><div align="center">��¡�çҹ�������͡���</div></td>
    </tr>
    <tr>
      <td align="center">Job ID</td>
      <td align="center">����ᾤࡨ�͡���</td>
      <td align="center">�Ҥ�</td>
	  <td align="center">�����ç���</td>
      <td align="center">&nbsp;</td>
    </tr>
<%if( (hotelcontact != null)&&(Flower_Job_ID!=null)){
			if (Flower_Job_ID[0]!=0){
				for (int i = 0;  i<Flower_Job_ID.length; i++){
				//org.openuri.www.FlowerReservationList hotelShowReserveFlower(int flowerJobId, int hotelNumber)
				flowerlist = Hotel.hotelShowReserveFlower(Flower_Job_ID[i],hotelcontact.getHotelId());
%>
	<form name="form23" method="post" action="Hotel/CancelFlowerJob.jsp">
    <tr>
      <td align="center"><a href = "Hotel/ShowDetailFlower.jsp?Hotel_Contact_ID=<%=hotelcontact.getHotelcontact()%>&Flower_Job_ID=<%=flowerlist.getFlowerJobId()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Hotel_Name=<%=hotelcontact.getHotelName()%>&Hotel_ID=<%=hotelcontact.getHotelId()%>"><%=flowerlist.getFlowerJobId()%></a>&nbsp;</td>
      <td align="center"><%=flowerlist.getFlowerPackageName()%>&nbsp;</td>
      <td align="center"><%=flowerlist.getJobTotalPrice()%>&nbsp;</td>
	  <td align="center"><%=hotelcontact.getHotelName()%></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
	<input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
	<input type = "hidden" name = "Flower_Job_ID" value = "<%=flowerlist.getFlowerJobId()%>">
	<input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
	</form>
	<%}}}%>
  </table>
<!-------------------------------------------------------------------------------Job Flower---------------------------------------------------------------------------------------->

<!---------------------------------------------------------------------------Search Flower--------------------------------------------------------------------------------------->
      <form name="form24" method="post" action="Hotel/SearchHotelFlower.jsp">
          <div align="center">
		  <%if (hotelcontact != null){
		  %>
		  <input type= "hidden" name = "Hotel_Name" value = "<%=hotelcontact.getHotelName()%>">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "<%=hotelcontact.getHotelcontact()%>">
		  <input type = "hidden" name = "Hotel_ID" value = "<%=hotelcontact.getHotelId()%>">
		  <%}
		  else {%>
		  <input type= "hidden" name = "Hotel_Name" value = "null">
		  <input type = "hidden" name = "Hotel_Contact_ID" value = "0">
		  <input type = "hidden" name = "Hotel_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="���Ҵ͡���" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
<!---------------------------------------------------------------------------Search Flower--------------------------------------------------------------------------------------->

<!-----------------------------------------------------------------------Cancel Contact Flower------------------------------------------------------------------------------->
<%if (hotelcontact != null){
%>
      <form name="form25" method="post" action="Hotel/CancelHotelContact.jsp">
          <div align="center">
			<input type = "hidden" name = "Hotel_Contact_ID" value ="<%=hotelcontact.getHotelcontact()%>">
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="¡��ԡ��¡�âͧ�ç���������" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
	<%}%>
<!-----------------------------------------------------------------------Cancel Contact Flower------------------------------------------------------------------------------->



<!-----------------------------------------------------�͹����෹�����----------------------------------------------->
<a name= "entertainment"></a>
  <table width="85%" border="1" bordercolor="#CCCCCC" align = "center">
    <tr  bgcolor="#FFCCFF">
      <td colspan="7"><div align="center">��¡�çҹ�������ͧ����ѷ�͹����෹�����</div></td>
    </tr>

    <tr>
      <td width="8%"><div align="center">&nbsp;</div></td>
      <td width="16%"><div align="center">���ʡ���ʴ�</div></td>
      <td width="22%"><div align="center">�ѡɳТͧ����ʴ�</div></td>
      <td width="25%"><div align="center">������������ʴ�</div></td>
      <td width="16%"><div align="center">���ͺ���ѷ�͹����෹�����</div></td>
      <td width="21%"><div align="center">&nbsp;</div></td>
    </tr>

    <%if ((list != null)&&(list.length!=0)){
                for (int i = 0 ; i < list.length ; i ++ )
                {
                        %>
        <form name="form2" method="post" action="Entertainment/CancelEntertainJob.jsp">
    <tr>
      <td width="5%"><div align="center">
          <%out.print(i+1);%>
        </div></td>
  <!-----------------------------------------------------�ʴ���¡���͹����෹�����----------------------------------------------->

      <td width="16%"><div align="center"><a href = "Entertainment/ShowDetailEntertain.jsp?Entertain_Contact_ID=<%=list[i].getContactID()%>&Entertain_Job_ID=<%=list[i].getJobID()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Entertain_Name=<%=list[i].getEntertainmentName()%>&Entertain_Address=<%=list[i].getEntertainmentAddress()%>&Band_ID=<%=list[i].getBandID()%>&Bandtype_ID=<%=list[i].getBandTypeID()%>"><%=list[i].getJobID()%></a></div></td>
      <td width="22%"><div align="center"><%=list[i].getFunctionType()%></div></td>
      <td width="22%"><div align="center">
          <%
                                                        String temp = new String();
                                                        int  day1 = 0;
                                                        int month1 = 0;
                                                        int year1 = 0;
                                                        int count = 0;
                                                        String hour1 = new String();
                                                        int minute1 = 0;
                                                        String minute = new String();
                                                        char[] temp_date = list[i].getStartDateTime().toCharArray();
                                                        for(int j = 0;  j < list[i].getStartDateTime().length(); j++)
                                                        {
                                                                        if(temp_date[j] == ' ' || temp_date[j] == ':')
                                                                        {
                                                                                        count++;
                                                                                        if(count == 1)
                                                                                        {
                                                                                                        Integer temp_day = new Integer(temp);
                                                                                                        day1 = temp_day.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 2)
                                                                                        {
                                                                                                        Integer temp_month = new Integer(temp);
                                                                                                        month1 = temp_month.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 3)
                                                                                        {
                                                                                                        Integer temp_year = new Integer(temp);
                                                                                                        year1 = temp_year.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 4)
                                                                                        {
                                                                                                        hour1 = temp;
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 5)
                                                                                        {
                                                                                                Integer temp_minute = new Integer(temp);
                                                                                                minute1 = temp_minute.intValue();
                                                                                                if(minute1 < 10)
                                                                                                {
                                                                                                                minute = "0" + temp_minute.toString(minute1);
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                                minute = temp_minute.toString(minute1);
                                                                                                }
                                                                                                temp = "";
                                                                                        }

                                                                        }
                                                                        else
                                                                        {
                                                                                        temp = temp + temp_date[j];
                                                                        }
                                                        }
                                                        year1 = year1 +543;
                                        %>
							          <%=day1%>&nbsp;
							          <%if (month1 == 1) out.print("�.�.");
                                                                                                                if (month1 == 2) out.print("�.�.");
                                                                                                                if (month1 == 3) out.print("��.�.");
                                                                                                                if (month1 == 4) out.print("��.�.");
                                                                                                                if (month1 == 5) out.print("�.�.");
                                                                                                                if (month1 == 6) out.print("��.�.");
                                                                                                                if (month1 == 7) out.print("�.�.");
                                                                                                                if (month1 == 8) out.print("�.�.");
                                                                                                                if (month1 == 9) out.print("�.�.");
                                                                                                                if (month1 == 10) out.print("�.�.");
                                                                                                                if (month1 == 11) out.print("�.�.");
                                                                                                                if (month1 == 12) out.print("�.�.");
                                                                                        %>
          &nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�. </div></td>
      <td width="16%"><div align="center"><%=list[i].getEntertainmentName()%></div></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
<input type = "hidden" name ="Entertain_Contact_ID" value = "<%=list[i].getContactID()%>">
<input type = "hidden" name ="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
<input type = "hidden" name ="Entertainment_Name" value = "<%=list[i].getEntertainmentName()%>">
<input type = "hidden" name ="Entertain_Job_ID" value = "<%=list[i].getJobID()%>">
        </form>
	<%}}%>

  </table>
  <!-----------------------------------------------------�����͹����෹�����----------------------------------------------->

      <form name="form3" method="post" action="Entertainment/SearchEntertain.jsp">
		  <%if ((list != null)&&(list.length!=0)){
		  %>
		  <input type= "hidden" name = "Entertainment_Name" value = "<%=list[0].getEntertainmentName()%>">
		  <input type = "hidden" name = "Entertain_Contact_ID" value = "<%=list[0].getContactID()%>">
		  <%}
		  else{%>
		  <input type= "hidden" name = "Entertainment_Name" value = "null">
		  <input type = "hidden" name = "Entertain_Contact_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
          <div align="center">
            <input type="submit" name="Submit" value="�����͹����෹�����" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
  <!----------------------------------------------------	¡��ԡ�͹����෹�����----------------------------------------------->

<%if ((list != null)&&(list.length!=0)){%>
  <form name="form4" method="post" action="Entertainment/CancelEntertainContact.jsp">
		  <input type = "hidden" name = "Entertain_Contact_ID" value = "<%=list[0].getContactID()%>">
		  <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
    <div align="center"><input type="submit" name="Submit" value="¡��ԡ��¡�âͧ�͹����෹����������" <%if(lockButton){%>disabled<%}%>></div>
  </form>
  <%}%>
<!---------------------------------------------------------------------��ҹ�����Ҿ----------------------------------------------------------------------------->
<a name = "photo"></a>
	  <% org.openuri.www.ContactID Contact = PhotosoapProxy.photo_HasContact(Wedding_contact_ID);
	  //org.openuri.www.ContactID photo_HasContact(int weddingContactID)
		org.openuri.www.ContactInfo[] photojob = null;%>
  <p>&nbsp;</p>
    <table width="85%" border="1" bordercolor="#CCCCCC" align = "center">
    <tr  bgcolor="#FFCCFF">
      <td colspan="7"><div align="center">��¡�çҹ�������ͧ��ҹ�����Ҿ</div></td>
    </tr>
    <tr>
      <td width="5%"><div align="center">&nbsp;</div></td>
      <td width="16%"><div align="center">�����Ҿ</div></td>
      <td width="26%"><div align="center">���ͻ�����ᾤࡨ</div></td>
      <td width="16%"><div align="center">����ᾤࡨ����</div></td>
      <td width="16%"><div align="center">�ѹ�Ѻ�ͧ</div></td>
      <td width="16%"><div align="center">������ҹ�����Ҿ</div></td>
      <td width="21%"><div align="center">&nbsp;</div></td>
    </tr>
  <!-------------------------------------�ʴ����ҧ��������´ job----------------------------------------------------------------------------->

<%
		if (Contact != null)
		{
			photojob = PhotosoapProxy.photo_ShowOrderByContact(Wedding_contact_ID,Contact.getContactID());
			if ((photojob != null)&&(photojob.length != 0))
				{
					StringTokenizer strtoken = null;
					int type_id = 0;
					String str = null;
					for (int i = 0; i < photojob.length; i++)
					{
						if (photojob[i].getTypeID()!= null){
						str = photojob[i].getTypeID();
						strtoken = new StringTokenizer(str," ");
						type_id = Integer.parseInt(strtoken.nextToken());
					}else type_id = 0;
					%>
   <form name="form11" method="post" action="Photo/CancelPhotoJob.jsp"> 
    <tr>
      <td width="5%"><div align="center"><%=i+1%></div></td>
      <td width="16%"><div align="center"><a href = "Photo/ShowDetailPhoto.jsp?Photo_Contact_ID=<%=Contact.getContactID()%>&Type_ID=<%=type_id%>&Photo_Job_ID=<%=photojob[i].getJobID()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Photo_Name=<%=photojob[i].getPhotoName()%>&Photo_ID=<%=photojob[i].getPhotoID()%>&Sub_Type_Name=<%=photojob[i].getSubTypeName()%>&ReceiveDate=<%=photojob[i].getReceiveDate()%>&Type_Name=<%=photojob[i].getTypeName()%>"><%=photojob[i].getJobID()%></a></div></td>
      <td width="26%"><div align="center"><%=photojob[i].getTypeName()%>&nbsp;</div></td>
      <td width="16%"><div align="center"><%=photojob[i].getSubTypeName()%>&nbsp;</div></td>
      <td width="16%"><div align="center">
	            <%
                                                        String temp = new String();
                                                        int  day1 = 0;
                                                        int month1 = 0;
                                                        int year1 = 0;
                                                        int count = 0;
                                                        String hour1 = new String();
                                                        int minute1 = 0;
                                                        String minute = new String();
                                                        char[] temp_date = photojob[i].getReceiveDate().toCharArray();
                                                        for(int j = 0;  j < photojob[i].getReceiveDate().length(); j++)
                                                        {
                                                                        if(temp_date[j] == ' ' || temp_date[j] == ':')
                                                                        {
                                                                                        count++;
                                                                                        if(count == 1)
                                                                                        {
                                                                                                        Integer temp_day = new Integer(temp);
                                                                                                        day1 = temp_day.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 2)
                                                                                        {
                                                                                                        Integer temp_month = new Integer(temp);
                                                                                                        month1 = temp_month.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 3)
                                                                                        {
                                                                                                        Integer temp_year = new Integer(temp);
                                                                                                        year1 = temp_year.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 4)
                                                                                        {
                                                                                                        hour1 = temp;
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 5)
                                                                                        {
                                                                                                Integer temp_minute = new Integer(temp);
                                                                                                minute1 = temp_minute.intValue();
                                                                                                if(minute1 < 10)
                                                                                                {
                                                                                                                minute = "0" + temp_minute.toString(minute1);
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                                minute = temp_minute.toString(minute1);
                                                                                                }
                                                                                                temp = "";
                                                                                        }

                                                                        }
                                                                        else
                                                                        {
                                                                                        temp = temp + temp_date[j];
                                                                        }
                                                        }
                                                        year1 = year1 +543;
                                        %>
							          <%=day1%>&nbsp;
							          <%if (month1 == 1) out.print("�.�.");
                                                                                                                if (month1 == 2) out.print("�.�.");
                                                                                                                if (month1 == 3) out.print("��.�.");
                                                                                                                if (month1 == 4) out.print("��.�.");
                                                                                                                if (month1 == 5) out.print("�.�.");
                                                                                                                if (month1 == 6) out.print("��.�.");
                                                                                                                if (month1 == 7) out.print("�.�.");
                                                                                                                if (month1 == 8) out.print("�.�.");
                                                                                                                if (month1 == 9) out.print("�.�.");
                                                                                                                if (month1 == 10) out.print("�.�.");
                                                                                                                if (month1 == 11) out.print("�.�.");
                                                                                                                if (month1 == 12) out.print("�.�.");
                                                                                        %>
          &nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�. 	  
	  </div></td>
      <td width="16%"><div align="center"><%=photojob[i].getPhotoName()%></div></td>
		<input type = "hidden" name = "type_id" value = "<%=photojob[i].getTypeID()%>">
		<input type = "hidden" name ="Photo_Contact_ID" value = "<%=Contact.getContactID()%>">
		<input type = "hidden" name ="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
		<input type = "hidden" name ="Photo_Name" value = "<%=photojob[i].getPhotoName()%>">
		<input type = "hidden" name ="Photo_Job_ID" value = "<%=photojob[i].getJobID()%>">
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
</form>
		<%}}}%>
  </table>
   <!---------------------------------------------------------------------������ҹ�����Ҿ---------------------------------------------------------->
      <form name="form9" method="post" action="Photo/SearchPhoto.jsp">
          <div align="center">
		  <%if ((photojob != null)&&(photojob.length != 0)){
		  %>
		  <input type= "hidden" name = "Photo_Name" value = "<%=Contact.getPhotoName()%>">
		  <input type = "hidden" name = "Photo_Contact_ID" value = "<%=Contact.getContactID()%>">
		  <input type = "hidden" name = "Photo_ID" value = "<%=Contact.getPhotoID()%>">
		  <%}
		  else if (Contact != null){%>
		  <input type= "hidden" name = "Photo_Name" value = "<%=Contact.getPhotoName()%>">
		  <input type = "hidden" name = "Photo_Contact_ID" value = "<%=Contact.getContactID()%>">
		  <input type = "hidden" name = "Photo_ID" value = "<%=Contact.getPhotoID()%>">
		  <%}
		  else
			  {%>
		  <input type= "hidden" name = "Photo_Name" value = "null">
		  <input type = "hidden" name = "Photo_Contact_ID" value = "0">
		  <input type = "hidden" name = "Photo_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="������ҹ�����Ҿ" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>
<!----------------------------------------¡��ԡ Contact----------------------------------------------------------------------------->
		  <%if (Contact != null){%>
  <form name="form10" method="post" action="Photo/CancelPhotoContact.jsp">
		  <input type = "hidden" name = "Photo_Contact_ID" value = "<%=Contact.getContactID()%>">
		  <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
    <div align="center"><input type="submit" name="Submit" value="¡��ԡ��¡���Ҿ������" <%if(lockButton){%>disabled<%}%>></div>
  </form>
  <%}%>
  <p>&nbsp;</p>
<!--------------------------------------��ҹ��¢ͧ������----------------------------------------------------------------------------->
<a name = "gift"></a>
  <table width="85%" border="1" bordercolor="#CCCCCC" align = "center">
    <tr  bgcolor="#FFCCFF">
      <td colspan="6"><div align="center">��¡�çҹ�������ͧ��ҹ��¢ͧ������</div></td>
    </tr>
    <tr>
      <td width="5%"><div align="center">&nbsp;</div></td>
      <td width="16%"><div align="center">���ʢͧ������</div></td>
      <td width="25%"><div align="center">��Դ�ͧ������</div></td>
      <td width="22%"><div align="center">�ѹ�Ѻ�ͧ</div></td>
      <td width="17%"><div align="center">������ҹ�ͧ������</div></td>
      <td width="21%"><div align="center">&nbsp;</div></td>
    </tr>
  <%
          org.openuri.www.Contactdetail Contactgift = GiftsoapProxy.giftListContact1(Customer_id,Wedding_contact_ID);
		  org.openuri.www.Job[] GiftJobList = null;
		  if ((Contactgift != null)&&(Contactgift.getGiftContactId()!=0)){
        GiftJobList = GiftsoapProxy.giftListJob(Customer_id,Wedding_contact_ID,Contactgift.getGiftContactId());
	if ((GiftJobList != null)&&(GiftJobList.length != 0)){
		for (int i = 0; i < GiftJobList.length; i++)
	  {
	%>
   <form name="form5" method="post" action="Gift/CancelGiftJob.jsp">
    <tr>
      <td width="5%"><div align="center"><%=i+1%></div></td>
      <td width="16%"><div align="center"><a href = "Gift/ShowDetailGift.jsp?Gift_Contact_ID=<%=Contactgift.getGiftContactId()%>&Gift_Job_ID=<%=GiftJobList[i].getJobId()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Gift_Name=<%=GiftJobList[i].getGiftName()%>&Gift_ID=<%=GiftJobList[i].getGiftNumber()%>&Sub_Type_Name=<%=GiftJobList[i].getSubtypeName()%>&ReceiveDate=<%=GiftJobList[i].getReceiveDate()%>"><%=GiftJobList[i].getJobId()%></a></div></td>
      <td width="25%"><div align="center"><%=GiftJobList[i].getSubtypeName()%></div></td>
      <td width="22%"><div align="center">
	            <%
                                                        String temp = new String();
                                                        int  day1 = 0;
                                                        int month1 = 0;
                                                        int year1 = 0;
                                                        int count = 0;
                                                        String hour1 = new String();
                                                        int minute1 = 0;
                                                        String minute = new String();
                                                        char[] temp_date = GiftJobList[i].getReceiveDate().toCharArray();
                                                        for(int j = 0;  j < GiftJobList[i].getReceiveDate().length(); j++)
                                                        {
                                                                        if(temp_date[j] == ' ' || temp_date[j] == ':')
                                                                        {
                                                                                        count++;
                                                                                        if(count == 1)
                                                                                        {
                                                                                                        Integer temp_day = new Integer(temp);
                                                                                                        day1 = temp_day.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 2)
                                                                                        {
                                                                                                        Integer temp_month = new Integer(temp);
                                                                                                        month1 = temp_month.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 3)
                                                                                        {
                                                                                                        Integer temp_year = new Integer(temp);
                                                                                                        year1 = temp_year.intValue();
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 4)
                                                                                        {
                                                                                                        hour1 = temp;
                                                                                                        temp = "";
                                                                                        }
                                                                                        if(count == 5)
                                                                                        {
                                                                                                Integer temp_minute = new Integer(temp);
                                                                                                minute1 = temp_minute.intValue();
                                                                                                if(minute1 < 10)
                                                                                                {
                                                                                                                minute = "0" + temp_minute.toString(minute1);
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                                minute = temp_minute.toString(minute1);
                                                                                                }
                                                                                                temp = "";
                                                                                        }

                                                                        }
                                                                        else
                                                                        {
                                                                                        temp = temp + temp_date[j];
                                                                        }
                                                        }
                                                        year1 = year1 +543;
                                        %>
							          <%=day1%>&nbsp;
							          <%if (month1 == 1) out.print("�.�.");
                                                                                                                if (month1 == 2) out.print("�.�.");
                                                                                                                if (month1 == 3) out.print("��.�.");
                                                                                                                if (month1 == 4) out.print("��.�.");
                                                                                                                if (month1 == 5) out.print("�.�.");
                                                                                                                if (month1 == 6) out.print("��.�.");
                                                                                                                if (month1 == 7) out.print("�.�.");
                                                                                                                if (month1 == 8) out.print("�.�.");
                                                                                                                if (month1 == 9) out.print("�.�.");
                                                                                                                if (month1 == 10) out.print("�.�.");
                                                                                                                if (month1 == 11) out.print("�.�.");
                                                                                                                if (month1 == 12) out.print("�.�.");
                                                                                        %>
          &nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�. </div></td>
      <td width="17%"><div align="center"><%=GiftJobList[i].getGiftName()%></div></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
		<input type = "hidden" name ="Gift_Contact_ID" value = "<%=Contactgift.getGiftContactId()%>">
		<input type = "hidden" name ="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
		<input type = "hidden" name ="Gift_Name" value = "<%=GiftJobList[i].getGiftName()%>">
		<input type = "hidden" name ="Gift_Job_ID" value = "<%=GiftJobList[i].getJobId()%>">
	</form>
    <%}}}%>
  </table>
      <form name="form6" method="post" action="Gift/SearchGift.jsp">
          <div align="center">
		  <%if ((GiftJobList != null)&&(GiftJobList.length!=0)){
		  %>
		  <input type= "hidden" name = "Gift_Name" value = "<%=Contactgift.getGIFTNAME()%>">
		  <input type = "hidden" name = "Gift_Contact_ID" value = "<%=Contactgift.getGiftContactId()%>">
		  <input type = "hidden" name = "Gift_ID" value = "<%=Contactgift.getGIFTID()%>">
		  <%}
		  else if ((Contactgift != null)&&(Contactgift.getGiftContactId()!=0)){%>
		  <input type= "hidden" name = "Gift_Name" value = "<%=Contactgift.getGIFTNAME()%>">
		  <input type = "hidden" name = "Gift_Contact_ID" value = "<%=Contactgift.getGiftContactId()%>">
		  <input type = "hidden" name = "Gift_ID" value = "<%=Contactgift.getGIFTID()%>">
		  <%}
		  else {%>
		  <input type= "hidden" name = "Gift_Name" value = "null">
		  <input type = "hidden" name = "Gift_Contact_ID" value = "0">
		  <input type = "hidden" name = "Gift_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="���Ңͧ������" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>

<%if ((Contactgift != null)&&(Contactgift.getGiftContactId()!=0)){%>
  <form name="form7" method="post" action="Gift/CancelGiftContact.jsp">
		  <input type = "hidden" name = "Gift_Contact_ID" value = "<%=Contactgift.getGiftContactId()%>">
		  <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
    <div align="center"><input type="submit" name="Submit" value="¡��ԡ��¡�âͧ�����·�����" <%if(lockButton){%>disabled<%}%>></div>
  </form>
  <%}%>
  <p>&nbsp;</p>
  <a name = "tour"></a>
  <table width="85%" border="1" bordercolor="#CCCCCC" align = "center">
    <tr  bgcolor="#FFCCFF">
      <td colspan="6"><div align="center">��¡�çҹ�������ͧ����ѷ�����</div></td>
    </tr>
    <tr>
      <td align="center" width="5%">&nbsp;</td>
      <td align="center" width="26%">���ʷ����</td>
      <td align="center" width="16%">����ᾤࡨ�����</td>
      <td align="center" width="16%">�ѹ�͡�Թ�ҧ</td>
      <td align="center" width="20%">���ͺ���ѷ�����</td>
      <td align="center" width="21%">&nbsp;</td>
    </tr>
<%
		org.openuri.www.ContactID tourcontact = ToursoapProxy.tour_GetContactID(Wedding_contact_ID);
		org.openuri.www.TourJobDetailLow[] tourjob = null;
		int Tour_Contact_ID = 0;
		if (tourcontact != null)
		{
			tourjob = ToursoapProxy.tour_GetJobByContact(tourcontact.getContactID(),Wedding_contact_ID);
			Tour_Contact_ID = tourcontact.getContactID();
			if ((tourjob != null)&&(tourjob.length != 0))
				{
					for (int i = 0; i < tourjob.length; i++)
					{
					%>
   <form name="form8" method="post" action="Tour/CancelTourJob.jsp">    
	<tr>
      <td align="center" width="5%"><%=i+1%></td>
      <td align="center" width="26%"><a href = "Tour/ShowDetailTour.jsp?Tour_Contact_ID=<%=Tour_Contact_ID%>&Tour_Job_ID=<%=tourjob[i].getJobID()%>&Wedding_Contact_ID=<%=Wedding_contact_ID%>&Package_Name=<%=tourjob[i].getPackageName()%>&StartDate=<%=tourjob[i].getStartDate()%>&Tour_Name=<%=tourjob[i].getTourName()%>&Tour_ID=<%=tourjob[i].getTourID()%>"><%=tourjob[i].getJobID()%></a></td>
      <td align="center" width="16%"><%=tourjob[i].getPackageName()%></td>
      <td align="center" width="16%"><%=tourjob[i].getStartDate()%></td>
      <td align="center" width="20%"><%=tourjob[i].getTourName()%></td>
      <td width="21%"><div align="center"><input type = "submit" value = "¡��ԡ��¡��" name = "cancel" <%if(lockButton){%>disabled<%}%>></div></td>
    </tr>
	<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
	<input type = "hidden" name = "Tour_Contact_ID" value = "<%=tourcontact.getContactID()%>">
	<input type = "hidden" name = "Tour_Job_ID" value = "<%=tourjob[i].getJobID()%>">
		</form>
		<%}}}%>
  </table>

      <form name="form9" method="post" action="Tour/SearchTour.jsp">
          <div align="center">
		  <%if ((tourcontact != null)&&((tourjob != null)&&(tourjob.length != 0))){
		  %>
		  <input type= "hidden" name = "Tour_Name" value = "<%=tourjob[0].getTourName()%>">
		  <input type = "hidden" name = "Tour_Contact_ID" value = "<%=Tour_Contact_ID%>">
		  <input type = "hidden" name = "Tour_ID" value = "<%=tourjob[0].getTourID()%>">
		  <%}
		  else{%>
		  <input type= "hidden" name = "Tour_Name" value = "null">
		  <input type = "hidden" name = "Tour_Contact_ID" value = "0">
		  <input type = "hidden" name = "Tour_ID" value = "0">
		  <%}%>
            <input type="hidden"name="Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
            <input type="submit" name="Submit" value="����ᾤࡨ�����" <%if(lockButton){%>disabled<%}%>>
          </div>
        </form>

		  <%if ((tourcontact != null)&&((tourjob != null)&&(tourjob.length != 0))){%>
  <form name="form10" method="post" action="Tour/CancelTourContact.jsp">
		  <input type = "hidden" name = "Tour_Contact_ID" value = "<%=Tour_Contact_ID%>">
		  <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_contact_ID%>">
    <div align="center"><input type="submit" name="Submit" value="¡��ԡ��¡��ᾤࡨ����������" <%if(lockButton){%>disabled<%}%>></div>
  </form>
  <%}%>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</body>
</html>