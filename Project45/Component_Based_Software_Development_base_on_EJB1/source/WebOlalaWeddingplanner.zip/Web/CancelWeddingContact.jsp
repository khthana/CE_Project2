<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%Weddingplanner_Impl proxy = new Weddingplanner_Impl();
	WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap();%>
<%WeddingplannerGift_Impl proxyGift = new WeddingplannerGift_Impl() ;
	WeddingplannerGiftSoap GiftsoapProxy = proxyGift.getWeddingplannerGiftSoap();%>
<%	Weddingplanner1_Impl proxyHotel = new Weddingplanner1_Impl() ;
	Weddingplanner1Soap Hotel = proxyHotel.getweddingplanner1Soap();%>
<%OlalaTour_Impl proxyTour = new OlalaTour_Impl();
	OlalaTourSoap ToursoapProxy = proxyTour.getOlalaTourSoap();%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<%Payment_Impl proxyPay = new Payment_Impl();
	PaymentSoap PaysoapProxy = proxyPay.getpaymentSoap();%>
<html>
<head><title>Olala Wedding Planner : Cancel Wedding Contact</title></head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Wedding_Contact_Name");
	String Wedding_Contact_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	//boolean delete_wedding_contact(int customerId, int weddingContactId)
    int cancel = PaysoapProxy.delete_wedding_contact(Customer_id,Wedding_Contact_ID);
    if (cancel ==6)
    {
      response.sendRedirect("./ShowContact.jsp");
    }
	else {%>
	<center>
	�������ö¡��ԡ Wedding Contact ��  
	<a href = "./ShowContact.jsp">��Ѻ仴���������´</a></center>
<%	}%>
</body>
</html>