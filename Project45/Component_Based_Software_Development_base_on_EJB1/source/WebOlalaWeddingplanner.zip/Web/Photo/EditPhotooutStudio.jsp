<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="java.util.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner : Edit  Photo Out Studio</title></head>

<body bgcolor="F9F9EF">
<%
	String Temp_Str = null;
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);
    Temp_Str = (String)request.getParameter("Photo_Contact_ID");
    int Photo_Contact_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Job_ID");
	int Photo_Job_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Name");
	String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Photo_ID");
	int Photo_ID = Integer.parseInt(Temp_Str);
	Temp_Str = request.getParameter("SubType_Name");
	String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
	Temp_Str = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	StringTokenizer strtoken;
	Temp_Str = (String)request.getParameter("Type_ID");
	String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(type_id," ");
	int Type_ID = Integer.parseInt(strtoken.nextToken());
	Temp_Str = (String)request.getParameter("SubType_ID");
	String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(strtoken.nextToken());
	Temp_Str = (String)request.getParameter("ReserveDate");
	String ReserveDate = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Round");
	String Round = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Price");
	double Price = Double.parseDouble(Temp_Str);
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = ReserveDate.toCharArray();
							for(int j = 0;  j < ReserveDate.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':' || temp_date[j] == '/')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;%>
<center>
<!----------------------------------------------------�͡ʵٴ���------------------------------------------------->
<form name="form1" method="post" action="./EditOutStudio.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"> 
          <div align="center">��������´��èͧ��ҹ�����Ҿ�͡ʵٴ���</div>
        </td>
      </tr>
      <tr> 
        <td><div align="center">1.</div></td>
        <td><div align="left" width = "40%">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ :</div></td>
        <td><div align="left">
<select name = "day1" >
			<%
					for (int i = 1 ; i <= 31 ; i ++) {
			%>
					<option value = "<%=i%>" <% if ( i == day1) { %> <%="selected"%> <%}%>><%=i%></option>
			<%
				}
			%>
		</select>&nbsp;��͹ 
		 <select name = "month1">
		 <option value = "1" <%if (month1 == 1) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "2" <%if (month1 == 2) { %><%="selected"%><%}%>>����Ҿѹ��</option>
		 <option value = "3" <%if (month1 == 3) { %><%="selected"%><%}%>>�չҤ�</option>
		 <option value = "4" <%if (month1 == 4) { %><%="selected"%><%}%>>����¹</option>
		 <option value = "5" <%if (month1 == 5) { %><%="selected"%><%}%>>����Ҥ�</option>
		 <option value = "6" <%if (month1 == 6) { %><%="selected"%><%}%>>�Զع�¹</option>
		 <option value = "7" <%if (month1 == 7) { %><%="selected"%><%}%>>�á�Ҥ�</option>
		 <option value = "8" <%if (month1 == 8) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
		 <option value = "9" <%if (month1 == 9) { %><%="selected"%><%}%>>�ѹ��¹</option>
		 <option value = "10" <%if (month1 == 10) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "11" <%if (month1 == 11) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
		 <option value = "12" <%if (month1 == 12) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
		</select>&nbsp;�.�. 
		<select name = "year1">
		<option value = "2003">2546</option>
		<option value = "2004">2547</option>
		<option value = "2005">2548</option>
		</select>
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">�ӹǹ������� :</div></td>
        <td><div align="left">
		<%
		  String hour = null;
		  if (SubType_ID == 1){
		  hour = "4 �������";
		  }else if (SubType_ID == 2){
			  hour = "8 �������";
		  }else {
			  hour = "12 �������";}%>
		&nbsp;<%=hour%>
        </div></td>
      </tr>
	  <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">���� :</div></td>
        <td><div align="left">
              <select name="Round">
                <option value = "1"> 9.00 -11.00 �.</option>
                <option value = "2">10.00 -12.00 �.</option>
                <option value = "3">13.00 -15.00 �.</option>
                <option value = "4">14.00 -16.00 �.</option>
                <option value = "5">15.00 -17.00 �.</option>
                <option value = "6">16.00 -18.00 �.</option>
                <option value = "7">17.00 -19.00 �.</option>
                <option value = "8">18.00 -20.00 �.</option>
              </select>  &nbsp; 
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">��Һ�ԡ�� :</div></td>
        <td><div align="left"><%=Price%>&nbsp;�ҷ</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
    </table>
		<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
		<input type = "hidden" name = "Photo_Contact_ID" value = "<%=Photo_Contact_ID%>">
		<input type = "hidden" name ="Photo_Job_ID" value = "<%=Photo_Job_ID%>">
		<input type = "hidden" name = "Type_ID" value = "<%=Type_ID%>">
		<input type = "hidden" name = "SubType_Name" value = "<%=SubType_Name%>">
		<input type = "hidden" name = "SubType_ID" value = "<%=SubType_ID%>">
		<input type = "hidden" name = "SubType_Detail" value = "<%=SubType_Detail%>">
		<input type = "hidden" name = "Price" value = "<%=Price%>">
        <input type = "hidden" name= "Photo_ID" value = "<%=Photo_ID%>">
        <input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
		<center><input type = "Submit" value = "Edit"></center>
    </form>
  <p>&nbsp;</p>
</center>
</body>
</html>