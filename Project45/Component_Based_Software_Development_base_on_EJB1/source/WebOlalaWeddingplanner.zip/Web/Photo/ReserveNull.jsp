<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>
<body>
<%
		session.setAttribute("Customer_ID" , "");
%>
<div id="Layer1" style="position:absolute; left:88px; top:74px; width:480px; height:278px; z-index:1">Home</div>
</body>
</html>