<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Multimedia</title>
</head>

<body bgcolor="F9F9EF">
<%
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Job_ID");
	int Photo_Job_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Name");
	String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
    Temp_Str = (String)request.getParameter("Photo_Contact_ID");
    int Photo_Contact_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("SubType_Name");
	String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Price");
	double Price = Double.parseDouble(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_ID");
	int Photo_ID = Integer.parseInt(Temp_Str);
	StringTokenizer strtoken;
	Temp_Str = (String)request.getParameter("Type_ID");
	String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(type_id," ");
	int Type_ID = Integer.parseInt(strtoken.nextToken());
	Temp_Str = (String)request.getParameter("SubType_ID");
	String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(strtoken.nextToken());
		Temp_Str = (String)request.getParameter("Date");
		String Date1 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		Temp_Str = (String)request.getParameter("Month");
		String Month1 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		Temp_Str = (String)request.getParameter("Year");
		String Year1 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		Temp_Str = (String)request.getParameter("hour");
		String hour = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		Temp_Str = (String)request.getParameter("Date1");
		String Date2 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		Temp_Str = (String)request.getParameter("Month1");
		String Month2 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		Temp_Str = (String)request.getParameter("Year1");
		String Year2 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
		if (Date1.length() ==1)
			Date1 = "0"+Date1;
		if (Date2.length() == 1)
			Date2 = "0"+Date2;
		String reserveDate = Date1+" "+Month1+" "+Year1+" "+hour;
		String finishDate = Date2+" "+Month2+" "+Year2;
		int years;

//boolean photo_EditReserve_Multi(int weddingContactID, int contactID, int jobID, java.lang.String reserveDate, java.lang.String finishDate)]
	boolean result = PhotosoapProxy.photo_EditReserve_Multi(Wedding_Contact_ID,Photo_Contact_ID,Photo_Job_ID,reserveDate,finishDate);
		if (result == false){
		%>
			<p>&nbsp;</p>
			<center>�������ö�����
			<p>&nbsp;</p>
			<a href = "../ShowContact.jsp">˹���á</a></center>
		<%	}
		else
		{
%>
<center>
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF">
        <td colspan="3"><div align="center">��������´��������ҹ�����Ҿ</div></td>
      </tr>
      <tr>
        <td width="5%"><div align="center">1.</div></td>
        <td width="47%"><div align="left">����ᾤࡨ���� :</div></td>
        <td width="48%"> <div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr>
        <td><div align="center">2.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr>
        <td><div align="left">3.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ :</div></td>
        <td><div align="left">
           <%=Date1%>&nbsp;<%if (Month1.equals("01")) out.print("�.�.");
														if (Month1.equals("02")) out.print("�.�.");
														if (Month1.equals("03")) out.print("��.�.");
														if (Month1.equals("04")) out.print("��.�.");
														if (Month1.equals("05")) out.print("�.�.");
														if (Month1.equals("06")) out.print("��.�.");
														if (Month1.equals("07")) out.print("�.�.");
														if (Month1.equals("08")) out.print("�.�.");
														if (Month1.equals("09")) out.print("�.�.");
														if (Month1.equals("10")) out.print("�.�.");
														if (Month1.equals("11")) out.print("�.�.");
														if (Month1.equals("12")) out.print("�.�.");
											years = Integer.parseInt(Year1);
											years = years+543;
											%>&nbsp;<%=years%>&nbsp;&nbsp;<%=hour%>�. 
		</div></td>
      </tr>
      <tr>
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ����ʴ� :</div></td>
        <td><div align="left">
           <%=Date2%>&nbsp;<%if (Month2.equals("01")) out.print("�.�.");
														if (Month2.equals("02")) out.print("�.�.");
														if (Month2.equals("03")) out.print("��.�.");
														if (Month2.equals("04")) out.print("��.�.");
														if (Month2.equals("05")) out.print("�.�.");
														if (Month2.equals("06")) out.print("��.�.");
														if (Month2.equals("07")) out.print("�.�.");
														if (Month2.equals("08")) out.print("�.�.");
														if (Month2.equals("09")) out.print("�.�.");
														if (Month2.equals("10")) out.print("�.�.");
														if (Month2.equals("11")) out.print("�.�.");
														if (Month2.equals("12")) out.print("�.�.");
											years = Integer.parseInt(Year2);
											years = years+543;
											%>&nbsp;<%=years%>&nbsp;&nbsp; 
		</div></td>
      </tr>
      <tr>
        <td><div align="left">5.</div></td>
        <td><div align="left">�Ҥ� :</div></td>
        <td><div align="left"><%=Price%>&nbsp;�ҷ</div></td>
      </tr>
      <tr>
        <td><div align="center">6.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
    </table>
  <p>&nbsp;</p>
<a href = "../ShowContact.jsp">˹���á</a>
	  <%}%>
</center>
</body>
</html>