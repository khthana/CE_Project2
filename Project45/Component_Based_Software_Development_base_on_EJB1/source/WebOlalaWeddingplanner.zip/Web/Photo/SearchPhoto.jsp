<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Search Photo</title>
</head>

<body bgcolor="F9F9EF">
<%
        int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

        String tempstr = (String)request.getParameter("Wedding_Contact_ID");
        int Wedding_Contact_ID = Integer.parseInt(tempstr);

        tempstr = (String)request.getParameter("Photo_Contact_ID");
		int Photo_Contact_ID;
        if (tempstr == "0")
        {
          Photo_Contact_ID = 0;
        }
        else
        {
          Photo_Contact_ID = Integer.parseInt(tempstr);
        }
        tempstr = (String)request.getParameter("Photo_Name");
		String Photo_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		tempstr = (String)request.getParameter("Photo_ID");
		int Photo_ID = Integer.parseInt(tempstr);
        boolean photo = true;
        if (Photo_Name.equals("null"))
        {
           photo = true;
        }
        else photo = false;
%>
<form name="form1" method="post" action="./ResultSearch.jsp">
<%Date now = new Date();%>
<table align="center" border=0 cellpadding="0" cellspacing="0" width="450">
  <tr><td align= "left"><p>&nbsp;</p></td></tr>
  <tr><td width="450">
		<table width="567" border="1" bordercolor="#CCCCCC">
          <tr bgcolor="#FFCCFF"><td colspan="3"><div align="center">��سҡ�͡�����ŷ���ͧ��ä��Ңͧ��ҹ�����Ҿ</div></td></tr>
          <tr> 
            <td width="12">1.</td>
            <td width="188"> ��Դ�Թ��� :</td>
            <td width="345"> 
              <select name="type_id">
                <option value="0" selected>������</option>
                <option value="1">�����Ҿ������ �ʵٴ���</option>
<!--                <option value="2">�����Ҿ��ͺ����,�ҾῪ�� �ʵٴ���</option>-->
                <option value="3">�����Ҿ��ѹ�觧ҹ</option>
<!--                <option value="4">�����Ҿ�ѹ�Ѻ��ԭ��,��ѹ�Ը� ���� �ҹ�ѧ��ä��ҧ� (�͡ʵٴ���)</option>-->
                <option value="5">�����մ����ѹ�ҹ�Ը� ���ͧҹ����§�ѧ��ä�</option>
                <option value="6">�����Դ��ͨѴ���մ��� ��ŵ������ ���ૹ൪�� 㹧ҹ�觧ҹ</option>
              </select></td>
          </tr>
          <tr> 
            <td width="12">2.</td>
            <td width="188">�Ҥҵ���ش :</td>
            <td width="345"><input name="Minprice" type="text" value="5" size="10">�ҷ </td>
          </tr>
          <tr> 
            <td width="12">3.</td>
            <td width="188">�Ҥ��٧�ش:</td>
            <td width="345"><input name="Maxprice" type="text" value="10000" size="10">�ҷ</td>
          </tr>
          <tr> 
            <td height="27" width="12">4.</td>
            <td width="188">��ͧ����ҤҶ١����ش :</td>
            <td width="345">
				<input name="cheap" type="radio" value="yes" checked>��ͧ��� 
				<input type="radio" name="cheap" value="no">����ͧ���</td>
          </tr>
          <tr> 
            <td width="12">5.</td>
            <td width="188">������ҹ��¢ͧ������:</td>
            <td width="345"> 
              <%if (Photo_Name.equals("null")){%>
              <select name="Photo_ID">
                <option value = "0">�ء��ҹ</option>
                <option value = "1">Photo1</option>
                <option value = "2">Photo2</option>
                <option value = "3">Photo3</option>
                <option value = "4">Photo4</option>
                <option value = "5">Photo5</option>
                <option value = "6">Photo6</option>
                <option value = "7">Photo7</option>
                <option value = "8">Photo8</option>
                <option value = "9">Photo9</option>
                <option value = "10">Photo10</option>
              </select>  &nbsp; 
               <%switch (Photo_ID){
			case 1: Photo_Name = "Photo1";break;
			case 2: Photo_Name = "Photo2";break;
			case 3: Photo_Name = "Photo3";break;
			case 4: Photo_Name = "Photo4";break;
			case 5: Photo_Name = "Photo5";break;
			case 6: Photo_Name = "Photo6";break;
			case 7: Photo_Name = "Photo7";break;
			case 8: Photo_Name = "Photo8";break;
			case 9: Photo_Name = "Photo9";break;
			case 10: Photo_Name = "Photo10";break;
			case 0: Photo_Name = "";break;	}%>
			<input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
			<%}  else
			{out.println(Photo_Name);%>
			<input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
			<input type = "hidden" name = "Photo_ID" value = "<%=Photo_ID%>">
<%        } %>
			</td>
          </tr>
          <%if (photo == true){%>
          <tr> 
            <td height="27" width="13">6.</td>
            <td width="188">
              <input type="radio" name="Near" value="region">
              �Ҥ :</td>
            <td width="345"> 
              <select name="Region">
                <option value = "0">-- �Ҥ --</option>
                <option value = "1">�˹��</option>
                <option value = "2">��ҧ</option>
                <option value = "3">���ѹ�͡</option>
                <option value = "4">���ѹ�͡��§�˹��</option>
                <option value = "5">��</option>
                <option value = "6">���ѹ��</option>
              </select> </td>
          </tr>
          <tr> 
            <td height="27" width="14">7.</td>
            <td width="188">
              <input type="radio" name="Near" value="district" checked>
              ࢵ㹡�ا෾ :</td>
            <td width="345"> 
              <select name="District">
                <option value = "0">-- ࢵ --</option>
                <option value = "1">	��ͧ��	</option>
                <option value = "2">	��ͧ�ҹ	</option>
                <option value = "3">	��ͧ�����	</option>
                <option value = "4">	�ѹ�����	</option>
                <option value = "5">	��بѡ�	</option>
                <option value = "6">	����ͧ	</option>
                <option value = "7">	�͹���ͧ	</option>
                <option value = "8">	�Թᴧ	</option>
                <option value = "9">	���Ե	</option>
                <option value = "10">	���觪ѹ	</option>
                <option value = "11">	����Ѳ��	</option>
                <option value = "12">	��觤��	</option>
                <option value = "13">	������	</option>
                <option value = "14">	�ҧ�͡����	</option>
                <option value = "15">	�ҧ�͡�˭�	</option>
                <option value = "16">	�ҧ�л�	</option>
                <option value = "17">	�ҧ�ع��¹	</option>
                <option value = "18">	�ҧࢹ	</option>
                <option value = "19">	�ҧ������	</option>
                <option value = "20">	�ҧ�	</option>
                <option value = "21">	�ҧ����	</option>
                <option value = "22">	�ҧ��	</option>
                <option value = "23">	�ҧ�͹	</option>
                <option value = "24">	�ҧ��Ѵ	</option>
                <option value = "25">	�ҧ�ѡ	</option>
                <option value = "26">	��觡���	</option>
                <option value = "27">	�����ѹ	</option>
                <option value = "28">	������	</option>
                <option value = "29">	������Һ	</option>
                <option value = "30">	����	</option>
                <option value = "31">	���⢹�	</option>
                <option value = "32">	��й��	</option>
                <option value = "33">	������ԭ	</option>
                <option value = "34">	�չ����	</option>
                <option value = "35">	�ҹ����	</option>
                <option value = "36">	�Ҫ���	</option>
                <option value = "37">	��ɮ���ó�	</option>
                <option value = "38">	�Ҵ��кѧ	</option>
                <option value = "39">	�Ҵ�����	</option>
                <option value = "40">	�ѧ�ͧ��ҧ	</option>
                <option value = "41">	�Ѳ��	</option>
                <option value = "42">	�ǹ��ǧ	</option>
                <option value = "43">	�оҹ�٧	</option>
                <option value = "44">	����ѹ�ǧ��	</option>
                <option value = "45">	�Ҹ�	</option>
                <option value = "46">	������	</option>
                <option value = "47">	˹ͧ��	</option>
                <option value = "48">	˹ͧ�͡	</option>
                <option value = "49">	��ѡ���	</option>
                <option value = "50">	���¢�ҧ	</option>
              </select> </td>
          </tr>
			<%}else {%>
				<input type = "hidden" name = "Region" value = "0">
				<input type = "hidden" name = "District" value = "0">
			<%}%>
        </table>
		<BR>
    </td>
  </tr>
  <tr><td colspan="3" align="center"><br> <input type="submit" name="Submit" value="����"></td></tr>
</table>
<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
<input type = "hidden" name = "Photo_Contact_ID" value = "<%=Photo_Contact_ID%>">
</form>
</body>
</html>