<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.EntertainResultsearch"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner : Result Search Entertain</title></head>
<body bgcolor="F9F9EF">
<%	          
		String tempstr = (String)request.getParameter("type_id");
		String type_id = new String(tempstr.getBytes("ISO8859_1"),"MS874");
		StringTokenizer strtoken;
		strtoken = new StringTokenizer(type_id," ");
		int Type_ID = Integer.parseInt(strtoken.nextToken());

		tempstr = (String)request.getParameter("Minprice");
		int minprice = Integer.parseInt(tempstr);

		tempstr = (String)request.getParameter("Maxprice");
		int maxprice = Integer.parseInt(tempstr);

         String Cheap =  (String)request.getParameter("cheap");
         boolean cheap = true;
         if (Cheap.equals("yes"))
         {
            cheap = true;
         }
         else
         {
            cheap = false;
         }

		tempstr = (String)request.getParameter("Region");
		int Region = Integer.parseInt(tempstr);
		tempstr = (String)request.getParameter("District");
		int District = Integer.parseInt(tempstr);

        tempstr = (String)request.getParameter("Photo_ID");
        int Photo_ID = Integer.parseInt(tempstr);
		String Photo_Name = null;

		org.openuri.www.ServiceDetail[] result = PhotosoapProxy.photo_SearchService(Photo_ID,type_id,minprice,maxprice,cheap,District,Region);
//		org.openuri.www.ServiceDetail[] photo_SearchService(int photoID, java.lang.String typeID, int minPrice, int maxPrice, boolean cheap, int district, int region);
		%>
<center>
  <table width="95%" height="143" border="1"  bordercolor="#CCCCCC">
    <tr  bgcolor="#FFCCFF"><td colspan="7"><center>�š�ä���</center></td></tr>
    <tr>
      <td><div align="center">���ͻ�����ᾤࡨ</div></td>
      <td><div align="center">����ᾤࡨ����</div></td>
      <td><div align="center">��������´</div></td>
      <td><div align="center">�Ҥ�</div></td>
      <td><div align="center">������ҹ�����Ҿ</div></td>
      <td><div align="center">���������ҹ�����Ҿ</div></td>
    </tr>
    <%
    if ((result != null)&&(result.length != 0))
	{
                for (int i = 0 ; i < result.length ; i ++ )
                {
                        %>
      <tr>
        <td><div align="center"><%=result[i].getTypeName()%></div></td>
        <td><div align="center"><%=result[i].getSubTypeName()%></div></td>
        <td><div align="center"><%=result[i].getSubTypeDetail()%></div></td>
        <td><div align="center"><%=result[i].getPrice()%></div></td>
        <%switch (result[i].getPhotoID())
			{
				case (1) : Photo_Name = "Photo1"; break;
				case (2) : Photo_Name = "Photo2"; break;
				case (3) : Photo_Name = "Photo3"; break;
				case (4) : Photo_Name = "Photo4"; break;
				case (5) : Photo_Name = "Photo5"; break;
				case (6) : Photo_Name = "Photo6"; break;
				case (7) : Photo_Name = "Photo7"; break;
				case (8) : Photo_Name = "Photo8"; break;
				case (9) : Photo_Name = "Photo9"; break;
				case (10) : Photo_Name = "Photo10"; break;}%>
	  <td><div align="center"><%=Photo_Name%>&nbsp;</div></td>
      <td><div align="center"><%=result[i].getPhotoAddress()%>&nbsp;</div></td>
    </tr>
    <%  }}%>
  </table>
      <form name="form1" method="post" action="./SearchNoLog.jsp" target = "mainFrame">
    <input type="submit" name="Submit" value="Back">
  </form>
</center>
</body>
</html>