<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="java.util.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner : Reserve Photo</title></head>

<body bgcolor="F9F9EF">
<%
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("Photo_Job_ID");
	int Photo_Job_ID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("Photo_Name");
	String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

    Temp_Str = (String)request.getParameter("Photo_Contact_ID");
    int Photo_Contact_ID = Integer.parseInt(Temp_Str);

	Temp_Str = request.getParameter("SubType_Name");
	String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

	StringTokenizer strtoken;
	Temp_Str = (String)request.getParameter("Type_ID");
//	String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
//	strtoken = new StringTokenizer(type_id," ");
	int Type_ID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("SubType_ID");
//	String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
//	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(Temp_Str);
		
	Temp_Str = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

	Temp_Str = (String)request.getParameter("Price");
	double Price = Double.parseDouble(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_ID");
	int Photo_ID = Integer.parseInt(Temp_Str);

%>
<%Date now = new Date();
	Date now2 = new Date();
	Date now3 = new Date();%>
<%  
/*	public Date calIncDate( java.util.Date d1,int du ){
		Date d2;
		long x = 1000;
		x = x*du *60*60* 24;
	    return d2.setTime( d1.getTime()+1000*10*60*60*24);
	}*/
%>
<center>

<form name="form3" method="post" action="./EditMulti.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"> 
          <div align="center">��������´��èͧᾤࡨ���¢ͧ��ԡ�����ҧ�մ��� ��ŵ������ 
            ���ૹ൪��</div>
        </td>
      </tr>
      <tr> 
        <td width="5%"><div align="center">1.</div></td>
        <td width="40%"><div align="left">����ᾤࡨ���� :</div></td>
        <td width="60%"><div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr> 
        <td ><div align="center">3.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ :</div></td>
        <td><div align="left"> 
            <select name="Date">
			<%now3.setTime(now.getTime()+1000*10*60*60*24);%>
              <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
              <option value = "<%=i%>" <% if ( i == now3.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
              <%
				}
		%>
            </select>
            / 
            <select name="Month">
              <option value = "01" <%if (now3.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "02" <%if (now3.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
              <option value = "03" <%if (now3.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
              <option value = "04" <%if (now3.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
              <option value = "05" <%if (now3.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
              <option value = "06" <%if (now3.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
              <option value = "07" <%if (now3.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
              <option value = "08" <%if (now3.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
              <option value = "09" <%if (now3.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
              <option value = "10" <%if (now3.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "11" <%if (now3.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
              <option value = "12" <%if (now3.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
            </select>
            / 
            <select name="Year">
              <option value="2003" selected>2546</option>
              <option value="2004">2547</option>
              <option value="2005">2548</option>
            </select>
            <select name="hour">
				<option value = "09:00:00"> 9.00 - 12.00 �.</option>
				<option value = "13:00:00">13.00 - 16.00 �.</option>
            </select>
          </div>
        </td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ����ͧ��é���մ��� :</div></td>
        <td><div align="left"> 
			<%now2.setTime(now.getTime()+1000*20*60*60*24);%>
            <select name="Date1">
              <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
              <option value = "<%=i%>" <% if ( i == now2.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
              <%
				}
		%>
            </select>
            / 
            <select name="Month1">
              <option value = "01" <%if (now2.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "02" <%if (now2.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
              <option value = "03" <%if (now2.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
              <option value = "04" <%if (now2.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
              <option value = "05" <%if (now2.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
              <option value = "06" <%if (now2.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
              <option value = "07" <%if (now2.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
              <option value = "08" <%if (now2.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
              <option value = "09" <%if (now2.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
              <option value = "10" <%if (now2.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "11" <%if (now2.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
              <option value = "12" <%if (now2.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
            </select>
            / 
            <select name="Year1">
              <option value="2003" selected>2546</option>
              <option value="2004">2547</option>
              <option value="2005">2548</option>
            </select>
			</div></td>
      </tr>
      <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
      <tr> 
        <td colspan="3"><div align="center"><input type="submit" name="Submit" value="�ͧ"></div></td>
      </tr>
    </table>
		<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
		<input type = "hidden" name = "Photo_Contact_ID" value = "<%=Photo_Contact_ID%>">
		<input type = "hidden" name = "Photo_Job_ID" value = "<%=Photo_Job_ID%>">
		<input type = "hidden" name = "Type_ID" value = "<%=Type_ID%>">
		<input type = "hidden" name = "SubType_Name" value = "<%=SubType_Name%>">
		<input type = "hidden" name = "SubType_ID" value = "<%=SubType_ID%>">
		<input type = "hidden" name = "SubType_Detail" value = "<%=SubType_Detail%>">
		<input type = "hidden" name = "Price" value = "<%=Price%>">
        <input type = "hidden" name= "Photo_ID" value = "<%=Photo_ID%>">
        <input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
    </form>
  <p>&nbsp;</p>
</center>
</body>
</html>