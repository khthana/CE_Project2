<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874" language="java"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>

</head>

<body bgcolor="F9F9EF">
<% int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));
	String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("Photo_Contact_ID");
	int Photo_Contact_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Photo_Job_ID");
	int Photo_Job_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Photo_Name");
	String Photo_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("Photo_ID");
	int Photo_ID = Integer.parseInt(tempstr);
	tempstr = (String)request.getParameter("Sub_Type_Name");
	String Sub_Type_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");
	tempstr = (String)request.getParameter("ReceiveDate");
	String ReceiveDate = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	tempstr = (String)request.getParameter("Type_ID");
	String type_id = new String(tempstr.getBytes("ISO8859_1"),"MS874");
    StringTokenizer strtoken = new StringTokenizer(type_id," ");
    int Type_ID = Integer.parseInt(strtoken.nextToken());

	tempstr = (String)request.getParameter("Type_Name");
	String Type_Name = new String(tempstr.getBytes("ISO8859_1"),"MS874");

	if (Type_ID ==1){
		//org.openuri.www.JobInStudioDetail photo_ShowJobInfo_InStudio(int photoID, int contactID, int jobID)
		org.openuri.www.JobInStudioDetail detail = PhotosoapProxy.photo_ShowJobInfo_InStudio(Photo_ID,Photo_Contact_ID,Photo_Job_ID);
		if (detail != null){%>
		<center>
<table width = "80%" align = "center" border = 1 bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ��ҹ�����Ҿ�ʵٴ���</div></td>
      </tr>
      <tr> 
        <td><div align="center">1.</div></td>
        <td><div align="left" >���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=detail.getSubTypeName()%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=detail.getSubTypeDetail()%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ���ͧ :</div></td>
        <td><div align="left">
					<%
							String temp = "";
							int day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = detail.getReserveDate().toCharArray();
							for(int j = 0;  j < detail.getReserveDate().length(); j++)
							{
									if((temp_date[j] == ' ')||(temp_date[j]=='/'))
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
		</div></td></tr>
      <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">���ҷ��ͧ :</div></td>
        <td><div align="left"><%=detail.getRound()%>�.</div></td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">��Һ�ԡ�� :</div></td>
        <td><div align="left"><%=detail.getPrice()%>&nbsp;�ҷ</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
</table>
</center>
<div align="center">
  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditPhotoInStudio.jsp">
<%
	type_id = new String(detail.getTypeID().getBytes("ISO8859_1"),"MS874");
    strtoken = new StringTokenizer(type_id," ");
    Type_ID = Integer.parseInt(strtoken.nextToken());
	String subtype_id = new String(detail.getSubTypeID().getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(strtoken.nextToken());
	%>
          <div align="right">
			<input type="hidden" name ="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name ="Photo_Contact_ID" value="<%=Photo_Contact_ID%>">
			<input type="hidden" name ="Photo_Job_ID" value="<%=detail.getJobID()%>">
			<input type="hidden" name ="SubType_Name" value = "<%=detail.getSubTypeName()%>">
			<input type="hidden" name ="SubType_Detail" value = "<%=detail.getSubTypeDetail()%>">
			<input type="hidden" name ="ReserveDate" value = "<%=detail.getReserveDate()%>">
			<input type="hidden" name ="Round" value = "<%=detail.getRound()%>">
			<input type="hidden" name ="SubType_ID" value = "<%=SubType_ID%>">
			<input type="hidden" name ="Type_ID" value = "<%=Type_ID%>">
			<input type="hidden" name ="Price" value="<%=detail.getPrice()%>">
			<input type="hidden" name ="Photo_Name" value ="<%=Photo_Name%>">
			<input type="hidden" name ="Photo_ID" value = "<%=Photo_ID%>">
			<input type="submit" name ="Submit" value="Edit">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelPhotoJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Photo_Contact_ID" value="<%=Photo_Contact_ID%>">
			<input type="hidden" name="Photo_Job_ID" value="<%=Photo_Job_ID%>">
          <input type="submit" name="Submit2" value="Cancel">
        </form></td>
    </tr>
  </table>
  <!----------------------------------------------------------------Edit Photo outstudio------------------------------------------------------------->
  <%}	}else if ((Type_ID ==3)||(Type_ID ==5)){
			//org.openuri.www.JobInStudioDetail photo_ShowJobInfo_OutStudio(int photoID, int contactID, int jobID)
			org.openuri.www.JobInStudioDetail detail1 = PhotosoapProxy.photo_ShowJobInfo_OutStudio(Photo_ID,Photo_Contact_ID,Photo_Job_ID);
			if (detail1 != null){%>
			<center>
    <table width="80%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ��ҹ�����Ҿ�͡ʵٴ���</div></td>
      </tr>
      <tr> 
        <td><div align="center">1.</div></td>
        <td><div align="left">���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=detail1.getSubTypeName()%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=detail1.getSubTypeDetail()%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ���ͧ :</div></td>
        <td><div align="left">
					<%=detail1.getReserveDate()%>
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">�ӹǹ������� :</div></td>
        <td><div align="left">
		<%
			String subtype_id = new String(detail1.getSubTypeID().getBytes("ISO8859_1"),"MS874");
			strtoken = new StringTokenizer(subtype_id," ");
			int SubType_ID = Integer.parseInt(strtoken.nextToken());
		  String hour = null;
		  if (SubType_ID == 1){
		  hour = "4 �������";
		  }else if (SubType_ID == 2){
			  hour = "8 �������";
		  }else {
			  hour = "12 �������";}%>
		&nbsp;<%=hour%>;
        </div></td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">���� :</div></td>
        <td><div align="left"><%=detail1.getRound()%> &nbsp;�.</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">��Һ�ԡ�� :</div></td>
        <td><div align="left"><%=detail1.getPrice()%>&nbsp;�ҷ</div></td>
      </tr>
      <tr> 
        <td><div align="center">8.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
    </table>
	</center>
<div align="center">
  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditPhotooutStudio.jsp">
<%
	type_id = new String(detail1.getTypeID().getBytes("ISO8859_1"),"MS874");
    strtoken = new StringTokenizer(type_id," ");
    Type_ID = Integer.parseInt(strtoken.nextToken());
	subtype_id = new String(detail1.getSubTypeID().getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	SubType_ID = Integer.parseInt(strtoken.nextToken());
	%>
          <div align="right">
			<input type ="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Photo_Contact_ID" value="<%=Photo_Contact_ID%>">
			<input type="hidden" name="Photo_Job_ID" value="<%=detail1.getJobID()%>">
			<input type="hidden" name = "SubType_Name" value = "<%=detail1.getSubTypeName()%>">
			<input type="hidden" name = "SubType_Detail" value = "<%=detail1.getSubTypeDetail()%>">
			<input type="hidden" name = "ReserveDate" value = "<%=detail1.getReserveDate()%>">
			<input type="hidden" name = "Round" value = "<%=detail1.getRound()%>">
			<input type="hidden" name = "SubType_ID" value = "<%=SubType_ID%>">
			<input type="hidden" name = "Type_ID" value = "<%=Type_ID%>">
			<input type="hidden" name="Price" value="<%=detail1.getPrice()%>">
			<input type="hidden" name="Photo_Name" value ="<%=Photo_Name%>">
		  	<input type="hidden" name = "Photo_ID" value = "<%=Photo_ID%>">
			<input type="submit" name="Submit" value="Edit">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelPhotoJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Photo_Contact_ID" value="<%=Photo_Contact_ID%>">
			<input type="hidden" name="Photo_Job_ID" value="<%=Photo_Job_ID%>">
          <input type="submit" name="Submit2" value="Cancel">
        </form></td>
    </tr>
  </table>
 <!-------------------------------------------------------Show job Multimedia---------------------------------------------------------------------->
<%}}else {
	org.openuri.www.JobMultiDetail detail2 = PhotosoapProxy.photo_ShowJobInfo_Multi(Photo_ID,Photo_Contact_ID,Photo_Job_ID);
	//org.openuri.www.JobMultiDetail photo_ShowJobInfo_Multi(int photoID, int contactID, int jobID)
	if (detail2 != null){%>
	<center>
	    <table width="80%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ��ҹ�����Ҿ��ŵ������</div></td>
      </tr>
      <tr> 
        <td><div align="center">1.</div></td>
        <td><div align="left">���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=detail2.getSubTypeName()%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=detail2.getSubTypeDetail()%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">�ѹ���ͧ :</div></td>
        <td><div align="left">
					<%
							String temp = "";
							int day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = "";
							int minute1 = 0;
							String minute = "";
							char[] temp_date =detail2.getReserveDate().toCharArray();
							for(int j = 0;  j < detail2.getReserveDate().length(); j++)
							{
									if(temp_date[j] == ' ' || temp_date[j] == ':' || temp_date[j] =='/')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">�ѹ����ͧ��é���մ��� :</div></td>
        <td><div align="left"> 
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							temp_date = detail2.getFinishDate().toCharArray();
							for(int j = 0;  j < detail2.getFinishDate().length(); j++)
							{
									if((temp_date[j] == ' ')||(temp_date[j] == '/'))
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
			</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">��Һ�ԡ�� :</div></td>
        <td><div align="left"><%=detail2.getPrice()%>&nbsp;�ҷ</div></td>
      </tr>
      <tr> 
        <td><div align="center">8.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
    </table>
	</center>
	<!-----------------------------------------------------------------------Edit Photo multi--------->
<center>
  <table width="75%" border="0">
    <tr>
      <td><form name="form1" method="post" action="./EditPhotoMulti.jsp">
          <div align="right">
<%
	type_id = new String(detail2.getTypeID().getBytes("ISO8859_1"),"MS874");
    strtoken = new StringTokenizer(type_id," ");
    Type_ID = Integer.parseInt(strtoken.nextToken());
	String subtype_id = new String(detail2.getSubTypeID().getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(strtoken.nextToken());
	%>
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Photo_Contact_ID" value="<%=Photo_Contact_ID%>">
			<input type="hidden" name="Photo_Job_ID" value="<%=detail2.getJobID()%>">
			<input type="hidden" name="SubType_Name" value = "<%=detail2.getSubTypeName()%>">
			<input type="hidden" name="SubType_Detail" value = "<%=detail2.getSubTypeDetail()%>">
			<input type="hidden" name="ReserveDate" value = "<%=detail2.getReserveDate()%>">
			<input type="hidden" name="FinishDate" value = "<%=detail2.getFinishDate()%>">
			<input type="hidden" name="SubType_ID" value = "<%=SubType_ID%>">
			<input type="hidden" name="Type_ID" value = "<%=Type_ID%>">
			<input type="hidden" name="Price" value="<%=detail2.getPrice()%>">
			<input type="hidden" name="Photo_Name" value ="<%=Photo_Name%>">
			<input type="hidden" name="Photo_ID" value = "<%=Photo_ID%>">
			<input type="submit" name="Submit" value="Edit">
          </div>
        </form></td>
      <td><form name="form2" method="post" action="./CancelPhotoJob.jsp">
			<input type="hidden" name="Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
			<input type="hidden" name="Photo_Contact_ID" value="<%=Photo_Contact_ID%>">
			<input type="hidden" name="Photo_Job_ID" value="<%=Photo_Job_ID%>">
          <input type="submit" name="Submit2" value="Cancel">
        </form></td>
    </tr>
  </table>
	</center>
<%}}%>
  <p>&nbsp;</p>
</div>
</body>
</html>