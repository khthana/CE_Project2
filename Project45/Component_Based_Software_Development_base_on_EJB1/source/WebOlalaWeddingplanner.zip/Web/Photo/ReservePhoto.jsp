<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="java.util.*"%>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Reserve Photo</title>
</head>

<body bgcolor="F9F9EF">
<%
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

	Temp_Str = (String)request.getParameter("Photo_Name");
	String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

	Temp_Str = (String)request.getParameter("Photo_Address");
    String Photo_Address = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

    Temp_Str = (String)request.getParameter("Photo_Contact_ID");
    int Photo_Contact_ID = Integer.parseInt(Temp_Str);

	Temp_Str = request.getParameter("Type_Name");
	String Type_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

	Temp_Str = request.getParameter("SubType_Name");
	String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");

	StringTokenizer strtoken;
	Temp_Str = (String)request.getParameter("Type_ID");
	String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(type_id," ");
	int Type_ID = Integer.parseInt(strtoken.nextToken());

	Temp_Str = (String)request.getParameter("SubType_ID");
	String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(strtoken.nextToken());
		
	Temp_Str = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

	Temp_Str = (String)request.getParameter("Price");
	double Price = Double.parseDouble(Temp_Str);

	Temp_Str = (String)request.getParameter("Photo_ID");
	int Photo_ID = 0;
	if ((Type_ID == 3)||(Type_ID == 5)||(Type_ID == 6))
	{    Photo_ID = Integer.parseInt(Temp_Str);
	}

%>
<%Date now = new Date();
	Date now2 = new Date();%>
<%  
/*	public Date calIncDate( java.util.Date d1,int du ){
		Date d2;
		long x = 1000;
		x = x*du *60*60* 24;
	    return d2.setTime( d1.getTime()+1000*10*60*60*24);
	}*/
%>
<center>
<!----------------------------------------------------�ʵٴ���------------------------------------------------->
<%if (Type_ID == 1)
{%>
<form name="form1" method="post" action="./BookPhotoInStudio.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"> 
          <div align="center">��������´��èͧ��ҹ�����Ҿ�ʵٴ���</div>
        </td>
      </tr>
      <tr> 
        <td width="5%"> <div align="center">1.</div></td>
        <td width="47%"><div align="left">���� contact :</div></td>
        <td width="58%"><div align="left"><input type="text" name="Photo_Contact_Name" value = "Olala"></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ</div></td>
        <td><div align="left">
		<select name="Date">
		<%now2.setTime(now.getTime()+1000*10*60*60*24);%>
                <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
                <option value = "<%=i%>" <% if ( i == now2.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                <%
				}
		%>
              </select>
              /
              <select name="Month">
                <option value = "01" <%if (now2.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                <option value = "02" <%if (now2.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                <option value = "03" <%if (now2.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                <option value = "04" <%if (now2.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                <option value = "05" <%if (now2.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                <option value = "06" <%if (now2.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                <option value = "07" <%if (now2.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                <option value = "08" <%if (now2.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                <option value = "09" <%if (now2.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                <option value = "10" <%if (now2.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                <option value = "11" <%if (now2.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                <option value = "12" <%if (now2.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
              </select>
              /
              <select name="Year">
                <option value="2003" selected>2546</option>
                <option value="2004">2547</option>
                <option value="2005">2548</option>
              </select>
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">���� :</div></td>
        <td><div align="left">
              <select name="Round">
                <option value = "1"> 9.00 -11.00 �.</option>
                <option value = "2">10.00 -12.00 �.</option>
                <option value = "3">13.00 -15.00 �.</option>
                <option value = "4">14.00 -16.00 �.</option>
                <option value = "5">15.00 -17.00 �.</option>
                <option value = "6">16.00 -18.00 �.</option>
                <option value = "7">17.00 -19.00 �.</option>
                <option value = "8">18.00 -20.00 �.</option>
              </select>  &nbsp; 
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">8.</div></td>
        <td><div align="left">���������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Address%></div></td>
      </tr>
      <tr> 
        <td colspan="3"><div align="center"><input type="submit" name="Submit" value="�ͧ"></div></td>
      </tr>
    </table>
			<%
				if (Photo_Name.equals("Photo1")){
					Photo_ID = 1;
				}else if (Photo_Name.equals("Photo2")){
					Photo_ID = 2;
				}else if (Photo_Name.equals("Photo3")){
					Photo_ID = 3;
				}else if (Photo_Name.equals("Photo4")){
					Photo_ID = 4;
				}else if (Photo_Name.equals("Photo5")){
					Photo_ID = 5;
				}else if (Photo_Name.equals("Photo6")){
					Photo_ID = 6;
				}else if (Photo_Name.equals("Photo7")){
					Photo_ID = 7;
				}else if (Photo_Name.equals("Photo8")){
					Photo_ID = 8;
				}else if (Photo_Name.equals("Photo9")){
					Photo_ID = 9;
				}else if (Photo_Name.equals("Photo10")){
					Photo_ID = 10;
				}
			%>
      <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
      <input type = "hidden" name = "Photo_Contact_ID" value = "<%=Photo_Contact_ID%>">
      <input type = "hidden" name = "Type_ID" value = "<%=Type_ID%>">
      <input type = "hidden" name = "Type_Name" value = "<%=Type_Name%>">
      <input type = "hidden" name = "SubType_Name" value = "<%=SubType_Name%>">
      <input type = "hidden" name = "SubType_ID" value = "<%=SubType_ID%>">
      <input type = "hidden" name = "SubType_Detail" value = "<%=SubType_Detail%>">
      <input type = "hidden" name = "Price" value = "<%=Price%>">
        <input type = "hidden" name= "Photo_ID" value = "<%=Photo_ID%>">
        <input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
        <input type = "hidden" name = "Photo_Address" value = "<%=Photo_Address%>">
    </form>
<%}
//--------------------------------------------------�͡ʵٴ���-----------------------------------------------
	else if ((Type_ID == 3)||(Type_ID == 5))
{%>
<form name="form2" method="post" action="./BookPhotoOutStudio.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"> 
          <div align="center">��������´��èͧ��ҹ�����Ҿ�͡ʵٴ���</div>
        </td>
      </tr>
      <tr> 
        <td width="5%"> <div align="center">1.</div></td>
        <td width="47%"><div align="left">���� contact :</div></td>
        <td width="55%"><div align="left"><input type="text" name="Photo_Contact_Name" value = "Olala"></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ :</div></td>
        <td><div align="left">
		<select name="Date">
		<%now2.setTime(now.getTime()+1000*10*60*60*24);%>
                <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
                <option value = "<%=i%>" <% if ( i == now2.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
                <%
				}
		%>
              </select>
              /
              <select name="Month">
                <option value = "01" <%if (now2.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
                <option value = "02" <%if (now2.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
                <option value = "03" <%if (now2.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
                <option value = "04" <%if (now2.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
                <option value = "05" <%if (now2.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
                <option value = "06" <%if (now2.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
                <option value = "07" <%if (now2.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
                <option value = "08" <%if (now2.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
                <option value = "09" <%if (now2.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
                <option value = "10" <%if (now2.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
                <option value = "11" <%if (now2.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
                <option value = "12" <%if (now2.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
              </select>
              /
              <select name="Year">
                <option value="2003" selected>2546</option>
                <option value="2004">2547</option>
                <option value="2005">2548</option>
              </select>
		</div></td>
      </tr>
      <tr> 
        <td ><div align="center">6.</div></td>
        <td><div align="left">�ӹǹ������� :</div></td>
        <td><div align="left">
		<%
		  String hour = null;
		  if (SubType_ID == 1){
		  hour = "4 �������";
		  }else if (SubType_ID == 2){
			  hour = "8 �������";
		  }else {
			  hour = "12 �������";}%><%=hour%>
        </div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">���� :</div></td>
        <td><div align="left">
		<% if (SubType_ID == 1){%>
                  <select name="Hour">
				  	<option value = "1" > 8.00 - 12.00 �.</option>
				  	<option value = "2" >13.00 - 17.00 �.</option>
				  	<option value = "3" >18.00 - 22.00 �.</option>
                  </select>			
		  <%}else if (SubType_ID == 2){%>
                  <select name="Hour">
				  	<option value = "4" > 8.00 - 17.00 �.</option>
				  	<option value = "5" >13.00 - 22.00 �.</option>
                  </select>
            <%}else {%>
            8.00 - 22.00 �.&nbsp; 
            <%}%>
          </div>
        </td>
      </tr>
          <!--  <table width="85%" border="0">
              <tr>
                <td width="55%">
<input type="radio" name="Hour" value="4" checked>&nbsp;4 �������</td>
                <td width="48%"> 
                  <select name="FourHour">
				  	<option value = "1" > 8.00 - 12.00 �.</option>
				  	<option value = "2" >13.00 - 17.00 �.</option>
				  	<option value = "3" >18.00 - 22.00 �.</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td width="55%">
<input type="radio" name="Hour" value="8">&nbsp;8 �������</td>
                <td width="48%"> 
                  <select name="EightHour">
				  	<option value = "4" > 8.00 - 17.00 �.</option>
				  	<option value = "5" >13.00 - 22.00 �.</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td width="55%"><input type="radio" name="Hour" value="12">&nbsp;12 �������</td>
                <td width="48%">8.00 - 22.00 �.</td>
              </tr>
            </table>
          </div>
        </td>
      </tr>-->
      <tr> 
        <td><div align="center">8.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">9.</div></td>
        <td><div align="left">���������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Address%></div></td>
      </tr>
      <tr> 
        <td colspan="3"><div align="center"><input type="submit" name="Submit" value="�ͧ"></div></td>
      </tr>
    </table>
      <input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
      <input type = "hidden" name = "Photo_Contact_ID" value = "<%=Photo_Contact_ID%>">
      <input type = "hidden" name = "Type_ID" value = "<%=Type_ID%>">
      <input type = "hidden" name = "Type_Name" value = "<%=Type_Name%>">
      <input type = "hidden" name = "SubType_Name" value = "<%=SubType_Name%>">
      <input type = "hidden" name = "SubType_ID" value = "<%=SubType_ID%>">
      <input type = "hidden" name = "SubType_Detail" value = "<%=SubType_Detail%>">
      <input type = "hidden" name = "Price" value = "<%=Price%>">
        <input type = "hidden" name= "Photo_ID" value = "<%=Photo_ID%>">
        <input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
        <input type = "hidden" name = "Photo_Address" value = "<%=Photo_Address%>">
    </form>
    <%}
//-------------------------------------��ԡ�����ҧ�մ��� ��ŵ������ ���ૹ൪��----------------------------------------------------------
	else if (Type_ID == 6)
{%>
<form name="form3" method="post" action="./BookPhotoPresent.jsp">
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"> 
          <div align="center">��������´��èͧᾤࡨ���¢ͧ��ԡ�����ҧ�մ��� ��ŵ������ 
            ���ૹ൪��</div>
        </td>
      </tr>
      <tr> 
        <td width="5%"><div align="center">1.</div></td>
        <td width="40%"><div align="left">���� contact :</div></td>
        <td width="60%">
          <div align="left">
            <input type="text" name="Photo_Contact_Name" value = "Olala">
          </div>
        </td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr> 
        <td ><div align="center">5.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ :</div></td>
        <td><div align="left"> 
            <select name="Date">
              <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
              <option value = "<%=i%>" <% if ( i == now.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
              <%
				}
		%>
            </select>
            / 
            <select name="Month">
              <option value = "01" <%if (now.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "02" <%if (now.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
              <option value = "03" <%if (now.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
              <option value = "04" <%if (now.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
              <option value = "05" <%if (now.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
              <option value = "06" <%if (now.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
              <option value = "07" <%if (now.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
              <option value = "08" <%if (now.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
              <option value = "09" <%if (now.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
              <option value = "10" <%if (now.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "11" <%if (now.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
              <option value = "12" <%if (now.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
            </select>
            / 
            <select name="Year">
              <option value="2003" selected>2546</option>
              <option value="2004">2547</option>
              <option value="2005">2548</option>
            </select>
            <select name="hour">
				<option value = "09:00:00"> 9.00 - 12.00 �.</option>
				<option value = "13:00:00">13.00 - 16.00 �.</option>
            </select>
          </div>
        </td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">�ѹ����ͧ��é���մ��� :</div></td>
        <td><div align="left"> 
			<%now2.setTime(now.getTime()+1000*10*60*60*24);%>
            <select name="Date1">
              <%
				for (int i = 1 ; i <= 31 ; i ++) {
				%>
              <option value = "<%=i%>" <% if ( i == now2.getDate()) { %> <%="selected"%> <%}%>><%=i%></option>
              <%
				}
		%>
            </select>
            / 
            <select name="Month1">
              <option value = "01" <%if (now2.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "02" <%if (now2.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
              <option value = "03" <%if (now2.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
              <option value = "04" <%if (now2.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
              <option value = "05" <%if (now2.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
              <option value = "06" <%if (now2.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
              <option value = "07" <%if (now2.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
              <option value = "08" <%if (now2.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
              <option value = "09" <%if (now2.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
              <option value = "10" <%if (now2.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
              <option value = "11" <%if (now2.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
              <option value = "12" <%if (now2.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
            </select>
            / 
            <select name="Year1">
              <option value="2003" selected>2546</option>
              <option value="2004">2547</option>
              <option value="2005">2548</option>
            </select>
			</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">8.</div></td>
        <td><div align="left">���������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Address%></div></td>
      </tr>
      <tr> 
        <td colspan="3"><div align="center"><input type="submit" name="Submit" value="�ͧ"></div></td>
      </tr>
    </table>
      
<input type = "hidden" name = "Wedding_Contact_ID" value = "<%=Wedding_Contact_ID%>">
      <input type = "hidden" name = "Photo_Contact_ID" value = "<%=Photo_Contact_ID%>">
      <input type = "hidden" name = "Type_ID" value = "<%=Type_ID%>">
      <input type = "hidden" name = "Type_Name" value = "<%=Type_Name%>">
      <input type = "hidden" name = "SubType_Name" value = "<%=SubType_Name%>">
      <input type = "hidden" name = "SubType_ID" value = "<%=SubType_ID%>">
      <input type = "hidden" name = "SubType_Detail" value = "<%=SubType_Detail%>">
      <input type = "hidden" name = "Price" value = "<%=Price%>">
        <input type = "hidden" name= "Photo_ID" value = "<%=Photo_ID%>">
        <input type = "hidden" name = "Photo_Name" value = "<%=Photo_Name%>">
        <input type = "hidden" name = "Photo_Address" value = "<%=Photo_Address%>">
    </form>
	<%}%>
  <p>&nbsp;</p>
</center>
</body>
</html>