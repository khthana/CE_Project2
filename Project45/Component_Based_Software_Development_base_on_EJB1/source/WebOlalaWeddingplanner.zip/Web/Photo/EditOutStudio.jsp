<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Edit Photo Out Stuidio</title>
</head>

<body bgcolor="F9F9EF">
<%
    int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));
    String Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Contact_ID");
	int Photo_Contact_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Job_ID");
	int Photo_Job_ID = Integer.parseInt(Temp_Str);
	StringTokenizer strtoken;
	Temp_Str = (String)request.getParameter("Type_ID");
//	String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
//	strtoken = new StringTokenizer(type_id," ");
	int Type_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("SubType_ID");
//	String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
//	strtoken = new StringTokenizer(subtype_id," ");
	int SubType_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("SubType_Name");
	String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("SubType_Detail");
	String SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Price");
	double Price = Double.parseDouble(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_ID");
	int Photo_ID = Integer.parseInt(Temp_Str);
	Temp_Str = (String)request.getParameter("Photo_Name");
	String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
	Temp_Str = (String)request.getParameter("Round");
	int Round = Integer.parseInt(Temp_Str);

	String day2 = request.getParameter("day1");
	String month2 = request.getParameter("month1");
	String year2 = request.getParameter("year1");
	String reserveDate = day2 + " " + month2 + " " + year2;
		boolean result = PhotosoapProxy.photo_EditReserve_OutStudio(Wedding_Contact_ID,Photo_Contact_ID,Photo_Job_ID,reserveDate,Round);
		//boolean photo_EditReserve_OutStudio(int weddingContactID, int contactID, int jobID, java.lang.String reserveDate, int round)
		if (result == true)
		{%>
			<p>&nbsp;</p>
			<center>�������������
			<p>&nbsp;</p>
			<a href = "../ShowContact.jsp">˹���á</a></center>
		<%	}
		else
		{
%>
<center>
    <table width="75%" border="1" bordercolor="#CCCCCC">
      <tr bordercolor="#CCCCCC" bgcolor="#FFCCFF">
        <td colspan="3"><div align="center">��������´��������ҹ�����Ҿ</div></td>
      </tr>
      <tr>
        <td width="5%"><div align="center">1.</div></td>
        <td width="47%"><div align="left">����ᾤࡨ���� :</div></td>
        <td width="48%"> <div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr>
        <td><div align="center">2.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr>
        <td><div align="left">3.</div></td>
        <td><div align="left">�ѹ����ͧ��èͧ :</div></td>
        <td><div align="left">
					<%
							String temp = "";
							int day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = reserveDate.toCharArray();
							for(int j = 0;  j < reserveDate.length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;
		</div></td>
      </tr>
      <tr>
        <td><div align="center">4.</div></td>
        <td><div align="left">�ӹǹ������� :</div></td>
        <td><div align="left">
		<%
		  String hour = null;
		  if (SubType_ID == 1){
		  hour = "4 �������";
		  }else if (SubType_ID == 2){
			  hour = "8 �������";
		  }else {
			  hour = "12 �������";}%>
		&nbsp;<%=hour%>
		</div></td>
      </tr>
      <tr>
        <td><div align="left">5.</div></td>
        <td><div align="left">���� :</div></td>
        <td><div align="left">
          <%
				  String round = null;
				  switch(Round){
				  case (1):round = "9.00 -11.00 �.";
				  case (2):round = "10.00 -12.00 �.";
				  case (3):round = "13.00 -15.00 �.";
				  case (4):round = "14.00 -16.00 �.";
				  case (5):round = "15.00 -17.00 �.";
				  case (6):round = "16.00 -18.00 �.";
				  case (7):round = "17.00 -19.00 �.";
				  case (8):round = "18.00 -20.00 �.";
              }%><%=round%>
		</div></td>
      </tr>
      <tr>
        <td><div align="center">6.</div></td>
        <td><div align="left">�Ҥ� :</div></td>
        <td><div align="left"><%=Price%>&nbsp;�ҷ</div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
    </table>
<p>&nbsp;</p>
<a href = "../ShowContact.jsp">˹���á</a>
	  <%}%>
</center>
</body>
</html>