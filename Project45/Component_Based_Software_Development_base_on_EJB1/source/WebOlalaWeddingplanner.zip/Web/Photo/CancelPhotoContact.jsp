<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head><title>Olala Wedding Planner : Cancel Photo Contact</title></head>

<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Photo_Contact_ID");
    int Photo_Contact_ID = 0;
    if (tempstr != null)
    {
      Photo_Contact_ID = Integer.parseInt(tempstr);
      boolean cancel = PhotosoapProxy.photo_CancelContact(Photo_Contact_ID,Wedding_Contact_ID);
      response.sendRedirect("../ShowContact.jsp");
    }
    else response.sendRedirect("../Main.htm");
	%>
</body>
</html>