<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body  bgcolor="F9F9EF">
<%
                String Temp_Str = null;
                int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

                Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
                int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Photo_Contact_ID");
				int Photo_Contact_ID = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Photo_Contact_Name");
				String Photo_Contact_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

				Temp_Str  = (String)request.getParameter("Type_ID");
				String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				StringTokenizer strtoken = new StringTokenizer(type_id," ");
				int Type_ID = Integer.parseInt(strtoken.nextToken());

				Temp_Str = (String)request.getParameter("Round");
				int Round = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Date");
				String date3 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				Temp_Str = (String)request.getParameter("Month");
				String month3 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				Temp_Str = (String)request.getParameter("Year");
				String year3 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				Temp_Str = (String)request.getParameter("Type_Name");
				String Type_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("SubType_Name");
				String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("SubType_ID");
				String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				strtoken = new StringTokenizer(subtype_id," ");
				int SubType_ID = Integer.parseInt(strtoken.nextToken());
				Temp_Str = (String)request.getParameter("SubType_Detail");
				String  SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("Price");
				double Price = Double.parseDouble(Temp_Str);
				Temp_Str = (String)request.getParameter("Photo_ID");
				int Photo_ID = Integer.parseInt(Temp_Str);
				Temp_Str = (String)request.getParameter("Photo_Name");
				String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("Photo_Address");
				String Photo_Address = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				if (date3.length() ==  1)
					date3 = "0" +date3;
				String reserveDate = date3+" "+month3+" "+year3;

				boolean create = false;
				if (Photo_Contact_ID == 0)
				{
					Photo_Contact_ID = PhotosoapProxy.photo_CreateContactID(Photo_ID,Photo_Contact_Name,Wedding_Contact_ID,Customer_ID);
					create = true;
				}

//double photo_ReserveInStudio(int photoID, int weddingContactID, java.lang.String typeID, java.lang.String subtypeID, java.lang.String reserveDate, int round)
                double price = PhotosoapProxy.photo_ReserveInStudio(Photo_ID,Wedding_Contact_ID,type_id,subtype_id,reserveDate,Round);
//Customer_ID, Wedding_Contact_ID, Entertain_Contact_ID, Band_ID, Type_ID, Start_Datetime, Finish_Datetime, Place, Function_Type, Price_AM, Price_PM, Additional_Requests, Entertainment_ID, Entertain_Contact_Name);
				if ((price == 0.0)&&(create == true))
                   {
						boolean cancel = PhotosoapProxy.photo_CancelContact(Photo_Contact_ID,Wedding_Contact_ID);%>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<center>�������ö�ͧ��</center>
<center><a href = "../ShowJob.jsp#photo">��Ѻ�˹���ʴ���������´ 				   <%}else if (price == 0.0)
				   {%>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<center>�������ö�ͧ��</center>
<center><a href = "../ShowJob.jsp#photo">��Ѻ�˹���ʴ���������´ <% } else {%>
<table width = "80%" align = "center" border = 1 bordercolor="#CCCCCC">
<tr bgcolor="#FFCCFF"><td align = "">���� Contact :</td><td align = "center"><%=Photo_Contact_Name%></td></tr>
<tr><td align = "">���ͻ�����ᾤࡨ :</td><td align = "center"><%=Type_Name%></td></tr>
<tr><td align = "">����ᾤࡨ���� :</td><td align = "center"><%=SubType_Name%></td></tr>
<tr><td align = "">��������´ :</td><td align = "center"><%=SubType_Detail%></td></tr>
<tr><td align = "">�ѹ���ͧ :</td><td align = "center">
					<%
							String temp = "";
							int day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = reserveDate.toCharArray();
							for(int j = 0;  j < reserveDate.length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
</td></tr>
<tr><td align = "">���ҷ��ͧ :</td><td align = "center">
		<%String round = null;
		switch (Round){
		case (1):round = "9.00 -11.00 �.";break;
		case (2):round = "10.00 -12.00 �.";break;
		case (3):round = "13.00 -15.00 �.";break;
		case (4):round = "14.00 -16.00 �.";break;
		case (5):round = "15.00 -17.00 �.";break;
		case (6):round = "16.00 -18.00 �.";break;
		case (7):round = "17.00 -19.00 �.";break;
		case (8):round = "18.00 -20.00 �.";break;
		}%><%=round%>
</td></tr>
<tr><td align = "">��Һ�ԡ�� :</td><td align = "center"><%=price%> �ҷ</td></tr>
<tr><td align = "">������ҹ�����Ҿ :</td><td align = "center"><%=Photo_Name%></td></tr>
<tr><td align = "">���������ҹ�����Ҿ :</td><td align = "center"><%=Photo_Address%></td></tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<center>��èͧ���º��������</center>
<center><a href = "../ShowJob.jsp#photo">��Ѻ�˹���ʴ���������´ 		<%} %>
</body>
</html>