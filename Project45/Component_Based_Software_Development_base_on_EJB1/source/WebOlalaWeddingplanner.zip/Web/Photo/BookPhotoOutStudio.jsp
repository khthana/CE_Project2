<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%@ page import="org.openuri.www.*"%>
<%@ page import = "org.openuri.www.EntertainResultReserve"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner</title>
</head>

<body  bgcolor="F9F9EF">
<%
                String Temp_Str = null;
                int Customer_ID = Integer.parseInt((String)session.getAttribute("Customer_ID"));

                Temp_Str = (String)request.getParameter("Wedding_Contact_ID");
                int Wedding_Contact_ID = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Photo_Contact_ID");
				int Photo_Contact_ID = Integer.parseInt(Temp_Str);

				Temp_Str = (String)request.getParameter("Photo_Contact_Name");
				String Photo_Contact_Name = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");

				Temp_Str  = (String)request.getParameter("Type_ID");
				String type_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				StringTokenizer strtoken = new StringTokenizer(type_id," ");
				int Type_ID = Integer.parseInt(strtoken.nextToken());

				Temp_Str = (String)request.getParameter("Date");
				String date3 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				Temp_Str = (String)request.getParameter("Month");
				String month3 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				Temp_Str = (String)request.getParameter("Year");
				String year3 = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				Temp_Str = (String)request.getParameter("Type_Name");
				String Type_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("SubType_Name");
				String SubType_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("SubType_ID");
				String subtype_id = new String(Temp_Str.getBytes("ISO8859_1"),"MS874");
				strtoken = new StringTokenizer(subtype_id," ");
				int SubType_ID = Integer.parseInt(strtoken.nextToken());
				Temp_Str = (String)request.getParameter("SubType_Detail");
				String  SubType_Detail = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("Price");
				double Price = Double.parseDouble(Temp_Str);
				Temp_Str = (String)request.getParameter("Photo_ID");
				int Photo_ID = Integer.parseInt(Temp_Str);
				Temp_Str = (String)request.getParameter("Photo_Name");
				String Photo_Name = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				Temp_Str = (String)request.getParameter("Photo_Address");
				String Photo_Address = new String(Temp_Str.getBytes("ISO8859_1") , "MS874");
				if (date3.length() ==  1)
					date3 = "0" +date3;
				String reserveDate = date3+" "+month3+" "+year3;
				Temp_Str = (String)request.getParameter("Hour");
				int Hour = Integer.parseInt(Temp_Str);
				boolean create = false;
				if (Photo_Contact_ID == 0)
				{
					Photo_Contact_ID = PhotosoapProxy.photo_CreateContactID(Photo_ID,Photo_Contact_Name,Wedding_Contact_ID,Customer_ID);
					create = true;
				}
				//int photo_CreateContactID(int photoID, java.lang.String contactName, int weddingContactID, int custID)
//double photo_ReserveOutStudio(int photoID, int weddingContactID, java.lang.String typeID, java.lang.String subtypeID, java.lang.String reserveDate, int round)
                double price = PhotosoapProxy.photo_ReserveOutStudio(Photo_ID,Wedding_Contact_ID,type_id,subtype_id,reserveDate,Hour);
				if ((price == 0.0)&&(create == true))
                   {
						boolean cancel = PhotosoapProxy.photo_CancelContact(Photo_Contact_ID,Wedding_Contact_ID);%>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#photo">��Ѻ�˹���ʴ���������´ contact</a></center>
				   <%}else if (price == 0.0)
				   {%>
						<p>&nbsp;</p>
						<p>&nbsp;</p>
						<center>�������ö�ͧ��</center>
			<center><a href = "../ShowJob.jsp#photo">��Ѻ�˹���ʴ���������´ contact</a></center>
<% } else {%>
    <table width="80%" border="1" bordercolor="#CCCCCC">
      <tr bgcolor="#FFCCFF"> 
        <td colspan="3"><div align="center">��������´��èͧ��ҹ�����Ҿ�͡ʵٴ���</div></td>
      </tr>
      <tr> 
        <td width="5%"> <div align="center">1.</div></td>
        <td width="47%"><div align="left">���� contact :</div></td>
        <td width="55%"><div align="left"><%=Photo_Contact_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">2.</div></td>
        <td><div align="left">���ͻ�����ᾤࡨ :</div></td>
        <td><div align="left"><%=Type_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">3.</div></td>
        <td><div align="left">����ᾤࡨ���� :</div></td>
        <td><div align="left"><%=SubType_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">4.</div></td>
        <td><div align="left">��������´ :</div></td>
        <td><div align="left"><%=SubType_Detail%></div></td>
      </tr>
      <tr> 
        <td><div align="center">5.</div></td>
        <td><div align="left">�ѹ���ͧ :</div></td>
        <td><div align="left">
					<%
							String temp = "";
							int day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = reserveDate.toCharArray();
							for(int j = 0;  j < reserveDate.length(); j++)
							{
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
		</div></td>
      </tr>
      <tr> 
        <td><div align="center">6.</div></td>
        <td><div align="left">�ӹǹ������� :</div></td>
        <td><div align="left">
		<%
		  String hour = null;
		  if (SubType_ID == 1){
		  hour = "4 �������";
		  }else if (SubType_ID == 2){
			  hour = "8 �������";
		  }else {
			  hour = "12 �������";}%>
		&nbsp;<%=hour%>;
        </div></td>
      </tr>
      <tr> 
        <td><div align="center">7.</div></td>
        <td><div align="left">���� :</div></td>
        <td><div align="left">
		<%
		  String hour1 = null;
		switch (Hour){
			case (1):hour1 = "8.00 - 12.00 �.";break;
			case (2):hour1 ="13.00 - 17.00 �.";break;
			case (3):hour1 = "18.00 - 22.00 �.";break;
			case (4):hour1 = "8.00 - 17.00 �.";break;
			case (5):hour1 = "13.00 - 22.00 �.";break;
			case (6):hour1 = "8.00 - 22.00 �.";break;
		}%><%=hour1%>
        </div></td>
      </tr>
      <tr> 
        <td><div align="center">8.</div></td>
        <td><div align="left">������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Name%></div></td>
      </tr>
      <tr> 
        <td><div align="center">9.</div></td>
        <td><div align="left">���������ҹ�����Ҿ :</div></td>
        <td><div align="left"><%=Photo_Address%></div></td>
      </tr>
    </table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<center>��èͧ���º��������</center>
			<center><a href = "../ShowJob.jsp#photo">��Ѻ�˹���ʴ���������´ contact</a></center>
		<%} %>
</body>
</html>