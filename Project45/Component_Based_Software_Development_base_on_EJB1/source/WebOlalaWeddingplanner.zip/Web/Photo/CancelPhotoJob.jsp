<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType = "text/html;charset=WINDOWS-874"%>
<%OlalaPhoto_Impl proxyPhoto = new OlalaPhoto_Impl();
	OlalaPhotoSoap PhotosoapProxy = proxyPhoto.getOlalaPhotoSoap();%>
<html>
<head>
<title>Olala Wedding Planner : Cancel Job Entertain</title>

</head>
<body bgcolor="F9F9EF">
<%
	int Customer_id = Integer.parseInt((String)session.getAttribute("Customer_ID"));

    String tempstr = (String)request.getParameter("Photo_Contact_ID");
    int Photo_Contact_ID = Integer.parseInt(tempstr);

	tempstr = (String)request.getParameter("type_id");
	String type_id = new String(tempstr.getBytes("ISO8859_1"),"MS874");
    StringTokenizer strtoken = new StringTokenizer(type_id," ");
    int Type_ID = Integer.parseInt(strtoken.nextToken());

	tempstr = (String)request.getParameter("Photo_Job_ID");
    int Photo_Job_ID = Integer.parseInt(tempstr);

    tempstr = (String)request.getParameter("Wedding_Contact_ID");
    int Wedding_Contact_ID = Integer.parseInt(tempstr);

	//boolean photo_CancelJob_OutStudio(int contactID, int jobID, int weddingContactID)Type_ID = 3,5
	//boolean photo_CancelJob_Multimedia(int contactID, int jobID, int weddingContactID) Type_ID = 6
	//boolean photo_CancelJob_InStudio(int contactID, int jobID, int weddingContactID) Type_ID = 1
	boolean cancel;
	if (Type_ID == 1)
	{
		cancel = PhotosoapProxy.photo_CancelJob_InStudio(Photo_Contact_ID,Photo_Job_ID,Wedding_Contact_ID);
	}
	else if (Type_ID == 6)
	{
		cancel = PhotosoapProxy.photo_CancelJob_Multimedia(Photo_Contact_ID,Photo_Job_ID,Wedding_Contact_ID);
	}
	else 
	{
		cancel = PhotosoapProxy.photo_CancelJob_OutStudio(Photo_Contact_ID,Photo_Job_ID,Wedding_Contact_ID);
	}
    if (cancel == true)
    {
		org.openuri.www.ContactInfo[] photojob = PhotosoapProxy.photo_ShowOrderByContact(Wedding_Contact_ID,Photo_Contact_ID);
		if ((photojob != null)&&(photojob.length == 0))
		{
			boolean cancelcontact = PhotosoapProxy.photo_CancelContact(Photo_Contact_ID,Wedding_Contact_ID);
			if (cancelcontact == false)
			{
				response.sendRedirect("../Main.htm");
			}
		}
      response.sendRedirect("../ShowContact.jsp");
    }
	else response.sendRedirect("../Main.htm");
%>
</body>
</html>