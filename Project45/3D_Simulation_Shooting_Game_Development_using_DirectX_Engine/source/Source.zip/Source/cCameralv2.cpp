#include "Core_Global.h"

void cCameralv2::calcamera()
{
	if (movetype==1)
	{
	m_Camera.Point(fPosX,fPosY,fPosZ,fPosX,fPosY,fPosZ+0.1f);
	m_Camera.Rotate(D3DXToRadian(fAngleX),D3DXToRadian(fAngleY),0);
	}else
	if (movetype==2)
	{
	fPosX=distance*sinf(D3DXToRadian(fAngleY))*cosf(D3DXToRadian(fAngleX));
	fPosZ=distance*cosf(D3DXToRadian(fAngleY))*cosf(D3DXToRadian(fAngleX));
	fPosY=distance*sinf(D3DXToRadian(fAngleX));

	m_Camera.Point(fPosX+flookX,fPosY+flookY,fPosZ+flookZ,flookX,flookY,flookZ);

	}
}
float cCameralv2::getposX(){return fPosX;}
float cCameralv2::getposY(){return fPosY;}
float cCameralv2::getposZ(){return fPosZ;}
float cCameralv2::getlookX(){return flookX;}
float cCameralv2::getlookY(){return flookY;}
float cCameralv2::getlookZ(){return flookZ;}
float cCameralv2::getAngleX(){return fAngleX;}
float cCameralv2::getAngleY(){return fAngleY;}

void cCameralv2::resetpos()
{
	fAngleX=0.0f;
	fAngleY=0.0f;
	fPosX=0.0f;
	fPosY=0.0f;
	fPosZ=0.0f;
	flookX=0.0f;
	flookY=0.0f;
	flookZ=0.0f;
	distance=5.0f;
}
void cCameralv2::setlookatpoint(float x,float y,float z)
{
	flookX=x;flookY=y;flookZ=z;
}

void cCameralv2::lookupdown(long lud)
{
	fAngleX+= lud*MOUSE_ROTATION_SPEED;
	
	if (fAngleX<0.0f)
	{
	fAngleX=360+fAngleX;
	}else if (fAngleX>=360.0f)
	{
	fAngleX=fAngleX-360.0f;
	}

	if (fAngleX>89.0f && fAngleX<=180)
	{
		fAngleX=89.0f;
	}else if (fAngleX>180 && fAngleX<=270.0f)
	{
		fAngleX=270.0f;
	}

}

void cCameralv2::lookleftright(long llr)
{
	fAngleY-= -llr*MOUSE_ROTATION_SPEED;

	if (fAngleY<0.0f)
	{
		fAngleY=360.0f+fAngleY;
	}else if (fAngleY>=360.0f)
	{
		fAngleY=fAngleY-360.0f;
	}
	
}

void cCameralv2::moveforward()
{
	fPosX-=sinf(D3DXToRadian(fAngleY))*KEYBOARD_MOVING_SPEED;
	fPosZ+=cosf(D3DXToRadian(fAngleY))*KEYBOARD_MOVING_SPEED;
}
void cCameralv2::moveback()
{
	fPosX+=sinf(D3DXToRadian(fAngleY))*KEYBOARD_MOVING_SPEED;
	fPosZ-=cosf(D3DXToRadian(fAngleY))*KEYBOARD_MOVING_SPEED;
}
void cCameralv2::moveleft()
{
	fPosX-=sinf(D3DXToRadian(fAngleY+90.0f))*KEYBOARD_MOVING_SPEED;
	fPosZ+=cosf(D3DXToRadian(fAngleY+90.0f))*KEYBOARD_MOVING_SPEED;
}
void cCameralv2::moveright()
{
	fPosX-=sinf(D3DXToRadian(fAngleY-90.0f))*KEYBOARD_MOVING_SPEED;
	fPosZ+=cosf(D3DXToRadian(fAngleY-90.0f))*KEYBOARD_MOVING_SPEED;
}

void cCameralv2::setdistance(float dist)
{
	if (distance>3||dist>0)
	{
	distance+=(dist/120);
	}
}
void cCameralv2::setmovetype(int mtype)
{
	movetype=mtype;
}
void cCameralv2::setspeed(float krs,float kms,float mrs,float mms)
{
	KEYBOARD_ROTATION_SPEED=krs;
	KEYBOARD_MOVING_SPEED=kms;
	MOUSE_ROTATION_SPEED=mrs;
	MOUSE_MOVING_SPEED=mms;
}
void cCameralv2::setfirstxyz(float x,float y,float z)
{
	fPosX=x;
	fPosY=y;
	fPosZ=z;
}
cCamera cCameralv2::getCamera()
{	
	return m_Camera;
}
cCameralv2::cCameralv2()
{
	fAngleX=0.0f;
	fAngleY=0.0f;
	fPosX=0.0f;
	fPosY=0.0f;
	fPosZ=0.0f;
	flookX=0.0f;
	flookY=0.0f;
	flookZ=0.0f;
	KEYBOARD_ROTATION_SPEED=0.2f;
	KEYBOARD_MOVING_SPEED=0.01f;
	MOUSE_ROTATION_SPEED=0.2f;
	MOUSE_MOVING_SPEED=0.001f;
	distance=5.0f;
	movetype=1;
}
cCameralv2::~cCameralv2()
{
}