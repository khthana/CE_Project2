#include "Core_Global.h"
#include <math.h>
int i;
float fnAngleVector(D3DXVECTOR3 U,D3DXVECTOR3 V)
{
	float resultDot = D3DXVec3Dot(&U,&V) ;
	float resultLength = D3DXVec3Length(&U) * D3DXVec3Length(&V) ;
	return D3DXToDegree(acosf(resultDot/resultLength));
}
class craff
{
private:
	cMesh           m_Meshes;
    cObject         m_Objects;
	cMesh           m_MeshesBull;
    cObject         m_ObjectsBull;
	float			PosX;
	float			PosY;
	float			PosZ;
	float			MovetoX;
	float			MovetoY;
	float			MovetoZ;
	float			DiffX;
	float			DiffY;
	float			DiffZ;
	float			Difftotal;
	int				a;
	float			Angel,TempAngel;
	int				typebull;
	float			Angelmove;
	float			RotationX,RotationY,RotationZ;
	float			distancemove;
	float			time;
	float			timebull;
	int				maxhp;
	bool			pause; // ture = canrun ,flase cannotrun
	bool			type; // true = player ,false = enemy
// Craff Status
	float			speed;
	float			hp;
	float			str;
	float			agi;
	int				count;

public:
	craff();
	~craff();
	void Create(cGraphics *Graphic,int maxhp,bool type,char *filename,char *path);
	void Setpos(float x,float y,float z);
	void Setspeed(float s);
	void Setpause(bool p);
	void SetScale(float s);
	void Rotatetion(float x,float y,float z);
	void Moveto(float x,float y,float z);
	void Setstatus(int hp,int str,int agi);
	void Setdistancemove(float d);
	bool Move();
	void Render();
	float getTotaldiff();
	float getPosX();
	float getPosY();
	float getPosZ();
	float getAngel();
	float getHP();
	float getSTR();
	float getAGI();
	void ChangeHP(float);
	void ChangeSTR(float);
	void ChangeAGI(float);
	bool CanATK();
	void Setbull(cGraphics *Graphic,int type);
	void Renderbull();
};
void craff::Renderbull()
{
	m_ObjectsBull.Rotate(D3DXToRadian(0)+RotationX,RotationY+D3DXToRadian(TempAngel),D3DXToRadian(0)+RotationZ);
	m_ObjectsBull.Move(PosX,PosY,PosZ);

	if (hp>0)
		if (type==0)
		{	
			{
				if (timeGetTime()-timebull>100)
					{
						timebull=timeGetTime();
						m_ObjectsBull.Render();
					}
			}
		}else 
		if (type==1)
		{	
			{
				if (timeGetTime()-timebull>100)
					{
						timebull=timeGetTime();
						m_ObjectsBull.Render();
					}
			}
		}else 
			
		if (type==2)
		{
							if (timeGetTime()-timebull>100)
					{
						timebull=timeGetTime();
						m_ObjectsBull.Render();
					}

		}else 
			
		if (type==3)
		{
							if (timeGetTime()-timebull>100)
					{
						timebull=timeGetTime();
						m_ObjectsBull.Render();
					}

		}

}
void craff::Setbull(cGraphics *Graphic,int type)
{ 
	typebull=type;
	if (typebull ==0)
	{
	m_MeshesBull.Load(Graphic,"craff\\bullet0.x","craff\\");
    m_ObjectsBull.Create(Graphic, &m_MeshesBull);
	}else
	if (typebull ==1)
	{
	m_MeshesBull.Load(Graphic,"craff\\bullet1.x","craff\\");
    m_ObjectsBull.Create(Graphic, &m_MeshesBull);
	}else
	if (typebull ==2)
	{
	m_MeshesBull.Load(Graphic,"craff\\bullet2.x","craff\\");
    m_ObjectsBull.Create(Graphic, &m_MeshesBull);
	}else
	if (typebull ==3)
	{
	m_MeshesBull.Load(Graphic,"craff\\bullet3.x","craff\\");
    m_ObjectsBull.Create(Graphic, &m_MeshesBull);
	}


}

bool craff::CanATK()
{
	if (Difftotal<=distancemove) 
		return true; 
	return false;
}
void craff::Setstatus(int thp,int tstr,int tagi)
{
	hp=thp;
	str=tstr;
	agi=tagi;
}
void craff::ChangeHP(float in)
{
	hp+=in;
}
void craff::ChangeAGI(float in)
{
	agi+=in;
}
void craff::ChangeSTR(float in)
{
	str+=in;
}
float craff::getHP()
{
	if (hp>0) return hp; 
	return 0;
}
float craff::getSTR()
{
	if (str>0) return str; 
	return 0;
}
float craff::getAGI()
{
	if (agi>0) return agi; 
	return 0;
}
void craff::Rotatetion(float x,float y,float z)
{
	RotationX=D3DXToRadian(x);
	RotationY=D3DXToRadian(y);
	TempAngel=y;
	RotationZ=D3DXToRadian(z);
}
bool craff::Move()
{
	Difftotal=sqrt((pow(DiffX,2)+pow(DiffZ,2)));

	if (timeGetTime()-time>50)
	{
		time=timeGetTime();

		if (Difftotal>=distancemove) 
		{
		PosX+=(DiffX*speed);
		PosY+=(DiffY*speed);
		PosZ+=(DiffZ*speed);
		} else if ((Difftotal<=distancemove) && (Difftotal>=(distancemove/2)))
		{
		PosX+=(DiffX*speed*0.5);
		PosY+=(DiffY*speed*0.5);
		PosZ+=(DiffZ*speed*0.5);
		}
	}

	D3DXVECTOR3 vecFrontModel = D3DXVECTOR3(0,0,1);
	D3DXVECTOR3 vecPath = D3DXVECTOR3(MovetoX-PosX,-MovetoY-PosY,MovetoZ-PosZ);
	D3DXVec3Normalize(&vecPath,&vecPath);


	Angel = fnAngleVector(vecFrontModel,vecPath);

	if ((MovetoX-PosX)<0)
	{Angel+=((180-Angel)*2);}
	TempAngel=Angel;

	return true;

}
void craff::Create(cGraphics *Graphic,int tmaxhp,bool ty,char *filename,char *path)
{	
	maxhp=tmaxhp;
	type=ty;
	m_Meshes.Load(Graphic,filename,path);
    m_Objects.Create(Graphic, &m_Meshes);

}

void craff::Render()
{	
	m_Objects.Rotate(D3DXToRadian(0)+RotationX,RotationY+D3DXToRadian(TempAngel),D3DXToRadian(0)+RotationZ);
	m_Objects.Move(PosX,PosY,PosZ);

	if (hp>0)
	m_Objects.Render();
}

void craff::Moveto(float x,float y,float z)
{
	MovetoX=x;MovetoZ=z;MovetoY=y;

	DiffX=(MovetoX-PosX);
	DiffY=(MovetoY-PosY);
	DiffZ=(MovetoZ-PosZ);

	if (!pause) 
			Move();
}
void craff::SetScale(float s)
{
	m_Objects.Scale(s,s,s);
	m_ObjectsBull.Scale(s,s,s);
}
void craff::Setpos(float x,float y,float z)
{
	PosX=x;
	PosZ=z;
	PosY=y;
}
void craff::Setspeed(float s)
{ 
	speed = s;
}
void craff::Setpause(bool p)
{
	pause = p;
}
void craff::Setdistancemove(float d)
{
	distancemove=d;
}
float craff::getTotaldiff()
{
	return Difftotal;
}
float craff::getPosX()
{
	return PosX;
}
float craff::getPosY()
{
	return PosY;
}
float craff::getPosZ()
{
	return PosZ;
}
float craff::getAngel()
{
	return Angel;
}
craff::craff()
{
	PosX=PosY=PosZ=0;
	Angel=0;
	TempAngel=0;
	pause=false;
	count=0;
	Difftotal=50;
	RotationY=RotationX=RotationZ=0;
	distancemove=5;
	hp=str=agi=0;
	time=0;
	timebull=0;
}
craff::~craff()
{
	m_Meshes.Free();
    m_Objects.Free();
	m_MeshesBull.Free();
    m_ObjectsBull.Free();
}
////////////////////////////////////////////////////////
////////////////////////////////////////////////////////
class cApp : public cApplication
{
private:  
	cCameralv2      m_Cameralv2;
	cFont			Font;
	char strout[100];

    cGraphics		m_Graphics;
	cInput          m_Input;     // Input object
    cInputDevice    m_Keyboard;  // Keyboard device object
    cInputDevice    m_Mouse;     // Moues device object

	cTexture        m_Tiles;
	cTexture		m_TilesHP;
	cTexture		m_TilesSTR;
	cTexture		m_TilesAGI;

	cTexture		m_Talk2;

	cTexture        m_Loading;
	cTexture        m_Start0;
	cTexture        m_Start1;
	cTexture        m_Start2;

	craff			tour[6];
	int				totalcraff;
	int				camerapos;
	int				movetocraff[6];
	bool			att;

	cVertexBuffer  m_VB;
	cWorldPosition World;

	cMesh           m_MeshesSkybox;
    cObject         m_ObjectsSkybox;


	cMesh           m_MScreen[14];
    cObject         m_OScreen[14];



	cMaterial		m_mate;	

	int		stage;


	bool		hpup1;
	bool		hpup2;
	bool		hpup3;

public:
	cApp();
	BOOL Init();
	BOOL Shutdown();
	BOOL Frame();
	void initscreen();
	void renderscreen();
};

cApp::cApp()
{
	m_Style = WS_OVERLAPPEDWINDOW;	m_XPos = 0;	m_YPos = 0;
	m_Width = 800;	m_Height = 600;	strcpy(m_Class,"Tour");
	strcpy(m_Caption,"3D Game Delvelopment");
	stage=0;

}

BOOL cApp::Init()
{
	if (stage==0)
	{
	// Initialize the graphics device and set display mode
	m_Graphics.Init();
	m_Graphics.SetMode(GethWnd(), false, TRUE,800,600);
	m_Graphics.SetPerspective(D3DX_PI/4,1.3333f,1.0f,10000.0f);
	ShowMouse(TRUE);

	// Create Font
	Font.Create(&m_Graphics, "Arial");

	// Initialize input and input devices
	m_Input.Init(GethWnd(), GethInst());
	m_Keyboard.Create(&m_Input, KEYBOARD);
	m_Mouse.Create(&m_Input, MOUSE, TRUE);

	m_Start0.Load(&m_Graphics,"pic2D/start0.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);
	m_Start1.Load(&m_Graphics,"pic2D/start1.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);
	m_Start2.Load(&m_Graphics,"pic2D/start2.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);

	return true;
	}

	if (stage==1)
	{
	m_Loading.Load(&m_Graphics,"pic2D/load.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);
	return true;
	}
	
	sprintf(strout,"Start Game!!!");

	hpup1=hpup2=hpup3=true;
	


	 // Load the 2-D tiles 
    m_Tiles.Load(&m_Graphics,"pic2D/craffnum.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);
	m_TilesHP.Load(&m_Graphics,"pic2D/hp.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);
	m_TilesSTR.Load(&m_Graphics,"pic2D/str.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);
	m_TilesAGI.Load(&m_Graphics,"pic2D/agi.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);

	m_Talk2.Load(&m_Graphics,"talk/1.bmp",D3DCOLOR_RGBA(0,0,0,255),D3DFMT_A1R5G5B5);

	// Load Skybox
	m_MeshesSkybox.Load(&m_Graphics, "skybox\\skybox.x","skybox\\");
    m_ObjectsSkybox.Create(&m_Graphics, &m_MeshesSkybox);

	// Load Screen
	initscreen();

	camerapos=0;
	totalcraff=6;
	for (i=0;i<totalcraff;i++)
	{
		movetocraff[i]=i;
	}

	tour[0].Create(&m_Graphics,3000,true,"craff\\craff1.x","craff\\");
	tour[1].Create(&m_Graphics,5000,true,"craff\\craff2.x","craff\\");
	tour[2].Create(&m_Graphics,1000,true,"craff\\craff2.x","craff\\");
	tour[3].Create(&m_Graphics,3,true,"craff\\craff4.x","craff\\");
	tour[4].Create(&m_Graphics,4,true,"craff\\craff5.x","craff\\");
	tour[5].Create(&m_Graphics,5,true,"craff\\craff5.x","craff\\");

	tour[0].Rotatetion(270,0,0);
	tour[1].Rotatetion(270,0,0);
	tour[2].Rotatetion(270,0,0);
	tour[3].Rotatetion(270,0,180);
	tour[4].Rotatetion(270,0,180);
	tour[5].Rotatetion(270,0,180);

	tour[0].Setbull(&m_Graphics,0);
	tour[1].Setbull(&m_Graphics,1);
	tour[2].Setbull(&m_Graphics,1);
	tour[3].Setbull(&m_Graphics,2);
	tour[4].Setbull(&m_Graphics,3);
	tour[4].Setbull(&m_Graphics,3);

	tour[0].Setdistancemove(5);
	tour[1].Setdistancemove(8);
	tour[2].Setdistancemove(10);


	tour[0].Setpos(0,0,-50);
	tour[1].Setpos(10,0,-55);
	tour[2].Setpos(-10,0,-55);
	tour[3].Setpos(0,0,80);
	tour[4].Setpos(-20,0,60);
	tour[5].Setpos(30,0,50);

	tour[0].SetScale(0.08);
	tour[1].SetScale(0.03);
	tour[2].SetScale(0.03);
	tour[3].SetScale(0.03);
	tour[4].SetScale(0.08);
	tour[5].SetScale(0.08);	

	tour[0].Setstatus(3800,30,50);
	tour[1].Setstatus(4500,40,10);
	tour[2].Setstatus(2000,50,80);

	tour[3].Setstatus(4500,60,60);
	tour[4].Setstatus(5000,40,80);
	tour[5].Setstatus(1000,80,40);

	tour[0].Setspeed(0.02);
	tour[1].Setspeed(0.02);
	tour[2].Setspeed(0.02);

	att=false;

	return true;
}

BOOL cApp::Frame()
{
	// Get input
    m_Keyboard.Read();
	m_Mouse.Read();


	if (stage==0)
	{
		stage=0;


		sprintf(strout, "MouseX = %d, MouseY = %d,",m_Mouse.GetXPos(),m_Mouse.GetYPos());
		//Check input
		if(m_Mouse.GetButtonState(MOUSE_LBUTTON)==true)
		{
			if ((m_Mouse.GetXPos()>300)&&
				(m_Mouse.GetXPos()<420)&&
				(m_Mouse.GetYPos()>426)&&
				(m_Mouse.GetYPos()<460)) 
			{
			stage=1;
			}else
			{
			if ((m_Mouse.GetXPos()>300)&&
				(m_Mouse.GetXPos()<540)&&
				(m_Mouse.GetYPos()>470)&&
				(m_Mouse.GetYPos()<507)) 
				{
				return false;
				}

			}
		}


		m_Graphics.Clear();
		m_Graphics.Clear(D3DCOLOR_RGBA(0,0,0,255));

		if(m_Graphics.BeginScene() == TRUE) 
		{
			if ((m_Mouse.GetXPos()>300)&&
				(m_Mouse.GetXPos()<540)&&
				(m_Mouse.GetYPos()>426)&&
				(m_Mouse.GetYPos()<460)) 
			{
			m_Start1.Blit(150,50);
			}else
			if ((m_Mouse.GetXPos()>300)&&
				(m_Mouse.GetXPos()<540)&&
				(m_Mouse.GetYPos()>470)&&
				(m_Mouse.GetYPos()<507)) 
			{
			m_Start2.Blit(150,50);
			}else
			{
			m_Start0.Blit(150,50);
			}
		//	Font.Print(strout,30,30);

			m_Graphics.EndScene();
		}
		m_Graphics.Display();

		if (stage==1) Init();

		return true;
	}
	
	if (stage==1)
	{
		stage=2;
		m_Graphics.Clear();
		m_Graphics.Clear(D3DCOLOR_RGBA(0,0,0,255));

		if(m_Graphics.BeginScene() == TRUE) 
		{
			m_Loading.Blit(150,50);
			m_Graphics.EndScene();
		}
		m_Graphics.Display();
		Init();
		return true;
	}
	

// End Stage Start game
	if ((tour[0].getHP()==0)&&(tour[1].getHP()==0)&&(tour[2].getHP()==0))
	{
		MessageBox(GethWnd(),"You LOSS !!!","Try again",MB_ICONEXCLAMATION);
		return false;
	}

	if ((tour[3].getHP()==0)&&(tour[4].getHP()==0)&&(tour[5].getHP()==0))
	{
		MessageBox(GethWnd(),"You WIN !!!","Congratulation",MB_ICONINFORMATION);
		return false;
	}
	
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON)==true)
	{
		for (i=0;i<totalcraff;i++)
		{
			tour[i].Setpause(true);
		}
	}else
		for (i=0;i<totalcraff;i++)
		{
			tour[i].Setpause(false);
		}



	// Interface Engine


if(m_Mouse.GetButtonState(MOUSE_LBUTTON)==true)
// Select Camera to posting
{
	if ((m_Mouse.GetXPos()>0)&&(m_Mouse.GetXPos()<85)&&(m_Mouse.GetYPos()>345)&&(m_Mouse.GetYPos()<430)) // 0
	{if (tour[0].getHP()>0) {camerapos=0;sprintf(strout, "Camera zoom to Craff no. 1");}
	
	}else

	if ((m_Mouse.GetXPos()>0)&&(m_Mouse.GetXPos()<85)&&(m_Mouse.GetYPos()>430)&&(m_Mouse.GetYPos()<515)) // 1
	{if (tour[1].getHP()>0) {camerapos=1;sprintf(strout, "Camera zoom to Craff no. 2");}
	
	}else

	if ((m_Mouse.GetXPos()>0)&&(m_Mouse.GetXPos()<85)&&(m_Mouse.GetYPos()>515)&&(m_Mouse.GetYPos()<600)) // 2
	{if (tour[2].getHP()>0) {camerapos=2;sprintf(strout, "Camera zoom to Craff no. 3");}
	
	}

	if ((m_Mouse.GetXPos()>715)&&(m_Mouse.GetXPos()<800)&&(m_Mouse.GetYPos()>0)&&(m_Mouse.GetYPos()<85)) // 3
	{if (tour[3].getHP()>0) {camerapos=3;sprintf(strout, "Camera zoom to Enemy no. 4");}
	
	}else

	if ((m_Mouse.GetXPos()>715)&&(m_Mouse.GetXPos()<800)&&(m_Mouse.GetYPos()>85)&&(m_Mouse.GetYPos()<170)) // 4
	{if (tour[4].getHP()>0) {camerapos=4;sprintf(strout, "Camera zoom to Enemy no. 5");}
	
	}else

	if ((m_Mouse.GetXPos()>715)&&(m_Mouse.GetXPos()<800)&&(m_Mouse.GetYPos()>170)&&(m_Mouse.GetYPos()<255)) // 5
	{if (tour[5].getHP()>0) {camerapos=5;sprintf(strout, "Camera zoom to Enemy no. 6");}
	}
}
if(m_Mouse.GetButtonState(MOUSE_MBUTTON)==true)
{
 for (i=0;i<3;i++)
	if (camerapos==i)
	{
	if ((m_Mouse.GetXPos()>715)&&(m_Mouse.GetXPos()<800)&&(m_Mouse.GetYPos()>0)&&(m_Mouse.GetYPos()<85)) // 3
	{ movetocraff[i]=3;	sprintf(strout, "Craff no %d Move to Attack Enemy no. 4", i+1);}
	if ((m_Mouse.GetXPos()>715)&&(m_Mouse.GetXPos()<800)&&(m_Mouse.GetYPos()>85)&&(m_Mouse.GetYPos()<170)) // 4
	{movetocraff[i]=4;sprintf(strout, "Craff no %d Move to Attack Enemy no. 5", i+1);}
	if ((m_Mouse.GetXPos()>715)&&(m_Mouse.GetXPos()<800)&&(m_Mouse.GetYPos()>170)&&(m_Mouse.GetYPos()<255)) // 5
	{movetocraff[i]=5;sprintf(strout, "Craff no %d Move to Attack Enemy no. 6", i+1);}
	}
}


	// ESC quits program
   if(m_Keyboard.GetKeyState(KEY_ESC) == TRUE) return false;

// Moveing
	for (i=0;i<totalcraff;i++)
		{
		if (i!=movetocraff[i])
			tour[i].Moveto(tour[movetocraff[i]].getPosX(),
						   tour[movetocraff[i]].getPosY(),
						   tour[movetocraff[i]].getPosZ());
		}

// Atking
for (i=0;i<3;i++)
	if (tour[i].CanATK()==true)
	{
		if (tour[i].getHP()>0)
		{
		tour[movetocraff[i]].ChangeHP(-tour[i].getSTR());
		

		}

		if (tour[movetocraff[i]].getHP()>0)
		{
		tour[i].ChangeHP(-tour[movetocraff[i]].getSTR());
		}
	}

// Bonus HP , UP
	if ((tour[3].getHP()==0)&&(hpup1))
	{
		hpup1=false;
		sprintf(strout, "Enemy no. 1 Die Get Bonus HP 1500");
		for (i=0;i<3;i++)
		{
		if (tour[i].getHP()>0);
		tour[i].ChangeHP(1500);
		}

	}
		if ((tour[4].getHP()==0)&&(hpup2))
	{
		hpup2=false;
		sprintf(strout, "Enemy no. 2 Die Get ATK UP 10");
		for (i=0;i<3;i++)
		{
		if (tour[i].getHP()>0);
		tour[i].ChangeSTR(10);
		}

	}
	if ((tour[5].getHP()==0)&&(hpup3))
	{
		hpup3=false;
		sprintf(strout, "Enemy no. 3 Die Get AGI UP 20");
		for (i=0;i<3;i++)
		{
		if (tour[i].getHP()>0);
		tour[i].ChangeAGI(20);
		}

	}
// Cameralv2
	if(m_Mouse.GetButtonState(MOUSE_RBUTTON)==true)
	{
		if(m_Mouse.GetYDelta()!=0) m_Cameralv2.lookupdown(m_Mouse.GetYDelta());
		if(m_Mouse.GetXDelta()!=0) m_Cameralv2.lookleftright(m_Mouse.GetXDelta());	
	}

	if(m_Mouse.GetZDelta()!=0) m_Cameralv2.setdistance(m_Mouse.GetZDelta());


	m_Cameralv2.setlookatpoint(tour[camerapos].getPosX(),tour[camerapos].getPosY(),tour[camerapos].getPosZ());
	m_Cameralv2.setmovetype(2);
	m_Cameralv2.calcamera();
	m_Graphics.SetCamera(&m_Cameralv2.getCamera());

    // End Camera

	m_Graphics.Clear();
	// Rander The Screen
    m_Graphics.Clear(D3DCOLOR_RGBA(0,0,0,255));

//	m_ObjectsSkybox.Move(tour[camerapos].getPosX(),tour[camerapos].getPosY(),tour[camerapos].getPosZ());

m_ObjectsSkybox.Scale(10,10,10);


//Begin Screene
  if(m_Graphics.BeginScene() == TRUE) 
  {
//	sprintf(strout, "PosX = %5.3f, PosY = %5.3f, PosZ = %5.3f, AngleX =%3.3f,AngleY =%3.3f", 
//		     m_Cameralv2.getposX(),m_Cameralv2.getposY(),m_Cameralv2.getposZ(),
//			 m_Cameralv2.getAngleX(),m_Cameralv2.getAngleY());
//	sprintf(strout, "Craff Number =%d ,MoveTo Craff = %d ,Total Diff = %5.3f,PosX = %5.3f, PosZ = %5.3f , Angle = %5.3f", 
//		     camerapos,movetocraff[camerapos],tour[camerapos].getTotaldiff(),tour[camerapos].getPosX(),tour[camerapos].getPosZ(),tour[camerapos].getAngel());
//	sprintf(strout, "MouseX = %d, MouseY = %d,",m_Mouse.GetXPos(),m_Mouse.GetYPos());

//	sprintf(strout, "a = %d,  angel = %f, tempangle =%f",tour[camerapos].a,tour[camerapos].Angel
//		,tour[camerapos].TempAngel);

//	sprintf(strout, "DifX = %f,DifZ  = %f, Total = %f",tour[camerapos].DiffX,tour[camerapos].DiffZ,
//		tour[camerapos].Difftotal);




	m_Graphics.EnableZBuffer(TRUE);

	// Render Sky Box
	m_ObjectsSkybox.Render();

	// Render the Screen
	renderscreen();


	// Render Craff
	tour[0].Render();
	tour[1].Render();
	tour[2].Render();
	tour[3].Render();
	tour[4].Render();
	tour[5].Render();


//	for (i=0;i<3;i++)
//	if (tour[movetocraff[i]].getHP()>0)
//	{
//	tour[i].Renderbull();
//	}
for (i=0;i<3;i++)
	if (tour[i].CanATK()==true)
	{
		if ((tour[i].getHP()>0)&&(tour[movetocraff[i]].getHP()>0))
		{
//		tour[movetocraff[i]].ChangeHP(-tour[i].getSTR());
		tour[i].Renderbull();

		}

		if (tour[movetocraff[i]].getHP()>0)
		{
			if (tour[i].getHP()>0)
	//	tour[i].ChangeHP(-tour[movetocraff[i]].getSTR());
				tour[movetocraff[i]].Renderbull();
		}
	}

	// Render 2D
    m_Graphics.EnableZBuffer(FALSE);
    m_Graphics.EnableAlphaTesting(TRUE);
    m_Graphics.BeginSprite();

	if ((camerapos==0)&&(tour[0].getHP()>0))
	{
		m_Tiles.Blit(0,345,0,0,85,85,1.0f,1.0f);
		m_TilesHP.Blit(28,396,0,0,(17/12)*40,(17/12)*10,tour[0].getHP()/5000,1.0f);
		m_TilesSTR.Blit(28,406,0,0,(17/12)*40,(17/12)*10,tour[0].getSTR()/100,1.0f);
		m_TilesAGI.Blit(28,416,0,0,(17/12)*40,(17/12)*10,tour[0].getAGI()/100,1.0f);
	}else 
	{
		if (tour[0].getHP()>0) {
		m_Tiles.Blit(0,345,0,0,85,85,1.0f,1.0f,0xaaffffff);
		m_TilesHP.Blit(28,396,0,0,(17/12)*40,(17/12)*10,tour[0].getHP()/5000,1.0f,0xaaffffff);
		m_TilesSTR.Blit(28,406,0,0,(17/12)*40,(17/12)*10,tour[0].getSTR()/100,1.0f,0xaaffffff);
		m_TilesAGI.Blit(28,416,0,0,(17/12)*40,(17/12)*10,tour[0].getAGI()/100,1.0f,0xaaffffff);
		}
	}

	if ((camerapos==1)&&(tour[0].getHP()>0))
	{
		m_Tiles.Blit(0,430,0,85,85,85,1.0f,1.0f);
		m_TilesHP.Blit(28,481,0,0,(17/12)*40,(17/12)*10,tour[1].getHP()/5000,1.0f);
		m_TilesSTR.Blit(28,491,0,0,(17/12)*40,(17/12)*10,tour[1].getSTR()/100,1.0f);
		m_TilesAGI.Blit(28,501,0,0,(17/12)*40,(17/12)*10,tour[1].getAGI()/100,1.0f);
	}else 
	{
		if (tour[1].getHP()>0) {
		m_Tiles.Blit(0,430,0,85,85,85,1.0f,1.0f,0xaaffffff);
		m_TilesHP.Blit(28,481,0,0,(17/12)*40,(17/12)*10,tour[1].getHP()/5000,1.0f,0xaaffffff);
		m_TilesSTR.Blit(28,491,0,0,(17/12)*40,(17/12)*10,tour[1].getSTR()/100,1.0f,0xaaffffff);
		m_TilesAGI.Blit(28,501,0,0,(17/12)*40,(17/12)*10,tour[1].getAGI()/100,1.0f,0xaaffffff);
		}
	}

	if ((camerapos==2)&&(tour[0].getHP()>0))
	{
		m_Tiles.Blit(0,515,0,170,85,85,1.0f,1.0f);
		m_TilesHP.Blit(28,566,0,0,(17/12)*40,(17/12)*10,tour[2].getHP()/5000,1.0f);
		m_TilesSTR.Blit(28,576,0,0,(17/12)*40,(17/12)*10,tour[2].getSTR()/100,1.0f);
		m_TilesAGI.Blit(28,586,0,0,(17/12)*40,(17/12)*10,tour[2].getAGI()/100,1.0f);
	}else 
	{
		if (tour[2].getHP()>0) {
		m_Tiles.Blit(0,515,0,170,85,85,1.0f,1.0f,0xaaffffff);
		m_TilesHP.Blit(28,566,0,0,(17/12)*40,(17/12)*10,tour[2].getHP()/5000,1.0f,0xaaffffff);
		m_TilesSTR.Blit(28,576,0,0,(17/12)*40,(17/12)*10,tour[2].getSTR()/100,1.0f,0xaaffffff);
		m_TilesAGI.Blit(28,586,0,0,(17/12)*40,(17/12)*10,tour[2].getAGI()/100,1.0f,0xaaffffff);
		}
	}

	if ((camerapos==3)&&(tour[0].getHP()>0))
	{
		m_Tiles.Blit(715,0,85,0,85,85,1.0f,1.0f);
		m_TilesHP.Blit(745,50,0,0,(17/12)*40,(17/12)*10,tour[3].getHP()/5000,1.0f);
		m_TilesSTR.Blit(745,60,0,0,(17/12)*40,(17/12)*10,tour[3].getSTR()/100,1.0f);
		m_TilesAGI.Blit(745,70,0,0,(17/12)*40,(17/12)*10,tour[3].getAGI()/100,1.0f);
	}else 
	{
		if (tour[3].getHP()>0) {
		m_Tiles.Blit(715,0,85,0,85,85,1.0f,1.0f,0xaaffffff);
		m_TilesHP.Blit(745,50,0,0,(17/12)*40,(17/12)*10,tour[3].getHP()/5000,1.0f,0xaaffffff);
		m_TilesSTR.Blit(745,60,0,0,(17/12)*40,(17/12)*10,tour[3].getSTR()/100,1.0f,0xaaffffff);
		m_TilesAGI.Blit(745,70,0,0,(17/12)*40,(17/12)*10,tour[3].getAGI()/100,1.0f,0xaaffffff);
		}
	}
	if ((camerapos==4)&&(tour[0].getHP()>0))
	{
		m_Tiles.Blit(715,85,85,85,85,85,1.0f,1.0f);
		m_TilesHP.Blit(745,135,0,0,(17/12)*40,(17/12)*10,tour[4].getHP()/5000,1.0f);
		m_TilesSTR.Blit(745,145,0,0,(17/12)*40,(17/12)*10,tour[4].getSTR()/100,1.0f);
		m_TilesAGI.Blit(745,155,0,0,(17/12)*40,(17/12)*10,tour[4].getAGI()/100,1.0f);
	}else 
	{
		if (tour[4].getHP()>0) {
		m_Tiles.Blit(715,85,85,85,85,85,1.0f,1.0f,0xaaffffff);
		m_TilesHP.Blit(745,135,0,0,(17/12)*40,(17/12)*10,tour[4].getHP()/5000,1.0f,0xaaffffff);
		m_TilesSTR.Blit(745,145,0,0,(17/12)*40,(17/12)*10,tour[4].getSTR()/100,1.0f,0xaaffffff);
		m_TilesAGI.Blit(745,155,0,0,(17/12)*40,(17/12)*10,tour[4].getAGI()/100,1.0f,0xaaffffff);
		}
	}

	if ((camerapos==5)&&(tour[0].getHP()>0))
	{
		m_Tiles.Blit(715,170,85,170,85,85,1.0f,1.0f);
		m_TilesHP.Blit(745,220,0,0,(17/12)*40,(17/12)*10,tour[5].getHP()/5000,1.0f);
		m_TilesSTR.Blit(745,230,0,0,(17/12)*40,(17/12)*10,tour[5].getSTR()/100,1.0f);
		m_TilesAGI.Blit(745,240,0,0,(17/12)*40,(17/12)*10,tour[5].getAGI()/100,1.0f);
	}else 
	{
		if (tour[5].getHP()>0) {
		m_Tiles.Blit(715,170,85,170,85,85,1.0f,1.0f,0xaaffffff);
		m_TilesHP.Blit(745,220,0,0,(17/12)*40,(17/12)*10,tour[5].getHP()/5000,1.0f,0xaaffffff);
		m_TilesSTR.Blit(745,230,0,0,(17/12)*40,(17/12)*10,tour[5].getSTR()/100,1.0f,0xaaffffff);
		m_TilesAGI.Blit(745,240,0,0,(17/12)*40,(17/12)*10,tour[5].getAGI()/100,1.0f,0xaaffffff);
		}
	}

	m_Talk2.Blit(0,0,0,0,NULL,128,1.5,0.8,0xaaffffff);


    m_Graphics.EndSprite();
    m_Graphics.EnableAlphaTesting(FALSE);



	Font.Print(strout,30,30);


	m_Graphics.EndScene();
  }
    m_Graphics.Display();
	

	return true;
}


BOOL cApp::Shutdown()
{
	// Shutdown input
	m_Keyboard.Free();
	m_Input.Shutdown();

	// Shutdown graphics
	m_Graphics.Shutdown();
	Font.Free();

	// cTexture Shutdown
	m_Tiles.Free();
	m_TilesHP.Free();
	m_TilesSTR.Free();
	m_TilesAGI.Free();


	m_Loading.Free();
	m_Talk2.Free();


	m_MeshesSkybox.Free();
    m_ObjectsSkybox.Free();
	
	m_VB.Free();

	for (i=0;i<14;i++)
	{   
		m_OScreen[i].Free();
		m_MScreen[i].Free();
	}

	return true;
}


int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow)
{
	cApp App;
	return App.Run();
}

void cApp::initscreen()
{
	m_MScreen[0].Load(&m_Graphics, "screen\\s11.x","screen\\");
	m_MScreen[1].Load(&m_Graphics, "screen\\s12.x","screen\\");
	m_MScreen[2].Load(&m_Graphics, "screen\\s13.x","screen\\");
	m_MScreen[3].Load(&m_Graphics, "screen\\s21.x","screen\\");
	m_MScreen[4].Load(&m_Graphics, "screen\\s22.x","screen\\");
	m_MScreen[5].Load(&m_Graphics, "screen\\s23.x","screen\\");
	m_MScreen[6].Load(&m_Graphics, "screen\\s31.x","screen\\");
	m_MScreen[7].Load(&m_Graphics, "screen\\s32.x","screen\\");
	m_MScreen[8].Load(&m_Graphics, "screen\\s4.x","screen\\");
	m_MScreen[9].Load(&m_Graphics, "screen\\s51.x","screen\\");
	m_MScreen[10].Load(&m_Graphics, "screen\\s52.x","screen\\");
	m_MScreen[11].Load(&m_Graphics, "screen\\s61.x","screen\\");
	m_MScreen[12].Load(&m_Graphics, "screen\\s62.x","screen\\");
	m_MScreen[13].Load(&m_Graphics, "screen\\s73.x","screen\\");


	for (i=0;i<14;i++)
	{   
		m_OScreen[i].Create(&m_Graphics, &m_MScreen[i]);
	}

}

void cApp::renderscreen()
{
		m_OScreen[9].Move(10,10,10);
		m_OScreen[9].Render();
		m_OScreen[9].Move(0,-8,10);
		m_OScreen[0].Render();
		m_OScreen[0].Move(0,20,60);
		m_OScreen[0].Render();
		m_OScreen[0].Move(48,-33,-50);
		m_OScreen[0].Render();
		m_OScreen[0].Move(-40,20,32);
		m_OScreen[0].Render();
		m_OScreen[0].Move(40,-9,-20);
		m_OScreen[0].Render();
		m_OScreen[0].Move(20,20,60);
		m_OScreen[0].Render();
		m_OScreen[0].Move(0,-11,0);
		m_OScreen[0].Render();
		m_OScreen[9].Move(30,20,-10);
		m_OScreen[9].Render();
		m_OScreen[9].Move(-40,-15,45);
		m_OScreen[1].Render();
		m_OScreen[1].Move(-51,31,60);
		m_OScreen[1].Render();
		m_OScreen[1].Move(118,-13,-10);
		m_OScreen[1].Render();
		m_OScreen[1].Move(-10,20,-30);
		m_OScreen[1].Render();
		m_OScreen[1].Move(46,-9,-20);
		m_OScreen[1].Render();
		m_OScreen[1].Move(-60,20,10);
		m_OScreen[1].Render();
		m_OScreen[1].Move(0,-14,0);
		m_OScreen[1].Render();
		m_OScreen[9].Move(0,20,50);
		m_OScreen[9].Render();
		m_OScreen[9].Move(60,-30,51);
		m_OScreen[2].Render();
		m_OScreen[2].Move(90,4,40);
		m_OScreen[2].Render();
		m_OScreen[2].Move(-48,-4,-4);
		m_OScreen[2].Render();
		m_OScreen[2].Move(-42,10,-32);
		m_OScreen[2].Render();
		m_OScreen[2].Move(60,-19,-50);
		m_OScreen[2].Render();
		m_OScreen[2].Move(20,10,-60);
		m_OScreen[2].Render();
		m_OScreen[2].Move(0,-21,56);
		m_OScreen[2].Render();
		m_OScreen[9].Move(-30,24,-19);
		m_OScreen[9].Render();
		m_OScreen[9].Move(-20,-12,50);
		m_OScreen[3].Render();
		m_OScreen[3].Move(-80,14,20);
		m_OScreen[3].Render();
		m_OScreen[3].Move(-118,-23,-80);
		m_OScreen[3].Render();
		m_OScreen[3].Move(-90,10,30);
		m_OScreen[3].Render();
		m_OScreen[3].Move(16,-25,-24);
		m_OScreen[3].Render();
		m_OScreen[3].Move(-60,25,-10);
		m_OScreen[3].Render();
		m_OScreen[3].Move(-54,-24,-14);
		m_OScreen[3].Render();
		m_OScreen[10].Move(-10,10,-10);
		m_OScreen[10].Render();
		m_OScreen[10].Move(12,-8,10);
		m_OScreen[4].Render();
		m_OScreen[4].Move(18,20,-60);
		m_OScreen[4].Render();
		m_OScreen[4].Move(28,-14,-40);
		m_OScreen[4].Render();
		m_OScreen[4].Move(-40,20,32);
		m_OScreen[4].Render();
		m_OScreen[4].Move(44,-9,-20);
		m_OScreen[4].Render();
		m_OScreen[4].Move(-20,20,60);
		m_OScreen[4].Render();
		m_OScreen[4].Move(0,-11,0);
		m_OScreen[4].Render();
		m_OScreen[10].Move(30,20,-10);
		m_OScreen[10].Render();
		m_OScreen[10].Move(10,-15,45);
		m_OScreen[5].Render();
		m_OScreen[5].Move(-50,17,60);
		m_OScreen[5].Render();
		m_OScreen[5].Move(45,-18,-10);
		m_OScreen[5].Render();
		m_OScreen[5].Move(12,16,-30);
		m_OScreen[5].Render();
		m_OScreen[5].Move(-40,-17,-20);
		m_OScreen[5].Render();
		m_OScreen[5].Move(10,20,10);
		m_OScreen[5].Render();
		m_OScreen[5].Move(-30,-4,0);
		m_OScreen[5].Render();
		m_OScreen[10].Move(0,15,50);
		m_OScreen[10].Render();
		m_OScreen[10].Move(60,-20,51);
		m_OScreen[6].Render();
		m_OScreen[6].Move(90,4,40);
		m_OScreen[6].Render();
		m_OScreen[6].Move(-48,-4,-4);
		m_OScreen[6].Render();
		m_OScreen[6].Move(-42,10,-32);
		m_OScreen[6].Render();
		m_OScreen[6].Move(60,-19,-50);
		m_OScreen[6].Render();
		m_OScreen[6].Move(20,10,-60);
		m_OScreen[6].Render();
		m_OScreen[6].Move(0,-21,56);
		m_OScreen[6].Render();
		m_OScreen[11].Move(-30,24,-19);
		m_OScreen[11].Render();
		m_OScreen[11].Move(-20,-12,50);
		m_OScreen[7].Render();
		m_OScreen[7].Move(-80,14,20);
		m_OScreen[7].Render();
		m_OScreen[7].Move(-118,-23,-80);
		m_OScreen[7].Render();
		m_OScreen[7].Move(-90,10,30);
		m_OScreen[7].Render();
		m_OScreen[7].Move(16,-25,-24);
		m_OScreen[7].Render();
		m_OScreen[7].Move(-60,25,-10);
		m_OScreen[7].Render();
		m_OScreen[7].Move(-54,-24,-14);
		m_OScreen[7].Render();
		m_OScreen[12].Move(20,10,120);
		m_OScreen[12].Render();
		m_OScreen[12].Move(16,-19,100);
		m_OScreen[12].Render();
		m_OScreen[12].Move(30,10,90);
		m_OScreen[12].Render();
		m_OScreen[12].Move(-30,-21,99);
		m_OScreen[12].Render();
		m_OScreen[12].Move(-10,24,69);
		m_OScreen[12].Render();
		m_OScreen[12].Move(-20,-12,90);
		m_OScreen[12].Render();
		m_OScreen[13].Move(-80,14,94);
		m_OScreen[13].Render();
		m_OScreen[13].Move(-118,-23,84);
		m_OScreen[13].Render();
		m_OScreen[13].Move(-90,10,130);
		m_OScreen[13].Render();
		m_OScreen[13].Move(16,-25,184);
		m_OScreen[13].Render();
		m_OScreen[13].Move(-60,25,150);
		m_OScreen[13].Render();
		m_OScreen[13].Move(-54,-24,114);
		m_OScreen[3].Render();
		m_OScreen[10].Move(-10,10,90);
		m_OScreen[10].Render();
		m_OScreen[10].Move(12,-8,110);
		m_OScreen[11].Render();
		m_OScreen[11].Move(18,20,130);
		m_OScreen[11].Render();
		m_OScreen[4].Move(28,-14,120);
		m_OScreen[4].Render();
		m_OScreen[4].Move(-40,20,111);
		m_OScreen[4].Render();

}
