class cCameralv2
{
private:
	cCamera         m_Camera;    // Camera

	float fAngleX;
	float fAngleY;
	float fPosX;
	float fPosY;
	float fPosZ;	
	float flookX;
	float flookY;
	float flookZ;

	float KEYBOARD_ROTATION_SPEED;
	float KEYBOARD_MOVING_SPEED;
	float MOUSE_ROTATION_SPEED;
	float MOUSE_MOVING_SPEED;
	float distance;
	int movetype;

public:
	cCameralv2();
	~cCameralv2();
	void setspeed(float,float,float,float);
	void setfirstxyz(float,float,float);
	void setlookatpoint(float,float,float);
	void setdistance(float);
	void setmovetype(int);// 1= First PersonCamera, 2 = 3 Person Camera
	void moveforward();
	void moveback();
	void moveleft();
	void moveright();
	void lookupdown(long);
	void lookleftright(long);
	void calcamera();
	void resetpos();
	float getposX();
	float getposY();
	float getposZ();
	float getlookX();
	float getlookY();
	float getlookZ();
	float getAngleX();
	float getAngleY();
	cCamera getCamera();

};