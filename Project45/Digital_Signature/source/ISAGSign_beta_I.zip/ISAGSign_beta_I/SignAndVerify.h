// SignAndVerify.h: interface for the SignAndVerify class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIGNANDVERIFY_H__5CFAEB3D_15E6_4249_9A60_DC499888DFD4__INCLUDED_)
#define AFX_SIGNANDVERIFY_H__5CFAEB3D_15E6_4249_9A60_DC499888DFD4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ISAGSign_beta_I.h"

class SignAndVerify  
{
public:
	SignAndVerify();
	BYTE* GetDigitalSignature();
	UINT GetDigitalSignatureLength();
	CString GetHashValue();
	CString GetCertificateSubject(CERT_NAME_BLOB*);
	
	void FindHashValue(BYTE* , UINT , CString);
	void SignSignature(BYTE* , UINT , CString);
	BOOL VerifySignature(BYTE* , DWORD , BYTE*);
	void HandleError(CString);
	virtual ~SignAndVerify();
private:
	BYTE		*digitalSignature;
	UINT		 digitalSignatureLen;
	HCRYPTPROV	hProv;
	HCRYPTHASH	hHash;
	CString		hashValue;
};

#endif // !defined(AFX_SIGNANDVERIFY_H__5CFAEB3D_15E6_4249_9A60_DC499888DFD4__INCLUDED_)
