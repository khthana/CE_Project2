// ISAGSign_beta_I.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"

#include "MainFrm.h"
#include "IpFrame.h"
#include "ISAGSign_beta_IDoc.h"
#include "ISAGSign_beta_IView.h"
#include "CSignStep01Dlg.h"
#include "CSignStep02Dlg.h"
#include "CSignStep03Dlg.h"
#include "VerifyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IApp

BEGIN_MESSAGE_MAP(CISAGSign_beta_IApp, CWinApp)
	//{{AFX_MSG_MAP(CISAGSign_beta_IApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(IDM_SIGN, OnSign)
	ON_COMMAND(IDM_VERIFY, OnVerify)
	ON_COMMAND(IDM_CERT_MGR, OnCertMgr)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IApp construction
CISAGSign_beta_IApp::CISAGSign_beta_IApp()
{
	/////////////////////////////////////////////////////////////////////////
	// Allocate memory for current signer.
	currentSigner = new SignatureInformation();	
	
	// Digital signature status...
	// value -1 => None sign.
	// value  0 => Modified document.
	// value  1 => Unmodified document.
	// value  2 => Sign successful.
	// Set signature status to none sign.
	sigStatus = -1;	

	// Set result equal NONE.
	result = NONE;
}

CISAGSign_beta_IApp::~CISAGSign_beta_IApp()
{
	/////////////////////////////////////////////////////////////////////////
	// Deallocate memory for current signer.
	delete currentSigner;
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CISAGSign_beta_IApp object

CISAGSign_beta_IApp theApp;

// This identifier was generated to be statistically unique for your app.
// You may change it if you prefer to choose a specific identifier.

// {D7703A74-8AD3-4A3B-A79D-5C52F32FFA9D}
static const CLSID clsid =
{ 0xd7703a74, 0x8ad3, 0x4a3b, { 0xa7, 0x9d, 0x5c, 0x52, 0xf3, 0x2f, 0xfa, 0x9d } };

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IApp initialization

BOOL CISAGSign_beta_IApp::InitInstance()
{
	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CISAGSign_beta_IDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CISAGSign_beta_IView));
	pDocTemplate->SetServerInfo(
		IDR_SRVR_EMBEDDED, IDR_SRVR_INPLACE,
		RUNTIME_CLASS(CInPlaceFrame));
	AddDocTemplate(pDocTemplate);

	// Connect the COleTemplateServer to the document template.
	//  The COleTemplateServer creates new documents on behalf
	//  of requesting OLE containers by using information
	//  specified in the document template.
	m_server.ConnectTemplate(clsid, pDocTemplate, TRUE);
		// Note: SDI applications register server objects only if /Embedding
		//   or /Automation is present on the command line.

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Check to see if launched as OLE server
	if (cmdInfo.m_bRunEmbedded || cmdInfo.m_bRunAutomated)
	{
		// Register all OLE server (factories) as running.  This enables the
		//  OLE libraries to create objects from other applications.
		COleTemplateServer::RegisterAll();

		// Application was run with /Embedding or /Automation.  Don't show the
		//  main window in this case.
		return TRUE;
	}

	// When a server application is launched stand-alone, it is a good idea
	//  to update the system registry in case it has been damaged.
	m_server.UpdateRegistry(OAT_INPLACE_SERVER);

	// When a mini-server is run stand-alone the registry is updated and the
	//  user is instructed to use the Insert Object dialog in a container
	//  to use the server.  Mini-servers do not have stand-alone user interfaces.
	AfxMessageBox(IDP_USE_INSERT_OBJECT);
	return FALSE;
}


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CISAGSign_beta_IApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IApp message handlers

void CISAGSign_beta_IApp::OnSign() 
{
	/////////////////////////////////////////////////////////////////////////
	// This is function signs data.
	// Digital signature status...
	// value -1 => None sign.
	// value  0 => Modified document.
	// value  1 => Unmodified document.
	// value  2 => Sign successful.

	// Declare and initialize local variable here.
	signStep = STEP01;						// sign signature step 1.

	// Sign signature 1st step.
	if (signStep == STEP01)
	{
		CSignStep01Dlg signStep01Dlg;
		signStep01Dlg.DoModal();
	}

	// Sign signature 2nd step.
	if (signStep == STEP02)
	{
		CSignStep02Dlg signStep02Dlg;
		signStep02Dlg.DoModal();
		signStep = STEP04;
	}

	// Sign signature 3rd step.
	if (signStep == STEP03) 
	{
		CSignStep03Dlg signStep03Dlg;
		signStep03Dlg.DoModal();
	}

	// Sign signature 4th step.
	if (signStep == STEP04)
	{
		// Get the CWnd captain title.
		CString wndName;
		this->containerWnd->GetWindowText(wndName);
		if (wndName.Find("Microsoft Excel") != -1)
		{
			SignSignatureMSExcel();
		}
		if (wndName.Find("Microsoft Word")  != -1)
		{
			SignSignatureMSWord();
		}
		
		// Set signature status => Sign successful.
		sigStatus = 3;
	}
}

void CISAGSign_beta_IApp::SignSignatureMSExcel()
{
	//------------------------------------------------------------------
	// Local variable for call the DLL function.
	HINSTANCE gLibMyDLL = NULL;						// DLL function.
	typedef BYTE*  (*DATABLOCKEXCEL)();				// DLL function.
	DATABLOCKEXCEL GetDataBlock;					// DLL function.
	typedef UINT   (*DATABLOCKLENGTHEXCEL)();		// DLL function.
	DATABLOCKLENGTHEXCEL GetDataBlockLength;		// DLL function.
	typedef void   (*DEALLOCATEMEMORY)();			// DLL function.
	DEALLOCATEMEMORY DeallocateMemory;				// DLL function.

	// Load CryptExcelText.dll library.
	gLibMyDLL = LoadLibrary("CryptExcelTxt.dll");
 	if (gLibMyDLL == NULL) 
	{
 		AfxMessageBox("Error in 'LoadLibrary' !");
		exit(1);
	}

	GetDataBlock = (DATABLOCKEXCEL)GetProcAddress(gLibMyDLL , "GetDataBlock");
	GetDataBlockLength = (DATABLOCKLENGTHEXCEL)GetProcAddress(gLibMyDLL , "GetDataBlockLength");
	DeallocateMemory = (DEALLOCATEMEMORY)GetProcAddress(gLibMyDLL , "DeallocateMemory");

	// -----------------------------------------------------------------
	// Begin the process here.
	SignerInformation signerInfo = theApp.currentSigner->getSignerInfo();
	CString signerName = signerInfo.SignerName;
	CString hashAlgo = theApp.currentSigner->getHashAlgorithm();

	// Step 01 : Get data block and data block length from CryptExcelTxt library.
	BYTE *dataBlockTmp = GetDataBlock();
	UINT  dataBlockLen = GetDataBlockLength();

	// Step 02 : Find the hash value of data.
	SignAndVerify *SignAndVerifyCom = new SignAndVerify();
	SignAndVerifyCom->FindHashValue(dataBlockTmp, dataBlockLen , hashAlgo);
	CString hashValue = SignAndVerifyCom->GetHashValue();
	AfxMessageBox(hashValue , MB_OK | MB_ICONINFORMATION);
	BYTE *hashStream = (BYTE*)(LPCSTR)(hashValue); 
	UINT  hashStreamLen = strlen((LPCSTR)(hashValue));

	// Step 03 : Encrypt message digest with private of signer.
	SignAndVerifyCom->SignSignature(hashStream , hashStreamLen , signerName);

	// Step 04 : Get digital signature.
	BYTE *sig   = SignAndVerifyCom->GetDigitalSignature();
	UINT sigLen = SignAndVerifyCom->GetDigitalSignatureLength();

	// Set digital signature blob.
	theApp.currentSigner->setPbSignatureBlob(sig , sigLen);
	AfxMessageBox("Sign successful..." , MB_OK | MB_ICONINFORMATION);
	DeallocateMemory();
	delete SignAndVerifyCom;
}

void CISAGSign_beta_IApp::SignSignatureMSWord()
{
	//------------------------------------------------------------------
	// Local variable for call the DLL function.
	HINSTANCE gLibMyDLL = NULL;						// DLL function.
	typedef BYTE*  (*DATABLOCKWORD)();				// DLL function.
	DATABLOCKWORD GetDataBlock;						// DLL function.
	typedef UINT   (*DATABLOCKLENGTHWORD)();		// DLL function.
	DATABLOCKLENGTHWORD GetDataBlockLength;			// DLL function.
	typedef void   (*DEALLOCATEMEMORY)();			// DLL function.
	DEALLOCATEMEMORY DeallocateMemory;				// DLL function.

	// Load CryptExcelText.dll library.
	gLibMyDLL = LoadLibrary("CryptWordTxt.dll");
 	if (gLibMyDLL == NULL) 
	{
 		AfxMessageBox("Error in 'LoadLibrary' !");
		exit(1);
	}

	GetDataBlock = (DATABLOCKWORD)GetProcAddress(gLibMyDLL , "GetDataBlock");
	GetDataBlockLength = (DATABLOCKLENGTHWORD)GetProcAddress(gLibMyDLL , "GetDataBlockLength");
	DeallocateMemory = (DEALLOCATEMEMORY)GetProcAddress(gLibMyDLL , "DeallocateMemory");

	// -----------------------------------------------------------------
	// Begin the process here.
	SignerInformation signerInfo = theApp.currentSigner->getSignerInfo();
	CString signerName = signerInfo.SignerName;
	CString hashAlgo = theApp.currentSigner->getHashAlgorithm();

	// Step 01 : Get data block and data block length from CryptExcelTxt library.
	BYTE *dataBlockTmp = GetDataBlock();
	UINT  dataBlockLen = GetDataBlockLength();

	// Step 02 : Find the hash value of data.
	SignAndVerify *SignAndVerifyCom = new SignAndVerify();
	SignAndVerifyCom->FindHashValue(dataBlockTmp, dataBlockLen , hashAlgo);
	CString hashValue = SignAndVerifyCom->GetHashValue();
	AfxMessageBox(hashValue , MB_OK | MB_ICONINFORMATION);
	BYTE *hashStream = (BYTE*)(LPCSTR)(hashValue); 
	UINT  hashStreamLen = strlen((LPCSTR)(hashValue));

	// Step 03 : Encrypt message digest with private of signer.
	SignAndVerifyCom->SignSignature(hashStream , hashStreamLen , signerName);

	// Step 04 : Get digital signature.
	BYTE *sig   = SignAndVerifyCom->GetDigitalSignature();
	UINT sigLen = SignAndVerifyCom->GetDigitalSignatureLength();
	
	// Set digital signature blob.
	theApp.currentSigner->setPbSignatureBlob(sig , sigLen);
	AfxMessageBox("Sign successful..." , MB_OK | MB_ICONINFORMATION);
	DeallocateMemory();
	delete SignAndVerifyCom;
}

void CISAGSign_beta_IApp::OnVerify() 
{
	///////////////////////////////////////////////////////////////////
	// Verify the digital signature.
	// Digital signature status...
	// value -1 => None sign.
	// value  0 => Modified document.
	// value  1 => Unmodified document.
	// value  2 => Sign successful.

	// Declare and initialize local variable here.
	CTime currTm = CTime::GetCurrentTime();
	CTime certTo = theApp.currentSigner->getCertTo();
	CTime certFm = theApp.currentSigner->getCertFrom();
	CTime keyExp = theApp.currentSigner->getSignDate();
	int maxApprove = theApp.currentSigner->getMaxApprove();

	// Check : Max approve.
	if (maxApprove == 0)
	{
		theApp.result = OVER_MAX_VERIFY;
		return;
	}

	// Check : Certificate duration.
	if ((certFm != NULL) && (certTo != NULL))
		if (!((currTm >= certFm) && (currTm <= certTo)))
		{
			theApp.result = OVER_CERT_DURATION;
			return;
		}

	// If the current max approve is not over than the first setting. 
	// Then decrement that max approve value.
	maxApprove--;
	theApp.currentSigner->setMaxApprove(maxApprove);

	CString wndName;
	this->containerWnd->GetWindowText(wndName);
	CVerifySignatureDlg verifyResultDlg;

	// Verify document in MS - Excel.
	if (wndName.Find("Microsoft Excel") != -1)
	{
		if (VerifySignatureMSExcel() == TRUE) 
		{
			AfxMessageBox("Unmodified...");
			theApp.sigStatus = 1;			// Unmodified document.
			verifyResultDlg.DoModal();
		}
			
		else
		{
			AfxMessageBox("Modified...");
			theApp.sigStatus = 0;			// Modified document.
			verifyResultDlg.DoModal();
		}
	}
	// Verify document in MS - Word.
	if (wndName.Find("Microsoft Word") != -1)
	{
		if (VerifySignatureMSWord()  == TRUE)
		{
			AfxMessageBox("Unmodified...");
			theApp.sigStatus = 1;			// Unmodified document.
			verifyResultDlg.DoModal();
		}
		else
		{
			AfxMessageBox("Modified...");
			theApp.sigStatus = 0;			// Modified document.
			verifyResultDlg.DoModal();
		}
	}
}

BOOL CISAGSign_beta_IApp::VerifySignatureMSExcel()
{
	//------------------------------------------------------------------
	// Local variable for call the DLL function.
	HINSTANCE gLibMyDLL = NULL;						// DLL function.
	typedef BYTE*  (*DATABLOCKEXCEL)();				// DLL function.
	DATABLOCKEXCEL GetDataBlock;					// DLL function.
	typedef UINT   (*DATABLOCKLENGTHEXCEL)();		// DLL function.
	DATABLOCKLENGTHEXCEL GetDataBlockLength;		// DLL function.
	typedef void   (*DEALLOCATEMEMORY)();			// DLL function.
	DEALLOCATEMEMORY DeallocateMemory;				// DLL function.

	// Load CryptExcelText.dll library.
	gLibMyDLL = LoadLibrary("CryptExcelTxt.dll");
 	if (gLibMyDLL == NULL) 
	{
 		AfxMessageBox("Error in 'LoadLibrary' !");
		exit(1);
	}

	GetDataBlock = (DATABLOCKEXCEL)GetProcAddress(gLibMyDLL , "GetDataBlock");
	GetDataBlockLength = (DATABLOCKLENGTHEXCEL)GetProcAddress(gLibMyDLL , "GetDataBlockLength");
	DeallocateMemory = (DEALLOCATEMEMORY)GetProcAddress(gLibMyDLL , "DeallocateMemory");

	// -----------------------------------------------------------------
	// Begin the process here.
	SignerInformation signerInfo = theApp.currentSigner->getSignerInfo();
	CString signerName = signerInfo.SignerName;
	CString hashAlgo = theApp.currentSigner->getHashAlgorithm();
	// Step 01 : Get data block and data block length from CryptExcelTxt library.
	BYTE *dataBlockTmp = GetDataBlock();
	UINT  dataBlockLen = GetDataBlockLength();

	// Step 02 : Find the hash value of data.
	SignAndVerify *SignAndVerifyCom = new SignAndVerify();
	SignAndVerifyCom->FindHashValue(dataBlockTmp, dataBlockLen , hashAlgo);
	CString hashValue = SignAndVerifyCom->GetHashValue();
	AfxMessageBox(hashValue , MB_OK | MB_ICONINFORMATION);

	BYTE *hashStream = (BYTE*)(LPCSTR)(hashValue);
	UINT  hashStreamLen = strlen((LPCSTR)(hashValue));	

	BYTE *digitalSignature = theApp.currentSigner->getPbSignatureBlob();
	DWORD  digitalSignatureLen = theApp.currentSigner->getPbSignatureBlobLength();
	BOOL r = SignAndVerifyCom->VerifySignature(digitalSignature , digitalSignatureLen , hashStream);	

	DeallocateMemory();
	if (r) 
	{
		delete SignAndVerifyCom;
		return TRUE;
	}
	else
	{
		delete SignAndVerifyCom;
		return FALSE;
	}
}

BOOL CISAGSign_beta_IApp::VerifySignatureMSWord()
{
	//------------------------------------------------------------------
	// Local variable for call the DLL function.
	HINSTANCE gLibMyDLL = NULL;						// DLL function.
	typedef BYTE*  (*DATABLOCKWORD)();				// DLL function.
	DATABLOCKWORD GetDataBlock;						// DLL function.
	typedef UINT   (*DATABLOCKLENGTHWORD)();		// DLL function.
	DATABLOCKLENGTHWORD GetDataBlockLength;			// DLL function.
	typedef void   (*DEALLOCATEMEMORY)();			// DLL function.
	DEALLOCATEMEMORY DeallocateMemory;				// DLL function.
	typedef void   (*SAVE)();						// DLL function.
	SAVE Save;										// DLL function.

	// Load CryptExcelText.dll library.
	gLibMyDLL = LoadLibrary("CryptWordTxt.dll");
 	if (gLibMyDLL == NULL) 
	{
 		AfxMessageBox("Error in 'LoadLibrary' !");
		exit(1);
	}

	GetDataBlock = (DATABLOCKWORD)GetProcAddress(gLibMyDLL , "GetDataBlock");
	GetDataBlockLength = (DATABLOCKLENGTHWORD)GetProcAddress(gLibMyDLL , "GetDataBlockLength");
	DeallocateMemory = (DEALLOCATEMEMORY)GetProcAddress(gLibMyDLL , "DeallocateMemory");
	Save = (SAVE)GetProcAddress(gLibMyDLL , "Save");

	// -----------------------------------------------------------------
	// Begin the process here.
	SignerInformation signerInfo = theApp.currentSigner->getSignerInfo();
	CString signerName = signerInfo.SignerName;
	CString hashAlgo = theApp.currentSigner->getHashAlgorithm();

	// Step 01 : Get data block and data block length from CryptExcelTxt library.
	BYTE *dataBlockTmp = GetDataBlock();
	UINT  dataBlockLen = GetDataBlockLength();

	// Step 02 : Find the hash value of data.
	SignAndVerify *SignAndVerifyCom = new SignAndVerify();
	SignAndVerifyCom->FindHashValue(dataBlockTmp, dataBlockLen , hashAlgo);
	CString hashValue = SignAndVerifyCom->GetHashValue();
	AfxMessageBox(hashValue , MB_OK | MB_ICONINFORMATION);
	BYTE *hashStream = (BYTE*)(LPCSTR)(hashValue); 
	UINT  hashStreamLen = strlen((LPCSTR)(hashValue));

	BYTE *digitalSignature = theApp.currentSigner->getPbSignatureBlob();
	DWORD  digitalSignatureLen = theApp.currentSigner->getPbSignatureBlobLength();
	BOOL r = SignAndVerifyCom->VerifySignature(digitalSignature , digitalSignatureLen , hashStream);

	DeallocateMemory();
	if (r) 
	{
		delete SignAndVerifyCom;
		return TRUE;
	}
	else
	{
		delete SignAndVerifyCom;
		return FALSE;
	}
}

void CISAGSign_beta_IApp::OnCertMgr() 
{
	////////////////////////////////////////////////////////////////////
	// Run the CertMgr.exe application.
	WinExec("CertMgr.exe" , SW_SHOW);	
}
