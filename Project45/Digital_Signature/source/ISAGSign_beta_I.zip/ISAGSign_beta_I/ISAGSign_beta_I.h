// ISAGSign_beta_I.h : main header file for the ISAGSIGN_BETA_I application
//

#if !defined(AFX_ISAGSIGN_BETA_I_H__47B31299_5940_401B_A597_6E834FB1576D__INCLUDED_)
#define AFX_ISAGSIGN_BETA_I_H__47B31299_5940_401B_A597_6E834FB1576D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#define _WIN32_WINNT 0X0500
#include "windows.h"
#include "wincrypt.h"
#define CERT_STORE_NAME  L"MY"
#define MY_ENCODE_TYPE (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING)

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IApp:
// See ISAGSign_beta_I.cpp for the implementation of this class
//
#include "Utilities.h"
#include "SignAndVerify.h"
#include "SignatureInformation.h"

class CISAGSign_beta_IApp : public CWinApp
{
public:
	BOOL VerifySignatureMSWord();
	BOOL VerifySignatureMSExcel();
	CISAGSign_beta_IApp();
	virtual ~CISAGSign_beta_IApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CISAGSign_beta_IApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	int sigStatus;
	CWnd *containerWnd;
	SIGN_STEP signStep;
	ISAG_RESULT result;
	COleTemplateServer m_server;
	SignatureInformation *currentSigner;
		// Server object for document creation
	//{{AFX_MSG(CISAGSign_beta_IApp)
	afx_msg void OnAppAbout();
	afx_msg void OnSign();
	afx_msg void OnVerify();
	afx_msg void OnCertMgr();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void SignSignatureMSExcel();
	void SignSignatureMSWord();
	SignAndVerify *SignAndVerifyCom;
};
extern CISAGSign_beta_IApp NEAR theApp;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAGSIGN_BETA_I_H__47B31299_5940_401B_A597_6E834FB1576D__INCLUDED_)
