#if !defined(AFX_CSIGNSTEP03DLG_H__5F2AB8F1_4081_4AB2_A48E_88392F2D7CD3__INCLUDED_)
#define AFX_CSIGNSTEP03DLG_H__5F2AB8F1_4081_4AB2_A48E_88392F2D7CD3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CSignStep03Dlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSignStep03Dlg dialog

class CSignStep03Dlg : public CDialog
{
// Construction
public:
	CSignStep03Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSignStep03Dlg)
	enum { IDD = IDD_SIGN_STEP03 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSignStep03Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
	BOOL OnInitDialog();
protected:

	// Generated message map functions
	//{{AFX_MSG(CSignStep03Dlg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSIGNSTEP03DLG_H__5F2AB8F1_4081_4AB2_A48E_88392F2D7CD3__INCLUDED_)
