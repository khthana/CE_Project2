////////////////////////////////////////////////////////////////////////////////////////////////////
// Utilities.h 

// Sign step.
enum SIGN_STEP {STEP01 , STEP02 , STEP03 ,STEP04};

// Verify result.
enum ISAG_RESULT {NONE , OVER_MAX_VERIFY , OVER_CERT_DURATION , KEY_EXPIRED};

// Sign status.
enum SIGN_STATUS {N0NE , SIGN , UNMODIFIED , MODIFIED};

// SignerInformation structure.
struct SignerInformation 
{
	CString SignerName;
	CString IssuerName;
	CTime IssueDate;
	CTime RevocationDate;
};


