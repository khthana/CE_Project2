; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CVerifyDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ISAGSign_beta_I.h"
LastPage=0

ClassCount=9
Class1=CISAGSign_beta_IApp
Class2=CISAGSign_beta_IDoc
Class3=CISAGSign_beta_IView
Class4=CMainFrame
Class5=CInPlaceFrame

ResourceCount=12
Resource1=IDD_ABOUTBOX
Resource2=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_SIGN_STEP01
Resource6=IDD_VERIFY
Resource3=IDR_SRVR_INPLACE
Resource4=IDR_SRVR_EMBEDDED
Class6=CAboutDlg
Resource7=IDD_SIGN_STEP02
Resource8=IDD_FORMVIEW (English (U.S.))
Resource9=IDR_SRVR_INPLACE (English (U.S.))
Resource10=IDD_SIGN_STEP03
Class7=CSignStep01Dlg
Resource11=IDR_MAINFRAME (English (U.S.))
Class8=CSignStep02Dlg
Class9=CVerifyDlg
Resource12=IDR_SRVR_EMBEDDED (English (U.S.))

[CLS:CISAGSign_beta_IApp]
Type=0
HeaderFile=ISAGSign_beta_I.h
ImplementationFile=ISAGSign_beta_I.cpp
Filter=N
LastObject=CISAGSign_beta_IApp
BaseClass=CWinApp
VirtualFilter=AC

[CLS:CISAGSign_beta_IDoc]
Type=0
HeaderFile=ISAGSign_beta_IDoc.h
ImplementationFile=ISAGSign_beta_IDoc.cpp
Filter=N
LastObject=CISAGSign_beta_IDoc

[CLS:CISAGSign_beta_IView]
Type=0
HeaderFile=ISAGSign_beta_IView.h
ImplementationFile=ISAGSign_beta_IView.cpp
Filter=C
LastObject=IDM_CERT_MGR
BaseClass=CView
VirtualFilter=VWC


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T

[CLS:CInPlaceFrame]
Type=0
HeaderFile=IpFrame.h
ImplementationFile=IpFrame.cpp
Filter=T



[CLS:CAboutDlg]
Type=0
HeaderFile=ISAGSign_beta_I.cpp
ImplementationFile=ISAGSign_beta_I.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[MNU:IDR_SRVR_INPLACE]
Type=1
Class=CISAGSign_beta_IView
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
CommandCount=5
Command5=ID_APP_ABOUT

[TB:IDR_SRVR_INPLACE]
Type=1
Class=CISAGSign_beta_IView
Command1=ID_EDIT_CUT
Command2=ID_EDIT_COPY
Command3=ID_EDIT_PASTE
CommandCount=4
Command4=ID_APP_ABOUT

[MNU:IDR_SRVR_EMBEDDED]
Type=1
Class=CISAGSign_beta_IView
Command1=ID_FILE_UPDATE
Command6=ID_EDIT_PASTE
Command7=ID_VIEW_TOOLBAR
Command8=ID_VIEW_STATUS_BAR
Command9=ID_APP_ABOUT
CommandCount=9
Command2=ID_APP_EXIT
Command3=ID_EDIT_UNDO
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY

[ACL:IDR_SRVR_INPLACE]
Type=1
Class=CISAGSign_beta_IView
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
CommandCount=8

[ACL:IDR_SRVR_EMBEDDED]
Type=1
Class=CISAGSign_beta_IView
Command1=ID_FILE_UPDATE
Command3=ID_EDIT_CUT
Command4=ID_EDIT_COPY
Command5=ID_EDIT_PASTE
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_NEXT_PANE
CommandCount=11
Command2=ID_EDIT_UNDO
Command11=ID_PREV_PANE


[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=IDC_SIGN
Command2=IDC_VERIFY
CommandCount=2

[TB:IDR_SRVR_INPLACE (English (U.S.))]
Type=1
Class=CISAGSign_beta_IView
Command1=IDT_SIGN
Command2=IDT_VERIFY
CommandCount=2

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_APP_EXIT
Command2=ID_APP_ABOUT
CommandCount=2

[MNU:IDR_SRVR_INPLACE (English (U.S.))]
Type=1
Class=CISAGSign_beta_IView
Command1=IDM_SIGN
Command2=IDM_VERIFY
Command3=IDM_CERT_MGR
Command4=ID_APP_ABOUT
CommandCount=4

[MNU:IDR_SRVR_EMBEDDED (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_UPDATE
Command2=ID_APP_EXIT
Command3=ID_EDIT_UNDO
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_VIEW_TOOLBAR
Command8=ID_VIEW_STATUS_BAR
Command9=ID_APP_ABOUT
CommandCount=9

[ACL:IDR_SRVR_INPLACE (English (U.S.))]
Type=1
Class=?
Command1=ID_EDIT_UNDO
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_CANCEL_EDIT_SRVR
CommandCount=9

[ACL:IDR_SRVR_EMBEDDED (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_UPDATE
Command2=ID_EDIT_UNDO
Command3=ID_EDIT_CUT
Command4=ID_EDIT_COPY
Command5=ID_EDIT_PASTE
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_NEXT_PANE
Command11=ID_PREV_PANE
CommandCount=11

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_FORMVIEW (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC,static,1342308352

[DLG:IDD_VERIFY]
Type=1
Class=CVerifyDlg
ControlCount=19
Control1=IDC_STATIC,static,1342177294
Control2=IDC_SIGINFO,button,1342177287
Control3=IDS_SIGNER_NAME,static,1342308354
Control4=IDS_ISSUE_DATE,static,1342308354
Control5=IDS_ISSUE_NAME,static,1342308354
Control6=IDS_REVOCATION_DATE,static,1342308354
Control7=IDS_SIGN_DATE,static,1342308354
Control8=IDS_SIGNER_NAME2,static,1342308352
Control9=IDS_ISSUE_NAME2,static,1342308352
Control10=IDS_ISSUE_DATE2,static,1342308352
Control11=IDS_REVOCATION_DATE2,static,1342308352
Control12=IDS_SIGN_DATE2,static,1342308352
Control13=IDC_CLOSE,button,1342242816
Control14=IDS_CERT_FM,static,1342177282
Control15=IDC_CERT_FM2,static,1342308352
Control16=IDS_CERT_TO,static,1342177282
Control17=IDC_CERT_TO2,static,1342308352
Control18=IDC_ABOUT,button,1342242816
Control19=IDC_STATIC,static,1350565902

[CLS:CSignStep01Dlg]
Type=0
HeaderFile=CSignStep01Dlg.h
ImplementationFile=CSignStep01Dlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CSignStep01Dlg
VirtualFilter=dWC

[DLG:IDD_SIGN_STEP03]
Type=1
Class=?
ControlCount=3
Control1=IDC_STATIC,static,1342177287
Control2=IDC_PROGRESS1,msctls_progress32,1350565888
Control3=IDS_WAIT,static,1342308352

[DLG:IDD_SIGN_STEP01]
Type=1
Class=CSignStep01Dlg
ControlCount=4
Control1=IDC_SIGNER_LIST,SysListView32,1350631424
Control2=IDC_COMMENT01,static,1342308352
Control3=IDC_NEXT,button,1342242817
Control4=IDC_EXIT,button,1342242816

[DLG:IDD_SIGN_STEP02]
Type=1
Class=CSignStep02Dlg
ControlCount=17
Control1=ID_SIGN,button,1342242817
Control2=IDC_EXIT,button,1342242816
Control3=IDC_HASH_ALG,button,1342177287
Control4=IDC_MD4,button,1342177289
Control5=IDC_SIGNIMAGE,static,1350566414
Control6=IDC_MD5,button,1342177289
Control7=IDC_SHA,button,1342177289
Control8=IDC_CERT_LMT,button,1342177287
Control9=IDC_MAXAPPROVE_CHECK,button,1342242819
Control10=IDC_CERTDUR_CHECK,button,1342242819
Control11=IDC_FROMDATE,SysDateTimePick32,1476460576
Control12=IDC_TODATE,SysDateTimePick32,1476460576
Control13=IDC_MAXAPPROVE_EDIT,edit,1484980352
Control14=IDC_STATIC,static,1342308354
Control15=IDC_STATIC,static,1342308354
Control16=IDC_SIGN_IMG,static,1342308352
Control17=IDC_MAXSPIN,msctls_updown32,1342177314

[CLS:CSignStep02Dlg]
Type=0
HeaderFile=CSignStep02Dlg.h
ImplementationFile=CSignStep02Dlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CSignStep02Dlg
VirtualFilter=dWC

[CLS:CVerifyDlg]
Type=0
HeaderFile=VerifyDlg.h
ImplementationFile=VerifyDlg.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_CLOSE

