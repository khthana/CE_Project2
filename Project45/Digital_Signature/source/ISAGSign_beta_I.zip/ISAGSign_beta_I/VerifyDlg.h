#if !defined(AFX_VERIFYDLG_H__B1E9BB24_46A1_47C0_B503_CEC71670D51F__INCLUDED_)
#define AFX_VERIFYDLG_H__B1E9BB24_46A1_47C0_B503_CEC71670D51F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VerifyDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CVerifyDlg dialog

class CVerifySignatureDlg : public CDialog
{
// Construction
public:
	CVerifySignatureDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CVerifyDlg)
	enum { IDD = IDD_VERIFY };
	CStatic	m_iName;
	CStatic	m_sName;
	CStatic	m_sDate;
	CStatic	m_rDate;
	CStatic	m_iDate;
	CStatic	m_certTO;
	CStatic	m_certFM;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVerifyDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
	BOOL OnInitDialog();
protected:

	// Generated message map functions
	//{{AFX_MSG(CVerifyDlg)
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VERIFYDLG_H__B1E9BB24_46A1_47C0_B503_CEC71670D51F__INCLUDED_)
