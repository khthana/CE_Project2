// SignatureInformation.cpp: implementation of the SignatureInformation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "SignatureInformation.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMPLEMENT_SERIAL (SignatureInformation , CObject , 1);

SignatureInformation::SignatureInformation()
{
	signerInfo.SignerName = "Mc Fisho";
	signerInfo.IssuerName = "XXX";
//	signerInfo.IssueDate  = "10/10/10";
//	signerInfo.RevocationDate = "10/10/10";
//	certFm = "XXX";
//	certTo = "XXX";
//	signDate = "XXX";
	hashAlgo = "MD5";
	maxApprove = -1;
	pbSignatureLen = 0;
	pbSignature = NULL;
}

SignatureInformation::SignatureInformation(const SignatureInformation& sigInfo)
{
	signerInfo = sigInfo.signerInfo;
	hashAlgo = sigInfo.hashAlgo;
	certFm = sigInfo.certFm;
	certTo = sigInfo.certTo;
	hashAlgo = sigInfo.hashAlgo;
	signDate = sigInfo.signDate;
	maxApprove = sigInfo.maxApprove;
	pbSignatureLen = sigInfo.pbSignatureLen;
	pbSignature = new BYTE[pbSignatureLen];
	CopyMemory(pbSignature , sigInfo.pbSignature , pbSignatureLen);
}

SignatureInformation::~SignatureInformation()
{
//	delete [] pbSignature;
}

void SignatureInformation::SetDefault()
{
	signerInfo.SignerName = "Mc Fisho";
	signerInfo.IssuerName = "XXX";
//	signerInfo.IssueDate  = "10/10/10";
//	signerInfo.RevocationDate = "10/10/10";
//	certFm = "XXX";
//	certTo = "XXX";
//	signDate = "XXX";
	hashAlgo = "MD5";
	maxApprove = -1;
	pbSignatureLen = 0;
	pbSignature = NULL;
}

void SignatureInformation::Serialize(CArchive &ar)
{
	CObject::Serialize(ar);
	if (ar.IsStoring())
	{
		ar << signerInfo.SignerName;
		ar << signerInfo.IssuerName;
		ar << signerInfo.IssueDate;
		ar << signerInfo.RevocationDate;
		ar << signDate;
		ar << certFm;
		ar << certTo;
		ar << maxApprove;
		ar << hashAlgo;
		ar << pbSignatureLen;
		ar.Write(pbSignature , pbSignatureLen);		
	}
	else
	{
		ar >> signerInfo.SignerName;
		ar >> signerInfo.IssuerName;
		ar >> signerInfo.IssueDate;
		ar >> signerInfo.RevocationDate;
		ar >> signDate;
		ar >> certFm;
		ar >> certTo;
		ar >> maxApprove;
		ar >> hashAlgo;
		ar >> pbSignatureLen;
		pbSignature = new BYTE[pbSignatureLen];
		ar.Read(pbSignature  , pbSignatureLen);
	}

}

void SignatureInformation::setSignerInfo(SignerInformation signerInfo)
{
	//////////////////////////////////////////////////////////////////
	// Set signer information.
	this->signerInfo.SignerName		= signerInfo.SignerName;
	this->signerInfo.IssuerName		= signerInfo.IssuerName;
	this->signerInfo.IssueDate		= signerInfo.IssueDate;
	this->signerInfo.RevocationDate = signerInfo.RevocationDate;
}

void SignatureInformation::setHashAlgorithm(CString hashAlgo)
{
	/////////////////////////////////////////////////////////////////
	// Set hash algorithm.
	this->hashAlgo = hashAlgo;
}

void SignatureInformation::setMaxApprove(int maxAppv)
{
	/////////////////////////////////////////////////////////////////
	// Set maximum approve.
	this->maxApprove = maxAppv;
}

void SignatureInformation::setSignDate(CTime signDate)
{
	/////////////////////////////////////////////////////////////////
	// Set sign signature date.
	this->signDate = signDate;
}

void SignatureInformation::setCertDuration(CTime fm , CTime to)
{
	/////////////////////////////////////////////////////////////////
	// Set certificate duration.
	this->certFm = fm;
	this->certTo = to;
}

void SignatureInformation::setPbSignatureBlob(BYTE *pbSig , UINT pbSigLen)
{
	/////////////////////////////////////////////////////////////////
	// Set signature blob.
	this->pbSignatureLen = pbSigLen;
	this->pbSignature = new BYTE[pbSigLen];
    CopyMemory(pbSignature , pbSig , pbSignatureLen);
}

SignerInformation SignatureInformation::getSignerInfo()
{
	/////////////////////////////////////////////////////////////////
	// Return signer information.
	return this->signerInfo;
}

CString SignatureInformation::getHashAlgorithm()
{
	/////////////////////////////////////////////////////////////////
	// Return hash algorithm.
	return this->hashAlgo;
}

int SignatureInformation::getMaxApprove()
{
	/////////////////////////////////////////////////////////////////
	// Return the max approve.
	return this->maxApprove;
}

CTime SignatureInformation::getSignDate()
{
	/////////////////////////////////////////////////////////////////
	// Return sign signature date.
	return this->signDate;
}

CTime SignatureInformation::getCertFrom()
{
	/////////////////////////////////////////////////////////////////
	// Return the certificate from date.
	return this->certFm;
}

CTime SignatureInformation::getCertTo()
{
	/////////////////////////////////////////////////////////////////
	// Return the certificate to date.
	return this->certTo;
}

BYTE* SignatureInformation::getPbSignatureBlob()
{
	/////////////////////////////////////////////////////////////////
	// Return digital signature blob.
	return this->pbSignature;
}

UINT SignatureInformation::getPbSignatureBlobLength()
{
	/////////////////////////////////////////////////////////////////
	// Return digital signature blob length.
	return this->pbSignatureLen;
}


