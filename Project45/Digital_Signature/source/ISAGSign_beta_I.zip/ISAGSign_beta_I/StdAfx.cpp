// stdafx.cpp : source file that includes just the standard includes
//	ISAGSign_beta_I.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



