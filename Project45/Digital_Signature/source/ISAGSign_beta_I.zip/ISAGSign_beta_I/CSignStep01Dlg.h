#if !defined(AFX_CSIGNSTEP01DLG_H__9F10823F_988B_4780_B1F4_B836E6C50BD8__INCLUDED_)
#define AFX_CSIGNSTEP01DLG_H__9F10823F_988B_4780_B1F4_B836E6C50BD8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CSignStep01Dlg.h : header file
//

#include "FontCtrl.h"
#include "CertStore.h"

/////////////////////////////////////////////////////////////////////////////
// CSignStep01Dlg dialog

class CSignStep01Dlg : public CDialog
{
// Construction
public:
	BOOL OnInitDialog();
	CSignStep01Dlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CSignStep01Dlg();
// Dialog Data
	//{{AFX_DATA(CSignStep01Dlg)
	enum { IDD = IDD_SIGN_STEP01 };
	CListCtrl m_signerList;
	CFontCtrl<CStatic> m_cmt;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSignStep01Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSignStep01Dlg)
	afx_msg void OnDblclkSignerList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSign();
	afx_msg void OnExit();
	afx_msg void OnNext();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private :
	int signerCount;
	CString signerSelectedName;
	CCertStore *certificateStore;
	SignerInformation *signerList;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSIGNSTEP01DLG_H__9F10823F_988B_4780_B1F4_B836E6C50BD8__INCLUDED_)
