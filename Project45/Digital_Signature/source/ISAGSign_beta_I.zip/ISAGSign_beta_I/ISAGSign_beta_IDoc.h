// ISAGSign_beta_IDoc.h : interface of the CISAGSign_beta_IDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISAGSIGN_BETA_IDOC_H__7F26B891_D97D_4BD7_B944_58DA08C058BD__INCLUDED_)
#define AFX_ISAGSIGN_BETA_IDOC_H__7F26B891_D97D_4BD7_B944_58DA08C058BD__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SignatureInformation.h"	// Added by ClassView

class CISAGSign_beta_ISrvrItem;

class CISAGSign_beta_IDoc : public COleServerDoc
{
protected: // create from serialization only
	CISAGSign_beta_IDoc();
	DECLARE_DYNCREATE(CISAGSign_beta_IDoc)

// Attributes
public:
	CISAGSign_beta_ISrvrItem* GetEmbeddedItem()
		{ return (CISAGSign_beta_ISrvrItem*)COleServerDoc::GetEmbeddedItem(); }

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CISAGSign_beta_IDoc)
	protected:
	virtual COleServerItem* OnGetEmbeddedItem();
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetSignatureInfo(const SignatureInformation&);
	virtual ~CISAGSign_beta_IDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CISAGSign_beta_IDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private :
	SignatureInformation signatureInfo;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAGSIGN_BETA_IDOC_H__7F26B891_D97D_4BD7_B944_58DA08C058BD__INCLUDED_)
