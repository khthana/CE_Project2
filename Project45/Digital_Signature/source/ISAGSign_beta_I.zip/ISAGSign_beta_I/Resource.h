//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ISAGSign_beta_I.rc
//
#define IDR_SRVR_INPLACE                4
#define IDR_SRVR_EMBEDDED               5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_USE_INSERT_OBJECT           101
#define IDR_MAINFRAME                   128
#define IDR_ISAGSITYPE                  129
#define IDR_ISAGSIGN                    132
#define IDD_SIGN_STEP01                 133
#define IDD_SIGN_STEP03                 134
#define IDD_VERIFY                      135
#define IDD_SIGN_STEP02                 136
#define IDB_DST                         137
#define IDB_KEY                         138
#define IDB_VER                         139
#define IDB_MOD                         145
#define IDB_UNM                         146
#define IDB_LGO                         151
#define IDB_BITMAP3                     156
#define IDC_SIGNER_LIST                 1000
#define IDC_PROGRESS1                   1002
#define IDS_WAIT                        1003
#define IDS_SIGNER_NAME                 1004
#define IDS_ISSUE_DATE                  1005
#define IDS_ISSUE_NAME                  1006
#define IDS_REVOCATION_DATE             1007
#define IDS_SIGN_DATE                   1008
#define IDS_SIGNER_NAME2                1009
#define IDS_ISSUE_NAME2                 1010
#define IDS_ISSUE_DATE2                 1011
#define IDS_REVOCATION_DATE2            1012
#define IDS_SIGN_DATE2                  1013
#define IDS_CERT_FM                     1014
#define IDC_CERT_FM2                    1015
#define IDC_EXIT                        1016
#define IDS_CERT_TO                     1016
#define IDC_MD4                         1017
#define IDC_CERT_TO2                    1017
#define IDC_MD5                         1018
#define IDC_SHA                         1019
#define IDC_MAXAPPROVE_CHECK            1020
#define IDC_CERTDUR_CHECK               1021
#define IDC_FROMDATE                    1023
#define IDC_TODATE                      1024
#define IDC_MAXAPPROVE_EDIT             1025
#define IDC_SIGNIMAGE                   1027
#define ID_SIGN                         1028
#define IDC_MAXSPIN                     1032
#define IDC_COMMENT01                   1033
#define IDC_CLOSE                       1034
#define IDC_ABOUT                       1036
#define IDC_NEXT                        1037
#define IDC_HASH_ALG                    1040
#define IDC_CERT_LMT                    1041
#define IDC_SIGN_IMG                    1042
#define IDC_SIGINFO                     1043
#define ID_CANCEL_EDIT_SRVR             32769
#define IDC_SIGN                        32771
#define IDT_SIGN                        32773
#define IDT_VERIFY                      32775
#define IDM_SIGN                        32777
#define IDM_VERIFY                      32778
#define IDC_VERIFY                      32780
#define IDM_CERT_MGR                    32781

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
