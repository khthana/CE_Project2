// ISAGSign_beta_IDoc.cpp : implementation of the CISAGSign_beta_IDoc class
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "CertStore.h"

#include "ISAGSign_beta_IDoc.h"
#include "SrvrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IDoc

IMPLEMENT_DYNCREATE(CISAGSign_beta_IDoc, COleServerDoc)

BEGIN_MESSAGE_MAP(CISAGSign_beta_IDoc, COleServerDoc)
	//{{AFX_MSG_MAP(CISAGSign_beta_IDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IDoc construction/destruction

CISAGSign_beta_IDoc::CISAGSign_beta_IDoc()
{
	// Use OLE compound files
	EnableCompoundFile();

	// TODO: add one-time construction code here
}

CISAGSign_beta_IDoc::~CISAGSign_beta_IDoc()
{
	
}

BOOL CISAGSign_beta_IDoc::OnNewDocument()
{
	if (!COleServerDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IDoc server implementation

COleServerItem* CISAGSign_beta_IDoc::OnGetEmbeddedItem()
{
	// OnGetEmbeddedItem is called by the framework to get the COleServerItem
	//  that is associated with the document.  It is only called when necessary.

	CISAGSign_beta_ISrvrItem* pItem = new CISAGSign_beta_ISrvrItem(this);
	ASSERT_VALID(pItem);
	return pItem;
}



/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IDoc serialization

void CISAGSign_beta_IDoc::Serialize(CArchive& ar)
{
	theApp.currentSigner->Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IDoc diagnostics

#ifdef _DEBUG
void CISAGSign_beta_IDoc::AssertValid() const
{
	COleServerDoc::AssertValid();
}

void CISAGSign_beta_IDoc::Dump(CDumpContext& dc) const
{
	COleServerDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IDoc commands

void CISAGSign_beta_IDoc::SetSignatureInfo(const SignatureInformation &sigInfo)
{
}
