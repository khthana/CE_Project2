// SignatureInformation.h: interface for the SignatureInformation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIGNATUREINFORMATION_H__69BDC749_270D_4E6B_9FB8_0061493A7DDF__INCLUDED_)
#define AFX_SIGNATUREINFORMATION_H__69BDC749_270D_4E6B_9FB8_0061493A7DDF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ISAGSign_beta_I.h"

class SignatureInformation : public CObject  
{
public:
	void SetDefault();
	SignatureInformation();
	SignatureInformation(const SignatureInformation&);
	virtual ~SignatureInformation();

	// Set member variable function.
	void setSignerInfo(SignerInformation);
	void setHashAlgorithm(CString);
	void setSignDate(CTime);
	void setMaxApprove(int);
	void setCertDuration(CTime , CTime);
	void setPbSignatureBlob(BYTE* , UINT);
	
	// Get member variable function.
	SignerInformation getSignerInfo();
	CString getHashAlgorithm();
	CTime getSignDate();
	CTime getCertFrom();
	CTime getCertTo();
	int getMaxApprove();
	BYTE* getPbSignatureBlob();
	UINT getPbSignatureBlobLength();

	// Serialize.
	void Serialize(CArchive&);
	DECLARE_SERIAL(SignatureInformation)
private:
	SignerInformation signerInfo;			// Signer information.
	CString hashAlgo;						// Hash algorithm.
	CTime signDate;							// Sign signature data.
	CTime certFm;							// Certificate from.
	CTime certTo;							// Certificate to.
	int maxApprove;							// Max approve.
	BYTE  *pbSignature;						// Signature blob.
	UINT   pbSignatureLen;					// Signature blob length.
};

#endif // !defined(AFX_SIGNATUREINFORMATION_H__69BDC749_270D_4E6B_9FB8_0061493A7DDF__INCLUDED_)
