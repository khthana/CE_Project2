// DataTransfer.cpp: implementation of the DataTransfer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "DataTransfer.h"
#include "msword8.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

DataTransfer::DataTransfer()
{
	// Initial the begin data block array equal zero.
	m_uNextBlockIndex = 0;
}

DataTransfer::~DataTransfer()
{
	delete [] m_ppData;
}

void DataTransfer::DataToClipboardForSign()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Transfer data to clipboard for sign digital signature.

	// Declare local variable here.
	CLSID			clsid;
	HRESULT			hResult;
	IUnknown	   *pUnk  = NULL;
	IDispatch	   *pDisp = NULL;
	LPDISPATCH		lDisp = NULL;	

		_Document		docObj;
		_Application	appObj;
	
		hResult = GetActiveObject((const CLSID&)clsid,NULL,&pUnk);
		// Check step 01: Find class id and IUnknown of MS-Word application...
		if ( hResult == S_OK )
			AfxMessageBox("OK...PASS step 01");
		else
			AfxMessageBox("NO...PASS step 01");

		hResult = pUnk->QueryInterface(IID_IDispatch,(void**)&pDisp);
		// Check step 02: Query Interface for IDispatch
		if ( hResult == S_OK )
			AfxMessageBox("OK...PASS step 02");
		else
			AfxMessageBox("NO...PASS step 02");

}

void DataTransfer::DataToClipboardForVerify()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Transfer data to clipboard for verify digital signature.

	// Declare local variable here.
/*	CLSID			clsid;
	HRESULT			hResult;
	IUnknown	   *pUnk  = NULL;
	IDispatch	   *pDisp = NULL;
	IDataObject	   *pDataObj = NULL;
	LPDISPATCH		lDisp = NULL;
	LPDATAOBJECT    lDataObj = NULL;
	
		_Document		docObj;
		Documents		docsObj;
		_Application	appObj;

		CLSIDFromProgID(L"Word.Application", &clsid);
		hResult = GetActiveObject((const CLSID&)clsid,NULL,&pUnk);
		// Check step 01: Find class id and IUnknown of MS-Word application...
		if ( hResult == S_OK )
			AfxMessageBox("OK...PASS step 01");
		else
			AfxMessageBox("NO...PASS step 01");

		hResult = pUnk->QueryInterface(IID_IDispatch,(void**)&pDisp);
		// Check step 02: Query Interface for IDispatch
		if ( hResult == S_OK )
			AfxMessageBox("OK...PASS step 02");
		else
			AfxMessageBox("NO...PASS step 02");

		appObj.AttachDispatch(pDisp,TRUE);
		lDisp = appObj.GetDocuments();
		docsObj.AttachDispatch(lDisp,TRUE);

		if (docsObj.GetCount() != 0)
		{
	
			lDisp = appObj.GetActiveDocument();
			docObj.AttachDispatch(lDisp , TRUE);
			hResult = lDisp->QueryInterface(IID_IDataObject , (void**)&pDataObj);

			if ( hResult == S_OK )
				AfxMessageBox("OK...PASS step 03");
			else
				AfxMessageBox("NO...PASS step 03");

			COleDataObject pDO;
			
			lDataObj = pDataObj;
			pDO.Attach(lDataObj , FALSE);
			
			FORMATETC fmetc;
			STGMEDIUM medium;

			fmetc.cfFormat = CF_TEXT & CF_UNICODETEXT & CF_METAFILEPICT;
			fmetc.ptd = NULL;
			fmetc.lindex = -1;
			fmetc.dwAspect = DVASPECT_CONTENT;
			fmetc.tymed = TYMED_HGLOBAL;

			hResult = pDataObj->GetData(&fmetc , &medium);			

			if ( hResult == S_OK )
				AfxMessageBox("OK...PASS step 04");
			if ( hResult == DV_E_LINDEX )
				AfxMessageBox("OK...PASS step 05");				
			if ( hResult == DV_E_FORMATETC )
				AfxMessageBox("OK...PASS step 06");
			if ( hResult == DV_E_TYMED )
				AfxMessageBox("OK...PASS step 07");
			if ( hResult == DV_E_DVASPECT )
				AfxMessageBox("OK...PASS step 08");
			if ( hResult == OLE_E_NOTRUNNING )
				AfxMessageBox("OK...PASS step 09");
			if ( hResult == STG_E_MEDIUMFULL )
				AfxMessageBox("OK...PASS step 10");

			ReadAndFillData(&pDO);
		}
*/
}

void DataTransfer::ReadAndFillData(COleDataObject *pDO)
{
	// --------------------------------------------------------------------
	// Declare and initialize variable here
	FORMATETC			etc;
	UINT				uNumberFormat = 0;
	UINT				uFormat;
	bool				bReadData = false;
	TCHAR				szFormatName[256];
	HGLOBAL				hgData;
//	DWORD				uDataSize;

    ASSERT ( AfxIsValidAddress (pDO,sizeof(COleDataObject) ));

	// --------------------------------------------------------------------
	// Determine how many format are available on the clipboard.
	pDO->BeginEnumFormats();
	while(pDO->GetNextFormat(&etc)) 
		if (pDO->IsDataAvailable(etc.cfFormat))
			uNumberFormat++;

//	*m_ppData = new BYTE[uNumberFormat];
	
	CString cbNumberFormat;
	cbNumberFormat.Format("Number of clipboard format : %d",uNumberFormat);
	AfxMessageBox(cbNumberFormat);

	// --------------------------------------------------------------------
	// Now get all the data and pass it to the doc for storage.
	pDO->BeginEnumFormats();
	while(pDO->GetNextFormat(&etc)) {
		if (!pDO->IsDataAvailable(etc.cfFormat))
			continue;
		
		// ----------------------------------------------------------------
		// See if this is the build-in clipboard format.  
		else {
			uFormat = etc.cfFormat;
			switch(uFormat) {
				case CF_TEXT :
					AfxMessageBox("CF_TEXT");
					break;
				case CF_BITMAP :
					AfxMessageBox("CF_BITMAP");
					break;
				case CF_METAFILEPICT :    
					AfxMessageBox("CF_METAFILEPICT");
					break;
				case CF_SYLK :            
					AfxMessageBox("CF_SYLK");
					break;
				case CF_DIF :             
					AfxMessageBox("CF_DIF");
					break;
				case CF_TIFF :    
					AfxMessageBox("CF_TIFF");
					break;
				case CF_OEMTEXT :        
					AfxMessageBox("CF_OEMTEXT"); 
					break;
				case CF_DIB :             
					AfxMessageBox("CF_DIB"); 
					break;
				case CF_PALETTE :         
					AfxMessageBox("CF_PALETTE"); 
					break;
				case CF_PENDATA :         
					AfxMessageBox("CF_PENDATA"); 
					break;
				case CF_RIFF :            
					AfxMessageBox("CF_RIFF"); 
					break; 
				case CF_WAVE :            
					AfxMessageBox("CF_WAVE"); 
					break; 
				case CF_UNICODETEXT :     
					AfxMessageBox("CF_UNICODETEXT"); 
					break; 
				case CF_ENHMETAFILE :     
					AfxMessageBox("CF_ENHMETAFILE"); 
					break; 
				case CF_HDROP :           
					AfxMessageBox("CF_HDROP"); 
					break; 
				case CF_LOCALE :   
					AfxMessageBox("CF_LOCALE"); 
					break; 
				case CF_OWNERDISPLAY : 
					AfxMessageBox("CF_OWNERDISPLAY"); 
					break; 
				case CF_DSPTEXT :      
					AfxMessageBox("CF_DSPTEXT"); 
					break; 
				case CF_DSPBITMAP :    
					AfxMessageBox("CF_DSPBITMAP"); 
					break; 
				case CF_DSPMETAFILEPICT : 
					AfxMessageBox("CF_DSPMETAFILEPICT"); 
					break; 
				case CF_DSPENHMETAFILE :  
					AfxMessageBox("CF_DSPENHMETAFILE"); 
					break; 
				default : {
					GetClipboardFormatName(etc.cfFormat,szFormatName,256);
					AfxMessageBox(szFormatName);
					break;
				}  // default...					  
			} // switch... 
		} // else... 

/*		// ---------------------------------------------------------------
		// Get an HGLOBAL of the data.
		hgData = pDO->GetGlobalData( etc.cfFormat );
		if ( NULL != hgData ) {
            uDataSize = GlobalSize(hgData);
            AddDataBlock(hgData,uDataSize);
            // Free the memory that GetGlobalData() allocated for us.
            GlobalFree ( hgData );
        }
        else
        {
            // The data isn't in global memory, so try getting an IStream 
            // interface to it.
            STGMEDIUM stg;

            if (pDO->GetData(etc.cfFormat,&stg))
            {
				switch ( stg.tymed )
                {
					case TYMED_HGLOBAL:
                    {
						uDataSize = GlobalSize ( stg.hGlobal );
                        AddDataBlock (stg.hGlobal,uDataSize );
                    }
                    break; // end case stg.tymed = TYMED_HGLOBAL
                    case TYMED_ISTREAM:
                    {
                        LARGE_INTEGER li;
                        ULARGE_INTEGER uli;

                        li.HighPart = li.LowPart = 0;

                        if ( SUCCEEDED( stg.pstm->Seek ( li, STREAM_SEEK_END, &uli )))
                        {
                            HGLOBAL hg = GlobalAlloc ( GMEM_MOVEABLE | GMEM_SHARE , uli.LowPart );
                            void* pv = GlobalLock ( hg );

                            stg.pstm->Seek ( li, STREAM_SEEK_SET, NULL );
                            
                            if ( SUCCEEDED( stg.pstm->Read ( pv, uli.LowPart, (PULONG) &uDataSize )))
                            {
                                GlobalUnlock ( hg );
                                AddDataBlock ( hg, uDataSize );
                                // Free the memory we just allocated.
                                GlobalFree ( hg );
                            }
                            else
								GlobalUnlock ( hg );
                        }
					}
                    break; // end case stg.tymed = TYMED_ISTREAM
				} // end switch   
				ReleaseStgMedium ( &stg );
			}        
		} // else if **/
	} // while...
	etc.cfFormat = CF_UNICODETEXT;
	hgData = pDO->GetGlobalData(etc.cfFormat);
	if (hgData != NULL)
	{
		AfxMessageBox("HGDATA successful...");
	}
	else 
		AfxMessageBox("HGDATA unsuccessful..");
}

void DataTransfer::AddDataBlock(HGLOBAL hgData , const UINT uSize)
{
	LPVOID pvData;
	ASSERT ( NULL != m_ppData );					// Called Init() yet?

    // Get a real pointer to the data.
    pvData = GlobalLock ( hgData );

    if ( NULL != pvData )
    {
        ASSERT ( AfxIsValidAddress ( pvData, uSize, FALSE ));

        // Allocate memory to hold a copy of the data.
        m_ppData [ m_uNextBlockIndex ] = new BYTE [ uSize ];

        // Copy the data to the newly-allocated memory.
        CopyMemory ( m_ppData [ m_uNextBlockIndex ], pvData, uSize );

        // Update other stuff...
        m_uNextBlockIndex++;

        // Unlock the HGLOBAL.
        GlobalUnlock ( hgData );
    }
    else
    {
        // Couldn't access the data, so just add an empty block instead.
        m_ppData [ m_uNextBlockIndex++ ] = NULL;
    }
}