// ISAGSign_beta_IView.cpp : implementation of the CISAGSign_beta_IView class
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"

#include "ISAGSign_beta_IDoc.h"
#include "ISAGSign_beta_IView.h"
#include "SrvrItem.h"
#include "CSignStep01Dlg.h"
#include "CSignStep02Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IView

IMPLEMENT_DYNCREATE(CISAGSign_beta_IView, CView)

BEGIN_MESSAGE_MAP(CISAGSign_beta_IView, CView)
	//{{AFX_MSG_MAP(CISAGSign_beta_IView)
	ON_COMMAND(IDM_VERIFY, OnVerify)
	ON_COMMAND(IDC_SIGN, OnSign)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IView construction/destruction

CISAGSign_beta_IView::CISAGSign_beta_IView()
{
	// TODO: add construction code here

}

CISAGSign_beta_IView::~CISAGSign_beta_IView()
{
}

BOOL CISAGSign_beta_IView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IView drawing

void CISAGSign_beta_IView::OnDraw(CDC* pDC)
{
	CISAGSign_beta_IDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

	BITMAP bmp;
	CBitmap pic;
	pic.LoadBitmap(IDB_DST);
	pic.GetObject(sizeof(BITMAP) , &bmp);
	pDC->DrawState(CPoint(0,0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP , NULL);
}
/////////////////////////////////////////////////////////////////////////////
// OLE Server support

// The following command handler provides the standard keyboard
//  user interface to cancel an in-place editing session.  Here,
//  the server (not the container) causes the deactivation.
void CISAGSign_beta_IView::OnCancelEditSrvr()
{
	GetDocument()->OnDeactivateUI(FALSE);
}

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IView diagnostics

#ifdef _DEBUG
void CISAGSign_beta_IView::AssertValid() const
{
	CView::AssertValid();
}

void CISAGSign_beta_IView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CISAGSign_beta_IDoc* CISAGSign_beta_IView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CISAGSign_beta_IDoc)));
	return (CISAGSign_beta_IDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_IView message handlers


void CISAGSign_beta_IView::OnVerify() 
{
	// TODO: Add your command handler code here
	theApp.OnVerify();
	GetDocument()->GetEmbeddedItem()->NotifyChanged();
}

void CISAGSign_beta_IView::OnSign() 
{
	// TODO: Add your command handler code here
	theApp.OnSign();
	GetDocument()->GetEmbeddedItem()->NotifyChanged();
}


