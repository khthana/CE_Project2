// SrvrItem.h : interface of the CISAGSign_beta_ISrvrItem class
//

#if !defined(AFX_SRVRITEM_H__E8672DA5_674C_42C2_9880_24260100E278__INCLUDED_)
#define AFX_SRVRITEM_H__E8672DA5_674C_42C2_9880_24260100E278__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CISAGSign_beta_ISrvrItem : public COleServerItem
{
	DECLARE_DYNAMIC(CISAGSign_beta_ISrvrItem)

// Constructors
public:
	CISAGSign_beta_ISrvrItem(CISAGSign_beta_IDoc* pContainerDoc);

// Attributes
	CISAGSign_beta_IDoc* GetDocument() const
		{ return (CISAGSign_beta_IDoc*)COleServerItem::GetDocument(); }

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CISAGSign_beta_ISrvrItem)
	public:
	virtual BOOL OnDraw(CDC* pDC, CSize& rSize);
	virtual BOOL OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize);
	//}}AFX_VIRTUAL

// Implementation
public:
	~CISAGSign_beta_ISrvrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SRVRITEM_H__E8672DA5_674C_42C2_9880_24260100E278__INCLUDED_)
