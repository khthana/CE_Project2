// SignAndVerify.cpp: implementation of the SignAndVerify class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "SignAndVerify.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

SignAndVerify::SignAndVerify()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Acquire the CSP <ISAGSIGN is default CSP 's name>
	if (!CryptAcquireContext(
		 &hProv ,									// Pointer to a handle of CSP.
		 "ISAGSIGN" ,								// Key container name. 
		 NULL ,										// Name of CSP.
		 PROV_RSA_FULL ,							// Type of provider to acquire.
		 NULL										// Flag value.
	   ))
	{
		if (!CryptAcquireContext(					
			 &hProv ,								// Pointer to a handle of CSP.
			 "ISAGSIGN" ,							// Key container name. 
			 NULL ,									// Name of CSP..
			 PROV_RSA_FULL ,						// Type of provider to acquire
			 CRYPT_NEWKEYSET						// Flag value to create new key set.
		   ))
		{
			HandleError("Error during acquire the CSP !");	
		}
	}

	// digital signature initialize equal NULL.
	digitalSignature = NULL;
}

SignAndVerify::~SignAndVerify()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Release the CSP
	CryptReleaseContext(hProv , 0);

	////////////////////////////////////////////////////////////////////////////////////////////////
	// Deallocate memory of digital signature blob.
	if (digitalSignature != NULL)
		delete [] digitalSignature;
}

BYTE* SignAndVerify::GetDigitalSignature()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return digital signature in bit stream.
	return digitalSignature;
}

UINT SignAndVerify::GetDigitalSignatureLength()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return digital signature length.
	return digitalSignatureLen;
}

CString SignAndVerify::GetHashValue()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the hash value in CString format.
	
	// Declare local variable here.
	BYTE		*pbHash;
	BYTE		*pbHashSize;
	DWORD		dwHashLen = sizeof(DWORD);
	DWORD		index;
	CString		hashDigit;

	// Allocate memory for hash value.
	if(!(pbHashSize =(BYTE*)malloc(dwHashLen)))
		HandleError("Memory allocation failed.");
	
	// Retrieve the hash value from hash object step 01 - 03.
	// Step 01:  
	if (!CryptGetHashParam(hHash , HP_HASHSIZE , pbHashSize , &dwHashLen , 0))
		HandleError("CryptGetHashParam failed to get size....step 01");
	// Step 02:
	if (!CryptGetHashParam(hHash , HP_HASHVAL , NULL , &dwHashLen , 0))
		HandleError("CryptGetHashParam failed to get size....step 02");

	if (!(pbHash = (BYTE*)malloc(dwHashLen)))
		HandleError("Allocation failed...");

	// Step 03:
	if (CryptGetHashParam(hHash , HP_HASHVAL , pbHash , &dwHashLen , 0)) 
	{
		// Convert the hash value from bit stream to CString type.
		for(index = 0 ; index < dwHashLen ; index++) 
		{
			hashDigit.Format("%2.2x ",pbHash[index]);
			hashValue = hashValue + hashDigit;
		}
	}			
	else
	    HandleError("Error during reading hash value.");

	return hashValue;
}

void SignAndVerify::FindHashValue(BYTE* dataStream , UINT dataStreamLen , CString hashAlgo)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Create and find hash value from dataStream with specific hash algorithm in hashAlgo.

	// Declare local variable here.

	// Create hash object.
	if (hashAlgo == "MD4") 
		if (!CryptCreateHash(hProv , CALG_MD4 , 0 , 0 , &hHash))
			HandleError("Error in create hash object process !");
	if (hashAlgo == "MD5")
		if (!CryptCreateHash(hProv , CALG_MD5 , 0 , 0 , &hHash))
			HandleError("Error in create hash object process !");
	if (hashAlgo == "SHA")
		if (!CryptCreateHash(hProv , CALG_SHA , 0 , 0 , &hHash))
			HandleError("Error in create hash object process !");

	// Find hash value.
	if (!CryptHashData(hHash , dataStream , dataStreamLen , 0))
		HandleError("Error during CryptHashData !");
}

void SignAndVerify::SignSignature(BYTE* hashStream , UINT hashStreamLen , CString userName)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Declare local variable here.
	HCERTSTORE					hStoreHandle;
	PCCERT_CONTEXT				pSignerCert = NULL;
	CRYPT_SIGN_MESSAGE_PARA		SigParams;
	DWORD						cbSignedMessageBlob;
	BYTE					   *pbSignedMessageBlob;
	const BYTE *messageArray[] = {hashStream};
	DWORD messageSize[1] = {hashStreamLen};

	// Open certificate store
	if (!(hStoreHandle = CertOpenStore(CERT_STORE_PROV_SYSTEM , 0 , NULL , CERT_SYSTEM_STORE_CURRENT_USER , CERT_STORE_NAME)))
		HandleError("Error during CertOpenStore !");

	// Get pointer to signer's certificate.     
	// This is certificate must have access to the signer's private key.

	while (pSignerCert = CertEnumCertificatesInStore(hStoreHandle , pSignerCert))
	{
		
		if (GetCertificateSubject(&(pSignerCert->pCertInfo->Subject)) == userName) 
		{
			break;
		}
	}

	// Initialize the signature structure.
	SigParams.cbSize = sizeof(CRYPT_SIGN_MESSAGE_PARA);
	SigParams.dwMsgEncodingType = MY_ENCODE_TYPE;
	SigParams.pSigningCert = pSignerCert;
	SigParams.HashAlgorithm.pszObjId = szOID_RSA_MD5;
	SigParams.HashAlgorithm.Parameters.cbData = NULL;
	SigParams.cMsgCert = 1;
	SigParams.rgpMsgCert = &pSignerCert;
	SigParams.cAuthAttr = 0;
	SigParams.dwInnerContentType = 0;
	SigParams.cMsgCrl = 0;
	SigParams.cUnauthAttr = 0;
	SigParams.dwFlags = 0;
	SigParams.pvHashAuxInfo = NULL;
	SigParams.rgAuthAttr = NULL;

	// With two calls to CryptSignMessage , sign the message.
	// First get the size of the output sign blob.
	if (!CryptSignMessage(
		 &SigParams ,							// Signature parameters.
		 FALSE ,								// Not detached.
		 1 ,									// Number of message.
		 messageArray ,							// Message to be signed.
		 messageSize ,							// Size of message.
		 NULL ,									// Buffer for signed message.
		 &cbSignedMessageBlob					// Size of buffer.
	   ))
	{
		HandleError("Error during CryptSignMessage step 1...!");
	}

	// Allocate memory for sign blob.
	if (!(pbSignedMessageBlob = new BYTE[cbSignedMessageBlob]))
		HandleError("Error during allocate memory for sign blob !");

	// Second get the signed message blob.
	if (!CryptSignMessage(
		 &SigParams ,							// Signature parameters.
		 FALSE ,								// Not detached.
		 1 ,									// Number of message.
		 messageArray ,							// Message to be signed.
		 messageSize ,							// Size of messages.
		 pbSignedMessageBlob ,					// Buffer for signed message.
		 &cbSignedMessageBlob					// Size of buffer.
	   ))
	{
		HandleError("Error during CryptSignMessage step 2...!");	
	}

	// Assign digitalSignatureLen = cbSignedMessageBlob   
	// Assign digitalSignature    = pbSignedMessageBloc
	digitalSignatureLen = cbSignedMessageBlob;
	digitalSignature = new BYTE[digitalSignatureLen];
	CopyMemory(digitalSignature , pbSignedMessageBlob , digitalSignatureLen);
	// Deallocate memory here.
	delete [] pbSignedMessageBlob;
}

BOOL SignAndVerify::VerifySignature(BYTE *message , DWORD messageLen , BYTE* hashMessage)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Verify the message signature.

	// Declare local variable here.
	CRYPT_VERIFY_MESSAGE_PARA		 VerifyParams;
	DWORD						     cbDecodedMessageBlob;
	BYTE							*pbDecodedMessageBlob;

	// Initialize the VerifyParams data sturcture.
	VerifyParams.cbSize = sizeof(CRYPT_VERIFY_MESSAGE_PARA);
	VerifyParams.dwMsgAndCertEncodingType = MY_ENCODE_TYPE;
	VerifyParams.hCryptProv = 0;
	VerifyParams.pfnGetSignerCertificate = NULL;
	VerifyParams.pvGetArg = NULL;

	// With two calls to CryptVerifyMessageSignature, verify and decode the signed message.
	// First   ,   call CryptVerifyMessageSignature to get the length of the buffer need to hold the
	// decode message.
	if (!CryptVerifyMessageSignature(
		 &VerifyParams ,						// Verify parameters.
		 0 ,									// Signer index.
		 message ,								// Pointer to signed blob.
		 messageLen ,							// Size of signed blob.
		 NULL ,									// Buffer to decode message. 
		 &cbDecodedMessageBlob ,				// Size of buffer. 
		 NULL									// Pointer to signer certificate.
	   ))
	{
		HandleError("Error during CryptVerifyMessageSignature step 1... !");
	}

	// Allocate memory for the buffer
	if (!(pbDecodedMessageBlob = new BYTE[cbDecodedMessageBlob]))
	{
		HandleError("Error in allocate memory for buffer to decode message !");
	}

	// Second  ,  call CryptVerifyMessageSignature agian to copy the message into the buffer.
	if (!CryptVerifyMessageSignature(
		 &VerifyParams ,						// Verify parameters.
		 0 ,									// Signer index
		 message ,								// Pointer to signed blob.
		 messageLen ,							// Size of signed blob.
		 pbDecodedMessageBlob ,				    // Buffer to decode message.
		 &cbDecodedMessageBlob ,				// Size of buffer.
		 NULL									// Pointer to signer certificate.
	   ))
	{
		HandleError("Error during CryptVerifyMessageSignature step 2... !");
	}

	// If hash message equal decode message then return true else return false.
	BOOL result = TRUE;
	for (UINT i = 0 ; i < cbDecodedMessageBlob ; i++)
		if (pbDecodedMessageBlob[i] != hashMessage[i])
		{
			result = FALSE;
			break;
		}
		
	// Deallocate memory here.
	delete [] pbDecodedMessageBlob;
	return result;
}

CString SignAndVerify::GetCertificateSubject(CERT_NAME_BLOB *nameBlob)
{
	// Declare and initialize local variable here.
	int				t1 = -1 , t2 = -1;		// String separater.
	LPSTR		    pszName;	
	DWORD			cbName;
	DWORD			dwStrType = CERT_OID_NAME_STR;
	
	// The function CertNameToStr returns the number of bytes needed for a string to hold the name.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 NULL,							// Pointer to buffer.
			 0);							// Size of buffer.

	// If it return zero then there has been an error.
	if (0 == cbName)
		HandleError("Error during GetCertificateInformation !");

	// Allocate the needed buffer.
	if (!(pszName = new char[cbName]))
		HandleError("Error during in allcation memory for CERT_NAME_BLOB !");

	// Call the function again to get the string.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 pszName ,						// Pointer to buffer.
			 cbName);						// Size of buffer.

	// Declare and initialize local variable for tag finding.
	CString	tempStr1(pszName) , tempStr2 , tempStr3 , tempStr4 , tag;
	// If found issuer name in certificate information then certificate can be used.
	t1 = tempStr1.Find("2.5.4.3");								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');
	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx
	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx
	
	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

void SignAndVerify::HandleError(CString errorMsg)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Handle the error occured in running the program
	AfxMessageBox(errorMsg , MB_OK | MB_ICONSTOP);
	exit(1);
}


