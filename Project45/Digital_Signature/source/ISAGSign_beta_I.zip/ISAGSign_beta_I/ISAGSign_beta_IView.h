// ISAGSign_beta_IView.h : interface of the CISAGSign_beta_IView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ISAGSIGN_BETA_IVIEW_H__3B4897A8_CA66_4957_8465_2245C863D8DB__INCLUDED_)
#define AFX_ISAGSIGN_BETA_IVIEW_H__3B4897A8_CA66_4957_8465_2245C863D8DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SignAndVerify.h"

class CISAGSign_beta_IView : public CView
{
protected: // create from serialization only
	CISAGSign_beta_IView();
	DECLARE_DYNCREATE(CISAGSign_beta_IView)

// Attributes
public:
	CISAGSign_beta_IDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CISAGSign_beta_IView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CISAGSign_beta_IView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CISAGSign_beta_IView)
	afx_msg void OnCancelEditSrvr();
	afx_msg void OnVerify();
	afx_msg void OnSign();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ISAGSign_beta_IView.cpp
inline CISAGSign_beta_IDoc* CISAGSign_beta_IView::GetDocument()
   { return (CISAGSign_beta_IDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ISAGSIGN_BETA_IVIEW_H__3B4897A8_CA66_4957_8465_2245C863D8DB__INCLUDED_)
