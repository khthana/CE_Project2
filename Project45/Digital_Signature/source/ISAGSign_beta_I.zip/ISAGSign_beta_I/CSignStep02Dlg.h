#if !defined(AFX_CSIGNSTEP02DLG_H__81CD649C_5E9B_4141_AECF_86A82BB16980__INCLUDED_)
#define AFX_CSIGNSTEP02DLG_H__81CD649C_5E9B_4141_AECF_86A82BB16980__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CSignStep02Dlg.h : header file
//

#include "FontCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CSignStep02Dlg dialog

class CSignStep02Dlg : public CDialog
{
// Construction
public:
	CSignStep02Dlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSignStep02Dlg)
	enum { IDD = IDD_SIGN_STEP02 };
	CFontCtrl<CStatic>	m_sign;
	CFontCtrl<CButton>	m_cert;
	CFontCtrl<CButton>	m_hash;
	CSpinButtonCtrl	m_maxspin;
	CButton	m_dur;
	CButton	m_max;
	CDateTimeCtrl	m_toctrl;
	CDateTimeCtrl	m_fmctrl;
	CEdit	m_maxedit;
	CTime	m_fmdate;
	CTime	m_todate;
	int		m_maxapp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSignStep02Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	BOOL OnInitDialog();

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSignStep02Dlg)
	afx_msg void OnMD4();
	afx_msg void OnMD5();
	afx_msg void OnSHA();
	afx_msg void OnMaxApproveCheck();
	afx_msg void OnCertDurationCheck();
	afx_msg void OnSign();
	afx_msg void OnExit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CString m_Hash;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CSIGNSTEP02DLG_H__81CD649C_5E9B_4141_AECF_86A82BB16980__INCLUDED_)
