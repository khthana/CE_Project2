// CVerifyResultDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "CVerifyResultDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVerifyResultDlg dialog


CVerifyResultDlg::CVerifyResultDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVerifyResultDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVerifyResultDlg)
	//}}AFX_DATA_INIT
}


void CVerifyResultDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVerifyResultDlg)
	DDX_Control(pDX, IDS_ISSUE_NAME, m_iname);
	DDX_Control(pDX, IDS_SIGN_DATE, m_sdate);
	DDX_Control(pDX, IDS_SIGNER_NAME, m_sname);
	DDX_Control(pDX, IDC_CERT_TO2, m_scDateTO);
	DDX_Control(pDX, IDC_CERT_FM2, m_scDateFM);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CVerifyResultDlg, CDialog)
	//{{AFX_MSG_MAP(CVerifyResultDlg)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVerifyResultDlg message handlers

BOOL CVerifyResultDlg::OnInitDialog()
{
	/////////////////////////////////////////////////////////////////////////
	// Declare and initialize local variable here.
	SignerInformation signer = theApp.currentSigner->getSignerInfo();
	CTime signDate = theApp.currentSigner->getSignDate();
	CString signDateStr = signDate.FormatGmt("%H:%M , %d %A %B %Y");  

	// Display signature information.
	// Update the data to control.
	UpdateData(FALSE);
	m_signerName.SetWindowText(signer.SignerName);
//	m_issueName.SetWindowText(signer.IssuerName);
//	m_issueDate.SetWindowText(signer.IssueDate.FormatGmt("%H:%M , %d %A %B %Y"));
//	m_revDate.SetWindowText(signer.RevocationDate.FormatGmt("%H:%M , %d %A %B %Y"));
//	m_signDate.SetWindowText(signDateStr);

	AfxMessageBox(signer.SignerName);
	AfxMessageBox(signer.IssuerName);
	AfxMessageBox(signer.IssueDate.FormatGmt("%H:%M , %d %A %B %Y"));
	AfxMessageBox(signer.RevocationDate.FormatGmt("%H:%M , %d %A %B %Y"));
	AfxMessageBox(signDateStr);

	// Set font in bold from and blue color.
	m_sname.ChangeFontStyle(FC_FONT_BOLD);
	m_sname.SetTextColor(0x00C00000);
	m_iname.ChangeFontStyle(FC_FONT_BOLD);
	m_iname.SetTextColor(0x00C00000);
	m_idate.ChangeFontStyle(FC_FONT_BOLD);
	m_idate.SetTextColor(0x00C00000);
	m_rdate.ChangeFontStyle(FC_FONT_BOLD);
	m_rdate.SetTextColor(0x00C00000);
	m_sdate.ChangeFontStyle(FC_FONT_BOLD);
	m_sdate.SetTextColor(0x00C00000);
	m_scDateFM.ChangeFontStyle(FC_FONT_BOLD);
	m_scDateFM.SetTextColor(0x00C00000);
	m_scDateTO.ChangeFontStyle(FC_FONT_BOLD);
	m_scDateTO.SetTextColor(0x00C00000);

	m_sigInfo.ChangeFontStyle(FC_FONT_BOLD);

	UpdateView();
	return TRUE;
}

void CVerifyResultDlg::OnClose() 
{
	// TODO: Add your control notification handler code here
	SendMessage(WM_CLOSE);
}

void CVerifyResultDlg::UpdateView()
{
	if (theApp.result == KEY_EXPIRED)
		m_rdate.SetTextColor(0x0000FF00);
	
	if (theApp.result == OVER_CERT_DURATION)
		m_sdate.SetTextColor(0x0000FF00);

	if (theApp.result == OVER_MAX_VERIFY)
		AfxMessageBox("Over max approve..." , MB_OK | MB_ICONINFORMATION);
}

void CVerifyResultDlg::OnAbout() 
{
	/////////////////////////////////////////////////////////////////////////
	// Show about dialog.
}
