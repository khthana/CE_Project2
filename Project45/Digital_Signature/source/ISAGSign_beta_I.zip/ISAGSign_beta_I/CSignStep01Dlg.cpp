// CSignStep01Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "CSignStep01Dlg.h"
#include "CSignStep02Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep01Dlg dialog


CSignStep01Dlg::CSignStep01Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSignStep01Dlg::IDD, pParent)
{

}

CSignStep01Dlg::~CSignStep01Dlg()
{
	/////////////////////////////////////////////////////////////////////////
	// Deallocate all pointer.
	delete certificateStore;
}

void CSignStep01Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep01Dlg)
	DDX_Control(pDX, IDC_COMMENT01, m_cmt);
	DDX_Control(pDX, IDC_SIGNER_LIST, m_signerList);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSignStep01Dlg, CDialog)
	//{{AFX_MSG_MAP(CSignStep01Dlg)
	ON_NOTIFY(NM_DBLCLK, IDC_SIGNER_LIST, OnDblclkSignerList)
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignStep01Dlg message handlers

BOOL CSignStep01Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Declare and initialize local variable here.
	CImageList *imgISAGSIGN;
	// Create image list.
	imgISAGSIGN = new CImageList();
	imgISAGSIGN->Create(32,32,ILC_COLOR24,2,0);
	imgISAGSIGN->Add(AfxGetApp()->LoadIcon(IDR_ISAGSIGN));
	m_signerList.SetImageList(imgISAGSIGN , LVSIL_NORMAL);

	// Declare and initialize local variable here.
	certificateStore = new CCertStore();
	certificateStore->ReadCertificateInStore();
	signerList = certificateStore->GetSignerList();
	signerCount = certificateStore->GetSignerCount();

	// Create new CListCtrl for store signer list.
	LV_ITEM item;
	LV_COLUMN column;
	column.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH ;
	column.fmt = LVCFMT_LEFT;

	// Create "Signer name" column.
	column.pszText = "Signer name";
	column.iSubItem = 0;
	column.cx = 180;
	m_signerList.InsertColumn(0 , &column);
	// Create "Issue name" column
	column.pszText = "Issue name";
	column.iSubItem = 1;
	column.cx = 180;
	m_signerList.InsertColumn(1 , &column);
	// Create "Issue date" column
	column.pszText = "Issue date";
	column.iSubItem = 2;
	column.cx = 200;
	m_signerList.InsertColumn(2 , &column);
	// Create "Expire date" column
	column.pszText = "Expire date";
	column.iSubItem = 3;
	column.cx = 200;
	m_signerList.InsertColumn(3 , &column);

	// Show all singer information in list.
	int subItemNext;
	for (int index = 0 ; index < signerCount ; index++)
	{
		item.mask = LVIF_TEXT | LVIF_IMAGE;
		item.iItem = index;
		item.iSubItem = 0;
		item.iImage = 0;
		item.pszText = signerList[index].SignerName.GetBuffer(0);
		subItemNext = m_signerList.InsertItem(&item);

//		item.mask = LVIF_TEXT;
//		item.iSubItem = 1;
//		item.pszText = signerList[index].IssuerName.GetBuffer(0);
//		m_signerList.SetItem(&item);

//		item.mask = LVIF_TEXT;
//		item.iSubItem = 2;
//		item.pszText = signerList[index].IssueDate.GetBuffer(0);
//		m_signerList.SetItem(&item);
		
//		item.mask = LVIF_TEXT;
//		item.iSubItem = 3;
//		item.pszText = signerList[index].RevocationDate.GetBuffer(0);
//		m_signerList.SetItem(&item);
	}

	// Set font in the comment to bold format.
	m_cmt.ChangeFontStyle(FC_FONT_BOLD);

	return TRUE;
}

void CSignStep01Dlg::OnDblclkSignerList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	int selectNumber = m_signerList.GetSelectionMark();
	signerSelectedName = m_signerList.GetItemText(selectNumber , 0);
	
	// Goto next step...
	*pResult = 0;
}

void CSignStep01Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	SendMessage(WM_CLOSE);	
}

void CSignStep01Dlg::OnNext() 
{
	// TODO: Add your control notification handler code here
	int selectNumber = m_signerList.GetSelectionMark();
	if (selectNumber != -1) 
	{
		// Get the name of selected signer.
		signerSelectedName = m_signerList.GetItemText(selectNumber , 0);
		theApp.currentSigner->setSignerInfo(signerList[selectNumber]);

		// Sign signature goto 2nd step. 
		theApp.signStep = STEP02;		
		// Close dialog.
		SendMessage(WM_CLOSE);
	}
	else
		// Show the error message.
		AfxMessageBox("ERROR..." , MB_OK | MB_ICONSTOP);
}
