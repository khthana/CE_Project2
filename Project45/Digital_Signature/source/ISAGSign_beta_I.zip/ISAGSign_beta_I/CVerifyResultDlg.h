#if !defined(AFX_CVERIFYRESULTDLG_H__1E682053_6D55_46FA_89A6_D96E1AC372FE__INCLUDED_)
#define AFX_CVERIFYRESULTDLG_H__1E682053_6D55_46FA_89A6_D96E1AC372FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CVerifyResultDlg.h : header file
//

#include "FontCtrl.h"
#include "ColorCtrl.h"
typedef CFontCtrl<CStatic> CFontStatic;

/////////////////////////////////////////////////////////////////////////////
// CVerifyResultDlg dialog

class CVerifyResultDlg : public CDialog
{
// Construction
public:
	CVerifyResultDlg(CWnd* pParent = NULL);   // standard constructor
	
// Dialog Data
	//{{AFX_DATA(CVerifyResultDlg)
	enum { IDD = IDD_VERIFY };
	CColorCtrl<CFontStatic>	m_scDateTO;
	CColorCtrl<CFontStatic>	m_scDateFM;
	CColorCtrl<CFontStatic> m_idate;
	CColorCtrl<CFontStatic> m_rdate;
	CColorCtrl<CFontStatic> m_sdate;
	CColorCtrl<CFontStatic> m_sname;
	CColorCtrl<CFontStatic> m_iname;
	CFontCtrl<CButton>		m_sigInfo;
	CFontCtrl<CStatic>      m_result;
	CFontCtrl<CStatic>      m_signerName;
	CFontCtrl<CStatic>      m_signDate;
	CFontCtrl<CStatic>      m_revDate;
	CFontCtrl<CStatic>      m_issueName;
	CFontCtrl<CStatic>      m_issueDate;
	CFontCtrl<CStatic>		m_certTO;
	CFontCtrl<CStatic>		m_certFM;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVerifyResultDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
	BOOL OnInitDialog();
// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CVerifyResultDlg)
	afx_msg void OnClose();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	void UpdateView();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CVERIFYRESULTDLG_H__1E682053_6D55_46FA_89A6_D96E1AC372FE__INCLUDED_)
