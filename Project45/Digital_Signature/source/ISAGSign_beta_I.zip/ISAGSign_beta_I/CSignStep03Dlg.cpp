// CSignStep03Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "CSignStep03Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep03Dlg dialog


CSignStep03Dlg::CSignStep03Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSignStep03Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSignStep03Dlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSignStep03Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep03Dlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSignStep03Dlg, CDialog)
	//{{AFX_MSG_MAP(CSignStep03Dlg)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSignStep03Dlg message handlers

BOOL CSignStep03Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	theApp.signStep = STEP04;

	return TRUE;
}
