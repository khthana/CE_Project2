// VerifyDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "VerifyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CVerifyDlg dialog


CVerifySignatureDlg::CVerifySignatureDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVerifySignatureDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVerifyDlg)
	//}}AFX_DATA_INIT
}


void CVerifySignatureDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVerifyDlg)
	DDX_Control(pDX, IDS_ISSUE_NAME2, m_iName);
	DDX_Control(pDX, IDS_SIGNER_NAME2, m_sName);
	DDX_Control(pDX, IDS_SIGN_DATE2, m_sDate);
	DDX_Control(pDX, IDS_REVOCATION_DATE2, m_rDate);
	DDX_Control(pDX, IDS_ISSUE_DATE2, m_iDate);
	DDX_Control(pDX, IDC_CERT_TO2, m_certTO);
	DDX_Control(pDX, IDC_CERT_FM2, m_certFM);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVerifySignatureDlg, CDialog)
	//{{AFX_MSG_MAP(CVerifyDlg)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVerifyDlg message handlers
BOOL CVerifySignatureDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	/////////////////////////////////////////////////////////////////////////
	// Declare and initialize local variable here.
	SignerInformation signer = theApp.currentSigner->getSignerInfo();
	CTime signDate = theApp.currentSigner->getSignDate();
	CString signDateStr = signDate.FormatGmt("%H:%M , %d %A %B %Y");  
	CTime certFM = theApp.currentSigner->getCertFrom();
	CTime certTO = theApp.currentSigner->getCertTo();
	CString certFMstr = certFM.FormatGmt("%H:%M , %d %A %B %Y");
	CString certTOstr = certTO.FormatGmt("%H:%M , %d %A %B %Y");

	if ((certFM == NULL) && (certTO == NULL))
	{
		certFMstr = "NONE";
		certTOstr = "NONE";
	}

	// Display signature information.
	// Update the data to control.
	UpdateData(FALSE);
	m_sName.SetWindowText(signer.SignerName);
	m_iName.SetWindowText(signer.IssuerName);
	m_sDate.SetWindowText(signDateStr);
	m_iDate.SetWindowText(signer.IssueDate.FormatGmt("%H:%M , %d %A %B %Y"));
	m_rDate.SetWindowText(signer.RevocationDate.FormatGmt("%H:%M , %d %A %B %Y"));
	m_certFM.SetWindowText(certFMstr);
	m_certTO.SetWindowText(certTOstr);

	return TRUE;
}

void CVerifySignatureDlg::OnClose() 
{
	// TODO: Add your control notification handler code here
	SendMessage(WM_CLOSE);
}
