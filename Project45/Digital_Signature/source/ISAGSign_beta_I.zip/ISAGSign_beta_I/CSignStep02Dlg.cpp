// CSignStep02Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"
#include "CSignStep02Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSignStep02Dlg dialog


CSignStep02Dlg::CSignStep02Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSignStep02Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSignStep02Dlg)
	m_fmdate = 0;
	m_todate = 0;
	m_maxapp = 0;
	//}}AFX_DATA_INIT
}


void CSignStep02Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSignStep02Dlg)
	DDX_Control(pDX, IDC_SIGN_IMG, m_sign);
	DDX_Control(pDX, IDC_CERT_LMT, m_cert);
	DDX_Control(pDX, IDC_HASH_ALG, m_hash);
	DDX_Control(pDX, IDC_MAXSPIN, m_maxspin);
	DDX_Control(pDX, IDC_CERTDUR_CHECK, m_dur);
	DDX_Control(pDX, IDC_MAXAPPROVE_CHECK, m_max);
	DDX_Control(pDX, IDC_TODATE, m_toctrl);
	DDX_Control(pDX, IDC_FROMDATE, m_fmctrl);
	DDX_Control(pDX, IDC_MAXAPPROVE_EDIT, m_maxedit);
	DDX_DateTimeCtrl(pDX, IDC_FROMDATE, m_fmdate);
	DDX_DateTimeCtrl(pDX, IDC_TODATE, m_todate);
	DDX_Text(pDX, IDC_MAXAPPROVE_EDIT, m_maxapp);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSignStep02Dlg, CDialog)
	//{{AFX_MSG_MAP(CSignStep02Dlg)
	ON_BN_CLICKED(IDC_MD4, OnMD4)
	ON_BN_CLICKED(IDC_MD5, OnMD5)
	ON_BN_CLICKED(IDC_SHA, OnSHA)
	ON_BN_CLICKED(IDC_MAXAPPROVE_CHECK, OnMaxApproveCheck)
	ON_BN_CLICKED(IDC_CERTDUR_CHECK, OnCertDurationCheck)
	ON_COMMAND(IDC_SIGN, OnSign)
	ON_BN_CLICKED(ID_SIGN, OnSign)
	ON_BN_CLICKED(IDC_EXIT, OnExit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CSignStep02Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Initial all control properties.
	m_maxspin.SetRange(1 , 10);
	m_maxspin.SetBuddy(&m_maxedit);
	m_maxspin.SetPos(5);

	m_fmctrl.SetTime(&CTime::GetCurrentTime());
	m_toctrl.SetTime(&CTime::GetCurrentTime());

	m_hash.ChangeFontStyle(FC_FONT_BOLD);
	m_cert.ChangeFontStyle(FC_FONT_BOLD);
	m_sign.ChangeFontStyle(FC_FONT_BOLD);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CSignStep02Dlg message handlers

void CSignStep02Dlg::OnMD4() 
{
	// Set hash algorithm = MD4
	m_Hash = "MD4";
}

void CSignStep02Dlg::OnMD5() 
{
	// Set hash algorithm = MD5
	m_Hash = "MD5";
}

void CSignStep02Dlg::OnSHA() 
{
	// Set hash algorithm = SHA.
	m_Hash = "SHA";	
}

void CSignStep02Dlg::OnMaxApproveCheck() 
{
	// Enable or disable max approve control.
	if (m_max.GetCheck() == 1)
	{
		m_maxedit.EnableWindow(TRUE);
		m_maxspin.EnableWindow(TRUE);
	}
	else
	{
		m_maxedit.EnableWindow(FALSE);
		m_maxspin.EnableWindow(FALSE);
	}
}

void CSignStep02Dlg::OnCertDurationCheck() 
{
	// Enable or disable certificate duration control.
	if (m_dur.GetCheck() == 1)
	{
		m_fmctrl.EnableWindow(TRUE);
		m_toctrl.EnableWindow(TRUE);
	}
	else
	{
		m_fmctrl.EnableWindow(FALSE);
		m_toctrl.EnableWindow(FALSE);
	}	
}

void CSignStep02Dlg::OnSign() 
{
	// Update the data from all input control.
	UpdateData(TRUE);

	// Step 01 : Set hash algorithm.
	if (!(m_Hash.IsEmpty()))
		theApp.currentSigner->setHashAlgorithm(m_Hash);
	else 
	{
		AfxMessageBox("ERROR..." , MB_OK | MB_ICONSTOP);
		return;
	}

	// Step 02 : Set max approve.
	if (m_max.GetCheck() == 1)
		theApp.currentSigner->setMaxApprove(m_maxapp);
	else 
		theApp.currentSigner->setMaxApprove(m_maxapp);

	// Step 03 : Set approve duration.
	CTime certFm = m_fmdate;
	CTime certTo = m_todate;
	if (m_dur.GetCheck() == 1)
		theApp.currentSigner->setCertDuration(certFm , certTo);
	else
		theApp.currentSigner->setCertDuration(NULL   , NULL  );

	// Step 04 : Set sign signature date.
	CTime signDt = CTime::GetCurrentTime();
	theApp.currentSigner->setSignDate(signDt);

	// Sign signature goto 3rd step.
	theApp.signStep = STEP03;
	// Close dialog.
	SendMessage(WM_CLOSE);
}

void CSignStep02Dlg::OnExit() 
{
	// TODO: Add your control notification handler code here
	SendMessage(WM_CLOSE);
}
