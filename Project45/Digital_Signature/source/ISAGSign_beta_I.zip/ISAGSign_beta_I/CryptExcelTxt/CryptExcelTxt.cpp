// CryptExcelTxt.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "CryptExcelTxt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CCryptExcelTxtApp

BEGIN_MESSAGE_MAP(CCryptExcelTxtApp, CWinApp)
	//{{AFX_MSG_MAP(CCryptExcelTxtApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCryptExcelTxtApp construction

CCryptExcelTxtApp::CCryptExcelTxtApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCryptExcelTxtApp object

CCryptExcelTxtApp theApp;

extern "C" BYTE* FAR PASCAL EXPORT GetDataBlockExcel()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	IUnknown			*pUnk = NULL;
	IDispatch			*pDisp = NULL;
	IDataObject			*pDataOb = NULL;
	LPDISPATCH			 lDisp = NULL;
	CLSID				 classID;
	HRESULT				 hResult;	
	// OLE Automation variable.
	_Application		appObj;
	_Workbook			wrkObj;
	Workbooks			wrksObj;	

	// Clipboard data.
	FORMATETC etc;
	STGMEDIUM stg;
	
	etc.cfFormat = CF_TEXT;
	etc.ptd = NULL;
	etc.lindex = -1;
	etc.dwAspect = DVASPECT_CONTENT;
	etc.tymed = TYMED_HGLOBAL;
	
	CLSIDFromProgID(L"Excel.Application" , &classID);
	// Find class id and IUnknown interface of MS-EXCEL Application.
	hResult = GetActiveObject((const CLSID&)classID , NULL , &pUnk);
	if (hResult != S_OK) 
		HandleError("Error during GetActiveObject !");
		
	// Query IDispatch interface.
	hResult = pUnk->QueryInterface(IID_IDispatch , (void**)&pDisp);
	if (hResult != S_OK)
		HandleError("Error during QueryInterface for IDispatch !");

	appObj.AttachDispatch(pDisp , TRUE);
	lDisp = appObj.GetWorkbooks();
	wrkObj.AttachDispatch(lDisp , TRUE);

	// Query IDataobject interface.
	lDisp = appObj.GetActiveWorkbook();
	wrkObj.AttachDispatch(lDisp ,  TRUE);
	hResult = lDisp->QueryInterface(IID_IDataObject,(void**)&pDataOb);
	if ( hResult != S_OK )
		HandleError("Error during QueryInterface for IDataObject !");

	// Get data object in CF_TEXT format from MS-EXCEL.
	hResult = pDataOb->GetData(&etc,&stg);
	if ( hResult != S_OK )
		HandleError("Error during GetData !");

	HGLOBAL hgData = stg.hGlobal;
	BYTE *dataBlock = (BYTE*)GlobalLock(hgData);
	
	// Return data block from MS-Excel.
	return dataBlock;
	// Free the stg storage medium.
	ReleaseStgMedium(&stg);
}

extern "C" UINT FAR PASCAL EXPORT GetDataBlockLengthExcel()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	IUnknown			*pUnk = NULL;
	IDispatch			*pDisp = NULL;
	IDataObject			*pDataOb = NULL;
	LPDISPATCH			 lDisp = NULL;
	CLSID				 classID;
	HRESULT				 hResult;	
	// OLE Automation variable.
	_Application		appObj;
	_Workbook			wrkObj;
	Workbooks			wrksObj;	

	// Clipboard data.
	FORMATETC etc;
	STGMEDIUM stg;
	
	etc.cfFormat = CF_TEXT;
	etc.ptd = NULL;
	etc.lindex = -1;
	etc.dwAspect = DVASPECT_CONTENT;
	etc.tymed = TYMED_HGLOBAL;
	
	CLSIDFromProgID(L"Excel.Application" , &classID);
	// Find class id and IUnknown interface of MS-EXCEL Application.
	hResult = GetActiveObject((const CLSID&)classID , NULL , &pUnk);
	if (hResult != S_OK) 
		HandleError("Error during GetActiveObject !");
		
	// Query IDispatch interface.
	hResult = pUnk->QueryInterface(IID_IDispatch , (void**)&pDisp);
	if (hResult != S_OK)
		HandleError("Error during QueryInterface for IDispatch !");

	appObj.AttachDispatch(pDisp , TRUE);
	lDisp = appObj.GetWorkbooks();
	wrkObj.AttachDispatch(lDisp , TRUE);

	// Query IDataobject interface.
	lDisp = appObj.GetActiveWorkbook();
	wrkObj.AttachDispatch(lDisp ,  TRUE);
	hResult = lDisp->QueryInterface(IID_IDataObject,(void**)&pDataOb);
	if ( hResult != S_OK )
		HandleError("Error during QueryInterface for IDataObject !");

	// Get data object in CF_TEXT format from MS-EXCEL.
	hResult = pDataOb->GetData(&etc,&stg);
	if ( hResult != S_OK )
		HandleError("Error during GetData !");

	UINT  dataBlockLen = GlobalSize(stg.hGlobal);

	// Free the stg storage medium.
	ReleaseStgMedium(&stg);

	// Return data block length from MS-Excel.
	return dataBlockLen;
}

/*void CCryptExcelTxtApp::AddDataBlock(HGLOBAL hgData, const UINT uSize)
{
	LPVOID dataBlockTemp = GlobalLock(hgData);
	dataBlockLen = uSize;

	ASSERT(AfxIsValidAddress(dataBlockTemp , dataBlockLen , FALSE));

	if (dataBlockTemp != NULL)
	{
		// Allocate new memory.
		dataBlock = new BYTE[dataBlockLen];
		// Copy the data to the newly-allocate memory .
		CopyMemory(dataBlock , dataBlockTemp , dataBlockLen);
		// Unlock the HGLOBAL.
		GlobalUnlock(hgData);
	}
}*/

extern "C" void HandleError(CString errorMsg)
{
	////////////////////////////////////////////////////////////////
	// Display an error message and exit the program.
	AfxMessageBox(errorMsg , MB_OK | MB_ICONSTOP);
	exit(0);
}

/*extern "C" BYTE* FAR PASCAL EXPORT SignDigitalSignature()
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	////////////////////////////////////////////////////////////////
	// Sign digital signature.
	// Step 01 : Get the data from MS-EXCEL.
	BYTE* dataBlock = (BYTE*)"Test";
	UINT  dataBlockLen = strlen((char*)(dataBlock));
	CString signerName = "Mc Fisho";
//	GetTextFromMsExcel();		

	// Step 02 : Find the hash value of data.
//	SignAndVerify *SignAndVerifyCom = new SignAndVerify();
//	SignAndVerifyCom->FindHashValue(dataBlock , dataBlockLen , MD5);
//	CString hashValue = SignAndVerifyCom->GetHashValue();
//	BYTE *hashStream = (BYTE*)(LPCSTR)(hashValue); 
//	UINT  hashStreamLen = strlen((LPCSTR)(hashValue));

	// Step 03 : Encrypt message digest with private of signer.
//	SignAndVerifyCom->SignSignature(hashStream , hashStreamLen , signerName);

	// Step 04 :Get digital signature.
//	UINT sigLen = SignAndVerifyCom->GetDigitalSignatureLength();
	
//	BYTE *sig   = new BYTE[sigLen];
//	sig = SignAndVerifyCom->GetDigitalSignature();
	return dataBlock;
}*/


