// CryptExcelTxt.h : main header file for the CRYPTEXCELTXT DLL
//

#if !defined(AFX_CRYPTEXCELTXT_H__6F231545_2623_11D7_B6BC_DC8E9CA3F31E__INCLUDED_)
#define AFX_CRYPTEXCELTXT_H__6F231545_2623_11D7_B6BC_DC8E9CA3F31E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "Excel8.h"

/////////////////////////////////////////////////////////////////////////////
// CCryptExcelTxtApp
// See CryptExcelTxt.cpp for the implementation of this class
//

#include "SignAndVerify.h"

extern "C" {
	BYTE* FAR PASCAL EXPORT GetDataBlockExcel();
	UINT  FAR PASCAL EXPORT GetDataBlockLengthExcel();
	void  HandleError(CString);
}

class CCryptExcelTxtApp : public CWinApp
{
public:
	void AddDataBlock(HGLOBAL , const UINT);
	CCryptExcelTxtApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCryptExcelTxtApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CCryptExcelTxtApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CRYPTEXCELTXT_H__6F231545_2623_11D7_B6BC_DC8E9CA3F31E__INCLUDED_)
