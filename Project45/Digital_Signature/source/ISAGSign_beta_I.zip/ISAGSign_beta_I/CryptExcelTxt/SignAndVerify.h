// SignAndVerify.h: interface for the SignAndVerify class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SIGNANDVERIFY_H__DF9B6B36_D561_43E3_9551_A51D49665B36__INCLUDED_)
#define AFX_SIGNANDVERIFY_H__DF9B6B36_D561_43E3_9551_A51D49665B36__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define _WIN32_WINNT 0X0500
#define CERT_STORE_NAME  L"MY"
#define MY_ENCODE_TYPE (PKCS_7_ASN_ENCODING | X509_ASN_ENCODING)
#include "windows.h"
#include "wincrypt.h"
#include "utilities.h"

class SignAndVerify  
{
public:
	UINT GetDigitalSignatureLength();
	SignAndVerify();
	BYTE* GetDigitalSignature();
	CString GetHashValue();
	void FindHashValue(BYTE* , UINT , HashAlgorithm);
	void SignSignature(BYTE* , UINT , CString);
	void VerifySignature(BYTE* , DWORD);
	void HandleError(CString);
	virtual ~SignAndVerify();
private:
	CString GetCertificateSubject(CERT_NAME_BLOB*);
	BYTE		*digitalSignature;
	UINT		 digitalSignatureLen;
	HCRYPTPROV	 hProv;
	HCRYPTHASH	 hHash;
	CString		 hashValue;
};

#endif // !defined(AFX_SIGNANDVERIFY_H__DF9B6B36_D561_43E3_9551_A51D49665B36__INCLUDED_)
