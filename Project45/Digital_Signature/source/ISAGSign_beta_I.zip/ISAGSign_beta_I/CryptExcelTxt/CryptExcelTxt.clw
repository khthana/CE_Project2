; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
ClassCount=1
Class1=CCryptExcelTxtApp
LastClass=CCryptExcelTxtApp
NewFileInclude2=#include "CryptExcelTxt.h"
ResourceCount=0
NewFileInclude1=#include "stdafx.h"

[CLS:CCryptExcelTxtApp]
Type=0
HeaderFile=CryptExcelTxt.h
ImplementationFile=CryptExcelTxt.cpp
Filter=N
LastObject=CCryptExcelTxtApp

