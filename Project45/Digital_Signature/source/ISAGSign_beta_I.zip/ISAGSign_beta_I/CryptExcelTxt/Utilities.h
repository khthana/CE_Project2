////////////////////////////////////////////////////////////////////////////////////////////////////
// Utilities.h 

// Hash algorithm.
enum HashAlgorithm {MD4 , MD5 , SHA};

// SignerInformation structure.
struct SignerInformation 
{
	CString SignerName;
	CString IssuerName;
	CString IssueDate;
	CString RevocationDate;
};