//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CRYPTEXCELTXT.RC
//

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE	6000
#define _APS_NEXT_CONTROL_VALUE		6000
#define _APS_NEXT_SYMED_VALUE		6000
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif
