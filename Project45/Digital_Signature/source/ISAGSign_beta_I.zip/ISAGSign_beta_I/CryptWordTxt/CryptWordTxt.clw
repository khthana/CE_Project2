; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
ClassCount=1
Class1=CCryptWordTxtApp
LastClass=CCryptWordTxtApp
NewFileInclude2=#include "CryptWordTxt.h"
ResourceCount=0
NewFileInclude1=#include "stdafx.h"

