// CryptWordTxt.h : main header file for the CRYPTWORDTXT DLL
//

#if !defined(AFX_CRYPTWORDTXT_H__8CEE7090_1960_4BB6_92B5_B471CD66377F__INCLUDED_)
#define AFX_CRYPTWORDTXT_H__8CEE7090_1960_4BB6_92B5_B471CD66377F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "Msword8.h"

/////////////////////////////////////////////////////////////////////////////
// CCryptWordTxtApp
// See CryptWordTxt.cpp for the implementation of this class
//

extern "C" {
	BYTE* FAR PASCAL EXPORT GetDataBlock();
	UINT  FAR PASCAL EXPORT GetDataBlockLength();
	void  HandleError(CString);
}

class CCryptWordTxtApp : public CWinApp
{
public:
	CCryptWordTxtApp();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsWordOleApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CMsWordOleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CRYPTWORDTXT_H__8CEE7090_1960_4BB6_92B5_B471CD66377F__INCLUDED_)
