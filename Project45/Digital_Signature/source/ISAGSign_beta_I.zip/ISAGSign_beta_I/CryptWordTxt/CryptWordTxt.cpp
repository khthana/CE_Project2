// CryptWordTxt.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "CryptWordTxt.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CCryptWordTxtApp

BEGIN_MESSAGE_MAP(CCryptWordTxtApp, CWinApp)
	//{{AFX_MSG_MAP(CCryptWordTxtApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCryptWordTxtApp construction

CCryptWordTxtApp::CCryptWordTxtApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CCryptWordTxtApp object

CCryptWordTxtApp theApp;

extern "C" BYTE* FAR PASCAL EXPORT GetDataBlock()
{
	////////////////////////////////////////////////////////////////
	// Return CF_TEXT.
//	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	// Declare and initialize local variable here.
	IUnknown			*pUnk = NULL;
	IDispatch			*pDisp = NULL;
	IDataObject			*pDataOb = NULL;
	LPDISPATCH			 lDisp = NULL;
	CLSID				 classID;
	HRESULT				 hResult;	
	// OLE Automation variable.
	_Application		appObj;
	_Document			docObj;
	Documents			docsObj;
	// Clipboard data.
	FORMATETC etc;
	STGMEDIUM stg;
	
	etc.cfFormat = CF_TEXT;
	etc.ptd = NULL;
	etc.lindex = -1;
	etc.dwAspect = DVASPECT_CONTENT;
	etc.tymed = TYMED_HGLOBAL;
	
	CLSIDFromProgID(L"Word.Application" , &classID);
	// Find class id and IUnknown interface of MS-WORD Application.
	hResult = GetActiveObject((const CLSID&)classID , NULL , &pUnk);
	if (hResult != S_OK) 
		HandleError("Error during GetActiveObject !");
		
	// Query IDispatch interface.
	hResult = pUnk->QueryInterface(IID_IDispatch , (void**)&pDisp);
	if (hResult != S_OK)
		HandleError("Error during QueryInterface for IDispatch !");

	appObj.AttachDispatch(pDisp , TRUE);
	lDisp = appObj.GetDocuments();
	docObj.AttachDispatch(lDisp , TRUE);

	// Query IDataobject interface.
	lDisp = appObj.GetActiveDocument();
	docObj.AttachDispatch(lDisp,TRUE);
	hResult = lDisp->QueryInterface(IID_IDataObject,(void**)&pDataOb);
	if ( hResult != S_OK )
		HandleError("Error during QueryInterface for IDataObject !");

	// Get data object in CF_TEXT format from MS-WORD.
	hResult = pDataOb->GetData(&etc,&stg);
	if ( hResult != S_OK )
		HandleError("Error during GetData !");

	HGLOBAL hgData = stg.hGlobal;
	BYTE *dataBlock = (BYTE*)GlobalLock(hgData);
	
	// Return data block from MS-WORD.
	return dataBlock;
	// Free the stg storage medium.
	ReleaseStgMedium(&stg);
}

extern "C" UINT FAR PASCAL EXPORT GetDataBlockLength()
{
//	AFX_MANAGE_STATE(AfxGetStaticModuleState());
	// Declare and initialize local variable here.
	IUnknown			*pUnk = NULL;
	IDispatch			*pDisp = NULL;
	IDataObject			*pDataOb = NULL;
	LPDISPATCH			 lDisp = NULL;
	CLSID				 classID;
	HRESULT				 hResult;	
	// OLE Automation variable.
	_Application		appObj;
	_Document			docObj;
	Documents			docsObj;
	// Clipboard data.
	FORMATETC etc;
	STGMEDIUM stg;
	
	etc.cfFormat = CF_TEXT;
	etc.ptd = NULL;
	etc.lindex = -1;
	etc.dwAspect = DVASPECT_CONTENT;
	etc.tymed = TYMED_HGLOBAL;
	
	CLSIDFromProgID(L"Word.Application" , &classID);
	// Find class id and IUnknown interface of MS-WORD Application.
	hResult = GetActiveObject((const CLSID&)classID , NULL , &pUnk);
	if (hResult != S_OK) 
		HandleError("Error during GetActiveObject !");
		
	// Query IDispatch interface.
	hResult = pUnk->QueryInterface(IID_IDispatch , (void**)&pDisp);
	if (hResult != S_OK)
		HandleError("Error during QueryInterface for IDispatch !");

	appObj.AttachDispatch(pDisp , TRUE);
	lDisp = appObj.GetDocuments();
	docObj.AttachDispatch(lDisp , TRUE);

	// Query IDataobject interface.
	lDisp = appObj.GetActiveDocument();
	docObj.AttachDispatch(lDisp,TRUE);
	hResult = lDisp->QueryInterface(IID_IDataObject,(void**)&pDataOb);
	if ( hResult != S_OK )
		HandleError("Error during QueryInterface for IDataObject !");

	// Get data object in CF_TEXT format from MS-WORD.
	hResult = pDataOb->GetData(&etc,&stg);
	if ( hResult != S_OK )
		HandleError("Error during GetData !");

	HGLOBAL hgData = stg.hGlobal;
	UINT  dataBlockLen = GlobalSize(stg.hGlobal);
	
	// Return data block from MS-WORD.
	return dataBlockLen;
}

extern "C" void HandleError(CString errorMsg)
{
	////////////////////////////////////////////////////////////////	
	// Display an error message and exit the program.
	AfxMessageBox(errorMsg , MB_OK | MB_ICONSTOP);
	exit(1);
}
