// DataTransfer.h: interface for the DataTransfer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATATRANSFER_H__7FB0F562_97A9_4419_B1CC_395966EA32A8__INCLUDED_)
#define AFX_DATATRANSFER_H__7FB0F562_97A9_4419_B1CC_395966EA32A8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class DataTransfer  
{
public:
	DataTransfer();
	virtual ~DataTransfer();
	void DataToClipboardForSign();
	void DataToClipboardForVerify();
	void ReadAndFillData(COleDataObject*);
	
private:
	void AddDataBlock(HGLOBAL , const UINT);
	DWORD		startSelPos;
	DWORD		endSelPos;
	BYTE		**m_ppData;
	UINT		m_uNextBlockIndex;
};

#endif // !defined(AFX_DATATRANSFER_H__7FB0F562_97A9_4419_B1CC_395966EA32A8__INCLUDED_)
