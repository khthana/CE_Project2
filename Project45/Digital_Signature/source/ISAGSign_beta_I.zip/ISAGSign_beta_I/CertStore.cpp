// CertStore.cpp: implementation of the CertStore class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "CertStore.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCertStore::CCertStore()
{
	// Initial signerCount equal zero.
	signerCount = 0;
}

CCertStore::~CCertStore()
{
	// Deallocate memory of signer list array.
	delete [] signerInfoList;
}

//////////////////////////////////////////////////////////////////////
/* Old CCertStore.
void CertStore::ReadCertificateInStore()
{
	// Declare and initialize variable.
	BOOL						insert = TRUE;
	HANDLE						hStoreHandle;
	PCCERT_CONTEXT				pCertContext = NULL;
	PCCERT_CONTEXT				pDupCertContext = NULL;
	char						pszStoreName[256] = "MY";			// default pszStoreName.
	int							index = 0;
	FILETIME					t1 , t2;
	CTime currTime = CTime::GetCurrentTime();						// get current time.

	// Open system certificate store.
	if (!(hStoreHandle = CertOpenSystemStore(NULL , pszStoreName)))
		HandleError("Error during CertOpenSystemStore !");

	// Find the certificate in the system store.
	// On the first call to the function this parameter is NULL.On all subsequent calls.
	// It is the last pointer returned by the function.
	while (pCertContext = CertEnumCertificatesInStore(hStoreHandle , pCertContext)) {
		signerCount++;
	}

	// Allocate memory for 'SignerInformation'
	signerInfoList = new SignerInformation[signerCount];

	while (pCertContext = CertEnumCertificatesInStore(hStoreHandle , pCertContext))
	{
		// Get issue date for each certificate.
		t1 = pCertContext->pCertInfo->NotBefore;
		// Get revocation date for each certificate.
		t2 = pCertContext->pCertInfo->NotAfter;

		// Check : issue name.
		// If the certificate not have issue name field then not insert that certificate in signer list.
		if (GetCertificateInformation(&(pCertContext->pCertInfo->Issuer) , "ISSUER") == "None issuer") 
			insert = FALSE;
		else 
		{
			// Check : certificate expiration.
			// If the cerifitcate has been expired then not insert that certificate in signer list.
			if (!(currTime <= GetTime(t2)))	
				insert = FALSE;
			else
				insert = TRUE;
		}

		// Insert the certificate in singer list.
		if (insert == TRUE)
		{
			// Get the issue's name for each certificate in system store.
			signerInfoList[index].IssuerName = GetCertificateInformation(&(pCertContext->pCertInfo->Issuer) , "ISSUER");
			// Get the subject's name for each certificate in system store. 
			signerInfoList[index].SignerName = GetCertificateInformation(&(pCertContext->pCertInfo->Subject) , "SUBJECT"); 
			// Set the issue date for each certificate to signer list.
			signerInfoList[index].IssueDate = GetTime(t1);
			// Set the recokation date for each dertificate to signer list.
			signerInfoList[index].RevocationDate = GetTime(t2);				
			// Next certificate in store.
			index++;
		}
	}
	
	// Assign signer count equal the aviarable ceritificate in certificate store.
	signerCount = index;

	// Clean up system system certificate store.
	CertCloseStore(hStoreHandle , 0);
}

CString CertStore::GetCertificateInformation(CERT_NAME_BLOB *nameBlob , CString certAttr)
{
	// Declare and initialize local variable here.
	int				t1 = -1 , t2 = -1;		// String separater.
	LPSTR		    pszName;	
	DWORD			cbName;
	DWORD			dwStrType = CERT_OID_NAME_STR;
	
	// The function CertNameToStr returns the number of bytes needed for a string to hold the name.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 NULL,							// Pointer to buffer.
			 0);							// Size of buffer.

	// If it return zero then there has been an error.
	if (0 == cbName)
		HandleError("Error during GetCertificateInformation !");

	// Allocate the needed buffer.
	if (!(pszName = new char[cbName]))
		HandleError("Error during in allcation memory for CERT_NAME_BLOB !");

	// Call the function again to get the string.
	cbName = CertNameToStr(
		     MY_ENCODE_TYPE ,				// Encode type used.
			 nameBlob ,						// Pointer to CERT_NAME_BLOB.
			 dwStrType ,					// Specifies the desired returned string type.
			 pszName ,						// Pointer to buffer.
			 cbName);						// Size of buffer.

	// Declare and initialize local variable for tag finding.
	CString	tempStr1(pszName) , tempStr2 , tempStr3 , tempStr4 , tag;
	// If found issuer name in certificate information then certificate can be used.
	if (tempStr1.Find("2.5.4.10") != -1) 
	{
		// Cut the subject name of signer certificate from pszName string.
		if (certAttr == "SUBJECT") 
			tag = "2.5.4.3";
		// Cut the issuer name of signer certificate from pszName string.
		else if (certAttr == "ISSUER")
			tag = "2.5.4.10";
		
		t1 = tempStr1.Find(tag);								
		tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

		t1 = tempStr2.Find('=');
		if (tempStr2[t1 + 1] == '\"')
			t1 = tempStr2.Find('\"' , t1 + 2);
		else
			t1 = tempStr2.Find(',');

		if (t1 == -1)
			tempStr3 = tempStr2.Mid(0);
		else
			tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx

		t1 = tempStr3.Find('=');
		if (tempStr2[t1 + 1] == '\"')
			t1 = t1 + 1;
		else 
		{
			t1 = t1 + 1;
			t2 = tempStr3.ReverseFind(',');
		}
		if (t2 == -1)
			tempStr4 = tempStr3.Mid(t1);			
		else
			tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx
	}
	else 
		tempStr4 = "None issuer";
	
	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

SignerInformation* CertStore::GetSignerList()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the singer information list.
	return this->signerInfoList;
}

UINT CertStore::GetSignerCount()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return signerCount
	return this->signerCount;
}

CTime CertStore::GetTime(FILETIME t)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Convert FILETIME to CString.
	// Declare and initialize local variable here.
	CString timeStr;
//	WORD *dosDate = new WORD();
//	WORD *dosTime = new WORD();
//
//	if (!(CoFileTimeToDosDateTime(&t , dosDate , dosTime))) 
//	{
//		timeStr = "Unexpired.";
//	}	
//	CTime time(*dosDate , *dosTime);
	CTime time(t);
	// Deallocate memory.
//	delete dosDate;
//	delete dosTime;
	// Return time in CString format.
	return time;
}
*/

void CCertStore::HandleError(CString errorMsg)
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Handle the error occured in running the program
	AfxMessageBox(errorMsg , MB_OK | MB_ICONSTOP);
	exit(1);
}

void CCertStore::ReadCertificateInStore()
{
	// Declare and initailize local variable here.
	int							index = 0;
	BOOL						insert = TRUE;
	HANDLE						hStoreHandle;
	PCCERT_CONTEXT				pCertContext = NULL;
	PCCERT_CONTEXT				pDupCertContext = NULL;
	char						pszStoreName[256] = "MY";		// Default pszStoreName.
	FILETIME					t1 , t2;
	CString						tempCertStr , tempIssuerStr , tempSubjectStr;

	// Open system certificate store.
	if (!(hStoreHandle = CertOpenSystemStore(NULL, pszStoreName)))
		HandleError("Error during CertOpenSystemStore !");

	// Find the certificate in the system store.
	// On the first call to the function this parameter is NULL.On all subsequent calls.
	// It is the last pointer returned by the function.
	while (pCertContext = CertEnumCertificatesInStore(hStoreHandle , pCertContext)) {
		signerCount++;
	}

	// Allocate memory for 'SignerInformation'
	signerInfoList = new SignerInformation[signerCount];

	// Find the certificate in the system store.
	// On the first call to the function this parameter is NULL.On all subsequent calls.
	// It is the last pointer returned by the function.
	while (pCertContext = CertEnumCertificatesInStore(hStoreHandle, pCertContext)) {
		// Get issued date for each certificate.
		t1 = pCertContext->pCertInfo->NotAfter;
		// Get expired date for each certificate.
		t2 = pCertContext->pCertInfo->NotBefore;

		tempIssuerStr = DecodeCertificate(&(pCertContext->pCertInfo->Issuer));
		tempSubjectStr = DecodeCertificate(&(pCertContext->pCertInfo->Subject));							

		tempIssuerStr = RetrieveIssuer(tempIssuerStr);
		tempSubjectStr = RetrieveSubject(tempSubjectStr);

		if (tempIssuerStr != "NONE ISSUER") {
			if (CheckRevokationDate(pCertContext)) {
				// Get the issue's name for each certificate in system store.
				signerInfoList[index].IssuerName = tempIssuerStr;
				// Get the subject's name for each certificate in system store. 
				signerInfoList[index].SignerName = tempSubjectStr; 
				// Set the issue date for each certificate to signer list.
				signerInfoList[index].IssueDate = CTime(t2);
				// Set the recokation date for each dertificate to signer list.
				signerInfoList[index].RevocationDate = CTime(t1);				
				// Next certificate in store.
				index++;
			}
		}
	}

	// Assign signer count equal the aviarable ceritificate in certificate store.
	signerCount = index;

	// Clean up system system certificate store.
	CertCloseStore(hStoreHandle , 0);
}

CString CCertStore::DecodeCertificate(CERT_NAME_BLOB *nameBlob)
{
	// Declare and initailize local variable here.
	int			t1 = -1, t2 = -1;
	LPSTR		pszName;
	DWORD		cbName;
	DWORD		dwStrType = CERT_OID_NAME_STR;

	// The function CertNameToStr returns the number of bytes needed for a string to hold the name.
	cbName = CertNameToStr(
			 MY_ENCODE_TYPE,					// Encode type used.
			 nameBlob,							// Pointer to CERT_NAME_BLOB.
			 dwStrType,							// Specifies the desired returned string type.
			 NULL,								// Pointer to buffer.
			 0);								// Size of buffer.

	// If it return zero then there has been an error.
	if (0 == cbName)
		HandleError("Error during GetCertificateInformation !");

	// Allocate the needed buffer.
	if (!(pszName = new char[cbName]))
		HandleError("Error during in allcation memory for CERT_NAME_BLOB !");

	// Call the function again to get the string.
	cbName = CertNameToStr(
			 MY_ENCODE_TYPE,					// Encode type used.
			 nameBlob,							// Pointer to CERT_NAME_BLOB.
			 dwStrType,							// Specifies the desired returned string type.
			 pszName,							// Pointer to buffer.
			 cbName);							// Size of buffer.

	// return the decoded certificate in string format.
	return pszName;
}

CString CCertStore::RetrieveIssuer(CString certStr)
{
	// Declare and initialize local variable here.
	int					t1 = -1 , t2 = -1;
	CString				tag;
	CString				tempStr1(certStr) , tempStr2 , tempStr3 , tempStr4;
	
	// Cut the issuer name of signer certificate from pszName string.
	tag = "2.5.4.10";
		
	t1 = tempStr1.Find(tag);								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	// If the certificate is not trust by Certificate Authority then return 'NONE ISSUER'.
	if (t1 == -1)
		return "NONE ISSUER";

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');

	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx

	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx

	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

CString CCertStore::RetrieveSubject(CString certStr)
{
	// Declare and initialize local variable here.
	int					t1 , t2;
	CString				tag;
	CString				tempStr1(certStr) , tempStr2 , tempStr3 , tempStr4;
	
	// Cut the issuer name of signer certificate from pszName string.
	tag = "2.5.4.3";
		
	t1 = tempStr1.Find(tag);								
	tempStr2 = tempStr1.Mid(t1);						// tempStr2 => 2.5.4.3=xxxx,xxxx

	t1 = tempStr2.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = tempStr2.Find('\"' , t1 + 2);
	else
		t1 = tempStr2.Find(',');

	if (t1 == -1)
		tempStr3 = tempStr2.Mid(0);
	else
		tempStr3 = tempStr2.Mid(0 , t1 + 1);			// tempStr3 => 2.5.4.3=xxxx

	t1 = tempStr3.Find('=');
	if (tempStr2[t1 + 1] == '\"')
		t1 = t1 + 1;
	else 
	{
		t1 = t1 + 1;
		t2 = tempStr3.ReverseFind(',');
	}
	if (t2 == -1)
		tempStr4 = tempStr3.Mid(t1);			
	else
		tempStr4 = tempStr3.Mid(t1 , t2 - t1);			// tempStr4 => xxxx

	// Now , tempStr4 is the desired certificate attribute.
	return tempStr4;
}

BOOL CCertStore ::CheckRevokationDate(const CERT_CONTEXT *pCertContext)
{
	// Declare and initialize local variable here.
	FILETIME			t1 , t2;

	// Get issued date for each certificate.
	t1 = pCertContext->pCertInfo->NotAfter;
	// Get expired date for each certificate.
	t2 = pCertContext->pCertInfo->NotBefore;
	// Get current time.
	CTime currTime = CTime::GetCurrentTime();					
	CTime issuedTime(t2);
	CTime expiredTime(t1);

	// If the certificate is not expired then return TRUE else return FALSE.
	if (!(currTime <= expiredTime))
		return FALSE;
	else
		return TRUE;
}

SignerInformation* CCertStore::GetSignerList()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return the singer information list.
	return this->signerInfoList;
}

UINT CCertStore::GetSignerCount()
{
	////////////////////////////////////////////////////////////////////////////////////////////////
	// Return signerCount
	return this->signerCount;
}

