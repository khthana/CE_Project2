// CertStore.h: interface for the CertStore class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CERTSTORE_H__11813AC8_60AF_4544_982F_38E910F3E39D__INCLUDED_)
#define AFX_CERTSTORE_H__11813AC8_60AF_4544_982F_38E910F3E39D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ISAGSign_beta_I.h"

class CCertStore  
{
//////////////////////////////////////////////////////////////////////
// Old CertStore
//public:
//	UINT GetSignerCount();
//	SignerInformation* GetSignerList();
//	CertStore();
//	void ReadCertificateInStore();
//	virtual ~CertStore();
//private:
//	CTime GetTime(FILETIME);
//	CString GetCertificateInformation(CERT_NAME_BLOB* , CString);
//	SignerInformation *signerInfoList;
//	int signerCount;					
public:
	UINT GetSignerCount();
	SignerInformation* GetSignerList();
	void ReadCertificateInStore();
	CString RetrieveIssuer(CString);
	CString RetrieveSubject(CString);
	CString DecodeCertificate(CERT_NAME_BLOB *nameBlob);
	BOOL CheckRevokationDate(const CERT_CONTEXT *pCertContext);
	CCertStore();
	virtual ~CCertStore();
private:
	CString certInfo;
	SignerInformation *signerInfoList;
	int signerCount;
	void HandleError(CString);
};

#endif // !defined(AFX_CERTSTORE_H__11813AC8_60AF_4544_982F_38E910F3E39D__INCLUDED_)
