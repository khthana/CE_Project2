// SrvrItem.cpp : implementation of the CISAGSign_beta_ISrvrItem class
//

#include "stdafx.h"
#include "ISAGSign_beta_I.h"

#include "ISAGSign_beta_IDoc.h"
#include "SrvrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_ISrvrItem implementation

IMPLEMENT_DYNAMIC(CISAGSign_beta_ISrvrItem, COleServerItem)

CISAGSign_beta_ISrvrItem::CISAGSign_beta_ISrvrItem(CISAGSign_beta_IDoc* pContainerDoc)
	: COleServerItem(pContainerDoc, TRUE)
{
	// TODO: add one-time construction code here
	//  (eg, adding additional clipboard formats to the item's data source)
	RegisterClipboardFormat("CF_ISAGSIGN");

}

CISAGSign_beta_ISrvrItem::~CISAGSign_beta_ISrvrItem()
{
	// TODO: add cleanup code here
}

void CISAGSign_beta_ISrvrItem::Serialize(CArchive& ar)
{
	// CISAGSign_beta_ISrvrItem::Serialize will be called by the framework if
	//  the item is copied to the clipboard.  This can happen automatically
	//  through the OLE callback OnGetClipboardData.  A good default for
	//  the embedded item is simply to delegate to the document's Serialize
	//  function.  If you support links, then you will want to serialize
	//  just a portion of the document.

	if (!IsLinkedItem())
	{
		CISAGSign_beta_IDoc* pDoc = GetDocument();
		ASSERT_VALID(pDoc);
		pDoc->Serialize(ar);
	}
}

BOOL CISAGSign_beta_ISrvrItem::OnGetExtent(DVASPECT dwDrawAspect, CSize& rSize)
{
	// Most applications, like this one, only handle drawing the content
	//  aspect of the item.  If you wish to support other aspects, such
	//  as DVASPECT_THUMBNAIL (by overriding OnDrawEx), then this
	//  implementation of OnGetExtent should be modified to handle the
	//  additional aspect(s).

	if (dwDrawAspect != DVASPECT_CONTENT)
		return COleServerItem::OnGetExtent(dwDrawAspect, rSize);

	// CISAGSign_beta_ISrvrItem::OnGetExtent is called to get the extent in
	//  HIMETRIC units of the entire item.  The default implementation
	//  here simply returns a hard-coded number of units.

	CISAGSign_beta_IDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: replace this arbitrary size

	rSize = CSize(9800 , 1800);   // 3000 x 3000 HIMETRIC units

	return TRUE;
}

BOOL CISAGSign_beta_ISrvrItem::OnDraw(CDC* pDC, CSize& rSize)
{
	// Remove this if you use rSize
	UNREFERENCED_PARAMETER(rSize);

	CISAGSign_beta_IDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);


	/////////////////////////////////////////////////////////////////////////
	// Display result picture in the document.
	pDC->SetMapMode(MM_TEXT);
	pDC->SetWindowOrg(0,0);
	pDC->SetWindowExt(9800 , 1800);

	BITMAP bmp;
	CBitmap pic;

	if (theApp.sigStatus == -1)
	{
		pic.LoadBitmap(IDB_DST);
		pic.GetObject(sizeof(BITMAP) , &bmp);
		pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);

	}
	if (theApp.sigStatus ==  0)
	{
		pic.LoadBitmap(IDB_MOD);
		pic.GetObject(sizeof(BITMAP) , &bmp);
		pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);

	}
	if (theApp.sigStatus ==  1)
	{
		pic.LoadBitmap(IDB_UNM);
		pic.GetObject(sizeof(BITMAP) , &bmp);
		pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);
	
	}
	if (theApp.sigStatus ==  2)
	{
		pic.LoadBitmap(IDB_DST);
		pic.GetObject(sizeof(BITMAP) , &bmp);
		pDC->DrawState(CPoint(0 , 0) , CSize(bmp.bmWidth , bmp.bmHeight) , pic , DST_BITMAP);

	}

	// TODO: set mapping mode and extent
	//  (The extent is usually the same as the size returned from OnGetExtent)
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CISAGSign_beta_ISrvrItem diagnostics

#ifdef _DEBUG
void CISAGSign_beta_ISrvrItem::AssertValid() const
{
	COleServerItem::AssertValid();
}

void CISAGSign_beta_ISrvrItem::Dump(CDumpContext& dc) const
{
	COleServerItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
