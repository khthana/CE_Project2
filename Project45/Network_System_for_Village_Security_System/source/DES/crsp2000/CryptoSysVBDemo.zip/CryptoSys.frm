VERSION 5.00
Begin VB.Form frmCryptoSys 
   Caption         =   "CryptoSys Testbed Demo Version 1.01"
   ClientHeight    =   7110
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8550
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   7110
   ScaleWidth      =   8550
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtDecrypt 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   315
      Left            =   1125
      TabIndex        =   46
      Top             =   6075
      Width           =   7320
   End
   Begin VB.TextBox txtPlainAsHex 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   315
      Left            =   1125
      TabIndex        =   44
      Top             =   4200
      Width           =   7320
   End
   Begin VB.TextBox txtDecryptHex 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1125
      TabIndex        =   43
      Top             =   6450
      Width           =   7320
   End
   Begin VB.CommandButton cmdGenKeyPrompt 
      Caption         =   "Generate Key with &User Prompt"
      Height          =   390
      Left            =   4575
      TabIndex        =   41
      Top             =   2100
      Width           =   2790
   End
   Begin VB.Frame Frame4 
      Caption         =   "Plain text format"
      Height          =   540
      Left            =   3075
      TabIndex        =   38
      Top             =   3600
      Width           =   2790
      Begin VB.OptionButton optPTHex 
         Caption         =   "Hex"
         Height          =   240
         Left            =   1200
         TabIndex        =   40
         Top             =   225
         Width           =   1365
      End
      Begin VB.OptionButton optPTAlpha 
         Caption         =   "Alpha"
         Height          =   240
         Left            =   150
         TabIndex        =   39
         Top             =   225
         Value           =   -1  'True
         Width           =   840
      End
   End
   Begin VB.TextBox txtIVAsString 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   285
      Left            =   1125
      TabIndex        =   35
      Top             =   2925
      Width           =   7320
   End
   Begin VB.CommandButton cmdGenKey 
      Caption         =   "&Generate Random Key"
      Height          =   390
      Left            =   2175
      TabIndex        =   34
      Top             =   2100
      Width           =   2190
   End
   Begin VB.TextBox txtIV 
      Height          =   300
      Left            =   855
      TabIndex        =   3
      Top             =   1725
      Width           =   6120
   End
   Begin VB.Frame Frame3 
      Caption         =   "Paddin&g"
      Height          =   1065
      Left            =   7050
      TabIndex        =   31
      Top             =   75
      Width           =   1365
      Begin VB.OptionButton optNoPad 
         Caption         =   "None"
         Height          =   240
         Left            =   150
         TabIndex        =   33
         Top             =   600
         Width           =   915
      End
      Begin VB.OptionButton optPad 
         Caption         =   "RFC 2630"
         Height          =   240
         Left            =   150
         TabIndex        =   32
         Top             =   300
         Value           =   -1  'True
         Width           =   1065
      End
   End
   Begin VB.Frame grpMode 
      Caption         =   "&Mode"
      Height          =   1065
      Left            =   5625
      TabIndex        =   28
      Top             =   75
      Width           =   990
      Begin VB.OptionButton optModeCBC 
         Caption         =   "CBC"
         Height          =   195
         Left            =   150
         TabIndex        =   30
         Top             =   600
         Width           =   765
      End
      Begin VB.OptionButton optModeECB 
         Caption         =   "ECB"
         Height          =   240
         Left            =   150
         TabIndex        =   29
         Top             =   300
         Value           =   -1  'True
         Width           =   765
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "&Algorithm"
      Height          =   1065
      Left            =   2175
      TabIndex        =   22
      Top             =   75
      Width           =   2940
      Begin VB.OptionButton optAES256256 
         Caption         =   "AES 256/256"
         Height          =   240
         Left            =   1275
         TabIndex        =   27
         Top             =   525
         Width           =   1365
      End
      Begin VB.OptionButton optAES128128 
         Caption         =   "AES 128/128"
         Height          =   315
         Left            =   1275
         TabIndex        =   26
         Top             =   225
         Width           =   1290
      End
      Begin VB.OptionButton optBLF 
         Caption         =   "Blowfish"
         Height          =   240
         Left            =   150
         TabIndex        =   25
         Top             =   675
         Width           =   1140
      End
      Begin VB.OptionButton optTDEA 
         Caption         =   "TDEA"
         Height          =   240
         Left            =   150
         TabIndex        =   24
         Top             =   450
         Width           =   1140
      End
      Begin VB.OptionButton optDES 
         Caption         =   "DES"
         Height          =   240
         Left            =   150
         TabIndex        =   23
         Top             =   225
         Value           =   -1  'True
         Width           =   990
      End
   End
   Begin VB.TextBox txtCipher64 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1125
      Locked          =   -1  'True
      TabIndex        =   20
      Top             =   5325
      Width           =   7320
   End
   Begin VB.Frame grpKeyForm 
      Caption         =   "Key &format:"
      Height          =   840
      Left            =   7125
      TabIndex        =   17
      Top             =   1200
      Width           =   1305
      Begin VB.OptionButton optAlphaKey 
         Caption         =   "Alpha"
         Height          =   255
         Left            =   150
         TabIndex        =   19
         Top             =   525
         Width           =   960
      End
      Begin VB.OptionButton optHexKey 
         Caption         =   "Hex string"
         Height          =   255
         Left            =   150
         TabIndex        =   18
         Top             =   225
         Value           =   -1  'True
         Width           =   1065
      End
   End
   Begin VB.TextBox txtCipherHex 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1125
      Locked          =   -1  'True
      TabIndex        =   16
      Top             =   4950
      Width           =   7320
   End
   Begin VB.TextBox txtCipher 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1125
      TabIndex        =   7
      Top             =   4575
      Width           =   7320
   End
   Begin VB.CommandButton cmdDecrypt 
      Caption         =   "&Decrypt cipher text"
      Enabled         =   0   'False
      Height          =   345
      Left            =   1125
      TabIndex        =   12
      Top             =   5700
      Width           =   1695
   End
   Begin VB.TextBox txtKeyAsString 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1125
      Locked          =   -1  'True
      TabIndex        =   10
      Top             =   2550
      Width           =   7320
   End
   Begin VB.CommandButton cmdSetKey 
      Caption         =   "&Set Key"
      Height          =   390
      Left            =   900
      TabIndex        =   9
      Top             =   2100
      Width           =   990
   End
   Begin VB.CommandButton cmdEncrypt 
      Caption         =   "&Encrypt plain text"
      Enabled         =   0   'False
      Height          =   450
      Left            =   1125
      TabIndex        =   8
      Top             =   3675
      Width           =   1695
   End
   Begin VB.TextBox txtKey 
      Height          =   300
      Left            =   855
      TabIndex        =   1
      Top             =   1320
      Width           =   6120
   End
   Begin VB.TextBox txtPlain 
      Height          =   300
      Left            =   1125
      TabIndex        =   5
      Top             =   3270
      Width           =   7320
   End
   Begin VB.Label Label12 
      Caption         =   "PT input:"
      Height          =   240
      Left            =   150
      TabIndex        =   45
      Top             =   4275
      Width           =   840
   End
   Begin VB.Label Label11 
      Caption         =   "Demonstration of CryptoSys API functions."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00800000&
      Height          =   915
      Left            =   75
      TabIndex        =   42
      Top             =   150
      Width           =   1665
   End
   Begin VB.Label Label10 
      Caption         =   "(In hex):"
      Height          =   240
      Left            =   150
      TabIndex        =   37
      Top             =   6450
      Width           =   840
   End
   Begin VB.Label Label9 
      Caption         =   "Active IV:"
      Height          =   165
      Left            =   150
      TabIndex        =   36
      Top             =   2925
      Width           =   915
   End
   Begin VB.Label Label8 
      Caption         =   "I&V (hex):"
      Height          =   315
      Left            =   150
      TabIndex        =   2
      Top             =   1725
      Width           =   615
   End
   Begin VB.Label Label7 
      Caption         =   "(Radix64):"
      Height          =   375
      Left            =   165
      TabIndex        =   21
      Top             =   5280
      Width           =   855
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      Caption         =   "Copyright (C) 2001 DI Management Services Pty Ltd <www.di-mgt.com.au>. All rights reserved."
      ForeColor       =   &H00800000&
      Height          =   225
      Left            =   225
      TabIndex        =   15
      Top             =   6825
      Width           =   7380
   End
   Begin VB.Label Label2 
      Caption         =   "(In hex):"
      Height          =   255
      Index           =   1
      Left            =   165
      TabIndex        =   14
      Top             =   4950
      Width           =   975
   End
   Begin VB.Label Label5 
      Caption         =   "Deciphered:"
      Height          =   255
      Left            =   150
      TabIndex        =   13
      Top             =   6105
      Width           =   975
   End
   Begin VB.Label Label4 
      Caption         =   "Active key:"
      Height          =   255
      Left            =   150
      TabIndex        =   11
      Top             =   2550
      Width           =   855
   End
   Begin VB.Label Label3 
      Caption         =   "&Key:"
      Height          =   255
      Left            =   135
      TabIndex        =   0
      Top             =   1320
      Width           =   855
   End
   Begin VB.Label Label2 
      Caption         =   "&Cipher text:"
      Height          =   255
      Index           =   0
      Left            =   165
      TabIndex        =   6
      Top             =   4575
      Width           =   975
   End
   Begin VB.Label Label1 
      Caption         =   "&Plain text:"
      Height          =   255
      Left            =   165
      TabIndex        =   4
      Top             =   3270
      Width           =   975
   End
End
Attribute VB_Name = "frmCryptoSys"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Option Base 0

' frmCryptoSys.frm
' A multi-function example to demonstrate some
' of the functions in the CryptoSys (TM) API.

' Note: Because this tries to do everything, it's more
' complicated than you'd need in a normal implementation.

' This is just a test-bed demo. It is not meant to be
' represesentative of good security code practices.
' There are no error handling facilities, either.

' Version 1. Published September 2001.
'************************* COPYRIGHT NOTICE*************************
' Copyright (c) 2001 DI Management Services Pty Limited.
' All rights reserved.
' Commercial use is prohibited without a valid licence.
' For a licence contact <sales@di-mgt.com.au>.
'  This code may only be used as part of an application. It may
' not be reproduced or distributed separately by any means without
' the express written permission of the author.
'  David Ireland and DI Management Services Pty Limited make no
' representations concerning either the merchantability of this
' software or the suitability of this software for any particular
' purpose. It is provided "as is" without express or implied
' warranty of any kind.
'  Report errors or make suggestions for improvement to
' <code@di-mgt.com.au>.
' The latest version of CryptoSys(TM) for personal use may be
' downloaded from <www.di-mgt.com.au/crypto.html>.
'  This copyright notice must always be left intact.
'****************** END OF COPYRIGHT NOTICE*************************

Dim msHexKey As String
Dim msHexIV As String
Dim msPlain As String
Dim msCipher As String
Dim msDecrypt As String

Private Sub cmdDecrypt_Click()
    Dim nblocklen As Long
    Dim lngRet As Long
    Dim sMode As String
    
    nblocklen = GetBlockLen()
    
    ' Assume cipher text is OK; just do it
    msCipher = Me.txtCipherHex
    msDecrypt = String(Len(msCipher), " ")
    
    ' Set mode
    If Me.optModeCBC Then
        sMode = "CBC"
    Else
        sMode = "ECB"
    End If
    
    ' Now decrypt as per algorithm
    If Me.optDES.Value Then
        lngRet = DES_HexMode(msDecrypt, msCipher, msHexKey, False, sMode, msHexIV)
    ElseIf Me.optTDEA.Value Then
        lngRet = TDEA_HexMode(msDecrypt, msCipher, msHexKey, False, sMode, msHexIV)
    ElseIf Me.optAES128128 Then
        lngRet = AES_HexMode(msDecrypt, msCipher, msHexKey, 128&, 128&, False, sMode, msHexIV)
    ElseIf Me.optAES256256 Then
        lngRet = AES_HexMode(msDecrypt, msCipher, msHexKey, 256&, 256&, False, sMode, msHexIV)
    ElseIf Me.optBLF Then
        lngRet = BLF_HexMode(msDecrypt, msCipher, msHexKey, False, sMode, msHexIV)
    End If
    
    ' Check whether OK
    If lngRet <> 0 Then
        MsgBox "CryptoSys error " & lngRet & " has occurred"
        Exit Sub
    End If
    
    ' Strip padding if nec
    If Me.optPad Then
        msDecrypt = bu_UnpadHexString(msDecrypt, nblocklen)
    End If
    
    ' Display output
    Me.txtDecryptHex = msDecrypt
    Me.txtDecrypt = bu_Hex2Str(msDecrypt)
    
End Sub

Private Sub cmdEncrypt_Click()
' Encrypt the plain text as required using hex strings
    Dim nBlkLen As Long
    Dim lngRet As Long
    Dim sMode As String
    
    ' Make sure key and IV are set
    Call SetKey
    Call SetIV
    
    ' Convert plain text into hex if nec
    If Me.optPTAlpha Then
        msPlain = bu_Str2Hex(Me.txtPlain)
    Else
        If Not bu_IsValidHex(Me.txtPlain) Then
            MsgBox "Invalid hex in plain text"
            GoTo Done
        End If
        msPlain = Me.txtPlain
    End If
    
    ' Then pad input if required
    nBlkLen = GetBlockLen()
    If Me.optPad Then
        msPlain = bu_PadHexString(msPlain, nBlkLen)
    ElseIf Len(msPlain) / 2 < nBlkLen Then
        MsgBox "Plain text is too short to encrypt without padding"
        GoTo Done
    End If
    
    ' Show input data as hex
    Me.txtPlainAsHex = msPlain
    
    ' Set up output string to required length
    msCipher = String(Len(msPlain), " ")
    
    ' Set mode
    If Me.optModeCBC Then
        sMode = "CBC"
    Else
        sMode = "ECB"
    End If
    
    ' Now encrypt as per algorithm
    If Me.optDES.Value Then
        lngRet = DES_HexMode(msCipher, msPlain, msHexKey, True, sMode, msHexIV)
    ElseIf Me.optTDEA.Value Then
        lngRet = TDEA_HexMode(msCipher, msPlain, msHexKey, True, sMode, msHexIV)
    ElseIf Me.optAES128128 Then
        lngRet = AES_HexMode(msCipher, msPlain, msHexKey, 128&, 128&, True, sMode, msHexIV)
    ElseIf Me.optAES256256 Then
        lngRet = AES_HexMode(msCipher, msPlain, msHexKey, 256&, 256&, True, sMode, msHexIV)
    ElseIf Me.optBLF Then
        lngRet = BLF_HexMode(msCipher, msPlain, msHexKey, True, sMode, msHexIV)
    End If
    
    If lngRet <> 0 Then
        MsgBox "CryptoSys error " & lngRet & " has occurred"
        Exit Sub
    End If

    ' Display results
    Me.txtCipherHex = msCipher
    Me.txtCipher = bu_Hex2Str(msCipher)
    Me.txtCipher64 = EncodeStr64(bu_Hex2Str(msCipher))
    Me.cmdDecrypt.Enabled = True
Done:

End Sub

Private Sub cmdGenKey_Click()
    ' Generate a random key silently
    Call GenerateKey(False)
End Sub

Private Sub cmdGenKeyPrompt_Click()
    ' Generate a random key with user prompt
    Call GenerateKey(True)
End Sub

Private Sub GenerateKey(bPromptUser As Boolean)
    ' Generate a random key
    Dim sHexKey As String
    
    ' Pad to longest possible length
    sHexKey = String(64, " ")
    
    ' Create in appropriate length
    If Me.optDES.Value Then
        Call RAN_DESKeyGenHex(sHexKey, bPromptUser)
    ElseIf Me.optTDEA.Value Then
        Call RAN_TDEAKeyGenHex(sHexKey, bPromptUser)
    ElseIf Me.optAES128128 Then
        Call RAN_KeyGenHex(sHexKey, 16, bPromptUser)
    ElseIf Me.optAES256256 Then
        Call RAN_KeyGenHex(sHexKey, 32, bPromptUser)
    Else
        ' Set to 16 byte length by default
        Call RAN_KeyGenHex(sHexKey, 16, bPromptUser)
    End If
    
    sHexKey = Trim(sHexKey)
    
    Me.optHexKey = True
    Me.txtKey = sHexKey
    Me.txtKeyAsString.Text = sHexKey
    ' Allow encrypt
    Me.cmdEncrypt.Enabled = True
    ' Put user in plaintext box
    Me.txtPlain.SetFocus

End Sub

Private Sub cmdSetKey_Click()
    Call SetKey
    Call SetIV
End Sub
    
Private Sub SetKey()
' Set key as a hex string
    Dim nKeyLen As Long
    Dim nPad As Long

    ' What format is the key in?
    If Me.optHexKey Then
        If bu_IsValidHex(Me.txtKey) Then
            msHexKey = Me.txtKey
        Else
            MsgBox "Key is not valid hex"
            Me.txtKey.SetFocus
            GoTo Done
        End If
    Else
        ' User has provided a plain alpha string
        msHexKey = bu_Str2Hex(Me.txtKey)
    End If
    
    ' Now pad key with zeroes as per algorithm
    If Me.optDES.Value Then
        nKeyLen = 8
    ElseIf Me.optTDEA.Value Then
        nKeyLen = 24
    ElseIf Me.optAES128128 Then
        nKeyLen = 16
    ElseIf Me.optAES256256 Then
        nKeyLen = 32
    Else
        nKeyLen = Len(msHexKey) \ 2
    End If
    
    ' nKeyLen is # of bytes - we want len of hex string
    nPad = nKeyLen * 2 - Len(msHexKey)
    If nPad > 0 Then
        msHexKey = msHexKey & String(nPad, "0")
    ElseIf nPad < 0 Then
        msHexKey = Left(msHexKey, nKeyLen * 2)
    End If
    
    
    ' Show key
    Me.txtKeyAsString = msHexKey
    ' Allow encrypt
    Me.cmdEncrypt.Enabled = True
    ' Put user in plaintext box
    Me.txtPlain.SetFocus
    
Done:

End Sub

Private Sub SetIV()
' Set IV
    Dim sHexIV As String
    Dim nBlkLen As Long
    Dim nPad As Long
    
    ' Check mode
    If Me.optModeECB Then
        msHexIV = ""
        GoTo Done
    Else
        msHexIV = Me.txtIV
    End If
    
    ' Now pad IV with zeroes as per algorithm
    nBlkLen = GetBlockLen()
    
    nPad = nBlkLen * 2 - Len(msHexIV)
    If nPad > 0 Then
        msHexIV = msHexIV & String(nPad, "0")
    ElseIf nPad < 0 Then
        msHexIV = Left(msHexIV, nBlkLen * 2)
    End If
    
    ' Show iv
    Me.txtIVAsString = msHexIV
    
Done:

End Sub

Private Function GetBlockLen()
    If Me.optDES.Value Then
        GetBlockLen = 8
    ElseIf Me.optTDEA.Value Then
        GetBlockLen = 8
    ElseIf Me.optAES128128 Then
        GetBlockLen = 16
    ElseIf Me.optAES256256 Then
        GetBlockLen = 32
    Else    ' default
        GetBlockLen = 8
    End If
End Function
