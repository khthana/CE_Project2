/* t_diCryptoLib.c  */

/*
This source code carries out a series of tests on the 
functions in diCryptoSys.dll. It is not meant to be representative
of good security coding, but uses published test vectors wherever possible.
(Warning: strcmp() is case-sensitive).

Use in conjunction with diCryptoSys.lib and diCryptoSys.dll (Version 2.0 or later)

Copyright (C) 2003 DI Management Services Pty Limited. All rights reserved.
*/

#include "diCryptoSys.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

// Compiler-specific explicit link to library
// This works in MSVC and Borland - you may need to do otherwise
#pragma comment(lib, ".\\diCryptoSys.lib")

/* UTILITIES USED IN THESE TESTS */

int create_hello_file(char *hello_file)
/* Create a 13-byte text file "hello world" plus CR-LF */
{
	FILE *fp;

	fp = fopen(hello_file, "wb");
	assert (fp != NULL);
	fprintf(fp, "hello world\r\n");
	fclose(fp);
	printf("Created 'hello.txt' as %s\n", hello_file);

	return 0;
}

int create_nowis_file(char *filename)
/* Create a 32-byte text file without a CR-LF at end */
{
	FILE *fp;

	fp = fopen(filename, "wb");
	assert (fp != NULL);
	fprintf(fp, "Now is the time for all good men");
	fclose(fp);
	printf("Created 'nowis.txt' as %s\n", filename);

	return 0;
}

int create_bin_file(char *bin_file)
/* Create a 512-byte binary file (0x00,0x01,0x02,...,0xFF)*2 */
{
	int i, k;
	FILE *fp;

	fp = fopen(bin_file, "wb");
	assert (fp != NULL);
	for (k = 0; k < 2; k++)
		for (i = 0; i < 256; i++)
			fputc(i, fp);
	fclose(fp);
	printf("Created 'test.bin' as %s\n", bin_file);

	return 0;
}

int cmp_files(char *file1, char *file2)
/* Compares two binary files: returns 0 if identical 
   or 1 if not identical or -1 if file error */
{
	FILE *fp1, *fp2;
	int c1, c2;
	int result = 0;	/* Innocent until proven guilty */

	fp1 = fopen(file1, "rb");
	if (fp1 == NULL) 
		return -1;
	fp2 = fopen(file2, "rb");
	if (fp2 == NULL)
	{
		fclose(fp1);
		return -1;
	}

	while ((c1 = fgetc(fp1)) != EOF)
	{
		c2 = fgetc(fp2);
		if (c2 == EOF)
		{	/* File 2 is shorter than file 1 */
			result = 1;
			break;
		}
		if (c1 != c2)
		{	/* Found a mis-match */
			result = 1;
			break;
		}
	}

	if (feof(fp1))
	{	/* Make sure file2 is same length */
		if ((c2 = fgetc(fp2)) != EOF)
			result = 1;
	}

	fclose(fp1);
	fclose(fp2);

	return result;
}

int cmp_file_with_hex(char *file, char *hex_ok)
{
	unsigned char *correct, *fbuf, *cp;
	int i, n, x;
	FILE *fp;
	char hex[3];

	/* Convert correct hex string to bytes */
	n = strlen(hex_ok) / 2;
	correct = malloc(n);
	assert (correct != NULL);
	fbuf = malloc(n);
	assert (fbuf != NULL);

	for (cp = hex_ok, i = 0; i < n; i++)
	{
		hex[0] = *cp++;
		hex[1] = *cp++;
		hex[2] = 0;
		sscanf(hex, "%x", &x);
		correct[i] = x;
	}

	/* Read in file to buffer */
	fp = fopen(file, "rb");
	assert (fp != NULL);
	fread(fbuf, 1, n, fp);
	/* Make sure we are end of file */
	x = fgetc(fp);
	fclose(fp);
	if (x != EOF)
		return 1;

	/* Do we have a match? */
	return (memcmp(fbuf, correct, n));
}


static void pr_hexbytes(unsigned char *bytes, int nbytes)
/* Print bytes in hex format + newline */
{
	int i;

	for (i = 0; i < nbytes; i++)
		printf("%02X", bytes[i]);
	printf("\n");
}

/* DES TESTS */

void test_DES_Hex(void)
{
    char *testfn = "DES_Hex()";
    char sHexKey[] = "0123456789abcdef";
	/* "Now is t" in hex */
    char sInput[] = "4E6F772069732074";
    char sCorrect[] = "3FA40E8A984D4815";
    char sOutput[sizeof(sInput)+1];
	long lngRet;

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = DES_Hex(sOutput, sInput, sHexKey, ENCRYPT);
	assert (lngRet == 0);
	/* Check */
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sCorrect, sOutput) == 0);

    // Now decrypt back to plain text using same buffer
    lngRet = DES_Hex(sOutput, sOutput, sHexKey, DECRYPT);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sInput, sOutput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_DES_HexMode(void)
{
    char *testfn = "DES_HexMode()";
	long lngRet;
	char sHexKey[] = "0123456789abcdef";
    char sHexIV[] = "1234567890abcdef";
    // "Now is the time for all good men"
    char sInput[] = "4E6F77206973207468652074696D6520666F7220616C6C20";
    char sCorrect[] = "E5C7CDDE872BF27C43E934008C389C0F683788499A7C05F6";
    // Set sOutput to be same length as sInput
    char sOutput[sizeof(sInput)+1];

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("IV=%s\n", sHexIV);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = DES_HexMode(sOutput, sInput, sHexKey, ENCRYPT, "CBC", sHexIV);
	assert (lngRet == 0);
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sOutput, sCorrect) == 0);

    // Now decrypt back to plain text
    lngRet = DES_HexMode(sOutput, sOutput, sHexKey, DECRYPT, "cbc", sHexIV);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sOutput, sInput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_DES_UpdateHex(void)
{
	long hContext;
	long result;
	char sKey[] = "0123456789ABCDEF";
	char sInitV[] = "1234567890abcdef";
	char sHexString[33];
	char *correct;

	printf("Testing DES_UpdateHex() in CBC mode ...\n");
	hContext = DES_InitHex(sKey, ENCRYPT, "CBC", sInitV);
	if (hContext == 0)
		printf("DES_InitError=%ld\n", DES_InitError());
	assert (hContext != 0);

	/* First part: "Now is t" in hex (8 chars) */
	strcpy(sHexString, "4e6f772069732074");
	result = DES_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "E5C7CDDE872BF27C";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
	assert (strcmp(sHexString, correct) == 0);

    /* Second part: "he time for all " in hex (16 chars) */
    strcpy(sHexString, "68652074696d6520666f7220616c6c20");
    result = DES_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "43E934008C389C0F683788499A7C05F6";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
    assert (strcmp(sHexString, correct) == 0);

    result = DES_Final(hContext);
	assert (result == 0);

	/* Now decrypt */
	hContext = DES_InitHex(sKey, DECRYPT, "CBC", sInitV);
	if (hContext == 0)
		printf("DES_InitError=%ld\n", DES_InitError());
	assert (hContext != 0);

	strcpy(sHexString, "E5C7CDDE872BF27C43E934008C389C0F");
	result = DES_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "4E6F77206973207468652074696D6520";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
	assert (strcmp(sHexString, correct) == 0);

    strcpy(sHexString, "683788499A7C05F6");
    result = DES_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "666F7220616C6C20";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
    assert (strcmp(sHexString, correct) == 0);

    result = DES_Final(hContext);
	assert (result == 0);


	printf("...DES_UpdateHex() tested OK\n");
}

void test_DES_FileHex(void)
{
    char *testfn = "DES_FileHex()";
    long lngRet;

    // Construct full path names to files
    char *strFileIn = "now.txt";
    char *strFileOut = "DESnow.enc";
    char *strFileChk = "DESnow.chk";

    // Encrypt plaintext file to cipher
    // WARNING: output file is just clobbered
    char sHexKey[] = "0123456789ABCDEF";

	printf("Testing %s...\n", testfn);

	create_nowis_file(strFileIn);

    lngRet = DES_FileHex(strFileOut, strFileIn, sHexKey, 
        ENCRYPT, "ECB", 0);
    assert (lngRet == 0);

	assert (cmp_file_with_hex(strFileOut, 
		"3FA40E8A984D48156A271787AB8883F9893D51EC4B563B53"
		"73C1ADB2171F7894086F9A1D74C94D4E")
		== 0);

    // Now decrypt it
    lngRet = DES_FileHex(strFileChk, strFileOut, sHexKey, 
        DECRYPT, "ECB", 0);
    assert (lngRet == 0);

	/* and check we got the plaintext we started with */
	assert (cmp_files(strFileChk, strFileIn) == 0);

	remove(strFileIn);
	remove(strFileOut);
	remove(strFileChk);

	printf("...%s tested OK\n", testfn);
}

void test_DES_Bytes_rand(void)
/* Encrypt and decrypt random blocks with random keys */
{
    char *testfn = "DES_Bytes_rand()";

	unsigned char key[8];
	unsigned char plain[1024];
	unsigned char cipher[1024];
	int i, j, n, m;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing DES_Bytes() with random blocks ...\n");
	for (i = 0; i < 10; i++)
	{
		/* Create a random key */
		for (j = 0; j < 8; j++)
			key[j] = rand() & 0xFF;

		/* Create some 'random' plaintext up to 1024 bytes long */
		/* in a multiple of block size */
		m = 1024 / 8;
		n = ((rand() % m) + 1) * 8; 
		assert (n <= sizeof(plain));

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;
	
		/* Encrypt it into ciphertext */
		result = DES_Bytes(cipher, plain, n, key, ENCRYPT);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = DES_Bytes(cipher, cipher, n, key, DECRYPT);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
		printf("%d(%d) ", i+1, n);
	}

	printf("...%s tested OK\n", testfn);
}


void test_DES_InitError(void)
{
	unsigned char key[24], iv[8];
	char badhex[] = "THIS IS NOT HEX!";
	long hContext;
	long errcode;
	
	printf("Testing DES_InitError() ...\n");

	/* Call with a bad key */
	hContext = DES_Init(NULL, ENCRYPT, "CBC", iv);
	assert (hContext == 0);
	errcode = DES_InitError();
	printf("DES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad iv */
	hContext = DES_Init(key, ENCRYPT, "CBC", NULL);
	assert (hContext == 0);
	errcode = DES_InitError();
	printf("DES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex key */
	hContext = DES_InitHex(badhex, ENCRYPT, "CBC", "FEDCBA9876543210");
	assert (hContext == 0);
	errcode = DES_InitError();
	printf("DES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex iv */
	hContext = DES_InitHex("FEDCBA9876543210", ENCRYPT, "CBC", badhex);
	assert (hContext == 0);
	errcode = DES_InitError();
	printf("DES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad mode */
	hContext = DES_InitHex("FEDCBA9876543210", ENCRYPT, "XXX", "0123456789ABDCDEF");
	assert (hContext == 0);
	errcode = DES_InitError();
	printf("DES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	printf("...DES_InitError tested OK\n");
}



/* TRIPLE DES (TDEA, 3DES) TESTS */

void test_TDEA_Hex(void)
{
    char *testfn = "TDEA_Hex()";
    char sHexKey[] = "010101010101010101010101010101010101010101010101";
    char sInput[] = "8000000000000000";
    char sCorrect[] = "95F8A5E5DD31D900";
    char sOutput[sizeof(sInput)+1];
	long lngRet;

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = TDEA_Hex(sOutput, sInput, sHexKey, ENCRYPT);
	assert (lngRet == 0);
	/* Check */
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sCorrect, sOutput) == 0);

    // Now decrypt back to plain text using same buffer
    lngRet = TDEA_Hex(sOutput, sOutput, sHexKey, DECRYPT);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sInput, sOutput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_TDEA_Hex_Monte(void)
{
	int i;
	long lngRet;
	char sBlock[] = "4e6f772069732074";
    char sKey[] = 
		"0123456789abcdef"
		"23456789abcdef01"
		"456789abcdef0123";
    char sCorrect[] = "DD17E8B8B437D232";

    char *testfn = "TDEA_Hex_Monte()";

	printf("Testing %s...\n", testfn);

    printf("TDEA Monte Carlo TECB Mode Encrypt:\n");
    printf("KY=%s\n", sKey);
    printf("PT=%s\n", sBlock);
    // Do 10,000 times
    for (i = 0; i < 10000; i++)
	{
        lngRet = TDEA_Hex(sBlock, sBlock, sKey, ENCRYPT);
		assert (lngRet == 0);
	}
    printf("CT=%s\n", sBlock);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sBlock, sCorrect) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_TDEA_FileHex(void)
{
    char *testfn = "TDEA_FileHex()";
    long lngRet;

    // Construct full path names to files
    char *strFileIn = "now.txt";
    char *strFileOut = "TDEAnow.enc";
    char *strFileChk = "TDEAnow.chk";

    // Encrypt plaintext file to cipher
    // WARNING: output file is just clobbered
    char sHexKey[] = "fedcba9876543210fedcba9876543210fedcba9876543210";

	printf("Testing %s...\n", testfn);

	create_nowis_file(strFileIn);

    lngRet = TDEA_FileHex(strFileOut, strFileIn, sHexKey, 
        ENCRYPT, "ECB", 0);
    assert (lngRet == 0);

    // Now decrypt it
    lngRet = TDEA_FileHex(strFileChk, strFileOut, sHexKey, 
        DECRYPT, "ECB", 0);
    assert (lngRet == 0);

	/* and check we got the plaintext we started with */
	assert (cmp_files(strFileChk, strFileIn) == 0);

	remove(strFileIn);
	remove(strFileOut);
	remove(strFileChk);

	printf("...%s tested OK\n", testfn);
}

void test_TDEA_Bytes_rand(void)
/* Encrypt and decrypt random blocks with random keys */
{
    char *testfn = "TDEA_Bytes_rand()";

	unsigned char key[24];
	unsigned char plain[1024];
	unsigned char cipher[1024];
	int i, j, n, m;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing %s...\n", testfn);
	for (i = 0; i < 10; i++)
	{
		/* Create a random key */
		for (j = 0; j < 24; j++)
			key[j] = rand() & 0xFF;

		/* Create some 'random' plaintext up to 1024 bytes long */
		/* in a multiple of block size */
		m = 1024 / 8;
		n = ((rand() % m) + 1) * 8; 
		assert (n <= sizeof(plain));

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;
	
		/* Encrypt it into ciphertext */
		result = TDEA_Bytes(cipher, plain, n, key, ENCRYPT);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = TDEA_Bytes(cipher, cipher, n, key, DECRYPT);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
		printf("%d(%d) ", i+1, n);
	}

	printf("...%s tested OK\n", testfn);
}

void test_TDEA_BytesMode_rand(void)
/* Encrypt and decrypt random blocks with random keys 
   in random modes 
*/
{
    char *testfn = "TDEA_BytesMode_rand()";

	unsigned char key[24];
	unsigned char plain[1024];
	unsigned char cipher[1024];
	unsigned char iv[8];
	char *modes[] = { "ECB", "CBC" };
	int i, j, n, m, im;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing %s...\n", testfn);
	for (i = 0; i < 10; i++)
	{
		/* Create a random key and IV */
		for (j = 0; j < 24; j++)
			key[j] = rand() & 0xFF;
		for (j = 0; j < 8; j++)
			iv[j] = rand() & 0xFF;

		/* Create some 'random' plaintext up to 1024 bytes long */
		/* in a multiple of block size */
		m = 1024 / 8;
		n = ((rand() % m) + 1) * 8; 
		assert (n <= sizeof(plain));

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;

		/* Select a mode index: 0 or 1 */
		im = rand() & 0x01;
	
		/* Encrypt it into ciphertext */
		result = TDEA_BytesMode(cipher, plain, n, key, ENCRYPT, modes[im], iv);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = TDEA_BytesMode(cipher, cipher, n, key, DECRYPT, modes[im], iv);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
		printf("%d(%d) ", i+1, n);
	}

	printf("...%s tested OK\n", testfn);
}


void test_TDEA_InitError(void)
{
	unsigned char key[24], iv[8];
	char badhex[] = "THIS IS NOT HEX!";
	long hContext;
	long errcode;
	
	printf("Testing TDEA_InitError() ...\n");

	/* Call with a bad key */
	hContext = TDEA_Init(NULL, 1, "CBC", iv);
	assert (hContext == 0);
	errcode = TDEA_InitError();
	printf("TDEA_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad iv */
	hContext = TDEA_Init(key, 1, "CBC", NULL);
	assert (hContext == 0);
	errcode = TDEA_InitError();
	printf("TDEA_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex key */
	hContext = TDEA_InitHex(badhex, 1, "CBC", "FEDCBA9876543210");
	assert (hContext == 0);
	errcode = TDEA_InitError();
	printf("TDEA_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex iv */
	hContext = TDEA_InitHex("FEDCBA9876543210", 1, "CBC", badhex);
	assert (hContext == 0);
	errcode = TDEA_InitError();
	printf("TDEA_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad mode */
	hContext = TDEA_InitHex("FEDCBA9876543210", 1, "XXX", "0123456789ABDCDEF");
	assert (hContext == 0);
	errcode = TDEA_InitError();
	printf("TDEA_InitError returns %d\n", errcode);
	assert (errcode != 0);

	printf("...TDEA_InitError tested OK\n");
}



/* SHA-1 TESTS */

void Test_SHA1_StringHexHash(void)
{
    long result;
    char sDigest[41];	/* NB 1 extra char */
    char sCorrect[] = "a9993e364706816aba3e25717850c26c9cd0d89d";

	printf("Testing SHA1_StringHexHash()...\n");

    result = SHA1_StringHexHash(sDigest, "abc");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...SHA1_StringHexHash() tested OK\n");
}

void Test_SHA2_StringHexHash(void)
{
    char *testfn = "SHA2_StringHexHash()";
	long result;
    char sDigest[65];	/* NB 1 extra char */
    char sCorrect[] = 
"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";

	printf("Testing %s...\n", testfn);

    result = SHA2_StringHexHash(sDigest, "abc");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA1_BytesHexHash(void)
{
    char *testfn = "SHA1_BytesHexHash()";
	long result;
    char sDigest[41];	/* NB 1 extra char */
    char sCorrect[] = "a9993e364706816aba3e25717850c26c9cd0d89d";
	unsigned char bytes[3];

	printf("Testing %s...\n", testfn);

	bytes[0] = 'a';
	bytes[1] = 'b';
	bytes[2] = 'c';
    result = SHA1_BytesHexHash(sDigest, bytes, 3);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA2_BytesHexHash(void)
{
    char *testfn = "SHA2_BytesHexHash()";
	long result;
    char sDigest[65];	/* NB 1 extra char */
    char sCorrect[] = 
"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
	unsigned char bytes[3];

	printf("Testing %s...\n", testfn);

	bytes[0] = 'a';
	bytes[1] = 'b';
	bytes[2] = 'c';
    result = SHA2_BytesHexHash(sDigest, bytes, 3);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA1_HexDigest(void)
{
    char *testfn = "SHA1_HexDigest()";
	long result;
    char sDigest[41];	/* NB 1 extra char */
    char sCorrect[] = "a9993e364706816aba3e25717850c26c9cd0d89d";
	long hContext;
	unsigned char bytes[2];

	printf("Testing %s...\n", testfn);

	hContext = SHA1_Init();
	assert (hContext != 0);

	/* Combine _AddString and _AddBytes */

	result = SHA1_AddString(hContext, "a");
	assert (result == 0);

    bytes[0] = 'b';
	bytes[1] = 'c';
	result = SHA1_AddBytes(hContext, bytes, 2);
	assert (result == 0);

	result = SHA1_HexDigest(sDigest, hContext);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA2_HexDigest(void)
{
    char *testfn = "SHA2_HexDigest()";
	long result;
    char sDigest[65];	/* NB 1 extra char */
    char sCorrect[] = 
"ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
	long hContext;
	unsigned char bytes[2];

	printf("Testing %s...\n", testfn);

	hContext = SHA2_Init();
	assert (hContext != 0);

	/* Combine _AddString and _AddBytes */

	result = SHA2_AddString(hContext, "a");
	assert (result == 0);

    bytes[0] = 'b';
	bytes[1] = 'c';
	result = SHA2_AddBytes(hContext, bytes, 2);
	assert (result == 0);

	result = SHA2_HexDigest(sDigest, hContext);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA1_AddString(void)
{
    char *testfn = "SHA1_AddString()";
	long result;
    char sDigest[41];	/* NB 1 extra char */
    char sCorrect[] = "34aa973cd4c4daa4f61eeb2bdbad27316534016f";
	long hContext;
	char sA1000[1001];
	int i;

	printf("Testing %s...\n", testfn);

	hContext = SHA1_Init();
	assert (hContext != 0);

	/* Create a string of 1000 'a's */
	for (i = 0; i < 1000; i++)
		sA1000[i] = 'a';
	sA1000[i] = '\0';

	/* Add 1000 times => one million repetitions of "a" */

	for (i = 0; i < 1000; i++)
	{
		result = SHA1_AddString(hContext, sA1000);
		assert (result == 0);
	}

	/* Create final digest */

	result = SHA1_HexDigest(sDigest, hContext);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA2_AddString(void)
{
    char *testfn = "SHA2_AddString()";
	long result;
    char sDigest[65];	/* NB 1 extra char */
    char sCorrect[] = 
"cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0";
	long hContext;
	char sA1000[1001];
	int i;

	printf("Testing %s...\n", testfn);

	hContext = SHA2_Init();
	assert (hContext != 0);

	/* Create a string of 1000 'a's */
	for (i = 0; i < 1000; i++)
		sA1000[i] = 'a';
	sA1000[i] = '\0';

	/* Add 1000 times => one million repetitions of "a" */

	for (i = 0; i < 1000; i++)
	{
		result = SHA2_AddString(hContext, sA1000);
		assert (result == 0);
	}

	/* Create final digest */

	result = SHA2_HexDigest(sDigest, hContext);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect);
	assert (strcmp(sDigest, sCorrect) == 0);
	printf("...%s tested OK\n", testfn);
}

void Test_SHA1_Hmac(void)
{
    char *testfn = "SHA1_Hmac()";
	long result;
    char sDigest[41];	/* NB 1 extra char */
    char sCorrect1[] = "675b0b3a1b4ddf4e124872da6c2f632bfed957e9";
    char sCorrect2[] = "effcdf6ae5eb2fa2d27416d5f184df9c259a7c79";
    char sCorrect3[] = "d730594d167e35d5956fd8003d0db3d3f46dc7bb";
	int i;
	unsigned char key1[16];
	unsigned char key2[] = "Jefe";
	unsigned char key3[16];
	unsigned char data1[] = "Hi There";
	unsigned char data2[] = "what do ya want for nothing?";
	unsigned char data3[50];
	int key_len, data_len;

	printf("Testing %s...\n", testfn);

    /* Test No 1. from RFC 2104
	key =         0x0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b
	key_len =     16 bytes
	data =        "Hi There"
	data_len =    8  bytes
	*/
	key_len = 16;
	for (i = 0; i < key_len; i++)
		key1[i] = 0x0b;

	data_len = 8;

	result = SHA1_Hmac(sDigest, data1, data_len, key1, key_len);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect1);
	assert (strcmp(sDigest, sCorrect1) == 0);

    /* Test No 2.
	key =         "Jefe"
	data =        "what do ya want for nothing?"
	data_len =    28 bytes
	digest =      0x750c783e6ab0b503eaa86e310a5db738
	*/
	key_len = 4;
	data_len = 28;

	result = SHA1_Hmac(sDigest, data2, data_len, key2, key_len);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect2);
	assert (strcmp(sDigest, sCorrect2) == 0);

    /* Test No 3.
	key =         0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
	key_len       16 bytes
	data =        0xDDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD
	data_len =    50 bytes
	*/
	key_len = 16;
	for (i = 0; i < key_len; i++)
		key3[i] = 0xAA;

	data_len = 50;
	for (i = 0; i < data_len; i++)
		data3[i] = 0xDD;

	result = SHA1_Hmac(sDigest, data3, data_len, key3, key_len);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect3);
	assert (strcmp(sDigest, sCorrect3) == 0);

	printf("...%s tested OK\n", testfn);
}

void Test_SHA2_Hmac(void)
{
    char *testfn = "SHA2_Hmac()";
	long result;
    char sDigest[65];	/* NB 1 extra char */
    char sCorrect1[] = 
"492ce020fe2534a5789dc3848806c78f4f6711397f08e7e7a12ca5a4483c8aa6";
    char sCorrect2[] = 
"5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843";
    char sCorrect3[] = 
"7dda3cc169743a6484649f94f0eda0f9f2ff496a9733fb796ed5adb40a44c3c1";
	int i;
	unsigned char key1[16];
	unsigned char key2[] = "Jefe";
	unsigned char key3[16];
	unsigned char data1[] = "Hi There";
	unsigned char data2[] = "what do ya want for nothing?";
	unsigned char data3[50];
	int key_len, data_len;

	printf("Testing %s...\n", testfn);

    /* Test No 1. from RFC 2104
	key =         0x0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b0b
	key_len =     16 bytes
	data =        "Hi There"
	data_len =    8  bytes
	*/
	key_len = 16;
	for (i = 0; i < key_len; i++)
		key1[i] = 0x0b;

	data_len = 8;

	result = SHA2_Hmac(sDigest, data1, data_len, key1, key_len);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect1);
	assert (strcmp(sDigest, sCorrect1) == 0);

    /* Test No 2.
	key =         "Jefe"
	data =        "what do ya want for nothing?"
	data_len =    28 bytes
	digest =      0x750c783e6ab0b503eaa86e310a5db738
	*/
	key_len = 4;
	data_len = 28;

	result = SHA2_Hmac(sDigest, data2, data_len, key2, key_len);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect2);
	assert (strcmp(sDigest, sCorrect2) == 0);

    /* Test No 3.
	key =         0xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
	key_len       16 bytes
	data =        0xDDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD...
				..DDDDDDDDDDDDDDDDDDDD
	data_len =    50 bytes
	*/
	key_len = 16;
	for (i = 0; i < key_len; i++)
		key3[i] = 0xAA;

	data_len = 50;
	for (i = 0; i < data_len; i++)
		data3[i] = 0xDD;

	result = SHA2_Hmac(sDigest, data3, data_len, key3, key_len);

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrect3);
	assert (strcmp(sDigest, sCorrect3) == 0);

	printf("...%s tested OK\n", testfn);
}


void Test_SHA1_FileHexHash(void)
/* 'hello' and 'bin' are filenames */
{
	char *testfn = "SHA1_FileHexHash";
	long result;
	char sDigest[41];	/* NB 1 extra char */
    char sCorrectT[] = "22596363b3de40b06f981fb85d82312e8c0ed511";
    char sCorrectB[] = "88a5b867c3d110207786e66523cd1e4a484da697";
    char sCorrectBIN[] = "dbe649daba340bce7a44b809016d914839b99f10";
	char *hello = "hello$$.txt";
	char *bin = "bin$$.dat";

	printf("Testing %s...\n", testfn);

	create_hello_file(hello);
	create_bin_file(bin);

	result = SHA1_FileHexHash(sDigest, hello, "t");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrectT);
	assert (strcmp(sDigest, sCorrectT) == 0);

	result = SHA1_FileHexHash(sDigest, hello, "b");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrectB);
	assert (strcmp(sDigest, sCorrectB) == 0);

	result = SHA1_FileHexHash(sDigest, bin, "b");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n",  sCorrectBIN);
	assert (strcmp(sDigest, sCorrectBIN) == 0);

	remove(hello);
	remove(bin);
	printf("...%s tested OK\n", testfn);
/*
C:\Test>sha1sum hello.txt
22596363b3de40b06f981fb85d82312e8c0ed511  hello.txt

C:\Test>sha1sum -b hello.txt
88a5b867c3d110207786e66523cd1e4a484da697 *hello.txt

C:\Test>sha1sum -b test.bin
dbe649daba340bce7a44b809016d914839b99f10 *test.bin
*/
}

void Test_SHA2_FileHexHash(void)
{
	char *testfn = "SHA2_FileHexHash";
	long result;
	char sDigest[65];	/* NB 1 extra char */
    char sCorrectT[] = 
"a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447";
    char sCorrectB[] = 
"572a95fee9c0f320030789e4883707affe12482fbb1ea04b3ea8267c87a890fb";
    char sCorrectBIN[] = 
"110009dcee21620b166f3abfecb5eff7a873be729d1c2d53822e7acc5f34eb9b";
	char *hello = "hello$$2.txt";
	char *bin = "bin$$2.dat";

	printf("Testing %s...\n", testfn);

	create_hello_file(hello);
	create_bin_file(bin);

	result = SHA2_FileHexHash(sDigest, hello, "t");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrectT);
	assert (strcmp(sDigest, sCorrectT) == 0);

	result = SHA2_FileHexHash(sDigest, hello, "b");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n", sCorrectB);
	assert (strcmp(sDigest, sCorrectB) == 0);

	result = SHA2_FileHexHash(sDigest, bin, "b");

	assert (result == 0);
	printf("Result =%s\n", sDigest);
	printf("Correct=%s\n",  sCorrectBIN);
	assert (strcmp(sDigest, sCorrectBIN) == 0);

	remove(hello);
	remove(bin);
	printf("...%s tested OK\n", testfn);
}

void test_BLF_Hex(void)
{
	long result;
    char sInputHex[] = "0123456789ABCDEF";
    char sKeyHex[] = "FEDCBA9876543210";
    char sCorrectHex[] = "0ACEAB0FC6A0A28D";
	/* NB Output for Hex requires an extra byte */
	char sOutputHex[sizeof(sInputHex)+1];

	printf("Testing BLF_Hex()...\n");
	result = BLF_Hex(sOutputHex, sInputHex, sKeyHex, 1);
	assert (result == 0);
	printf("Result =%s\n", sOutputHex);
	printf("Correct=%s\n", sCorrectHex);
	assert (strcmp(sOutputHex, sCorrectHex) == 0);
	printf("...BLF_Hex() tested OK\n");
}

void test_BLF_UpdateHex(void)
{
	long hContext;
	long result;
	char sKey[] = "0123456789ABCDEF";
	char sHexString[33];
	char *correct;

	printf("Testing BLF_UpdateHex() in ECB mode ...\n");
	hContext = BLF_InitHex(sKey, 1, "ECB", NULL);
	if (hContext == 0)
		printf("BLF_InitError=%ld\n", BLF_InitError());
	assert (hContext != 0);

	/* First part: "Now is t" in hex (8 chars) */
	strcpy(sHexString, "4e6f772069732074");
	result = BLF_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "CB08E682C67E32E2";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
	assert (strcmp(sHexString, correct) == 0);

    /* Second part: "he time for all " in hex (16 chars) */
    strcpy(sHexString, "68652074696d6520666f7220616c6c20");
    result = BLF_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "8FCB010AC2CE9B1D9C4538762E33B52F";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
    assert (strcmp(sHexString, correct) == 0);

    result = BLF_Final(hContext);
	assert (result == 0);

	/* Now decrypt */
	hContext = BLF_InitHex(sKey, 0, "ECB", NULL);
	if (hContext == 0)
		printf("BLF_InitError=%ld\n", BLF_InitError());
	assert (hContext != 0);

	strcpy(sHexString, "CB08E682C67E32E2");
	result = BLF_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "4E6F772069732074";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
	assert (strcmp(sHexString, correct) == 0);

    strcpy(sHexString, "8FCB010AC2CE9B1D9C4538762E33B52F");
    result = BLF_UpdateHex(hContext, sHexString);
	assert (result == 0);
	correct = "68652074696D6520666F7220616C6C20";
	printf("Result =%s\n", sHexString);
	printf("Correct=%s\n", correct);
    assert (strcmp(sHexString, correct) == 0);

    result = BLF_Final(hContext);
	assert (result == 0);


	printf("...BLF_UpdateHex() tested OK\n");
}

void test_BLF_Ecb(void)
/* Test both BLF_Update in CBC mode and BLF_Ecb */
{
	unsigned char key[16] = { 
		0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF, 
		0xF0, 0xE1, 0xD2, 0xC3, 0xB4, 0xA5, 0x96, 0x87 };
	unsigned char iv[8] = {
		0xFE, 0xDC, 0xBA, 0x98, 0x76, 0x54, 0x32, 0x10 };
	unsigned char data[32]  = "7654321 Now is the time for \0\0\0\0";
	unsigned char cdata[32];
	unsigned char correct[32]= {
		0x6B, 0x77, 0xB4, 0xD6, 0x30, 0x06, 0xDE, 0xE6, 
		0x05, 0xB1, 0x56, 0xE2, 0x74, 0x03, 0x97, 0x93, 
		0x58, 0xDE, 0xB9, 0xE7, 0x15, 0x46, 0x16, 0xD9, 
		0x59, 0xF1, 0x65, 0x2B, 0xD5, 0xFF, 0x92, 0xCC };
	unsigned char work[8] = {
		0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef };
	unsigned char cwork[8];
	long result, hContext;

	printf("Testing BLF_Update() and BLF_Ecb() ...\n");

	hContext = BLF_Init(key, sizeof(key), 1, "CBC", iv);
	if (hContext == 0)
		printf("BLF_InitError=%ld\n", BLF_InitError());
	assert (hContext != 0);

	/* Encrypt data in CBC mode */
	memcpy(cdata, data, sizeof(data)); /* keep a copy */
	result = BLF_Update(hContext, data, sizeof(data));
	assert (result == 0);
	assert (memcmp(correct, data, sizeof(data)) == 0);

	/* Now use BLF_Ecb to do an independent encryption */
	memcpy(cwork, work, sizeof(work));	/* Keep a copy */
	result = BLF_Ecb(hContext, work, sizeof(work), 1);
	assert (result == 0);
	/* and decrypt */
	result = BLF_Ecb(hContext, work, sizeof(work), 0);
	assert (result == 0);
	/* and check against copy of plaintext */
	assert (memcmp(cwork, work, sizeof(work)) == 0);

	result = BLF_Final(hContext);
	assert (result == 0);

	/* Now decrypt in CBC mode */
	hContext = BLF_Init(key, sizeof(key), 0, "CBC", iv);
	if (hContext == 0)
		printf("BLF_InitError=%ld\n", BLF_InitError());
	assert (hContext != 0);

	result = BLF_Update(hContext, data, sizeof(data));
	assert (result == 0);
	/* and check against our original data */
	assert (memcmp(cdata, data, sizeof(data)) == 0);

	result = BLF_Final(hContext);
	assert (result == 0);


	printf("...BLF_Update() and BLF_Ecb tested OK\n");
}

void test_BLF_InitError(void)
{
	unsigned char key[24], iv[8];
	char badhex[] = "THIS IS NOT HEX!";
	long hContext;
	long errcode;
	
	printf("Testing BLF_InitError() ...\n");

	/* Call with a bad key */
	hContext = BLF_Init(NULL, sizeof(key), 1, "CBC", iv);
	assert (hContext == 0);
	errcode = BLF_InitError();
	printf("BLF_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad iv */
	hContext = BLF_Init(key, sizeof(key), 1, "CBC", NULL);
	assert (hContext == 0);
	errcode = BLF_InitError();
	printf("BLF_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex key */
	hContext = BLF_InitHex(badhex, 1, "CBC", "FEDCBA9876543210");
	assert (hContext == 0);
	errcode = BLF_InitError();
	printf("BLF_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex iv */
	hContext = BLF_InitHex("FEDCBA9876543210", 1, "CBC", badhex);
	assert (hContext == 0);
	errcode = BLF_InitError();
	printf("BLF_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad mode */
	hContext = BLF_InitHex("FEDCBA9876543210", 1, "XXX", "0123456789ABDCDEF");
	assert (hContext == 0);
	errcode = BLF_InitError();
	printf("BLF_InitError returns %d\n", errcode);
	assert (errcode != 0);

	printf("...BLF_InitError tested OK\n");
}

void test_BLF_Bytes_rand(void)
/* Encrypt and decrypt random blocks */
{
	unsigned char key[8] = { 
		0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10 };
	unsigned char plain[512];
	unsigned char cipher[512];
	int i, j, n;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing BLF_Bytes() with random blocks ...\n");
	for (i = 0; i < 10; i++)
	{
		/* Create some 'random' plaintext up to 512 bytes long */
		n = ((rand() & 0x2F) + 1) * 8; /* in multiple of 8 */
		assert (n <= 512);

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;
	
		/* Encrypt it into ciphertext */
		result = BLF_Bytes(cipher, plain, n, key, 8, 1);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = BLF_Bytes(cipher, cipher, n, key, 8, 0);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
		printf("%d(%d) ", i+1, n);
	}
	printf("\n...BLF_Bytes() tested OK\n");
}

void test_BLF_BytesMode_rkeys(void)
/* Encrypt and decrypt with random keys */
{
	unsigned char key[56];
	/* NB we don't want the trailing NUL here! */
	unsigned char plain[32] = "Now is the time for all good men";
	unsigned char cipher[sizeof(plain)];
	unsigned char iv[8];
	int i, j, n;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing BLF_BytesMode() with random keys and IV ...\n");
	for (i = 0; i < 10; i++)
	{
		/* Create some 'random' keys from 1 to 56 bytes long */
		n = (rand() % 56) + 1;
		for (j = 0; j < n; j++)
			key[j] = rand() & 0xFF;
		for (j = 0; j < 8; j++)
			iv[j] = rand() & 0xFF;
	
		/* Encrypt it into ciphertext in CBC mode */
		result = BLF_BytesMode(cipher, plain, sizeof(plain), key, n, 1,
			"CBC", iv);
		assert (result == 0);

		/* Now decipher (use same variable for result) */
		result = BLF_BytesMode(cipher, cipher, sizeof(cipher), key, n, 0,
			"CBC", iv);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, sizeof(plain)) == 0);
		printf("%d(%d) ", i+1, n);
	}
	printf("\n...BLF_BytesMode() tested OK\n");
}

void test_BLF_BytesMode_rmode(void)
/* Encrypt and decrypt random blocks and modes */
{
	unsigned char key[8] = { 
		0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10 };
	unsigned char iv[8] = { 
		0x01, 0x23, 0x45, 0x67, 0x89, 0xAB, 0xCD, 0xEF }; 
	unsigned char plain[512];
	unsigned char cipher[512];
	int i, j, n;
	long result;
	char *mode[] = { "ECB", "CBC", "CFB", "OFB" };
	int m;

	srand((unsigned)time(NULL));

	printf("Testing BLF_BytesMode() with random modes ...\n");
	for (i = 0; i < 10; i++)
	{
		/* Create some 'random' plaintext up to 512 bytes long */
		n = ((rand() & 0x2F) + 1) * 8; /* in multiple of 8 */
		assert (n <= 512);

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;

		/* And pick a random mode */
		m = rand() & 0x3;
	
		printf("%d-%s(%d) ", i+1, mode[m], n);

		/* Encrypt it into ciphertext */
		result = BLF_BytesMode(cipher, plain, n, key, 8, 1,
			mode[m], iv);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = BLF_BytesMode(cipher, cipher, n, key, 8, 0,
			mode[m], iv);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
	}
	printf("\n...BLF_BytesMode() tested OK\n");
}


void test_BLF_File(void)
{
	char sFileIn[]  = "test$.txt";
	char sFileOut[] = "test$.ecb";
	char sFileChk[] = "test$.chk";
	unsigned char key[8] = { 
		0xfe, 0xdc, 0xba, 0x98, 0x76, 0x54, 0x32, 0x10 };
	unsigned char correct[] = { 
		0x1a, 0xa1, 0x51, 0xb7, 0x7a, 0x5a, 0x33, 0x5c, 
		0x4e, 0x7e, 0xdc, 0x84, 0xa3, 0x86, 0xdc, 0x96 };
	long result;
	FILE *fp;
	char buf[128], *cp;
	int c, n;
	
	/* Create a test file in current dir */
	fp = fopen(sFileIn, "wb");
	assert(fp != NULL);
	fprintf(fp, "hello world\r\n");
	fclose(fp);

	printf("Testing BLF_File()...\n");

	/* Encrypt it and create output file */
	result = BLF_File(sFileOut, sFileIn, key, sizeof(key), 1, "ECB", NULL);
	assert (result == 0);

	/* Read this ciphertext file to a buffer and see if correct */
	fp = fopen(sFileOut, "rb");
	assert (fp != NULL);
	printf("Result =");
	for (n = 0, cp = buf; (c = fgetc(fp)) != EOF && n < sizeof(buf); n++)
	{
		*cp++ = c;
		printf("%02X", (unsigned char)c);
	}
	fclose(fp);
	printf("\n");

	printf("Correct=");
	pr_hexbytes(correct, sizeof(correct));

	assert (memcmp(buf, correct, n) == 0);

	/* Now decrypt back to plaintext */
	result = BLF_File(sFileChk, sFileOut, key, sizeof(key), 0, "ECB", NULL);
	assert (result == 0);

	/* and check we got the plaintext we started with */
	assert (cmp_files(sFileChk, sFileIn) == 0);

	/* Delete the test files */
	remove(sFileIn);
	remove(sFileOut);
	remove(sFileChk);

	printf("...BLF_File() tested OK\n");
}

void test_BLF_FileHex_CFB(void)
{
	char sFileIn[]  = "testf$.txt";
	char sFileOut[] = "testf$.cfb";
	char sFileChk[] = "testf$.chk";
	char key[] = "0123456789ABCDEFF0E1D2C3B4A59687";
	char iv[]  = "FEDCBA9876543210";
	unsigned char correct[] = { 
	/* E73214A2822139CAF26ECF6D2EB9E76E3DA3DE04D1517200519D57A6C3 */
		0xE7, 0x32, 0x14, 0xA2, 0x82, 0x21, 0x39, 0xCA,
		0xF2, 0x6E, 0xCF, 0x6D, 0x2E, 0xB9, 0xE7, 0x6E, 
		0x3D, 0xA3, 0xDE, 0x04, 0xD1, 0x51, 0x72, 0x00, 
		0x51, 0x9D, 0x57, 0xA6, 0xC3 };
	long result;
	FILE *fp;
	char buf[128], *cp;
	int c, n;
	
	/* Create a test file in current dir */
	fp = fopen(sFileIn, "wb");
	assert(fp != NULL);
	fprintf(fp, "7654321 Now is the time for ");
	fputc('\0', fp);
	fclose(fp);

	printf("Testing BLF_FileHex() in CFB mode...\n");

	/* Encrypt it and create output file */
	result = BLF_FileHex(sFileOut, sFileIn, key, 1, "CFB", iv);
	assert (result == 0);

	/* Read this ciphertext file to a buffer and see if correct */
	fp = fopen(sFileOut, "rb");
	assert (fp != NULL);
	printf("Result =");
	for (n = 0, cp = buf; (c = fgetc(fp)) != EOF && n < sizeof(buf); n++)
	{
		*cp++ = c;
		printf("%02X", (unsigned char)c);
	}
	fclose(fp);
	printf("\n");

	printf("Correct=");
	pr_hexbytes(correct, sizeof(correct));

	assert (memcmp(buf, correct, n) == 0);

	/* Now decrypt back to plaintext */
	result = BLF_FileHex(sFileChk, sFileOut, key, 0, "CFB", iv);
	assert (result == 0);

	/* and check we got the plaintext we started with */
	assert (cmp_files(sFileChk, sFileIn) == 0);

	/* Delete the test files */
	remove(sFileIn);
	remove(sFileOut);
	remove(sFileChk);

	printf("...BLF_FileHex() tested OK\n");
}

void test_ZLIB(void)
{
    char *testfn = "ZLIB_De/Inflate()";
	unsigned char *input = 
		"hello, hello, hello. This is a 'hello world' message "
        "for the world, repeat, for the world.";
	unsigned char *pcomp, *pcheck;
	long uncomp_len, comp_len, result;

	printf("Testing %s...\n", testfn);

	/* Find out compressed length of ascii input
	   NB don't use strlen for binary data */
	uncomp_len = strlen(input);
	printf("Input length = %ld bytes\n", uncomp_len);
	comp_len = ZLIB_Deflate(NULL, 0, input, uncomp_len);
	assert (comp_len > 0);
	printf("Compressed length = %ld bytes\n", comp_len);
	/* Alloc buffer storage */
	pcomp = (unsigned char*)malloc(comp_len);
	assert (pcomp != NULL);
	/* Do compression */
	result = ZLIB_Deflate(pcomp, comp_len, input, uncomp_len);
	assert (result > 0);

	/* Now uncompress and check */
	pcheck = (unsigned char*)malloc(uncomp_len);
	assert(pcheck != NULL);
	result = ZLIB_Inflate(pcheck, uncomp_len, pcomp, comp_len);
	assert (result > 0);
	printf("Inflated length = %ld\n", result);

	/* Do we have the same as we started with? */
	assert (memcmp(pcheck, input, uncomp_len) == 0);

	free(pcomp);
	free(pcheck);

	printf("...%s tested OK\n", testfn);
}

void test_RAN_KeyGenerate(void)
{
    char *testfn = "RAN_KeyGenerate()";
	long result;
	unsigned char keyArray[24];

	printf("Testing %s...\n", testfn);

	/* Generate random key with user prompt */
	result = RAN_KeyGenerate(keyArray, sizeof(keyArray), 1);
	assert (result == 0);

	pr_hexbytes(keyArray, sizeof(keyArray));

	printf("...%s tested OK\n", testfn);
}

void test_RNG_KeyGenHex(void)
{
    char *testfn = "RNG_KeyGenHex()";
	long keylen = 8;
	char hexstr[17]; /* NB = keylen * 2 + 1 */
	long result;
	long rng_check;
	char seedstr[6];
	int i;

	printf("Testing %s...\n", testfn);

	/* Generate 3 random keys using counter as a seed */

	for (i = 0; i < 3; i++)
	{
		sprintf(seedstr, "%d", i);
		result = RNG_KeyGenHex(hexstr, keylen, seedstr, &rng_check, 0);
		assert (result == 0);
		printf("%s\n", hexstr);
		printf("rng_check = %08x\n", rng_check);
	}

	printf("...%s tested OK\n", testfn);
}

void test_RNG_KeyGenerate(void)
{
    char *testfn = "RNG_KeyGenerate()";
	char key[8];
	long result;
	long rng_check;
	char seedstr[6];
	int i;

	printf("Testing %s...\n", testfn);

	/* Generate 3 random keys using counter as a seed */

	for (i = 0; i < 3; i++)
	{
		sprintf(seedstr, "%d", i);
		result = RNG_KeyGenerate(key, sizeof(key), seedstr, &rng_check, 0);
		assert (result == 0);
		pr_hexbytes(key, sizeof(key));
		printf("rng_check = %08x\n", rng_check);
	}

	printf("...%s tested OK\n", testfn);
}

void test_RNG_Nonce(void)
{
    char *testfn = "RNG_Nonce()";
	long result;
	unsigned char nonce[64];

	printf("Testing %s...\n", testfn);

	/* Generate nonce  */
	result = RNG_Nonce(nonce, sizeof(nonce), "");
	assert (result == 0);

	pr_hexbytes(nonce, sizeof(nonce)); 
	printf("...%s tested OK\n", testfn);
}

void test_RNG_Long(void)
{
    char *testfn = "RNG_Long()";
	long mylong;
	long mymin = 256;
	long mymax = 0x0fffffff;
	int i;

	printf("Testing %s...\n", testfn);

	/* Generate set of random longs */
	for (i = 0; i < 8; i++)
	{
		mylong = RNG_Long(mymin, mymax, "");
		printf("%08x ", mylong);
		assert (mylong > mymin || mylong > mymax);
	}
	printf("\n");

	printf("...%s tested OK\n", testfn);

}

void test_RNG_Test(void)
{
    char *testfn = "RNG_Test()";
	long result;
	char *filename = "RNGtest.txt";

	printf("Testing %s...\n", testfn);

	result = RNG_Test(filename);
	assert (result == 0);

	/* Now delete the file */
	remove(filename);

	printf("...%s tested OK\n", testfn);
}

void test_AES_Hex(void)
{
    char *testfn = "AES_Hex()";
    char sHexKey[] = "00000000000000000000000000000000";
    char sInput[] = "80000000000000000000000000000000";
    char sCorrect[] = "3AD78E726C1EC02B7EBFE92B23D9EC34";
    char sOutput[sizeof(sInput)+1];
	long lngRet;

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = AES_Hex(sOutput, sInput, sHexKey, 128L, 128L, ENCRYPT);
	assert (lngRet == 0);
	/* Check */
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sCorrect, sOutput) == 0);

    // Now decrypt back to plain text using same buffer
    lngRet = AES_Hex(sOutput, sOutput, sHexKey, 128L, 128L, DECRYPT);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sInput, sOutput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_AES_HexMode(void)
{
    char *testfn = "AES_HexMode()";
	long lngRet;
	char sHexKey[] = "0123456789ABCDEFF0E1D2C3B4A59687";
    char sHexIV[] = "FEDCBA9876543210FEDCBA9876543210";
    // "Now is the time for all good men"
    char sInput[] = "4E6F77206973207468652074696D6520666F7220616C6C20676F6F64206D656E";
    char sCorrect[] = "C3153108A8DD340C0BCB1DFE8D25D2320EE0E66BD2BB4A313FB75C5638E9E177";
    // Set sOutput to be same length as sInput
    char sOutput[sizeof(sInput)+1];

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("IV=%s\n", sHexIV);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = AES_HexMode(sOutput, sInput, sHexKey, 128L, 128L, ENCRYPT, "CBC", sHexIV);
	assert (lngRet == 0);
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sOutput, sCorrect) == 0);

    // Now decrypt back to plain text
    lngRet = AES_HexMode(sOutput, sOutput, sHexKey, 128L, 128L, DECRYPT, "cbc", sHexIV);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sOutput, sInput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_AES_HexMode_CBC128128(void)
{
    char *testfn = "AES_HexMode_CBC128128()";
	long lngRet;
    // NIST SP800-38a F.2.1 CBC-AES128.Encrypt
	char sHexKey[] = "2b7e151628aed2a6abf7158809cf4f3c";
    char sHexIV[] = "000102030405060708090a0b0c0d0e0f";
    char sInput[] = "6BC1BEE22E409F96E93D7E117393172A";
    char sCorrect[] = "7649ABAC8119B246CEE98E9B12E9197D";
    // Set sOutput to be same length as sInput
    char sOutput[sizeof(sInput)+1];

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("IV=%s\n", sHexIV);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = AES_HexMode(sOutput, sInput, sHexKey, 128L, 128L, ENCRYPT, "CBC", sHexIV);
	assert (lngRet == 0);
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sOutput, sCorrect) == 0);

    // Now decrypt back to plain text
    lngRet = AES_HexMode(sOutput, sOutput, sHexKey, 128L, 128L, DECRYPT, "cbc", sHexIV);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sOutput, sInput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_AES_HexMode_CBC192128(void)
{
    char *testfn = "AES_HexMode_CBC192128()";
	long lngRet;
    // NIST SP800-38a F.2.3 CBC-AES192.Encrypt
	char sHexKey[] = "8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b";
    char sHexIV[] = "000102030405060708090a0b0c0d0e0f";
    char sInput[] = "6BC1BEE22E409F96E93D7E117393172A";
    char sCorrect[] = "4F021DB243BC633D7178183A9FA071E8";
    // Set sOutput to be same length as sInput
    char sOutput[sizeof(sInput)+1];

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("IV=%s\n", sHexIV);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = AES_HexMode(sOutput, sInput, sHexKey, 192L, 128L, ENCRYPT, "CBC", sHexIV);
	assert (lngRet == 0);
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sOutput, sCorrect) == 0);

    // Now decrypt back to plain text
    lngRet = AES_HexMode(sOutput, sOutput, sHexKey, 192L, 128L, DECRYPT, "cbc", sHexIV);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sOutput, sInput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_AES_HexMode_CBC256128(void)
{
    char *testfn = "AES_HexMode_CBC256128()";
	long lngRet;
    // NIST SP800-38a F.2.5 CBC-AES256.Encrypt
	char sHexKey[] = 
		"603deb1015ca71be2b73aef0857d7781"
		"1f352c073b6108d72d9810a30914dff4";
    char sHexIV[] = "000102030405060708090a0b0c0d0e0f";
    char sInput[] = "6BC1BEE22E409F96E93D7E117393172A";
    char sCorrect[] = "F58C4C04D6E5F1BA779EABFB5F7BFBD6";
    // Set sOutput to be same length as sInput
    char sOutput[sizeof(sInput)+1];

	printf("Testing %s...\n", testfn);

    printf("KY=%s\n", sHexKey);
    printf("IV=%s\n", sHexIV);
    printf("PT=%s\n", sInput);

    // Encrypt in one-off process
    lngRet = AES_HexMode(sOutput, sInput, sHexKey, 256L, 128L, ENCRYPT, "CBC", sHexIV);
	assert (lngRet == 0);
    printf("CT=%s %d\n", sOutput, lngRet);
    printf("OK=%s\n", sCorrect);
	assert (strcmp(sOutput, sCorrect) == 0);

    // Now decrypt back to plain text
    lngRet = AES_HexMode(sOutput, sOutput, sHexKey, 256L, 128L, DECRYPT, "cbc", sHexIV);
	assert (lngRet == 0);
    printf("P'=%s %d\n", sOutput, lngRet);
	assert (strcmp(sOutput, sInput) == 0);

	printf("...%s tested OK\n", testfn);
}

void test_AES_FileHex(void)
{
    char *testfn = "AES_FileHex()";
    long lngRet;

    // Construct full path names to files
    char *strFileIn = "now.txt";
    char *strFileOut = "aesnow.enc";
    char *strFileChk = "aesnow.chk";

    char sHexKey[] = "0123456789ABCDEFF0E1D2C3B4A59687";
	char sCorrect[] = 
		"F0D1AD6F901FFFAE5572A6928DAB52B0"
		"64B25C79F876730321E36DC01011ACCE"
		"9C68DA6958A93ADFDECD9A1418D61EFD";

	printf("Testing %s...\n", testfn);

	create_nowis_file(strFileIn);

    // Encrypt plaintext file to cipher (with padding)
    // WARNING: output file is just clobbered
    lngRet = AES_FileHex(strFileOut, strFileIn, sHexKey, 
        128L, 128L, ENCRYPT, "ECB", 0);
    assert (lngRet == 0);

	// Check we got the correct ciphertext 
	assert (cmp_file_with_hex(strFileOut, sCorrect) == 0);

    // Now decrypt it
    lngRet = AES_FileHex(strFileChk, strFileOut, sHexKey, 
        128L, 128L, DECRYPT, "ECB", 0);
    assert (lngRet == 0);

	/* and check we got the plaintext we started with */
	assert (cmp_files(strFileChk, strFileIn) == 0);

	remove(strFileIn);
	remove(strFileOut);
	remove(strFileChk);

	printf("...%s tested OK\n", testfn);
}

void test_AES_Bytes_rand(void)
/* Encrypt and decrypt random blocks with random keys */
{
    char *testfn = "AES_Bytes_rand()";

	unsigned char key[32];
	unsigned char plain[1024];
	unsigned char cipher[1024];
	long keybits, blkbits;
	int i, j, n, m;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing AES_Bytes() with random blocks ...\n");
	for (i = 0; i < 10; i++)
	{
		/* Select a random key and block size: 128|192|256 */
		keybits = ((rand() % 3) + 2) * 64;
		blkbits = ((rand() % 3) + 2) * 64;

		/* Create a random key */
		for (j = 0; j < keybits / 8; j++)
			key[j] = rand() & 0xFF;

		/* Create some 'random' plaintext up to 1024 bytes long */
		/* in a multiple of block size */
		m = 1024 * 8 / blkbits;
		n = ((rand() % m) + 1) * blkbits / 8; 
		assert (n <= sizeof(plain));

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;
	
		/* Encrypt it into ciphertext */
		result = AES_Bytes(cipher, plain, n, key, keybits, blkbits, ENCRYPT);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = AES_Bytes(cipher, cipher, n, key, keybits, blkbits, DECRYPT);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
		printf("%d(%d) ", i+1, n);
	}

	printf("...%s tested OK\n", testfn);
}

void test_AES_BytesMode_rand(void)
/* Encrypt and decrypt random blocks with random keys
   and random modes */
{
    char *testfn = "AES_BytesMode_rand()";

	unsigned char key[32];
	unsigned char plain[1024];
	unsigned char cipher[1024];
	long keybits, blkbits;
	unsigned char iv[32];
	char *modes[] = { "ECB", "CBC" };
	int i, j, n, m, im;
	long result;

	srand((unsigned)time(NULL));

	printf("Testing AES_BytesMode() with random blocks and modes...\n");
	for (i = 0; i < 10; i++)
	{
		/* Select a random key and block size: 128|192|256 */
		keybits = ((rand() % 3) + 2) * 64;
		blkbits = ((rand() % 3) + 2) * 64;

		/* Create a random key */
		for (j = 0; j < keybits / 8; j++)
			key[j] = rand() & 0xFF;

		/* and a random IV */
		for (j = 0; j < blkbits / 8; j++)
			iv[j] = rand() & 0xFF;

		/* Select a mode index: 0 or 1 */
		im = rand() & 0x01;

		/* Create some 'random' plaintext up to 1024 bytes long */
		/* in a multiple of block size */
		m = 1024 * 8 / blkbits;
		n = ((rand() % m) + 1) * blkbits / 8; 
		assert (n <= sizeof(plain));

		for (j = 0; j < n; j++)
			plain[j] = rand() & 0xFF;
	
		/* Encrypt it into ciphertext */
		result = AES_BytesMode(cipher, plain, n, key, keybits, blkbits, ENCRYPT, modes[im], iv);
		assert (result == 0);

		/* Now decipher (use same variable) */
		result = AES_BytesMode(cipher, cipher, n, key, keybits, blkbits, DECRYPT, modes[im], iv);
		assert (result == 0);

		/* Check identical */
		assert (memcmp(plain, cipher, n) == 0);
		printf("%d(%d)%s ", i+1, n, modes[im]);
	}

	printf("...%s tested OK\n", testfn);
}


void test_AES_InitError(void)
{
	unsigned char key[24], iv[8];
	char badhex[] = "THIS IS NOT HEX!";
	long hContext;
	long errcode;
	
	printf("Testing AES_InitError() ...\n");

	/* Call with a bad key */
	hContext = AES_Init(NULL, 128L, 128L, ENCRYPT, "CBC", iv);
	assert (hContext == 0);
	errcode = AES_InitError();
	printf("AES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad iv */
	hContext = AES_Init(key, 128L, 128L, ENCRYPT, "CBC", NULL);
	assert (hContext == 0);
	errcode = AES_InitError();
	printf("AES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex key */
	hContext = AES_InitHex(badhex, 128L, 128L, ENCRYPT, "CBC", "FEDCBA9876543210");
	assert (hContext == 0);
	errcode = AES_InitError();
	printf("AES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad hex iv */
	hContext = AES_InitHex("FEDCBA9876543210", 128L, 128L, ENCRYPT, "CBC", badhex);
	assert (hContext == 0);
	errcode = AES_InitError();
	printf("AES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	/* Call with a bad mode */
	hContext = AES_InitHex("FEDCBA9876543210", 128L, 128L, ENCRYPT, "XXX", "0123456789ABDCDEF");
	assert (hContext == 0);
	errcode = AES_InitError();
	printf("AES_InitError returns %d\n", errcode);
	assert (errcode != 0);

	printf("...AES_InitError tested OK\n");
}




int main()
{
	/* Test DES */
	test_DES_Hex();
	test_DES_HexMode();
	test_DES_UpdateHex();
	test_DES_FileHex();
	test_DES_Bytes_rand();
	test_DES_InitError();

	/* Test AES */
	test_AES_Hex();
	test_AES_HexMode();
	test_AES_FileHex();
	test_AES_InitError();
	test_AES_HexMode_CBC128128();
	test_AES_HexMode_CBC192128();
	test_AES_HexMode_CBC256128();
	test_AES_Bytes_rand();
	test_AES_BytesMode_rand();

	/* Test TDEA */
	test_TDEA_Hex();
	test_TDEA_FileHex();
	test_TDEA_Bytes_rand();
	test_TDEA_BytesMode_rand();
	test_TDEA_Hex_Monte();
	test_TDEA_InitError();

	/* Test the Blowfish functions */
	test_BLF_Hex();
	test_BLF_UpdateHex();
	test_BLF_Ecb();
	test_BLF_File();
	test_BLF_FileHex_CFB();
	test_BLF_Bytes_rand();
	test_BLF_BytesMode_rkeys();
	test_BLF_BytesMode_rmode();
	test_BLF_InitError();

	/* Test the ZLIB compression functions */
	test_ZLIB();
	
	/* Test the random number generators */
	test_RNG_KeyGenHex();
	test_RNG_KeyGenerate();
	test_RNG_Nonce();
	test_RNG_Test();
	test_RNG_Long();
	/* and the older-style "Gutmann" generator */
	test_RAN_KeyGenerate();

	/* Do all hash digest tests */
	Test_SHA1_StringHexHash();
	Test_SHA2_StringHexHash();
	Test_SHA1_BytesHexHash();
	Test_SHA2_BytesHexHash();
	Test_SHA1_HexDigest();
	Test_SHA2_HexDigest();
	Test_SHA1_AddString();
	Test_SHA2_AddString();
	Test_SHA1_Hmac();
	Test_SHA2_Hmac();
	Test_SHA1_FileHexHash();
	Test_SHA2_FileHexHash();


	return 0;
}


