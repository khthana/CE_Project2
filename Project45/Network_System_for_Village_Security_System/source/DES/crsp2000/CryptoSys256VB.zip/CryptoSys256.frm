VERSION 5.00
Begin VB.Form frmCryptoSys256 
   Caption         =   "CryptoSys 256 Testbed Demo 1.01"
   ClientHeight    =   7110
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   8550
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   7110
   ScaleWidth      =   8550
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Frame1 
      Caption         =   "Padding"
      Height          =   540
      Left            =   5400
      TabIndex        =   34
      Top             =   2250
      Width           =   2940
      Begin VB.OptionButton Option2 
         Caption         =   "None"
         Height          =   240
         Left            =   1425
         TabIndex        =   36
         Top             =   225
         Width           =   1140
      End
      Begin VB.OptionButton optPad 
         Caption         =   "RFC 2560"
         Height          =   240
         Left            =   150
         TabIndex        =   35
         Top             =   225
         Value           =   -1  'True
         Width           =   1140
      End
   End
   Begin VB.TextBox txtHmac 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   315
      Left            =   1275
      TabIndex        =   31
      Top             =   6300
      Width           =   7065
   End
   Begin VB.TextBox txtSHA256 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   315
      Left            =   1275
      TabIndex        =   29
      Top             =   5925
      Width           =   7065
   End
   Begin VB.TextBox txtDecrypt 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   315
      Left            =   1050
      TabIndex        =   28
      Top             =   4800
      Width           =   7320
   End
   Begin VB.TextBox txtPlainAsHex 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   315
      Left            =   1050
      TabIndex        =   26
      Top             =   2925
      Width           =   7320
   End
   Begin VB.TextBox txtDecryptHex 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1050
      TabIndex        =   25
      Top             =   5175
      Width           =   7320
   End
   Begin VB.Frame Frame4 
      Caption         =   "Plain text format"
      Height          =   540
      Left            =   3075
      TabIndex        =   21
      Top             =   2250
      Width           =   2040
      Begin VB.OptionButton optPTHex 
         Caption         =   "Hex"
         Height          =   240
         Left            =   1200
         TabIndex        =   23
         Top             =   225
         Width           =   615
      End
      Begin VB.OptionButton optPTAlpha 
         Caption         =   "Alpha"
         Height          =   240
         Left            =   150
         TabIndex        =   22
         Top             =   225
         Value           =   -1  'True
         Width           =   840
      End
   End
   Begin VB.TextBox txtCipher64 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1050
      Locked          =   -1  'True
      TabIndex        =   18
      Top             =   4050
      Width           =   7320
   End
   Begin VB.Frame grpKeyForm 
      Caption         =   "Key &format:"
      Height          =   540
      Left            =   3600
      TabIndex        =   15
      Top             =   900
      Width           =   3405
      Begin VB.OptionButton optAlphaKey 
         Caption         =   "Alpha"
         Height          =   255
         Left            =   1350
         TabIndex        =   17
         Top             =   225
         Width           =   960
      End
      Begin VB.OptionButton optHexKey 
         Caption         =   "Hex string"
         Height          =   255
         Left            =   150
         TabIndex        =   16
         Top             =   225
         Value           =   -1  'True
         Width           =   1065
      End
   End
   Begin VB.TextBox txtCipherHex 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1050
      Locked          =   -1  'True
      TabIndex        =   14
      Top             =   3675
      Width           =   7320
   End
   Begin VB.TextBox txtCipher 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1050
      TabIndex        =   5
      Top             =   3300
      Width           =   7320
   End
   Begin VB.CommandButton cmdDecrypt 
      Caption         =   "&Decrypt cipher text"
      Enabled         =   0   'False
      Height          =   345
      Left            =   1050
      TabIndex        =   10
      Top             =   4425
      Width           =   1695
   End
   Begin VB.TextBox txtKeyAsString 
      Appearance      =   0  'Flat
      BackColor       =   &H80000004&
      Height          =   300
      Left            =   1050
      Locked          =   -1  'True
      TabIndex        =   8
      Top             =   1575
      Width           =   7320
   End
   Begin VB.CommandButton cmdSetKey 
      Caption         =   "&Set Key"
      Height          =   465
      Left            =   1125
      TabIndex        =   7
      Top             =   975
      Width           =   1290
   End
   Begin VB.CommandButton cmdEncrypt 
      Caption         =   "&Encrypt plain text"
      Enabled         =   0   'False
      Height          =   450
      Left            =   1125
      TabIndex        =   6
      Top             =   2325
      Width           =   1695
   End
   Begin VB.TextBox txtKey 
      Height          =   300
      Left            =   1050
      TabIndex        =   1
      Top             =   525
      Width           =   7320
   End
   Begin VB.TextBox txtPlain 
      Height          =   300
      Left            =   1050
      TabIndex        =   3
      Top             =   1920
      Width           =   7320
   End
   Begin VB.Label Label13 
      Caption         =   "Hash results"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   75
      TabIndex        =   33
      Top             =   5625
      Width           =   1590
   End
   Begin VB.Label Label9 
      Caption         =   "HMAC (PT, K)"
      Height          =   240
      Left            =   75
      TabIndex        =   32
      Top             =   6300
      Width           =   1140
   End
   Begin VB.Label Label8 
      Caption         =   "SHA-256 (PT)"
      Height          =   240
      Left            =   75
      TabIndex        =   30
      Top             =   5925
      Width           =   1215
   End
   Begin VB.Label Label12 
      Caption         =   "PT input:"
      Height          =   240
      Left            =   75
      TabIndex        =   27
      Top             =   3000
      Width           =   840
   End
   Begin VB.Label Label11 
      Caption         =   "Demonstration of 256-bit CryptoSys API functions: AES and SHA-256"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00800000&
      Height          =   240
      Left            =   75
      TabIndex        =   24
      Top             =   150
      Width           =   7740
   End
   Begin VB.Label Label10 
      Caption         =   "(In hex):"
      Height          =   240
      Left            =   75
      TabIndex        =   20
      Top             =   5175
      Width           =   840
   End
   Begin VB.Label Label7 
      Caption         =   "(Radix64):"
      Height          =   375
      Left            =   90
      TabIndex        =   19
      Top             =   4005
      Width           =   855
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      Caption         =   "Copyright (C) 2001-3 DI Management Services Pty Ltd <www.di-mgt.com.au>. All rights reserved."
      ForeColor       =   &H00800000&
      Height          =   225
      Left            =   225
      TabIndex        =   13
      Top             =   6840
      Width           =   7380
   End
   Begin VB.Label Label2 
      Caption         =   "(In hex):"
      Height          =   255
      Index           =   1
      Left            =   90
      TabIndex        =   12
      Top             =   3675
      Width           =   975
   End
   Begin VB.Label Label5 
      Caption         =   "Deciphered:"
      Height          =   255
      Left            =   75
      TabIndex        =   11
      Top             =   4830
      Width           =   975
   End
   Begin VB.Label Label4 
      Caption         =   "Active key:"
      Height          =   255
      Left            =   150
      TabIndex        =   9
      Top             =   1575
      Width           =   855
   End
   Begin VB.Label Label3 
      Caption         =   "Enter &Key:"
      Height          =   255
      Left            =   135
      TabIndex        =   0
      Top             =   525
      Width           =   855
   End
   Begin VB.Label Label2 
      Caption         =   "&Cipher text:"
      Height          =   255
      Index           =   0
      Left            =   90
      TabIndex        =   4
      Top             =   3300
      Width           =   975
   End
   Begin VB.Label Label1 
      Caption         =   "&Plain text:"
      Height          =   255
      Left            =   165
      TabIndex        =   2
      Top             =   1920
      Width           =   750
   End
End
Attribute VB_Name = "frmCryptoSys256"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Option Base 0

' frmCryptoSys256.frm
' Example to demonstrate some
' of the functions in the CryptoSys (TM) API.

' This is just a test-bed demo. It is not meant to be
' represesentative of good security code practices.
' There are no error handling facilities, either.

' Version 1.1. Published February 2003.
'************************* COPYRIGHT NOTICE*************************
' Copyright (c) 2001 DI Management Services Pty Limited.
' All rights reserved.
' Commercial use is prohibited without a valid licence.
' For a licence contact <sales@di-mgt.com.au>.
'  This code may only be used as part of an application. It may
' not be reproduced or distributed separately by any means without
' the express written permission of the author.
'  David Ireland and DI Management Services Pty Limited make no
' representations concerning either the merchantability of this
' software or the suitability of this software for any particular
' purpose. It is provided "as is" without express or implied
' warranty of any kind.
'  Report errors or make suggestions for improvement to
' <code@di-mgt.com.au>.
' The latest version of CryptoSys(TM) for personal use may be
' downloaded from <www.di-mgt.com.au/crypto.html>.
'  This copyright notice must always be left intact.
'****************** END OF COPYRIGHT NOTICE*************************

Dim msHexKey As String
Dim msPlainHex As String
Dim msCipher As String
Dim msDecrypt As String

Private Sub cmdDecrypt_Click()
    Dim lngRet As Long
    Dim nblocklen As Long
    
    nblocklen = 32
    
    ' Assume cipher text is OK; just do it
    msCipher = Me.txtCipherHex
    msDecrypt = String(Len(msCipher), " ")
    
    ' Now decrypt as per algorithm
    lngRet = AES_Hex(msDecrypt, msCipher, msHexKey, 256&, 256&, False)
    
    ' Check whether OK
    If lngRet <> 0 Then
        MsgBox "CryptoSys error " & lngRet & " has occurred"
        Exit Sub
    End If
    
    ' Strip padding if nec
    ' Fixed error
    If Me.optPad Then
        ' Fixed to make this UNpad instead of pad
        ' Thanks to Maxwell D. Moon for pointing this out.
        msDecrypt = bu_UnpadHexString(msDecrypt, 32)
    End If
    
    ' Display output
    Me.txtDecryptHex = msDecrypt
    Me.txtDecrypt = bu_Hex2Str(msDecrypt)
    
End Sub

Private Sub cmdEncrypt_Click()
' Encrypt the plain text as required using hex strings
    Dim lngRet As Long
    Dim nBlkLen As Long
    
    ' Make sure key and IV are set
    Call SetKey
    
    ' Convert plain text into hex if nec
    If Me.optPTAlpha Then
        msPlainHex = bu_Str2Hex(Me.txtPlain)
    Else
        If Not bu_IsValidHex(Me.txtPlain) Then
            MsgBox "Invalid hex in plain text"
            GoTo Done
        End If
        msPlainHex = Me.txtPlain
    End If
    
    ' Then pad input if required
    nBlkLen = 32
    If Me.optPad Then
        msPlainHex = bu_PadHexString(msPlainHex, nBlkLen)
    ElseIf Len(msPlainHex) / 2 < nBlkLen Then
        MsgBox "Plain text is too short to encrypt without padding"
        GoTo Done
    End If
    
    ' Show input data as hex
    Me.txtPlainAsHex = msPlainHex
    
    ' Set up output string to required length
    msCipher = String(Len(msPlainHex), " ")
    
    ' Now encrypt as per algorithm
    lngRet = AES_Hex(msCipher, msPlainHex, msHexKey, 256&, 256&, True)
    
    If lngRet <> 0 Then
        MsgBox "CryptoSys error " & lngRet & " has occurred"
        Exit Sub
    End If

    ' Display results
    Me.txtCipherHex = msCipher
    Me.txtCipher = bu_Hex2Str(msCipher)
    Me.txtCipher64 = EncodeStr64(bu_Hex2Str(msCipher))
    Me.cmdDecrypt.Enabled = True
    
    ' Now create hash and keyed HMAC of plain text, too
    Call HashIt

Done:

End Sub


Private Sub cmdSetKey_Click()
    Call SetKey
End Sub
    
Private Sub SetKey()
' Set key as a hex string
    Dim nHexKeyLen As Long
    Dim nPad As Long

    ' What format is the key in?
    If Me.optHexKey Then
        If bu_IsValidHex(Me.txtKey) Then
            msHexKey = Me.txtKey
        Else
            MsgBox "Key is not valid hex"
            Me.txtKey.SetFocus
            GoTo Done
        End If
    Else
        ' User has provided a plain alpha string
        msHexKey = bu_Str2Hex(Me.txtKey)
    End If
    
    ' Now pad key with zeroes as per algorithm
    nHexKeyLen = 64     'NB 2x length in bytes
    nPad = nHexKeyLen - Len(msHexKey)
    If nPad > 0 Then
        msHexKey = msHexKey & String(nPad, "0")
    ElseIf nPad < 0 Then
        msHexKey = Left(msHexKey, nHexKeyLen)
    End If
    
    ' Show key
    Me.txtKeyAsString = msHexKey
    ' Allow encrypt
    Me.cmdEncrypt.Enabled = True
    ' Put user in plaintext box
    Me.txtPlain.SetFocus
    
Done:

End Sub

Private Sub HashIt()
    Dim aMessage() As Byte
    Dim aKey() As Byte
    Dim lngDataLen As Long
    Dim lngKeyLen As Long
    Dim iRet As Long
    Dim sDigest As String
    
    
    ' We will use the Byte versions here
    
    ' What format is the data in?
    If Me.optPTAlpha Then
        ' Data is in plain ascii
        lngDataLen = Len(Me.txtPlain)
        ReDim aMessage(lngDataLen)
        Call bu_String2Bytes(Me.txtPlain, aMessage)
    Else
        ' Data is in hex
        lngDataLen = Len(Me.txtPlain) \ 2
        ReDim aMessage(lngDataLen)
        Call bu_HexStr2Bytes(Me.txtPlain, aMessage)
    End If
    
    ' Set sDigest to be 64 chars and make it
    sDigest = String(64, " ")
    
    iRet = SHA2_BytesHexHash(sDigest, aMessage(0), lngDataLen)
    
    Me.txtSHA256 = sDigest
    
    ' Now do the HMAC. For that we need the key in byte format.
    If Me.optAlphaKey Then
        ' Key is in plain ascii
        lngKeyLen = Len(Me.txtKey)
        ReDim aKey(lngKeyLen)
        Call bu_String2Bytes(Me.txtKey, aKey)
    Else
        ' key is in hex
        lngKeyLen = Len(Me.txtKeyAsString) \ 2
        ReDim aKey(lngKeyLen)
        Call bu_HexStr2Bytes(Me.txtKeyAsString, aKey)
    End If
    
    ' Debug to check key
    'Me.txtHmac = bu_Bytes2HexStr(aKey(), lngKeyLen)
    
    ' Create the keyed hash
    iRet = SHA2_Hmac(sDigest, aMessage(0), lngDataLen, aKey(0), lngKeyLen)
    
    Me.txtHmac = sDigest
    
End Sub

'***************************************************
' REVISION HISTORY
' Version 1.1. February 2003. Fixed Pad/Unpad bug in cmdDecrypt. Thanks
' to Maxwell D. Moon for pointing this out.
' Version 1. First published September 2001.
'***************************************************



