<?php
	include("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Sql_job_day");
	
	function Sql_job_day($user_id, $tmp_date2){
		
		include("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select sch_time, sch_title, sch_id from schedule where mem_id = '$user_id' and sch_date = '$tmp_date2'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result = array("sch_time" => $row[0], "sch_title" => $row[1], "sch_id" => $row[2], "numrow" => $count);
		return $result;
	}
	
	$s->service($HTTP_RAW_POST_DATA);
?>