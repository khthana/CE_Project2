<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	//$s->register("Sqlinsert");

	/*
	function Sqlinsert($user_id, $schdate2, $schtime2, $title, $note, $duration, $remind_before, $remind_before_hour, $remind_mail2){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "insert into schedule (mem_id, sch_date, sch_time, sch_title, sch_note, sch_duration, sch_remind_before, sch_remind_before_hour, sch_remind_mail, sch_sendmail) values ('$user_id', '$schdate2', '$schtime2', '$title', '$note', '$duration', '$remind_before', '$remind_before_hour', '$remind_mail2', 'N')";
		mysql_query($query);
		mysql_close($handle);
		return 0;
	}

	$user_id, $schdate2, $schtime2, $title, $note, $duration, $remind_before, $remind_before_hour, $remind_mail2
	*/

	$s->register("Sqlinsert"); 

	function Sqlinsert($user_id, $schdate2, $schtime2, $title, $note, $duration, $remind_before, $remind_before_hour, $remind_mail2){
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "insert into schedule (mem_id, sch_date, sch_time, sch_title, sch_note, sch_duration, sch_remind_before, sch_remind_before_hour, sch_remind_mail, sch_sendmail) values ('$user_id', '$schdate2', '$schtime2', '$title', '$note', '$duration', '$remind_before', '$remind_before_hour', '$remind_mail2', 'N')";
		mysql_query($query);
		mysql_close($handle);
		return 0;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>