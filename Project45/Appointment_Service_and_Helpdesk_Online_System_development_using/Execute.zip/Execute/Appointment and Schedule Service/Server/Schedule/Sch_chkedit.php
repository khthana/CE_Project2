<?php
	include("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Sqlupdate");
	
	function Sqlupdate($schdate2, $title, $note, $duration, $remind_before, $remind_before_hour, $tmp_remind_mail, $sch_id){
		
		include("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "update schedule set sch_date = '$schdate2', sch_title='$title', sch_note = '$note', sch_duration = '$duration', sch_remind_before = '$remind_before', sch_remind_before_hour = '$remind_before_hour', sch_remind_mail = '$tmp_remind_mail' where sch_id = '$sch_id'";
		mysql_query($query);
		
		return 0;
	}
$s->service($HTTP_RAW_POST_DATA);
?>