<?php
	include("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("NumMesg");
	$s->register("NewMesg"); 

	function NumMesg($user_id){
		
		include("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select count(*) from message_receiver where friend_id = '$user_id'";
		$result = mysql_query($query);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result1 = array("num_of_msg" => $row[0]);
		return $result1;
	}

	function NewMesg($user_id){
		
		include("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select count(*) from message_receiver where friend_id = '$user_id' && msr_status = 'new'";
		$result = mysql_query($query);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result2 = array("new_msg" => $row[0]);
		return $result2;
	}

$s->service($HTTP_RAW_POST_DATA);
?>