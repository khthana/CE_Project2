<?php
	include("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Sql_sch");
	
	function Sql_sch($user_id, $tmp_date, $tmptime){
		
		include("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select sch_duration, sch_time, sch_title, sch_id from schedule where mem_id = '$user_id' and sch_date = '$tmpdate' and sch_time = '$tmptime' order by sch_duration desc";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result = array("sch_duration" => $row[0], "sch_time" => $row[1], "sch_title" => $row[2], "sch_id" => $row[3], "numrow" => $count);
		return $result;
	}
	
	$s->service($HTTP_RAW_POST_DATA);
?>