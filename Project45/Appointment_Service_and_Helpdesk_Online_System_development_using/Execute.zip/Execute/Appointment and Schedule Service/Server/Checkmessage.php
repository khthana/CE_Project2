<?php
	require("Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Num_of_msg");
	$s->register("New_msg");
	
	function Num_of_msg($user_id){
		
		require("Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select count(*) from message_receiver  where friend_id = '$user_id' ";
		$result1 = mysql_query($query);
		$count = mysql_num_rows($result1);
		$row = mysql_fetch_array($result1);
		mysql_close($handle);
		$result1 = array("num_of_msg" => $row[0]);
		return $result1;
	}
	
	function New_msg($user_id){
		
		require("Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select count(*) from message_receiver  where friend_id = '$user_id' && msr_status = 'new' ";
		$result2 = mysql_query($query);
		$count = mysql_num_rows($result2);
		$row = mysql_fetch_array($result2);
		mysql_close($handle);
		$result2 = array("new_msg" => $row[0]);
		return $result2;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>