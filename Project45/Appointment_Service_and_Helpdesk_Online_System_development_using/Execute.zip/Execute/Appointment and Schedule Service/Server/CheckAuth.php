<?php
	require("Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("CheckAuth");

	function CheckAuth($user_id){
		
		require("Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select mem_id, mem_username, mem_password from member where mem_id = '$user_id' ";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result = array("mem_id" => $row->mem_id, "mem_username" => $row->mem_username, "mem_password" => $row->mem_password, "numrow" => $count);
		return $result;
	}
	
	$s->service($HTTP_RAW_POST_DATA);
?>