<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("App_add");
	
	function App_add($user_id, $appdate2, $apptime2, $app_title, $app_note, $app_duration, $app_remind_before, $app_remind_before_hour, $tmp_remind_mail){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "insert into appointment (mem_id, app_date, app_time, app_title, app_note, app_duration, app_remind_before, app_remind_before_hour, app_remind_mail) values ('$user_id', '$appdate2', '$apptime2', '$app_title', '$app_note', '$app_duration', '$app_remind_before', '$app_remind_before_hour', '$tmp_remind_mail')";
		mysql_query($query);
		
		return 0;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>