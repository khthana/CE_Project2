<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Select_app");
	$s->register("Select_sender");

	function Select_app($user_id){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select a1.app_id, app_time, app_date, app_title, a1.mem_id from appointment a1, appoint_receiver a2  where a1.app_id = a2.app_id and friend_id = $user_id and apr_status = 'NE' order by app_date, app_time";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		$result1 = array("app_id" => $row[0], "app_time" => $row[1], "app_date" => $row[2], "app_title" => $row[3], "mem_id" => $row[4], "numrow" => $count);
		return $result1;
	}

	function Select_sender($sender_id){

		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select mem_username, mem_fname from member where mem_id = '$sender_id' ";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		$result2 = array("mem_username" => $row[0], "mem_fname" => $row[1]);
		return $result2;
	}
	
	$s->service($HTTP_RAW_POST_DATA);
?>