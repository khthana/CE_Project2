<?php
	//require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Sql_app2");
	$s->register("Sql_friendname");

	function Sql_app2($user_id){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select a1.app_id, friend_id, app_time, app_date, app_title, apr_status from appointment a1, appoint_receiver a2 where a1.app_id = a2.app_id and mem_id = $user_id and (apr_status = 'AC' or apr_status = 'UN') order by app_date, app_time";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result1 = array("app_id" => $row[0], "friend_id" => $row[1], "app_time" => $row[2], "app_date" => $row[3], "app_title" => $row[4], "apr_status" => $row[5], "numrow" => $count);
		return $result1;
	}

	function Sql_friendname($friend_id){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select mem_username, mem_fname from member where mem_id = $friend_id";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result2 = array("mem_username" => $row["mem_username"]);
		return $result2;
	}
	
	$s->service($HTTP_RAW_POST_DATA);
?>