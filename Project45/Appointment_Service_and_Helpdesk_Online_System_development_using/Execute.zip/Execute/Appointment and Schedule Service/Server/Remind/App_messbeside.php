	<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Sql_app");
	$s->register("Sql_sender");
	
	function Sql_app($user_id){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		//$query = "select app_id, app_time, app_date, app_title, mem_id from appointment"; 
		$query = "select a1.app_id, app_time, app_date, app_title, mem_id from appointment a1, appoint_receiver a2 where a1.app_id = a2.app_id and friend_id = $user_id and app_status = 'NE' order by app_date, app_time";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result1 = array("app_id" => $row[0], "app_time" => $row[1], "app_date" => $row[2], "app_title" => $row[3], "mem_id" => $row[4], "numrow" => $count);
		return $result1;
	}

	function Sql_sender($sender_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_id = '$sender_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result2 = array("mem_username" => $row->mem_username);
		return $result2;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>