<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Sql_sch");
	$s->register("Sql_bd");
	
	function Sql_sch($user_id, $tmpdate2){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from schedule where mem_id = '$user_id' and sch_date >= '$tmpdate2' order by sch_date, sch_time";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result1 = array("sch_id" => $row->sch_id, "sch_date" => $row->sch_date, "sch_time" => $row->sch_time, "sch_duration" => $row->sch_duration, "sch_remind_before" => $row->sch_remind_before, "sch_remind_before_hour" => $row->sch_remind_before_hour, "numrow"=>$count, );
		return $result1;
	}

	function Sql_bd($user_id){
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select m1.mem_username, m1.mem_fname, m1.mem_birthday from member m1, contact c1 where c1.friend_id = m1.mem_id and c1.mem_id = $user_id order by m1.mem_username";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result2 = array("mem_username" => $row[0], "mem_fname" => $row[1], "mem_birthday" => $row[2], "numrowbd" => $count);
		return $result2;
	} 
	
	$s->service($HTTP_RAW_POST_DATA);
?>