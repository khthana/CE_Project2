<?php
	$host = "localhost";
	$uname = "";
	$passwd = "";
	$dbname = "WebCalendar";
?>