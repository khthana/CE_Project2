<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Dologin");
	
	function Dologin($username){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_username='$username'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result = array("mem_id" => $row->mem_id, "mem_password" => $row->mem_password, "count" => $count);
		return $result;
	}
	$s->service($HTTP_RAW_POST_DATA);
?>