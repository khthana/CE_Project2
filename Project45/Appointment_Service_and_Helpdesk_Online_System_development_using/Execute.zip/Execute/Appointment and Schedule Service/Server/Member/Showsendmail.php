<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("ShowSendMail");
	
	function ShowSendMail($user_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		
		$query = "select * from member where mem_id='$user_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result = array("mem_fname" => $row->mem_fname, "mem_lname" => $row->mem_lname);
		return $result;
	}
	
	$s->service($HTTP_RAW_POST_DATA);
?>