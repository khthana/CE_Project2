<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("ChkPasswd");
	
	function ChkPasswd($user){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_username='$user'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		mysql_close($handle);
		$result = array("count" => $count);
		return $result;
	}
	$s->service($HTTP_RAW_POST_DATA);
?>