<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Editdetail");
	

	function Editdetail($user_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select mem_username, mem_password, mem_fname, mem_lname, mem_nickname, mem_address, mem_zipcode, mem_birthday, mem_email, mem_icq, mem_tel, mem_gender, mem_show_status from member where mem_id = '$user_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result = array("mem_username" => $row->mem_username, "mem_password" => $row->mem_password, "mem_fname" => $row->mem_fname, "mem_lname" =>  $row->mem_lname, "mem_nickname" => $row->mem_nickname, "mem_address" => $row->mem_address, "mem_zipcode" => $row->mem_zipcode, "mem_birthday" => $row->mem_birthday, "mem_email" => $row->mem_email, "mem_icq" => $row->mem_icq, "mem_tel" => $row->mem_tel, "mem_gender" => $row->mem_gender, "mem_show_status" => $row->mem_show_status);
		return $result;
	}
	$s->service($HTTP_RAW_POST_DATA);
?>