<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("ChkDetail");
	$s->register("SelectMem");
	$s->register("InsertGroup");
	
	function ChkDetail($query){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		mysql_query($query);
		mysql_close($handle);
		return 0;
	}
	
	function SelectMem($user){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_username='$user'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result = array("mem_id" => $row->mem_id);
		return $result;
	}

	function InsertGroup($grp_id, $mem_id, $grp_name){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "insert into group_name (grp_id, mem_id, grp_name) values ('$grp_id', '$mem_id', '$grp_name')";
		mysql_query($query);
		mysql_close($handle);
		return 0;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>