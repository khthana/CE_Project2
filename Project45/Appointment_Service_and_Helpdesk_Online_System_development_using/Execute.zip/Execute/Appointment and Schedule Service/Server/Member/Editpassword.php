<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("ChkPasswd");
	$s->register("EditPasswd");
		
	function ChkPasswd($user_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_id = '$user_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result1 = array("mem_username" => $row->mem_username, "mem_password" => $row->mem_password);
		return $result1;
	}

	function EditPasswd($newpass1, $username){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "update member set mem_password = '$newpass1' where mem_username = '$username'";
		mysql_query($query);
		return 0;
	}

		$s->service($HTTP_RAW_POST_DATA);
?>