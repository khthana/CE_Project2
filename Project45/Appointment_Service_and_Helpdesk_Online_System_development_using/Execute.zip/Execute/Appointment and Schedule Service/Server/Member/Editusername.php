<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("ChkNewUname");
	$s->register("ChkAccount");
	$s->register("EditUname");
	
	function ChkNewUname($newname){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select count(*) from member where mem_username = '$newname'";
		$result = mysql_query($query);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result1 = array("count" => $row[0]);
		return $result1;
	}

	function ChkAccount($user_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_id = '$user_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result2 = array("mem_password" => $row->mem_password);
		return $result2;
	}

	function EditUname($newname, $user_id){
	
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "update member set mem_username = '$newname' where mem_id = '$user_id'";
		mysql_query($query);
		return 0;
	}

$s->service($HTTP_RAW_POST_DATA);
?>