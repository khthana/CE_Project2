<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Updatedetail");

	function Updatedetail($new_fname, $new_lname, $new_nickname, $new_address, $new_zipcode, $new_birthday, $new_email, $new_icq, $new_tel, $new_gender, $new_showstatus, $user_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "update member set mem_fname = '$new_fname', mem_lname = '$new_lname', mem_nickname = '$new_nickname', mem_address = '$new_address', mem_zipcode = '$new_zipcode', mem_birthday = '$new_birthday', mem_email = '$new_email', mem_icq = '$new_icq', mem_tel = '$new_tel', mem_gender = '$new_gender', mem_show_status = '$new_showstatus' where mem_id = '$user_id'";
		mysql_query($query);
		//return 0;
	}
	$s->service($HTTP_RAW_POST_DATA);
?>