<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("Login");
	$s->register("ChkWriter");
	$s->register("ChkAdmin"); 

	function Login($username){
		
		require("../Lib/Database.php");

		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_username='$username'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result = array("mem_id" => $row->mem_id, "mem_username" => $row->mem_username, "mem_password" => $row->mem_password, "count" => $count);
		return $result;
	}
	
	function ChkWriter($mem_id){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from writer where mem_id='$mem_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result2 = array("count" => $count);
		return $result2;
	}

	function ChkAdmin($mem_id){
		
		require("../Lib/Database.php");

		$host = "localhost";
		$uname = "";
		$passwd = "";
		$dbname = "WebCalendar";
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from Admin where mem_id='$mem_id'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_object($result);
		mysql_close($handle);
		$result3 = array("adm_function" => $row->adm_function, "count" => $count);
		return $result3;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>