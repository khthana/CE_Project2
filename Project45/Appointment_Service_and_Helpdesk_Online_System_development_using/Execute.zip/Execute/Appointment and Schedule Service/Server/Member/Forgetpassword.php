<?php
	require("../Lib/Nusoap.php");
	
	$s = new soap_server;
	$s->register("ChkAccount");
	$s->register("SelectMember");


	function ChkAccount($username){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select * from member where mem_username = '$username'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		mysql_close($handle);
		return $count;
	}

	function SelectMember($mem_username, $mem_email){
		
		require("../Lib/Database.php");
		
		$handle = mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = "select count(*), max(mem_password), max(mem_fname), max(mem_lname), max(mem_id)  from member where mem_username = '$mem_username' && mem_email = '$mem_email'";
		$result = mysql_query($query);
		$count = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		mysql_close($handle);
		$result2 = array("password" => $row[1], "name" => $row[2], "surname" => $row[3], "id" => $row[4]);
		return $result2;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>