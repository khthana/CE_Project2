<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body>
	<?php
		session_start();
		
		require("../Lib/Nusoap.php");
		require("../Lib/Server.php");
		
		$parameters = array("user_id"=>"1");
		$soapclient = new soapclient("$server/Member/Checkauth.php");
		$result = $soapclient->call("ChkAuth", $parameters);
		echo '<xmp>'.$soapclient->request.'</xmp>';
		echo '<xmp>'.$soapclient->response.'</xmp>';
		
		echo $result["mem_password"];
		//$cpassword=crypt($result["mem_password"],"mg");
		//$username=$result["mem_username"];
		//if($result["count"] == 0 || $cpassword <> $crp_password)
		//	echo "<META http-equiv=refresh content=\"0; URL=../Index.php\">";
	?>
</body>
</html>
