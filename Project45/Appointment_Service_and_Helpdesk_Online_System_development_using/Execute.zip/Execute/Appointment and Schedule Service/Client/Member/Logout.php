<?php
session_start();
$user_id=0;
$crp_password='';
$user_type='';
session_unregister("user_id");
session_unregister("user_type");
session_unregister("crp_password");
session_destroy();
     
echo "<META http-equiv=refresh content=\"0; URL=../../index.php?logout=true\">";
?>