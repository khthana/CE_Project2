<?php
require("Checkauth.inc");
$msg="";
	if(isset($oldpass)&isset($newpass1)&&isset($newpass2) )
	{

	require("../Lib/Server.php");
			
	$parameters1 = array("user_id"=>$user_id);
	$soapclient1 = new soapclient("$server/Member/Editpassword.php");
	$result1 = $soapclient1->call("ChkPasswd", $parameters1);
	echo '<xmp>'.$soapclient1->request.'</xmp>';
	echo '<xmp>'.$soapclient1->response.'</xmp>';
	$username = $result1["mem_username"];
	$password = $result1["mem_password"];

	if($password<>$oldpass) 	{$msg="������ʼ�ҹ���١��ͧ";	} //check old password is valid
		elseif ($newpass1<>$newpass2) {$msg="������ʼ�ҹ ���� ���ç�ѹ";}  //check re-type new password
			elseif(strlen($newpass1)<4)	{$msg="���ʼ�ҹ���������ǹ��¡��� 4 ����ѡ��";	}
				else
					{ 
	
						$parameters2 = array("newpass1"=>$newpass1, "username"=>$username);
						$soapclient2 = new soapclient("$server/Member/Editpassword.php");
						$result2 = $soapclient2->call("EditPasswd", $parameters2);
						echo '<xmp>'.$soapclient2->request.'</xmp>';
						echo '<xmp>'.$soapclient2->response.'</xmp>';
					

				  $crp_password=crypt($newpass1,"mg");
				echo "<META http-equiv=refresh content=\"0; URL=./edit_profile.html\">";
				
				}

}
//mysql_close($link);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<!-- saved from url=(0062)http://olala05.ce.kmitl.ac.th/s/testphp/tempwhite.html -->

<HTML><HEAD><TITLE>Calendar</TITLE>

<style type="text/css">



<!--



body {  margin: 0px  0px; padding: 0px  0px}



a:link { color: #ccffcc; text-decoration: none}



a:visited { color: #CCFFCC; text-decoration: none}



a:active { color: #CCFFCC; text-decoration: underline}



a:hover { color: #CCFFCC; text-decoration: underline}



-->



</style>

<META http-equiv=Content-Type content="text/html; charset=Windows-874">

<SCRIPT language=JavaScript>

<!--

function MM_swapImgRestore() { //v3.0

  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;

}



function MM_preloadImages() { //v3.0

  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();

    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)

    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}

}



function MM_findObj(n, d) { //v3.0

  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {

    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}

  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];

  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;

}



function MM_swapImage() { //v3.0

  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)

   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}

}

//-->

</SCRIPT>



<META content="MSHTML 5.50.4134.600" name=GENERATOR></HEAD>

<BODY bgColor=#ffffff 

onload="MM_preloadImages('file:///E|/project//redpoint.gif','file:///E|/project//carblue.gif','file:///E|/project//sendpink.gif','file:///E|/project//detailblue.gif','file:///E|/project//logoutorg.gif','file:///E|/project//docyellow.gif','file:///E|/project//addresspink.gif')" link="#666666">
<TABLE height=10 width="100%" border=0 cellpadding="0" cellspacing="0">

  <TBODY> 

  <TR>

    <TD height=39>&nbsp;</TD></TR>

  <TR>

    <TD height=8> <img src="../images/label1.gif" width="126" height="54" border="0"> 
      <a href="../welcome.php"><IMG 

      height=33 src="../images/home.gif" width=90 border=0 

      name=Image1></a><a href="../../reader.php"><img name="Image15" border="0" src="../images/document.gif" width="90" height="33"></a><a href="../schedule/sch_add.php"><IMG 

      height=33 src="../images/carlendar.gif" width=90 border=0 

      name=Image2></a><a href="../message/readmessage.php"><IMG 

      height=33 src="../images/message.gif" width=90 border=0 

      name=Image4></a><a href="../address/addressbook.php"><img name="Image14" border="0" src="../images/address.gif" width="90" height="33"></a><a href="./edit_profile.html"><IMG 

      height=33 src="../images/detail.gif" width=90 border=0 

      name=Image5></a><a href="./logout.php"><IMG 

      height=33 src="../images/logout.gif" width=90 border=0 

      name=Image6></a></TD>

  </TR>

  <TR> 

    <TD height="18"><img src="../images/bolder2.gif" width="130" height="18"><img src="../images/bolder1.gif" width="630" height="18"></TD>

  </TR>



  <TR vAlign=top align=left>

    <TD>

      <TABLE height=464 width="100%" border=0>
        <TBODY> 
        <TR align="left" bgcolor="#FFFFFF"> 
          <TD vAlign=top width="169" height="497"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td height="100"> 
                  <table width="99%" border="1" cellspacing="0" cellpadding="0" bordercolor="#6699CC" align="center" height="96">
                    <tr align="center" bgcolor="#FF9900"> 
                      <td height="20" valign="top" bgcolor="#6699CC"><font size="3" face="MS Sans Serif" color="#000000">��䢢�����</font></td>
                    </tr>
                    <tr> 
                      <td height="75" valign="top"> 
                        <table width="100%" border="1">
                          <tr> 
                            <td align="center"><a href="./editusername.php"><font face="MS Sans Serif" size="2" color="#666666">��䢪��ͼ����</font></a></td>
                          </tr>
                          <tr> 
                            <td align="center"><a href="./editpassword.php"><font face="MS Sans Serif" size="2" color="#000000"><font color="#FF6600">������ʼ�ҹ</font></font></a></td>
                          </tr>
                          <tr> 
                            <td align="center"><a href="./editdetail.php"><font face="MS Sans Serif" size="2" color="#666666">��䢢�������ǹ���</font></a></td>
                          </tr>
                        </table>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
              </tr>
            </table>
<? //-----�����Ѵ���ҧ�Ǵ���� ��� �Ѵ�����Ǵ����-------- ?>

<table width="180" border="0" cellpadding="0" cellspacing="0">

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="25"> 

                          <div align="right"><a href="../schedule/sch_add2.php"><img src="../images/sch_quick.gif" width="150" height="20" border="0"></a></div>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="26"> 

                          <div align="right"><a href="app_add1.php?quick_butt=Y"><img src="../images/app_quick.gif" width="150" height="20" border="0"></a></div>

                        </td>

                      </tr>

                      <?

if($user_calendar=="A" || $user_calendar=="W")

{

?> 

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="26"> 

                          <div align="right"><a href="../../document/edit_article/page_edit.php"><img src="../images/write_column.gif" width="148" height="20" border="0"></a></div>

                        </td>

                      </tr>

                      <?

} //���Է����¹

?> <?

if($user_calendar=="A")

{

?> 

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="2"> 

                          <div align="right"><a href="../admin/adminpage.php"><img src="../images/admin.gif" width="149" height="22" border="0"></a></div>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="2"> 

                          <div align="right">&nbsp;</div>

                        </td>

                      </tr>



                      <?

} //�礼������к�

?> 

                    </table>

<? //-------------���quickbutton------- ?>
          </TD>
          <TD vAlign=top width="678" height="497"> 
            <div align="left"></div>
            <form name="" method="post" action="./editpassword.php">
              <table width="325" border="0" cellpadding="0" cellspacing="0" align="center" height="300">
                <tr align="left" valign="top"> 
                  <td nowrap colspan="2" height="18"> 
                    <div align="left"><img src="../images/head_table.gif" width="324" height="20"></div>
                  </td>
                </tr>
                <tr align="left" valign="top"> 
                  <td colspan="2" bgcolor="#FFFFFF" height="185"> 
                    <div align="center"> 
                      <table width="100%" border="0" cellspacing="0" cellpadding="0" height="100%">
                        <tr> 
                          <td height="193" valign="top"> 
                            <table width="99%" border="1" cellspacing="0" cellpadding="0" bordercolor="#6699CC" align="center" height="170">
                              <tr> 
                                <td height="272" valign="top"> 
                                  <table width="100%" border="0" cellspacing="0" cellpadding="3" height="116">
                                    <tr> 
                                      <td height="19" colspan="3" align="center" valign="middle"><font face="MS Sans Serif">&nbsp;</font></td>
                                    </tr>
                                    <tr> 
                                      <td height="26" colspan="3" align="center" valign="middle"><font size="2" face="MS Sans Serif"><b><font size="3" color="#6666CC">������ʼ�ҹ</font></b></font></td>
                                    </tr>
                                    <tr valign="top"> 
                                      <td height="13" colspan="3" align="center"> 
                                        <table width="100%" border="0" height="100%">
                                          <tr align="left"> 
                                            <td width="53%" height="38"><font size="2"><b><font face="MS Sans Serif" color="#993399">���ͼ���� 
                                              : </font></b></font></td>
                                            <td width="47%" height="38"><font color="#333333" size="2" face="MS Sans Serif"><b><?php echo $username  ?></b></font></td>
                                          </tr>
                                          <tr align="left"> 
                                            <td width="53%"><font face="MS Sans Serif" size="2"><b><font color="#993399">���ʼ�ҹ 
                                              ���: </font></b></font></td>
                                            <td width="47%"><font face="MS Sans Serif"> 
                                              <input type="password" name="oldpass" size="15" maxlength="40">
                                              </font></td>
                                          </tr>
                                          <tr align="left"> 
                                            <td width="53%"> 
                                              <p><font color="#993399" face="MS Sans Serif" size="2"><b>���ʼ�ҹ 
                                                ���� : </b><br>
                                                <font size="1">(����������ҧ���� 
                                                4����ѡ�� )</font></font></p>
                                            </td>
                                            <td width="47%"><font face="MS Sans Serif"><b><font color="#000000" size="5"> 
                                              </font><font face="MS Sans Serif"> 
                                              <input type="password" name="newpass1" size="15" maxlength="40">
                                              </font></b></font><font face="MS Sans Serif" size="3">&nbsp;</font></td>
                                          </tr>
                                          <tr align="left"> 
                                            <td width="53%"><font color="#993399" face="MS Sans Serif" size="2"><b>���ʼ�ҹ 
                                              �����ա���� :</b></font></td>
                                            <td width="47%"><font face="MS Sans Serif"> 
                                              <input type="password" name="newpass2" size="15" maxlength="40">
                                              </font></td>
                                          </tr>
                                          <tr align="left"> 
                                            <td width="53%">&nbsp;</td>
                                            <td width="47%"><font face="MS Sans Serif"> 
                                              <input type="submit" name="Submit" value="������ʼ�ҹ">
                                              </font> 
                                              <input type="reset" name="cancle" value="¡��ԡ">
                                            </td>
                                          </tr>
                                          <tr align="left"> 
                                            <td colspan="2" align="center" height="28"> 
                                              <div align="center"><font face="MS Sans Serif" size="2" color="#CC0033"><b> <?php echo$msg;?></b></font></div>
                                            </td>
                                          </tr>
                                        </table>
                                        
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                      <font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><img src="../images/login_line.gif" width="324" height="18"></b></font></div>
                  </td>
                </tr>
              </table>
            </form>
            <div align="left"></div>
          </TD>
        </TR>
        </TBODY> 
      </TABLE>
    </TD></TR></TBODY></TABLE>

</BODY>

</HTML>

