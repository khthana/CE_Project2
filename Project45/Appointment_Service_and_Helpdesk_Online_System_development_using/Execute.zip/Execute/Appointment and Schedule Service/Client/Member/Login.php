<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>

<body>
	<?php		
		require("../Lib/Nusoap.php");
		require("../Lib/Server.php");
			
		$parameters = array("username"=>$loginUser);
		$soapclient = new soapclient("$server/Member/Login.php");
		$result = $soapclient->call("Login", $parameters);
		echo '<xmp>'.$soapclient->request.'</xmp>';
		echo '<xmp>'.$soapclient->response.'</xmp>';
		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		if($result["count"]){
			if($result["mem_password"] == $passwordUser){
				session_start();
				session_destroy();
				$user_id = $result["mem_id"];
				$user_name = $result["mem_username"];
				$crp_password=crypt($result["mem_password"],"mg");
				session_register("user_id");
				session_register("user_name");
				session_register("crp_password");
				$user_type = "R";
				$user_calendar = $user_type;
				$user_types = $user_type;
		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
				$parameters2 = array("mem_id"=>$result["mem_id"]);
				$soapclient2 = new soapclient("$server/Member/Login.php");
				$result2 = $soapclient2->call("ChkWriter", $parameters2);
				echo '<xmp>'.$soapclient2->request.'</xmp>';
				echo '<xmp>'.$soapclient2->response.'</xmp>';
		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
				if($result2["count"]){
					$user_type = "W";
					$user_calendar = $user_type;
					$user_types = "$user_types W";
				}
		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
				$parameters3 = array("mem_id"=>$result["mem_id"]);
				$soapclient3 = new soapclient("$server/Member/Login.php");
				$result3 = $soapclient3->call("ChkAdmin", $parameters3);
				echo '<xmp>'.$soapclient3->request.'</xmp>';
				echo '<xmp>'.$soapclient3->response.'</xmp>';
		//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
				if($result3["count"]){
					$user_type = "A";
					$user_calendar = $user_type;
					$user_types = "$user_types A";
					if($result3["adm_function"]=="column")
						$function = "column_admin";
					else if ($result3["adm_function"]=="member")
						$function = "member_admin";
					session_register("function");
				}
				session_register("user_type");
				session_register("user_calendar");
				session_register("user_types");
				if($user_type=="A")
					echo "<META http-equiv=refresh content=\"0; URL=../Index.php\">";
				else
					echo "<META http-equiv=refresh content=\"0; URL=../Welcome.php\">";
				}
			else
				echo "<META http-equiv=refresh content=\"0; URL=./Index.php?login=\"password_fail\">";
			}
		else
			echo "<META http-equiv=refresh content=\"0; URL=./Index.php?login=\"not_member\"\">";
	?>
</body>
</html>
