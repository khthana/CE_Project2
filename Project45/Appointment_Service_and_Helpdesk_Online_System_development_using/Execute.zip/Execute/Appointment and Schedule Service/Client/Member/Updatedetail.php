<?php
require('Checkauth.inc');
//$link=mysql_connect($host,$user,$pass) or die("�������ö�Դ��Ͱҹ��������");
$new_email=trim($new_email);
$new_fname=trim($new_fname);
$new_lname=trim($new_lname);
$new_nickname=trim($new_nickname);


session_register("old_fname");
$old_fname=$new_fname;

session_register("old_lname");
$old_lname=$new_lname;

session_register("old_nickname");
$old_nickname=$new_nickname;

session_register("old_address");
$old_address=$new_address;

session_register("old_zipcode");
$old_zipcode=$new_zipcode;

session_register("old_bdate");
$old_bdate=$new_bdate;

session_register("old_bmonth");
$old_bmonth=$new_bmonth;

session_register("old_byear");
$old_byear=$new_byear;

session_register("old_email");
$old_email=$new_email;

session_register("old_icq");
$old_icq=$new_icq;

session_register("old_tel");
$old_tel=$new_tel;

session_register("old_gender");
$old_gender=$new_gender;

session_register("old_showstatus");
$old_showstatus=$new_showstatus;

session_register("lastpage");
$lastpage='updatedetail';

$accept=1;
session_register("err_msg");
$index=strpos($new_email,'@');
$indexpoint=strpos($new_email,'.');
if(($index===false)||($index==0)||($indexpoint==(strlen($new_email)-1)) ||($indexpoint===false)||($index==($indexpoint-1)))
{
$err_msg="�������������١��ͧ";
$accept=0;
}

if($new_fname==''){$err_msg=$err_msg."�������١��ͧ<br>";$accept=0;}
if($new_lname==''){$err_msg=$err_msg."���ʡ�����١��ͧ<br>";$accept=0;}
if($new_nickname==''){$err_msg=$err_msg."����������١��ͧ<br>";$accept=0;}
if(!checkdate($new_bmonth,$new_bdate,$new_byear))
{
$err_msg=$err_msg."�ѹ�Դ���١��ͧ";
$accept=0;
}

if($accept==0){echo "<META http-equiv=refresh content=\"0; URL=./editdetail.php\">";}
else
{

$new_birthday=$new_byear."-".$new_bmonth."-".$new_bdate;
if ($new_showstatus<>'Y'){$new_showstatus='N';}
/*
$sql="update member set mem_fname='".$new_fname."',mem_lname='".$new_lname
."',mem_nickname='".$new_nickname."',mem_address='".$new_address."',mem_zipcode='".$new_zipcode."',mem_birthday='".$new_birthday
."',mem_email='".$new_email."',mem_icq='".$new_icq."',mem_tel='".$new_tel."',mem_gender='".$new_gender
."',mem_show_status='".$new_showstatus."' where mem_id=".$user_id;
$link=mysql_connect($host,$user,$pass)or die("�������ö�Դ��Ͱҹ��������");
$result=mysql_db_query($db,$sql);
mysql_close($link);
*/

require("../Lib/Server.php");
$parameters = array("new_fname" => $new_fname, "new_lname" => $new_lname, "new_nickname" => $new_nickname, "new_address" => $new_address, "new_zipcode" => $new_zipcode, "new_birthday" => $new_birthday, "new_email" => $new_email, "new_icq" => $new_icq, "new_tel" => $new_tel, "new_gender" => $new_gender, "new_showstatus" => $new_showstatus, "user_id" => $user_id);
$soapclient = new soapclient("$server/Member/Updatedetail.php");
$result = $soapclient->call("Updatedetail", $parameters);
echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';

$lastpage='';
$old_fname='';
$old_lname='';
$old_nickname='';
$old_address='';
$old_zipcode='';
$old_bdate='';
$old_bmonth='';
$old_byear='';
$old_email='';
$old_icq='';
$old_tel='';
$old_gender='';
$old_showstatus='';
session_unregister("err_msg");
session_unregister("lastpage");
session_unregister("old_fname");
session_unregister("old_lname");
session_unregister("old_nickname");
session_unregister("old_address");
session_unregister("old_zipcode");
session_unregister("old_bdate");
session_unregister("old_bmonth");
session_unregister("old_byear");
session_unregister("old_email");
session_unregister("old_icq");
session_unregister("old_tel");
session_unregister("old_gender");
session_unregister("old_showstatus");
     echo "<META http-equiv=refresh content=\"30; URL=./edit_profile.html\">";
	 
}
?>