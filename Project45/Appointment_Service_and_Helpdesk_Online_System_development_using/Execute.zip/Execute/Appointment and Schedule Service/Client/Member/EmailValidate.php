<html>
	<body>
		<?php

				//http://ws2.serviceobjects.net/ev/EmailValidate.asmx?op=ValidateEmail
				//http://ws2.serviceobjects.net/ev/EmailValidate.asmx?WSDL

				require("../Lib/Nusoap.php");
				
				$wsdlFile = "http://ws2.serviceobjects.net/ev/EmailValidate.asmx?WSDL";
				
				$msg = '<ValidateEmail xmlns="http://www.serviceobjects.com/"><Email>juthakiat@hotmail.com</Email><LicenseKey>WS10-KBY4-GAP2</LicenseKey></ValidateEmail>';

				$s = new soapclient($wsdlFile, 'wsdl');
				$s->call("ValidateEmail", array($msg));

				print 'RESULT:<xmp>';
				var_dump ($s->document);
				print '</xmp>';

				echo 'REQUEST:<xmp>'.$s->request.'</xmp>';
				echo 'RESPONSE:<xmp>'.$s->response.'</xmp>';
				
		?>
	</body>
</html>