<?php
	$a = 5;
	$b = 10;
	require("inc.inc");
?>