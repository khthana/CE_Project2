<?

session_start();

include("../checkauth.inc");

if($appoint=="�ӡ�ùѴ����")

{

	$num_chk="F";

	$err=4;

	$host="localhost";



	$usersql="";



	$password="";



	$table="schedule";



	$db="WebCalendar";



	$link=mysql_connect($host,$usersql,$password) or



	die("�������ö�Դ��Ͱҹ��������");



	mysql_select_db("WebCalendar") or die("�������ö�Դ��������������"); 

//��Ҫ������͹�Ѻid �ҷ��繵�������º�Ѻ�������

if($grp_num<>"all")

{

$sqlfriend="select friend_id,mem_username from member,contact ";

$sqlfriend=$sqlfriend."where member.mem_id=contact.friend_id and contact.mem_id=$user_id and grp_id=$grp_num order by mem_username";

}else

{

$sqlfriend="select friend_id,mem_username from member,contact ";

$sqlfriend=$sqlfriend."where member.mem_id=contact.friend_id and contact.mem_id=$user_id group by friend_id order by mem_username";

}

$result= mysql_db_query("WebCalendar",$sqlfriend);

$numrow=@mysql_num_rows($result);

	

	$num_chk="F";

	$err=4;

	$list_friend_id="00";

for($i=0;$i<$numrow;$i++)

{

	   $row=mysql_fetch_array($result);		

		$tmpname=$row[1];

		$tmpname=$tmpname.$row[0];

		if($$tmpname==$row[0])

		{	 

			$list_friend_id=$list_friend_id."/".$row[0];

			$num_chk="T";

			$err="";

		}

}

mysql_close();

} // if $appoint



if($num_chk<>"T")

{

?>



<HTML><HEAD><TITLE>Calendar</TITLE>

<style type="text/css">



<!--



body {  margin: 0px  0px; padding: 0px  0px}



a:link { color: #ccffcc; text-decoration: none}



a:visited { color: #CCFFCC; text-decoration: none}



a:active { color: #CCFFCC; text-decoration: underline}



a:hover { color: #CCFFCC; text-decoration: underline}



-->



</style>

<META http-equiv=Content-Type content="text/html; charset=Windows-874">

<SCRIPT language=JavaScript>

<!--

function MM_swapImgRestore() { //v3.0

  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;

}



function MM_preloadImages() { //v3.0

  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();

    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)

    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}

}



function MM_findObj(n, d) { //v3.0

  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {

    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}

  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];

  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document); return x;

}



function MM_swapImage() { //v3.0

  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)

   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}

}

//-->

</SCRIPT>



<META content="MSHTML 5.50.4134.600" name=GENERATOR></HEAD>

<BODY bgColor=#ffffff 

onload="MM_preloadImages('../redpoint.gif','../carblue.gif','../sendpink.gif','../detailblue.gif','../logoutorg.gif','../docyellow.gif','../addresspink.gif','../image/detailblue.gif')">

<?



	Include("time.inc");

 	Include("thaidate.inc");



if(!isset($schday))

{

	$schday=date("w");

}

if(!isset($schdate))

{

	$schdate=date("j");

}

if(!isset($schmonth))

{

	$schmonth=date("m");

}

if(!isset($schyear))

{

	$schyear=date("Y");

}



?> 

<TABLE width="120%" border=0 cellpadding="0" cellspacing="0">

  <TBODY> 

  <TR>

    <TD height=39>&nbsp;</TD></TR>

  <TR>

    <TD height=8> <img src="../images/label1.gif" width="126" height="54" border="0"> 

      <A onmouseover="MM_swapImage('Image1','','../images/redpoint.gif',1)" 

      onmouseout=MM_swapImgRestore() 

      href="../welcome.php"><IMG 

      height=33 src="../images/home.gif" width=90 border=0 

      name=Image1></A><a href="../../reader.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image15','','../images/docyellow.gif',1)"><img name="Image15" border="0" src="../images/document.gif" width="90" height="33"></a><A onmouseover="MM_swapImage('Image2','','../images/carblue.gif',1)" 

      onmouseout=MM_swapImgRestore() 

      href="../schedule/sch_add.php"><IMG 

      height=33 src="../images/carlendar.gif" width=90 border=0 

      name=Image2></A><A 

      onmouseover="MM_swapImage('Image4','','../images/messagegreen.gif',1)" 

      onmouseout=MM_swapImgRestore() 

      href="../message/readmessage.php"><IMG 

      height=33 src="../images/message.gif" width=90 border=0 

      name=Image4></A><a href="../address/addressbook.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image14','','../images/addresspink.gif',1)"><img name="Image14" border="0" src="../images/address.gif" width="90" height="33"></a><A 

      onmouseover="MM_swapImage('Image5','','../images/detailblue.gif',1)" 

      onmouseout=MM_swapImgRestore() 

      href="../member/edit_profile.html"><IMG 

      height=33 src="../images/detail.gif" width=90 border=0 

      name=Image5></A><A 

      onmouseover="MM_swapImage('Image6','','../images/logoutorg.gif',1)" 

      onmouseout=MM_swapImgRestore() 

      href="../member/logout.php"><IMG 

      height=33 src="../images/logout.gif" width=90 border=0 

      name=Image6></A></TD>

  </TR>

  <TR> 

    <TD height="18"><img src="../images/bolder2.gif" width="130" height="18"><img src="../images/bolder1.gif" width="630" height="18"></TD>

  </TR>



  <TR vAlign=top align=left>

    <TD>

      <TABLE height=464 width="100%" border=0>

        <TBODY>

        <TR>

          <TD vAlign=top align=left width="21%"> 



              <table width="98%" border="0" cellpadding="0" cellspacing="0">

                <tr> 

                  

                <td nowrap colspan="2"> 

                  <div align="center"></div>

                  </td>

                </tr>

                <tr> 

                  <td colspan="2" bgcolor="#FFFFFF" nowrap> 

                    <div align="center"> 

                      <table width="180" border="0" cellspacing="0" cellpadding="0">

                        <tr> 

                          <td height="109"> 

                            <table width="100%" border="0" cellspacing="0" cellpadding="0" bordercolor="">

                              <tr>

                                

                              <td>

                                <table cellspacing=0 cellpadding=1 width="100%" border=1 bordercolor="#6699CC">

                                  <tbody> 

                                  <tr bgcolor="#6699CC"> 

          <td colspan=4 align=middle noWrap> 

            <div align="left"><font face="MS Sans Serif, Microsoft Sans Serif" color="#FFFFCC" size="2"><b>�ѹ��� :</b>

 <a href="../schedule/sch_add.php?schday=<? echo date("w"); ?>&schdate=<? echo date("j"); ?>&schmonth=<? echo date("m"); ?>&schyear=<? echo date("Y"); ?>">

<font color="#FFFFCC" size="2">



<? echo date("j")," ",$thaimonth[date("m")-1]," ",date("Y")+543;    

?>

		 </font></a>

     </font></div></td>

        </tr>



        <tr bgcolor=#ffffff> 

          <td align=middle bgcolor=#FFCC99 width="25%" height="12"><a href="../schedule/sch_add.php?schday=<? echo $schday; ?>&schdate=<? echo $schdate; ?>&schmonth=<? echo $schmonth; ?>&schyear=<? echo $schyear; ?>">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FF0000">�ѹ</font></a></td>

          <td align=middle bgcolor=#ffffff width="25%" height="12"><a href="../schedule/sch_add_week.php?schday=<? echo $schday; ?>&schdate=<? echo $schdate; ?>&schmonth=<? echo $schmonth; ?>&schyear=<? echo $schyear; ?>">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2"><font color="#009900">�ѻ����</font></font></a></td>

          <td align=middle bgcolor=#ffffff width="25%" height="12"><a href="../schedule/sch_add_month.php?schday=<? echo $schday; ?>&schdate=<? echo $schdate; ?>&schmonth=<? echo $schmonth; ?>&schyear=<? echo $schyear; ?>"><font color="#009900">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2">��͹</font></font></a></td>

          <td align=middle bgcolor=#ffffff width="25%" height="12"><a href="../schedule/sch_add_year.php?schday=<? echo $schday; ?>&schdate=<? echo $schdate; ?>&schmonth=<? echo $schmonth; ?>&schyear=<? echo $schyear; ?>"><font color="#009900">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2">��</font></font></a></td>

        </tr>

        <tr> 

          <td noWrap align=middle bgcolor=#dcdcdc colspan=4 height="32"> 

            <table cellspacing=0 cellpadding=1 border=0>

              <tbody> 

              <tr>

<?

//-----next month

	$next_month= date("d/m/Y",mktime(1,1,0,$schmonth+1,1,$schyear));

	$nx_day=(int) date("w",mktime(1,1,0,$schmonth+1,1,$schyear));

	$nx_date=(int) substr($next_month,0,2);

	$nx_month=(int) substr($next_month,3,2);

	$nx_year= substr($next_month,6,4);

//----previous month

	$pre_month= date("d/m/Y",mktime(1,1,0,$schmonth-1,1,$schyear));

	$pr_day=(int) date("w",mktime(1,1,0,$schmonth-1,1,$schyear));

	$pr_date=(int) substr($pre_month,0,2);

	$pr_month=(int) substr($pre_month,3,2);

	$pr_year= substr($pre_month,6,4);





?>

 

                                          <td><a 

                  href="../schedule/sch_add.php?schday=<? echo $pr_day; ?>&schdate=<? echo $pr_date; ?>&schmonth=<? echo $pr_month; ?>&schyear=<? echo $pr_year; ?>"> 

                                            <img height=10 src="../images/left4.gif" width=11 

                  border=0></a> </td>

                <td valign=center noWrap><tt><b>

				<font face="MS Sans Serif,Microsoft Sans Serif" size="2" color="#FF6600">

<?

	echo $thaimonth[$schmonth-1]," ",$schyear+543;

?>

				</font></b></tt> </td>

                                          <td><a 

                  href="../schedule/sch_add.php?schday=<? echo $nx_day; ?>&schdate=<? echo $nx_date; ?>&schmonth=<? echo $nx_month; ?>&schyear=<? echo $nx_year; ?>"> 

                                            <img height=11 src="../images/right4.gif" width=11 

                  border=0></a> </td>

              </tr>

              </tbody> 

            </table>

          </td>

        </tr>

        <tr> 

          <td align=middle colspan=4> 

<?



// ��ԷԹ��ҹ���***************

include("sch_day_of_month.inc");//$day_of_month[0-34] or [0-42] ,$num_week

?> 

            <table width= 100% cellspacing=3 cellpadding=1 bgcolor=#ffffff border=0>

        <tbody>

        <tr>

<?

$start=0;

for($i=0;$i<7;$i++)//week

{

?>

                <td valign=top align=right><font face="MS Sans Serif,Microsoft Sans Serif" size="2" color="#000000"> 

                  <?

	$num_show=$start+$i;

    echo $thaiday_short[$i],"<br>";

	for($j=0;$j<$num_week;$j++)

    {

	  $show_date=(int) substr($day_of_month[$num_show],0,2);

	  $tmp_month=(int) substr($day_of_month[$num_show],3,2);

	  $tmp_year=(int) substr($day_of_month[$num_show],6,4);

?></font> <a href="../schedule/sch_add.php?schday=<? echo $i; ?>&schdate=<? echo $show_date; ?>&schmonth=<? echo $tmp_month; ?>&schyear=<? echo $tmp_year; ?>"> 

                  <font face="MS Sans Serif,Microsoft Sans Serif" size="2" color="#000000">	

                  <?

// ���ѹ�������㹻�ԷԹ���繢ͧ��͹��͹�Ѻ��͹˹��

$last_week=$num_week-1;

	  if(($j==0 and $show_date>7) || ($j==$last_week and $show_date<7))

	  { 

		echo "<font color=#999999>";

//�ʴ����˹�

		    if($show_date==$schdate and $tmp_month==$schmonth) 

			{ echo "<b>",$show_date,"</b><br></font>";

			}else

			{ echo $show_date,"<br></font>";

			}

	  }else

	  {

		echo "<font color=#0000FF>";

		    if($show_date==$schdate and $tmp_month==$schmonth) 

			{ echo "<b>",$show_date,"</b><br></font>";

			}else

			{ echo $show_date,"<br></font>";

			}

	  }		

	  $num_show=$num_show+7;	

	} 

?> </font></a></td>

<?

}

?>

        </tr>

        </tbody> 

      </table>                

<? //�����ԷԹ��ҹ��� 

?>

          </td>

        </tr>

        <tr bgcolor="#CCCCCC"> 

          <td noWrap align=middle colspan=4 height="10">&nbsp;</td>

        </tr>

        </tbody> 

      </table>



								&nbsp; <? //--------------  �����ԷԹ��ҹ���     -------------------- ?></td>

                              </tr>

                            </table>

                          </td>

                        </tr>

                      </table>

<? //-----�����Ѵ���ҧ�Ǵ���� ��� �Ѵ�����Ǵ����-------- ?>

<table width="180" border="0" cellpadding="0" cellspacing="0">

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="25"> 

                          <div align="right"><a href="../schedule/sch_add2.php"><img src="../images/sch_quick.gif" width="150" height="20" border="0"></a></div>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="26"> 

                          <div align="right"><a href="app_add1.php?quick_butt=Y"><img src="../images/app_quick.gif" width="150" height="20" border="0"></a></div>

                        </td>

                      </tr>

                      <?

if($user_calendar=="A" || $user_calendar=="W")

{

?> 

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="26"> 

                          <div align="right"><a href="../../document/edit_article/page_edit.php"><img src="../images/write_column.gif" width="148" height="20" border="0"></a></div>

                        </td>

                      </tr>

                      <?

} //���Է����¹

?> <?

if($user_calendar=="A")

{

?> 

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="2"> 

                          <div align="right"><a href="../admin/adminpage.php"><img src="../images/admin.gif" width="149" height="22" border="0"></a></div>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2" height="2"> 

                          <div align="right">&nbsp;</div>

                        </td>

                      </tr>



                      <?

} //�礼������к�

?> 

                    </table>

<? //-------------���quickbutton------- ?>

                      

                    <table width="120" border="0" cellpadding="0" cellspacing="0">

                      <tr align="left" valign="top"> 

                        <td nowrap colspan="2"> 

                          <div align="center"><img src="../images/mess_remindhead.gif" width="188" height="21"></div>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td colspan="2" bgcolor="#FFFFFF" height="150"> 

                          <div align="center"> 

                            <table width="100%" border="0" cellspacing="0" cellpadding="0">

                              <tr> 

                                <td height="72"> 

                                  <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#6699CC" height="91">

                                    <tr> 

                                      <td height="97"> 

                                        <table width="100%" border="0" cellspacing="0" cellpadding="3">

                                          <tr> 

                                            <td height="34" colspan="2"><font size="2"><font color="#0066FF" face="AngsanaUPC, Angsana New, MS Serif"><?php include("../checkmessage.inc"); ?></font></font></td>

                                          </tr>

                                          <tr> 

                                            <td height="31" colspan="2">&nbsp;</td>

                                          </tr>

                                        </table>

                                      </td>

                                    </tr>

                                  </table>

                                  <? //----------��� ��͹��ͤ��� ---------- ?> 

                                </td>

                              </tr>

                            </table>

                            <font face="MS Sans Serif, Microsoft Sans Serif" size="2"></font></div>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td colspan="2" height="16"><img src="../images/sch_remindhead.gif" width="188" height="20"></td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td colspan="2" height="69"> 

                          <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#6699CC">

                            <tr> 

                              <td height="83"> 

                                <table width="100%" border="0" cellspacing="0" cellpadding="3">

                                  <tr> 

                                    <td height="34" colspan="2"><font size="1"><font color="#0066FF" face="MS Sans Serif, Microsoft Sans Serif"><?php include("../remind/sch_remindside.inc"); ?></font></font></td>

                                  </tr>

                                  <tr> 

                                    <td height="31" colspan="2">&nbsp;</td>

                                  </tr>

                                </table>

                              </td>

                            </tr>

                          </table>

                        </td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td colspan="2" height="2">&nbsp;</td>

                      </tr>

                      <? //------------��� ��͹ ���ҧ------------ ?> 

                      <tr align="left" valign="top"> 

                        <td colspan="2" height="9"><img src="../images/app_remindhead.gif" width="188" height="20"></td>

                      </tr>

                      <tr align="left" valign="top"> 

                        <td colspan="2"> 

                          <div align="center"> 

                            <table width="100%" border="1" cellspacing="0" cellpadding="0" bordercolor="#6699CC">

                              <tr> 

                                <td height="88"> 

                                  <table width="100%" border="0" cellspacing="0" cellpadding="3">

                                    <tr> 

                                      <td height="34" colspan="2"><font size="1"><font color="#0066FF" face="MS Sans Serif, Microsoft Sans Serif"><?php include("../remind/app_messbeside.inc"); ?></font></font></td>

                                    </tr>

                                    <tr> 

                                      <td height="31" colspan="2"><font size="1"><font color="#0066FF" face="MS Sans Serif, Microsoft Sans Serif"><?php include("../remind/app_mess_tosenderbeside.inc"); ?></font></font></td>

                                    </tr>

                                  </table>

                                </td>

                              </tr>

                            </table>

                            <? //---------------- ��� ��͹ �Ѵ���� -------------- ?> 

                          </div>

                        </td>

                      </tr>

                    </table>

                  </div>

                  </td>

                </tr>

                <tr> 

                  <td colspan="2">

                    

                  <div align="center"></div>

                  </td>

                </tr>

                <tr> 

                  <td colspan="2" height="35"> 

                    

                  <div align="center"></div>

                  </td>

                </tr>

              </table>

          </TD>

          <TD width="79%"> 

      <form method="post" action="app_add_all_list.php?time=<? echo $time; ?>&schday=<? echo $schday; ?>&schdate=<? echo $schdate; ?>&schmonth=<? echo $schmonth; ?>&schyear=<? echo $schyear; ?>&grp_num=<? echo $grp_num; ?>">

              <table width="85%" border="0" cellspacing="0" cellpadding="0">

                <tr> 

                  <td width="10%" height="341"> 

                    <table width="100%" border="0" cellspacing="0" cellpadding="0">

                      <tr> 

                        <td width="10%" height="27">&nbsp; </td>

                      </tr>

                      <tr> 

                        <td width="10%" height="27">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                      <tr> 

                        <td width="10%">&nbsp;</td>

                      </tr>

                    </table>

                  </td>

                  <td width="70%" height="341"> 

<font size="2" face="MS Sans Serif, Microsoft Sans Serif" color="#FF0000">&nbsp;

<?

if($err=="4")

{

		echo "<b>��س����͡���ͼ���Ѻ </b><br>";

}

?>

</font>				

                    <table width="100%" border="1" cellspacing="0" cellpadding="0">

                      <tr bgcolor="#003399"> 

                        <td colspan="4"> 

                          <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FFFFFF">��ª������͹</font></div>

                        </td>

                      </tr>

                      <tr bgcolor="#CCCCCC"> 

                        <td colspan="4" height="30"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#003399">����� 

                          : </font> <?

$host="localhost";



$usersql="";



$password="";



$table="schedule";



$db="WebCalendar";



$link=mysql_connect($host,$usersql,$password) or



die("�������ö�Դ��Ͱҹ��������");



mysql_select_db("WebCalendar") or die("�������ö�Դ��������������"); 

if($grp_num<>"all")

{

	$sqlgrpname="select grp_name from group_name where mem_id=$user_id and grp_id=$grp_num";

	$result= mysql_db_query("WebCalendar",$sqlgrpname);

	$numrow=@mysql_num_rows($result);

	if ($numrow>0)

	{

  	 $row=mysql_fetch_array($result);		

		  $grp_name=$row[0];

	}//�ʴ����͡���������ʴ���ª������͹

}else

{

	$grp_name="������";

}

 //�礡óշ���ͧ��ê������͹������

?> <font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#003399"><b><? echo $grp_name; ?></b></font> 

                          <input type="hidden" name="grp_num" value=<? echo $grp_num; ?>>

                        </td>

                      </tr>

                      <tr bgcolor="#6699CC"> 

                        <td> 

                          <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FFFF99"><font color="#000099"><font color="#FFFFFF"><font color="#CCFFCC"><font color="#0099CC"><font color="#CCFFFF"></font></font></font></font></font></font></div>

                        </td>

                        <td> 

                          <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#CCFFFF">���ͼ����</font></div>

                        </td>

                        <td> 

                          <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#CCFFFF">����-���ʡ��</font></div>

                        </td>

                        <td> 

                          <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#CCFFFF">�������</font></div>

                        </td>

                      </tr>

 <?

if($grp_num<>"all")

{

$sqlfriend="select friend_id,mem_username,mem_fname,mem_lname,mem_nickname from member,contact ";

$sqlfriend=$sqlfriend."where member.mem_id=contact.friend_id and contact.mem_id=$user_id and grp_id=$grp_num order by mem_username";

}else

{

$sqlfriend="select friend_id,mem_username,mem_fname,mem_lname,mem_nickname from member,contact ";

$sqlfriend=$sqlfriend."where member.mem_id=contact.friend_id and contact.mem_id=$user_id group by friend_id order by mem_username";

}

$result= mysql_db_query("WebCalendar",$sqlfriend);

$numrow=@mysql_num_rows($result);

$listfriend=split("/",$list_friend_id);

$numfriend_chk=count($listfriend);

for($i=0;$i<$numrow;$i++)

{

	   $row=mysql_fetch_array($result);		

		$tmpname=$row[1];

		$tmpname=$tmpname.$row[0];

?>

                      <tr> 

                        <td width="5%" height="27"> <?     echo "<input type=checkbox name=$tmpname value=$row[0] ";

		for($j=1;$j<$numfriend_chk;$j++)

		{

			if($listfriend[$j]==$row[0])

			{

				echo "checked";

			}

		} // ��������͹���˹�١�礨ҡ˹�ҷ�����Ǻ�ҧ

		echo ">";							

?> </td>

                        <td width="25%" height="27"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" > 

                          <?      echo " <font color=#0066CC>&nbsp;", $row[1]," </font>"; 

									   echo "<a href=checkfree.php?group_id=$grp_num&friend_id=$row[0]&time=$time&schday=$schday&schdate=$schdate&schmonth=$schmonth&schyear=$schyear&lastpage=app_add_all_list>";

   									echo "<img border=0 src=../images/search.gif width=12 height=12>";

										echo "</a>";



							?> 

                          </font> </td>

                        <td width="50%" height="27"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" > 

                          <?      echo " <font color=#0066CC>&nbsp; $row[2] &nbsp; $row[3]</font>"; ?> 

                          </font> 

                        <td width="20%" height="27"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" > 

                          <?      echo " <font color=#0066CC>&nbsp;", $row[4]," </font>"; ?> 

                          </font> 

                      </tr>

<?

} //for $numrow

?>

                      <tr> 

                        <td colspan="4" height="35"> 

                          <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif" > 

                            <input type="submit" name="appoint" value="�ӡ�ùѴ����">

                            </font></div>

                        </td>

                      </tr>

                    </table>

                  </td>

                  <td width="20%" height="341"> </td>

                </tr>

                <tr> 

                  <td width="11%">&nbsp;</td>

                  <td width="70%">&nbsp;</td>

                  <td width="20%">&nbsp;</td>

                </tr>

              </table>

            </form>

<table width="95%" height="100%" border="0" cellspacing="0" cellpadding="0">

                <tr>

                  <td>&nbsp;</td>

                </tr>

              </table>

            



          </TD>

        </TR></TBODY></TABLE></TD></TR></TBODY></TABLE>

</BODY>

</HTML>

<?

}elseif($num_chk=="T")

{

$schdate=$schdate;

$schmonth=$schmonth;

$schyear=$schyear;

$schday=(int) date("w",mktime(1,1,0,$schmonth,$schdate,$schyear));

echo "<META http-equiv=refresh content=\"0; URL=app_add_all_list2.php?time=$time&schday=$schday&schdate=$schdate&schmonth=$schmonth&schyear=$schyear&grp_num=$grp_num\">";


}

?>

