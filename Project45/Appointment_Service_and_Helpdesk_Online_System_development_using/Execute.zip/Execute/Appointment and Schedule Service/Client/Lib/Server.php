<?php
	$server = "http://161.246.6.59/Project/WebCalendar/Server";
?>