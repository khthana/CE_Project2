<?	session_start();

	$user_type = "R";

	session_unregister("user_type");

	session_register("user_type");

   $hostname = "localhost";

   $username = "";

   $password = "";

   $dbName = "WebCalendar";

   mysql_connect($hostname,$username,$password) or die("can not connect!");

	if ($id_col == "")

	$id_col = "0";	//***

?>

<html>

<head>

<title>Home</title>

<meta http-equiv="Content-Type" content="text/html; charset=windows-874">

</head>



<body bgcolor="#FFFFFF" background="Client/Images/32_NEST.GIF" text="#000000">

<table width="95%" border="0" cellspacing="0" cellpadding="0" align="center">
  <TR> 
    <TD align=left height=86><img src="Client/Images/logo.jpg" width="992" height="100" border="0"></TD>
  </TR>
  <TR> 
    <TD align=left height=5 bgcolor="#7BA2E7"><IMG height=5 src="" 
            width="0"></TD>
  </TR>
  <tr> 
    <td height="86" align="left" valign="top"> <table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
        <tr> 
          <td colspan="4" valign="top">&nbsp;</td>
          <td height="2" valign="top" colspan="2">&nbsp;</td>
        </tr>
        <tr> 
          <td valign="top">&nbsp;</td>
          <td valign="top" bgcolor="#66CCFF">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td valign="top">&nbsp;</td>
          <td colspan="2" align="right" valign="middle"> <table width="550" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td align="right"> <form name="form1" method="post" action="search/searchBasic.php"R"">
                    <table cellspacing=0 cellpadding=0 width="400" 

                  bgcolor=#dcedf5 border=0>
                      <tbody>
                        <tr> 
                          <td align=center width=97><font color="#003399" size="2" face="MS Sans Serif, Tahoma, sans-serif">Search</font><br> </td>
                          <td align=left width=108> <input size=20 name=keyword> 
                          </td>
                          <td align=center width=40> <input type=image height=19 

                        width=19 

                        src="Client/Images/go2.gif" 

                        border=0 name="image"> <br> </td>
                          <td align=center colspan="2" width=155><font color="#CC0000" size="2">Search 
                            Tip</font></td>
                        </tr>
                      </tbody>
                    </table>
                  </form></td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td valign="top" width="1%" height="7" background="image/my/3/bg4.jpg"></td>
          <td valign="top" height="7" width="17%" bgcolor="#66CCFF"> <table border="0" cellspacing="0" cellpadding="3" width="100%">
              <tr> 
                <td bgcolor="#003399" colspan="2" height="24"><b><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Main 
                  menu</font></b></td>
              </tr>
              <tr> 
                <td bgcolor="#66CCFF"> <img src="Client/Images/sch_dayline.gif" width="10" height="10"> 
                  <font size="2"><a href="reader.php?id_col=<?echo $id_col;?>"><font face="Verdana, Arial, Helvetica, sans-serif">articles</font></a><br>
                  <img src="Client/Images/sch_dayline.gif" width="10" height="10"> <font size="2"><a href="search.php?id_col=<?echo $id_col;?>"><font face="Verdana, Arial, Helvetica, sans-serif">search</font></a></font> 
                  </font></td>
              </tr>
            </table>
            <br> <table border="0" cellspacing="0" cellpadding="3" width="100%">
              <tr> 
                <td bgcolor="#003399" colspan="2" height="24"> 
                  <? //show column

	$sql = "select * from col where col_id = $id_col ";

	$SQLresult = mysql_db_query($dbName,$sql);

   $num = mysql_numrows($SQLresult);

   if ($num) {

      for ($i=1;$i<=$num;$i++) {

			$row = mysql_fetch_array($SQLresult);

			echo "<b><font color=\"#FFFFFF\" size=\"2\" face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\">".ucwords($row[col_name])." [ <a href=\"reader.php?id_col=$row[parent_col_id]\"><font size=\"1\" color=\"#FFFF00\" face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\">Up</font></a> ]</font></b>";

		}

	}

	else {

		echo "<b><font color=\"#FFFFFF\" size=\"2\" face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\">Column</font></b>";	

	}

?>
                </td>
              </tr>
              <tr> 
                <td><font color="#330099" size="2" face="Microsoft Sans Serif, MS Sans Serif, sans-serif"><br>
                  <a href="Col.php">.NET �ա��� J2EE ���ҧ�������?</a></font></td>
              </tr>
            </table>
            <form method="post" action="Client/Member/Login.php">
              <table border="0" cellspacing="0" cellpadding="3" width="100%">
                <tr> 
                  <td bgcolor="#003399" colspan="2" height="24"><b><font color="#FFFFFF" size="2" face="Verdana, Arial, Helvetica, sans-serif">Member</font></b></td>
                </tr>
                <tr> 
                  <td> 
                    <?

	if ($logout=="true") {

		session_destroy();

		$member = "fail";

	}

	$sql = "select mem_password from member where mem_username = \"$user_name\"";

	$SQLresult = mysql_db_query($dbName,$sql);

   $num = mysql_numrows($SQLresult);

	echo "<font color=\"#0000FF\" size=\"1\" face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\">";

   if ($num && $logout!="true") {

		$row = mysql_fetch_array($SQLresult);

		$password=crypt($row[mem_password],"mg");

		if($password==$crp_password) {

			$member = "true";

			if (strpos(" $user_types","A")) {

				if (!$function || $function=="column_admin")

					echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"Client/Admin/columnAdmin.php\"> column managment</a><br>";

				if (!$function || $function=="member_admin")

					echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"Client/Admin/adminpage.php\"> member managment</a><br>";

				if (!$function || $function=="article_admin")

					echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"Client/Admin/articleAdmin.php\"> article managment</a><br>";

			}

			if (strpos(" $user_types","W")) {

				echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"./document/onweb/onweb.php\"> create article on web</a><br>";

				echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"./document/upload/upload.php\"> create article by upload</a><br>";

				echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"./document/edit_article/page_edit.php\"> edit article</a><br>";

				echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"./document/edit_article/delete.php\"> delate article</a><br>";

			}

			echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"./Client/Welcome.php?app_title=&app_note=&app_duration=&app_remind_before=&app_remind_before_hour=&app_remind_mail=&list_friend_id=&list_group_id=\"> system calendar</a><br>";

			echo "<img src=\"Client/Images/sch_dayline.gif\" width=\"12\" height=\"12\"><a href=\"./index.php?logout=true\"> logout</a><br>";

		}

		else

			$member = "fail";

	}

	if ($member!="true") {

		echo "

				  <table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">

					 <tr> 

						<td>

						  <font color=\"#003399\" size=\"1\" face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\">

						  User name :<br>

						  <input type=\"text\" name=\"loginUser\" size=\"12\"><br>

						  Password :<br>

						  <input type=\"password\" name=\"passwordUser\" size=\"12\">

						  </font>

						</td>

					 </tr>

					 <tr> 

						<td><a href=\"./Client/Member/Mem_register1.php\"><font color=\"#FF0000\" size=\"2\">��Ѥ���Ҫԡ����</font></a><br>&nbsp;</td>

					 </tr>

					 <tr> 

						<td> 

						  <font color=\"##003399\" size=\"1\" face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\">

						  <input type=\"submit\" name=\"Submit\" value=\"Submit\">

						  <input type=\"reset\" name=\"Reset\" value=\"Reset\">

						  </font>

						</td>

					 </tr>

				  </table>

				";

	}

	echo "</font>";	

?>
                  </td>
                </tr>
              </table>
            </form></td>
          <td valign="top" height="7" width="1%" background="image/my/3/bg7.jpg">&nbsp;</td>
          <td valign="top" height="7" colspan="3"> <table width="100%" border="0" cellspacing="3" cellpadding="0">
              <tr> 
                <td height="13" background="image/my/head_bg.jpg" bgcolor="#999999"><b><font size="3" face="Microsoft Sans Serif, MS Sans Serif, sans-serif">Welcome</font></b></td>
              </tr>
              <tr> 
                <td> <blockquote>
                    <p><font color="#FF0000" size="2" face="MS Sans Serif, CordiaUPC, AngsanaUPC"><br>
                      �Թ�յ�͹�Ѻ�������к���ԷԹ�Ѵ�����͹�Ź� (Appointment 
                      and Schedule Services)</font><font color="#330066" size="2" face="MS Sans Serif, CordiaUPC, AngsanaUPC"><br>
                      <br>
                      �к���ԷԹ�Ѵ�������к�������ѡɳТͧ��������ش�ѹ�֡�Ҽ�ǡ�Ѻ��������ö�ͧ෤����� 
                      �Թ������������������� �������ҧ����Է���Ҿ�ͧ��èѴ���ҧ�ҹ������� 
                      � ��� �� �ա����͹�ҹ�ͧ������ҹ�ҧ��-����ѧ��������Ҽ�����������ǹ� 
                      � �ͧ����š ���������ö��Һ�Ѻ��Һ�֧�ҹ��ҧ � ��赹��ͧ���� 
                      ,��������ö㹡�ùѴ���«�觷�����ùѴ���ºؤ�ŵ�ҧ � ��к�����觷���������Ǵ���Ǣ��<br>
                      </font><font face="MS Sans Serif, CordiaUPC, AngsanaUPC" size="2"><font color="#330066">���ԭ��Ѥ��������Ҫԡ�ͧ�к������Ѻ�Է�Ծ����������ԡ�õ�ҧ� 
                      ����¤�Ѻ<br>
                      <br>
                      </font> </font></p>
                  </blockquote></td>
              </tr>
              <tr> 
                <td height="15" background="image/my/head_whatnews2.jpg" bgcolor="#999999"><b><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif">What's 
                  new</font></b></td>
              </tr>
              <tr> 
                <td><blockquote> 
                    <p><br>
                      <font size="2" face="MS Sans Serif, Tahoma, sans-serif">��������ǡѺ����� 
                      Linux ������ö�Ѳ�� .NET Application �������к���Ժѵԡ�� 
                      Linux ���� Unix ���� ���ǹ����� update ���ǵ�����س� 
                      ��Դ����ѹ��Ѻ ���硷����ҡ��� Mono ����ͧ ����ç�˭�ͧ���硹����� 
                      ����ѷ���Ѳ�����硪��� Ximian <br>
                      �Ҵ�ѹ������� Mono ����Ҩ���ҹ�����㹻�˹�� �¹ѡ�Ѳ������ö���оѲ�� 
                      software ������ .NET Application �ҹ���Ѻ���Ժѵԡ�� Linux 
                      �͡�ҡ����� Mono ���鼹ǡ C# ��ҡѺ�ش��þѲ�Ңͧ Gnome 
                      ��������ôҹѡ�Ѳ������ö���оѲ�� .NET Application �����ҧ�١��ͧ���� 
                      ... <br>
                      10 ��.�. 2003 | <a href="News.php">��ҹ���...</a><br>
                      <br>
                      </font></p>
                  </blockquote></td>
              </tr>
              <tr> 
                <td background="image/my/head_bg.jpg" bgcolor="#999999"><b><font face="Microsoft Sans Serif, MS Sans Serif, sans-serif">Top 
                  10</font></b></td>
              </tr>
              <tr> 
                <td> 
                  <?

	$sql = "select art_id,art_name,abstract,location,last_update,num_reader,p1.col_id,template from article p1,col p2 where p1.col_id=p2.col_id and art_status='A' order by num_reader desc";

	$SQLresult = mysql_db_query($dbName,$sql);

   $num = mysql_num_rows($SQLresult);

   if ($num) {

      for ($i=1;$i<=$num && $i<=10;$i++) {

			$row = mysql_fetch_array($SQLresult);

			echo "<font face=\"MS Sans Serif, CordiaUPC, AngsanaUPC\" size=\"2\">$i. <a href=\"./document/template/$row[template]?template=$row[template]&location=$row[location]&name=index.html&article_id=$row[art_id]&id_col=$row[col_id]\">$row[art_name]</a> ($row[num_reader])</front><br>";

		}

	}

?>
                  &nbsp;</td>
              </tr>
            </table></td>
        </tr>
        <tr> 
          <td height="5" colspan="6" valign="top"><div align="center"><a href="mailto:juthakiat@yahoo.com"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Contract 
              Webmaster</font></a></div></td>
        </tr>
      </table></td>
  </tr>
</table>

</body>

</html>

