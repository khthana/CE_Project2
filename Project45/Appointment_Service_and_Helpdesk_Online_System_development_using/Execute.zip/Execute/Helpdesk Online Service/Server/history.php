<?
	require_once ("../NuSoft/nusoap.php");

//***************************************************************************************************************************************************
	$s = new soap_server;

	$s->register('history');
	function history($mem_username) 
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);
		$status = $memstatus["MemberStatus"];

		$sql = 'select distinct QuestionID from ask where mem_username = "'.$mem_username.'"';
		$askresult = mysql_db_query($dbname,$sql);
		$num_q = mysql_num_rows($askresult);

		$arr['status'] = $status;							$arr['num_q'] = $num_q;

		return $arr;
	}
//***************************************************************************************************************************************************
	$s->register('qresult');
	function qresult($mem_username,$goto)
	{
		require_once('dbconnect.inc');
		$sql = "select distinct questions.QuestionID,Subject,AskDate from questions,ask where questions.QuestionID=ask.QuestionID and ask.mem_username = '$mem_username' order by AskDate desc limit $goto,10";
		$result = mysql_db_query($dbname,$sql);
		$arrQ['num'] = mysql_num_rows($result);

		for ($i=0;$i<$arrQ['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$arrQ[$arrNum]['QuestionID'] = $arr[$arrNum]['QuestionID'];
			$arrQ[$arrNum]['Subject'] = $arr[$arrNum]['Subject'];
			$arrQ[$arrNum]['AskDate'] = $arr[$arrNum]['AskDate'];
		}
		return $arrQ;
	}
//****************************************************************************************************************
	$s->register('num');
	function num($mem_username,$QID) 
	{
		require_once('dbconnect.inc');
		$sql = 'select QuestionID from ask where mem_username = "'.$mem_username.'" and AnsStatus = "Y" and QuestionID= '.$QID;
		$result = mysql_db_query($dbname,$sql);
		$num_a = mysql_num_rows($result);

		$sql = 'select QuestionID from ask where mem_username = "'.$mem_username.'" and QuestionID= '.$QID;
		$result = mysql_db_query($dbname,$sql);
		$num_q = mysql_num_rows($result);
		
		$arr['num_q'] = $num_q;							$arr['num_a'] = $num_a;

		return $arr;
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>