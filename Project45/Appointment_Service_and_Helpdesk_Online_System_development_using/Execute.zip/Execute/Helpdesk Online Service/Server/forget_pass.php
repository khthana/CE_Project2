<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('sendMail');
	function sendMail($email)
	{
			require_once('dbconnect.inc');
			require_once('mime_mail.inc');
			require_once('smtp_mail.inc');

			$sql = "select * from member where Email = '$email'";
			$result = mysql_db_query($dbname,$sql);	
			$nrow = mysql_num_rows($result);
			if ($nrow == 0)
			{
				$flag = 1;
			} else 
			{
				$result_arr = mysql_fetch_array($result);
				$mto = $result_arr["Email"];
				$newpass = "";
				for ($i=0; $i<8;$i++)
				{
					$tmp = rand(48,122);
					$newpass .= chr($tmp);
				}
				$u_name = $result_arr["mem_username"];
				$sql = "update member set mem_password = '".md5($newpass)."' where mem_username = '".$u_name."'";
				$ch_pass = mysql_db_query($dbname,$sql);
				$msub = "Your Password at Helpdesk Online";
				$mmesg = "Your new password at Helpdesk Online \n";
				$mmesg .= 'Login Name = '.$result_arr["mem_username"]." \n";
				$mmesg .= 'Password = '.$newpass." \n";
				$mmesg .= "You can change this password by your self after login \n \n";
				$mmesg .= "Thanks \n";
				$mmesg .= "Helpdesk System \n";
				$from = "helpdesk@ce.kmitl.ac.th";

				$smtp_server = "diamond.ce.kmitl.ac.th";
				$mail = new mime_mail;
				$mail->from = $from;
				$mail->to = $mto;
				$mail->subject = $msub;
				$mail->body = $mmesg;
				$data = $mail->get_mail();
				$smtp = new smtp_mail;
				$smtp->send_email($smtp_server, $from, $mto, $data);
				$flag = 2;
			}
			return $flag;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>