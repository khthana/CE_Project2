<? 
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('searchsql');
	function searchsql ($CatID,$keyword,$cat,$day_ask1,$month_ask1,$year_ask1,$day_ask2,$month_ask2,$year_ask2,$last_ask,$day_ans1,$month_ans1,$year_ans1,$day_ans2,$month_ans2,$year_ans2,$last_ans,$subject,$question,$answer,$expert)
	{	
		$keyword = trim($keyword);
		if (!isset($cat))
		{ $cat=0;}
		if (!isset($day_ask1))
		{ $day_ask1=0;}
		if (!isset($month_ask1))
		{ $month_ask1=0;}
		if (!isset($year_ask1))
		{ $year_ask1=0;}
		if (!isset($last_ask))
		{ $last_ask=0;}
		if($day_ask1==99)
		{ $day_ask1= date("d");}
		if($month_ask1==99)
		{ $month_ask1= date("m");}
		if($year_ask1==99)
		{ $year_ask1= date("Y");}
		if (!isset($day_ask2))
		{ $day_ask2=0;}
		if (!isset($month_ask2))
		{ $month_ask2=0;}
		if (!isset($year_ask2))
		{ $year_ask2=0;}
		if($day_ask2==99)
		{ $day_ask2= date("d");}
		if($month_ask2==99)
		{ $month_ask2= date("m");}
		if($year_ask2==99)
		{ $year_ask2= date("Y");}
		if (!isset($day_ans1))
		{ $day_ans1=0;}
		if (!isset($month_ans1))
		{ $month_ans1=0;}
		if (!isset($year_ans1))
		{ $year_ans1=0;}
		if (!isset($last_ans))
		{ $last_ans=0;}
		if (!isset($day_ans2))
		if($day_ans1==99)
		{ $day_ans1= date("d");}
		if($month_ans1==99)
		{ $month_ans1= date("m");}
		if($year_ans1==99)
		{ $year_ans1= date("Y");}
		{ $day_ans2=0;}
		if (!isset($month_ans2))
		{ $month_ans2=0;}
		if (!isset($year_ans2))
		{ $year_ans2=0;}
		if($day_ans2==99)
		{ $day_ans2= date("d");}
		if($month_ans2==99)
		{ $month_ans2= date("m");}
		if($year_ans2==99)
		{ $year_ans2= date("Y");}
		if (!isset($subject))
		{ $subject="or";}
		if (!isset($question))
		{ $question="or";}
		if (!isset($answer))
		{ $answer="or";}
		if (!isset($expert))
		{ 
			$expert = "";
		}else
		{
			$expert = trim($expert);
		}
		$searchsql = "select distinct Q.QuestionID, Subject , ask.mem_username, AskDate ";
		if ($expert != "")
		{
			$searchsql .=" ,ask.ExpertName,AnswerDate ";
		}
		$searchsql .= " from questions Q, ans,ask where ";
		$searchsql .= "Q.QuestionID = ask.QuestionID and ask.QuestionID = ans.QuestionID ";
		if ($expert != "")
		{
			$searchsql .=" and ask.ExpertName=ans.mem_username ";
		}
		if ($keyword <>"") 
		{
			if( $subject == "and" or $question == "and" or $answer == "and")
			{
				if ($subject =="and")
				{
					$searchsql .= "and Subject like '%$keyword%' ";
				}
				if ($question =="and")
				{
					$searchsql .= "and Question like '%$keyword%' ";
				}
				if ($answer =="and")
				{
					$searchsql .= "and Answer like '%$keyword%' ";
				}		
			}else
			{
				$searchsql .= "and (Subject like '%$keyword%' or  Answer like '%$keyword%' or Question like '%$keyword%') ";
			}
		}//end if $keyword <>""

				if ($last_ask != 0)
		{			
			$day = date("d");
			$month = date("m");
			$year = date("Y");

			$jd = gregoriantojd($month,$day,$year); 	
			$ask = $jd-$last_ask;
			$gregorian = JDToGregorian ($ask);
			$chk_month = substr($gregorian,0,2);
			if (strpos($chk_month,'/'))
			{	
				$month = substr($gregorian,0,1);				
				$chk_day = substr($gregorian,2,2);		
				if (strpos($chk_day,'/'))
				{
					$day = substr($gregorian,2,1);
					$year = substr($gregorian,4,4);				
				}
				else
				{
					$day = $chk_day;
					$year = substr($gregorian,5,4);
				}
			} else 
			{
				$month = $chk_month;
				$chk_day = substr($gregorian,3,2);		
				if (strpos($chk_day,'/'))
				{
					$day = substr($gregorian,3,1);
					$year = substr($gregorian,5,4);				
				}
				else
				{
					$day = $chk_day;
					$year = substr($gregorian,6,4);
				}				
			}
			$askdate1 = "$year-$month-$day 00:00:00";
			$searchsql .= "and AskDate >= '$askdate1' ";
			$today = date("Y-m-d");
			$askdate2 = "$today 00:00:00";
			$searchsql .= "and AskDate <= '$askdate2' ";
		}
		else
		{
			if ($day_ask1!= 0 and $month_ask1!= 0 and $year_ask1!= 0)
			{
				$askdate1 = "$year_ask1-$month_ask1-$day_ask1 00:00:00";
				$searchsql .= "and AskDate >= '$askdate1' ";
			}
			if ($day_ask2!= 0 and $month_ask2!= 0 and $year_ask2!= 0)
			{				
				$askdate2 = "$year_ask2-$month_ask2-$day_ask2 00:00:00";
				$searchsql .= "and AskDate <= '$askdate2' ";
			}
		}	
		

		if ($last_ans != 0)
		{
			$day = date("d");
			$month = date("m");
			$year = date("Y");
			$today = date("m-d-Y");

			$jd = gregoriantojd($month,$day,$year); 	
			$ans = $jd-$last_ans;
			$gregorian = JDToGregorian ($ans);
			$chk_month = substr($gregorian,0,2);
			if (strpos($chk_month,'/'))
			{	
				$month = substr($gregorian,0,1);				
				$chk_day = substr($gregorian,2,2);		
				if (strpos($chk_day,'/'))
				{
					$day = substr($gregorian,2,1);
					$year = substr($gregorian,4,4);				
				}
				else
				{
					$day = $chk_day;
					$year = substr($gregorian,5,4);
				}
			} else 
			{
				$month = $chk_month;
				$chk_day = substr($gregorian,3,2);		
				if (strpos($chk_day,'/'))
				{
					$day = substr($gregorian,3,1);
					$year = substr($gregorian,5,4);				
				}
				else
				{
					$day = $chk_day;
					$year = substr($gregorian,6,4);
				}
				$ansdate1 = "$year-$month-$day 00:00:00";
				$searchsql .= "and AnswerDate >=  '$ansdate1' ";
				$today = date("Y-m-d");
				$ansdate2 = "$today 00:00:00";
				$searchsql .= "and AnswerDate <=  '$ansdate2' ";
			}	
		}
		else
		{
			if ($day_ans1!= 0 and $month_ans1!= 0 and $year_ans1!= 0)
			{
				$ansdate1 = "$year_ans1-$month_ans1-$day_ans1 00:00:00";
				$searchsql .= "and AnswerDate >=  '$ansdate1' ";
			}
			if ($day_ans2!= 0 and $month_ans2!= 0 and $year_ans2!= 0)
			{
				$ansdate2 = "$year_ans2-$month_ans2-$day_ans2 00:00:00";
				$searchsql .= "and AnswerDate <=  '$ansdate2' ";
			}
		}		

		if ($expert != "")
		{
			$searchsql .= "and ExpertName like '%$expert%'";
		}
		if ($cat != 0)
		{
			$searchsql .= "and CatID = '$cat'";
		}
		return $searchsql;
	}
//***************************************************************************************************************************************************
	$s->register('numsearch');
	function numsearch ($searchsql)
	{	
		require_once('dbconnect.inc');
		$searchresult = mysql_db_query($dbname,$searchsql);
		$numsearch = mysql_num_rows($searchresult);
		return $numsearch;
	}
//***************************************************************************************************************************************************
	$s->register('searchNext');
	function searchNext ($searchsql,$goto)
	{	
		require_once('dbconnect.inc');
		$searchsql .= " order by Q.QuestionID  limit $goto,10";
		$searchresult = mysql_db_query($dbname,$searchsql);
		$arrResult['num'] = mysql_num_rows($searchresult);

		for ($i=0;$i<$arrResult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($searchresult);
			$arrResult[$arrNum][0] = $arr[$arrNum][0];
			$arrResult[$arrNum][1] = $arr[$arrNum][1];
			$arrResult[$arrNum][2] = $arr[$arrNum][2];
			$arrResult[$arrNum][3] = $arr[$arrNum][3];
		}		
		return $arrResult;
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>			