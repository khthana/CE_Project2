<? 
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('numParent');
	function numParent($CatID)
	{
		require_once('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID= '$CatID'";
		$result = mysql_db_query($dbname,$sql);
		$nrow = mysql_num_rows($result);
		return $nrow;
	}
//****************************************************************************************************************
	$s->register('numExpert');
	function numExpert($CatID)
	{
		require_once('dbconnect.inc');
		$sql  = "select mem_username from expertin where CatID = '$CatID' ";
		$rateresult = mysql_db_query($dbname,$sql);
		$numexpert = mysql_num_rows($rateresult);
		return $numexpert;
	}
//****************************************************************************************************************
	$s->register('allresult');
	function allresult($count,$CatID,$used)
	{
		require_once('dbconnect.inc');
		if ($count == 0)
		{			
			$sql = "select mem_username,Rate from expertin  where CatID = '$CatID' order by mem_username";	
		} else
		{
			$sql = "select mem_username,Rate from expertin where CatID = '$CatID' and mem_username not in ( ".$used.") order by mem_username";			
		}
		$allresult = mysql_db_query($dbname,$sql);
		$arrResult['num'] = mysql_num_rows($allresult);
		for ($i=0;$i<$arrResult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($allresult);
			$arrResult[$arrNum][0] = $arr[$arrNum][0];
			$arrResult[$arrNum][1] = $arr[$arrNum][1];
		}
		return $arrResult;
	}
//****************************************************************************************************************
	$s->register('NumVote');
	function NumVote($CatID,$compare)
	{
		require_once('dbconnect.inc');
		$sql = "select NumVote  from expertin where CatID= '$CatID' and mem_username = '$compare'";
		$result = mysql_db_query($dbname,$sql);		
		$num = mysql_fetch_array($result);
		$numask[0] = $num[0];
		return $numask;		
	}
//****************************************************************************************************************
	$s->register('numQ');
	function numQ($CatID)
	{
		require_once('dbconnect.inc');
		$sql = "select  distinct questions.QuestionID,Subject,Question,AskDate,mem_username from questions,ask where questions.CatID = '$CatID' and questions.QuestionID=ask.QuestionID  order by questions.QuestionID DESC";
		$result = mysql_db_query($dbname,$sql);		
		$num = mysql_num_rows($result);
		return $num;		
	}
//****************************************************************************************************************
	$s->register('allQ');
	function allQ($CatID,$goto)
	{
		require_once('dbconnect.inc');
		$sql1 = "select  distinct questions.QuestionID,Subject,Question,AskDate,mem_username from questions,ask where questions.CatID = '$CatID' and questions.QuestionID=ask.QuestionID  order by questions.QuestionID DESC limit $goto,10 ";
		$result1 = mysql_db_query($dbname,$sql1);
		$allQ['num'] = mysql_num_rows($result1);

		for ($i=0;$i<$allQ['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result1);
			$allQ[$arrNum][0] = $arr[$arrNum][0];
			$allQ[$arrNum][1] = $arr[$arrNum][1];
			$allQ[$arrNum][2] = $arr[$arrNum][2];
			$allQ[$arrNum][3] = $arr[$arrNum][3];
			$allQ[$arrNum][4] = $arr[$arrNum][4];
		}
		return $allQ;
	}
//****************************************************************************************************************
	$s->register('countASK');
	function countASK($QID)
	{
		require_once('dbconnect.inc');
		$sql2 = "select count(*) from ask where QuestionID = '$QID' and AnsStatus = 'Y' ";
		$result2 = mysql_db_query($dbname,$sql2);
		$count = mysql_fetch_array($result2);
		$result2arr = $count[0];
		return $result2arr;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>