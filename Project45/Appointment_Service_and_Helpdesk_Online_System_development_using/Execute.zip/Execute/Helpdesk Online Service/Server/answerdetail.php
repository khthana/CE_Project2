<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('allQ');
	function allQ($CatID,$QuestionID) 
	{
		require_once('dbconnect.inc');
		$sql1 = "select distinct Subject,Question,Askdate,mem_username from questions,ask where CatID = '$CatID' and questions.QuestionID = $QuestionID and questions.QuestionID = ask.QuestionID";
		$result1 = mysql_db_query($dbname,$sql1);
		$arr = mysql_fetch_array($result1);
		$result1arr[0] = $arr[0];						$result1arr[1] = $arr[1];
		$result1arr[2] = $arr[2];						$result1arr[3] = $arr[3];

		return	$result1arr;
	}	// end function
//***************************************************************************************************************************************************
	$s->register('result2');
	function result2($QuestionID) 
	{
			require_once('dbconnect.inc');
			$sql2 = " select count(*) from ask where QuestionID = '$QuestionID' and AnsStatus = 'Y'";
			$result2 = mysql_db_query($dbname,$sql2);
		return	$result2;
	}	// end function
//***************************************************************************************************************************************************
	$s->register('allAns');
	function allAns($mem_username,$QuestionID) 
	{
		require_once('dbconnect.inc');
		$sql3 = "select * from ans where QuestionID = '$QuestionID' and mem_username = '$mem_username' order by AnswerDate";
		$result3 = mysql_db_query($dbname,$sql3);
		$arr3 = mysql_fetch_array($result3);
		$result3arr[0] = $arr3[0];							$result3arr[1] = $arr3[1];
		$result3arr[2] = $arr3[2];							$result3arr[3] = $arr3[3];
		return	$result3arr;
	}	// end function
//****************************************************************************************************************************************************
	

	$s->service($HTTP_RAW_POST_DATA);
?>