<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('showAsk');
	function showAsk($QID)
	{
			require_once('dbconnect.inc');
			$sql = "select Subject,Question,AskDate,mem_username from ask,questions  where questions.QuestionID = ask.QuestionID and questions.QuestionID = '$QID'";
			$showresult = mysql_db_query($dbname,$sql);
			$arry = mysql_fetch_array($showresult);
			$showarry['Subject'] = $arry['Subject'];						$showarry['Question'] = $arry['Question'];
			$showarry['AskDate'] = $arry['AskDate'];						$showarry['mem_username'] = $arry['mem_username'];
			return $showarry;
	}
//***************************************************************************************************************************************************		
	$s->register('showAns');
	function showAns($ename,$QID)
	{
		require_once('dbconnect.inc');
		$sql = "select mem_username, AnswerDate,Answer  from ANS,questions  where questions.QuestionID = ANS.QuestionID and questions.QuestionID = '$QID'";
		if ($ename !="")
		{ $sql .= "and mem_username = '$ename'"; }
		$result = mysql_db_query($dbname,$sql);
		$showresult['num'] = mysql_num_rows($result);

		for ($i=0;$i<$showresult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$showresult[$arrNum]['mem_username'] = $arr[$arrNum]['mem_username'];
			$showresult[$arrNum]['AnswerDate'] = $arr[$arrNum]['AnswerDate'];
			$showresult[$arrNum]['Answer'] = $arr[$arrNum]['Answer'];
		}		
			return $showresult;
	}
//***************************************************************************************************************************************************		

	$s->service($HTTP_RAW_POST_DATA);
?>