<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('addinf_n1');
	function addinf_n1($mem_username,$QID,$EName)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);
		$status = $memstatus["MemberStatus"];

		$sql = "select Subject,Question,AskDate,AnswerDate,Answer,mem_username,CatID  from ans,questions  where questions.QuestionID = ans.QuestionID and questions.QuestionID = '$QID' and mem_username = '$EName'";
		$showresult = mysql_db_query($dbname,$sql);
		$arry = mysql_fetch_array($showresult);		
		$showarry['Subject'] = $arry['Subject'];							$showarry['Question'] = $arry['Question'];
		$showarry['AskDate'] = $arry['AskDate'];						$showarry['AnswerDate'] = $arry['AnswerDate'];
		$showarry['Answer'] = $arry['Answer'];						$showarry['mem_username'] = $arry['mem_username'];
		$showarry['CatID'] = $arry['CatID'];	

		 $arr1['status']= $status;					$arr1['showarry']= $showarry;
		 
		return $arr1;
	}	// end function
//***************************************************************************************************************************************************
	$s->register('addinf_n');
	function addinf_n($mem_username,$Subject,$Question,$QID,$EName) 
	{
		require_once('dbconnect.inc');
		require_once('mime_mail.inc');
		require_once('smtp_mail.inc');
		$bansql = "select * from banword";
		$banresult = mysql_db_query($dbname,$bansql);
		$bannum = mysql_num_rows($banresult);
		if ($bannum != 0)
		{
			$ban_i = 0;
			$place = "";
			$Subject = " $Subject";
			$Question = " $Question";
			while ($banarry = mysql_fetch_array($banresult))
			{
				$found2 = strpos($Question,$banarry['Word'],0);
				if ($found2)
				{
					$ban[$ban_i] = $banarry['Word'];
					$ban_i = $ban_i +1;
					$Flag03 = "F3";
				}
			} // end while ban
			$Question = trim($Question);
		} //end if ban num !=0
		if($Flag03 != "F3")
		{
			$Question = trim($Question);
			$sql=" update questions set Question = '$Question' where QuestionID = '$QID' ";
			$result = mysql_db_query($dbname,$sql);
			$sql = "update ask set AnsStatus='N' , ViewStatus='N' , EditStatus='A'  where QuestionID = '$QID' and ExpertName = '$EName' and mem_username = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$sql = "select Email from member where mem_username = '$EName'";
			$result = mysql_db_query($dbname,$sql);
			$expertemail = mysql_fetch_array($result);
			$to = $expertemail[0];
			$subject = "Get an added information question.";
			$sql = "select Subject,AskDate  from questions  where QuestionID = '$QID'";
			$result = mysql_db_query($dbname,$sql);
			$qresult = mysql_fetch_array($result);
			$mmesg = $mem_username." has added information of question about ";
			$mmesg .= '"'.$qresult[0].'"'." that asked on ";
			$mmesg .= $qresult[1]." \n\n";
			$mmesg .= "Thanks \n";
			$mmesg .= "Helpdesk System \n";			
			$from = "helpdesk@ce.kmitl.ac.th\n";

			$smtp_server = "diamond.ce.kmitl.ac.th";
			$mail = new mime_mail;
			$mail->from = $from;
			$mail->to = $mto;
			$mail->subject = $subject;
			$mail->body = $mmesg;

			# get the constructed e-mail data
			$data = $mail->get_mail();

			# create smtp_mail instance
			$smtp = new smtp_mail;

			# send e-mail
			$smtp->send_email($smtp_server, $from, $mto, $data);
		}
		$arr['Flag03']= $Flag03;
		$arr['ban_i']= $ban_i;					$arr['ban']= $ban;

		return	$arr;
	}	// end function
//***************************************************************************************************************************************************
	$s->register('updateAsk');
	function updateAsk($QID,$EName)
	{
		require_once('dbconnect.inc');
		$sql = "update ask set ViewStatus='Y' where QuestionID='$QID' and ExpertName='$EName'";
		$result = mysql_db_query($dbname,$sql);
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);	
