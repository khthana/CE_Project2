<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;
//****************************************************************************************************************	
	$s->register('chkEmail');
	function chkEmail($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select mem_username from member where Email = '$email' and mem_username <> '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$nrow = mysql_num_rows($result);
		return $nrow;
	}
//****************************************************************************************************************
	$s->register('chkBan');
	function chkBan($mem_username)
	{
		require_once('dbconnect.inc');
		$bansql = "select * from banword";
		$banresult = mysql_db_query($dbname,$bansql);
		$bannum = mysql_num_rows($banresult);
		if ($bannum != 0)
		{
			$detail = " $detail";
			while ($banarry = mysql_fetch_array($banresult))
			{
				$found1 = strpos($detail,$banarry['Word'],0);
					if($found1)
				{
					return "F";
				}
			} // end while ban
		} //end if ban num !=0
		return "T";
	}
//****************************************************************************************************************
	$s->register('insertpic');
	function insertpic($mem_username,$data)
	{
		require_once('dbconnect.inc');		
  		$sql = "update member set Picture='$data'  where mem_username= '$mem_username'";
		$result = mysql_db_query($dbname,$sql);		
	}
//***************************************************************************************************************************************************
	$s->register('oldPic');
	function oldPic($mem_username)
	{
		require_once('dbconnect.inc');
  		$sql = "select Picture  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$file = mysql_fetch_array($result);
		$filename = $file['Picture'];
		return $filename;
	}
//***************************************************************************************************************************************************
	$s->register('updatePWD');
	function updatePWD($mem_password,$firstname,$lastname,$email,$Link,$detail,$mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select mem_password from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$oldpass = mysql_fetch_array($result);
		$enterpass = substr($mem_password,0,10);$arr[enterpass]=$enterpass;
		$oldpass = substr($oldpass[0],0,10);$arr[oldpass]=$oldpass;
		
		if ($oldpass != $enterpass)
		{
		$sql1 = "update member set mem_password = '$mem_password' , FirstName = '$firstname', LastName = '$lastname' , Email = '$email' , Link = '$Link' , Detail = '$detail' where mem_username= '$mem_username'";
		}else
		{
			$sql1 = "update member set FirstName = '$firstname', LastName = '$lastname' , Email = '$email' , Link = '$Link' ,Detail = '$detail' where mem_username= '$mem_username'";
		}
			$result = mysql_db_query($dbname,$sql1);
	}
//***************************************************************************************************************************************************
	$s->register('status');
	function status($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '".$mem_username."'";
		$result = mysql_db_query($dbname,$sql);
		$mstatus = mysql_fetch_array($result);
		$status = $mstatus[0];
		return $status;
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>