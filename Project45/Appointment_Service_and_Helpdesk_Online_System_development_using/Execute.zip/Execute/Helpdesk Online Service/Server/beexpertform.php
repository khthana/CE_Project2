<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;
	$s->register('beExpert');
	function beExpert($mem_username,$mem_password,$Pwd,$FirstName,$LastName,$Email,$Link,$detail,$subdate)
	{
		require_once('dbconnect.inc');
		require_once('mime_mail.inc');
		require_once('smtp_mail.inc');

		$mem_username = trim($mem_username);
		$mem_password = trim($mem_password );
		$Pwd = trim($Pwd );
		$FirstName = trim($FirstName);
		$LastName = trim($LastName);
		$Email = trim($Email);
		$Link = trim($Link);
		$mem_username=strtolower($mem_username);
		$sql = "select mem_username from 	member where mem_username = '$mem_username' ";
		$result = mysql_db_query($dbname,$sql);
		$nrow = mysql_num_rows($result);
		if ($mem_username == "")
		{
			$flag01 = 'T0';
		}elseif ($nrow != 0 )
		{ 
			$flag01 = 'T1';
		}elseif ($mem_password != $Pwd)
		{
			$flag01 = 'T2';
		}elseif (strlen($mem_password) < 6)
		{
			$flag01 = 'T5';
		} elseif ($Email == "")
		{
			$flag01 = 'T4';
		}else
		{
			$sql = "select mem_username from member where Email = '$Email' ";
			$result = mysql_db_query($dbname,$sql);
			$nrow = mysql_num_rows($result);
			if ($nrow != 0 )
			{ 
				$flag01 = 'T3';
			} else
			{
				$bansql = "select * from banword";
				$banresult = mysql_db_query($dbname,$bansql);
				$bannum = mysql_num_rows($banresult);
				if ($bannum != 0)
				{
					$ban_i = 0;
					$place = "";
					$mem_username = " $mem_username";
					$detail = " $detail";
					while ($banarry = mysql_fetch_array($banresult))
					{
						$found1 = strpos($mem_username,$banarry['Word'],0);
						if ($found1)
						{
							$ban[$ban_i] = $banarry['Word'];
							$ban_i = $ban_i +1;
							$Flag03 = "F3";
							if ($place=="")
							{
								$place = "Login Name";
							}elseif($place=="����ѵ���ǹ���")
							{
								$place = "Login Name ��� ����ѵ���ǹ���";
							}
						}
						$found2 = strpos($detail,$banarry['Word'],0);
						if ($found2)
						{
							if (!$found1)
							{
								$ban[$ban_i] = $banarry['Word'];
								$ban_i = $ban_i +1;
							}
							$Flag03 = "F3";
							if ($place=="")
							{
								$place = "����ѵ���ǹ���";
							}elseif($place=="Login Name")
							{
								$place = "Login Name ��� ����ѵ���ǹ���";
							}
						}
					} // end while ban
					$mem_username = trim($mem_username);
					$detail = trim($detail);
					$flag01 = 'T';
				} //end if ban num !=0
	
				if($Flag03 != "F3")
				{
					$sql=" insert into member  (mem_username,mem_password,FirstName,LastName,Email,Link,Detail,MemberStatus,SubDate) 
					values ('$mem_username','$mem_password','$FirstName','$LastName','$Email','$Link','$detail','E','$subdate')";
					$result = mysql_db_query($dbname,$sql);
					
					$mem_username=$mem_username;
					$mto = $Email;
					$msub ="Welcome to CE- Helpdesk";
					$mmesg = "Welcome $mem_username\n";
					$mmesg .=  "Thanks that  you have registered to be an expert at helpdesk online. \n";
					$mmesg .= "You will receive E- mail from helpdesk system when you get new questions or answers  \n\n";
					$mmesg .= "Thanks \n";
					$mmesg .= "Helpdesk System \n";
					$from = "helpdesk@ce.kmitl.ac.th";

					$smtp_server = "diamond.ce.kmitl.ac.th";
					$mail = new mime_mail;
					$mail->from = $from;
					$mail->to = $mto;
					$mail->subject = $msub;
					$mail->body = $mmesg;
					$data = $mail->get_mail();
					$smtp = new smtp_mail;
					$smtp->send_email($smtp_server, $from, $mto, $data);
				}			//	End Flag03
		}		
	}
	$arr['flag01'] = $flag01;					$arr['Flag03']= $Flag03;
	$arr['ban_i']= $ban_i;						$arr['ban']= $ban;
	$arr['place']= $place;	

	return $arr;
}
//****************************************************************************************************************
	$s->register('insertpic');
	function insertpic($mem_username,$data)
	{
		require_once('dbconnect.inc');		
  		$sql = "update member set Picture='$data'  where mem_username= '$mem_username'";
		$result = mysql_db_query($dbname,$sql);		
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>