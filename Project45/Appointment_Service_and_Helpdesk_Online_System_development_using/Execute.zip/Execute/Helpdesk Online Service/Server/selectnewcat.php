<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('selectnewcat');
	function selectnewcat($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);

		$arr['status'] = $memstatus["MemberStatus"];

		$sql = "select CatID,CatName from category where ParentID= '0'";
		$mainresult = mysql_db_query($dbname,$sql);
		$arr['nrow'] = mysql_num_rows($mainresult);
		for ($i=0;$i<$arr['nrow'];$i++)
		{
			$main = 'main'.$i;
			$arr[$main] = mysql_fetch_array($mainresult);			
		}
//		$arr['main'] = $main;
		$arr['CatID'] = $main['CatID'];
		
		return $arr;
	}
//****************************************************************************************************************

	$s->register('have_sub');
	function have_sub ($parentid)
	{	
		require_once('dbconnect.inc');
		$sql = "select count(*) as num from category where ParentID=$parentid";
		$result = mysql_db_query($dbname,$sql );
		$num = mysql_result($result,0,"num");
		return $num;
	}

//****************************************************************************************************************
	$s->register('exnum');
	function exnum ($catid,$mem_username)
	{	
		include('dbconnect.inc');
		$exsql = "select CatID from expertin where CatID='$catid' and mem_username = '$mem_username'";
		$exresult = mysql_db_query($dbname,$exsql );
		$exnum = mysql_num_rows($exresult);
		return $exnum;
	}
//****************************************************************************************************************
	$s->register('result_CatID_Name');
	function result_CatID_Name ($mid)
	{	
		include('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID=$mid";
		$result = mysql_db_query($dbname,$sql);
		return $exnum;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>  