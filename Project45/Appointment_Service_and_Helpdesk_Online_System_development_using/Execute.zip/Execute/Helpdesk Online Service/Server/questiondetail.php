<? 
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('allQ');
	function allQ($CatID,$QuestionID)
	{
		require_once('dbconnect.inc');
		$sql1 = "select distinct Subject,Question,Askdate,mem_username from questions,ask where CatID = '$CatID' and questions.QuestionID = $QuestionID and questions.QuestionID = ask.QuestionID";
		$result1 = mysql_db_query($dbname,$sql1);
		$arr = mysql_fetch_array($result1);
		$result1arr[0] = $arr[0];						$result1arr[1] = $arr[1];
		$result1arr[2] = $arr[2];						$result1arr[3] = $arr[3];

		return $result1arr;
	}
//****************************************************************************************************************
	$s->register('coutASK');
	function coutASK($QuestionID)
	{
		require_once('dbconnect.inc');
		$sql2 = " select count(*) from ask where QuestionID = '$QuestionID' and AnsStatus = 'Y'";
		$result2 = mysql_db_query($dbname,$sql2);
		$count2 = mysql_num_rows($result2);
		$result2arr = mysql_fetch_array($result2);

		$arr['count2'] = $count2;				$arr['result2arr'] = $result2arr;
		return $arr;
	}
//****************************************************************************************************************
	$s->register('allAns');
	function allAns($QuestionID)
	{
		require_once('dbconnect.inc');
		$sql3 = "select * from ans where QuestionID = '$QuestionID' order by AnswerDate";
		$result3 = mysql_db_query($dbname,$sql3);
		$arrAns['num'] = mysql_num_rows($result3);
		
		for ($i=0;$i<$arrAns['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result3);
			$arrAns[$arrNum][0] = $arr[$arrNum][0];
			$arrAns[$arrNum][1] = $arr[$arrNum][1];
			$arrAns[$arrNum][2] = $arr[$arrNum][2];
			$arrAns[$arrNum][3] = $arr[$arrNum][3];			
		}
//		$arrResult3['arrAns'] = $arrAns;

		return $arrAns;	
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>