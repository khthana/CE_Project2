<? 
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

	$s->register('pic');
	function pic($mem_username)
	{
		include('dbconnect.inc');
		$sql = "select Picture from  member where mem_username= '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$Pic = mysql_fetch_array($result);
		$Picname = $Pic[0];
		return $Picname;
	}

	$s->service($HTTP_RAW_POST_DATA);
?>

