<?
	require_once ("../NuSoft/nusoap.php");

//***************************************************************************************************************************************************
	$s = new soap_server;

	$s->register('historya');
	function historya($mem_username) 
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);
		$status = $memstatus["MemberStatus"];

		$sql = 'select distinct QuestionID from ask where mem_username = "'.$mem_username.'"';
		$askresult = mysql_db_query($dbname,$sql);
		$num_a = mysql_num_rows($askresult);

		$arr['status'] = $status;							$arr['num_a'] = $num_a;

		return $arr;
	}
//***************************************************************************************************************************************************
	$s->register('aresult');
	function aresult($mem_username,$goto)
	{
		require_once('dbconnect.inc');		
		$sql = "select distinct questions.QuestionID,Subject,AskDate,AnsStatus,EditStatus from questions,ask where questions.QuestionID=ask.QuestionID and ExpertName = '$mem_username' order by AskDate desc limit $goto,10";
		$result = mysql_db_query($dbname,$sql);
		$arrQ['num'] = mysql_num_rows($result);

		for ($i=0;$i<$arrQ['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$arrQ[$arrNum]['QuestionID'] = $arr[$arrNum]['QuestionID'];
			$arrQ[$arrNum]['Subject'] = $arr[$arrNum]['Subject'];
			$arrQ[$arrNum]['AskDate'] = $arr[$arrNum]['AskDate'];
			$arrQ[$arrNum]['AnsStatus'] = $arr[$arrNum]['AnsStatus'];
			$arrQ[$arrNum]['EditStatus'] = $arr[$arrNum]['EditStatus'];
		}
		return $arrQ;
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>	