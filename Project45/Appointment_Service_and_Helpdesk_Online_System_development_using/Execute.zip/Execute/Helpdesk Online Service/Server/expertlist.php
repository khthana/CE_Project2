<? 
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('NumVote');
	function NumVote($CatID,$compare)
	{
		include('dbconnect.inc');
		$sql = "select NumVote  from expertin where CatID= '$catID' and mem_username = '$compare'";
		$result = mysql_db_query($dbname,$sql);		
		$numask = mysql_fetch_array($result);
		return $numask;		
	}
//****************************************************************************************************************
	$s->register('numParent');
	function numParent($CatID)
	{
		require_once('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID= '$CatID'";
		$result = mysql_db_query($dbname,$sql);
		$nrow = mysql_num_rows($result);
		return $nrow;
	}
//****************************************************************************************************************
	$s->register('numExpert');
	function numExpert($CatID)
	{
		require_once('dbconnect.inc');
		$sql  = "select mem_username from expertin where CatID = '$CatID' ";
		$rateresult = mysql_db_query($dbname,$sql);
		$numexpert = mysql_num_rows($rateresult);
		return $numexpert;
	}
//****************************************************************************************************************
	$s->register('allresult');
	function allresult($CatID,$count,$used)
	{
		require_once('dbconnect.inc');
		if ($count == 0)
		{
			$sql = "select mem_username,Rate from expertin  where CatID = '$CatID' order by mem_username";	
		} else
		{
			$sql = "select mem_username,Rate from expertin where CatID = '$CatID' and mem_username not in ( ".$used.") order by mem_username";
		}
		$allresult = mysql_db_query($dbname,$sql);
		$arrResult['num'] = mysql_num_rows($allresult);
		for ($i=0;$i<$arrResult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($allresult);
			$arrResult[$arrNum][0] = $arr[$arrNum][0];
			$arrResult[$arrNum][1] = $arr[$arrNum][1];
		}
		return $arrResult;
	}
//****************************************************************************************************************
	$s->register('thisExpert');
	function thisExpert($CatID)
	{
		require_once('dbconnect.inc');		
		$sql = "select mem_username,CatID, Rate, NumVote, ResRate, NumRate, Rate/NumVote  from expertin where CatID = $CatID and NumVote <> 0 order by 7 desc , NumVote desc , mem_username";
		$result = mysql_db_query($dbname,$sql);		
		$arrExpert['num'] = mysql_num_rows($result);
		
		for ($i=0;$i<$arrExpert['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$arrExpert[$arrNum][0] = $arr[$arrNum][0];
			$arrExpert[$arrNum][1] = $arr[$arrNum][1];
			$arrExpert[$arrNum][2] = $arr[$arrNum][2];
			$arrExpert[$arrNum][3] = $arr[$arrNum][3];
			$arrExpert[$arrNum][4] = $arr[$arrNum][4];
			$arrExpert[$arrNum][5] = $arr[$arrNum][5];
			$arrExpert[$arrNum][6] = $arr[$arrNum][6];
		}
		return $arrExpert;	
	}
//****************************************************************************************************************
	$s->register('detailMem');
	function detailMem($x)
	{
		require_once('dbconnect.inc');
		$sql2 = "select Detail from member where mem_username = '$x' ";
		$result2 = mysql_db_query($dbname,$sql2);
		$arry = mysql_fetch_array($result2);
		$result2arr[0] = $arry[0];

		return $result2arr;
	}
//****************************************************************************************************************
	$s->register('thisExpert1');
	function thisExpert1($CatID)
	{
		require_once('dbconnect.inc');
		$sql1 = "select mem_username,CatID, Rate, NumVote, ResRate, NumRate, Rate/NumVote  from expertin where CatID = '$CatID' and NumVote = '0' order by mem_username";
		$result = mysql_db_query($dbname,$sql1);		
		$arrExpert['num'] = mysql_num_rows($result);
		
		for ($i=0;$i<$arrExpert['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$arrExpert[$arrNum][0] = $arr[$arrNum][0];
			$arrExpert[$arrNum][1] = $arr[$arrNum][1];
			$arrExpert[$arrNum][2] = $arr[$arrNum][2];
			$arrExpert[$arrNum][3] = $arr[$arrNum][3];
			$arrExpert[$arrNum][4] = $arr[$arrNum][4];
			$arrExpert[$arrNum][5] = $arr[$arrNum][5];
			$arrExpert[$arrNum][6] = $arr[$arrNum][6];
		}
		return $arrExpert;	
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>          