<? 
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('NumVote');
	function NumVote($CatID,$compare)
	{
		require_once('dbconnect.inc');
		$sql = "select NumVote  from expertin where CatID= '$CatID' and mem_username = '$compare'";
		$result = mysql_db_query($dbname,$sql);		
		$num = mysql_fetch_array($result);
		$numask[0] = $num[0];
		return $numask;		
	}
//****************************************************************************************************************
	$s->register('numParent');
	function numParent($CatID)
	{
		require_once('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID= '$CatID'";
		$result = mysql_db_query($dbname,$sql);
		$nrow = mysql_num_rows($result);
		return $nrow;
	}
//****************************************************************************************************************
	$s->register('numExpert');
	function numExpert($CatID)
	{
		require_once('dbconnect.inc');
		$sql  = "select mem_username from expertin where CatID = '$CatID' ";
		$rateresult = mysql_db_query($dbname,$sql);
		$numexpert = mysql_num_rows($rateresult);
		return $numexpert;
	}
//****************************************************************************************************************
	$s->register('allresult');
	function allresult($count,$used)
	{
		require_once('dbconnect.inc');
		if ($count == 0)
		{
			$sql = "select mem_username,Rate from expertin  group by mem_username order by mem_username";	
		} else
		{
			$sql = "select mem_username,Rate from expertin where mem_username not in ( ".$used.") group by mem_username order by mem_username";			
		}
		$allresult = mysql_db_query($dbname,$sql);
		$arrResult['num'] = mysql_num_rows($allresult);
		for ($i=0;$i<$arrResult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($allresult);
			$arrResult[$arrNum][0] = $arr[$arrNum][0];
			$arrResult[$arrNum][1] = $arr[$arrNum][1];
		}
		return $arrResult;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>