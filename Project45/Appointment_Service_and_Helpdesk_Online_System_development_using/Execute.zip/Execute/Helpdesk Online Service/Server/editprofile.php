<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('resmember');
	function resmember($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select *  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$member = mysql_fetch_array($result);
		$resmember[mem_username] = $member[mem_username];			
		$resmember[FirstName] = $member[FirstName];								$resmember[LastName] = $member[LastName];
		$resmember[Email] = $member[Email];													$resmember[Detail] = $member[Detail];
		$resmember[Picture] = $member[Picture];												$resmember[Link] = $member[Link];
		$resmember[MemberStatus] = $member[MemberStatus];				$resmember[SubDate] = $member[SubDate];

		return $resmember;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>