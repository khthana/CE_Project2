<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('newStatus');
	function newStatus($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$status = mysql_fetch_array($result);
		$arr['mstatus'] = $status['MemberStatus'];
		
		$sql = 'select QuestionID,ExpertName,EditStatus  from ask where mem_username = "'.$mem_username.'" and AnsStatus="Y" and  ViewStatus = "N"';
		$askresult = mysql_db_query($dbname,$sql);
		$arr['num_new'] = mysql_num_rows($askresult);

		return $arr;
	}

//****************************************************************************************************************

	$s->register('askresult');
	function askresult($mem_username,$goto)
	{
		require_once('dbconnect.inc');
		$sql = "select questions.QuestionID,Subject,ExpertName,AskDate,EditStatus  from ask ,questions where mem_username = '$mem_username' and questions.QuestionID = ask.QuestionID and AnsStatus='Y' and  ViewStatus = 'N' order by AskDate desc limit $goto,10";
		$askresult = mysql_db_query($dbname,$sql);
		$askarry['num'] = mysql_num_rows($askresult);

		for ($i=0;$i<$askarry['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($askresult);
			$askarry[$arrNum]['QuestionID'] = $arr[$arrNum]['QuestionID'];
			$askarry[$arrNum]['Subject'] = $arr[$arrNum]['Subject'];
			$askarry[$arrNum]['AskDate'] = $arr[$arrNum]['AskDate'];
			$askarry[$arrNum]['ExpertName'] = $arr[$arrNum]['ExpertName'];
			$askarry[$arrNum]['EditStatus'] = $arr[$arrNum]['EditStatus'];
		}
		return $askarry;
	}
//****************************************************************************************************************

	$s->register('thisarry');
	function thisarry($expertthis)
	{
		require_once('dbconnect.inc');
		$thissql = "select avg(Rate) from expertin where mem_username = '$expertthis'";
		$thisresult = mysql_db_query($dbname,$thissql);
		$arry=mysql_fetch_array($thisresult);
		$thisarry = $arry[0];
		return $thisarry;
	}
//****************************************************************************************************************

$s->service($HTTP_RAW_POST_DATA);

?>          