<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;
	
	$s->register('showans');
	function showans($mem_username,$QID) 
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);
		$status = $memstatus["MemberStatus"];

		$sql = 'select QuestionID,ExpertName  from ask where mem_username = "'.$mem_username.'" and AnsStatus="Y" and QuestionID='.$QID;
		$askresult = mysql_db_query($dbname,$sql);
		$num_new = mysql_num_rows($askresult);

		$arr['status'] = $status;							$arr['num_new'] = $num_new;

		return $arr;
	}
//***************************************************************************************************************************************************
	$s->register('askresult');
	function askresult($mem_username,$QID,$goto)
	{
			require_once('dbconnect.inc');
			$sql = 'select questions.QuestionID,Subject,ExpertName,AskDate,EditStatus  from ask ,questions where mem_username = "'.$mem_username.'" and questions.QuestionID = ask.QuestionID and AnsStatus="Y" and ask.QuestionID='.$QID.' order by AskDate desc limit '.$goto.',10';
			$result = mysql_db_query($dbname,$sql);		
			$askresult['num'] = mysql_num_rows($result);

			for ($i=0;$i<$askresult['num'];$i++)
			{
				$arrNum = 'arrNum'.$i;
				$arr[$arrNum] = mysql_fetch_array($result);
				$askresult[$arrNum]['QuestionID'] = $arr[$arrNum]['QuestionID'];
				$askresult[$arrNum]['Subject'] = $arr[$arrNum]['Subject'];
				$askresult[$arrNum]['ExpertName'] = $arr[$arrNum]['ExpertName'];
				$askresult[$arrNum]['AskDate'] = $arr[$arrNum]['AskDate'];
				$askresult[$arrNum]['EditStatus'] = $arr[$arrNum]['EditStatus'];
			}
			return $askresult;
	}	
//***************************************************************************************************************************************************
	$s->register('avgRate');
	function avgRate($expertthis)
	{
			require_once('dbconnect.inc');
			$thissql = "select avg(Rate) from expertin where mem_username = '$expertthis'";
			$thisresult = mysql_db_query($dbname,$thissql);
			$thisarry=mysql_fetch_array($thisresult);
			return $thisarry;
	}	
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>