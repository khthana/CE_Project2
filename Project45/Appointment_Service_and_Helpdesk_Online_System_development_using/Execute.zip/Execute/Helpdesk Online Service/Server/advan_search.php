<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('have_sub');
	function have_sub ($parentid)
	{	
		require_once('dbconnect.inc');
		$sql = "select count(*) as num from category where ParentID=$parentid";
		$result = mysql_db_query($dbname,$sql );
		$num = mysql_result($result,0,"num");
		return $num;
	}
//***************************************************************************************************************************************************
	$s->register('mainresult');
	function mainresult ()
	{
		require_once('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID= '0'";
		$mainresult = mysql_db_query($dbname,$sql);
		$arrResult['num'] = mysql_num_rows($mainresult);

		for ($i=0;$i<$arrResult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($mainresult);
			$arrResult[$arrNum]['CatID'] = $arr[$arrNum]['CatID'];
			$arrResult[$arrNum]['CatName'] = $arr[$arrNum]['CatName'];
		}		
		return $arrResult;
	}
//***************************************************************************************************************************************************
	$s->register('selectCat');
	function selectCat ($mid)
	{	
		require_once('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID= '$mid'";
		$result = mysql_db_query($dbname,$sql);
		$arrResult['num'] = mysql_num_rows($result);

		for ($i=0;$i<$arrResult['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$arrResult[$arrNum]['CatID'] = $arr[$arrNum]['CatID'];
			$arrResult[$arrNum]['CatName'] = $arr[$arrNum]['CatName'];
		}		
		return $arrResult;
	}
//***************************************************************************************************************************************************

	$s->register('AskDate');
	function AskDate ()
	{	
		require_once('dbconnect.inc');
		$ysql = "select min(AskDate) from questions";
		$yresult = mysql_db_query($dbname,$ysql);		
		$ynum = mysql_num_rows($yresult);
		if ($ynum != 0)
		{
			$mindate = mysql_fetch_array($yresult);
			$ysql = "select max(AskDate) from questions";
			$yresult = mysql_db_query($dbname,$ysql);
			$maxdate = mysql_fetch_array($yresult);
			$arr['mindate'] = $mindate;					$arr['maxdate'] = $maxdate;
		}
		$arr['ynum'] = $ynum;

		return $arr;
	}
//***************************************************************************************************************************************************
	$s->register('AnsDate');
	function AnsDate ()
	{	
		require_once('dbconnect.inc');
		$ysql = "select min(AnswerDate) from ans";
		$yresult = mysql_db_query($dbname,$ysql);
		$ynum = mysql_num_rows($yresult);

		if ($ynum != 0)
		{
			$mindate = mysql_fetch_array($yresult);
			$ysql = "select max(AskDate) from questions";
			$yresult = mysql_db_query($dbname,$ysql);
			$maxdate = mysql_fetch_array($yresult);
			$arr['mindate'] = $mindate;					$arr['maxdate'] = $maxdate;
		}

		$arr['ynum'] = $ynum;

		return $arr;
	}
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>