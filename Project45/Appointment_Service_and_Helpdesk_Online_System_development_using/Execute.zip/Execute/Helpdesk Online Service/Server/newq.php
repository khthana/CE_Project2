<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;
//****************************************************************************************************************
	$s->register('newq');
	function newq($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '".$mem_username."'";
		$result = mysql_db_query($dbname,$sql);
		$mstatus = mysql_fetch_array($result);
		$arr['status'] = $mstatus[0];
		
		$sql = 'select QuestionID,mem_username  from ask where ExpertName = "'.$mem_username.'" and AnsStatus = "N"';
		$askresult = mysql_db_query($dbname,$sql);
		$arr['num_newq'] = mysql_num_rows($askresult);

		return $arr;
	}
//****************************************************************************************************************
	$s->register('askresult');
	function askresult($mem_username,$goto)
	{
		require_once('dbconnect.inc');
		$sql = "select questions.QuestionID,Subject,AskDate,mem_username,EditStatus  from ask ,questions where questions.QuestionID=ask.QuestionID and ExpertName = '$mem_username' and  AnsStatus='N' order by AskDate desc limit $goto,10";
		$result = mysql_db_query($dbname,$sql);
		$allask['num'] = mysql_num_rows($result);

		for ($i=0;$i<$allask['num'];$i++)
		{
			$arrNum = 'arrNum'.$i;
			$arr[$arrNum] = mysql_fetch_array($result);
			$allask[$arrNum]['QuestionID'] = $arr[$arrNum]['QuestionID'];
			$allask[$arrNum]['Subject'] = $arr[$arrNum]['Subject'];
			$allask[$arrNum]['AskDate'] = $arr[$arrNum]['AskDate'];
			$allask[$arrNum]['mem_username'] = $arr[$arrNum]['mem_username'];
			$allask[$arrNum]['EditStatus'] = $arr[$arrNum]['EditStatus'];
		}
		return $allask;
	}
//****************************************************************************************************************	

	$s->service($HTTP_RAW_POST_DATA);

?>