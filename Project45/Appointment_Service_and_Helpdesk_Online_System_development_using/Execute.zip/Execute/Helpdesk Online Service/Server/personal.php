<? 
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('resexpert');
	function resexpert($expert)
	{
		require_once('dbconnect.inc');
		$sql = "select *  from member where mem_username = '$expert'";
		$result = mysql_db_query($dbname,$sql);
		$expert = mysql_fetch_array($result);
		$resexpert[mem_username] = $expert[mem_username];			
		$resexpert[FirstName] = $expert[FirstName];								$resexpert[LastName] = $expert[LastName];
		$resexpert[Email] = $expert[Email];													$resexpert[Detail] = $expert[Detail];
		$resexpert[Picture] = $expert[Picture];												$resexpert[Link] = $expert[Link];
		$resexpert[MemberStatus] = $expert[MemberStatus];				$resexpert[SubDate] = $expert[SubDate];

		return $resexpert;
	}
//****************************************************************************************************************
	$s->register('catres');
	function catres($expert)
	{
		require_once('dbconnect.inc');
		$sql = "select CatName, Rate,ResRate,C.CatID  from expertin E,category C  where mem_username = '$expert' and C.CatID = E.CatID";
		$result = mysql_db_query($dbname,$sql);
		$arr['exnum']= mysql_num_rows($result);
		for ($i=0;$i<$arr['exnum'];$i++)
		{
			$ex = 'ex'.$i;
			$arry[$ex] = mysql_fetch_array($result);
			$arr[$ex]['CatName'] = $arry[$ex]['CatName'];
			$arr[$ex]['Rate'] = $arry[$ex]['Rate'];
			$arr[$ex]['ResRate'] = $arry[$ex]['ResRate'];
			$arr[$ex]['CatID'] = $arry[$ex]['CatID'];
		}

		return $arr;
	}
//****************************************************************************************************************
function  avg_rate($avgtmp,$e_rate,$divider)
{	
	if ($divider != 0 )
	{
		$avgtmp= $e_rate/$divider;
	}else
	{
		$avgtmp = 0;
	}
}
//****************************************************************************************************************
	$s->register('personal');
	function personal($i,$catres,$expert)
	{
		require_once('dbconnect.inc');
		$sql = "select NumVote  from expertin  where CatID= '".$catres['CatID']."' and mem_username = '$expert'";
		$sqlresult = mysql_db_query($dbname,$sql);
		$numask = mysql_fetch_array($sqlresult);
		avg_rate(&$avgrate[$i],$catres['Rate'],$numask[0]);
		$numshow[$i] = $numask[0];
		$arr['numshow'] = $numshow[$i];
		
		$sql = "select NumRate  from expertin  where CatID= '".$catres['CatID']."' and mem_username = '$expert'";
		$sqlresult = mysql_db_query($dbname,$sql);
		$numa = mysql_fetch_array($sqlresult);
		avg_rate(&$avgresrate[$i],$catres['ResRate'],$numa[0]);

		$pospoint = strpos($avgrate[$i],".");
		if(!$pospoint)
		{
			$avgrate[$i] .=".00";
		}else
		{
			$numlen = strlen($avgrate[$i]);
			if($numlen<$pospoint+3)
			{
				$avgrate[$i] .= "0";
			}else
			{
				$avgrate[$i] = substr($avgrate[$i],0,$pospoint+3);
			}
		}
		$pospoint = strpos($avgresrate[$i],".");
		if(!$pospoint)
		{
			$avgresrate[$i] .=".00";
		}else
		{
			$numlen = strlen($avgresrate[$i]);
			if($numlen<$pospoint+3)
			{
				$avgresrate[$i] .= "0";
			}else
			{
				$avgresrate[$i] = substr($avgresrate[$i],0,$pospoint+3);
			}
		}

		$arr['avgresrate'] = $avgresrate[$i];					$arr['avgrate'] = $avgrate[$i];

		return $arr;
	}
//****************************************************************************************************************
	$s->register('NumRate');
	function NumRate($catres,$expert)
	{
		require_once('dbconnect.inc');
		$sql = "select NumRate  from expertin  where CatID= '$catres' and mem_username = '$expert'";
		$sqlresult = mysql_db_query($dbname,$sql);
		$numa = mysql_fetch_array($sqlresult);

		return $numa;
	}
//****************************************************************************************************************
	$s->register('Rate');
	function Rate($expert)
	{
		require_once('dbconnect.inc');
		$sql = "select sum(Rate) from expertin where mem_username = '$expert' ";
		$sumresult = mysql_db_query($dbname,$sql);
		$sumrate = mysql_fetch_array($sumresult);
		$sql = "select sum(NumVote) from expertin where mem_username = '$expert' ";
		$numresult = mysql_db_query($dbname,$sql);
		$numcat = mysql_fetch_array($numresult);
		if ($numcat[0] != 0 )
		{
			$overall = $sumrate[0] / $numcat[0];
		}else
		{
			$overall = 0;
		}
		$pospoint = strpos($overall,".");
		if(!$pospoint)
		{
			$overall .=".00";
		}else
		{
			$numlen = strlen($overall);
			if($numlen<$pospoint+3)
			{
				$overall .= "0";
			}else
			{
				$overall= substr($overall,0,$pospoint+3);
			}
		}

		$sql = "select sum(ResRate) from expertin where mem_username = '$expert' ";
		$sumresult = mysql_db_query($dbname,$sql);
		$sumrate = mysql_fetch_array($sumresult);
		$sql = "select sum(NumRate) from expertin where mem_username = '$expert' ";
		$numresult = mysql_db_query($dbname,$sql);
		$numcat = mysql_fetch_array($numresult);

		if ($numcat[0] != 0 )
		{
			$overallres = $sumrate[0] / $numcat[0];
		}else
		{
			$overallres = 0;
		}
		$pospoint = strpos($overallres,".");
		if(!$pospoint)
		{
			$overallres .=".00";
		}else
		{
			$numlen = strlen($overallres);
			if($numlen<$pospoint+3)
			{
				$overallres .= "0";
			}else
			{
				$overallres= substr($overallres,0,$pospoint+3);
			}
		}
		$arr['overall'] = $overall;				$arr['overallres'] = $overallres;
		return $arr;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>