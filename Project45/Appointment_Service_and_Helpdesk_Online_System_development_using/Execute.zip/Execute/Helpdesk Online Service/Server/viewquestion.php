<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('arrAskQ');
	function arrAskQ($QID,$mem_username)
	{
			require_once('dbconnect.inc');
			$sql = "select Subject,Question,AskDate,mem_username,EditStatus,CatID  from ask,questions  where questions.QuestionID = ask.QuestionID and questions.QuestionID = '$QID' and ExpertName = '$mem_username'";
			$showresult = mysql_db_query($dbname,$sql);
			$arr = mysql_fetch_array($showresult);

			$showarry['Question'] = $arr['Question'];
			$showarry['Subject'] = $arr['Subject'];
			$showarry['AskDate'] = $arr['AskDate'];
			$showarry['mem_username'] = $arr['mem_username'];
			$showarry['EditStatus'] = $arr['EditStatus'];
			$showarry['CatID'] = $arr['CatID'];
			return $showarry;
	}
//***************************************************************************************************************************************************	
	$s->register('memstatus');
	function memstatus($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$status = mysql_fetch_array($result);
		$memstatus["status"] = $status["MemberStatus"];
		return $memstatus;
	}
//****************************************************************************************************************	

	$s->service($HTTP_RAW_POST_DATA);
?>
