<?
	require_once ("../NuSoft/nusoap.php");

	//****************************************************************************************************************
	$s = new soap_server;

	$s->register('post');
	function post($mem_username,$Subject,$Question,$CatID,$memstatus)
	{
		require_once('dbconnect.inc');
		require_once('mime_mail.inc');
		require_once('smtp_mail.inc');
		if (!$mem_username)
		{
			$mem_username= 'Anonymous';
		}

		if  ( $Subject == "" )
		{
				$Flag03 = "F1";
		}elseif ($Question == "")
		{
				$Flag03 = "F2";
		}else
		{
			$bansql = "select * from banword";
			$banresult = mysql_db_query($dbname,$bansql);
			$bannum = mysql_num_rows($banresult);
			if ($bannum != 0)
			{
				$ban_i = 0;
				$place = "";
				$Subject = " $Subject";
				$Question = " $Question";
				while ($banarry = mysql_fetch_array($banresult))
				{
					$found1 = strpos($Subject,$banarry['Word'],0);
					if ($found1)
					{
						$ban[$ban_i] = $banarry['Word'];
						$ban_i = $ban_i +1;
						$Flag03 = "F3";
						if ($place=="")
						{
							$place = "��Ǣ��";
						}elseif($place=="�Ӷ��")
						{
							$place = "��Ǣ����ФӶ��";
						}
					}
					$found2 = strpos($Question,$banarry['Word'],0);
					if ($found2)
					{
						if (!$found1)
						{
							$ban[$ban_i] = $banarry['Word'];
							$ban_i = $ban_i +1;
						}
						$Flag03 = "F3";
						if ($place=="")
						{
							$place = "�Ӷ��";
						}elseif($place=="��Ǣ��")
						{
							$place = "��Ǣ����ФӶ��";
						}
					}
				} // end while ban
				$Subject = trim($Subject);
				$Question = trim($Question);
			} //end if ban num !=0
			if($Flag03 != "F3")
			{				
				$AskDate = date("Y-m-d H:i:s");
				$sql0 = "select max(QuestionID) from questions";
				$result0 = mysql_db_query($dbname,$sql0);
				$qid = mysql_fetch_array($result0);
				$qid[0] = $qid[0] + 1;
				$sql = "insert into questions (Subject,Question, AskDate, CatID) values ('$Subject','$Question','$AskDate','$CatID')";
				$result = mysql_db_query($dbname,$sql);
				$sql3	= "select mem_username from expertin where CatID = '$CatID'";
  	   			if ($memstatus=="E")
				{
					$sql3 .= " and mem_username <> '$mem_username'";
				}
				$result3 = mysql_db_query($dbname,$sql3);
				while ($expertin = mysql_fetch_array($result3))
				{
					$tmpe_name = $expertin['mem_username'];
					$sql4 = "insert into ask values ('$mem_username','$qid[0]','$tmpe_name','N','N','N')";
					$result4 = mysql_db_query($dbname,$sql4);
					$sql5 = "select Email from member where mem_username = '$tmpe_name'";
					$result5 = mysql_db_query($dbname,$sql5);
					$result5arr = mysql_fetch_array($result5);

					$mto = $result5arr[0];
					$msub = "You've got a new Question !";
					$mmesg = $mem_username." has asked you a question about ";			
					$mmesg .= '"'.$Subject.'"'." on ";
					$mmesg .= $AskDate." \n\n";
					$mmesg .= "Thanks \n";
					$mmesg .= "Helpdesk System \n";
					$from = "helpdesk@ce.kmitl.ac.th";

					$smtp_server = "diamond.ce.kmitl.ac.th";
					$mail = new mime_mail;
					$mail->from = $from;
					$mail->to = $mto;
					$mail->subject = $msub;
					$mail->body = $mmesg;
					$data = $mail->get_mail();
					$smtp = new smtp_mail;
					$smtp->send_email($smtp_server, $from, $mto, $data);
				}				
			}
		}

		$arr['Flag03'] = $Flag03;
		$arr['ban_i']= $ban_i;						$arr['ban']= $ban;
		$arr['place']= $place;	

		return $arr;
	}

//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>