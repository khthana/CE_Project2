<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('viewask');
	function viewask($mem_username,$QID)
	{
			require_once('dbconnect.inc');

			$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$memstatus = mysql_fetch_array($result);
			$status = $memstatus['MemberStatus'];

			$sql = "select Subject,Question,AskDate,mem_username,EditStatus,CatID  from ask,questions  where questions.QuestionID = ask.QuestionID and questions.QuestionID = '$QID' and ExpertName = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$arry = mysql_fetch_array($result);
			$showarry['Subject'] = $arry['Subject'];								$showarry['CatID'] = $arry['CatID'];
			$showarry['AskDate'] = $arry['AskDate'];							$showarry['Question'] = $arry['Question'];
			$showarry['EditStatus'] = $arry['EditStatus'];					$showarry['mem_username'] = $arry['mem_username'];

			$sql="select QuestionID,AnsStatus from ask where QuestionID ='$QID' and ExpertName = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$arry = mysql_fetch_array($result);
			$ansstatus['QuestionID'] = $arry['QuestionID'];		$ansstatus['AnsStatus'] = $arry['AnsStatus'];

			$sql="select Answer,AnswerDate from ans  where QuestionID ='$QID' and mem_username = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$arry = mysql_fetch_array($result);
			$ansarry['Answer'] = $arry['Answer'];		$ansarry['AnswerDate'] = $arry['AnswerDate'];

			$arr['status'] = $status;										$arr['showarry'] = $showarry;					
			$arr['ansstatus'] = $ansstatus;						$arr['ansarry'] = $ansarry;	

			return $arr;
	}
//***************************************************************************************************************************************************				
$s->register('edit');
	function edit($mem_username,$QID,$Answer)
	{
		require_once('dbconnect.inc');
		$AnsDate = date("Y-m-d H:i:s");
		$sql = "update ans set Answer='$Answer', AnswerDate= '$AnsDate'  where (mem_username= '$mem_username') and (QuestionID=$QID)";
		$result = mysql_db_query($dbname,$sql);

	}
//***************************************************************************************************************************************************			
$s->register('del');
	function del($mem_username,$QID)
	{
		require_once('dbconnect.inc');
		$sql = "delete  from ans where mem_username = '$mem_username' and QuestionID='$QID'";		
		$result = mysql_db_query($dbname,$sql);
		$sql = "update ask set AnsStatus='N'  where (ExpertName= '$mem_username') and (QuestionID=$QID)";
		$result = mysql_db_query($dbname,$sql);
	}
//***************************************************************************************************************************************************			

	$s->service($HTTP_RAW_POST_DATA);
?>