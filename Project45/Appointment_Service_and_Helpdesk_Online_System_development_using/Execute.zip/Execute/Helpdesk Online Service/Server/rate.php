<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('updateRate');
	function updateRate($expert,$CatID,$score)
	{
		require_once('dbconnect.inc');
		$sql = "select Rate,NumVote  from expertin where mem_username = '$expert' and CatID = '$CatID'";
		$result = mysql_db_query($dbname,$sql);
		$num = mysql_num_rows($result);
		if ($num != 0)
		{
			$ratearry = mysql_fetch_array($result);
			$rate = $ratearry['Rate'] + $score;
			$numvote = $ratearry['NumVote']+ 1;
			$sql = "update  expertin set Rate='$rate',NumVote='$numvote'  where mem_username = '$expert' and CatID = '$CatID'";
			$result = mysql_db_query($dbname,$sql);
		}
	}
//****************************************************************************************************************
	
	$s->service($HTTP_RAW_POST_DATA);
?>
