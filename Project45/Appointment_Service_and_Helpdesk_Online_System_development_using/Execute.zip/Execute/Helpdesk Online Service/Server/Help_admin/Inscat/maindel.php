<?
	session_start( );
	if (!session_is_registered("admin"))
	{
		echo "<meta http-equiv='refresh' content='3;URL= index.php'>";
		exit;
	}

	if (!isset($Yes)) $Yes='';
	if (!isset($No)) $No='';

	include('dbconnect.inc');
		function delsub($dbname,$mainid)
		{
			$sql5 = "select CatID from category where ParentID=$mainid";
			$result5 = mysql_query($sql5);
			$nrow = mysql_num_rows($result5);
			if ($nrow !=0)
			{
				while($sub = mysql_fetch_array($result5))
				{
					delsub($dbname,$sub["CatID"]);
					$sql2 = "delete from  category where CatID = $mainid";
  				    $result = mysql_query($sql2);
					$sql2 = "update questions set CatID= -1 where CatID=$mainid";
					$result = mysql_query($sql2);
					$sql2 = "delete from  expertin where CatID = $mainid";
					$result = mysql_query($sql2);
				}
			}else
			{
				$sql2 = "delete from  category where CatID = $mainid";
				$result = mysql_query($sql2);
				$sql2 = "update questions set CatID= -1 where CatID=$mainid";
				$result = mysql_query($sql2);
				$sql2 = "delete from  expertin where CatID = $mainid";
				$result = mysql_query($sql2);
			}
		}

		if ($Yes)
		{
			$sql3 = "select CatID from category where ParentID=$delcatid";
			$result = mysql_query($sql3);
			delsub($dbname,$delcatid);
			echo "<meta http-equiv='refresh' content='3;URL= initdel.php?flag=0'>";
			exit;					
		}elseif($No)
		{
			echo "<meta http-equiv='refresh' content='3;URL= initdel.php'>";
			exit;								
		}else
		{
			if ($DID != 0)
			{
				$sql1 = "select CatID,CatName from category where CatID=$DID";
				$result = mysql_query($sql1);
				$nrow = mysql_numrows($result);
				if ($nrow!=0)
				{
					$delcat = mysql_fetch_array($result);
					$delcatname = $delcat["CatName"];
					$delcatid = $delcat["CatID"];
				}else 
				{
					echo "<meta http-equiv='refresh' content='3;URL= initdel.php?flag=1'>";
					exit;								
				}
			}else
			{
				$delcatname = "main category";
				$delcatid = 0;
			}

?>
<html>
<head>
<title>Un title page</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

</head>
<body bgcolor="#FFFFCC">
<div align="center">
  <p>&nbsp;</p>
  <p align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="4" color="#FF3399">�س��ͧ���ź 
    Category <? echo $delcatname; ?> ��� Subcategory �ͧ <? echo $delcatname; ?></font></p>
  <p align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="4" color="#FF3399">��Шзӡ���� 
    CatID �ͧ�Ӷ���������� <? echo $delcatname; ?> �� -1</font></p>
  <form method="post" action="maindel.php" name="del_cat">
    <input type="submit" name="No" value="No">
    <input type="submit" name="Yes" value="Yes">
    <input type="hidden" name="delcatid" value="<?echo $delcatid;?>">
  </form>
  <p>&nbsp;</p>
</div>
</body>
</html>
<?	
		} // end else $submit
?>