<?
	session_start( );
	if (!session_is_registered("admin"))
	{
		echo "<meta http-equiv='refresh' content='3;URL= index.php'>";
		exit;
	}
?>
<html>
<head>
<title>��� Category �ͧ�Ӷ��</title></head>
<FRAMESET cols="200,*"> 
  <FRAME src="leftE.php" name="treeframe" > 
  <FRAME SRC="initE.php" name="basefrm" > 
</FRAMESET><noframes></noframes>
</HTML>