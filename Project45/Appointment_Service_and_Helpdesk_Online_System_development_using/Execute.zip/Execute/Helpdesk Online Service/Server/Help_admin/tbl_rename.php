<?

	session_start( );
	if (!session_is_registered("admin"))
	{
		echo "<meta http-equiv='refresh' content='3;URL= index.php'>";
		exit;
	}
	include('dbconnect.inc');
		$sql = "ALTER TABLE ".$table." RENAME ".$newname;
		$result = mysql_query( $sql);
		if ($result)
		{ 
			$flag = 0;
			$table = $newname;
		}
		else
		 { 
			$flag = 1;
			session_register("errmsg");
			$errmsg = mysql_error();
		}
		$location = "tbl_properties.php?table=".$table."&flag=".$flag;
		echo "<meta http-equiv='refresh' content='3;URL=$location'>";
		exit;			
?>