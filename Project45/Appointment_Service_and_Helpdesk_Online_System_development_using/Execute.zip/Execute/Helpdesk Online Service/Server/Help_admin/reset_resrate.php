<?
	session_start( );
	if (!session_is_registered("admin"))
	{
		header ("Location: index.php");  
		exit;
	}
include('dbconnect.inc');if (!isset($Yes)) {$Yes = '';}if (!isset($No)) {$No = '';}
if($Yes)
{
	$sql = "update expertin set ResRate = 0 , NumRate = 0";
	$result = mysql_query($sql);
	echo mysql_error();
	echo "<meta http-equiv='refresh' content='3;URL= db_detail.php'>";
}elseif ($No)
{
	echo "<meta http-equiv='refresh' content='3;URL= db_detail.php'>";
}
?>
<html>
<head>
<title>Reset Rate</title><meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css"><!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>
</head>
<body bgcolor="#9999CC">
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="50">  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="90%">
  <tr>    <td width="50">&nbsp;</td>
    <td bgcolor="#FFFFCC" valign="top" align="center"> 
      <p>&nbsp; </p>
      <form method="post" action="reset_resrate.php">
        <p><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#3333FF"><b>�س��ͧ��� 
          Reset Response Rate ��� �ӹǹ����㹡������ṹ ����� 0</b></font></p>
        <p> 
          <input type="submit" name="Yes" value="Yes">
          <input type="submit" name="No" value="No">
        </p>
      </form>
      <p>&nbsp;</p>
		</td>
    <td width="50">&nbsp;</td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="50">  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>