<? 

	include('dbconnect.inc');
	$sql = "select Picture from  member where mem_username= '$mem_username'";

	$result = mysql_db_query($dbname,$sql);

  $row = mysql_fetch_row($result);

	header ("Content-type: image/gif");  

	echo $row[0];

?>

