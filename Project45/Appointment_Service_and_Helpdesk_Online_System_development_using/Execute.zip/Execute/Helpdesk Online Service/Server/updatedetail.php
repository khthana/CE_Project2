<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;
//****************************************************************************************************************	
	$s->register('status');
	function status($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$arrstatus = mysql_fetch_array($result);
		$status = $arrstatus['MemberStatus'];

		return $status;
	}
//****************************************************************************************************************
	$s->register('oldexarry');
	function oldexarry($mem_username)
	{
		require_once('dbconnect.inc');
		$exsql = "select CatID,Rate,NumVote  from expertin where mem_username = '$mem_username'";
		$exresult = mysql_db_query($dbname,$exsql );
		$arr['exnum'] = mysql_num_rows($exresult);
		for ($i=0;$i<$arr['exnum'];$i++)
		{
			$oldex = 'oldex'.$i;
			$arr[$oldex] = mysql_fetch_array($exresult);
		}
		return $arr;
	}
//****************************************************************************************************************
	$s->register('insertExpert');
	function insertExpert($mem_username,$e_cat)
	{
		require_once('dbconnect.inc');
		$sql=" insert into expertin  (mem_username,CatID) values ('$mem_username','$e_cat')";
		$result = mysql_db_query($dbname,$sql);
		return $result;
	}
//****************************************************************************************************************
	$s->register('deleteExpert');
	function deleteExpert($mem_username,$exuse)
	{
		require_once('dbconnect.inc');
		$exsql = "delete  from expertin where mem_username = '$mem_username' and CatID not in ( $exuse )";
		$exresult = mysql_db_query($dbname,$exsql );
		return $result;
	}
//****************************************************************************************************************
	$s->register('catarry');
	function catarry($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select CatName from category,expertin where expertin.CatID = category.CatID and mem_username = '$mem_username'";
		$catresult = mysql_db_query($dbname,$sql);
		$arr['rnum'] = mysql_num_rows($catresult);
		for ($i=0;$i<$arr['rnum'];$i++)
		{
			$cat = 'cat'.$i;
			$arr[$cat] = mysql_fetch_array($catresult);
		}

		return $arr;
	}
//****************************************************************************************************************
	
	$s->service($HTTP_RAW_POST_DATA);
?>