<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('postpone_n1');
	function postpone_n1($mem_username,$QID) 
	{
		require_once('dbconnect.inc');

		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);
		$status = $memstatus["MemberStatus"];

		$sql = "select Subject,Question,AskDate,mem_username,EditStatus  from ask,questions  where questions.QuestionID = ask.QuestionID and questions.QuestionID = '$QID' and ExpertName = '$mem_username'";
		$showresult = mysql_db_query($dbname,$sql);
		$arry = mysql_fetch_array($showresult);
		$showarry['Subject'] = $arry['Subject'];							$showarry['Question'] = $arry['Question'];
		$showarry['AskDate'] = $arry['AskDate'];						$showarry['mem_username'] = $arry['mem_username'];
		$showarry['EditStatus'] = $arry['EditStatus'];				

		$sql="select QuestionID,AnsStatus from ask where QuestionID ='$QID' and ExpertName = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);		
		$array = mysql_fetch_array($result);
		$ansstatus['QuestionID'] = $array['QuestionID'];							$ansstatus['AnsStatus'] = $array['AnsStatus'];

		$arr['status'] = $status;						$arr['showarry'] = $showarry;
		$arr['ansstatus'] = $ansstatus;

		return $arr;
	}
//****************************************************************************************************************
	$s->register('postpone_n');
	function postpone_n($mem_username,$Answer,$EditStatus,$QID,$asker) 
	{
		require_once('dbconnect.inc');
		require_once('mime_mail.inc');
		require_once('smtp_mail.inc');

		$bansql = "select * from banword";
		$banresult = mysql_db_query($dbname,$bansql);
		$bannum = mysql_num_rows($banresult);
		if ($bannum != 0)
		{
			$ban_i = 0;
			$place = "";
			$Answer = " $Answer";
			while ($banarry = mysql_fetch_array($banresult))
			{
				$found2 = strpos($Answer,$banarry['Word'],0);
				if ($found2)
				{
					$ban[$ban_i] = $banarry['Word'];
					$ban_i = $ban_i +1;
					$Flag03 = "F3";
				}
			} // end while ban
			$Answer = trim($Answer);
		} //end if ban num !=0
		if($Flag03 != "F3")
		{
			$Answer = trim($Answer);
			$AnsDate = date("Y-m-d H:i:s");
			if ($EditStatus != 'A')
			{
				$sql=" insert into ans  (mem_username,QuestionID,Answer,AnswerDate) values ('$mem_username','$QID','$Answer','$AnsDate')";
			}else
			{
				$sql="update ans  set  Answer='$Answer', AnswerDate= '$AnsDate' where mem_username = '$mem_username' and QuestionID = '$QID' ";
			}
			$result = mysql_db_query($dbname,$sql);
			echo mysql_error();
			$sql = "update ask set AnsStatus='Y' , EditStatus = 'Y'  where QuestionID = '$QID' and ExpertName = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			echo mysql_error();
			if ($asker != "Anonymous")
			{
				$sql = "select Email from member where mem_username = '$asker'";
				$result = mysql_db_query($dbname,$sql);
				$askeremail = mysql_fetch_array($result);
				$mto = $askeremail[0];
				$msub = "You are asked to give more information.";
				$sql = "select Subject,AskDate  from questions  where QuestionID = '$QID'";
				$result = mysql_db_query($dbname,$sql);
				$qresult = mysql_fetch_array($result);
				$mmesg = $mem_username." request information about ";
				$mmesg .= '"'.$qresult[0].'"'." that you ask on ";
				$mmesg .= $qresult[1]." \n\n";
				$mmesg .= "Thanks \n";
				$mmesg .= "Helpdesk System \n";
				$from = "helpdesk@ce.kmitl.ac.th";

				$smtp_server = "diamond.ce.kmitl.ac.th";
				$mail = new mime_mail;
				$mail->from = $from;
				$mail->to = $mto;
				$mail->subject = $msub;
				$mail->body = $mmesg;
				$data = $mail->get_mail();
				$smtp = new smtp_mail;
				$smtp->send_email($smtp_server, $from, $mto, $data);
			}
		}
		$arr['Flag03']= $Flag03;
		$arr['ban_i']= $ban_i;					$arr['ban']= $ban;

		return	$arr;
	}	// end function
//***************************************************************************************************************************************************		

	$s->service($HTTP_RAW_POST_DATA);
?>