<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('detailQ');
	function detailQ($mem_username,$QID)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$status = mysql_fetch_array($result);
		$arr["status"] = $status["MemberStatus"];

		$sql = "select Subject,Question,AskDate,mem_username,EditStatus,CatID  from ask,questions  where questions.QuestionID = ask.QuestionID and questions.QuestionID = '$QID' and ExpertName = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$arry = mysql_fetch_array($result);

		$showarry['Subject'] = $arry['Subject'];
		$showarry['Question'] = $arry['Question'];
		$showarry['AskDate'] = $arry['AskDate'];
		$showarry['mem_username'] = $arry['mem_username'];
		$showarry['EditStatus'] = $arry['EditStatus'];
		$showarry['CatID'] = $arry['CatID'];

		$arr['showarry'] = $showarry;

		return $arr;
	}
//****************************************************************************************************************
	$s->register('ansQ');
	function ansQ($mem_username,$asker,$EditStatus,$QID,$CatID,$Answer)
	{
		require_once('dbconnect.inc');
		require_once('mime_mail.inc');
		require_once('smtp_mail.inc');

		$bansql = "select * from banword";
		$banresult = mysql_db_query($dbname,$bansql);
		$bannum = mysql_num_rows($banresult);
		if ($bannum != 0)
		{
			$ban_i = 0;
			$place = "";
			$Answer = " $Answer";
			while ($banarry = mysql_fetch_array($banresult))
			{
				$found2 = strpos($Answer,$banarry['Word'],0);
				if ($found2)
				{
					$ban[$ban_i] = $banarry['Word'];
					$ban_i = $ban_i +1;
					$Flag03 = "F3";
				}
			} // end while ban
			$Answer = trim($Answer);
		} //end if ban num !=0
	
		if($Flag03 != "F3")
		{
			$Answer = trim($Answer);
			$AnsDate = date("Y-m-d H:i:s");
			if ($EditStatus != 'A')
			{
				$sql=" insert into ans  (mem_username,QuestionID,Answer,AnswerDate) values ('$mem_username','$QID','$Answer','$AnsDate')";
			}else
			{
				$sql="update  ans  set Answer = '$Answer',AnswerDate = '$AnsDate' where mem_username = '$mem_username' and QuestionID = '$QID'";
			}
			$result = mysql_db_query($dbname,$sql);
			$sql = "update ask set AnsStatus='Y',EditStatus = 'N'  where QuestionID = '$QID' and ExpertName = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$sql = "select AskDate from questions where QuestionID = '$QID'";
			$result = mysql_db_query($dbname,$sql);
			$askdate = mysql_fetch_array($result);
			$sql = "select AnswerDate from ans where QuestionID = '$QID' and mem_username = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$ansdate = mysql_fetch_array($result);
			$asky = substr($askdate[0],0,4);
			$askm = substr($askdate[0],5,2);
			$askd = substr($askdate[0],8,2);
			$ansy = substr($ansdate[0],0,4);
			$ansm = substr($ansdate[0],5,2);
			$ansd = substr($ansdate[0],8,2);
			$ydiff = $ansy-$asky;
			$mdiff = $ansm-$askm;
			$ddiff = $ansd-$askd;
			$score = 0;
			if ($ydiff == 0)
			{
				if($ddiff<0)
				{
					if($mdiff == 1)
					{
						$day = 30;
						if($askm == "02")
						{ $day = 28;}
						if($askm == "01" or $askm == "03" or $askm == "05" or $askm == "07" or $askm == "08" or $askm == "10" or $askm == "12")
						{ $day = 31;}
						$tmp = $day+$ddiff;
						if($tmp <10 )
						{
							$score = 10-$tmp;
						}
					}
				}elseif($ddiff >= 0 and $mdiff == 0)
				{
						if($ddiff <10 )
						{
							$score = 10-$ddiff;
						}
				}
			}  //end ydiff =0
			$sql = "select ResRate,NumRate  from expertin where mem_username = '$mem_username' and CatID = '$CatID'";
			$result = mysql_db_query($dbname,$sql);
			echo mysql_error();
			$exnum = mysql_num_rows($result);
			if ($exnum !=0)
			{
				$ratearry = mysql_fetch_array($result);
				$rate = $ratearry['ResRate'] + $score;
				$numvote = $ratearry['NumRate']+ 1;
				$sql = "update  expertin set ResRate='$rate',NumRate='$numvote'  where mem_username = '$mem_username' and CatID = '$CatID'";
				$result = mysql_db_query($dbname,$sql);
				echo mysql_error();
			}
			if ($asker != "Anonymous")
			{
				$sql = "select Email from member  where mem_username = '$asker'";
				$result = mysql_db_query($dbname,$sql);
				$askeremail = mysql_fetch_array($result);
				$mto = $askeremail[0];
				$msub = "You've got new answer.";
				$sql = "select Subject,AskDate  from questions  where QuestionID = '$QID'";
				$result = mysql_db_query($dbname,$sql);
				$qresult = mysql_fetch_array($result);
				$mmesg = $mem_username." has answered your question about ";
				$mmesg .= '"'.$qresult[0].'"'." that you asked on ";
				$mmesg .= $qresult[1]." \n\n";
				$mmesg .= "Thanks \n";
				$mmesg .= "Helpdesk System \n";
				$from = "helpdesk@ce.kmitl.ac.th";

				$smtp_server = "diamond.ce.kmitl.ac.th";
				$mail = new mime_mail;
				$mail->from = $from;
				$mail->to = $mto;
				$mail->subject = $msub;
				$mail->body = $mmesg;
				$data = $mail->get_mail();
				$smtp = new smtp_mail;
				$smtp->send_email($smtp_server, $from, $mto, $data);
			}
		}
	
		$arr['Flag03'] = $Flag03;				$arr['Answer'] = $Answer;
		$arr['ban'] = $ban;							$arr['ban_i'] = $ban_i;		

		return	$arr;
}	// end function
//***************************************************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>