<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('viewAns');
	function viewAns($mem_username,$QID,$EName)
	{
			require_once('dbconnect.inc');
			$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$memstatus = mysql_fetch_array($result);

			$sql = "select Subject,Question,AskDate,AnswerDate,Answer,mem_username,CatID  from ans,questions  where questions.QuestionID = ans.QuestionID and questions.QuestionID = '$QID' and mem_username = '$EName'";
			$showresult = mysql_db_query($dbname,$sql);
			$arr = mysql_fetch_array($showresult);
			
			$showarry['Subject'] = $arr['Subject'];
			$showarry['Question'] = $arr['Question'];
			$showarry['AskDate'] = $arr['AskDate'];
			$showarry['AnswerDate'] = $arr['AnswerDate'];
			$showarry['Answer'] = $arr['Answer'];
			$showarry['mem_username'] = $arr['mem_username'];
			$showarry['CatID'] = $arr['CatID'];

			$arry['showarry'] = $showarry;						$arry['status'] = $memstatus['MemberStatus'];

			return $arry;
	}	
//***************************************************************************************************************************************************
	$s->register('updateASKstatus');
	function updateASKstatus($mem_username,$EName,$QID)
	{
			require_once('dbconnect.inc');
			$sql = "update ask set ViewStatus='Y' where QuestionID='$QID' and ExpertName='$EName'";
			$result = mysql_db_query($dbname,$sql);
			return $result;
	}	// end function
//***************************************************************************************************************************************************


	$s->service($HTTP_RAW_POST_DATA);
?>
