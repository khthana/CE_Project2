<?
	require_once ("../NuSoft/nusoap.php");

	$s = new soap_server;

//****************************************************************************************************************	
	$s->register('memstatus');
	function memstatus($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$memstatus = mysql_fetch_array($result);
		return $memstatus;
	}
//****************************************************************************************************************

	$s->register('CountAskAns');
	function CountAskAns($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus,SubDate from member where mem_username= '$mem_username'";
		$memresult = mysql_db_query($dbname,$sql);
		$marry = mysql_fetch_array($memresult);
		$memarry['MemberStatus'] = $marry['MemberStatus'];
		$date = $marry['SubDate'];
		$day = substr($date,8,2);
		$month = substr($date,5,2);
		$year = substr($date,0,4);
		$memarry['SubDate'] = $day.'/'.$month.'/'.$year;
		$array['memarry'] = $memarry;


		$memasksql = "select count(*) from ask where mem_username = '$mem_username'";
		$memaskresult = mysql_db_query($dbname,$memasksql);
		$Umemaskarry = mysql_fetch_array($memaskresult);
		$array['Umemaskarry'] = $Umemaskarry[0];

		$memanssql = "select count(*) from ask where mem_username = '$mem_username' and AnsStatus = 'Y'";
		$memansresult = mysql_db_query($dbname,$memanssql);
		$Umemansarry = mysql_fetch_array($memansresult);
		$array['Umemansarry'] = $Umemansarry[0];

		$memasksql = "select count(*) from ASK where ExpertName = '$mem_username'";
		$memaskresult = mysql_db_query($dbname,$memasksql);
		$Ememaskarry = mysql_fetch_array($memaskresult);
		$array['Ememaskarry'] = $Ememaskarry[0];

		$memanssql = "select count(*) from ASK where ExpertName = '$mem_username' and AnsStatus = 'Y'";
		$memansresult = mysql_db_query($dbname,$memanssql);
		$Ememansarry = mysql_fetch_array($memansresult);	
		$array['Ememansarry'] = $Ememansarry[0];

		return $array;
	}
//****************************************************************************************************************
	$s->register('selectCat');
	function selectCat($CatID)
	{
		require_once('dbconnect.inc');
		$sql = "select CatID,CatName from category where ParentID= '$CatID'";
		return $sql;
		$result = mysql_db_query($dbname,$sql);
		return $result;
	}
//****************************************************************************************************************
	$s->register('numexpert');
	function numexpert($CatID,$compare)
	{
		require_once('dbconnect.inc');
		$sql  = "select mem_username from expertin where CatID = '$CatID' ";
		$rateresult = mysql_db_query($dbname,$sql);
		$numexpert = mysql_num_rows($rateresult);
		return $numexpert;
	}
//****************************************************************************************************************

	$s->service($HTTP_RAW_POST_DATA);
?>