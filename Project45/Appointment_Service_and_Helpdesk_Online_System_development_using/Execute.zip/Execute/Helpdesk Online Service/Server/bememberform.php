<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;
	$s->register('beMember');
	function beMember($mem_username,$mem_password,$Pwd,$FirstName,$LastName,$Email,$subdate) 
		{		
			require_once('dbconnect.inc');
			require_once('mime_mail.inc');
			require_once('smtp_mail.inc');

			$mem_username = trim($mem_username);
			$mem_password = trim($mem_password );
			$Pwd = trim($Pwd );
			$FirstName = trim($FirstName);
			$LastName = trim($LastName);
			$Email = trim($Email);
			$mem_username=strtolower($mem_username);
			$sql = "select mem_username from 	member  where mem_username = '$mem_username' ";
			$result = mysql_db_query($dbname,$sql);
			$nrow = mysql_num_rows($result);
			if ($mem_username == "")
			{
				$flag01 = 'T0';
			}elseif ($nrow != 0 )
			{ 
				$flag01 = 'T1';
			} elseif ($mem_password != $Pwd)
			{
				$flag01 = 'T2';
			} elseif (strlen($mem_password) < 6)
			{
				$flag01 = 'T5';
			} elseif ($Email == "")
			{
				$flag01 = 'T4';
			}else
			{
					$bansql = "select * from banword";
					$banresult = mysql_db_query($dbname,$bansql);
					$bannum = mysql_num_rows($banresult);
					if ($bannum != 0)
					{
						$ban_i = 0;
						$place = "";
						$mem_username = " $mem_username";
						while ($banarry = mysql_fetch_array($banresult))
						{
							$found1 = strpos($mem_username,$banarry['Word'],0);
							if ($found1)
							{
								$ban[$ban_i] = $banarry['Word'];
								$ban_i = $ban_i +1;
								$Flag03 = "F3";
								if ($place=="")
								{
									$place = "Login Name";
								}
							}
						} // end while ban
						$mem_username = trim($mem_username);
					} //end if ban num !=0
				if($Flag03 != "F3")
				{
					$sql = "select mem_username from member  where Email = '$Email' ";
					$result = mysql_db_query($dbname,$sql);
					$nrow = mysql_num_rows($result);
					if ($nrow != 0 )
					{ 
						$flag01 = 'T3';
					} else
					{
						$subdate = date("Y-m-d");
						$result = mysql_db_query($dbname," insert into member (mem_username,mem_password,FirstName,LastName,Email,MemberStatus,SubDate)						values('$mem_username','$mem_password','$FirstName','$LastName','$Email','U','$subdate')");
						
						$loginname=$LoginName;
						$mto = $Email;
						$msub ="Welcome to CE- Helpdesk";
						$mmesg = "Welcome $loginname\n";
						$mmesg .=  "Thanks that  you have registered to be a member at helpdesk online. \n";
						$mmesg .= "You will receive E- mail from helpdesk system when you get new questions or answers  \n\n";
						$mmesg .= "Thanks \n";
						$mmesg .= "Helpdesk System \n";
						$from = "helpdesk@ce.kmitl.ac.th";

						$smtp_server = "diamond.ce.kmitl.ac.th";
						$mail = new mime_mail;
						$mail->from = $from;
						$mail->to = $mto;
						$mail->subject = $msub;
						$mail->body = $mmesg;
						$data = $mail->get_mail();
						$smtp = new smtp_mail;
						$smtp->send_email($smtp_server, $from, $mto, $data);
						$flag01 = 'T';						
					}
				}
			}

		$arr['flag01'] = $flag01;					$arr['Flag03']= $Flag03;
		$arr['ban_i']= $ban_i;					$arr['ban']= $ban;
		$arr['place']= $place;	

		return $arr;
	}	// End Function

//****************************************************************************************************************

$s->service($HTTP_RAW_POST_DATA);
?>          