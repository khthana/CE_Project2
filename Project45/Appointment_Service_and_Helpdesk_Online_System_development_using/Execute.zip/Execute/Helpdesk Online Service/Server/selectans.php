<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************
	$s = new soap_server;

	$s->register('memstatus');
	function memstatus($mem_username)
	{
		require_once('dbconnect.inc');
		$sql = "select MemberStatus  from member where mem_username = '$mem_username'";
		$result = mysql_db_query($dbname,$sql);
		$status = mysql_fetch_array($result);
		$memstatus["status"] = $status["MemberStatus"];
		return $memstatus;
	}
//****************************************************************************************************************	
	$s->register('selectAns');
		
	function selectAns($QID,$mem_username)
	{
			require_once('dbconnect.inc');
			$sql = "select Subject,Question,AskDate,mem_username,EditStatus,CatID  from ask,questions  where questions.QuestionID = ask.QuestionID and questions.QuestionID = '$QID' and ExpertName = '$mem_username'";
			$showresult = mysql_db_query($dbname,$sql);
			$arry = mysql_fetch_array($showresult);
			$showarry['Question'] = $arry['Question'];
			$showarry['Subject'] = $arry['Subject'];
			$showarry['AskDate'] = $arry['AskDate'];
			$showarry['mem_username'] = $arr['mem_username'];
			$showarry['EditStatus'] = $arry['EditStatus'];
			$showarry['CatID'] = $arry['CatID'];

			$sql="select QuestionID,AnsStatus from ask where QuestionID ='$QID' and ExpertName = '$mem_username'";
			$result = mysql_db_query($dbname,$sql);
			$arry = mysql_fetch_array($result);
			$ansstatus['QuestionID'] = $arry['QuestionID'];			$ansstatus['AnsStatus'] = $arry['AnsStatus'];

			$arr['showarry'] = $showarry;			$arr['ansstatus'] = $ansstatus;	

			return $arr;
	}
//***************************************************************************************************************************************************	

	$s->service($HTTP_RAW_POST_DATA);
?>