<?
	require_once ("../NuSoft/nusoap.php");

//****************************************************************************************************************

	$s = new soap_server;

	$s->register('Login');
	function Login($mem_username,$mem_password)
	{
		require_once('dbconnect.inc');

		$arr['flag'] = false;
		$sql = "select mem_password  from member where mem_username = '$mem_username' ";
		$result1 = mysql_db_query($dbname,$sql);
		$numreal = mysql_num_rows($result1);

		if ($numreal != 0)
		{
			$realpass = mysql_fetch_array($result1);						
			$enterpass = substr($mem_password,0,10);
			$realpass = substr($realpass[0],0,10);
//			$enterpass = $mem_password;return $enterpass;
			if ($realpass == $enterpass)
			{
				$sql = "select MemberStatus  from member where mem_username = '$mem_username' ";		
				$result = mysql_db_query($dbname,$sql);
				$mstatus = mysql_fetch_array($result);		
				$arr['mstatus']  = $mstatus[0];		
				$arr['flag'] = true;
			} // endif ($realpass[0] == $enterpass[0])			
		}//end if ($numreal != 0)		
		return $arr;
	}//end function

//****************************************************************************************************************
		
	$s->service($HTTP_RAW_POST_DATA);
?>