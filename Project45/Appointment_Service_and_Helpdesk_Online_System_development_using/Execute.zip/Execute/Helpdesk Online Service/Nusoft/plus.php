<?php

require_once('NuSoft/nusoap.php');
$s = new soap_server;
$s->register('hello');
function Add($num1,$num2){	
	if ($name == "") {
		return new soap_fault('Client',",'Must supply a valid name.'");
	}
	$result = $num1+$num2;
	return "$result!";
}
$s->service($HTTP_RAW_POST_DATA);

?>