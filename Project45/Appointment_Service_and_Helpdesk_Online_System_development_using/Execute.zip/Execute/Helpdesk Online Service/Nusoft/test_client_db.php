<?php

require_once('nusoap.php');
$parameters = array('dsn'=>'db_hardware','username'=>'','password'=>'');
$soapclient = new soapclient('http://localhost/php/NuSoft/test_server_db.php');
echo $soapclient->call('showname',$parameters);

?>