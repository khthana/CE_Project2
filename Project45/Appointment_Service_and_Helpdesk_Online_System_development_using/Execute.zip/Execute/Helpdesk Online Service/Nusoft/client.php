<?php

require_once('nusoap.php');
$parameters = array('name'=>'Kasidis','surname'=>'Theamtud');
$soapclient = new soapclient('http://localhost/php/NuSoft/hello.php');
echo $soapclient->call('hello',$parameters);
echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';


?>