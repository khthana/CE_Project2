<?php

require_once('nusoap.php');
$x=10;$y=15;
$parameters = array('a'=>$x,'b'=>$y);
$soapclient = new soapclient('http://localhost/php/NuSoft/add.php');
echo $soapclient->call('add',$parameters);
echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';


?>