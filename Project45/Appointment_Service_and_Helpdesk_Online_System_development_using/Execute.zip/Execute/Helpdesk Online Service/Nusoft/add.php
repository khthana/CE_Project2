<?php

require_once('nusoap.php');
$s = new soap_server;
$s->register('add');
function add($a,$b){	
	if (($a == "")&&($b=="")) {
		return new soap_fault('Client',",'Must supply a valid name.'");
	}
	$c=$a+$b;
	return "result = ".$c;
}
$s->service($HTTP_RAW_POST_DATA);

?>