<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
		<title>Success Code</title>
		<meta http-equiv=Content-Type content="text/html; charset=windows-874">
	</head>
	<body>
		<?php
			
			include("nusoap.php");

			$parameters = array("host"=>"localhost", "uname"=>"", "passwd"=>"", "dbname"=>"login", "tbname"=>"member");
			$soapclient = new soapclient("http://161.246.6.59/test/server_2.php");
			$a = $soapclient->call("query", $parameters);
			echo $a;

			echo '<xmp>'.$soapclient->request.'</xmp>';
			echo '<xmp>'.$soapclient->response.'</xmp>';
			
		?>
	</body>