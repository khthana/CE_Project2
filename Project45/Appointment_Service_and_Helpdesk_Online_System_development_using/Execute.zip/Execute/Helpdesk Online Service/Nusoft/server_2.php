<?php
	include("nusoap.php");

	$s = new soap_server;
	
	$s->register("query");
	
	function create_query($tbname){
		$query = "select * from $tbname";
		return $query;
	}

	function concat_str($text){
		global $str;
		$str .= $text;
		return $str;
	}
	
	function show_result($arr){
	//	can modify this function to display result in different style;
		global $arr, $str;		
		$str = "";
		$count = 0;
		for($i = 0; $i <3; $i++){
			for($j = 0; $j < 3; $j++){
				$str = concat_str($arr[$i][$j]);
				$str.= " ";
				$count++;
				if($count == 3){
					$str.= "<br> ";
					$count = 0;
				}
			}
		}
		
		return $str;
	}

	function query($host, $uname, $passwd, $dbname, $tbname){
		global $arr, $str;
		mysql_connect($host, $uname, $passwd);
		mysql_select_db($dbname);
		$query = create_query($tbname);
		$result = mysql_query($query);
		$i = 0;
		while($row = mysql_fetch_array($result)){	
			$arr[$i][0] = $row["id"];
			$arr[$i][1] = $row["uname"];
			$arr[$i][2] = $row["passwd"];	
			$i++;
		}
		return show_result($arr);
	}

	$s->service($HTTP_RAW_POST_DATA);
?>
