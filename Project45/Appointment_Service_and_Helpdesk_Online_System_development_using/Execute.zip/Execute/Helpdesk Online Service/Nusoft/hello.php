<?php

require_once('nusoap.php');
$s = new soap_server;
$s->register('hello');
function hello($name,$surname){	
	if ($name == "") {
		return new soap_fault('Client',",'Must supply a valid name.'");
	}
	return "hello $name $surname!";
}
$s->service($HTTP_RAW_POST_DATA);

?>