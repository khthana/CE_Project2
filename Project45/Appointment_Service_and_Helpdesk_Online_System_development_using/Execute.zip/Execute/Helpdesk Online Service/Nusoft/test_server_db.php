<?php

require_once('NuSoft/nusoap.php');
$s = new soap_server;
$s->register('showname');
function showname($dsn,$username,$password){	
	$conn = ODBC_CONNECT($dsn,$username,$password); 
	$query = "SELECT User.*, User.ID FROM User WHERE (((User.ID)=1))";
	$result = odbc_exec($conn,$query);
	$all = odbc_result($result,"strNickname");
	return "Name $all!";
}
$s->service($HTTP_RAW_POST_DATA);

?>