<?php

require_once('NuSoft/nusoap.php');
$soapclient = new soapclient('http://localhost/NuSoft/hello.wsdl','wsdl');
$soap_proxy = $soapclient->getProxy();
echo $soap_proxy->hello('dietrich');

?>