<?php

require_once('nusoap.php');
$parameters = array('dietrich');
$soapclient = new soapclient('http://localhost/php/NuSoft/hello.wsdl','wsdl');
echo $soapclient->call('hello',$parameters);

?>