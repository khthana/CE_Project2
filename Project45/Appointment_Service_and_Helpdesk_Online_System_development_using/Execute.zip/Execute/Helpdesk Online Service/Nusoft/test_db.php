<?php
$dsn = "db_Hardware";
$username = "";
$password = "";
$conn = ODBC_CONNECT($dsn,$username,$password); 
$query = "SELECT * FROM User ";
$result = odbc_exec($conn,$query);
$all = odbc_result($result,"str_Nickname");
//echo $all;
?>