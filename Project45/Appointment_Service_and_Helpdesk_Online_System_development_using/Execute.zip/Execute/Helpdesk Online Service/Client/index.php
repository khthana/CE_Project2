<?
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );
	if ($CatID=="")
	{
		$CatID = 0;
	}
	$parameters = array('CatID'=>$CatID);
	$soapclient = new soapclient($link.'index.php');
	$nrow =  $soapclient->call('numCat',$parameters);
function  ratemax($main,$compare,$index,$numask)
{
	if ($numask[0] != 0 )
	{
		$compare[1] = $compare[1]/$numask[0];
	}else
	{
		$compare[1] = 0;
	}
	if ($main[$index][1]<=$compare[1])
	{
		if ($main[$index][1]==$compare[1])
		{
			if ($main[$index][2] < $numask[0])
			{
				$main[$index][0] = $compare[0];
				$main[$index][1]=$compare[1];
				$main[$index][2]=$numask[0];
			}
		}else
		{
			$main[$index][0] = $compare[0];
			$main[$index][1]=$compare[1];
			$main[$index][2]=$numask[0];
		}
	}
}
?>
<html>
<head>
<title>CE- helpdesk &quot; �ء�Ӷ���դӵͺ����� &quot;</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<table width="100%" border="0" cellspacing="0" cellpadding="0" height="80">
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><img src="image/logo3.gif" width="100%" height="77"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="22">
  <tr bgcolor="#0000FF">
    <td width="29%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#999999">.</font>
        </font></b></font></div>
    </td>
    <td width="1%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%">
      <div align="center"><a href="login.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��͡�Թ</font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%">
      <div align="center"><a href="index.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">˹���á</font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="13%">
      <div align="center"><a href="bememberform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥ���Ҫԡ</font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="17%">
      <div align="center"><a href="beexpertform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥü������Ǫҭ</font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="12%">
      <div align="center"><a href="about.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font>
        </font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">|</font>
        </font></b></font></div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="476">
  <tr>
    <td width="30%" valign="top" align="center" height="494">
      <form method="post" action="search.php" name="">
        <table width="90%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td height="12" width="22%">&nbsp;</td>
            <td height="12" width="57%">&nbsp;</td>
            <td height="12" width="21%">&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC">
            <td height="37" width="22%" align="center" valign="middle"><font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����</font></b></font></td>
            <td height="37" width="57%" align="center" valign="middle">
              <input type="text" name="keyword" size="15" maxlength="100">
            </td>
            <td height="37" width="21%" align="center" valign="middle">
              <input type="image" border="0" src="image/butt-go-red.gif" width="22" height="22" name="submit">
            </td>
          </tr>
          <tr bgcolor="#FFFFCC">
            <td colspan="3" height="33">
              <div align="center"><a href="advan_search.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#6666FF">Advance
                SEARCH</font></a></div>
            </td>
          </tr>
          <tr>
            <td width="22%">&nbsp;</td>
            <td width="57%">&nbsp;</td>
            <td width="21%">&nbsp;</td>
          </tr>
        </table>
      </form>
		<?
			if (session_is_registered("mem_username"))
			{
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'mixfunction.php');
				$array =  $soapclient->call('CountAskAns',$parameters);
				$memarry =  $array['memarry'];
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>&nbsp;&nbsp;�Թ�յ�͹�Ѻ</b></font></td>
          <td width="40%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><div align="center"><b>&nbsp;�س <?echo $mem_username;?></b></div></font></td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;����Ҫԡ�����</font></td>
          <td bgcolor="#FFFFCC" width="40%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memarry['SubDate'];?></font></div>
          </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;��駶��/�ӵͺ</font></td>
          <?
				$memaskarry = $array['Umemaskarry'];
				$memansarry = $array['Umemansarry'];
			?>
          <td bgcolor="#FFFFCC" width="40%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
		?>
        <tr>
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;�Ӷ��/�ͺ</font></td>
          <?
				$memaskarry = $array['Ememaskarry'];
				$memansarry = $array['Ememansarry'];
			?>
          <td bgcolor="#FFFFCC" width="40%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;</font></td>
          <td bgcolor="#FFFFCC" width="40%">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="personal.php?expert=<?echo $mem_username;?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٢�������ǹ���</font></a></font></div>
          </td>
       </tr>
        <? }
			?>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="editprofile.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">��䢢�������ǹ���</font></a></font></div>
          </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<a href="new.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤ӵͺ����</font></a></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<a href="newq.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤Ӷ������</font></a>
            </div>
          </td>
        </tr>
        <?}  ?>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center"><a href="logout.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">Log
              Out</font></a></div>
          </td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <? } //end session mem_username registered
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td colspan="3">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>Top
              5 Rating</b></font></div>
          </td>
        </tr>
        <tr bgcolor="#FFFFCC">
          <td width="50%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">Expert
              Name</font></div>
          </td>
          <td width="30%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">Number
              of Voter</font></div>
          </td>
          <td width="20%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">Rate</font></div>
          </td>
        </tr>
        <?
			$parameters = array();
			$soapclient = new soapclient($link.'index.php');
			$numexpert =  $soapclient->call('numexpert',$parameters);

			$maxshow = 5;
			if ($numexpert < 5)
			{ $maxshow = $numexpert; }
			$ratearry[0][0] = -1;
			$ratearry[0][1] = -1;
			$ratearry[0][2] =-1;

			$ratearry[1][0] = -1;
			$ratearry[1][1] = -1;
			$ratearry[1][2] = -1;

			$ratearry[2][0] = -1;
			$ratearry[2][1] = -1;
			$ratearry[2][2] = -1;

			$ratearry[3][0] = -1;
			$ratearry[3][1] = -1;
			$ratearry[3][2] = -1;

			$ratearry[4][0] = -1;
			$ratearry[4][1] = -1;
			$ratearry[4][2] = -1;

			$ratearry[5][0] = -1;
			$ratearry[5][1] = -1;
			$ratearry[5][2] =-1;

			$count=0;
			$used = "";
			while ($count < $maxshow)
			{
				$parameters = array('count'=>$count,'used'=>$used);
				$soapclient = new soapclient($link.'index.php');
				$arrResult =  $soapclient->call('allresult',$parameters);

				$num = $arrResult['num'];
				for ($i=0; $i<$num;$i++)
				{
					$arrNum = 'arrNum'.$i;
					$allarry = $arrResult[$arrNum];	
					$parameters = array('compare'=>$allarry[0]);
					$soapclient = new soapclient($link.'index.php');
					$numask =  $soapclient->call('sumNumVote',$parameters);

					ratemax(&$ratearry,$allarry,$count,$numask);
					echo $a;echo $b;
				}
				if ($count <> 0)
				{ $used .= "," ; }
				$used .= "'".$ratearry[$count][0]."'" ;
				$pospoint = strpos($ratearry[$count][1],".");
				if(!$pospoint)
				{
					$ratearry[$count][1] .=".00";
				}else
				{
					$numlen = strlen($ratearry[$count][1]);
					if($numlen<$pospoint+3)
					{
						$ratearry[$count][1] .= "0";
					}else
					{
						$ratearry[$count][1] = substr($ratearry[$count][1],0,$pospoint+3);
					}
				}
		?>
        <tr bgcolor="#FFFFCC">
          <td width="50%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="personal.php?expert=<?echo $ratearry[$count][0];?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF" ><? echo $ratearry[$count][0];?></font></a></td>
          <td width="30%"><div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><? echo $ratearry[$count][2];?></font></div></td>
          <td width="20%">
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><? echo $ratearry[$count][1];?></font></div>
          </td>
        </tr>
        <?
				$count = $count+1;
			}
		?>
      </table>
    </td>
    <td width="72%" valign="top" height="494">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td background="image/2color2.jpg" align="left" valign="top" width="7" height="6"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
          <td background="image/2color2.jpg" width="579"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
        </tr>
        <tr>
          <td width="7" background="image/shadow-topleft.gif" height="5" align="left" valign="top"><img src="image/blackdot.jpg" width="1" height="1"></td>
          <td width="579" height="5" background="image/shadow-top.gif" valign="top" align="left"><img src="image/blackdot.jpg" width="1" height="1"></td>
        </tr>
        <tr>
          <td height="485" background="image/shadow-left.gif" align="left" valign="top"><img src="image/transparent.gif" width="5" height="1"></td>
          <td height="620" bgcolor="#FFFFFF" align="left" valign="top"><img src="image/whitedot.jpg" width="1" height="1">
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="202">
                  <table width="100%" border="0" cellspacing="0" cellpadding="0" height="82">
                    <tr>
                      <td height="38">
                        <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif"><font face="MS Sans Serif, Microsoft Sans Serif"><font size="1">�Թ�յ�͹�Ѻ���
                          <font color="#FF3333">CE-helpdesk</font>...�ء�Ӷ�����سʧ���
                          ������դӵͺ</font></font></font></div>
                      </td>
                    </tr>
                    <tr>
                      <td height="35">
                        <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif"><font face="MS Sans Serif, Microsoft Sans Serif"><font size="1">�ԭ��Ѥ�����Ҫԡ
                          <font color="#FF3333">CE-helpdesk</font> �����Է�Ծ���ɵ�ҧ� </font></font></font></div>
                      </td>
                    </tr>
                    <tr>
                      <td height="38">
                        <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="1">������Ѥ��繼������Ǫҭ�����觻ѹ���������еͺ�Ӷ��������س��Ѵ
                          </font></div>
                      </td>
                    </tr>
                  </table>
                </td>
              </tr>
              <tr valign="top" align="center">
                <td>
                  <table width="80%" border="0" cellspacing="0" cellpadding="0">
					<tr bgcolor="#FFFFCC">
					  <td colspan="2">&nbsp;
<?
   if ($CatID == 0 )
   {
     echo '<font size="3" face="MS Sans Serif, Microsoft Sans Serif" color="#CC3300"><b>Category</b></font>';
   } else
   {
     echo '<font size="3" face="MS Sans Serif, Microsoft Sans Serif" color="#CC3300"><b>'.$CatName.'</b></font>';
   }
?>
					  </td>
					  <td colspan="2">&nbsp;</td>
					 </tr>
					<?
							$parameters = array('CatID'=>$CatID,'count'=>$count);
							$soapclient = new soapclient($link.'index.php');
							$arrResult =  $soapclient->call('resCat',$parameters);
							$nrow = $arrResult['num'];

							$count = 0;
							for ($i=0; $i<$nrow;$i++)
							{
								$arrNum = 'arrNum'.$i;
								$resCat = $arrResult[$arrNum];
								$count = $count+1;
							
								echo'<tr bgcolor="#FFFFCC"> ';
								echo '<td width="7%" valign="middle" align="center"><img src="image/circle.gif" width="15" height="15"></td>';
							echo '<td width="43%"><a href="prepost.php?CatID='.$resCat[0].'&CatName='.$resCat[1].'"><font color="#CC3300" size="2" face="MS Sans Serif, Microsoft Sans Serif">'.$resCat[1].'</font></a></td>';
							
							$count = $count+1;
							$i=$i+1;
							$arrNum = 'arrNum'.$i;
							$resCat = $arrResult[$arrNum];
							if ($nrow >= $count)
							{								
								echo '<td width="7%" valign="middle" align="center"><img src="image/circle.gif" width="15" height="15"></td>';
  	              			echo '<td width="43%"><a href="prepost.php?CatID='.$resCat[0].'&CatName='.$resCat[1].'"><font color="#CC3300" size="2" face="MS Sans Serif, Microsoft Sans Serif">'.$resCat[1].'</font></a></td>';

							}else
							{
								echo '<td width="7%">&nbsp;</td>';
								echo '<td width="43%">&nbsp;</td>';
							}
  		            	echo '</tr>';
						}
					?>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>