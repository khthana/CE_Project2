<?
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );
	if (!session_is_registered("mem_username"))
	{		
		echo "<meta http-equiv='refresh' content='1;URL=login.php'>";
		exit;
	}

	$firstname = trim($firstname);
	$lastname = trim($lastname);
	$link = trim($link);
	$detail = trim($detail);
	$email = trim($email);
	$mem_password = trim($mem_password);
	if (strlen($mem_password) < 6)
	{ 		
		echo "<meta http-equiv='refresh' content='1;URL=editprofile.php?flag=P'>";
		exit;
	} 	
	$parameters = array('mem_username'=>$mem_username);
	$soapclient = new soapclient($link.'updateprofile.php');
	$nrow =  $soapclient->call('chkEmail',$parameters);
	if ($nrow != 0 )
	{ 		
		echo "<meta http-equiv='refresh' content='1;URL=editprofile.php?flag=E'>";
		exit;
	} else
	{
		$parameters = array('mem_username'=>$mem_username);
		$soapclient = new soapclient($link.'updateprofile.php');
		$chkBan =  $soapclient->call('chkBan',$parameters);
		if ($chkBan == "F")
		{		
			echo "<meta http-equiv='refresh' content='1;URL=editprofile.php?flag=ban'>";
			exit;
		}			
		$detail = trim($detail);
		if ($Picture!="")
		{
			if ($Picture != none )
			{
				$realname = $HTTP_POST_FILES['Picture']['name']; 
				$lenght = strlen($realname);
				$pos=strpos($realname,"'");
				if ($pos)
				{		
					$str1 = substr($realname,0,$pos-1);
					$str2 = substr($realname,$pos+1,$lenght);		
					$realname = $str1.$str2;
				}	

				$FILE = file_exists ('tmp/'.$realname);
				$i = 0;
				while ($FILE)
				{							
					$i = $i+1;
					$lenght = strlen($realname);
					$pos=strpos($realname,".");
					$str1 = substr($realname,0,$pos-1);
					$str2 = substr($realname,$pos+1,$lenght);		
					$str1 = $str1.$i;
					$realname = $str1.'.'.$str2;					
					$FILE = file_exists ('tmp/'.$realname);
				} 

				if (is_uploaded_file($HTTP_POST_FILES['Picture']['tmp_name']))  
				{     
					copy($HTTP_POST_FILES['Picture']['tmp_name'],"tmp/$realname");
				}
				else
				{     
					echo "Upload not complete";   
				}
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'updateprofile.php');
				$filename = $soapclient->call('oldPic',$parameters);

				if ($filename!=$realname)
				{					
					unlink('tmp/'.$filename);
				}

		  		$parameters = array('mem_username'=>$mem_username,'data'=>$realname);
				$soapclient = new soapclient($link.'updateprofile.php');
				$soapclient->call('insertpic',$parameters);
			}
		}
		$parameters = array('mem_password'=>md5($mem_password),'firstname'=>$firstname,'lastname'=>$lastname,'email'=>$email,'Link'=>$Link,'detail'=>$detail,'mem_username'=>$mem_username);
		$soapclient = new soapclient($link.'updateprofile.php');
		$soapclient->call('updatePWD',$parameters);

		$parameters = array('mem_username'=>$mem_username);
		$soapclient = new soapclient($link.'updateprofile.php');
		$status =  $soapclient->call('status',$parameters);
									
		echo "<meta http-equiv='refresh' content='1;URL=new.php'>";

	}
?>
<html>
<head>
<title>See Your New Question</title>
<html>
<head>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<?
/*echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';
���ʺ��ó����¹����Ф�� 4 �դ��������ҧ�Ф�Ѻ ���ҹ��趹Ѵ����ش��͡����¹���� PHP ��Ѻ
*///echo $a;echo $b;
?>
</body>
</html>