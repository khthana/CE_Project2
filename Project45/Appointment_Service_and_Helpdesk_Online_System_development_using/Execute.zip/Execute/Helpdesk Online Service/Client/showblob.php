<? 
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
/*		$parameters = array('mem_username'=>$mem_username);
		$soapclient = new soapclient($link.'showblob.php');
		$Picname =  $soapclient->call('pic',$parameters);
/*		echo	'<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';
	*/	if ($Picname)
		{
			$im = imageCreateFromJPEG('/tmp/$Picname');
			echo "<meta Content-type='image/jpeg'>";
//			header ("Content-type: image/jpeg"); 
			ImageJPEG($im);
			ImageDestroy($im);
		}
?>