<? 
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );

	if ($CatID=="")
	{
		$CatID = 0;
	}
	$parameters = array('CatID'=>$CatID);
	$soapclient = new soapclient($link.'questionboard.php');
	$nrow =  $soapclient->call('numParent',$parameters);
	if ($nrow !=0)
	{
		header ("Location: index.php?CatID=$CatID&CatName=$CatName");
		exit;
	}
function  ratemax($main,$compare,$index,$numask)

{
	if ($numask[0] != 0 )
	{
		$compare[1] = $compare[1]/$numask[0];
	}else
	{
		$compare[1] = 0;
	}
		if ($main[$index][1]<=$compare[1])
		{
			if ($main[$index][1]==$compare[1])
		{
			if ($main[$index][2] < $numask[0])
			{
				$main[$index][0] = $compare[0];
				$main[$index][1]=$compare[1];
				$main[$index][2]=$numask[0];
			}
		}else
		{
			$main[$index][0] = $compare[0];
			$main[$index][1]=$compare[1];
			$main[$index][2]=$numask[0];
		}
		}
}

?>
<html>
<head>
<title>&quot;Question Board&quot;</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<table width="100%" border="0" cellspacing="0" cellpadding="0" height="80">
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><img src="image/logo3.gif" width="100%" height="77"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="22">
  <tr bgcolor="#0000FF"> 
    <td width="29%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#999999">.</font> 
        </font></b></font></div>
    </td>
    <td width="1%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="login.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��͡�Թ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="index.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">˹���á</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="13%"> 
      <div align="center"><a href="bememberform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥ���Ҫԡ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="17%"> 
     <div align="center"><a href="beexpertform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥü������Ǫҭ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="12%"> 
      <div align="center"><a href="about.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font> 
        </font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">|</font> 
        </font></b></font></div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="476">
  <tr>
    <td width="30%" valign="top" align="center" height="494">
      <form method="post" action="search.php">
        <table width="90%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="12" width="22%">&nbsp;</td>
            <td height="12" width="57%">&nbsp;</td>
            <td height="12" width="21%">&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td height="37" width="22%" align="center" valign="middle"><font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����</font></b></font></td>
            <td height="37" width="57%" align="center" valign="middle"> 
              <input type="text" name="keyword" size="15" maxlength="100">
            </td>
            <td height="37" width="21%" align="center" valign="middle"> 
              <input type="image" border="0" src="image/butt-go-red.gif" width="22" height="22" name="submit">
            </td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td colspan="3" height="33"> 
              <div align="center"><a href="advan_search.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#6666FF">Advance 
                SEARCH</font></a></div>
            </td>
          </tr>
          <tr>
            <td width="22%">&nbsp;</td>
            <td width="57%">&nbsp;</td>
            <td width="21%">&nbsp;</td>
          </tr>
        </table>
      </form>
		<?	
			if (session_is_registered("mem_username"))
			{
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'mixfunction.php');
				$array =  $soapclient->call('CountAskAns',$parameters);	
				$memarry =  $array['memarry'];
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>&nbsp;&nbsp;�Թ�յ�͹�Ѻ</b></font></td>
          <td width="40%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><div align="center"><b>&nbsp;�س <?echo $mem_username;?></b></div></font></td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;����Ҫԡ�����</font></td>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memarry['SubDate'];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;��駶��/�ӵͺ</font></td>
          <?
				$memaskarry = $array['Umemaskarry'];
				$memansarry = $array['Umemansarry'];
			?>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
		?> 
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;�Ӷ��/�ͺ</font></td>
          <?
				$memaskarry = $array['Ememaskarry'];
				$memansarry = $array['Ememansarry'];
			?> 

          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;</font></td>
          <td bgcolor="#FFFFCC" width="40%">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="personal.php?expert=<?echo $mem_username;?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٢�������ǹ���</font></a></font></div>
          </td>
       </tr>
        <? } 
			?>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="editprofile.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">��䢢�������ǹ���</font></a></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="new.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤ӵͺ����</font></a></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?> 
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="newq.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤Ӷ������</font></a> 
            </div>
          </td>
        </tr>
        <?}  ?> 
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center"><a href="logout.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">Log 
              Out</font></a></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <? } //end session mem_username registered
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#999999"> 
          <td colspan="3"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b><font color="#FFFFFF">Top 
              5 Rating in <? echo $CatName;?></font></b></font></div>
          </td>
        </tr>
        <tr bgcolor="#FFFFCC"> 
          <td width="50%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">Expert 
              Name</font></div>
          </td>
          <td width="30%"><div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">Number 
              of Voter</font></div></td>
          <td width="20%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">Rate</font></div>
          </td>
        </tr>
        <?
			$parameters = array('CatID'=>$CatID);
			$soapclient = new soapclient($link.'questionboard.php');
			$numexpert =  $soapclient->call('numExpert',$parameters);
			$maxshow = 5;
			if ($numexpert < 5)
			{ $maxshow = $numexpert; }

			$ratearry[0][0] = -1;
			$ratearry[0][1] = -1;
			$ratearry[0][2] =-1;

			$ratearry[1][0] = -1;
			$ratearry[1][1] = -1;
			$ratearry[1][2] = -1;

			$ratearry[2][0] = -1;
			$ratearry[2][1] = -1;
			$ratearry[2][2] = -1;

			$ratearry[3][0] = -1;
			$ratearry[3][1] = -1;
			$ratearry[3][2] = -1;

			$ratearry[4][0] = -1;
			$ratearry[4][1] = -1;
			$ratearry[4][2] = -1;

			$ratearry[5][0] = -1;
			$ratearry[5][1] = -1;
			$ratearry[5][2] =-1;

			$count=0;
			$used = "";

			while ($count < $maxshow)
			{
				$parameters = array('count'=>$count,'CatID'=>$CatID,'used'=>$used);
				$soapclient = new soapclient($link.'questionboard.php');
				$arrResult =  $soapclient->call('allresult',$parameters);				

				$num = $arrResult['num'];			

				for ($i=0; $i<$num;$i++)
				{
					$arrNum = 'arrNum'.$i;
					$allarry = $arrResult[$arrNum];
					$parameters = array('CatID'=>$CatID,'compare'=>$allarry[0]);
					$soapclient = new soapclient($link.'questionboard.php');
					$numask =  $soapclient->call('NumVote',$parameters);
					ratemax(&$ratearry,$allarry,$count,$numask);
				}
				if ($count <> 0)
				{ $used .= "," ; }
				$used .= "'".$ratearry[$count][0]."'" ;
				$pospoint = strpos($ratearry[$count][1],".");
				if(!$pospoint)
				{
					$ratearry[$count][1] .=".00";
				}else
				{
					$numlen = strlen($ratearry[$count][1]);
					if($numlen<$pospoint+3)
					{
						$ratearry[$count][1] .= "0";
					}else
					{
						$ratearry[$count][1] = substr($ratearry[$count][1],0,$pospoint+3);
					}
				}
		?> 
        <tr bgcolor="#FFFFCC"> 
          <td width="50%">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="personal.php?expert=<?echo $ratearry[$count][0];?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF" ><? echo $ratearry[$count][0];?></font></a></td>
          <td width="30%"><div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><? echo $ratearry[$count][2];?></font></div></td>
          <td width="20%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><? echo $ratearry[$count][1];?></font></div>
          </td>
        </tr>
        <?
				$count = $count+1;
			}
		?> 
      </table>
      <p>&nbsp;</p>
    </td>
    <td width="72%" valign="top">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td background="image/2color2.jpg" align="left" valign="top" width="7" height="6"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
          <td background="image/2color2.jpg" width="579"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
        </tr>
        <tr>
          <td width="7" background="image/shadow-topleft.gif" height="3" align="left" valign="top"><img src="image/blackdot.jpg" width="1" height="1"></td>
          <td width="579" height="3" background="image/shadow-top.gif" valign="top" align="left"><img src="image/blackdot.jpg" width="1" height="1"></td>
        </tr>
<?
	$parameters = array('CatID'=>$CatID);
	$soapclient = new soapclient($link.'questionboard.php');
	$count1 =  $soapclient->call('numQ',$parameters);
?>
		  <tr>
          <td height="485" background="image/shadow-left.gif" align="left" valign="top"><img src="image/transparent.gif" width="5" height="1"></td>
          <td height="485" bgcolor="#FFFFFF" align="center" valign="top">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" height="168">
<? if ($count1 == 0)
		{ ?>
			   <tr>
                <td width="6%" height="40">&nbsp;</td>
                <td colspan="2" height="40"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#CC3300">�ѧ����դӶ��㹻��������</font></b></font></td>
                <td width="6%" height="40">&nbsp;</td>
              </tr>
		<? } 
		else 
		{ ?>
              <tr>
                <td width="6%" height="40">&nbsp;</td>
                <td colspan="2" height="40"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#CC3300">Question 
                  Board �ͧ�Ӷ�������� </font><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#CC3300"><?echo $CatName ?></font></b></font></b></font></td>
                <td width="6%" height="40">&nbsp;</td>
              </tr>
		        <tr>
                <td width="6%">&nbsp;</td>
                <td colspan="2" bgcolor="#FFFFCC">
                  <table width="100%"  border="0" cellpadding="1" cellspacing="2" height="95">
                    <tr> 
						<td>
		                  <div align="center">
                          <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#003898" >
                            <tr bgcolor="#003399"> 
                              <td height="27" width="51%"> 
                                <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif"><font face="MS Sans Serif, Microsoft Sans Serif"><font size="2"><font size="2"><font color="#FFFFFF"><b>��Ǣ��</b></font></font></font></font></font></div>
                            </td>
                            <td height="27" width="1%" bgcolor="#FFFFCC">&nbsp;</td>
                            <td height="27" width="28%"> 
                              <div align="center"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF">�����</font></b></div>
                            </td>
                            <td height="27" width="1%" bgcolor="#FFFFCC">&nbsp;</td>
                            <td height="27" width="20%"> 
                              <div align="center"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF">&nbsp;�ӹǹ�ӵͺ&nbsp;</font></b></div>
                            </td>
                          </tr>
                        </table>
						</div>
	                   </td></tr>
                    <tr>
						<td height="80" colspan="3">
					<?
							$tmp = $count1%10;
							$plus=1;
							if ($tmp==0 )
							{
								$plus = 0;
							}
							$totalpage = ($count1/10)+$plus;
							$point = strpos($totalpage,".");
							if ($point)
							{
								$totalpage =substr($totalpage,0,$point+1);
							}
							if (!isset($current))
							{
								$current = 0;
							}
							switch($page)
							{
								case "First":
									$current = 0;
									break;
								case "Prev":
									if ($current-1<0)
									{
										$current = 0;
									}else
									{
										$current = $current-1;
									}
									break;
								case "Next":
									if ($current+1> $totalpage-1)
									{
										$current = $totalpage-1;
									}else
									{
										$current = $current+1;
									}
									break;
								case "Last":
									$current=$totalpage-1;
									break;
							}
							$goto = $current*10;

				$parameters = array('CatID'=>$CatID,'goto'=>$goto);
				$soapclient = new soapclient($link.'questionboard.php');
				$arrQ =  $soapclient->call('allQ',$parameters);				
				$num = $arrQ['num'];			

				for ($i=0; $i<$num;$i++)
				{
					$arrNum = 'arrNum'.$i;
					$result1arr = $arrQ[$arrNum];
					
					$parameters = array('QID'=>$result1arr[0]);
					$soapclient = new soapclient($link.'questionboard.php');
					$result2arr =  $soapclient->call('countASK',$parameters);
					?>
                        <table width="100%" border="0" cellpadding="0" cellspacing="0" bordercolor="#003498" bgcolor="#6699CC" height="88">
                          <tr bgcolor="#99CCCC"> 
                            <td width="51%" height="29"> 
                              <div align="left"><a href="questiondetail.php?CatName=<? echo $CatName; ?>&CatID=<? echo $CatID ?>&QuestionID=<? echo $result1arr[0] ?>">
                               <b><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300"><?echo htmlspecialchars($result1arr[1])?></font></b></a></div>
                            </td>
                            <td  height="29" width="28%"> 
                              <div align="center"> 
                                <font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300"><b><?echo $result1arr[4]?><br></b></font>
								<font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#000000">����� 
                                  <?echo $result1arr[3]?></font>
                              </div>
                            </td>
                            <td width="21%" height="29"> 
                              <div align="center"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300"><?echo $result2arr?></font></b></div>
                            </td>
                          </tr>
                          <tr bgcolor="#99CCCC"> 
                            <td  colspan="3" height="55" width="51%"><font size="1"><font size="1"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#000000"><?echo htmlspecialchars($result1arr[2])?> 
                              ( <a href="questiondetail.php?CatName=<? echo $CatName; ?>&CatID=<? echo $CatID ?>&QuestionID=<? echo $result1arr[0] ?>"><font color="#CC3300">�٤ӵͺ�����</font></a> 
                              )</font></font></font></td>
                           </tr>
                          <tr>
                            <td colspan="3" height="19" bgcolor="#FFFFCC"><b></b></td>
                          </tr>
                        </table>

<? } ?>
<form method="post" action="questionboard.php">
                      <div align="center"></div>
                          <table width="100%" border="0" cellspacing="0" cellpadding="0">

                            <tr>
                          <td width="50%">
                            <div align="left"> <font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#333399">˹�ҷ��
                              <? echo $current+1;?> / <?echo $totalpage;?></font> </div>
                          </td>
                          <td width="50%">
                            <div align="center">
                              <input type="hidden" name="CatID" value="<?echo $CatID;?>">
                              <input type="hidden" name="CatName" value="<?echo $CatName;?>">
                              <input type="hidden" name="current" value="<?echo $current;?>">
                              <input type="submit" name="page" value="First">
                              <input type="submit" name="page" value="Prev">
                              <input type="submit" name="page" value="Next">
                              <input type="submit" name="page" value="Last">
                            </div>
                          </td>
                        </tr>
                      </table>
                    </form>
					<?
				}?>
                      </td>
                    </tr>
                  </table>
                </td>
                <td width="6%">&nbsp;</td>
              </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>