<? 
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );

	if ($CatID=="")
	{
		$CatID = 0;
	}			

	function recurprint ($mid,$mname)
	{
		$parameters = array('parentid'=>$mid);
		$soapclient = new soapclient($link.'advan_search.php');
		$numchild =  $soapclient->call('have_sub',$parameters);	
		
		if ($numchild==0)
		{
			echo    '<option value="'.$mid.'">    - '.$mname.'</option>';
		}else
		{
			$parameters = array('CatID'=>$mid);
			$soapclient = new soapclient($link.'advan_search.php');
			$result =  $soapclient->call('selectCat',$parameters);	
			if (!$result){exit;}
			$num = $result['num'];	
			for ($i=0; $i<$num;$i++)
			{
				$arrNum = 'arrNum'.$i;
				$child = $result[$arrNum];			 				
				recurprint ($child["CatID"],$child["CatName"]);			
			}
		}
	}
?>

<html>
<head>
<title>Advance Search</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<?/*
echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';
*/
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="80">
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><img src="image/logo3.gif" width="100%" height="77"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="22">
  <tr bgcolor="#0000FF"> 
    <td width="29%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#999999">.</font> 
        </font></b></font></div>
    </td>
    <td width="1%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="login.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��͡�Թ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="index.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">˹���á</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="13%"> 
      <div align="center"><a href="bememberform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥ���Ҫԡ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="17%"> 
      <div align="center"><a href="beexpertform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥü������Ǫҭ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="12%"> 
      <div align="center"><a href="about.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font> 
        </font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">|</font> 
        </font></b></font></div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="476">
  <tr>
    <td width="30%" valign="top" align="center" height="494"> 
      <form method="post" action="search.php">
        <table width="90%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="12" width="22%">&nbsp;</td>
            <td height="12" width="57%">&nbsp;</td>
            <td height="12" width="21%">&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td height="37" width="22%" align="center" valign="middle"><font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����</font></b></font></td>
            <td height="37" width="57%" align="center" valign="middle"> 
              <input type="text" name="keyword" size="15" maxlength="100">
            </td>
            <td height="37" width="21%" align="center" valign="middle"> 
              <input type="image" border="0" src="image/butt-go-red.gif" width="22" height="22" name="submit">
            </td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td colspan="3" height="33"> 
              <div align="center"><a href="advan_search.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#6666FF">Advance 
                SEARCH</font></a></div>
            </td>
          </tr>
        </table>
      </form>
		<?	
			if (session_is_registered("mem_username"))
			{
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'mixfunction.php');
				$array =  $soapclient->call('CountAskAns',$parameters);	
				$memarry =  $array['memarry'];
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>&nbsp;&nbsp;�Թ�յ�͹�Ѻ</b></font></td>
          <td width="40%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><div align="center"><b>&nbsp;�س <?echo $mem_username;?></b></div></font></td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;����Ҫԡ�����</font></td>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memarry['SubDate'];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;��駶��/�ӵͺ</font></td>
          <?
				$memaskarry = $array['Umemaskarry'];
				$memansarry = $array['Umemansarry'];
			?>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
		?> 
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;�Ӷ��/�ͺ</font></td>
          <?
				$memaskarry = $array['Ememaskarry'];
				$memansarry = $array['Ememansarry'];
			?> 
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;</font></td>
          <td bgcolor="#FFFFCC" width="40%">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="personal.php?expert=<?echo $mem_username;?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٢�������ǹ���</font></a></font></div>
          </td>
       </tr>
        <? } 
			?>  
        <tr>
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="editprofile.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">��䢢�������ǹ���</font></a></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="new.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤ӵͺ����</font></a></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?> 
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="newq.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤Ӷ������</font></a> 
            </div>
          </td>
        </tr>
        <?}  ?> 
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center"><a href="logout.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">Log 
              Out</font></a></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <? } //end session mem_username registered
		?>
    </td>
    <td width="72%" valign="top" height="494"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td background="image/2color2.jpg" align="left" valign="top" width="7" height="6"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
          <td background="image/2color2.jpg" width="579"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
        </tr>
        <tr>
          <td width="7" background="image/shadow-topleft.gif" height="5" align="left" valign="top"><img src="image/blackdot.jpg" width="1" height="1"></td>
          <td width="579" height="5" background="image/shadow-top.gif" valign="top" align="left"><img src="image/blackdot.jpg" width="1" height="1"></td>
        </tr>
        <tr>
          <td height="485" background="image/shadow-left.gif" align="left" valign="top"><img src="image/transparent.gif" width="5" height="1"></td>
          <td height="620" bgcolor="#FFFFFF" align="left" valign="top"><p><img src="image/whitedot.jpg" width="1" height="1"> 
            </p><form method="post" action="search.php" name="adv_search">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td colspan="2" bgcolor="#333399"> <div align="center"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="3" color="#FFFFFF">Advance 
                      SEARCH</font></b></div></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC">&nbsp; </td>
                  <td width="50%" bgcolor="#FFFFCC">&nbsp;</td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font color="#333399"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2">Keyword 
                      :</font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"> <input type="text" name="keyword" size="40" maxlength="100"> 
                  </td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font color="#333399"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2">Category 
                      :</font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"> <select name="cat">
                      <option value="0" selected>Any Category</option>
                      <?
						$parameters = array();
						$soapclient = new soapclient($link.'advan_search.php');
						$mainresult =  $soapclient->call('mainresult',$parameters);	
						$num = $mainresult['num'];	
						for ($i=0; $i<$num;$i++)
						{
							$arrNum = 'arrNum'.$i;
							$maincat = $mainresult[$arrNum];			 			

							$parameters = array('parentid'=>$maincat["CatID"]);
							$soapclient = new soapclient($link.'advan_search.php');
							$numchild =  $soapclient->call('have_sub',$parameters);	
							if ($numchild==0)
							{
					?>
                      <option value="<? echo $maincat["CatID"];?>"><?echo $maincat['CatName'];?></option>
                      <?
							}else
							{
					?>
                      <option value="0"><?echo "<< ".$maincat['CatName'] ." >>";?></option>
                      <?
								recurprint ($maincat["CatID"],$maincat["CatName"]);	
							} //end else
						} //end while $maincat
					?>
                    </select> </td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font color="#333399"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2">�ѹ����� 
                      :</font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC">&nbsp;</td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font size="1"><font face="MS Sans Serif, Microsoft Sans Serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ҡ</font></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"> 
                    <select name="day_ask1">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">1</option>
                      <option value="02">2</option>
                      <option value="03">3</option>
                      <option value="04">4</option>
                      <option value="05">5</option>
                      <option value="06">6</option>
                      <option value="07">7</option>
                      <option value="08">8</option>
                      <option value="09">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                      <option value="13">13</option>
                      <option value="14">14</option>
                      <option value="15">15</option>
                      <option value="16">16</option>
                      <option value="17">17</option>
                      <option value="18">18</option>
                      <option value="19">19</option>
                      <option value="20">20</option>
                      <option value="21">21</option>
                      <option value="22">22</option>
                      <option value="23">23</option>
                      <option value="24">24</option>
                      <option value="25">25</option>
                      <option value="26">26</option>
                      <option value="27">27</option>
                      <option value="28">28</option>
                      <option value="29">29</option>
                      <option value="30">30</option>
                      <option value="31">31</option>
                    </select>
                    <select name="month_ask1">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">JAN</option>
                      <option value="02">FEB</option>
                      <option value="03">MAR</option>
                      <option value="04">APR</option>
                      <option value="05">MAY</option>
                      <option value="06">JUN</option>
                      <option value="07">JUL</option>
                      <option value="08">AUG</option>
                      <option value="09">SEP</option>
                      <option value="10">OCT</option>
                      <option value="11">NOV</option>
                      <option value="12">DEC</option>
                    </select>
                    <select name="year_ask1">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <?
		$parameters = array();
		$soapclient = new soapclient($link.'advan_search.php');
		$askDate =  $soapclient->call('AskDate',$parameters);
		$ynum = $askDate['ynum'];

		if ($ynum != 0)
		{
			$mindate = $askDate['mindate'];
			$miny = substr($mindate[0],0,4);			
			$maxdate = $askDate['maxdate'];
			$maxy = substr($maxdate[0],0,4);


			for ($i=$miny; $i<=$maxy; $i++)
			{
?>
                      <option value="<?echo $i;?>"><?echo $i;?></option>
                      <?
			}
		}
?>
                    </select>
                    </font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif">�֧</font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"> 
                    <select name="day_ask2">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">1</option>
                      <option value="02">2</option>
                      <option value="03">3</option>
                      <option value="04">4</option>
                      <option value="05">5</option>
                      <option value="06">6</option>
                      <option value="07">7</option>
                      <option value="08">8</option>
                      <option value="09">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                      <option value="13">13</option>
                      <option value="14">14</option>
                      <option value="15">15</option>
                      <option value="16">16</option>
                      <option value="17">17</option>
                      <option value="18">18</option>
                      <option value="19">19</option>
                      <option value="20">20</option>
                      <option value="21">21</option>
                      <option value="22">22</option>
                      <option value="23">23</option>
                      <option value="24">24</option>
                      <option value="25">25</option>
                      <option value="26">26</option>
                      <option value="27">27</option>
                      <option value="28">28</option>
                      <option value="29">29</option>
                      <option value="30">30</option>
                      <option value="31">31</option>
                    </select>
                    <select name="month_ask2">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">JAN</option>
                      <option value="02">FEB</option>
                      <option value="03">MAR</option>
                      <option value="04">APR</option>
                      <option value="05">MAY</option>
                      <option value="06">JUN</option>
                      <option value="07">JUL</option>
                      <option value="08">AUG</option>
                      <option value="09">SEP</option>
                      <option value="10">OCT</option>
                      <option value="11">NOV</option>
                      <option value="12">DEC</option>
                    </select>
                    <select name="year_ask2">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <?
		$parameters = array();
		$soapclient = new soapclient($link.'advan_search.php');
		$askDate =  $soapclient->call('AskDate',$parameters);
		$ynum = $askDate['ynum'];

		if ($ynum != 0)
		{
			$mindate = $askDate['mindate'];
			$miny = substr($mindate[0],0,4);			
			$maxdate = $askDate['maxdate'];
			$maxy = substr($maxdate[0],0,4);


			for ($i=$miny; $i<=$maxy; $i++)
			{
?>
                      <option value="<?echo $i;?>"><?echo $i;?></option>
                      <?
			}
		}
?>
                    </select>
                    </font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td>&nbsp;</td>
                  <td bgcolor="#FFFFCC"><div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif">��͹��ѧ</font></div></td>
                  <td bgcolor="#FFFFCC"><input name="last_ask" type="text" id="last_ask" size="3">
                    <font size="1" face="MS Sans Serif, Microsoft Sans Serif">&nbsp;�ѹ 
                    </font><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">*������������ҵ���ѹ������͡</font></td>
                  <td>&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font color="#333399"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2">�ѹ���ͺ 
                      :</font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC">&nbsp;</td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font size="1"><font face="MS Sans Serif, Microsoft Sans Serif">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�ҡ</font></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"> 
                    <select name="day_ans1">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">1</option>
                      <option value="02">2</option>
                      <option value="03">3</option>
                      <option value="04">4</option>
                      <option value="05">5</option>
                      <option value="06">6</option>
                      <option value="07">7</option>
                      <option value="08">8</option>
                      <option value="09">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                      <option value="13">13</option>
                      <option value="14">14</option>
                      <option value="15">15</option>
                      <option value="16">16</option>
                      <option value="17">17</option>
                      <option value="18">18</option>
                      <option value="19">19</option>
                      <option value="20">20</option>
                      <option value="21">21</option>
                      <option value="22">22</option>
                      <option value="23">23</option>
                      <option value="24">24</option>
                      <option value="25">25</option>
                      <option value="26">26</option>
                      <option value="27">27</option>
                      <option value="28">28</option>
                      <option value="29">29</option>
                      <option value="30">30</option>
                      <option value="31">31</option>
                    </select>
                    <select name="month_ans1">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">JAN</option>
                      <option value="02">FEB</option>
                      <option value="03">MAR</option>
                      <option value="04">APR</option>
                      <option value="05">MAY</option>
                      <option value="06">JUN</option>
                      <option value="07">JUL</option>
                      <option value="08">AUG</option>
                      <option value="09">SEP</option>
                      <option value="10">OCT</option>
                      <option value="11">NOV</option>
                      <option value="12">DEC</option>
                    </select>
                    <select name="year_ans1">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <?
		$parameters = array();
		$soapclient = new soapclient($link.'advan_search.php');
		$ansDate =  $soapclient->call('AnsDate',$parameters);
		$ynum = $ansDate['ynum'];

		if ($ynum != 0)
		{
			$mindate = $ansDate['mindate'];
			$miny = substr($mindate[0],0,4);			
			$maxdate = $ansDate['maxdate'];
			$maxy = substr($maxdate[0],0,4);


			for ($i=$miny; $i<=$maxy; $i++)
			{
?>
                      <option value="<?echo $i;?>"><?echo $i;?></option>
                      <?
			}
		}
?>
                    </select>
                    </font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font size="1"><font face="MS Sans Serif, Microsoft Sans Serif">�֧</font></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"> 
                    <select name="day_ans2">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">1</option>
                      <option value="02">2</option>
                      <option value="03">3</option>
                      <option value="04">4</option>
                      <option value="05">5</option>
                      <option value="06">6</option>
                      <option value="07">7</option>
                      <option value="08">8</option>
                      <option value="09">9</option>
                      <option value="10">10</option>
                      <option value="11">11</option>
                      <option value="12">12</option>
                      <option value="13">13</option>
                      <option value="14">14</option>
                      <option value="15">15</option>
                      <option value="16">16</option>
                      <option value="17">17</option>
                      <option value="18">18</option>
                      <option value="19">19</option>
                      <option value="20">20</option>
                      <option value="21">21</option>
                      <option value="22">22</option>
                      <option value="23">23</option>
                      <option value="24">24</option>
                      <option value="25">25</option>
                      <option value="26">26</option>
                      <option value="27">27</option>
                      <option value="28">28</option>
                      <option value="29">29</option>
                      <option value="30">30</option>
                      <option value="31">31</option>
                    </select>
                    <select name="month_ans2">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <option value="01">JAN</option>
                      <option value="02">FEB</option>
                      <option value="03">MAR</option>
                      <option value="04">APR</option>
                      <option value="05">MAY</option>
                      <option value="06">JUN</option>
                      <option value="07">JUL</option>
                      <option value="08">AUG</option>
                      <option value="09">SEP</option>
                      <option value="10">OCT</option>
                      <option value="11">NOV</option>
                      <option value="12">DEC</option>
                    </select>
                    <select name="year_ans2">
                      <option value="0" selected>Any</option>
                      <option value="99">Now</option>
                      <?
		$parameters = array();
		$soapclient = new soapclient($link.'advan_search.php');
		$ansDate =  $soapclient->call('AnsDate',$parameters);
		$ynum = $ansDate['ynum'];

		if ($ynum != 0)
		{
			$mindate = $ansDate['mindate'];
			$miny = substr($mindate[0],0,4);			
			$maxdate = $ansDate['maxdate'];
			$maxy = substr($maxdate[0],0,4);


			for ($i=$miny; $i<=$maxy; $i++)
			{
?>
                      <option value="<?echo $i;?>"><?echo $i;?></option>
                      <?
			}
		}
?>
                    </select>
                    </font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td>&nbsp;</td>
                  <td bgcolor="#FFFFCC"><div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif">��͹��ѧ</font></div></td>
                  <td bgcolor="#FFFFCC"><input name="last_ans" type="text" id="last_ans" size="3">
                    <font size="1" face="MS Sans Serif, Microsoft Sans Serif">&nbsp;�ѹ 
                    </font><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">*������������ҵ���ѹ������͡</font><font size="1" face="MS Sans Serif, Microsoft Sans Serif">&nbsp; 
                    </font></td>
                  <td>&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font color="#333399"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2">���ҵ�� 
                      :</font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"> <font size="1" face="MS Sans Serif, Microsoft Sans Serif"> 
                    <input type="checkbox" name="subject" value="and">
                    ��Ǣ�� 
                    <input type="checkbox" name="question" value="and">
                    �Ӷ�� 
                    <input type="checkbox" name="answer" value="and">
                    �ӵͺ</font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font color="#333399"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="2">�������Ǫҭ 
                      :</font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"> <input type="text" name="expert" size="20" maxlength="10"> 
                    <font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">* 
                    ���������Ф��ҷء��</font><font face="MS Sans Serif, Microsoft Sans Serif" size="1">&nbsp; 
                    </font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC">&nbsp;</td>
                  <td width="50%" bgcolor="#FFFFCC">&nbsp; </td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td colspan="2" bgcolor="#FFFFCC"> <div align="center"> 
                      <input type="submit" name="Submit" value="Submit">
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                      <input type="reset" name="Reset" value="Reset">
                    </div></td>
                  <td width="10%">&nbsp;</td>
                </tr>
                <tr> 
                  <td width="10%">&nbsp;</td>
                  <td width="30%" bgcolor="#FFFFCC"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#333399"></font></b></font></div></td>
                  <td width="50%" bgcolor="#FFFFCC"><font face="MS Sans Serif, Microsoft Sans Serif" size="1">&nbsp; 
                    </font></td>
                  <td width="10%">&nbsp;</td>
                </tr>
              </table>
            </form>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>