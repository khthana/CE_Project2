<?
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );

	$parameters = array('expert'=>$expert,'CatID'=>$CatID,'score'=>$score);
	$soapclient = new soapclient($link.'rate.php');
	$soapclient->call('updateRate',$parameters);

	echo "<meta http-equiv='refresh' content='1;URL=$target'>";
	exit;
?>