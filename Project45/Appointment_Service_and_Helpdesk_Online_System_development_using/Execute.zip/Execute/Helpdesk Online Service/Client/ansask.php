<?
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );
	if (!session_is_registered("mem_username"))
	{
		echo "<meta http-equiv='refresh' content='1;URL=login.php'>";
		exit;
	}
	if (!isset($QID))
	{
		echo "<meta http-equiv='refresh' content='1;URL=new.php'>";
		exit;
	}

	$parameters = array('mem_username'=>$mem_username,'QID'=>$QID);
	$soapclient = new soapclient($link.'ansask.php');
	$arr =  $soapclient->call('ansask',$parameters);	

	$status = $arr["status"];
	$showarry = $arr["showarry"];
	$ansstatus = $arr["ansstatus"];

	if ($status != 'E')
	{
		echo "<meta http-equiv='refresh' content='1;URL=new.php'>";
		exit;
	}
	if ($Submit)
	{
		$parameters = array('mem_username'=>$mem_username,'asker'=>$asker,'EditStatus'=>$EditStatus,'QID'=>$QID,'CatID'=>$CatID,'Answer'=>$Answer);
		$soapclient = new soapclient($link.'ansask.php');
		$AnsAsk =  $soapclient->call('ansask1',$parameters);

		if($Flag03 != "F3")
		{
			echo "<meta http-equiv='refresh' content='1;URL=historya.php'>";
			exit;		
		}
	}
?>

<html>
<head>
<title>Answer Your Question</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<?/*
echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';
*/
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="80">
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><img src="image/logo3.gif" width="100%" height="77"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="22">
  <tr bgcolor="#0000FF"> 
    <td width="29%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#999999">.</font> 
        </font></b></font></div>
    </td>
    <td width="1%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="login.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��͡�Թ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="index.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">˹���á</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="13%"> 
      <div align="center"><a href="bememberform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥ���Ҫԡ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="17%"> 
      <div align="center"><a href="beexpertform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥü������Ǫҭ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="12%"> 
      <div align="center"><a href="about.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font> 
        </font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">|</font> 
        </font></b></font></div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="476">
  <tr>
    <td width="30%" valign="top" align="center" height="494"> 
      <form method="post" action="search.php" name="">
        <table width="90%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="12" width="22%">&nbsp;</td>
            <td height="12" width="57%">&nbsp;</td>
            <td height="12" width="21%">&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td height="37" width="22%" align="center" valign="middle"><font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����</font></b></font></td>
            <td height="37" width="57%" align="center" valign="middle"> 
              <input type="text" name="keyword" size="15" maxlength="100">
            </td>
            <td height="37" width="21%" align="center" valign="middle"> 
              <input type="image" border="0" src="image/butt-go-red.gif" width="22" height="22" name="submit">
            </td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td colspan="3" height="33"> 
              <div align="center"><a href="advan_search.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#6666FF">Advance 
                SEARCH</font></a></div>
            </td>
          </tr>
          <tr>
            <td width="22%">&nbsp;</td>
            <td width="57%">&nbsp;</td>
            <td width="21%">&nbsp;</td>
          </tr>
        </table>
      </form>
		<?	
			if (session_is_registered("mem_username"))
			{
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'mixfunction.php');
				$array =  $soapclient->call('CountAskAns',$parameters);	
				$memarry =  $array['memarry'];
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>&nbsp;&nbsp;�Թ�յ�͹�Ѻ</b></font></td>
          <td width="40%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><div align="center"><b>&nbsp;�س <?echo $mem_username;?></b></div></font></td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;����Ҫԡ�����</font></td>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memarry['SubDate'];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;��駶��/�ӵͺ</font></td>
          <?
				$memaskarry = $array['Umemaskarry'];
				$memansarry = $array['Umemansarry'];
			?>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
		?> 
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;�Ӷ��/�ͺ</font></td>
          <?
				$memaskarry = $array['Ememaskarry'];
				$memansarry = $array['Ememansarry'];
			?> 
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;</font></td>
          <td bgcolor="#FFFFCC" width="40%">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="personal.php?expert=<?echo $mem_username;?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٢�������ǹ���</font></a></font></div>
          </td>
       </tr>
        <? } 
			?>  
        <tr>
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="editprofile.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">��䢢�������ǹ���</font></a></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="new.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤ӵͺ����</font></a></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?> 
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="newq.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤Ӷ������</font></a> 
            </div>
          </td>
        </tr>
        <?}  ?> 
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center"><a href="logout.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">Log 
              Out</font></a></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <? } //end session mem_username registered
		?>
      <p>&nbsp;</p>
    </td>
    <td width="72%" valign="top" height="494">
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
          <td background="image/2color2.jpg" align="left" valign="top" width="7" height="6"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
          <td background="image/2color2.jpg" width="579"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
        </tr>
        <tr> 
          <td width="7" background="image/shadow-topleft.gif" height="5" align="left" valign="top"><img src="image/blackdot.jpg" width="1" height="1"></td>
          <td width="579" height="5" background="image/shadow-top.gif" valign="top" align="left"><img src="image/blackdot.jpg" width="1" height="1"></td>
        </tr>
        <tr> 
          <td height="485" background="image/shadow-left.gif" align="left" valign="top"><img src="image/transparent.gif" width="5" height="1"></td>
          <td height="485" bgcolor="#FFFFFF" align="left" valign="top"><img src="image/whitedot.jpg" width="1" height="1"> 
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr align="left" valign="middle"> 
                <td height="38"><font size="3" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">Welcome 
                  <? echo $mem_username;?> </font></b></font></td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
              <tr> 
                <td bgcolor=#999999 height=24 valign=top width="0%"><img height=4 
            src="image/tbl.gif" width=4></td>
                <th bgcolor=#999999 noWrap width="15%"><font color="#9999CC" face="MS Sans Serif, Microsoft Sans Serif" size="1"><b><a href="new.php"><font color="#FFFFFF">�ӵͺ����</font></a></b></font></th>
                <td align=right bgcolor=#999999 valign=top width="0%"><img height=4 
            src="image/tbr.gif" width=4></td>
                <td bgcolor="#FFFFFF" width="0%">&nbsp;</td>
                <td class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbl.gif" width=4></td>
                <th class=tbTD noWrap bgcolor="#999999" width="15%"><a href="history.php"><font color="#FFFFFF" size="1" face="MS Sans Serif, Microsoft Sans Serif"><b>�ٻ���ѵԡ�ö��</b></font></a></th>
                <td align=right class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbr.gif" width=4></td>
                <td bgcolor="#FFFFFF" width="0%">&nbsp;</td>
                <? if ($status=='E')
					{
			?> 
                <td class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbl.gif" width=4></td>
                <th class=tbTD noWrap bgcolor="#999999" width="15%"><font color="#FFFFFF" size="1" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#9999CC"><a href="newq.php"><font color="#FFFFFF">�Ӷ������</font></a></font></b></font></th>
                <td align=right class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbr.gif" width=4></td>
                <td bgcolor="#FFFFFF" width="0%">&nbsp;</td>
                <td class=tbTD valign=top bgcolor="#FFFFCC" width="0%"><img height=4 
            src="image/tbl.gif" width=4></td>
                <th class=tbTD noWrap bgcolor="#FFFFCC" width="15%"><font color="#9999CC" size="1" face="MS Sans Serif, Microsoft Sans Serif"><b>�ٻ���ѵԡ�õͺ</b></font></th>
                <td align=right class=tbTD valign=top bgcolor="#FFFFCC" width="0%"><img height=4 
            src="image/tbr.gif" width=4></td>
                <td bgcolor="#FFFFFF" width="0%">&nbsp;</td>
                <?	} ?> 
                <td class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbl.gif" width=4></td>
                <th class=tbTD bgcolor="#999999" width="22%"><a href="editprofile.php"><font color="#FFFFFF" size="1"><b><font face="MS Sans Serif, Microsoft Sans Serif">��䢢�������ǹ���</font></b></font></a></th>
                <td align=right class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbr.gif" width=4></td>
                <td bgcolor="#FFFFFF" width="0%">&nbsp;</td>
                <td class=tbTD valign=top bgcolor="#999999" width="0%"><img height=4 
            src="image/tbl.gif" width=4></td>
                <th class=tbTD bgcolor="#999999" width="20%"><a href="prepost.php"><font color="#FFFFFF" face="MS Sans Serif, Microsoft Sans Serif" size="1"><b>��駤Ӷ������</b></font></a></th>
                <td align=right class=tbTD valign=top bgcolor="#999999" width="1%"><img height=4 
            src="image/tbr.gif" width=4></td>
                <td width="<? if ($status=='E'){echo "5%";}else{echo "15%";}?>">&nbsp;</td>
              </tr>
            </table>
            <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#FFFFCC">
              <tr> 
                <td>&nbsp;</td>
              </tr>
              <tr> 
                <td> 
<? 
		if ($Flag03 == "F3")
		{
?> 
      	      <font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">������Һ㹢�ͤ����ͧ�س</font></b></font><br>
      	      <font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����Һ��辺��� :
				  <?
						for ($i=0;$i<$ban_i;$i++)
						{
							echo " $ban[$i]";
						}
				  ?>
				  </font></b></font><br>
<?
 		}
?>
                  <form method="post" action="ansask.php">
                    <div align="center"> 
                      <table width="90%" border="0" cellspacing="0" cellpadding="0">
                        <tr> 
                          <td width="18%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">�������ͧ 
                            :</font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;<?echo htmlspecialchars($showarry["Subject"]);?></font></td>
                        </tr>
                        <tr> 
                          <td width="18%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">�ѹ����� 
                            :</font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"color="#CC3300">&nbsp;<?echo $showarry["AskDate"];?></font></td>
                        </tr>
                        <tr>
                          <td width="18%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">����� 
                            : </font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;<?echo $showarry["mem_username"];?></font></td>
                        </tr>
                        <tr> 
                          <td width="18%" valign="top"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">�Ӷ�� 
                            :</font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;<?echo htmlspecialchars($showarry["Question"]);?></font></td>
                        </tr>
                        <tr>
                          <td width="18%">&nbsp;</td>
                          <td width="82%">&nbsp;</td>
                        </tr>
                       <?
						if ($ansstatus["AnsStatus"]=="N")
						{
							echo '
                        <tr> 
                          <td width="18%" valign="top"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">�ӵͺ 
                            :</font></td>
                          <td width="82%"> 
                            <div align="left"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"> 
                              <textarea name="Answer" cols="40" rows="10" wrap="PHYSICAL">'.$Answer.'</textarea>
                              </font></div>
                          </td>
                        </tr>
                        <tr> 
                          <td width="18%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;</font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"> 
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            &nbsp;&nbsp; </font></td>
                        </tr>
                      </table>
                      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">';
						echo '<input type="hidden" name="asker" value="'.$showarry["mem_username"].'">';
						echo '<input type="hidden" name="QID" value="'.$QID.'">';
						echo '<input type="hidden" name="CatID" value="'.$showarry["CatID"].'">';
						echo '<input type="hidden" name="EditStatus" value="'.$showarry['EditStatus'].'"></font>';
						echo '
                        <input type="submit" name="Submit" value="Submit">
                        <input type="reset" name="Reset" value="Reset">
                        </font></div>
                    </div>
                    <div align="center"> </div>';
						} else
						{
							$parameters = array('QID'=>$QID,'mem_username'=>$mem_username);
							$soapclient = new soapclient($link.'ansask.php');
							$ansarry =  $soapclient->call('ansarry',$parameters);
					?> 
                        <tr> 
                          <td width="18%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">�ѹ���ͺ 
                            :</font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">&nbsp;<?echo $ansarry["AnswerDate"];?></font></td>
                        </tr>
                        <tr> 
                          <td width="18%" valign="top"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300">�ӵͺ 
                            :</font></td>
                          <td width="82%"> 
                            <div align="left"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;<?echo htmlspecialchars($ansarry["Answer"]);?></font></div>
                          </td>
                        </tr>
                        <tr> 
                          <td width="18%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;</font></td>
                          <td width="82%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"> 
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                            &nbsp;&nbsp; </font></td>
                        </tr>
                      </table>
                    </div>
                    <?
						} //end else ansstatus
					?> 
                  </form>
                </td>
              </tr>
              <tr>
                <td>
                  <div align="center"><font color="#9999FF"><a href="historya.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">���꡷�������͡�Ѻ仴ٻ���ѵԡ�õͺ���</font></a></font></div>
                </td>
              </tr>
              <tr> 
                <td>&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>