<? 
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
	session_start( );
	if ($CatID=="")
	{
		$CatID = 0;
	}			
	$parameters = array('CatID'=>$CatID,'keyword'=>$keyword,'cat'=>$cat,'day_ask1'=>$day_ask1,'month_ask1'=>$month_ask1,'year_ask1'=>$year_ask1,'day_ask2'=>$day_ask2,'month_ask2'=>$month_ask2,'year_ask2'=>$year_ask2,'last_ask'=>$last_ask,'day_ans1'=>$day_ans1,'month_ans1'=>$month_ans1,'year_ans1'=>$year_ans1,'day_ans2'=>$day_ans2,'month_ans2'=>$month_ans2,'year_ans2'=>$year_ans2,'last_ans'=>$last_ans,'subject'=>$subject,'question'=>$question,'answer'=>$answer,'expert'=>$expert);
	$soapclient = new soapclient($link.'search.php');
	$searchsql =  $soapclient->call('searchsql',$parameters);	

	$parameters = array('searchsql'=>$searchsql);
	$soapclient = new soapclient($link.'search.php');
	$numsearch =  $soapclient->call('numsearch',$parameters);	
	
?>
<html>
<head>
<title>�š�ä���</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<?
/*echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';
*/
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="80">
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><img src="image/logo3.gif" width="100%" height="77"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="22">
  <tr bgcolor="#0000FF"> 
    <td width="29%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#999999">.</font> 
        </font></b></font></div>
    </td>
    <td width="1%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="login.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��͡�Թ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="index.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">˹���á</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="13%"> 
      <div align="center"><a href="bememberform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥ���Ҫԡ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="17%"> 
      <div align="center"><a href="beexpertform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥü������Ǫҭ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="12%"> 
      <div align="center"><a href="about.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font> 
        </font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">|</font> 
        </font></b></font></div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="476">
  <tr>
    <td width="30%" valign="top" align="center" height="494"> 
      <form method="post" action="search.php">
        <table width="90%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="12" width="22%">&nbsp;</td>
            <td height="12" width="57%">&nbsp;</td>
            <td height="12" width="21%">&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td height="37" width="22%" align="center" valign="middle"><font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����</font></b></font></td>
            <td height="37" width="57%" align="center" valign="middle"> 
              <input type="text" name="keyword" size="15" maxlength="100">
            </td>
            <td height="37" width="21%" align="center" valign="middle"> 
              <input type="image" border="0" src="image/butt-go-red.gif" width="22" height="22" name="submit">
            </td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td colspan="3" height="33"> 
              <div align="center"><a href="advan_search.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#6666FF">Advance 
                SEARCH</font></a></div>
            </td>
          </tr>
        </table>
      </form>
		<?	
			if (session_is_registered("mem_username"))
			{
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'mixfunction.php');
				$array =  $soapclient->call('CountAskAns',$parameters);	
				$memarry =  $array['memarry'];
		?>
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>&nbsp;&nbsp;�Թ�յ�͹�Ѻ</b></font></td>
          <td width="40%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><div align="center"><b>&nbsp;�س <?echo $mem_username;?></b></div></font></td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;����Ҫԡ�����</font></td>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memarry['SubDate'];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;��駶��/�ӵͺ</font></td>
          <?
				$memaskarry = $array['Umemaskarry'];
				$memansarry = $array['Umemansarry'];
			?>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
		?> 
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;�Ӷ��/�ͺ</font></td>
          <?
				$memaskarry = $array['Ememaskarry'];
				$memansarry = $array['Ememansarry'];
			?> 
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;</font></td>
          <td bgcolor="#FFFFCC" width="40%">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="personal.php?expert=<?echo $mem_username;?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٢�������ǹ���</font></a></font></div>
          </td>
       </tr>
        <? } 
			?>  
        <tr>
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="editprofile.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">��䢢�������ǹ���</font></a></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="new.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤ӵͺ����</font></a></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?> 
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="newq.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤Ӷ������</font></a> 
            </div>
          </td>
        </tr>
        <?}  ?> 
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center"><a href="logout.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">Log 
              Out</font></a></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <? } //end session mem_username registered
		?>
    </td>
    <td width="72%" valign="top" height="494"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td background="image/2color2.jpg" align="left" valign="top" width="7" height="6"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
          <td background="image/2color2.jpg" width="579"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
        </tr>
        <tr>
          <td width="7" background="image/shadow-topleft.gif" height="5" align="left" valign="top"><img src="image/blackdot.jpg" width="1" height="1"></td>
          <td width="579" height="5" background="image/shadow-top.gif" valign="top" align="left"><img src="image/blackdot.jpg" width="1" height="1"></td>
        </tr>
        <tr>
          <td height="485" background="image/shadow-left.gif" align="left" valign="top"><img src="image/transparent.gif" width="5" height="1"></td>
          <td height="620" bgcolor="#FFFFFF" align="center" valign="top"> 
            <p><?
				 if ($numsearch ==0)
				{
			?><img src="image/whitedot.jpg" width="1" height="1"> </p>
			 <p align="left"> <font color="#6666FF"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="3">&nbsp;&nbsp;&nbsp;��辺 keyword ���س��ͧ���</font></b></font></p>
          <? 
				}else
				{
			?>
		            <p align="left"> <font color="#6666FF"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="3">&nbsp;&nbsp;&nbsp;�鹾�<?echo " $numsearch ";?>�Ӷ��</font></b></font></p>
			<?
					$tmp = $numsearch%10;
					$plus=1;
					if ($tmp==0 )
					{
						$plus = 0;
					}
					$totalpage = ($num10)+$plus;
					$point = strpos($totalpage,".");
					if ($point)
					{
						$totalpage =substr($totalpage,0,$point+1);
					}
					if (!isset($current))
					{
						$current = 0;
					}
					switch($page)
					{
						case "First":
							$current = 0;
							break;
						case "Prev":
							if ($current-1<0)
							{
								$current = 0;
							}else
							{
								$current = $current-1;
							}
							break;
						case "Next":
							if ($current+1> $totalpage-1)
							{
								$current = $totalpage-1;
							}else
							{
								$current = $current+1;
							}
							break;
						case "Last":
							$current=$totalpage-1;
							break;
					}
						$goto = $current*10;
						$parameters = array('searchsql'=>$searchsql,'goto'=>$goto);
						$soapclient = new soapclient($link.'search.php');
						$searchresult =  $soapclient->call('searchNext',$parameters);	
						$num = $searchresult['num'];	
		if ($expert =="")
			{
		?>
            <table width="95%" border="1" cellspacing="0" cellpadding="0" bordercolor="#303498">
              <tr bgcolor="#333399"> 
                <td width="40%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ǣ��</font></b></font></div>
                </td>
                <td width="15%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF"><b>�����</b></font></div>
                </td>
                <td width="15%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF"><b>�ѹ�����</b></font></div>
                </td>
              </tr>
              <?
					for ($i=0; $i<$num;$i++)
					{
						$arrNum = 'arrNum'.$i;
						$searcharry = $searchresult[$arrNum];					
				?> 
              <tr> 
                <td width="40%">&nbsp;<a href="showsearch.php?QID=<?echo $searcharry[0];?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF"><?echo $searcharry[1];?></font></a></td>
                <td width="15%"> 
                  <div align="center">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $searcharry[2];?></font></div>
                </td>
                <td width="15%">
                  <div align="center">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2" ><?echo $searcharry[3];?></font></div>
                </td>
              </tr>
              <?
					} //end while $searcharry 
				?> 
            </table>
            <p>&nbsp;</p>
			<?
				}else  //end if $expert ==""
				{
			?>
            <table width="95%" border="1" cellspacing="0" cellpadding="0" bordercolor="#303498">
              <tr bgcolor="#333399">
                <td width="40%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ǣ��</font></b></font></div>
                </td>
                <td width="13%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF"><b>�����</b></font></div>
                </td>
                <td width="17%">
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF"><b>�ѹ�����</b></font></div>
                </td>
                <td width="13%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF"><b>���ͺ</b></font></div>
                </td>
                <td width="17%"> 
                  <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#FFFFFF"><b>�ѹ���ͺ</b></font></div>
                </td>
              </tr>
              <?
					for ($i=0; $i<$num;$i++)
					{
						$arrNum = 'arrNum'.$i;
						$searcharry = $searchresult[$arrNum];						
				?> 
              <tr> 
                <td width="40%">&nbsp;<a href="showsearch.php?QID=<?echo $searcharry[0];?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF"><?echo $searcharry[1];?></font></a></td>
                <td width="13%"> 
                  <div align="center">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $searcharry[2];?></font></div>
                </td>
                <td width="17%"> 
                  <div align="center">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2" ><?echo $searcharry[3];?></font></div>
                </td>
                <td width="13%">
<div align="center">&nbsp;<a href="personal.php?expert=<?echo $searcharry[4];?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF"><?echo $searcharry[4];?></font></a></div></td>
                <td width="17%"> 
                  <div align="center">&nbsp;<font face="MS Sans Serif, Microsoft Sans Serif" size="2" ><?echo $searcharry[5];?></font></div>
                </td>
              </tr>
              <?
					} //end while $searcharry 
				?>
            </table>
            <p>&nbsp;</p>
			<?
				}  //end if $expert ==""
			?> 
            <form method="post" action="<?getenv("URL");?>">
              <table width="90%" border="0" cellspacing="0" cellpadding="0">
                <tr> 
                  <td width="50%"> 
                    <div align="left"> <font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#333399">˹�ҷ�� 
                      <? echo $current+1;?> / <?echo $totalpage;?></font> </div>
                  </td>
                  <td width="50%">
                    <div align="center"> 
                      <input type="hidden" name="current" value="<?echo $current;?>">
                      <input type="hidden" name="keyword" value="<?echo $keyword;?>">
                      <input type="hidden" name="cat" value="<?echo $cat;?>">
                      <input type="hidden" name="subject" value="<?echo $subject;?>">
                      <input type="hidden" name="question" value="<?echo $question;?>">
                      <input type="hidden" name="answer" value="<?echo $answer;?>">
                      <input type="hidden" name="expert" value="<?echo $expert;?>">
                      <input type="hidden" name="day_ask1" value="<?echo $day_ask1;?>">
                      <input type="hidden" name="month_ask1" value="<?echo $month_ask1;?>">
                      <input type="hidden" name="year_ask1" value="<?echo $year_ask1;?>">
                      <input type="hidden" name="day_ask2" value="<?echo $day_ask2;?>">
                      <input type="hidden" name="month_ask2" value="<?echo $month_ask2;?>">
                      <input type="hidden" name="year_ask2" value="<?echo $year_ask2;?>">
                      <input type="hidden" name="day_ans1" value="<?echo $day_ans1;?>">
                      <input type="hidden" name="month_ans1" value="<?echo $month_ans1;?>">
                      <input type="hidden" name="year_ans1" value="<?echo $year_ans1;?>">
                      <input type="hidden" name="day_ans2" value="<?echo $day_ans2;?>">
                      <input type="hidden" name="month_ans2" value="<?echo $month_ans2;?>">
                      <input type="hidden" name="year_ans2" value="<?echo $year_ans2;?>">
					  <input type="hidden" name="year_ans2" value="<?echo $last_ask;?>">
					  <input type="hidden" name="year_ans2" value="<?echo $last_ans;?>">

                      <input type="submit" name="page" value="First">
                      <input type="submit" name="page" value="Prev">
                      <input type="submit" name="page" value="Next">
                      <input type="submit" name="page" value="Last">
                    </div>
                  </td>
                </tr>
              </table>
            </form>
			<?
				} //end else $numsearch ==0
			?>
            <p align="center">&nbsp; </p>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
</body>
</html>