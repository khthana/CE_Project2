<?
		session_start();
		session_unregister("mem_username");
		header ("Location: index.php");  
		exit;
?>