<?
	require_once ("../NuSoft/nusoap.php");
	require_once('link.inc');
session_start( );

$tmppath = "usr/local/www/htdocs/helpdesk/tmp/";

if ($flag01 =="")
{
	$flag01 = 'F';
};

if ($Submit)
{
	$parameters = array('mem_username'=>$mem_username,'mem_password'=>md5($mem_password),'Pwd'=>md5($Pwd),'FirstName'=>$FirstName,'LastName'=>$LastName,'Email'=>$Email,'Link'=>$Link,'detail'=>$detail,'subdate'=>$subdate);
	$soapclient = new soapclient($link.'beexpertform.php');
	$arr =  $soapclient->call('beExpert',$parameters);

	$flag01 = $arr['flag01'];					$Flag03 = $arr['Flag03'];
	$ban_i = $arr['ban_i'];						$ban = $arr['ban'];
	$place = $arr['place'];

	if(($Flag03 != "F3")&&($flag01=="T"))
	{
		if ($Picture!="")
		{
			if ($Picture != none )
			{
				$realname = $HTTP_POST_FILES['Picture']['name']; 				
				$lenght = strlen($realname);
				$pos=strpos($realname,"'");
				if ($pos)
				{		
					$str1 = substr($realname,0,$pos-1);
					$str2 = substr($realname,$pos+1,$lenght);		
					$realname = $str1.$str2;
				}	

				$FILE = file_exists ('tmp/'.$realname);
				$i = 0;
				while ($FILE)
				{							
					$i = $i+1;
					$lenght = strlen($realname);
					$pos=strpos($realname,".");
					$str1 = substr($realname,0,$pos-1);
					$str2 = substr($realname,$pos+1,$lenght);		
					$str1 = $str1.$i;
					$realname = $str1.'.'.$str2;					
					$FILE = file_exists ('tmp/'.$realname);
				} 

				if (is_uploaded_file($HTTP_POST_FILES['Picture']['tmp_name']))  
				{     
					copy($HTTP_POST_FILES['Picture']['tmp_name'],"tmp/$realname");
				}
				else
				{     
					echo "Upload not complete";   
				}
			
		  		$parameters = array('mem_username'=>$mem_username,'data'=>$realname);
				$soapclient = new soapclient($link.'beexpertform.php');
				$soapclient->call('insertpic',$parameters);
			}
		}
				
		if (session_is_registered("mem_username"))
		{
			session_unregister("mem_username");
		}
		session_register("mem_username");
		
		echo "<meta http-equiv='refresh' content='1;URL=selectnewcat.php'>";
		exit;
	}
}

?>
<html>
<head>
<title>Become Our Expert !</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
<style type="text/css">
<!--
body {  margin: 0px  0px; padding: 0px  0px}
a:link { color: #005CA2; text-decoration: none}
a:visited { color: #005CA2; text-decoration: none}
a:active { color: #0099FF; text-decoration: underline}
a:hover { color: #0099FF; text-decoration: underline}
-->
</style>

<!-- ############################# Scrollbars ############################# -->
<STYLE>
BODY { scrollbar-face-color: #6BB4FF; 
scrollbar-shadow-color: white; 
scrollbar-highlight-color: white; 
scrollbar-3dlight-color: #000099; 
scrollbar-track-color: #BCDBFA; 
scrollbar-arrow-color: rgb(250,250,250)
}
</STYLE>
<STYLE TYPE="text/css">
<!--
BODY{
overflow:scroll;
overflow-x:hidden;
}

.s1
{
  position  : absolute;
  font-size : 10pt;
  color     : blue;
  visibility: hidden;
}

.s2
{
  position  : absolute;
  font-size : 18pt;
  color     : red;
	visibility : hidden;
}

.s3
{
  position  : absolute;
  font-size : 14pt;
  color     : gold;
	visibility : hidden;
}

.s4
{
  position  : absolute;
  font-size : 12pt;
  color     : lime;
	visibility : hidden;
}

//-->
</STYLE>
<style>
.spanstyle {
	position:absolute;
	visibility:visible;
	top:-50px;
	font-size:10pt;
	font-family:Verdana;
      font-weight:bold;
	color:red;
}
</style>
<!-- ############################# Mouse ############################# -->
<script>
var x,y
var step=20
var flag=0

// Your snappy message. Important: the space at the end of the sentence!!!
var message="HelpDesk Online System "
message=message.split("")

var xpos=new Array()
for (i=0;i<=message.length-1;i++) {
	xpos[i]=-50
}

var ypos=new Array()
for (i=0;i<=message.length-1;i++) {
	ypos[i]=-50
}

function handlerMM(e){
	x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
	y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
	flag=1
}

function makesnake() {
	if (flag==1 && document.all) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("span"+(i)+".style")
    		thisspan.posLeft=xpos[i]
			thisspan.posTop=ypos[i]
    	}
	}
	
	else if (flag==1 && document.layers) {
    	for (i=message.length-1; i>=1; i--) {
   			xpos[i]=xpos[i-1]+step
			ypos[i]=ypos[i-1]
    	}
		xpos[0]=x+step
		ypos[0]=y
	
		for (i=0; i<message.length-1; i++) {
    		var thisspan = eval("document.span"+i)
    		thisspan.left=xpos[i]
			thisspan.top=ypos[i]
    	}
	}
		var timer=setTimeout("makesnake()",30)
}

</script>

</head>

<!-- ############################# End Head #############################-->

<body background="image/2color2.jpg" onLoad="makesnake()" style="width:100%;overflow-x:hidden;overflow-y:scroll">

<!-- ############################# Mouse #############################-->
<script>
<!-- Beginning of JavaScript -

for (i=0;i<=message.length-1;i++) {
    document.write("<span id='span"+i+"' class='spanstyle'>")
	document.write(message[i])
    document.write("</span>")
}

if (document.layers){
	document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
// - -->
</script>
<!-- // - End of JavaScript - --> 

<?/*
echo '<xmp>'.$soapclient->request.'</xmp>';
echo '<xmp>'.$soapclient->response.'</xmp>';
*/
?>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="80">
  <tr>
    <td width="100%" bgcolor="#FFFFFF"><img src="image/logo3.gif" width="100%" height="77"></td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="22">
  <tr bgcolor="#0000FF"> 
    <td width="29%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#999999">.</font> 
        </font></b></font></div>
    </td>
    <td width="1%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="login.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��͡�Թ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="9%"> 
      <div align="center"><a href="index.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">˹���á</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>

    </td>
    <td width="13%"> 
      <div align="center"><a href="bememberform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥ���Ҫԡ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="17%"> 
      <div align="center"><a href="beexpertform.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">��Ѥü������Ǫҭ</font></b></font></a></div>
    </td>
    <td width="2%"> 
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF">|</font></b></font></div>
    </td>
    <td width="12%"> 
      <div align="center"><a href="about.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">����ǡѺ���</font> 
        </font></b></font></a></div>
    </td>
    <td width="2%">
      <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b><font color="#FFFFFF"><font color="#FFFFFF">|</font> 
        </font></b></font></div>
    </td>
  </tr>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" height="476">
  <tr>
    <td width="30%" valign="top" align="center" height="539"> 
      <form method="post" action="search.php">
        <table width="90%" border="0" cellspacing="0" cellpadding="0">
          <tr> 
            <td height="12" width="22%">&nbsp;</td>
            <td height="12" width="57%">&nbsp;</td>
            <td height="12" width="21%">&nbsp;</td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td height="37" width="22%" align="center" valign="middle"><font size="2" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����</font></b></font></td>
            <td height="37" width="57%" align="center" valign="middle"> 
              <input type="text" name="keyword" size="15" maxlength="100">
            </td>
            <td height="37" width="21%" align="center" valign="middle"> 
              <input type="image" border="0" src="image/butt-go-red.gif" width="22" height="22" name="submit">
            </td>
          </tr>
          <tr bgcolor="#FFFFCC"> 
            <td colspan="3" height="33"> 
              <div align="center"><a href="advan_search.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#6666FF">Advance 
                SEARCH</font></a></div>
            </td>
          </tr>
        </table>
      </form>
		<?	
			if (session_is_registered("mem_username"))
			{				
				$parameters = array('mem_username'=>$mem_username);
				$soapclient = new soapclient($link.'mixfunction.php');
				$array =  $soapclient->call('CountAskAns',$parameters);	
				$memarry =  $array['memarry'];
		?>        
      <table width="90%" border="0" cellspacing="0" cellpadding="0">
        <tr bgcolor="#FFFFCC">
          <td width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><b>&nbsp;&nbsp;�Թ�յ�͹�Ѻ</b></font></td>
          <td width="40%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#CC3300"><div align="center"><b>&nbsp;�س <?echo $mem_username;?></b></div></font></td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;����Ҫԡ�����</font></td>
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memarry['SubDate'];?></font></div>
          </td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;��駶��/�ӵͺ</font></td>
          <?
				$memaskarry = $array['Umemaskarry'];
				$memansarry = $array['Umemansarry'];
			?> 
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?> 
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;�Ӷ��/�ͺ</font></td>
          <?
				$memaskarry = $array['Ememaskarry'];
				$memansarry = $array['Ememansarry'];	
			?> 
          <td bgcolor="#FFFFCC" width="40%"> 
            <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><?echo $memaskarry[0]." / ".$memansarry[0];?></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" width="60%"><font face="MS Sans Serif, Microsoft Sans Serif" size="2">&nbsp;&nbsp;</font></td>
          <td bgcolor="#FFFFCC" width="40%">&nbsp;</td>
        </tr>
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="personal.php?expert=<?echo $mem_username;?>"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٢�������ǹ���</font></a></font></div>
          </td>
       </tr>
        <? } 
			?>        
        <tr>
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<font color="#9999FF"><a href="editprofile.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">��䢢�������ǹ���</font></a></font></div>
          </td>
        </tr>
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="new.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤ӵͺ����</font></a></div>
          </td>
        </tr>
        <? if ($memarry["MemberStatus"]=="E")
				{
			?> 
        <tr> 
          <td bgcolor="#FFFFCC" colspan="2"> 
            <div align="center">&nbsp;&nbsp;<a href="newq.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">�٤Ӷ������</font></a> 
            </div>
          </td>
        </tr>
        <?}  ?> 
        <tr>
          <td bgcolor="#FFFFCC" colspan="2">
            <div align="center"><a href="logout.php"><font face="MS Sans Serif, Microsoft Sans Serif" size="2" color="#6666FF">Log 
              Out</font></a></div>
          </td>
        </tr>
        <tr> 
          <td>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
      </table>
      <? } //end session mem_username registered
		?> </td>
    <td width="72%" valign="top" height="539"> 
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr>
          <td background="image/2color2.jpg" align="left" valign="top" width="7" height="6"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
          <td background="image/2color2.jpg" width="579"><img src="image/2color2_6pix.jpg" width="1" height="6"></td>
        </tr>
        <tr>
          <td width="7" background="image/shadow-topleft.gif" height="5" align="left" valign="top"><img src="image/blackdot.jpg" width="1" height="1"></td>
          <td width="579" height="5" background="image/shadow-top.gif" valign="top" align="left"><img src="image/blackdot.jpg" width="1" height="1"></td>
        </tr>
        <tr>
          <td height="485" background="image/shadow-left.gif" align="left" valign="top"><img src="image/transparent.gif" width="5" height="1"></td>
          <td height="485" bgcolor="#FFFFFF" align="left" valign="top"><img src="image/whitedot.jpg" width="1" height="1">
            <table width="100%" border="0" cellspacing="0" cellpadding="0" height="484">
              <?
				if ($flag01 == "F"){
					echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
	             <td colspan="2"> 
                <div align="center"><font size="1"><b><font face="MS Sans Serif, Microsoft Sans Serif">��Ѥ���Ҫԡ</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
               <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif">��سҡ�͡Ẻ�����</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
		} elseif ($flag01 == "T0") {
				 	echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2"> 
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">��س���� Login Name ����</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">&nbsp;</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
				$flag01 = "F"; 
				} elseif ($flag01 == "T4") {
				 	echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2"> 
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">��س���� E-mail ����</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">&nbsp;</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
				$flag01 = "F"; 
				} elseif ($flag01 == "T5") {
				 	echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2"> 
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">Password ����Թ�</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">&nbsp;</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
				$flag01 = "F"; 
				} elseif ($flag01 == "T1") {
				 	echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2"> 
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">�ռ���� Login Name �������</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">��س�����¹ Login Name ����</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
				$flag01 = "F"; 
				} elseif ($flag01 == "T3") {
				 	echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2"> 
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">�ռ���� Email �������</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">��س�����¹ Email �������͵�Ǩ�ͺ�ա����</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
				$flag01 = "0"; 
				}	elseif ($flag01 == "T2") {
					echo '
				 <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2"> 
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">Password ���ç�ѹ</font></b></font></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>
              <tr> 
                <td width="7%">&nbsp;</td>
                <td colspan="2">
                  <div align="center"><b><font size="1" face="MS Sans Serif, Microsoft Sans Serif" color="#FF3333">��س���� Password �����ա����</font></b></div>
                </td>
                <td width="7%">&nbsp;</td>
              </tr>';
				$flag01 = "F";}
				?>
              <tr> 
                <td width="2%" height="450">&nbsp;</td>
                <td width="98%" height="450" bgcolor="#FFFFCC"> 
                  <?
				if ($Flag03 == "F3")
				{
					$flag01 = "F"; 
			?>
                  <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">������Һ� 
                    <? echo $place;?>�ͧ�س</font></b></font></div>
                  <div align="center"><font size="1" face="MS Sans Serif, Microsoft Sans Serif"><b><font color="#CC3300">����Һ��辺��� 
                    : 
                    <?
					for ($i=0;$i<$ban_i;$i++)
					{
						echo " $ban[$i]";
					}
			?>
                    </font></b></font></div>
                  <? }
?>
                  <form method="post" action="beexpertform.php" name="beexpert" enctype = "multipart/form-data">
                    <table width="100%" border="0" cellspacing="0" cellpadding="0" height="363">
                      <tr> 
                        <td width="48%" height="41" valign="middle" align="center"> 
                          <div align="center"> 
                            <p><font size="1" face="MS Sans Serif, Microsoft Sans Serif"><b>Login 
                              Name</b></font><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300"> 
                              <br>
                              </font><font size="1" face="MS Sans Serif, Microsoft Sans Serif"> 
                              (Max. 10 Characters)</font></p>
                          </div></td>
                        <td width="52%" height="41"> 
                          <?
									echo '<input type="text" name="mem_username" maxlength="10"  value="'.$mem_username.'">';
						  ?>
                          <font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">**</font></td>
                      </tr>
                      <tr> 
                        <td width="48%" height="34"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"><b>Password</b> 
                            ( 6-10 Characters)</font></div></td>
                        <td width="52%" height="34"> <input type="password" name="mem_password" maxlength="10"> 
                          <font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">**</font> 
                        </td>
                      </tr>
                      <tr> 
                        <td width="48%" height="36"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="1"><b>Confirm 
                            Password</b></font></div></td>
                        <td width="52%" height="36"> <input type="password" name="Pwd" maxlength="10"> 
                          <font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">**</font> 
                        </td>
                      </tr>
                      <tr> 
                        <td width="48%" height="33"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="2"><b>����</b></font></div></td>
                        <td width="52%" height="33"> 
                          <?
									echo '<input type="text" name="FirstName" maxlength="20" value="'.$FirstName.'">';
						  ?>
                        </td>
                      </tr>
                      <tr> 
                        <td width="48%" height="33"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="2">���ʡ��</font></b></font></div></td>
                        <td width="52%" height="33"> 
                          <?
									echo '<input type="text" name="LastName" maxlength="20" value="'.$LastName.'">';
						  ?>
                        </td>
                      </tr>
                      <tr> 
                        <td width="48%" height="36"> <div align="center"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="1">E-mail</font></b></div></td>
                        <td width="52%" height="36"> 
                          <?
									echo '<input type="text" name="Email" maxlength="30"  value="'.$Email.'">';
						  ?>
                          <font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">**</font></td>
                      </tr>
                      <tr> 
                        <td width="48%" height="39"> <div align="center"> 
                            <p><b><font face="MS Sans Serif, Microsoft Sans Serif" size="1">�ٻ�Ҿ</font></b></p>
                          </div></td>
                        <td width="52%" height="39"> <b><font face="MS Sans Serif, Microsoft Sans Serif" size="1"> 
                          </font></b> <input type="file" name="Picture"> </td>
                      </tr>
                      <tr> 
                        <td width="48%" height="37"> <div align="center"><b><font face="MS Sans Serif, Microsoft Sans Serif" size="1">Link</font></b></div></td>
                        <td width="52%" height="37"> <b><font face="MS Sans Serif, Microsoft Sans Serif" size="1">&nbsp;&nbsp;http://</font></b>
                          <?
									echo '<input type="text" name="Link" maxlength="80"  value="'.$Link.'">';
						  ?>
                          <input type="hidden" name="subdate" value="<?echo date("Y-m-d");?>"> 
                        </td>
                      </tr>
                      <tr> 
                        <td width="48%" height="42"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif"><b><font size="2">������ѵ� 
                            ���� �йӵ���ͧ</font></b></font></div></td>
                        <td width="52%" height="42"> <textarea name="detail" cols="35" rows="10"><?echo $detail;?></textarea> 
                        </td>
                      </tr>
                      <td width="48%" height="42"> <div align="center"> 
                          <input type="submit" name="Submit" value="Submit">
                        </div></td>
                      <td width="52%" height="42"> <input type="reset" name="Reset" value="Reset"> 
                      </td>
                      </tr>
                      <tr> 
                        <td colspan="2" height="54"> <div align="center"><font face="MS Sans Serif, Microsoft Sans Serif" size="1" color="#CC3300">** 
                            ��ͧ��͡���ú </font> &nbsp;</div></td>
                      </tr>
                    </table>
                  </form></td>
                <td width="0%" height="450">&nbsp;</td>
              </tr>
              <tr> 
                <td width="2%">&nbsp;</td>
                <td width="98%">&nbsp;</td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>

</table>
</body>
</html>