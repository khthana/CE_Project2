package ui;
import java.net.* ;
import java.io.* ;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class SendFile extends Thread {
  private File filename ;
  private DataOutputStream netout ;
  private UserData user ;
  private DesEncrypter des;
  public SendFile(File filename,DataOutputStream out,UserData user) {
       this.filename = filename ;
       this.netout = out ;
       this.user = user ;
       this.des = new DesEncrypter() ;
  }
//------------------------------------------------------------
  public void run(){
      while(true){
        try{
             FileInputStream in = new FileInputStream(this.filename) ;
             des.setSecretKey(this.user.getSecretKey(),"File") ;
            // FileTransfer f = new FileTransfer() ;
            // f.FileProcess(this.filename) ;
            // f.show() ;
             des.encrypt(in,this.netout) ;
             this.stop() ;
        }catch(IOException e)
        { System.out.println(e.getMessage()) ;      }
      }
  }
//-----------------------------------------------------------
}