package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;
public class CmdPacket extends Packet {
  private ClientToServerCMD cmd  ;
  private ServerToClientCMD srv_cmd ;
  private Constant constant      ;
  private Util util ;
  //----------- extend header -----------------------------
  private short flags   ;
  private int reference ;
//-----------------------------------------------------------------------
  /*      not  complete        */
  public byte[] setPacket(int cmd,short seq,byte[] data){
    try{
           int ref = 0;
           byte chn = 0;
           short flag = 0;
           this.setData(data);
           //---------------------------------------------------------------
           while(seq == -1){   // if seq  is inittial,it will be random
             Random r = new Random()  ;
             seq = (short)r.nextInt() ;
           }
           //----------------------------------------------------------------
           seq++ ;
           ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
           DataOutputStream dataOut = new DataOutputStream(byteOut) ;
        //------------------------------------------------------------------------
           if(cmd == this.cmd.sendmsg){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00040006 ;
           }
           if(cmd == this.cmd.sendsmg2server){
              cmd = 0x00040006 ;
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00040007 ;
           }
           if(cmd == this.cmd.snack1_11){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00010011 ;
           }
           if(cmd == this.cmd.changestatus){
              cmd = 0x0001001e ;
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00130008 ;
           }
          else if(cmd == this.cmd.addbuddy){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00130008 ;
           }
          else if(cmd == this.cmd.updategroup){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00130009 ;
           }
          else if(cmd == this.cmd.addend){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00130012 ;
           }
          else if(cmd == this.cmd.addstart){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00130011 ;
           }
          else if(cmd == this.cmd.grantauth){
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00130014 ;
           }
          else if(cmd == this.cmd.searchbyuin){
              cmd = 0x00150002 ;
              chn = 0x02 ;
              flag = 0x0000;
              ref = 0x00110012 ;
           }
          else if(cmd == this.cmd.searchbypersinf){
               cmd = 0x00150002 ;
               chn = 0x02 ;
               flag = 0x0000;
               ref = 0x00120012 ;
           }
          else if(cmd == this.cmd.searchbymail){
               cmd = 0x00150002 ;
               chn = 0x02 ;
               flag = 0x0000;
               ref = 0x00130012 ;
           }
        //------------------------------------------------------------------------
          else if(cmd == this.cmd.families){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000017 ;
          }
        //------------------------------------------------------------------------
          else if(cmd == this.cmd.ratesrequest){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000006 ;
          }
        //-------------------------------------------------------------------------
          else if(cmd == this.cmd.ackrates){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000008 ;
         }
        //-------------------------------------------------------------------------
          else if(cmd == this.cmd.reqinfo){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x0000000e ;
          }
        //-------------------------------------------------------------------------
         else if(cmd == this.cmd.reqlists){
             chn = 0x02 ;
             flag = 0x0000 ;
             ref = 0x00000002 ;
          }
        //-------------------------------------------------------------------------
         else if(cmd == this.cmd.checkroster){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00010005 ;
          }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.reqlocation){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000002 ;
          }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.reqbuddy){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000002 ;
          }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.reqicbm){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000004 ;
          }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.reqbos){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000002 ;
         }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.rosterack){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000007 ;
          }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.setuserinfo){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000004 ;
           }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.seticbm){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref =  0x00000002 ;
          }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.setstatus){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x0000001e ;
         }
         //-------------------------------------------------------------------------
        else if(cmd == this.cmd.ready){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x00000002 ;
         }
        //----------------------------------------------------
         else if(cmd == this.cmd.reqroster){
               chn = 0x02 ;
               flag = 0x0000 ;
               ref = 0x01300002 ;
         }
        //----------------------------------------------------
        else if(cmd == this.cmd.metareqinfo){
               cmd  = 0x00150002 ;
               chn  = 0x02 ;
               flag = 0x0000 ;
               ref  = 0x01d00002 ;
         }
       //----------------------------------------------------
       else if(cmd == this.cmd.deletebuddy){
              chn  = 0x02 ;
              flag = 0x0000 ;
              ref  = 0x0013000a ;
        }
      //-------------------------------------------
        else if(cmd == this.cmd.reqofflinemsgs){
              chn  = 0x02 ;
              cmd  = 0x00150002 ;
              flag = 0x0000 ;
              ref  = 0x00150002 ;
        }
        //-------------------------------------------
        else if(cmd == this.cmd.ackofflinemsgs){
              chn  = 0x02 ;
              cmd  = 0x00150002 ;
              flag = 0x0000 ;
              ref  = 0x001500a9 ;
        }
        //-------------------------------------------
        else if(cmd == this.cmd.registeruser){
              chn  = 0x02 ;
              flag = 0x0000 ;
              ref  = 0x00040000 ;
        }
        //------------------------------------------
        else if(cmd == this.cmd.metasetgeneral){
              cmd  = 0x00150002 ;
              chn  = 0x02 ;
              flag = 0x0000 ;
              ref  = 0x00050000 ;
        }
        //------------------------------------------
        else if(cmd == this.cmd.metasetmore){
              cmd  = 0x00150002 ;
              chn  = 0x02 ;
              flag = 0x0000 ;
              ref  = 0x00060000 ;
        }
        //-------------------------------------------------------------------------
       // else if(cmd == this.cmd.reqofflinemsgs){
       //      this.setData(this.cmd.setReqOfflineMsgsPacket());
       //      ref = 0x00010002 ;
       //   }
         //-------------------------------------------------------------------------
      //  else if(cmd == this.cmd.ackofflinemsgs){
      //       this.setData(this.cmd.setAckofflinemsgs());
      //       ref = 0x00000000 ;
      //   }
        //-------------------------------------------------------------------------
           short length ;
           if(this.data == null)
             { length = 0 ;}
           else
             {length = (short)this.data.length ; }
           this.setHeader(this.constant.id,chn,seq,length,cmd,flag,ref);
           dataOut.write(this.header.getAllByte()); //put header
           //-------------------- put extend header ----------------------------
           dataOut.writeInt(this.header.getcommand());
           dataOut.writeShort(this.flags);
           dataOut.writeInt(this.reference);
           //-------------------------------------------------------------------
           if(this.data == null)
           {}
           else
           { dataOut.write(this.data) ; } //put data
           return byteOut.toByteArray() ; //return stream of packet[header+data]
         }
      catch(IOException e)
           { System.out.println(e.getMessage()); }
       return null;
  }
//--------------------------------------------------
  public void setExtendHeader(){

  }
//--------------------------------------------------
  public void  setHeader(byte id,byte chn,short seq,short length,int command,short flags,int ref){
         //set header for cmdPacket
         this.header.setId(id);
         this.header.setChannel(chn);
         this.header.setSequence(seq);
         this.header.setLength((short)(length + 10));
         this.header.setCommand(command);
         this.flags = flags ;
         this.reference = ref ;
  }
//--------------------------------------------------
  public void  setData(byte[] data1) {
         //set data for CmdPacket
         if(data1 == null)
           {
             this.data = null ;
           }
         else
           {
             this.data = new byte[data1.length] ;
             this.data = data1 ;
           }
  }
//--------------------------------------------------
  public void  analytePacket(byte[] packet) {
    byte[] temp = new byte[5] ;
    short   tmpshort ;
    int     tmpint  ;
    long    tmplong ;
    String  tmpstring ;
                 //-------------- normal command packet----------------
                 int  posdata = 16 ;
                 // chn_login = new Channel_LoginHeader() ;
                  this.header.setId(packet[0]);
                  this.header.setChannel(packet[1]) ;
                  // chn_login.setId(packet[0]);
                  // chn_login.setChannel(packet[1]);
                  //---------------------------------------
                  temp[0] = packet[2] ;
                  temp[1] = packet[3] ;
                  tmpshort = util.bytes2Short(temp) ;
                  this.header.setSequence(tmpshort);
                  //---------------------------------------
                  //chn_login.setSequence(tmpshort) ;
                  temp[0] = packet[4] ;
                  temp[1] = packet[5] ;
                  tmpshort = util.bytes2Short(temp) ;
                  this.header.setLength(tmpshort);
                  //chn_login.setLength(tmpshort);
                  //--------------------------------------
                  temp[0] = packet[10] ;
                  temp[1] = packet[11] ;
                  tmpshort = util.bytes2Short(temp) ;
                  this.flags = tmpshort ;
                  //---------------------------------------
                  temp[0] = packet[12] ;
                  temp[1] = packet[13] ;
                  temp[2] = packet[14] ;
                  temp[3] = packet[15] ;
                  tmpint = util.bytes2Int(temp) ;
                  this.reference = tmpshort ;
                  //----------------------------------------
                  temp[0] = packet[6]  ;
                  temp[1] = packet[7]  ;
                  temp[2] = packet[8]  ;
                  temp[3] = packet[9]  ;
                  tmpint = util.bytes2Int(temp) ;
                  this.header.setCommand(tmpint) ;
                  //------------------------------------------
                  this.data = new byte[this.header.getLength() - 10 ] ;
                  for(tmpint = 0; tmpint != this.header.getLength() - 10 ; tmpint++)
                    {
                        this.data[tmpint] = packet[posdata] ;
                        posdata++ ;
                    }
            //---------------------------- for sub command in cmd 0x00150003 ----------------------------
                if(this.header.getcommand() == 0x00150003)
                {
                  boolean flag = false;
                  String subcmd = "";
                  byte[] datatemp;
               /*   if (this.data[10] == (byte) 0x41) {
                    this.header.setCommand(this.srv_cmd.srv_offlinemsg);
                  }
                 else if (this.data[10] == (byte) 0x42) {
                   this.header.setCommand(this.srv_cmd.srv_doneofflinemsgs);
                 }
                 else  */if (this.data[14] == (byte) 0xae) {
                    this.header.setCommand(this.srv_cmd.srv_metalast);
                    subcmd = "search";
                    flag = true;
                  }
                  else if (this.data[14] == (byte) 0xa4) {
                    this.header.setCommand(this.srv_cmd.srv_metafound);
                    subcmd = "search";
                    flag = true;
                  }
                  else if (this.data[14] == (byte) 0xc8) {
                    this.header.setCommand(this.srv_cmd.srv_metageneral);
                    subcmd = "detail";
                    flag = true;
                  }
                  else if (this.data[14] == (byte) 0xdc) {
                    this.header.setCommand(this.srv_cmd.srv_metamore);
                    subcmd = "detail";
                    flag = true;
                  }
                  //------------------------------------------------------------
                  if (subcmd.equals("search")) {
                    posdata = 19;
                  }
                  else if (subcmd.equals("detail")) {
                    posdata = 17;
                  }
                  if (flag) {
                    datatemp = new byte[this.data.length - posdata];
                    for (tmpint = 0; tmpint != datatemp.length; tmpint++) {
                      datatemp[tmpint] = this.data[posdata];
                      posdata++;
                    }
                    //------------------------------------------------------------
                    this.data = new byte[datatemp.length];
                    this.data = datatemp;
                  }
                }
            //-------------------------------------------------------------------------
  }
//--------------------------------------------------
  public byte[] getCookie(){
        return null ;
  }
//--------------------------------------------------
  public CmdPacket() {
          this.header    = new HeadPacket() ;
          this.data      = null ;
          this.cmd       = new ClientToServerCMD();
          this.srv_cmd   = new ServerToClientCMD() ;
          this.constant  = new Constant() ;
  }
//--------------------------------------------------
}