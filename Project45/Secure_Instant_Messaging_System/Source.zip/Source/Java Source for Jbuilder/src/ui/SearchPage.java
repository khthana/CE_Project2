package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.io.*;
import java.util.* ;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SearchPage extends JFrame {
  private ServerConnect sconn ;
  private UserData user;
  private TCPconnect tcpconnect ;
  JPanel contentPane;
  JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel jPanel1 = new JPanel();
  JPanel jPanel2 = new JPanel();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel1 = new JLabel();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JTextField jTextField5 = new JTextField();
  JLabel jLabel13 = new JLabel();
  JCheckBox jCheckBox1 = new JCheckBox();
  JButton jButton3 = new JButton();
  JLabel jLabel14 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  private JTable jTable1 = new JTable();
  private Vector searchresult ;

  //Construct the frame
  public SearchPage(ServerConnect sconn) {
    this.sconn = sconn ;
    tcpconnect = new TCPconnect(this.sconn) ;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(SearchPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(460, 520));
    this.setTitle("IsagQ Search Engine");
    jPanel1.setLayout(null);
    jPanel2.setLayout(null);
    jPanel3.setLayout(null);
    jLabel1.setBorder(titledBorder2);
    jLabel1.setText("");
    jLabel1.setBounds(new Rectangle(340, 33, 100, 120));
    jButton1.setBounds(new Rectangle(350, 55, 80, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Search");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(350, 100, 80, 25));
    jButton2.setText("Clear");
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Search for a user by E-mail Address");
    jLabel2.setBounds(new Rectangle(15, 35, 204, 16));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Search for a user by parameters of Name");
    jLabel3.setBounds(new Rectangle(15, 15, 235, 16));
    jLabel4.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel4.setText("Search for a user by UIN");
    jLabel4.setBounds(new Rectangle(15, 35, 137, 16));
    jLabel5.setBorder(BorderFactory.createEtchedBorder());
    jLabel5.setBounds(new Rectangle(15, 65, 285, 45));
    jLabel7.setBorder(BorderFactory.createEtchedBorder());
    jLabel7.setBounds(new Rectangle(15, 45, 285, 105));
    jLabel8.setText("First Name");
    jLabel8.setBounds(new Rectangle(45, 60, 70, 15));
    jLabel6.setText("E-mail Address");
    jLabel6.setBounds(new Rectangle(20, 80, 90, 15));
    jLabel9.setText("Last Name");
    jLabel9.setBounds(new Rectangle(45, 90, 70, 15));
    jLabel10.setText("Nickname");
    jLabel10.setBounds(new Rectangle(45, 120, 70, 15));
    jLabel11.setBorder(BorderFactory.createEtchedBorder());
    jLabel11.setBounds(new Rectangle(15, 65, 285, 45));
    jLabel12.setText("UIN #");
    jLabel12.setBounds(new Rectangle(75, 80, 35, 15));
    jLabel13.setBorder(BorderFactory.createEtchedBorder());
    jLabel13.setBounds(new Rectangle(340, 165, 100, 45));
    jCheckBox1.setEnabled(false);
    jCheckBox1.setFont(new java.awt.Font("Dialog", 1, 12));
    jCheckBox1.setText("Online Only");
    jCheckBox1.setBounds(new Rectangle(347, 175, 90, 25));
    jPanel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jPanel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jPanel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jTabbedPane1.setFont(new java.awt.Font("Dialog", 1, 12));
    jTabbedPane1.setBounds(new Rectangle(10, 10, 320, 200));
    jButton3.setBounds(new Rectangle(340, 450, 90, 25));
    jButton3.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton3.setActionCommand("Add User");
    jButton3.setText("Add User");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jLabel14.setBorder(BorderFactory.createEtchedBorder());
    jLabel14.setBounds(new Rectangle(330, 440, 110, 45));
    jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        jTable1_mouseClicked(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(14, 243, 425, 160));
    jTextField1.setBounds(new Rectangle(115, 78, 175, 20));
    jTextField4.setBounds(new Rectangle(120, 118, 145, 20));
    jTextField3.setBounds(new Rectangle(120, 88, 145, 20));
    jTextField2.setBounds(new Rectangle(120, 58, 145, 20));
    jTextField5.setBounds(new Rectangle(115, 78, 120, 20));
    contentPane.add(jTabbedPane1, null);
    jTabbedPane1.add(jPanel1, " E-mail ");
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(jLabel6, null);
    jPanel1.add(jTextField1, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jTextField2, null);
    jPanel2.add(jTextField3, null);
    jPanel2.add(jTextField4, null);
    jPanel2.add(jLabel8, null);
    jPanel2.add(jLabel9, null);
    jPanel2.add(jLabel10, null);
    jPanel2.add(jLabel7, null);
    jPanel3.add(jLabel4, null);
    jPanel3.add(jLabel11, null);
    jPanel3.add(jLabel12, null);
    jPanel3.add(jTextField5, null);
    jTabbedPane1.add(jPanel2, " Names ");
    jTabbedPane1.add(jPanel3, "   UIN   ");
    contentPane.add(jLabel1, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jCheckBox1, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jButton3, null);
    contentPane.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(jTable1, null);
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }
//--------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
        if(jTabbedPane1.getSelectedIndex() == 0){//search by email
            short lastseq ;
            byte[] data ;
            try{
              data = this.sconn.clientCMD.setSearchByemail(this.jTextField1.getText());
              lastseq = this.sconn.packetforsend.header.getSequence() ;
              this.sconn.packetforsend = new CmdPacket() ;
              this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.searchbymail,lastseq,data)) ;
              }
            catch (IOException ex)
              {}
        }
        //-------------------------------------------------------------
        else if(jTabbedPane1.getSelectedIndex() == 1){//search by name
          short lastseq ;
          byte[] data ;
          try{
            data = this.sconn.clientCMD.setSearchByPersinf(this.jTextField4.getText(),this.jTextField2.getText(),this.jTextField3.getText());
            lastseq = this.sconn.packetforsend.header.getSequence() ;
            this.sconn.packetforsend = new CmdPacket() ;
            this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.searchbypersinf,lastseq,data)) ;
          }
          catch (IOException ex)
              {}
        }
        //-------------------------------------------------------------
        else if(jTabbedPane1.getSelectedIndex() == 2){//search by uin
          short lastseq ;
          byte[] data ;
          try{
            data = this.sconn.clientCMD.setSearchByUin(this.jTextField5.getText());
            lastseq = this.sconn.packetforsend.header.getSequence() ;
            this.sconn.packetforsend = new CmdPacket() ;
            this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.searchbyuin,lastseq,data)) ;
          }
          catch (IOException ex)
              {}
        }
        //-------------------------------------------------------------
  }
//---------------------------------------------------------------------
  public void setTable(){
    String field[] = {"uin","nickname","firstname","lastname","email","authorize","status","gender","age"};
     int size,j,k,i ;
     SearchInfo sin;
     size = searchresult.size() ;
     String  result[][] = new String[size][9] ;
     for(i = 0;i <size ; i++){
        sin =  (SearchInfo) searchresult.elementAt(i);
                result[i][0] = Integer.toString(sin.getUin()) ;
                result[i][1] = sin.getNickname()  ;
                result[i][2] = sin.getFirstname() ;
                result[i][3] = sin.getLastname()  ;
                result[i][4] = sin.getEmail() ;
                result[i][5] = sin.getAuthorize() ;
                result[i][6] = sin.getStatus() ;
                result[i][7] = sin.getGender() ;
                result[i][8] = Integer.toString(sin.getAge()) ;
     }
     this.jTable1 = new JTable(result,field) ;
     this.jScrollPane1.getViewport().add(this.jTable1, null) ;
  }
//---------------------------------------------------------------------
  public void updateAddGroup(){
      try{
      short lastseq ;
      byte[] data ;
      data = this.sconn.clientCMD.setUpdateGroupPacket("Add",user) ;
      lastseq = this.sconn.packetforsend.header.getSequence() ;
      this.sconn.packetforsend = new CmdPacket() ;
      this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.updategroup,lastseq,data)) ;
      //Thread.sleep(1000);

      data = this.sconn.clientCMD.setAddEndPacket();
      lastseq = this.sconn.packetforsend.header.getSequence() ;
      this.sconn.packetforsend = new CmdPacket() ;
      this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.addend,lastseq,data)) ;
      //Thread.sleep(5000);

      OwnerDataInfo.getMyContactlist().addElement(user) ;
      OwnerDataInfo.addProperties(user);

      this.sconn.logonpage.mainPage.setList();

      System.out.println("----------------------------Add Finish------------------");
      //--------------------------------new user-------------------------------------------
      this.sconn.logonpage.getUserNotInGroupList().put(user.getUin(),user) ;
      //-----------------------------------------------------------------------------------
      //this.tcpconnect.sendkey(user) ;
      //-----------------------------------------------------------------------------------
      this.dispose() ;
      }catch(Exception e){}
  }
//---------------------------------------------------------------------
  public void setUserDataAdd(){
         SearchInfo sinfo ;
         String uin ;
         String nick ;
         int selectitem ;
         selectitem = jTable1.getSelectedRow() ;
         sinfo = (SearchInfo) this.searchresult.elementAt(selectitem) ;
         uin = Integer.toString(sinfo.getUin()) ;
         nick = sinfo.getNickname() ;


        user = new UserData() ;
        user.setAge(sinfo.getAge());
        user.setAuthorize(sinfo.getAuthorize());
        user.setEmail(sinfo.getEmail());
        user.setFirstname(sinfo.getFirstname());
        user.setGender(sinfo.getGender());
        user.setLastname(sinfo.getLastname());
        user.setNickname(sinfo.getNickname()) ;
        user.setStatus("offline");
        user.setUin(Integer.toString(sinfo.getUin())) ;
  }
//---------------------------------------------------------------------
  public void setSearchresult(Vector result){
         this.searchresult = result ;
  }
//---------------------------------------------------------------------
  void jTable1_mouseClicked(MouseEvent e) {
  }
//------------------------------------------------------------------------
  void jButton3_actionPerformed(ActionEvent e) {
         short lastseq ;
         byte[] data ;
          try{

            System.out.println("------------------start add-------------------");
            this.setUserDataAdd() ;
            this.sconn.updatetype = "Add" ;

            data = this.sconn.clientCMD.setAddStartPacket();
            lastseq = this.sconn.packetforsend.header.getSequence() ;
            this.sconn.packetforsend = new CmdPacket() ;
            this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.addstart,lastseq,data)) ;
            //Thread.sleep(1000);

            data = this.sconn.clientCMD.setAddBuddyPacket(user.getUin(),user.getNickname());
            lastseq = this.sconn.packetforsend.header.getSequence() ;
            this.sconn.packetforsend = new CmdPacket() ;
            this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.addbuddy,lastseq,data)) ;

          }
          catch(Exception ex)
          {}
  }
//--------------------------------------------------------
}