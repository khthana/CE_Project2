package ui;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.util.* ;
import java.io.*;
import java.net.* ;
public class TCPconnect {
  private  Socket socket ;
  private  DataOutputStream out;
  private  PeerInit  msginit ;
  private  TcpClientCMD cmd ;
  private  ServerConnect sconnect ;
  private  DesEncrypter  des;
  private  SendFile sendfile ;
  private  ReceiveFile receivefile ;
//----------------------------------------------------------------
  public Socket getSocket(){
       return this.socket ;
  }
//---------------------------------------------------------------
  public void connect(String ip,int port){
       try{
         ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
         DataOutputStream dataOut=new DataOutputStream(byteOut);
           InetAddress serverAddr = InetAddress.getByName(ip);
           socket = new Socket(serverAddr,port) ;
           out = new DataOutputStream(socket.getOutputStream()) ;
           //save stream for each user
           //code
           //-------------------------
        /*   short cmd = 0x3000 ;
           dataOut.writeShort(cmd);
           out.write(byteOut.toByteArray()) ;
           out.flush();
           msginit = new PeerInit(0x83adbe0b,0x6830,0x328cf109,0xa1f60523,0xa1f60523,0x6830,0x8c6e63b3) ;
           out.write(msginit.setAllbyteinit1()) ;
           out.flush();
           //send for initack
           cmd = 0x0400 ;
           byteOut=new ByteArrayOutputStream();
           dataOut=new DataOutputStream(byteOut);
           dataOut.writeShort(cmd);
           out.write(byteOut.toByteArray()) ;
           out.flush();

           byteOut=new ByteArrayOutputStream();
           dataOut=new DataOutputStream(byteOut);
           dataOut.writeInt(0x01000000);
           out.write(byteOut.toByteArray());//ack
           out.flush();
           //send for init2
           byteOut=new ByteArrayOutputStream();
           dataOut=new DataOutputStream(byteOut);
           dataOut.writeShort(0x2100);
           out.write(byteOut.toByteArray());
           out.flush();

           msginit = new PeerInit() ;
           out.write(msginit.setAllbyteInit2("outgoing"));
           //------------end init-----------------------------*/
       }
       catch(IOException e){
         System.out.println("connection not connect"+e.getMessage());
       }
  }
//----------------------------------------------------------------
  public void sendEncryptFile(UserData user,int port){
         this.connect(user.getExternal_ip(),port);
         sendfile = new SendFile(this.sconnect.logonpage.mainPage.filechooser.getFile(),this.out,user) ;
         sendfile.start();
  }
//----------------------------------------------------------------
  public void sendAcceptReceiveFile(UserData user,String filename,int filesize){
         byte[] data ;
         int port ;
         try{
           this.connect(user.getExternal_ip(), 13000);
           data = cmd.setAcceptReceiveFile(OwnerDataInfo.getUin());
           port = cmd.getPortToreceiveFile() ;
           out.write(data);
           out.flush();
           socket.close();
           receivefile = new ReceiveFile(port,filename,user,filesize) ;
           receivefile.start();
         }
         catch(IOException e){}
 }
//----------------------------------------------------------------
  public void sendRejectReceiveFile(UserData user){
         byte[] data ;
         try{
           this.connect(user.getExternal_ip(), 13000);
           data = cmd.setRejectReceiveFile(OwnerDataInfo.getUin());
           out.write(data);
           out.flush();
           socket.close();
         }
         catch(IOException e){}
 }
//---------------------------------------------------------------
  public void sendReqSendFile(UserData user,File filename){
          byte[] data ;
          try{
            this.connect(user.getExternal_ip(), 13000);
            data = cmd.setReqSendfilePacket(filename);
            out.write(data);
            out.flush();
            socket.close();
          }
          catch(IOException e){}
  }
//---------------------------------------------------------------
  public void sendEncryptmsg(String msg,UserData user){
       try{
          byte[] data ;
          this.connect(user.getExternal_ip(),13000) ;
          data = cmd.setsendEncryptMsg(user,msg) ;
          out.write(data);
          out.flush();
          socket.close();
       }
       catch(IOException e){
           System.out.println("send encrypt error"+e.getMessage());
       }
  }
//----------------------------------------------------------------
  public void sendkey(UserData user)throws IOException{
           byte[] data ;
            if(user.getStatus().equals("online")) {
              System.out.println(user.getExternal_ip());
              socket = new Socket(user.getExternal_ip(), 13000);
              out = new DataOutputStream(socket.getOutputStream());
              data = cmd.setsendPublickeyPacket();
              out.write(data);
              out.flush();
              socket.close();
            }
  }
//----------------------------------------------------------------
  public void sendkey(){
        int i,len ;
        UserData user ;
        byte[] data ;
  //------------- send key to every one who online ----------------
        len = OwnerDataInfo.getOnlinelist().size() ;
        for(i = 0 ;i < len ; i++ ){
            user = (UserData) OwnerDataInfo.getOnlinelist().elementAt(i) ;
           if(user.getStatus().equals("online")) {
              try{
                System.out.println(user.getExternal_ip());
                socket = new Socket(user.getExternal_ip(),13000) ;
                out = new DataOutputStream(socket.getOutputStream()) ;
                data = cmd.setsendPublickeyPacket() ;
                out.write(data);
                out.flush();
                socket.close();
                this.sconnect.logonpage.mainPage.setList() ;
                }catch(Exception ui){
              }
            }
        }
  }
//------------------   test version  ----------------------------------
  public void sendDeskey(OwnerDataInfo o,UserData u) {
             try{
                Socket remoteOut = new Socket("127.0.0.1",13000) ;
                out = new DataOutputStream(remoteOut.getOutputStream()) ;
                byte[] packetbyte ;
               // packetbyte = cmd.setsendDeskeyPacket(u) ;
               // out.write(packetbyte) ;
                remoteOut.close() ;
             }catch(IOException t){
                 System.out.println(t.getMessage());
             }
  }
//----------------------------------------------------------------
  public TCPconnect(ServerConnect s) {
       cmd = new TcpClientCMD() ;
       this.sconnect = s ;
       des = new DesEncrypter();
  }
}