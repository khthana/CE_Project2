package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.security.* ;
import javax.crypto.spec.* ;
import java.math.* ;
import java.security.spec.* ;
import javax.crypto.* ;
import java.util.* ;
import java.math.*;
import java.net.*;
import java.io.*;
public class TCPreceive extends Thread {
  private ServerConnect sconnect ;
  private Socket sock ;
  private Socket remoteOut ;
  private ServerSocket serversock ;
  private DataInputStream in ;
  private DataOutputStream out ;
  private TcpClientCMD   cmd ;
  private TCPconnect   tcpconnect ;
  //private RSA rsa ;
  //private DES des ;
  //private OwnerDataInfo test ;
  private DiffieHellman dh ;
  private DesEncrypter des ;
  public TCPreceive(ServerConnect sconn) {
       this.sconnect = sconn ;
       cmd = new  TcpClientCMD() ;
       dh = new DiffieHellman() ;
       des = new DesEncrypter() ;
       this.tcpconnect = new TCPconnect(this.sconnect);
  //     rsa = new RSA();
  //     des = new DES();
  }
//-------------------------------------------------
  public UserData finduserincontactlist(String uin){
       UserData user ;
       Properties p = OwnerDataInfo.getProperties() ;
       user = (UserData)p.get(uin) ;
       return user ;
}
//---------------------------------------------------
//  public void setOwnerDataInfo( OwnerDataInfo test){
//      this.test = test ;
// }
//------------------------------------------
  public Socket accept(int port) throws IOException {
            serversock = new ServerSocket(port) ;
            Socket client = serversock.accept();
            serversock.close();
            System.out.print("Starting on port "+port+"\n");
            System.out.println("Waiting\n");
            return client;
  }
//------------------------------------------
  public void run(){
      while(true){
          try{
             ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
             DataOutputStream dataOut=new DataOutputStream(byteOut);
             byte[] temp ;
             byte[] data = null;
             int c ;
             String uin ;
             int i = 0 ;
             UserData user ;
             sock = accept(13000) ;
             in = new DataInputStream(sock.getInputStream());
             out = new DataOutputStream(sock.getOutputStream());
               while((c = in.read())!= -1 ) {
                       dataOut.writeByte(c);
                }
              sock.close() ;
              data = byteOut.toByteArray() ;
              temp = Util.copyBytes(data,0,2);
              //-------------------------get RejectReceiveFile---------------------------
             if(Util.bytes2Short(temp) == -21840){
                  int sizecontact,uinlen ;
                  byte[] publickeyBytes ;
                  temp = Util.copyBytes(data,2,2) ;//----------get uin length-------------------
                  uinlen = Util.bytes2Short(temp) ;
                  temp = Util.copyBytes(data,4,uinlen);//---------get uin-----------------------
                  uin =  new String(temp) ;
                  user = this.finduserincontactlist(uin) ;
                  if(user != null ){
                          //--------------- tell user that another reject receive file--------------
                          String message ;
                          String title ;
                          title   = "Receive File Reject" ;
                          message = "User "+user.getNickname()+" doesn't want to receive file from you." ;
                          this.sconnect.logonpage.messageBox = new MessageBox(title,message) ;
                          this.sconnect.logonpage.messageBox.show();
                          //-----------------------------------------------------------------------
                  }
                 //------------------------------------------------------------------------------
              }
            //-------------------------get AcceptReceiveFile---------------------------
            if(Util.bytes2Short(temp) == -21841){
                 int sizecontact,uinlen ;
                 byte[] publickeyBytes ;
                 int porttosendfile ;
                 temp = Util.copyBytes(data,2,2) ;//----------get uin length-------------------
                 uinlen = Util.bytes2Short(temp) ;
                 temp = Util.copyBytes(data,4,uinlen);//---------get uin-----------------------
                 uin =  new String(temp) ;
                 user = this.finduserincontactlist(uin) ;
                 if(user != null ){
                         temp = Util.copyBytes(data,4+uinlen,data.length-(4+uinlen)) ;
                         porttosendfile = Util.bytes2Short(temp) ;
                         //--------------- send file--------------------
                         this.tcpconnect.sendEncryptFile(user,porttosendfile) ;
                         //---------------------------------------------
                 }
                //------------------------------------------------------------------------------
             }
            //-------------------------get reqSendFile------------------------
            if(Util.bytes2Short(temp) == -21842){
                 int sizecontact,uinlen,filenamelen,filesize ;
                 String filename ;
                 String headmsg ;
                 byte[] publickeyBytes ;
                 temp = Util.copyBytes(data,2,2) ;//----------get uin length-------------------
                 uinlen = Util.bytes2Short(temp) ;
                 temp = Util.copyBytes(data,4,uinlen);//---------get uin-----------------------
                 uin =  new String(temp) ;
                 user = this.finduserincontactlist(uin) ;

                 temp = Util.copyBytes(data,4+uinlen,2) ;
                 filenamelen = Util.bytes2Short(temp) ;
                 temp = Util.copyBytes(data,6+uinlen,filenamelen) ;
                 filename = new String(temp) ;

                 temp = Util.copyBytes(data,6+uinlen+filenamelen,data.length-(6+uinlen+filenamelen)) ;
                 filesize = Util.bytes2Int(temp) ;

                 if(user != null ){
                          headmsg = "User "+user.getNickname()+" want to send file "+filename+" to you ." ;
                          this.sconnect.logonpage.reqsendfile = new RequestFilePage(headmsg,this.sconnect,user,filename,filesize) ;
                          this.sconnect.logonpage.reqsendfile.show() ;
                 }
                //------------------------------------------------------------------------------
             }
            //-------------------------get return publickey ------------------
            if(Util.bytes2Short(temp) == -21845){
                 int sizecontact,uinlen ;
                 byte[] publickeyBytes ;
                 SecretKey secretkey ;
                 temp = Util.copyBytes(data,2,2) ;//----------get uin length-------------------
                 uinlen = Util.bytes2Short(temp) ;
                 temp = Util.copyBytes(data,4,uinlen);//---------get uin-----------------------
                 uin =  new String(temp) ;
                 //-------------- search  user in order to put secret key----------------------
                 user = this.finduserincontactlist(uin) ;
                 if(user != null ){
                          temp = Util.copyBytes(data,4+uinlen,data.length-(4+uinlen)) ;//-------- get publickeyBytes------------
                          publickeyBytes = temp ;
                          //------------- generate secretkey with diffie-hellman algolithm------------------------------------
                          secretkey = dh.generateSecretKey(publickeyBytes) ;
                          user.setSecretKey(secretkey);
                          user.setStatus("secure");
                          this.sconnect.logonpage.mainPage.setList();
                          //--------------------------------------------------------------------------------------------------
                 }
                //------------------------------------------------------------------------------
            }
            //-------------------------get public key ------------------------
             if(Util.bytes2Short(temp) == -21846){
                  int sizecontact,uinlen,dhParalength ;
                  byte[] publickeyBytes ;
                  SecretKey secretkey ;
                  String dhParameter ;
                  temp = Util.copyBytes(data,2,2) ;//----------get uin length-------------------
                  uinlen = Util.bytes2Short(temp) ;
                  temp = Util.copyBytes(data,4,uinlen);//---------get uin-----------------------
                  uin = new String(temp) ;
                  temp = Util.copyBytes(data,4+uinlen,2);//----get dhParalength--------------
                  dhParalength = Util.bytes2Short(temp) ;
                  temp = Util.copyBytes(data,6+uinlen,dhParalength) ;//--------- DHparameter----
                  dhParameter = new String(temp) ;
                  //-------------- search  user in order to put secret key------------------
                  user = this.finduserincontactlist(uin) ;
                  if(user != null){
                           temp = Util.copyBytes(data,6+uinlen+dhParalength,data.length-(6+uinlen+dhParalength)) ;//-------- get publickeyBytes------------
                           publickeyBytes = temp ;
                           //------------- generate secretkey with diffie-hellman algolithm------------------------------------
                           secretkey = dh.generateSecretKey(dhParameter,publickeyBytes,user) ;
                           user.setSecretKey(secretkey);
                           user.setStatus("secure") ;
                           this.sconnect.logonpage.mainPage.setList();
                        }
                   //------------------------------------------------------------------------
             }
            //---------------------get encrypt message----------------------
             else if(Util.bytes2Short(temp) == -21843){
                  String realmsg   ;
                  String encryptmsg ;
                  int sizecontact,uinlen,msglen ;
                  temp = Util.copyBytes(data,2,2) ;//------get uin length-----------
                  uinlen =  Util.bytes2Short(temp);
                  temp = Util.copyBytes(data,4,uinlen);//--------- get uin data--------
                  uin = new String(temp) ;
                  //------ search for user in ordet to retreive right secret key--------------------
                   user = this.finduserincontactlist(uin) ;
                   if(user != null){
                           des.setSecretKey(user.getSecretKey(),"String");
                           temp = Util.copyBytes(data,4+uinlen,2) ;//-------- get messages length--------------
                           msglen = Util.bytes2Short(temp) ;
                           temp = Util.copyBytes(data,6+uinlen,msglen) ;//--------- get data of encrypt messages-------
                           encryptmsg = new String(temp) ;

                           //-------------- decrypt messages----------------
                           realmsg = des.decryptStr(encryptmsg);
                           System.out.println(realmsg);
                           //-----------------------------------------------
                           //---------- display message----------------------
                           this.sconnect.logonpage.mainPage.messagePage = new MessagePage(this.sconnect,user) ;
                           this.sconnect.logonpage.mainPage.messagePage.jTextArea1.setText(realmsg);
                           this.sconnect.logonpage.mainPage.messagePage.show() ;
                           //------------------------------------------------
                  }
            }
            //--------------------------------------------------------------
          }
          catch(IOException y)
          {}
      }
  }
//------------------------------------------------------------------------------
}