package ui;

import javax.swing.*;
import java.awt.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class RequestFilePage extends JFrame {
  private  String header ;
  private  TCPconnect tcpconnect ;
  private  ServerConnect sconnect ;
  private  UserData user ;
  private  String filename ;
  private  int filesize ;
  JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();

  public RequestFilePage(String header,ServerConnect sconnect,UserData user,String filename,int filesize) {
    try {
      this.filesize = filesize ;
      this.sconnect = sconnect ;
      this.header = header ;
      this.tcpconnect = new TCPconnect(this.sconnect) ;
      this.user = user ;
      this.filename = filename ;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.getContentPane().setBackground(SystemColor.control);
    this.setLocale(java.util.Locale.getDefault());
    this.setResizable(false);
    this.setSize(new Dimension(297, 179));
    this.getContentPane().setLayout(null);
    this.setTitle("Another User want to send file to you");
    jPanel1.setBorder(null);
    jPanel1.setBounds(new Rectangle(3, 2, 285, 147));
    jPanel1.setLayout(null);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText(header);
    jLabel1.setBounds(new Rectangle(25, 28, 235, 38));
    jButton1.setBounds(new Rectangle(42, 92, 73, 24));
    jButton1.setFont(new java.awt.Font("Dialog", 0, 11));
    jButton1.setText("Accept");
    jButton1.addActionListener(new RequestFilePage_jButton1_actionAdapter(this));
    jButton2.setText("Reject");
    jButton2.addActionListener(new RequestFilePage_jButton2_actionAdapter(this));
    jButton2.setBounds(new Rectangle(166, 93, 73, 23));
    jButton2.setFont(new java.awt.Font("Dialog", 0, 11));
    jPanel1.add(jLabel1, null);
    jPanel1.add(jButton1, null);
    jPanel1.add(jButton2, null);
    this.getContentPane().add(jPanel1, null);
  }
//--------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
        this.tcpconnect.sendAcceptReceiveFile(this.user,this.filename,this.filesize) ;
        this.dispose() ;
  }
//--------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
       this.tcpconnect.sendRejectReceiveFile(this.user);
       this.dispose() ;
  }
//-------------------------------------------------------------------
}

class RequestFilePage_jButton1_actionAdapter implements java.awt.event.ActionListener {
  RequestFilePage adaptee;

  RequestFilePage_jButton1_actionAdapter(RequestFilePage adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class RequestFilePage_jButton2_actionAdapter implements java.awt.event.ActionListener {
  RequestFilePage adaptee;

  RequestFilePage_jButton2_actionAdapter(RequestFilePage adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}