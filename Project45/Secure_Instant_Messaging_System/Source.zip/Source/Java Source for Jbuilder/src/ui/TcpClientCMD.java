package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.math.* ;
import java.io.*;
public class TcpClientCMD {
  private int porttoreceivefile ;
  final int sendPublickey     = 0xaaaa ;//-21846
  final int sendAckPublickey  = 0xaaab ;//-21845
  //final int sendMsg         = 0xaaac ;
  final int sendEncryptMsg    = 0xaaad ;//-21843
  final int reqSendfile       = 0xaaae ;//-21842
  final int acceptReceivefile = 0xaaaf ;//-21841
  final int rejectReceivefile = 0xaab0 ;//-21840
  private DesEncrypter des ;
//-------------------------------------------------------------
  public int getPortToreceiveFile(){
          return this.porttoreceivefile ;
  }
//--------------------------------------------------------------
   public byte[] setRejectReceiveFile(String uin)throws IOException{
       ByteArrayOutputStream byteOut = new ByteArrayOutputStream() ;
       DataOutputStream dataOut = new DataOutputStream(byteOut)    ;
       int uinlength  = uin.length();

       dataOut.writeShort(this.rejectReceivefile);
       dataOut.writeShort(uinlength);
       dataOut.writeBytes(uin);

       return byteOut.toByteArray() ;
  }
//--------------------------------------------------------------
  public byte[] setAcceptReceiveFile(String uin)throws IOException{
       ByteArrayOutputStream byteOut = new ByteArrayOutputStream() ;
       DataOutputStream dataOut = new DataOutputStream(byteOut)    ;
       int uinlength  = uin.length();
       int port = Util.portGen() ;
       this.porttoreceivefile = port ;
       dataOut.writeShort(this.acceptReceivefile);
       dataOut.writeShort(uinlength);
       dataOut.writeBytes(uin);
       dataOut.writeShort(port) ;
       return byteOut.toByteArray() ;
  }
//---------------------------------------------------------
  public byte[] setReqSendfilePacket(File file) throws IOException{
       ByteArrayOutputStream byteOut = new ByteArrayOutputStream() ;
       DataOutputStream dataOut = new DataOutputStream(byteOut)    ;
       byte[] data ;
       String uin ;
       int uinlength ;
       int max = file.exists() ? (int)file.length() : 0;
       data = file.getName().getBytes() ;
       uin = OwnerDataInfo.getUin() ;
       uinlength = uin.length() ;
       dataOut.writeShort(this.reqSendfile) ;
       dataOut.writeShort(uinlength) ;
       dataOut.writeBytes(uin) ;
       dataOut.writeShort(data.length);
       dataOut.write(data) ;
       dataOut.writeInt(max);
       return byteOut.toByteArray() ;
  }
//---------------------------------------------------------
  public byte[] setsendEncryptMsg(UserData user,String msg)throws IOException{
       String encryptmsgs ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream() ;
       DataOutputStream dataOut=new DataOutputStream(byteOut)    ;
       des.setSecretKey(user.getSecretKey(),"String");
       encryptmsgs = des.encryptStr(msg) ;

       dataOut.writeShort(this.sendEncryptMsg) ; //----------- header type----------------
       dataOut.writeShort(OwnerDataInfo.getUin().length());//-------- length of uin ------
       dataOut.write(OwnerDataInfo.getUin().getBytes());//------ data of uin number-------
       dataOut.writeShort(encryptmsgs.length());//---------- messages length--------------
       dataOut.writeBytes(encryptmsgs);//------------------- data of message -------------
       return byteOut.toByteArray() ;
  }
//---------------------------------------------------------
  public byte[] setsendPublickeyPacket()throws IOException{
       String dhParameter ;
       byte[] dhParaBytes ;
       short  dhParalength ;
       dhParameter = OwnerDataInfo.getdhPublicValue() ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       dataOut.writeShort(this.sendPublickey);
       dataOut.writeShort(OwnerDataInfo.getUin().length()); //-----length of uin------
       dataOut.write(OwnerDataInfo.getUin().getBytes()) ;//-------- uin number--------
       dhParaBytes  = dhParameter.getBytes() ;
       dhParalength = (short)dhParaBytes.length ;
       dataOut.writeShort(dhParalength);//----------- length of dhParameter ----------
       dataOut.write(dhParaBytes);//--------------- data(byte) of dhParameter --------
       dataOut.write(OwnerDataInfo.getPublickeyBytes()) ;//---publickey bytes --------
       return byteOut.toByteArray() ;
  }
//---------------------------------------------------------
  public byte[] setsendAckPublickeyPacket(byte[] publickeybytes)throws IOException{
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       dataOut.writeShort(this.sendAckPublickey);
       dataOut.writeShort(OwnerDataInfo.getUin().length()); //-----len of uin---------
       dataOut.write(OwnerDataInfo.getUin().getBytes()) ;//-------- uin number--------
       dataOut.write(publickeybytes) ;//------------publickey bytes-------------------
       return byteOut.toByteArray() ;
  }
//---------------------------------------------------------
/*  public byte[] setsendDeskeyPacket(UserData user)throws IOException {
       String msg  ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       dataOut.writeShort(this.sendDeskey) ;
       dataOut.writeShort(OwnerDataInfo.getUin().length()) ;
       dataOut.write(OwnerDataInfo.getUin().getBytes());
       BigInteger des = new BigInteger(user.getDes()) ;
       BigInteger deskey =  rsa.Encrypt(user.getKey_E(),user.getKey_N(),des) ;
       msg = deskey.toString() ;
       dataOut.writeShort(msg.length()) ;
       dataOut.write(msg.getBytes()) ;
       return byteOut.toByteArray()  ;
  }*/
//------------------------------------------------------
  public TcpClientCMD() {
     des = new DesEncrypter() ;
  }
}