package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.* ;
import java.util.* ;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class LogonPage extends JFrame {
  private ServerConnect sconnect ;
  private TCPconnect tcp;
  private TCPreceive tcpreceive ;
  private boolean statuslogin ;
  private DiffieHellman dh ;
  private FileInputStream fi ;
  private FileOutputStream fo ;
  private Properties activeuser ;
  private Properties usernotinlist ;
  MessageBox messageBox ;
  RequestFilePage reqsendfile ;
  LogonFail logonFail;
  MainPage mainPage;
  AddAnother addAnother;
  RegisterPage registerPage;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JPasswordField jPasswordF1 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JComboBox jComboBox1 = new JComboBox();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();

  //Construct the frame
  public LogonPage() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    tcp = new TCPconnect(this.sconnect) ;
    dh = new DiffieHellman();
    this.usernotinlist = new Properties() ;
    this.sconnect = new ServerConnect() ;
    try {
      jbInit();
      this.setComboBoxNickname() ;
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(LogonPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(290, 215));
    this.setTitle("Login to server");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("User :");
    jLabel1.setBounds(new Rectangle(45, 38, 65, 20));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Password :");
    jLabel2.setBounds(new Rectangle(45, 65, 65, 20));
    jPasswordF1.setText("");
    jPasswordF1.setBounds(new Rectangle(115, 65, 120, 20));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Please enter user's password.");
    jLabel3.setBounds(new Rectangle(5, 5, 180, 20));
    //-------------------- may be omit-----------------------------
   // jComboBox1.addItem("Nol");
   // jComboBox1.addItem("Nut");
   // jComboBox1.addItem("Pee");
   // jComboBox1.addItem("Poon");
   // jComboBox1.setSelectedIndex(0);
    //-------------------------------------------------------------
    jButton1.setBounds(new Rectangle(65, 100, 60, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(140, 100, 75, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setBounds(new Rectangle(65, 137, 150, 18));
    jButton3.setText("Add Another User");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jButton4.setBounds(new Rectangle(65, 162, 150, 18));
    jButton4.setText("Register A New user");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });
    jComboBox1.setEnabled(true);
    jComboBox1.setBounds(new Rectangle(115, 38, 120, 20));
    contentPane.setDebugGraphicsOptions(0);
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jPasswordF1, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
//----------------------------------------------------------
  public Properties getUserNotInGroupList(){
         return this.usernotinlist ;
  }
//---------------------------------------------------------
  public void setServerConnect(ServerConnect sconnect){
         this.sconnect = sconnect ;
  }
//---------------------------------------------------------
  public ServerConnect getServerConnect(){
         return this.sconnect ;
  }
//---------------------------------------------------------
  public void setComboBoxNickname(){
     try{
       this.fi = new FileInputStream("./activeuser/activeuser") ;
       this.activeuser = new Properties();
       this.activeuser.load(fi);
       fi.close() ;
       if(!this.activeuser.isEmpty()){
           Enumeration e = this.activeuser.propertyNames() ;
           while(e.hasMoreElements()){
               this.jComboBox1.addItem(e.nextElement()) ;
           }
         this.jComboBox1.setSelectedIndex(0) ;
       }
     }catch(IOException e){}
  }
//---------------------------------------------------------
  public void outPropertiesTofile(Properties a,String filename){
        try{
          this.fo = new FileOutputStream(filename) ;
          a.store(this.fo,filename) ;
          this.fo.close();
        }
        catch(IOException rt){}
  }
//---------------------------------------------------------
  public void getOwnInfo(SearchInfo sinfo){
        try{
          this.fi = new FileInputStream("./activeuser/activeuserdetail");
          Properties activeuserdetail = new Properties() ;
          activeuserdetail.load(fi);
          fi.close() ;

          OwnerDataInfo.setAge(sinfo.getAge());
          OwnerDataInfo.setFirstname(sinfo.getFirstname());
          OwnerDataInfo.setAuthorize(sinfo.getAuthorize());
          OwnerDataInfo.setEmail(sinfo.getEmail());
          OwnerDataInfo.setGender(sinfo.getGender());
          OwnerDataInfo.setLastname(sinfo.getLastname());
          OwnerDataInfo.setNickname(sinfo.getNickname());
          OwnerDataInfo.setStatus(sinfo.getStatus());
          OwnerDataInfo.setUin(Integer.toString(sinfo.getUin()));

          activeuser.put(OwnerDataInfo.getNickname(), OwnerDataInfo.getUin());
          this.outPropertiesTofile(this.activeuser,"./activeuser/activeuser");
          String passwd = new String(OwnerDataInfo.getencryptPassword()) ;
          activeuserdetail.put(OwnerDataInfo.getUin(),passwd) ;
          this.outPropertiesTofile(activeuserdetail,"./activeuser/activeuserdetail");
        }
        catch(Exception e){}
  }
//-----------------------------------------------------------------------------
  public void collectuserdata()throws IOException{
      int i = 0,len;
      UserData user ;
      byte[] data   ;
      short lastseq ;
      len = OwnerDataInfo.getMyContactlist().size() ;
      for(i = 0 ; i < len; i++){
          user = (UserData)OwnerDataInfo.getMyContactlist().elementAt(i) ;
          lastseq = this.sconnect.packetforsend.header.getSequence() ;
          this.sconnect.packetforsend = new CmdPacket() ;
          data = this.sconnect.clientCMD.setSearchByUin(user.getUin()) ;
          this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.searchbyuin,lastseq,data)) ;
         try {
        //      Thread.sleep(2000) ;
            if(i % 3 == 0 && i != 0){
              Thread.sleep(2000) ;
            }
          }
             catch(Exception t){}
      }
  }
//---------------------------------------------------------
  public void login(String uin,String password){
    try{
      this.dispose()     ;
      ServerConnect  bosServerconnc ;
      //System.out.println(password);
      this.setStatusLogin(false) ;
      //-------------------generate diffie-hellman key ----------------------------------------------
            System.out.println("---------------------generation dh key---------------------------");
            OwnerDataInfo.setdhPublicValue(dh.genDhParams()) ;
            dh.generateKeypair(OwnerDataInfo.getdhPublicValue());
            OwnerDataInfo.setPublicKey(dh.getPublicKey());
            OwnerDataInfo.setPrivateKey(dh.getPrivateKey());
            System.out.println("publickey = "+OwnerDataInfo.getPublickey().toString());
            System.out.println("privatekey = "+OwnerDataInfo.getPrivatekey().toString());
            System.out.println("---------------------generate key success -----------------------");
      //----------------------------------------------------------------------------------------------

      //    sconnect = new ServerConnect(5190,"login.icq.com","221210738","123","icqserver",this) ;
      //    sconnect = new ServerConnect(5190,"login.icq.com","17278025","2gpwcBG6","icqserver",this) ;
            this.sconnect = new ServerConnect(5190,"login.icq.com",uin,password,"icqserver",this) ;

            this.sconnect.Login(this.sconnect.getServername(),this.sconnect.getPort());
            if(sconnect.getStatus() == false){
                 String ip = sconnect.getServerBosIP() ;
                 bosServerconnc = new ServerConnect(5190,ip,"icqserver",this) ;
                 bosServerconnc.setServer2connect("bosserver") ;
                 bosServerconnc.Login(bosServerconnc.getServername(),bosServerconnc.getPort()) ;
                 this.sconnect = bosServerconnc ;
                 this.setVisible(false);
                   mainPage = new MainPage(this.sconnect);
      //-------------------------------------
                 while(this.statuslogin == false) { }
                     Thread.sleep(5000) ;
            //------------------ change key----------------------------------
             System.out.println("---------------------begin change key----------------------------");
             tcp = new TCPconnect(sconnect) ;
             tcpreceive = new TCPreceive(bosServerconnc) ;
             tcpreceive.start() ;
             tcp.sendkey();
             System.out.println("--------------------change key success---------------------------");
       //--------------------------------------------------------------------
             //this.collectuserdata() ;
             mainPage.show()  ;
       }
     }catch(Exception ex)
       {}
  }
//---------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    String nickname ;
    String password ;
    char[] pass     ;
    String uin  = ""   ;

    nickname = jComboBox1.getSelectedItem().toString() ;
    //System.out.println(nickname);
    pass = this.jPasswordF1.getPassword() ;
    password = new String(pass) ;
     //------------------- change nickname to uin ------------------------------
    try{

         if(!activeuser.isEmpty()){
             uin = (String)activeuser.get(nickname) ;
         }
    }
    catch(Exception exc){}
    //-------------------------------------------------------------------------
    this.login(uin,password) ;
  }
//--------------------------------------------------------
  public void setStatusLogin(boolean status){
        this.statuslogin = status ;
  }
//--------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
    jPasswordF1.setText("");
  }
//------------------------- add anathor user -----------------------------------
  void jButton3_actionPerformed(ActionEvent e) {
    addAnother = new AddAnother();
    addAnother.show();
    dispose();
  }
//------------------------------------------------------------------------------
  void jButton4_actionPerformed(ActionEvent e) {
    registerPage = new RegisterPage();
    registerPage.show();
    dispose();
  }
//------------------------------------------------------------------------------
}