package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class FileTransfer extends JFrame {
  JPanel contentPane;
  XYLayout xYLayout1 = new XYLayout();
  JLabel jLabel1 = new JLabel();
  JProgressBar jProgressBar1 = new JProgressBar();
  JLabel jLabel2 = new JLabel();

  //Construct the frame
  public FileTransfer() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    jLabel1.setText("");
    contentPane.setLayout(xYLayout1);
    this.setSize(new Dimension(400, 120));
    this.setTitle("Frame Title");
    jLabel2.setText("jLabel2");
    contentPane.add(jLabel1, new XYConstraints(10, 10, 372, 35));
    contentPane.add(jProgressBar1,  new XYConstraints(20, 17, 352, 20));
    contentPane.add(jLabel2,  new XYConstraints(46, 65, 300, 25));
    this.setResizable(false);
 }
  //Overridden so we can exit when window is closed
//-----------------------------------------------------------
  public void FileProcess(String filename,int max)
  {
   jLabel2.setText(filename+" : Transfering...");
   for (int i=0; i<max  ; i++)
   {
     jProgressBar1.setValue((i*100)/max);
        try{Thread.sleep(10);}catch(Exception e) {}
   }
    this.dispose() ;
  }
//----------------------------------------------------------
  public void FileProcess(File f)
  {
   int max = f.exists() ? (int)f.length() : 0;
   jLabel2.setText(f.getName()+" : Transfering...");
   for (int i=0; i<max  ; i++)
   {
     jProgressBar1.setValue((i*100)/max);
        try{Thread.sleep(10);}catch(Exception e) {}
   }
    this.dispose() ;
  }
//------------------------------------------------------------
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      this.dispose();
    }
  }
}