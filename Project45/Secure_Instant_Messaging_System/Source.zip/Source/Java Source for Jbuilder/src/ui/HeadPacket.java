package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.* ;
public class HeadPacket {
   private byte  id        ;
   private byte  channel   ;
   private short sequence  ;
   private short length    ;
   private int   command   ;
//--------------------------------------------------------------
   public byte[] getAllByte(){
     ByteArrayOutputStream byteOut=new ByteArrayOutputStream() ;
     DataOutputStream dataOut=new DataOutputStream(byteOut) ;
     try{
             dataOut.writeByte(this.id);
             dataOut.writeByte(this.channel);
             dataOut.writeShort(this.sequence);
             dataOut.writeShort(this.length);
      return byteOut.toByteArray() ;
        }
      catch(IOException e)
        {  }
      return byteOut.toByteArray() ;
   }
//---------------------------------------------------
   public int getcommand(){
       return this.command ;
   }
//---------------------------------------------------
   public byte getId(){
       return this.id ;
   }
//---------------------------------------------------
   public byte getChannel(){
       return this.channel ;
   }
//---------------------------------------------------
   public short getSequence(){
        return this.sequence ;
   }
//--------------------------------------------------
   public short getLength(){
        return this.length ;
   }
//-------------------------------------------------
   public void setId(byte id){
        this.id =  id ;
   }
//-------------------------------------------------
   public void setChannel(byte channel) {
        this.channel = channel ;
   }
//------------------------------------------------------
   public void setSequence(short sequence){
        this.sequence = sequence ;
   }
//------------------------------------------------------
   public void setLength(short length){
        this.length = length ;
   }
//---------------------------------------------------------
   public void setCommand (int command){
        this.command = command ;
   }
//---------------------------------------------------------
   public HeadPacket() {
       this.id = 0 ;
       this.channel = 0 ;
       this.length = 0 ;
       this.sequence = 0;
       this.command = 0 ;
   }
}