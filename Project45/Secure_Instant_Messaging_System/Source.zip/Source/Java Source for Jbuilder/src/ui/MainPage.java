package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MainPage extends JFrame {
  private ServerConnect sconn ;
  private UserData userdata  ;
  LogonPage logonPage;
  MessagePage messagePage;
  RenamePage renamePage;
  SearchPage searchPage;
  AddAnother addAnother;
  DeleteUser deleteUser;
  RemoveUser removeUser;
  RegisterPage registerPage;
  MyDetailPage myDetailPage;
  UserDetail userDetail;
  FileChooser filechooser ;
  JPanel contentPane;
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  TitledBorder titledBorder1;
  TitledBorder titledBorder2;
  JButton jButton1 = new JButton();
  JPopupMenu jPopupMenu1 = new JPopupMenu();
  JPanel jPanel1 = new JPanel();
  JPopupMenu jPopupMenu2 = new JPopupMenu();
  JPopupMenu jPopupMenu3 = new JPopupMenu();
  JPopupMenu jPopupMenu4 = new JPopupMenu();
  TitledBorder titledBorder3;
  private ImageIcon[] ic = {new ImageIcon("./images/online.gif"),
                            new ImageIcon("./images/offline.gif"),
                            new ImageIcon("./images/secure.gif"),
                            new ImageIcon("./images/freechat.gif"),
                            new ImageIcon("./images/away.gif"),
                            new ImageIcon("./images/extend.gif"),
                            new ImageIcon("./images/urgent.gif"),
                            new ImageIcon("./images/nodisturb.gif"),
                            new ImageIcon("./images/aaa.gif"),
                            new ImageIcon("./images/aab.gif"),
                            new ImageIcon("./images/aac.gif")} ;
  private Vector user = new Vector();
  private MyCellRenderer m ;
  Icon s_on = new ImageIcon("./images/online.gif");
  Icon s_free = new ImageIcon("./images/freechat.gif");
  Icon s_away = new ImageIcon("./images/away.gif");
  Icon s_na = new ImageIcon("./images/extend.gif");
  Icon s_occ = new ImageIcon("./images/urgent.gif");
  Icon s_dis = new ImageIcon("./images/nodisturb.gif");
  Icon s_in = new ImageIcon("./images/invisible.gif");
  Icon s_off = new ImageIcon("./images/offline.gif");
  Icon m_view = new ImageIcon("./images/view.gif");
//  Icon m_pref = new ImageIcon("./images/prefer.gif");
//  Icon m_sec = new ImageIcon("./images/secure.gif");
  Icon m_shut = new ImageIcon("./images/shut.gif");
  Icon i_change = new ImageIcon("./images/change.gif");
  Icon i_add = new ImageIcon("./images/another.gif");
  Icon i_remove = new ImageIcon("./images/remove.gif");
  Icon i_regist = new ImageIcon("./images/register.gif");
//  Icon i_unregist = new ImageIcon("./images/unregister.gif");
  Icon u_message = new ImageIcon("./images/another.gif");
  Icon u_detail = new ImageIcon("./images/remove.gif");
//  Icon u_rename = new ImageIcon("./images/register.gif");
  Icon u_delete = new ImageIcon("./images/unregister.gif");
//  Icon on_mode = new ImageIcon("./images/onmode.gif");
//  Icon sec_mode = new ImageIcon("./images/secmode.gif");
//  Icon off_mode = new ImageIcon("./images/offmode.gif");
  private JScrollPane jScrollPane1 = new JScrollPane();
  JList jList1 ;

  //Construct the frame
  public MainPage(ServerConnect s) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.sconn = s ;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(MainPage.class.getResource("[Your Icon]")));
    //String uin = "17278025";
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(180, 382));
    //this.setTitle(uin);
    this.setTitle(OwnerDataInfo.getUin());
    jButton2.setBounds(new Rectangle(86, 300, 82, 22));
    jButton2.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton2.setText("IsagQ");
    //JButton jButton4 = new JButton("online",s_on);
    JMenuItem i1 = new JMenuItem("Change The Active User",i_change);
    JMenuItem i2 = new JMenuItem("Add Another Registered User",i_add);
    JMenuItem i3 = new JMenuItem("Remove User From This Computer",i_remove);
    JMenuItem i4 = new JMenuItem("Register A New User",i_regist);
//    JMenuItem i5 = new JMenuItem("Unregister A User",i_unregist);
    JMenuItem m1 = new JMenuItem("View / Change My Details",m_view);
//    JMenuItem m2 = new JMenuItem("Server Settings",m_pref);
//    JMenuItem m3 = new JMenuItem("Security",m_sec);
    JMenuItem m4 = new JMenuItem("Shut Down",m_shut);
    JMenuItem s1 = new JMenuItem("Online",s_on);
    JMenuItem s2 = new JMenuItem("Free Chat",s_free);
    JMenuItem s3 = new JMenuItem("Away",s_away);
    JMenuItem s4 = new JMenuItem("N/A",s_na);
    JMenuItem s5 = new JMenuItem("Occupied",s_occ);
    JMenuItem s6 = new JMenuItem("No Disturb",s_dis);
    JMenuItem s7 = new JMenuItem("Invisible",s_in);
    JMenuItem s8 = new JMenuItem("Offline",s_off);
    JMenuItem u1 = new JMenuItem("Message",u_message);
    JMenuItem u2 = new JMenuItem("User's Details",u_detail);
//    JMenuItem u3 = new JMenuItem("Rename",u_rename);
    JMenuItem u4 = new JMenuItem("Delete",u_delete);
    JMenuItem u5 = new JMenuItem("SendFile",m_shut);
    user.addElement("  ------------- Secure --------------");
    user.addElement("  ------------- Online --------------");
    user.addElement("  ------------- Offline -------------");
   /* user.addElement("  ------------- Secure --------------");
    user.addElement("Nut");
    user.addElement("Peach");
    user.addElement("  ------------- Online --------------");
    user.addElement("Pee");
    user.addElement("Poon");
    user.addElement("  ------------- Offline -------------");
    user.addElement("Jeab");
    user.addElement("Tee");
    user.addElement("Roj");*/

    jList1 = new JList(user) ;
    m = new MyCellRenderer(ic) ;
    jList1.setBackground(new Color(236, 255, 255));
    jList1.setCellRenderer(m);
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setBounds(new Rectangle(3, 323, 62, 20));
    jButton3.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton3.setText("Main");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jButton4.setText("Online");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });
    jButton1.setBounds(new Rectangle(3, 300, 82, 22));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Add");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    i1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        i1_actionPerformed(e);
      }
    });
    i2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        i2_actionPerformed(e);
      }
    });
    i3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        i3_actionPerformed(e);
      }
    });
    i4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        i4_actionPerformed(e);
      }
    });
/*    i5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        i5_actionPerformed(e);
      }
    });*/
    s1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s1_actionPerformed(e);
      }
    });
    s2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s2_actionPerformed(e);
      }
    });
    s3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s3_actionPerformed(e);
      }
    });
    s4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s4_actionPerformed(e);
      }
    });
    s5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s5_actionPerformed(e);
      }
    });
    s6.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s6_actionPerformed(e);
      }
    });
    s7.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s7_actionPerformed(e);
      }
    });
    s8.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        s8_actionPerformed(e);
      }
    });
    m1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        m1_actionPerformed(e);
      }
    });
    m4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        m4_actionPerformed(e);
      }
    });
    //jButton4 = new JButton("Online",online);
    jButton4.setBounds(new Rectangle(66, 323, 102, 20));
    jButton4.setFont(new java.awt.Font("Dialog", 0, 10));
    jButton4.setIcon(s_on);
    contentPane.setMaximumSize(new Dimension(168, 369));
    jList1.addMouseListener(new java.awt.event.MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        jList1_mouseClicked(e);
      }
    });
    jScrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    jScrollPane1.setBorder(BorderFactory.createLoweredBevelBorder());
    jScrollPane1.setBounds(new Rectangle(3, 21, 165, 273));
    u1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        u1_actionPerformed(e);
      }
    });
    u2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        u2_actionPerformed(e);
      }
    });
    u4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        u4_actionPerformed(e);
      }
    });
    u5.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        u5_actionPerformed(e);
      }
    });
    jPanel1.setBounds(new Rectangle(68, 342, 28, 27));
    jPanel1.setLayout(null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jPanel1, null);
    contentPane.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(jList1, null);
    //jTabbedPane1.addTab("",on_mode,jPanel2.add(new JLabel("")));
    //jTabbedPane1.addTab("",sec_mode,jPanel3.add(new JLabel("")));
    //jTabbedPane1.addTab("",off_mode,jPanel4.add(new JLabel("")));
    jPopupMenu1.add(i1);
    jPopupMenu1.add(i2);
    jPopupMenu1.add(i3);
    jPopupMenu1.addSeparator();
    jPopupMenu1.add(i4);
//    jPopupMenu1.add(i5);
    jPopupMenu2.add(m1);
//    jPopupMenu2.add(m2);
//    jPopupMenu2.add(m3);
    jPopupMenu2.addSeparator();
    jPopupMenu2.add(m4);
    jPopupMenu3.add(s1);
    jPopupMenu3.add(s2);
    jPopupMenu3.add(s3);
    jPopupMenu3.add(s4);
    jPopupMenu3.add(s5);
    jPopupMenu3.add(s6);
    jPopupMenu3.add(s7);
    jPopupMenu3.add(s8);
    jPopupMenu4.add(u1);
    jPopupMenu4.addSeparator();
    jPopupMenu4.add(u2);
//    jPopupMenu4.add(u3);
    jPopupMenu4.add(u4);
    jPopupMenu4.add(u5);
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }
//-----------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
    jPopupMenu1.show(jPanel1,-125,-129);
  }

  void jButton1_actionPerformed(ActionEvent e) {

    searchPage = new SearchPage(this.sconn);
    searchPage.show();
  }

  void jButton4_actionPerformed(ActionEvent e) {
    jPopupMenu3.show(jPanel1,-13,1);
  }

  void jButton3_actionPerformed(ActionEvent e) {
    jPopupMenu2.show(jPanel1,-186,1);
  }
//----------------------------------------------------------------
  void s1_actionPerformed(ActionEvent e) {

          short lastseq ;
          byte[] data ;
          lastseq = this.sconn.packetforsend.header.getSequence() ;
          try{
              data = this.sconn.clientCMD.setSnack1_11("Online") ;
              this.sconn.packetforsend = new CmdPacket() ;
              this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
              lastseq = this.sconn.packetforsend.header.getSequence() ;
              //----------------------------------------------------------------------------------------------------------------
              data = this.sconn.clientCMD.setChangeStatuspacket("Online") ;
              this.sconn.packetforsend = new CmdPacket() ;
              this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
          }catch (IOException ex)
         {
         }
         jButton4.setText("Online");
         jButton4.setIcon(s_on);
  }
//--------------------------------------------------------------
  void s2_actionPerformed(ActionEvent e) {
    short lastseq ;
    byte[] data ;
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    try{
         data = this.sconn.clientCMD.setSnack1_11("Free for chat") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         lastseq = this.sconn.packetforsend.header.getSequence() ;
         //----------------------------------------------------------------------------------------------------------------
         data = this.sconn.clientCMD.setChangeStatuspacket("Free for chat") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         }catch (IOException ex)
             {}
    jButton4.setIcon(s_free);
    jButton4.setText("Free Chat");
  }
//--------------------------------------------------------------
  void s3_actionPerformed(ActionEvent e) {
       short lastseq ;
       byte[] data ;
       lastseq = this.sconn.packetforsend.header.getSequence() ;
       try{
           data = this.sconn.clientCMD.setSnack1_11("Away") ;
           this.sconn.packetforsend = new CmdPacket() ;
           this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
           lastseq = this.sconn.packetforsend.header.getSequence() ;
           //----------------------------------------------------------------------------------------------------------------
           data = this.sconn.clientCMD.setChangeStatuspacket("Away") ;
           this.sconn.packetforsend = new CmdPacket() ;
           this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
       }catch (IOException ex)
           {}
       jButton4.setIcon(s_away);
       jButton4.setText("Away");
  }
//--------------------------------------------------------------
  void s4_actionPerformed(ActionEvent e) {
    short lastseq ;
    byte[] data ;
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    try{
         data = this.sconn.clientCMD.setSnack1_11("N/A") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         lastseq = this.sconn.packetforsend.header.getSequence() ;
         //----------------------------------------------------------------------------------------------------------------
         data = this.sconn.clientCMD.setChangeStatuspacket("N/A") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         }catch (IOException ex)
             {}
    jButton4.setIcon(s_na);
    jButton4.setText("N/A");
  }
//-------------------------------------------------------------------------
  void s5_actionPerformed(ActionEvent e) {
    short lastseq ;
    byte[] data ;
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    try{
         data = this.sconn.clientCMD.setSnack1_11("Occupied") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         lastseq = this.sconn.packetforsend.header.getSequence() ;
         //----------------------------------------------------------------------------------------------------------------
         data = this.sconn.clientCMD.setChangeStatuspacket("Occupied") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         }catch (IOException ex)
             {}
    jButton4.setIcon(s_occ);
    jButton4.setText("Occupied");
  }
//--------------------------------------------------------------------
  void s6_actionPerformed(ActionEvent e) {
    short lastseq ;
    byte[] data ;
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    try{
     //----------------------------------------------------------------------------------------------------------------
         data = this.sconn.clientCMD.setChangeStatuspacket("DND") ;
         this.sconn.packetforsend = new CmdPacket() ;
         this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.changestatus,lastseq,data)) ;
         }catch (IOException ex)
             {}

    jButton4.setIcon(s_dis);
    jButton4.setText("No Disturb");
  }
//----------------------------------------------------------------------
  void s7_actionPerformed(ActionEvent e) {
    jButton4.setIcon(s_in);
    jButton4.setText("Invisible");
  }
//----------------------------------------------------------------------------
  void s8_actionPerformed(ActionEvent e) {
    short lastseq ;
    byte[] data ;
    lastseq = this.sconn.packetforsend.header.getSequence() ;
        data = this.sconn.clientCMD.setGoodbyePacket() ;
        this.sconn.packetforsend = new StdPacket() ;
        this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.goodbye,lastseq,data)) ;
        lastseq = this.sconn.packetforsend.header.getSequence() ;
    //----------------------------------------------------------------
        int i,len ;
           UserData user ;
           len = OwnerDataInfo.getMyContactlist().size() ;
           for(i = 0 ;i < len ; i++ ){
               user = (UserData) OwnerDataInfo.getMyContactlist().elementAt(i) ;
               user.setStatus("offline");
          }
          this.setList() ;
    //----------------------------------------------------------------
    jButton4.setIcon(s_off)     ;
    jButton4.setText("Offline") ;
    this.sconn.getServerListenner().stop();
    try{
           this.sconn.getSocket().close();}
    catch(IOException ea )
    {
    }
  }
//------------------------------------------------------------------------------
  void i1_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
    //-------------------------- log off----------------------------------------
    byte[] data ;
    short lastseq ;
    data = this.sconn.clientCMD.setGoodbyePacket();
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    this.sconn.packetforsend = new  StdPacket() ;
    this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.goodbye,lastseq,data)) ;
    this.sconn.getServerListenner().stop();
    //--------------------------------------------------------------------------
  }
//------------------------------------------------------------------------------
  void i2_actionPerformed(ActionEvent e) {
    addAnother = new AddAnother();
    addAnother.show();
    dispose();
    //-------------------------- log off----------------------------------------
    byte[] data ;
    short lastseq ;
    data = this.sconn.clientCMD.setGoodbyePacket();
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    this.sconn.packetforsend = new  StdPacket() ;
    this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.goodbye,lastseq,data)) ;
    this.sconn.getServerListenner().stop();
    //--------------------------------------------------------------------------
  }
//------------------------------------------------------------------------------
  void i3_actionPerformed(ActionEvent e) {
    removeUser = new RemoveUser();
    removeUser.show();
    dispose();
  }
//------------------------------------------------------------------------------
  void i4_actionPerformed(ActionEvent e) {
    registerPage = new RegisterPage();
    registerPage.show();
    dispose();
    //-------------------------- log off----------------------------------------
    byte[] data ;
    short lastseq ;
    data = this.sconn.clientCMD.setGoodbyePacket();
    lastseq = this.sconn.packetforsend.header.getSequence() ;
    this.sconn.packetforsend = new  StdPacket() ;
    this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.goodbye,lastseq,data)) ;
    this.sconn.getServerListenner().stop();
    //--------------------------------------------------------------------------
  }
//------------------------------------------------------------------------------
  void u1_actionPerformed(ActionEvent e) {
    messagePage = new MessagePage(this.sconn,userdata);
    messagePage.show();
    //dispose();
  }
//------------------------------------------------------------------------------
  void u2_actionPerformed(ActionEvent e) {
    System.out.println("Request user Information");
    byte[] data ;
    short lastseq ;
    try{
          data = this.sconn.clientCMD.setMetaReqInfoPacket(userdata.getUin());
          lastseq = this.sconn.packetforsend.header.getSequence() ;
          this.sconn.packetforsend = new  CmdPacket() ;
          this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.metareqinfo,lastseq,data)) ;
    }
    catch(Exception ty){}
    this.sconn.logonpage.mainPage.userDetail = new UserDetail(this.sconn);
    this.sconn.logonpage.mainPage.userDetail.setUin(this.userdata.getUin());
  }
//------------------------------------------------------------------------------
  void u3_actionPerformed(ActionEvent e) {
    renamePage = new RenamePage();
    renamePage.show();
    dispose();
  }
//-------------------------------------------------------------------------
  void u4_actionPerformed(ActionEvent e) {
    System.out.println("request delete user") ;
    deleteUser = new DeleteUser(this.sconn,userdata) ;
    deleteUser.show();
    //dispose();
  }
//-------------------------------------------------------------------------
  void i5_actionPerformed(ActionEvent e) {
    // open "http://cf.icq.com/cf/2003/unregister.html"
  }
//-------------------------------------------------------------------------
  void m1_actionPerformed(ActionEvent e) {
    System.out.println("Request MyInformation");
    byte[] data ;
    short lastseq ;
    try{
          data = this.sconn.clientCMD.setMetaReqInfoPacket(OwnerDataInfo.getUin());
          lastseq = this.sconn.packetforsend.header.getSequence() ;
          this.sconn.packetforsend = new  CmdPacket() ;
          this.sconn.sendPacket(this.sconn.packetforsend.setPacket(this.sconn.clientCMD.metareqinfo,lastseq,data)) ;
    }
    catch(Exception ty){}
    this.sconn.logonpage.mainPage.userDetail = new UserDetail(this.sconn);
    this.sconn.logonpage.mainPage.userDetail.setUin(OwnerDataInfo.getUin());
  }
//--------------------------------------------------------------------------
  void m4_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
//--------------------------------------------------------
  public void setList(){
        Vector onlinelist = new Vector()  ;
        Vector offlinelist = new Vector() ;
        Vector securelist = new Vector() ;
        Vector user = new Vector() ;

       /* jList1.addMouseListener(new java.awt.event.MouseAdapter() {
          public void mouseClicked(MouseEvent e) {
            jList1_mouseClicked(e);
          }
        }); */
        user.addElement("  ------------- Secure --------------");
        user.addElement("  ------------- Online --------------");
        user.addElement("  ------------- Offline -------------");
        UserData uinfo ;
        int sizeofmycontact,i,j ;
        int len ;
        String uin ;
        sizeofmycontact = OwnerDataInfo.getMyContactlist().size() ;
        for(i = 0 ;i < sizeofmycontact ;i++){
                uinfo = (UserData) OwnerDataInfo.getMyContactlist().elementAt(i) ;
                if(uinfo.getStatus().equals("online")){
                   user.insertElementAt(uinfo.getNickname(),securelist.size()+2) ;
                   onlinelist.insertElementAt(uinfo,0);
                }else if(uinfo.getStatus().equals("offline")){
                   user.insertElementAt(uinfo.getNickname(),user.size());
                   offlinelist.addElement(uinfo);
                }else if(uinfo.getStatus().equals("secure")){
                   //-------------not complete---------------
                   user.insertElementAt(uinfo.getNickname(),1);
                   securelist.addElement(uinfo) ;
                }
        }
     //----------------------set list ------------------------------
        OwnerDataInfo.setOnlinelist(onlinelist);
        OwnerDataInfo.setOfflinelist(offlinelist);
        OwnerDataInfo.setSecurelist(securelist);
     //---------------------------------------------------------------

      this.jScrollPane1.remove(jList1) ;
      //this.jList1 = new JList(user) ;
      this.jList1.setListData(user);
      m = new MyCellRenderer(ic/*,this.sconn.ownerdata.getMyContactlist()*/) ;
      jList1.setCellRenderer(m);

      jScrollPane1.getViewport().add(jList1, null);
      jList1.setBackground(new Color(236, 255, 255));
      jScrollPane1.setBorder(BorderFactory.createLoweredBevelBorder());
  }
//------------------------------------------------------------
  void jList1_mouseClicked(MouseEvent e) {
      int i,j;
      String status ;
      userdata = new UserData() ;
      int onlinepos = 0,offlinepos = 0,securepos = 0 ;
       if(e.getButton() == 3 && this.jList1.getSelectedIndex() != -1)
       {
         jPopupMenu4.show(jPanel1,e.getX()-68,e.getY()-322)  ;
         System.out.println(jList1.getSelectedIndex()) ;
         j = m.getSelectindex(this.jList1.getSelectedIndex()) ;
             if(m.getStatuslist().equals("online")){
               userdata = (UserData) OwnerDataInfo.getOnlinelist().elementAt(j) ;
             }
             else if(m.getStatuslist().equals("offline")){
              userdata = (UserData) OwnerDataInfo.getOfflinelist().elementAt(j) ;
             }
             else if(m.getStatuslist().equals("secure")){
              userdata = (UserData) OwnerDataInfo.getSecurelist().elementAt(j) ;
             }
       }
       //----------------------------------------------------------------------
       if(e.getClickCount() > 2 && e.getButton() == 1 ){
         j = m.getSelectindex(this.jList1.getSelectedIndex()) ;
             if(m.getStatuslist().equals("online")){
               userdata = (UserData) OwnerDataInfo.getOnlinelist().elementAt(j) ;
             }
             else if(m.getStatuslist().equals("offline")){
              userdata = (UserData) OwnerDataInfo.getOfflinelist().elementAt(j) ;
             }
             else if(m.getStatuslist().equals("secure")){
              userdata = (UserData) OwnerDataInfo.getSecurelist().elementAt(j) ;
             }
          messagePage = new MessagePage(this.sconn,userdata);
          messagePage.show();
       }
      //-----------------------------------------------------------------------
  }
//------------------------------------------------------
  public void setuser(Vector user){
           this.user = user ;
  }
//-----------------------------------------------------------------
  void u5_actionPerformed(ActionEvent e) {
        this.filechooser = new FileChooser(this.sconn,this.userdata) ;
        this.filechooser.show();
  }
//-------------------------------------------------------
}