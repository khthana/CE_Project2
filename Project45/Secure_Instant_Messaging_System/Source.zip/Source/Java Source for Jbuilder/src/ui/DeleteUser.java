package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.* ;
import com.borland.jbcl.layout.*;
import java.util.* ;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DeleteUser extends JFrame {
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  private String uin  ;
  private ServerConnect sconnect ;
  private UserData user ;

  //Construct the frame
  public DeleteUser(ServerConnect sconnect,UserData user) {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.user = user ;
    this.sconnect = sconnect ;
    try {
      this.uin = user.getUin() ;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(DeleteUser.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();

    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("Do you want to delete UIN " + uin + " ?");
    jLabel1.setBounds(new Rectangle(10, 10, 156, 20));
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(285, 105));
    this.setTitle("Delete UIN " + uin);
    jButton1.setBounds(new Rectangle(150, 45, 60, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("Yes");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(220, 45, 50, 25));
    jButton2.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton2.setText("No");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    contentPane.add(jLabel1, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
  }
  //Overridden so we can exit when window is closed
//----------------------------------------------------------------
  public UserData checknewuser(String uin){
        UserData user ;

        user = new UserData() ;
        Properties p ;
        p = new Properties() ;
        p = this.sconnect.logonpage.getUserNotInGroupList() ;
        System.out.println(uin);
        user = (UserData)p.get(uin) ;
        if(user != null ){
            return user ;
        }
        return null ;
 }
//---------------------------------------------------------------
  public void updategroupRemove(){
            byte[] data ;
            short lastseq ;
      //      UserData tempdata ;
      //      tempdata = this.checknewuser(this.user.getUin()) ;//--------------- new user-----------------
            try{
      //        if(tempdata == null){//--------------- old user-----------------------------

                data = this.sconnect.clientCMD.setUpdateGroupPacket("Remove", user);
                lastseq = this.sconnect.packetforsend.header.getSequence();
                this.sconnect.packetforsend = new CmdPacket();
                this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.updategroup, lastseq, data));
                //Thread.sleep(5000);

                data = this.sconnect.clientCMD.setAddEndPacket();
                lastseq = this.sconnect.packetforsend.header.getSequence();
                this.sconnect.packetforsend = new CmdPacket();
                this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.addend, lastseq, data));
                //Thread.sleep(5000);
        //      }//--------------------------- new user -------------------------------------
                Properties p = new Properties();
                UserData temp;
                p = OwnerDataInfo.getProperties();
                p.remove(user.getUin());
                for (int i = 0; i < OwnerDataInfo.getMyContactlist().size(); i++) {
                  temp = (UserData) OwnerDataInfo.getMyContactlist().elementAt(i);
                if (temp.getUin().equals(user.getUin())) {
                  OwnerDataInfo.getMyContactlist().removeElementAt(i);
                }
              }
            }catch(Exception e){}
        this.sconnect.logonpage.mainPage.setList() ;
        System.out.println("------------------ remove   success--------------------------");
  }
//---------------------------------------------------------------
  public void deleteUser(){
         byte[] data ;
         short lastseq ;
         try{

         System.out.println("---------------start remove---------------");
         this.sconnect.updatetype = "Remove" ;

         data = this.sconnect.clientCMD.setAddStartPacket();
         lastseq = this.sconnect.packetforsend.header.getSequence() ;
         this.sconnect.packetforsend = new CmdPacket() ;
         this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.addstart,lastseq,data)) ;
         //Thread.sleep(5000);

         data = this.sconnect.clientCMD.setDeleteBuddyPacket(this.user);
         lastseq = this.sconnect.packetforsend.header.getSequence() ;
         this.sconnect.packetforsend = new CmdPacket() ;
         this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.deletebuddy,lastseq,data)) ;

       }catch(Exception g){}
  }
//---------------------------------------------------------------
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      dispose();
    }
  }
//----------------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
       dispose();
  }
//------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
       this.deleteUser();
       dispose();
  }
}