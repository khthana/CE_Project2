package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AddAnother extends JFrame {
  private ServerConnect sconnect ;
  LogonPage logonPage;
  AddAnotherFail addAnotherFail;
  AddAnotherConfirm addAnotherConfirm;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JLabel jLabel3 = new JLabel();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JTextField jTextField1 = new JTextField();

  //Construct the frame
  public AddAnother() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(AddAnother.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(290, 160));
    this.setTitle("Add another registered user");
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel1.setText("UIN :");
    jLabel1.setBounds(new Rectangle(45, 38, 65, 20));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Password :");
    jLabel2.setBounds(new Rectangle(45, 65, 65, 20));
    jPasswordField1.setText("");
    jPasswordField1.setBounds(new Rectangle(115, 65, 120, 20));
    jLabel3.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel3.setText("Please enter UIN and password.");
    jLabel3.setBounds(new Rectangle(5, 5, 185, 20));
    jButton1.setBounds(new Rectangle(65, 100, 60, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(140, 100, 75, 25));
    jButton2.setText("Cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jTextField1.setBounds(new Rectangle(115, 38, 120, 20));
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jTextField1, null);
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }
//------------------------------------------------------------------------------
  void jButton2_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
  }
//---------------------------------------------------------
   public void reqOwnInfo(){
       int i = 0   ;
       short lastseq ;
       byte[] data ;
       try{
          this.sconnect = this.logonPage.getServerConnect() ;
          lastseq = this.sconnect.packetforsend.header.getSequence();
          this.sconnect.packetforsend = new CmdPacket();
          data = this.sconnect.clientCMD.setSearchByUin(OwnerDataInfo.getUin());
          this.sconnect.sendPacket(this.sconnect.packetforsend.setPacket(this.sconnect.clientCMD.searchbyuin, lastseq, data));
          try {
            Thread.sleep(1000);
          }
          catch (Exception t) {}
       }
       catch(IOException e){}
   }
//------------------------------------------------------------------------------
  void jButton1_actionPerformed(ActionEvent e) {
    String password ;
    String uin = jTextField1.getText();
    char[] pass ;
    this.dispose() ;
    pass = jPasswordField1.getPassword() ;
    password = new String(pass) ;
    this.logonPage = new LogonPage() ;
    this.logonPage.login(uin,password);
    this.reqOwnInfo() ;
  }
//------------------------------------------------------------------------------
}