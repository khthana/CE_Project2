package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
public class ContactListinfo {
  private String groupname ;
  private short groupnum ;
  private short ids ;
  private short type ;
  private byte[] time = new byte[4] ;
  private byte[] size = new byte[2] ;
  private byte[] listofids ;
  public ContactListinfo() {
  }
  //--------------------------------------------
  public void setListofid(byte[] list){
        this.listofids = list ;
  }
  //--------------------------------------------
  public byte[] getlistofids(){
    return this.listofids ;
  }
  //--------------------------------------------
  public byte[] size(){
    return this.size ;
  }
  //--------------------------------------------
  public byte[] getTime(){
      return this.time ;
  }
  //---------------------------------
  public void setSize(byte[] size){
    this.size = size ;
  }
  //-------------------------------------
  public void setTime(byte[] time){
      this.time = time ;
  }
  //------------------------------------
  public short getType(){
      return this.type ;
  }
  //------------------------------------
  public void setType(short type){
      this.type = type ;
  }
  //--------------------------
  public short getId(){
      return  this.ids ;
  }
  //------------------------------
  public void setId(short id){
      this.ids = id ;
  }
  //-------------------------------
  public short getGroupnum(){
     return this.groupnum;
  }
  //--------------------------------
  public void setGroupunm(short id){
     this.groupnum = id ;
  }
  //-------------------------------
  public void setGroupname(String group){
     this.groupname = group ;
  }
  //-----------------------------------
  public String getGroupname(){
     return this.groupname ;
  }
}