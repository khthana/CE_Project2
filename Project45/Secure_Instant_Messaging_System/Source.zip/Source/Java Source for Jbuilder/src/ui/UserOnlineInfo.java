package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.* ;
public class UserOnlineInfo {
  private String uin  ;
  private String internal_ip ;
  private String external_ip ;
  private int status ;
  private short port ;
  private byte[] cookies ;
  private DataOutputStream out ;
  private    String displaystatus = " ";
//----------------------------------------------------------
public  void setDisplaystatus(String status){
  this.displaystatus = status ;
}
//----------------------------------------------------------
public String getDisplaystatus(){
  return this.displaystatus ;
}
//--------------------------------
  public UserOnlineInfo() {
  }
//-------------------------------
  public byte[] getCookies(){
      return this.cookies ;
  }
//---------------------------------
  public int getStatus(){
      return this.status ;
  }
//--------------------------------
  public short getPort(){
      return this.port ;
  }
//---------------------------------
  public String getExternal_Ip(){
      return this.external_ip ;
  }
//---------------------------------
  public String getInternal_Ip(){
      return this.internal_ip ;
  }
//---------------------------------
  public String getUin(){
      return this.uin ;
  }
//---------------------------------
  public void setUin(String uin){
      this.uin = uin ;
  }
//---------------------------------
  public void setInternal_Ip(String ip){
      this.internal_ip = ip ;
  }
//---------------------------------
  public void setExternal_Ip(String ip){
      this.external_ip = ip ;
  }
//------------------------------------
  public void setStatus(int status){
      this.status = status ;
  }
//-------------------------------------
  public void setport(short port){
      this.port = port ;
  }
//-------------------------------------
  public void setCookie(byte[] cookies){
      this.cookies = cookies ;
  }
//---------------------------------
  public void setDataOutput(DataOutputStream out){
      this.out = out ;
  }
//---------------------------------------------------
  public DataOutputStream getOutputStream(){
      return this.out ;
  }
}