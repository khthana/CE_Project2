package ui;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.security.* ;
import javax.crypto.spec.* ;
import java.math.* ;
import java.security.spec.* ;
import javax.crypto.* ;
public class UserData {
     private    short idInGroup ;
     private    String uin ;
     private    String nickname = " " ;
     private    byte[] cookiep2p   ;
     private    String internal_ip ;
     private    String external_ip ;
     private    String status      ;
     private    String lastname   ;
     private    String firstname  ;
     private    String email  ;
     private    String gender ;
     private    int age ;
     private    String authorize ;
     private    short tcpconnectport ;
     private    PublicKey publickey  ;
     private    SecretKey  secretkey ;
     private    String city ;
     private    String state ;
     private    String country ;
     private    String zipcode ;
     private    String phone ;
     private    String fax ;
     private    String street ;
     private    String cellular ;
     private    String homepage ;
     private    String year ;
     private    String month ;
     private    String day ;
     private    String displaystatus ;

//----------------------------------------------------------
  public  void setDisplaystatus(String status){
       this.displaystatus = status ;
  }
//----------------------------------------------------------
  public String getDisplaystatus(){
       return this.displaystatus ;
  }
//----------------------------------------------------------
  public   void setPublicKey(PublicKey pubkey){
       publickey = pubkey ;
  }
//----------------------------------------------------------
  public   void setDay(String day1){
       day =  day1 ;
   }
//----------------------------------------------------------
   public   String getDay(){
       return day  ;
   }
//----------------------------------------------------------
  public   void setMonth(String month1){
       month =  month1 ;
   }
//----------------------------------------------------------
   public   String getMonth(){
       return month  ;
   }
//----------------------------------------------------------
  public   void setYear(String year1){
       year =  year1 ;
   }
//----------------------------------------------------------
   public   String getYear(){
       return  year  ;
   }
//----------------------------------------------------------
  public   void setHomepage(String homepage1){
       homepage =  homepage1 ;
   }
//----------------------------------------------------------
   public   String getHomepage(){
       return homepage  ;
   }
//----------------------------------------------------------
  public   void setCellular(String cellular1){
       cellular =  cellular1 ;
   }
//----------------------------------------------------------
   public   String getCellular(){
       return cellular  ;
   }
//----------------------------------------------------------
  public   void setStreet(String street1){
       street =  street1 ;
   }
//----------------------------------------------------------
   public   String getStreet(){
       return street  ;
   }
//----------------------------------------------------------
  public   void setFax(String fax1){
       fax =  fax1 ;
   }
//----------------------------------------------------------
   public   String getFax(){
       return fax  ;
   }
//----------------------------------------------------------
  public   void setPhone(String phone1){
       phone =  phone1 ;
   }
//----------------------------------------------------------
   public   String getPhone(){
       return phone  ;
   }
//----------------------------------------------------------
  public   void setCity(String city1){
       city =  city1 ;
   }
//----------------------------------------------------------
   public   String getCity(){
       return city  ;
   }
//----------------------------------------------------------
  public   void setZipcode(String zipcode1){
       zipcode =  zipcode1 ;
   }
//----------------------------------------------------------
   public   String getZipcode(){
       return zipcode  ;
   }
//----------------------------------------------------------
  public   void setState(String state1){
       state =  state1 ;
   }
//----------------------------------------------------------
   public   String getState(){
       return state  ;
   }
//----------------------------------------------------------
  public   void setCountry(String country1){
       country =  country1 ;
   }
//----------------------------------------------------------
   public   String getCountry(){
       return country  ;
   }
//------------------------------------------------------------
  public   byte[] getPublickeyBytes(){
          byte[] publicKeyBytes = publickey.getEncoded();
          return publicKeyBytes ;
  }
//----------------------------------------------------------------------

  public   void setSecretKey(SecretKey seckey){
      secretkey = seckey ;
  }
//----------------------------------------------------------
  public   PublicKey getPublickey(){
     return publickey ;
  }
//----------------------------------------------------------
  public   SecretKey getSecretKey(){
     return secretkey ;
  }
//----------------------------------------------------------
  public   short getIdInGroup(){
        return idInGroup ;
  }
//----------------------------------------------------------
  public   void setIdInGroup(short id){
        idInGroup = id ;
  }
//----------------------------------------------------------
  public   String getNickname(){
        return nickname ;
  }
//-----------------------------------------------------------
  public   void setNickname(String nickname1){
      nickname = nickname1 ;
  }
//-----------------------------------------------------------
  public   short getTcpconnectport(){
      return tcpconnectport ;
  }
//-----------------------------------------------------------
  public   void setTcpconnectport(short port){
      tcpconnectport = port ;
  }
//-----------------------------------------------------------
  public   byte[] getCookiep2p(){
      return cookiep2p ;
  }
//-----------------------------------------------------------
  public   void setCookiep2p(byte[] cookie){
      cookiep2p = cookie ;
  }
//-----------------------------------------------------------
  public   void  setStatus(String status1){
      status = status1 ;
  }
//-----------------------------------------------------------
  public   String getStatus(){
      return status ;
  }
//-----------------------------------------------------------
  public   String getExternal_ip(){
      return external_ip ;
  }
//-----------------------------------------------------------
  public   void setExternal_ip(String ip){
       external_ip = ip ;
  }
//-----------------------------------------------------------
  public   void setInternal_ip(String ip){
       internal_ip = ip   ;
  }
//-----------------------------------------------------------
  public   void setUin(String uin1){
       uin = uin1;
  }
//-----------------------------------------------------------
  public UserData() {
       status = "offline" ;
       nickname = " " ;
  }
//------------------------------------------------------------
  public   String getInternal_ip(){
       return internal_ip ;
  }
//-----------------------------------------------------------
  public   String getUin(){
        return uin ;
  }
//-------------------------------------------------------------
  public   String getLastname(){
    return lastname ;
  }
//---------------------------------------------------------------
  public   String getFirstname(){
    return firstname ;
  }
//---------------------------------------------------------------
  public   String getEmail(){
    return email ;
  }
//---------------------------------------------------------------
  public   String getGender(){
    return gender ;
  }
//---------------------------------------------------------------
  public   int getAge(){
    return age ;
  }
//---------------------------------------------------------------
  public   String getAuthorize(){
    return authorize ;
  }
//-------------------------------------------------------
  public   void setLastname(String lastname1){
     lastname = lastname1 ;
  }
//----------------------------------------------------------
  public   void setFirstname(String firstname1){
    firstname = firstname1 ;
  }
//-----------------------------------------------------------
  public   void setEmail(String email1){
    email = email1 ;
  }
//------------------------------------------------------------
  public   void setGender(String gender1){
    gender = gender1   ;
  }
//------------------------------------------------------------
  public   void setAge(int age1){
     age = age1 ;
  }
//------------------------------------------------------------
  public   void setAuthorize(String authorize1){
    authorize = authorize1 ;
  }
//---------------------------------------------------------------
}