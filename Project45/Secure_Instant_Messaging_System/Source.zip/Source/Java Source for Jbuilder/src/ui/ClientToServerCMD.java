package ui;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;
public class ClientToServerCMD {
   private short groupid ;
   private byte[] listofids ;
   private short idtoadd ;
   private short idtoremove ;
   final int keepalive        = 0x10000000 ;
   final int ident            = 0x00000001 ;
   final int cookie           = 0x00000002 ;
   final int goodbye          = 0x00000003 ;
   final int changestatus     = 0x00000004 ;
   final int ready            = 0x00010002 ;
   final int ratesrequest     = 0x00010006 ;
   final int ackrates         = 0x00010008 ;
   final int reqinfo          = 0x0001000e ;
   final int families         = 0x00010017 ;
   final int setstatus        = 0x0001001e ;
   final int reqlocation      = 0x00020002 ;
   final int setuserinfo      = 0x00020004 ;
   final int reqbuddy         = 0x00030002 ;
   final int addconnect       = 0x00030004 ;
   final int removeconnect    = 0x00030005 ;
   final int seticbm          = 0x00040002 ;
   final int reqicbm          = 0x00040004 ;
   final int sendmsg          = 0x00040006 ;
   final int reqbos           = 0x00090002 ;
   final int addvisible       = 0x00090005 ;
   final int remvisible       = 0x00090006 ;
   final int addinvisible     = 0x00090007 ;
   final int reminvisible     = 0x00090008 ;
   final int reqlists         = 0x00130002 ;
   final int reqroster        = 0x00130004 ;
   final int checkroster      = 0x00130005 ;
   final int rosterack        = 0x00130007 ;
   final int addbuddy         = 0x00130008 ;
   final int updategroup      = 0x00130009 ;
   final int deletebuddy      = 0x0013000a ;
   final int addstart         = 0x00130011 ;
   final int addend           = 0x00130012 ;
   final int grantauth        = 0x00130014 ;
   final int reqauth          = 0x00130018 ;
   final int authorize        = 0x0013001a ;
   final int snack1_11        = 0x00010011 ;
   //final int toicqsrv         = 0x00150002 ;
   final int reqofflinemsgs    = 0x00150002 ;
   final int ackofflinemsgs    = 0x000000a9 ;
   final int searchbypersinf   = 0x000000aa ;
   final int searchbymail      = 0x000000ab ;
   final int searchbyuin       = 0x000000ac ;
   final int sendsmg2server    = 0x000000ad ;
   final int metareqinfo       = 0x000000ae ;
   final int metasetgeneral    = 0x000000af ;
   final int metasetmore       = 0x000000b0 ;

   final int registeruser      = 0x00170004 ;

 /* private final int meta ;
  private final int metasetgeneral ;
  private final int metasetmore ;
  private final int metasetabout ;

  private final int searchwp ;

  private final int searchrandom ;
  private final int metasetrandom ;
  private final int reqxml ;
  private final int snac20002750 ;
  private final int sendsms ;
  private final int registeruser ; */
   private Util u;
//------------------------------------------------------------------------
   public void setGroupid(short id){
       this.groupid = id ;
   }
//-----------------------------------------------------------------------------
   public void setIdtoadd(short id){
       this.idtoadd = id ;
   }
//-----------------------------------------------------------------------------
   public void setListofids(byte [] list){
        this.listofids = list ;
   }
//-----------------------------------------------------------------------------
   public byte[] setHelloPacket() throws IOException{
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       int hello = 0x00000001  ;
       dataOut.writeInt(hello) ;
       return byteOut.toByteArray() ;
   }
//-----------------------------------------------------------------------------
   public byte[] setIdentPacket() throws IOException
  {
               int Hello = 0x00000001;
               String uin =       OwnerDataInfo.getUin() ;
               String password  = OwnerDataInfo.getStringPassword() ;
               final String version    = "ICQ Inc. - Product of ICQ (TM).2002a.5.37.1.3728.85"  ;
               final short unknow        = 0x010a ;
               final short ver_major     = 0x0005 ;
               final short ver_minor     = 0x0025 ;
               final short ver_lesser    = 0x0001 ;
               final short ver_build     = 0x0e90 ;
               final int ver_subbulid = 0x00000055 ;
               String language = OwnerDataInfo.getLanguage() ;
               String country =  OwnerDataInfo.getCountry()  ;
               short tlvlength = 0 ;
               short tlv1  = 0x0001 ;
               short tlv2  = 0x0002 ;
               short tlv3  = 0x0003 ;
               short tlv16 = 0x0016 ;
               short tlv17 = 0x0017 ;
               short tlv18 = 0x0018 ;
               short tlv19 = 0x0019 ;
               short tlv1a = 0x001a ;
               short tlv14 = 0x0014 ;
               short tlv0f = 0x000f ;
               short tlv0e = 0x000e ;
               ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
               DataOutputStream dataOut=new DataOutputStream(byteOut);
               dataOut.writeInt(Hello);
               dataOut.writeShort(tlv1);// tlv(1)
               tlvlength =  (short)uin.length() ;
               dataOut.writeShort(tlvlength) ; //set length tlv1
               dataOut.writeBytes(uin);
               dataOut.writeShort(tlv2);// tlv(2)
               tlvlength =  (short)password.length() ;
               dataOut.writeShort(tlvlength);  //set length tlv2
               dataOut.write(OwnerDataInfo.getencryptPassword());
               //------------------------------------
               dataOut.writeShort(tlv3);// tlv(3)
               tlvlength =  (short)version.getBytes().length ;
               dataOut.writeShort(tlvlength); // set length tlv3
               dataOut.writeBytes(version);
               dataOut.writeShort(tlv16);// tlv(16)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv16
               dataOut.writeShort(unknow);
               dataOut.writeShort(tlv17);// tlv(17)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv17
               dataOut.writeShort(ver_major);
               dataOut.writeShort(tlv18);// tlv(18)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv18
               dataOut.writeShort(ver_minor);
               dataOut.writeShort(tlv19);// tlv(19)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv19
               dataOut.writeShort(ver_lesser);
               dataOut.writeShort(tlv1a);// tlv(1a)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv1a
               dataOut.writeShort(ver_build);
               dataOut.writeShort(tlv14);// tlv(14)
               tlvlength =  (short)0x0004  ;
               dataOut.writeShort(tlvlength);//set length tlv14
               dataOut.writeInt(ver_subbulid);
               dataOut.writeShort(tlv0f);// tlv(0f)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv0f
               dataOut.writeBytes(language);
               dataOut.writeShort(tlv0e);// tlv(0e)
               tlvlength =  (short)0x0002  ;
               dataOut.writeShort(tlvlength);//set length tlv0e
               dataOut.writeBytes(country);
               return byteOut.toByteArray();
  }
  //----------------------------------------------------------------------------
  public byte[] setGoodbyePacket(){
       return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setCookiePacket() throws IOException {
               ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
               DataOutputStream dataOut=new DataOutputStream(byteOut);
               dataOut.writeInt(this.ident) ;
               dataOut.write(OwnerDataInfo.getCookies())    ;
               return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setRateReqPacket()
    {
           return null;
    }
  //----------------------------------------------------------------------------
  public byte[] setAckRatePacket() throws IOException
    {
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       final short ack1  =   0x0001  ;
       final short ack2  =   0x0002  ;
       final short ack3  =   0x0003  ;
       final short ack4  =   0x0004  ;
       final short ack5  =   0x0005  ;
       dataOut.writeShort(ack1);
       dataOut.writeShort(ack2);
       dataOut.writeShort(ack3);
       dataOut.writeShort(ack4);
       dataOut.writeShort(ack5);
       return byteOut.toByteArray();
    }
  //----------------------------------------------------------------------------
  public byte[] setReqInfoPacket()
    {
           return null;
    }
  //----------------------------------------------------------------------------
  public byte[] setFamiliesPacket() throws IOException
  {
      ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
      DataOutputStream dataOut=new DataOutputStream(byteOut);
      final int family1  = 0x00010003 ;
      final int family2  = 0x00130002 ;
      final int family3  = 0x00020001 ;
      final int family4  = 0x00030001 ;
      final int family5  = 0x00150001 ;
      final int family6  = 0x00040001 ;
      final int family7  = 0x00060001 ;
      final int family8  = 0x00090001 ;
      final int family9  = 0x000a0001 ;
      final int family10 = 0x000b0001 ;
      dataOut.writeInt(family1);
      dataOut.writeInt(family2);
      dataOut.writeInt(family3);
      dataOut.writeInt(family4);
      dataOut.writeInt(family5);
      dataOut.writeInt(family6);
      dataOut.writeInt(family7);
      dataOut.writeInt(family8);
      dataOut.writeInt(family9);
      dataOut.writeInt(family10);
      return byteOut.toByteArray()  ;
  }
  //----------------------------------------------------------------------------
  public byte[] setStatusPacket() throws IOException
  {
      ///------------------------- not complete------------------------------
         ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
         DataOutputStream dataOut=new DataOutputStream(byteOut);
         // STATUS
         dataOut.writeShort(0x0006); // tlv(06)
         dataOut.writeShort(0x0004);
         dataOut.writeInt(0x20020000); // xx xx xx xx status
         // ERROR
         dataOut.writeShort(0x0008); // tlv(08)
         dataOut.writeInt(0x00020000);
         // CLI2CLI
         dataOut.writeShort(0x000c); // tlv(0c)
         dataOut.writeShort(0x0025);
         // IPINTERNAL
         dataOut.writeInt(Util.IPstring2Int(OwnerDataInfo.getMyIPaddress())); // xx xx xx xx
         // PORT
         dataOut.writeShort(0x0000);
         dataOut.writeShort(0x1388);
         // TCPFLAG
         dataOut.writeByte(0x04); // xx
         // TCPVERSION
         dataOut.writeShort(0x0008);
         // COOKIE
         dataOut.writeInt(0x00000000); // xx xx xx xx
         // UNKNOWN
         dataOut.writeShort(0x0000);
         // UNKNOWN
         dataOut.writeShort(0x0050);
         // UNKNOWN
         dataOut.writeShort(0x0000);
         // COUNT
         dataOut.writeShort(0x0003);
         // TIME
         dataOut.writeInt(0x3df43f27); // xx xx xx xx
         // TIME
         dataOut.writeInt(0x3df440ac); // xx xx xx xx
         // TIME
         dataOut.writeInt(0x3df43f27); // xx xx xx xx
         // UNKNOWN
         dataOut.writeShort(0x0000);
          return  byteOut.toByteArray();
  }
  //----------------------------------------------------------------------------
  public byte[] setReqLocationPacket()
  { return null ;}
  //----------------------------------------------------------------------------
  public byte[] setUserInfoPacket() throws IOException{
      ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
      DataOutputStream dataOut=new DataOutputStream(byteOut);
      // CAPABILITIES
      dataOut.writeShort(0x0005); // tlv(05)
      dataOut.writeShort(0x0040);
      if(OwnerDataInfo.icqversion().equals("icq2001")){
      // for sending by ICQ2001 constanst
         dataOut.writeInt(0x09461349) ;
         dataOut.writeInt(0x4C7F11D1) ;
         dataOut.writeInt(0x82224445) ;
         dataOut.writeInt(0x53540000) ;
         dataOut.writeInt(0x97B12751) ;
         dataOut.writeInt(0x243C4334) ;
         dataOut.writeInt(0xAD22D6AB) ;
         dataOut.writeInt(0xF73F1492) ;
         dataOut.writeInt(0x2E7A6475) ;
         dataOut.writeInt(0xFADF4DC8) ;
         dataOut.writeInt(0x886FEA35) ;
         dataOut.writeInt(0x95FDB6DF) ;
         dataOut.writeInt(0x09461344) ;
         dataOut.writeInt(0x4C7F11D1) ;
         dataOut.writeInt(0x82224445) ;
         dataOut.writeInt(0x53540000) ;
      }
      else if(OwnerDataInfo.icqversion().equals("icq2002a")){
      // for sending by ICQ2002a  constanst
         dataOut.writeInt(0x09461349) ;
         dataOut.writeInt(0x4C7F11D1) ;
         dataOut.writeInt(0x82224445) ;
         dataOut.writeInt(0x53540000) ;
         dataOut.writeInt(0x0946134E) ;
         dataOut.writeInt(0x4C7F11D1) ;
         dataOut.writeInt(0x82224445) ;
         dataOut.writeInt(0x53540000) ;
         dataOut.writeInt(0x97B12751) ;
         dataOut.writeInt(0x243C4334) ;
         dataOut.writeInt(0xAD22D6AB) ;
         dataOut.writeInt(0xF73F1492) ;
         dataOut.writeInt(0x09461344) ;
         dataOut.writeInt(0x4C7F11D1) ;
         dataOut.writeInt(0x82224445) ;
         dataOut.writeInt(0x53540000) ;
      }
      return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setReqBuddyPacket()
  {
     return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setAddContactPacket(String uin) throws IOException
  {
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       short tlvlength = 0;
       // STRLEN
       tlvlength = (short)uin.length() ;
       dataOut.writeShort(tlvlength);
       // UIN
       dataOut.writeChars(uin);
       return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setRemoveContactPacket(String uin) throws IOException
  {
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       short tlvlength = 0;
       // STRLEN
       tlvlength = (short)uin.length() ;
       dataOut.writeShort(tlvlength);
       // UIN
       dataOut.writeChars(uin);
       return  byteOut.toByteArray();
  }
  //----------------------------------------------------------------------------
  public byte[] setIcbmPacket() throws IOException
  {
      ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
      DataOutputStream dataOut=new DataOutputStream(byteOut);
      // UNKNOWN
      dataOut.writeShort(0x0000); // 0
      // UNKNOWN
      dataOut.writeShort(0x0000); // 0
      // UNKNOWN
      dataOut.writeShort(0x0003); // 3
      // UNKNOWN
      dataOut.writeShort(0x1f40); // 8000
      // UNKNOWN
      dataOut.writeShort(0x03e7); // 999
      // UNKNOWN
      dataOut.writeShort(0x03e7); // 999
      // UNKNOWN
      dataOut.writeShort(0x0000); // 0
      // UNKNOWN
      dataOut.writeShort(0x0000); // 0
      return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setReqIcbmPacket()
   {
       return null ;
   }
  //----------------------------------------------------------------------------
  public byte[] setSendmsgonline(String uintosendmsg,String msg)throws IOException {
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       int msgid ;
       Random r = new Random();
       msgid = (short)r.nextInt() ;
       int msgid1 ;
       r = new Random();
       msgid1 = (short)r.nextInt() ;
       int unknown4 = 0x0001 ;
       int uinlen ;
       uinlen = uintosendmsg.length() ;
       short tlv02 = 0x0002 ;
       int tlv02len ;
       int unknown3_1 = 0x05010004 ; //----not same ------
       int unknown3_2 = 0x01010102 ; //----not same ------
       short tlv0101 = 0x0101 ;
       int tlv0101len ;
       int unknown2 = 0x00000000 ;
       int unknown1 = 0x00060000 ;
       int unknown0 = 0x00030000 ;
        dataOut.writeInt(msgid) ;
        dataOut.writeInt(msgid1);
        dataOut.writeShort(unknown4);
        dataOut.writeByte(uinlen) ;
        dataOut.writeBytes(uintosendmsg) ;
        dataOut.writeShort(tlv02) ;
        tlv0101len =  4 + msg.length() ;
        tlv02len = 12  + tlv0101len ;
        dataOut.writeShort(tlv02len);
        dataOut.writeInt(unknown3_1);
        dataOut.writeInt(unknown3_2);
        dataOut.writeShort(tlv0101);
        dataOut.writeShort(tlv0101len);
        dataOut.writeInt(unknown2);
        dataOut.writeBytes(msg);
        dataOut.writeInt(unknown1);
        dataOut.writeInt(unknown0);
       return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setSendmsg2serverPacket(String uin,String msg)throws IOException{
        //--------------------------------not complete------------------------
        ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
        DataOutputStream dataOut=new DataOutputStream(byteOut);
        int msgid ;
        Random r = new Random();
        msgid = (short)r.nextInt() ;
        int msgid1 ;
        r = new Random();
        msgid1 = (short)r.nextInt() ;
        int unknown4 = 0x0001 ;
        int uinlen ;
        uinlen = uin.length() ;
        short tlv02 = 0x0002 ;
        int tlv02len ;
        int unknown3_1 = 0x05010001 ;
        byte unknown3_2 = 0x01 ;
        short tlv0101 = 0x0101 ;
        int tlv0101len ;
        int unknown2 = 0x0000ffff ;
        int unknown1 = 0x00060000 ;
        dataOut.writeInt(msgid) ;
        dataOut.writeInt(msgid1);
        dataOut.writeShort(unknown4);
        dataOut.writeByte(uinlen) ;
        dataOut.writeBytes(uin) ;
        dataOut.writeShort(tlv02) ;
        tlv0101len =  4 + msg.length() ;
        tlv02len = 9  + tlv0101len ;
        dataOut.writeShort(tlv02len);
        dataOut.writeInt(unknown3_1);
        dataOut.writeByte(unknown3_2);
        dataOut.writeShort(tlv0101);
        dataOut.writeShort(tlv0101len);
        dataOut.writeInt(unknown2);
        dataOut.writeBytes(msg);
        dataOut.writeInt(unknown1);
        return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setSendMsgPacket() throws IOException
  {
     //************************* under construction ***************************
        final int   unknown1   = (byte)0x05010001 ;
        final int   unknown1_1 = (byte)0x010101 ;
        final short unknown2 = 0x00000000 ;
        final short unknown3 = 0x0000 ;
        short tlvlength = 0 ;
        short msgID =   /*underconstruction*/ 0 ; // Message ID
        int msgFormat = /*underconstruction*/ 0 ; // Type Message
        String uin = OwnerDataInfo.getUin() ; // User UIN
        String uinSent =  /*underconstruction*/ null ; // UIN for Sending
        String textSent = /*underconstruction*/ null ; // Text following
        ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
        DataOutputStream dataOut=new DataOutputStream(byteOut);
        // MID
        dataOut.write(msgID); // xx xx xx xx xx xx xx xx
        // MSGFORMAT
        dataOut.write(msgFormat); // xx xx - Type of Message
        // UIN
        tlvlength =  (short)uinSent.length() ;
        dataOut.writeShort(tlvlength) ; // xx
        dataOut.writeChars(uinSent); // varies
        // MESSAGE
        dataOut.write(0x0002); // tlv02
        dataOut.write(/*message*/null); // varies -- Message for FORMAT = 1
        // UNKNOWN
        dataOut.write(unknown1);
        dataOut.write(unknown1_1);
        // LENGTH
        tlvlength =  (short)textSent.length() ;
        //tlvlength =  tlvlength + 4 ;
        dataOut.writeShort(tlvlength) ; // xx xx
        // UNKNOWN
        dataOut.writeInt(unknown2);
        // MESSAGE
        dataOut.writeChars(textSent);
        // MESSAGE
        dataOut.write(0x0005); // tlv05
        dataOut.writeChars(/*message*/null); // varies -- Message for FORMAT = 2 or 4
        // UIN
        dataOut.write(null); // xx xx xx xx -- Reverse HEX UIN ex. uin 8083608 - HEX -> 00 7B 58 98 - rev. -> 98 58 7B 00
        // TYPE
        dataOut.write(null); // xx -- Type Message in old protocol
        // FLAGS
        dataOut.write(0x00);
        // MESSAGE
        dataOut.write(null);
        // EMPTY
        dataOut.write(0x0006); // tlv06
        dataOut.writeInt(unknown3);
        return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setReqBosPacket()
   {
      return null ;
   }
  //----------------------------------------------------------------------------
  public byte[] setAddVisiblePacket(String uin) throws IOException
   {
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       short tlvlength = 0;
       // STRLEN
       tlvlength = (short)uin.length() ;
       dataOut.writeShort(tlvlength);
       // UIN
       dataOut.writeChars(uin);
       return  byteOut.toByteArray();
   }
  //----------------------------------------------------------------------------
  public byte[] setRemVisiblePacket(String uin) throws IOException
  {
        ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
        DataOutputStream dataOut=new DataOutputStream(byteOut);
        short tlvlength = 0;
        // STRLEN
        tlvlength = (short)uin.length() ;
        dataOut.writeShort(tlvlength);
        // UIN
        dataOut.writeChars(uin);
        return byteOut.toByteArray();
  }
  //----------------------------------------------------------------------------
  public byte[] setReqListsPacket() throws IOException
    {
        return null ;
    }
  //----------------------------------------------------------------------------
  public byte[] setReqRosterPacket()
    {
        return null ;
    }
  //----------------------------------------------------------------------------
  public byte[] setCheckRosterPacket() throws IOException
  {
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       // TIME
       dataOut.writeInt(0x00000000); // xx xx xx xx
       // SIZE
       dataOut.writeByte(0x00); // xx
       return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setRosterAckPacket()
  {
      return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setAddBuddyPacket(String uin2add,String nick) throws IOException
  {
    //********************** near to complete ***************************
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream() ;
       DataOutputStream dataOut=new DataOutputStream(byteOut) ;
       int len = uin2add.length() ;
       short randomid = 0x0000 ;
       short groupid = this.groupid ;//defualt Group general
       Random r = new Random();
       randomid = (short)r.nextInt() ;
       short type = 0x0000 ;//defualt normal
       int followbyte = 0x0000;
       short tlv0131 = 0x0131;
       short tlvlen ;
       //----------------------------------------------
       dataOut.writeShort(len);
       dataOut.writeBytes(uin2add);
       dataOut.writeShort(groupid);
       dataOut.writeShort(randomid);
       this.setIdtoadd(randomid);
       dataOut.writeShort(type);
       followbyte =  4 + nick.length() ;
       dataOut.writeShort(followbyte);
       dataOut.writeShort(tlv0131);
       dataOut.writeShort(nick.length());
       dataOut.writeBytes(nick);
       return byteOut.toByteArray() ;
       //--------------------------------------------------
  }
  //----------------------------------------------------------------------------
  public byte[] setUpdateGroupPacket(String kind,UserData user)throws IOException{
    //---------------------------near to complete-----------------------------
              String groupname ;
              int len ;
              short tag ;
              short id ;
              short type ;
              short lentlv ;
              short ids ;
              int followingdata ;
              byte[] dataOfAllidInGroup = null;
              byte[] temp ;
              ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
              DataOutputStream dataOut=new DataOutputStream(byteOut);
              groupname  = "General" ;// Group's name(defualt fix)
              len = groupname.length() ;
              tag =  this.groupid ;
              id  =  0x0000 ;
              type = 0x0001 ;
              dataOfAllidInGroup = this.listofids ;

              // STRLEN
              dataOut.writeShort(len) ; // xx xx
              // UIN
              dataOut.writeBytes(groupname);
              // TAG
              dataOut.writeShort(tag); // xx xx
              // ID
              dataOut.writeShort(id);
              // TYPE
              dataOut.writeShort(type);
              // BYTELEN

              if(kind.equals("Add")){
                followingdata = dataOfAllidInGroup.length+2 ;
                dataOut.writeShort(followingdata); // xx xx
                // TLV
                //-------------case add----------------
                temp = Util.copyBytes(dataOfAllidInGroup, 0, 2);
                dataOut.write(temp); // varies
                int lendata = dataOfAllidInGroup.length - 2;
                dataOut.writeShort(lendata);
                temp = Util.copyBytes(dataOfAllidInGroup, 4,dataOfAllidInGroup.length - 4);
                dataOut.write(temp);
                dataOut.writeShort(this.idtoadd);
                //---------------------------------------
              }else if(kind.equals("Remove")){
                followingdata = dataOfAllidInGroup.length-2 ;
                dataOut.writeShort(followingdata); // xx xx
                // TLV
                //-------------case remove-------------
                short id2remove ;
                int posinit = 4 ;
                int finish ;
                ByteArrayOutputStream byteOutTemp=new ByteArrayOutputStream();
                DataOutputStream dataOutTemp=new DataOutputStream(byteOutTemp);

                //---------------------- delete id in group -------------
                id2remove = user.getIdInGroup() ;
                finish =  (dataOfAllidInGroup.length - 4)/2 ;
                for (int i = 0; i < finish ;i++ ) {
                  short tempshort;
                  temp = Util.copyBytes(dataOfAllidInGroup, posinit, 2);
                  tempshort = Util.bytes2Short(temp);

                  if (tempshort != id2remove){
                      dataOutTemp.writeShort(tempshort);
                  }
                  posinit = posinit + 2 ;
                }
               //--------------------------------------------------------
                temp = Util.copyBytes(dataOfAllidInGroup, 0, 2) ;
                dataOut.write(temp); // varies
                int lendata = dataOfAllidInGroup.length - 6 ;
                dataOut.writeShort(lendata) ;
                dataOut.write(byteOutTemp.toByteArray()) ;
            }
            //-------------------------------------
              return byteOut.toByteArray() ;
      }
//----------------------------------------------------------------------------
  public byte[] setDeleteBuddyPacket(UserData user){
              short  groupid       = this.groupid ;//-----------defualt Group general--------
              String nickname      = user.getNickname() ;
              String uin           = user.getUin()   ;
              short  idtoremove    = user.getIdInGroup() ;
              short  type          = 0x0000 ;//------------ default normal type ----
              short  tlv131        = 0x0131 ;
              short  tlv131length  = (short)user.getNickname().length()  ;
              short  uinlength     = (short)user.getUin().length() ;
              int    followingbyte = tlv131length + 4 ;

              ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
              DataOutputStream dataOut = new DataOutputStream(byteOut);
        try{
              dataOut.writeShort(uinlength) ;
              dataOut.writeBytes(uin) ;
              dataOut.writeShort(groupid) ;
              dataOut.writeShort(idtoremove);
              dataOut.writeShort(type) ;
              dataOut.writeShort(followingbyte) ;
              dataOut.writeShort(tlv131) ;
              dataOut.writeShort(tlv131length) ;
              dataOut.writeBytes(nickname) ;
           }
        catch(IOException e){
            System.out.println(e.getMessage());
           }
        return byteOut.toByteArray() ;
  }
  //----------------------------------------------------------------------------
  public byte[] setAddStartPacket()
  {
      return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setAddEndPacket()
  {
      return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setReqAuthPacket(){/*
              String uin = ; // Request UIN
              ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
              DataOutputStream dataOut=new DataOutputStream(byteOut);
              short tlvlength = 0;
              final short unknown = 0x0000;
              // STRLEN
              tlvlength =  (short)uin.length() ;
              dataOut.writeShort(tlvlength) ;
              // UIN
              dataOut.writeChars(uin);
              // STRLEN
              dataOut.write(); // xx xx -- Length of Request
              // MESSAGE
              dataOut.write(); // varies
              // UNKNOWN
              dataOut.writeInt(unknown);
              return byteOut.toByteArray() ;*/
              return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setAuthorizePacket()
  { /*
        String uin = userdata.getUin();
        ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
        DataOutputStream dataOut=new DataOutputStream(byteOut);
        short tlvlength = 0;
        final short unknown = 0x0000;
        // STRLEN
        tlvlength =  (short)uin.length() ;
        dataOut.writeShort(tlvlength) ;
        // UIN
        dataOut.writeChars(uin);
        // AUTHORIZE
        dataOut.write(); // xx -- 00 Decline, 01 Authorize
        // STRLEN
        dataOut.write(); // xx xx -- Length of Reason
        // REASON
        dataOut.write(); // varies
        // UNKNOWN
        dataOut.writeInt(unknown);
        return byteOut.toByteArray() ; */
        return null ;
  }
  //----------------------------------------------------------------------------
  public byte[] setToIcqSrvPacket()
  { /*
        short tlv1  = (byte)0x0001;
        short ICQdata = ;// xx xx
        String uin = userdata.getUin();
        ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
        DataOutputStream dataOut=new DataOutputStream(byteOut);
        // ICQDATA
        dataOut.write(tlv1);
        dataOut.write(ICQdata);
        // LENGTH
        dataOut.write(); // xx xx -- Reverse ex. length = 00 08 - rev. -> 08 00
        // UIN
        dataOut.write(); // xx xx xx xx -- Reverse HEX UIN ex. uin 8083608 - HEX -> 00 7B 58 98 - rev. -> 98 58 7B 00
        // COMMAND
        dataOut.write(); // xx xx
        // SEQUENCE
        dataOut.write(); // xx xx
        // DATA
        dataOut.write(); // varies
        return byteOut.toByteArray() ;*/
        return null ;
   }
  //----------------------------------------------------------------------------
  public byte[] setReqOfflineMsgsPacket() throws IOException
   {
       int uin ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       uin = Integer.parseInt(OwnerDataInfo.getUin()) ;
       dataOut.writeInt(0x0001000a);
       dataOut.writeShort(0x8000);
       dataOut.write(Util.revsorder(uin)); //unknown xx xx xx xx
       dataOut.writeInt(0x3c000200);
       return byteOut.toByteArray() ;
   }
  //----------------------------------------------------------------------------
   public byte[] setReadyPacket() throws IOException{
     ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
     DataOutputStream dataOut=new DataOutputStream(byteOut);
       dataOut.writeInt(0x00010003) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x00130002) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x00020001) ;
       dataOut.writeInt(0x0101047B) ;
       dataOut.writeInt(0x00030001) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x00150001) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x00040001) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x00060001) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x00090001) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x000A0001) ;
       dataOut.writeInt(0x0110047B) ;
       dataOut.writeInt(0x000B0001) ;
       dataOut.writeInt(0x0110047B) ;
     return byteOut.toByteArray() ;
   }
  //----------------------------------------------------------------------------
   public byte[] setAckofflinemsgs()throws IOException{
       int uin ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       uin = Integer.parseInt(OwnerDataInfo.getUin()) ;
       dataOut.writeInt(0x0001000a);
       dataOut.writeShort(0x8000);
       dataOut.write(Util.revsorder(uin)); //unknown xx xx xx xx
       dataOut.writeInt(0x3e000200);
       return byteOut.toByteArray() ;
   }
  //----------------------------------------------------------------------------
   public byte[] setSearchByemail(String email) throws IOException {
       int emaillength ;
       int tlvlength ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       ByteArrayOutputStream byteOuttemp=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       DataOutputStream dataOuttemp=new DataOutputStream(byteOuttemp);
       int uin ;
       dataOuttemp.writeByte(0x00); //fix 00
       uin = Integer.parseInt(OwnerDataInfo.getUin()) ;
       dataOuttemp.write(this.u.revsorder(uin));//uin
       dataOuttemp.writeShort(0xd007);//fix 2000
       dataOuttemp.writeByte(0x02) ; //count of search
       dataOuttemp.writeByte(0x00) ; //fix 00
       dataOuttemp.writeShort(0x7305);//fix 1395
       dataOuttemp.writeShort(0x5e01);//key
       emaillength = email.length() ;
       dataOuttemp.writeByte(emaillength+3); // length
       dataOuttemp.writeByte(0x00);// fix 00
       dataOuttemp.writeByte(emaillength+1); // length - 2
       dataOuttemp.writeByte(0x00);// fix 00
       dataOuttemp.writeBytes(email);//email name is searched ;
       dataOuttemp.writeByte(0x00); //fix 00

       tlvlength = byteOuttemp.toByteArray().length ;
       dataOut.writeShort(0x0001); //tlv1
       dataOut.writeShort(tlvlength+1); //length of tlv1
       dataOut.writeByte(tlvlength-1); // length - 2
       dataOut.write(byteOuttemp.toByteArray());
       return byteOut.toByteArray() ;
   }
  //----------------------------------------------------------------------------
   public byte[] setSearchByPersinf(String nickname,String firstname,String lastname) throws IOException {
       int uin ;
       int tlvlength ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       ByteArrayOutputStream byteOuttemp=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       DataOutputStream dataOuttemp=new DataOutputStream(byteOuttemp);

       dataOuttemp.writeByte(0x00); //fix 00
       uin = Integer.parseInt(OwnerDataInfo.getUin()) ;
       dataOuttemp.write(this.u.revsorder(uin));//uin
       dataOuttemp.writeShort(0xd007);//fix 2000
       dataOuttemp.writeByte(0x02) ; //count of search
       dataOuttemp.writeByte(0x00) ; //fix 00
       dataOuttemp.writeShort(0x5f05);//fix 1375

          if(firstname != null){
            int firstnamelength ;
            dataOuttemp.writeShort(0x4a01);//key
            firstnamelength = firstname.length() ;
            dataOuttemp.writeByte(firstnamelength+3); // length
            dataOuttemp.writeByte(0x00);// fix 00
            dataOuttemp.writeByte(firstnamelength+1); // length - 2
            dataOuttemp.writeByte(0x00);// fix 00
            dataOuttemp.writeBytes(firstname);//lastname is searched ;
            dataOuttemp.writeByte(0x00); //fix 00
           }
          if(lastname != null){
            int lastnamelength ;
            dataOuttemp.writeShort(0x4a01);//key
            lastnamelength = lastname.length() ;
            dataOuttemp.writeByte(lastnamelength+3); // length
            dataOuttemp.writeByte(0x00);// fix 00
            dataOuttemp.writeByte(lastnamelength+1); // length - 2
            dataOuttemp.writeByte(0x00);// fix 00
            dataOuttemp.writeBytes(lastname);//lastname is searched ;
            dataOuttemp.writeByte(0x00); //fix 00
           }
          if(nickname != null){
             int nicknamelength ;
             dataOuttemp.writeShort(0x5401);//key
             nicknamelength = nickname.length() ;
             dataOuttemp.writeByte(nicknamelength+3); // length
             dataOuttemp.writeByte(0x00);// fix 00
             dataOuttemp.writeByte(nicknamelength+1); // length - 2
             dataOuttemp.writeByte(0x00);// fix 00
             dataOuttemp.writeBytes(nickname);//nickname is searched ;
             dataOuttemp.writeByte(0x00); //fix 00
          }
          tlvlength = byteOuttemp.toByteArray().length ;
          dataOut.writeShort(0x0001); //tlv1
          dataOut.writeShort(tlvlength+1); //length of tlv1
          dataOut.writeByte(tlvlength-1); // length - 2
          dataOut.write(byteOuttemp.toByteArray());
       return byteOut.toByteArray() ;
   }
  //----------------------------------------------------------------------------
   public byte[] setSearchByUin(String uin2search) throws IOException {
       int uinlength,uins,tlvlength ;
       ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
       ByteArrayOutputStream byteOuttemp=new ByteArrayOutputStream();
       DataOutputStream dataOut=new DataOutputStream(byteOut);
       DataOutputStream dataOuttemp=new DataOutputStream(byteOuttemp);

       dataOuttemp.writeByte(0x00); //fix 00
       uins = Integer.parseInt(OwnerDataInfo.getUin()) ;
       dataOuttemp.write(this.u.revsorder(uins));//uin
       dataOuttemp.writeShort(0xd007);//fix 2000
       dataOuttemp.writeByte(0x02) ; //count of search
       dataOuttemp.writeByte(0x00) ; //fix 00
       dataOuttemp.writeShort(0x6905);//fix 1385
       dataOuttemp.writeShort(0x3601);//key
       uins = Integer.parseInt(uin2search) ;
       uinlength = this.u.revsorder(uins).length + 1 ;
       dataOuttemp.writeByte(uinlength);
       dataOuttemp.writeByte(0x00); //fix 00
       dataOuttemp.write(this.u.revsorder(uins));//uin

       tlvlength = byteOuttemp.toByteArray().length ;
       dataOut.writeShort(0x0001); //tlv1
       dataOut.writeShort(tlvlength+1); //length of tlv1
       dataOut.writeByte(tlvlength-1); // length - 2
       dataOut.write(byteOuttemp.toByteArray());
       return byteOut.toByteArray() ;
   }
  //-------------------------------------------------------------
   public byte[] setgrantauthPacket(String uin2add) throws IOException {
      ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
      DataOutputStream dataOut=new DataOutputStream(byteOut);
      int len = uin2add.length() ;
      dataOut.writeShort(len);
      dataOut.writeChars(uin2add);
      dataOut.writeInt(0x00000000);
      return byteOut.toByteArray() ;

   }
  //----------------------------------------------------------------------------
  public byte[] setChangeStatuspacket(String stat)throws IOException{
      ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
      DataOutputStream dataOut=new DataOutputStream(byteOut);
      short st = 0x0000;
      short tlv06 = 0x0006 ;
      short lentlv = 0x0004 ;
      short type = 0x2002 ;
      if(stat.equals("Online")){
            st = 0x0000 ;
      }
      else if(stat.equals("Away")){
            st = 0x0001 ;
      }
      else if(stat.equals("N/A")){
            st = 0x0005 ;
      }else if(stat.equals("Free for chat")){
            st = 0x0020;
      }else if(stat.equals("DND")){
            st = 0x0013;
      }else if(stat.equals("Occupied")){
            st = 0x0011;
      }


      dataOut.writeShort(tlv06);
      dataOut.writeShort(lentlv);
      dataOut.writeShort(type);
      dataOut.writeShort(st);
      return byteOut.toByteArray() ;     }
  //-----------------------------------------------------------------------
  public byte[] setSnack1_11(String status) throws IOException{
      ByteArrayOutputStream byteOut= new ByteArrayOutputStream();
      DataOutputStream dataOut= new DataOutputStream(byteOut);
      int type = 0x00000000 ;
       if(status.equals("Online")|| status.equals("Occupied")|| status.equals("Free for chat")|| status.equals("DND")){
          type = 0x00000000 ;
       }else if(status.equals("Away") || status.equals("N/A")){
          type = 0x0000003c ;
       }
      dataOut.writeInt(type);
      return byteOut.toByteArray() ;
  }
  //-------------------------------------------------------------------------
  public byte[] setMetaReqInfoPacket(String uin2search) throws IOException{
    int uinlength,uins,tlvlength ;
     ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
     ByteArrayOutputStream byteOuttemp=new ByteArrayOutputStream();
     DataOutputStream dataOut=new DataOutputStream(byteOut);
     DataOutputStream dataOuttemp=new DataOutputStream(byteOuttemp);

     dataOuttemp.writeShort(0x0e00); //fix 0e00
     uins = Integer.parseInt(OwnerDataInfo.getUin()) ;
     dataOuttemp.write(this.u.revsorder(uins));//uin
     dataOuttemp.writeShort(0xd007);//fix 2000
     dataOuttemp.writeByte(0x1e) ; //count of search
     dataOuttemp.writeByte(0x00) ; //fix 00
     dataOuttemp.writeShort(0xb204);//fix 1202
     uins = Integer.parseInt(uin2search) ;
     dataOuttemp.write(this.u.revsorder(uins));//uin2search

     tlvlength = byteOuttemp.toByteArray().length ;
     dataOut.writeShort(0x0001); //tlv1
     dataOut.writeShort(tlvlength); //length of tlv1
     dataOut.write(byteOuttemp.toByteArray() );

     return byteOut.toByteArray() ;
  }
  //-------------------------------------------------------------------------
  public byte[] setRegisteruserPacket(String password) throws IOException{
     ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
     DataOutputStream dataOut = new DataOutputStream(byteOut);
       int randomid ;
       Random r = new Random();
       randomid = (short)r.nextInt() ;
     int requin  = 0x0001    ;
     int empty   = 0x00000000    ;
     int unknown1 = 0x28000300   ;
     int empty1  = 0x00000000    ;
     int empty2  = 0x00000000    ;
     int seen1   = 0x0000    ;
     int seen2   = 0x0000    ;
     int empty3  = 0x00000000    ;
     int empty4  = 0x00000000    ;
     int empty5  = 0x00000000    ;
     int empty6  = 0x00000000    ;
     int seen3   = 0x0000    ;
     int empty7  = 0x0000    ;
     int seen4   = 0x1902        ;
     int passwdlength = password.length() ;
     int followingbyte = 50+passwdlength+1 ;
     byte[] data = password.getBytes() ;
     //-------------------------- data out------------------------------
     dataOut.writeShort(requin) ;
     dataOut.writeShort(followingbyte);
     dataOut.writeInt(empty) ;
     dataOut.writeInt(unknown1) ;
     dataOut.writeInt(empty1) ;
     dataOut.writeInt(empty2) ;
     dataOut.writeShort(randomid);
     dataOut.writeShort(seen1)  ;
     dataOut.writeShort(randomid);
     dataOut.writeShort(seen2)  ;
     dataOut.writeInt(empty3) ;
     dataOut.writeInt(empty4) ;
     dataOut.writeInt(empty5) ;
     dataOut.writeInt(empty6) ;
     dataOut.writeByte(passwdlength+1);//----------include 00 Therefor,Add 1-----------
     dataOut.writeByte(00);//---------fix 00 ---------------------
     dataOut.write(data) ;
     dataOut.writeByte(00);//---------fix 00 ---------------------
     dataOut.writeShort(randomid);
     dataOut.writeShort(seen3) ;
     dataOut.writeShort(empty7) ;
     dataOut.writeShort(seen4) ;
     return byteOut.toByteArray() ;
  }
  //-------------------------------------------------------------------------
  public byte[] setMetaSetGeneral(String nickname,String first,String last,String email,String city,String state,String hphone,String hfax,String street,String cellular,String zip,String country)throws IOException{
           int uinlength,uins,tlvlength ;
           ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
           ByteArrayOutputStream byteOuttemp=new ByteArrayOutputStream();
           DataOutputStream dataOut=new DataOutputStream(byteOut);
           DataOutputStream dataOuttemp=new DataOutputStream(byteOuttemp);


           uins = Integer.parseInt(OwnerDataInfo.getUin()) ;
           dataOuttemp.write(this.u.revsorder(uins));//uin
           dataOuttemp.writeShort(0xd007);//fix 2000
           dataOuttemp.writeByte(0x1e) ; //count of search
           dataOuttemp.writeByte(0x00) ; //fix 00
           dataOuttemp.writeShort(0xea03);//fix 1002
          //----------------- nick-----------------------
          if(nickname.equals("")){
               dataOuttemp.writeByte(00);
          }else{
               int nicklength = nickname.length()+1 ;
               dataOuttemp.writeByte(nicklength);
               dataOuttemp.writeByte(00);
               dataOuttemp.writeBytes(nickname);
          }
          //---------------------------------------------
          //----------------- first-----------------------
          if(first.equals("")){
              dataOuttemp.writeByte(00);
              dataOuttemp.writeByte(00);
         }else{
              dataOuttemp.writeByte(00);
              int firstlength = first.length()+1 ;
              dataOuttemp.writeByte(firstlength);
              dataOuttemp.writeByte(00);
              dataOuttemp.writeBytes(first);
         }
        //------------------ last ---------------------
        if(last.equals("")){
             dataOuttemp.writeByte(00);
             dataOuttemp.writeByte(00);
        }else{
             dataOuttemp.writeByte(00);
             int lastlength = last.length()+1 ;
             dataOuttemp.writeByte(lastlength);
             dataOuttemp.writeByte(00);
             dataOuttemp.writeBytes(last);
        }
      //------------------ email ---------------------
       if(email.equals("")){
            dataOuttemp.writeByte(00);
            dataOuttemp.writeByte(00);
       }else{
            dataOuttemp.writeByte(00);
            int emaillength = email.length()+1 ;
            dataOuttemp.writeByte(emaillength);
            dataOuttemp.writeByte(00);
            dataOuttemp.writeBytes(email);
       }
       //------------------ city ---------------------
       if(city.equals("")){
            dataOuttemp.writeByte(00);
            dataOuttemp.writeByte(00);
       }else{
            dataOuttemp.writeByte(00);
            int citylength = email.length()+1 ;
            dataOuttemp.writeByte(citylength);
            dataOuttemp.writeByte(00);
            dataOuttemp.writeBytes(city);
       }
       //------------------ state ---------------------
       if(state.equals("")){
            dataOuttemp.writeByte(00);
            dataOuttemp.writeByte(00);
       }else{
            dataOuttemp.writeByte(00);
            int statelength = state.length()+1 ;
            dataOuttemp.writeByte(statelength);
            dataOuttemp.writeByte(00);
            dataOuttemp.writeBytes(state);
       }
       //------------------ hphone ---------------------
      if(hphone.equals("")){
           dataOuttemp.writeByte(00);
           dataOuttemp.writeByte(00);
      }else{
           dataOuttemp.writeByte(00);
           int hphonelength = hphone.length()+1 ;
           dataOuttemp.writeByte(hphonelength);
           dataOuttemp.writeByte(00);
           dataOuttemp.writeBytes(hphone);
      }
      //------------------ hfax ---------------------
      if(hfax.equals("")){
           dataOuttemp.writeByte(00);
           dataOuttemp.writeByte(00);
      }else{
           dataOuttemp.writeByte(00);
           int hfaxlength = hfax.length()+1 ;
           dataOuttemp.writeByte(hfaxlength);
           dataOuttemp.writeByte(00);
           dataOuttemp.writeBytes(hfax);
      }
      //------------------ street ---------------------
      if(street.equals("")){
           dataOuttemp.writeByte(00);
           dataOuttemp.writeByte(00);
      }else{
           dataOuttemp.writeByte(00);
           int streetlength = street.length()+1 ;
           dataOuttemp.writeByte(streetlength);
           dataOuttemp.writeByte(00);
           dataOuttemp.writeBytes(street);
      }
      //------------------ cellular ---------------------
      if(cellular.equals("")){
           dataOuttemp.writeByte(00);
           dataOuttemp.writeByte(00);
      }else{
           dataOuttemp.writeByte(00);
           int cellularlength = cellular.length()+1 ;
           dataOuttemp.writeByte(cellularlength);
           dataOuttemp.writeByte(00);
           dataOuttemp.writeBytes(street);
      }
      //------------------ zip ---------------------
      if(zip.equals("")){
           dataOuttemp.writeByte(00);
           dataOuttemp.writeByte(00);
      }else{
           dataOuttemp.writeByte(00);
           int ziplength = zip.length()+1 ;
           dataOuttemp.writeByte(ziplength);
           dataOuttemp.writeByte(00);
           dataOuttemp.writeBytes(zip);
      }
      //------------------ country code ---------------------
      if(country.equals("")){
           dataOuttemp.writeByte(00);
           dataOuttemp.writeShort(00);
      }else{
           dataOuttemp.writeByte(00);
           dataOuttemp.writeShort(66);
      }
      //------------------ time zone ---------------------
           dataOuttemp.writeByte(10);
      //------------------ publish -----------------------
           dataOuttemp.writeByte(00);
      //------------------------------------------------
           tlvlength = byteOuttemp.toByteArray().length ;
           dataOut.writeShort(0x0001); //tlv1
           dataOut.writeShort(tlvlength+2); //length of tlv1
           dataOut.writeByte(tlvlength)  ;
           dataOut.writeByte(00)  ;
           dataOut.write(byteOuttemp.toByteArray() );

           return byteOut.toByteArray() ;
  }
  //-------------------------------------------------------------------------
  public byte[] setMetaSetMore(String sex,String age,String day,String month,String year)throws IOException{
           int uinlength,uins,tlvlength,intage,intyear,intmonth,intday ;
           ByteArrayOutputStream byteOut=new ByteArrayOutputStream();
           ByteArrayOutputStream byteOuttemp=new ByteArrayOutputStream();
           DataOutputStream dataOut=new DataOutputStream(byteOut);
           DataOutputStream dataOuttemp=new DataOutputStream(byteOuttemp);


           uins = Integer.parseInt(OwnerDataInfo.getUin()) ;
           dataOuttemp.write(this.u.revsorder(uins));//uin
           dataOuttemp.writeShort(0xd007);//fix 2000
           dataOuttemp.writeByte(0x1e) ; //count of search
           dataOuttemp.writeByte(0x00) ; //fix 00
           dataOuttemp.writeShort(0xfd03);//fix 1021

           //--------------------age----------------------------------
           intage = Integer.parseInt(age) ;
           dataOuttemp.writeByte(intage) ;
           dataOuttemp.writeByte(00) ;
           //--------------------sex----------------------------------
           if(sex.equals("Male")){
                dataOuttemp.writeByte(02) ;
           }else if(sex.equals("Female")){
                dataOuttemp.writeByte(01) ;
           }else {
                dataOuttemp.writeByte(00) ;
           }
           //---------------------home page-------------------------
           dataOuttemp.writeShort(0000);
           //--------- code here------------------------------------
           //--------------------year-------------------------------
           intyear = Integer.parseInt(year) ;
           dataOuttemp.writeShort(intyear) ;
           //--------------------month-------------------------------
           intmonth = Integer.parseInt(month) ;
           dataOuttemp.writeByte(intmonth) ;
           //--------------------day-------------------------------
           intday = Integer.parseInt(day) ;
           dataOuttemp.writeByte(intday) ;
           //--------------------lang1--------------------------------
           dataOuttemp.writeByte(00) ;
           //--------------------lang2--------------------------------
           dataOuttemp.writeByte(00) ;
           //--------------------lang3--------------------------------
           dataOuttemp.writeByte(00) ;

      //------------------------------------------------
           tlvlength = byteOuttemp.toByteArray().length ;
           dataOut.writeShort(0x0001); //tlv1
           dataOut.writeShort(tlvlength+2); //length of tlv1
           dataOut.writeByte(tlvlength)  ;
           dataOut.writeByte(00)  ;
           dataOut.write(byteOuttemp.toByteArray() );

           return byteOut.toByteArray() ;
  }
  //-------------------------------------------------------------------------
  public ClientToServerCMD() {
  }
  //-------------------------------------------------------------------------
}