package ui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class RegisterPage extends JFrame {
  private ServerConnect sconnect ;
  LogonPage logonPage;
  RegisterSuccess registerSuccess;
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JLabel jLabel6 = new JLabel();
  JTextField jTextField3 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JComboBox jComboBox1 = new JComboBox();
  JLabel jLabel8 = new JLabel();
  JTextField jTextField4 = new JTextField();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JComboBox jComboBox2 = new JComboBox();
  JLabel jLabel11 = new JLabel();
  JComboBox jComboBox3 = new JComboBox();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JTextField jTextField6 = new JTextField();
  JLabel jLabel14 = new JLabel();
  JComboBox jComboBox4 = new JComboBox();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  JLabel jLabel19 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JPasswordField jPasswordField2 = new JPasswordField();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JComboBox jComboBox5 = new JComboBox();

  //Construct the frame
  public RegisterPage() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    this.sconnect = sconnect ;
    this.logonPage = new LogonPage() ;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(RegisterPage.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setResizable(false);
    this.setSize(new Dimension(400, 415));
    this.setTitle("Register a new user");
    jLabel1.setBorder(BorderFactory.createEtchedBorder());
    jLabel1.setBounds(new Rectangle(5, 5, 380, 380));
    jLabel2.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel2.setText("Enter details about yourself");
    jLabel2.setBounds(new Rectangle(15, 20, 155, 20));
    jLabel3.setBorder(BorderFactory.createEtchedBorder());
    jLabel3.setBounds(new Rectangle(15, 45, 360, 170));
    jLabel4.setText("First Name");
    jLabel4.setBounds(new Rectangle(25, 60, 65, 20));
    jLabel5.setText("Last Name");
    jLabel5.setBounds(new Rectangle(200, 60, 65, 20));
    jLabel6.setText("Nickname");
    jLabel6.setBounds(new Rectangle(25, 90, 65, 20));
    jLabel7.setText("Gender");
    jLabel7.setBounds(new Rectangle(200, 90, 65, 20));
    jComboBox1.addItem("Not Specified");
    jComboBox1.addItem("Male");
    jComboBox1.addItem("Female");
    jComboBox1.setSelectedItem("Not Specified");
    jComboBox1.setBounds(new Rectangle(265, 90, 100, 20));
    jComboBox2.addItem("");
    jComboBox2.addItem("01");
    jComboBox2.addItem("02");
    jComboBox2.addItem("03");
    jComboBox2.addItem("04");
    jComboBox2.addItem("05");
    jComboBox2.addItem("06");
    jComboBox2.addItem("07");
    jComboBox2.addItem("08");
    jComboBox2.addItem("09");
    jComboBox2.addItem("10");
    jComboBox2.addItem("11");
    jComboBox2.addItem("12");
    jComboBox2.addItem("13");
    jComboBox2.addItem("14");
    jComboBox2.addItem("15");
    jComboBox2.addItem("16");
    jComboBox2.addItem("17");
    jComboBox2.addItem("18");
    jComboBox2.addItem("19");
    jComboBox2.addItem("20");
    jComboBox2.addItem("21");
    jComboBox2.addItem("22");
    jComboBox2.addItem("23");
    jComboBox2.addItem("24");
    jComboBox2.addItem("25");
    jComboBox2.addItem("26");
    jComboBox2.addItem("27");
    jComboBox2.addItem("28");
    jComboBox2.addItem("29");
    jComboBox2.addItem("30");
    jComboBox2.addItem("31");
    jComboBox3.addItem("");
    jComboBox3.addItem("January");
    jComboBox3.addItem("February");
    jComboBox3.addItem("March");
    jComboBox3.addItem("April");
    jComboBox3.addItem("May");
    jComboBox3.addItem("June");
    jComboBox3.addItem("July");
    jComboBox3.addItem("August");
    jComboBox3.addItem("September");
    jComboBox3.addItem("October");
    jComboBox3.addItem("November");
    jComboBox3.addItem("December");
    jComboBox4.addItem("");
    jComboBox4.addItem("1900");
    jComboBox4.addItem("1901");
    jComboBox4.addItem("1902");
    jComboBox4.addItem("1903");
    jComboBox4.addItem("1904");
    jComboBox4.addItem("1905");
    jComboBox4.addItem("1906");
    jComboBox4.addItem("1907");
    jComboBox4.addItem("1908");
    jComboBox4.addItem("1909");
    jComboBox4.addItem("1910");
    jComboBox4.addItem("1911");
    jComboBox4.addItem("1912");
    jComboBox4.addItem("1913");
    jComboBox4.addItem("1914");
    jComboBox4.addItem("1915");
    jComboBox4.addItem("1916");
    jComboBox4.addItem("1917");
    jComboBox4.addItem("1918");
    jComboBox4.addItem("1919");
    jComboBox4.addItem("1920");
    jComboBox4.addItem("1921");
    jComboBox4.addItem("1922");
    jComboBox4.addItem("1923");
    jComboBox4.addItem("1924");
    jComboBox4.addItem("1925");
    jComboBox4.addItem("1926");
    jComboBox4.addItem("1927");
    jComboBox4.addItem("1928");
    jComboBox4.addItem("1929");
    jComboBox4.addItem("1930");
    jComboBox4.addItem("1931");
    jComboBox4.addItem("1932");
    jComboBox4.addItem("1933");
    jComboBox4.addItem("1934");
    jComboBox4.addItem("1935");
    jComboBox4.addItem("1936");
    jComboBox4.addItem("1937");
    jComboBox4.addItem("1938");
    jComboBox4.addItem("1939");
    jComboBox4.addItem("1940");
    jComboBox4.addItem("1941");
    jComboBox4.addItem("1942");
    jComboBox4.addItem("1943");
    jComboBox4.addItem("1944");
    jComboBox4.addItem("1945");
    jComboBox4.addItem("1946");
    jComboBox4.addItem("1947");
    jComboBox4.addItem("1948");
    jComboBox4.addItem("1949");
    jComboBox4.addItem("1950");
    jComboBox4.addItem("1951");
    jComboBox4.addItem("1952");
    jComboBox4.addItem("1953");
    jComboBox4.addItem("1954");
    jComboBox4.addItem("1955");
    jComboBox4.addItem("1956");
    jComboBox4.addItem("1957");
    jComboBox4.addItem("1958");
    jComboBox4.addItem("1959");
    jComboBox4.addItem("1960");
    jComboBox4.addItem("1961");
    jComboBox4.addItem("1962");
    jComboBox4.addItem("1963");
    jComboBox4.addItem("1964");
    jComboBox4.addItem("1965");
    jComboBox4.addItem("1966");
    jComboBox4.addItem("1967");
    jComboBox4.addItem("1968");
    jComboBox4.addItem("1969");
    jComboBox4.addItem("1970");
    jComboBox4.addItem("1971");
    jComboBox4.addItem("1972");
    jComboBox4.addItem("1973");
    jComboBox4.addItem("1974");
    jComboBox4.addItem("1975");
    jComboBox4.addItem("1976");
    jComboBox4.addItem("1977");
    jComboBox4.addItem("1978");
    jComboBox4.addItem("1979");
    jComboBox4.addItem("1980");
    jComboBox4.addItem("1981");
    jComboBox4.addItem("1982");
    jComboBox4.addItem("1983");
    jComboBox4.addItem("1984");
    jComboBox4.addItem("1985");
    jComboBox4.addItem("1986");
    jComboBox4.addItem("1987");
    jComboBox4.addItem("1988");
    jComboBox4.addItem("1989");
    jComboBox4.addItem("1990");
    jComboBox4.addItem("1991");
    jComboBox4.addItem("1992");
    jComboBox4.addItem("1993");
    jComboBox4.addItem("1994");
    jComboBox4.addItem("1995");
    jComboBox4.addItem("1996");
    jComboBox4.addItem("1997");
    jComboBox4.addItem("1998");
    jComboBox4.addItem("1999");
    jComboBox4.addItem("2000");
    jComboBox4.addItem("2001");
    jComboBox4.addItem("2002");
    jComboBox5.addItem("");
    jComboBox5.addItem("Thailand");
    jLabel8.setText("E-mail address");
    jLabel8.setBounds(new Rectangle(25, 120, 90, 20));
    jLabel9.setText("Birthdate");
    jLabel9.setBounds(new Rectangle(25, 150, 55, 20));
    jLabel10.setFont(new java.awt.Font("Dialog", 2, 12));
    jLabel10.setText("Day :");
    jLabel10.setBounds(new Rectangle(85, 150, 30, 20));
    jLabel11.setFont(new java.awt.Font("Dialog", 2, 12));
    jLabel11.setText(" Month :");
    jLabel11.setBounds(new Rectangle(152, 150, 45, 20));
    jLabel12.setFont(new java.awt.Font("Dialog", 2, 12));
    jLabel12.setText("Year :");
    jLabel12.setBounds(new Rectangle(281, 150, 35, 20));
    jLabel13.setText("Your City");
    jLabel13.setBounds(new Rectangle(25, 180, 65, 20));
    jLabel14.setText("Country");
    jLabel14.setBounds(new Rectangle(200, 180, 65, 20));
    jLabel15.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel15.setText("Enter your password");
    jLabel15.setBounds(new Rectangle(15, 225, 120, 20));
    jLabel16.setFont(new java.awt.Font("Dialog", 1, 12));
    jLabel16.setForeground(Color.red);
    jLabel16.setText("(Required)");
    jLabel16.setBounds(new Rectangle(135, 225, 59, 20));
    jLabel17.setBorder(BorderFactory.createEtchedBorder());
    jLabel17.setBounds(new Rectangle(15, 250, 360, 80));
    jLabel18.setText("                Password :");
    jLabel18.setBounds(new Rectangle(65, 265, 110, 20));
    jLabel19.setText("Confirm Password :");
    jLabel19.setBounds(new Rectangle(65, 295, 110, 20));
    jButton1.setBounds(new Rectangle(55, 340, 100, 25));
    jButton1.setFont(new java.awt.Font("Dialog", 1, 12));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(165, 340, 80, 25));
    jButton2.setText("Clear");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setBounds(new Rectangle(255, 340, 80, 25));
    jButton3.setText("Cancel");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jComboBox2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        CheckDate(e);
      }
    });
    jComboBox3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        CheckDate(e);
      }
    });
    jComboBox4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        CheckDate(e);
      }
    });
    jPasswordField2.setBounds(new Rectangle(180, 295, 140, 20));
    jPasswordField1.setBounds(new Rectangle(180, 265, 140, 20));
    jComboBox5.setBounds(new Rectangle(265, 180, 100, 20));
    jTextField6.setBounds(new Rectangle(90, 180, 100, 20));
    jComboBox4.setBounds(new Rectangle(315, 150, 50, 20));
    jComboBox3.setBounds(new Rectangle(197, 150, 84, 20));
    jComboBox2.setBounds(new Rectangle(115, 150, 37, 20));
    jTextField4.setBounds(new Rectangle(115, 120, 200, 20));
    jTextField3.setBounds(new Rectangle(90, 90, 100, 20));
    jTextField2.setBounds(new Rectangle(265, 60, 100, 20));
    jTextField1.setBounds(new Rectangle(90, 60, 100, 20));
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jComboBox2, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jComboBox3, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jComboBox4, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jLabel16, null);
    contentPane.add(jLabel17, null);
    contentPane.add(jLabel18, null);
    contentPane.add(jLabel19, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jPasswordField2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jComboBox5, null);
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      logonPage = new LogonPage();
      logonPage.show();
      dispose();
    }
  }

  void jButton3_actionPerformed(ActionEvent e) {
    logonPage = new LogonPage();
    logonPage.show();
    dispose();
  }

  void jButton2_actionPerformed(ActionEvent e) {
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField6.setText("");
    jPasswordField1.setText("");
    jPasswordField2.setText("");
    jComboBox1.setSelectedItem("Not Specified");
    jComboBox2.setSelectedItem("");
    jComboBox3.setSelectedItem("");
    jComboBox4.setSelectedItem("");
    jComboBox4.setSelectedItem("");
  }

  void CheckDate(ActionEvent e) {
    int day = jComboBox2.getSelectedIndex();
    int month = jComboBox3.getSelectedIndex();
    int year = jComboBox4.getSelectedIndex();
    int qyear = year % 4;
    if ((month != 0)||(year != 0))
    {
      if (month==2)
      {
        if (qyear==1)
        {
          if (day > 28)
          {
            jComboBox2.setSelectedIndex(0);
          }
        }
        else
        {
          if (day > 29)
          {
            jComboBox2.setSelectedIndex(0);
          }
        }
      }
      else if ((month==4)||(month==6)||(month==9)||(month==11))
      {
        if (day > 30)
        {
          jComboBox2.setSelectedIndex(0);
        }
      }
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    char[] pwd1 = jPasswordField1.getPassword() ;
    char[] pwd2 = jPasswordField2.getPassword() ;
    String result ;
    String title  ;
    String passwd1 = new String(pwd1) ;
    String passwd2 = new String(pwd2) ;
  if ((!passwd1.equals(""))&&(!passwd2.equals(""))&&(passwd1.equals(passwd2)))
  {
        //-------------------------------------------------------------------
        String firstname = jTextField1.getText();
        String lastname  = jTextField2.getText();
        String nickname  = jTextField3.getText();
        String email     = jTextField4.getText();
        String yourcity  = jTextField6.getText();
        String gender    = jComboBox1.getSelectedItem().toString() ;
        String birthday  = jComboBox2.getSelectedItem().toString() ;
        String birthmonth =  jComboBox3.getSelectedItem().toString() ;
        String birthyear =    jComboBox4.getSelectedItem().toString() ;
        String country   =   jComboBox5.getSelectedItem().toString()  ;
       //-----------------------------------------------------------------
       OwnerDataInfo.setFirstname(firstname);
       OwnerDataInfo.setLastname(lastname);
       OwnerDataInfo.setNickname(nickname);
       OwnerDataInfo.setEmail(email);
       OwnerDataInfo.setCity(yourcity);
       OwnerDataInfo.setGender(gender);
       OwnerDataInfo.setDay(birthday);
       OwnerDataInfo.setMonth(birthmonth);
       OwnerDataInfo.setYear(birthyear);
       OwnerDataInfo.setCountry(country);

       //-----------------------------------------------------------------
       try {
         this.sconnect = new ServerConnect(5190, "login.icq.com", "00000000",passwd2,"RegisterNewUser",this.logonPage);
         this.sconnect.Login(this.sconnect.getServername(), 5190);
        // this.logonPage.setServerConnect(this.sconnect) ;
       }
       catch (Exception ex) {}
       //-------------------------------------------------------
  }
  else
  {
  if ((passwd1.equals(""))||(passwd2.equals("")))
    {
      jPasswordField1.setText("");
      jPasswordField2.setText("");
      title =  "Register A New User Fail" ;
      result  =  "Please enter Password and Confirm Password." ;
    }
    else
    {
      jPasswordField1.setText("");
      jPasswordField2.setText("");
      title =  "Register A New User Fail" ;
      result  =  "Your Confirm Password does not match." ;
    }
    this.logonPage.messageBox = new  MessageBox(title,result);
    this.logonPage.messageBox.show() ;
  }
 }
}