package ui;
import java.security.* ;
import javax.crypto.spec.* ;
import java.math.* ;
import java.security.spec.* ;
import javax.crypto.* ;
import java.security.cert.* ;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;
import java.math.*;
public class Test {
  Vector test = new Vector();
//------------------------------------------------------------------
  public Test() {

 }
//----------------------------------------------------------
 public static void main(String[] arg){
    ServerConnect sconnect = new ServerConnect() ;
    UserData user = new UserData();
    //FileChooser a = new FileChooser(sconnect,user);
    //a.show();
    //RequestFilePage a = new RequestFilePage("aaaaaaaaaaaaa",sconnect,user,"ggggggg");
    //a.show();
    /*File file ;
    Certificate a = new Certificate();
    java.security.cert.Certificate  cer1,cer2,cer3 ;
    java.security.cert.Certificate[] certs = new java.security.cert.Certificate[10];
    file = new File("./certificate/certificatenut.cer") ;
    cer1 = a.importCertificate(file) ;
    file = new File("./certificate/verrisignclass1.cer") ;
    cer2 = a.importCertificate(file) ;
    file = new File("./certificate/caverisign.cer") ;
    cer3 = a.importCertificate(file) ;
    //System.out.println(cer.toString());
    certs[0] = cer3 ;
    certs[1] = cer2 ;
    certs[2] = cer1 ;
    a.validationcheckcerPath(a.createCertPath(certs));*/
 }
//-----------------------------------------------------------
}