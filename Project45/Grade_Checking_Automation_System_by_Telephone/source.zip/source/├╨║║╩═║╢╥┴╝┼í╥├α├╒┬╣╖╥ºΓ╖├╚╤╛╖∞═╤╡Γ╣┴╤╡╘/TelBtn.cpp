// TelBtn.cpp: implementation of the CTelBtn class.
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "A002.h"
#include "TelBtn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CTelBtn::CTelBtn(){
	q="";
	cnt=0;
}
CTelBtn::~CTelBtn(){}
void CTelBtn::Type(char c){
	cnt++;
	q=q+c;
}
void CTelBtn::Reset(){
	q="";
	cnt=0;
}
char CTelBtn::Fst(){
	char c;
	if(IsEmpty()){
		c=q.GetAt(0);
		q=q.Mid(1);
		cnt--;
	}else	c='.';
	return c;
}
bool CTelBtn::IsEmpty(){
	if(cnt)	return true;
	else	return false;
}
