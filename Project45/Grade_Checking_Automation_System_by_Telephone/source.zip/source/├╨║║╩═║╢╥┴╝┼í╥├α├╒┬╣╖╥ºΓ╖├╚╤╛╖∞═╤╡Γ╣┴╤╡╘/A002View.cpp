// A002View.cpp : implementation of the CA002View class
//

#include "stdafx.h"
#include "A002.h"
#include "TelBtn.h"
#include <afx.h>
#include <stdlib.h>
#include <sapi.h>
#include "sphelper.h"

#include "StudentSet.h"
#include "A002Doc.h"
#include "A002View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CA002View
IMPLEMENT_DYNCREATE(CA002View, CRecordView)
BEGIN_MESSAGE_MAP(CA002View, CRecordView)
	//{{AFX_MSG_MAP(CA002View)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_BN_CLICKED(IDC_BUTTON11, OnButton11)
	ON_BN_CLICKED(IDC_BUTTON12, OnButton12)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRecordView::OnFilePrintPreview)
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CA002View construction/destruction
CA002View::CA002View(): CRecordView(CA002View::IDD){
	//{{AFX_DATA_INIT(CA002View)
	m_pSet = NULL;
	m_Edit1 = _T("");
	m_Edit2 = _T("");
	m_Edit3 = _T("");
	//}}AFX_DATA_INIT
	// TODO: add construction code here
	St=0;
	if (FAILED(CoInitialize(NULL))){
		AfxMessageBox("Error to intiliaze COM");
		return;
	}
}
CA002View::~CA002View(){
	CoUninitialize();
}
void CA002View::DoDataExchange(CDataExchange* pDX){
	CRecordView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CA002View)
	DDX_Text(pDX, IDC_EDIT1, m_Edit1);
	DDX_Text(pDX, IDC_EDIT2, m_Edit2);
	DDX_Text(pDX, IDC_EDIT3, m_Edit3);
	//}}AFX_DATA_MAP
}
BOOL CA002View::PreCreateWindow(CREATESTRUCT& cs){
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	return CRecordView::PreCreateWindow(cs);
}
void CA002View::OnInitialUpdate(){
	m_pSet = &GetDocument()->m_studentSet;
	//m_pSubjectSet=&m_SubjectSet;
	//m_pGradeSet=&m_GradeSet;
	CRecordView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
	State();
	m_GradeSet.Open();
}
/////////////////////////////////////////////////////////////////////////////
// CA002View printing
BOOL CA002View::OnPreparePrinting(CPrintInfo* pInfo){
	// default preparation
	return DoPreparePrinting(pInfo);
}
void CA002View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/){
	// TODO: add extra initialization before printing
}
void CA002View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/){
	// TODO: add cleanup after printing
}
/////////////////////////////////////////////////////////////////////////////
// CA002View diagnostics
#ifdef _DEBUG
void CA002View::AssertValid() const{
	CRecordView::AssertValid();
}
void CA002View::Dump(CDumpContext& dc) const{
	CRecordView::Dump(dc);
}
CA002Doc* CA002View::GetDocument(){ // non-debug version is inline
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CA002Doc)));
	return (CA002Doc*)m_pDocument;
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CA002View database support
CRecordset* CA002View::OnGetRecordset(){
	return m_pSet;
}
/////////////////////////////////////////////////////////////////////////////
// CA002View message handlers
void CA002View::OnButton1(){
	// TODO: Add your control notification handler code here
	Input('1');
}
void CA002View::OnButton2(){
	// TODO: Add your control notification handler code here
	Input('2');
}
void CA002View::OnButton3(){
	// TODO: Add your control notification handler code here
	Input('3');
}
void CA002View::OnButton4(){
	// TODO: Add your control notification handler code here
	Input('4');
}
void CA002View::OnButton5(){
	// TODO: Add your control notification handler code here
	Input('5');
}
void CA002View::OnButton6(){
	// TODO: Add your control notification handler code here
	Input('6');
}
void CA002View::OnButton7(){
	// TODO: Add your control notification handler code here
	Input('7');
}
void CA002View::OnButton8(){
	// TODO: Add your control notification handler code here
	Input('8');
}
void CA002View::OnButton9(){
	// TODO: Add your control notification handler code here
	Input('9');
}
void CA002View::OnButton10(){
	// TODO: Add your control notification handler code here
	Input('*');
}
void CA002View::OnButton11(){
	// TODO: Add your control notification handler code here
	Input('0');
}
void CA002View::OnButton12(){
	// TODO: Add your control notification handler code here
	Input('#');
}

//###############
void CA002View::Speak(CString st){
	ISpVoice *pVoice= NULL;
	HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&pVoice);
	if(SUCCEEDED(hr)){
		CtoW(st,Speech);
		hr = pVoice->Speak(Speech, 0, NULL);
        pVoice->Release();
        pVoice = NULL;
	}
}
void CA002View::Speak(CString st,CString fname){
	CComPtr <ISpVoice>		cpVoice;
	CComPtr <ISpStream>		cpStream;
	CSpStreamFormat			cAudioFmt;
	HRESULT hr = cpVoice.CoCreateInstance(CLSID_SpVoice);
	//Set the audio format
	if(SUCCEEDED(hr)){
		hr = cAudioFmt.AssignFormat(SPSF_48kHz16BitStereo);	
		//Call SPBindToFile, a SAPI helper method,  to bind the audio stream to the file
		if(SUCCEEDED(hr)){
			CtoW(fname,FILE);
			CtoW(st,Speech);
			hr = SPBindToFile(FILE,SPFM_CREATE_ALWAYS,
				&cpStream,&cAudioFmt.FormatId(),cAudioFmt.WaveFormatExPtr());	
			//set the output to cpStream so that the output audio data will be stored in cpStream
			if(SUCCEEDED(hr)){
				hr = cpVoice->SetOutput( cpStream, TRUE );
				//Speak the text "hello world" synchronously
				if(SUCCEEDED(hr)){
					hr = cpVoice->Speak(Speech,SPF_DEFAULT,NULL);	
					//close the stream
					if(SUCCEEDED(hr)){
						hr = cpStream->Close();
						//Release the stream and voice object
					}
				}
			}
		}
		cpStream.Release ();
		cpVoice.Release();
	}
}
void CA002View::CtoW(CString a,WCHAR *w){
	int i,j;
	char *ch;
	i = a.GetLength();
	ch=(char*)malloc(i);
	for (j=i;j>0;j--){
		ch[j-1]=a.GetAt(j-1);
	}
	for(j=0;j<200;j++)w[j]=0;
	mbstowcs(w,ch,i);
/*
	char ch1[200];
	for(j=0;j<200;j++)ch1[j]=' ';
	wcstombs(ch1,Speech,i);
	CString s;
	s.Format("%d",i);
	MessageBox(s);
	MessageBox(ch1);
*/
}
int CA002View::Count(int j,int k){
	switch(k){
	case '0':j=j*10;break;
	case '1':j=j*10+1;break;
	case '2':j=j*10+2;break;
	case '3':j=j*10+3;break;
	case '4':j=j*10+4;break;
	case '5':j=j*10+5;break;
	case '6':j=j*10+6;break;
	case '7':j=j*10+7;break;
	case '8':j=j*10+8;break;
	case '9':j=j*10+9;break;
	}
	return j;
}
/*
State transform
[Start]
	invalid=0;
	thread=0;
	name=0;
	gpa=0;
	gpaterm=0;
	<=hello.wav
[invalid]
	<=ID.wav
	waiting 8 digit
	ID=8 digit
	<=PASS.wav
	waiting 6 digit
	PASS=6 digit
	query for valid from student by ID=,PASS=
	check result if valid
		F:	go to [invalid]
		T:	go to [valid]
[valid]
	ask for speak case
		1: GPA
		2: Term Grades
	<=speakCase.wav
	waiting input for speak case
	check speak case
		1:	go to [GPA]
		2:	go to [term]
[GPA]
	=>name_[thread].wav
	name=1;
	=>GPA_[thread].wav
	gpa=1;
	<=GPAof.wav
	<=name_[thread].wav
	<=result.wav
	<=GPA_[thread].wav
	go to [finish]
[term]
	<=year.wav
	waiting 4 digit
	YEAR = 4 digit
	<=term.wav
	waiting 1 digit
	TERM = 1 digit
	Query for Grades by ID=,Year<,Year= and Term<=
	calculate for GPA until the Year and Term specific
	=>GPAterm_[thread].wav
	gpaterm=0;
	Query for Grades by ID=,Year=,Term=
	count=0;
		<=subject.wav
		=>subject_[thread]_[count].wav
		<=subject_[thread]_[count].wav
		<=result_.wav
		<="result".wav
		MoveNext
	until IsEOF
	<=GPS.wav
	<=GPS_[thread].wav
	<=GPA.wav
	<=GPAterm_[thread].wav
	go to [finish]
[finish]
	ask for more
		1:	yes
		2:	no
	<=more.wav
	go to State 31
	check if more
		1:	go to [valid]
		2:	go to [release]
[release]
	release line
*/
void CA002View::Input(char c){
	int ii;
	Q.Type(c);
	/*
	m_Edit3=Q.q;
	//MessageBox(Q.q);
	//CRecordView::OnInitialUpdate();
	*/
	do{
		ii=St;
		State();
	}while(ii!=St);
}
float CA002View::GPlus(CString a){
	if(a.GetLength()>1)	return 0.5;
	else				return 0;
}
float CA002View::Grade(CString a){
	float b;
	char c;
	c=a.GetAt(0);
	switch (c){
	case 'F':
	case 'f':b=0;break;
	case 'D':
	case 'd':b=1+GPlus(a);break;
	case 'C':
	case 'c':b=2+GPlus(a);break;
	case 'B':
	case 'b':b=3+GPlus(a);break;
	case 'A':
	case 'a':b=4;break;
	default :b=0;
	}
	return b;
}
float CA002View::GPA(){
	int a,b;
	float c;
	a=0;
	c=0;
	do{
		b=m_GradeSet.m_Weight;
		if((b>0)&&(m_GradeSet.m_Grade!="")){
			c+=Grade(m_GradeSet.m_Grade) * b;
			a+=b;
		}
		m_GradeSet.MoveNext();
	}while (m_GradeSet.IsEOF()==0);
	c/=a;
	return c;
}
void CA002View::State(){
	int i;
	CString s,t;
	switch(St){
	case 0://[Start]
		invalid=0;
		thread=0;
		gpa=0;
		gpaterm=0;
		gps=0;
		for(i=0;i<200;i++)Speech[i]=0;
		//hello.wav
		Speak("Hello.");
		//Speak("Welcome to Grade Checking Automation by Telephone");
		St++;
		//break;
	case 1://[invalid]
		Q.Reset();
		if(invalid<3){
			//id.wav
			//Speak("Pleas type your eight I D number");
			Speak("I D");
			St++;
		}else	St=17;
		break;
	case 2:
		if(Q.cnt>=8){
			ID=0;
			for(i=0;i<8;i++)ID=Count(ID,Q.Fst());
			Q.Reset();
			//pass.wav
			//Speak("Pleas type your password");
			Speak("Pass");
			St++;
		}
		break;
	case 3:
		if(Q.cnt>=6){
			PASS=0;
			for(i=0;i<6;i++)PASS=Count(PASS,Q.Fst());
			m_pSet->Close();
			s.Format("[id]=%d and [Pass]=%d",ID,PASS);
			m_pSet->m_strFilter=s;
			m_pSet->Open();
			UpdateData(FALSE);
			if(m_pSet->IsEOF()==0){
				St++;
			}else{
				St=1;
				invalid++;
			}
		}
		break;
	case 4://[valid]
		Q.Reset();
		//speakcase.wav
		//Speak("Press 1 for G P A");
		//Speak("Press 2 for Term Grades");
		Speak("G P A 1 Term 2");
		St++;
		break;
	case 5:
		if(Q.cnt>=1){
			i=Count(0,Q.Fst());
			if(i==1)	St++;
			else if(i==2)	St=10;
			else		St=4;
		}
		break;
	case 6://[GPA]
		s.Format("%s %s",m_pSet->m_Fname,m_pSet->m_Lname);
		/*
		t.Format("name_%d.wav",thread);
		Speak(s,t);
		*/
		Speak(s);
		//result.wav
		Speak("G-P-A is");
		s.Format("%.2f",m_pSet->m_GPA);
		/*
		t.Format("GPA_%d.wav",thread);
		Speak(s,t);
		*/
		Speak(s);
		St=15;
		break;
	case 10://[term]
		Q.Reset();
		//year.wav
		Speak("Pleas type Year");
		St++;
		break;
	case 11:
		if(Q.cnt>=4){
			YEAR=0;
			for(i=0;i<6;i++)YEAR=Count(YEAR,Q.Fst());
			Q.Reset();
			//term.wav
			Speak("Pleas type Term");
			St++;
		}
		break;
	case 12:
		if(Q.cnt>=1){
			TERM=Count(0,Q.Fst());
			s.Format("[StdID]=%d and [ID]=[SubID] and ([Year]<%d or ([Year]=%d and [Term]<=%d))",ID,YEAR,YEAR,TERM);
			m_GradeSet.Close();
			m_GradeSet.m_strFilter=s;
			m_GradeSet.Open();
			UpdateData(FALSE);
			if(m_GradeSet.GetRecordCount()!=0){
				gpaterm=GPA();
				/*
				s.Format("%.2f",gpaterm);
				t.Format("GPAterm_%d.wav");
				Speak(s,t);
				*/
				s.Format("[StdID]=%d and [SubID]=[ID] and [Year]=%d and [Term]=%d",ID,YEAR,TERM);
				m_GradeSet.Close();
				m_GradeSet.m_strFilter=s;
				m_GradeSet.Open();
				UpdateData(FALSE);
				if(m_GradeSet.GetRecordCount()!=0){
					i=0;
					do{
						//subject.wav
						Speak("Subject");
						Speak(m_GradeSet.m_Subject);
						//t.Format("subject_%d_%d.wav",thread,i);
						//Speak(m_GradeSet.m_Subject,t);
						i++;
						Speak("Result is");
						//"result".wav
						Speak(m_GradeSet.m_Grade);
						m_GradeSet.MoveNext();
					}while (m_GradeSet.IsEOF()==0);
					m_GradeSet.MoveFirst();
					gps=GPA();
					//GPS.wav
					Speak("G-P-S is");
					s.Format("%.2f",gps);
					/*
					t.Format("GPS_%d.wav",thread);
					Speak(s,t);
					*/
					Speak(s);
					//GPA.wav
					Speak("Your G-P-A is");
					s.Format("%.2f",gpaterm);
					/*
					t.Format("GPAterm_%d.wav",thread);
					Speak(s,t);
					*/
					Speak(s);
					/*
					m_Edit2.Format("%.2f",gps);
					m_Edit1.Format("%.2f",gpaterm);
					*/
					St=15;
				}else St++;
			}else	St++;
		}
		break;
	case 13:
		Speak("No record found");
		St=10;
		break;
	case 15://[finish]
		//more.wav
		Speak("more 1 quit 2");
		St++;
		break;
	case 16:
		if(Q.cnt>=1){
			i=Count(0,Q.Fst());
			if(i==1)	St=4;
			else		St++;
		}
		break;
	case 17://[release]
		//release line
		break;
	default:
		St=17;
		break;
	}
}
/*
    ISpVoice * pVoice = NULL;
    if (FAILED(CoInitialize(NULL))){
        AfxMessageBox("Error to intiliaze COM");
        return;
    }
	HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&pVoice);
    if( SUCCEEDED( hr ) ){
        //hr = pVoice->Speak(L"Hello world", 0, NULL);
		CtoW(m_pSet->m_Fname);
		hr = pVoice->Speak(Speech, 0, NULL);
        // Change pitch
        //hr = pVoice->Speak(L"This sounds normal <pitch middle = '-10'/> but the pitch drops half way through", SPF_IS_XML, NULL );
        pVoice->Release();
        pVoice = NULL;
    }
    CoUninitialize();
*//*
	m_pSet->Close();
	m_pSet->m_strFilter="[id]=42010070";
	m_pSet->Open();
	UpdateData(FALSE);
	m_ID="42010070";
	//MessageBox("asdf");
	CRecordView::OnInitialUpdate();
	UpdateData();
*/
