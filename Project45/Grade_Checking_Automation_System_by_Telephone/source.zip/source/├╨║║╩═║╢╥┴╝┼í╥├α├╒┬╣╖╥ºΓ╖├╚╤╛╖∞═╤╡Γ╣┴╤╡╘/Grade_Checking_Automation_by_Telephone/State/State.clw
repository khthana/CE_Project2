; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CStateDlg
LastTemplate=CRecordset
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "State.h"

ClassCount=5
Class1=CStateApp
Class2=CStateDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_STATE_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Class4=CStudentSet
Class5=CGradeSet
Resource5=IDD_STATE_DIALOG (English (U.S.))

[CLS:CStateApp]
Type=0
HeaderFile=State.h
ImplementationFile=State.cpp
Filter=N
LastObject=CStateApp

[CLS:CStateDlg]
Type=0
HeaderFile=StateDlg.h
ImplementationFile=StateDlg.cpp
Filter=D
LastObject=CStateDlg
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=StateDlg.h
ImplementationFile=StateDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_STATE_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CStateDlg

[DLG:IDD_STATE_DIALOG (English (U.S.))]
Type=1
Class=CStateDlg
ControlCount=1
Control1=IDC_EDIT1,edit,1350631556

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[CLS:CStudentSet]
Type=0
HeaderFile=StudentSet.h
ImplementationFile=StudentSet.cpp
BaseClass=CRecordset
Filter=N
VirtualFilter=r
LastObject=CStudentSet

[DB:CStudentSet]
DB=1
DBType=ODBC
ColumnCount=5
Column1=[ID], 4, 4
Column2=[Fname], -9, 48
Column3=[Lname], -9, 48
Column4=[Pass], 4, 4
Column5=[GPA], 7, 4

[CLS:CGradeSet]
Type=0
HeaderFile=GradeSet.h
ImplementationFile=GradeSet.cpp
BaseClass=CRecordset
Filter=N
VirtualFilter=r

[DB:CGradeSet]
DB=1
DBType=ODBC
ColumnCount=8
Column1=[StdID], 4, 4
Column2=[SubID], 4, 4
Column3=[Year], 5, 2
Column4=[Term], -6, 1
Column5=[Grade], -9, 6
Column6=[ID], 4, 4
Column7=[Subject], -9, 256
Column8=[Weight], -6, 1

