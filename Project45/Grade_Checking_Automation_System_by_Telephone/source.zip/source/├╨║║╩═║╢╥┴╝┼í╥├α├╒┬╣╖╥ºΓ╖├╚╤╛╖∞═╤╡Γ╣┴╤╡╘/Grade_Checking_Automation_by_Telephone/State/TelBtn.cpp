// TelBtn.cpp: implementation of the CTelBtn class.
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "State.h"
#include "TelBtn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CTelBtn::CTelBtn(){
	q="";
	cnt=0;
}
CTelBtn::~CTelBtn(){}
void CTelBtn::Type(char c){
	switch (c){
	case '1':
	case '2':
	case '3':
	case '4':
	case '5':
	case '6':
	case '7':
	case '8':
	case '9':
	case '0':cnt++;q=q+c;break;
	default :break;
	}
}
void CTelBtn::Reset(){
	q="";
	cnt=0;
}
char CTelBtn::Fst(){
	char c;
	if(IsEmpty()){
		c=q.GetAt(0);
		q=q.Mid(1);
		cnt--;
	}else	c='.';
	return c;
}
bool CTelBtn::IsEmpty(){
	if(cnt)	return true;
	else	return false;
}
