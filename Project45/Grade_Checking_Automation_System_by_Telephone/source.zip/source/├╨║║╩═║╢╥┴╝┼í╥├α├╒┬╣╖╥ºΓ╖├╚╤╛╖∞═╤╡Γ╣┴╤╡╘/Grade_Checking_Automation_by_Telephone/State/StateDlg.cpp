// StateDlg.cpp : implementation file
#include "stdafx.h"
#include "State.h"
#include "StateDlg.h"
#include "TelState.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD){
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}
void CAboutDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CStateDlg dialog
CStateDlg::CStateDlg(CWnd* pParent /*=NULL*/):CDialog(CStateDlg::IDD, pParent){
	//{{AFX_DATA_INIT(CStateDlg)
	m_Edit1 = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}
void CStateDlg::DoDataExchange(CDataExchange* pDX){
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CStateDlg)
	DDX_Text(pDX, IDC_EDIT1, m_Edit1);
	//}}AFX_DATA_MAP
}
BEGIN_MESSAGE_MAP(CStateDlg, CDialog)
	//{{AFX_MSG_MAP(CStateDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// CStateDlg message handlers
BOOL CStateDlg::OnInitDialog(){
	int i;
	CDialog::OnInitDialog();
	// Add "About..." menu item to system menu.
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL){
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty()){
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon	
	// TODO: Add extra initialization here
	//SetWindowText("lek");
	for(i=0;i<max_tel;i++)	Tel[i].SetThread(i);
	//TelWnd = FindWindow(NULL,"test");
	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CStateDlg::OnSysCommand(UINT nID, LPARAM lParam){
	if ((nID & 0xFFF0) == IDM_ABOUTBOX){
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}else{
		CDialog::OnSysCommand(nID, lParam);
	}
}
// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CStateDlg::OnPaint(){
	if (IsIconic()){
		CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}else{
		CDialog::OnPaint();
	}
}
// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CStateDlg::OnQueryDragIcon(){
	return (HCURSOR) m_hIcon;
}
LRESULT CStateDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam){
	WPARAM tmp;
	CString s;
	int i;
	// TODO: Add your specialized code here and/or call the base class
	tmp=100;
	if(message == 32769){
		tmp=Tel[lParam].Input(wParam);
		TelWnd = FindWindow(NULL,"Control Modem");
		if(TelWnd!=NULL)	TelWnd->SendMessage(32769,tmp,lParam);
		if(tmp!=100){
			s=GetState(tmp);
			//str[lParam].Format("Line %d\tReceive : %s\r\n\tSend : %s\r\n",lParam,GetState(wParam),s);
			str[lParam].Format("Line %d\tStatus: %s\r\n",lParam,s);
		}
		m_Edit1="";
		for(i=0;i<max_tel;i++)	m_Edit1+=str[i];
		UpdateData(FALSE);
	}
	return CDialog::WindowProc(message, wParam, lParam);
}
CString CStateDlg::GetState(int i){
	switch(i){
	case 35:return "Button #";
	case 42:return "Button *";
	case 48:return "Button 0";
	case 49:return "Button 1";
	case 50:return "Button 2";
	case 51:return "Button 3";
	case 52:return "Button 4";
	case 53:return "Button 5";
	case 54:return "Button 6";
	case 55:return "Button 7";
	case 56:return "Button 8";
	case 57:return "Button 9";
	case 100:return "Line receive";
	case 200:return "Line release";
	case 201:return "Line release request";
	case 300:return "NULL.wav";
	case 310:return "Hello";
	case 320:return "ID request";
	case 321:return "PASS request";
	case 330:return "ask for speak case";
	case 340:return "Ask for more";
	case 350:return "GPA of";
	case 351:return "Name of user";
	case 352:return "User GPA";
	case 360:return "Year request";
	case 361:return "Term request";
	case 362:return "Subject";
	case 363:return "Subject name";
	case 364:return "Result is";
	case 366:return "GPS";
	case 368:return "GPA";
	case 370:return "No record";
	case 380:return "0";
	case 381:return "1";
	case 382:return "2";
	case 383:return "3";
	case 384:return "4";
	case 385:return "5";
	case 386:return "6";
	case 387:return "7";
	case 388:return "8";
	case 389:return "9";
	case 390:return "Dot";
	case 399:return "A";
	case 398:return "B+";
	case 397:return "B";
	case 396:return "C+";
	case 395:return "C";
	case 394:return "D+";
	case 393:return "D";
	case 392:return "F";
	case 379:return "Fa";
	case 378:return "Fe";
	case 377:return "Fw";
	case 376:return "W";
	case 375:return "I";
	case 374:return "S";
	case 373:return "U";
	default :return "";
	}
}