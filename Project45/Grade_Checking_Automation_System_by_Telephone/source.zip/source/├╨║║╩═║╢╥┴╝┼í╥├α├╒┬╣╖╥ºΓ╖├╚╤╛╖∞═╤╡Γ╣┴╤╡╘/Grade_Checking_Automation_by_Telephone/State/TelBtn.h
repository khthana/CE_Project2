// TelBtn.h: interface for the CTelBtn class.
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TELBTN_H__9A4E7721_F5AD_4EF0_835A_DB60FDFFEDE2__INCLUDED_)
#define AFX_TELBTN_H__9A4E7721_F5AD_4EF0_835A_DB60FDFFEDE2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTelBtn  
{
public:
	CString	q;
	int		cnt;

	void	Type(char c);
	char	Fst();
	bool	IsEmpty();
	void	Reset();
	CTelBtn();
	virtual ~CTelBtn();
};

#endif // !defined(AFX_TELBTN_H__9A4E7721_F5AD_4EF0_835A_DB60FDFFEDE2__INCLUDED_)
