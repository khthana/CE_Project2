// GradeSet.cpp : implementation file
//

#include "stdafx.h"
#include "State.h"
#include "GradeSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGradeSet

IMPLEMENT_DYNAMIC(CGradeSet, CRecordset)

CGradeSet::CGradeSet(CDatabase* pdb)
	: CRecordset(pdb)
{
	//{{AFX_FIELD_INIT(CGradeSet)
	m_Grade = _T("");
	m_Subject = _T("");
	m_Weight = 0;
	m_nFields = 3;
	//}}AFX_FIELD_INIT
	m_nDefaultType = snapshot;
}


CString CGradeSet::GetDefaultConnect()
{
	return _T("ODBC;DSN=Student");
}

CString CGradeSet::GetDefaultSQL()
{
	return _T("[Grade],[Subject]");
}

void CGradeSet::DoFieldExchange(CFieldExchange* pFX)
{
	//{{AFX_FIELD_MAP(CGradeSet)
	pFX->SetFieldType(CFieldExchange::outputColumn);
	RFX_Text(pFX, _T("[Grade]"), m_Grade);
	RFX_Text(pFX, _T("[Subject]"), m_Subject);
	RFX_Byte(pFX, _T("[Weight]"), m_Weight);
	//}}AFX_FIELD_MAP
}

/////////////////////////////////////////////////////////////////////////////
// CGradeSet diagnostics

#ifdef _DEBUG
void CGradeSet::AssertValid() const
{
	CRecordset::AssertValid();
}

void CGradeSet::Dump(CDumpContext& dc) const
{
	CRecordset::Dump(dc);
}
#endif //_DEBUG
