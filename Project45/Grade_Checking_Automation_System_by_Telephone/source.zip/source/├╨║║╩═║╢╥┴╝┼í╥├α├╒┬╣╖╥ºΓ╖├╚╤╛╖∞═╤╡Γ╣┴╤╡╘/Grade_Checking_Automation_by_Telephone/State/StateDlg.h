// StateDlg.h : header file
//

#if !defined(AFX_STATEDLG_H__9CB1867F_7C3C_432D_83FD_EB423DC71A81__INCLUDED_)
#define AFX_STATEDLG_H__9CB1867F_7C3C_432D_83FD_EB423DC71A81__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TelState.h"
#define	max_tel	4
/////////////////////////////////////////////////////////////////////////////
// CStateDlg dialog

class CStateDlg : public CDialog
{
// Construction
public:
	CTelState	Tel[max_tel];
	CString		str[max_tel];
	CWnd		*TelWnd;
	CStateDlg(CWnd* pParent = NULL);	// standard constructor
	CString GetState(int i);


// Dialog Data
	//{{AFX_DATA(CStateDlg)
	enum { IDD = IDD_STATE_DIALOG };
	CString	m_Edit1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStateDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CStateDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATEDLG_H__9CB1867F_7C3C_432D_83FD_EB423DC71A81__INCLUDED_)
