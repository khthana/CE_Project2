// TelState.cpp: implementation of the CTelState class.
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "State.h"
#include "TelState.h"
#include "TelBtn.h"
#include "GradeSet.h"
#include "StudentSet.h"
#include <sapi.h>
#include "sphelper.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CTelState::CTelState(){
	Q.Reset();
	St=0;Receive=0;IsPlay=0;NowPlay=0;
	m_StudentSet.Open();
	m_GradeSet.Open();
	//State();
}
CTelState::~CTelState(){
}
void CTelState::SetThread(int t){
	Thread=t;
}
void CTelState::Speak(CString st){
	ISpVoice *pVoice= NULL;
	HRESULT hr = CoCreateInstance(CLSID_SpVoice, NULL, CLSCTX_ALL, IID_ISpVoice, (void **)&pVoice);
	if(SUCCEEDED(hr)){
		CtoW(st,Speech);
		hr = pVoice->Speak(Speech, 0, NULL);
        pVoice->Release();
        pVoice = NULL;
	}
}
void CTelState::Speak(CString st,CString fname){
	CComPtr <ISpVoice>		cpVoice;
	CComPtr <ISpStream>		cpStream;
	CSpStreamFormat			cAudioFmt;
	HRESULT hr = cpVoice.CoCreateInstance(CLSID_SpVoice);
	//Set the audio format
	if(SUCCEEDED(hr)){
		hr = cAudioFmt.AssignFormat(SPSF_8kHz16BitMono);	
		//Call SPBindToFile, a SAPI helper method,  to bind the audio stream to the file
		if(SUCCEEDED(hr)){
			CtoW(fname,FILE);
			CtoW(st,Speech);
			hr = SPBindToFile(FILE,SPFM_CREATE_ALWAYS,
				&cpStream,&cAudioFmt.FormatId(),cAudioFmt.WaveFormatExPtr());	
			//set the output to cpStream so that the output audio data will be stored in cpStream
			if(SUCCEEDED(hr)){
				hr = cpVoice->SetOutput( cpStream, TRUE );
				//Speak the text "hello world" synchronously
				if(SUCCEEDED(hr)){
					hr = cpVoice->Speak(Speech,SPF_DEFAULT,NULL);	
					//close the stream
					if(SUCCEEDED(hr)){
						hr = cpStream->Close();
						//Release the stream and voice object
					}
				}
			}
		}
		cpStream.Release ();
		cpVoice.Release();
	}
}
void CTelState::CtoW(CString a,WCHAR *w){
	int i,j;
	char *ch;
	i = a.GetLength();
	ch=(char*)malloc(i);
	for (j=i;j>0;j--){
		ch[j-1]=a.GetAt(j-1);
	}
	for(j=0;j<200;j++)w[j]=0;
	mbstowcs(w,ch,i);
/*
	char ch1[200];
	for(j=0;j<200;j++)ch1[j]=' ';
	wcstombs(ch1,Speech,i);
	CString s;
	s.Format("%d",i);
	MessageBox(s);
	MessageBox(ch1);
*/
}
int CTelState::Count(int j,char k){
	switch(k){
	case '0':j=j*10;break;
	case '1':j=j*10+1;break;
	case '2':j=j*10+2;break;
	case '3':j=j*10+3;break;
	case '4':j=j*10+4;break;
	case '5':j=j*10+5;break;
	case '6':j=j*10+6;break;
	case '7':j=j*10+7;break;
	case '8':j=j*10+8;break;
	case '9':j=j*10+9;break;
	}
	return j;
}
WPARAM CTelState::Input(WPARAM wParam){
	WPARAM i=100;
	 if(wParam==100){SetReceive();Q.Type('A');i=State();
	 }else if(Receive!=0){
		if(wParam==48)		{Q.Type('0');i=State();
		}else if(wParam==49){Q.Type('1');i=State();
		}else if(wParam==50){Q.Type('2');i=State();
		}else if(wParam==51){Q.Type('3');i=State();
		}else if(wParam==52){Q.Type('4');i=State();
		}else if(wParam==53){Q.Type('5');i=State();
		}else if(wParam==54){Q.Type('6');i=State();
		}else if(wParam==55){Q.Type('7');i=State();
		}else if(wParam==56){Q.Type('8');i=State();
		}else if(wParam==57){Q.Type('9');i=State();
		}else if(wParam==35){Q.Type('#');i=State();
		}else if(wParam==42){Q.Type('*');i=State();
		}else if(wParam==200){i=100;
		}else if(wParam==201){i=200;Receive=0;
		}else if((wParam>299)&&(wParam<400)){
			SetFinishPlay(wParam);
			Q.Type('A');
			i=State();
		}
	}else	i=100;
	return i;
	//TRACE( "char = %c , cnt = %d , string = %s \n",c,Q.cnt,Q.q);
}
float CTelState::GPlus(CString a){
	if(a.GetLength()>1)	return 0.5;
	else				return 0;
}
float CTelState::Grade(CString a){
	float b;
	char c;
	c=a.GetAt(0);
	switch (c){
	case 'F':
	case 'f':b=0;break;
	case 'D':
	case 'd':b=1+GPlus(a);break;
	case 'C':
	case 'c':b=2+GPlus(a);break;
	case 'B':
	case 'b':b=3+GPlus(a);break;
	case 'A':
	case 'a':b=4;break;
	default :b=0;
	}
	return b;
}
int CTelState::Grade_Message(CString a){
	int b;
	char c;
	c=a.GetAt(0);
	switch (c){
	case 'W':
	case 'w':b=376;break;
	case 'I':
	case 'i':b=375;break;
	case 'S':
	case 's':b=374;break;
	case 'U':
	case 'u':b=373;break;
	case 'F':
	case 'f':
		if(a.GetLength()>1){
			c=a.GetAt(2);
			switch(c){
			case 'a':b=379;break;
			case 'e':b=378;break;
			case 'w':b=377;break;
			default :b=100;break;
			}
		}else				b=392;
		break;
	case 'D':
	case 'd':
		if(a.GetLength()>1)	b=394;
		else				b=393;
		break;
	case 'C':
	case 'c':
		if(a.GetLength()>1)	b=396;
		else				b=395;
		break;
	case 'B':
	case 'b':
		if(a.GetLength()>1)	b=398;
		else				b=397;
		break;
	case 'A':
	case 'a':b=399;break;
	default :b=0;
	}
	return b;
}
float CTelState::GPA(){
	int a,b;
	float c;
	a=0;
	c=0;
	do{
		b=m_GradeSet.m_Weight;
		if((b>0)&&(m_GradeSet.m_Grade!="")){
			c+=Grade(m_GradeSet.m_Grade) * b;
			a+=b;
		}
		m_GradeSet.MoveNext();
	}while (m_GradeSet.IsEOF()==0);
	c/=a;
	return c;
}
void CTelState::SetReceive(){
	int i;
	for(i=0;i<200;i++)Speech[i]=0;
	Invalid=0;
	gpa=0;
	gpaterm=0;
	gps=0;
	Receive=1;
	St=0;
}
void CTelState::SetFinishPlay(int l){
	if(l==NowPlay)
		IsPlay=0;
}
WPARAM CTelState::State(){
	int i;
	switch(St){
	case 0://[Start]
		if(Receive!=0){
			IsPlay=1;
			NowPlay=310;//Hello.wav
			St=1;
			Q.Reset();
			//Speak("Welcome to Grade Checking Automation by Telephone");
			//*s*/Speak("Hello");
			return NowPlay;
		}return 100;
		break;
	case 1://[invalid]
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=320;//ID.wav
			St=2;
			Q.Reset();
			//Speak("Pleas type your eight I D number");
			//*s*/Speak("I D");
			return NowPlay;
		}return 100;
		break;
	case 2:
		if(Q.cnt>=8){
			ID=0;
			for(i=0;i<8;i++)ID=Count(ID,Q.Fst());
			IsPlay=1;
			NowPlay=321;//PASS.wav
			St=3;
			Q.Reset();
			//Speak("Pleas type your password");
			//*s*/Speak("Pass");
			return NowPlay;
		}return 100;
		break;
	case 3:
		if(Q.cnt>=6){
			PASS=0;
			for(i=0;i<6;i++)PASS=Count(PASS,Q.Fst());
			s.Format("[id]=%d and [Pass]=%d",ID,PASS);
			m_StudentSet.Close();
			m_StudentSet.m_strFilter=s;
			m_StudentSet.Open();
			if(m_StudentSet.IsEOF()==0){
				IsPlay=1;
				NowPlay=330;//SpeakCase.wav
				St=20;
				Q.Reset();
				//Speak("Press 1 for G P A");
				//Speak("Press 2 for Term Grades");
				//*s*/Speak("G P A 1 Subject 2 Term 3");
				return NowPlay;
			}
			Invalid++;
			if(Invalid<3){
				IsPlay=1;
				NowPlay=320;//id.wav
				St=2;
				Q.Reset();
				//Speak("Pleas type your eight I D number");
				//*s*/Speak("I D");
				return NowPlay;
			}
			Receive=0;
			return 200;//release line;
		}return 100;
		break;
	case 10://[finish]
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=340;//More.wav
			St=11;
			Q.Reset();
			//*s*/Speak("more 1 quit 2");
			return NowPlay;
		}return 100;
		break;
	case 11:
		if(Q.cnt>=1){
			if(Receive<3){
				i=Count(0,Q.Fst());
				switch (i){
				case 1:
					IsPlay=1;
					NowPlay=330;//SpeakCase.wav
					St=20;
					Q.Reset();
					//Speak("Press 1 for G P A");
					//Speak("Press 2 for Term Grades");
					//*s*/Speak("G P A 1 Subject 2 Term 3");
					return NowPlay;
					break;
				case 2:
					Receive=0;
					return 200;//release line
					break;
				default:
					IsPlay=1;
					NowPlay=340;//More.wav
					St=11;
					Receive++;
					Q.Reset();
					//*s*/Speak("more 1 quit 2");
					return NowPlay;
					break;
				}
			}else{
				Receive=0;
				return 200;//release line
			}
		}return 100;
		break;
	case 20:
		if(Q.cnt>=1){
			i=Count(0,Q.Fst());
			if(i==1){
				//create name_[thread].wav
				s.Format("%s %s",m_StudentSet.m_Fname,m_StudentSet.m_Lname);
				t.Format("Name_%d.wav",Thread);
				Speak(s,t);
				//calculate GPA
				s.Format("[StdID]=%d and [ID]=[SubID]",ID);
				m_GradeSet.Close();
				m_GradeSet.m_strFilter=s;
				m_GradeSet.Open();
				if(m_GradeSet.IsEOF()==0)	gpa=GPA();
				s.Format("%.2f",gpa);
				IsPlay=1;
				NowPlay=350;//GPAof.wav
				St=30;
				Q.Reset();
				//*s*/Speak("G P A of");
				return NowPlay;
			}else if(i==2){
				IsPlay=1;
				NowPlay=360;//year.wav
				St=40;
				Q.Reset();
				//*s*/Speak("Pleas type Year");
				return NowPlay;
			}else if(i==3){
				IsPlay=1;
				NowPlay=360;//year.wav
				St=60;
				Q.Reset();
				//*s*/Speak("Pleas type Year");
				return NowPlay;
			}
			IsPlay=1;
			NowPlay=330;//speakcase.wav
			Q.Reset();
			//St=20;//same state
			//Speak("Press 1 for G P A");
			//Speak("Press 2 for Term Grades");
			//*s*/Speak("G P A 1 Subject 2 Term 3");
			return NowPlay;
		}return 100;
		break;
	case 30://[GPA]
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=351;//Name_[thread].wav
			St=31;
			Q.Reset();
			//*s*/Speak("your name");
			return NowPlay;
		}return 100;
		break;
	case 31:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=352;//result.wav
			St=32;
			Q.Reset();
			//*s*/Speak("is");
			return NowPlay;
		}return 100;
		break;
	case 32:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(0));//[0-9].wav
			St=33;
			Q.Reset();
			//*s*/Speak(s.GetAt(0));
			return NowPlay;
		}return 100;
		break;
	case 33:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=390;//Dot.wav
			St=34;
			Q.Reset();
			//*s*/Speak("point");
			return NowPlay;
		}return 100;
		break;
	case 34:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(2));//[0-9].wav
			St=35;
			Q.Reset();
			//*s*/Speak(s.GetAt(2));
			return NowPlay;
		}return 100;
		break;
	case 35:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(3));//[0-9].wav
			St=10;
			Q.Reset();
			//*s*/Speak(s.GetAt(3));
			return NowPlay;
		}return 100;
		break;
	case 40:
		if(Q.cnt>=4){
			YEAR=0;
			for(i=0;i<6;i++)YEAR=Count(YEAR,Q.Fst());
			IsPlay=1;
			NowPlay=361;//term.wav
			St=41;
			Q.Reset();
			//*s*/Speak("Pleas type Term");
			return NowPlay;
		}return 100;
		break;
	case 41:
		if(Q.cnt>=1){
			TERM=Count(0,Q.Fst());
			s.Format("[StdID]=%d and [ID]=[SubID] and ([Year]<%d or ([Year]=%d and [Term]<=%d))",ID,YEAR,YEAR,TERM);
			m_GradeSet.Close();
			m_GradeSet.m_strFilter=s;
			m_GradeSet.Open();
			if(m_GradeSet.GetRecordCount()!=0){
				gpaterm=GPA();
				s.Format("[StdID]=%d and [SubID]=[ID] and [Year]=%d and [Term]=%d",ID,YEAR,TERM);
				m_GradeSet.Close();
				m_GradeSet.m_strFilter=s;
				m_GradeSet.Open();
				if(m_GradeSet.GetRecordCount()!=0){
					//create subject_[thread].wav
					t.Format("Subject_%d.wav",Thread);
					Speak(m_GradeSet.m_Subject,t);
					gps=GPA();
					m_GradeSet.MoveFirst();
					IsPlay=1;
					NowPlay=362;//subject.wav
					St=43;
					Q.Reset();
					//*s*/Speak("Subject");
					return NowPlay;
				}
			}
			IsPlay=1;
			NowPlay=370;//NoRecord.wav
			St=55;
			Q.Reset();
			//*s*/Speak("No record found");
			return NowPlay;
		}return 100;
		break;
	case 42:
		if((Q.cnt>=1)||(IsPlay==0)){
			if(m_GradeSet.IsEOF()==0){
				//create Subject_[thread].wav
				Speak(m_GradeSet.m_Subject,t);
				IsPlay=1;
				NowPlay=362;//subject.wav
				St=43;
				Q.Reset();
				//*s*/Speak("Subject");
				return NowPlay;
			}
			s.Format("%.2f",gps);
			IsPlay=1;
			NowPlay=366;//GPS.wav
			St=46;
			Q.Reset();
			//*s*/Speak("Your G-P-S is");
			return NowPlay;
		}return 100;
		break;
	case 43:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=363;//Subject_[thread].wav
			St=44;
			Q.Reset();
			//*s*/Speak(m_GradeSet.m_Subject);
			return NowPlay;
		}return 100;
		break;
	case 44:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=364;//"result_".wav
			St=45;
			Q.Reset();
			//*s*/Speak("Result is");
			return NowPlay;
		}return 100;
		break;
	case 45:
		if((Q.cnt>=1)||(IsPlay==0)){
			m_GradeSet.MoveNext();
			IsPlay=1;
			St=42;
			Q.Reset();
			//*s*/Speak(m_GradeSet.m_Grade);
			NowPlay=Grade_Message(m_GradeSet.m_Grade);
			return NowPlay;
		}return 100;
		break;
	case 46:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(0));//[0-9].wav
			St=47;
			Q.Reset();
			//*s*/Speak(s.GetAt(0));
			return NowPlay;
		}return 100;
		break;
	case 47:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=390;//Dot.wav
			St=48;
			Q.Reset();
			//*s*/Speak("point");
			return NowPlay;
		}return 100;
		break;
	case 48:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(2));//[0-9].wav
			St=49;
			Q.Reset();
			//*s*/Speak(s.GetAt(2));
			return NowPlay;
		}return 100;
		break;
	case 49:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(3));//[0-9].wav
			St=50;
			Q.Reset();
			//*s*/Speak(s.GetAt(3));
			return NowPlay;
		}return 100;
		break;
	case 50:
		if((Q.cnt>=1)||(IsPlay==0)){
			s.Format("%.2f",gpaterm);
			IsPlay=1;
			NowPlay=368;//GPA.wav
			St=51;
			Q.Reset();
			//*s*/Speak("Your G-P-A is");
			return NowPlay;
		}return 100;
		break;
	case 51:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(0));//[0-9].wav
			St=52;
			Q.Reset();
			//*s*/Speak(s.GetAt(0));
			return NowPlay;
		}return 100;
		break;
	case 52:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=390;//Dot.wav
			St=53;
			Q.Reset();
			//*s*/Speak("point");
			return NowPlay;
		}return 100;
		break;
	case 53:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(2));//[0-9].wav
			St=54;
			Q.Reset();
			//*s*/Speak(s.GetAt(2));
			return NowPlay;
		}return 100;
		break;
	case 54:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(3));//[0-9].wav
			St=10;
			Q.Reset();
			//*s*/Speak(s.GetAt(3));
			return NowPlay;
		}return 100;
		break;
	case 55:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=360;//year.wav
			St=40;
			Q.Reset();
			//*s*/Speak("Pleas type Year");
			return NowPlay;
		}return 100;
		break;
	case 60:
		if(Q.cnt>=4){
			YEAR=0;
			for(i=0;i<6;i++)YEAR=Count(YEAR,Q.Fst());
			IsPlay=1;
			NowPlay=361;//term.wav
			St=61;
			Q.Reset();
			//*s*/Speak("Pleas type Term");
			return NowPlay;
		}return 100;
		break;
	case 61:
		if(Q.cnt>=1){
			TERM=Count(0,Q.Fst());
			s.Format("[StdID]=%d and [ID]=[SubID] and ([Year]<%d or ([Year]=%d and [Term]<=%d))",ID,YEAR,YEAR,TERM);
			m_GradeSet.Close();
			m_GradeSet.m_strFilter=s;
			m_GradeSet.Open();
			if(m_GradeSet.GetRecordCount()!=0){
				gpaterm=GPA();
				s.Format("[StdID]=%d and [SubID]=[ID] and [Year]=%d and [Term]=%d",ID,YEAR,TERM);
				m_GradeSet.Close();
				m_GradeSet.m_strFilter=s;
				m_GradeSet.Open();
				if(m_GradeSet.GetRecordCount()!=0){
					gps=GPA();
					m_GradeSet.MoveFirst();
					s.Format("%.2f",gps);
					IsPlay=1;
					NowPlay=366;//GPS.wav
					St=63;
					Q.Reset();
					//*s*/Speak("Your G-P-S is");
					return NowPlay;
				}
			}
			IsPlay=1;
			NowPlay=370;//NoRecord.wav
			St=62;
			Q.Reset();
			//*s*/Speak("No record found");
			return NowPlay;
		}return 100;
		break;
	case 62:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=360;//year.wav
			St=60;
			Q.Reset();
			//*s*/Speak("Pleas type Year");
			return NowPlay;
		}return 100;
		break;
	case 63:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(0));//[0-9].wav
			St=64;
			Q.Reset();
			//*s*/Speak(s.GetAt(0));
			return NowPlay;
		}return 100;
		break;
	case 64:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=390;//Dot.wav
			St=65;
			Q.Reset();
			//*s*/Speak("point");
			return NowPlay;
		}return 100;
		break;
	case 65:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(2));//[0-9].wav
			St=66;
			Q.Reset();
			//*s*/Speak(s.GetAt(2));
			return NowPlay;
		}return 100;
		break;
	case 66:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(3));//[0-9].wav
			St=67;
			Q.Reset();
			//*s*/Speak(s.GetAt(3));
			return NowPlay;
		}return 100;
		break;
	case 67:
		if((Q.cnt>=1)||(IsPlay==0)){
			s.Format("%.2f",gpaterm);
			IsPlay=1;
			NowPlay=368;//GPA.wav
			St=68;
			Q.Reset();
			//*s*/Speak("Your G-P-A is");
			return NowPlay;
		}return 100;
		break;
	case 68:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(0));//[0-9].wav
			St=69;
			Q.Reset();
			//*s*/Speak(s.GetAt(0));
			return NowPlay;
		}return 100;
		break;
	case 69:
		if((Q.cnt>=1)||(IsPlay==0)){
			IsPlay=1;
			NowPlay=390;//Dot.wav
			St=70;
			Q.Reset();
			//*s*/Speak("point");
			return NowPlay;
		}return 100;
		break;
	case 70:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(2));//[0-9].wav
			St=71;
			Q.Reset();
			//*s*/Speak(s.GetAt(2));
			return NowPlay;
		}return 100;
		break;
	case 71:
		if((Q.cnt>=1)||(IsPlay==0)){
			//s.Format("%.2f",gpa);
			IsPlay=1;
			NowPlay=380+Count(0,s.GetAt(3));//[0-9].wav
			St=10;
			Q.Reset();
			//*s*/Speak(s.GetAt(3));
			return NowPlay;
		}return 100;
		break;
	default:
		St=17;
		return 100;
		break;
	}
	return 100;
}
