// State.h : main header file for the STATE application
//

#if !defined(AFX_STATE_H__6586A3C4_0933_4A57_9AF0_622DCBDF0FB9__INCLUDED_)
#define AFX_STATE_H__6586A3C4_0933_4A57_9AF0_622DCBDF0FB9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CStateApp:
// See State.cpp for the implementation of this class
//

class CStateApp : public CWinApp
{
public:

	CStateApp();
	~CStateApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CStateApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CStateApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STATE_H__6586A3C4_0933_4A57_9AF0_622DCBDF0FB9__INCLUDED_)
