#if !defined(AFX_GRADESET_H__46E9A3FC_A8B4_4B6C_BBCB_F2C55CE62716__INCLUDED_)
#define AFX_GRADESET_H__46E9A3FC_A8B4_4B6C_BBCB_F2C55CE62716__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GradeSet.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGradeSet recordset

class CGradeSet : public CRecordset
{
public:
	CGradeSet(CDatabase* pDatabase = NULL);
	DECLARE_DYNAMIC(CGradeSet)

// Field/Param Data
	//{{AFX_FIELD(CGradeSet, CRecordset)
	CString	m_Grade;
	CString	m_Subject;
	BYTE	m_Weight;
	//}}AFX_FIELD


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGradeSet)
	public:
	virtual CString GetDefaultConnect();    // Default connection string
	virtual CString GetDefaultSQL();    // Default SQL for Recordset
	virtual void DoFieldExchange(CFieldExchange* pFX);  // RFX support
	//}}AFX_VIRTUAL

// Implementation
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRADESET_H__46E9A3FC_A8B4_4B6C_BBCB_F2C55CE62716__INCLUDED_)
