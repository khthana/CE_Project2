// TelState.h: interface for the CTelState class.
//////////////////////////////////////////////////////////////////////
#if !defined(AFX_TELSTATE_H__39064552_F5FD_4C06_ABAB_F67D989A0236__INCLUDED_)
#define AFX_TELSTATE_H__39064552_F5FD_4C06_ABAB_F67D989A0236__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "TelBtn.h"
#include "GradeSet.h"
#include "StudentSet.h"

class CTelState  
{
public:
	CTelState();
	virtual ~CTelState();
	WPARAM Input(WPARAM wParam);
	void SetThread(int t);
	void SetReceive();
	void SetFinishPlay(int l);
	void Speak(CString st);
	void Speak(CString st,CString fname);
private:
	CStudentSet m_StudentSet;
	CGradeSet	m_GradeSet;
	WCHAR	Speech[200],FILE[200];
	CTelBtn	Q;
	int	St,Invalid,Thread,Receive,IsPlay,NowPlay,Down;
	float gpa,gpaterm,gps;
	long ID,PASS,YEAR,TERM;
	CString s,t;

	void CtoW(CString a,WCHAR *w);
	WPARAM State();
	int	Count(int j,char k);
	float GPA();
	float GPlus(CString a);
	int	Grade_Message(CString a);
	float Grade(CString a);
};

#endif // !defined(AFX_TELSTATE_H__39064552_F5FD_4C06_ABAB_F67D989A0236__INCLUDED_)
