//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by test.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEST_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1017
#define IDC_BUTTON2                     1018
#define IDC_BUTTON3                     1019
#define IDC_BUTTON4                     1020
#define IDC_BUTTON5                     1021
#define IDC_BUTTON6                     1022
#define IDC_BUTTON7                     1023
#define IDC_BUTTON8                     1024
#define IDC_BUTTON9                     1025
#define IDC_BUTTON10                    1026
#define IDC_BUTTON11                    1027
#define IDC_BUTTON12                    1028
#define IDC_BUTTON13                    1029
#define IDC_BUTTON14                    1030
#define IDC_BUTTON15                    1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
