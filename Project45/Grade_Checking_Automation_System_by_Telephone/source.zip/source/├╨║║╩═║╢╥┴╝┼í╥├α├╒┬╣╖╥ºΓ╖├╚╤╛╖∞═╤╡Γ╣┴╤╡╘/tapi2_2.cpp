// tapi2_2.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "tapi.h"
#include "resource.h"
#include <stdlib.h>
#include <stdio.h>
#include "Mmsystem.h"
#include "process.h"

DWORD delay=15000;

/*======================== Window Name ============================*/
char szWindowClass[] ="First Window Application";
// Message to communication dialog //
WPARAM commessage,commessage2,commessage3,commessage4;
BYTE active[20];
BOOLEAN status1,status2,statusline1,statusline2;
int countstatus1,countstatus2;
DWORD deviceid1,deviceid2;
HANDLE semaphor1,semaphor2,semaphor3,semaphor4;
//====== variable to another modem ============//
DWORD hdevice1,hdevice2;
DWORD dwWaveOutID1,dwWaveOutID2;
//===============================================//
//temp//
HWAVEOUT hWaveOut;
/////////////////////

char buffer[20],buffer2[20];
HINSTANCE hint;

HLINEAPP hlineapp,hlineapp2;
HLINE hline,hline2;
HCALL hcall=NULL;
HCALL hcall2=NULL;
LINEEXTENSIONID extensionid;
DWORD numdevice ;
DWORD version = 0x00020000;
DWORD versionn;
LINEINITIALIZEEXPARAMS setbehave,setbehave2;
LONG temp,temp2;
LINEDEVCAPS linedevcap;
LINEADDRESSCAPS lineaddresscap;
DWORD addressid;
HWND hwnd,ahwnd;
DWORD deviceid;

DWORD dwWaveInID ;

/*============== Variable for Play Wave =============================== */
HWAVEOUT hWaveOut2;
WAVEHDR WaveHeader2;
HMMIO hmmio2;
/*=====================================================================*/
char *filename1,*filename2;
void checknull2(void *cs);
void checknull1(void *cs);
void playwave_to_modem(void *cs);
void playwave_to_modem2(void *cs);
void err_mmioopen(int i);
void CALLBACK waveOutProc(
  HWAVEOUT hwo,      
  UINT uMsg,         
  DWORD dwInstance,  
  DWORD dwParam1,    
  DWORD dwParam2     
);
LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK MyDialog1(HWND hDlg,UINT message,WPARAM wParam,LPARAM lParam);
VOID FAR PASCAL lineCallbackFunc(	DWORD hDevice,             
									DWORD dwMsg,               
									DWORD dwCallbackInstance,  
									DWORD dwParam1,            
									DWORD dwParam2,            
									DWORD dwParam3             
								);
VOID FAR PASCAL lineCallbackFunc2(	DWORD hDevice,             
									DWORD dwMsg,               
									DWORD dwCallbackInstance,  
									DWORD dwParam1,            
									DWORD dwParam2,            
									DWORD dwParam3             
								);
void CALLBACK waveOutProc2(
  HWAVEOUT hwo,      
  UINT uMsg,         
  DWORD dwInstance,  
  DWORD dwParam1,    
  DWORD dwParam2     );

DWORD playWAVEFile(HWND hWndNotify, LPSTR lpszWAVEFileName);


/*================================ WinMain ==========================*/

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
	
	hint = hInstance;	

/* ======================== Tapi ================================================*/

	
	//setbehave.dwNeededSize = 0x00000020 ;
	setbehave.dwTotalSize = sizeof(LINEINITIALIZEEXPARAMS);
	//setbehave.dwOptions =LINEINITIALIZEEXOPTION_USEEVENT ;
	setbehave.dwOptions = LINEINITIALIZEEXOPTION_USEHIDDENWINDOW ;
	//setbehave.dwUsedSize = 0x00000020 ;
//	HLINE hline;
//	lineOpen(hInstance,1,hline,version,version,NULL,"LINEOPENOPTION_SINGLEADDRESS ");
	
	LINEMESSAGE linemessage;
	DWORD timeout;
	
	temp=lineInitializeEx(&hlineapp,hInstance,(LINECALLBACK)lineCallbackFunc,"TAPI",&numdevice,&version,&setbehave);
	temp2=lineInitializeEx(&hlineapp2,hInstance,(LINECALLBACK)lineCallbackFunc2,"TAPI",&numdevice,&version,&setbehave);
	//temp=lineInitializeEx(&hlineapp,hInstance,NULL,NULL,&numdevice,&version,&setbehave);
	_ltoa( temp, buffer, 16 );	// convert long to string
	if(temp!=0)
	{
		MessageBox(hwnd,buffer,"lineInitialize error",MB_OK); // check error from lineInitializeEx 
	}




/*=========================== Semaphor ===========================*/
/*================================================================*/

	semaphor1 = CreateSemaphore(NULL,0,1,"sem1");
	if(!semaphor1)
	MessageBox(hwnd,"error semaphor","error",MB_OK);

	semaphor2 = CreateSemaphore(NULL,0,1,"sem2");
	if(!semaphor2)
	MessageBox(hwnd,"error semaphor","error",MB_OK);

	semaphor3 = CreateSemaphore(NULL,0,1,"sem3");
	if(!semaphor1)
	MessageBox(hwnd,"error semaphor","error",MB_OK);

	semaphor4 = CreateSemaphore(NULL,0,1,"sem4");
	if(!semaphor2)
	MessageBox(hwnd,"error semaphor","error",MB_OK);
	
/*===================== Create Main Dialog   ============================================*/
	_beginthread(checknull1,0,NULL);
	_beginthread(checknull2,0,NULL);

	hwnd = (HWND)DialogBox(hint,"IDD_MAIN",NULL,(DLGPROC)WndProc);


	
	lineClose(hline);
	lineClose(hline2);
	return 0;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam,LPARAM lParam)
{
	
	int wmld;
	switch(message)
	{
	case WM_INITDIALOG:
		//MessageBox(hWnd,"init dialog","init dialog",MB_OK);
		int j;
				for (j=0;j<20;j++)
					active[j]=0;
				commessage=100;
				commessage3=100;
				statusline1=false;
				statusline2=false;
				countstatus1=0;
				countstatus2=0;
		/*============================ Init Send Message ================================*/
				ahwnd = FindWindow(NULL,"State");
				if(ahwnd == NULL) { 						
				MessageBox(hwnd,"Send Message to Database Error","Error Message",MB_OK);
				}
				/*========================== Init Combobox 1 and 2 ========================*/
				TCHAR *name;
				LINEDEVCAPS linedevcaps[20];
				linedevcap.dwTotalSize = sizeof(LINEDEVCAPS)+1000; //// important Value
				
				int i ;
				for(i=0;i<numdevice;i++)				
				{
					linedevcaps[i].dwTotalSize = sizeof(LINEDEVCAPS)+1000; //// important Value
					temp=lineGetDevCaps(hlineapp,i,0x00010004,0x00000000,&linedevcaps[i]);
				//	linedevcap.dwTotalSize = linedevcap.dwNeededSize ;
				//	temp = lineGetDevCaps(hlineapp,deviceid,0x00010003,0x00000000,&linedevcap);
					_ltoa(temp,buffer,16);
					_itoa(i,buffer,10);
						strcpy(buffer2," Line ");
							strcat(buffer2,buffer);
							strcat(buffer2," -> ");
					if(linedevcaps[i].dwNeededSize < linedevcaps[i].dwTotalSize )
					{
						if(temp!=0)
							MessageBox(hwnd,buffer,"test error LineGetDevCaps ",MB_OK);
						
						name = (LPSTR)((DWORD)(&linedevcaps[i])+(DWORD)linedevcaps[i].dwLineNameOffset );
						strcat(buffer2,name);
						//SendMessage(IDC_COMBO1, LB_ADDSTRING, 0,(LPARAM)buffer2 );
						SendDlgItemMessage(hWnd,IDC_COMBO1,CB_ADDSTRING ,100,(LPARAM)buffer2);
						SendDlgItemMessage(hWnd,IDC_COMBO2,CB_ADDSTRING ,100,(LPARAM)buffer2);
					}
					else
					{
						strcat(buffer2,"!!! Invalid device !!!");
						//SendMessage(h_list, LB_ADDSTRING, 0,(DWORD)buffer2 );
						SendDlgItemMessage(hWnd,IDC_COMBO1,CB_ADDSTRING ,100,(LPARAM)buffer2);
						SendDlgItemMessage(hWnd,IDC_COMBO2,CB_ADDSTRING ,100,(LPARAM)buffer2);

					}
				}
		break;
	case WM_CLOSE:
		EndDialog(hWnd,0);
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	case WM_COMMAND:
			switch(LOWORD(wParam))
			{
			case IDC_START1:	
				status1 = true;
				lineClose(hline);
				deviceid1=SendDlgItemMessage(hWnd,IDC_COMBO1,CB_GETCURSEL,NULL,0);
				if(active[deviceid1]==0)
				{
					temp=lineNegotiateAPIVersion(hlineapp,deviceid1,0x00010004,0x00020002,&versionn,&extensionid);
					_ltoa(temp,buffer,16);
					if(temp!=0)
					{
						MessageBox(hWnd,"negotiate","test error",MB_OK); // check error from lineInitializeEx 
						MessageBox(hwnd,buffer,"linenegotiate error",MB_OK);
						status1 = false;
					}
					
					temp=lineOpen(hlineapp,deviceid1,&hline,0x00010004,NULL,NULL,LINECALLPRIVILEGE_OWNER,LINEMEDIAMODE_AUTOMATEDVOICE,NULL);				
					_ltoa(temp,buffer,16);
					if(temp!=0)
					{
						MessageBox(hwnd,"lineopen","test error",MB_OK); // check error from lineInitializeEx 
						MessageBox(hwnd,buffer,"test error",MB_OK);
						status1 = false;
					}
					temp=lineSetStatusMessages(hline,LINEDEVSTATE_CONNECTED | LINEDEVSTATE_INSERVICE |LINEDEVSTATE_MSGWAITON | LINEDEVSTATE_RINGING | LINEDEVSTATE_SIGNAL , LINEADDRESSSTATE_INUSEONE );
					_ltoa(temp,buffer,16);
					if(temp!=0)
					{		
						MessageBox(hwnd,buffer,"lineSetStatus error",MB_OK);
						status1 = false;
					}
					if(status1==true)
					{
						SetDlgItemText(hWnd,IDC_STATUS1," Ready ");
						active[deviceid1]=1;
					}
					else
					{
						SetDlgItemText(hWnd,IDC_STATUS1," Not Ready ");
						active[deviceid1]=0;
					}
				}
				else
					MessageBox(hWnd," This line Active now . Don't open againg","Error",MB_OK);
				break;
			case IDC_START2:
				status2 = true;
				lineClose(hline2);
				deviceid2=SendDlgItemMessage(hWnd,IDC_COMBO2,CB_GETCURSEL,NULL,0);
				if(active[deviceid2]==0)
				{
					temp=lineNegotiateAPIVersion(hlineapp2,deviceid2,0x00010004,0x00020002,&versionn,&extensionid);
					_ltoa(temp,buffer,16);
					if(temp!=0)
					{
						MessageBox(hwnd,"negotiate","test error",MB_OK); // check error from lineInitializeEx 
						MessageBox(hwnd,buffer,"linenegotiate error",MB_OK);
						status2 = false;
					}				
					temp=lineOpen(hlineapp2,deviceid2,&hline2,0x00010004,NULL,NULL,LINECALLPRIVILEGE_OWNER,LINEMEDIAMODE_AUTOMATEDVOICE,NULL);				
					_ltoa(temp,buffer,16);
					if(temp!=0)
					{
						MessageBox(hwnd,"lineopen","test error",MB_OK); // check error from lineInitializeEx 
						MessageBox(hwnd,buffer,"test error",MB_OK);
						status2 = false;
					}
					temp=lineSetStatusMessages(hline2,LINEDEVSTATE_CONNECTED | LINEDEVSTATE_INSERVICE |LINEDEVSTATE_MSGWAITON | LINEDEVSTATE_RINGING | LINEDEVSTATE_SIGNAL , LINEADDRESSSTATE_INUSEONE );
					_ltoa(temp,buffer,16);
					if(temp!=0)
					{		
						MessageBox(hwnd,buffer,"lineSetStatus error",MB_OK);
						status2 = false;
					}
					if(status2==true)
					{
						SetDlgItemText(hWnd,IDC_STATUS2," Ready ");
						active[deviceid2]=1;
					}
					else
					{
						SetDlgItemText(hWnd,IDC_STATUS2," Not Ready ");
						active[deviceid2]=0;
					}
				}
				else
					MessageBox(hWnd," This line Active now . Don't open againg","Error",MB_OK);
				break;
			}
			break;		
			case 32769:
				if(wParam!=100)
				{
					//if(lParam==0)
					
				//	else if(lParam==1)
				
					_ltoa(wParam,buffer,10);
					//MessageBox(hwnd,buffer,"Communicate",MB_OK);				
				if((lParam==0)&&(statusline1==true))
				{
					switch (wParam)
					{
					case 310:
						filename1="hello.wav";					
						break;
					case 320:
						filename1="id.wav";
						break;
					case 321:
						filename1="pass.wav";
						break;
					case 330:
						filename1="SpeakCase.wav";
						break;
					case 340:
						filename1="More.wav";
						break;
					case 350:
						filename1="GPAof.wav";
						break;
					case 351:
						filename1="Name_0.wav";
						break;
					case 352:
						filename1="Result.wav";
						break;
					case 360:
						filename1="Year.wav";
						break;
					case 361:
						filename1="Term.wav";
						break;
					case 362:
						filename1="Subject.wav";
						break;
					case 363:
						filename1="Subject_0.wav";
						break;
					case 364:
						filename1="Result_.wav";
						break;
					case 366:
						filename1="GPS.wav";
						break;
					case 368:
						filename1="GPA.wav";
						break;
					case 370:
						filename1="NoRecord.wav";
						break;
					case 380:
						filename1="0.wav";
						break;
					case 381:
						filename1="1.wav";
						break;
					case 382:
						filename1="2.wav";
						break;
					case 383:
						filename1="3.wav";
						break;
					case 384:
						filename1="4.wav";
						break;
					case 385:
						filename1="5.wav";
						break;
					case 386:
						filename1="6.wav";
						break;
					case 387:
						filename1="7.wav";
						break;
					case 388:
						filename1="8.wav";
						break;
					case 389:
						filename1="9.wav";
						break;
					case 390:
						filename1="dot.wav";
						break;
					case 399:
						filename1="a.wav";
						break;
					case 398:
						filename1="b+.wav";
						break;
					case 397:
						filename1="b.wav";
						break;
					case 396:
						filename1="c+.wav";
						break;
					case 395:
						filename1="c.wav";
						break;
					case 394:
						filename1="d+.wav";
						break;
					case 393:
						filename1="d.wav";
						break;
					case 392:
						filename1="f.wav";
						break;
					case 200:
						ReleaseSemaphore(semaphor1,1,NULL);
						SendMessage(ahwnd,32769,200, 0);
						statusline1=false;
						commessage=100;
						
						lineDeallocateCall(hcall);
						lineClose(hline);
						temp=lineOpen(hlineapp,deviceid1,&hline,0x00010004,NULL,NULL,LINECALLPRIVILEGE_OWNER,LINEMEDIAMODE_AUTOMATEDVOICE,NULL);						
						_ltoa(temp,buffer,16);
						if(temp!=0)
						{
							MessageBox(hwnd,"lineopen","test error",MB_OK); // check error from lineInitializeEx 
							MessageBox(hwnd,buffer,"test error",MB_OK);
						}

						temp=lineSetStatusMessages(hline,LINEDEVSTATE_CONNECTED | LINEDEVSTATE_INSERVICE |LINEDEVSTATE_MSGWAITON | LINEDEVSTATE_RINGING | LINEDEVSTATE_SIGNAL , LINEADDRESSSTATE_INUSEONE );
						_ltoa(temp,buffer,16);
						if(temp!=0)
						{		
							MessageBox(hwnd,buffer,"lineSetStatus error",MB_OK);
						}
						hcall=NULL;
						break;
					}
					
					//MessageBox(hWnd,filename1,"filename1",MB_OK);
					if(wParam!=200)
					{
						countstatus1++;
						commessage = wParam;
						ReleaseSemaphore(semaphor1,1,NULL);											
						_beginthread(playwave_to_modem,0,NULL);
					}
				}
				else if( (lParam==1) && (statusline2==true) )
				{
					switch (wParam)
					{
					case 310:
						filename2="hello.wav";					
						break;
					case 320:
						filename2="id.wav";
						break;
					case 321:
						filename2="pass.wav";
						break;
					case 330:
						filename2="SpeakCase.wav";
						break;
					case 340:
						filename2="More.wav";
						break;
					case 350:
						filename2="GPAof.wav";
						break;
					case 351:
						filename2="Name_1.wav";
						break;
					case 352:
						filename2="Result.wav";
						break;
					case 360:
						filename2="Year.wav";
						break;
					case 361:
						filename2="Term.wav";
						break;
					case 362:
						filename2="Subject.wav";
						break;
					case 363:
						filename2="Subject_1.wav";
						break;
					case 364:
						filename2="Result_.wav";
						break;
					case 366:
						filename2="GPS.wav";
						break;
					case 368:
						filename2="GPA.wav";
						break;
					case 370:
						filename2="NoRecord.wav";
						break;
					case 380:
						filename2="0.wav";
						break;
					case 381:
						filename2="1.wav";
						break;
					case 382:
						filename2="2.wav";
						break;
					case 383:
						filename2="3.wav";
						break;
					case 384:
						filename2="4.wav";
						break;
					case 385:
						filename2="5.wav";
						break;
					case 386:
						filename2="6.wav";
						break;
					case 387:
						filename2="7.wav";
						break;
					case 388:
						filename2="8.wav";
						break;
					case 389:
						filename2="9.wav";
						break;
					case 390:
						filename2="dot.wav";
						break;
					case 399:
						filename2="a.wav";
						break;
					case 398:
						filename2="b+.wav";
						break;
					case 397:
						filename2="b.wav";
						break;
					case 396:
						filename2="c+.wav";
						break;
					case 395:
						filename2="c.wav";
						break;
					case 394:
						filename2="d+.wav";
						break;
					case 393:
						filename2="d.wav";
						break;
					case 392:
						filename2="f.wav";
						break;
					case 200:
						SendMessage(ahwnd,32769,200, 1);
						ReleaseSemaphore(semaphor3,1,NULL);
						statusline2=false;
						commessage3=100;
						//commessage4=100;
						lineDeallocateCall(hcall2);
						lineClose(hline2);
						temp2=lineOpen(hlineapp2,deviceid2,&hline2,0x00010003,NULL,NULL,LINECALLPRIVILEGE_OWNER,LINEMEDIAMODE_AUTOMATEDVOICE,NULL);						
						_ltoa(temp,buffer,16);
						if(temp!=0)
						{
							MessageBox(hwnd,"lineopen","test error",MB_OK); // check error from lineInitializeEx 
							MessageBox(hwnd,buffer,"test error",MB_OK);
						}

						temp2=lineSetStatusMessages(hline2,LINEDEVSTATE_CONNECTED | LINEDEVSTATE_INSERVICE |LINEDEVSTATE_MSGWAITON | LINEDEVSTATE_RINGING | LINEDEVSTATE_SIGNAL , LINEADDRESSSTATE_INUSEONE );
						_ltoa(temp,buffer,16);
						if(temp!=0)
						{		
							MessageBox(hwnd,buffer,"lineSetStatus error",MB_OK);
						}						
						hcall2 = NULL;
						commessage3=100;
						break;
					}
					if(wParam!=200)
					{
						countstatus2++;
						commessage3=wParam;					
						//MessageBox(hWnd,filename2,"filename2",MB_OK);
						ReleaseSemaphore(semaphor3,1,NULL);											
						_beginthread(playwave_to_modem2,0,NULL);
					}
				}
			}
			break;
	}
	return 0 ;
}




VOID FAR PASCAL lineCallbackFunc(	DWORD hDevice,             
									DWORD dwMsg,               
									DWORD dwCallbackInstance,  
									DWORD dwParam1,            
									DWORD dwParam2,            
									DWORD dwParam3             
								)
{
	temp=hDevice;
	_ltoa(temp,buffer,16);
//	MessageBox(hwnd,buffer,"!!! hDevice !!!!!",MB_OK);
	
	switch(dwMsg) 
   { 
   case LINE_CALLSTATE: 
       switch(dwParam1) 
		{ 
			case LINECALLSTATE_DISCONNECTED: /* your logic here*/; 
					SendMessage(ahwnd,32769,201, 0);  // Send request lineRelease
			
			break;
			case LINECALLSTATE_IDLE: /* your logic here */; 
			MessageBox(hwnd,"State_idle","test callback Initial",MB_OK);
			
			break;
			case LINECALLSTATE_CONNECTED:

				
			break;
			case LINECALLSTATE_BUSY: /* your logic here */; 
				MessageBox(hwnd,"bosy","test callback Initial",MB_OK);
			break;
/////////////////////////////////////////
/* This occor When first incoming ring */
/////////////////////////////////////////
			case LINECALLSTATE_OFFERING :
			//MessageBox(hwnd,"offering","test callback Initial",MB_OK);
				countstatus1++;
				statusline1=true;
			hcall = (HCALL)hDevice;
			temp=lineMonitorDigits(hcall,LINEDIGITMODE_DTMF );
			_ltoa(temp,buffer,16);
				if(temp!=0)
				{				
					MessageBox(hwnd,buffer,"Errpr line MonitorDigit",MB_OK);
				}
/*=================== Wave ==================*/
			VARSTRING  *vs;			
			DWORD dwSize;
			DWORD dwWaveDev;
			// allocate memory for structure
			vs = (VARSTRING *) calloc (1, sizeof(VARSTRING));
			// set structure size
			vs->dwTotalSize = sizeof(VARSTRING);
			do
			{
				temp=lineGetID(hline,0l,hcall,LINECALLSELECT_CALL,vs,"wave/out");
				_ltoa(temp,buffer,16);
					if(temp!=0)
					{				
						MessageBox(hwnd,buffer,"Return from Line_GetID -> 0 is Complete",MB_OK);
					}
				if(temp)
					MessageBox(hwnd,"!!!! LineGetID Error !!!!","Error",MB_OK);
				if (vs->dwTotalSize < vs->dwNeededSize) {
							dwSize = vs->dwNeededSize;
							free (vs);
							vs = (VARSTRING *) calloc(1, dwSize);
							vs->dwTotalSize = dwSize;
							continue;
					} /* end if (need more space) */
				break;
			}while(true);
			DWORD dwWaveOutID;
			dwWaveOutID=(DWORD) *((DWORD *)((LPSTR)vs + vs->dwStringOffset));
			free (vs);
			_ltoa(dwWaveOutID,buffer,16);
				/*if(temp!=0)         /// show waveoutid
				{				
					MessageBox(hwnd,buffer,"Wave Out ID",MB_OK);
				}*/							
////////////////  WaveID - > lineApp -> aztech
				dwWaveOutID1=dwWaveOutID;
			
			temp=lineAnswer(hcall,NULL,0);
				_ltoa(temp,buffer,16);
				if(temp!=0)
				{				
				//	MessageBox(hwnd,buffer,"Line_Answer",MB_OK);
				}	
				filename1="null.wav";								
				ReleaseSemaphore(semaphor2,1,NULL);
				_beginthread(playwave_to_modem,0,NULL);
				
			break;

			case LINECALLSTATE_ACCEPTED :
			//MessageBox(hwnd,"accept state","test callback ",MB_OK);
			break;
			case LINECALLSTATE_RINGBACK :
		//	MessageBox(hwnd,"ringback","test callback",MB_OK);
			break;
			case LINECALLSTATE_PROCEEDING:
		//	MessageBox(hwnd,"processs","test callback",MB_OK);
			break;	
			case LINECALLSTATE_UNKNOWN :
				MessageBox(hwnd,"UNKNOWM","test callback Initial",MB_OK);
			break;
			default : 
			break;
       }	
	case LINE_REPLY:
		//MessageBox(hwnd,"line reply","test callback line reply",MB_OK);
		break;	
	case LINE_LINEDEVSTATE:
		switch (dwParam1) 
			{
			case LINEDEVSTATE_RINGING:
		
				
				
					//	MessageBox(hwnd,"Ring","test callback line reply",MB_OK);				
				
                break;			
			}
		break;
	case LINE_MONITORDIGITS:

				switch (dwParam2) {
					case LINEDIGITMODE_DTMF:
					{
						SendMessage(ahwnd,32769,dwParam1,0);
				            if (LOBYTE(dwParam1) == '1') {
								/*char* cs;
								cs = (char*)malloc(20);
								filename1="c:\\ivrgreet.wav";
								//playwave_to_modem(cs);
								//playwave_to_modem(cs);
								ReleaseSemaphore(semaphor2,1,NULL);
								_beginthread(playwave_to_modem,0,NULL);
								//MessageBox(hwnd,"PUSH 1","Monitor digit",MB_OK);				
					              */
							}
							 else if (LOBYTE(dwParam1) == '2') {
								 //ReleaseSemaphore(semaphor1,1,NULL);	
								 //waveOutMessage(hWaveOut,WOM_DONE,0,0);

								//  MessageBox(hwnd,"PUSH 2","Monitor digit",MB_OK);				
							}                   
							 else if(LOBYTE(dwParam1)=='3'){
							/*	 ReleaseSemaphore(semaphor1,1,NULL);
								 filename1="c:\\et.wav";
								
								 _beginthread(playwave_to_modem,0,NULL);*/
							 }
							break;
					}
				break;			
            }
	case LINEDIGITMODE_DTMFEND:

          break;
	default:
	break;
   } 
		
} 



void err_mmioopen(int i)
{
	if(i==MMIOERR_ACCESSDENIED)
		MessageBox(hwnd,"accessdenied","error mmioopen",MB_OK);
	else if(i==MMIOERR_INVALIDFILE)
		MessageBox(hwnd,"invalidfile","error mmioopen",MB_OK);
	else if(i==MMIOERR_NETWORKERROR)
		MessageBox(hwnd,"MMIOERR_NETWORKERROR","error mmioopen",MB_OK);
	else if(i==MMIOERR_PATHNOTFOUND)
		MessageBox(hwnd,"MMIOERR_PATHNOTFOUND","error mmioopen",MB_OK);
	else if(i==MMIOERR_SHARINGVIOLATION)
		MessageBox(hwnd,"MMIOERR_SHARINGVIOLATION","error mmioopen",MB_OK);
	else if(i==MMIOERR_TOOMANYOPENFILES)
		MessageBox(hwnd,"MMIOERR_TOOMANYOPENFILES","error mmioopen",MB_OK);
	
}

void playwave_to_modem(void *cs)
{
	//ReleaseSemaphore(semaphor1,1,NULL);
	//while (WaitForSingleObject(semaphor1,300) != WAIT_OBJECT_0);
			 while (WaitForSingleObject(semaphor2,300) != WAIT_OBJECT_0);
			 commessage2=commessage;
				HWAVEOUT hWaveOut;				
				UINT  num;
				HMMIO   hmmio;
														
				long hmmioIn,ret;
				int errorCode;
		
				// receive All wave id
				num=waveOutGetNumDevs(); 
				
				// ================== Open Wavefile by mmioOpen Window API ================ //
				
			
				hmmio = mmioOpen(filename1,0, MMIO_READ | MMIO_ALLOCBUF );
				//hmmio = mmioOpen(cs,0, MMIO_READ | MMIO_ALLOCBUF );
				if( hmmio==NULL )								
				;//	MessageBox(hwnd,"!! Error mmioOpen","  mmio Error ",MB_OK);				

			
				//============ Call function to find wave data ================= //
				MMCKINFO parent;				
				memset(&parent,0,sizeof(MMCKINFO));

				parent.fccType = mmioFOURCC('W','A','V','E'); 

				mmioDescend(hmmio,&parent,0,MMIO_FINDRIFF);

					
				//========================= find format data ===========
				MMCKINFO child; 

				memset(&child,0,sizeof(MMCKINFO));

				child.fccType = mmioFOURCC('f','m','t',' '); 

				mmioDescend(hmmio,&child,&parent,0);
				//=============  Read format wave file =================== //
				WAVEFORMATEX wavefmt; // Variable wave Format 

				mmioRead(hmmio,(char*)&wavefmt,sizeof(wavefmt));

				if(wavefmt.wFormatTag != WAVE_FORMAT_PCM) 
				;
				//MessageBox(hwnd,"LoadDirectSound mmioOpen","ERRO WARNING",MB_OK); 
				//==================== find data =========== //
				mmioAscend(hmmio,&child,0);

				child.ckid = mmioFOURCC('d','a','t','a'); 

				mmioDescend(hmmio,&child,&parent,MMIO_FINDCHUNK);
				// ========= Allocate soundbuffer and read sound data
				HGLOBAL hmem;
				VOID *bufferin;
				GlobalFree(hmem);
				hmem = GlobalAlloc(0x40,child.cksize );
				bufferin = GlobalLock(hmem);
				ret = mmioRead(hmmio,(char*)bufferin,child.cksize );
				long numsample;
				numsample = child.cksize / wavefmt.nBlockAlign ;

////////////////////////////////////////////////////////////////////////				
				
				mmioClose(hmmio, 0);  
				//if(errorCode=waveOutOpen(&hWaveOut,(UINT)1, &PCMWaveFmtRecord, 0, 0,0)) 							
				if(errorCode=waveOutOpen(&hWaveOut,(UINT)dwWaveOutID1, &wavefmt,(DWORD)waveOutProc, 0,CALLBACK_FUNCTION )) 							
				{
					_itoa(errorCode,buffer,10);
					MessageBox(hwnd,buffer,"  Wave outopen  Error ",MB_OK);		
				}
				WAVEHDR WaveHeader;				
				WaveHeader.dwBufferLength =  numsample * wavefmt.nBlockAlign ;
				WaveHeader.lpData = (LPSTR) bufferin ;
				WaveHeader.dwFlags = WaveHeader.reserved = 0;
				//WaveHeader.dwLoops = 10;


				waveOutPrepareHeader(hWaveOut, &WaveHeader, sizeof(WaveHeader));
				//Write data to WAVE device.
				waveOutWrite(hWaveOut, &WaveHeader, sizeof(WaveHeader));
				//Loop until playback is finished.

		//		do {}
		//		while (!(WaveHeader.dwFlags & WHDR_DONE)); // inefficient busy wait!
				
			while (WaitForSingleObject(semaphor1,300) != WAIT_OBJECT_0);

				//Unprepare the wave output header.
				waveOutUnprepareHeader(hWaveOut, &WaveHeader, sizeof(WaveHeader));
				
				//Close the WAVE device.
				waveOutClose(hWaveOut);
									
				ReleaseSemaphore(semaphor2,1,NULL);	
				//MessageBox(hwnd,"close wave","close wave",MB_OK);	
				_endthread();
				
}

void playwave_to_modem2(void *cs)
{
				//ReleaseSemaphore(semaphor4,1,NULL);
				while (WaitForSingleObject(semaphor4,300) != WAIT_OBJECT_0);
				commessage4=commessage3;
				
				HWAVEOUT hWaveOut;				
				UINT  num;
				HMMIO   hmmio;
														
				long hmmioIn,ret;
				int errorCode;
		
				// receive All wave id
				num=waveOutGetNumDevs(); 
				
				// ================== Open Wavefile by mmioOpen Window API ================ //
				
				
				hmmio = mmioOpen(filename2,0, MMIO_READ | MMIO_ALLOCBUF );
				//hmmio = mmioOpen((char*)cs,0, MMIO_READ | MMIO_ALLOCBUF );
				if( hmmio==NULL )								
				;//	MessageBox(hwnd,"!! Error mmioOpen","  mmio Error ",MB_OK);				
				
				//============ Call function to find wave data ================= //
				MMCKINFO parent;				
				memset(&parent,0,sizeof(MMCKINFO));

				parent.fccType = mmioFOURCC('W','A','V','E'); 

				mmioDescend(hmmio,&parent,0,MMIO_FINDRIFF);

					
				//========================= find format data ===========
				MMCKINFO child; 

				memset(&child,0,sizeof(MMCKINFO));

				child.fccType = mmioFOURCC('f','m','t',' '); 

				mmioDescend(hmmio,&child,&parent,0);
				//=============  Read format wave file =================== //
				WAVEFORMATEX wavefmt; // Variable wave Format 

				mmioRead(hmmio,(char*)&wavefmt,sizeof(wavefmt));

				if(wavefmt.wFormatTag != WAVE_FORMAT_PCM) 
					;
			//	MessageBox(hwnd,"LoadDirectSound mmioOpen","ERRO WARNING",MB_OK); 
				//==================== find data =========== //
				mmioAscend(hmmio,&child,0);

				child.ckid = mmioFOURCC('d','a','t','a'); 

				mmioDescend(hmmio,&child,&parent,MMIO_FINDCHUNK);
				// ========= Allocate soundbuffer and read sound data
				HGLOBAL hmem;
				VOID *bufferin;
				GlobalFree(hmem);
				hmem = GlobalAlloc(0x40,child.cksize );
				bufferin = GlobalLock(hmem);
				ret = mmioRead(hmmio,(char*)bufferin,child.cksize );
				long numsample;
				numsample = child.cksize / wavefmt.nBlockAlign ;
				mmioClose(hmmio, 0);  
////////////////////////////////////////////////////////////////////////				
				//if(errorCode==waveOutOpen(&hWaveOut,(UINT)dwWaveOutID2, &wavefmt ,0,0,0))
				
				if(errorCode=waveOutOpen(&hWaveOut,(UINT)dwWaveOutID2, &wavefmt,(DWORD)waveOutProc2 , 0,CALLBACK_FUNCTION ))
				{
					_itoa(errorCode,buffer,10);
					MessageBox(hwnd,buffer,"  Wave outopen  Error ",MB_OK);		
				}
				WAVEHDR WaveHeader;				
				WaveHeader.dwBufferLength =  numsample * wavefmt.nBlockAlign ;
				WaveHeader.lpData = (LPSTR) bufferin ;
				WaveHeader.dwFlags = WaveHeader.reserved = 0;
				//WaveHeader.dwLoops = 10;
	

				waveOutPrepareHeader(hWaveOut, &WaveHeader, sizeof(WaveHeader));
				//Write data to WAVE device.
				waveOutWrite(hWaveOut, &WaveHeader, sizeof(WaveHeader));
				//Loop until playback is finished.
//				do {}
//				while (!(WaveHeader.dwFlags & WHDR_DONE)); // inefficient busy wait!
				

				while (WaitForSingleObject(semaphor3,300) != WAIT_OBJECT_0);
				//MessageBox(hwnd,"close","close",MB_OK);
				//Unprepare the wave output header.
				waveOutUnprepareHeader(hWaveOut, &WaveHeader, sizeof(WaveHeader));
											
				//Close the WAVE device.
				waveOutClose(hWaveOut);

				
				ReleaseSemaphore(semaphor4,1,NULL);	
				_endthread();
}


VOID FAR PASCAL lineCallbackFunc2(	DWORD hDevice,             
									DWORD dwMsg,               
									DWORD dwCallbackInstance,  
									DWORD dwParam1,            
									DWORD dwParam2,            
									DWORD dwParam3             
								)
{
	/*
	temp2=dwMsg;
	_ltoa(temp2,buffer2,16);
	strcat(buffer2,"   Msg callback");
	//temp2 = dwParam1;
	MessageBox(hwnd,buffer2,"test callback Initial",MB_OK);
	*/
	temp2=hDevice;
	_ltoa(temp2,buffer2,16);
//	MessageBox(hwnd,buffer2,"!!! hDevice !!!!!",MB_OK);
	
	switch(dwMsg) 
   { 
   case LINE_CALLSTATE: 
       switch(dwParam1) 
		{ 
			case LINECALLSTATE_DISCONNECTED: /* your logic here*/; 
				SendMessage(ahwnd,32769,201, 1);  // Send request lineRelease
				
			break;
			case LINECALLSTATE_IDLE: /* your logic here */; 
		//	MessageBox(hwnd,"State_idle","test callback Initial",MB_OK);
			
			break;
			case LINECALLSTATE_CONNECTED:

				
			break;
			case LINECALLSTATE_BUSY: /* your logic here */; 
		//		MessageBox(hwnd,"bosy","test callback Initial",MB_OK);
			break;
			case LINECALLSTATE_UNKNOWN :
		//		MessageBox(hwnd,"UNKNOWM","test callback Initial",MB_OK);
				break;
/////////////////////////////////////////
/* This occor When first incoming ring */
/////////////////////////////////////////
			case LINECALLSTATE_OFFERING :
				countstatus2++;
				statusline2=true;
		//	MessageBox(hwnd,"offering","test callback Initial",MB_OK);
			hcall2 = (HCALL)hDevice;
			temp2=lineMonitorDigits(hcall2,LINEDIGITMODE_DTMF );
			_ltoa(temp2,buffer2,16);
				if(temp2!=0)
				{				
					MessageBox(hwnd,buffer2,"Errpr line MonitorDigit",MB_OK);
				}
/*=================== Wave ==================*/
			VARSTRING  *vs;			
			DWORD dwSize;
			DWORD dwWaveDev;
			// allocate memory for structure
			vs = (VARSTRING *) calloc (1, sizeof(VARSTRING));
			// set structure size
			vs->dwTotalSize = sizeof(VARSTRING);
			do
			{
				temp2=lineGetID(hline2,0l,hcall2,LINECALLSELECT_CALL,vs,"wave/out");
				_ltoa(temp2,buffer2,16);
					if(temp2!=0)
					{				
						MessageBox(hwnd,buffer2,"Return from Line_GetID -> 0 is Complete",MB_OK);
					}
				if(temp2)
					MessageBox(hwnd,"!!!! LineGetID Error !!!!","Error",MB_OK);
				if (vs->dwTotalSize < vs->dwNeededSize) {
							dwSize = vs->dwNeededSize;
							free (vs);
							vs = (VARSTRING *) calloc(1, dwSize);
							vs->dwTotalSize = dwSize;
							continue;
					} /* end if (need more space) */
				break;
			}while(true);
			DWORD dwWaveOutID;
			dwWaveOutID=(DWORD) *((DWORD *)((LPSTR)vs + vs->dwStringOffset));
			free (vs);
			_ltoa(dwWaveOutID,buffer2,16);
				/*if(temp2!=0)
				{				
					MessageBox(hwnd,buffer2,"Wave Out ID",MB_OK);
				}*/							
////////////////  WaveID - > lineApp -> aztech
				dwWaveOutID2=dwWaveOutID;
				temp2=lineAnswer(hcall2,NULL,0);
				_ltoa(temp2,buffer2,16);
				if(temp2!=0)
				{				
				//	MessageBox(hwnd,buffer2,"Line_Answer",MB_OK);
				}		
				filename2="null.wav";	
				ReleaseSemaphore(semaphor4,1,NULL);	
				_beginthread(playwave_to_modem2,0,NULL);	
			break;

			case LINECALLSTATE_ACCEPTED :
			//MessageBox(hwnd,"accept state","test callback ",MB_OK);
			break;
			case LINECALLSTATE_RINGBACK :
			//MessageBox(hwnd,"ringback","test callback",MB_OK);
			break;
			case LINECALLSTATE_PROCEEDING:
			MessageBox(hwnd,"processs","test callback",MB_OK);
			break;	
			default : 
			break;
       }	
	case LINE_REPLY:
		//MessageBox(hwnd,"line reply","test callback line reply",MB_OK);
		break;	
	case LINE_LINEDEVSTATE:
		switch (dwParam1) 
			{
			case LINEDEVSTATE_RINGING:
		
				
				
					//	MessageBox(hwnd,"Ring","test callback line reply",MB_OK);				
				
                break;			
			}
		break;
	case LINE_MONITORDIGITS:

				switch (dwParam2) {
					case LINEDIGITMODE_DTMF:
					{
							
							SendMessage(ahwnd,32769,dwParam1, 1);

				            if (LOBYTE(dwParam1) == '1') {
							/*	char* cs;
								cs = (char*)malloc(20);
								//cs="c:\\IVRGreet.wav";
								filename2="c:\\gpa.wav";
								_beginthread(playwave_to_modem2,0,NULL);

								//playwave_to_modem2(cs);
							*/
								
							}
							 else if (LOBYTE(dwParam1) == '2') {
							//	 ReleaseSemaphore(semaphor2,1,NULL);	
								  //MessageBox(hwnd,"PUSH 2","Monitor digit",MB_OK);				
							
							}                        						                    
							break;
					}
				break;			
            }
	case LINEDIGITMODE_DTMFEND:

          break;
	default:
	break;
   } 
		
} 

void CALLBACK waveOutProc(
  HWAVEOUT hwo,      
  UINT uMsg,         
  DWORD dwInstance,  
  DWORD dwParam1,    
  DWORD dwParam2     )
{
	
	//MessageBox(hwnd,"CALLBACK","WAVEOUTPROC",MB_OK);
	switch(uMsg)
	{
	case WOM_OPEN:		
		//	MessageBox(hwnd,"WOM_OPEN","CALLBACK OF WAVEOUTPROC",MB_OK);
			break;
	case WOM_DONE:	
		/*
		//	MessageBox(hwnd,"WOM_DONE1","CALLBACK OF WAVEOUTPROC",MB_OK);
				LPWAVEHDR   pwh ;
				pwh = (LPWAVEHDR)dwParam1;
				do{}
				while(!((*pwh).dwFlags & WHDR_DONE));
		//MessageBox(hwnd,"WOM_DONE","CALLBACK OF WAVEOUTPROC",MB_OK);
			
		//Unprepare the wave output header.	
				waveOutReset(hwo);
				waveOutUnprepareHeader(hwo,pwh,sizeof(*pwh));
				//waveOutUnprepareHeader(hwo, (WAVEHDR*)dwParam1,sizeof(*((WAVEHDR*)dwParam1)));											
				//Close the WAVE device.
				waveOutClose(hwo);				 
		*/	
		//	ReleaseSemaphore(semaphor2,1,NULL);
				
		SendMessage(ahwnd,32769,commessage2, 0);
		//MessageBox(hwnd,"WOM_DONE","CALLBACK OF WAVEOUTPROC",MB_OK);
			break;	
	case WOM_CLOSE:		
		break;
	default:;
	}
	
}

void CALLBACK waveOutProc2(
  HWAVEOUT hwo,      
  UINT uMsg,         
  DWORD dwInstance,  
  DWORD dwParam1,    
  DWORD dwParam2     )
{
	
	//MessageBox(hwnd,"CALLBACK","WAVEOUTPROC",MB_OK);
	switch(uMsg)
	{
	case WOM_OPEN:		
			//MessageBox(hwnd,"WOM_OPEN","CALLBACK OF WAVEOUTPROC",MB_OK);
			break;
	case WOM_DONE:	
		
		//	MessageBox(hwnd,"WOM_DONE1","CALLBACK OF WAVEOUTPROC",MB_OK);
		/*		LPWAVEHDR   pwh ;
				pwh = (LPWAVEHDR)dwParam1;
				do{}
				while(!((*pwh).dwFlags & WHDR_DONE));
		//MessageBox(hwnd,"WOM_DONE","CALLBACK OF WAVEOUTPROC",MB_OK);
			
		//Unprepare the wave output header.										
				waveOutUnprepareHeader(hwo,pwh,sizeof(*pwh));
				//waveOutUnprepareHeader(hwo, (WAVEHDR*)dwParam1,sizeof(*((WAVEHDR*)dwParam1)));											
				//Close the WAVE device.
				waveOutClose(hwo);				 
			//	MessageBox(hwnd,"WOM_DONE2","CALLBACK OF WAVEOUTPROC",MB_OK);*/
		//	ReleaseSemaphore(semaphor4,1,NULL);
			SendMessage(ahwnd,32769,commessage4, 1);
			break;	
	case WOM_CLOSE:		
		break;
	default:;
	}
	
}

void checknull1(void *cs)
{
	int oldvalue;
	oldvalue=countstatus1;
	while(true)
	{
		Sleep(delay);
		if((statusline1==true)&&(oldvalue==countstatus1))
		{
			SendMessage(ahwnd,32769,201, 0);  // Request lineRelease			
			//MessageBox(hwnd,"very Delay 1 ","Close This Line",MB_OK);
		}
		else
		{
			oldvalue=countstatus1;
		}

	}
	_endthread();
}

void checknull2(void *cs)
{
	int oldvalue;
	oldvalue=countstatus2;
	while(true)
	{
		Sleep(delay);
		if((statusline2==true)&&(oldvalue==countstatus2))
		{
			SendMessage(ahwnd,32769,201, 1);  // Request lineRelease
			//MessageBox(hwnd,"very Delay 2","Close This Line",MB_OK);
			
		}
		else
		{
			oldvalue=countstatus2;
		}

	}
		_endthread();
}