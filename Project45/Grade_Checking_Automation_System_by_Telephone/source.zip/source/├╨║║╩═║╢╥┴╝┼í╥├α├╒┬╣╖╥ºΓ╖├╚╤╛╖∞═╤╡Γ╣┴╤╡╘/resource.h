//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by rc1.rc
//
#define IDC_COMBO1                      1005
#define IDC_START1                      1006
#define IDC_COMBO2                      1007
#define IDC_START2                      1008
#define IDC_STATUS1                     1012
#define IDC_STATUS2                     1013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
