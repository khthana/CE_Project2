package Server_Center;

import java.awt.*;
import java.sql.*;
import java.io.*;
import java.net.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Thread_Main extends Thread
{
  private ServerSocket server;
  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;


  //Conection Con;

  public void run()
  {
      try
      {
         // Step 1: Create a ServerSocket.
         server = new ServerSocket( 6000 );
         while ( true )
         {
            // Step 2: Wait for a connection.
            System.out.println ("Wait for a connection.");
            connection = server.accept();
            //connection.setSoTimeout(3000);
            // Step 3: Get input and output streams.]
            input = connection.getInputStream();
            output = connection.getOutputStream() ;
            din = new DataInputStream( input );
            dout = new DataOutputStream( output );
            // Step 4: Process connection.  //wait for command until get 0
            System.out.println ("Waiting for command.");
            //Conection Con = new Conection(connection);
            processCommand(connection);
            // Step 5: Close connection.
            System.out.println ("Remote>> Closing Connection.");
            close();
         }
      }catch(InterruptedIOException e)
      {
          System.out.println ("RemoteClient>> socket time out : "+e);
      }catch(IOException e)
      {
          System.out.println ("RemoteClient>> Problem with IO : "+e);
      }catch(NullPointerException e)
      {
          System.out.println ("RemoteClient>> "+e);
      }
  }

// New Connection for User //
  void processCommand(Socket connection) throws IOException
  {
     Conection Con;
     Con = new Conection(connection);
  }
  void close() throws IOException
   {
    din.close();
    dout.close();
    connection.close();
   }
   public static void main(String[] args)
  {
    new Thread_Main().start();
  }

}