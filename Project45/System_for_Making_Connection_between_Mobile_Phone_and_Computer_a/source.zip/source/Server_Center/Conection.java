package Server_Center;

import javax.swing.UIManager;
import java.awt.*;
import java.sql.*;
import java.io.*;
import java.net.*;
import Protocol.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Conection
{
  String sql=null;
  private DataInputStream din;
  private DataOutputStream dout;
// Set defult Parameter //
  private String NameT = null;
  private String IpT = null;
  private String AuthorityT= "Custom";
  private String GroupT = "Non Group";
  private String PassT = "";

  private Thread_Main ThreadT;
// Parameter ODBC //
  String driverName = "sun.jdbc.odbc.JdbcOdbcDriver";
  String connectionURL = "jdbc:odbc:Server_DB";

  public Conection(Socket sock) throws IOException
  {
/*    try
    {
      din = new DataInputStream( sock.getInputStream());
      dout = new DataOutputStream( sock.getOutputStream());
// Receive Protocol from Network //
      FMPrequest req = new FMPrequest(din);
// Separate Protocol //
      int command = req.getMethod();
      NameT = req.getName();
      IpT = sock.getInetAddress().getHostAddress();
      PassT = req.getParameter();
      GroupT = req.getGroup();
// Check Command //
      switch(command)
      {
        case 0 : Log_in(NameT,IpT,AuthorityT,GroupT,PassT); break;
        case 1 : Log_out(NameT); break;
        case 2 : Register(NameT,IpT,AuthorityT,GroupT,PassT); break;

        default : break;
      }
    }
      catch (Exception e)
      {
         e.printStackTrace();
      }
  }

  void close() throws IOException
   {
    din.close();
    dout.close();
   }
// Method LOGIN //
   void Log_in(String NameT,String IpT,String AuthorityT,String GroupT,String PassT) throws IOException
   {
     try
     {
       // Set ODBC //
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql ="Select * FROM Server_DB WHERE NAME ='"+NameT+"'";
       ResultSet m = null;
       m = stmt.executeQuery(sql);
       int j = 0;
       //Check Password //
       while (m.next())
       {
           if (PassT.equals(m.getString("Pass"))  )  { j=1; }
       }

       // If password Correct //
       if (j==1)
       {
          sql = "UPDATE Server_DB SET STATUS ='Online' WHERE NAME = '"+NameT+"'";
          stmt.executeUpdate(sql);

          sql = "Select * FROM Server_DB WHERE NAME = '"+NameT+"' and Pass ='"+PassT+"'";
          ResultSet  n= null;
          n = stmt.executeQuery(sql);

          // Get Authority and Group //
          while (n.next())
          {
            AuthorityT = n.getString("Authority");
            GroupT = n.getString("GROUP");
          }
          // User haven't Group //
          if(GroupT.equals("Non Group"))
          {
            sql = "Select * FROM Server_DB WHERE STATUS = 'Online' and [GROUP] = 'Non Group'";
            ResultSet t = null;
            t = stmt.executeQuery(sql);

            int i=0;
            while(t.next()) {i++;}

            ResultSet r = null;
            r = stmt.executeQuery(sql);

            String[] Username = new String[i];
            String[] Ip = new String[i];
            int k = 0;

            // Get Name and Group //
            while(r.next())
            {
              Username[k] = r.getString("NAME");
              Ip[k]=r.getString("IP");
              k++;
            }
            // Send Name and IP User who Online and haven't Group to User who Login //
            FMPresponse res = new FMPresponse(FMPresponse.OK);
            res.setUsername(Username,Ip);
            res.sendResponse(dout);

          }else
          // User have Group //
          {
            sql = "Select * FROM Server_DB WHERE STATUS = 'Online' and [GROUP] = '"+GroupT+"'";
            ResultSet t = null;
            t = stmt.executeQuery(sql);

            int i=0;
            while(t.next()) {i++;}

            ResultSet r = null;
            r = stmt.executeQuery(sql);

            String[] Username = new String[i];
            String[] Ip = new String[i];
            int k = 0;

            // Get Name and IP //
            while(r.next())
            {
              Username[k] = r.getString("NAME");
              Ip[k]=r.getString("IP");
              k++;
            }
            // Send Name and IP User who Online and have same Group to User who Login //
            FMPresponse res = new FMPresponse(FMPresponse.OK);
            res.setUsername(Username,Ip);
            res.sendResponse(dout);
          }
        }else
        // Password Incorrect //
        {
        FMPresponse res = new FMPresponse(FMPresponse.FAIL);
        res.setMessage("Password incorrect.");
        }

       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

// Method LOGOUT //
   void Log_out(String NameT) throws IOException
   {
     try
     {
       // Set ODBC //
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql ="Select * FROM Server_DB WHERE NAME ='"+NameT+"'";
       ResultSet n = null;
       n = stmt.executeQuery(sql);

       while (n.next())
       {
           // Same user Name who Logout //
           if (NameT.equals(n.getString("NAME"))  )
           {
             sql = "UPDATE Server_DB SET STATUS = 'Offline' WHERE NAME = '"+NameT+"'";
             stmt.executeUpdate(sql);
             // Return response OK//
             FMPresponse res = new FMPresponse(FMPresponse.OK);
             res.setMessage("Logout Complete");
             res.sendResponse(dout);
           }else
           // Haven't same user Name who Login //
           {
             // Return response Fail//
             FMPresponse res = new FMPresponse(FMPresponse.FAIL);
             res.setMessage("Can't Logout");
             res.sendResponse(dout);
           }
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

// Method REGISTER //
   void Register(String NameT,String IpT,String AuthorityT,String GroupT,String PassT) throws IOException
   {
     try
     {
       // Set ODBC //
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM Server_DB ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;

       // Check already Name //
       while(j.next())
       {
         if(NameT.equals(j.getString("NAME") ))   {i = -1;}
       }

       // Don't already Name //
       if (i == 1)
       {
         sql = "INSERT INTO Server_DB(NAME,IP,STATUS,Authority,[GROUP],Pass) VALUES('"+NameT+"','"+IpT+"','Online','"+AuthorityT+"','"+GroupT+"','"+PassT+"')";
         stmt.executeUpdate(sql);

         // Return Response OK //
         FMPresponse res = new FMPresponse(FMPresponse.OK);
         res.sendResponse(dout);
       }else
       // Already Name //
       {
         //Return Response Fail //
         FMPresponse res = new FMPresponse(FMPresponse.FAIL);
         res.setMessage("Name Already Exist...!!!");
         res.sendResponse(dout);
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
*/   }

}