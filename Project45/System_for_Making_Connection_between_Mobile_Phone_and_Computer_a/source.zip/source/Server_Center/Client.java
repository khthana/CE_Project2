package Server_Center;

import java.awt.*;
import java.io.*;
import java.net.*;
import javax.swing.*;

public class Client extends JFrame {
  static final int Login = 0;
  static final int Logout = 1;
  static final int Regist = 2;
  private Socket socket;
  private DataInputStream din;
  private DataOutputStream dout;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea textArea = new JTextArea();
  private JLabel jLabel1 = new JLabel();

  public Client() {
    try{
      jbInit();
      socket = new Socket("127.0.0.1",6000);
      din = new DataInputStream(socket.getInputStream());
      dout = new DataOutputStream(socket.getOutputStream());

      //register();
      login();
      //logout();

      din.close();
      dout.close();
      socket.close();
    }catch(IOException e){
      textArea.append("\n\nCan not connect server!!");
      System.err.println("Can not connect server!!");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    Client client = new Client();
    client.setVisible(true);
  }

  void login() throws IOException
  {
    dout.writeInt(Login);
    dout.writeUTF("BBB");
    dout.writeUTF("161.246.5.50");
    //wait for list of online user
    int j = din.readInt();
    if (j ==1)
    {
      int i = din.readInt();
      for(int x = 0; x<i ;x++)
      {
        textArea.append("\n"+din.readUTF());
        textArea.append("     "+din.readUTF());
      }
    }else
    {
        textArea.append("\n"+din.readUTF());
    }
  }

  void logout() throws IOException
  {
    dout.writeInt(Logout);
    dout.writeUTF("AAA");
    dout.writeUTF("161.246.5.45");
    //wait for list of online user
    textArea.append("\n"+din.readUTF());
  }

  void register() throws IOException
  {
    dout.writeInt(Regist);
    dout.writeUTF("EEE");
    dout.writeUTF("161.246.5.67");
    //wait for list of online user
    textArea.append("\n"+din.readUTF());
  }

  private void jbInit() throws Exception {
    jLabel1.setText("List of online User");
    this.getContentPane().add(jScrollPane1, BorderLayout.CENTER);
    this.getContentPane().add(jLabel1, BorderLayout.NORTH);
    jScrollPane1.getViewport().add(textArea, null);
  }
}