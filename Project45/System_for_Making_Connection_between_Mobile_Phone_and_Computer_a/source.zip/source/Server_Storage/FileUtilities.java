package server_storage;
import java.io.*;
import javax.swing.filechooser.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public final class FileUtilities {

  public FileUtilities() {
  }

  // parameter -String full path of file
  // return -InputStream of this file if exists
  //        -null if this path is not file or not exists
  public InputStream getFileInputStream(String src) throws IOException{
    File file = new File(src);
    if (file.isFile()) {
      FileInputStream fin = new FileInputStream(file);
      return fin;
    }else return null;
  }

  public byte[] getFile(String src) {
    try {
      File f = new File(src);
      FileInputStream fin = new FileInputStream(f);
      Long l = new Long(f.length());
      byte b[] = new byte[l.intValue()];
      fin.read(b);
      return b;
    }
    catch (Exception ex) {
      return null;
    }
  }

  public boolean writeFile(String filepath, byte[] b) {
    try {
      File f = new File(filepath);
      FileOutputStream fout = new FileOutputStream(f);
      fout.write(b);
      return true;
    }
    catch (Exception ex) {
      return false;
    }
  }


  // parameter -InputStream stream that contain file data stream
  //           -String full path of this file
  // return -true if file have been write successful
  //        -false if file already exists or occured Exception while writing this file
  public boolean writeFile(InputStream in,String path) throws IOException{
    File file = new File(path);
    if (file.exists()){
      return false;
    }
    BufferedInputStream bin = new BufferedInputStream(in);
    DataInputStream din = new DataInputStream(bin);

    FileOutputStream fout = new FileOutputStream(file);
    BufferedOutputStream bout = new BufferedOutputStream(fout);
    DataOutputStream dout = new DataOutputStream(bout);

    try {
      while (true)
        dout.writeByte(din.readByte());
    }catch (EOFException ex) {
      dout.close();
      return true;
    }catch (Exception e){
      return false;
    }
  }

  // parameter -String full path of source file or folder
  //           -String full path of destination folder
  //           (!!important!! "dest" is a path of folder that is placed "src")
  // return -true if file have been write successful
  //        -false if file already exists or occured Exception while writing this file
  public static boolean copy(String src, String dest) throws FileNotFoundException, IOException{
    File fsrc = new File(src);
    File fdest = new File(dest+File.separator+fsrc.getName());
    if (fdest.exists() || (!fsrc.exists()))
      return false;
    else if (fsrc.isDirectory()){ //selected path is folder
      if(fdest.mkdir()){  // try to create new folder
        String[] list = fsrc.list();
        for (int i = 0; i < list.length; i++) {
          // copy all files in this folder
          if(!copy(fsrc.getPath()+File.separator+list[i],fdest.getPath())){
            fdest.delete();
            return false;
          }
        }
        return true;
      }else return false;
    }else{
        FileInputStream fin = new FileInputStream(fsrc);
        DataInputStream din = new DataInputStream(fin);

        FileOutputStream fout = new FileOutputStream(fdest);
        DataOutputStream dout = new DataOutputStream(fout);

        try{
          while (true)
            dout.writeByte(din.readByte());
        }catch(EOFException e){
          din.close();
          dout.close();
          return true;
        }
    }
 }

// parameter -String full path of file to delete
// return -true if file have been delete successful
//        -false if file already exists or occured Exception while deleting this file
 public boolean delete(String path) {
   File file = new File(path);
   //if this file is folder,
   if(file.isDirectory()){
     String[] list = file.list();
     for (int i = 0; i < list.length; i++) {
       if(!delete(file.getPath()+File.separator+list[i]))
         return false;
     }
   }
  return file.delete();
 }

 // parameter -String full path of this file
 //           -String new name of this file
 // return -true if file have been rename successfully
 //        -false if file not found
 //        -throws Exception if this file cannot access
 public boolean rename(String path,String name) throws SecurityException{
   try {
     return new File(path).renameTo(new File(name));
   }
   catch (NullPointerException ex) {
     return false;
   }
 }

 // parameter -String full path of parent
 //           -String new name of new folder
 // return -true if file have been rename successfully
 //        -false if file not fail
 //        -throws Exception if this file cannot access
 public boolean createFolder(String path,String name) throws SecurityException{
     return new File(path, name).mkdir();
 }

 public boolean isSystemFile(File file){
   FileSystemView fsv = FileSystemView.getFileSystemView();
   return fsv.isRoot(file);
 }


}