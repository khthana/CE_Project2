package server_storage;

import java.net.*;
import java.io.*;
import Protocol.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ServerThread extends Thread{
  private ServerSocket server;
  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;
  private boolean done = false;
  private String username;
  private String password;
  // Set parameter ODBC //
  private String driverName = "sun.jdbc.odbc.JdbcOdbcDriver";
  private String connectionURL = "jdbc:odbc:Storage_DB";

  public ServerThread()
  {

  }

  public void run(){
    try {
      // Step 1: Create a ServerSocket.
      server = new ServerSocket( 6000 );
     // server.accept();
      while ( !done ) {
        // Step 2: Wait for a connection.
        System.out.println ("Wait for a connection.");
        connection = server.accept();
        input = connection.getInputStream();
        output = connection.getOutputStream() ;
        din = new DataInputStream( input );
        dout = new DataOutputStream( output );
        verifyPassword();
      }
    }catch(IOException ex){
    }
  }

// Check Password //
  public void verifyPassword()
  {
   try
   {
    // Receive Request protocol //
    FMPrequest req = new FMPrequest(din);

    // Check method Connect //
    if(FMPrequest.CONNECT == req.getMethod())
    {
      // Set ODBC //
      Class.forName(driverName).newInstance();
      Connection con = DriverManager.getConnection(connectionURL);
      Statement stmt = con.createStatement();

      String sql = "Select * FROM Server_DB WHERE NAME ='"+req.getName()+"'";
      ResultSet j = null;
      j = stmt.executeQuery(sql);
      int i=1;

      // Check password //
      while(j.next())
      {
         String PassT = null;
         PassT = req.getParameter();
         if(PassT.equals(j.getString("Pass") ))   {i = -1;}
      }
      // Password correct //
      if (i == 1)
      {
         req.readGroup();
         // New connection for User //
         new RemoteClient(connection,req.getName(),req.getGroup()).start();
      }else
      // Password Incorrect //
      {
         // Return response Fail //
         FMPresponse res = new FMPresponse(FMPresponse.FAIL);
         res.setMessage("Password incorrect.");
      }
      stmt.close();
      con.close();
    }
  }catch(Exception e)
  {

  }
}
  public void setDone(boolean b)
  {
    done = b;
  }

  public static void main(String[] args)
  {
    new ServerThread().start();
  }

}