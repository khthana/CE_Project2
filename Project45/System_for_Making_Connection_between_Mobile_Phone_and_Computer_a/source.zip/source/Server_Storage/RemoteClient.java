package server_storage;

import java.net.*;
import java.io.*;
import Protocol.*;
import java.util.*;
import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author Kwanduen Saelew
 * @version 1.0
 */

public class RemoteClient extends Thread  {
  //flag check client is mobile?
  private boolean isMobile;
  private boolean done = false;

  private FileUtilities fileUtil = new FileUtilities();

  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;
  // Set parameter ODBC //
  private String driverName = "sun.jdbc.odbc.JdbcOdbcDriver";
  private String connectionURL = "jdbc:odbc:Storage_DB";

  public RemoteClient(Socket socket,String NameT,String GroupT)
  {
    connection = socket;
    try {
      input = connection.getInputStream();
      output = connection.getOutputStream() ;
      din = new DataInputStream( input );
      dout = new DataOutputStream( output );

      FMPresponse res = new FMPresponse(FMPresponse.OK);
      res.sendOKListResponse(Check_Group(NameT,GroupT),dout);
    }
    catch (Exception ex) {
      System.out.println("new remoteclient error !!!");
    }
  }

  public void run(){
    try {
       // Step 1: Create a ServerSocket.
       while ( !done ) {
          // Step 2: Wait for a command.
          // Step 3: Get Request.
         FMPrequest req = new FMPrequest(din);
         // Step 4: Process connection.
         //System.out.println ("Waiting for command.");
         processCommand(req);
         // Step 5: Close connection.
       }
       close();
    }catch(Exception e){
        System.out.println ("IO ERROR : "+e);
    }
  }


  void processCommand(FMPrequest req) throws IOException{

      int command = req.getMethod();
      switch(command)
      {
        case FMPrequest.CONNECT : connect();
          break;
        case FMPrequest.COPY : copy(req.getPath(), req.getName(), req.getParameter());
          break;
        case FMPrequest.DELETE : delete(req.getPath(), req.getName());
          break;
        case FMPrequest.DISCONNECT : done = true;
          break;
        case FMPrequest.DOWNLOAD : download(req.getPath(), req.getName());
          break;
        case FMPrequest.FOLDERUP : getParent(req.getPath());
          break;
        case FMPrequest.MOVE : move(req.getPath(), req.getName(), req.getParameter());
          break;
        case FMPrequest.OPENFOLDER : openfolder(req.getPath(), req.getName());
          break;
        case FMPrequest.PROPERTY : getProperty(req.getPath(), req.getName());
          break;
        case FMPrequest.RENAME : rename(req.getPath(), req.getName(), req.getParameter());
          break;
        case FMPrequest.SYNC : sendAck();
          break;
        case FMPrequest.UPLOAD : upload(req.getPath(), req.getName(), req.getContent(),req.getLength(),req.getAuthority());
          break;
        case FMPrequest.NEWFOLDER : newFolder(req.getPath(), req.getName());
          break;
        default : break;
      }
   }

   void connect(){
     sendFailResponse("You've already connected");
   }

   void sendOKListResponse(String path){
     try {
       FMPresponse res = new FMPresponse(FMPresponse.OK);
       res.setPath(path);

       File f = new File(path);
       File list[] = f.listFiles();
       //write all list in content
       ByteArrayOutputStream bout = new ByteArrayOutputStream();
       DataOutputStream dbout = new DataOutputStream(bout);
       // write number of file
       dout.writeInt(list.length);
       for (int i = 0; i < list.length; i++) {
         dbout.writeUTF(list[i].getName());  // file name
         if(list[i].isDirectory())
           dbout.writeInt(0);  // folder type
         else //if(list[i].isFile())
           dbout.writeInt(1);  // file type
       }
       res.setContent( bout.toByteArray());
       res.sendResponse(dout);
     }
     catch (Exception ex) {

     }
   }

   void sendAck(){
     FMPresponse res = new FMPresponse(FMPresponse.ACK);
     res.sendResponse(dout);
   }

   void print(String path , String name, byte[] file){
     //FMPresponse res = new FMPresponse(FMPresponse.OK);

   }

   void runCommand(String path, String cmdline){
     if(cmdline != null){
       StringTokenizer tokens = new StringTokenizer(cmdline);
       Runtime rt = Runtime.getRuntime();
       InputStream is;
       int i = 0;
       String par[] = new String[tokens.countTokens()];
       while(tokens.hasMoreTokens())
         par[i++] = tokens.nextToken();

       try {
         is = rt.exec(par, null, new File(path)).getInputStream();
         StringBuffer buf = new StringBuffer();
         int data = 0;
         while((data = is.read())!=-1){
           buf.append((char) data);
         }
       }catch (IOException ex) {
         sendFailResponse("Exception occured while execute command");
       }
     }else sendFailResponse("command is null");
  }

  void upload(String path, String NameT, byte[] file,int File_SizeT,String AuthorityT) throws IOException
  {
   try
   {
    if(Check_Size(NameT,File_SizeT,AuthorityT))
    {
      if( fileUtil.writeFile(path+File.separator+NameT, file))
      {
        Add_Size(NameT,File_SizeT);
        sendOKListResponse(path);
      }else sendFailResponse("Cannot upload this file");
    }
   }catch (Exception e){}
  }

// Method check Size before Save file //
  public boolean Check_Size(String NameT,int File_Size,String AuthorityT) throws Exception
  {
    String Limit_SizeT = null;
    Class.forName(driverName).newInstance();
    Connection con = DriverManager.getConnection(connectionURL);
    Statement stmt = con.createStatement();

    String sql = "Select * FROM TYPE";
    ResultSet  at= null;
    at = stmt.executeQuery(sql);

    while(at.next())
    {
      String p=null;
      p=at.getString("TYPE");

      // Set Limit Size from Database//
      if (p.equals(AuthorityT)) Limit_SizeT = at.getString("TYPE_SIZE");
    }

    sql = "Select * FROM Server_DB WHERE NAME = '"+NameT+"'";
    ResultSet  au= null;
    au = stmt.executeQuery(sql);

    // Check size //
    if( ( Integer.parseInt(au.getString("SIZE"))+ File_Size ) <= Integer.parseInt(Limit_SizeT))
      {
         stmt.close();
         con.close();
         return true;
      }
    else
      {
         stmt.close();
         con.close();
         return false;
      }
  }

// Method Add size //
  public void Add_Size(String NameT,int File_SizeT) throws Exception
  {
    // Set ODBC //
    Class.forName(driverName).newInstance();
    Connection con = DriverManager.getConnection(connectionURL);
    Statement stmt = con.createStatement();

    String sql = "Select * FROM Server_DB WHERE NAME = '"+NameT+"'";
    ResultSet  au= null;
    au = stmt.executeQuery(sql);

    // Add userd size to Database //
    int tmp_s = Integer.parseInt(au.getString("SIZE")) + File_SizeT;
    sql = "UPDATE Server_DB SET SIZE='"+tmp_s+"' WHERE NAME = '"+NameT+"'" ;
    stmt.executeUpdate(sql);

    stmt.close();
    con.close();
   }

// Method Check Group //
   public String Check_Group(String NameT,String GroupT)
  {
      String PathT = "C:/";

      if(GroupT.equals("Non Group"))
      {
        // User haven't Group //
        PathT = PathT+NameT;
        File f = new File(PathT);
        if(f.exists() == false) newFolder("C:/",NameT);
      }
      else
      {
        // User have Group //
        PathT = PathT+GroupT;
        File f = new File(PathT);
        if(f.exists() == false) newFolder("C:/",GroupT);
      }
      return PathT;
   }

  void delete(String path, String name) throws IOException{
    if(fileUtil.delete(path+File.separator+name)){
      sendOKListResponse(path);
    }else{
      sendFailResponse("Cannot delete this file");
    }
  }

  void download(String path, String name) throws IOException{
 //   InputStream in = fileUtil.getFileInputStream(path+File.separator+name);
    File f = new File(path+File.separator+name);
    byte[] b =fileUtil.getFile(path+File.separator+name);
    if(b!=null){
      FMPresponse res = new FMPresponse(FMPresponse.OK);
      res.setPath(f.getParent());
      res.setName(f.getName());
      res.setType("Unknown");
      res.setContent(b);
    }else
    {
      FMPresponse res = new FMPresponse(FMPresponse.FAIL);
    }
  }

  void rename(String path, String name, String newname) throws IOException{
    File f = new File(path,name);
    File f2 = new File(path,newname);
    if(f.renameTo(f2)){
      sendOKListResponse(path);
    }else sendFailResponse("Cannot rename this file !!!");

  }
  void sendOKResponse(){
    FMPresponse res = new FMPresponse(FMPresponse.OK);
    res.sendResponse(dout);
  }

  void sendFailResponse(String msg){
    FMPresponse res = new FMPresponse(FMPresponse.FAIL);
    res.setMessage(msg);
    res.sendResponse(dout);
  }

  void newFolder(String path, String name) {
    if(fileUtil.createFolder(path,name)){
      sendOKListResponse(path);
    }else
      sendFailResponse("Cannot create new folder");
  }

  void getProperty(String path, String name) {
    File f = new File(path, name);
    if(f.exists()){
      FMPresponse res = new FMPresponse(FMPresponse.OK);
   //  res.setType(f.);
    }
    else this.sendFailResponse("File not exists.");
  }

  void getParent(String path){
    File f = new File(path);
    if(f.exists() && !f.getParent().equals("C:/"))
      sendOKListResponse(f.getParent());
    else sendFailResponse("File not exists");
  }

  void copy(String path, String name, String copyPath)throws IOException{
    if( fileUtil.copy(path+File.separator+name, copyPath) ){
      sendOKListResponse(path);
    }else{
      sendFailResponse("cannot copy");
    }
  }

  void move(String path, String name, String movePath)throws IOException{
    if( fileUtil.copy(path+File.separator+name, movePath) ){
      fileUtil.delete(path+File.separator+name);
      sendOKListResponse(path);
    }else sendFailResponse("Cannot move this file.");
  }

  void openfolder(String path, String name)throws IOException{
    File f = new File(path, name);
    sendOKListResponse(f.getParent());
  }

  void close() {
    try{
      din.close();
      dout.close();
      connection.close();
    }catch(IOException e){
      System.out.println("can not close stream and socket.");
    }
  }
}