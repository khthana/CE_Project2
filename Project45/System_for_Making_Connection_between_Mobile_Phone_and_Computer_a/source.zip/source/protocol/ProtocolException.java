package Protocol;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ProtocolException extends Exception {


  public ProtocolException() {
    super("Protocol error");
  }
  public ProtocolException(String str) {
      super(str);
  }
  public ProtocolException(String str, int x) {
        super(str);
        i = x;
    }

  public int val() { return i; }
  private int i;

}