package protocol;

import java.util.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FMPrequest {
  public static final String separator = "\n";
  //use to communicate between client and main server
  public static final int LOGIN = 0;
  public static final int LOGOUT = 1;
  public static final int REGISTER = 2;
  public static final int MEMBER = 3;  // get the member list

  //use to communicate between clients
  public static final int CONNECT = 4;
  public static final int DISCONNECT = 5;
  public static final int FOLDERUP = 6;
  public static final int OPENFOLDER = 7;
  public static final int DELETE = 8;
  public static final int RENAME = 9;
  public static final int COPY = 10;
  public static final int MOVE = 11;
  public static final int NEWFOLDER = 12;
  public static final int PROPERTY = 13;
  public static final int UPLOAD = 14;
  public static final int DOWNLOAD = 15;
  public static final int COMMAND = 16;
  public static final int PRINT = 17;
  public static final int SYNC = 18;
  public static final int PASTE = 19;

  private String[] headers = {"method:", "date:", "path:", "name:", "length:", "type:", "parameter:", "group:"};
  private String[] value = new String[headers.length];
  // header
  private String agent;
  private int method;
  private String date;
  private String path;
  private String name;
  private String type;
  private int length; //length of content length
  private String parameter;
  private String authority;
  private String group;

  private byte[] content;

// constructor for write new request
// Writer have to complete other headers as the method want
  public FMPrequest(int methodT) {
    setMethod(methodT);
  }

// read request message from input stream
  public FMPrequest(DataInputStream in) throws Exception{
//    try {
      String head = in.readUTF();

      for (int i = 0; i < headers.length; i++) {
        String tmp = getValue(head, headers[i]);
        if(tmp!=null){
          switch(i){
            case 0 : setMethod(Integer.parseInt(tmp));
                     break;
            case 1 : setDate(tmp);
                     break;
            case 2 : setPath(tmp);
                     break;
            case 3 : setName(tmp);
                     break;
            case 4 : setLength(Integer.parseInt(tmp));
                     break;
            case 5 : setType(tmp);
                     break;
            case 6 : setParameter(tmp);
                     break;
            case 7 : setPath(tmp);
                     break;
            default: break;
          }
        }
      }
      //read
      if(head.indexOf("\n\n")!=-1){
        content = new byte[length];
        in.read(content);
      }
//    }catch (Exception ex) {
//      ex.printStackTrace();
//      System.exit(1);
//    }
  }
  public String getDate(){
    return date;
  }
  public String getGroup(){
    return group;
  }
  public String getAuthority(){
    return authority;
  }
  public void setMethod(int methodT){
    method = methodT;
    value[0] = String.valueOf(method);
  }
  public void setDate(String date){
    this.date = date;
    value[1] = date;
  }
  public void setPath(String path){
    this.path = path;
    value[2] = path;
  }
  public void setName(String name){
    this.name = name;
    value[3] = name;
  }
  public void setLength(int len){
    length = len;
    value[4] =String.valueOf(length);
  }
  public void setType(String type){
    this.type = type;
    value[5] = path;
  }
  public void setParameter(String parameter){
    this.parameter = parameter;
    value[6] = parameter;
  }
  public void setGroup(String group){
    this.group = group;
    value[7] = group;
  }
  public void setContent(byte[] b){
    this.content = b;
  }

/*
  private boolean isCorrect() throws ProtocolException{
    if(method==CONNECT || method==LOGIN || method==REGISTER){
      //require username and password
      if(name==null || parameter==null)
        return false;
      else return true;
    }
    else if(method==OPENFOLDER || method==DELETE ||method==PROPERTY || method==DOWNLOAD
            || method==LOGOUT || method==PRINT || method==NEWFOLDER ){
      //require path and file name
      if(path==null || name==null)
        return false;
      else return true;
    }
    else if(method==FOLDERUP){
      if(path==null)
        return false;
      else return true;
    }
    else if(method==COMMAND){
      if(path==null || parameter==null)
        return false;
      else return true;
    }
    else if(method==COPY || method==MOVE || method==RENAME){
      if(path==null || name==null || parameter==null)
        return false;
      else return true;
    }
    else if(method==LOGOUT || method==DISCONNECT){
       if(name==null)
         return false;
       else return true;
    }
    else if(method==UPLOAD){
       if(path==null || name==null || content==null)
         return false;
       else return true;
    }
    else if(method==MEMBER || method==SYNC){
      return true;
    }else
   throw new ProtocolException();
  }
  */

  public void sendRequest(DataOutputStream dout){
    try {
      dout.writeUTF(getRequest());
      if(content!=null){
        dout.write(content);
      }
    }
    catch (Exception ex) {
      System.out.println("send error ");
      ex.printStackTrace();
    }

  }

  private String getRequest() {
   // if(isCorrect()){
      String temp = "";
      if(content!=null)
        setLength(content.length);
      else setLength(0);
      for (int i = 0; i < headers.length; i++) {
        if(value[i]!=null){
          temp = temp+headers[i]+value[i]+"\n";
        }
      }
      if(content!=null)
        temp = temp+"\n";
      return temp;
  // }else return null;
  }

  private String getValue(String all, String header){
    int i = all.indexOf(header);
    int j = all.indexOf(separator);
    if(i!=-1){
      if(j!=-1){
        String str = all.substring(i);
        return str.substring(header.length(), str.indexOf("\n"));
      }
    }
    return null;
  }

  public int getMethod(){
    return method;
  }
  public String getName(){
    return name;
  }
  public String getPath(){
    return path;
  }
  public String getType(){
    return type;
  }
  private int getLength(){
    return length;
  }
  public String getParameter(){
    return parameter;
  }
  public byte[] getContent(){
    return content;
  }


}