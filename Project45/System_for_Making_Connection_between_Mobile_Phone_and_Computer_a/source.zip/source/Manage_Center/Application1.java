package manage_center;

import javax.swing.UIManager;
import java.awt.*;
import java.sql.*;
import java.io.*;
import java.net.*;
import java.util.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Application1
{
  private boolean packFrame = false;

  public String path = null;

  private ServerSocket server;
  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;

  String driverName = "sun.jdbc.odbc.JdbcOdbcDriver";
  String connectionURL = "jdbc:odbc:Server_DB";
  Frame1 frame;
  //Construct the application
  public Application1()
  {
    frame = new Frame1(this);
    //Validate frames that have preset sizes
    //Pack frames that have useful preferred size info, e.g. from their layout
    if (packFrame)
    {
      frame.pack();
    }
    else
    {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height)
    {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width)
    {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

  public void list()
  {
    try
    {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       frame.Show_Status("Waiting...");
       String sql ="Select * FROM Server_DB ";
       ResultSet l = null;
       l = stmt.executeQuery(sql);
       String temp = "";

       while(l.next())
       {
          //frame.Show_List(l.getString("NAME"),l.getString("STATUS"),l.getString("Pass"));
          temp = temp+l.getString("NAME")+"("+l.getString("STATUS")+","+l.getString("Pass")+")";
          temp = temp+"\n";
       }

       frame.Show_List(temp);
       frame.Show_Status("List Complate");
       stmt.close();
       con.close();
    }catch(Exception e)
    {
       e.printStackTrace();
    }
  }

  public void Search(String NameT,String IpT)
  {
    try
    {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       frame.Show_Status("Waiting...");
       String sql ="Select * FROM Server_DB WHERE NAME = '"+NameT+"'";
       ResultSet l = null;
       l = stmt.executeQuery(sql);
       int tmp = 1;
       while(l.next())
       {
          frame.Show_Result(l.getString("NAME"),l.getString("IP"),l.getString("STATUS"),l.getString("GROUP"),l.getString("Authority"),l.getString("Pass"));
          frame.Show_Status("Search Complate");
          tmp = -1;
       }
       if(tmp != -1) frame.Show_Status("Not Found...!!!");
       stmt.close();
       con.close();
    }catch(Exception e)
    {
       e.printStackTrace();
    }
  }
/*
  public void Register(String NameT,String IpT) throws IOException
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM Server_DB ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;

       while(j.next())
       {
         if(IpT.equals(j.getString("IP") ))       {i = -1;}
         if(NameT.equals(j.getString("NAME") ))   {i = -1;}
       }
       if (i == 1)
       {
         sql = "INSERT INTO Server_DB(NAME,IP,STATUS) VALUES('"+NameT+"','"+IpT+"','Online')";
         stmt.executeUpdate(sql);
         dout.writeUTF("Register Complete");
       }else
       {
         dout.writeUTF("Already Login");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }
*/
  public void Edit(String NameT,String IpT,String StatusT,String AuthorityT,String GroupT,String PassT)
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM Server_DB ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;

       while(j.next())
       {
         if(NameT.equals(j.getString("NAME") ))       {i = -1;}
       }
       if (i == -1)
       {
         sql = "UPDATE Server_DB SET NAME='"+NameT+"',STATUS='"+StatusT+"',Authority='"+AuthorityT+"',[GROUP]='"+GroupT+"',Pass='"+PassT+"' WHERE NAME = '"+NameT+"'" ;
         stmt.executeUpdate(sql);
         //dout.writeUTF("Edit Complete");
         frame.Show_Status("Edit Complete");
       }else
       {
         //dout.writeUTF("IP not found");
         frame.Show_Status("IP not found");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

   public void Create(String NameT,String IpT,String StatusT,String AuthorityT,String GroupT,String PassT)
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM Server_DB ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;
       //String PassT = null;

       while(j.next())
       {
         //if(IpT.equals(j.getString("IP") ))       {i = -1;}
         if(NameT.equals(j.getString("NAME") ))   {i = -1;}
       }
       if (i == 1)
       {
         sql = "INSERT INTO Server_DB(NAME,IP,STATUS,Authority,[GROUP],Pass) VALUES('"+NameT+"','"+IpT+"','Online','"+AuthorityT+"','"+GroupT+"','"+PassT+"')";
         stmt.executeUpdate(sql);
         //dout.writeUTF("Register Complete");
         frame.Show_Status("Create Complate");
       }else
       {
         //dout.writeUTF("Already Login");
         frame.Show_Status("Already Name or IP Address");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

  //Main method
  public static void main(String[] args)
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      Application1 run = new Application1();
      //run.Register("CCC","161.246.6.69");
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

  }
}