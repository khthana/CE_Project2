package manage_center;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import com.borland.dbswing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame1 extends JFrame {
  private JPanel contentPane;
  private JPanel panel1 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel jLabel1 = new JLabel();
  static private JTextField name = new JTextField();
  private JLabel jLabel2 = new JLabel();
  static private JTextField ip = new JTextField();
  private JLabel jLabel3 = new JLabel();
  static private JTextField status = new JTextField();
  private JPanel jPanel2 = new JPanel();
  private JLabel label4 = new JLabel();
  static private JTextField group = new JTextField();
  private JButton search = new JButton();
  private JLabel jLabel6 = new JLabel();
  private TitledBorder titledBorder1;
  static private JTextField authority = new JTextField();
  private JButton edit = new JButton();
  private JButton list = new JButton();

  private Application1 app;
  private XYLayout xYLayout2 = new XYLayout();
  private XYLayout xYLayout3 = new XYLayout();
  private JButton Create = new JButton();
  private JLabel jLabel4 = new JLabel();
  private JLabel Status_Bar = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JTextField password = new JTextField();
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JTextArea ListArea = new JTextArea();


  //Construct the frame
  public Frame1(Application1 a)
  {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    app = a;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(165, 163, 151)),"Detail Custom");
    contentPane.setLayout(xYLayout2);
    this.setSize(new Dimension(530, 300));
    this.setTitle("Center Manage");
    panel1.setLayout(xYLayout1);
    jLabel1.setToolTipText("");
    jLabel1.setText("NAME  :");
    name.setText("test");
    name.setColumns(15);
    jLabel2.setText("IP Address :");
    panel1.setBorder(titledBorder1);
    ip.setText("161.246.6.01");
    ip.setColumns(12);
    jLabel3.setText("Status :");
    status.setText("Ofline");
    status.setColumns(14);
    label4.setText("Group :");
    group.setText("Narak");
    group.setColumns(15);

    search.setText("Search");
    search.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        search_actionPerformed(e);
      }
    });
    search.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        search_actionPerformed(e);
      }
    });
    search.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        search_actionPerformed(e);
      }
    });
    search.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        search_actionPerformed(e);
      }
    });
    search.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        search_actionPerformed(e);
      }
    });
    search.addActionListener(new Frame1_search_actionAdapter(this));
    jPanel2.setLayout(xYLayout3);
    jLabel6.setText("Authority :");
    authority.setText("VIP");
    authority.setColumns(14);
    edit.setText("Edit");
    edit.addActionListener(new Frame1_edit_actionAdapter(this));
    list.setText("List");
    list.addActionListener(new Frame1_list_actionAdapter(this));
    Create.setText("Create");
    Create.addActionListener(new Frame1_Create_actionAdapter(this));

    jLabel4.setText("Status :");
    Status_Bar.setText("Ready!!!");

    jLabel7.setText("Password :");
    jLabel8.setText("List Username");
    panel1.add(jLabel1, new XYConstraints(12, 13, -1, -1));
    panel1.add(name,  new XYConstraints(59, 10, 207, -1));
    panel1.add(jLabel2, new XYConstraints(11, 43, -1, -1));
    panel1.add(ip,  new XYConstraints(86, 42, 180, -1));
    panel1.add(jLabel3, new XYConstraints(12, 78, -1, -1));
    panel1.add(status,  new XYConstraints(59, 77, 70, -1));
    panel1.add(label4, new XYConstraints(10, 113, -1, -1));
    panel1.add(group,  new XYConstraints(59, 112, 208, -1));
    panel1.add(jLabel6, new XYConstraints(9, 147, -1, -1));
    panel1.add(authority,   new XYConstraints(71, 146, 197, -1));
    panel1.add(Create,   new XYConstraints(32, 174, 79, 24));
    panel1.add(edit,   new XYConstraints(155, 174, 83, 24));
    panel1.add(list,   new XYConstraints(155, 201, 83, 24));
    panel1.add(search, new XYConstraints(32, 204, 78, 24));
    panel1.add(password,  new XYConstraints(202, 77, 66, -1));
    panel1.add(jLabel7,   new XYConstraints(136, 79, -1, -1));
    contentPane.add(ListArea,   new XYConstraints(322, 38, 188, 196));
    contentPane.add(jLabel8,  new XYConstraints(375, 10, -1, -1));
    contentPane.add(jPanel2,      new XYConstraints(324, 0, -1, 273));
    contentPane.add(jLabel4, new XYConstraints(319, 242, -1, -1));
    contentPane.add(Status_Bar,   new XYConstraints(367, 242, -1, -1));
    contentPane.add(panel1,           new XYConstraints(9, 6, 302, 260));
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }


  void Show_Result(String Tname,String Tip,String Tstatus,String Tgroup,String Tauthority,String Tpass)
  {
    name.setText(Tname);
    ip.setText(Tip);
    status.setText(Tstatus);
    group.setText(Tgroup);
    authority.setText(Tauthority);
    password.setText(Tpass);

  }
  public void Show_List(String temp)
  {
    //name_L.setText(Tname);
    //ip_L.setText(Tip);
   //ListArea.setText(Tname+"("+Tstatus+","+Tpass+")");
   //ListArea.setText("AAAA\nBBB");
   //ListArea.setText("\n");
   //ListArea.setListData(tm);
    ListArea.setText(temp);



  }

  public void search_actionPerformed(ActionEvent e)
  {
    String Tname = null;
    String Tip = null;
    String Tstatus = null;
    String Tgroup = null;
    String Tauthority = null;

    Tname = name.getText();
    Tip = ip.getText();
    app.Search(Tname,Tip);


  }

  public void edit_actionPerformed(ActionEvent e)
  {
    String Tname = null;
    String Tip = null;
    String Tstatus = null;
    String Tgroup = null;
    String Tauthority = null;
    String Tpass = null;

    Tname = name.getText();
    Tip = ip.getText();
    Tstatus = status.getText();
    Tgroup = group.getText(); if(Tgroup == null) Tgroup = "Non Group";
    Tauthority = authority.getText();
    Tpass = password.getText();
    app.Edit(Tname,Tip,Tstatus,Tauthority,Tgroup,Tpass);

  }

  public void list_actionPerformed(ActionEvent e)
  {
    app.list();
  }

  public void Create_actionPerformed(ActionEvent e)
  {
    String Tname = null;
    String Tip = null;
    String Tstatus = null;
    String Tgroup = null;
    String Tauthority = null;
    String Tpass = null;

    Tname = name.getText();
    Tip = ip.getText();
    Tstatus = status.getText();
    Tgroup = group.getText();
    Tauthority = authority.getText();
    Tpass = password.getText();
    app.Create(Tname,Tip,Tstatus,Tauthority,Tgroup,Tpass);

  }

  public void Show_Status(String Status_BarT)
  {
    Status_Bar.setText(Status_BarT);

  }

}

class Frame1_search_actionAdapter implements java.awt.event.ActionListener {
  private Frame1 adaptee;

  Frame1_search_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.search_actionPerformed(e);
  }
}

class Frame1_edit_actionAdapter implements java.awt.event.ActionListener {
  private Frame1 adaptee;

  Frame1_edit_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.edit_actionPerformed(e);

  }
}

class Frame1_list_actionAdapter implements java.awt.event.ActionListener {
  private Frame1 adaptee;

  Frame1_list_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.list_actionPerformed(e);
  }
}

class Frame1_Create_actionAdapter implements java.awt.event.ActionListener {
  private Frame1 adaptee;

  Frame1_Create_actionAdapter(Frame1 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Create_actionPerformed(e);
  }
}



