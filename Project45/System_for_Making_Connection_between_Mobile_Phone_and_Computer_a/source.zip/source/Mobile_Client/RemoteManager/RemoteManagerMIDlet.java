package RemoteManager;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import ui.MainScreen;

public class RemoteManagerMIDlet extends MIDlet {
  private static RemoteManagerMIDlet instance;
  private ScreenManager screenManager;

  /** Constructor */
  public RemoteManagerMIDlet() {
    instance = this;
  }

  /** Main method */
  public void startApp() {
      screenManager = new ScreenManager(Display.getDisplay(this));
      screenManager.showScreen(new MainScreen(screenManager));
  }

  /** Handle pausing the MIDlet */
  public void pauseApp() {
  }

  /** Handle destroying the MIDlet */
  public void destroyApp(boolean unconditional) {
  }

  /** Quit the MIDlet */
  public static void quitApp() {
    instance.destroyApp(true);
    instance.notifyDestroyed();
    instance = null;
  }

}
