package RemoteManager;

import ui.*;
import Storage.*;
import javax.microedition.io.*;
import java.io.*;
import protocol.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */


public class LocalHost {
  private ScreenManager screen;
  private FileChooser fc ;
  private File copyFile;
  private final Root root ;
  private Folder currentDir;

  private boolean logon;
  private String[] user;

  public LocalHost(ScreenManager screenManager) {
    screen = screenManager;
    fc = new FileChooser(screen);
    root = new Root();
    currentDir = root;
    update();
    //    test
    logon = false;
  }

  public FileChooser getFileChooser(){
    return fc;
  }

  public void chooseFile(){
    update();
    screen.showScreen(fc);
  }

  public FolderMenu getFolderMenu(){
    return new FolderMenu(screen, currentDir.getPath()+File.separator+fc.getSelectedFile());
  }
  public FileMenu getFileMenu(){
    return new FileMenu(screen, currentDir.getPath()+File.separator+fc.getSelectedFile());
  }
  public File getSelectedFile(){
    return currentDir.getFileList()[fc.getSelectedIndex()-1];
  }
  public Folder getCurrentDir(){
    return currentDir;
  }

  public boolean paste(){
    if(copyFile==null)
      return false;
    currentDir.addFile(copyFile);
    update();
    copyFile = null;
    return true;
  }

  public boolean copy(){
    if(fc.getSelectedType()==File.FOLDER)
      return false;
    copyFile = currentDir.getFileList()[fc.getSelectedIndex()-1];
    return true;
  }

  public void newfolder(String name){
    if(!currentDir.nameExist(name, File.FOLDER)){
      Folder f = new Folder(currentDir, name);
      chooseFile();
    }else{
      screen.showError("New Folder Error!","Can not create folder with this name.");
    }
  }

  public void folderup(){
    Folder parent = currentDir.getParent();
    if(parent!=null){
      currentDir = parent;
      chooseFile();
    }else
      screen.showFileChooser();
  }
  public void openFolder(){
      Folder tmp = (Folder) currentDir.getFileList()[fc.getSelectedIndex()-1];
      if(tmp.exist()){
        currentDir = tmp;
        chooseFile();
      }else
        screen.showFileChooser();
  }

  public void openFile(){
      Folder tmp = (Folder) currentDir.getFileList()[fc.getSelectedIndex()-1];
      if(tmp.exist()){
        currentDir = tmp;
        update();
      }else
        screen.showFileChooser();
  }

  public void delete(){
    File f = currentDir.getFileList()[fc.getSelectedIndex()-1];
    if(f.exist()){
      if(f.delete()){
        update();
 //       folderup();
      }
    } else{
      screen.showError("Delete Error", "Can not delete this file");
    }
  }

  public void rename(String newname){
    if(currentDir.nameExist( newname, fc.getSelectedType()))
      return;
    File f = currentDir.getFileList()[fc.getSelectedIndex()-1];
    if(f.exist()){
      if(f.rename(newname))
        update();
   }else{
      screen.showError("Rename Error", "Cannot rename this file");
   }
  }


  public boolean login(String username, String password){
    try {
      if(username.startsWith("test")){
        logon = true;
        return true;
      }

      StreamConnection con = (StreamConnection)  Connector.open("socket://127.0.0.1"+":6000", Connector.READ_WRITE);
      DataInputStream din = con.openDataInputStream();
      DataOutputStream dout = con.openDataOutputStream();

      FMPrequest req = new FMPrequest(FMPrequest.LOGIN);
      req.setName(username);
      req.setParameter(password);
      req.sendRequest(dout);

      FMPresponse res = new FMPresponse(din);
      din.close();
      dout.close();
      con.close();
      if(res.getStatus()==res.OK){
        logon = true;
        return true;
      }else{
        System.out.println("FAIL !!!");
        logon = false;
        return false;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
      return false;
    }

  }
  public void connect(String IP, String username, String password){
    try {
      StreamConnection con = (StreamConnection)  Connector.open("socket://IP:6000", Connector.READ_WRITE);
      DataInputStream din = con.openDataInputStream();
      DataOutputStream dout = con.openDataOutputStream();
      con.close();

      FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
      req.setName(username);
      req.setParameter(password);
      req.sendRequest(dout);

      FMPresponse res = new FMPresponse(din);
       if(res.getStatus()==res.OK){
         logon = true;
//        res.readList();
//         manager.showRemoteFileChooser(res.getPath(), res.filelist(), res.typelist());
      }else{
        System.out.println("FAIL !!!");
        logon = false;
      }
      din.close();
      dout.close();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public boolean isLogon(){
    return logon;
  }
  public String[] getUser(){
    return user;
  }


  public void update(){
    fc.update(currentDir.getPath(), currentDir.getList(), currentDir.getTypeList(), currentDir==root);
  }


}