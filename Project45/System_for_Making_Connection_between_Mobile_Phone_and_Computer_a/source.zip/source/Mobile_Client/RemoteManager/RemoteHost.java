package RemoteManager;

import protocol.*;
import java.io.*;
import javax.microedition.io.*;
import ui.*;
import Storage.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

// control remote host communication
public class RemoteHost {
  private ScreenManager manager;
  private DataInputStream din;
  private DataOutputStream dout;
  private boolean connected = false;

  private ScreenManager screen;
  private FileChooser fc = new FileChooser(screen);
  private String copyPath;
  private String currentDir;
  private String[] listFile;
  private int[] listType;


  public RemoteHost(ScreenManager manager) {
    this.manager = manager;
  }

  public FileMenu getFileMenu(){
    return new FileMenu(screen, currentDir+fc.getSelectedFile());
  }
  public FolderMenu getFolderMenu(){
    return new FolderMenu(screen, currentDir+fc.getSelectedFile());
  }
  public FileChooser getFileChooser(){
    return fc;
  }

  public void openfolder(){
    FMPrequest req = new FMPrequest(FMPrequest.OPENFOLDER);
    req.setName(fc.getSelectedFile());
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
  //    fc.update();
    }else {

    }
  }

  public void folderup(){
    FMPrequest req = new FMPrequest(FMPrequest.FOLDERUP);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }

  public void delete(){
    FMPrequest req = new FMPrequest(FMPrequest.DELETE);
    req.setName(fc.getSelectedFile());
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
      chooseFile();
    }else if(res.getStatus()==res.FAIL)
      screen.showError("Delete Error!", "Can not delete this file.");
  }

  public void rename(String newname){
    FMPrequest req = new FMPrequest(FMPrequest.RENAME);
    req.setName(fc.getSelectedFile());
    req.setParameter(newname);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }

  //move this method
  public void connect(String username, String password){
    FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
    req.setName(username);
    req.setParameter(password);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
    }
  }

  public void copy(){
    FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
    req.setName(fc.getSelectedFile());
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      //response must return full path of copied file in Name field
      copyPath = res.getName();
      chooseFile();
    }else
      screen.showError("Copy Error!", res.getParameter());
  }

  public void upload(String filename, byte[] file){
    FMPrequest req = new FMPrequest(FMPrequest.UPLOAD);
    req.setName(filename);
    req.setContent(file);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }

  public void newfolder(String foldername){
    FMPrequest req = new FMPrequest(FMPrequest.NEWFOLDER);
    req.setName(foldername);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }
  public void print(byte[] doc){
    FMPrequest req = new FMPrequest(FMPrequest.PRINT);
    req.setContent(doc);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
    }
  }

  public void command(String command, String filename, byte[] doc){
    FMPrequest req = new FMPrequest(FMPrequest.COMMAND);
    req.setParameter(command);
    req.setName(filename);
    req.setContent(doc);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
    }
  }

  public byte[] download(Folder folder){
    FMPrequest req = new FMPrequest(FMPrequest.DOWNLOAD);
    req.setName(fc.getSelectedFile());
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      return res.getContent();
    }else
      return null;
  }

  public String property(String filename){
    FMPrequest req = new FMPrequest(FMPrequest.PROPERTY);
    req.setName(filename);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      return res.getParameter();
    }else return null;
  }


  public void folderup(String path){
    try {
      FMPrequest req = new FMPrequest(FMPrequest.FOLDERUP);
      req.setName(path);
//      req.setParameter(password);
      req.sendRequest(dout);
      FMPresponse res = new FMPresponse(din);
       if(res.getStatus()==res.OK){
 //       res.readList();
 //        manager.showRemoteFileChooser(res.getPath(), res.filelist(), res.typelist());
      }else System.out.println("FAIL !!!");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
/*
  public void readList(FMPresponse res){
    try {
      String s[];
      ByteArrayInputStream bin = new ByteArrayInputStream(res.getContent());
      DataInputStream dbin = new DataInputStream(bin);
      int len = res.getLength();
      if(len>0){
        listFile = new String[len];
        listType = new int[len];
        for (int i = 0; i < len; i++) {
          listFile[i] =  dbin.readUTF();
          listType[i] = dbin.readInt();
        }
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
*/
  public boolean isConnected (){
    return connected;
  }

  public void chooseFile(){
    fc.update(currentDir, listFile, listType, false);
    screen.showScreen(fc);
  }

  public void readList(FMPresponse res){
  try {
    String[] filelist;
    int[] typelist;

    ByteArrayInputStream bin = new ByteArrayInputStream(res.getContent());
    DataInputStream dbin = new DataInputStream(bin);
    int len = dbin.readInt();
    if(len>0){
      filelist = new String[len];
      typelist = new int[len];
      for (int i = 0; i < len; i++) {
        filelist[i] =  dbin.readUTF();
        typelist[i] = dbin.readInt();
      }
      fc.update(currentDir, filelist, typelist, true);
    }
  }
  catch (Exception ex) {
    System.out.println("read list error..");
    ex.printStackTrace();
  }


  }


}