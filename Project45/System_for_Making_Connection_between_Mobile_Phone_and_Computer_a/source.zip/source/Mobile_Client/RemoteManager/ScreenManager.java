package RemoteManager;

import javax.microedition.lcdui.*;
import ui.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ScreenManager {

  private Display display;
  private LocalHost local ;//= new LocalHost(this);
  private RemoteHost remote = null;
  private boolean localMode = true;

  public ScreenManager(Display display) {
    this.display = display;
    local = new LocalHost(this);
    //test
//    remote = new RemoteHost(this);
  }

  public void showScreen(Displayable disp){
    display.setCurrent(disp);
  }

  public void showError(String title, String text){
    display.setCurrent(new Alert(title, text, null, AlertType.ERROR));
  }

  public void setLocalMode(boolean b){
    localMode = b;
  }
  public boolean isLocalMode(){
    return localMode;
  }

  public LocalHost getLocalHost(){
    return local;
  }
  public RemoteHost getRemoteHost(){
    return remote;
  }
  public void showFileChooser(){
    if(localMode)
      showScreen(local.getFileChooser());
    else
      showScreen(remote.getFileChooser());
  }

  public void showMainScreen(){
    showScreen(new MainScreen(this));
  }

  public static Image createImage(String filename)
  {
      Image image = null;
      try {
          image = Image.createImage(filename);
      }catch (java.io.IOException e) {
        // Use a 'null' image instead
        System.out.println(filename+" not found.");
      }
      return image;
  }

}