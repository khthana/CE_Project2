package Storage;

import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class VirtualFile extends File{
  private String host;
  private String location;

  public VirtualFile(Folder parent, int index, String name, int size, long created, long last, String fileType, String host, String location) {
    super(parent, File.VIRTUAL_FILE, index, name, size, created, last, fileType);
    this.host = host;
    this.location = location;
  }
  public VirtualFile(Folder parent, int index, String name, int size, long created, long last, String fileType, byte[] data) {
    super(parent, File.VIRTUAL_FILE, index, name, size, created, last, fileType);
    setContent(data);
  }
  public byte[] getContent() {
    try {
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      DataOutputStream dout = new DataOutputStream(bout);
      dout.writeUTF(host);
      dout.writeUTF(location);
      bout.flush();
      byte[] data = bout.toByteArray();
      dout.close();
      return data;
    } catch (IOException ex) {
      return null;
    }
  }
  public void setContent(byte[] data){
    try {
      ByteArrayInputStream bin = new ByteArrayInputStream(data);
      DataInputStream din = new DataInputStream(bin);
      host = din.readUTF();
      location = din.readUTF();
      din.close();
    }
    catch (Exception ex) {
      host = null;
      location = null;
    }
  }
  public String getProperty(){
    return "Host IP address : "+host+"\n"+
           "Host Location : "+location+"\n"+
           super.getProperty();
  }

  public String getHost(){
    return host;
  }
  public String getLocation(){
    return location;
  }
}