package Storage;

import javax.microedition.rms.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class BinFile extends File{

  public BinFile(Folder parent, int index, String name, long created, long last, String fileType, byte[] data) {
    super(parent, File.FOLDER, index, name, data.length, created, last, fileType);
    this.content = data;
  }
  public BinFile(Folder parent, int index, String name, long created, long last, String fileType) {
    super(parent, File.FOLDER, index, name, 0, created, last, fileType);
  }

  public byte[] getContent(){
    try{
      if(content == null){
        content = parent.getData(index);
        size = content.length;
        return content;
      }else return null;
    }catch(Exception e){
       System.out.println(e.getMessage());
       return null;
    }
  }

  public void setContent(byte[] data){
      content = data;
  }
}