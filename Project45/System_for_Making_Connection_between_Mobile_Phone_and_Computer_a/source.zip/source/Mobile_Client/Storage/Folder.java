package Storage;

import javax.microedition.rms.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Folder extends File{

  protected RecordStore rs;

  //record store name, It's not necessary to use exact folder name.
  //rsName'll alternate if folder name is already exist.
  private String rsName;

  //list of all files in this folder (include empty record)
  private File[] files;

  private int typeList[];
  private String nameList[];

  //count number of file (exclude empty record)
  private int count = 0;

  //constructor : open from rs
  //it's shouldn't be construct by user...don't forget to change it to default
  public Folder(Folder parent, String rsName, int index, String name, long created, long last) {
    super(parent, File.FOLDER, index, name, 0, created, last, "File Folder");
    this.rsName = rsName;
    content = rsName.getBytes();
    openFolder();
  }
  public Folder(Folder parent, File file) {
    super(parent, File.FOLDER, file.getIndex(), file.getName(), 0, file.getCreated(), file.getLastModified(), "File Folder");
    this.rsName = new String(file.getContent());
    content = file.getContent();
    createFolder();
  }

  //constructor : create new Folder
  public Folder(Folder parent, String name) {
    super(parent, File.FOLDER, File.NOT_EXIST, name, 0, System.currentTimeMillis(), System.currentTimeMillis(), "File Folder");
    // assign record store name to this folder
    if(!nameExist(name,File.FOLDER )){
      String tmp = new String(name);
      int i = 1;
      while(rsNameExist(tmp)){
        tmp = name+"_"+String.valueOf(i++);
      }
      content = tmp.getBytes();
      createFolder();
      //save();
    }
  }

  //constructor : open root
  Folder(String rootName, String rsName) {
    super(null, File.FOLDER, File.NOT_EXIST, rootName, 0, 0, 0, "File Folder");
    this.rsName = rsName;
    createFolder();
    try {
      updateList();
    }
    catch (Exception ex) {
      System.err.println("Open root : update list error!!");
    }
  }

  static boolean rsNameExist(String rsName){
    String[] list = RecordStore.listRecordStores();
    for (int i = 0; i < list.length; i++) {
      if(list[i].equals(rsName)){
        return true;
      }
    }
    return false;
  }
/*
  public RecordStore getRecordStore(){
    return rs;
  }
*/
  public boolean nameExist(String name, int type){
    if(files!= null){
      for (int i = 0; i < files.length; i++) {
        if(files[i].getType()==type)
          if(files[i].getName().equals(name))
            return true;
      }
    }
    return false;
  }

  public int getNumFile(){
    return count;
  }

  public File[] getFileList(){
    return files;
  }

  public byte[] getData(int index) throws Exception{
    return rs.getRecord(index+1);
  }

  public int[] getTypeList(){
    if(count>0){
      int[] type = new int[count];
      int temp = 0;
      for (int i = 0; i < typeList.length; i++) {
        if(typeList[i]!=File.EMPTY)
          type[temp++] = typeList[i];
      }
      return type;
    }else return null;
  }
  public String[] getList(){
    if(count == 0){
      return null;
    }else{
      String[] list = new String[count];

      int temp = 0;
      for (int i = 0; i < nameList.length; i++) {
        if(nameList[i]!=null)
          list[temp++] = nameList[i];
      }
      return list;
    }
  }

  private int searchEmptyRecord(){
    if( files!=null){
      for (int i = 0; i < files.length; i++) {
        if(files[i].getType()==File.EMPTY){
          return 2*i+1;
        }
      }
      return -1;  //not found empty record
    }else return -1;  //empty folder
  }

  public boolean saveContent(File file){
    try {
      byte[] data = file.getContent();
      rs.setRecord(file.getIndex()+1, data, 0, data.length);
      return true;
    }
    catch (Exception ex) {
      return false;
    }
  }

  public boolean saveProperty(File file){
    try {
      byte[] prop = file.getProp();
      if(file.getIndex()!=-1){
          rs.setRecord(file.getIndex(), prop, 0, prop.length);
          updateList();
          return true;
      }else{
        return false;
      }
    }catch (Exception ex) {
      ex.printStackTrace();
      return false;
    }
  }

  public boolean deleteFile(File file){
    try {
      saveProperty(file);
      saveContent(file);
      updateList();
      return true;
    }
    catch (Exception ex) {
      this.openFolder();
      this.deleteFile(file);
      ex.printStackTrace();
      return false;
    }
  }



// record store operation
  public boolean openFolder(){//throws RecordStoreNotFoundException, RecordStoreException {
    try {
      rs = RecordStore.openRecordStore( rsName, false );
      updateList();
      return true;
    }catch (RecordStoreNotFoundException ex) {
      return false;//createFolder();
    }catch (Exception ex2){
      return false;
    }
  }

  //refresh list of files
  private void updateList() throws RecordStoreException, IOException{
    int temp = 0;  //count number of files (include empty file)
    int num = rs.getNumRecords()/2;
    files = new File[num];

    nameList = new String[num];
    typeList = new int[num];

    count = 0; // reset file counter

    int numRecord = rs.getNumRecords(); // number of file include Empty File

    //read only file property in this record store
    for (int i = 1; i < numRecord; i=i+2) {
      byte[] record = rs.getRecord(i);
      ByteArrayInputStream bin = new ByteArrayInputStream(record);
      DataInputStream din = new DataInputStream(bin);

      int type = din.readInt();
      String name = din.readUTF();
      String fileType = din.readUTF();
      int size = din.readInt();
      long created = din.readLong();
      long last = din.readLong();

      typeList[temp] = type;
      if(type == File.EMPTY){
        files[temp++] = new EmptyFile(i);
      }else{
        nameList[temp] = name;
        count++;
        if(type == File.BINARY_FILE){
          byte[] data = rs.getRecord(i+1);
          files[temp++] = new BinFile(this, i, name, created, last, fileType, data);
        }else if(type == File.VIRTUAL_FILE){
          byte[] data = rs.getRecord(i+1);
          files[temp++] = new VirtualFile(this, i, name, size, created, last, fileType, data);
        }else if(type == File.FOLDER){
          String recName = new String(rs.getRecord(i+1));
          files[temp++] = new Folder(this, recName, i, name, created, last);
        }
      }
    }
  }

  private boolean createFolder() {
    try {
      rs = RecordStore.openRecordStore( name, true );
      if(rs!=null && parent!=null){
        save();
      }
      return (rs!=null);
    }
    catch (Exception ex) {
      return false;
    }
  }

  public void close(){
    try {
      if(rs!=null){
        System.out.println("Folder name : "+rs.getName());
        System.out.println("Used Memory : "+rs.getSize());
        System.out.println("Free Memory : "+rs.getSizeAvailable());
        System.out.println("-----------------------");
        rs.closeRecordStore();
      }
    }
    catch (Exception ex) {
    }
  }


  public boolean addFile(File file){
    try {
      byte[] prop = file.getProp();
      byte[] data = file.getContent();
      int index = searchEmptyRecord();
      if(index == -1){          // There's no hole in record store
        file.setIndex(rs.getNextRecordID());  //set index to this file
        rs.addRecord(prop, 0, prop.length);
        rs.addRecord(data, 0, data.length);
        System.out.println("add : "+file.getName()+" at index : "+file.getIndex());
      }else{
        System.out.println("Find empty record at "+index);
        rs.setRecord(index, prop, 0, prop.length);
        rs.setRecord(index+1, data, 0, data.length);
        System.out.println("set : "+file.getName()); //comment
      }
      updateList();
      return true;
    }catch(RecordStoreNotOpenException e1){
      openFolder();
      System.out.println("parent folder did not open !!");
      return addFile(file);
    }catch (Exception ex) {
      System.out.println("add file error");
      ex.printStackTrace();
      return false;
    }
  }
}