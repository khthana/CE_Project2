package Storage;

import java.util.*;
import javax.microedition.rms.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class File{
  //Fle constants
  public static final char separatorChar = '/';
  public static final String separator = "/";
  public static final String[] specialChar = {"/", "\\", ":", "*", "?", "\"", "<", ">", "|"};
  //index - record address of file
  public static final int NOT_EXIST = -1;

  //file type constants
  public static final int FOLDER = 0;
  public static final int BINARY_FILE = 1;
  public static final int VIRTUAL_FILE = 2;
  public static final int EMPTY = 3;

  //Record index in record store
  protected int index = NOT_EXIST;
  //type of file
  protected int type = EMPTY;
  protected String name;
  protected int size = 0;
  protected long created = System.currentTimeMillis();
  protected long lastModified = System.currentTimeMillis();
  protected Folder parent = null;
  protected String fileType = "none";
  //full path of file
  protected String path;
  protected byte[] content;

  //constructor
  public File(Folder folder, int type, int index, String name, int size, long created, long last, String fileType) {
    this.parent = folder;
    this.type = type;
    this.index = index;
    this.name = name;
    this.size = size;
    this.created = created;
    this.lastModified = last;
    this.fileType = fileType;
    if(parent != null)
      this.path = parent.getPath()+File.separator+name;
    else
      this.path = name;
  }

  public int getSize(){
    return size;
  }
  public int getIndex(){
    return index;
  }
  public int getType(){
    return type;
  }
  public String getName(){
    return name;
  }
  public String getPath(){
    return  path;
  }
  public byte[] getContent(){
    return  content;
  }

  public void setIndex(int index){
    this.index = index;
  }
  public Folder getParent(){
    return parent;
  }
  public void setParent(Folder folder){
     parent = folder;
  }
  public long getCreated(){
    return created;
  }
  public long getLastModified(){
    return lastModified;
  }
  public boolean exist(){
    return index!= File.NOT_EXIST;
  }

  static public boolean isValidName(String str){
    for (int i = 0; i < specialChar.length; i++) {
      if (str.indexOf(specialChar[i])!=-1)
        return false;
    }
    return true;
  }

  public boolean rename(String new_name){
    //check special character
    if (isValidName(new_name)){
      this.name = new_name;
      saveProperty();
      return true;
    }
    return false;
  }

  public boolean delete(){
    type = File.EMPTY;
    content = " ".getBytes();
    return parent.deleteFile(this);
  }

  protected void setContent(byte[] data){
    content = data;
  }

  public String getProperty(){
    StringBuffer tmp = null;
    tmp.append("Name : "+name+"\n");
    if(type == this.BINARY_FILE){
      int index = name.indexOf(".");
      if(index!=-1)
        tmp.append("Type : "+name.substring(index)+" File\n");
      else
        tmp.append("Type : File\n");
    }else if(type == this.FOLDER)
      tmp.append("Type : File Folder\n");
    else if(type == this.VIRTUAL_FILE)
      tmp.append("Type : Virtual File\n");
    tmp.append("Location : "+path+"\n");
    tmp.append("Size : "+size+"\n");
    Calendar c = Calendar.getInstance();
    c.setTime(new Date(lastModified));
    tmp.append("Last modified : "+c.toString()+"\n");
    return tmp.toString();
  }

  public byte[] getProp(){
    try {
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      DataOutputStream dout = new DataOutputStream(bout);
      dout.writeInt(type);
      dout.writeUTF(name);
      dout.writeUTF(fileType);
      dout.writeInt(size);
      dout.writeLong(created);
      dout.writeLong(lastModified);
      dout.flush();
      return bout.toByteArray();
    }
    catch (IOException ex) {
      return null;
    }
  }

  public void save(){
    if(index == -1 ){
      parent.addFile(this);
    }else{
      saveProperty();
      saveContent();
    }
  }

  public boolean saveProperty(){
    return parent.saveProperty(this);
  }

  public boolean saveContent(){
    return parent.saveContent(this);
  }

}

class EmptyFile extends File{
  public EmptyFile(int index){
    super((Folder) null, File.EMPTY, index, "/", 0, 0, 0, "none");
  }
  public byte[] getContent(){
    return " ".getBytes();
  }

}
