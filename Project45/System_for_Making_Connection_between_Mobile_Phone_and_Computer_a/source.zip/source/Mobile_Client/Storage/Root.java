package Storage;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Root extends Folder {
  static final String rootName = "M:";

  public Root() {
    super(rootName, rootName);
  }

  public Folder getParent(){
    return this;
  }

  public void format(){
    try {
      if(rs.getNumRecords()>0){
        for (int i = 1; i <= rs.getNumRecords(); i++) {
          rs.deleteRecord(i);
        }
      }
    }catch (Exception ex) {
      ex.printStackTrace();
      System.err.println("can not clear recordstore error!!!");
    }
  }
}