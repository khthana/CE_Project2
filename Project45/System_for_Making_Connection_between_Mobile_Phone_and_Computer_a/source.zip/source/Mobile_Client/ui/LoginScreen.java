package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;

public class LoginScreen extends Form implements CommandListener {
  private TextField username;
  private TextField password;
  ScreenManager screen;
  private TextField textField1;
  /**Construct the displayable*/
  public LoginScreen(ScreenManager screen) {
    super("Login to Server");
    this.screen = screen;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    username = new TextField("", "", 15,TextField.ANY);
    password = new TextField("", "", 15,TextField.ANY);
    textField1 = new TextField("", "", 15,TextField.ANY);
    textField1.setLabel("Confirm Password :");
    textField1.setConstraints(TextField.PASSWORD);
    textField1.setMaxSize(30);
    textField1.setString("teskd fdgfhgfhhg");
    this.setTitle("Register");
    password.setLabel("Password :                               ");
    password.setConstraints(TextField.PASSWORD);
    password.setMaxSize(30);
    password.setString("teskd fdgfhgfhhg");
    username.setLabel("Username :");
    username.setMaxSize(30);
    username.setString("TestName");
    setCommandListener(this);
    this.append(username);
    this.append(password);
    this.append(textField1);
    // add the Exit command
    addCommand(new Command("Register", Command.SCREEN, 1));
    addCommand(new Command("Cancel", Command.SCREEN, 1));
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel()=="Cancel"){
      screen.showScreen(new MainScreen(screen));
    }else if(command.getLabel()=="Login"){
      screen.getLocalHost().login(username.getString(), password.getString());
      screen.showMainScreen();
    }
  }

}
