package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;

public class UserScreen extends Form implements CommandListener {
  public Image userImg = ScreenManager.createImage("/res/red.PNG");
  public ScreenManager manager;
  private String[] userlist, iplist;

  /**Construct the displayable*/
  public UserScreen(ScreenManager manager, String[] user, String[] ip) {
    super("Online User List");
    try {
      this.manager = manager;
      this.userlist = user;
      this.iplist = ip;
      jbInit();
      setList(user, ip);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    choice = new ChoiceGroup("",ChoiceGroup.EXCLUSIVE);
/*    for (int i = 0; i < userlist.length; i++) {
      choice.append(userlist[i]+" ("+iplist[i]+")", userImg);
    }
*/
    password = new TextField("", "", 15,TextField.ANY);
    password.setLabel("Password : ");
    password.setConstraints(TextField.PASSWORD);
    password.setMaxSize(30);
    password.setString("test");
    setCommandListener(this);
    // add the Exit command
    addCommand(new Command("Cancel", Command.SCREEN, 1));
    addCommand(new Command("Select", Command.SCREEN, 1));
//    this.append(choice);
    this.append(password);
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel()=="Cancel")
      manager.showScreen(new MainScreen(manager));
    else if(command.getLabel()=="Select"){
//      String str = getString(getSelectedIndex());
  //    manager.getLocalHost().connect(iplist[choice.getSelectedIndex()],
   //                                  "test127.0.0.1", password.getString());
  //    manager.showScreen (new Connect iplist[getSelectedIndex()], remote);

    }
  }

  public void setList(String[] userlist, String[] iplist){
    clearAll();
    this.userlist = userlist;
    this.iplist = iplist;
    if(userlist!=null){
      for (int i = 0; i < userlist.length; i++) {
        choice.append(userlist[i]+"("+iplist[i]+")", userImg);
      }
    }
  }
  public void clearAll(){
    while(this.size()>0)
      this.delete(0);
  }
  private ChoiceGroup choice;
  private TextField password;



}
