package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;

public class RenameDialog extends Form implements CommandListener {
  private TextField textField1;
  ScreenManager manager;
  LocalHost local;
  RemoteHost remote;
  String file;

  /**Construct the displayable*/
  public RenameDialog(ScreenManager manager, String filename) {
    super("Rename "+filename+" to..");
    try {
      this.manager = manager;
      this.local = manager.getLocalHost();
      this.remote = manager.getRemoteHost();
      file = filename;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    textField1 = new TextField("", file, 32,TextField.ANY);
    textField1.setLabel("Enter new name :");
    setCommandListener(this);
    // add the Exit command
    addCommand(new Command("Back", Command.SCREEN, 1));
    addCommand(new Command("OK", Command.SCREEN, 1));
    this.append(textField1);
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel() == "Back"){
      manager.showFileChooser();
    }else if(command.getLabel() == "OK"){
      if(manager.isLocalMode()){
        local.rename(textField1.getString());
      }else{
        remote.rename(textField1.getString());
      }
    }
  }

}
