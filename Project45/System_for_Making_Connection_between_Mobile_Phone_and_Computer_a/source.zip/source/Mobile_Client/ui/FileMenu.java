package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;
import Storage.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
public class FileMenu extends List implements CommandListener {
  private ScreenManager screen;
  private LocalHost local;
  private RemoteHost remote;
  /**Construct the displayable*/
  public FileMenu(ScreenManager manager, String title) {
    super("HelloWorld.java", List.IMPLICIT);
    try {
      this.screen = manager;
      this.local = screen.getLocalHost();
      this.remote = screen.getRemoteHost();

      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    Image openImg = ScreenManager.createImage("/res/open16.PNG");
    Image propImg = ScreenManager.createImage("/res/property16.PNG");
    Image copyImg = ScreenManager.createImage("/res/copy16.PNG");
    Image downloadImg = ScreenManager.createImage("/res/download.PNG");
    Image uploadImg = ScreenManager.createImage("/res/upload.PNG");
    Image delImg = ScreenManager.createImage("/res/delete16.PNG");
    Image renameImg = ScreenManager.createImage("/res/rename16.PNG");
    Image printImg = ScreenManager.createImage("/res/print16.PNG");
    Image cutImg = ScreenManager.createImage("/res/cut.PNG");
    Image compileImg = ScreenManager.createImage("/res/compile.PNG");
    Image runImg = ScreenManager.createImage("/res/play.PNG");

    String s = getTitle().toLowerCase();
    if((s.endsWith(".png")||s.endsWith(".txt")||s.endsWith(".java")) && screen.isLocalMode())
      append("open",openImg);
    append("rename",renameImg);
    append("delete",delImg);
    append("copy",copyImg);
    append("cut",cutImg);
//    if(screen.isLocalMode())
 //     if(local.getSelectedFile().getType()==File.BINARY_FILE)
    append("upload",uploadImg);
    append("compile",compileImg);
    append("run",runImg);
  //  else
  //    append("download",downloadImg);
    append("print",printImg);
    append("property",propImg);
    // set up this Displayable to listen to command events
    setCommandListener(this);
    // add the Exit command
    addCommand(new Command("Exit", Command.EXIT, 1));
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel()=="Back"){

    }
//      manager.showFileChooser();
    else if(command == List.SELECT_COMMAND){
      String str = getString(getSelectedIndex());
      if(str.equals("open")){
          local.openFile();
      }else if(str.equals("rename")){
        screen.showScreen(new RenameDialog(screen, getTitle()));
      }else if(str.equals("delete")){
        if(screen.isLocalMode())
          local.delete();
        else
          remote.delete();
      }else if(str.equals("copy")){
        if(screen.isLocalMode())
          local.copy();
        else
          remote.copy();
      }else if(str.equals("upload")){
        File f = local.getSelectedFile();
        remote.upload(f.getName(), f.getContent());
      }else if(str.equals("download")){
        remote.download(local.getCurrentDir());
//      }else if(str.equals("print")){
      } else if(str.equals("property")){
        if(screen.isLocalMode())
          screen.showScreen( new TextDialog(screen, "File Propety", local.getSelectedFile().getProperty()));
        else
          screen.showScreen( new TextDialog(screen, "File Propety", remote.property(str)));
      }
    }
  }

}
