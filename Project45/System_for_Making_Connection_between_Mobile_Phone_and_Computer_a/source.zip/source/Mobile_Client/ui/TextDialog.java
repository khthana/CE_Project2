package ui;

import javax.microedition.lcdui.*;
import RemoteManager.ScreenManager;

public class TextDialog extends Form implements CommandListener {
  private StringItem stringItem1;
  ScreenManager screen;
  /**Construct the displayable*/
  public TextDialog(ScreenManager screen, String title, String text) {
    super(title);
    this.screen = screen;
    try {
      stringItem1 = new StringItem("", text);
      setCommandListener(this);
      // add the Exit command
      addCommand(new Command("Close", Command.SCREEN, 1));
      this.append(stringItem1);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    screen.showFileChooser();
  }

}
