package ui;

import javax.microedition.lcdui.*;
import RemoteManager.ScreenManager;

public class NewFolderDialog extends Form implements CommandListener {
  private TextField textField1;
  private ScreenManager screen;
  /**Construct the displayable*/
  public NewFolderDialog(ScreenManager screen) {
    super("Create New Folder");
    try {
      this.screen = screen;
      textField1 = new TextField("Enter folder name : ", "", 32,TextField.ANY);
      setCommandListener(this);
      // add the Exit command
      addCommand(new Command("Cancel", Command.SCREEN, 1));
      addCommand(new Command("OK", Command.SCREEN, 1));
      this.append(textField1);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel()=="Cancel"){
      screen.showFileChooser();
    }else if(command.getLabel()=="OK"){
      if(screen.isLocalMode())
        screen.getLocalHost().newfolder(textField1.getString());
      else
        screen.getRemoteHost().newfolder(textField1.getString());
    }
  }

}
