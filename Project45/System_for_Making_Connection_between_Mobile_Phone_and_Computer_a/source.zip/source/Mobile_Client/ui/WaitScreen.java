package ui;

import javax.microedition.lcdui.*;

public class WaitScreen extends Canvas implements CommandListener, Runnable {
  private boolean done = false;
  int count = 0;
  Thread t;

  /**Construct the displayable*/
  public WaitScreen() {
    try {
      jbInit();
      t = new Thread(this);
      t.start();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    setCommandListener(this);
    // add the Exit command
//    addCommand(new Command("Exit", Command.EXIT, 1));
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */

  }

  /** Required paint implementation */
  protected void paint(Graphics g) {
    /** @todo Add paint codes */
    g.setColor(255,255,255);
    g.fillRect(0, 0, this.getWidth(), this.getHeight());
    g.setColor(0);
    g.drawString("Please Wait", 70, 20, g.TOP|g.RIGHT);
    if(count%4 == 1)
      g.drawString(".", 70, 20, g.TOP|g.LEFT);
    else if(count%4 == 2)
      g.drawString("..", 70, 20, g.TOP|g.LEFT);
    else if(count%4 == 3){
      g.drawString("...", 70, 20, g.TOP|g.LEFT);
//      count = 0;
    }
  }

  public void close(){
    done = true;
  }

  public void run(){
    while(!done){
      try {
        repaint();
        t.sleep(500);
        count++;
      }
      catch (Exception ex) {

      }
    }
  }

}
