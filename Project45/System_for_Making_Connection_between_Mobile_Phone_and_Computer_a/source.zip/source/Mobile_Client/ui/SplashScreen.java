package ui;
import RemoteManager.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import javax.microedition.lcdui.*;
import java.util.Timer;
import java.util.TimerTask;


public class SplashScreen  extends Form
{
    private final ScreenManager manager;
    private Timer timer = null;


    public SplashScreen(ScreenManager manager, Image logoImage)
    {
        super(null);
        this.manager = manager;

        append(new StringItem(null, "Remote File Manager"));
        append(new ImageItem(null, logoImage,
            (ImageItem.LAYOUT_CENTER | ImageItem.LAYOUT_NEWLINE_BEFORE), null));
        start();
    }


    void start()
    {
        if (timer != null)
        {
            timer.cancel();
        }
        timer = new Timer();
        TimerTask task = new TimerTask()
                         {
                             public void run()
                             {
                                 timer.cancel(); // remove the timer
                                 manager.showScreen(new MainScreen(manager));
                             }
                         };
        timer.schedule(task, 2000L); // 1 second
    }

 }
