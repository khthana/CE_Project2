package ui;

import javax.microedition.lcdui.*;

public class SettingScreen extends Form implements CommandListener {
  private TextField textField1;
  private TextField textField2;
  /**Construct the displayable*/
  public SettingScreen() {
    super("Preferrence");
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    textField1 = new TextField("", "", 15,TextField.ANY);
    textField2 = new TextField("", "", 5,TextField.ANY);
    textField2.setLabel("Server Port :");
    textField2.setConstraints(TextField.NUMERIC);
    textField2.setString("6000");
    textField1.setLabel("Server  Center IP address : ");
    textField1.setString("161.246.6.68");
    setCommandListener(this);
    // add the Exit command
    addCommand(new Command("Close", Command.EXIT, 1));
    addCommand(new Command("Apply", Command.EXIT, 1));
    this.append(textField1);
    this.append(textField2);
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
  }

}
