package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;
import Storage.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FolderMenu extends List implements CommandListener {
  private ScreenManager screen;
  private LocalHost local;
  private RemoteHost remote;

  /**Construct the displayable*/
  public FolderMenu(ScreenManager manager, String title) {
    super(title , List.IMPLICIT);
    try {
      this.screen = manager;
      this.local = screen.getLocalHost();
      this.remote = screen.getRemoteHost();

      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void clear(){
    while(this.size()>0)
      this.delete(0);
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    Image openImg = ScreenManager.createImage("/res/open16.png");
    Image propImg = ScreenManager.createImage("/res/property16.png");
    Image copyImg = ScreenManager.createImage("/res/copy16.png");
    Image moveImg = ScreenManager.createImage("/res/move16.png");
    Image moveremoteImg = ScreenManager.createImage("/res/comfolder16.png");
    Image delImg = ScreenManager.createImage("/res/delete16.png");
    Image renameImg = ScreenManager.createImage("/res/rename16.png");
    // set up this Displayable to listen to command events
    append("open",openImg);
//    append("copy",copyImg);
    append("delete",delImg);
    append("rename",renameImg);
    append("property",propImg);

    setCommandListener(this);
    addCommand(new Command("Back", Command.SCREEN, 1));
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel()=="Back"){
      screen.showFileChooser();
    }
    else if(command == List.SELECT_COMMAND){
      String str = getString(getSelectedIndex());
      if(str.equals("open")){
        if(screen.isLocalMode())
          local.openFolder();
        else
          remote.openfolder();
      }else if(str.equals("copy")){
        if(screen.isLocalMode())
          local.copy();
        else
          remote.copy();
      }else if(str.equals("delete")){
        if(screen.isLocalMode())
          local.delete();
        else
          remote.delete();
      } else if(str.equals("rename")){
        screen.showScreen(new RenameDialog(screen, getTitle()));
      } else if(str.equals("property")){
        screen.showScreen( new TextDialog(screen, "File Propety", local.getSelectedFile().getProperty()));
      }
    }
  }


}
