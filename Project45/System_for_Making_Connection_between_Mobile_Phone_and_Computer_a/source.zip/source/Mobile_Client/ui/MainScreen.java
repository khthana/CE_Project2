package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;

public class MainScreen extends List implements CommandListener {
  ScreenManager screen;
  /**Construct the displayable*/
  public MainScreen(ScreenManager screen) {
    super("mobile Remote Manager V1.0", List.IMPLICIT);
    this.screen = screen;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    Image loginImg = ScreenManager.createImage("/res/login.PNG");
    Image remoteImg = ScreenManager.createImage("/res/NewHost16.PNG");
    Image exploreImg = ScreenManager.createImage("/res/explore16.PNG");
    Image setImg = ScreenManager.createImage("/res/tool16.PNG");
    Image commandImg = ScreenManager.createImage("/res/command16.PNG");
    Image exitImg = ScreenManager.createImage("/res/exit.PNG");
    Image disconnectImg = ScreenManager.createImage("/res/disconnect.PNG");
    if(screen.getLocalHost()!=null)
    if(!screen.getLocalHost().isLogon())
      append("Login", loginImg);
    else {
      append("Logout", loginImg);
//      if(screen.getRemoteHost()==null)
//        append("Connect Remote Host", remoteImg);
//      else
        append("Run Command", commandImg);
    }
    append("Browse File", exploreImg);
    append("Setting", setImg);
    append("disconnect", disconnectImg);
    append("Exit", exitImg);
    // set up this Displayable to listen to command events
    setCommandListener(this);
    // add the Exit command
//    addCommand(new Command("Exit", Command.EXIT, 1));
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
//    if (command.getCommandType() == Command.EXIT) {
// stop the MIDlet
    if(command == List.SELECT_COMMAND){
      String str = getString(getSelectedIndex());
      if(str.equals("Exit")){
        RemoteManagerMIDlet.quitApp();
      }else if(str.equals("Login")){
        screen.showScreen(new LoginScreen(screen));
      }else if(str.equals("Logout")){

      }else if(str.equals("Connect Remote Host")){
        String user[] = {"test", "garlicia"};
        String ip[] = {"161.246.6.68", "161.246.6.45"};
        screen.showScreen(new ConnectScreen(screen,user,ip ));
      }else if(str.equals("Browse File")){
        screen.showFileChooser();
      }else if(str.equals("Run Command")){

      }else if(str.equals("Setting")){
        screen.showScreen(new SettingScreen());
      }
    }
  }

}
