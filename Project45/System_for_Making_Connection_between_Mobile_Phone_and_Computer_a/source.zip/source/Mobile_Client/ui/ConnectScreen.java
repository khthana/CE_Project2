package ui;

import RemoteManager.*;
import javax.microedition.lcdui.*;

public class ConnectScreen extends Form implements CommandListener {
  private ChoiceGroup choice;
  private TextField password;
  public Image userImg = ScreenManager.createImage("/res/red.PNG");
  public ScreenManager manager;
  private String[] userlist, iplist;

  /**Construct the displayable*/
  public ConnectScreen(ScreenManager manager, String[] user, String[] ip) {
    super("Connect to..");
    try {
      this.manager = manager;
      this.userlist = user;
      this.iplist = ip;
      jbInit();
      setList(user, ip);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    choice = new ChoiceGroup("",ChoiceGroup.EXCLUSIVE);
    password = new TextField("", "", 15,TextField.ANY);
    password.setLabel("Password : ");
    password.setConstraints(TextField.PASSWORD);
    password.setMaxSize(30);
    choice.setLabel("Select remote host : ");
    setCommandListener(this);
    // add the Exit command
    this.append(choice);
    this.append(password);
    addCommand(new Command("Cancel", Command.SCREEN, 1));
    addCommand(new Command("Select", Command.SCREEN, 1));
  }
  public void setList(String[] userlist, String[] iplist){
    this.userlist = userlist;
    this.iplist = iplist;
    if(userlist!=null){
      for (int i = 0; i < userlist.length; i++) {
        choice.append(userlist[i]+"("+iplist[i]+")", userImg);
      }
    }
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if(command.getLabel() == "Cancel")
      manager.showMainScreen();
    else
      manager.getLocalHost().connect(iplist[choice.getSelectedIndex()],
                                     userlist[choice.getSelectedIndex()],
                                     password.getString());
  }

}
