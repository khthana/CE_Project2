package ui;

import javax.microedition.lcdui.*;
import RemoteManager.*;
import Storage.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FileChooser extends List implements CommandListener, Runnable {
//images
  public static final int SELECT_FOLDER_ONLY = 1;
  public static final int SELECT_FILE_ONLY = 2;
  public static final int SELECT_BOTH = 3;

  private String currentPath;
  private String selectedFile;
  private String[] filesName;
  private int[] filesType;
  private String copyPath = null;

  private String blinkTitle = null;//"test title";   //test
  private Thread titleThread = new Thread(this);

  private ScreenManager screen;
//  private LocalHost local;
//  private RemoteHost remote;

  /**Construct the displayable*/
  public FileChooser(ScreenManager manager) {
    super("", List.IMPLICIT);

    this.screen = manager;
    try {
      jbInit();
    } catch(NullPointerException ex){
      ex.printStackTrace();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    titleThread.start();
    // set up this Displayable to listen to command events
    setCommandListener(this);
    // add the Exit command
    addCommand(new Command("Main Menu", Command.SCREEN, 1));
 //   if(screen.getRemoteHost()!=null){
  //    if(screen.isLocalMode())
        addCommand(new Command("Switch to Remote Host", Command.SCREEN, 1));
  //    else
  //      addCommand(new Command("Switch to Local Host", Command.SCREEN, 1));
  //  }
        addCommand(new Command("New Folder", Command.SCREEN, 1));
    if(copyPath != null)
      addCommand(new Command("Paste "+copyPath, Command.SCREEN, 1));
//    addCommand(new Command("New Folder", Command.SCREEN, 1));
  }

  public void run(){
    while (true){
      if(blinkTitle!=null){
        try{
          if(!getTitle().equals(blinkTitle)){
            setTitle(blinkTitle);
          }else setTitle(currentPath);
          titleThread.sleep(1200);
        }catch(InterruptedException e){
          System.err.println("Title thread error");
        }
      }
    }
  }

  public String getCurrentPath(){
    return currentPath;
  }

  public void update(String title, String[] filesName, int[] filesType, boolean canUp){
    Image folderImg = RemoteManager.ScreenManager.createImage("/res/folder16.PNG");
    Image binfileImg = RemoteManager.ScreenManager.createImage("/res/binfile.PNG");
    Image vfileImg = RemoteManager.ScreenManager.createImage("/res/vfile.PNG");
    Image folderupImg = RemoteManager.ScreenManager.createImage("/res/folderup16.PNG");

    this.filesName = filesName;
    this.filesType = filesType;
    setTitle(title);
    //clear old list
    clear();
    //append new list
      append("...", folderupImg);
    if(filesName != null && filesType != null){
      for (int i = 0; i < filesName.length; i++) {
        if(filesType[i] == File.FOLDER)
          append(filesName[i], folderImg);
        else if(filesType[i] == File.BINARY_FILE)
          append(filesName[i], binfileImg);
        else if(filesType[i] == File.VIRTUAL_FILE)
          append(filesName[i], vfileImg);
      }
    }
    //delete this
    append("HelloWorld.java", vfileImg);
    append("readme.txt", binfileImg);

  }

  private void clear(){
    while(size()!=0) {
      delete(0);
    }
  }

  public int getSelectedType(){
    int i = getSelectedIndex();
    if(i>0){
      return filesType[i];
    }
    return 0;
  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */

    if(command.getLabel()=="Main Menu"){
      screen.showScreen(new MainScreen(screen));
    }else if(command.getLabel()=="Switch to Remote Host"){
      screen.setLocalMode(false);
      screen.showFileChooser();
    }else if(command.getLabel()=="Switch to Local Host"){
      screen.setLocalMode(true);
      screen.showFileChooser();
    }else if(command.getLabel()=="New Folder"){
      screen.showScreen(new NewFolderDialog(screen));
    }else if(command.getLabel().startsWith("Paste ")){

    }else if(command == List.SELECT_COMMAND){
      String name = this.getString(getSelectedIndex()-1);
      selectedFile = name;
      if(this.getSelectedIndex() == 0 && name=="..."){
        if(screen.isLocalMode())
          screen.getLocalHost().folderup();
        else
          screen.getRemoteHost().folderup();
        return;
      }

//      if(filesType[getSelectedIndex()-1]==File.FOLDER){
//        screen.showScreen(new FolderMenu(screen, name));
//      }else{

        screen.showScreen(new FileMenu(screen, "readme.txt"));
//      }
    }
  }

  public String getSelectedFile(){
    return selectedFile;
  }

  public void setBlinkTitle(String str){
    blinkTitle = str;
    Thread t = new Thread(this);
    t.start();
  }

}
