package protocol;
import com.garlicia.midp.lcdui.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class testProtocol extends MIDlet {
  private static testProtocol instance;
  private Displayable1 displayable = new Displayable1();
//  private WaitScreen displayable = new WaitScreen();

  /** Constructor */
  public testProtocol() {
    instance = this;
  }

  /** Main method */
  public void startApp() {
    Display.getDisplay(this).setCurrent(displayable);
  }

  /** Handle pausing the MIDlet */
  public void pauseApp() {
  }

  /** Handle destroying the MIDlet */
  public void destroyApp(boolean unconditional) {
  }

  /** Quit the MIDlet */
  public static void quitApp() {
    instance.destroyApp(true);
    instance.notifyDestroyed();
    instance = null;
  }

}
