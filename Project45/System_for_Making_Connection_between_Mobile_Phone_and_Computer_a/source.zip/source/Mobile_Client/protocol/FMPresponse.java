package protocol;

import java.util.*;
import java.lang.*;
import java.io.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FMPresponse  {
  public static final String separator = "\n";
  // status
  public static final int OK = 0;
  public static final int FAIL = 1;
  public static final int ACK = 2;

  private String[] headers = {"status:", "date:", "path:", "name:", "length:", "type:", "parameter:","group:"};
  private String[] value = new String[headers.length];

  private int status;
  private String date;
  private String path;
  private String name;
  private int length;
  private String type;
  private String parameter;
  private String group;
  private byte[] content;

  public FMPresponse(int status) {
    setStatus(status);
  }
  public FMPresponse(DataInputStream din) {
    try {
      String head = din.readUTF();
      for (int i = 0; i < headers.length; i++) {
        String tmp = getValue(head, headers[i]);
        if(tmp!=null){
          switch(i){
            case 0 : setStatus(Integer.parseInt(tmp));
                     break;
            case 1 : setDate(tmp);
                     break;
            case 2 : setPath(tmp);
                     break;
            case 3 : setName(tmp);
                     break;
            case 4 : setLength(Integer.parseInt(tmp));
                     break;
            case 5 : setType(tmp);
                     break;
            case 6 : setParameter(tmp);
                     break;
            case 7 : setGroup(tmp);
            default: break;
          }
        }
      }
      if(head.indexOf("\n\n")!=-1){
        content = new byte[length];
        din.read(content);
      }
     }
    catch (Exception ex) {

    }
  }
/*
  public void readList(){
    try {
      ByteArrayInputStream bin = new ByteArrayInputStream(content);
      DataInputStream dbin = new DataInputStream(bin);
      int len = dbin.readInt();
      if(len>0){
        filelist = new String[len];
        typelist = new int[len];
        for (int i = 0; i < len; i++) {
          filelist[i] =  dbin.readUTF();
          typelist[i] = dbin.readInt();
        }
      }
    }
    catch (Exception ex) {
      System.out.println("read list error..");
      ex.printStackTrace();
    }
  }
*/
  public String getGroup(){
    return group;
  }
  public void setGroup(String group){
    this.group = group;
    value[6] = group;
  }
/*
  public void setUsername(String[] username, String[] IP){
    try {
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      DataOutputStream dbout = new DataOutputStream(bout);
      dbout.writeInt(username.length);
      for (int i = 0; i < username.length; i++) {
        dbout.writeUTF(username[i]);
        dbout.writeUTF(IP[i]);
      }
      setContent(bout.toByteArray());
    }
    catch (Exception ex) {
    }
  }
  */
  public void setStatus(int s){
    this.status = s;
    value[0] = String.valueOf(s);
  }
  public void setDate(String date){
    this.date = date;
    value[1] = date;
  }
  public void setPath(String path){
    this.path = path;
    value[2] = path;
  }
  public void setName(String name){
    this.name = name;
    value[3] = name;
  }
  public void setLength(int len){
    this.length = len;
    value[4] = String.valueOf(len);
  }
  public void setType(String type){
    this.type = type;
    value[5] = type;
 }
 public void setParameter(String par){
   this.parameter = par;
   value[6] = par;
 }
  public void setContent(byte[] b){
    setLength(b.length);
    this.content = b;
  }
  public String getDate(){
    return date;
  }
  public String getName(){
    return name;
  }
  public int getLength(){
    return length;
  }
  public String getType(){
    return type;
  }
  public String getPath(){
    return path;
  }
  public String getParameter(){
    return parameter;
  }
  public byte[] getContent(){
    return content;
  }
  public int getStatus(){
    return status;
  }

  private String getValue(String all, String header){
    int i = all.indexOf(header);
    int j = all.indexOf(separator);
    if(i!=-1){
      if(j!=-1){
        String str = all.substring(i);
        return str.substring(header.length(), str.indexOf("\n"));
      }
    }
    return null;
  }

  private String getResponse(){
      String temp = "";
      if(content!=null)
        setLength(content.length);
      else setLength(0);
      for (int i = 0; i < headers.length; i++) {
        if(value[i]!=null){
          temp = temp+headers[i]+value[i]+"\n";
        }
      }
      if(content!=null)
        temp = temp+"\n";
      return temp;
  }

  public void sendResponse(DataOutputStream dout){
    try {
      dout.writeUTF(getResponse());
      if(content!=null){
        dout.write(content);
      }
    }
    catch (Exception ex) {
      System.out.println("send error "+ex.getMessage());
      ex.printStackTrace();
    }
  }
/*
  public void sendOKListResponse(String path, DataOutputStream dout){
  try {
    setPath(path);

    File f = new File(path);
    File list[] = f.listFiles();

    //write all list in content
    ByteArrayOutputStream bout = new ByteArrayOutputStream();
    DataOutputStream dbout = new DataOutputStream(bout);
    if(list.length>0){
      dbout.writeInt(list.length);
      for (int i = 0; i < list.length; i++) {
        dbout.writeUTF(list[i].getName());  // file name
        if(list[i].isDirectory())
          dbout.writeInt(0);  // folder type
        else
          dbout.writeInt(1);  // file type
      }
    }
    setContent( bout.toByteArray());
    sendResponse(dout);
  }
  catch (Exception ex) {
  }
}
  */

}