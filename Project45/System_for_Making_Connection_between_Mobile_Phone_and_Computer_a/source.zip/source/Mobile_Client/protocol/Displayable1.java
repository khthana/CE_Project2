package protocol;

import javax.microedition.lcdui.*;
import java.io.*;
import javax.microedition.io.*;

public class Displayable1 extends List implements CommandListener {
  private DataInputStream din;
  private DataOutputStream dout;
  /**Construct the displayable*/
  public Displayable1() {
    super("Test Protocol", List.IMPLICIT);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /**Component initialization*/
  private void jbInit() throws Exception {
    // set up this Displayable to listen to command events
    setCommandListener(this);

    this.append("test", null);

    // add the Exit command
    addCommand(new Command("Exit", Command.EXIT, 1));
    addCommand(new Command("Connect", Command.SCREEN, 1));
    addCommand(new Command("New Folder", Command.SCREEN, 1));
    ///    test
    //FMPRequest req = new FMPRequest("method:1\npath:testpath\nname:test\nlength:222");
/*    byte temp[] = "Hello world".getBytes();
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    DataOutputStream dout = new DataOutputStream(out);
    dout.writeUTF("method:1\npath:testpath\nname:test\nlength:"+temp.length+"\n\n");
    dout.write(temp);
    byte tmp[] = out.toByteArray();
    ByteArrayInputStream in = new ByteArrayInputStream(tmp);
    DataInputStream din = new DataInputStream(in);
    FMPRequest req = new FMPRequest(din);
    System.out.println("method :"+req.getMethod());
    System.out.println("name :"+req.getName());
    System.out.println("path :"+req.getPath());
    System.out.println("length :"+req.getLength());
    System.out.println("content :"+new String(req.getContent()));
*/
//    System.out.println("method :"+req.getMethod()+"\n");

  }

  /**Handle command events*/
  public void commandAction(Command command, Displayable displayable) {
    /** @todo Add command handling code */
    if (command.getCommandType() == Command.EXIT) {
// stop the MIDlet
      testProtocol.quitApp();
    }else if (command.getLabel() == "Connect") {
      connect();
    }else if (command.getLabel() == "New Folder") {
      newfolder();
    }

  }

  public void connect(){
    try {
      StreamConnection conn = (StreamConnection) Connector.open("socket://localhost:6000", Connector.READ_WRITE);
      din = conn.openDataInputStream();
      dout = conn.openDataOutputStream();
      conn.close();

      FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
      req.setName("test");
      req.setParameter("pass");
      req.sendRequest(dout);

      //wait response
      FMPresponse res = new FMPresponse(din);
      if(res.getStatus()==res.OK)
        append("OK",null);
      else append("Fail",null);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  public void newfolder(){
    try {
      FMPrequest req = new FMPrequest(FMPrequest.NEWFOLDER);
      req.setName("Test on Mobile");
      req.sendRequest(dout);

      //wait response
      FMPresponse res = new FMPresponse(din);
      if(res.getStatus()==res.OK)
        append("New Folder success",null);
      else append("Fail!, cannot make folder.",null);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

}
