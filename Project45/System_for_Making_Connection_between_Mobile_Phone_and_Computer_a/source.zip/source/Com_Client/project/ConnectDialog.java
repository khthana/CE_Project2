package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ConnectDialog extends JDialog implements ActionListener{
    private static ConnectDialog dialog;
    private static String value = "";
    private JList list;
    private IconRenderer renderer = new IconRenderer();
    JButton cancelButton = new JButton("Cancel");
    JButton setButton = new JButton("Connect");
    JPasswordField password = new JPasswordField(30);
    MainFrame frame;

/*    public String showDialog(Component frame) {
      setLocationRelativeTo(frame);
      setVisible(true);
      setLocation(frame.getX()+frame.getWidth()/2-dialog.getWidth()/2,
                  frame.getY()+frame.getHeight()/2-dialog.getHeight()/2);
      return value;
    }
*/
    public ConnectDialog(MainFrame frame, Object[] data, String title, String labelText) {
        super(frame, title, true);
        this.frame = frame;
        cancelButton.addActionListener(this);
        setButton.addActionListener(this);
        getRootPane().setDefaultButton(setButton);

        //main part of the dialog
        list = new JList(data);
        list.setVisibleRowCount(8);
        list.setCellRenderer(renderer);
        list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        JScrollPane listScroller = new JScrollPane(list);
        listScroller.setPreferredSize(new Dimension(250, 80));
        //XXX: Must do the following, too, or else the scroller thinks
        //XXX: it's taller than it is:
        listScroller.setMinimumSize(new Dimension(250, 80));
        listScroller.setAlignmentX(LEFT_ALIGNMENT);

        //Create a container so that we can add a title around
        //the scroll pane.  Can't add a title directly to the
        //scroll pane because its background would be white.
        //Lay out the label and scroll pane from top to button.
        JPanel listPane = new JPanel();
        listPane.setLayout(new BoxLayout(listPane, BoxLayout.Y_AXIS));
        JLabel label = new JLabel(labelText);
        label.setLabelFor(list);
        listPane.add(label);
        listPane.add(Box.createRigidArea(new Dimension(0,5)));
        listPane.add(listScroller);
        listPane.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        //Lay out the buttons from left to right.
        JPanel buttonPane = new JPanel();
        buttonPane.setLayout(new BoxLayout(buttonPane, BoxLayout.X_AXIS));
        buttonPane.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));
        buttonPane.add(Box.createHorizontalGlue());
        buttonPane.add(setButton);
        buttonPane.add(Box.createRigidArea(new Dimension(10, 0)));
        buttonPane.add(cancelButton);

        //
        JPanel passwordPane = new JPanel();
        passwordPane.add(new Label("Password : "));
        passwordPane.add(password);

        //Put everything together, using the content pane's BorderLayout.
        Container contentPane = getContentPane();
        contentPane.add(listPane, BorderLayout.NORTH);
        contentPane.add(passwordPane, BorderLayout.CENTER);
        contentPane.add(buttonPane, BorderLayout.SOUTH);

        pack();

        dialog = this;
    }

    public void actionPerformed(ActionEvent e){
      if(e.getSource()==setButton){
        String p = new String(password.getPassword());
        frame.connect(list.getSelectedIndex(), p);
      }else if(e.getSource()==cancelButton){
        value = null;
      }
      dispose();
    }

}
