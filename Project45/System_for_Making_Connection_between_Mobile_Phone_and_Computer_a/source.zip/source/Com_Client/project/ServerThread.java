package project;
import java.net.*;
import java.io.*;
import protocol.*;
import java.util.*;

/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class ServerThread extends Thread {
  private FileUtil util = new FileUtil();
  private File currentDir;
  private File copyFile, moveFile;

  private boolean done = false;
  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;

  public ServerThread(Socket socket) {
    connection = socket;
    currentDir = util.getRoots()[0];
    try {
      input = connection.getInputStream();
      output = connection.getOutputStream() ;
      din = new DataInputStream( input );
      dout = new DataOutputStream( output );
      sendListResponse();
    }
    catch (Exception ex) {
      System.out.println("new server thread error !!!");
      ex.printStackTrace();
    }
  }

  public void run(){
    try {
       while ( !done ) {
         System.out.println ("Waiting for Request.");
         //  Wait for a request.
         FMPrequest req = new FMPrequest(din);
         //  Process task.
         processCommand(req);
       }
       close();
    }catch(Exception e){
      done = true;
      System.out.println ("IO ERROR : "+e);
    }
  }

  private void processCommand(FMPrequest req) throws IOException{
      int command = req.getMethod();
      switch(command){
/*        case FMPrequest.LOGIN : login(req.getName(), req.getParameter());
          break;
        case FMPrequest.LOGOUT : logout(req.getName());
          break;
        case FMPrequest.REGISTER : register(req.getName(), req.getParameter());
          break;
        case FMPrequest.CONNECT : connect(req.getName(), req.getParameter());
          break;
*/        case FMPrequest.COMMAND : runCommand(req.getParameter(), req.getName(), req.getContent());
          break;
        case FMPrequest.COPY : copy(req.getName());
          //pass selected file name in current directory to save as copy file
          break;
        case FMPrequest.DELETE : delete(req.getName());
          break;
        case FMPrequest.DISCONNECT : disconnect();
          break;
        case FMPrequest.DOWNLOAD : download(req.getName());
          break;
        case FMPrequest.FOLDERUP : folderup();
          break;
        case FMPrequest.MOVE : move(req.getName());
          break;
        case FMPrequest.OPENFOLDER : openfolder(req.getName());
          break;
        case FMPrequest.PRINT : print(req.getPath(), req.getName(), req.getContent());
          break;
        case FMPrequest.PROPERTY : getProperty(req.getName());
          break;
        case FMPrequest.RENAME : rename(req.getName(), req.getParameter());
          break;
        case FMPrequest.SYNC : sendAck();
          break;
        case FMPrequest.UPLOAD : upload(req.getPath(), req.getName(), req.getContent());
          break;
        case FMPrequest.NEWFOLDER : newFolder(req.getName());
          break;
        case FMPrequest.PASTE : paste();
        default : break;
      }
   }

   private void connect(){
     sendFailResponse("You've already connected");
   }
   private void disconnect(){
     done = true;
     sendOKResponse();
   }

   private void print(String path , String name, byte[] file){
     //FMPresponse res = new FMPresponse(FMPresponse.OK);

   }

   private void runCommand(String cmdline, String name, byte[] file){
     try {
       File f = new File(currentDir, name);
       if(file!=null || f.exists()){
         FileOutputStream fout = new FileOutputStream(f);
         fout.write(file);
         fout.close();
       }

       String temp = util.runCommand(cmdline, currentDir);
       if(temp!=null){
           FMPresponse res = new FMPresponse(FMPresponse.OK);
           res.setContent(temp.getBytes());
           res.sendResponse(dout);
       }else
         sendFailResponse("Cannot execute this command");
     }
     catch (IOException ex) {

     }
  }

  private void upload(String path, String name, byte[] file) throws IOException{
    if( util.writeFile(new File(currentDir, name), file))
      sendListResponse();
    else sendFailResponse("Cannot upload this file");
  }

  private void delete(String name) throws IOException{
    if(util.delete(new File(currentDir, name))){
      sendListResponse();
    }else{
      sendFailResponse("Cannot delete this file");
    }
  }

  private void download(String name) throws IOException{
    File f = new File(currentDir, name);
    byte[] b = util.getFile(f);
    if(b!=null){
      FMPresponse res = new FMPresponse(FMPresponse.OK);
      res.setName(f.getName());
      res.setType(util.getFileType(f));
      res.setContent(b);
      res.setDate(util.getDate(System.currentTimeMillis()));
      res.sendResponse(dout);
    }else{
      sendFailResponse("Cannot get this file");
    }
  }

  private void rename(String name, String newname) throws IOException{
    File f = new File(currentDir, name);
    if(util.rename(f, newname)){
      sendListResponse();
    }else
      sendFailResponse("Can not rename this file.");
  }

  private void paste(){
    if(copyFile!=null){
      try {
        if(util.copy(copyFile, currentDir)){
          if(moveFile!=null){
            util.delete(moveFile);
            copyFile = null;
            moveFile = null;
          }
          sendListResponse();
        }else
          sendFailResponse("Cannot rename this file !!!");
      }
      catch (Exception ex) {

      }
    }
  }

  private void newFolder(String name) {
    if(util.createFolder(currentDir, name)){
      sendListResponse();
    }else
      sendFailResponse("Cannot create new folder");
  }

  private void getProperty(String name) {
    File f = new File(currentDir, name);
    if(f.exists()){
      FMPresponse res = new FMPresponse(FMPresponse.OK);
      res.setParameter(util.getFileProperty(f));
      res.sendResponse(dout);
    }
    else this.sendFailResponse("File not exists.");
  }

  private void folderup(){
    File f = util.getParent(currentDir);
    if(f != null){
      currentDir = f;
      sendListResponse();
    }
    else sendFailResponse("File not exists");
  }

  private boolean copy(String name)throws IOException{
    File f = new File(currentDir, name);
    if((f.isDirectory() || f.isFile()) && !util.isSystemFile(f)){
      copyFile = f;
      sendOKResponse();
      return true;
    }else{
      sendFailResponse("Can not copy system file.");
      return false;
    }
  }

  private void move(String name)throws IOException{
    File f = new File(currentDir, name);
    if((f.isDirectory() || f.isFile()) && !util.isSystemFile(f)){
      copyFile = f;
      moveFile = copyFile;
      sendOKResponse();
    }else
      sendFailResponse("Can not move system file.");
  }

  private void openfolder(String name)throws IOException{
    File f = new File(currentDir, name);
    if(f.isDirectory()){
      currentDir = f;
      sendListResponse();
    }else
      sendFailResponse("Can not open this file.");
  }

  private void sendListResponse(){
    try {
      FMPresponse res = new FMPresponse(FMPresponse.OK);
      if(util.isSystemFile(currentDir))
        res.setPath(util.getDisplayName(currentDir));
      else
        res.setPath(currentDir.getPath());
      File list[] = util.getList(currentDir);
      //set length as file number
      res.setLength(list.length);

      //write all list in content
      ByteArrayOutputStream bout = new ByteArrayOutputStream();
      DataOutputStream dbout = new DataOutputStream(bout);

      dbout.writeInt(list.length);
      for (int i = 0; i < list.length; i++) {
        dbout.writeUTF(util.getDisplayName(list[i]));  // file name
        if(list[i].isDirectory())
          dbout.writeInt(0);  // folder type
        else //if(list[i].isFile())
          dbout.writeInt(1);  // file type
      }
      res.setContent( bout.toByteArray());
      res.sendResponse(dout);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private void sendAck(){
    FMPresponse res = new FMPresponse(FMPresponse.ACK);
    res.sendResponse(dout);
  }
  private void sendOKResponse(){
    FMPresponse res = new FMPresponse(FMPresponse.OK);
    res.sendResponse(dout);
  }

  private void sendFailResponse(String msg){
    FMPresponse res = new FMPresponse(FMPresponse.FAIL);
    res.setParameter(msg);
    res.sendResponse(dout);
  }
  /*
  private void sendResponse(FMPresponse res){
    res.setDate(util.getDate(System.currentTimeMillis()));
    res.
  }
*/

  public void close() {
    try{
      din.close();
      dout.close();
      connection.close();
    }catch(IOException e){
      System.out.println("can not close stream and socket.");
    }
  }
}