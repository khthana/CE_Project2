package project;

import java.net.*;
import java.io.*;
import protocol.*;
import javax.swing.*;
/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class RemoteHost {
  private String currentDir;
  private String[] listFile;
  private int[] listType;
  private RemotePanel pane;
  private String copyPath;

  private Socket connection;
  private DataInputStream din;
  private DataOutputStream dout;

  public RemoteHost(Socket socket, FMPresponse res) throws IOException{
    connection = socket;
    din = new DataInputStream( connection.getInputStream() );
    dout = new DataOutputStream( connection.getOutputStream() );

    readList(res);

    pane = new RemotePanel(this);
    pane.updateList(currentDir, listFile, listType);
  }

  public JPanel getPanel(){
    return pane;
  }

  public void openfolder(String path, String foldername){
    FMPrequest req = new FMPrequest(FMPrequest.OPENFOLDER);
    req.setPath(path);
    req.setName(foldername);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
      pane.updateList(currentDir, listFile, listType);
    }else {

    }
  }

  public void folderup(){
    FMPrequest req = new FMPrequest(FMPrequest.FOLDERUP);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }

  public void delete(String filename){
    FMPrequest req = new FMPrequest(FMPrequest.DELETE);
    req.setName(filename);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }

  public void rename(String filename, String newname){
    FMPrequest req = new FMPrequest(FMPrequest.RENAME);
    req.setName(filename);
    req.setParameter(newname);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }


  public void copy(String filename){
    FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
    req.setName(filename);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      //response must return full path of copied file in Name field
      copyPath = res.getName();
    }
  }

  public void upload(String filename, byte[] file){
    FMPrequest req = new FMPrequest(FMPrequest.UPLOAD);
    req.setName(filename);
    req.setContent(file);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }

  public void newfolder(String foldername){
    FMPrequest req = new FMPrequest(FMPrequest.NEWFOLDER);
    req.setName(foldername);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      currentDir = res.getPath();
      readList(res);
    }
  }
  public void print(byte[] doc){
    FMPrequest req = new FMPrequest(FMPrequest.PRINT);
    req.setContent(doc);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
    }
  }

  public void command(String command, String filename, byte[] doc){
    FMPrequest req = new FMPrequest(FMPrequest.COMMAND);
    req.setParameter(command);
    req.setName(filename);
    req.setContent(doc);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
    }
  }

  public byte[] download(String filename){
    FMPrequest req = new FMPrequest(FMPrequest.DOWNLOAD);
    req.setName(filename);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
      return res.getContent();
    }else
      return null;
  }

  public void property(String filename){
    FMPrequest req = new FMPrequest(FMPrequest.PROPERTY);
    req.setName(filename);
    req.sendRequest(dout);

    FMPresponse res = new FMPresponse(din);
    if(res.getStatus()==res.OK){
    }
  }


/*
  public void login(String IP, String username, String password){
    try {
      StreamConnection con = (StreamConnection)  Connector.open("socket://161.246.6.65:6000", Connector.READ_WRITE);
      DataInputStream din = con.openDataInputStream();
      DataOutputStream dout = con.openDataOutputStream();

      FMPrequest req = new FMPrequest(FMPrequest.LOGIN);
      req.setName(username);
      req.setParameter(password);
      req.sendRequest(dout);

      FMPresponse res = new FMPresponse(din);
      if(res.getStatus()==res.OK){
  //      res.readUsername();
   //     manager.showUser(res.getUsername(), res.getIP());
      }else{
        System.out.println("FAIL !!!");
      }
      din.close();
      dout.close();
      con.close();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  public void connect(String IP, String username, String password){
    try {
      StreamConnection con = (StreamConnection)  Connector.open("socket://localhost:6000", Connector.READ_WRITE);
      DataInputStream din = con.openDataInputStream();
      DataOutputStream dout = con.openDataOutputStream();
      con.close();

      FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
      req.setName(username);
      req.setParameter(password);
      req.sendRequest(dout);
      FMPresponse res = new FMPresponse(din);

       if(res.getStatus()==res.OK){
         connected = true;
//        res.readList();
//         manager.showRemoteFileChooser(res.getPath(), res.filelist(), res.typelist());
      }else{
        System.out.println("FAIL !!!");
        connected = false;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  */
  public void folderup(String path){
    try {
      FMPrequest req = new FMPrequest(FMPrequest.FOLDERUP);
      req.setName(path);
      req.sendRequest(dout);
      FMPresponse res = new FMPresponse(din);
       if(res.getStatus()==res.OK){
        readList(res);
      }else System.out.println("FAIL !!!");
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public void readList(FMPresponse res){
    try {
      currentDir = res.getPath();
      String s[];
      ByteArrayInputStream bin = new ByteArrayInputStream(res.getContent());
      DataInputStream dbin = new DataInputStream(bin);
      int len = dbin.readInt();
      if(len>0){
        listFile = new String[len];
        listType = new int[len];
        for (int i = 0; i < len; i++) {
          listFile[i] =  dbin.readUTF();
          listType[i] = dbin.readInt();
        }
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public boolean isConnected (){
    return connection!=null;
  }


}