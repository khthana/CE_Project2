package project;

import java.io.*;
import java.net.*;
import javax.swing.filechooser.*;
import javax.swing.*;
import java.util.*;
import protocol.*;
/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class LocalHost {

  private FileUtil util = new FileUtil();
  private File currentDir;
  private File secondDir;
  private File copyFile, moveFile;

  private String username, password;
  private boolean logon;
  private String[] users, ip;

  private MainFrame frame;
  private Server server;
  private Vector remote = new Vector();


  public LocalHost(MainFrame f){
    frame = f;
    currentDir = util.getRoots()[0];
  }

  public void setCurrentDir(File f){
    currentDir = f;
    secondDir = currentDir;
  }
/*  public JPanel getPanel(){
    return pane;
  }
*/
  public boolean openFolder(int index){
    File[] f = util.getList(currentDir);
    if(f[index].isFile())
      return false;
    currentDir = f[index];
    secondDir = currentDir;
    return true;
  }

  public ImageIcon[] getListImgIcon() throws FileNotFoundException{
    File[] list = util.getList(currentDir);
    ImageIcon[] icons = new ImageIcon[list.length];
    for (int i = 0; i < icons.length; i++) {
      icons[i] = util.getFileImgIcon(list[i]);
      icons[i].setDescription(util.getDisplayName(list[i]));
    }
    return icons;
  }

  public void setCurrentRoot(){
    currentDir = util.getRoots()[0];
  }
  public void setSecondDir(){
    currentDir = secondDir;
  }

  public String getListName(int i){
    return util.getList(currentDir)[i].getAbsolutePath();
  }

  public ImageIcon getCurrentDirImgIcon(){
    return util.getFileImgIcon(currentDir);
  }
  public ImageIcon getFileImgIcon(int i){
    return util.getFileImgIcon(getFile(i));
  }

  public boolean newFolder(String s){
    try {
      return util.createFolder(currentDir, s);
    }
    catch (Exception ex) {
      System.out.println(ex.toString());
      ex.printStackTrace();
      return false;
    }
  }

  public boolean isFolder(int i){
    File[] list = util.getList(currentDir);
    return list[i].isDirectory() && !util.isSystemFile(list[i]);
  }

  public boolean isFile(int i){
    File[] list = util.getList(currentDir);
    return list[i].isFile() && !util.isSystemFile(list[i]);
  }
  public boolean isSystemFile(int i){
    File[] list = util.getList(currentDir);
    return util.isSystemFile(list[i]);
  }

  public File getFile(int i){
    return util.getList(currentDir)[i];
  }

  public boolean rename(int i, String name){
    try {
      return util.rename(getFile(i), name);
    }
    catch (Exception ex) {
      return false;
    }
  }

  public boolean folderup(){
    File f = util.getParent(currentDir);
    if(f==null)
      return false;
    currentDir = f;
    secondDir = currentDir;
    return true;
  }

  public String getProperty(int i){
    return util.getFileProperty(getFile(i));
  }

  public File getCurrentDir(){
    return currentDir;
  }

  public File getCopyFile(){
    return copyFile;
  }
  public boolean copy(int i){
    File f = getFile(i);
    if((f.isDirectory() || f.isFile()) && !util.isSystemFile(f)){
      copyFile = getFile(i);
      return true;
    }else return false;
  }
  public boolean move(int i){
    if(copy(i)){
      moveFile = copyFile;
      return true;
    }else return false;
  }
  public boolean paste(){
    try {
      if(util.copy(copyFile, currentDir)){
        if(moveFile!=null){
          util.delete(moveFile);
          copyFile = null;
          moveFile = null;
        }
        return true;
      }else return false;
    }
    catch (Exception ex) {
      ex.printStackTrace();
      return false;
    }

  }

  public void delete(File f){
    util.delete(f);
  }
  public void printText(){

  }

  public void login(String username, String password){
    if(username.startsWith("test")){
      logon = true;

      String[] s = {"localhost","test"};
      users = s;
      String[] i = {"127.0.0.1", username.substring(4)};
      ip = i;

      server = new Server("test", password);
      server.start();
      return;
    }else

    try {
      Socket con = new Socket(RemoteManager.SERVER_CENTER_IP, RemoteManager.PORT);
      DataInputStream din = new DataInputStream(con.getInputStream());
      DataOutputStream dout = new DataOutputStream(con.getOutputStream());

      FMPrequest req = new FMPrequest(FMPrequest.LOGIN);
      req.setName(username);
      req.setParameter(password);
      req.sendRequest(dout);

      FMPresponse res = new FMPresponse(din);
      if(res.getStatus()==res.OK){
        logon = true;
  //      res.readUsername();
   //     manager.showUser(res.getUsername(), res.getIP());
      }else{
        System.out.println("FAIL !!!");
      }
      din.close();
      dout.close();
      con.close();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public String[] getUsername(){
    return users;
  }
  public String[] getUserIP(){
    return ip;
  }
  public boolean isLogon(){
    return logon;
  }

  public boolean connect(int index, String password){
    try {
      Socket con = new Socket(ip[index], RemoteManager.PORT);
      DataInputStream din = new DataInputStream(con.getInputStream());
      DataOutputStream dout = new DataOutputStream(con.getOutputStream());
      FMPrequest req = new FMPrequest(FMPrequest.CONNECT);
      req.setName(users[index]);
      req.setParameter(password);
      req.sendRequest(dout);

      FMPresponse res = new FMPresponse(din);
      if(res.getStatus()==res.OK){
        this.username = username;
        this.password = password;
        RemoteHost r = new RemoteHost(con, res);
        remote.add(r);
        frame.addTabbedPane(r.getPanel(), users[index]+" ("+ip[index]+")");
        frame.setStatus("Connect to "+users[index]+" success");
        return true;
      }else {
        return false;
      }
    }
    catch (Exception ex) {
      return false;
    }
  }

  private void readUsername(FMPresponse res){
  try {
    ByteArrayInputStream bin = new ByteArrayInputStream(res.getContent());
    DataInputStream dbin = new DataInputStream(bin);
    int len = dbin.readInt();
    if(len>0){
      users = new String[len];
      ip = new String[len];
      for (int i = 0; i < len; i++) {
        users[i] = dbin.readUTF();
        ip[i] = dbin.readUTF();
      }
    }
  }
  catch (Exception ex) {
  }
}


}