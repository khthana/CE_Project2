package project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.HeadlessException;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class LoginDialog extends JDialog {
  private MainFrame frame;
  private JPanel jPanel1 = new JPanel();
  private JPanel jPanel2 = new JPanel();
  private JPanel jPanel3 = new JPanel();
  private JTextField userTF = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JPanel jPanel7 = new JPanel();
  private JPanel jPanel6 = new JPanel();
  private JPanel registerPane = new JPanel();
  private JLabel jLabel3 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton register = new JButton();
  private JButton login = new JButton();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JPasswordField pass1 = new JPasswordField();
  private JPasswordField pass2 = new JPasswordField();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel4 = new JPanel();
  private JButton cancelBtn1 = new JButton();
  private JPanel loginPane = new JPanel();
  private JButton loginBtn = new JButton();
  private JButton newBtn = new JButton();
  private CardLayout cardLayout1 = new CardLayout();

  public LoginDialog(MainFrame frame) throws HeadlessException {
    super(frame, "Login", true);
    this.frame = frame;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
   }
  }

  private void jbInit() throws Exception {
    jPanel1.setLayout(borderLayout1);
    jLabel1.setText("Username : ");
    jLabel2.setText("Password : ");
    userTF.setPreferredSize(new Dimension(217, 21));
    userTF.setColumns(20);
    this.setModal(true);
    this.setResizable(true);
    this.setTitle("Login");
    jLabel3.setText("Confirm :     ");
    jButton1.setText("Cancel");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel();
      }
    });
    register.setText("Register");
    register.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        register_actionPerformed(e);
      }
    });
    login.setText("Exist User");
    login.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        login_actionPerformed(e);
      }
    });
    registerPane.setLayout(verticalFlowLayout1);
    pass1.setColumns(31);
    pass2.setColumns(31);
    cancelBtn1.setText("Cancel");
    cancelBtn1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel();
      }
    });
    loginBtn.setText("Login");
    loginBtn.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loginBtn_actionPerformed(e);
      }
    });
    newBtn.setText("New User");
    newBtn.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        newBtn_actionPerformed(e);
      }
    });
    jPanel4.setLayout(cardLayout1);
    jPanel4.setPreferredSize(new Dimension(307, 83));
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    registerPane.add(jPanel7, null);
    jPanel7.add(jLabel3, null);
    jPanel7.add(pass2, null);
    registerPane.add(jPanel6, null);
    jPanel6.add(login, null);
    jPanel6.add(register, null);
    jPanel6.add(jButton1, null);
 //   jPanel1.add(registerPane, BorderLayout.SOUTH);////
    jPanel1.add(jPanel2,  BorderLayout.NORTH);
    jPanel2.add(jLabel1, null);
    jPanel2.add(userTF, null);
    jPanel1.add(jPanel3, BorderLayout.CENTER);
    jPanel3.add(jLabel2, null);
    jPanel3.add(pass1, null);
    jPanel4.add(loginPane,  "login");
    jPanel4.add(registerPane,  "register");
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    cardLayout1.show(jPanel4, "login");
    loginPane.add(newBtn, null);
    loginPane.add(loginBtn, null);
    loginPane.add(cancelBtn1, null);

    pack();
    setLocation(frame.getX()+frame.getWidth()/2-this.getWidth()/2,
                frame.getY()+frame.getHeight()/2-this.getHeight()/2);

  }

  void newBtn_actionPerformed(ActionEvent e) {
//    Container contentPane = getContentPane();
//    jPanel1.remove(loginPane);
//    jPanel1.add(registerPane, BorderLayout.SOUTH);
    //validate();
    cardLayout1.show(jPanel4,"register");
    this.repaint();
  }

  void cancel(){
    dispose();
  }

  void loginBtn_actionPerformed(ActionEvent e) {
    String username = userTF.getText();
    String pass = new String(pass1.getPassword());
    frame.login(username, pass);
    dispose();
  }

  void register_actionPerformed(ActionEvent e) {
  //  frame.register();
  }

  void login_actionPerformed(ActionEvent e) {
    cardLayout1.show(jPanel4,"login");
    this.repaint();

  }
  void cancelBtn1_actionPerformed(ActionEvent e) {

  }

}