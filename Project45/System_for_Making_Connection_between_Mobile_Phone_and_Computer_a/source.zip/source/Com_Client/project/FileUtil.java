package project;

import java.io.*;
import javax.swing.filechooser.*;
import java.util.*;
import javax.swing.*;
import java.util.*;
import java.text.DateFormat;
/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */
public class FileUtil {

  FileSystemView fsv = FileSystemView.getFileSystemView();
  boolean hideFile = false;

  public FileUtil() {
  }


  // parameter -String full path of file
  // return -InputStream of this file if exists
  //        -null if this path is not file or not exists
  public InputStream getFileInputStream(File file) throws IOException{
//    File file = new File(src);
    if(file!=null){
      if (file.isFile()) {
        FileInputStream fin = new FileInputStream(file);
        return fin;
      }
    }
    return null;
  }

  public byte[] getFile(File f) {
    try {
      byte b[] = null;
      if(f.isFile()){
        FileInputStream fin = new FileInputStream(f);
        Long l = new Long(f.length());
        b = new byte[l.intValue()];
        fin.read(b);
      }
      return b;
    }
    catch (Exception ex) {
      return null;
    }
  }

  public boolean writeFile(File f, byte[] b) {
    try {
//      File f = new File(filepath);
      FileOutputStream fout = new FileOutputStream(f);
      fout.write(b);
      return true;
    }
    catch (Exception ex) {
      return false;
    }
  }


  // parameter -InputStream stream that contain file data stream
  //           -String full path of this file
  // return -true if file have been write successful
  //        -false if file already exists or occured Exception while writing this file
  public boolean writeFile(InputStream in, File file) throws IOException{
//    File file = new File(path);
    if (file.exists()){
      return false;
    }
    BufferedInputStream bin = new BufferedInputStream(in);
    DataInputStream din = new DataInputStream(bin);

    FileOutputStream fout = new FileOutputStream(file);
    BufferedOutputStream bout = new BufferedOutputStream(fout);
    DataOutputStream dout = new DataOutputStream(bout);

    try {
      while (true)
        dout.writeByte(din.readByte());
    }catch (EOFException ex) {
      dout.close();
      return true;
    }catch (Exception e){
      return false;
    }
  }

  // parameter -String full path of source file or folder
  //           -String full path of destination folder
  //           (!!important!! "dest" is a path of folder that is placed "src")
  // return -true if file have been write successful
  //        -false if file already exists or occured Exception while writing this file
  public boolean copy(File src, File destDir) throws IOException{
//    File fsrc = new File(src);
//    File fdest = new File(dest+File.separator+fsrc.getName());
    File f = new File(destDir, src.getName());
    if (!src.exists() || f.exists())
      return false;
    else if (src.isDirectory()){ //selected path is folder
      if(f.mkdir()){  // try to create new folder
        String[] list = src.list();
        for (int i = 0; i < list.length; i++) {
          // copy all files in this folder
          if(!copy(new File(src, list[i]), f)){
            f.delete();
            return false;
          }
        }
        return true;
      }else return false;
    }else{
        FileInputStream fin = new FileInputStream(src);
        DataInputStream din = new DataInputStream(fin);

        FileOutputStream fout = new FileOutputStream(f);
        DataOutputStream dout = new DataOutputStream(fout);

        try{
          while (true)
            dout.writeByte(din.readByte());
        }catch(EOFException e){
          din.close();
          dout.close();
          return true;
        }
    }
 }

// parameter -String full path of file to delete
// return -true if file have been delete successful
//        -false if file already exists or occured Exception while deleting this file
 public boolean delete(File file) {
//   File file = new File(path);
   if(file.isDirectory()){
     String[] list = file.list();
     for (int i = 0; i < list.length; i++) {
       if(!delete(new File(file, list[i])))
         return false;
     }
   }
  return file.delete();
 }

 // parameter -String full path of this file
 //           -String new name of this file
 // return -true if file have been rename successfully
 //        -false if file not found
 //        -throws Exception if this file cannot access
 public boolean rename(File file, String newname) throws NullPointerException, SecurityException{
   File f = new File(getParent(file), newname);
   if(f.exists() && file.getName().compareTo(newname)==0)
     return true;
   return file.renameTo(f);
 }

 // parameter -String full path of parent
 //           -String new name of new folder
 // return -true if file have been rename successfully
 //        -false if file exists or cannot make new folder
 //        -throws Exception if this file cannot access

 public boolean createFolder(File folder,String name) throws SecurityException{
   File f = new File(folder, name);
   if(f.exists())
     return false;
   return f.mkdir();
 }

 public boolean getHideFile(){
   return hideFile;
 }

 public void setHideFile(boolean b){
   hideFile = b;
 }

 public boolean isSystemFile(File file){
/*   System.out.println("mycom is com node : "+fsv.isComputerNode(file));
   System.out.println("mycom is drive : "+fsv.isDrive(file));
   System.out.println("mycom is system file : "+fsv.isFileSystem(file));
   System.out.println("mycom is system root : "+fsv.isFileSystemRoot(file));
   System.out.println("mycom is hidden : "+fsv.isHiddenFile(file));
   System.out.println("--------------");
*/
   return (fsv.isComputerNode(file)|| fsv.isDrive(file)||
           fsv.isFileSystemRoot(file)||file.getName().equals("ShellFolder: "));
 }

 public File[] getRoots(){
   return fsv.getRoots();
 }

 public File[] getList(File f){
   return fsv.getFiles(f, hideFile);
 }

 public String getDisplayName(File f){
   return fsv.getSystemDisplayName(f);
 }

 public String getDate(long l){
   Date date = new Date(l);
   return DateFormat.getDateInstance(DateFormat.LONG).format(date);
 }

 public String getFileProperty(File f){
   StringBuffer prop = new StringBuffer();
   prop.append("Name : "+f.getName()+"\n");
   prop.append("Type : "+fsv.getSystemTypeDescription(f)+"\n");
   prop.append("Location : "+f.getParent()+"\n");
   prop.append("Size : "+f.length()+" bytes\n");
   prop.append("Last Modified : "+getDate(f.lastModified())+"\n");
   prop.append("is Hidden : "+f.isHidden()+"\n");
   prop.append("Readable : "+f.canRead()+"\n");
   prop.append("Writable : "+f.canWrite()+"\n");

   return prop.toString();
 }

 public ImageIcon getFileImgIcon(File f){
   ImageIcon icon = (ImageIcon) fsv.getSystemIcon(f);
   icon.setDescription(fsv.getSystemDisplayName(f));
   return icon;
 }

 public String getFileType(File f){
   return fsv.getSystemTypeDescription(f);
 }

 public File getParent(File f){
   return fsv.getParentDirectory(f);
 }

 public String runCommand(String cmdline, File workDir){
   if(cmdline != null){
     StringTokenizer tokens = new StringTokenizer(cmdline);
     Runtime rt = Runtime.getRuntime();
     int i = 0;
     String par[] = new String[tokens.countTokens()];
     while(tokens.hasMoreTokens())
       par[i++] = tokens.nextToken();

/*     File workDir = new File(path);
     if(workDir.exists()&&workDir.isDirectory())
       workDir = fsv.getHomeDirectory();
*/
     try {
       Process process = rt.exec(par, null, workDir);
       InputStream is = process.getInputStream();
       InputStream es = process.getErrorStream();
       String output = readString(is);
       String error = readString(es);
       return output+"\n"+error;
     }catch (IOException ex) {
       return "This command cannot operate.";
     }catch (SecurityException ex) {
       return "This command not allow to process.";
     }
   }else return null;
 }
 public String readString(InputStream is) throws IOException{
     StringBuffer buf = new StringBuffer();
     int data = 0;
     while((data = is.read())!=-1){
       buf.append((char) data);
     }
     return buf.toString();
 }

}