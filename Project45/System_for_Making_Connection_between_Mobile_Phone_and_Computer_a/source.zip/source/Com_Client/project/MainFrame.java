package project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.io.*;
import javax.swing.border.*;
import java.util.*;
/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class MainFrame extends JFrame implements ActionListener, ItemListener{
  private File currentDir;
  private LocalHost local = new LocalHost(this);

  private JPanel contentPane;
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenuFile = new JMenu();
  private JMenuItem jMenuFileExit = new JMenuItem();
  private JMenu jMenuHelp = new JMenu();
  private JMenuItem jMenuHelpAbout = new JMenuItem();
  private JToolBar jToolBar = new JToolBar();
  private JButton loginButton = new JButton();
  private JButton connectButton = new JButton();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel localPane = new JPanel();
  private JPanel remotePane = new JPanel();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList localList = new JList();
  private JPanel localDirPane = new JPanel();
  private JButton browseL = new JButton();
  private JComboBox dirBoxL ;
  private FileUtil util;
  private JPanel localButtonPane = new JPanel();
  private BorderLayout borderLayout2 = new BorderLayout();
  private IconRenderer renderer = new IconRenderer();

  private TitledBorder titledBorder1;
  private JButton propertyL = new JButton();
  private JButton pasteL = new JButton();
  private JButton copyL = new JButton();
  private JButton deleteL = new JButton();
  private JButton renameL = new JButton();
  private JButton newfolderL = new JButton();
  private JButton folderupL = new JButton();
  private JPanel jPanel5 = new JPanel();
  private JPanel StatusPane = new JPanel();
  private JLabel statusBar = new JLabel();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JTextArea statusTB = new JTextArea();
  private JButton cutL = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JPanel jPanel7 = new JPanel();
  private JButton downloadBtn = new JButton();
  private JButton printBtn = new JButton();
  private JButton uploadBtn = new JButton();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JTabbedPane tabbedPane = new JTabbedPane();
  private Border border1;
  private TitledBorder titledBorder2;
  private BorderLayout borderLayout3 = new BorderLayout();
  private JButton compileBtn = new JButton();
  private JButton runBtn = new JButton();
  private JPanel jPanel1 = new JPanel();
  private Border border2;
  private TitledBorder titledBorder3;
  private JMenuItem jMenuItem1 = new JMenuItem();
  private JMenuItem jMenuItem2 = new JMenuItem();
  private JMenu jMenu1 = new JMenu();
  private JMenuItem settingMenu = new JMenuItem();
  private JLabel jLabel2 = new JLabel();
  private JButton executeBtn = new JButton();

  //Construct the frame
  public MainFrame() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      updateLocal();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    ImageIcon exploreImg = new ImageIcon("images/explore24.PNG");
    ImageIcon folderupImg = new ImageIcon("images/folderup24.gif");
    ImageIcon newfolderImg = new ImageIcon("images/newfolder24.PNG");
    ImageIcon deleteImg = new ImageIcon("images/del24.PNG");
    ImageIcon renameImg = new ImageIcon("images/rename24.PNG");
    ImageIcon propertyImg = new ImageIcon("images/property24.PNG");
    ImageIcon copyImg = new ImageIcon("images/copy.gif");
    ImageIcon pasteImg = new ImageIcon("images/paste.PNG");
    ImageIcon cutImg = new ImageIcon("images/cut.PNG");
    ImageIcon commandImg = new ImageIcon("images/command32.PNG");
    ImageIcon loginImg = new ImageIcon("images/login.PNG");
    ImageIcon settingImg = new ImageIcon("images/setting.PNG");
    ImageIcon connectImg = new ImageIcon("images/connect.gif");
    ImageIcon uploadImg = new ImageIcon("images/upload.gif");
    ImageIcon downloadImg = new ImageIcon("images/download.gif");
    ImageIcon printImg = new ImageIcon("images/print.gif");
    ImageIcon runImg = new ImageIcon("images/play.gif");
    ImageIcon compileImg = new ImageIcon("images/compile.gif");
    ImageIcon exeImg = new ImageIcon("images/command24.PNG");
    //setIconImage(Toolkit.getDefaultToolkit().createImage(MainFrame.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158))," Local Host  ");
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    titledBorder2 = new TitledBorder(border1,"Status ");
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    titledBorder3 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158))," Remote Host ");
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(800, 600));
    this.setTitle("Remote Manager V1.0");
    jMenuFile.setText("New");
    jMenuFileExit.setText("Exit");
    jMenuFileExit.addActionListener(this);
    jMenuHelp.setText("Help");
    jMenuHelpAbout.setText("About");
    jMenuHelpAbout.addActionListener(this);
    loginButton.setIcon(loginImg);
    loginButton.setText("Login");
    loginButton.setToolTipText("Login");
    loginButton.addActionListener(this);
    connectButton.setIcon(connectImg);
    connectButton.setText("Connect");
    connectButton.setEnabled(false);
    connectButton.setToolTipText("Connect to remote host");
    connectButton.addActionListener(this);


    localList.setCellRenderer(renderer);
    localList.setFixedCellWidth(300);
    localList.setSelectedIndex(0);
    localList.setFont(new java.awt.Font("SansSerif", 0, 12));
    localList.setVisibleRowCount(14);
    localList.addMouseListener(new LocalList_mouseAdapter(this));


    browseL.setPreferredSize(new Dimension(26, 26));
    browseL.setToolTipText("Browse directory");
    browseL.setIcon(exploreImg);
    browseL.addActionListener(this);
    localPane.setLayout(borderLayout2);


    ImageIcon[] icon = {local.getCurrentDirImgIcon()};
    dirBoxL = new JComboBox(icon);
    renderer.setPreferredSize(new Dimension(200, 21));
    dirBoxL.setPreferredSize(new Dimension(250, 21));
    dirBoxL.setMaximumRowCount(2);
    dirBoxL.setRenderer(renderer);
    dirBoxL.addActionListener(this);

    localPane.setBorder(titledBorder1);
    propertyL.setPreferredSize(new Dimension(28, 28));
    propertyL.setToolTipText("View selected file\'s property");
    propertyL.setIcon(propertyImg);
    propertyL.addActionListener(this);
    pasteL.setEnabled(false);
    pasteL.setPreferredSize(new Dimension(28, 28));
    pasteL.setToolTipText("Paste ");
    pasteL.setIcon(pasteImg);
    pasteL.addActionListener(this);
    copyL.setPreferredSize(new Dimension(28, 28));
    copyL.setToolTipText("Copy selected file");
    copyL.setIcon(copyImg);
    copyL.addActionListener(this);
    deleteL.setPreferredSize(new Dimension(28, 28));
    deleteL.setToolTipText("Delete selected file");
    deleteL.setIcon(deleteImg);
    deleteL.addActionListener(this);
    renameL.setPreferredSize(new Dimension(28, 28));
    renameL.setToolTipText("Rename selected File");
    renameL.setIcon(renameImg);
    renameL.addActionListener(this);
    newfolderL.setAlignmentY((float) 0.0);
    newfolderL.setPreferredSize(new Dimension(28, 28));
    newfolderL.setToolTipText("Create new Folder");
    newfolderL.setIcon(newfolderImg);
    newfolderL.addActionListener(this);
    folderupL.setPreferredSize(new Dimension(26, 26));
    folderupL.setToolTipText("Go up one level");
    folderupL.setIcon(folderupImg);
    folderupL.addActionListener(this);
    statusBar.setText(" ");
    statusTB.setColumns(110);
    statusTB.setRows(3);
    cutL.setPreferredSize(new Dimension(28, 28));
    cutL.setToolTipText("Cut selected file");
    cutL.setIcon(cutImg);
    cutL.addActionListener(this);
    jLabel1.setText("  ");
    jPanel7.setLayout(verticalFlowLayout1);
    StatusPane.setBorder(titledBorder2);
    StatusPane.setLayout(borderLayout3);
    downloadBtn.setPreferredSize(new Dimension(109, 28));
    downloadBtn.setIcon(downloadImg);
    downloadBtn.setText("Download");
    uploadBtn.setPreferredSize(new Dimension(91, 28));
    uploadBtn.setIcon(uploadImg);
    uploadBtn.setText("Upload");
    printBtn.setPreferredSize(new Dimension(28, 28));
    printBtn.setIcon(printImg);
    printBtn.setText("Print");

    borderLayout2.setHgap(5);
    borderLayout2.setVgap(5);
    compileBtn.setText("Compile");
    compileBtn.setIcon(compileImg);
    runBtn.setText("Run");
    runBtn.setIcon(runImg);
    jPanel7.setEnabled(false);
    borderLayout1.setHgap(5);
    borderLayout1.setVgap(5);
    remotePane.setBorder(titledBorder3);
    jPanel5.setEnabled(false);
    jPanel5.setPreferredSize(new Dimension(61, 178));
    jMenuItem1.setText("Connect remote host");
    jMenuItem2.setToolTipText("");
    jMenuItem2.setText("Login");
    jMenu1.setText("Setting");
    settingMenu.setText("Preference");
    settingMenu.addActionListener(this);
    verticalFlowLayout1.setHgap(3);
    jLabel2.setPreferredSize(new Dimension(109, 100));
    executeBtn.setText("Command");
    executeBtn.setIcon(exeImg);
    localButtonPane.add(newfolderL, null);
    localButtonPane.add(renameL, null);
    localPane.add(localButtonPane,  BorderLayout.SOUTH);
    localButtonPane.add(deleteL, null);
    localButtonPane.add(cutL, null);
    localButtonPane.add(copyL, null);
    localButtonPane.add(pasteL, null);
    localButtonPane.add(propertyL, null);
    jToolBar.add(loginButton);
    jToolBar.add(connectButton);
    jToolBar.add(jLabel1, null);
    jMenuFile.add(jMenuItem2);
    jMenuFile.add(jMenuItem1);
    jMenuFile.add(jMenuFileExit);
    jMenuHelp.add(jMenuHelpAbout);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenu1);
    jMenuBar1.add(jMenuHelp);
    this.setJMenuBar(jMenuBar1);
    contentPane.add(jToolBar, BorderLayout.NORTH);
    //just test
    contentPane.add(localPane,  BorderLayout.WEST);
//    contentPane.add(local.getPanel(),  BorderLayout.WEST);

    contentPane.add(remotePane,  BorderLayout.EAST);

    remotePane.add(tabbedPane, null);
 //   tabbedPane.add(new RemotePanel(null), "Garlicia (161.246.6.68)");
    contentPane.add(StatusPane,  BorderLayout.SOUTH);
    StatusPane.add(jScrollPane2, BorderLayout.CENTER);
    jScrollPane2.getViewport().add(statusTB, null);
    StatusPane.add(statusBar,  BorderLayout.SOUTH);
    contentPane.add(jPanel5, BorderLayout.CENTER);
    jPanel5.add(jPanel7, null);
    jPanel7.add(jLabel2, null);
    jPanel7.add(executeBtn, null);
    jPanel7.add(compileBtn, null);
    jPanel7.add(runBtn, null);
    jPanel7.add(downloadBtn, null);
    jPanel7.add(uploadBtn, null);
    jPanel7.add(printBtn, null);
    localPane.add(localDirPane, BorderLayout.NORTH);
    localDirPane.add(dirBoxL, null);
    localDirPane.add(browseL, null);
    localPane.add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(localList, null);
    localDirPane.add(folderupL, null);
    jMenu1.add(settingMenu);

  }

  public void login(String username, String pass){
    local.login(username, pass);
    if(local.isLogon()){
      connectButton.setEnabled(true);
      loginButton.setText("Logout");
    }
  }
  public void connect(int index, String pass){
    if(local.connect(index, pass)){
    }
    else statusBar.setText("Cannot connect");
  }
  public void register(String username, String pass){
  }

  public void setStatus(String s){
    statusTB.append("\n"+s);
  }

  public void updateLocal(){
    try {
      dirBoxL.setToolTipText(local.getCurrentDir().getPath());
      localList.setListData(local.getListImgIcon());
    }
    catch (Exception ex) {
      System.err.println("Update Local ERROR!");
      ex.printStackTrace();
    }
  }

  public File chooseDir(){
    JFileChooser fc = new JFileChooser();
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    if(fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
      return fc.getSelectedFile();
    }else return null;
  }

  public void browseFolder(){
    File f = chooseDir();
    if (f!=null){
      local.setCurrentDir(f);
      updateLocalChoice();
      updateLocal();
    }
  }

  public void folderup(){
    if(local.folderup()){
      updateLocalChoice();
      updateLocal();
    }
  }

  public void actionPerformed(ActionEvent e) {
    if(e.getSource() == jMenuFileExit)
      jMenuFileExit_actionPerformed(e);
    else if(e.getSource() == jMenuHelpAbout)
      jMenuHelpAbout_actionPerformed(e);
    else if(e.getSource() == settingMenu)
      new SettingDialog(this).setVisible(true);
    else if(e.getSource() == loginButton)
      showLoginDialog();
    else if(e.getSource() == connectButton)
      showConnectDialog();
    else if(e.getSource() == browseL)
      browseFolder();
    else if(e.getSource() == folderupL)
      folderup();
    else if(e.getSource() == dirBoxL)
      changeLocalDir();
    else if(e.getSource() == newfolderL)
      createFolder();
    else if(e.getSource() == deleteL)
      deleteLocal();
    else if(e.getSource() == pasteL)
      pasteLocal();
    else if(e.getSource() == copyL)
      copyLocal();
    else if(e.getSource() == cutL)
      moveLocal();
    else if(e.getSource() == renameL)
      renameLocal();
    else if(e.getSource() == propertyL)
      propertyLocal();
  }

  public void propertyLocal(){
    int i = localList.getSelectedIndex();
    showInformation("File Property", local.getProperty(i), (Icon) local.getFileImgIcon(i));
  }

  public void renameLocal(){
    int i = localList.getSelectedIndex();
    File f = local.getFile(i);
    String s = showInput("Rename "+f.getName(), "Enter new name :", f.getName());
    if(s!=null){
      if(local.rename(i, s)){
        statusBar.setText("Rename \""+s+"\" completed");
        updateLocal();
      }else
        showError("Rename Error!", "Can not rename to \""+s+"\".");
    }
  }

  public void pasteLocal(){
    if(local.paste()){
      statusBar.setText("Paste file completed.");
      if(local.getCopyFile()==null)
        pasteL.setEnabled(false);
      updateLocal();
    }
    else showError("Paste Error", "You can not paste this file.");
  }

  public void deleteLocal(){
    int i = localList.getSelectedIndex();

    if(local.isFolder(i)){
      File f = local.getFile(i);
      if(showConfirm("Delete Confirmation", "Are you sure want to delete\n"+
                  f.getPath()+"\nand all its contents ?")){
        local.delete(f);
        updateLocal();
      }
    }else if(local.isFile(i)){
      File f = local.getFile(i);
      if(showConfirm("Delete Confirmation", "Are you sure want to delete\n"+
                  f.getPath()+" ?")){
        local.delete(f);
        updateLocal();
      }
    }else
      showError("Delete Error!","You can not delete system file.");
  }

  public void copyLocal(){
    if(local.copy(localList.getSelectedIndex()))
      updatePasteButton();
    else
      showError("Copy Error!","You can not copy system file.");
  }
  public void moveLocal(){
    if(local.move(localList.getSelectedIndex()))
      updatePasteButton();
    else
      showError("Copy Error!","You can not copy system file.");
  }
  private void updatePasteButton(){
    File copyFile = local.getCopyFile();
    if(copyFile!=null){
      pasteL.setEnabled(true);
      pasteL.setToolTipText("paste \""+copyFile.getPath()+"\"");
    }
  }

  public void createFolder(){
    String s = showInput("Create New Folder", "Enter folder name : ", "New Folder");
    if(s!=null){
      if(local.newFolder(s)){
        statusBar.setText("Create folder \""+s+"\" completed");
        updateLocal();
      }else showError("Create New Folder Error", "Can not create new folder with this name");
    }
  }

  public void changeLocalDir(){
    if(dirBoxL.isFocusOwner()){
      if(dirBoxL.getSelectedIndex()==0)
        local.setCurrentRoot();
      else local.setSecondDir();
      updateLocal();
    }
  }

  public void itemStateChanged(ItemEvent e){
    if(e.getSource()==localList)
      localList.setToolTipText(local.getListName(localList.getSelectedIndex()));
  }

  public void openFolder(int i){
    if(local.openFolder(i)){
      updateLocalChoice();
      updateLocal();
    }
  }

  public void updateLocalChoice(){
    int index = dirBoxL.getSelectedIndex();
    if(index != 0){
      dirBoxL.removeItemAt(1);
    }else index++;
    dirBoxL.insertItemAt(local.getCurrentDirImgIcon(), 1);
    dirBoxL.setSelectedIndex(1);

  }

  public void LocalList_mouseEntered(MouseEvent e){

  }

  public void LocalList_mouseClicked(MouseEvent e){
    if (e.getClickCount() == 2) {
      try {
        int i = localList.locationToIndex(e.getPoint());
        openFolder(i);
      }
      catch (Exception ex) {
        System.out.println("Open file ERROR!!");
        ex.printStackTrace();
      }
    }
  }

  public void addTabbedPane(JPanel pane, String text){
    tabbedPane.add(pane, text) ;
  }
  public void showLoginDialog(){
    new LoginDialog(this).setVisible(true);
  }
  public void showConnectDialog(){
    String name[] = local.getUsername();
    String ip[] = local.getUserIP();
    ImageIcon icon = new ImageIcon("images/red.PNG");
    ImageIcon icons[] = new ImageIcon[name.length];
    for (int i = 0; i < name.length; i++) {
      icons[i] = new ImageIcon(icon.getImage(), name[i]+" ("+ip[i]+") ");
    }
    ConnectDialog d = new ConnectDialog(this, icons, "Connect to...", "Select remote host to connect");
    d.setLocation(getX()+getWidth()/2-d.getWidth()/2,
                getY()+getHeight()/2-d.getHeight()/2);
    d.setVisible(true);
  }

  public void showError(String title, String message){
    JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
  }
  public void showInformation(String title, String message, Icon icon){
    JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE, icon);
  }
  public boolean showConfirm(String title, String message){
    return JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION);
  }
  public String showInput(String title, String message, String text){
    return (String) JOptionPane.showInputDialog(this, message, title, JOptionPane.QUESTION_MESSAGE,
                                       null, null, text);
  }
  //File | Exit action performed
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
  //Help | About action performed
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
  }

  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }
}


class LocalList_mouseAdapter extends java.awt.event.MouseAdapter {
  private MainFrame adaptee;

  LocalList_mouseAdapter(MainFrame adaptee) {
    this.adaptee = adaptee;
  }
  public void mouseClicked(MouseEvent e) {
    adaptee.LocalList_mouseClicked(e);
  }
  public void mouseEntered(MouseEvent e) {
    adaptee.LocalList_mouseEntered(e);
  }


}


