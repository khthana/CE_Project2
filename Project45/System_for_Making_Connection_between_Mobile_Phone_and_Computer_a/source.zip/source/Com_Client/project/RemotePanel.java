package project;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class RemotePanel extends JPanel {
  private RemoteHost host;

  private JPanel jPanel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel2 = new JPanel();
  private JPanel jPanel3 = new JPanel();
  private JButton folderup = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList list = new JList();
  private JButton paste = new JButton();
  private JButton copy = new JButton();
  private JButton cut = new JButton();
  private JButton delete = new JButton();
  private JButton rename = new JButton();
  private JButton newfolder = new JButton();
  private JButton browseL = new JButton();
  private JButton property = new JButton();
  private JList jList1 = new JList();
  private IconRenderer renderer = new IconRenderer();
  private JButton disconnect = new JButton();

  public RemotePanel(RemoteHost remoteHost) {
    try {
      host = remoteHost;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    ImageIcon folderupImg = new ImageIcon("images/folderup24.gif");
    ImageIcon newfolderImg = new ImageIcon("images/newfolder24.PNG");
    ImageIcon deleteImg = new ImageIcon("images/del24.PNG");
    ImageIcon renameImg = new ImageIcon("images/rename24.PNG");
    ImageIcon propertyImg = new ImageIcon("images/property24.PNG");
    ImageIcon copyImg = new ImageIcon("images/copy.PNG");
    ImageIcon pasteImg = new ImageIcon("images/paste.PNG");
    ImageIcon cutImg = new ImageIcon("images/cut.PNG");
    ImageIcon openImg = new ImageIcon("images/open16.PNG");
    ImageIcon exitImg = new ImageIcon("images/exit.PNG");

    this.setLayout(borderLayout1);
    folderup.setPreferredSize(new Dimension(28, 28));
    folderup.setIcon(folderupImg);
    folderup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        folderup_actionPerformed(e);
      }
    });
    paste.setEnabled(false);
    paste.setPreferredSize(new Dimension(28, 28));
    paste.setToolTipText("paste");
    paste.setIcon(pasteImg);
    cut.setPreferredSize(new Dimension(28, 28));
    cut.setToolTipText("Cut selected file");
    cut.setIcon(cutImg);
    delete.setPreferredSize(new Dimension(28, 28));
    delete.setToolTipText("Delete selected file");
    delete.setIcon(deleteImg);
    browseL.setPreferredSize(new Dimension(26, 26));
    browseL.setToolTipText("Browse directory");
    list.setFont(new java.awt.Font("SansSerif", 0, 12));
    list.setCellRenderer(renderer);
    list.setFixedCellWidth(300);
    list.setVisibleRowCount(15);
    list.addMouseListener(new MouseAdapter() {
        public void mouseClicked(MouseEvent e) {
            if (e.getClickCount() == 2) {
              openfolder(list.locationToIndex(e.getPoint()));
            }
        }
    });

    newfolder.setPreferredSize(new Dimension(28, 28));
    newfolder.setToolTipText("Create New Folder");
    newfolder.setIcon(newfolderImg);
    rename.setPreferredSize(new Dimension(28, 28));
    rename.setToolTipText("Rename selected file");
    rename.setIcon(renameImg);
    copy.setPreferredSize(new Dimension(28, 28));
    copy.setToolTipText("Copy selected file");
    copy.setIcon(copyImg);
    property.setPreferredSize(new Dimension(28, 28));
    property.setToolTipText("view property");
    property.setIcon(propertyImg);
    jList1.setFixedCellWidth(270);
    jList1.setCellRenderer(renderer);
    jList1.setSelectionBackground(Color.white);
    jList1.setVisibleRowCount(1);
    openImg.setDescription("TEST DIR");
    ImageIcon icon[] = {openImg};
    jList1.setListData(icon);
    disconnect.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        disconnect_actionPerformed(e);
      }
    });
    disconnect.setPreferredSize(new Dimension(28, 28));
    disconnect.setIcon(exitImg);
    this.add(jPanel1,  BorderLayout.NORTH);
    jPanel1.add(jList1, null);
    jPanel1.add(folderup, null);
    this.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(list, null);
    this.add(jPanel3, BorderLayout.SOUTH);
    jPanel3.add(newfolder, null);
    jPanel3.add(rename, null);
    jPanel3.add(delete, null);
    jPanel3.add(cut, null);
    jPanel3.add(copy, null);
    jPanel3.add(paste, null);
    jPanel3.add(property, null);
    jPanel3.add(disconnect, null);
  }

  void folderup_actionPerformed(ActionEvent e) {
  }

  public void updateList(String current, String[] file, int[] type){
    ImageIcon folderImg = new ImageIcon("images/folder16.PNG");
    folderImg.setDescription(current);
    ImageIcon[] icons = {folderImg};
    jList1.setListData(icons);


    ImageIcon fileImg = new ImageIcon("images/binfile.PNG");
    icons = new ImageIcon[file.length];
    for (int i = 0; i < file.length; i++) {
      if(type[i]==0)
        icons[i] = new ImageIcon(folderImg.getImage() , file[i]);
      else
        icons[i] = new ImageIcon(fileImg.getImage() , file[i]);
      icons[i].setDescription(file[i]);
    }
    list.setListData(icons);
  }

  public void setList(String path, String[] name, int[] type){

  }

  private void openfolder(int i){

  }

  void disconnect_actionPerformed(ActionEvent e) {

  }

}