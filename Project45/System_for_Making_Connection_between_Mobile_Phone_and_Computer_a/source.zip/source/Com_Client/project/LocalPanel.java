package project;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class LocalPanel extends JPanel implements ActionListener, ItemListener{
  private BorderLayout borderLayout1 = new BorderLayout();
  private JList localList = new JList();
  private JPanel localDirPane = new JPanel();
  private JButton browseL = new JButton();
  private JComboBox dirBoxL ;
  private FileUtil util;
  private JPanel localButtonPane = new JPanel();
  private BorderLayout borderLayout2 = new BorderLayout();
  private IconRenderer renderer = new IconRenderer();

  private JButton cutL = new JButton();
  private JButton propertyL = new JButton();
  private JButton pasteL = new JButton();
  private JButton copyL = new JButton();
  private JButton deleteL = new JButton();
  private JButton renameL = new JButton();
  private JButton newfolderL = new JButton();
  private JButton folderupL = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private TitledBorder titledBorder1;

  private LocalHost local;
  public LocalPanel(LocalHost l) {
    try {
      local = l;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    ImageIcon exploreImg = new ImageIcon("images/explore24.PNG");
    ImageIcon folderupImg = new ImageIcon("images/folderup24.PNG");
    ImageIcon newfolderImg = new ImageIcon("images/newfolder24.PNG");
    ImageIcon deleteImg = new ImageIcon("images/del24.PNG");
    ImageIcon renameImg = new ImageIcon("images/rename24.PNG");
    ImageIcon propertyImg = new ImageIcon("images/property24.PNG");
    ImageIcon copyImg = new ImageIcon("images/copy.PNG");
    ImageIcon pasteImg = new ImageIcon("images/paste.PNG");
    ImageIcon cutImg = new ImageIcon("images/cut.PNG");

    localList.setCellRenderer(renderer);
    localList.setFixedCellWidth(300);
    localList.setSelectedIndex(0);
    localList.setFont(new java.awt.Font("SansSerif", 0, 12));
    localList.setVisibleRowCount(14);
    localList.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
//                    setButton.doClick();
                }         }        });

    browseL.setPreferredSize(new Dimension(26, 26));
    browseL.setToolTipText("Browse directory");
    browseL.setIcon(exploreImg);
    browseL.addActionListener(this);

    ImageIcon[] icon = {local.getCurrentDirImgIcon()};
    dirBoxL = new JComboBox(icon);
    renderer.setPreferredSize(new Dimension(200, 21));
    dirBoxL.setPreferredSize(new Dimension(250, 21));
    dirBoxL.setMaximumRowCount(2);
    dirBoxL.setRenderer(renderer);
    dirBoxL.addActionListener(this);

    propertyL.setPreferredSize(new Dimension(28, 28));
    propertyL.setToolTipText("View selected file\'s property");
    propertyL.setIcon(propertyImg);
    propertyL.addActionListener(this);

    pasteL.setEnabled(false);
    pasteL.setPreferredSize(new Dimension(28, 28));
    pasteL.setToolTipText("Paste ");
    pasteL.setIcon(pasteImg);
    pasteL.addActionListener(this);

    copyL.setPreferredSize(new Dimension(28, 28));
    copyL.setToolTipText("Copy selected file");
    copyL.setIcon(copyImg);
    copyL.addActionListener(this);

    deleteL.setPreferredSize(new Dimension(28, 28));
    deleteL.setToolTipText("Delete selected file");
    deleteL.setIcon(deleteImg);
    deleteL.addActionListener(this);

    renameL.setPreferredSize(new Dimension(28, 28));
    renameL.setToolTipText("Rename selected File");
    renameL.setIcon(renameImg);
    renameL.addActionListener(this);

    newfolderL.setPreferredSize(new Dimension(28, 28));
    newfolderL.setToolTipText("Create new Folder");
    newfolderL.setIcon(newfolderImg);
    newfolderL.addActionListener(this);

    folderupL.setPreferredSize(new Dimension(26, 26));
    folderupL.setToolTipText("Go up one level");
    folderupL.setIcon(folderupImg);
    folderupL.addActionListener(this);

    cutL.setPreferredSize(new Dimension(28, 28));
    cutL.setToolTipText("Cut selected file");
    cutL.setIcon(cutImg);
    cutL.addActionListener(this);

    add(localButtonPane,  BorderLayout.SOUTH);
    localButtonPane.add(newfolderL, null);
    localButtonPane.add(renameL, null);
    localButtonPane.add(deleteL, null);
    localButtonPane.add(cutL, null);
    localButtonPane.add(copyL, null);
    localButtonPane.add(pasteL, null);
    localButtonPane.add(propertyL, null);

    add(localDirPane, BorderLayout.NORTH);
    localDirPane.add(dirBoxL, null);
    localDirPane.add(browseL, null);
    add(jScrollPane1,  BorderLayout.CENTER);
    jScrollPane1.getViewport().add(localList, null);
    localDirPane.add(folderupL, null);

    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158))," Local Host ");
    this.setBorder(titledBorder1);
    this.setLayout(borderLayout1);

    this.setSize(300,400);
  }
  public void actionPerformed(ActionEvent e) {
    if(e.getSource() == browseL)
      browseFolder();
    else if(e.getSource() == folderupL)
      folderup();
    else if(e.getSource() == dirBoxL)
      changeLocalDir();
    else if(e.getSource() == newfolderL)
      createFolder();
    else if(e.getSource() == deleteL)
      deleteLocal();
    else if(e.getSource() == pasteL)
      pasteLocal();
    else if(e.getSource() == copyL)
      copyLocal();
    else if(e.getSource() == cutL)
      moveLocal();
    else if(e.getSource() == renameL)
      renameLocal();
    else if(e.getSource() == propertyL)
      propertyLocal();
  }

  public void itemStateChanged(ItemEvent e){
    if(e.getSource()==localList)
      localList.setToolTipText(local.getListName(localList.getSelectedIndex()));
  }

  public void updateLocal(){
    try {
      dirBoxL.setToolTipText(local.getCurrentDir().getPath());
      localList.setListData(local.getListImgIcon());
    }
    catch (Exception ex) {
      System.err.println("Update Local ERROR!");
      ex.printStackTrace();
    }
  }

  public File chooseDir(){
    JFileChooser fc = new JFileChooser();
    fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
    if(fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION){
      return fc.getSelectedFile();
    }else return null;
  }

  public void browseFolder(){
    File f = chooseDir();
    if (f!=null){
      local.setCurrentDir(f);
      updateLocalChoice();
      updateLocal();
    }
  }

  public void folderup(){
    if(local.folderup()){
      updateLocalChoice();
      updateLocal();
    }
  }
  public void propertyLocal(){
    int i = localList.getSelectedIndex();
    showInformation("File Property", local.getProperty(i), (Icon) local.getFileImgIcon(i));
  }

  public void renameLocal(){
    int i = localList.getSelectedIndex();
    File f = local.getFile(i);
    String s = showInput("Rename "+f.getName(), "Enter new name :", f.getName());
    if(s!=null){
      if(local.rename(i, s)){
//        statusBar.setText("Rename \""+s+"\" completed");
        updateLocal();
      }else
        showError("Rename Error!", "Can not rename to \""+s+"\".");
    }
  }

  public void pasteLocal(){
    if(local.paste()){
//      statusBar.setText("Paste file completed.");
      if(local.getCopyFile()==null)
        pasteL.setEnabled(false);
      updateLocal();
    }
    else showError("Paste Error", "You can not paste this file.");
  }

  public void deleteLocal(){
    int i = localList.getSelectedIndex();

    if(local.isFolder(i)){
      File f = local.getFile(i);
      if(showConfirm("Delete Confirmation", "Are you sure want to delete\n"+
                  f.getPath()+"\nand all its contents ?")){
        local.delete(f);
        updateLocal();
      }
    }else if(local.isFile(i)){
      File f = local.getFile(i);
      if(showConfirm("Delete Confirmation", "Are you sure want to delete\n"+
                  f.getPath()+" ?")){
        local.delete(f);
        updateLocal();
      }
    }else
      showError("Delete Error!","You can not delete system file.");
  }

  public void copyLocal(){
    if(local.copy(localList.getSelectedIndex()))
      updatePasteButton();
    else
      showError("Copy Error!","You can not copy system file.");
  }
  public void moveLocal(){
    if(local.move(localList.getSelectedIndex()))
      updatePasteButton();
    else
      showError("Copy Error!","You can not copy system file.");
  }
  private void updatePasteButton(){
    File copyFile = local.getCopyFile();
    if(copyFile!=null){
      pasteL.setEnabled(true);
      pasteL.setToolTipText("paste \""+copyFile.getPath()+"\"");
    }
  }

  public void createFolder(){
    String s = showInput("Create New Folder", "Enter folder name : ", "New Folder");
    if(s!=null){
      if(local.newFolder(s)){
//        statusBar.setText("Create folder \""+s+"\" completed");
        updateLocal();
      }else showError("Create New Folder Error", "Can not create new folder with this name");
    }
  }

  public void changeLocalDir(){
    if(dirBoxL.isFocusOwner()){
      if(dirBoxL.getSelectedIndex()==0)
        local.setCurrentRoot();
      else local.setSecondDir();
      updateLocal();
    }
  }

  public void openFolder(int i){
    if(local.openFolder(i)){
      updateLocalChoice();
      updateLocal();
    }
  }

  public void updateLocalChoice(){
    int index = dirBoxL.getSelectedIndex();
    if(index != 0){
      dirBoxL.removeItemAt(1);
    }else index++;
    dirBoxL.insertItemAt(local.getCurrentDirImgIcon(), 1);
    dirBoxL.setSelectedIndex(1);

  }
  public void showError(String title, String message){
    JOptionPane.showMessageDialog(this, message, title, JOptionPane.ERROR_MESSAGE);
  }
  public void showInformation(String title, String message, Icon icon){
    JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE, icon);
  }
  public boolean showConfirm(String title, String message){
    return JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(this, message, title, JOptionPane.YES_NO_OPTION);
  }
  public String showInput(String title, String message, String text){
    return (String) JOptionPane.showInputDialog(this, message, title, JOptionPane.QUESTION_MESSAGE,
                                       null, null, text);
  }

}