package project;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.HeadlessException;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;

/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class SettingDialog extends JDialog {
  private MainFrame frame;
  private JPanel jPanel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel4 = new JPanel();
  private JButton cancelBtn1 = new JButton();
  private JPanel loginPane = new JPanel();
  private JButton loginBtn = new JButton();
  private FlowLayout flowLayout1 = new FlowLayout();
  private JPanel jPanel5 = new JPanel();
  private JTextField userTF = new JTextField();
  private JPanel jPanel2 = new JPanel();
  private JLabel jLabel1 = new JLabel();
  private JPanel jPanel3 = new JPanel();
  private JPasswordField pass1 = new JPasswordField();
  private JLabel jLabel2 = new JLabel();
  private Border border1;
  private TitledBorder titledBorder1;
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();

  public SettingDialog(MainFrame frame) throws HeadlessException {
    super(frame, "Login", true);
    this.frame = frame;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
   }
  }

  private void jbInit() throws Exception {
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    titledBorder1 = new TitledBorder(border1,"Server Center Setting ");
    jPanel1.setLayout(borderLayout1);
    this.setModal(true);
    this.setResizable(true);
    this.setTitle("Preferrence");
    cancelBtn1.setText("Cancel");
    cancelBtn1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cancel();
      }
    });
    loginBtn.setText("OK");
    loginBtn.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        loginBtn_actionPerformed(e);
      }
    });
    jPanel4.setPreferredSize(new Dimension(307, 47));
    loginPane.setLayout(flowLayout1);
    flowLayout1.setAlignment(FlowLayout.RIGHT);
    userTF.setPreferredSize(new Dimension(217, 21));
    userTF.setColumns(20);
    jLabel1.setToolTipText("");
    jLabel1.setText("           Server Port  : ");
    pass1.setColumns(31);
    jLabel2.setToolTipText("");
    jLabel2.setText("Server IP address : ");
    jPanel5.setBorder(titledBorder1);
    jPanel5.setLayout(verticalFlowLayout1);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
 //   jPanel1.add(registerPane, BorderLayout.SOUTH);////
    jPanel4.add(loginPane, null);
    jPanel1.add(jPanel4,  BorderLayout.SOUTH);
    loginPane.add(loginBtn, null);
    loginPane.add(cancelBtn1, null);
    jPanel1.add(jPanel5,  BorderLayout.CENTER);
    jPanel3.add(jLabel2, null);
    jPanel3.add(pass1, null);
    jPanel5.add(jPanel3, null);
    jPanel5.add(jPanel2, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(userTF, null);

    pack();
    setLocation(frame.getX()+frame.getWidth()/2-this.getWidth()/2,
                frame.getY()+frame.getHeight()/2-this.getHeight()/2);
  }

  void cancel(){
    dispose();
  }

  void loginBtn_actionPerformed(ActionEvent e) {
    String username = userTF.getText();
    String pass = new String(pass1.getPassword());
    frame.login(username, pass);
    dispose();
  }


  void cancelBtn1_actionPerformed(ActionEvent e) {

  }

}