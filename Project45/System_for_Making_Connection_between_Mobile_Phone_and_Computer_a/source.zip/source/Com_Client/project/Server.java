package project;
import java.net.*;
import java.io.*;
import protocol.*;

/**
 * <p>Title: Senior Project</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author 42010036
 * @version 1.0
 */

public class Server extends Thread{
  private ServerSocket server;
  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;
  private boolean done = false;
  private final String username;
  private final String password;

  private boolean debug = true;

  public Server(String username, String password) {
    this.username = username;
    this.password = password;
  }
  public void run(){
    try {
      // Step 1: Create a ServerSocket.
      server = new ServerSocket( 6000 );
      while ( !done ) {
        // Step 2: Wait for a connection.
        System.out.println ("Wait for a connection.");
        connection = server.accept();
        input = connection.getInputStream();
        output = connection.getOutputStream() ;
        din = new DataInputStream( input );
        dout = new DataOutputStream( output );
        verifyPassword();
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
  }
  public void verifyPassword() throws Exception{
    FMPrequest req = new FMPrequest(din);

    if(password.equals(req.getParameter()) && FMPrequest.CONNECT == req.getMethod()){
//      FMPresponse res = new FMPresponse(FMPresponse.OK);
//      res.sendResponse(dout);
      new ServerThread(connection).start();
    }else {
      FMPresponse res = new FMPresponse(FMPresponse.FAIL);
      res.sendResponse(dout);
      res.setParameter("Password incorrect.");
    }
  }

  public void close(){
    done = true;
  }

  public static void main(String[] args) {
    new Server("test", "pass").start();
  }
}