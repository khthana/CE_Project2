package manage_storage;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame1 extends JFrame {
  private JPanel contentPane;
  private Application1  app;
  private JPanel jPanel1 = new JPanel();
  private JPanel jPanel5 = new JPanel();
  private JPanel jPanel6 = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  private BorderLayout borderLayout1 = new BorderLayout();
  private XYLayout xYLayout2 = new XYLayout();
  private XYLayout xYLayout3 = new XYLayout();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JButton Search_T = new JButton();
  private JTextField type = new JTextField();
  private JTextField type_size = new JTextField();
  private JButton Edit_T = new JButton();
  private JLabel jLabel5 = new JLabel();
  private JTextField name = new JTextField();
  private JLabel jLabel6 = new JLabel();
  private JTextField ip = new JTextField();
  private JLabel jLabel7 = new JLabel();
  private JTextField used_size = new JTextField();
  private JButton Search = new JButton();
  private JButton Edit = new JButton();
  private JButton List = new JButton();
  private TitledBorder titledBorder1;
  private JButton Create_T = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JLabel Status_Bar = new JLabel();
  private JButton Create_D = new JButton();
  private JButton List_T = new JButton();
  private JLabel jLabel2 = new JLabel();
  private JTextField password = new JTextField();
  private JLabel Label = new JLabel();
  private JTextArea ListUser = new JTextArea();



  //Construct the frame
  public Frame1(Application1 a)
  {
    app = a;
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame1.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(151, 152, 155)),"Detail Custom Storage");
    this.setSize(new Dimension(470, 360));
    this.setTitle("Storage Manage");
    contentPane.setMinimumSize(new Dimension(444, 258));
    contentPane.setPreferredSize(new Dimension(444, 258));
    contentPane.setLayout(borderLayout1);
    jPanel1.setLayout(xYLayout1);
    jPanel5.setBorder(titledBorder1);
    jPanel5.setToolTipText("");
    jPanel5.setLayout(xYLayout2);
    jPanel6.setBorder(titledBorder1);
    jPanel6.setLayout(xYLayout3);
    jLabel3.setText("TYPE :");
    jLabel4.setText("SIZE :");
    Search_T.setText("Search");
    Search_T.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Search_T_actionPerformed(e);
      }
    });
    Edit_T.setText("Edit");
    Edit_T.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_T_actionPerformed(e);
      }
    });
    jLabel5.setText("NAME :");
    jLabel6.setText("IP Address :");
    jLabel7.setText("Used Size :");
    Search.setText("Search");
    Search.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Search_actionPerformed(e);

      }
    });
    Edit.setText("Edit");
    Edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_actionPerformed(e);
      }
    });
    List.setText("List");
    List.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        List_actionPerformed(e);
      }
    });
    Create_T.setText("Create");
    Create_T.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Create_T_actionPerformed(e);
      }
    });
    type_size.setColumns(6);
    jLabel1.setText("Status : ");
    Status_Bar.setText("Ready!!!");
    Create_D.setText("Create");
    Create_D.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Create_D_actionPerformed(e);
      }
    });
    List_T.setText("List");
    List_T.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        List_T_actionPerformed(e);
      }
    });
    jLabel2.setText("Password");

    Label.setText("List Username");
    contentPane.add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jPanel6,                 new XYConstraints(9, 214, 250, 113));
    jPanel6.add(type,     new XYConstraints(43, 10, 83, -1));
    jPanel6.add(jLabel3,  new XYConstraints(4, 12, -1, -1));
    jPanel6.add(type_size,  new XYConstraints(169, 9, -1, -1));
    jPanel6.add(jLabel4, new XYConstraints(133, 12, -1, -1));
    jPanel1.add(jPanel5,         new XYConstraints(9, 9, 249, 204));
    jPanel5.add(jLabel7, new XYConstraints(11, 108, -1, -1));
    jPanel5.add(used_size,  new XYConstraints(80, 104, 141, -1));
    jPanel1.add(jLabel1,   new XYConstraints(273, 294, -1, -1));
    jPanel1.add(Status_Bar,       new XYConstraints(318, 294, -1, -1));
    jPanel5.add(Search, new XYConstraints(21, 151, 75, 22));
    jPanel5.add(List,   new XYConstraints(142, 152, 74, 22));
    jPanel5.add(Edit, new XYConstraints(143, 129, 73, 22));
    jPanel5.add(Create_D,     new XYConstraints(21, 129, 75, 21));
    jPanel5.add(jLabel5, new XYConstraints(12, 10, -1, -1));
    jPanel5.add(name, new XYConstraints(79, 7, 143, -1));
    jPanel5.add(jLabel6, new XYConstraints(11, 41, -1, -1));
    jPanel5.add(jLabel2,  new XYConstraints(11, 77, -1, -1));
    jPanel5.add(ip,  new XYConstraints(79, 40, 143, -1));
    jPanel5.add(password,  new XYConstraints(79, 70, 144, -1));
    jPanel6.add(Create_T,    new XYConstraints(22, 37, 76, 21));
    jPanel6.add(Search_T,   new XYConstraints(22, 61, 76, 21));
    jPanel6.add(Edit_T, new XYConstraints(143, 38, 73, 21));
    jPanel6.add(List_T,     new XYConstraints(143, 62, 74, 20));
    jPanel1.add(ListUser,  new XYConstraints(268, 41, 182, 244));
    jPanel1.add(Label, new XYConstraints(323, 16, -1, -1));
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  public void Show_Result(String Tname,String Tip,String PassT,String Tsize)
  {
    name.setText(Tname);
    ip.setText(Tip);
    password.setText(PassT);
    used_size.setText(Tsize);
  }
  public void Show_Result_Type(String Ttype,String Tsize_t)
  {
    type.setText(Ttype);
    type_size.setText(Tsize_t);

  }
  public void Show_List(String temp,String head)
  {
    Label.setText(head);
    ListUser.setText(temp);
  }

  void Search_actionPerformed(ActionEvent e)
  {
    String Tname = null;
    //String Tip = null;
    String Tpass = null;

    Tname = name.getText();
    //Tip = ip.getText();
    Tpass = password.getText();
    app.Search(Tname,Tpass);

  }

  void Edit_actionPerformed(ActionEvent e)
  {
    String Tname = null;
    String Tip = null;
    String Tused = null;
    String Tpass = null;

    Tname = name.getText();
    Tip = ip.getText();
    Tpass = password.getText();
    Tused = used_size.getText();
    app.Edit(Tname,Tip,Tused,Tpass);

  }

  void List_actionPerformed(ActionEvent e)
  {
    app.List();

  }

  void Search_T_actionPerformed(ActionEvent e)
  {
    String Ttype = null;
    String Tnum = null;

    Ttype = type.getText();
    app.Search_Type(Ttype);

  }

  void Edit_T_actionPerformed(ActionEvent e)
  {
    String Ttype = null;
    String Tsize_t = null;

    Ttype = type.getText();
    Tsize_t = type_size.getText();
    app.Edit_Size(Ttype,Tsize_t);
  }

  void Create_T_actionPerformed(ActionEvent e)
  {
    String Ttype = null;
    String Tsize_t = null;

    Ttype = type.getText();
    Tsize_t = type_size.getText();
    app.Create_Type(Ttype,Tsize_t);
  }

  public void Show_Status(String Status_BarT)
  {
    Status_Bar.setText(Status_BarT);

  }

  void Create_D_actionPerformed(ActionEvent e)
  {
    String Tname = null;
    String Tip = null;
    String Tused_size = null;
    String Tpass = null;

    Tname = name.getText();
    Tip = ip.getText();
    Tpass = password.getText();
    Tused_size = used_size.getText();
    app.Create_Detail(Tname,Tip,Tused_size,Tpass);
  }

  void List_T_actionPerformed(ActionEvent e)
  {
    app.List_Type();
  }




}