package manage_storage;

import javax.swing.UIManager;
import java.awt.*;
import java.sql.*;
import java.io.*;
import java.net.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Application1
{
  private boolean packFrame = false;

  static public String path = null;

  private ServerSocket server;
  private Socket connection;
  private InputStream input;
  private OutputStream output;
  private DataInputStream din;
  private DataOutputStream dout;

  String driverName = "sun.jdbc.odbc.JdbcOdbcDriver";
  String connectionURL = "jdbc:odbc:Storage_DB";
  Frame1 frame;

  //Construct the application
  public Application1()
  {
     frame = new Frame1(this);
    //Validate frames that have preset sizes
    //Pack frames that have useful preferred size info, e.g. from their layout
    if (packFrame)
    {
      frame.pack();
    }
    else
    {
      frame.validate();
    }
    //Center the window
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height)
    {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width)
    {
      frameSize.width = screenSize.width;
    }
    frame.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }

  public void List()
  {
    try
    {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql ="Select * FROM Storage_DB ";
       ResultSet l = null;
       l = stmt.executeQuery(sql);
       String temp = "";

       while(l.next())
       {
          temp = temp+l.getString("NAME")+"("+l.getString("SIZE")+")";
          temp = temp +"\n";
       }

       frame.Show_List(temp,"List Username");
       frame.Show_Status("List Complate");
       stmt.close();
       con.close();
    }catch(Exception e)
    {
       e.printStackTrace();
    }
  }

  public void List_Type()
  {
    try
    {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql ="Select * FROM TYPE ";
       ResultSet l = null;
       l = stmt.executeQuery(sql);
       String temp = "";

       while(l.next())
       {
          temp = temp+l.getString("TYPE")+"("+l.getString("TYPE_SIZE")+")";
          temp = temp+"\n";
       }
       frame.Show_List(temp,"List Type");
       frame.Show_Status("List Complate");
       stmt.close();
       con.close();
    }catch(Exception e)
    {
       e.printStackTrace();
    }
  }

  public void Search(String NameT,String IpT)
  {
    try
    {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql ="Select * FROM Storage_DB WHERE NAME = '"+NameT+"'";
       ResultSet l = null;
       l = stmt.executeQuery(sql);
       int tmp = 1;

       while(l.next())
       {
          frame.Show_Result(l.getString("NAME"),l.getString("IP"),l.getString("Pass"),l.getString("SIZE"));
          frame.Show_Status("Search Complate");
          tmp = -1;
       }
       if (tmp != -1) frame.Show_Status("Not Found...!!!");
       stmt.close();
       con.close();
    }catch(Exception e)
    {
       e.printStackTrace();
    }
  }

  public void Search_Type(String TypeT)
  {
    try
    {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();
       frame.Show_Status("Waiting...");

       String sql ="Select * FROM TYPE WHERE TYPE = '"+TypeT+"'";
       ResultSet l = null;
       l = stmt.executeQuery(sql);
       int tmp = 1;
       while(l.next())
       {
          frame.Show_Result_Type(l.getString("TYPE"),l.getString("TYPE_SIZE"));
          frame.Show_Status("Search Type Complate");
          tmp = -1;
       }
       if (tmp != -1) frame.Show_Status("Not Found...!!!");
       stmt.close();
       con.close();
    }catch(Exception e)
    {
       e.printStackTrace();
    }
  }

   public void Edit(String NameT,String IpT,String SizeT,String PassT)
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM Storage_DB ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;

       while(j.next())
       {
         if(NameT.equals(j.getString("NAME") ))       {i = -1;}
       }
       if (i == -1)
       {
         sql = "UPDATE Storage_DB SET SIZE='"+SizeT+"',IP='"+IpT+"',Pass='"+PassT+"' WHERE NAME = '"+NameT+"'" ;
         stmt.executeUpdate(sql);
         //dout.writeUTF("Edit Complete");
         frame.Show_Status("Edit Complate");
       }else
       {
         //dout.writeUTF("IP not found");
         frame.Show_Status("Not Found...!!!");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

   public void Edit_Size(String TypeT,String Type_SizeT)
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM TYPE ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;

       while(j.next())
       {
         if(TypeT.equals(j.getString("TYPE") ))       {i = -1;}
       }
       if (i == -1)
       {
         sql = "UPDATE TYPE SET TYPE_SIZE='"+Type_SizeT+"' WHERE TYPE = '"+TypeT+"'" ;
         stmt.executeUpdate(sql);
         //dout.writeUTF("Edit Complete");
         frame.Show_Status("Edit Size Complate");
       }else
       {
         //dout.writeUTF("TYPE not found");
         frame.Show_Status("Not Found...!!!");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

   public void Create_Type(String TypeT,String Type_SizeT)
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM TYPE ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;

       while(j.next())
       {
         if(TypeT.equals(j.getString("TYPE") ))       {i = -1;}
         //if(Type_SizeT.equals(j.getString("TYPE_SIZE") ))   {i = -1;}
       }
       if (i == 1)
       {
         sql = "INSERT INTO TYPE(TYPE,TYPE_SIZE) VALUES('"+TypeT+"','"+Type_SizeT+"')";
         stmt.executeUpdate(sql);
         //dout.writeUTF("Register Complete");
         frame.Show_Status("Create Complate");
       }else
       {
         //dout.writeUTF("Already Login");
         frame.Show_Status("Already Type...!!!");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

   public void Create_Detail(String NameT,String IpT,String Used_SizeT,String PassT)
   {
     try
     {
       Class.forName(driverName).newInstance();
       Connection con = DriverManager.getConnection(connectionURL);
       Statement stmt = con.createStatement();

       String sql = "Select * FROM Storage_DB ";
       ResultSet j = null;
       j = stmt.executeQuery(sql);
       int i=1;
       //String PassT = "";

       while(j.next())
       {
         if(NameT.equals(j.getString("NAME") ))       {i = -1;}
         //if(IpT.equals(j.getString("IP") ))       {i = -1;}
         //if(Type_SizeT.equals(j.getString("TYPE_SIZE") ))   {i = -1;}
       }
       if (i == 1)
       {
         sql = "INSERT INTO Storage_DB(NAME,IP,SIZE,Pass) VALUES('"+NameT+"','"+IpT+"','"+Used_SizeT+"','"+PassT+"')";
         stmt.executeUpdate(sql);
         //dout.writeUTF("Register Complete");
         frame.Show_Status("Create Complate");
       }else
       {
         //dout.writeUTF("Already Login");
         frame.Show_Status("Already Name or IP Address...!!!");
       }
       stmt.close();
       con.close();
     }
     catch (Exception e)
     {
       e.printStackTrace();
     }
   }

  //Main method
  public static void main(String[] args)
  {
    try
    {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
      Application1 run = new Application1();


    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

  }
}