VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form gridinv 
   Caption         =   "Form1"
   ClientHeight    =   7125
   ClientLeft      =   1470
   ClientTop       =   1035
   ClientWidth     =   9315
   ControlBox      =   0   'False
   BeginProperty Font 
      Name            =   "MS Sans Serif"
      Size            =   12
      Charset         =   222
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   ScaleHeight     =   7125
   ScaleWidth      =   9315
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   Begin VB.TextBox Text1 
      Height          =   345
      Left            =   1680
      TabIndex        =   25
      Top             =   720
      Width           =   375
   End
   Begin VB.TextBox txdetail 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   960
      MaxLength       =   99
      TabIndex        =   24
      Top             =   1080
      Width           =   5655
   End
   Begin VB.TextBox txpermit 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   5400
      MaxLength       =   72
      TabIndex        =   23
      Top             =   720
      Width           =   2775
   End
   Begin VB.TextBox txtype 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   8760
      MaxLength       =   2
      TabIndex        =   22
      Top             =   120
      Width           =   495
   End
   Begin VB.TextBox tx_voucher_id 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   4800
      MaxLength       =   15
      TabIndex        =   21
      Top             =   360
      Width           =   1935
   End
   Begin VB.TextBox txtype_book 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   960
      MaxLength       =   50
      TabIndex        =   20
      Top             =   360
      Width           =   2295
   End
   Begin VB.TextBox txbranch 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   345
      Left            =   960
      MaxLength       =   50
      TabIndex        =   19
      Top             =   0
      Width           =   2295
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H80000000&
      BorderStyle     =   0  'None
      Height          =   3855
      Left            =   0
      TabIndex        =   6
      Top             =   1920
      Width           =   9375
      Begin VB.PictureBox inputpic 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   1200
         ScaleHeight     =   270
         ScaleWidth      =   795
         TabIndex        =   7
         Tag             =   "noprint"
         Top             =   4320
         Visible         =   0   'False
         Width           =   825
         Begin VB.TextBox TMText 
            Appearance      =   0  'Flat
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   390
            Left            =   0
            TabIndex        =   8
            ToolTipText     =   "Enter data"
            Top             =   0
            Width           =   840
         End
      End
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   3615
         Left            =   120
         TabIndex        =   9
         Top             =   120
         Width           =   9255
         _ExtentX        =   16325
         _ExtentY        =   6376
         _Version        =   393216
         BackColor       =   -2147483624
         Rows            =   99
         Cols            =   6
         FixedCols       =   0
         GridColorFixed  =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         _NumberOfBands  =   1
         _Band(0).Cols   =   6
      End
      Begin VB.Label TotalInv 
         Alignment       =   1  'Right Justify
         BackStyle       =   0  'Transparent
         Height          =   255
         Left            =   8025
         TabIndex        =   11
         Top             =   5505
         Width           =   1110
      End
      Begin VB.Label Total 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Total"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   7290
         TabIndex        =   10
         Top             =   5490
         Width           =   615
      End
      Begin VB.Image Image2 
         Height          =   480
         Left            =   4590
         Picture         =   "gridinv.frx":0000
         Top             =   735
         Visible         =   0   'False
         Width           =   480
      End
   End
   Begin VB.CommandButton Command1 
      Caption         =   "SAVE"
      BeginProperty Font 
         Name            =   "Microsoft Sans Serif"
         Size            =   9
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5040
      TabIndex        =   5
      Top             =   6240
      Width           =   1335
   End
   Begin VB.CommandButton insert 
      Caption         =   "F3-�á��÷Ѵ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1920
      TabIndex        =   4
      Top             =   6240
      Width           =   1335
   End
   Begin VB.CommandButton eraser 
      Caption         =   "F4-ź��÷Ѵ"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3480
      TabIndex        =   3
      Top             =   6240
      Width           =   1335
   End
   Begin VB.CommandButton balence 
      Caption         =   "F2-�������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   6240
      Width           =   1335
   End
   Begin VB.TextBox sum_total_credit 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7440
      TabIndex        =   1
      Top             =   5760
      Width           =   1815
   End
   Begin VB.TextBox sum_total_dabit 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5520
      TabIndex        =   0
      Top             =   5760
      Width           =   1815
   End
   Begin MSComCtl2.DTPicker dtp_day 
      Height          =   375
      Left            =   4800
      TabIndex        =   28
      Top             =   0
      Width           =   1335
      _ExtentX        =   2355
      _ExtentY        =   661
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Format          =   22806529
      CurrentDate     =   37476
   End
   Begin VB.Label Label9 
      Caption         =   "���"
      Height          =   375
      Left            =   120
      TabIndex        =   27
      Top             =   5880
      Width           =   495
   End
   Begin VB.Label Label8 
      Caption         =   "�ٻẺ��� POST"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   240
      TabIndex        =   26
      Top             =   840
      Width           =   1455
   End
   Begin VB.Label Label7 
      Caption         =   "��͸Ժ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   240
      TabIndex        =   18
      Top             =   1200
      Width           =   975
   End
   Begin VB.Label Label6 
      Caption         =   "��ش"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   240
      TabIndex        =   17
      Top             =   360
      Width           =   495
   End
   Begin VB.Label Label5 
      Caption         =   "���͹��ѵ�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4680
      TabIndex        =   16
      Top             =   720
      Width           =   615
   End
   Begin VB.Label Label4 
      Caption         =   "�Ң�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   240
      TabIndex        =   15
      Top             =   0
      Width           =   615
   End
   Begin VB.Label Label3 
      Caption         =   "�ѹ���ŧ�ѭ��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   14
      Top             =   0
      Width           =   975
   End
   Begin VB.Label Label2 
      Caption         =   "Type"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   8040
      TabIndex        =   13
      Top             =   120
      Width           =   615
   End
   Begin VB.Label Label1 
      Caption         =   "Voucher No."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   12
      Top             =   360
      Width           =   1215
   End
End
Attribute VB_Name = "gridinv"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim LastLine As Integer
Dim Init As Boolean
Dim col_number As Integer
'Dim j As Integer
'Dim insert1 As Integer



Private Sub balence_Click()
        Dim dabit As Double
        Dim crebit As Double
        Dim tem_number As Double
        Dim condition As Integer
        Dim count As Integer
        
        dabit = CDbl(sum_total_dabit)
        crebit = CDbl(sum_total_credit)
        tem_number = dabit - crebit
        Select Case tem_number
                    Case Is > 0
                                condition = 1
                    Case Is < 0
                                tem_number = tem_number * -1
                                condition = -1
                    Case Is = 0
                                condition = 0
         End Select
         
         count = 1

        Do While count < (LastLine - 1)  '��row�ش���·����ҧ�
                        If Not gridinv.TextMatrix(count, 0) <> "" Then
                                        Exit Do
                        End If
                        count = count + 1
        Loop
        count = count - 1
        
        Select Case condition
                        Case -1 '������ col dabit
                                    gridinv.TextMatrix(count, 2) = tem_number
                        Case 1 '������ col credit
                                    gridinv.TextMatrix(count, 3) = tem_number
                        Case 0
            End Select
       
End Sub

Private Sub Command1_Click() ' ���� save
Dim a() As String
Dim b() As Currency
Dim m As Integer
Dim n As Integer
Dim o As Integer
Dim w As String
'ReDim a(10, 20) As Integer
If sum_total_credit.Text <> sum_total_dabit.Text Then
   MsgBox "�������ҹ Debit �Ѻ��ҹ Credit �����ҡѹ", vbOKOnly, "ERROR"
Else
    w = dtp_day.Value '�ѹ��͹��
   acc_data.cn_voucher.Open
   acc_data.insert_voucher tx_voucher_id.Text, w, txtype_book.Text, txbranch.Text, txpermit.Text, txtype.Text, txdetail.Text
   m = 1 '���Ѻrow � grid
   gridinv.col = 0
  
   Do
      gridinv.row = m
      w = gridinv.Text
      m = m + 1
   Loop Until w = ""
   m = m - 2 '��Ҩ��Թ�ӹǹrow�2
   o = m 'keep value m
   ReDim a(m, 5) As String
   ReDim b(m, 2) As Currency '1�� ഺԵ 2���ôԵ
   
   n = 1 '��Ѻ��� metrix
   Do
       a(n, 1) = n    '�ӴѺ���  item_id
       a(n, 2) = tx_voucher_id.Text '���� voucher
       a(n, 3) = gridinv.TextMatrix(n, 0)  '���ʺѭ��
       a(n, 4) = gridinv.TextMatrix(n, 4) 'Ἱ�
       a(n, 5) = gridinv.TextMatrix(n, 5) 'G
       
       If gridinv.TextMatrix(n, 2) = "" Then
         gridinv.TextMatrix(n, 2) = "0"
       End If
       If gridinv.TextMatrix(n, 3) = "" Then
          gridinv.TextMatrix(n, 3) = "0"
       End If
       b(n, 1) = CCur(gridinv.TextMatrix(n, 2)) 'ഺԵ
       b(n, 2) = CCur(gridinv.TextMatrix(n, 3))  '�ôԵ
       
       m = m - 1 'Ŵ count loop
       n = n + 1 'row �Ѵ�
   Loop Until m = 0
   
   m = o ' count loop
   n = 1
   o = 0
   Do
      acc_data.insert_voucher_item a(n, 1), a(n, 2), a(n, 3), a(n, 4), a(n, 5), b(n, 1), b(n, 2)
      n = n + 1
      o = o + 1
      m = m - 1
   Loop Until m = 0
      MsgBox "�ѹ�֡��¡����������ó�ӹǹ '" & o & "' record", vbOKOnly, "Message"
     acc_data.cn_voucher.Close
     Unload Me
     plan.Show
End If
End Sub

    


Private Sub eraser_Click()
If MsgBox("��ҹ��ͧ���ź�������", 305, "�ô�׹�ѹ") = 1 Then
            Dim line As Integer
            Dim col As Integer
            Dim old_row As Integer
            Dim tem_data As String
 '           Dim m As Integer
  '          Dim n As Integer
            
            tem_data = gridinv.TextMatrix(gridinv.row + 1, gridinv.col)
            
            line = LastLine - 1
            old_row = gridinv.row + 1

                    Do While line > old_row
                                        col = 0
                            Do
                                         gridinv.TextMatrix(old_row - 1, col) = gridinv.TextMatrix(old_row, col)
                                                If col = (col_number - 1) Then
                                                        Exit Do
                                                End If
                                         col = col + 1
                            Loop Until col > (col_number - 1)
                            
                            old_row = old_row + 1
                     Loop
                
                TMText.Text = tem_data   '�׹ ��� �����row ��ҧ��ҧ
                

End If
                                         
End Sub

Private Sub Form_Activate()
gridinv.col = 0

End Sub

Private Sub Form_Initialize()
LastLine = 99
col_number = 6
End Sub

Private Sub Form_Load()
Init = True
Setgrid

' insert1 = 0
End Sub

Private Sub gridinv_EnterCell()  ' �͹��ԡ����ͧ�

On Error Resume Next

If Init Then
        
        'Exit Sub    'lnit �繤�� true  �ʴ�����ش��÷Ѵ����
Else

        inputpic.Move gridinv.CellLeft - 20
        inputpic.Top = gridinv.CellTop + gridinv.Top - 20
        inputpic.Visible = True
        
        inputpic.Width = gridinv.CellWidth + 10
        inputpic.Height = gridinv.CellHeight + 20
        TMText.Width = inputpic.Width

End If

TMText.SetFocus
TMText.Text = gridinv.Text
TMText.SelStart = 0
TMText.SelLength = 100

End Sub
Private Sub gridinv_LeaveCell()

On Error Resume Next
Dim tem_number As Double
Dim tem_string As String

tem_number = val(TMText.Text)
tem_string = Str(tem_number)
If tem_string = " 0" Then
        tem_string = " "
End If
    If gridinv.col = 2 Or gridinv.col = 3 Then
            If (Len(tem_string) - 1) = Len(TMText.Text) Then
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        TotalSum_credit
                        TotalSum_dabit
                        If gridinv.col = 2 And (0 <> Len(TMText.Text)) Then '�ӡ�á��ⴴ����
                            gridinv.col = gridinv.col + 1
                        End If
            Else
                        MsgBox "�س�������ŷ�����ѡ�û�����", 48, "����͹"
                        gridinv.col = gridinv.col - 1
                        
            End If
    Else
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        TotalSum_credit
                        TotalSum_dabit
    End If
End Sub

Private Sub gridinv_Scroll()

On Error Resume Next
If Init Then Exit Sub
If Not gridinv.RowIsVisible(gridinv.row) Or Not gridinv.ColIsVisible(gridinv.col) Then
inputpic.Visible = False
Else
inputpic.Move gridinv.CellLeft
inputpic.Top = gridinv.CellTop + gridinv.Top
inputpic.Visible = True
End If

End Sub

Private Sub insert_Click()
'Dim x As Integer
'Dim y As Integer
'Dim st2 As String
'insert1 = insert1 + 1 '���Ѻ�ӹǹ�Ƿ���á����á������
'gridinv.col = 0
'st2 = gridinv.Text
'If insert1 > 1 Then
'   MsgBox "�س�á����§����1ROW ��ҹ��", vbOKOnly
'   insert1 = 1
'Else
If gridinv.TextMatrix(LastLine - 1, 0) = "" Then
            Dim line As Integer
            Dim col As Integer
            Dim old_col  As Integer
            line = LastLine - 1

                    Do While line > gridinv.row
                                        col = 0
                            Do
                                         gridinv.TextMatrix(line, col) = gridinv.TextMatrix(line - 1, col)
                                                If col = (col_number - 1) Then
                                                        Exit Do
                                                End If
                                         col = col + 1
                            Loop Until col > (col_number - 1)
                            
                            line = line - 1
                            Loop
                            
                            
                old_col = gridinv.col
                gridinv.col = 0
                Do
                          gridinv.TextMatrix(gridinv.row, gridinv.col) = ""
                          If gridinv.col = (col_number - 1) Then
                                        gridinv.col = old_col  ' �׹��ҵ��˹����
                                        TMText.SetFocus
                                        TMText.Text = gridinv.Text
                                        TMText.SelStart = 0
                                        TMText.SelLength = 100
                                        Exit Do
                          End If
                          gridinv.col = gridinv.col + 1
                Loop Until gridinv.col > (col_number - 1)
                'gridinv.Text = st2
                'x = 1
                'y = 1
                'Do
                 '     gridinv.TextMatrix(x, 0) = x
                  '    x = x + 1
                   '   If (gridinv.TextMatrix(x, 0) = "") Then
                    '     y = 0
                   '   End If
                'Loop Until y = 0
                gridinv.col = 0
Else
            MsgBox "�������ö�ӡ���á��������", 64, "������"
End If
'End If
End Sub

Private Sub TMtext_KeyDown(KeyCode As Integer, Shift As Integer) '�͹��������� textb  ����MOUSE  ��ԡ

Select Case KeyCode
            Case 13
                            gridinv_LeaveCell
                            cheak_enter
                            gridinv_EnterCell
            Case 37
                            gridinv_LeaveCell
                            cheak_left
                            gridinv_EnterCell
            Case 38
                            gridinv_LeaveCell
                            cheak_up
                            gridinv_EnterCell
            Case 39
                            gridinv_LeaveCell
                            cheak_right
                            gridinv_EnterCell
            Case 40
                            gridinv_LeaveCell
                            cheak_down
                            gridinv_EnterCell
            Case 113
                            balence_Click
            Case 114
                            insert_Click
            Case 115
                            eraser_Click
            
            End Select
End Sub

Private Sub cheak_enter()  '��Ǩ�ͺ����ش��÷Ѵ�ѧ�� ��Ǩ�ͺ������ 6 col
Dim st1 As String
Dim s As Integer
s = 1
                If gridinv.col < (col_number - 1) Then
                        If gridinv.col = 0 Then
                           st1 = gridinv.Text
                           acc_data.cn_plan.Open
                           acc_data.name_acc st1
                           If acc_data.rsname_acc.RecordCount = 0 Then
                              MsgBox "���ʺѭ�շ��س��͹���������㹼ѧ�ѭ��", vbOKOnly, "����͹"
                              'gridinv.col = gridinv.col - 1
                              s = 0
                            Else
                              gridinv.col = gridinv.col + 1
                              gridinv.Text = acc_data.rsname_acc.Fields(0)
                            End If
                            acc_data.cn_plan.Close
                        End If
                        gridinv.col = gridinv.col + s
                Else
                        If IsNumeric(gridinv.TextMatrix(gridinv.row, 2)) And IsNumeric(gridinv.TextMatrix(gridinv.row, 3)) Then
                                        MsgBox "�س�������Ũӹǹ�Թ㹪�ͧ �ӹǹ�ԹഺԵ ��� �ӹǹ�Թ�ôԵ ", 48, "����͹"
                                        gridinv.col = 2
                                        Exit Sub
                        End If
                        
                        gridinv.col = 0
                        'If (gridinv.col = 0) And (gridinv.row = 1) Then
                        '    gridinv.Text = j
                        'End If
                        gridinv.row = gridinv.row + 1
                        'gridinv.col = 1
                        'If gridinv.Text = "" Then
                         '  gridinv.col = 0
                          '  j = j + 1
                           ' gridinv.Text = j
                            'gridinv.col = 1
                        'Else
                         '   j = j + insert1 + 1
                          '  gridinv.row = j
                           ' gridinv.col = 0
                            'gridinv.Text = j
                            'gridinv.col = 1
                            'insert1 = 0
                        'End If
                End If
End Sub
Private Sub cheak_up()  '��Ǩ�ͺ����ش��÷Ѵ���ѧ
                
                If gridinv.row <= 1 Then
                        gridinv.row = 1
                Else
                        gridinv.row = gridinv.row - 1
                End If

End Sub
Private Sub cheak_down()  '��Ǩ�ͺ����ش��÷Ѵ��ҧ�ѧ
                
                If gridinv.row >= (LastLine - 1) Then
                        gridinv.row = (LastLine - 1)
                Else
                        If (Len(gridinv.TextMatrix(gridinv.row, 2)) > 0) And (Len(gridinv.TextMatrix(gridinv.row, 3)) > 0) Then
                        
                        Else
                            gridinv.row = gridinv.row + 1
                        End If
                        
                        
                End If

End Sub
Private Sub cheak_left()  '��Ǩ�ͺ����ش��÷Ѵ����
                
                If gridinv.col > 0 Then
                        gridinv.col = gridinv.col - 1
                Else
                        gridinv.col = col_number - 1
                End If
End Sub
Private Sub cheak_right()  '��Ǩ�ͺ����ش��÷Ѵ���
                If gridinv.col < (col_number - 1) Then
                        gridinv.col = gridinv.col + 1
                Else
                        gridinv.col = 0
                        
                End If
End Sub

Private Sub Setgrid()

Dim i As Integer


gridinv.Move 20, 100    'set ���˹觢ͧ textbox 㹡���ʴ�������

'gridinv.ColWidth(0) = 600
gridinv.ColWidth(0) = 1300
gridinv.ColWidth(1) = 3500
gridinv.ColWidth(2) = 1500
gridinv.ColWidth(3) = 1500
gridinv.ColWidth(4) = 700
gridinv.ColWidth(5) = 400

'gridinv.TextMatrix(0, 0) = "�ӴѺ���"
gridinv.TextMatrix(0, 0) = "���ʺѭ��"  '���ʺѭ��
gridinv.TextMatrix(0, 1) = "���ͺѭ��"  '���ͺѭ��
gridinv.TextMatrix(0, 2) = "�ӹǹ�ԹഺԵ"   '�ӹǹ�ԹഺԵ
gridinv.TextMatrix(0, 3) = "�ӹǹ�Թ�ôԵ"  ' �ӹǹ�Թ�ôԵ
gridinv.TextMatrix(0, 4) = "Ἱ�"  ' Ἱ�
gridinv.TextMatrix(0, 5) = "G"  ' G
gridinv.col = 0
LastLine = 99  ' �ʴ���÷Ѵ�ش����

'j = 1
'gridinv.Text = j

For i = 0 To 4
gridinv.col = i
gridinv.ColAlignment = 7
Next i

gridinv_EnterCell
'Date = Format(Now, "dd/mm/yy")

TotalSum_dabit
TotalSum_credit
TMText.SelStart = 0        '���˹��á�鹢ͧ����ҧ "textbox"
TMText.SelLength = 100  '��˹�100 ����ѡ��
 
Init = False
gridinv.row = 1
gridinv.col = 1
End Sub

Private Sub TotalSum_dabit()

On Error Resume Next

Dim Sum As Currency
Dim row As Integer
row = 1
        Do While row < 100
                        Sum = Sum + CDbl(gridinv.TextMatrix(row, 2))
                        row = row + 1
        Loop
sum_total_dabit = Str$(Sum)
End Sub

Private Sub TotalSum_credit()

On Error Resume Next

Dim Sum As Double
Dim row As Integer
row = 1
        Do While row < 100
                    Sum = Sum + CDbl(gridinv.TextMatrix(row, 3))
                    row = row + 1
        Loop
sum_total_credit = Str$(Sum)
End Sub

