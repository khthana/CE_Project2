VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form ENTER_COMPANY 
   Caption         =   "��䢢����ź���ѷ�ӡ��"
   ClientHeight    =   9165
   ClientLeft      =   1005
   ClientTop       =   570
   ClientWidth     =   8730
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   9165
   ScaleWidth      =   8730
   Begin TabDlg.SSTab SSTab1 
      Height          =   8895
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   8445
      _ExtentX        =   14896
      _ExtentY        =   15690
      _Version        =   393216
      TabHeight       =   706
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "ENTER_COMPANY.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame1"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "���"
      TabPicture(1)   =   "ENTER_COMPANY.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame2"
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "���ҧ����"
      TabPicture(2)   =   "ENTER_COMPANY.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame3"
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame3 
         Caption         =   "���ҧ����"
         Height          =   8175
         Left            =   -74760
         TabIndex        =   4
         Top             =   480
         Width           =   7935
         Begin VB.TextBox detail_type_tex_new 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   2880
            TabIndex        =   61
            Top             =   5400
            Width           =   2300
         End
         Begin VB.CommandButton save_new 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   375
            Left            =   4920
            TabIndex        =   35
            Top             =   7560
            Width           =   1215
         End
         Begin VB.CommandButton esc_new 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   6360
            TabIndex        =   36
            Top             =   7560
            Width           =   1215
         End
         Begin VB.OptionButton Option4 
            Caption         =   "����"
            Height          =   375
            Left            =   2280
            TabIndex        =   60
            Top             =   6360
            Width           =   1215
         End
         Begin VB.OptionButton Option3 
            Caption         =   "�����¡�͡"
            Height          =   375
            Left            =   2280
            TabIndex        =   34
            Top             =   5880
            Value           =   -1  'True
            Width           =   1335
         End
         Begin VB.Frame Frame5 
            Height          =   1095
            Left            =   2160
            TabIndex        =   59
            Top             =   5760
            Width           =   1695
         End
         Begin VB.TextBox address_eng_new 
            Height          =   980
            Left            =   2160
            MultiLine       =   -1  'True
            TabIndex        =   27
            Top             =   2460
            Width           =   4700
         End
         Begin VB.TextBox name_company_thai_new 
            Height          =   315
            Left            =   2160
            TabIndex        =   25
            Top             =   720
            Width           =   4700
         End
         Begin VB.TextBox fax_new 
            Height          =   315
            Left            =   2160
            MaxLength       =   50
            TabIndex        =   29
            Top             =   3840
            Width           =   3375
         End
         Begin VB.TextBox phone_new 
            Height          =   315
            Left            =   2160
            MaxLength       =   50
            TabIndex        =   28
            Top             =   3480
            Width           =   3375
         End
         Begin VB.TextBox type_tex_new 
            Height          =   315
            Left            =   2160
            MaxLength       =   1
            TabIndex        =   33
            Top             =   5400
            Width           =   615
         End
         Begin VB.TextBox address_thai_new 
            Height          =   980
            Left            =   2160
            MultiLine       =   -1  'True
            TabIndex        =   26
            Top             =   1080
            Width           =   4700
         End
         Begin VB.TextBox start_date_new 
            Height          =   315
            Left            =   2160
            TabIndex        =   30
            Text            =   "01/01"
            Top             =   4200
            Width           =   615
         End
         Begin VB.TextBox id_company_new 
            Height          =   315
            Left            =   2160
            MaxLength       =   5
            TabIndex        =   24
            Top             =   360
            Width           =   1575
         End
         Begin VB.TextBox tex_id_new 
            Height          =   315
            Left            =   2160
            MaxLength       =   13
            TabIndex        =   32
            Top             =   5040
            Width           =   1935
         End
         Begin VB.TextBox name_company_eng_new 
            Height          =   315
            Left            =   2160
            TabIndex        =   37
            Top             =   2100
            Width           =   4700
         End
         Begin MSComCtl2.DTPicker DTPicker1 
            Height          =   315
            Left            =   2160
            TabIndex        =   31
            Top             =   4680
            Width           =   1215
            _ExtentX        =   2143
            _ExtentY        =   556
            _Version        =   393216
            Format          =   55836673
            CurrentDate     =   37485
         End
         Begin VB.Label Label24 
            Caption         =   "�����¡�͡/ ����"
            Height          =   255
            Left            =   240
            TabIndex        =   58
            Top             =   5880
            Width           =   1695
         End
         Begin VB.Label Label23 
            Caption         =   "����������"
            Height          =   255
            Left            =   840
            TabIndex        =   57
            Top             =   5400
            Width           =   975
         End
         Begin VB.Label Label22 
            Caption         =   "����������"
            Height          =   255
            Left            =   960
            TabIndex        =   56
            Top             =   720
            Width           =   975
         End
         Begin VB.Label Label21 
            Caption         =   "�������������"
            Height          =   375
            Left            =   840
            TabIndex        =   55
            Top             =   1080
            Width           =   1095
         End
         Begin VB.Label Label20 
            Caption         =   "�������� 2"
            Height          =   255
            Left            =   1080
            TabIndex        =   54
            Top             =   2160
            Width           =   975
         End
         Begin VB.Label Label19 
            Caption         =   "����������� 2"
            Height          =   495
            Left            =   960
            TabIndex        =   53
            Top             =   2520
            Width           =   1215
         End
         Begin VB.Label Label18 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   1080
            TabIndex        =   52
            Top             =   3525
            Width           =   735
         End
         Begin VB.Label Label17 
            Caption         =   "�����"
            Height          =   255
            Left            =   1200
            TabIndex        =   51
            Top             =   3900
            Width           =   615
         End
         Begin VB.Label Label16 
            Caption         =   "�ѹ������ͺ�ѭ��"
            Height          =   255
            Left            =   600
            TabIndex        =   50
            Top             =   4275
            Width           =   1215
         End
         Begin VB.Label Label15 
            Caption         =   "�ѹ�����������к�"
            Height          =   255
            Left            =   600
            TabIndex        =   49
            Top             =   4680
            Width           =   1215
         End
         Begin VB.Label Label14 
            Caption         =   "�Ţ��Шӵ�Ǽ����������"
            Height          =   255
            Left            =   120
            TabIndex        =   48
            Top             =   5040
            Width           =   1695
         End
         Begin VB.Label Label13 
            Caption         =   "���ʺ���ѷ"
            Height          =   255
            Left            =   1200
            TabIndex        =   47
            Top             =   360
            Width           =   855
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "���"
         Height          =   8175
         Left            =   -74760
         TabIndex        =   3
         Top             =   480
         Width           =   7935
         Begin VB.TextBox detail_type_tex_edit 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   2880
            TabIndex        =   62
            Top             =   5400
            Width           =   2300
         End
         Begin VB.TextBox address_eng_edit 
            Height          =   980
            Left            =   2160
            MultiLine       =   -1  'True
            TabIndex        =   9
            Top             =   2460
            Width           =   4700
         End
         Begin VB.TextBox name_company_eng_edit 
            Height          =   315
            Left            =   2160
            TabIndex        =   8
            Top             =   2100
            Width           =   4695
         End
         Begin VB.CommandButton save_edit 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   375
            Left            =   4920
            TabIndex        =   17
            Top             =   7560
            Width           =   1215
         End
         Begin VB.CommandButton esc_edit 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   6360
            TabIndex        =   46
            Top             =   7560
            Width           =   1215
         End
         Begin VB.TextBox type_tex_edit 
            Height          =   315
            Left            =   2160
            MaxLength       =   1
            TabIndex        =   15
            Top             =   5400
            Width           =   615
         End
         Begin VB.Frame Frame4 
            Height          =   1095
            Left            =   2160
            TabIndex        =   42
            Top             =   5760
            Width           =   1695
            Begin VB.OptionButton Option1 
               Caption         =   "�����¡�͡"
               Height          =   375
               Left            =   120
               TabIndex        =   16
               Top             =   120
               Width           =   1335
            End
            Begin VB.OptionButton Option2 
               Caption         =   "����"
               Height          =   375
               Left            =   120
               TabIndex        =   43
               Top             =   600
               Width           =   1215
            End
         End
         Begin VB.TextBox fax_edit 
            Height          =   315
            Left            =   2160
            MaxLength       =   50
            TabIndex        =   11
            Top             =   3840
            Width           =   3375
         End
         Begin VB.TextBox address_thai_edit 
            Height          =   980
            Left            =   2160
            MultiLine       =   -1  'True
            TabIndex        =   7
            Top             =   1080
            Width           =   4700
         End
         Begin VB.TextBox phone_edit 
            Height          =   315
            Left            =   2160
            MaxLength       =   50
            TabIndex        =   10
            Top             =   3480
            Width           =   3375
         End
         Begin VB.TextBox start_date_edit 
            Height          =   315
            Left            =   2160
            TabIndex        =   12
            Top             =   4200
            Width           =   615
         End
         Begin VB.TextBox tex_id_edit 
            Height          =   315
            Left            =   2160
            MaxLength       =   13
            TabIndex        =   14
            Top             =   5040
            Width           =   1935
         End
         Begin VB.TextBox name_company_thai_edit 
            Height          =   315
            Left            =   2160
            TabIndex        =   6
            Top             =   720
            Width           =   4695
         End
         Begin VB.TextBox id_company_edit 
            BackColor       =   &H80000004&
            Enabled         =   0   'False
            Height          =   315
            Left            =   2160
            TabIndex        =   5
            Top             =   360
            Width           =   1575
         End
         Begin MSComCtl2.DTPicker DTPicker2 
            Height          =   315
            Left            =   2160
            TabIndex        =   13
            Top             =   4620
            Width           =   1215
            _ExtentX        =   2143
            _ExtentY        =   556
            _Version        =   393216
            Format          =   55836673
            CurrentDate     =   37486
         End
         Begin VB.Label Label12 
            Caption         =   "�����¡�͡/ ����"
            Height          =   255
            Left            =   240
            TabIndex        =   45
            Top             =   5880
            Width           =   1695
         End
         Begin VB.Label Label11 
            Caption         =   "����������"
            Height          =   255
            Left            =   840
            TabIndex        =   44
            Top             =   5400
            Width           =   975
         End
         Begin VB.Label Label10 
            Caption         =   "�Ţ��Шӵ�Ǽ����������"
            Height          =   255
            Left            =   120
            TabIndex        =   41
            Top             =   5040
            Width           =   1695
         End
         Begin VB.Label Label9 
            Caption         =   "�ѹ�����������к�"
            Height          =   255
            Left            =   600
            TabIndex        =   40
            Top             =   4680
            Width           =   1215
         End
         Begin VB.Label Label8 
            Caption         =   "�ѹ������ͺ�ѭ��"
            Height          =   255
            Left            =   600
            TabIndex        =   39
            Top             =   4275
            Width           =   1215
         End
         Begin VB.Label Label7 
            Caption         =   "�����"
            Height          =   255
            Left            =   1200
            TabIndex        =   38
            Top             =   3900
            Width           =   615
         End
         Begin VB.Label Label6 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   1080
            TabIndex        =   23
            Top             =   3525
            Width           =   735
         End
         Begin VB.Label Label5 
            Caption         =   "����������� 2"
            Height          =   495
            Left            =   960
            TabIndex        =   22
            Top             =   2520
            Width           =   1215
         End
         Begin VB.Label Label4 
            Caption         =   "�������� 2"
            Height          =   255
            Left            =   1080
            TabIndex        =   21
            Top             =   2160
            Width           =   975
         End
         Begin VB.Label Label3 
            Caption         =   "�������������"
            Height          =   375
            Left            =   840
            TabIndex        =   20
            Top             =   1080
            Width           =   1095
         End
         Begin VB.Label Label2 
            Caption         =   "����������"
            Height          =   255
            Left            =   960
            TabIndex        =   19
            Top             =   720
            Width           =   975
         End
         Begin VB.Label Label1 
            Caption         =   "���ʺ���ѷ"
            Height          =   255
            Left            =   1200
            TabIndex        =   18
            Top             =   360
            Width           =   855
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "��������´"
         Height          =   8175
         Left            =   240
         TabIndex        =   1
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton esc_company 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   6360
            TabIndex        =   2
            Top             =   7560
            Width           =   1215
         End
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
            Height          =   6495
            Left            =   360
            TabIndex        =   63
            Top             =   360
            Width           =   7215
            _ExtentX        =   12726
            _ExtentY        =   11456
            _Version        =   393216
            Rows            =   99
            Cols            =   3
            _NumberOfBands  =   1
            _Band(0).Cols   =   3
         End
      End
   End
End
Attribute VB_Name = "ENTER_COMPANY"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim point_grid As Integer
Dim id_company As String




Private Sub esc_company_Click()
            Call cheak_dataenvironment
            Unload Me
            'navigator.Show
End Sub

Private Sub Esc_edit_Click()
            '**********clear  text ������  ����¡��ԡ

            id_company_edit.Text = ""
            name_company_thai_edit.Text = ""
            address_thai_edit.Text = ""
            name_company_eng_edit.Text = ""
            address_eng_edit.Text = ""
            phone_edit.Text = ""
            fax_edit.Text = ""
            start_date_edit.Text = ""
            tex_id_edit.Text = ""
            type_tex_edit.Text = ""
            Option1.Value = True
            SSTab1.Tab = 0
            
            Call cheak_dataenvironment
            
End Sub



Private Sub Esc_new_Click()
            '**********clear  text ������  ����¡��ԡ

            id_company_new.Text = ""
            name_company_thai_new.Text = ""
            address_thai_new.Text = ""
            name_company_eng_new.Text = ""
            address_eng_new.Text = ""
            phone_new.Text = ""
            fax_new.Text = ""
            start_date_new.Text = ""
            tex_id_new.Text = ""
            type_tex_new.Text = ""
            Option3.Value = True
            SSTab1.Tab = 0
            
            Call cheak_dataenvironment
            
End Sub

Private Sub Setgrid()
Dim row_temp As Integer
Dim i As Integer
point_grid = 350
row_temp = 1  ' set ���㹡�� clear gridinv

gridinv.Move point_grid, 300 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 200
gridinv.ColWidth(1) = 1000
gridinv.ColWidth(2) = 10000

gridinv.TextMatrix(0, 1) = "���ʺ���ѷ"
gridinv.TextMatrix(0, 2) = "���ͺ���ѷ"

Do While (gridinv.Rows - 1) > row_temp
                        
            gridinv.TextMatrix(row_temp, 1) = ""
            gridinv.TextMatrix(row_temp, 2) = ""
            row_temp = row_temp + 1
Loop

For i = 0 To 1
gridinv.col = i
gridinv.ColAlignment = 1
Next i

gridinv.row = 1
gridinv.col = 0
End Sub

Private Sub Form_Load()
        Call Setgrid
        SSTab1.Tab = 0
        Call detail_company
        
End Sub

Private Sub save_edit_Click()

Dim type_tex As String
            
            
            '***********����������Ţͧ���� text
            If (name_company_thai_edit.Text = "") Then
                                        MsgBox "�س�ѧ����������ͺ���ѷ", vbOKOnly, "ERROR"
                                        name_company_thai_edit.SetFocus
                                        Exit Sub
                     ElseIf (address_thai_edit.Text = "") Then
                                        MsgBox "�س�ѧ�����������������ѷ", vbOKOnly, "ERROR"
                                        address_thai_edit.SetFocus
                                        Exit Sub
                              ElseIf phone_edit.Text = "" Then
                                                    MsgBox "�س���������������Ѿ�����ѷ", vbOKOnly, "ERROR"
                                                    phone_edit.SetFocus
                                                    Exit Sub
                                                ElseIf (start_date_edit.Text = "") Then
                                                                    MsgBox "�س���������ѹ������ͺ�ѭ�բͧ����ѷ", vbOKOnly, "ERROR"
                                                                    start_date_edit.SetFocus
                                                                    Exit Sub
                                                                    
                                                        ElseIf (DTPicker1.Value = "") Then
                                                                                MsgBox "�س���������ѹ������к��ѭ�բͧ����ѷ", vbOKOnly, "ERROR"
                                                                                DTPicker1.SetFocus
                                                                                Exit Sub
                                                                ElseIf (tex_id_edit.Text = "") Then
                                                                                        MsgBox "�س����Ţ��Шӵ�Ǣͧ����������ռԴ��Ҵ", vbOKOnly, "ERROR"
                                                                                        tex_id_edit.SetFocus
                                                                                        Exit Sub
                                                                        ElseIf (type_tex_edit.Text = "") Then
                                                                                        MsgBox "�س���������ͧ���ռԴ��Ҵ", vbOKOnly, "ERROR"
                                                                                        type_tex_edit.SetFocus
                                                                                        Exit Sub
                    End If
                    
                    '*********��Ǩ�����ҧ�ͧ����������Ū�ͧ����� ���ͷ������ͧ����ѷ��Ъ��ͺ���ѷ �ӴѺ��� 2 �����������᷹
                    
                    If name_company_eng_edit.Text = "" Then
                                    name_company_eng_edit.Text = "-"
                    End If
                    If address_eng_edit.Text = "" Then
                                    address_eng_edit.Text = "-"
                    End If
                    
                    If Option1.Value = True Then
                                type_tex = "d"
                    Else
                                type_tex = "t"
                    End If
                    Call cheak_dataenvironment
                    If fax_edit.Text = "" Then
                       fax_edit = "-"
                    End If
                    acc_data.cn_company.Open
                    acc_data.concurrent_company
                    acc_data.company_edit name_company_thai_edit.Text, address_thai_edit.Text, name_company_eng_edit.Text, address_eng_edit.Text, phone_edit.Text, fax_edit.Text, start_date_edit.Text, DTPicker2.Value, tex_id_edit.Text, type_tex_edit.Text, type_tex, id_company_edit.Text
                    MsgBox "�ѹ�֡�������������", vbOKOnly, "COMPLETE"
                    Call cheak_dataenvironment
                    Call Esc_edit_Click  '**********clear  text ������  ����save
End Sub

Private Sub save_new_Click()

Dim type_tex As String
            '***********��õ�Ǩ�ͺ��ë�Ӣͧ���ʺ���ѷ
             Call cheak_dataenvironment
            acc_data.cn_company.Open
            acc_data.concurrent_company
            acc_data.cheak_company id_company_new.Text
            If acc_data.rscheak_company.RecordCount > 0 Then
                            MsgBox "�س������ʺ���ѷ��ӫ�͹", vbOKOnly, "ERROR"
                            id_company_new.SetFocus
                            Call cheak_dataenvironment
                            Exit Sub
            End If
                        id_company_new.SetFocus   '�������program ˹�ҹ������ҷ�� id_company_new �ѹ���
            '***********��õ�Ǩ�ͺ�����Ţͧ���� text
            If id_company_new.Text = "" Then
                            MsgBox "�س�����������ʺ���ѷ", vbOKOnly, "ERROR"
                            id_company_new.SetFocus
                            Exit Sub
            ElseIf (name_company_thai_new.Text = "") Then
                                        MsgBox "�س�ѧ����������ͺ���ѷ", vbOKOnly, "ERROR"
                                        name_company_thai_new.SetFocus
                                        Exit Sub
                     ElseIf (address_thai_new.Text = "") Then
                                        MsgBox "�س�ѧ�����������������ѷ", vbOKOnly, "ERROR"
                                        address_thai_new.SetFocus
                                        Exit Sub
                              ElseIf phone_new.Text = "" Then
                                                    MsgBox "�س���������������Ѿ�����ѷ", vbOKOnly, "ERROR"
                                                    phone_new.SetFocus
                                                    Exit Sub
                                                ElseIf (start_date_new.Text = "") Then
                                                                    MsgBox "�س���������ѹ������ͺ�ѭ�բͧ����ѷ", vbOKOnly, "ERROR"
                                                                    start_date_new.SetFocus
                                                                    Exit Sub
                                                                    
                                                        ElseIf (DTPicker1.Value = "") Then
                                                                                MsgBox "�س����ѹ������ͧ�к��ѭ�բͧ����ѷ�Դ��Ҵ", vbOKOnly, "ERROR"
                                                                                DTPicker1.SetFocus
                                                                                Exit Sub
                                                                ElseIf (tex_id_new.Text = "") Then
                                                                                        MsgBox "�س����Ţ��Шӵ�Ǣͧ����������ռԴ��Ҵ", vbOKOnly, "ERROR"
                                                                                        tex_id_new.SetFocus
                                                                                        Exit Sub
                                                                        ElseIf (type_tex_new.Text = "") Then
                                                                                        MsgBox "�س���������ͧ���ռԴ��Ҵ", vbOKOnly, "ERROR"
                                                                                        type_tex_new.SetFocus
                                                                                        Exit Sub
                    End If
                    
                    '*********��Ǩ�����ҧ�ͧ����������Ū�ͧ����� ���ͷ������ͧ����ѷ��Ъ��ͺ���ѷ �ӴѺ��� 2 �����������᷹
                    
                    If name_company_eng_new.Text = "" Then
                                    name_company_eng_new.Text = "-"
                    End If
                    If address_eng_new.Text = "" Then
                                    address_eng_new.Text = "-"
                    End If
                    
                    If Option3.Value = True Then
                                type_tex = "d"
                    Else
                                type_tex = "t"
                    End If
                    If fax_new.Text = "" Then
                       fax_new.Text = "-"
                    End If
                    acc_data.insert_company id_company_new.Text, name_company_thai_new.Text, address_thai_new.Text, name_company_eng_new.Text, address_eng_new.Text, phone_new.Text, fax_new.Text, start_date_new.Text, DTPicker1.Value, tex_id_new.Text, type_tex_new.Text, type_tex
                     MsgBox "��������ѷ�������", vbOKOnly, "COMPLETE"
                    Call cheak_dataenvironment
                    Call Esc_new_Click  '**********clear  text ������  ����save
                    
End Sub

Private Sub SSTab1_Click(PreviousTab As Integer)
                
                Call cheak_dataenvironment
        Select Case SSTab1.Tab
                Case 0
                                Call detail_company
                Case 1
                                 'Call Esc_edit_Click
                                Call company_edit
                Case 2
                                'call Esc_edit_Click
                                Call company_new
                                                
                End Select

End Sub
Private Sub company_new()
id_company_new.SetFocus   '�������program ˹�ҹ������ҷ�� id_company_new �ѹ���
id_company_new.Text = ""
name_company_thai_new.Text = ""
address_thai_new.Text = ""
name_company_eng_new.Text = ""
address_eng_new.Text = ""
phone_new.Text = ""
fax_new.Text = ""
start_date_new.Text = "01/01"
DTPicker1.Value = Date
tex_id_new.Text = ""
type_tex_new.Text = ""
Call cheak_dataenvironment
acc_data.cn_company.Open
acc_data.concurrent_company
acc_data.get_company
If acc_data.rsget_company.RecordCount <> 0 Then
   MsgBox "�س�������ö�պ���ѷ���ҡ����1����ѷ", vbOKOnly, "WARNING"
   SSTab1.Tab = 0
   Exit Sub
End If
End Sub
Private Sub detail_company()
Dim tmp_row As Integer
Dim row_edit As Integer
row_edit = 1
        Call Setgrid
        acc_data.cn_company.Open
        acc_data.concurrent_company
        acc_data.company
                          If acc_data.rscompany.RecordCount > 0 Then
                                            tmp_row = acc_data.rscompany.RecordCount
                                            Do
                                                        
                                                        gridinv.TextMatrix(row_edit, 1) = acc_data.rscompany.Fields(0)
                                                        gridinv.TextMatrix(row_edit, 2) = acc_data.rscompany.Fields(1)
                                                        
                                                        row_edit = row_edit + 1
                                                        tmp_row = tmp_row - 1
                                                        acc_data.rscompany.MoveNext
                                            Loop Until tmp_row = 0
                                            
                            End If
                'End With
                              
                
End Sub

Private Sub company_edit()
         id_company = gridinv.Text
        If (id_company = "") Or (Len(id_company) > 5) Then
                    MsgBox "��س����͡���ʺ���ѷ", vbOKOnly, "ERROR"
                    SSTab1.Tab = 0
                    Exit Sub
        Else
                    
                                                        name_company_thai_edit.SetFocus
                                                        Call cheak_dataenvironment
                                                        acc_data.cn_company.Open
                                                        acc_data.concurrent_company
                                                        acc_data.cheak_company id_company
                                                        
                                                        If Not (acc_data.rscheak_company.RecordCount > 0) Then
                                                        
                                                                    Exit Sub
                                                        End If
                                                        
                                                        id_company_edit.Text = acc_data.rscheak_company.Fields(0)
                                                        name_company_thai_edit.Text = acc_data.rscheak_company.Fields(1)
                                                        address_thai_edit.Text = acc_data.rscheak_company.Fields(2)
                                                        name_company_eng_edit.Text = acc_data.rscheak_company.Fields(3)
                                                        address_eng_edit.Text = acc_data.rscheak_company.Fields(4)
                                                        phone_edit.Text = acc_data.rscheak_company.Fields(5)
                                                        fax_edit.Text = acc_data.rscheak_company.Fields(6)
                                                        start_date_edit.Text = acc_data.rscheak_company.Fields(7)
                                                        DTPicker2.Value = acc_data.rscheak_company.Fields(8)
                                                        tex_id_edit.Text = acc_data.rscheak_company.Fields(9)
                                                        type_tex_edit.Text = acc_data.rscheak_company.Fields(10)
                                                        
                                                        'set ����  �����¡�͡/ ����
                                                        If acc_data.rscheak_company.Fields(11) = "d" Then
                                                                        Option1.Value = True
                                                       Else
                                                                        Option2.Value = True
                                                        End If
                        
        End If
        

End Sub
Private Sub cheak_dataenvironment()

            If acc_data.cn_company.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_company.Close
            End If

End Sub

