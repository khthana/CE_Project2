VERSION 5.00
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form ProfitReport 
   Caption         =   "�����âҴ�ع"
   ClientHeight    =   2190
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3645
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   2190
   ScaleWidth      =   3645
   Begin VB.CommandButton commit 
      Caption         =   "��ŧ"
      Height          =   495
      Left            =   960
      TabIndex        =   0
      Top             =   1560
      Width           =   1215
   End
   Begin VB.Frame Frame1 
      Caption         =   "�ʴ��ҧ"
      Height          =   1335
      Left            =   120
      TabIndex        =   2
      Top             =   120
      Width           =   3375
      Begin VB.OptionButton to_monitor 
         Caption         =   "������ҧ��͹�����"
         Height          =   495
         Left            =   360
         TabIndex        =   4
         Top             =   240
         Value           =   -1  'True
         Width           =   1575
      End
      Begin VB.OptionButton to_printer 
         Caption         =   "����ͧ�����"
         Height          =   495
         Left            =   360
         TabIndex        =   3
         Top             =   720
         Width           =   1215
      End
   End
   Begin VB.CommandButton cancel_but 
      Caption         =   "¡��ԡ"
      Height          =   495
      Left            =   2280
      TabIndex        =   1
      Top             =   1560
      Width           =   1215
   End
   Begin Crystal.CrystalReport cry_report_project 
      Left            =   240
      Top             =   1560
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      ReportFileName  =   "\reports\Profit.rpt"
      WindowControlBox=   -1  'True
      WindowMaxButton =   -1  'True
      WindowMinButton =   -1  'True
      WindowState     =   2
      PrintFileLinesPerPage=   60
   End
End
Attribute VB_Name = "ProfitReport"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cancel_but_Click()
    Unload Me
End Sub

Private Sub commit_Click()
    Dim name_company As String
     
     If acc_data.cn_company.State = adStateOpen Then
         acc_data.cn_company.Close
     End If

    acc_data.cn_company.Open
    acc_data.get_namec
    name_company = acc_data.rsget_namec.Fields(1)
    acc_data.cn_company.Close
    
    cry_report_project.ReportFileName = App.Path & "\reports\Profit.rpt"
     cry_report_project.WindowShowGroupTree = False
    cry_report_project.WindowTitle = "�����âҴ�ع"
    cry_report_project.WindowShowRefreshBtn = True
       
    
    '���͡����ʴ��Ż��·ҧ
     If to_monitor.Value Then cry_report_project.Destination = crptToWindow
     If to_printer.Value Then cry_report_project.Destination = crptToPrinter
    
    cry_report_project.Formulas(0) = "name_company=" & " ' " & name_company & " ' "
    cry_report_project.RetrieveDataFiles
    cry_report_project.Action = 1

End Sub
