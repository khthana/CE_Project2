VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form Report 
   Caption         =   "��§ҹ�к��ѭ��"
   ClientHeight    =   5745
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6030
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   5745
   ScaleWidth      =   6030
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame FramReport 
      Caption         =   "��§ҹ"
      Height          =   5175
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   5775
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   4575
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   5175
         _ExtentX        =   9128
         _ExtentY        =   8070
         _Version        =   393216
         Rows            =   99
         Cols            =   3
         ScrollBars      =   2
         _NumberOfBands  =   1
         _Band(0).Cols   =   3
      End
   End
   Begin VB.CommandButton CmdESC 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   4680
      TabIndex        =   2
      Top             =   5280
      Width           =   1215
   End
   Begin Crystal.CrystalReport CrystBalance 
      Left            =   1560
      Top             =   5280
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      ReportFileName  =   "C:\project\�����_report\balance_sheet.rpt"
      WindowTitle     =   "�����"
      WindowControlBox=   -1  'True
      WindowMaxButton =   -1  'True
      WindowMinButton =   -1  'True
      WindowState     =   2
      PrintFileLinesPerPage=   60
      WindowShowGroupTree=   -1  'True
      WindowAllowDrillDown=   -1  'True
      WindowShowRefreshBtn=   -1  'True
   End
   Begin Crystal.CrystalReport CryptProfit 
      Left            =   600
      Top             =   5280
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      ReportFileName  =   "C:\project\reports\Profit.rpt"
      WindowTitle     =   "�����âҴ�ع"
      WindowControlBox=   -1  'True
      WindowMaxButton =   -1  'True
      WindowMinButton =   -1  'True
      WindowState     =   2
      PrintFileLinesPerPage=   60
      WindowShowGroupTree=   -1  'True
      WindowAllowDrillDown=   -1  'True
      WindowShowRefreshBtn=   -1  'True
   End
   Begin Crystal.CrystalReport CrystAnalyse 
      Left            =   2400
      Top             =   5280
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      ReportFileName  =   "C:\project\reports\Analyse.rpt"
      WindowState     =   2
      PrintFileLinesPerPage=   60
   End
End
Attribute VB_Name = "Report"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Setgrid()
Dim row_temp As Integer
Dim i As Integer
Dim point_grid As Integer
point_grid = 350
row_temp = 1  ' set ���㹡�� clear gridinv

gridinv.Move point_grid, 300 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 200
gridinv.ColWidth(1) = 5500


gridinv.TextMatrix(0, 1) = "��ª���������§ҹ"
gridinv.TextMatrix(1, 1) = "Report �����ͧ"
gridinv.TextMatrix(2, 1) = "Report �ѭ������"
gridinv.TextMatrix(3, 1) = "Report �����âҴ�ع"
gridinv.TextMatrix(4, 1) = "Report �����"
gridinv.TextMatrix(5, 1) = "Report �������짺����Թ"
gridinv.TextMatrix(6, 1) = "Report �ѧ�ѭ��"
gridinv.TextMatrix(7, 1) = "Report ��д�ɷӡ��"

'Do While (gridinv.Rows - 1) > row_temp
                        
 '           gridinv.TextMatrix(row_temp, 1) = ""
  '          gridinv.TextMatrix(row_temp, 2) = ""
   '         row_temp = row_temp + 1
'Loop

For i = 0 To 1
gridinv.col = i
gridinv.ColAlignment = 1
Next i

gridinv.row = 1
gridinv.col = 0
End Sub

Private Sub CmdESC_Click()
    Unload Me
    windows_account.Show
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then
        Unload Me
        windows_account.Show
    End If
End Sub

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
    If KeyCode = 27 Then
        Unload Me
        windows_account.Show
    End If
End Sub

Private Sub Form_Load()
    Call Setgrid
End Sub

Private Sub gridinv_DblClick()
                    Select Case gridinv.Text
                                   Case "Report �����ͧ"
                                                reportTest.Show
                                    Case "Report �ѭ������"
                                                item_account.Show
                                    Case "Report �����âҴ�ع"
                                                ProfitReport.Show
                                    Case "Report �����"
                                                balance_report.Show
                                    Case "Report �������짺����Թ"
                                                AnalyseReport.Show
                                    Case "Report �ѧ�ѭ��"
                                                plan_report.Show
                                    Case "Report ��д�ɷӡ��"
                                                paperWork_report.Show
                    End Select
End Sub

Private Sub gridinv_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then
        Unload Me
        windows_account.Show
    End If
End Sub
