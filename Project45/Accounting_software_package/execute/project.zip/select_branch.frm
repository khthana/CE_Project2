VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form select_branch 
   Caption         =   "��¡��Ἱ�����ѷ"
   ClientHeight    =   5865
   ClientLeft      =   1935
   ClientTop       =   1275
   ClientWidth     =   6390
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   ScaleHeight     =   5865
   ScaleWidth      =   6390
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   5040
      TabIndex        =   2
      Top             =   5400
      Width           =   1215
   End
   Begin VB.Frame Frame1 
      Caption         =   "���͡Ἱ�����ѷ"
      Height          =   5175
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6135
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   4575
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   5655
         _ExtentX        =   9975
         _ExtentY        =   8070
         _Version        =   393216
         Rows            =   99
         Cols            =   3
         ScrollBars      =   2
         _NumberOfBands  =   1
         _Band(0).Cols   =   3
      End
   End
End
Attribute VB_Name = "select_branch"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public nameSelect_account As String

Private Sub CmdESC_Click()
    Unload Me
    windows_account.Show
End Sub

Private Sub Form_Load()
            Call Setgrid
            Call display_grid
            
End Sub
Private Sub display_grid()

Dim tmp_row As Integer
Dim row_edit As Integer
row_edit = 1
        Call Setgrid
        Call cheak_dataenvironment
        acc_data.cn_sub.Open
        acc_data.concurrent_sub
        acc_data.Sub
                          If acc_data.rssub.RecordCount > 0 Then
                                            tmp_row = acc_data.rssub.RecordCount
                                            Do
                                                        
                                                        gridinv.TextMatrix(row_edit, 1) = acc_data.rssub.Fields(0)
                                                        gridinv.TextMatrix(row_edit, 2) = acc_data.rssub.Fields(2)
                                                        
                                                        row_edit = row_edit + 1
                                                        tmp_row = tmp_row - 1
                                                        acc_data.rssub.MoveNext
                                            Loop Until tmp_row = 0
                                            
                            End If
                
                              
        Call cheak_dataenvironment

End Sub

Private Sub Setgrid()
Dim row_temp As Integer
Dim i As Integer
Dim point_grid As Integer
point_grid = 350
row_temp = 1  ' set ���㹡�� clear gridinv

gridinv.Move point_grid, 300 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 200
gridinv.ColWidth(1) = 1000
gridinv.ColWidth(2) = 4500

gridinv.TextMatrix(0, 1) = "����Ἱ�"
gridinv.TextMatrix(0, 2) = "����Ἱ�"

Do While (gridinv.Rows - 1) > row_temp
                        
            gridinv.TextMatrix(row_temp, 1) = ""
            gridinv.TextMatrix(row_temp, 2) = ""
            row_temp = row_temp + 1
Loop

For i = 0 To 1
gridinv.col = i
gridinv.ColAlignment = 1
Next i

gridinv.row = 1
gridinv.col = 0
End Sub

Private Sub cheak_dataenvironment()

            If acc_data.cn_sub.State = adStateOpen Then   '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_sub.Close
            End If

End Sub

Private Sub gridinv_DblClick()
Dim a As String
Dim sub_choose As String
Dim leng As Integer
a = gridinv.Text
If a = "" Then
Exit Sub
End If
leng = Len(a)
Call cheak_dataenvironment
acc_data.cn_sub.Open
acc_data.concurrent_sub
If leng < 4 Then
        acc_data.cheak_sub a
        If acc_data.rscheak_sub.RecordCount = 0 Then
               acc_data.check_sub_name a
               If acc_data.rscheck_sub_name.RecordCount > 0 Then
                  sub_choose = acc_data.rscheck_sub_name.Fields(0)
                  choose_branch.setsub (sub_choose)
               End If
        Else
              sub_choose = acc_data.rscheak_sub.Fields(0)
              choose_branch.setsub (sub_choose)
        End If
Else
        acc_data.check_sub_name a
        If acc_data.rscheck_sub_name.RecordCount > 0 Then
                  sub_choose = acc_data.rscheck_sub_name.Fields(0)
                  choose_branch.setsub (sub_choose)
        End If
End If
'***********************************************************
nameSelect_account = gridinv.Text   'get text for select_account

Call cheak_dataenvironment
Unload Me
select_account.Show
End Sub

Private Sub gridinv_KeyPress(KeyAscii As Integer)
                If KeyAscii = 27 Then
                                Call cheak_dataenvironment
                                Unload Me
                                windows_account.Show
                End If

End Sub
