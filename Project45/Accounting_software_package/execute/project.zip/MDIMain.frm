VERSION 5.00
Begin VB.MDIForm MDIMain 
   BackColor       =   &H8000000C&
   Caption         =   "Accounting (Module GL)"
   ClientHeight    =   7980
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10530
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   2  'CenterScreen
   WindowState     =   2  'Maximized
   Begin VB.Menu begin 
      Caption         =   "��������������к��ѭ��"
      Begin VB.Menu subBegin1 
         Caption         =   "�ʹ¡��"
      End
      Begin VB.Menu subBegin2 
         Caption         =   "������������ź���ѷ"
      End
      Begin VB.Menu subBegin3 
         Caption         =   "�������������Ἱ�"
      End
      Begin VB.Menu subBegin4 
         Caption         =   "��䢼ѧ�ѭ��"
      End
      Begin VB.Menu subBegin5 
         Caption         =   "�����żŢ���������Ѻ Report ��鹻�"
      End
      Begin VB.Menu subBegin6 
         Caption         =   "�Դ�ѭ����鹻�"
      End
      Begin VB.Menu subBegin7 
         Caption         =   "�͡�ҡ�����"
      End
   End
   Begin VB.Menu book 
      Caption         =   "ŧ��ش����ѹ"
      Begin VB.Menu subBook1 
         Caption         =   "��ش����ѹ�����"
      End
      Begin VB.Menu subBook2 
         Caption         =   "��ش�Թʴ�Ѻ"
      End
      Begin VB.Menu subBook3 
         Caption         =   "��ش�Թʴ����"
      End
      Begin VB.Menu subBook4 
         Caption         =   "��ش��������"
      End
      Begin VB.Menu subBook5 
         Caption         =   "��ش�������"
      End
   End
   Begin VB.Menu Analyse 
      Caption         =   "�������짺����Թ"
      Begin VB.Menu subAnalyse1 
         Caption         =   "�������������Ҿ���ͧ�Ԩ���"
         Begin VB.Menu subAnalyse11 
            Caption         =   "�ѵ����ǹ�ع��ع���¹"
         End
         Begin VB.Menu subAnalyse12 
            Caption         =   "�ѵ����ǹ�ع��ع���¹����"
         End
      End
      Begin VB.Menu subAnalyse2 
         Caption         =   "������������ѵ����ǹ�ʴ��ʴ���������ö㹡�÷ӡ���"
         Begin VB.Menu subAnalyse21 
            Caption         =   "�ѵ����ǹ�����ط�Ե���ʹ��� �����ѵ�Ҽŵͺ᷹�ʹ���"
         End
         Begin VB.Menu subAnalyse22 
            Caption         =   "�ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع"
         End
      End
      Begin VB.Menu subAnalyse3 
         Caption         =   "�ѵ����ǹ�ʴ���������§㹡�û�Сͺ��áԨ"
         Begin VB.Menu subAnalyse31 
            Caption         =   "�ѵ����ǹ˹���Թ����Թ��Ѿ�����"
         End
         Begin VB.Menu subAnalyse32 
            Caption         =   "�ѵ����ǹ˹���Թ�����ǹ�ͧ��Ңͧ"
         End
         Begin VB.Menu subAnalyse33 
            Caption         =   "�ѵ����ǹ�ʴ���������ö㹡�è��´͡����"
         End
      End
      Begin VB.Menu subAnalyse4 
         Caption         =   "�ѵ����ǹ�ʴ�����Է���Ҿ㹡�ô��Թ�ҹ"
         Begin VB.Menu subAnalyse41 
            Caption         =   "�ѵ�ҡ����ع���¹�ͧ�١˹��"
         End
         Begin VB.Menu subAnalyse42 
            Caption         =   "�ѵ�ҡ����ع���¹�ͧ�Թ��Ҥ���ѧ"
         End
         Begin VB.Menu subAnalyse43 
            Caption         =   "�ѵ�ҡ����ع���¹�ͧ�Թ��Ѿ�����"
         End
      End
      Begin VB.Menu subAnalyse5 
         Caption         =   "��§ҹ�������짺����Թ"
      End
      Begin VB.Menu subAnalyse6 
         Caption         =   "ź�ѵ�������������Թ"
      End
   End
   Begin VB.Menu Report 
      Caption         =   "��§ҹ�к��ѭ��"
      Begin VB.Menu subReport1 
         Caption         =   "��§ҹ����÷��ͧ"
      End
      Begin VB.Menu subReport2 
         Caption         =   "��§ҹ�ѭ������"
      End
      Begin VB.Menu subReport3 
         Caption         =   "��§ҹ�����âҴ�ع"
      End
      Begin VB.Menu subReport4 
         Caption         =   "��§ҹ�����"
      End
      Begin VB.Menu subReport5 
         Caption         =   "��§ҹ�������짺����Թ"
      End
      Begin VB.Menu subReport6 
         Caption         =   "��§ҹ�ѧ�ѭ��"
      End
      Begin VB.Menu subReport8 
         Caption         =   "��§ҹ��д�ɷӡ��"
      End
   End
End
Attribute VB_Name = "MDIMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub MDIForm_Load()
    'windows_account.Show
    'windows_account.Top = 1155
    'windows_account.Left = 3800
    'windows_account.Height = 8430
    'windows_account.Width = 7905
End Sub

Private Sub subAnalyse11_Click()
    Unload close_account
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_CRatio.Show
    frmSp_CRatio.Top = 1155
    frmSp_CRatio.Left = 3200
End Sub

Private Sub subAnalyse12_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_QRatio.Show
    frmSp_QRatio.Top = 1155
    frmSp_QRatio.Left = 3200
End Sub

Private Sub subAnalyse21_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_NPMargin.Show
    frmSp_NPMargin.Top = 1155
    frmSp_NPMargin.Left = 3200
End Sub

Private Sub subAnalyse22_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_ROI.Show
    frmSp_ROI.Top = 1155
    frmSp_ROI.Left = 3200
End Sub

Private Sub subAnalyse31_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_TAT.Show
    frmSp_TAT.Top = 1155
    frmSp_TAT.Left = 3200
End Sub

Private Sub subAnalyse32_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_DERatio.Show
    frmSp_DERatio.Top = 1155
    frmSp_DERatio.Left = 3200
End Sub

Private Sub subAnalyse33_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_TIE.Show
    frmSp_TIE.Top = 1155
    frmSp_TIE.Left = 3200
End Sub

Private Sub subAnalyse41_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_ART.Show
    frmSp_ART.Top = 1155
    frmSp_ART.Left = 3200
End Sub

Private Sub subAnalyse42_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_IT.Show
    frmSp_IT.Top = 1155
    frmSp_IT.Left = 3200
End Sub

Private Sub subAnalyse43_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    frmSp_DRatio.Show
    frmSp_DRatio.Top = 1155
    frmSp_DRatio.Left = 3200
End Sub

Private Sub subAnalyse5_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    AnalyseReport.Show
    AnalyseReport.Top = 1155
    AnalyseReport.Left = 5500
    AnalyseReport.Height = 2505
    AnalyseReport.Width = 3735
End Sub

Private Sub subAnalyse6_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    Unload start_account
        
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ���ź�ѵ�ҵ�ҧ���س�ӹǳ��� ����Ѻ Report ��������� ?", vbYesNo, "ź������") = vbYes Then
            acc_data.ClearAnalyse
        End If
        acc_data.cn_plan.Close
End Sub

Private Sub subBegin1_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    start_account.Show
    start_account.Top = 1155
    start_account.Left = 2600
    start_account.Height = 8445
    start_account.Width = 9885
End Sub

Private Sub subBegin2_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    ENTER_COMPANY.Show
    ENTER_COMPANY.Top = 500
    ENTER_COMPANY.Left = 3200
    ENTER_COMPANY.Height = 9570
    ENTER_COMPANY.Width = 8850
End Sub

Private Sub subBegin3_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    enter_branch.Show
    enter_branch.Top = 600
    enter_branch.Left = 3200
    enter_branch.Height = 8850
    enter_branch.Width = 8880
End Sub

Private Sub subBegin4_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    data_plan_account.Show
    data_plan_account.Top = 1155
    data_plan_account.Left = 3700
    data_plan_account.Height = 6675
    data_plan_account.Width = 8100
End Sub

Private Sub subBegin5_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    process_report.Show
    process_report.Top = 1155
    process_report.Left = 5000
    process_report.Height = 3045
    process_report.Width = 4230
End Sub

Private Sub subBegin6_Click()
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    Unload process_report

    close_account.Show
    close_account.Top = 1155
    close_account.Left = 5000
    close_account.Height = 2550
    close_account.Width = 3435
    
    
End Sub

Private Sub subBegin7_Click()
    Unload Me
End Sub

Private Sub subBook1_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    book_general_day.book_code = "GJ"
    book_general_day.Show
    book_general_day.Top = 1155
    book_general_day.Left = 2300
    book_general_day.Height = 8070
    book_general_day.Width = 10575
End Sub

Private Sub subBook2_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    book_cash_receive.book_code = "SC"
    book_cash_receive.Show
    book_cash_receive.Top = 1155
    book_cash_receive.Left = 2300
    book_cash_receive.Height = 8070
    book_cash_receive.Width = 10575
End Sub

Private Sub subBook3_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    book_cash_pay.book_code = "PC"
    book_cash_pay.Show
    book_cash_pay.Top = 1155
    book_cash_pay.Left = 2300
    book_cash_pay.Height = 8070
    book_cash_pay.Width = 10575
End Sub

Private Sub subBook4_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
       
    book_credit_buy.book_code = "PD"
    book_credit_buy.Show
    book_credit_buy.Top = 1155
    book_credit_buy.Left = 2300
    book_credit_buy.Height = 8070
    book_credit_buy.Width = 10575
End Sub

Private Sub subBook5_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    book_credit_sell.book_code = "SD"
    book_credit_sell.Show
    book_credit_sell.Top = 1155
    book_credit_sell.Left = 2300
    book_credit_sell.Height = 8070
    book_credit_sell.Width = 10575
End Sub

Private Sub subReport1_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    reportTest.Show
    reportTest.Top = 1155
    reportTest.Left = 5500
    reportTest.Height = 2625
    reportTest.Width = 3765
End Sub

Private Sub subReport2_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    item_account.Show
    item_account.Top = 1155
    item_account.Left = 5500
    item_account.Height = 3195
    item_account.Width = 4080
End Sub

Private Sub subReport3_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    ProfitReport.Show
    ProfitReport.Top = 1155
    ProfitReport.Left = 5500
    ProfitReport.Height = 2595
    ProfitReport.Width = 3765
End Sub

Private Sub subReport4_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload AnalyseReport
    Unload plan_report
    Unload balanch_sheet
    
    balance_report.Show
    balance_report.Top = 1155
    balance_report.Left = 5500
    balance_report.Height = 2580
    balance_report.Width = 3750
End Sub

Private Sub subReport5_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload plan_report
    Unload balanch_sheet
    
    AnalyseReport.Show
    AnalyseReport.Top = 1155
    AnalyseReport.Left = 5500
    AnalyseReport.Height = 2505
    AnalyseReport.Width = 3735
End Sub

Private Sub subReport6_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload balanch_sheet
    
    plan_report.Show
    plan_report.Top = 1155
    plan_report.Left = 5500
    plan_report.Height = 2490
    plan_report.Width = 3750
End Sub

Private Sub subReport8_Click()
   Unload close_account
    Unload frmSp_CRatio
    Unload frmSp_QRatio
    Unload frmSp_NPMargin
    Unload frmSp_ROI
    Unload frmSp_TAT
    Unload frmSp_DERatio
    Unload frmSp_TIE
    Unload frmSp_ART
    Unload frmSp_IT
    Unload frmSp_DRatio
    Unload AnalyseReport
    Unload start_account
    Unload ENTER_COMPANY
    Unload enter_branch
    Unload data_plan_account
    Unload process_report
    Unload book_general_day
    Unload book_cash_receive
    Unload book_cash_pay
    Unload book_credit_buy
    Unload book_credit_sell
    Unload reportTest
    Unload item_account
    Unload ProfitReport
    Unload balance_report
    Unload AnalyseReport
    Unload plan_report
    
    balanch_sheet.Show
    balanch_sheet.Top = 1155
    balanch_sheet.Left = 5500
    balanch_sheet.Height = 2580
    balanch_sheet.Width = 4305
End Sub
