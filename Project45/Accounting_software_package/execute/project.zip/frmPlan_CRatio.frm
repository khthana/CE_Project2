VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form frmPlan_CRatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   4425
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   4215
   ControlBox      =   0   'False
   Icon            =   "frmPlan_CRatio.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4425
   ScaleWidth      =   4215
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC_CRatio 
      Caption         =   "ESC"
      Height          =   375
      Left            =   2880
      TabIndex        =   0
      Top             =   4030
      Width           =   1335
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MFGridPlan_CRatio 
      Height          =   3975
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   7011
      _Version        =   393216
      BackColor       =   -2147483624
      Rows            =   17
      Cols            =   3
      FixedCols       =   0
      AllowBigSelection=   0   'False
      BandDisplay     =   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   3
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
End
Attribute VB_Name = "frmPlan_CRatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub CmdESC_CRatio_Click()
        frmSp_CRatio.Show
        Unload Me
End Sub

Private Sub Show_Plan()
     Dim i As Integer
     Dim Sum As Integer
     Call check_rs
     acc_data.cn_plan.Open
     acc_data.plan
     Sum = acc_data.rsplan.RecordCount  'total row of plan
     MFGridPlan_CRatio.Rows = Sum + 1
        
        MFGridPlan_CRatio.ColWidth(1) = 2000
        MFGridPlan_CRatio.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_CRatio.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_CRatio.TextMatrix(0, 2) = "��Դ�ѭ��"
     
     i = 0
     Do While i < Sum
        MFGridPlan_CRatio.TextMatrix(i + 1, 0) = acc_data.rsplan.Fields(0) 'check id_account in table plan_account
        MFGridPlan_CRatio.TextMatrix(i + 1, 1) = acc_data.rsplan.Fields(1) 'check name_account in table plan_account
        MFGridPlan_CRatio.TextMatrix(i + 1, 2) = acc_data.rsplan.Fields(2) 'check type_account in table plan_account
        i = i + 1
        acc_data.rsplan.MoveNext
     Loop

End Sub

Private Sub Form_Load()
        Show_Plan
End Sub

Private Sub MFGridPlan_CRatio_DblClick()
        Dim col As String
        Dim row As String
        Dim planType As String
        Dim a As String
        
        If CheckID(MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)) Then  'get ID_account
                If frmSp_CRatio.index = "1" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0), 1) 'check is Asset?
                                                                                            
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)
                                                frmSp_CRatio.TxtID1_CRatio.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_CRatio.TxtName1_CRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_CRatio.TxtMoney1_CRatio.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)
                                                frmSp_CRatio.TxtID1_CRatio.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_CRatio.TxtName1_CRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_CRatio.TxtMoney1_CRatio.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        Unload Me
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                ElseIf frmSp_CRatio.index = "2" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0), 1) 'check is debt?
                                                                                            
                                If a = "2" Then  'is debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)
                                                frmSp_CRatio.TxtID2_CRatio.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_CRatio.TxtName2_CRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_CRatio.TxtMoney2_CRatio.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_CRatio.TextMatrix(CInt(MFGridPlan_CRatio.row), 0)
                                                frmSp_CRatio.TxtID2_CRatio.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_CRatio.TxtName2_CRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_CRatio.TxtMoney2_CRatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        Unload Me
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                End If
        Else
                MsgBox "���ʺѭ�չ���������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        End If
End Sub
