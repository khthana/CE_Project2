VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.UserControl grid_acc1 
   ClientHeight    =   3825
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   9345
   ScaleHeight     =   3825
   ScaleWidth      =   9345
   Begin VB.Frame Frame1 
      BackColor       =   &H80000000&
      BorderStyle     =   0  'None
      Height          =   3855
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   9375
      Begin VB.PictureBox inputpic 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         ForeColor       =   &H80000008&
         Height          =   300
         Left            =   1200
         ScaleHeight     =   270
         ScaleWidth      =   795
         TabIndex        =   1
         Tag             =   "noprint"
         Top             =   4320
         Visible         =   0   'False
         Width           =   825
         Begin VB.TextBox TMText 
            Appearance      =   0  'Flat
            BorderStyle     =   0  'None
            Height          =   390
            Left            =   0
            TabIndex        =   2
            ToolTipText     =   "Enter data"
            Top             =   0
            Width           =   840
         End
      End
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   3615
         Left            =   0
         TabIndex        =   3
         Top             =   120
         Width           =   9255
         _ExtentX        =   16325
         _ExtentY        =   6376
         _Version        =   393216
         BackColor       =   -2147483624
         Rows            =   99
         Cols            =   4
         FixedCols       =   0
         GridColorFixed  =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         _NumberOfBands  =   1
         _Band(0).Cols   =   4
      End
      Begin VB.Image Image2 
         Height          =   480
         Left            =   4590
         Picture         =   "grid_acc1.ctx":0000
         Top             =   735
         Visible         =   0   'False
         Width           =   480
      End
      Begin VB.Label Total 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Total"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   7290
         TabIndex        =   5
         Top             =   5490
         Width           =   615
      End
      Begin VB.Label TotalInv 
         Alignment       =   1  'Right Justify
         BackStyle       =   0  'Transparent
         Height          =   255
         Left            =   8025
         TabIndex        =   4
         Top             =   5505
         Width           =   1110
      End
   End
   Begin VB.Label Label3 
      Caption         =   "���͡�ѹ���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8400
      TabIndex        =   6
      Top             =   120
      Width           =   735
   End
End
Attribute VB_Name = "grid_acc1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Option Explicit

Public Event sumvalue(value_debit As String, value_credit As String)
Public Event RowData(row1 As Integer, id_acc As String, val_debit As Currency, val_credit As Currency)

Dim debit As String
Dim credit As String

Dim LastLine As Integer
Dim Init As Boolean
Dim col_number As Integer
Dim r1 As Integer
'Dim j As Integer
'Dim insert1 As Integer


Private Sub gridinv_EnterCell()  ' �͹��ԡ����ͧ�

On Error Resume Next

If Init Then
        
        'Exit Sub    'lnit �繤�� true  �ʴ�����ش��÷Ѵ����
Else

        inputpic.Move gridinv.CellLeft - 20
        inputpic.Top = gridinv.CellTop + gridinv.Top - 20
        inputpic.Visible = True
        
        inputpic.Width = gridinv.CellWidth + 10
        inputpic.Height = gridinv.CellHeight + 20
        TMText.Width = inputpic.Width

End If

TMText.SetFocus
TMText.Text = gridinv.Text
TMText.SelStart = 0
TMText.SelLength = 100

End Sub
Private Sub gridinv_LeaveCell()

On Error Resume Next
Dim tem_number As Double
Dim tem_string As String

'tem_number = Val(TMText.Text)
'tem_string = Str(tem_number)
'If tem_string = " 0" Then
'        tem_string = " "
'End If
    If gridinv.Col = 2 Or gridinv.Col = 3 Then
            If IsNumeric(TMText.Text) Or (TMText.Text = "") Then
            'If (Len(tem_string) - 1) = Len(TMText.Text) Then
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        TotalSum_credit
                        TotalSum_dabit
                        RaiseEvent sumvalue(debit, credit)
                        If gridinv.Col = 2 And (0 <> Len(TMText.Text)) Then '�ӡ�á��ⴴ����
                            gridinv.Col = gridinv.Col + 1
                        End If
            Else
                        MsgBox "�س�������ŷ�����ѡ�û�����", 48, "����͹"
                        gridinv.Col = gridinv.Col - 1
                        
            End If
    Else
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        TotalSum_credit
                        TotalSum_dabit
                        RaiseEvent sumvalue(debit, credit)
    End If
End Sub

Private Sub gridinv_Scroll()

On Error Resume Next
If Init Then Exit Sub
If Not gridinv.RowIsVisible(gridinv.row) Or Not gridinv.ColIsVisible(gridinv.Col) Then
inputpic.Visible = False
Else
inputpic.Move gridinv.CellLeft
inputpic.Top = gridinv.CellTop + gridinv.Top
inputpic.Visible = True
End If

End Sub




Private Sub TMtext_KeyDown(KeyCode As Integer, Shift As Integer) '�͹��������� textb  ����MOUSE  ��ԡ

Select Case KeyCode
            Case 13
                            gridinv_LeaveCell
                            cheak_enter
                            gridinv_EnterCell
            Case 37
                            gridinv_LeaveCell
                            cheak_left
                            gridinv_EnterCell
            Case 38
                            gridinv_LeaveCell
                            cheak_up
                            gridinv_EnterCell
            Case 39
                            gridinv_LeaveCell
                            cheak_right
                            gridinv_EnterCell
            Case 40
                            gridinv_LeaveCell
                            cheak_down
                            gridinv_EnterCell
            Case 113
                            'balence_Click
            Case 114
                            'insert_Click
            Case 115
                            'eraser_Click
            
            End Select
End Sub

Private Sub cheak_enter()  '��Ǩ�ͺ����ش��÷Ѵ�ѧ�� ��Ǩ�ͺ������ 6 col
Dim st1 As String
Dim s As Integer
Dim z As Integer
Dim id_acc As String
Dim val_debit As Currency
Dim val_credit As Currency
Dim sub1 As String
Dim group As String
Dim kk1 As String
Dim kk2 As String

s = 1
                If gridinv.Col < (col_number - 1) Then
                        If gridinv.Col = 0 Then
                           st1 = gridinv.Text
                           'acc_data.cn_plan.Open
                           'acc_data.name_acc st1
                           gr_acc.cn_plans.Open
                           gr_acc.acc_name st1
                           If gr_acc.rsacc_name.RecordCount = 0 Then
                              MsgBox "���ʺѭ�շ��س��͹���������㹼ѧ�ѭ��", vbOKOnly, "����͹"
                              'gridinv.col = gridinv.col - 1
                              s = 0
                            Else
                               gr_acc.name_accd st1
                               If gr_acc.rsname_accd.RecordCount = 0 Then
                                 MsgBox "���ʺѭ�շ��س��͹�����ʡ�����ͧ�ѧ�ѭ��", vbOKOnly, "����͹"
                                 s = 0
                              Else
                                  'tempgrid = str1
                                 gridinv.Col = gridinv.Col + 1
                                 gridinv.Text = gr_acc.rsacc_name.Fields(0)
                               End If
                            End If
                            'acc_data.cn_plan.Close
                            gr_acc.cn_plans.Close
                        End If
                        gridinv.Col = gridinv.Col + s
                Else
                        If IsNumeric(gridinv.TextMatrix(gridinv.row, 2)) And IsNumeric(gridinv.TextMatrix(gridinv.row, 3)) Then
                                        MsgBox "�س�������Ũӹǹ�Թ㹪�ͧ �ӹǹ�ԹഺԵ ��� �ӹǹ�Թ�ôԵ ", 48, "����͹"
                                        gridinv.Col = 2
                                        Exit Sub
                        End If
                        
                        gridinv.Col = 0
                        ' �� event ��繤�ҷ�����
                        id_acc = gridinv.Text
                        gridinv.Col = 2
                        kk1 = gridinv.Text
                        If gridinv.Text = "" Then
                        gridinv.Text = "0"     '�����������ʴ����0�grid
                        End If
                        val_debit = CCur(gridinv.Text)
                        gridinv.Text = kk1
                        gridinv.Col = 3
                        kk2 = gridinv.Text
                        If gridinv.Text = "" Then
                        gridinv.Text = "0"     '�����������ʴ����0�grid
                        End If
                        val_credit = CCur(gridinv.Text)
                        gridinv.Text = kk2
                        'gridinv.Col = 4
                        'sub1 = gridinv.Text
                        'gridinv.Col = 5
                        r1 = gridinv.row
                        'group = gridinv.Text
                        RaiseEvent RowData(r1, id_acc, val_debit, val_credit)
                        '�� event �����纤�ҷ���͹
                        gridinv.Col = 0
                        'If (gridinv.col = 0) And (gridinv.row = 1) Then
                        '    gridinv.Text = j
                        'End If
                        gridinv.row = gridinv.row + 1
                        'gridinv.col = 1
                        'If gridinv.Text = "" Then
                         '  gridinv.col = 0
                          '  j = j + 1
                           ' gridinv.Text = j
                            'gridinv.col = 1
                        'Else
                         '   j = j + insert1 + 1
                          '  gridinv.row = j
                           ' gridinv.col = 0
                            'gridinv.Text = j
                            'gridinv.col = 1
                            'insert1 = 0
                        'End If
                End If
End Sub
Private Sub cheak_up()  '��Ǩ�ͺ����ش��÷Ѵ���ѧ
                
                If gridinv.row <= 1 Then
                        gridinv.row = 1
                Else
                        gridinv.row = gridinv.row - 1
                End If

End Sub
Private Sub cheak_down()  '��Ǩ�ͺ����ش��÷Ѵ��ҧ�ѧ
                
                If gridinv.row >= (LastLine - 1) Then
                        gridinv.row = (LastLine - 1)
                Else
                        If (Len(gridinv.TextMatrix(gridinv.row, 2)) > 0) And (Len(gridinv.TextMatrix(gridinv.row, 3)) > 0) Then
                        Else
                               gridinv.row = gridinv.row + 1
                        End If
                End If

End Sub
Private Sub cheak_left()  '��Ǩ�ͺ����ش��÷Ѵ����
                
                If gridinv.Col > 0 Then
                        gridinv.Col = gridinv.Col - 1
                Else
                        gridinv.Col = col_number - 1
                End If
End Sub
Private Sub cheak_right()  '��Ǩ�ͺ����ش��÷Ѵ���
                If gridinv.Col < (col_number - 1) Then
                        gridinv.Col = gridinv.Col + 1
                Else
                        gridinv.Col = 0
                        
                End If
End Sub

Private Sub Setgrid()

Dim i As Integer


gridinv.Move 20, 100    'set ���˹觢ͧ textbox 㹡���ʴ�������

'gridinv.ColWidth(0) = 600
gridinv.ColWidth(0) = 1300
gridinv.ColWidth(1) = 4000
gridinv.ColWidth(2) = 1800
gridinv.ColWidth(3) = 1800
'gridinv.ColWidth(4) = 700
'gridinv.ColWidth(5) = 400

'gridinv.TextMatrix(0, 0) = "�ӴѺ���"
gridinv.TextMatrix(0, 0) = "���ʺѭ��"  '���ʺѭ��
gridinv.TextMatrix(0, 1) = "���ͺѭ��"  '���ͺѭ��
gridinv.TextMatrix(0, 2) = "�ӹǹ�ԹഺԵ"   '�ӹǹ�ԹഺԵ
gridinv.TextMatrix(0, 3) = "�ӹǹ�Թ�ôԵ"  ' �ӹǹ�Թ�ôԵ
'gridinv.TextMatrix(0, 4) = "Ἱ�"  ' Ἱ�
'gridinv.TextMatrix(0, 5) = "G"  ' G
gridinv.Col = 0
LastLine = 99  ' �ʴ���÷Ѵ�ش����

'j = 1
'gridinv.Text = j

For i = 0 To 3
gridinv.Col = i
gridinv.ColAlignment = 7
Next i

gridinv_EnterCell
'Date = Format(Now, "dd/mm/yy")

TotalSum_dabit
TotalSum_credit
RaiseEvent sumvalue(debit, credit)
TMText.SelStart = 0        '���˹��á�鹢ͧ����ҧ "textbox"
TMText.SelLength = 100  '��˹�100 ����ѡ��
 
Init = False
gridinv.row = 1
gridinv.Col = 1
End Sub

Private Sub TotalSum_dabit()

On Error Resume Next

Dim Sum As Currency
Dim row As Integer
row = 1
        Do While row < 100
                        Sum = Sum + CDbl(gridinv.TextMatrix(row, 2))
                        row = row + 1
      Loop
debit = Str$(Sum)
End Sub

Private Sub TotalSum_credit()

On Error Resume Next

Dim Sum As Double
Dim row As Integer
row = 1
        Do While row < 100
                    Sum = Sum + CDbl(gridinv.TextMatrix(row, 3))
                    row = row + 1
        Loop
credit = Str$(Sum)
End Sub

Private Sub UserControl_Initialize()
Init = True
LastLine = 99
col_number = 4
gridinv.Col = 0
Setgrid
End Sub
