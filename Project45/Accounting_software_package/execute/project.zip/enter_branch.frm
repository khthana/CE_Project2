VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form enter_branch 
   Caption         =   "��䢢�����Ἱ��ӡ��"
   ClientHeight    =   8445
   ClientLeft      =   2145
   ClientTop       =   1275
   ClientWidth     =   8760
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MDIChild        =   -1  'True
   ScaleHeight     =   8445
   ScaleWidth      =   8760
   Begin TabDlg.SSTab SSTab1 
      Height          =   8295
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8445
      _ExtentX        =   14896
      _ExtentY        =   14631
      _Version        =   393216
      TabHeight       =   706
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "enter_branch.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame1"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "���"
      TabPicture(1)   =   "enter_branch.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame2"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "���ҧ����"
      TabPicture(2)   =   "enter_branch.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame3"
      Tab(2).Control(0).Enabled=   0   'False
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame3 
         Caption         =   "���ҧἹ�"
         Height          =   7575
         Left            =   -74760
         TabIndex        =   4
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton esc_new 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   6480
            TabIndex        =   29
            Top             =   6960
            Width           =   1215
         End
         Begin VB.CommandButton save_new 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   375
            Left            =   5040
            TabIndex        =   28
            Top             =   6960
            Width           =   1215
         End
         Begin VB.TextBox fax_new 
            Height          =   315
            Left            =   2400
            TabIndex        =   27
            Top             =   4120
            Width           =   1935
         End
         Begin VB.TextBox tel_new 
            Height          =   315
            Left            =   2400
            TabIndex        =   26
            Top             =   3760
            Width           =   1935
         End
         Begin VB.TextBox address_branch2_new 
            Height          =   980
            Left            =   2400
            MultiLine       =   -1  'True
            TabIndex        =   25
            Top             =   2760
            Width           =   4700
         End
         Begin VB.TextBox name_branch2_new 
            Height          =   315
            Left            =   2400
            TabIndex        =   24
            Top             =   2400
            Width           =   4700
         End
         Begin VB.TextBox address_branch1_new 
            Height          =   980
            Left            =   2400
            MultiLine       =   -1  'True
            TabIndex        =   23
            Top             =   1320
            Width           =   4700
         End
         Begin VB.TextBox name_branch1_new 
            Height          =   315
            Left            =   2400
            TabIndex        =   22
            Top             =   960
            Width           =   4700
         End
         Begin VB.TextBox id_branch_new 
            Height          =   315
            Left            =   2400
            TabIndex        =   21
            Top             =   600
            Width           =   1575
         End
         Begin VB.Label Label14 
            Caption         =   "����Ἱ�"
            Height          =   255
            Left            =   960
            TabIndex        =   36
            Top             =   600
            Width           =   855
         End
         Begin VB.Label Label13 
            Caption         =   "�����"
            Height          =   255
            Left            =   960
            TabIndex        =   35
            Top             =   4080
            Width           =   615
         End
         Begin VB.Label Label12 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   960
            TabIndex        =   34
            Top             =   3840
            Width           =   735
         End
         Begin VB.Label Label11 
            Caption         =   "������������ѧ���"
            Height          =   495
            Left            =   840
            TabIndex        =   33
            Top             =   2760
            Width           =   1215
         End
         Begin VB.Label Label10 
            Caption         =   "���������ѧ���"
            Height          =   255
            Left            =   840
            TabIndex        =   32
            Top             =   2400
            Width           =   1095
         End
         Begin VB.Label Label9 
            Caption         =   "�������������"
            Height          =   375
            Left            =   720
            TabIndex        =   31
            Top             =   1320
            Width           =   1095
         End
         Begin VB.Label Label8 
            Caption         =   "����������"
            Height          =   255
            Left            =   840
            TabIndex        =   30
            Top             =   960
            Width           =   855
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "���Ἱ�"
         Height          =   7575
         Left            =   -74760
         TabIndex        =   3
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton esc_edit 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   6480
            TabIndex        =   20
            Top             =   6960
            Width           =   1215
         End
         Begin VB.CommandButton save_edit 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   375
            Left            =   5040
            TabIndex        =   19
            Top             =   6960
            Width           =   1215
         End
         Begin VB.TextBox fax_edit 
            Height          =   315
            Left            =   2400
            TabIndex        =   18
            Top             =   4120
            Width           =   1935
         End
         Begin VB.TextBox tel_edit 
            Height          =   315
            Left            =   2400
            TabIndex        =   17
            Top             =   3760
            Width           =   1935
         End
         Begin VB.TextBox address_branch2_edit 
            Height          =   980
            Left            =   2400
            MultiLine       =   -1  'True
            TabIndex        =   16
            Top             =   2760
            Width           =   4700
         End
         Begin VB.TextBox name_branch2_edit 
            Height          =   315
            Left            =   2400
            TabIndex        =   15
            Top             =   2400
            Width           =   4700
         End
         Begin VB.TextBox address_branch1_edit 
            Height          =   980
            Left            =   2400
            MultiLine       =   -1  'True
            TabIndex        =   14
            Top             =   1320
            Width           =   4700
         End
         Begin VB.TextBox name_branch1_edit 
            Height          =   315
            Left            =   2400
            TabIndex        =   13
            Top             =   960
            Width           =   4700
         End
         Begin VB.TextBox id_branch_edit 
            BackColor       =   &H80000004&
            Enabled         =   0   'False
            Height          =   315
            Left            =   2400
            TabIndex        =   12
            Top             =   600
            Width           =   1575
         End
         Begin VB.Label Label7 
            Caption         =   "����Ἱ�"
            Height          =   255
            Left            =   960
            TabIndex        =   11
            Top             =   600
            Width           =   855
         End
         Begin VB.Label Label6 
            Caption         =   "�����"
            Height          =   255
            Left            =   960
            TabIndex        =   10
            Top             =   4080
            Width           =   615
         End
         Begin VB.Label Label5 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   960
            TabIndex        =   9
            Top             =   3840
            Width           =   735
         End
         Begin VB.Label Label4 
            Caption         =   "������������ѧ���"
            Height          =   495
            Left            =   600
            TabIndex        =   8
            Top             =   2760
            Width           =   1215
         End
         Begin VB.Label Label3 
            Caption         =   "���������ѧ���"
            Height          =   255
            Left            =   720
            TabIndex        =   7
            Top             =   2400
            Width           =   1095
         End
         Begin VB.Label Label2 
            Caption         =   "�������������"
            Height          =   375
            Left            =   720
            TabIndex        =   6
            Top             =   1320
            Width           =   1095
         End
         Begin VB.Label Label1 
            Caption         =   "����������"
            Height          =   255
            Left            =   840
            TabIndex        =   5
            Top             =   960
            Width           =   855
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "��������´Ἱ�"
         Height          =   7575
         Left            =   240
         TabIndex        =   1
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton esc_detail 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   6360
            TabIndex        =   37
            Top             =   6960
            Width           =   1215
         End
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
            Height          =   6495
            Left            =   360
            TabIndex        =   2
            Top             =   360
            Width           =   7215
            _ExtentX        =   12726
            _ExtentY        =   11456
            _Version        =   393216
            Rows            =   99
            Cols            =   3
            _NumberOfBands  =   1
            _Band(0).Cols   =   3
         End
      End
   End
End
Attribute VB_Name = "enter_branch"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim point_grid As Integer

Private Sub esc_detail_Click()
                Call cheak_dataenvironment
                Unload Me
                'navigator.Show
End Sub

Private Sub Esc_edit_Click()
        '**********clear  text ������  ����¡��ԡ
            id_branch_edit.Text = ""
            name_branch1_edit.Text = ""
            address_branch1_edit.Text = ""
            name_branch2_edit.Text = ""
            address_branch2_edit.Text = ""
            tel_edit.Text = ""
            fax_edit.Text = ""
           
            SSTab1.Tab = 0
            
            Call cheak_dataenvironment
End Sub

Private Sub Esc_new_Click()
            '**********clear  text ������  ����¡��ԡ

            id_branch_new.Text = ""
            name_branch1_new.Text = ""
            address_branch1_new.Text = ""
            name_branch2_new.Text = ""
            address_branch2_new.Text = ""
            tel_new.Text = ""
            fax_new.Text = ""
           
            SSTab1.Tab = 0
            
            Call cheak_dataenvironment
            
End Sub


Private Sub Form_Load()
            Call Setgrid
            SSTab1.Tab = 0
            Call tab_detail
            
End Sub

Private Sub save_edit_Click()
            '***********����������Ţͧ���� text
            If (name_branch1_edit.Text = "") Then
                                        MsgBox "�س�ѧ�����������Ἱ�", vbOKOnly, "ERROR"
                                        name_branch1_edit.SetFocus
                                        Exit Sub
                     ElseIf (address_branch1_edit.Text = "") Then
                                        MsgBox "�س�ѧ��������������Ἱ�", vbOKOnly, "ERROR"
                                        address_branch1_edit.SetFocus
                                        Exit Sub
                              ElseIf tel_edit.Text = "" Then
                                                    MsgBox "�س�ѧ���������������Ѿ��Ἱ�", vbOKOnly, "ERROR"
                                                    tel_edit.SetFocus
                                                    Exit Sub
                                        
                   End If
                    
                    '*********��Ǩ�����ҧ�ͧ����������Ū�ͧ����� ���ͷ������ͧἹ���Ъ���Ἱ� �ӴѺ��� 2 �����������᷹
                    
                    If name_branch2_edit.Text = "" Then
                                    name_branch2_edit.Text = "-"
                    End If
                    If address_branch2_edit.Text = "" Then
                                    address_branch2_edit.Text = "-"
                    End If
                    If fax_edit.Text = "" Then
                       fax_edit.Text = "-"
                    End If
                    Call cheak_dataenvironment
                    
                    acc_data.cn_sub.Open
                    acc_data.concurrent_sub
                    acc_data.sub_edit name_branch1_edit.Text, address_branch1_edit.Text, name_branch2_edit.Text, address_branch2_edit.Text, tel_edit.Text, fax_edit.Text, id_branch_edit.Text
                                                                    
                    Call cheak_dataenvironment
                    Call Esc_edit_Click  '**********clear  text ������  ����save
End Sub

Private Sub save_new_Click()
Dim comp_id As String
'***********��õ�Ǩ�ͺ��ë�Ӣͧ����Ἱ�
             Call cheak_dataenvironment
             acc_data.cn_company.Open
             acc_data.concurrent_company
             acc_data.get_company
             comp_id = acc_data.rsget_company.Fields(0)
             acc_data.cn_company.Close
            Call cheak_dataenvironment
            acc_data.cn_sub.Open
            acc_data.concurrent_sub
            acc_data.cheak_sub id_branch_new.Text
            If acc_data.rscheak_sub.RecordCount > 0 Then
                            MsgBox "�س�������Ἱ���ӫ�͹", vbOKOnly, "ERROR"
                            id_branch_new.SetFocus
                            Call cheak_dataenvironment
                            Exit Sub
            End If
                        id_branch_new.SetFocus   '�������program ˹�ҹ������ҷ�� id_company_new �ѹ���
            '***********��õ�Ǩ�ͺ�����Ţͧ���� text
            If Not IsNumeric(id_branch_new.Text) Then
                            MsgBox "�س�������Ἱ��Դ��Ҵ", vbOKOnly, "ERROR"
                            id_branch_new.SetFocus
                            Exit Sub
            ElseIf (name_branch1_new.Text = "") Then
                                        MsgBox "�س�ѧ�����������Ἱ�", vbOKOnly, "ERROR"
                                        name_branch1_new.SetFocus
                                        Exit Sub
                     ElseIf (address_branch1_new.Text = "") Then
                                        MsgBox "�س�ѧ��������������Ἱ�", vbOKOnly, "ERROR"
                                        address_branch1_new.SetFocus
                                        Exit Sub
                              ElseIf tel_new.Text = "" Then
                                                    MsgBox "�س�ѧ���������������Ѿ��Ἱ�", vbOKOnly, "ERROR"
                                                    tel_new.SetFocus
                                                    Exit Sub
                                        
                    End If
                    
                    '*********��Ǩ�����ҧ�ͧ����������Ū�ͧ����� ���ͷ������ͧἹ���Ъ���Ἱ� �ӴѺ��� 2 �����������᷹
                    
                    If name_branch2_new.Text = "" Then
                                    name_branch2_new.Text = "-"
                    End If
                    If address_branch2_new.Text = "" Then
                                    address_branch2_new.Text = "-"
                    End If
                    If fax_new.Text = "" Then
                       fax_new.Text = "-"
                    End If
                    acc_data.insert_sub id_branch_new.Text, comp_id, name_branch1_new.Text, address_branch1_new.Text, name_branch2_new.Text, address_branch2_new.Text, tel_new.Text, fax_new.Text
                    
                    Call cheak_dataenvironment
                    Call Esc_new_Click  '**********clear  text ������  ����save
End Sub

Private Sub SSTab1_Click(PreviousTab As Integer)
            Call cheak_dataenvironment
            
            Select Case SSTab1.Tab
                        Case 0
                                    Call tab_detail
                                    
                        Case 1
                                    Call tab_edit
            
                        Case 2
                                    Call tab_new
                                    
            End Select
            
End Sub
Private Sub tab_new()
            id_branch_new.SetFocus
End Sub


Private Sub tab_edit()
Dim enbran As Integer
        If Not IsNumeric(gridinv.Text) And (gridinv.Text = "") Then
                    MsgBox "��س����͡����Ἱ�", vbOKOnly, "ERROR"
                    SSTab1.Tab = 0
                    Exit Sub
                    
        Else
                    enbran = Len(gridinv.Text)
                    If enbran > 3 Then
                    MsgBox "��س����͡����Ἱ�", vbOKOnly, "ERROR"
                    SSTab1.Tab = 0
                    Exit Sub
                    End If
                                                        name_branch1_edit.SetFocus
                                                        acc_data.cn_sub.Open
                                                        acc_data.concurrent_sub
                                                        acc_data.cheak_sub gridinv.Text
                                                        
                                                         If Not (acc_data.rscheak_sub.RecordCount > 0) Then
                                                        
                                                                    Exit Sub
                                                            End If
                                                        
                                                        id_branch_edit.Text = acc_data.rscheak_sub.Fields(0)
                                                        name_branch1_edit.Text = acc_data.rscheak_sub.Fields(2)
                                                        address_branch1_edit.Text = acc_data.rscheak_sub.Fields(3)
                                                        name_branch2_edit.Text = acc_data.rscheak_sub.Fields(4)
                                                        address_branch2_edit.Text = acc_data.rscheak_sub.Fields(5)
                                                        tel_edit.Text = acc_data.rscheak_sub.Fields(6)
                                                        fax_edit.Text = acc_data.rscheak_sub.Fields(7)
        End If

End Sub

Private Sub tab_detail()
Dim row_temp As Integer
row_temp = 1

                Call Setgrid
                
                Call cheak_dataenvironment
                acc_data.cn_sub.Open
                acc_data.concurrent_sub
                acc_data.Sub
                If Not (acc_data.rssub.RecordCount > 0) Then
                            Call cheak_dataenvironment
                            Exit Sub
                End If
                
                Do While Not acc_data.rssub.EOF  'cheak �������ش�ͧ data_base
                
                        gridinv.TextMatrix(row_temp, 1) = acc_data.rssub.Fields(0)
                        gridinv.TextMatrix(row_temp, 2) = acc_data.rssub.Fields(2)
                        row_temp = row_temp + 1
                        
                        acc_data.rssub.MoveNext '����͹��� pointer
                Loop
                    
                Call cheak_dataenvironment
                
End Sub

Private Sub cheak_dataenvironment()

            If acc_data.cn_sub.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_sub.Close
            End If

End Sub
Private Sub Setgrid()
Dim row_temp As Integer
Dim i As Integer
point_grid = 350
row_temp = 1  ' set ���㹡�� clear gridinv

gridinv.Move point_grid, 300 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 200
gridinv.ColWidth(1) = 1000
gridinv.ColWidth(2) = 10000

gridinv.TextMatrix(0, 1) = "����Ἱ�"
gridinv.TextMatrix(0, 2) = "����Ἱ�"

Do While (gridinv.Rows - 1) > row_temp
                        
            gridinv.TextMatrix(row_temp, 1) = ""
            gridinv.TextMatrix(row_temp, 2) = ""
            row_temp = row_temp + 1
Loop

For i = 0 To 1
gridinv.col = i
gridinv.ColAlignment = 1
Next i

gridinv.row = 1
gridinv.col = 0
End Sub
