VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Object = "{FADDC776-948C-48BC-A4CF-FBC0830F2582}#11.0#0"; "grid_acc.ocx"
Begin VB.Form book_credit_sell 
   Caption         =   "��ش�������"
   ClientHeight    =   7665
   ClientLeft      =   525
   ClientTop       =   810
   ClientWidth     =   10455
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   7665
   ScaleWidth      =   10455
   Begin TabDlg.SSTab SSTab2 
      Height          =   7455
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   10125
      _ExtentX        =   17859
      _ExtentY        =   13150
      _Version        =   393216
      TabHeight       =   520
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "book_credit_sell.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame3"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "���"
      TabPicture(1)   =   "book_credit_sell.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame1"
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "���ҧ����"
      TabPicture(2)   =   "book_credit_sell.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame2"
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame2 
         Caption         =   "���ҧ����"
         Height          =   6975
         Left            =   -74880
         TabIndex        =   28
         Top             =   360
         Width           =   9900
         Begin VB.ComboBox name_sub_new 
            Height          =   315
            Left            =   720
            TabIndex        =   53
            Top             =   240
            Width           =   2775
         End
         Begin VB.TextBox vouncher_no_new 
            Height          =   315
            Left            =   5880
            MaxLength       =   15
            TabIndex        =   6
            Top             =   600
            Width           =   1335
         End
         Begin VB.TextBox parmit_new 
            Height          =   315
            Left            =   5880
            MaxLength       =   72
            TabIndex        =   7
            Top             =   1030
            Width           =   1815
         End
         Begin VB.TextBox tx_credit_new 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   7320
            TabIndex        =   43
            Top             =   5760
            Width           =   1815
         End
         Begin VB.TextBox tx_debit_new 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   5520
            TabIndex        =   42
            Top             =   5760
            Width           =   1815
         End
         Begin VB.TextBox name_book_new 
            BackColor       =   &H8000000A&
            Enabled         =   0   'False
            Height          =   315
            Left            =   720
            TabIndex        =   32
            Top             =   600
            Width           =   2775
         End
         Begin VB.TextBox detail_new 
            Height          =   315
            Left            =   1200
            MaxLength       =   99
            TabIndex        =   11
            Top             =   1440
            Width           =   8415
         End
         Begin VB.Frame Frame5 
            Caption         =   "Type"
            Height          =   975
            Left            =   8400
            TabIndex        =   10
            Top             =   120
            Width           =   1335
            Begin VB.OptionButton Option4 
               Caption         =   "CLOSE"
               Height          =   255
               Left            =   120
               TabIndex        =   8
               Top             =   240
               Width           =   855
            End
            Begin VB.OptionButton Option5 
               Caption         =   "ADJUST"
               Height          =   375
               Left            =   120
               TabIndex        =   9
               Top             =   480
               Value           =   -1  'True
               Width           =   975
            End
         End
         Begin VB.CommandButton Esc_new 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   8400
            TabIndex        =   31
            Top             =   6360
            Width           =   1215
         End
         Begin VB.CommandButton save_new 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   375
            Left            =   7080
            TabIndex        =   30
            Top             =   6360
            Width           =   1215
         End
         Begin VB.CheckBox post_cheak_new 
            Caption         =   " I=�ѧ��� Post,��ҧ� = Post"
            Height          =   375
            Left            =   1680
            TabIndex        =   29
            Top             =   1000
            Width           =   2295
         End
         Begin grid_acc.grid_acc1 grid_acc12 
            Height          =   3855
            Left            =   240
            TabIndex        =   33
            Top             =   1800
            Width           =   9375
            _ExtentX        =   16536
            _ExtentY        =   6800
         End
         Begin MSComCtl2.DTPicker dtp_day 
            Height          =   315
            Left            =   5880
            TabIndex        =   44
            Top             =   240
            Width           =   1335
            _ExtentX        =   2355
            _ExtentY        =   556
            _Version        =   393216
            Format          =   54591489
            CurrentDate     =   37485
         End
         Begin VB.Label Label14 
            BackColor       =   &H8000000A&
            Caption         =   "Ἱ�"
            Height          =   255
            Left            =   120
            TabIndex        =   41
            Top             =   240
            Width           =   495
         End
         Begin VB.Label Label15 
            Caption         =   "��ش"
            Height          =   255
            Left            =   240
            TabIndex        =   40
            Top             =   600
            Width           =   375
         End
         Begin VB.Label Label17 
            Caption         =   "͹��ѵ�"
            Height          =   375
            Left            =   4920
            TabIndex        =   39
            Top             =   1080
            Width           =   615
         End
         Begin VB.Label Label19 
            Caption         =   "�ٻẺ���  Post"
            Height          =   255
            Left            =   240
            TabIndex        =   38
            Top             =   1080
            Width           =   1215
         End
         Begin VB.Label Label20 
            Caption         =   "��������´"
            Height          =   375
            Left            =   240
            TabIndex        =   37
            Top             =   1440
            Width           =   975
         End
         Begin VB.Label Label21 
            Caption         =   "Voucher No."
            Height          =   255
            Left            =   4920
            TabIndex        =   36
            Top             =   600
            Width           =   975
         End
         Begin VB.Label Label22 
            Caption         =   "�ѹ���ŧ�ѭ��"
            Height          =   255
            Left            =   4920
            TabIndex        =   35
            Top             =   240
            Width           =   1215
         End
         Begin VB.Label Label9 
            Caption         =   "���"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   12
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Left            =   240
            TabIndex        =   34
            Top             =   5760
            Width           =   1215
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "���"
         Height          =   6975
         Left            =   -74880
         TabIndex        =   13
         Top             =   360
         Width           =   9900
         Begin VB.ComboBox text1 
            Height          =   315
            Left            =   720
            TabIndex        =   54
            Top             =   240
            Width           =   3255
         End
         Begin VB.PictureBox inputpic 
            Appearance      =   0  'Flat
            BackColor       =   &H00FFFFFF&
            ForeColor       =   &H80000008&
            Height          =   420
            Left            =   1440
            ScaleHeight     =   390
            ScaleWidth      =   915
            TabIndex        =   50
            Tag             =   "noprint"
            Top             =   2280
            Visible         =   0   'False
            Width           =   945
            Begin VB.TextBox TMText 
               Appearance      =   0  'Flat
               BorderStyle     =   0  'None
               BeginProperty Font 
                  Name            =   "MS Sans Serif"
                  Size            =   9.75
                  Charset         =   222
                  Weight          =   400
                  Underline       =   0   'False
                  Italic          =   0   'False
                  Strikethrough   =   0   'False
               EndProperty
               Height          =   750
               Left            =   0
               TabIndex        =   51
               ToolTipText     =   "Enter data"
               Top             =   0
               Width           =   960
            End
         End
         Begin VB.CommandButton Esc_edit 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   8400
            TabIndex        =   48
            Top             =   6360
            Width           =   1215
         End
         Begin VB.TextBox Text7 
            Height          =   315
            Left            =   1200
            MaxLength       =   99
            TabIndex        =   5
            Top             =   1440
            Width           =   8415
         End
         Begin VB.TextBox Text8 
            BackColor       =   &H80000004&
            Enabled         =   0   'False
            Height          =   315
            Left            =   5880
            TabIndex        =   19
            Top             =   600
            Width           =   1335
         End
         Begin VB.TextBox tx_credit_edit 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   7320
            TabIndex        =   18
            Top             =   5760
            Width           =   1815
         End
         Begin VB.TextBox tx_debit_edit 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   5520
            TabIndex        =   17
            Top             =   5760
            Width           =   1815
         End
         Begin VB.CommandButton save_edit 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   375
            Left            =   7080
            TabIndex        =   16
            Top             =   6360
            Width           =   1215
         End
         Begin VB.TextBox Text10 
            Height          =   315
            Left            =   5880
            MaxLength       =   72
            TabIndex        =   1
            Top             =   1030
            Width           =   1815
         End
         Begin VB.TextBox Text2 
            BackColor       =   &H80000004&
            Enabled         =   0   'False
            Height          =   315
            Left            =   720
            TabIndex        =   15
            Top             =   600
            Width           =   3255
         End
         Begin VB.CheckBox Check1 
            Caption         =   " I=�ѧ��� Post,��ҧ� = Post"
            Height          =   375
            Left            =   1680
            TabIndex        =   14
            Top             =   1000
            Width           =   2535
         End
         Begin VB.Frame Frame4 
            Caption         =   "Type"
            Height          =   975
            Left            =   8400
            TabIndex        =   4
            Top             =   120
            Width           =   1335
            Begin VB.OptionButton Option1 
               Caption         =   "CLOSE"
               Height          =   255
               Left            =   120
               TabIndex        =   2
               Top             =   240
               Width           =   855
            End
            Begin VB.OptionButton Option2 
               Caption         =   "ADJUST"
               Height          =   375
               Left            =   120
               TabIndex        =   3
               Top             =   480
               Value           =   -1  'True
               Width           =   975
            End
         End
         Begin MSComCtl2.DTPicker DTPicker2 
            Height          =   315
            Left            =   5880
            TabIndex        =   45
            Top             =   240
            Width           =   1335
            _ExtentX        =   2355
            _ExtentY        =   556
            _Version        =   393216
            Format          =   54591489
            CurrentDate     =   37485
         End
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
            Height          =   3615
            Left            =   240
            TabIndex        =   52
            Top             =   1920
            Width           =   9375
            _ExtentX        =   16536
            _ExtentY        =   6376
            _Version        =   393216
            BackColor       =   -2147483624
            Rows            =   99
            Cols            =   4
            FixedCols       =   0
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            _NumberOfBands  =   1
            _Band(0).Cols   =   4
         End
         Begin VB.Label Label1 
            Caption         =   "Ἱ�"
            Height          =   255
            Left            =   240
            TabIndex        =   27
            Top             =   240
            Width           =   495
         End
         Begin VB.Label Label2 
            Caption         =   "��ش"
            Height          =   255
            Left            =   240
            TabIndex        =   26
            Top             =   600
            Width           =   495
         End
         Begin VB.Label Label3 
            Caption         =   "�ѹ���ŧ�ѭ��"
            Height          =   255
            Left            =   4920
            TabIndex        =   25
            Top             =   240
            Width           =   1215
         End
         Begin VB.Label Label4 
            Caption         =   "Voucher No."
            Height          =   255
            Left            =   4920
            TabIndex        =   24
            Top             =   600
            Width           =   975
         End
         Begin VB.Label Label5 
            Caption         =   "��������´"
            Height          =   375
            Left            =   240
            TabIndex        =   23
            Top             =   1440
            Width           =   975
         End
         Begin VB.Label Label6 
            Caption         =   "�ٻẺ���  Post"
            Height          =   255
            Left            =   240
            TabIndex        =   22
            Top             =   1080
            Width           =   1215
         End
         Begin VB.Label Label10 
            Caption         =   "͹��ѵ�"
            Height          =   375
            Left            =   4920
            TabIndex        =   21
            Top             =   1080
            Width           =   615
         End
         Begin VB.Label Label13 
            Caption         =   "���"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   12
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Left            =   240
            TabIndex        =   20
            Top             =   5760
            Width           =   495
         End
      End
      Begin VB.Frame Frame3 
         Caption         =   "��������´"
         Height          =   6975
         Left            =   120
         TabIndex        =   12
         Top             =   360
         Width           =   9900
         Begin VB.CommandButton CmdCommit 
            Caption         =   "�ʴ���¡�����ش������ͧ͢Ἱ�"
            Height          =   335
            Left            =   4200
            TabIndex        =   56
            Top             =   360
            Width           =   2895
         End
         Begin VB.ComboBox ComboDetail 
            Height          =   315
            ItemData        =   "book_credit_sell.frx":0054
            Left            =   840
            List            =   "book_credit_sell.frx":0056
            TabIndex        =   55
            Text            =   "����Թ"
            Top             =   360
            Width           =   3255
         End
         Begin VB.CommandButton Command5 
            Caption         =   "ź��¡��"
            Height          =   375
            Left            =   7080
            TabIndex        =   47
            Top             =   6360
            Width           =   1215
         End
         Begin VB.CommandButton Command6 
            Caption         =   "¡��ԡ��¡��"
            Height          =   375
            Left            =   8400
            TabIndex        =   46
            Top             =   6360
            Width           =   1215
         End
         Begin MSDataGridLib.DataGrid DataGrid1 
            Height          =   5055
            Left            =   360
            TabIndex        =   49
            Top             =   960
            Width           =   8655
            _ExtentX        =   15266
            _ExtentY        =   8916
            _Version        =   393216
            BackColor       =   -2147483624
            HeadLines       =   1
            RowHeight       =   15
            FormatLocked    =   -1  'True
            BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ColumnCount     =   5
            BeginProperty Column00 
               DataField       =   "voucher_id"
               Caption         =   "�Ţ��� voucher"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column01 
               DataField       =   "voucher_date"
               Caption         =   "�ѹ���ŧ�ѭ��"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column02 
               DataField       =   "posted"
               Caption         =   "POSTED"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column03 
               DataField       =   "voucher_type"
               Caption         =   "TYPE"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column04 
               DataField       =   "voucher_detail"
               Caption         =   "��������´"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1033
                  SubFormatType   =   0
               EndProperty
            EndProperty
            SplitCount      =   1
            BeginProperty Split0 
               BeginProperty Column00 
                  ColumnWidth     =   1094.74
               EndProperty
               BeginProperty Column01 
                  ColumnWidth     =   945.071
               EndProperty
               BeginProperty Column02 
                  ColumnWidth     =   750.047
               EndProperty
               BeginProperty Column03 
                  ColumnWidth     =   555.024
               EndProperty
               BeginProperty Column04 
                  ColumnWidth     =   4800.189
               EndProperty
            EndProperty
         End
         Begin VB.Label Label7 
            Caption         =   "Ἱ�"
            Height          =   255
            Left            =   360
            TabIndex        =   57
            Top             =   360
            Width           =   495
         End
      End
   End
End
Attribute VB_Name = "book_credit_sell"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public s_id As String
Public book_code As String
Dim ref As Boolean
Dim a(99, 3) As String
Dim b(99, 2) As Currency
Dim id As String
Dim i As Integer
Dim LastLine As Integer
Dim Init As Boolean
Dim col_number As Integer
Dim point_grid   As Integer
Dim tempgrid As String

Private Sub ComboDetail_SelectItem()
        Call Setgrid
        
        Call cheak_dataenvironment
        acc_data.cn_sub.Open
        acc_data.concurrent_sub
        acc_data.check_sub_name ComboDetail.Text
        If acc_data.rscheck_sub_name.RecordCount > 0 Then
            s_id = acc_data.rscheck_sub_name.Fields(0) ' id Ἱ�
        End If
        'Call cheak_dataenvironment
    
    Call detial_voucher
End Sub

Private Sub CmdCommit_Click()
    Call ComboDetail_SelectItem
End Sub

Private Sub Command5_Click()
Dim tmp_id As String
Dim val As Integer

On Error GoTo ErrorRecordSet
tmp_id = DataGrid1.Text

Call cheak_dataenvironment
acc_data.cn_voucher.Open
acc_data.concurrent_voucher
acc_data.check_voucher tmp_id
If acc_data.rscheck_voucher.RecordCount > 0 Then
   val = MsgBox("�س��㨷���ź voucher �Ţ��� '" & tmp_id & "' ��������� ", vbYesNo, "Warning !")
   If val = 6 Then
      'acc_data.delete_voucher_item tmp_id
      acc_data.delete_voucher tmp_id
      MsgBox "�ӡ��ź��������������ó�", vbOKOnly, "Complete"
    End If
   Call detial_voucher
Else
    MsgBox "�س��������͡������� voucher ���ͷӡ��ź", vbOKOnly, "Warning"
End If
'Call cheak_dataenvironment
'Unload Me
'book_credit_sell.Show

GoTo ExitLine
ErrorRecordSet:
    MsgBox "����բ����� voucher", vbOKOnly + vbCritical, "Warning"
ExitLine:
End Sub

Private Sub Command6_Click()
Unload Me
Unload frmPlan
'select_account.Show
End Sub

Private Sub Esc_edit_Click()
            Call cheak_dataenvironment
             SSTab2.Tab = 0
End Sub

Private Sub Esc_new_Click()
            vouncher_no_new.Text = ""
            parmit_new.Text = ""
            detail_new.Text = ""
            post_cheak_new.Value = 0
            Call cheak_dataenvironment
             SSTab2.Tab = 0
End Sub

Private Sub grid_acc12_RowData(row1 As Integer, id_acc As String, val_debit As Currency, val_credit As Currency)

i = i + 1
            If row1 < i Then
                    a(row1, 1) = i
                    a(row1, 2) = vouncher_no_new.Text
                    a(row1, 3) = id_acc
                    'a(row1, 4) = sub1
                    'a(row1, 5) = group
                    b(row1, 1) = val_debit
                    b(row1, 2) = val_credit
                    
                    i = i - 1
          Else
                    a(i, 1) = i
                    a(i, 2) = vouncher_no_new.Text
                    a(i, 3) = id_acc
                    'a(i, 4) = sub1
                    'a(i, 5) = group
                    b(i, 1) = val_debit
                    b(i, 2) = val_credit
          End If
          

End Sub

Private Sub grid_acc11_sumvalue(value_debit As String, value_credit As String)
tx_debit_edit.Text = value_debit
tx_credit_edit.Text = value_credit
End Sub



'Private Sub balence_Click()
 '       Dim dabit As Double
  '      Dim crebit As Double
   '     Dim tem_number As Double
    '    Dim condition As Integer
     '   Dim count As Integer
        
        'dabit = CDbl(sum_total_dabit)
        'crebit = CDbl(sum_total_credit)
      '  tem_number = dabit - crebit
       ' Select Case tem_number
        '            Case Is > 0
         '                       condition = 1
          '          Case Is < 0
           '                     tem_number = tem_number * -1
            '                    condition = -1
             '       Case Is = 0
                                'condition = 0
         'End Select
         
         'count = 1

        'Do While count < (LastLine - 1)  '��row�ش���·����ҧ�
         '               If Not gridinv.TextMatrix(count, 0) <> "" Then
          '                              Exit Do
           '             End If
            '            count = count + 1
        'Loop
        'count = count - 1
        
        'Select Case condition
         '               Case -1 '������ col dabit
          '                          gridinv.TextMatrix(count, 2) = tem_number
           '             Case 1 '������ col credit
            '                        gridinv.TextMatrix(count, 3) = tem_number
             '           Case 0
            'End Select
       
'End Sub

Private Sub eraser_Click()
If MsgBox("��ҹ��ͧ���ź�������", 305, "�ô�׹�ѹ") = 1 Then
            Dim line As Integer
            Dim col As Integer
            Dim old_row As Integer
            Dim tem_data As String
            
            tem_data = gridinv.TextMatrix(gridinv.row + 1, gridinv.col)
            
            line = LastLine - 1
            old_row = gridinv.row + 1

                    Do While line > old_row
                                        col = 0
                            Do
                                         gridinv.TextMatrix(old_row - 1, col) = gridinv.TextMatrix(old_row, col)
                                                If col = (col_number - 1) Then
                                                        Exit Do
                                                End If
                                         col = col + 1
                            Loop Until col > (col_number - 1)
                            
                            old_row = old_row + 1
                     Loop
                
                TMText.Text = tem_data   '�׹ ��� �����row ��ҧ��ҧ
                gridinv.col = 0 ' set ���˹���������

End If
                                         
End Sub

Private Sub Form_Activate()
gridinv.col = 0

End Sub

Private Sub Form_Initialize()
LastLine = 99
col_number = 4
End Sub

Private Sub Form_Load()
Init = True
ref = True
dtp_day.Value = Date
Setgrid
i = 0
'name_book_new.Text = "��ش�������"
'acc_data.cn_sub.Open
'acc_data.concurrent_sub
'acc_data.cheak_sub s_id
'name_sub_new.Text = acc_data.rscheak_sub.Fields(2)
'acc_data.cn_sub.Close
SSTab2.Tab = 0
 'Call detial_voucher
 Call display_grid
End Sub

Private Sub gridinv_EnterCell()  ' �͹��ԡ����ͧ�

On Error Resume Next

If Init Then
        
        'Exit Sub    'lnit �繤�� true  �ʴ�����ش��÷Ѵ����
Else

        inputpic.Move gridinv.CellLeft - 20 + point_grid
        inputpic.Top = gridinv.CellTop + gridinv.Top - 20
        inputpic.Visible = True

        inputpic.Width = gridinv.CellWidth + 10
        inputpic.Height = gridinv.CellHeight + 20
        TMText.Width = inputpic.Width

End If

TMText.SetFocus
TMText.Text = gridinv.Text
TMText.SelStart = 0
TMText.SelLength = 100
gridinv.TextMatrix(1, 0) = tempgrid
End Sub
Private Sub gridinv_LeaveCell()

On Error Resume Next
Dim tem_number As Double
Dim tem_string As String

'tem_number = Val(TMText.Text)
'tem_string = Str(tem_number)
'If tem_string = " 0" Then
'        tem_string = " "
'End If
    If gridinv.col = 2 Or gridinv.col = 3 Then
            If IsNumeric(TMText.Text) Or (TMText.Text = "") Then
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        TotalSum_credit
                        TotalSum_dabit
                        If gridinv.col = 2 And (0 <> Len(TMText.Text)) Then '�ӡ�á��ⴴ����
                            gridinv.col = gridinv.col + 1
                        End If
            Else
                        MsgBox "�س�������ŷ�����ѡ�û�����", 48, "����͹"
                        gridinv.col = gridinv.col - 1
                        
            End If
    Else
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        TotalSum_credit
                        TotalSum_dabit
    End If
End Sub

Private Sub gridinv_Scroll()

On Error Resume Next
If Init Then Exit Sub
If Not gridinv.RowIsVisible(gridinv.row) Or Not gridinv.ColIsVisible(gridinv.col) Then
inputpic.Visible = False
Else
inputpic.Move gridinv.CellLeft
inputpic.Top = gridinv.CellTop + gridinv.Top
inputpic.Visible = True
End If

End Sub

Private Sub insert_Click()
If gridinv.TextMatrix(LastLine - 1, 0) = "" Then
            Dim line As Integer
            Dim col As Integer
            Dim old_col  As Integer
            line = LastLine - 1

                    Do While line > gridinv.row
                                        col = 0
                            Do
                                         gridinv.TextMatrix(line, col) = gridinv.TextMatrix(line - 1, col)
                                                If col = (col_number - 1) Then
                                                        Exit Do
                                                End If
                                         col = col + 1
                            Loop Until col > (col_number - 1)
                            
                            line = line - 1
                            Loop
                            
                            
                old_col = gridinv.col
                gridinv.col = 0
                Do
                          gridinv.TextMatrix(gridinv.row, gridinv.col) = ""
                          If gridinv.col = (col_number - 1) Then
                                        gridinv.col = old_col  ' �׹��ҵ��˹����
                                        TMText.SetFocus
                                        TMText.Text = gridinv.Text
                                        TMText.SelStart = 0
                                        TMText.SelLength = 100
                                        Exit Do
                          End If
                          gridinv.col = gridinv.col + 1
                Loop Until gridinv.col > (col_number - 1)
                            
Else
            MsgBox "�������ö�ӡ���á��������", 64, "������"
End If
End Sub

Private Sub save_edit_Click()
Dim ap1() As String
Dim bp1() As Currency
Dim mp As Integer
Dim np As Integer
Dim op As Integer
Dim wp As String
Dim z As Integer
Dim z_str As String
Dim type_book1 As String
If tx_debit_edit.Text <> tx_credit_edit.Text Then
   MsgBox "�������ҹ Debit �Ѻ��ҹ Credit �����ҡѹ", vbOKOnly, "ERROR"
Else
    wp = DTPicker2.Value  '�ѹ��͹��
    z = Check1.Value
    If z = 1 Then
       z_str = "P"
    Else
       z_str = "N"
    End If
    If Option1.Value = True Then
                    type_book1 = "CL"
        ElseIf Option2.Value = True Then
                    type_book1 = "AD"
                 'ElseIf Option3.Value = True Then
                  '      type_book1 = "ES"
        End If
   acc_data.cn_voucher.Open
   acc_data.concurrent_voucher
   acc_data.update_voucher z_str, Text10.Text, type_book1, Text7.Text, Text8.Text
   acc_data.delete_voucher_item Text8.Text
   'acc_data.insert_voucher tx_voucher_id.Text, w, txtype_book.Text, txsub.Text, txpermit.Text, txtype.Text, txdetail.Text
   mp = 1 '���Ѻrow � grid
   gridinv.col = 0
  
   Do
      gridinv.row = mp
      wp = gridinv.Text
      mp = mp + 1
   Loop Until wp = ""
   mp = mp - 2 '��Ҩ��Թ�ӹǹrow�2
   op = mp 'keep value m
   ReDim ap1(mp, 3) As String
   ReDim bp1(mp, 2) As Currency '1�� ഺԵ 2���ôԵ
   
   np = 1 '��Ѻ��� metrix
   Do
       ap1(np, 1) = np    '�ӴѺ���  item_id
       ap1(np, 2) = Text8.Text  '���� voucher
       ap1(np, 3) = gridinv.TextMatrix(np, 0)  '���ʺѭ��
       'ap1(np, 4) = gridinv.TextMatrix(np, 4) 'Ἱ�
       'ap1(np, 5) = gridinv.TextMatrix(np, 5) 'G
       
       If gridinv.TextMatrix(np, 2) = "" Then
         gridinv.TextMatrix(np, 2) = "0"
       End If
       If gridinv.TextMatrix(np, 3) = "" Then
          gridinv.TextMatrix(np, 3) = "0"
       End If
       bp1(np, 1) = CCur(gridinv.TextMatrix(np, 2)) 'ഺԵ
       bp1(np, 2) = CCur(gridinv.TextMatrix(np, 3))  '�ôԵ
       
       mp = mp - 1 'Ŵ count loop
       np = np + 1 'row �Ѵ�
   Loop Until mp = 0
   
   mp = op ' count loop
   np = 1
   op = 0
   Do
      acc_data.insert_voucher_item ap1(np, 1), ap1(np, 2), ap1(np, 3), bp1(np, 1), bp1(np, 2)
      np = np + 1
      op = op + 1
      mp = mp - 1
   Loop Until mp = 0
      MsgBox "�ѹ�֡��¡����������ó�ӹǹ '" & op & "' record", vbOKOnly, "Message"
     acc_data.cn_voucher.Close
     SSTab2.Tab = 0
     'Unload Me
     'plan.Show
End If
End Sub

Private Sub TMtext_KeyDown(KeyCode As Integer, Shift As Integer) '�͹��������� textb  ����MOUSE  ��ԡ

Select Case KeyCode
            Case 13
                            gridinv_LeaveCell
                            cheak_enter
                            gridinv_EnterCell
            Case 37
                            gridinv_LeaveCell
                            cheak_left
                            gridinv_EnterCell
            Case 38
                            gridinv_LeaveCell
                            cheak_up
                            gridinv_EnterCell
            Case 39
                            gridinv_LeaveCell
                            cheak_right
                            gridinv_EnterCell
            Case 40
                            gridinv_LeaveCell
                            cheak_down
                            gridinv_EnterCell
 '           Case 113
  '                          balence_Click
   '         Case 114
    '                        insert_Click
     '       Case 115
      '                      eraser_Click
            
            End Select
End Sub

Private Sub cheak_enter()  '��Ǩ�ͺ����ش��÷Ѵ�ѧ�� ��Ǩ�ͺ������ 6 col
Dim str1 As String
Dim ss1 As Integer
ss1 = 1
                If gridinv.col < (col_number - 1) Then
                       If gridinv.col = 0 Then
                           str1 = gridinv.Text
                           acc_data.cn_plan.Open
                           acc_data.concurrent_plan
                           'acc_data.name_acc str1
                           acc_data.name_acc str1
                           If acc_data.rsname_acc.RecordCount = 0 Then
                              MsgBox "���ʺѭ�շ��س��͹���������㹼ѧ�ѭ��", vbOKOnly, "����͹"
                              ss1 = 0
                           Else
                               'acc_data.rsname_acc.Close
                               acc_data.name_accd str1
                               If acc_data.rsname_accd.RecordCount = 0 Then
                                 MsgBox "���ʺѭ�շ��س��͹�����ʡ�����ͧ�ѧ�ѭ��", vbOKOnly, "����͹"
                                 ss1 = 0
                              Else
                                  tempgrid = str1
                                 gridinv.col = gridinv.col + 1
                                 gridinv.Text = acc_data.rsname_acc.Fields(0)
                              End If
                           End If
                           acc_data.cn_plan.Close
                        End If
                        gridinv.col = gridinv.col + ss1
                Else
                        If IsNumeric(gridinv.TextMatrix(gridinv.row, 2)) And IsNumeric(gridinv.TextMatrix(gridinv.row, 3)) Then
                                        MsgBox "�س�������Ũӹǹ�Թ㹪�ͧ �ӹǹ�ԹഺԵ ��� �ӹǹ�Թ�ôԵ ", 48, "����͹"
                                        gridinv.col = 2
                                        Exit Sub
                        End If
                        gridinv.col = 0
                        gridinv.row = gridinv.row + 1
                End If
End Sub
Private Sub cheak_up()  '��Ǩ�ͺ����ش��÷Ѵ���ѧ
                
                If gridinv.row <= 1 Then
                        gridinv.row = 1
                Else
                        gridinv.row = gridinv.row - 1
                End If

End Sub
Private Sub cheak_down()  '��Ǩ�ͺ����ش��÷Ѵ��ҧ�ѧ
                
                If gridinv.row >= (LastLine - 1) Then
                        gridinv.row = (LastLine - 1)
                Else
                         If IsNumeric(gridinv.TextMatrix(gridinv.row, 2)) And IsNumeric(gridinv.TextMatrix(gridinv.row, 3)) Then
                                        MsgBox "�س�������Ũӹǹ�Թ㹪�ͧ �ӹǹ�ԹഺԵ ��� �ӹǹ�Թ�ôԵ ", 48, "����͹"
                                        gridinv.col = 2
                                        Exit Sub
                        End If
                        gridinv.row = gridinv.row + 1
                End If
End Sub
Private Sub cheak_left()  '��Ǩ�ͺ����ش��÷Ѵ����
                
                If gridinv.col > 0 Then
                        gridinv.col = gridinv.col - 1
                Else
                        gridinv.col = col_number - 1
                End If
End Sub
Private Sub cheak_right()  '��Ǩ�ͺ����ش��÷Ѵ���
                If gridinv.col < (col_number - 1) Then
                        gridinv.col = gridinv.col + 1
                Else
                        gridinv.col = 0
                End If
End Sub

Private Sub Setgrid()

Dim i As Integer
point_grid = 230

gridinv.Move point_grid, 1900  'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 1300
gridinv.ColWidth(1) = 4000
gridinv.ColWidth(2) = 1800
gridinv.ColWidth(3) = 1800
'gridinv.ColWidth(4) = 700
'gridinv.ColWidth(5) = 400


gridinv.TextMatrix(0, 0) = "���ʺѭ��"  '���ʺѭ��
gridinv.TextMatrix(0, 1) = "���ͺѭ��"  '���ͺѭ��
gridinv.TextMatrix(0, 2) = "�ӹǹ�ԹഺԵ"   '�ӹǹ�ԹഺԵ
gridinv.TextMatrix(0, 3) = "�ӹǹ�Թ�ôԵ"  ' �ӹǹ�Թ�ôԵ
'gridinv.TextMatrix(0, 4) = "Ἱ�"  ' �ӹǹ�Թ�ôԵ
'gridinv.TextMatrix(0, 5) = "G"  ' G
gridinv.col = 0
LastLine = 99  ' �ʴ���÷Ѵ�ش����

For i = 0 To 3
gridinv.col = i
gridinv.ColAlignment = 7
Next i

gridinv_EnterCell
'Date = Format(Now, "dd/mm/yy")

TotalSum_dabit
TotalSum_credit
TMText.SelStart = 0        '���˹��á�鹢ͧ����ҧ "textbox"
TMText.SelLength = 100  '��˹�100 ����ѡ��
 
Init = False
gridinv.row = 1
gridinv.col = 0
End Sub

Private Sub TotalSum_dabit()

On Error Resume Next

Dim Sum As Double
Dim row As Integer
row = 1
        Do While row < 100
                        Sum = Sum + CDbl(gridinv.TextMatrix(row, 2))
                        row = row + 1
        Loop
tx_debit_edit = Str$(Sum)
End Sub

Private Sub TotalSum_credit()

On Error Resume Next

Dim Sum As Double
Dim row As Integer
row = 1
        Do While row < 100
                    Sum = Sum + CDbl(gridinv.TextMatrix(row, 3))
                    row = row + 1
        Loop
tx_credit_edit = Str$(Sum)
End Sub



Private Sub grid_acc12_sumvalue(value_debit As String, value_credit As String)
    tx_debit_new.Text = value_debit
    tx_credit_new.Text = value_credit


End Sub




Private Sub save_new_Click()
Dim ps As String
Dim j As Integer
Dim type_book As String
'Dim tb As String

If i = 0 Then
     MsgBox "�������¡�����ͷӡ�úѹ�֡", vbOKOnly, "ERROR"
     Call cheak_dataenvironment
     Exit Sub
     
Else

    If tx_debit_new.Text <> tx_credit_new.Text Then ' ���ŧ�ѭ�մ�ҹ Debit �Ѻ��ҹ Credit
    
        MsgBox "�������ҹ Debit �Ѻ��ҹ Credit �����ҡѹ", vbOKOnly, "ERROR"
        
    Else
    
        If post_cheak_new.Value = 1 Then
            ps = "P"  'posted
        Else
           ps = "N" ' not post
        End If
        
        If Option4.Value = True Then
                    type_book = "CL"
        ElseIf Option5.Value = True Then
                    type_book = "AD"
                 'ElseIf Option6.Value = True Then
                  '      type_book = "ES"
        End If
       
        Dim date1 As String
        Dim day As String
        Dim month As String
        Dim year As String
        Dim sr As String
        Dim p1 As Integer
        Dim tp1 As String
        Dim p2 As Integer
        date1 = dtp_day.Value
        p2 = Len(date1)
        sr = "/"
        p1 = 0
        p1 = InStr(date1, sr)
        day = Left$(date1, p1 - 1)
        date1 = Right$(date1, p2 - p1)
        p1 = InStr(date1, sr)
        month = Left$(date1, p1 - 1)
        year = Right$(date1, 4)
        
        
       
       acc_data.cn_voucher.Open
       acc_data.concurrent_voucher
       acc_data.insert_voucher vouncher_no_new.Text, day, month, year, "SD", s_id, ps, parmit_new.Text, type_book, detail_new.Text
       
       j = i
       i = 1
       Do
       acc_data.insert_voucher_item a(i, 1), a(i, 2), a(i, 3), b(i, 1), b(i, 2)
       i = i + 1
       j = j - 1
       Loop Until j = 0
       i = i - 1 '��Ҩ��Թ��1
       MsgBox "�ѹ�֡��¡����������ó�ӹǹ '" & i & "' record", vbOKOnly, "Message"
       Call cheak_dataenvironment
       SSTab2.Tab = 0
       Unload Me
       book_credit_sell.Show
    End If
 End If
 
        
End Sub

Private Sub cheak_dataenvironment()

            If acc_data.cn_voucher.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_voucher.Close
            End If
            If acc_data.cn_sub.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_sub.Close
            End If

End Sub

Private Sub SSTab2_Click(PreviousTab As Integer)
            Call cheak_dataenvironment   '��Ǩ�ͺ����Դ data base �ͧdata environmant
                
            Select Case SSTab2.Tab
                Case 0
                            If ref = False Then
                                Call detial_voucher
                            End If
                            ref = False
                Case 1
                            'name_account1_edit.SetFocus
                            Call clear_grid
                            Call edit_tab
                Case 2
                            'id_account_new.SetFocus
                             
                End Select
                

End Sub

Private Sub edit_tab()
Dim tmp_row As Integer
Dim row_edit As Integer
Dim post_value As Integer
Dim type_value As String
Dim ds As Integer
Dim ms As Integer
Dim ys As Integer
Dim dts1 As String
Dim dts2 As String
Dim dts3 As String
ref = False
Text2.Text = "��ش�������"
If id <> "" Then
        row_edit = 1
        gridinv.row = 1
                Call cheak_dataenvironment
                acc_data.cn_voucher.Open
                acc_data.concurrent_voucher
                acc_data.edit_voucher id
                Text8.Text = acc_data.rsedit_voucher.Fields(0)
                'DTPicker2.Value = acc_data.rsedit_voucher.Fields(1)
                
                ds = acc_data.rsedit_voucher.Fields(1)
                ms = acc_data.rsedit_voucher.Fields(2)
                ys = acc_data.rsedit_voucher.Fields(3)
                dts1 = Str$(ds)
                dts2 = Str$(ms)
                dts3 = Str$(ys)
                dts1 = dts1 + "/" + dts2 + "/" + dts3
                DTPicker2.Value = dts1
                
                Text2.Text = acc_data.rsedit_voucher.Fields(4)
                text1.Text = acc_data.rsedit_voucher.Fields(5)
                If acc_data.rsedit_voucher.Fields(6) = "P" Then
                   post_value = 1
                Else
                   post_value = 0
                End If
                Check1.Value = post_value
                Text10.Text = acc_data.rsedit_voucher.Fields(7)
                type_value = acc_data.rsedit_voucher.Fields(8)
                If type_value = "CL" Then
                   Option1.Value = True
                ElseIf type_value = "AD" Then
                    Option2.Value = True
                 'Else
                  '  Option3.Value = True
                 End If
                 Text7.Text = acc_data.rsedit_voucher.Fields(9)
        
                acc_data.voucher_edit id
                'With acc_data.rsvoucher_edit
                            If acc_data.rsvoucher_edit.RecordCount > 0 Then
                                            tmp_row = acc_data.rsvoucher_edit.RecordCount
                                            Do
                                                        gridinv.TextMatrix(row_edit, 0) = acc_data.rsvoucher_edit.Fields(0)
                                                        If row_edit = 1 Then
                                                           tempgrid = acc_data.rsvoucher_edit.Fields(0)
                                                        End If
                                                        gridinv.TextMatrix(row_edit, 1) = acc_data.rsvoucher_edit.Fields(1)
                                                        If acc_data.rsvoucher_edit.Fields(2) = "0" Then
                                                                gridinv.TextMatrix(row_edit, 2) = ""
                                                        Else
                                                                gridinv.TextMatrix(row_edit, 2) = acc_data.rsvoucher_edit.Fields(2)
                                                        End If
                                                        
                                                        If acc_data.rsvoucher_edit.Fields(3) = "0" Then
                                                                gridinv.TextMatrix(row_edit, 3) = ""
                                                        Else
                                                                gridinv.TextMatrix(row_edit, 3) = acc_data.rsvoucher_edit.Fields(3)
                                                        End If
                                                        
                                                        'gridinv.TextMatrix(row_edit, 4) = acc_data.rsvoucher_edit.Fields(4)
                                                        'gridinv.TextMatrix(row_edit, 5) = acc_data.rsvoucher_edit.Fields(5)
                                                        row_edit = row_edit + 1
                                                        tmp_row = tmp_row - 1
                                                        acc_data.rsvoucher_edit.MoveNext
                                            Loop Until tmp_row = 0
                                            
                            End If
                              If (type_value = "CL") Or (post_value = 1) Then
                               Text8.Enabled = False
                               DTPicker2.Enabled = False
                               Text2.Enabled = False
                               text1.Enabled = False
                               Check1.Enabled = False
                               Text10.Enabled = False
                               Option1.Enabled = False
                               Option2.Enabled = False
                               Text7.Enabled = False
                                gridinv.Enabled = False
                             Else
                                Text8.Enabled = False
                                 DTPicker2.Enabled = False
                                Text2.Enabled = False
                               text1.Enabled = False
                               Check1.Enabled = True
                               Text10.Enabled = True
                               Option1.Enabled = True
                               Option2.Enabled = True
                               Text7.Enabled = True
                                gridinv.Enabled = True
                            End If
                acc_data.cn_voucher.Close
                'End With
                Call Setgrid
                'check type_book
                If Option1.Value = True Then
                    TMText.Visible = False
                    inputpic.Visible = False
                ElseIf Option1.Value = False Then
                    TMText.Visible = True
                    inputpic.Visible = True
                End If
Else
        MsgBox "�������ö�Դ���ͷӡ������� ���ͧ�ҡ�ѧ��������͡���� voucher �ô��Ѻ����͡����voucher ���˹�� ��������´", vbOKOnly, "Warning"
        Call clear_grid
        SSTab2.Tab = 0
 End If
End Sub

Private Sub detial_voucher()
'Dim tb1 As String
'tb1 = "SD"
            Call cheak_dataenvironment
            acc_data.cn_voucher.Open
            acc_data.concurrent_voucher
            acc_data.voucher book_code, s_id
 
                With acc_data.rsvoucher
                        If .RecordCount > 0 Then      '�� record � table �������?
                                 Set DataGrid1.DataSource = acc_data.rsvoucher
                                 text1.Text = ComboDetail.Text
                                 text1.Enabled = False
                                 id = DataGrid1.Text
                        Else: MsgBox "Ἱ�����ѧ�������¡���Դ���", vbInformation + vbOKOnly, "Warning"
                                   DataGrid1.Refresh
                                   id = "" 'DataGrid1.Text = ""
                        End If
                End With
End Sub

Private Sub SSTab2_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
On Error Resume Next
        id = DataGrid1.Text
End Sub

Private Sub clear_grid()
Dim r1 As Integer
Dim c1 As Integer

text1.Text = ""
Text2.Text = ""
Text8.Text = ""
Text10.Text = ""
Text7.Text = ""

r1 = 1
Do
      c1 = 0
     Do
         gridinv.TextMatrix(r1, c1) = ""
         c1 = c1 + 1
    Loop Until c1 = 4
    r1 = r1 + 1
Loop Until r1 = 99

End Sub
      

Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
        If KeyCode = 117 Then
            frmPlan.Show
            frmPlan.Top = 1155
            frmPlan.Left = 11000
        ElseIf KeyCode = 27 Then
            Unload Me
            'select_account.Show
        End If
End Sub

Private Sub SSTab2_KeyUp(KeyCode As Integer, Shift As Integer)
        If KeyCode = 117 Then
            frmPlan.Show
            frmPlan.Top = 1155
            frmPlan.Left = 11000
        ElseIf KeyCode = 27 Then
            Unload Me
            'select_account.Show
        End If
End Sub
Private Sub display_grid()

Dim tmp_row As Integer
Dim row_edit As Integer
row_edit = 1
        Call Setgrid
        Call cheak_dataenvironment
        acc_data.cn_sub.Open
        acc_data.concurrent_sub
        acc_data.Sub
                          If acc_data.rssub.RecordCount > 0 Then
                                            tmp_row = acc_data.rssub.RecordCount
                                            Dim i As Integer
                                            i = 0
                                            Do
                                                        
                                                        'gridinv.TextMatrix(row_edit, 1) = acc_data.rssub.Fields(0)
                                                        name_sub_new.List(i) = acc_data.rssub.Fields(2)
                                                        text1.List(i) = acc_data.rssub.Fields(2)
                                                        ComboDetail.List(i) = acc_data.rssub.Fields(2)
                                                        
                                                        i = i + 1
                                                        'row_edit = row_edit + 1
                                                        tmp_row = tmp_row - 1
                                                        acc_data.rssub.MoveNext
                                            Loop Until tmp_row = 0
                                            
                            End If
                
                              
        Call cheak_dataenvironment

End Sub



