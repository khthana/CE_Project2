VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form item_account 
   Caption         =   "��§ҹ�ѭ����˻�����"
   ClientHeight    =   2790
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3960
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   2790
   ScaleWidth      =   3960
   Begin Crystal.CrystalReport cryrpt1 
      Left            =   120
      Top             =   2040
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      PrintFileLinesPerPage=   60
   End
   Begin VB.CommandButton Command2 
      Caption         =   "¡��ԡ"
      Height          =   495
      Left            =   2160
      TabIndex        =   4
      Top             =   2040
      Width           =   1455
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��ŧ"
      Height          =   495
      Left            =   600
      TabIndex        =   3
      Top             =   2040
      Width           =   1455
   End
   Begin MSComCtl2.DTPicker end_date 
      Height          =   375
      Left            =   1920
      TabIndex        =   2
      Top             =   1440
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      _Version        =   393216
      Format          =   50462721
      CurrentDate     =   37584
   End
   Begin MSComCtl2.DTPicker str_date 
      Height          =   375
      Left            =   1920
      TabIndex        =   1
      Top             =   840
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      _Version        =   393216
      Format          =   50462721
      CurrentDate     =   37584
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   1920
      MaxLength       =   11
      TabIndex        =   0
      Top             =   240
      Width           =   1695
   End
   Begin VB.Label Label4 
      Caption         =   "�ѹ����ش����"
      Height          =   375
      Left            =   240
      TabIndex        =   7
      Top             =   1440
      Width           =   1335
   End
   Begin VB.Label Label3 
      Caption         =   "�ѹ����������"
      Height          =   375
      Left            =   240
      TabIndex        =   6
      Top             =   840
      Width           =   1575
   End
   Begin VB.Label Label1 
      Caption         =   "��͹���ʺѭ��"
      Height          =   375
      Left            =   240
      TabIndex        =   5
      Top             =   240
      Width           =   1215
   End
End
Attribute VB_Name = "item_account"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Command1_Click()
If Text1.Text = "" Then
   Exit Sub
End If
Dim s_date As String
Dim e_date As String
'Dim sub1 As String
Dim id As String
Dim sql As String
Dim detail As String
Dim cn_acc As Connection
Set cn_acc = New Connection

id = Text1.Text
If Not IsNumeric(id) Then
            MsgBox ("�س��͹���ʺѭ�ռԴ��Ҵ")
            Exit Sub
End If
id = id + "%"
'sub1 = Combo1.Text
s_date = str_date.Value
e_date = end_date.Value

        'Dim date1 As String
        'Dim date2 As String
        Dim day1 As String
        Dim month1 As String
        Dim year1 As String
        Dim day2 As String
        Dim month2 As String
        Dim year2 As String
        Dim sr As String
        Dim p1 As Integer
        Dim tp1 As String
        Dim p2 As Integer
        
        'date1 = dtp_day.Value
        p2 = Len(s_date)
        sr = "/"
        p1 = 0
        p1 = InStr(s_date, sr)
        day1 = Left$(s_date, p1 - 1)
        s_date = Right$(s_date, p2 - p1)
        p1 = InStr(s_date, sr)
        month1 = Left$(s_date, p1 - 1)
        year1 = Right$(s_date, 4)

         p2 = Len(e_date)
        sr = "/"
        p1 = 0
        p1 = InStr(e_date, sr)
        day2 = Left$(e_date, p1 - 1)
        e_date = Right$(e_date, p2 - p1)
        p1 = InStr(e_date, sr)
        month2 = Left$(e_date, p1 - 1)
        year2 = Right$(e_date, 4)
        
        Dim intday1 As Integer
        Dim intday2 As Integer
        Dim intmonth1 As Integer
        Dim intmonth2 As Integer
        Dim intyear1 As Integer
        Dim intyear2 As Integer
        
        intday1 = val(day1)
        intday2 = val(day2)
        intmonth1 = val(month1)
        intmonth2 = val(month2)
        intyear1 = val(year1)
        intyear2 = val(year2)
        
If intyear1 <> intyear2 Then
   MsgBox "�������ö����¡�������ҧ����� ���ͧ�ҡ�Ҩ�Դ�����Դ�ͧ��������", vbOKOnly, "ERROR"
   Exit Sub
End If

With cn_acc
        .Provider = "MSDASQL"
        .ConnectionString = "User ID=Administrator; " & _
                                              "Data Source=cn_accounting; "
        .Open
End With

sql = "set transaction isolation level serializable"  '�� concurrentcy control
cn_acc.Execute sql
sql = "drop view item_acc"  ' clear �����Ţͧ�ѭ���¡������������
cn_acc.Execute sql

'sql = "create view item_acc as select voucher_id,voucher_detail,value_debit,value_credit from item_account where sub_name_th='sub1' and id_account like 'id' and voucher_date between 's_date' and 'e_date' "
If month1 = month2 Then
   sql = "create view item_acc as select voucher_id,sub_name_th,voucher_date,voucher_month,voucher_year,voucher_detail,value_debit,value_credit " & _
                  "from item_account " & _
                  "where id_account like '" & id & "' " & _
                 "and voucher_id in ( select voucher_id " & _
                                                        "from item_account " & _
                                                        "where voucher_id in ( select voucher_id " & _
                                                                                                   "from item_account " & _
                                                                                                   "where  voucher_month = " & intmonth1 & " " & _
                                                                                                                  "and voucher_year= " & intyear1 & " " & _
                                                                                                                  "and voucher_date between " & intday1 & " and  " & intday2 & " ))"
Else
         Dim bmonth As Integer
         bmonth = intmonth2 - intmonth1
         If bmonth > 1 Then    '�óշ���͡ report ��ҧ�ѹ������͹
                Dim em2 As Integer
                Dim sm2 As Integer
                em2 = 31
                sm2 = 1
                sql = "create view item_acc as select voucher_id,sub_name_th,voucher_date,voucher_month,voucher_year,voucher_detail,value_debit,value_credit " & _
                          " from item_account " & _
                         "where id_account like '" & id & "'  " & _
                         "and voucher_id in ( select voucher_id " & _
                                                               "from item_account " & _
                                                                "where voucher_id in ( select voucher_id " & _
                                                                                                           "from item_account " & _
                                                                                                               "where voucher_date between " & intday1 & " and " & em2 & " " & _
                                                                                                                          "and voucher_month= " & intmonth1 & " " & _
                                                                                                                          "and voucher_year= " & intyear1 & " ) " & _
                                                                             "or voucher_id in ( select voucher_id " & _
                                                                                                                "from item_account " & _
                                                                                                                "where voucher_date between " & sm2 & " and  " & intday2 & " " & _
                                                                                                                            "and voucher_month= " & intmonth2 & " " & _
                                                                                                                            "and voucher_year=" & intyear2 & " ) " & _
                                                                            "or voucher_id in ( select voucher_id " & _
                                                                                                                "from item_account " & _
                                                                                                                "where voucher_month between " & intmonth1 + 1 & " and " & intmonth2 - 1 & " " & _
                                                                                                                             "and voucher_year=" & intyear2 & " )) "
                                                                                                         
           
           
           Else
                    Dim em1 As Integer
                    Dim sm1 As Integer
                    em1 = 31
                    sm1 = 1
                    sql = "create view item_acc as select voucher_id,sub_name_th,voucher_date,voucher_month,voucher_year,voucher_detail,value_debit,value_credit " & _
                              " from item_account " & _
                             "where id_account like '" & id & "'  " & _
                                            "and voucher_id in ( select voucher_id " & _
                                                                                    "from item_account " & _
                                                                                   "where voucher_id in ( select voucher_id " & _
                                                                                                                               "from item_account " & _
                                                                                                                               "where voucher_date between " & intday1 & " and " & em1 & " " & _
                                                                                                                                            "and voucher_month= " & intmonth1 & " " & _
                                                                                                                                             "and voucher_year= " & intyear1 & " ) " & _
                                                                                                "or voucher_id in ( select voucher_id " & _
                                                                                                                                    "from item_account " & _
                                                                                                                                    "where voucher_date between " & sm1 & " and  " & intday2 & " " & _
                                                                                                                                                "and voucher_month= " & intmonth2 & " " & _
                                                                                                                                                "and voucher_year=" & intyear2 & " )) "
            End If
End If

cn_acc.Execute sql
cn_acc.Close
                                                      
 If acc_data.cn_grandly.State = adStateOpen Then
    acc_data.cn_grandly.Close
 End If
 acc_data.cn_grandly.Open
 acc_data.concurrent_grand
 acc_data.delete_tmpg  'clear data in table tmp_grand
 acc_data.get_grand Text1.Text
 
 If acc_data.rsget_grand.RecordCount > 0 Then
     Dim vd As Double
     Dim vc As Double
     
     intday1 = 1
     intmonth1 = 1
     detail = "�ʹ¡��"
     vd = acc_data.rsget_grand.Fields(2)
     vc = acc_data.rsget_grand.Fields(3)
      acc_data.rsget_grand.Close
      acc_data.insert_grand "XXXXX", "-", intday1, intmonth1, intyear1, detail, vd, vc, 0
Else
      acc_data.rsget_grand.Close
End If

acc_data.insert_acc
id = Text1.Text
sr = Left$(id, 1)

Dim nrow As Integer
Dim vdebit As Double
Dim vcredit As Double
Dim vbalance As Double

acc_data.get_tmpgrand
nrow = acc_data.rsget_tmpgrand.RecordCount


   Do
        If nrow > 0 Then
           vdebit = acc_data.rsget_tmpgrand.Fields(6)
           vcredit = acc_data.rsget_tmpgrand.Fields(7)
           If ((sr = "1") Or (sr = "5")) Then
              vdebit = vdebit - vcredit
              vbalance = vbalance + vdebit
              'acc_data.rsget_tmpgrand.Fields(5) = vbalance
           Else
              vcredit = vcredit - vdebit
              vbalance = vbalance + vcredit
            End If
           acc_data.update_balance vbalance, acc_data.rsget_tmpgrand.Fields(0), acc_data.rsget_tmpgrand.Fields(2), acc_data.rsget_tmpgrand.Fields(3), acc_data.rsget_tmpgrand.Fields(4), acc_data.rsget_tmpgrand.Fields(5)
           nrow = nrow - 1
         
         End If
       If nrow = 0 Then
          acc_data.rsget_tmpgrand.Close
      Else
          acc_data.rsget_tmpgrand.MoveNext
       End If
  Loop While nrow > 0
        acc_data.insert_grand "XXXXX", "-", intday2, intmonth2, intyear2, "�ʹ¡�", 0, 0, vbalance
        acc_data.cn_grandly.Close


cryrpt1.ReportFileName = App.Path & "\reports\item_acc4.rpt"
cryrpt1.WindowShowGroupTree = False
cryrpt1.RetrieveDataFiles
cryrpt1.WindowTitle = "�����źѭ������"
'cryrpt1.Formulas(2) = "sub_name=" & " ' " & Combo1.Text & " ' "
cryrpt1.Formulas(3) = "id_account=" & " ' " & Text1.Text & " ' "

If acc_data.cn_plan.State = adStateOpen Then
    acc_data.cn_plan.Close
End If
acc_data.cn_plan.Open
acc_data.concurrent_plan
acc_data.name_acc Text1.Text
Dim idn As String
idn = acc_data.rsname_acc.Fields(0)
acc_data.cn_plan.Close

cryrpt1.Formulas(4) = "acc_name=" & " ' " & idn & " ' "
cryrpt1.Formulas(5) = "start_date=" & " ' " & str_date.Value & " ' "
cryrpt1.Formulas(6) = "end_date=" & " ' " & end_date.Value & " ' "

cryrpt1.Action = 1
                       
End Sub

Private Sub Command2_Click()
    Unload Me
End Sub

Private Sub Form_Load()
Dim i As Integer
Dim l As Integer
str_date.Value = Date
end_date.Value = Date
'acc_data.cn_sub.Open
'acc_data.concurrent_sub
'acc_data.sub_name
'l = acc_data.rssub_name.RecordCount
'i = 0
'Do
 '   Combo1.List(i) = acc_data.rssub_name.Fields(0)
  '  i = i + 1
   '  l = l - 1
    ' If l > 0 Then
     '     acc_data.rssub_name.MoveNext
    ' End If
'Loop While l > 0
'acc_data.cn_sub.Close

End Sub
