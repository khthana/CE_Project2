VERSION 5.00
Begin VB.Form choose_day 
   Caption         =   "Form1"
   ClientHeight    =   3195
   ClientLeft      =   3915
   ClientTop       =   3045
   ClientWidth     =   4680
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   Begin VB.CommandButton Command2 
      Caption         =   "CANCEL"
      Height          =   375
      Left            =   2400
      TabIndex        =   4
      Top             =   2280
      Width           =   1095
   End
   Begin VB.CommandButton Command1 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   720
      MaskColor       =   &H00E0E0E0&
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   2280
      Width           =   1095
   End
   Begin VB.ComboBox cb_day 
      Height          =   315
      ItemData        =   "choose_day.frx":0000
      Left            =   240
      List            =   "choose_day.frx":0061
      TabIndex        =   2
      Text            =   "���͡�ѹ���"
      Top             =   1080
      Width           =   1095
   End
   Begin VB.ComboBox cb_month 
      Height          =   315
      ItemData        =   "choose_day.frx":00D8
      Left            =   1560
      List            =   "choose_day.frx":0100
      TabIndex        =   1
      Text            =   "���͡��͹"
      Top             =   1080
      Width           =   1215
   End
   Begin VB.TextBox tx_year 
      Height          =   285
      Left            =   3120
      TabIndex        =   0
      Top             =   1080
      Width           =   855
   End
End
Attribute VB_Name = "choose_day"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Unload Me
plan.Show
End Sub

Private Sub Command2_Click()
Unload Me
End Sub
