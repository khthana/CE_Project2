VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form start_account 
   Caption         =   "��͹�ʹ¡��"
   ClientHeight    =   8040
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   9765
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   8040
   ScaleWidth      =   9765
   Begin VB.Frame Frame1 
      Height          =   6375
      Left            =   240
      TabIndex        =   2
      Top             =   840
      Width           =   9255
      Begin VB.PictureBox inputpic 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFFFFF&
         ForeColor       =   &H80000008&
         Height          =   420
         Left            =   1440
         ScaleHeight     =   390
         ScaleWidth      =   915
         TabIndex        =   3
         Tag             =   "noprint"
         Top             =   2280
         Visible         =   0   'False
         Width           =   945
         Begin VB.TextBox TMText 
            Appearance      =   0  'Flat
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   750
            Left            =   0
            TabIndex        =   4
            ToolTipText     =   "Enter data"
            Top             =   -120
            Width           =   960
         End
      End
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   6255
         Left            =   0
         TabIndex        =   6
         Top             =   120
         Width           =   9255
         _ExtentX        =   16325
         _ExtentY        =   11033
         _Version        =   393216
         BackColor       =   -2147483624
         Rows            =   700
         Cols            =   4
         FixedCols       =   0
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         _NumberOfBands  =   1
         _Band(0).Cols   =   4
      End
   End
   Begin VB.CommandButton Command2 
      Caption         =   "¡��ԡ��¡��"
      Height          =   495
      Left            =   8040
      TabIndex        =   1
      Top             =   7320
      Width           =   1455
   End
   Begin VB.CommandButton Command1 
      Caption         =   "�ѹ�֡��¡��"
      Height          =   495
      Left            =   6480
      TabIndex        =   0
      Top             =   7320
      Width           =   1455
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "��͹�ʹ¡��"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   555
      Left            =   3720
      TabIndex        =   5
      Top             =   120
      Width           =   2640
   End
End
Attribute VB_Name = "start_account"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public tempgrid As String
Public col_number As Integer
Dim LastLine As Integer
Dim Init As Boolean
Dim point_grid   As Integer


Private Sub Command1_Click()

Dim ap1() As String
Dim bp1() As Currency
Dim mp As Integer
Dim np As Integer
Dim op As Integer
Dim wp As String
Dim z As Integer
Dim z_str As String
'Dim type_book1 As String
'If tx_debit_edit.Text <> tx_credit_edit.Text Then
 '  MsgBox "�������ҹ Debit �Ѻ��ҹ Credit �����ҡѹ", vbOKOnly, "ERROR"
'Else
 '  wp = DTPicker2.Value  '�ѹ��͹��
  '  z = Check1.Value
   ' If z = 1 Then
    '   z_str = "P"
    'Else
     '  z_str = "N"
    'End If
    'If Option1.Value = True Then
     '               type_book1 = "CL"
      '  ElseIf Option2.Value = True Then
       '             type_book1 = "AD"
'                 ElseIf Option3.Value = True Then
 '                       type_book1 = "ES"
        'End If
   'acc_data.cn_voucher.Open
   'acc_data.concurrent_voucher
   'acc_data.update_voucher z_str, Text10.Text, type_book1, Text7.Text, Text8.Text
   'acc_data.delete_voucher_item Text8.Text
   'acc_data.insert_voucher tx_voucher_id.Text, w, txtype_book.Text, txsub.Text, txpermit.Text, txtype.Text, txdetail.Text
   
   mp = 1 '���Ѻrow � grid
   gridinv.col = 0
  
   Do
      gridinv.row = mp
      wp = gridinv.Text
      mp = mp + 1
   Loop Until wp = ""
   mp = mp - 2 '��Ҩ��Թ�ӹǹrow�2
   op = mp 'keep value m
  ReDim ap1(mp, 1) As String
  ReDim bp1(mp, 2) As Currency '1�� ഺԵ 2���ôԵ
   
   np = 1 '��Ѻ��� metrix
   Do
       
       ap1(np, 1) = gridinv.TextMatrix(np, 0)  '���ʺѭ��
       If gridinv.TextMatrix(np, 2) = "" Then
         gridinv.TextMatrix(np, 2) = "0"
       End If
       If gridinv.TextMatrix(np, 3) = "" Then
          gridinv.TextMatrix(np, 3) = "0"
       End If
       bp1(np, 1) = CCur(gridinv.TextMatrix(np, 2)) 'ഺԵ
       bp1(np, 2) = CCur(gridinv.TextMatrix(np, 3))  '�ôԵ
       
       mp = mp - 1 'Ŵ count loop
       np = np + 1 'row �Ѵ�
   Loop Until mp = 0
   
   mp = op ' count loop
   np = 1
   op = 0
   acc_data.cn_grandly.Open
   Do
       acc_data.update_grandl bp1(np, 1), bp1(np, 2), ap1(np, 1)
      'acc_data.insert_voucher_item ap1(np, 1), ap1(np, 2), ap1(np, 3), bp1(np, 1), bp1(np, 2)
      np = np + 1
      op = op + 1
      mp = mp - 1
   Loop Until mp = 0
    '  MsgBox "�ѹ�֡��¡����������ó�ӹǹ '" & op & "' record", vbOKOnly, "Message"
     acc_data.cn_grandly.Close
   '  SSTab2.Tab = 0
     'Unload Me
     'plan.Show
'End If
Unload Me
windows_account.Show
End Sub

Private Sub Command2_Click()
Unload Me
'navigator.Show
End Sub

Private Sub Form_Initialize()
LastLine = 700
col_number = 4
End Sub

Private Sub Form_Load()
Setgrid
edit
End Sub


Private Sub gridinv_EnterCell()  ' �͹��ԡ����ͧ�

On Error Resume Next

If Init Then
        
        'Exit Sub    'lnit �繤�� true  �ʴ�����ش��÷Ѵ����
Else

        inputpic.Move gridinv.CellLeft - 20 + point_grid
        inputpic.Top = gridinv.CellTop + gridinv.Top - 20
        inputpic.Visible = True

        inputpic.Width = gridinv.CellWidth + 10
        inputpic.Height = gridinv.CellHeight + 20
        TMText.Width = inputpic.Width

End If

TMText.SetFocus
TMText.Text = gridinv.Text
TMText.SelStart = 0
TMText.SelLength = 100
gridinv.TextMatrix(1, 0) = tempgrid
End Sub
Private Sub gridinv_LeaveCell()

On Error Resume Next
Dim tem_number As Double
Dim tem_string As String

tem_number = val(TMText.Text)
tem_string = Str(tem_number)
If tem_string = " 0" Then
        tem_string = " "
End If
    If gridinv.col = 2 Or gridinv.col = 3 Then
            If IsNumeric(TMText.Text) Or (TMText.Text = "") Then
                        gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
                        'TotalSum_credit
                        'TotalSum_dabit
                        If gridinv.col = 2 And (0 <> Len(TMText.Text)) Then '�ӡ�á��ⴴ����
                            gridinv.col = gridinv.col + 1
                        End If
            Else
                        MsgBox "�س�������ŷ�����ѡ�û�����", 48, "����͹"
                        gridinv.col = gridinv.col - 1
                        
            End If
    'Else
     '                gridinv.Text = TMText.Text ' ��ǹ���зӡ����Ҥ��ŧ� flexgrid
      '                  TotalSum_credit
       '                 TotalSum_dabit
    End If
End Sub

Private Sub gridinv_Scroll()

On Error Resume Next
If Init Then Exit Sub
If Not gridinv.RowIsVisible(gridinv.row) Or Not gridinv.ColIsVisible(gridinv.col) Then
inputpic.Visible = False
Else
inputpic.Move gridinv.CellLeft
inputpic.Top = gridinv.CellTop + gridinv.Top
inputpic.Visible = True
End If

End Sub

Private Sub insert_Click()
If gridinv.TextMatrix(LastLine - 1, 0) = "" Then
            Dim line As Integer
            Dim col As Integer
            Dim old_col  As Integer
            line = LastLine - 1

                    Do While line > gridinv.row
                                        col = 0
                            Do
                                         gridinv.TextMatrix(line, col) = gridinv.TextMatrix(line - 1, col)
                                                If col = (col_number - 1) Then
                                                        Exit Do
                                                End If
                                         col = col + 1
                            Loop Until col > (col_number - 1)
                            
                            line = line - 1
                            Loop
                            
                            
                old_col = gridinv.col
                gridinv.col = 0
                Do
                          gridinv.TextMatrix(gridinv.row, gridinv.col) = ""
                          If gridinv.col = (col_number - 1) Then
                                        gridinv.col = old_col  ' �׹��ҵ��˹����
                                        TMText.SetFocus
                                        TMText.Text = gridinv.Text
                                        TMText.SelStart = 0
                                        TMText.SelLength = 100
                                        Exit Do
                          End If
                          gridinv.col = gridinv.col + 1
                Loop Until gridinv.col > (col_number - 1)
                            
Else
            MsgBox "�������ö�ӡ���á��������", 64, "������"
End If
End Sub
Private Sub TMtext_KeyDown(KeyCode As Integer, Shift As Integer) '�͹��������� textb  ����MOUSE  ��ԡ

Select Case KeyCode
            Case 13
                            gridinv_LeaveCell
                            cheak_enter
                            gridinv_EnterCell
            Case 37
                            gridinv_LeaveCell
                            cheak_left
                            gridinv_EnterCell
            Case 38
                            gridinv_LeaveCell
                            cheak_up
                            gridinv_EnterCell
            Case 39
                            gridinv_LeaveCell
                            cheak_right
                            gridinv_EnterCell
            Case 40
                            gridinv_LeaveCell
                            cheak_down
                            gridinv_EnterCell
            Case 113
                            'balence_Click
            Case 114
                            'insert_Click
            Case 115
                            'eraser_Click
            
            End Select
End Sub

Private Sub cheak_enter()  '��Ǩ�ͺ����ش��÷Ѵ�ѧ�� ��Ǩ�ͺ������ 6 col
Dim str1 As String
Dim ss1 As Integer
ss1 = 1
                If gridinv.col < (col_number - 1) Then
                       'If gridinv.col = 0 Then
                        '   str1 = gridinv.Text
                         '  acc_data.cn_plan.Open
                          ' acc_data.concurrent_plan
                           'acc_data.name_acc str1
                           'acc_data.name_acc str1
                        '   If acc_data.rsname_acc.RecordCount = 0 Then
                         '     MsgBox "���ʺѭ�շ��س��͹���������㹼ѧ�ѭ��", vbOKOnly, "����͹"
                          '    ss1 = 0
                           'Else
                               'acc_data.rsname_acc.Close
                            '   acc_data.name_accd str1
                              ' If acc_data.rsname_accd.RecordCount = 0 Then
                             '    MsgBox "���ʺѭ�շ��س��͹�����ʡ�����ͧ�ѧ�ѭ��", vbOKOnly, "����͹"
                              '   ss1 = 0
                             ' Else
                              'tempgrid = str1
                             ' gridinv.col = gridinv.col + 1
                            '  gridinv.Text = acc_data.rsname_acc.Fields(0)
                           '  End If
                          'End If
                         '  acc_data.cn_plan.Close
                        'End If
                       gridinv.col = gridinv.col + 1
                Else
                        If IsNumeric(gridinv.TextMatrix(gridinv.row, 2)) And IsNumeric(gridinv.TextMatrix(gridinv.row, 3)) Then
                                        MsgBox "�س�������Ũӹǹ�Թ㹪�ͧ �ӹǹ�ԹഺԵ ��� �ӹǹ�Թ�ôԵ ", 48, "����͹"
                                        gridinv.col = 2
                                        Exit Sub
                        End If
                        gridinv.col = 2
                        gridinv.row = gridinv.row + 1
                End If
End Sub
Private Sub cheak_up()  '��Ǩ�ͺ����ش��÷Ѵ���ѧ
                
                If gridinv.row <= 1 Then
                        gridinv.row = 1
                Else
                        gridinv.row = gridinv.row - 1
                End If

End Sub
Private Sub cheak_down()  '��Ǩ�ͺ����ش��÷Ѵ��ҧ�ѧ
                
                If gridinv.row >= (LastLine - 1) Then
                        gridinv.row = (LastLine - 1)
                Else
                         If IsNumeric(gridinv.TextMatrix(gridinv.row, 2)) And IsNumeric(gridinv.TextMatrix(gridinv.row, 3)) Then
                                        MsgBox "�س�������Ũӹǹ�Թ㹪�ͧ �ӹǹ�ԹഺԵ ��� �ӹǹ�Թ�ôԵ ", 48, "����͹"
                                        gridinv.col = 2
                                        Exit Sub
                        End If
                        gridinv.row = gridinv.row + 1
                End If
End Sub
Private Sub cheak_left()  '��Ǩ�ͺ����ش��÷Ѵ����
                
                If gridinv.col > 2 Then
                        gridinv.col = gridinv.col - 1
                Else
                        gridinv.col = col_number - 1
                End If
End Sub
Private Sub cheak_right()  '��Ǩ�ͺ����ش��÷Ѵ���
                If gridinv.col < (col_number - 1) Then
                        gridinv.col = gridinv.col + 1
                Else
                        gridinv.col = 2
                End If
End Sub

Private Sub Setgrid()

Dim i As Integer
point_grid = 0

gridinv.Move point_grid, 100 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 1300
gridinv.ColWidth(1) = 4000
gridinv.ColWidth(2) = 1800
gridinv.ColWidth(3) = 1800
'gridinv.ColWidth(4) = 700
'gridinv.ColWidth(5) = 400


gridinv.TextMatrix(0, 0) = "���ʺѭ��"  '���ʺѭ��
gridinv.TextMatrix(0, 1) = "���ͺѭ��"  '���ͺѭ��
gridinv.TextMatrix(0, 2) = "�ӹǹ�ԹഺԵ"   '�ӹǹ�ԹഺԵ
gridinv.TextMatrix(0, 3) = "�ӹǹ�Թ�ôԵ"  ' �ӹǹ�Թ�ôԵ
'gridinv.TextMatrix(0, 4) = "Ἱ�"  ' �ӹǹ�Թ�ôԵ
'gridinv.TextMatrix(0, 5) = "G"  ' G
gridinv.col = 0
LastLine = 700  ' �ʴ���÷Ѵ�ش����

For i = 0 To 3
gridinv.col = i
gridinv.ColAlignment = 7
Next i

gridinv_EnterCell
'Date = Format(Now, "dd/mm/yy")

'TotalSum_dabit
'TotalSum_credit
TMText.SelStart = 0        '���˹��á�鹢ͧ����ҧ "textbox"
TMText.SelLength = 100  '��˹�100 ����ѡ��
 gridinv.TextMatrix(1, 0) = tempgrid
Init = False
gridinv.row = 1
gridinv.col = 0
End Sub
Private Sub clear_grid()
Dim r1 As Integer
Dim c1 As Integer
r1 = 1
Do
      c1 = 0
     Do
         gridinv.TextMatrix(r1, c1) = ""
         c1 = c1 + 1
    Loop Until c1 = 4
    r1 = r1 + 1
Loop Until r1 = 700

End Sub

Private Sub edit()
Dim tmp_row As Integer
Dim row_edit As Integer
Dim post_value As Integer
Dim type_value As String




        row_edit = 1
        gridinv.row = 1
                 'Call cheak_dataenvironment
                acc_data.cn_grandly.Open
                acc_data.show_data
                'acc_data.concurrent_voucher
                'acc_data.edit_voucher id
                'acc_data.voucher_edit id
                'With acc_data.rsvoucher_edit
                            If acc_data.rsshow_data.RecordCount > 0 Then
                                            tmp_row = acc_data.rsshow_data.RecordCount
                                            Do
                                                        gridinv.TextMatrix(row_edit, 0) = acc_data.rsshow_data.Fields(0)
                                                        If row_edit = 1 Then
                                                           tempgrid = acc_data.rsshow_data.Fields(0)
                                                        End If
                                                        gridinv.TextMatrix(row_edit, 1) = acc_data.rsshow_data.Fields(1)
                                                        If acc_data.rsshow_data.Fields(2) = "0" Then
                                                                gridinv.TextMatrix(row_edit, 2) = ""
                                                        Else
                                                                gridinv.TextMatrix(row_edit, 2) = acc_data.rsshow_data.Fields(2)
                                                        End If
                                                        
                                                        If acc_data.rsshow_data.Fields(3) = "0" Then
                                                                gridinv.TextMatrix(row_edit, 3) = ""
                                                        Else
                                                                gridinv.TextMatrix(row_edit, 3) = acc_data.rsshow_data.Fields(3)
                                                        End If
                                                        
                                                        'gridinv.TextMatrix(row_edit, 4) = acc_data.rsvoucher_edit.Fields(4)
                                                        'gridinv.TextMatrix(row_edit, 5) = acc_data.rsvoucher_edit.Fields(5)
                                                        row_edit = row_edit + 1
                                                        tmp_row = tmp_row - 1
                                                        acc_data.rsshow_data.MoveNext
                                            Loop Until tmp_row = 0
                                            
                            End If
                             gridinv.TextMatrix(1, 0) = tempgrid
                            acc_data.cn_grandly.Close
                'End With
                Call Setgrid
'Else
'        MsgBox "�������ö�Դ���ͷӡ������� ���ͧ�ҡ�ѧ��������͡���� voucher �ô��Ѻ����͡����voucher ���˹�� ��������´", vbOKOnly, "ERROR"
' End If
End Sub

