VERSION 5.00
Begin VB.Form windows_account 
   BackColor       =   &H00FFFFFF&
   Caption         =   "���١�÷ӧҹ"
   ClientHeight    =   8025
   ClientLeft      =   2175
   ClientTop       =   1500
   ClientWidth     =   7785
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MDIChild        =   -1  'True
   ScaleHeight     =   8025
   ScaleMode       =   0  'User
   ScaleWidth      =   7785
   Begin VB.PictureBox Picture4 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   1815
      Left            =   120
      Picture         =   "windows_account.frx":0000
      ScaleHeight     =   1815
      ScaleWidth      =   2325
      TabIndex        =   6
      Top             =   6000
      Width           =   2325
   End
   Begin VB.PictureBox Picture3 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   1545
      Left            =   240
      Picture         =   "windows_account.frx":1418
      ScaleHeight     =   1545
      ScaleWidth      =   2115
      TabIndex        =   5
      Top             =   4200
      Width           =   2115
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   1815
      Left            =   120
      Picture         =   "windows_account.frx":2A8F
      ScaleHeight     =   1815
      ScaleWidth      =   2325
      TabIndex        =   3
      Top             =   120
      Width           =   2325
   End
   Begin VB.PictureBox Picture2 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   1545
      Left            =   240
      Picture         =   "windows_account.frx":3EA7
      ScaleHeight     =   1545
      ScaleWidth      =   2115
      TabIndex        =   2
      Top             =   2280
      Width           =   2115
   End
   Begin VB.Label Label4 
      BackColor       =   &H00FFFFFF&
      Caption         =   "��§ҹ�к��ѭ��"
      BeginProperty Font 
         Name            =   "JasmineUPC"
         Size            =   36
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   855
      Left            =   2760
      TabIndex        =   7
      Top             =   6480
      Width           =   3975
   End
   Begin VB.Label Label3 
      BackColor       =   &H8000000E&
      Caption         =   "�������짺����Թ"
      BeginProperty Font 
         Name            =   "JasmineUPC"
         Size            =   36
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   975
      Left            =   2760
      TabIndex        =   4
      Top             =   4440
      Width           =   4095
   End
   Begin VB.Label Label2 
      BackColor       =   &H00FFFFFF&
      Caption         =   "��������������к��ѭ��"
      BeginProperty Font 
         Name            =   "JasmineUPC"
         Size            =   36
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   855
      Left            =   2760
      TabIndex        =   1
      Top             =   600
      Width           =   4935
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFFF&
      Caption         =   "ŧ��ش����ѹ"
      BeginProperty Font 
         Name            =   "JasmineUPC"
         Size            =   36
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FF0000&
      Height          =   855
      Left            =   2760
      TabIndex        =   0
      Top             =   2520
      Width           =   3375
   End
End
Attribute VB_Name = "windows_account"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    windows_account.Top = 1155
    windows_account.Left = 3800
    windows_account.Height = 8430
    windows_account.Width = 7905
End Sub

Private Sub Label1_Click()
Unload Me
select_account.Show
End Sub

Private Sub Label2_Click()
Unload Me
 navigator.Show
End Sub

Private Sub Label3_Click()
    Unload Me
    Analyse.Show
End Sub

Private Sub Label4_Click()
    Unload Me
    Report.Show
End Sub

Private Sub Picture1_Click()
Unload Me
 navigator.Show
End Sub

Private Sub Picture2_Click()
Unload Me
select_branch.Show
End Sub

Private Sub Picture3_Click()
    Unload Me
    Analyse.Show
End Sub

Private Sub Picture4_Click()
    Unload Me
    Report.Show
End Sub
