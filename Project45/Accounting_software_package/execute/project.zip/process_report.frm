VERSION 5.00
Begin VB.Form process_report 
   Caption         =   "�����żŢ���������Ѻ Report"
   ClientHeight    =   2640
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4110
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   2640
   ScaleWidth      =   4110
   Begin VB.CommandButton CmdESC 
      Caption         =   "¡��ԡ��¡��"
      Height          =   495
      Left            =   1200
      TabIndex        =   3
      Top             =   1920
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   2640
      MaxLength       =   4
      TabIndex        =   1
      Top             =   240
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Caption         =   "�����ż�"
      Height          =   495
      Left            =   1200
      TabIndex        =   0
      Top             =   1320
      Width           =   1575
   End
   Begin VB.Label Label1 
      Caption         =   "��͹�շ���ͧ��û����ż�"
      ForeColor       =   &H000000FF&
      Height          =   375
      Left            =   360
      TabIndex        =   2
      Top             =   360
      Width           =   1815
   End
End
Attribute VB_Name = "process_report"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdESC_Click()
    Unload Me
    'navigator.Show
End Sub

Private Sub Command1_Click()
If Text1.Text = "" Then
    Exit Sub
End If
If Not IsNumeric(Text1.Text) Then
            MsgBox ("�س��͹�ռԴ��Ҵ")
            Exit Sub
End If

Dim id_acc As String
Dim id_g As String
Dim level_a As String
Dim tmp1 As String
Dim tmp2 As String
Dim debit As Currency
Dim credit As Currency
Dim rc As Integer
Dim l1 As Integer
Dim i As Integer
Dim j As Integer
Dim year1 As String

acc_data.create_report.Open
acc_data.concurrent_report
acc_data.delete_sum_g
acc_data.delete_sum_d
year1 = Text1.Text
acc_data.sum_item year1
rc = acc_data.rssum_item.RecordCount
If rc > 0 Then
   Do
         id_acc = acc_data.rssum_item.Fields(0)
         tmp1 = id_acc
         i = Len(tmp1)
         i = i - 1
         j = 0
         Do
             tmp2 = Left$(tmp1, i)
             Call check_id_close
             acc_data.check_id tmp2
             If acc_data.rscheck_id.RecordCount > 0 Then
                 j = 1
             Else
                tmp1 = tmp2
                i = i - 1
            End If
        Loop Until j = 1
        id_g = tmp2
        level_a = acc_data.rssum_item.Fields(1)
        debit = acc_data.rssum_item.Fields(2)
        credit = acc_data.rssum_item.Fields(3)
        acc_data.insert_sum_item id_acc, id_g, level_a, debit, credit
        rc = rc - 1
        If rc > 0 Then
           acc_data.rssum_item.MoveNext
        End If
 Loop Until rc = 0
 
 acc_data.rssum_item.Close
 ' prepare summary plan group
 acc_data.plan_group
 rc = acc_data.rsplan_group.RecordCount
 If rc > 0 Then
     debit = 0
     credit = 0
     Do
           id_acc = acc_data.rsplan_group.Fields(0)
           tmp1 = id_acc
           i = Len(tmp1)
           i = i - 1
           j = 0
           Do
                 If i = 0 Then
                    j = 1
                    tmp2 = "0"
                 Else
                    tmp2 = Left$(tmp1, i)
                    Call check_id_close
                    acc_data.check_id tmp2
                     If acc_data.rscheck_id.RecordCount > 0 Then
                         j = 1
                     Else
                         tmp1 = tmp2
                         i = i - 1
                      End If
                   End If
            Loop Until j = 1
                 id_g = tmp2
                 level_a = acc_data.rsplan_group.Fields(1)
                 acc_data.insert_sum_group id_acc, id_g, level_a, debit, credit
                 rc = rc - 1
                 If rc > 0 Then
                     acc_data.rsplan_group.MoveNext
                 End If
                 Loop Until rc = 0
                 acc_data.rsplan_group.Close
                 'acc_data.check_level   'check level to begin process
                 'level_a = acc_data.rscheck_level.Fields(0)
                 'acc_data.rscheck_level.Close
                  'Call sum_group_d_close
                 acc_data.sum_group_d
                 rc = acc_data.rssum_group_d.RecordCount
                 If rc > 0 Then
                    Do
                         id_acc = acc_data.rssum_group_d.Fields(0)
                         debit = acc_data.rssum_group_d.Fields(1)
                         credit = acc_data.rssum_group_d.Fields(2)
                         acc_data.update_sum_group debit, credit, id_acc
                         rc = rc - 1
                         If rc > 0 Then
                            acc_data.rssum_group_d.MoveNext
                         End If
                     Loop Until rc = 0
                 End If
                 acc_data.rssum_group_d.Close
                 
                 acc_data.check_level   'check level to begin process
                 level_a = acc_data.rscheck_level.Fields(0)
                 acc_data.rscheck_level.Close
                 Do
                      acc_data.check_data_g level_a
                      rc = acc_data.rscheck_data_g.RecordCount
                      acc_data.rscheck_data_g.Close
                      If rc > 0 Then
                        Call sum_group_g_close
                         acc_data.sum_group_g level_a
                         i = acc_data.rssum_group_g.RecordCount
                         If i > 0 Then
                              Do
                                 id_acc = acc_data.rssum_group_g.Fields(0)
                                 debit = acc_data.rssum_group_g.Fields(1)
                                 credit = acc_data.rssum_group_g.Fields(2)
                                 acc_data.update_sum_group debit, credit, id_acc
                                 i = i - 1
                                 If i > 0 Then
                                    acc_data.rssum_group_g.MoveNext
                                 End If
                             Loop Until i = 0
                          End If
                        End If
                         l1 = val(level_a)
                         l1 = l1 - 1
                         level_a = Str$(l1)
                         level_a = LTrim$(level_a)
                 Loop Until l1 = 0
       End If
End If
'End If

acc_data.create_report.Close
MsgBox "���������������Ѻ�͡ report ���º��������", vbOKOnly, "Complete ! "

Dim vdebit1 As Double
Dim vdebit2 As Double
Dim vcredit1 As Double
Dim vcredit2 As Double

acc_data.cn_grandly.Open
acc_data.concurrent_grand
acc_data.delete_gthis  ' clear data in table grandthis_year
acc_data.insert_thisy '�Ӥ���͡¡�������ҧ this year
acc_data.get_sumd
rc = acc_data.rsget_sumd.RecordCount

Do
      If rc > 0 Then
          id_acc = acc_data.rsget_sumd.Fields(0)
          vdebit1 = acc_data.rsget_sumd.Fields(3)
          vcredit1 = acc_data.rsget_sumd.Fields(4)
          id_g = Left$(id_acc, 1)
          If ((id_g = "1") Or (id_g = "5")) Then
              vdebit1 = vdebit1 - vcredit1
              acc_data.get_lastyear id_acc
              vdebit2 = acc_data.rsget_lastyear.Fields(1)
              acc_data.rsget_lastyear.Close
              vdebit1 = vdebit1 + vdebit2
              acc_data.update_thisy vdebit1, 0, id_acc
               
        Else
               vcredit1 = vcredit1 - vdebit1
               acc_data.get_lastyear id_acc
               vcredit2 = acc_data.rsget_lastyear.Fields(2)
               acc_data.rsget_lastyear.Close
               vcredit1 = vcredit1 + vcredit2
               acc_data.update_thisy 0, vcredit1, id_acc
               
        End If
        rc = rc - 1
        If rc > 0 Then
           acc_data.rsget_sumd.MoveNext
        End If
    End If
Loop Until rc = 0


acc_data.clear_thisy 'clear ������ 0
acc_data.cn_grandly.Close




Unload Me
'windows_account.Show

End Sub
Private Sub check_id_close()

If acc_data.rscheck_id.State = adStateOpen Then
    acc_data.rscheck_id.Close
End If

End Sub
Private Sub sum_group_d_close()

If acc_data.rssum_group_d.State = adStateOpen Then
   acc_data.rssum_group_d.Close
End If

End Sub

Private Sub sum_group_g_close()

If acc_data.rssum_group_g.State = adStateOpen Then
    acc_data.rssum_group_g.Close
End If

End Sub


Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = 27 Then
        Unload Me
        navigator.Show
    End If
End Sub
