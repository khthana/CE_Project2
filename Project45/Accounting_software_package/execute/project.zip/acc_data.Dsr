VERSION 5.00
Begin {C0E45035-5775-11D0-B388-00A0C9055D8E} acc_data 
   ClientHeight    =   7500
   ClientLeft      =   2910
   ClientTop       =   2400
   ClientWidth     =   7245
   _ExtentX        =   12779
   _ExtentY        =   13229
   FolderFlags     =   5
   TypeLibGuid     =   "{EDE2E9F6-DC29-4AAC-99D4-C5F4EA32B88F}"
   TypeInfoGuid    =   "{322CD257-50F2-4E39-8746-93582E21CD56}"
   TypeInfoCookie  =   0
   Version         =   4
   NumConnections  =   7
   BeginProperty Connection1 
      ConnectionName  =   "cn_plan"
      ConnDispId      =   1001
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;User ID=Administrator;Data Source=cn_accounting;Initial Catalog=accounting_db"
      Expanded        =   -1  'True
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   BeginProperty Connection2 
      ConnectionName  =   "cn_voucher"
      ConnDispId      =   1056
      SourceOfData    =   3
      ConnectionSource=   $"acc_data.dsx":0000
      Expanded        =   -1  'True
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   BeginProperty Connection3 
      ConnectionName  =   "cn_company"
      ConnDispId      =   1123
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;User ID=Administrator;Data Source=cn_accounting;Initial Catalog=accounting_db"
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   BeginProperty Connection4 
      ConnectionName  =   "cn_sub"
      ConnDispId      =   1132
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;User ID=Administrator;Data Source=cn_accounting;Initial Catalog=accounting_db"
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   BeginProperty Connection5 
      ConnectionName  =   "create_report"
      ConnDispId      =   1228
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;User ID=Administrator;Data Source=cn_accounting;Initial Catalog=accounting_db"
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   BeginProperty Connection6 
      ConnectionName  =   "cn_grandly"
      ConnDispId      =   1568
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;User ID=Adiministrator;Data Source=cn_accounting;Initial Catalog=accounting_db"
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   BeginProperty Connection7 
      ConnectionName  =   "cn_close_acc"
      ConnDispId      =   1863
      SourceOfData    =   3
      ConnectionSource=   "Provider=MSDASQL.1;Persist Security Info=False;User ID=Administrator;Data Source=cn_accounting;Initial Catalog=accounting_db"
      IsSQL           =   -1  'True
      QuoteChar       =   34
      SeparatorChar   =   46
   EndProperty
   NumRecordsets   =   93
   BeginProperty Recordset1 
      CommandName     =   "plan"
      CommDispId      =   1020
      RsDispId        =   1036
      CommandText     =   "select id_account,name_account,type_account from plan_account order by id_account"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   3
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset2 
      CommandName     =   "insert_account"
      CommDispId      =   1024
      RsDispId        =   -1
      CommandText     =   "insert into  plan_account  values(?,?,?,?,?,?)"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   6
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "id_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         UserName        =   "name_acount"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   72
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         UserName        =   "name_account2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   72
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         UserName        =   "type_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         UserName        =   "group_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   36
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         UserName        =   "leval_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset3 
      CommandName     =   "del_id"
      CommDispId      =   1028
      RsDispId        =   -1
      CommandText     =   "delete  from  plan_account  where id_account = ?"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "id"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset4 
      CommandName     =   "update_account"
      CommDispId      =   1034
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0093
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   7
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   72
         Scale           =   0
         Size            =   72
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   72
         Scale           =   0
         Size            =   72
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   1
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   36
         Scale           =   0
         Size            =   36
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   2
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset5 
      CommandName     =   "chk_repeat"
      CommDispId      =   1040
      RsDispId        =   1043
      CommandText     =   "select * from plan_account where id_account=?"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "id"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset6 
      CommandName     =   "plan_all"
      CommDispId      =   1044
      RsDispId        =   1049
      CommandText     =   "select * from plan_account order by id_account"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset7 
      CommandName     =   "name_acc"
      CommDispId      =   1050
      RsDispId        =   1344
      CommandText     =   "select name_account from plan_account where id_account=?"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset8 
      CommandName     =   "voucher"
      CommDispId      =   1072
      RsDispId        =   1508
      CommandText     =   $"acc_data.dsx":0125
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   7
      BeginProperty Field1 
         Precision       =   0
         Size            =   15
         Scale           =   0
         Type            =   200
         Name            =   "voucher_id"
         Caption         =   "voucher_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   3
         Size            =   1
         Scale           =   0
         Type            =   17
         Name            =   "voucher_date"
         Caption         =   "voucher_date"
      EndProperty
      BeginProperty Field3 
         Precision       =   3
         Size            =   1
         Scale           =   0
         Type            =   17
         Name            =   "voucher_month"
         Caption         =   "voucher_month"
      EndProperty
      BeginProperty Field4 
         Precision       =   5
         Size            =   2
         Scale           =   0
         Type            =   2
         Name            =   "voucher_year"
         Caption         =   "voucher_year"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "posted"
         Caption         =   "posted"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "voucher_type"
         Caption         =   "voucher_type"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "voucher_detail"
         Caption         =   "voucher_detail"
      EndProperty
      NumGroups       =   0
      ParamCount      =   2
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   2
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   3
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset9 
      CommandName     =   "voucher_edit"
      CommDispId      =   1082
      RsDispId        =   1312
      CommandText     =   $"acc_data.dsx":01C7
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   4
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset10 
      CommandName     =   "update_voucher"
      CommDispId      =   1089
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":02B5
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   5
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   72
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset11 
      CommandName     =   "delete_voucher_item"
      CommDispId      =   1091
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0314
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset12 
      CommandName     =   "edit_voucher"
      CommDispId      =   1093
      RsDispId        =   1493
      CommandText     =   $"acc_data.dsx":0344
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   10
      BeginProperty Field1 
         Precision       =   0
         Size            =   15
         Scale           =   0
         Type            =   200
         Name            =   "voucher_id"
         Caption         =   "voucher_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   3
         Size            =   1
         Scale           =   0
         Type            =   17
         Name            =   "voucher_date"
         Caption         =   "voucher_date"
      EndProperty
      BeginProperty Field3 
         Precision       =   3
         Size            =   1
         Scale           =   0
         Type            =   17
         Name            =   "voucher_month"
         Caption         =   "voucher_month"
      EndProperty
      BeginProperty Field4 
         Precision       =   5
         Size            =   2
         Scale           =   0
         Type            =   2
         Name            =   "voucher_year"
         Caption         =   "voucher_year"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "book_name_th"
         Caption         =   "book_name_th"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_th"
         Caption         =   "sub_name_th"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "posted"
         Caption         =   "posted"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "permiter"
         Caption         =   "permiter"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "voucher_type"
         Caption         =   "voucher_type"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "voucher_detail"
         Caption         =   "voucher_detail"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset13 
      CommandName     =   "delete_voucher"
      CommDispId      =   1098
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0453
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset14 
      CommandName     =   "check_voucher"
      CommDispId      =   1105
      RsDispId        =   1110
      CommandText     =   $"acc_data.dsx":047E
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   9
      BeginProperty Field1 
         Precision       =   0
         Size            =   15
         Scale           =   0
         Type            =   200
         Name            =   "voucher_id"
         Caption         =   "voucher_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "voucher_date"
         Caption         =   "voucher_date"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "book_code"
         Caption         =   "book_code"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   3
         Scale           =   0
         Type            =   200
         Name            =   "branch_id"
         Caption         =   "branch_id"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "posted"
         Caption         =   "posted"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "permiter"
         Caption         =   "permiter"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "voucher_type"
         Caption         =   "voucher_type"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_old_account"
         Caption         =   "start_old_account"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "voucher_detail"
         Caption         =   "voucher_detail"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset15 
      CommandName     =   "insert_company"
      CommDispId      =   1131
      RsDispId        =   -1
      CommandText     =   "insert into company values (?,?,?,?,?,?,?,?,?,?,?,?)"
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   12
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   5
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P8 
         RealName        =   "Param8"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   10
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P9 
         RealName        =   "Param9"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   10
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P10 
         RealName        =   "Param10"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   13
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P11 
         RealName        =   "Param11"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P12 
         RealName        =   "Param12"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset16 
      CommandName     =   "sub"
      CommDispId      =   1133
      RsDispId        =   1471
      CommandText     =   $"acc_data.dsx":04AB
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      Expanded        =   -1  'True
      IsRSReturning   =   -1  'True
      NumFields       =   8
      BeginProperty Field1 
         Precision       =   0
         Size            =   3
         Scale           =   0
         Type            =   200
         Name            =   "sub_id"
         Caption         =   "sub_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_th"
         Caption         =   "sub_name_th"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_th"
         Caption         =   "address_th"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_eng"
         Caption         =   "sub_name_eng"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_eng"
         Caption         =   "address_eng"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "tel_no"
         Caption         =   "tel_no"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "fax_no"
         Caption         =   "fax_no"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset17 
      CommandName     =   "cheak_sub"
      CommDispId      =   1138
      RsDispId        =   1472
      CommandText     =   $"acc_data.dsx":04D5
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      Expanded        =   -1  'True
      IsRSReturning   =   -1  'True
      NumFields       =   8
      BeginProperty Field1 
         Precision       =   0
         Size            =   3
         Scale           =   0
         Type            =   200
         Name            =   "sub_id"
         Caption         =   "sub_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_th"
         Caption         =   "sub_name_th"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_th"
         Caption         =   "address_th"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_eng"
         Caption         =   "sub_name_eng"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_eng"
         Caption         =   "address_eng"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "tel_no"
         Caption         =   "tel_no"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "fax_no"
         Caption         =   "fax_no"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   3
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset18 
      CommandName     =   "insert_sub"
      CommDispId      =   1144
      RsDispId        =   -1
      CommandText     =   "insert into  sub  values(?,?,?,?,?,?,?,?)"
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   8
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   3
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   5
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P8 
         RealName        =   "Param8"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset19 
      CommandName     =   "insert_voucher"
      CommDispId      =   1160
      RsDispId        =   -1
      CommandText     =   "insert into voucher values (?,?,?,?,?,?,?,?,?,?)"
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   10
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   1
         DataType        =   17
         HostType        =   17
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   1
         DataType        =   17
         HostType        =   17
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   2
         DataType        =   2
         HostType        =   2
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   3
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P8 
         RealName        =   "Param8"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   72
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P9 
         RealName        =   "Param9"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P10 
         RealName        =   "Param10"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset20 
      CommandName     =   "company"
      CommDispId      =   1167
      RsDispId        =   1455
      CommandText     =   $"acc_data.dsx":0500
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   12
      BeginProperty Field1 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "company_name_th"
         Caption         =   "company_name_th"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_th"
         Caption         =   "address_th"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "company_name_eng"
         Caption         =   "company_name_eng"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_eng"
         Caption         =   "address_eng"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "tel_no"
         Caption         =   "tel_no"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "fax_no"
         Caption         =   "fax_no"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_date"
         Caption         =   "start_date"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_old_account"
         Caption         =   "start_old_account"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   13
         Scale           =   0
         Type            =   200
         Name            =   "tax_id"
         Caption         =   "tax_id"
      EndProperty
      BeginProperty Field11 
         Precision       =   15
         Size            =   8
         Scale           =   0
         Type            =   5
         Name            =   "tax_type"
         Caption         =   "tax_type"
      EndProperty
      BeginProperty Field12 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "tax_devide"
         Caption         =   "tax_devide"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset21 
      CommandName     =   "company_edit"
      CommDispId      =   1173
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":05BB
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   12
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   99
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   200
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   99
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   200
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   50
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   50
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   10
         Scale           =   0
         Size            =   10
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P8 
         RealName        =   "Param8"
         Direction       =   1
         Precision       =   10
         Scale           =   0
         Size            =   10
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P9 
         RealName        =   "Param9"
         Direction       =   1
         Precision       =   13
         Scale           =   0
         Size            =   13
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P10 
         RealName        =   "Param10"
         Direction       =   1
         Precision       =   1
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P11 
         RealName        =   "Param11"
         Direction       =   1
         Precision       =   1
         Scale           =   0
         Size            =   1
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P12 
         RealName        =   "Param12"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   5
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset22 
      CommandName     =   "cheak_company"
      CommDispId      =   1179
      RsDispId        =   1184
      CommandText     =   $"acc_data.dsx":067E
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   12
      BeginProperty Field1 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "company_name_th"
         Caption         =   "company_name_th"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_th"
         Caption         =   "address_th"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "company_name_eng"
         Caption         =   "company_name_eng"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_eng"
         Caption         =   "address_eng"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "tel_no"
         Caption         =   "tel_no"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "fax_no"
         Caption         =   "fax_no"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_date"
         Caption         =   "start_date"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_old_account"
         Caption         =   "start_old_account"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   13
         Scale           =   0
         Type            =   200
         Name            =   "tax_id"
         Caption         =   "tax_id"
      EndProperty
      BeginProperty Field11 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   200
         Name            =   "tax_type"
         Caption         =   "tax_type"
      EndProperty
      BeginProperty Field12 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "tax_devide"
         Caption         =   "tax_devide"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   5
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset23 
      CommandName     =   "delete_company"
      CommDispId      =   1185
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":06C7
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   5
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset24 
      CommandName     =   "check_sub_name"
      CommDispId      =   1187
      RsDispId        =   1391
      CommandText     =   "select * from sub_v where sub_name_th=?"
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   8
      BeginProperty Field1 
         Precision       =   0
         Size            =   3
         Scale           =   0
         Type            =   200
         Name            =   "sub_id"
         Caption         =   "sub_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_th"
         Caption         =   "sub_name_th"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_th"
         Caption         =   "address_th"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_eng"
         Caption         =   "sub_name_eng"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_eng"
         Caption         =   "address_eng"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "fax_no"
         Caption         =   "fax_no"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "tel_no"
         Caption         =   "tel_no"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset25 
      CommandName     =   "sum_item"
      CommDispId      =   1229
      RsDispId        =   1554
      CommandText     =   $"acc_data.dsx":06F2
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   4
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   2
         DataType        =   2
         HostType        =   2
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset26 
      CommandName     =   "insert_sum_item"
      CommDispId      =   1235
      RsDispId        =   -1
      CommandText     =   "insert into summary_plan_d values (?,?,?,?,?)"
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   5
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "id_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         UserName        =   "id_group"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         UserName        =   "level"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         UserName        =   "debit"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         UserName        =   "credit"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset27 
      CommandName     =   "check_id"
      CommDispId      =   1243
      RsDispId        =   1248
      CommandText     =   $"acc_data.dsx":0797
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "id"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset28 
      CommandName     =   "sum_group_d"
      CommDispId      =   1249
      RsDispId        =   1254
      CommandText     =   $"acc_data.dsx":07D3
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   3
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_group"
         Caption         =   "id_group"
      EndProperty
      BeginProperty Field2 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset29 
      CommandName     =   "delete_sum_d"
      CommDispId      =   1255
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0844
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset30 
      CommandName     =   "delete_sum_g"
      CommDispId      =   1261
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0879
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset31 
      CommandName     =   "plan_group"
      CommDispId      =   1267
      RsDispId        =   1272
      CommandText     =   $"acc_data.dsx":08AE
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   2
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset32 
      CommandName     =   "insert_sum_group"
      CommDispId      =   1273
      RsDispId        =   -1
      CommandText     =   "insert into summary_plan_g values (?,?,?,?,?)"
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   5
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "id_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         UserName        =   "id_group"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         UserName        =   "level"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         UserName        =   "debit"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         UserName        =   "credit"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset33 
      CommandName     =   "update_sum_group"
      CommDispId      =   1281
      RsDispId        =   -1
      CommandText     =   "update summary_plan_g set value_debit=?,value_credit=? where id_account=?"
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   3
      BeginProperty P1 
         RealName        =   "Param1"
         UserName        =   "debit"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         UserName        =   "credit"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         UserName        =   "id_account"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset34 
      CommandName     =   "check_level"
      CommDispId      =   1289
      RsDispId        =   1294
      CommandText     =   $"acc_data.dsx":08FC
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset35 
      CommandName     =   "sum_group_g"
      CommDispId      =   1295
      RsDispId        =   1300
      CommandText     =   $"acc_data.dsx":0972
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   3
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_group"
         Caption         =   "id_group"
      EndProperty
      BeginProperty Field2 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset36 
      CommandName     =   "check_data_g"
      CommDispId      =   1301
      RsDispId        =   1306
      CommandText     =   "select * from summary_plan_g where level_account=?"
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   5
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_group"
         Caption         =   "id_group"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field5 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   2
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset37 
      CommandName     =   "insert_voucher_item"
      CommDispId      =   1310
      RsDispId        =   -1
      CommandText     =   "insert into voucher_item values (?,?,?,?,?)"
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   5
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   10
         Scale           =   0
         Size            =   4
         DataType        =   3
         HostType        =   3
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset38 
      CommandName     =   "name_accd"
      CommDispId      =   1345
      RsDispId        =   1350
      CommandText     =   "select name_account from plan_account where id_account=? and type_account='D'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset39 
      CommandName     =   "sub_edit"
      CommDispId      =   1384
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":09FA
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   7
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   200
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   3
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset40 
      CommandName     =   "get_company"
      CommDispId      =   1401
      RsDispId        =   1409
      CommandText     =   "select company_id from company"
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset41 
      CommandName     =   "get_namec"
      CommDispId      =   1465
      RsDispId        =   1470
      CommandText     =   "select * from company"
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   12
      BeginProperty Field1 
         Precision       =   0
         Size            =   5
         Scale           =   0
         Type            =   200
         Name            =   "company_id"
         Caption         =   "company_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "company_name_th"
         Caption         =   "company_name_th"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_th"
         Caption         =   "address_th"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "company_name_eng"
         Caption         =   "company_name_eng"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   200
         Scale           =   0
         Type            =   200
         Name            =   "address_eng"
         Caption         =   "address_eng"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "tel_no"
         Caption         =   "tel_no"
      EndProperty
      BeginProperty Field7 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "fax_no"
         Caption         =   "fax_no"
      EndProperty
      BeginProperty Field8 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_date"
         Caption         =   "start_date"
      EndProperty
      BeginProperty Field9 
         Precision       =   0
         Size            =   10
         Scale           =   0
         Type            =   200
         Name            =   "start_old_account"
         Caption         =   "start_old_account"
      EndProperty
      BeginProperty Field10 
         Precision       =   0
         Size            =   13
         Scale           =   0
         Type            =   200
         Name            =   "tax_id"
         Caption         =   "tax_id"
      EndProperty
      BeginProperty Field11 
         Precision       =   15
         Size            =   8
         Scale           =   0
         Type            =   5
         Name            =   "tax_type"
         Caption         =   "tax_type"
      EndProperty
      BeginProperty Field12 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "tax_devide"
         Caption         =   "tax_devide"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset42 
      CommandName     =   "sub_name"
      CommDispId      =   1473
      RsDispId        =   1485
      CommandText     =   $"acc_data.dsx":0A6D
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   50
         Scale           =   0
         Type            =   200
         Name            =   "sub_name_th"
         Caption         =   "sub_name_th"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset43 
      CommandName     =   "view_item"
      CommDispId      =   1486
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0A8E
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   4
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   0
         DataType        =   3
         HostType        =   3
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   0
         DataType        =   3
         HostType        =   3
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   0
         DataType        =   3
         HostType        =   3
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   0
         DataType        =   3
         HostType        =   3
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset44 
      CommandName     =   "concurrent_plan"
      CommDispId      =   1525
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset45 
      CommandName     =   "concurrent_voucher"
      CommDispId      =   1531
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "cn_voucher"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset46 
      CommandName     =   "concurrent_company"
      CommDispId      =   1537
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "cn_company"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset47 
      CommandName     =   "concurrent_sub"
      CommDispId      =   1543
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "cn_sub"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset48 
      CommandName     =   "concurrent_report"
      CommDispId      =   1552
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "create_report"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset49 
      CommandName     =   "show_data"
      CommDispId      =   1569
      RsDispId        =   1595
      CommandText     =   "select  *  from grand_l order by id_account"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   4
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset50 
      CommandName     =   "update_grandl"
      CommDispId      =   1596
      RsDispId        =   -1
      CommandText     =   "update grandlast_year set value_debit=?,value_credit=? where id_account=?"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   3
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset51 
      CommandName     =   "get_grand"
      CommDispId      =   1598
      RsDispId        =   1637
      CommandText     =   $"acc_data.dsx":0B44
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   4
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset52 
      CommandName     =   "concurrent_grand"
      CommDispId      =   1608
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset53 
      CommandName     =   "get_tmpgrand"
      CommDispId      =   1610
      RsDispId        =   1615
      CommandText     =   "select * from tmp_grand"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   7
      BeginProperty Field1 
         Precision       =   3
         Size            =   1
         Scale           =   0
         Type            =   17
         Name            =   "voucher_day"
         Caption         =   "voucher_day"
      EndProperty
      BeginProperty Field2 
         Precision       =   3
         Size            =   1
         Scale           =   0
         Type            =   17
         Name            =   "voucher_month"
         Caption         =   "voucher_month"
      EndProperty
      BeginProperty Field3 
         Precision       =   5
         Size            =   2
         Scale           =   0
         Type            =   2
         Name            =   "voucher_year"
         Caption         =   "voucher_year"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   99
         Scale           =   0
         Type            =   200
         Name            =   "voucher_detail"
         Caption         =   "voucher_detail"
      EndProperty
      BeginProperty Field5 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field6 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      BeginProperty Field7 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "balance"
         Caption         =   "balance"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset54 
      CommandName     =   "delete_tmpg"
      CommDispId      =   1616
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0B97
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset55 
      CommandName     =   "insert_acc"
      CommDispId      =   1624
      RsDispId        =   -1
      CommandText     =   $"acc_data.dsx":0BC5
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset56 
      CommandName     =   "insert_grand"
      CommDispId      =   1626
      RsDispId        =   -1
      CommandText     =   "insert into tmp_grand values(?,?,?,?,?,?,?,?,?)"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   9
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   50
         Scale           =   0
         Size            =   50
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   1
         DataType        =   17
         HostType        =   17
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   1
         DataType        =   17
         HostType        =   17
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   2
         DataType        =   2
         HostType        =   2
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   99
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P7 
         RealName        =   "Param7"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P8 
         RealName        =   "Param8"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P9 
         RealName        =   "Param9"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset57 
      CommandName     =   "update_balance"
      CommDispId      =   1635
      RsDispId        =   -1
      CommandText     =   "update tmp_grand set balance=? where voucher_id=? and voucher_day=? and voucher_month=? and voucher_year=? and voucher_detail=?"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   6
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   15
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   1
         DataType        =   17
         HostType        =   17
         Required        =   -1  'True
      EndProperty
      BeginProperty P4 
         RealName        =   "Param4"
         Direction       =   1
         Precision       =   3
         Scale           =   0
         Size            =   1
         DataType        =   17
         HostType        =   17
         Required        =   -1  'True
      EndProperty
      BeginProperty P5 
         RealName        =   "Param5"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   2
         DataType        =   2
         HostType        =   2
         Required        =   -1  'True
      EndProperty
      BeginProperty P6 
         RealName        =   "Param6"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   99
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset58 
      CommandName     =   "insert_grandl"
      CommDispId      =   1643
      RsDispId        =   -1
      CommandText     =   "insert into grandlast_year values (?,?,?)"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   3
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset59 
      CommandName     =   "get_lastyear"
      CommDispId      =   1645
      RsDispId        =   1657
      CommandText     =   "select * from grandlast_year where id_account=?"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   3
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset60 
      CommandName     =   "get_sumd"
      CommDispId      =   1651
      RsDispId        =   1656
      CommandText     =   "select * from summary_plan_d order by id_account"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   5
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_group"
         Caption         =   "id_group"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field5 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset61 
      CommandName     =   "insert_glast"
      CommDispId      =   1658
      RsDispId        =   -1
      CommandText     =   "insert into grandlast_year values (?,?,?)"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   3
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset62 
      CommandName     =   "insert_thisy"
      CommDispId      =   1660
      RsDispId        =   -1
      CommandText     =   "insert into grandthis_year select * from grandlast_year"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset63 
      CommandName     =   "delete_gthis"
      CommDispId      =   1668
      RsDispId        =   -1
      CommandText     =   "delete from grandthis_year"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset64 
      CommandName     =   "update_thisy"
      CommDispId      =   1670
      RsDispId        =   -1
      CommandText     =   "update grandthis_year set value_debit=?,value_credit=? where id_account=?"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   3
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset65 
      CommandName     =   "clear_thisy"
      CommDispId      =   1672
      RsDispId        =   -1
      CommandText     =   "delete grandthis_year where value_debit=0 and value_credit=0"
      ActiveConnectionName=   "cn_grandly"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset66 
      CommandName     =   "selectIDgroup"
      CommDispId      =   1674
      RsDispId        =   1679
      CommandText     =   $"acc_data.dsx":0C5E
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   5
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field5 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset67 
      CommandName     =   "getType"
      CommDispId      =   1680
      RsDispId        =   1685
      CommandText     =   "select type_account from plan_account where id_account=?"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset68 
      CommandName     =   "getPlanG"
      CommDispId      =   1686
      RsDispId        =   1691
      CommandText     =   $"acc_data.dsx":0CF6
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   4
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   0
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset69 
      CommandName     =   "getPlanD"
      CommDispId      =   1692
      RsDispId        =   1697
      CommandText     =   $"acc_data.dsx":0D9C
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   4
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset70 
      CommandName     =   "checkSummary"
      CommDispId      =   1698
      RsDispId        =   1703
      CommandText     =   $"acc_data.dsx":0E44
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   1
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset71 
      CommandName     =   "UpdateART"
      CommDispId      =   1704
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=?,value2=? where name='ART'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   2
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset72 
      CommandName     =   "UpdateCRatio"
      CommDispId      =   1710
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='CRatio'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset73 
      CommandName     =   "UpdateDERatio"
      CommDispId      =   1716
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='DERatio'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset74 
      CommandName     =   "UpdateDRatio"
      CommDispId      =   1722
      RsDispId        =   -1
      CommandText     =   "Update Analyse set value1=? where name='DRatio'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset75 
      CommandName     =   "UpdateIT"
      CommDispId      =   1728
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='IT'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset76 
      CommandName     =   "UpdateNPMargin"
      CommDispId      =   1734
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? name='NPMargin'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset77 
      CommandName     =   "UpdateQRatio"
      CommDispId      =   1740
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='QRatio'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset78 
      CommandName     =   "UpdateROI"
      CommDispId      =   1746
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='ROI'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset79 
      CommandName     =   "UpdateTAT"
      CommDispId      =   1752
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='TAT'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset80 
      CommandName     =   "UpdateTIE"
      CommDispId      =   1759
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=? where name='TIE'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   15
         Scale           =   0
         Size            =   8
         DataType        =   5
         HostType        =   5
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset81 
      CommandName     =   "SelectAsset"
      CommDispId      =   1761
      RsDispId        =   1783
      CommandText     =   "select * from plan_account where id_account LIKE'1%'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset82 
      CommandName     =   "SelectDebt"
      CommDispId      =   1771
      RsDispId        =   1784
      CommandText     =   "select * from plan_account where id_account LIKE'2%'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset83 
      CommandName     =   "SelectRevenue"
      CommDispId      =   1785
      RsDispId        =   1790
      CommandText     =   "select * from plan_account where id_account LIKE'4%'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset84 
      CommandName     =   "SelectCapital"
      CommDispId      =   1791
      RsDispId        =   1796
      CommandText     =   "Select * from plan_account where id_account LIKE '3%'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset85 
      CommandName     =   "SelectExpenses"
      CommDispId      =   1797
      RsDispId        =   1802
      CommandText     =   "select * from plan_account where id_account LIKE'5%'"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   6
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account"
         Caption         =   "name_account"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   72
         Scale           =   0
         Type            =   200
         Name            =   "name_account2"
         Caption         =   "name_account2"
      EndProperty
      BeginProperty Field4 
         Precision       =   0
         Size            =   1
         Scale           =   0
         Type            =   129
         Name            =   "type_account"
         Caption         =   "type_account"
      EndProperty
      BeginProperty Field5 
         Precision       =   0
         Size            =   36
         Scale           =   0
         Type            =   200
         Name            =   "group_account"
         Caption         =   "group_account"
      EndProperty
      BeginProperty Field6 
         Precision       =   0
         Size            =   2
         Scale           =   0
         Type            =   200
         Name            =   "level_account"
         Caption         =   "level_account"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset86 
      CommandName     =   "ClearAnalyse"
      CommDispId      =   1804
      RsDispId        =   -1
      CommandText     =   "update Analyse set value1=null, value2=null"
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset87 
      CommandName     =   "getthis_year"
      CommDispId      =   1864
      RsDispId        =   1867
      CommandText     =   "select * from grandthis_year"
      ActiveConnectionName=   "cn_close_acc"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   3
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset88 
      CommandName     =   "concurrent_close"
      CommDispId      =   1913
      RsDispId        =   -1
      CommandText     =   "set transaction isolation level serializable"
      ActiveConnectionName=   "cn_close_acc"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset89 
      CommandName     =   "del_voucher"
      CommDispId      =   1915
      RsDispId        =   -1
      CommandText     =   "delete from voucher where voucher_year=?"
      ActiveConnectionName=   "cn_close_acc"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   1
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   5
         Scale           =   0
         Size            =   2
         DataType        =   2
         HostType        =   2
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset90 
      CommandName     =   "update_lastyear"
      CommDispId      =   1921
      RsDispId        =   -1
      CommandText     =   "update grandlast_year set value_debit=?,value_credit=? where id_account=? "
      ActiveConnectionName=   "cn_close_acc"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   3
      BeginProperty P1 
         RealName        =   "Param1"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P2 
         RealName        =   "Param2"
         Direction       =   1
         Precision       =   19
         Scale           =   4
         Size            =   19
         DataType        =   131
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      BeginProperty P3 
         RealName        =   "Param3"
         Direction       =   1
         Precision       =   11
         Scale           =   0
         Size            =   11
         DataType        =   200
         HostType        =   8
         Required        =   -1  'True
      EndProperty
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset91 
      CommandName     =   "delthis_year"
      CommDispId      =   1923
      RsDispId        =   -1
      CommandText     =   "delete from grandthis_year "
      ActiveConnectionName=   "cn_close_acc"
      CommandType     =   1
      NumFields       =   0
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset92 
      CommandName     =   "check_vitem"
      CommDispId      =   1925
      RsDispId        =   1938
      CommandText     =   "select * from voucher_item "
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   5
      BeginProperty Field1 
         Precision       =   10
         Size            =   4
         Scale           =   0
         Type            =   3
         Name            =   "item_id"
         Caption         =   "item_id"
      EndProperty
      BeginProperty Field2 
         Precision       =   0
         Size            =   15
         Scale           =   0
         Type            =   200
         Name            =   "voucher_id"
         Caption         =   "voucher_id"
      EndProperty
      BeginProperty Field3 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field4 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field5 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
   BeginProperty Recordset93 
      CommandName     =   "check_lyear"
      CommDispId      =   1931
      RsDispId        =   1937
      CommandText     =   "select * from grandlast_year "
      ActiveConnectionName=   "cn_plan"
      CommandType     =   1
      IsRSReturning   =   -1  'True
      NumFields       =   3
      BeginProperty Field1 
         Precision       =   0
         Size            =   11
         Scale           =   0
         Type            =   200
         Name            =   "id_account"
         Caption         =   "id_account"
      EndProperty
      BeginProperty Field2 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_debit"
         Caption         =   "value_debit"
      EndProperty
      BeginProperty Field3 
         Precision       =   19
         Size            =   8
         Scale           =   0
         Type            =   6
         Name            =   "value_credit"
         Caption         =   "value_credit"
      EndProperty
      NumGroups       =   0
      ParamCount      =   0
      RelationCount   =   0
      AggregateCount  =   0
   EndProperty
End
Attribute VB_Name = "acc_data"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub rsdaily_receive_EndOfRecordset(fMoreData As Boolean, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)

End Sub

Private Sub rsdaily_receive_WillChangeField(ByVal cFields As Long, ByVal Fields As Variant, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)

End Sub

