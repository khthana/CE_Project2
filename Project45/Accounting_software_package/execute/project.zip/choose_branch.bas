Attribute VB_Name = "choose_branch"
Option Explicit

Public Sub setsub(sub_id As String)
book_cash_pay.s_id = sub_id
book_cash_receive.s_id = sub_id
book_credit_buy.s_id = sub_id
book_credit_sell.s_id = sub_id
book_general_day.s_id = sub_id
End Sub

Function CheckID(cmp As String) As Boolean
     Dim i As Integer
     Dim Sum As Long
     Dim ch As Boolean
     ch = False
     Call check_rs
     acc_data.cn_plan.Open
     acc_data.plan
     Sum = acc_data.rsplan.RecordCount  'total row of plan
     i = 0
     Do While i < Sum
        If cmp = acc_data.rsplan.Fields(0) Then 'check id_account in table plan_account
            ch = True 'have id_account in table plan_account
            Exit Do
        Else:   i = i + 1
                    acc_data.rsplan.MoveNext
        End If
     Loop
     
     If ch = True Then
        Call check_rs
        acc_data.cn_plan.Open
        acc_data.checkSummary
        Sum = acc_data.rscheckSummary.RecordCount  'total row of summary_plan
        i = 0
        Do While i < Sum
            If cmp = acc_data.rscheckSummary.Fields(0) Then
                CheckID = True  'have id_account in table summary_plan_d and g
                Exit Function
            Else:   i = i + 1
                        acc_data.rscheckSummary.MoveNext
            End If
        Loop
        CheckID = False  'have not  id_account in table summary_plan_d and g
     Else: CheckID = False 'have not id_account in table plan_account
     End If
End Function

Public Sub check_rs()
            If acc_data.cn_plan.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata recordset
                        acc_data.cn_plan.Close
            End If
End Sub

