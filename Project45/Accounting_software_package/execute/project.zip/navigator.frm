VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form navigator 
   Caption         =   "����׺�鹡�÷ӧҹ����׺�鹡�÷ӧҹ"
   ClientHeight    =   6690
   ClientLeft      =   1935
   ClientTop       =   810
   ClientWidth     =   6615
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   ScaleHeight     =   6690
   ScaleWidth      =   6615
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   5160
      TabIndex        =   2
      Top             =   6240
      Width           =   1335
   End
   Begin VB.Frame Frame1 
      Caption         =   "��������´����׺��"
      Height          =   6135
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   6375
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   5415
         Left            =   360
         TabIndex        =   1
         Top             =   360
         Width           =   5655
         _ExtentX        =   9975
         _ExtentY        =   9551
         _Version        =   393216
         Rows            =   99
         ScrollBars      =   2
         _NumberOfBands  =   1
         _Band(0).Cols   =   2
      End
   End
End
Attribute VB_Name = "navigator"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub CmdESC_Click()
    Unload Me
    windows_account.Show
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
                If KeyAscii = 33 Then
                                Call cheak_dataenvironment
                                Unload Me
                End If
                
End Sub

Private Sub Form_Load()
            Call Setgrid
            'Call display_grid
            Call cheak_dataenvironment
End Sub
'Private Sub display_grid()

'Dim tmp_row As Integer
'Dim row_edit As Integer
'row_edit = 1
 '       Call Setgrid
  '      acc_data.cn_branch.Open
   '     acc_data.branch
    '                      If acc_data.rsbranch.RecordCount > 0 Then
     '                                       tmp_row = acc_data.rsbranch.RecordCount
      '                                      Do
       '
        '                                                gridinv.TextMatrix(row_edit, 1) = acc_data.rsbranch.Fields(0)
          '                                              gridinv.TextMatrix(row_edit, 2) = acc_data.rsbranch.Fields(1)
         '
           '                                             row_edit = row_edit + 1
            '                                            tmp_row = tmp_row - 1
             '                                           acc_data.rsbranch.MoveNext
              '                              Loop Until tmp_row = 0
               '
                '            End If
                'End With
                              
                

'End Sub

Private Sub Setgrid()
Dim row_temp As Integer
Dim i As Integer
Dim point_grid As Integer
point_grid = 350
row_temp = 1  ' set ���㹡�� clear gridinv

gridinv.Move point_grid, 300 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 200
gridinv.ColWidth(1) = 5500


gridinv.TextMatrix(0, 1) = "��ª������١�÷ӧҹ"
gridinv.TextMatrix(1, 1) = "���������������ź���ѷ"
gridinv.TextMatrix(2, 1) = "����������������Ἱ�"
gridinv.TextMatrix(3, 1) = "��䢼ѧ�ѭ��"
gridinv.TextMatrix(4, 1) = "�����żŢ���������Ѻ Report ��鹻�"
gridinv.TextMatrix(5, 1) = "�ʹ¡��"


'Do While (gridinv.Rows - 1) > row_temp
                        
 '           gridinv.TextMatrix(row_temp, 1) = ""
  '          gridinv.TextMatrix(row_temp, 2) = ""
   '         row_temp = row_temp + 1
'Loop

For i = 0 To 1
gridinv.col = i
gridinv.ColAlignment = 1
Next i

gridinv.row = 1
gridinv.col = 0
End Sub

Private Sub cheak_dataenvironment()

            If acc_data.cn_company.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_company.Close
            End If

End Sub

Private Sub gridinv_DblClick()
                Select Case gridinv.Text
                            Case "���������������ź���ѷ"
                                        Unload Me
                                        ENTER_COMPANY.Show
                            Case "����������������Ἱ�"
                                        Unload Me
                                        enter_branch.Show
                            Case "��䢼ѧ�ѭ��"
                                        Unload Me
                                        data_plan_account.Show
                            Case "�����żŢ���������Ѻ Report ��鹻�"
                                        Unload Me
                                        process_report.Show
                            Case "�ʹ¡��"
                                         Unload Me
                                         start_account.Show
               End Select
                
End Sub

Private Sub gridinv_KeyPress(KeyAscii As Integer)
                If KeyAscii = 27 Then
                                Call cheak_dataenvironment
                                Unload Me
                                windows_account.Show
                End If

End Sub

