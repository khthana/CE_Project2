VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form Analyse 
   Caption         =   "�������짺����Թ"
   ClientHeight    =   6765
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6285
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   6765
   ScaleWidth      =   6285
   StartUpPosition =   2  'CenterScreen
   Begin Crystal.CrystalReport CrystAnalyse 
      Left            =   3720
      Top             =   6360
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      ReportFileName  =   "C:\project\reports\Analyse.rpt"
      WindowState     =   2
      PrintFileLinesPerPage=   60
   End
   Begin VB.CommandButton CmdESC 
      Caption         =   "¡��ԡ��¡��"
      Height          =   375
      Left            =   4800
      TabIndex        =   2
      Top             =   6360
      Width           =   1335
   End
   Begin VB.Frame Frame1 
      Caption         =   "��¡���������짺����Թ"
      Height          =   6240
      Left            =   120
      TabIndex        =   0
      Top             =   10
      Width           =   6015
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   5655
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   5535
         _ExtentX        =   9763
         _ExtentY        =   9975
         _Version        =   393216
         Rows            =   99
         _NumberOfBands  =   1
         _Band(0).Cols   =   2
      End
   End
End
Attribute VB_Name = "Analyse"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub Setgrid()

Dim row_temp As Integer
Dim i As Integer
Dim point_grid As Integer


gridinv.ColWidth(0) = 200           'Columns width 0
gridinv.ColWidth(1) = 6000         'Columns width 1


gridinv.TextMatrix(1, 1) = "�������������Ҿ���ͧ�Ԩ���"
gridinv.TextMatrix(2, 1) = "������������ѵ����ǹ�ʴ��ʴ���������ö㹡�÷ӡ���"
gridinv.TextMatrix(3, 1) = "�ѵ����ǹ�ʴ���������§㹡�û�Сͺ��áԨ"
gridinv.TextMatrix(4, 1) = "�ѵ����ǹ�ʴ�����Է���Ҿ㹡�ô��Թ�ҹ"
gridinv.TextMatrix(5, 1) = "��§ҹ�������짺����Թ"


gridinv.row = 1
gridinv.col = 0
End Sub

Private Sub CmdESC_Click()
    Unload Me
    windows_account.Show
End Sub

Private Sub Form_Load()
    Call Setgrid
End Sub

Private Sub gridinv_DblClick()
        If gridinv.col = 1 Then 'columns 1
            Select Case gridinv.row 'row select menu
                Case 1
                               Unload Me
                               Form_Liquidity.Show
                Case 2
                               Unload Me
                               Form_Profitability.Show
                Case 3
                               Unload Me
                               Form_Leverage.Show
                Case 4
                               Unload Me
                               Form_Activity.Show
                Case 5
                               Dim name_company As String
                               acc_data.cn_company.Open
                               acc_data.get_namec
                               name_company = acc_data.rsget_namec.Fields(1)
                               acc_data.cn_company.Close
    
                               CrystAnalyse.Formulas(0) = "name_company = ' " & name_company & " ' "
                               CrystAnalyse.RetrieveDataFiles    'refresh
                               CrystAnalyse.PrintReport      'or  CryptProfit.Action = 1
            End Select
        End If
End Sub
