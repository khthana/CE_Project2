VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form select_account 
   Caption         =   "��ش�ѭ��"
   ClientHeight    =   3030
   ClientLeft      =   1935
   ClientTop       =   810
   ClientWidth     =   6510
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   ScaleHeight     =   3030
   ScaleWidth      =   6510
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   5100
      TabIndex        =   2
      Top             =   2520
      Width           =   1215
   End
   Begin VB.Frame Frame1 
      Caption         =   "��¡����ش�ѭ��"
      Height          =   2295
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6200
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   1575
         Left            =   240
         TabIndex        =   1
         Top             =   360
         Width           =   5655
         _ExtentX        =   9975
         _ExtentY        =   2778
         _Version        =   393216
         Rows            =   6
         Cols            =   3
         _NumberOfBands  =   1
         _Band(0).Cols   =   3
      End
   End
End
Attribute VB_Name = "select_account"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub CmdESC_Click()
    Unload Me
    windows_account.Show
End Sub

Private Sub gridinv_KeyPress(KeyAscii As Integer)
                If KeyAscii = 27 Then
                                
                                Unload Me
                                windows_account.Show
                End If

End Sub

Private Sub Form_Load()
     'select_account.Caption = select_branch.nameSelect_account
     'Frame1.Caption = select_branch.nameSelect_account
     Call Setgrid
     
End Sub

Private Sub Setgrid()
Dim point_grid As Integer
Dim i As Integer
point_grid = 260
gridinv.Move point_grid, 300 'set ���˹觢ͧ textbox 㹡���ʴ�������

gridinv.ColWidth(0) = 200
gridinv.ColWidth(1) = 1200
gridinv.ColWidth(2) = 4170

gridinv.TextMatrix(0, 1) = "������ش����ѹ"
gridinv.TextMatrix(0, 2) = "������ش����ѹ"

gridinv.TextMatrix(1, 1) = "GL"
gridinv.TextMatrix(1, 2) = "��ش����ѹ�����"

gridinv.TextMatrix(2, 1) = "PC"
gridinv.TextMatrix(2, 2) = "��ش�Թʴ����"

gridinv.TextMatrix(3, 1) = "PD"
gridinv.TextMatrix(3, 2) = "��ش��������"

gridinv.TextMatrix(4, 1) = "SC"
gridinv.TextMatrix(4, 2) = "��ش�Թʴ�Ѻ"

gridinv.TextMatrix(5, 1) = "SD"
gridinv.TextMatrix(5, 2) = "��ش�������"

For i = 0 To 1
gridinv.col = i
gridinv.ColAlignment = 1
Next i

End Sub
Private Sub gridinv_DblClick()
                    Select Case gridinv.Text
                    
                                    Case "GL"
                                                    Unload Me
                                                    book_general_day.Show
                                                    book_general_day.book_code = "GJ"
                                    Case "��ش����ѹ�����"
                                                    Unload Me
                                                    book_general_day.Show
                                                    book_general_day.book_code = "GJ"
                                    Case "PC"
                                                    Unload Me
                                                    book_cash_pay.Show
                                                    book_cash_pay.book_code = "PC"
                                    Case "��ش�Թʴ����"
                                                    Unload Me
                                                    book_cash_pay.Show
                                                    book_cash_pay.book_code = "PC"
                                    Case "PD"
                                                    Unload Me
                                                    book_credit_buy.book_code = "PD"
                                                    book_credit_buy.Show
                                    Case "��ش��������"
                                                   Unload Me
                                                    book_credit_buy.book_code = "PD"
                                                    book_credit_buy.Show
                                    Case "SC"
                                                    Unload Me
                                                    book_cash_receive.book_code = "SC"
                                                    book_cash_receive.Show
                                    Case "��ش�Թʴ�Ѻ"
                                                    Unload Me
                                                    book_cash_receive.book_code = "SC"
                                                    book_cash_receive.Show
                                    Case "SD"
                                                    Unload Me
                                                    book_credit_sell.book_code = "SD"
                                                    book_credit_sell.Show
                                    Case "��ش�������"
                                                    Unload Me
                                                    book_credit_sell.book_code = "SD"
                                                    book_credit_sell.Show
                    End Select
                    
End Sub
