VERSION 5.00
Begin VB.Form frmSp_NPMargin 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5460
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   9210
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_NPMargin.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5460
   ScaleWidth      =   9210
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_NPMargin 
      Caption         =   "�ѵ����ǹ�����ط�Ե���ʹ��� (Net Profit Margin)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5250
      Left            =   120
      TabIndex        =   7
      Top             =   50
      Width           =   8920
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6240
         TabIndex        =   21
         Top             =   2550
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_NPMargin 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   2520
         TabIndex        =   20
         Top             =   2160
         Width           =   2535
      End
      Begin VB.PictureBox Pic_NPMargin 
         Height          =   1695
         Left            =   720
         ScaleHeight     =   1635
         ScaleWidth      =   7395
         TabIndex        =   15
         Top             =   3240
         Width           =   7455
         Begin VB.Label LabAnalyse4_NPMargin 
            AutoSize        =   -1  'True
            Caption         =   "2.  ����ҡ���� 20.00 �ʴ���� ��áԨ���ӡ������٧ "
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   1920
            TabIndex        =   19
            Top             =   1200
            Width           =   3495
         End
         Begin VB.Label LabAnalyse3_NPMargin 
            AutoSize        =   -1  'True
            Caption         =   "1.  ��ҹ��¡��� 20.00 �ʴ���� ��áԨ���ӡ�������"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   1920
            TabIndex        =   18
            Top             =   840
            Width           =   3450
         End
         Begin VB.Label LabAnalyse2_NPMargin 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�Ңͧ�ص��ˡ�������������ҳ  20.00 %  "
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   2160
            TabIndex        =   17
            Top             =   480
            Width           =   3360
         End
         Begin VB.Label LabAnalyse1_NPMargin 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ����ǹ�š��õ���ʹ���  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   795
            TabIndex        =   16
            Top             =   120
            Width           =   5805
         End
      End
      Begin VB.CommandButton CmdESC_NPMargin 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6240
         TabIndex        =   5
         Top             =   2180
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_NPMargin 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6240
         TabIndex        =   4
         Top             =   1800
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_NPMargin 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6240
         TabIndex        =   3
         Top             =   1425
         Width           =   1935
      End
      Begin VB.TextBox TxtNameSell_NPMargin 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4320
         TabIndex        =   11
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDSell_NPMargin 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2400
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneySell_NPMargin 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6240
         TabIndex        =   10
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyProfit_NPMargin 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6240
         TabIndex        =   2
         Top             =   960
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2400
         TabIndex        =   22
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabMoney_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6840
         TabIndex        =   14
         Top             =   330
         Width           =   705
      End
      Begin VB.Label LabName_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4920
         TabIndex        =   13
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabID_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   3000
         TabIndex        =   12
         Top             =   315
         Width           =   660
      End
      Begin VB.Label LabPercent_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "%"
         Height          =   195
         Left            =   5160
         TabIndex        =   9
         Top             =   2245
         Width           =   120
      End
      Begin VB.Label LabResult_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ����ǹ�š��õ���ʹ��� ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   360
         TabIndex        =   8
         Top             =   2220
         Width           =   2085
      End
      Begin VB.Label LabSell_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "�ʹ���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1750
         TabIndex        =   6
         Top             =   600
         Width           =   555
      End
      Begin VB.Label LabProfit_NPMargin 
         AutoSize        =   -1  'True
         Caption         =   "�����ط����ѧ�ѡ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   850
         TabIndex        =   0
         Top             =   970
         Width           =   1440
      End
   End
End
Attribute VB_Name = "frmSp_NPMargin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdCal_NPMargin_Click()
        Dim profit As String
        Dim Sell As String
        Dim result As String
        Dim TF As String
        'TF = IsNumeric(TxtMoneyProfit_NPMargin.Text)
        
        If TxtIDSell_NPMargin.Text = "" Then
                MsgBox "���ʺѭ�����ú��س�����������ó�...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        ElseIf IsNumeric(TxtMoneyProfit_NPMargin.Text) Then 'And IsNumeric(TxtMoneySell_NPMargin.Text) Then
                profit = CDbl(TxtMoneyProfit_NPMargin.Text)
                Sell = CDbl(TxtMoneySell_NPMargin.Text)
                result = profit * 100
                result = result / Sell
                TxtResult_NPMargin.Text = result
        Else: MsgBox "��سһ�͹�繨ӹǹ����Ţ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
        End If
End Sub

Private Sub CmdClear_NPMargin_Click()
        TxtIDSell_NPMargin.Text = ""
        TxtNameSell_NPMargin.Text = ""
        TxtMoneySell_NPMargin.Text = ""
        
        TxtMoneyProfit_NPMargin.Text = ""
        TxtResult_NPMargin.Text = ""
End Sub

Private Sub CmdESC_NPMargin_Click()
           'Form_Profitability.Show
           Unload Me
End Sub

Private Sub CmdSave_Click()
    If TxtResult_NPMargin.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateNPMargin CDbl(TxtResult_NPMargin.Text)
            TxtResult_NPMargin.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_NPMargin
End Sub

Private Sub TxtIDSell_NPMargin_DblClick()
        TxtIDSell_NPMargin_LostFocus
        frmPlan_NPMargin.Show
End Sub

Private Sub TxtIDSell_NPMargin_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDSell_NPMargin.Text = "") Then
                        TxtIDSell_NPMargin.Text = "" 'id
                        TxtNameSell_NPMargin.Text = "" 'name
                        TxtMoneySell_NPMargin.Text = "" 'value debit
                        TxtIDSell_NPMargin.SetFocus
                ElseIf CheckID(TxtIDSell_NPMargin.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDSell_NPMargin.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDSell_NPMargin.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                a$ = Left$(TxtIDSell_NPMargin.Text, 1) 'check is revenue?
                                                                                            
                                If a$ = "4" Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDSell_NPMargin.Text
                                                TxtNameSell_NPMargin.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_NPMargin.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDSell_NPMargin.Text
                                                TxtNameSell_NPMargin.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_NPMargin.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtMoneyProfit_NPMargin.SetFocus  'next text box
                                Else 'is't revenue
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�����...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDSell_NPMargin.Text = ""
                                        TxtNameSell_NPMargin.Text = ""
                                        TxtMoneySell_NPMargin.Text = ""
                                        TxtIDSell_NPMargin.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_NPMargin.Text = "" 'name
                        TxtMoneySell_NPMargin.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDSell_NPMargin.Text = ""
                            TxtNameSell_NPMargin.Text = ""
                            TxtMoneySell_NPMargin.Text = ""
                            TxtIDSell_NPMargin.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDSell_NPMargin_LostFocus()
      Dim a As String
      If (TxtIDSell_NPMargin.Text = "") Then
                TxtIDSell_NPMargin.Text = "" 'id
                TxtNameSell_NPMargin.Text = "" 'name
                TxtMoneySell_NPMargin.Text = "" 'value debit
                'TxtIDSell_NPMargin.SetFocus
      ElseIf CheckID(TxtIDSell_NPMargin.Text) = False Then
                TxtIDSell_NPMargin.Text = ""
                TxtNameSell_NPMargin.Text = "" 'name
                TxtMoneySell_NPMargin.Text = "" 'value debit
       ElseIf CheckID(TxtIDSell_NPMargin.Text) = True Then
                        'And TxtNameSell_NPMargin.Text = "" And TxtMoneySell_NPMargin.Text = "" Then
                        If TxtIDSell_NPMargin.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDSell_NPMargin.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDSell_NPMargin.Text <> "4") Then
                                    a = Left$(TxtIDSell_NPMargin.Text, 1) 'check is revenue?
                                Else: a = "4"
                                End If
                                
                                If a = "4" Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDSell_NPMargin.Text
                                                TxtNameSell_NPMargin.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_NPMargin.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDSell_NPMargin.Text
                                                TxtNameSell_NPMargin.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_NPMargin.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'TxtID2_CRatio.SetFocus  'next text box
                                Else 'is't Sell
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�����...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDSell_NPMargin.Text = ""
                                        TxtNameSell_NPMargin.Text = ""
                                        TxtMoneySell_NPMargin.Text = ""
                                        TxtIDSell_NPMargin.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_NPMargin.Text = "" 'name
                        TxtMoneySell_NPMargin.Text = "" 'value debit
                        End If
        End If
End Sub
