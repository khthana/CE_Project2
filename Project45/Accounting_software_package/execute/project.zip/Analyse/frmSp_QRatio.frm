VERSION 5.00
Begin VB.Form frmSp_QRatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   6390
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8655
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_QRatio.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6390
   ScaleWidth      =   8655
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_QRatio 
      Caption         =   "�ѵ����ǹ�ع��ع���¹���� (Quick Ratio)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6195
      Left            =   120
      TabIndex        =   0
      Top             =   60
      Width           =   8385
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   5880
         TabIndex        =   31
         Top             =   3400
         Width           =   1935
      End
      Begin VB.PictureBox Pic_CRatio 
         Height          =   1695
         Left            =   480
         ScaleHeight     =   1635
         ScaleWidth      =   7275
         TabIndex        =   26
         Top             =   4080
         Width           =   7335
         Begin VB.Label LabAnalyse1_QRatio 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ����ǹ�ع��ع���¹����  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   885
            TabIndex        =   30
            Top             =   120
            Width           =   5625
         End
         Begin VB.Label LabAnalyse2_CRatio 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�Ңͧ�ص��ˡ�������������ҳ  5.00  "
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   2160
            TabIndex        =   29
            Top             =   480
            Width           =   3030
         End
         Begin VB.Label LabAnalyse3_CRatio 
            AutoSize        =   -1  'True
            Caption         =   "1.  ��ҹ��¡��� 5.00 �ʴ���� ���Թ��Ѿ����ع���¹�ӹǹ�ҡ�������Ҿ���Թʴ����"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   480
            TabIndex        =   28
            Top             =   840
            Width           =   6000
         End
         Begin VB.Label LabAnalyse4_CRatio 
            AutoSize        =   -1  'True
            Caption         =   "2.  ����ҡ���� 5.00 �ʴ���� ���Թ��Ѿ����ع���¹�ӹǹ���·������Ҿ���Թʴ����"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   480
            TabIndex        =   27
            Top             =   1200
            Width           =   6000
         End
      End
      Begin VB.CommandButton CmdESC_QRatio 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   5880
         TabIndex        =   25
         Top             =   3050
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_QRatio 
         Caption         =   "Clear"
         Height          =   375
         Left            =   5880
         TabIndex        =   24
         Top             =   2690
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyDebt 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   22
         Top             =   1800
         Width           =   1935
      End
      Begin VB.TextBox TxtNameDebt 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   21
         Top             =   1800
         Width           =   1935
      End
      Begin VB.TextBox TxtIDDebt 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   4
         Top             =   1800
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_QRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   315
         Left            =   2280
         TabIndex        =   19
         Top             =   3120
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyPay 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   18
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtNamePay 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   17
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtIDPay 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   3
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyCargo 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   16
         Top             =   1080
         Width           =   1935
      End
      Begin VB.TextBox TxtNameCargo 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   15
         Top             =   1080
         Width           =   1935
      End
      Begin VB.TextBox TxtIDCargo 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   2
         Top             =   1080
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyAst 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   14
         Top             =   720
         Width           =   1935
      End
      Begin VB.TextBox TxtNameAst 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   13
         Top             =   720
         Width           =   1935
      End
      Begin VB.TextBox TxtIDAst 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   1
         Top             =   720
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_QRatio 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   5880
         TabIndex        =   5
         Top             =   2325
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2040
         TabIndex        =   32
         Top             =   2280
         Width           =   1830
      End
      Begin VB.Label LabDebt 
         AutoSize        =   -1  'True
         Caption         =   "˹���Թ��ع���¹"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   810
         TabIndex        =   23
         Top             =   1850
         Width           =   1095
      End
      Begin VB.Label LabPay_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "�������¨�����ǧ˹��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   20
         Top             =   1440
         Width           =   1440
      End
      Begin VB.Label labAst_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ѿ����ع���¹"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   630
         TabIndex        =   12
         Top             =   720
         Width           =   1290
      End
      Begin VB.Label LabCargo_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ҥ���ѧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1020
         TabIndex        =   11
         Top             =   1080
         Width           =   870
      End
      Begin VB.Label LabID_CRatio 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2640
         TabIndex        =   10
         Top             =   360
         Width           =   660
      End
      Begin VB.Label LabName_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4560
         TabIndex        =   9
         Top             =   360
         Width           =   540
      End
      Begin VB.Label LabResult_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ����ǹ�ع��ع���¹ = "
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   8
         Top             =   3165
         Width           =   1740
      End
      Begin VB.Label LabResult2_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4320
         TabIndex        =   7
         Top             =   3165
         Width           =   240
      End
      Begin VB.Label LabMoney_QRatio 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6480
         TabIndex        =   6
         Top             =   375
         Width           =   705
      End
   End
End
Attribute VB_Name = "frmSp_QRatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String

Private Sub CmdCal_QRatio_Click()
    Dim Asset As Double
    Dim Cargo As Double
    Dim pay As Double
    Dim Debt As Double
    Dim result As Double
    
    If ((TxtIDAst.Text = "") Or (TxtIDCargo.Text = "") Or (TxtIDPay.Text = "") Or (TxtIDDebt.Text = "")) Then
        MsgBox "���ʺѭ�����ú��س�����������ó�...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
    Else
        Asset = CDbl(TxtMoneyAst.Text)
        Cargo = CDbl(TxtMoneyCargo.Text)
        pay = CDbl(TxtMoneyPay.Text)
        Debt = CDbl(TxtMoneyDebt.Text)
        result = (Asset - Cargo - pay) / Debt
        TxtResult_QRatio.Text = result
    End If

End Sub

Private Sub CmdClear_QRatio_Click()
          TxtIDAst.Text = ""
          TxtNameAst.Text = ""
          TxtMoneyAst.Text = ""
                            
          TxtIDCargo.Text = ""
          TxtNameCargo.Text = ""
          TxtMoneyCargo.Text = ""
          
          TxtIDDebt.Text = ""
          TxtNameDebt.Text = ""
          TxtMoneyDebt.Text = ""
                            
          TxtIDPay.Text = ""
          TxtNamePay.Text = ""
          TxtMoneyPay.Text = ""
 
          TxtResult_QRatio.Text = ""
 End Sub

Private Sub CmdESC_QRatio_Click()
    Unload Me
    'Form_Liquidity.Show
End Sub

Private Sub check_rs()
            If acc_data.cn_plan.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata recordset
                        acc_data.cn_plan.Close
            End If
End Sub

Function CheckID(cmp As String) As Boolean
     Dim i As Integer
     Dim Sum As Long
     Dim ch As Boolean
     ch = False
     Call check_rs
     acc_data.cn_plan.Open
     acc_data.plan
     Sum = acc_data.rsplan.RecordCount  'total row of plan
     i = 0
     Do While i < Sum
        If cmp = acc_data.rsplan.Fields(0) Then 'check id_account in table plan_account
            ch = True 'have id_account in table plan_account
            Exit Do
        Else:   i = i + 1
                    acc_data.rsplan.MoveNext
        End If
     Loop
     
     If ch = True Then
        Call check_rs
        acc_data.cn_plan.Open
        acc_data.checkSummary
        Sum = acc_data.rscheckSummary.RecordCount  'total row of summary_plan
        i = 0
        Do While i < Sum
            If cmp = acc_data.rscheckSummary.Fields(0) Then
                CheckID = True  'have id_account in table summary_plan_d and g
                Exit Function
            Else:   i = i + 1
                        acc_data.rscheckSummary.MoveNext
            End If
        Loop
        CheckID = False  'have not  id_account in table summary_plan_d and g
     Else: CheckID = False 'have not id_account in table plan_account
     End If
End Function

Private Sub CmdSave_Click()
    If TxtResult_QRatio.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateQRatio CDbl(TxtResult_QRatio.Text)
            TxtResult_QRatio.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_QRatio
End Sub

Private Sub TxtIDAst_DblClick()
        TxtIDAst_LostFocus
        index1 = "1"  'mean Asset field
        index = "1"
        frmPlan_QRatio.Show
        frmPlan_QRatio.SetFocus
End Sub

Private Sub TxtIDAst_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDAst.Text = "") Then
                        TxtIDAst.Text = "" 'id
                        TxtNameAst.Text = "" 'name
                        TxtMoneyAst.Text = "" 'value debit
                        TxtIDAst.SetFocus
                ElseIf CheckID(TxtIDAst.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDAst.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAst.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDAst.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAst.Text
                                                TxtNameAst.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAst.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAst.Text
                                                TxtNameAst.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAst.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtIDCargo.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDAst.Text = ""
                                        TxtNameAst.Text = ""
                                        TxtMoneyAst.Text = ""
                                        TxtIDAst.SetFocus  'key new
                                End If
                        Else
                        TxtNameAst.Text = "" 'name
                        TxtMoneyAst.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDAst.Text = ""
                            TxtNameAst.Text = ""
                            TxtMoneyAst.Text = ""
                            TxtIDAst.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDAst_LostFocus()
       If (TxtIDAst.Text = "") Then
                TxtIDAst.Text = ""
                TxtNameAst.Text = "" 'name
                TxtMoneyAst.Text = "" 'value debit
       ElseIf CheckID(TxtIDAst.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDAst.Text = ""
                TxtNameAst.Text = "" 'name
                TxtMoneyAst.Text = "" 'value debit
       ElseIf (CheckID(TxtIDAst.Text) = True And TxtNameAst.Text = "" And TxtMoneyAst.Text = "") Or (CheckID(TxtIDAst.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAst.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDAst.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAst.Text
                                                TxtNameAst.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAst.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAst.Text
                                                TxtNameAst.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAst.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDCargo.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDAst.Text = ""
                                        TxtNameAst.Text = ""
                                        TxtMoneyAst.Text = ""
                                        TxtIDAst.SetFocus  'key new
                                End If
        End If
 End Sub

Private Sub TxtIDCargo_DblClick()
        TxtIDCargo_LostFocus
        index1 = "1" 'mean Asset field
        index = "2"
        frmPlan_QRatio.Show
End Sub

Private Sub TxtIDCargo_KeyPress(KeyAscii As Integer)
      If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDCargo.Text = "") Then
                        TxtIDCargo.Text = "" 'id
                        TxtNameCargo.Text = "" 'name
                        TxtMoneyCargo.Text = "" 'value debit
                        TxtIDCargo.SetFocus
                ElseIf CheckID(TxtIDCargo.Text) = True Then    'if have id_account in table summary_plan_d and g
                            If TxtIDCargo.Text <> "" Then
                                    Call check_rs
                                    acc_data.cn_plan.Open
                                    acc_data.getType TxtIDCargo.Text
                                    planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                    a$ = Left$(TxtIDCargo.Text, 1) 'check is Asset?
                                                                                            
                                    If a$ = 1 Then  'is Asset
                                            If planType = "D" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanD TxtIDCargo.Text
                                                    TxtNameCatgo.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                    TxtMoneyCargo.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                            ElseIf planType = "G" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanG TxtIDCargo.Text
                                                    TxtNameCargo.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                    TxtMoneyCargo.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                            End If
                                            TxtIDPay.SetFocus
                                    Else  'is't Asset
                                            MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                            TxtIDCargo.Text = ""
                                            TxtNameCargo.Text = ""
                                            TxtMoneyCargo.Text = ""
                                            TxtIDCargo.SetFocus  'key new
                                    End If
                            Else
                                    TxtNameCargo.Text = "" 'name
                                    TxtMoneyCargo.Text = "" 'value debit
                            End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDCargo.Text = ""
                            TxtNameCargo.Text = ""
                            TxtMoneyCargo.Text = ""
                            TxtIDCargo.SetFocus
                End If
     End If
End Sub

Private Sub TxtIDCargo_LostFocus()
       If (TxtIDCargo.Text = "") Then
                TxtIDCargo.Text = ""
                TxtNameCargo.Text = "" 'name
                TxtMoneyCargo.Text = "" 'value debit
       ElseIf CheckID(TxtIDCargo.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDCargo.Text = ""
                TxtNameCargo.Text = "" 'name
                TxtMoneyCargo.Text = "" 'value debit
       ElseIf (CheckID(TxtIDCargo.Text) = True And TxtNameCargo.Text = "" And TxtMoneyCargo.Text = "") Or (CheckID(TxtIDCargo.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDCargo.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDCargo.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDCargo.Text
                                                TxtNameCargo.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyCargo.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDCargo.Text
                                                TxtNameCargo.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyCargo.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDPay.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDCargo.Text = ""
                                        TxtNameCargo.Text = ""
                                        TxtMoneyCargo.Text = ""
                                        TxtIDCargo.SetFocus  'key new
                                End If
        End If
  End Sub

Private Sub TxtIDDebt_DblClick()
        TxtIDDebt_LostFocus
        index1 = "2"  'mean Debt
        index = "4"
        frmPlan_QRatio.Show
End Sub

Private Sub TxtIDDebt_KeyPress(KeyAscii As Integer)
      If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDDebt.Text = "") Then
                        TxtIDDebt.Text = "" 'id
                        TxtNameDebt.Text = "" 'name
                        TxtMoneyDebt.Text = "" 'value debit
                        TxtIDDebt.SetFocus
                ElseIf CheckID(TxtIDDebt.Text) = True Then    'if have id_account in table summary_plan_d and g
                            If TxtIDDebt.Text <> "" Then
                                    Call check_rs
                                    acc_data.cn_plan.Open
                                    acc_data.getType TxtIDDebt.Text
                                    planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                    a$ = Left$(TxtIDDebt.Text, 1) 'check is Debt?
                                                                                            
                                    If a$ = 2 Then  'is Debt
                                            If planType = "D" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanD TxtIDDebt.Text
                                                    TxtNameCatgo.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                    TxtMoneyDebt.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                            ElseIf planType = "G" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanG TxtIDDebt.Text
                                                    TxtNameDebt.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                    TxtMoneyDebt.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                            End If
                                            'CmdCal_QRatio.SetFocus
                                    Else  'is't debt
                                            MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                            TxtIDDebt.Text = ""
                                            TxtNameDebt.Text = ""
                                            TxtMoneyDebt.Text = ""
                                            TxtIDDebt.SetFocus  'key new
                                    End If
                            Else
                                    TxtNameDebt.Text = "" 'name
                                    TxtMoneyDebt.Text = "" 'value credit
                            End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDDebt.Text = ""
                            TxtNameDebt.Text = ""
                            TxtMoneyDebt.Text = ""
                            TxtIDDebt.SetFocus
                End If
     End If
End Sub

Private Sub TxtIDDebt_LostFocus()
       If (TxtIDDebt.Text = "") Then
                TxtIDDebt.Text = ""
                TxtNameDebt.Text = "" 'name
                TxtMoneyDebt.Text = "" 'value crebit
       ElseIf CheckID(TxtIDDebt.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDDebt.Text = ""
                TxtNameDebt.Text = "" 'name
                TxtMoneyDebt.Text = "" 'value credit
       ElseIf (CheckID(TxtIDDebt.Text) = True And TxtNameDebt.Text = "" And TxtMoneyDebt.Text = "") Or (CheckID(TxtIDDebt.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDDebt.Text, 1) 'check is Debt?
                                                                                            
                                If a$ = 2 Then  'is Debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt.Text
                                                TxtNameDebt.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt.Text
                                                TxtNameDebt.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'CmdCal_QRatio.SetFocus
                                Else  'is't Debt
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt.Text = ""
                                        TxtNameDebt.Text = ""
                                        TxtMoneyDebt.Text = ""
                                        TxtIDDebt.SetFocus  'key new
                                End If
        End If
End Sub

Private Sub TxtIDPay_DblClick()
        TxtIDPay_LostFocus
        index1 = "1"  'mean Asset field
        index = "3"
        frmPlan_QRatio.Show
End Sub

Private Sub TxtIDPay_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDPay.Text = "") Then
                        TxtIDPay.Text = "" 'id
                        TxtNamePay.Text = "" 'name
                        TxtMoneyPay.Text = "" 'value debit
                        TxtIDPay.SetFocus
                ElseIf CheckID(TxtIDPay.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDPay.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDPay.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDPay.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDPay.Text
                                                TxtNamePay.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyPay.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDPay.Text
                                                TxtNamePay.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyPay.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtIDDebt.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDPay.Text = ""
                                        TxtNamePay.Text = ""
                                        TxtMoneyPay.Text = ""
                                        TxtIDPay.SetFocus  'key new
                                End If
                        Else
                        TxtNamePay.Text = "" 'name
                        TxtMoneyPay.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDPay.Text = ""
                            TxtNamePay.Text = ""
                            TxtMoneyPay.Text = ""
                            TxtIDPay.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDPay_LostFocus()
       If (TxtIDPay.Text = "") Then
                TxtIDPay.Text = ""
                TxtNamePay.Text = "" 'name
                TxtMoneyPay.Text = "" 'value debit
       ElseIf CheckID(TxtIDPay.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDPay.Text = ""
                TxtNamePay.Text = "" 'name
                TxtMoneyPay.Text = "" 'value debit
       ElseIf (CheckID(TxtIDPay.Text) = True And TxtNamePay.Text = "" And TxtMoneyPay.Text = "") Or (CheckID(TxtIDPay.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDPay.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDPay.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDPay.Text
                                                TxtNamePay.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyPay.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDPay.Text
                                                TxtNamePay.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyPay.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDDebt.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDPay.Text = ""
                                        TxtNamePay.Text = ""
                                        TxtMoneyPay.Text = ""
                                        TxtIDPay.SetFocus  'key new
                                End If
        End If
End Sub
