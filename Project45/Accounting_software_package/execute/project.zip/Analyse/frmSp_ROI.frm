VERSION 5.00
Begin VB.Form frmSp_ROI 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5490
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8745
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_ROI.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5490
   ScaleWidth      =   8745
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_ROI 
      Caption         =   "�ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع (Return on investment, ROI)"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5355
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8475
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6000
         TabIndex        =   21
         Top             =   2590
         Width           =   1935
      End
      Begin VB.PictureBox Pic_ROI 
         Height          =   1695
         Left            =   600
         ScaleHeight     =   1635
         ScaleWidth      =   7395
         TabIndex        =   16
         Top             =   3360
         Width           =   7455
         Begin VB.Label LabAnalyse1_ROI 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   705
            TabIndex        =   20
            Top             =   120
            Width           =   5985
         End
         Begin VB.Label LabAnalyse2_ROI 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�Ңͧ�ص��ˡ�������������ҳ  5.00 %  "
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   2160
            TabIndex        =   19
            Top             =   480
            Width           =   3255
         End
         Begin VB.Label LabAnalyse3_ROI 
            AutoSize        =   -1  'True
            Caption         =   "1.  ��ҹ��¡��� 5.00 �ʴ���� ��áԨ������ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع���"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   1320
            TabIndex        =   18
            Top             =   840
            Width           =   4830
         End
         Begin VB.Label LabAnalyse4_ROI 
            AutoSize        =   -1  'True
            Caption         =   "2.  ����ҡ���� 5.00 �ʴ���� ��áԨ������ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع�٧"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   1320
            TabIndex        =   17
            Top             =   1200
            Width           =   4830
         End
      End
      Begin VB.TextBox TxtMoneyProfit_ROI 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   12
         Top             =   1005
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyAsset_ROI 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6000
         TabIndex        =   11
         Top             =   645
         Width           =   1935
      End
      Begin VB.TextBox TxtIDAsset_ROI 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2160
         TabIndex        =   1
         Top             =   645
         Width           =   1935
      End
      Begin VB.TextBox TxtNameAsset_ROI 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4080
         TabIndex        =   10
         Top             =   645
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_ROI 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6000
         TabIndex        =   9
         Top             =   1470
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_ROI 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6000
         TabIndex        =   8
         Top             =   1845
         Width           =   1935
      End
      Begin VB.CommandButton CmdESC_ROI 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6000
         TabIndex        =   7
         Top             =   2220
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_ROI 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   2640
         TabIndex        =   2
         Top             =   2280
         Width           =   2535
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2160
         TabIndex        =   22
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabID_ROI 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2760
         TabIndex        =   15
         Top             =   360
         Width           =   660
      End
      Begin VB.Label LabName_ROI 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4680
         TabIndex        =   14
         Top             =   360
         Width           =   540
      End
      Begin VB.Label LabMoney_ROI 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6600
         TabIndex        =   13
         Top             =   375
         Width           =   705
      End
      Begin VB.Label LabProfit_ROI 
         AutoSize        =   -1  'True
         Caption         =   "�����ط����ѧ�ѡ����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   600
         TabIndex        =   6
         Top             =   1030
         Width           =   1440
      End
      Begin VB.Label LabAssetl_ROI 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ѿ�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1100
         TabIndex        =   5
         Top             =   680
         Width           =   915
      End
      Begin VB.Label LabResult_ROI 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   360
         TabIndex        =   4
         Top             =   2280
         Width           =   2235
      End
      Begin VB.Label LabPercent_ROI 
         AutoSize        =   -1  'True
         Caption         =   "%"
         Height          =   195
         Left            =   5280
         TabIndex        =   3
         Top             =   2325
         Width           =   120
      End
   End
End
Attribute VB_Name = "frmSp_ROI"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdCal_ROI_Click()
        Dim profit As String
        Dim Asset As String
        Dim result As String
        
        If TxtIDAsset_ROI.Text = "" Then
                MsgBox "���ʺѭ�����ú��س�����������ó�...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        ElseIf IsNumeric(TxtMoneyProfit_ROI.Text) And IsNumeric(TxtMoneyAsset_ROI.Text) Then
                profit = CDbl(TxtMoneyProfit_ROI.Text)
                Asset = CDbl(TxtMoneyAsset_ROI.Text)
                result = profit * 100
                result = result / Asset
                TxtResult_ROI.Text = result
        Else: MsgBox "��سһ�͹�繨ӹǹ����Ţ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
        End If
End Sub

Private Sub CmdClear_ROI_Click()
        TxtIDAsset_ROI.Text = ""
        TxtNameAsset_ROI.Text = ""
        TxtMoneyAsset_ROI.Text = ""
        
        TxtMoneyProfit_ROI.Text = ""
        TxtResult_ROI.Text = ""
End Sub

Private Sub CmdESC_ROI_Click()
           'Form_Profitability.Show
           Unload Me
End Sub

Private Sub CmdSave_Click()
    If TxtResult_ROI.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateROI CDbl(TxtResult_ROI.Text)
            TxtResult_ROI.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If

End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_ROI
End Sub

Private Sub TxtIDAsset_ROI_DblClick()
        TxtIDAsset_ROI_LostFocus
        frmPlan_ROI.Show
End Sub

Private Sub TxtIDAsset_ROI_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDAsset_ROI.Text = "") Then
                        TxtIDAsset_ROI.Text = "" 'id
                        TxtNameAsset_ROI.Text = "" 'name
                        TxtMoneyAsset_ROI.Text = "" 'value debit
                        TxtIDAsset_ROI.SetFocus
                ElseIf CheckID(TxtIDAsset_ROI.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDAsset_ROI.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAsset_ROI.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                a$ = Left$(TxtIDAsset_ROI.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAsset_ROI.Text
                                                TxtNameAsset_ROI.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAsset_ROI.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAsset_ROI.Text
                                                TxtNameAsset_ROI.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAsset_ROI.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtMoneyProfit_ROI.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDAsset_ROI.Text = ""
                                        TxtNameAsset_ROI.Text = ""
                                        TxtMoneyAsset_ROI.Text = ""
                                        TxtIDAsset_ROI.SetFocus  'key new
                                End If
                        Else
                        TxtNameAsset_ROI.Text = "" 'name
                        TxtMoneyAsset_ROI.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDAsset_ROI.Text = ""
                            TxtNameAsset_ROI.Text = ""
                            TxtMoneyAsset_ROI.Text = ""
                            TxtIDAsset_ROI.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDAsset_ROI_LostFocus()
      Dim a As String
      If (TxtIDAsset_ROI.Text = "") Then
                TxtIDAsset_ROI.Text = "" 'id
                TxtNameAsset_ROI.Text = "" 'name
                TxtMoneyAsset_ROI.Text = "" 'value debit
                'TxtIDAsset_ROI.SetFocus
      ElseIf CheckID(TxtIDAsset_ROI.Text) = False Then
                TxtIDAsset_ROI.Text = ""
                TxtNameAsset_ROI.Text = "" 'name
                TxtMoneyAsset_ROI.Text = "" 'value debit
       ElseIf CheckID(TxtIDAsset_ROI.Text) = True Then
                        'And TxtNameAsset_ROI.Text = "" And TxtMoneyAsset_ROI.Text = "" Then
                        If TxtIDAsset_ROI.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAsset_ROI.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDAsset_ROI.Text <> "5") Then
                                    a = Left$(TxtIDAsset_ROI.Text, 1) 'check is Asset?
                                Else: a = "5"
                                End If
                                
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAsset_ROI.Text
                                                TxtNameAsset_ROI.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAsset_ROI.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAsset_ROI.Text
                                                TxtNameAsset_ROI.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAsset_ROI.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtID2_CRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDAsset_ROI.Text = ""
                                        TxtNameAsset_ROI.Text = ""
                                        TxtMoneyAsset_ROI.Text = ""
                                        TxtIDAsset_ROI.SetFocus  'key new
                                End If
                        Else
                        TxtNameAsset_ROI.Text = "" 'name
                        TxtMoneyAsset_ROI.Text = "" 'value debit
                        End If
        End If
End Sub


