VERSION 5.00
Begin VB.Form frmSp_TIE 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5385
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8775
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_TIE.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5385
   ScaleWidth      =   8775
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_TIE 
      Caption         =   "�ѵ����ǹ�ʴ���������ö㹡�è��´͡���� ( Times Interest Earned )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5250
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8520
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6120
         TabIndex        =   20
         Top             =   2550
         Width           =   1935
      End
      Begin VB.PictureBox Pic_TIE 
         Height          =   1695
         Left            =   600
         ScaleHeight     =   1635
         ScaleWidth      =   7395
         TabIndex        =   16
         Top             =   3240
         Width           =   7455
         Begin VB.Label LabAnalyse3_TIE 
            AutoSize        =   -1  'True
            Caption         =   "������٧�ҡ���������дѺ����áԨ���Ҷ������ ������з���͡�������ͧ��áԨ�ҡ�ѡ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   360
            TabIndex        =   19
            Top             =   840
            Width           =   6075
         End
         Begin VB.Label LabAnalyse2_TIE 
            AutoSize        =   -1  'True
            Caption         =   "����դ���ҡ �ʴ���Ҹ�áԨ�ա��ä�͹��ҧ�ҡ����ö���д͡��������§�� ��Ф������´͡����"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   360
            TabIndex        =   18
            Top             =   480
            Width           =   6570
         End
         Begin VB.Label LabAnalyse1_TIE 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ����ǹ�ʴ���������ö㹡�è��´͡����  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   60
            TabIndex        =   17
            Top             =   120
            Width           =   7275
         End
      End
      Begin VB.CommandButton CmdESC_TIE 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6120
         TabIndex        =   5
         Top             =   2170
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_TIE 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6120
         TabIndex        =   4
         Top             =   1795
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_TIE 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6120
         TabIndex        =   3
         Top             =   1430
         Width           =   1935
      End
      Begin VB.TextBox TxtNamePay_TIE 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   8
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDPay_TIE 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyPay_TIE 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   7
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyProfit_TIE 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   2
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_TIE 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   300
         Left            =   3000
         TabIndex        =   6
         Top             =   1920
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2280
         TabIndex        =   21
         Top             =   1320
         Width           =   1830
      End
      Begin VB.Label LabMoney_TIE 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6720
         TabIndex        =   15
         Top             =   330
         Width           =   705
      End
      Begin VB.Label LabPercent_TIE 
         AutoSize        =   -1  'True
         Caption         =   "���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5040
         TabIndex        =   14
         Top             =   1920
         Width           =   240
      End
      Begin VB.Label LabResult_TIE 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ�Ҥ�������ö㹡�è��´͡���� ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   240
         TabIndex        =   13
         Top             =   1920
         Width           =   2640
      End
      Begin VB.Label LabName_TIE 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4800
         TabIndex        =   12
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabID_TIE 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2880
         TabIndex        =   11
         Top             =   315
         Width           =   660
      End
      Begin VB.Label LabPay 
         AutoSize        =   -1  'True
         Caption         =   "�͡���¨���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1395
         TabIndex        =   10
         Top             =   600
         Width           =   780
      End
      Begin VB.Label LabProfit 
         AutoSize        =   -1  'True
         Caption         =   "���á�͹�ѡ�͡�����������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   250
         TabIndex        =   9
         Top             =   960
         Width           =   1905
      End
   End
End
Attribute VB_Name = "frmSp_TIE"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdCal_TIE_Click()
        Dim profit As String
        Dim pay As String
        Dim result As String
        
        If TxtIDPay_TIE.Text = "" Then
                MsgBox "���ʺѭ�����ú��س�����������ó�...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        ElseIf IsNumeric(TxtMoneyProfit_TIE.Text) And IsNumeric(TxtMoneyPay_TIE.Text) Then
                profit = CDbl(TxtMoneyProfit_TIE.Text)
                pay = CDbl(TxtMoneyPay_TIE.Text)
                result = profit / pay
                TxtResult_TIE.Text = result
        Else: MsgBox "��سһ�͹�繨ӹǹ����Ţ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
        End If
End Sub

Private Sub CmdClear_TIE_Click()
        TxtIDPay_TIE.Text = ""
        TxtNamePay_TIE.Text = ""
        TxtMoneyPay_TIE.Text = ""
        
        TxtMoneyProfit_TIE.Text = ""
        TxtResult_TIE.Text = ""
End Sub

Private Sub CmdESC_TIE_Click()
           'Form_Leverage.Show
           Unload Me
End Sub


Private Sub CmdSave_Click()
    If TxtResult_TIE.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateTIE CDbl(TxtResult_TIE.Text)
            TxtResult_TIE.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_TIE
End Sub

Private Sub TxtIDPay_TIE_DblClick()
        TxtIDPay_TIE_LostFocus
        frmPlan_TIE.Show
End Sub

Private Sub TxtIDPay_TIE_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDPay_TIE.Text = "") Then
                        TxtIDPay_TIE.Text = "" 'id
                        TxtNamePay_TIE.Text = "" 'name
                        TxtMoneyPay_TIE.Text = "" 'value debit
                        TxtIDPay_TIE.SetFocus
                ElseIf CheckID(TxtIDPay_TIE.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDPay_TIE.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDPay_TIE.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                a$ = Left$(TxtIDPay_TIE.Text, 1) 'check is pay?
                                                                                            
                                If a$ = "5" Then  'is Pay
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDPay_TIE.Text
                                                TxtNamePay_TIE.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyPay_TIE.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDPay_TIE.Text
                                                TxtNamePay_TIE.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyPay_TIE.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtMoneyProfit_TIE.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ��������...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDPay_TIE.Text = ""
                                        TxtNamePay_TIE.Text = ""
                                        TxtMoneyPay_TIE.Text = ""
                                        TxtIDPay_TIE.SetFocus  'key new
                                End If
                        Else
                        TxtNamePay_TIE.Text = "" 'name
                        TxtMoneyPay_TIE.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDPay_TIE.Text = ""
                            TxtNamePay_TIE.Text = ""
                            TxtMoneyPay_TIE.Text = ""
                            TxtIDPay_TIE.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDPay_TIE_LostFocus()
      Dim a As String
      If (TxtIDPay_TIE.Text = "") Then
                TxtIDPay_TIE.Text = "" 'id
                TxtNamePay_TIE.Text = "" 'name
                TxtMoneyPay_TIE.Text = "" 'value debit
                'TxtIDPay_TIE.SetFocus
      ElseIf CheckID(TxtIDPay_TIE.Text) = False Then
                TxtIDPay_TIE.Text = ""
                TxtNamePay_TIE.Text = "" 'name
                TxtMoneyPay_TIE.Text = "" 'value debit
       ElseIf CheckID(TxtIDPay_TIE.Text) = True Then
                        'And TxtNamePay_TIE.Text = "" And TxtMoneyPay_TIE.Text = "" Then
                        If TxtIDPay_TIE.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDPay_TIE.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDPay_TIE.Text <> "5") Then
                                    a = Left$(TxtIDPay_TIE.Text, 1) 'check is Pay?
                                Else: a = "5"
                                End If
                                
                                If a = "5" Then  'is Pay
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDPay_TIE.Text
                                                TxtNamePay_TIE.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyPay_TIE.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDPay_TIE.Text
                                                TxtNamePay_TIE.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyPay_TIE.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtID2_CRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ��������...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDPay_TIE.Text = ""
                                        TxtNamePay_TIE.Text = ""
                                        TxtMoneyPay_TIE.Text = ""
                                        TxtIDPay_TIE.SetFocus  'key new
                                End If
                        Else
                        TxtNamePay_TIE.Text = "" 'name
                        TxtMoneyPay_TIE.Text = "" 'value debit
                        End If
        End If
End Sub

