VERSION 5.00
Begin VB.Form frmSp_ART 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   7185
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8655
   ControlBox      =   0   'False
   Icon            =   "frmSp_ART.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   7185
   ScaleWidth      =   8655
   ShowInTaskbar   =   0   'False
   Begin VB.TextBox TxtART_ART 
      BackColor       =   &H80000004&
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   330
      Left            =   3120
      TabIndex        =   26
      Top             =   3480
      Width           =   2175
   End
   Begin VB.Frame Fram_ART 
      Caption         =   "�ѵ�ҡ����ع���¹�ͧ�١˹�� ( Account Receivable Turnover )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   7035
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8385
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   5880
         TabIndex        =   36
         Top             =   3440
         Width           =   1935
      End
      Begin VB.PictureBox Pic_ART 
         Height          =   2655
         Left            =   480
         ScaleHeight     =   2595
         ScaleWidth      =   7275
         TabIndex        =   29
         Top             =   4080
         Width           =   7335
         Begin VB.Label LabAnakyse6_ART 
            AutoSize        =   -1  'True
            Caption         =   "���� 1 �� (�Դ 360 �ѹ) ��áԨ����ö���Թ�ҡ�١�����ء� 14.4 �ѹ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   960
            TabIndex        =   35
            Top             =   1920
            Width           =   4905
         End
         Begin VB.Label LabAnalyse5_ART 
            AutoSize        =   -1  'True
            Caption         =   "��ǹ �������������㹡�����Թ�ҡ�١˹���� ���ص��� 14.4 �ѹ ���¤������"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   960
            TabIndex        =   34
            Top             =   1560
            Width           =   5400
         End
         Begin VB.Label LabAnalyse1_ART 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ�ҡ����ع���¹�ͧ�١˹��  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   780
            TabIndex        =   33
            Top             =   120
            Width           =   5835
         End
         Begin VB.Label LabAnalyse2_ART 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�Ңͧ�ص��ˡ�������������ҳ  20.5 �ͺ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   2040
            TabIndex        =   32
            Top             =   480
            Width           =   3270
         End
         Begin VB.Label LabAnalyse3_ART 
            AutoSize        =   -1  'True
            Caption         =   "1.  ��ҹ��¡��� 20.5 �ʴ���� ��áԨ����ö���Թ�ҡ�١������ҡ��Ҥ����������"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   960
            TabIndex        =   31
            Top             =   840
            Width           =   5445
         End
         Begin VB.Label LabAnalyse4_ART 
            AutoSize        =   -1  'True
            Caption         =   "2.  ����ҡ���� 20.5 �ʴ���� ��áԨ����ö���Թ�ҡ�١��������ǡ��Ҥ����������"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   960
            TabIndex        =   30
            Top             =   1200
            Width           =   5475
         End
      End
      Begin VB.CommandButton CmdCal_ART 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   5880
         TabIndex        =   5
         Top             =   2310
         Width           =   1935
      End
      Begin VB.TextBox TxtIDSell_ART 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   1
         Top             =   720
         Width           =   1935
      End
      Begin VB.TextBox TxtNameSell_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   16
         Top             =   720
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneySell_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   15
         Top             =   720
         Width           =   1935
      End
      Begin VB.TextBox TxtIDDebt1_ART 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   2
         Top             =   1080
         Width           =   1935
      End
      Begin VB.TextBox TxtNameDebt1_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   14
         Top             =   1080
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyDebt1_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   13
         Top             =   1080
         Width           =   1935
      End
      Begin VB.TextBox TxtIDDebt2_ART 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   3
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtNameDebt2_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   12
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyDebt2_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   11
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   3000
         TabIndex        =   10
         Top             =   3120
         Width           =   2175
      End
      Begin VB.TextBox TxtIDDebt3_ART 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2040
         TabIndex        =   4
         Top             =   1800
         Width           =   1935
      End
      Begin VB.TextBox TxtNameDebt3_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   3960
         TabIndex        =   9
         Top             =   1800
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyDebt3_ART 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         TabIndex        =   8
         Top             =   1800
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_ART 
         Caption         =   "Clear"
         Height          =   375
         Left            =   5880
         TabIndex        =   6
         Top             =   2690
         Width           =   1935
      End
      Begin VB.CommandButton CmdESC_ART 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   5880
         TabIndex        =   7
         Top             =   3055
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2040
         TabIndex        =   37
         Top             =   2280
         Width           =   1830
      End
      Begin VB.Label LabART_ART 
         AutoSize        =   -1  'True
         Caption         =   "�ͺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5200
         TabIndex        =   28
         Top             =   3480
         Width           =   285
      End
      Begin VB.Label LabART 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ�ҡ����ع���¹�ͧ�١˹�� ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   840
         TabIndex        =   27
         Top             =   3480
         Width           =   2115
      End
      Begin VB.Label LabMoney_ART 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6480
         TabIndex        =   25
         Top             =   375
         Width           =   705
      End
      Begin VB.Label LabResult2_ART 
         AutoSize        =   -1  'True
         Caption         =   "�ѹ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5200
         TabIndex        =   24
         Top             =   3150
         Width           =   195
      End
      Begin VB.Label LabResult_ART 
         AutoSize        =   -1  'True
         Caption         =   "�������������㹡�����Թ�ҡ�١˹�� ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   240
         TabIndex        =   23
         Top             =   3165
         Width           =   2730
      End
      Begin VB.Label LabName_ART 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4560
         TabIndex        =   22
         Top             =   360
         Width           =   540
      End
      Begin VB.Label LabID_ART 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2640
         TabIndex        =   21
         Top             =   360
         Width           =   660
      End
      Begin VB.Label LabDebt1_ART 
         AutoSize        =   -1  'True
         Caption         =   "�١˹���ä��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1020
         TabIndex        =   20
         Top             =   1080
         Width           =   840
      End
      Begin VB.Label labSell_ART 
         AutoSize        =   -1  'True
         Caption         =   "��Ң������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1200
         TabIndex        =   19
         Top             =   720
         Width           =   690
      End
      Begin VB.Label LabDebt2_ART 
         AutoSize        =   -1  'True
         Caption         =   "�١˹����þҡ�"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   800
         TabIndex        =   18
         Top             =   1440
         Width           =   1065
      End
      Begin VB.Label LabDebt3_ART 
         AutoSize        =   -1  'True
         Caption         =   "�١˹��������"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   820
         TabIndex        =   17
         Top             =   1845
         Width           =   1035
      End
   End
End
Attribute VB_Name = "frmSp_ART"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String

Private Sub CmdCal_ART_Click()
    Dim Sell As Double
    Dim Debt1_ART As Double
    Dim Debt3_ART As Double
    Dim Debt2_ART As Double
    Dim result As Double
    
    If ((TxtIDSell_ART.Text = "") Or (TxtIDDebt1_ART.Text = "") Or (TxtIDDebt3_ART.Text = "") Or (TxtIDDebt2_ART.Text = "")) Then
        MsgBox "���ʺѭ�����ú��س�����������ó�...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
    Else
        Sell = CDbl(TxtMoneySell_ART.Text)
        Debt1_ART = CDbl(TxtMoneyDebt1_ART.Text)
        Debt3_ART = CDbl(TxtMoneyDebt3_ART.Text)
        Debt2_ART = CDbl(TxtMoneyDebt2_ART.Text)
        result = Debt1_ART + Debt3_ART + Debt2_ART
        result = Sell / result
        TxtART_ART.Text = result
        result = 360 / result
        TxtResult_ART.Text = result
    End If

End Sub

Private Sub CmdClear_ART_Click()
          TxtIDSell_ART.Text = ""
          TxtNameSell_ART.Text = ""
          TxtMoneySell_ART.Text = ""
                            
          TxtIDDebt1_ART.Text = ""
          TxtNameDebt1_ART.Text = ""
          TxtMoneyDebt1_ART.Text = ""
          
          TxtIDDebt2_ART.Text = ""
          TxtNameDebt2_ART.Text = ""
          TxtMoneyDebt2_ART.Text = ""
                            
          TxtIDDebt3_ART.Text = ""
          TxtNameDebt3_ART.Text = ""
          TxtMoneyDebt3_ART.Text = ""
 
          TxtResult_ART.Text = ""
          TxtART_ART.Text = ""
 End Sub

Private Sub CmdESC_ART_Click()
    Unload Me
    'Form_Activity.Show
End Sub

Private Sub CmdSave_Click()
    If TxtResult_ART.Text <> "" And TxtART_ART.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateART CDbl(TxtResult_ART.Text), CDbl(TxtART_ART.Text)
            
            TxtResult_ART.Text = ""
            TxtART_ART.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If

End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_ART
End Sub

Private Sub TxtIDSell_ART_DblClick()
        TxtIDSell_ART_LostFocus
        index1 = "4"  'mean revenue
        index = "1"
        frmPlan_ART.Show
        frmPlan_ART.SetFocus
End Sub

Private Sub TxtIDSell_ART_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDSell_ART.Text = "") Then
                        TxtIDSell_ART.Text = "" 'id
                        TxtNameSell_ART.Text = "" 'name
                        TxtMoneySell_ART.Text = "" 'value debit
                        TxtIDSell_ART.SetFocus
                ElseIf CheckID(TxtIDSell_ART.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDSell_ART.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDSell_ART.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDSell_ART.Text, 1) 'check is revenue?
                                                                                            
                                If a$ = 4 Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDSell_ART.Text
                                                TxtNameSell_ART.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_ART.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDSell_ART.Text
                                                TxtNameSell_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_ART.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        TxtIDDebt1_ART.SetFocus
                                Else  'is't revenue
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�����...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDSell_ART.Text = ""
                                        TxtNameSell_ART.Text = ""
                                        TxtMoneySell_ART.Text = ""
                                        TxtIDSell_ART.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_ART.Text = "" 'name
                        TxtMoneySell_ART.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDSell_ART.Text = ""
                            TxtNameSell_ART.Text = ""
                            TxtMoneySell_ART.Text = ""
                            TxtIDSell_ART.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDSell_ART_LostFocus()
       If (TxtIDSell_ART.Text = "") Then
                TxtIDSell_ART.Text = ""
                TxtNameSell_ART.Text = "" 'name
                TxtMoneySell_ART.Text = "" 'value debit
       ElseIf CheckID(TxtIDSell_ART.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDSell_ART.Text = ""
                TxtNameSell_ART.Text = "" 'name
                TxtMoneySell_ART.Text = "" 'value debit
       ElseIf (CheckID(TxtIDSell_ART.Text) = True And TxtNameSell_ART.Text = "" And TxtMoneySell_ART.Text = "") Or (CheckID(TxtIDSell_ART.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDSell_ART.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDSell_ART.Text, 1) 'check is revenue?
                                                                                            
                                If a$ = 4 Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDSell_ART.Text
                                                TxtNameSell_ART.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_ART.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDSell_ART.Text
                                                TxtNameSell_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_ART.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'TxtIDDebt1_ART.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDSell_ART.Text = ""
                                        TxtNameSell_ART.Text = ""
                                        TxtMoneySell_ART.Text = ""
                                        TxtIDSell_ART.SetFocus  'key new
                                End If
        End If
 End Sub

Private Sub TxtIDDebt1_ART_DblClick()
        TxtIDDebt1_ART_LostFocus
        index1 = "1" 'mean Asset
        index = "2"
        frmPlan_ART.Show
End Sub

Private Sub TxtIDDebt1_ART_KeyPress(KeyAscii As Integer)
      If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDDebt1_ART.Text = "") Then
                        TxtIDDebt1_ART.Text = "" 'id
                        TxtNameDebt1_ART.Text = "" 'name
                        TxtMoneyDebt1_ART.Text = "" 'value debit
                        TxtIDDebt1_ART.SetFocus
                ElseIf CheckID(TxtIDDebt1_ART.Text) = True Then    'if have id_account in table summary_plan_d and g
                            If TxtIDDebt1_ART.Text <> "" Then
                                    Call check_rs
                                    acc_data.cn_plan.Open
                                    acc_data.getType TxtIDDebt1_ART.Text
                                    planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                    a$ = Left$(TxtIDDebt1_ART.Text, 1) 'check is Asset?
                                                                                            
                                    If a$ = 1 Then  'is Asset
                                            If planType = "D" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanD TxtIDDebt1_ART.Text
                                                    TxtNameCatgo.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                    TxtMoneyDebt1_ART.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                            ElseIf planType = "G" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanG TxtIDDebt1_ART.Text
                                                    TxtNameDebt1_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                    TxtMoneyDebt1_ART.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                            End If
                                            TxtIDDebt3_ART.SetFocus
                                    Else  'is't Asset
                                            MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                            TxtIDDebt1_ART.Text = ""
                                            TxtNameDebt1_ART.Text = ""
                                            TxtMoneyDebt1_ART.Text = ""
                                            TxtIDDebt1_ART.SetFocus  'key new
                                    End If
                            Else
                                    TxtNameDebt1_ART.Text = "" 'name
                                    TxtMoneyDebt1_ART.Text = "" 'value debit
                            End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDDebt1_ART.Text = ""
                            TxtNameDebt1_ART.Text = ""
                            TxtMoneyDebt1_ART.Text = ""
                            TxtIDDebt1_ART.SetFocus
                End If
     End If
End Sub

Private Sub TxtIDDebt1_ART_LostFocus()
       If (TxtIDDebt1_ART.Text = "") Then
                TxtIDDebt1_ART.Text = ""
                TxtNameDebt1_ART.Text = "" 'name
                TxtMoneyDebt1_ART.Text = "" 'value debit
       ElseIf CheckID(TxtIDDebt1_ART.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDDebt1_ART.Text = ""
                TxtNameDebt1_ART.Text = "" 'name
                TxtMoneyDebt1_ART.Text = "" 'value debit
       ElseIf (CheckID(TxtIDDebt1_ART.Text) = True And TxtNameDebt1_ART.Text = "" And TxtMoneyDebt1_ART.Text = "") Or (CheckID(TxtIDDebt1_ART.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt1_ART.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDDebt1_ART.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt1_ART.Text
                                                TxtNameDebt1_ART.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt1_ART.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt1_ART.Text
                                                TxtNameDebt1_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt1_ART.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDDebt3_ART.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt1_ART.Text = ""
                                        TxtNameDebt1_ART.Text = ""
                                        TxtMoneyDebt1_ART.Text = ""
                                        TxtIDDebt1_ART.SetFocus  'key new
                                End If
        End If
  End Sub

Private Sub TxtIDDebt2_ART_DblClick()
        TxtIDDebt2_ART_LostFocus
        index1 = "1" 'mean Asset
        index = "3"
        frmPlan_ART.Show
End Sub

Private Sub TxtIDDebt2_ART_KeyPress(KeyAscii As Integer)
      If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDDebt2_ART.Text = "") Then
                        TxtIDDebt2_ART.Text = "" 'id
                        TxtNameDebt2_ART.Text = "" 'name
                        TxtMoneyDebt2_ART.Text = "" 'value debit
                        TxtIDDebt2_ART.SetFocus
                ElseIf CheckID(TxtIDDebt2_ART.Text) = True Then    'if have id_account in table summary_plan_d and g
                            If TxtIDDebt2_ART.Text <> "" Then
                                    Call check_rs
                                    acc_data.cn_plan.Open
                                    acc_data.getType TxtIDDebt2_ART.Text
                                    planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                    a$ = Left$(TxtIDDebt2_ART.Text, 1) 'check is Asset?
                                                                                            
                                    If a$ = 1 Then  'is Asset
                                            If planType = "D" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanD TxtIDDebt2_ART.Text
                                                    TxtNameCatgo.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                    TxtMoneyDebt2_ART.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                            ElseIf planType = "G" Then
                                                    Call check_rs
                                                    acc_data.cn_plan.Open
                                                    acc_data.getPlanG TxtIDDebt2_ART.Text
                                                    TxtNameDebt2_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                    TxtMoneyDebt2_ART.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                            End If
                                            CmdCal_ART.SetFocus
                                    Else  'is't Debt2_ART
                                            MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                            TxtIDDebt2_ART.Text = ""
                                            TxtNameDebt2_ART.Text = ""
                                            TxtMoneyDebt2_ART.Text = ""
                                            TxtIDDebt2_ART.SetFocus  'key new
                                    End If
                            Else
                                    TxtNameDebt2_ART.Text = "" 'name
                                    TxtMoneyDebt2_ART.Text = "" 'value credit
                            End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDDebt2_ART.Text = ""
                            TxtNameDebt2_ART.Text = ""
                            TxtMoneyDebt2_ART.Text = ""
                            TxtIDDebt2_ART.SetFocus
                End If
     End If
End Sub

Private Sub TxtIDDebt2_ART_LostFocus()
       If (TxtIDDebt2_ART.Text = "") Then
                TxtIDDebt2_ART.Text = ""
                TxtNameDebt2_ART.Text = "" 'name
                TxtMoneyDebt2_ART.Text = "" 'value crebit
       ElseIf CheckID(TxtIDDebt2_ART.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDDebt2_ART.Text = ""
                TxtNameDebt2_ART.Text = "" 'name
                TxtMoneyDebt2_ART.Text = "" 'value credit
       ElseIf (CheckID(TxtIDDebt2_ART.Text) = True And TxtNameDebt2_ART.Text = "" And TxtMoneyDebt2_ART.Text = "") Or (CheckID(TxtIDDebt2_ART.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt2_ART.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDDebt2_ART.Text, 1) 'check is asset?
                                                                                            
                                If a$ = 1 Then  'is asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt2_ART.Text
                                                TxtNameDebt2_ART.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt2_ART.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt2_ART.Text
                                                TxtNameDebt2_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt2_ART.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'CmdCal_ART.SetFocus
                                Else  'is't Debt2_ART
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt2_ART.Text = ""
                                        TxtNameDebt2_ART.Text = ""
                                        TxtMoneyDebt2_ART.Text = ""
                                        TxtIDDebt2_ART.SetFocus  'key new
                                End If
        End If
End Sub

Private Sub TxtIDDebt3_ART_DblClick()
        TxtIDDebt3_ART_LostFocus
        index1 = "1" 'mean asset
        index = "4"
        frmPlan_ART.Show
End Sub

Private Sub TxtIDDebt3_ART_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDDebt3_ART.Text = "") Then
                        TxtIDDebt3_ART.Text = "" 'id
                        TxtNameDebt3_ART.Text = "" 'name
                        TxtMoneyDebt3_ART.Text = "" 'value debit
                        TxtIDDebt3_ART.SetFocus
                ElseIf CheckID(TxtIDDebt3_ART.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDDebt3_ART.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt3_ART.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDDebt3_ART.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt3_ART.Text
                                                TxtNameDebt3_ART.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt3_ART.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt3_ART.Text
                                                TxtNameDebt3_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt3_ART.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtIDDebt2_ART.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt3_ART.Text = ""
                                        TxtNameDebt3_ART.Text = ""
                                        TxtMoneyDebt3_ART.Text = ""
                                        TxtIDDebt3_ART.SetFocus  'key new
                                End If
                        Else
                        TxtNameDebt3_ART.Text = "" 'name
                        TxtMoneyDebt3_ART.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDDebt3_ART.Text = ""
                            TxtNameDebt3_ART.Text = ""
                            TxtMoneyDebt3_ART.Text = ""
                            TxtIDDebt3_ART.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDDebt3_ART_LostFocus()
       If (TxtIDDebt3_ART.Text = "") Then
                TxtIDDebt3_ART.Text = ""
                TxtNameDebt3_ART.Text = "" 'name
                TxtMoneyDebt3_ART.Text = "" 'value debit
       ElseIf CheckID(TxtIDDebt3_ART.Text) = False Then
                MsgBox "�ѭ�չ������㹼ѧ�ѭ�����ѧ�������¡���Դ��� ���� �����㹼ѧ�ѭ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                TxtIDDebt3_ART.Text = ""
                TxtNameDebt3_ART.Text = "" 'name
                TxtMoneyDebt3_ART.Text = "" 'value debit
       ElseIf (CheckID(TxtIDDebt3_ART.Text) = True And TxtNameDebt3_ART.Text = "" And TxtMoneyDebt3_ART.Text = "") Or (CheckID(TxtIDDebt3_ART.Text) = True) Then
                                Dim planType As String
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt3_ART.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type
                                a$ = Left$(TxtIDDebt3_ART.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = 1 Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt3_ART.Text
                                                TxtNameDebt3_ART.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt3_ART.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt3_ART.Text
                                                TxtNameDebt3_ART.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt3_ART.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDDebt2_ART.SetFocus
                                Else  'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt3_ART.Text = ""
                                        TxtNameDebt3_ART.Text = ""
                                        TxtMoneyDebt3_ART.Text = ""
                                        TxtIDDebt3_ART.SetFocus  'key new
                                End If
        End If
End Sub

