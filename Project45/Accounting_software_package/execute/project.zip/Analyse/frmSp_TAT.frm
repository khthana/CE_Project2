VERSION 5.00
Begin VB.Form frmSp_TAT 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5880
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8760
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_TAT.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5880
   ScaleWidth      =   8760
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_TAT 
      Caption         =   "�ѵ�ҡ����ع���¹�ͧ�Թ��Ѿ����� ( Total asset turnover )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5730
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8520
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6120
         TabIndex        =   6
         Top             =   2530
         Width           =   1935
      End
      Begin VB.PictureBox Pic_TAT 
         Height          =   2055
         Left            =   480
         ScaleHeight     =   1995
         ScaleWidth      =   7515
         TabIndex        =   19
         Top             =   3360
         Width           =   7575
         Begin VB.Label LabAnalyse5_TAT 
            AutoSize        =   -1  'True
            Caption         =   "��Ѿ���������������������Դ����������Ԩ�����ҷ����"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   23
            Top             =   1320
            Width           =   3690
         End
         Begin VB.Label LabAnalyse1_TAT 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ�ҡ����ع���¹�ͧ�Թ��Ѿ�����  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   480
            TabIndex        =   22
            Top             =   120
            Width           =   6435
         End
         Begin VB.Label LabAnalyse3_TAT 
            AutoSize        =   -1  'True
            Caption         =   "���ص����ѵ����ҡѺ 0.275 �ͺ ���¤�������Թ��Ѿ��������Ԩ���������������Դ��â��"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   21
            Top             =   600
            Width           =   6105
         End
         Begin VB.Label LabAnalyse4_TAT 
            AutoSize        =   -1  'True
            Caption         =   "0.275 ���駵�ͻ� ����ʴ���ҡԨ����ѧ���Թ��Ѿ�����ҧ����ջ���Է���Ҿ�ѡ �����ʹ�Թ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   20
            Top             =   960
            Width           =   6000
         End
      End
      Begin VB.TextBox TxtResult_TAT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   2880
         TabIndex        =   11
         Top             =   2160
         Width           =   2295
      End
      Begin VB.TextBox TxtNameasset_TAT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   10
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyAsset_TAT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   9
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneySell_TAT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   8
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDAsset_TAT 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   2
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtIDsell_TAT 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtNameSell_TAT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   7
         Top             =   600
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_TAT 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6120
         TabIndex        =   3
         Top             =   1430
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_TAT 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6120
         TabIndex        =   4
         Top             =   1795
         Width           =   1935
      End
      Begin VB.CommandButton CmdESC_TAT 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6120
         TabIndex        =   5
         Top             =   2160
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2280
         TabIndex        =   24
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabSell_TAT 
         AutoSize        =   -1  'True
         Caption         =   "������â��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1200
         TabIndex        =   18
         Top             =   660
         Width           =   960
      End
      Begin VB.Label LabAsset_TAT 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ѿ�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1250
         TabIndex        =   17
         Top             =   990
         Width           =   915
      End
      Begin VB.Label LabID_TAT 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2880
         TabIndex        =   16
         Top             =   315
         Width           =   660
      End
      Begin VB.Label LabName_TAT 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4800
         TabIndex        =   15
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabResult_TAT 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ����ع���¹�ͧ�Թ��Ѿ����� ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   14
         Top             =   2160
         Width           =   2370
      End
      Begin VB.Label LabPercent_TAT 
         AutoSize        =   -1  'True
         Caption         =   "�ͺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5205
         TabIndex        =   13
         Top             =   2205
         Width           =   285
      End
      Begin VB.Label LabMoney_TAT 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6720
         TabIndex        =   12
         Top             =   330
         Width           =   705
      End
   End
End
Attribute VB_Name = "frmSp_TAT"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String

Private Sub CmdCal_TAT_Click()
    Dim num1 As Double
    Dim num2 As Double
    Dim result As Double
    
    If ((TxtMoneySell_TAT.Text = "") Or (TxtMoneyAsset_TAT.Text = "") Or (TxtMoneySell_TAT.Text = "" And TxtMoneyAsset_TAT.Text = "")) Then
        MsgBox "�ӹǹ�Թ�Դ��Ҵ��س�����������ó�...!!! ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
    ElseIf ((TxtIDsell_TAT.Text = "") Or (TxtIDAsset_TAT.Text = "") Or (TxtIDsell_TAT.Text = "" And TxtIDAsset_TAT.Text = "")) Then
        MsgBox "���ʼԴ��Ҵ��س�����������ó�...!!!", vbCritical + vbOKOnly, "���ʼԴ��Ҵ"
    Else
        num1 = CDbl(TxtMoneySell_TAT.Text)
        num2 = CDbl(TxtMoneyAsset_TAT.Text)
        result = num2 * 100
        If num1 <> 0 Then
            result = result / num1
            TxtResult_TAT.Text = result
        Else:  MsgBox "������â���դ���� 0 �������ö�ӹǳ��", vbInformation + vbOKOnly, "Warning"
        End If
    End If
End Sub

Private Sub CmdClear_TAT_Click()
        TxtIDsell_TAT.Text = "" 'id
        TxtNameSell_TAT.Text = "" 'name
        TxtMoneySell_TAT.Text = "" 'value debit
        
        TxtIDAsset_TAT.Text = "" 'id
        TxtNameasset_TAT.Text = "" 'name
        TxtMoneyAsset_TAT.Text = "" 'value debit
        
        TxtResult_TAT.Text = ""
End Sub

Private Sub CmdESC_TAT_Click()
    Unload Me
   'Form_Activity.Show
End Sub

Private Sub CmdSave_Click()
    If TxtResult_TAT.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateTAT CDbl(TxtResult_TAT.Text)
            TxtResult_TAT.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_TAT
End Sub

Private Sub TxtIDSell_TAT_DblClick()
            TxtIDSell_TAT_LostFocus
            index1 = "4" 'mean Revenue
            index = "1"
            frmPlan_TAT.Show
End Sub

Private Sub TxtIDSell_TAT_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDsell_TAT.Text = "") Then
                        TxtIDsell_TAT.Text = "" 'id
                        TxtNameSell_TAT.Text = "" 'name
                        TxtMoneySell_TAT.Text = "" 'value debit
                        TxtIDsell_TAT.SetFocus
                ElseIf CheckID(TxtIDsell_TAT.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDsell_TAT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDsell_TAT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDsell_TAT.Text, 1) 'check is revenue?
                                                                                            
                                If a$ = "4" Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDsell_TAT.Text
                                                TxtNameSell_TAT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_TAT.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDsell_TAT.Text
                                                TxtNameSell_TAT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_TAT.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        TxtIDAsset_TAT.SetFocus  'next text box
                                Else 'is't revenue
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�����...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDsell_TAT.Text = ""
                                        TxtNameSell_TAT.Text = ""
                                        TxtMoneySell_TAT.Text = ""
                                        TxtIDsell_TAT.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_TAT.Text = "" 'name
                        TxtMoneySell_TAT.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDsell_TAT.Text = ""
                            TxtNameSell_TAT.Text = ""
                            TxtMoneySell_TAT.Text = ""
                            TxtIDsell_TAT.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDSell_TAT_LostFocus()
      Dim a As String
      If (TxtIDsell_TAT.Text = "") Then
                TxtIDsell_TAT.Text = "" 'id
                TxtNameSell_TAT.Text = "" 'name
                TxtMoneySell_TAT.Text = "" 'value debit
                'TxtIDSell_TAT.SetFocus
      ElseIf CheckID(TxtIDsell_TAT.Text) = False Then
                TxtIDsell_TAT.Text = ""
                TxtNameSell_TAT.Text = "" 'name
                TxtMoneySell_TAT.Text = "" 'value debit
       ElseIf CheckID(TxtIDsell_TAT.Text) = True Then
                    'And  ( _
                    '(TxtNameSell_TAT.Text = "" And TxtMoneySell_TAT.Text = "") or _
                    '(TxtNameSell_TAT.Text = "" And TxtMoneySell_TAT.Text = "")Then
                        If TxtIDsell_TAT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDsell_TAT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDsell_TAT.Text <> "4") Then
                                    a = Left$(TxtIDsell_TAT.Text, 1) 'check is revenue?
                                Else: a = "4"
                                End If
                                                                                            
                                If a = "4" Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDsell_TAT.Text
                                                TxtNameSell_TAT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_TAT.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDsell_TAT.Text
                                                TxtNameSell_TAT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_TAT.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'TxtIDAsset_TAT.SetFocus  'next text box
                                Else 'is't revenue
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�����...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDsell_TAT.Text = ""
                                        TxtNameSell_TAT.Text = ""
                                        TxtMoneySell_TAT.Text = ""
                                        TxtIDsell_TAT.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_TAT.Text = "" 'name
                        TxtMoneySell_TAT.Text = "" 'value debit
                        End If
        End If
End Sub

Private Sub TxtIDAsset_TAT_DblClick()
        TxtIDAsset_TAT_LostFocus
        index1 = "1" 'mean Asset
        index = "2"
        frmPlan_TAT.Show
End Sub

Private Sub TxtIDAsset_TAT_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDAsset_TAT.Text = "") Then
                        TxtIDAsset_TAT.Text = "" 'id
                        TxtNameasset_TAT.Text = "" 'name
                        TxtMoneyAsset_TAT.Text = "" 'value debit
                        TxtIDAsset_TAT.SetFocus
                ElseIf CheckID(TxtIDAsset_TAT.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDAsset_TAT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAsset_TAT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDAsset_TAT.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAsset_TAT.Text
                                                TxtNameasset_TAT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAsset_TAT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAsset_TAT.Text
                                                TxtNameasset_TAT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAsset_TAT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'CmdCal_TAT.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDAsset_TAT.Text = ""
                                        TxtNameasset_TAT.Text = ""
                                        TxtMoneyAsset_TAT.Text = ""
                                        TxtIDAsset_TAT.SetFocus  'key new
                                End If
                        Else
                        TxtNameasset_TAT.Text = "" 'name
                        TxtMoneyAsset_TAT.Text = "" 'value debit
                        End If
                Else: MsgBox "���ʺѭ�չ�����������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDAsset_TAT.Text = ""
                            TxtNameasset_TAT.Text = ""
                            TxtMoneyAsset_TAT.Text = ""
                            TxtIDAsset_TAT.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDAsset_TAT_LostFocus()
       Dim a As String
       If (TxtIDAsset_TAT.Text = "") Then
                TxtIDAsset_TAT.Text = "" 'id
                TxtNameasset_TAT.Text = "" 'name
                TxtMoneyAsset_TAT.Text = "" 'value debit
                'TxtIDSell_TAT.SetFocus
       ElseIf CheckID(TxtIDAsset_TAT.Text) = False Then
                TxtIDAsset_TAT.Text = ""
                TxtNameasset_TAT.Text = "" 'name
                TxtMoneyAsset_TAT.Text = "" 'value debit
       ElseIf CheckID(TxtIDAsset_TAT.Text) = True Then
                        'And TxtNameAsset_TAT.Text = "" And TxtMoneyAsset_TAT.Text = "" Then
                        If TxtIDAsset_TAT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAsset_TAT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDAsset_TAT.Text <> "1") Then
                                    a = Left$(TxtIDAsset_TAT.Text, 1) 'check is Asset?
                                Else: a = "1"
                                End If
                                                                                            
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAsset_TAT.Text
                                                TxtNameasset_TAT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAsset_TAT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAsset_TAT.Text
                                                TxtNameasset_TAT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAsset_TAT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'Cmd_Cal.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDAsset_TAT.Text = ""
                                        TxtNameasset_TAT.Text = ""
                                        TxtMoneyAsset_TAT.Text = ""
                                        TxtIDAsset_TAT.SetFocus  'key new
                                End If
                        Else
                        TxtNameasset_TAT.Text = "" 'name
                        TxtMoneyAsset_TAT.Text = "" 'value debit
                        End If
        End If
End Sub


