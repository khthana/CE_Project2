VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form frmPlan_IT 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   4425
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   4215
   ControlBox      =   0   'False
   Icon            =   "frmPlan_IT.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4425
   ScaleWidth      =   4215
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC_IT 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   2880
      TabIndex        =   0
      Top             =   4030
      Width           =   1335
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MFGridPlan_IT 
      Height          =   3975
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   7011
      _Version        =   393216
      BackColor       =   -2147483624
      Rows            =   17
      Cols            =   3
      FixedCols       =   0
      AllowBigSelection=   0   'False
      BandDisplay     =   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   3
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "�Ѻ��Ť�ԡ��� ���ʺѭ��"
      ForeColor       =   &H000000FF&
      Height          =   195
      Left            =   0
      TabIndex        =   2
      Top             =   4080
      Width           =   1560
   End
End
Attribute VB_Name = "frmPlan_IT"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub CmdESC_IT_Click()
        frmSp_IT.Show
        Unload Me
End Sub

Private Sub Show_Plan()
     Dim i As Integer
     Dim Sum As Integer
     Call check_rs
     acc_data.cn_plan.Open
     If frmSp_IT.index1 = "1" Then
        acc_data.SelectAsset
        Sum = acc_data.rsSelectAsset.RecordCount  'total row of plan
        MFGridPlan_IT.Rows = Sum + 1
        
        MFGridPlan_IT.ColWidth(1) = 2000
        MFGridPlan_IT.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_IT.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_IT.TextMatrix(0, 2) = "��Դ�ѭ��"
     
        i = 0
        Do While i < Sum
            MFGridPlan_IT.TextMatrix(i + 1, 0) = acc_data.rsSelectAsset.Fields(0) 'check id_account in table plan_account
            MFGridPlan_IT.TextMatrix(i + 1, 1) = acc_data.rsSelectAsset.Fields(1) 'check name_account in table plan_account
            MFGridPlan_IT.TextMatrix(i + 1, 2) = acc_data.rsSelectAsset.Fields(3) 'check type_account in table plan_account
            i = i + 1
            acc_data.rsSelectAsset.MoveNext
        Loop
    ElseIf frmSp_IT.index1 = "5" Then
        acc_data.SelectExpenses
        Sum = acc_data.rsSelectExpenses.RecordCount  'total row of plan
        MFGridPlan_IT.Rows = Sum + 1
        
        MFGridPlan_IT.ColWidth(1) = 2000
        MFGridPlan_IT.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_IT.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_IT.TextMatrix(0, 2) = "��Դ�ѭ��"
     
        i = 0
        Do While i < Sum
            MFGridPlan_IT.TextMatrix(i + 1, 0) = acc_data.rsSelectExpenses.Fields(0) 'check id_account in table plan_account
            MFGridPlan_IT.TextMatrix(i + 1, 1) = acc_data.rsSelectExpenses.Fields(1) 'check name_account in table plan_account
            MFGridPlan_IT.TextMatrix(i + 1, 2) = acc_data.rsSelectExpenses.Fields(3) 'check type_account in table plan_account
            i = i + 1
            acc_data.rsSelectExpenses.MoveNext
        Loop
    End If
End Sub

Private Sub Form_Load()
        Show_Plan
End Sub

Private Sub MFGridPlan_IT_DblClick()
        Dim col As String
        Dim row As String
        Dim planType As String
        Dim a As String
        
        If CheckID(MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)) Then  'get ID_account
                If frmSp_IT.index = "1" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0), 1) 'check is expenses?
                                                                                            
                                If a = "5" Then  'is expenses
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)
                                                frmSp_IT.TxtIDsell_IT.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_IT.TxtNameSell_IT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_IT.TxtMoneySell_IT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)
                                                frmSp_IT.TxtIDsell_IT.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_IT.TxtNameSell_IT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_IT.TxtMoneySell_IT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        Unload Me
                                Else 'is't Sell
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ��������...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                ElseIf frmSp_IT.index = "2" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0), 1) 'check is Cargo?
                                                                                            
                                If a = "1" Then  'is Cargo
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)
                                                frmSp_IT.TxtIDCargo_IT.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_IT.TxtNameCargo_IT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_IT.TxtMoneyCargo_IT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_IT.TextMatrix(CInt(MFGridPlan_IT.row), 0)
                                                frmSp_IT.TxtIDCargo_IT.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_IT.TxtNameCargo_IT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_IT.TxtMoneyCargo_IT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        Unload Me
                                Else 'is't Sell
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                End If
        Else
                MsgBox "���ʺѭ�չ���������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        End If
End Sub


