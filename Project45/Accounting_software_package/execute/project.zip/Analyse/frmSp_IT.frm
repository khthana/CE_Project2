VERSION 5.00
Begin VB.Form frmSp_IT 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   6375
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8760
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_IT.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6375
   ScaleWidth      =   8760
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_IT 
      Caption         =   "�ѵ�ҡ����ع���¹�ͧ�Թ��Ҥ���ѧ ( Inventory Turnover )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6210
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8520
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6120
         TabIndex        =   24
         Top             =   2550
         Width           =   1935
      End
      Begin VB.PictureBox Pic_IT 
         Height          =   2055
         Left            =   480
         ScaleHeight     =   1995
         ScaleWidth      =   7515
         TabIndex        =   18
         Top             =   3120
         Width           =   7575
         Begin VB.Label LabAnalyse4_IT 
            AutoSize        =   -1  'True
            Caption         =   "0.67  ���駵�ͻ� �ʴ���ҡ�èѴ����Թ��Ҥ���ѧ����ջ���Է���Ҿ  ����Ҩ�Դ�ҡ��ö���Թ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   23
            Top             =   1200
            Width           =   6075
         End
         Begin VB.Label LabAnalyse3_IT 
            AutoSize        =   -1  'True
            Caption         =   "���ص����ѵ����ҡѺ 0.67 �ͺ ���¤������ �Թ��Ҥ���ѧ����������鹨Т��������ҳ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   22
            Top             =   840
            Width           =   6045
         End
         Begin VB.Label LabAnalyse2_IT 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�ҹ��к͡����Թ��ҷ������������鹢��������駵�ͻ�"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   1920
            TabIndex        =   21
            Top             =   480
            Width           =   3465
         End
         Begin VB.Label LabAnalyse1_IT 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ�ҡ����ع���¹�ͧ�Թ��Ҥ������  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   465
            TabIndex        =   20
            Top             =   120
            Width           =   6465
         End
         Begin VB.Label LabAnalyse5_IT 
            AutoSize        =   -1  'True
            Caption         =   "��Ҥ���ѧ�ҡ�Թ仨��������� �Ԩ��� �֧���Ŵ�дѺ�Թ��Ҥ���ѧŧ��ҧ  �繵�"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   19
            Top             =   1560
            Width           =   5790
         End
      End
      Begin VB.CommandButton CmdESC_IT 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6120
         TabIndex        =   5
         Top             =   2170
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_IT 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6120
         TabIndex        =   4
         Top             =   1795
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_IT 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6120
         TabIndex        =   3
         Top             =   1430
         Width           =   1935
      End
      Begin VB.TextBox TxtNameSell_IT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   10
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDsell_IT 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDCargo_IT 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   2
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneySell_IT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   9
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyCargo_IT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   8
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtNameCargo_IT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   7
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_IT 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   3120
         TabIndex        =   6
         Top             =   2160
         Width           =   2295
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2280
         TabIndex        =   25
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabMoney_IT 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6720
         TabIndex        =   17
         Top             =   330
         Width           =   705
      End
      Begin VB.Label LabPercent_IT 
         AutoSize        =   -1  'True
         Caption         =   "�ͺ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5445
         TabIndex        =   16
         Top             =   2190
         Width           =   285
      End
      Begin VB.Label LabResult_IT 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ�ҡ����ع���¹�ͧ�Թ��Ҥ���ѧ ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   15
         Top             =   2160
         Width           =   2580
      End
      Begin VB.Label LabName_IT 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4800
         TabIndex        =   14
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabID_IT 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2880
         TabIndex        =   13
         Top             =   315
         Width           =   660
      End
      Begin VB.Label LabCargo_IT 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ҥ���ѧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1280
         TabIndex        =   12
         Top             =   990
         Width           =   870
      End
      Begin VB.Label LabSell_IT 
         AutoSize        =   -1  'True
         Caption         =   "�鹷ع���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1440
         TabIndex        =   11
         Top             =   660
         Width           =   705
      End
   End
End
Attribute VB_Name = "frmSp_IT"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String

Private Sub CmdCal_IT_Click()
    Dim num1 As Double
    Dim num2 As Double
    Dim result As Double
    
    If ((TxtMoneySell_IT.Text = "") Or (TxtMoneyCargo_IT.Text = "") Or (TxtMoneySell_IT.Text = "" And TxtMoneyCargo_IT.Text = "")) Then
        MsgBox "�ӹǹ�Թ�Դ��Ҵ��س�����������ó�...!!! ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
    ElseIf ((TxtIDsell_IT.Text = "") Or (TxtIDCargo_IT.Text = "") Or (TxtIDsell_IT.Text = "" And TxtIDCargo_IT.Text = "")) Then
        MsgBox "���ʼԴ��Ҵ��س�����������ó�...!!!", vbCritical + vbOKOnly, "���ʼԴ��Ҵ"
    Else
        num1 = CDbl(TxtMoneySell_IT.Text)
        num2 = CDbl(TxtMoneyCargo_IT.Text)
        result = num1 / num2
        TxtResult_IT.Text = result
    End If
End Sub

Private Sub CmdClear_IT_Click()
        TxtIDsell_IT.Text = "" 'id
        TxtNameSell_IT.Text = "" 'name
        TxtMoneySell_IT.Text = "" 'value debit
        
        TxtIDCargo_IT.Text = "" 'id
        TxtNameCargo_IT.Text = "" 'name
        TxtMoneyCargo_IT.Text = "" 'value debit
        
        TxtResult_IT.Text = ""
End Sub

Private Sub CmdESC_IT_Click()
    Unload Me
    'Form_Activity.Show
End Sub

Private Sub CmdSave_Click()
    If TxtResult_IT.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateIT CDbl(TxtResult_IT.Text)
            TxtResult_IT.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If

End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_IT
End Sub

Private Sub TxtIDSell_IT_DblClick()
            TxtIDSell_IT_LostFocus
            index1 = "5" 'mean expenses
            index = "1"
            frmPlan_IT.Show
End Sub

Private Sub TxtIDSell_IT_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDsell_IT.Text = "") Then
                        TxtIDsell_IT.Text = "" 'id
                        TxtNameSell_IT.Text = "" 'name
                        TxtMoneySell_IT.Text = "" 'value debit
                        TxtIDsell_IT.SetFocus
                ElseIf CheckID(TxtIDsell_IT.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDsell_IT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDsell_IT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDsell_IT.Text, 1) 'check is expenses?
                                                                                            
                                If a$ = "5" Then  'is expenses
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDsell_IT.Text
                                                TxtNameSell_IT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_IT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDsell_IT.Text
                                                TxtNameSell_IT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_IT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtIDCargo_IT.SetFocus  'next text box
                                Else 'is't expenses
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ��������...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDsell_IT.Text = ""
                                        TxtNameSell_IT.Text = ""
                                        TxtMoneySell_IT.Text = ""
                                        TxtIDsell_IT.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_IT.Text = "" 'name
                        TxtMoneySell_IT.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDsell_IT.Text = ""
                            TxtNameSell_IT.Text = ""
                            TxtMoneySell_IT.Text = ""
                            TxtIDsell_IT.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDSell_IT_LostFocus()
      Dim a As String
      If (TxtIDsell_IT.Text = "") Then
                TxtIDsell_IT.Text = "" 'id
                TxtNameSell_IT.Text = "" 'name
                TxtMoneySell_IT.Text = "" 'value debit
                'TxtIDSell_IT.SetFocus
      ElseIf CheckID(TxtIDsell_IT.Text) = False Then
                TxtIDsell_IT.Text = ""
                TxtNameSell_IT.Text = "" 'name
                TxtMoneySell_IT.Text = "" 'value debit
       ElseIf CheckID(TxtIDsell_IT.Text) = True Then
                    'And  ( _
                    '(TxtNameSell_IT.Text = "" And TxtMoneySell_IT.Text = "") or _
                    '(TxtNameSell_IT.Text = "" And TxtMoneySell_IT.Text = "")Then
                        If TxtIDsell_IT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDsell_IT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDsell_IT.Text <> "5") Then
                                    a = Left$(TxtIDsell_IT.Text, 1) 'check is expenses?
                                Else: a = "5"
                                End If
                                                                                            
                                If a = "5" Then  'is expenses
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDsell_IT.Text
                                                TxtNameSell_IT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneySell_IT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDsell_IT.Text
                                                TxtNameSell_IT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneySell_IT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDCargo_IT.SetFocus  'next text box
                                Else 'is't expenses
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ��������...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDsell_IT.Text = ""
                                        TxtNameSell_IT.Text = ""
                                        TxtMoneySell_IT.Text = ""
                                        TxtIDsell_IT.SetFocus  'key new
                                End If
                        Else
                        TxtNameSell_IT.Text = "" 'name
                        TxtMoneySell_IT.Text = "" 'value debit
                        End If
        End If
End Sub

Private Sub TxtIDCargo_IT_DblClick()
        TxtIDCargo_IT_LostFocus
        index1 = "1" 'mean Asset
        index = "2"
        frmPlan_IT.Show
End Sub

Private Sub TxtIDCargo_IT_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDCargo_IT.Text = "") Then
                        TxtIDCargo_IT.Text = "" 'id
                        TxtNameCargo_IT.Text = "" 'name
                        TxtMoneyCargo_IT.Text = "" 'value debit
                        TxtIDCargo_IT.SetFocus
                ElseIf CheckID(TxtIDCargo_IT.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDCargo_IT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDCargo_IT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDCargo_IT.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDCargo_IT.Text
                                                TxtNameCargo_IT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyCargo_IT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDCargo_IT.Text
                                                TxtNameCargo_IT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyCargo_IT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'CmdCal_IT.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDCargo_IT.Text = ""
                                        TxtNameCargo_IT.Text = ""
                                        TxtMoneyCargo_IT.Text = ""
                                        TxtIDCargo_IT.SetFocus  'key new
                                End If
                        Else
                        TxtNameCargo_IT.Text = "" 'name
                        TxtMoneyCargo_IT.Text = "" 'value debit
                        End If
                Else: MsgBox "���ʺѭ�չ�����������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDCargo_IT.Text = ""
                            TxtNameCargo_IT.Text = ""
                            TxtMoneyCargo_IT.Text = ""
                            TxtIDCargo_IT.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDCargo_IT_LostFocus()
       Dim a As String
       If (TxtIDCargo_IT.Text = "") Then
                TxtIDCargo_IT.Text = "" 'id
                TxtNameCargo_IT.Text = "" 'name
                TxtMoneyCargo_IT.Text = "" 'value debit
                'TxtIDSell_IT.SetFocus
       ElseIf CheckID(TxtIDCargo_IT.Text) = False Then
                TxtIDCargo_IT.Text = ""
                TxtNameCargo_IT.Text = "" 'name
                TxtMoneyCargo_IT.Text = "" 'value debit
       ElseIf CheckID(TxtIDCargo_IT.Text) = True Then
                        'And TxtNameCargo_IT.Text = "" And TxtMoneyCargo_IT.Text = "" Then
                        If TxtIDCargo_IT.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDCargo_IT.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDCargo_IT.Text <> "1") Then
                                    a = Left$(TxtIDCargo_IT.Text, 1) 'check is Cargo?
                                Else: a = "1"
                                End If
                                                                                            
                                If a = "1" Then  'is Cargo
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDCargo_IT.Text
                                                TxtNameCargo_IT.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyCargo_IT.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDCargo_IT.Text
                                                TxtNameCargo_IT.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyCargo_IT.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'Cmd_Cal.SetFocus  'next text box
                                Else 'is't Cargo
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDCargo_IT.Text = ""
                                        TxtNameCargo_IT.Text = ""
                                        TxtMoneyCargo_IT.Text = ""
                                        TxtIDCargo_IT.SetFocus  'key new
                                End If
                        Else
                        TxtNameCargo_IT.Text = "" 'name
                        TxtMoneyCargo_IT.Text = "" 'value debit
                        End If
        End If
End Sub


