VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form Form_Leverage 
   Caption         =   "��������§㹡�û�Сͺ��áԨ"
   ClientHeight    =   2790
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6285
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   ScaleHeight     =   2790
   ScaleWidth      =   6285
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame Fram_Leverage 
      Caption         =   "��¡�����������ѵ���ʴ���������§㹡�û�Сͺ��áԨ"
      Height          =   2160
      Left            =   120
      TabIndex        =   1
      Top             =   0
      Width           =   6015
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   1560
         Left            =   240
         TabIndex        =   2
         Top             =   345
         Width           =   5535
         _ExtentX        =   9763
         _ExtentY        =   2752
         _Version        =   393216
         Rows            =   6
         _NumberOfBands  =   1
         _Band(0).Cols   =   2
      End
   End
   Begin VB.CommandButton CmdButESC_Leverage 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   5160
      TabIndex        =   0
      Top             =   2280
      Width           =   975
   End
End
Attribute VB_Name = "Form_Leverage"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdButESC_Leverage_Click()
        Unload Me
        Analyse.Show
End Sub

Private Sub Form_Load()
    Call Setgrid
End Sub

Private Sub Setgrid()

Dim row_temp As Integer
Dim i As Integer
Dim point_grid As Integer

gridinv.ColWidth(0) = 200           'Columns width 0
gridinv.ColWidth(1) = 6000         'Columns width 1

gridinv.TextMatrix(1, 1) = "�ѵ����ǹ˹���Թ����Թ��Ѿ�����"
gridinv.TextMatrix(2, 1) = "�ѵ����ǹ˹���Թ�����ǹ�ͧ��Ңͧ"
gridinv.TextMatrix(3, 1) = "�ѵ����ǹ�ʴ���������ö㹡�è��´͡����"

gridinv.row = 1
gridinv.col = 0

End Sub

Private Sub gridinv_DblClick()
    If gridinv.col = 1 Then
    Select Case gridinv.row
        Case 1
                        Unload Me
                        frmSp_DRatio.Show
        Case 2
                        Unload Me
                        frmSp_DERatio.Show
        Case 3
                        Unload Me
                        frmSp_TIE.Show
    End Select
    End If
End Sub

