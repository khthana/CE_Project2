VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form frmPlan_QRatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   4425
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   4215
   ControlBox      =   0   'False
   Icon            =   "frmPlan_QRatio.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4425
   ScaleWidth      =   4215
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC_QRatio 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   2880
      TabIndex        =   0
      Top             =   4030
      Width           =   1335
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MFGridPlan_QRatio 
      Height          =   3975
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   7011
      _Version        =   393216
      BackColor       =   -2147483624
      Rows            =   17
      Cols            =   3
      FixedCols       =   0
      AllowBigSelection=   0   'False
      BandDisplay     =   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   3
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "�Ѻ��Ť�ԡ��� ���ʺѭ��"
      ForeColor       =   &H000000FF&
      Height          =   195
      Left            =   0
      TabIndex        =   2
      Top             =   4080
      Width           =   1560
   End
End
Attribute VB_Name = "frmPlan_QRatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub CmdESC_QRatio_Click()
        Unload Me
        frmSp_QRatio.Show
End Sub

Private Sub Show_Plan()
     Dim i As Integer
     Dim Sum As Integer
     Call check_rs
     acc_data.cn_plan.Open
     
     If frmSp_QRatio.index1 = 1 Then
        acc_data.SelectAsset
        Sum = acc_data.rsSelectAsset.RecordCount  'total row of plan
        MFGridPlan_QRatio.Rows = Sum + 1
        
        MFGridPlan_QRatio.ColWidth(1) = 2000
        MFGridPlan_QRatio.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_QRatio.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_QRatio.TextMatrix(0, 2) = "��Դ�ѭ��"
     
        i = 0
        Do While i < Sum
            MFGridPlan_QRatio.TextMatrix(i + 1, 0) = acc_data.rsSelectAsset.Fields(0) 'check id_account in table plan_account
            MFGridPlan_QRatio.TextMatrix(i + 1, 1) = acc_data.rsSelectAsset.Fields(1) 'check name_account in table plan_account
            MFGridPlan_QRatio.TextMatrix(i + 1, 2) = acc_data.rsSelectAsset.Fields(3) 'check type_account in table plan_account
            i = i + 1
            acc_data.rsSelectAsset.MoveNext
        Loop
     ElseIf frmSp_QRatio.index1 = 2 Then
         acc_data.SelectDebt
         Sum = acc_data.rsSelectDebt.RecordCount  'total row of plan
         MFGridPlan_QRatio.Rows = Sum + 1
        
         MFGridPlan_QRatio.ColWidth(1) = 2000
         MFGridPlan_QRatio.TextMatrix(0, 0) = "���ʺѭ��"
         MFGridPlan_QRatio.TextMatrix(0, 1) = "���ͺѭ��"
         MFGridPlan_QRatio.TextMatrix(0, 2) = "��Դ�ѭ��"
     
        i = 0
        Do While i < Sum
            MFGridPlan_QRatio.TextMatrix(i + 1, 0) = acc_data.rsSelectDebt.Fields(0) 'check id_account in table plan_account
            MFGridPlan_QRatio.TextMatrix(i + 1, 1) = acc_data.rsSelectDebt.Fields(1) 'check name_account in table plan_account
            MFGridPlan_QRatio.TextMatrix(i + 1, 2) = acc_data.rsSelectDebt.Fields(3) 'check type_account in table plan_account
            i = i + 1
            acc_data.rsSelectDebt.MoveNext
        Loop
    End If

End Sub


Private Sub Form_Load()
        Show_Plan
End Sub

Private Sub MFGridPlan_QRatio_dblClick()
        Dim col As String
        Dim row As String
        Dim planType As String
        Dim a As String
        
        If CheckID(MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)) Then  'get ID_account
                If frmSp_QRatio.index = "1" Then  'fileds Asset
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0), 1) 'check is Asset?
                                                                                            
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDAst.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_QRatio.TxtNameAst.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyAst.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDAst.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_QRatio.TxtNameAst.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyAst.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        Unload Me
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                ElseIf frmSp_QRatio.index = "2" Then  'fields Cargo
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0), 1) 'check is Asset?
                                                                                            
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDCargo.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_QRatio.TxtNameCargo.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyCargo.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDCargo.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_QRatio.TxtNameCargo.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyCargo.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        Unload Me
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                ElseIf frmSp_QRatio.index = "3" Then   'fields Pay
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0), 1) 'check is Asset?
                                                                                            
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDPay.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_QRatio.TxtNamePay.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyPay.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDPay.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_QRatio.TxtNamePay.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyPay.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        Unload Me
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                ElseIf frmSp_QRatio.index = "4" Then   'fields Debt
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0), 1) 'check is Debt?
                                                                                            
                                If a = "2" Then  'is Debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDDebt.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_QRatio.TxtNameDebt.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyDebt.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_QRatio.TextMatrix(CInt(MFGridPlan_QRatio.row), 0)
                                                frmSp_QRatio.TxtIDDebt.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_QRatio.TxtNameDebt.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_QRatio.TxtMoneyDebt.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        Unload Me
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                End If
        Else
                MsgBox "���ʺѭ�չ���������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        End If
End Sub

