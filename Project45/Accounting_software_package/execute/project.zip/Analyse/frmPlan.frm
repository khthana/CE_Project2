VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form frmPlan 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   6690
   ClientLeft      =   20040
   ClientTop       =   1935
   ClientWidth     =   4230
   ControlBox      =   0   'False
   Icon            =   "frmPlan.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6690
   ScaleWidth      =   4230
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton CmdESC_Plan 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   2880
      TabIndex        =   0
      Top             =   6320
      Width           =   1335
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MFGridPlan_Plan 
      Height          =   6255
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   11033
      _Version        =   393216
      BackColor       =   -2147483624
      Rows            =   17
      Cols            =   3
      FixedCols       =   0
      ForeColorSel    =   -2147483624
      AllowBigSelection=   0   'False
      BandDisplay     =   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   3
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
End
Attribute VB_Name = "frmPlan"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit

Private Sub CmdESC_Plan_Click()
        Unload Me
End Sub

Private Sub Show_Plan()
     Dim i As Integer
     Dim Sum As Integer
     Call check_rs
     acc_data.cn_plan.Open
     acc_data.plan
     Sum = acc_data.rsplan.RecordCount  'total row of plan
     MFGridPlan_Plan.Rows = Sum + 1
        
        MFGridPlan_Plan.ColWidth(1) = 2000
        MFGridPlan_Plan.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_Plan.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_Plan.TextMatrix(0, 2) = "��Դ�ѭ��"
     
     i = 0
     Do While i < Sum
        MFGridPlan_Plan.TextMatrix(i + 1, 0) = acc_data.rsplan.Fields(0) 'check id_account in table plan_account
        MFGridPlan_Plan.TextMatrix(i + 1, 1) = acc_data.rsplan.Fields(1) 'check name_account in table plan_account
        MFGridPlan_Plan.TextMatrix(i + 1, 2) = acc_data.rsplan.Fields(2) 'check type_account in table plan_account
        i = i + 1
        acc_data.rsplan.MoveNext
     Loop

End Sub


Private Sub Form_Load()
        Show_Plan
End Sub

