VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form frmPlan_NPMargin 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   4440
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   4215
   ControlBox      =   0   'False
   Icon            =   "frmPlan_Account.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4440
   ScaleWidth      =   4215
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MFGridPlan_NPMargin 
      Height          =   3975
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   7011
      _Version        =   393216
      BackColor       =   -2147483624
      Rows            =   17
      Cols            =   3
      FixedCols       =   0
      AllowBigSelection=   0   'False
      BandDisplay     =   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   3
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
   Begin VB.CommandButton CmdESC_NPMargin 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   2880
      TabIndex        =   0
      Top             =   4050
      Width           =   1335
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "�Ѻ��Ť�ԡ��� ���ʺѭ��"
      ForeColor       =   &H000000FF&
      Height          =   195
      Left            =   0
      TabIndex        =   2
      Top             =   4080
      Width           =   1560
   End
End
Attribute VB_Name = "frmPlan_NPMargin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdESC_NPMargin_Click()
        frmSp_NPMargin.Show
        Unload Me
End Sub

Private Sub Show_Plan()
     Dim i As Integer
     Dim Sum As Integer
     Call check_rs
     acc_data.cn_plan.Open
     acc_data.SelectRevenue
     Sum = acc_data.rsSelectRevenue.RecordCount  'total row of plan
     MFGridPlan_NPMargin.Rows = Sum + 1
        
        MFGridPlan_NPMargin.ColWidth(1) = 2000
        MFGridPlan_NPMargin.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_NPMargin.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_NPMargin.TextMatrix(0, 2) = "��Դ�ѭ��"
     
     i = 0
     Do While i < Sum
        MFGridPlan_NPMargin.TextMatrix(i + 1, 0) = acc_data.rsSelectRevenue.Fields(0) 'check id_account in table plan_account
        MFGridPlan_NPMargin.TextMatrix(i + 1, 1) = acc_data.rsSelectRevenue.Fields(1) 'check name_account in table plan_account
        MFGridPlan_NPMargin.TextMatrix(i + 1, 2) = acc_data.rsSelectRevenue.Fields(3) 'check type_account in table plan_account
        i = i + 1
        acc_data.rsSelectRevenue.MoveNext
     Loop
End Sub

Private Sub Form_Load()
        Show_Plan
End Sub

Private Sub MFGridPlan_NPMargin_DblClick()
         Dim col As String
        Dim row As String
        Dim planType As String
        Dim a As String
        
        If CheckID(MFGridPlan_NPMargin.TextMatrix(CInt(MFGridPlan_NPMargin.row), 0)) Then  'get ID_account
                'If frmSp_NPMargin.index = "1" Then  'fileds Sell
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_NPMargin.TextMatrix(CInt(MFGridPlan_NPMargin.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                a = Left$(MFGridPlan_NPMargin.TextMatrix(CInt(MFGridPlan_NPMargin.row), 0), 1) 'check is revenue?
                                                                                            
                                If a = "4" Then  'is revenue
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_NPMargin.TextMatrix(CInt(MFGridPlan_NPMargin.row), 0)
                                                frmSp_NPMargin.TxtIDSell_NPMargin.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_NPMargin.TxtNameSell_NPMargin.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_NPMargin.TxtMoneySell_NPMargin.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_NPMargin.TextMatrix(CInt(MFGridPlan_NPMargin.row), 0)
                                                frmSp_NPMargin.TxtIDSell_NPMargin.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_NPMargin.TxtNameSell_NPMargin.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_NPMargin.TxtMoneySell_NPMargin.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        Unload Me
                                Else 'is't revenue
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�����...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                'End If
        Else
                MsgBox "���ʺѭ�չ���������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        End If
End Sub



