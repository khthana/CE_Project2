VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form frmPlan_DERatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   4425
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   4215
   ControlBox      =   0   'False
   Icon            =   "frmPlan_DERatio.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4425
   ScaleWidth      =   4215
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton CmdESC_DERatio 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   2880
      TabIndex        =   0
      Top             =   4030
      Width           =   1335
   End
   Begin MSHierarchicalFlexGridLib.MSHFlexGrid MFGridPlan_DERatio 
      Height          =   3975
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   4215
      _ExtentX        =   7435
      _ExtentY        =   7011
      _Version        =   393216
      BackColor       =   -2147483624
      Rows            =   17
      Cols            =   3
      FixedCols       =   0
      AllowBigSelection=   0   'False
      BandDisplay     =   1
      _NumberOfBands  =   1
      _Band(0).Cols   =   3
      _Band(0).GridLinesBand=   1
      _Band(0).TextStyleBand=   0
      _Band(0).TextStyleHeader=   0
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "�Ѻ��Ť�ԡ��� ���ʺѭ��"
      ForeColor       =   &H000000FF&
      Height          =   195
      Left            =   0
      TabIndex        =   2
      Top             =   4080
      Width           =   1560
   End
End
Attribute VB_Name = "frmPlan_DERatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub CmdESC_DERatio_Click()
        frmSp_DERatio.Show
        Unload Me
End Sub

Private Sub Show_Plan()
     Dim i As Integer
     Dim Sum As Integer
     Call check_rs
     acc_data.cn_plan.Open
     
     If frmSp_DERatio.index1 = "3" Then
        acc_data.SelectCapital
        Sum = acc_data.rsSelectCapital.RecordCount  'total row of plan
        MFGridPlan_DERatio.Rows = Sum + 1
        
        MFGridPlan_DERatio.ColWidth(1) = 2000
        MFGridPlan_DERatio.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_DERatio.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_DERatio.TextMatrix(0, 2) = "��Դ�ѭ��"
     
        i = 0
        Do While i < Sum
            MFGridPlan_DERatio.TextMatrix(i + 1, 0) = acc_data.rsSelectCapital.Fields(0) 'check id_account in table plan_account
            MFGridPlan_DERatio.TextMatrix(i + 1, 1) = acc_data.rsSelectCapital.Fields(1) 'check name_account in table plan_account
            MFGridPlan_DERatio.TextMatrix(i + 1, 2) = acc_data.rsSelectCapital.Fields(3) 'check type_account in table plan_account
            i = i + 1
            acc_data.rsSelectCapital.MoveNext
        Loop
    ElseIf frmSp_DERatio.index1 = "2" Then
        acc_data.SelectDebt
        Sum = acc_data.rsSelectDebt.RecordCount  'total row of plan
        MFGridPlan_DERatio.Rows = Sum + 1
        
        MFGridPlan_DERatio.ColWidth(1) = 2000
        MFGridPlan_DERatio.TextMatrix(0, 0) = "���ʺѭ��"
        MFGridPlan_DERatio.TextMatrix(0, 1) = "���ͺѭ��"
        MFGridPlan_DERatio.TextMatrix(0, 2) = "��Դ�ѭ��"
     
        i = 0
        Do While i < Sum
            MFGridPlan_DERatio.TextMatrix(i + 1, 0) = acc_data.rsSelectDebt.Fields(0) 'check id_account in table plan_account
            MFGridPlan_DERatio.TextMatrix(i + 1, 1) = acc_data.rsSelectDebt.Fields(1) 'check name_account in table plan_account
            MFGridPlan_DERatio.TextMatrix(i + 1, 2) = acc_data.rsSelectDebt.Fields(3) 'check type_account in table plan_account
            i = i + 1
            acc_data.rsSelectDebt.MoveNext
        Loop
    End If
End Sub

Private Sub Form_Load()
        Show_Plan
End Sub

Private Sub MFGridPlan_DERatio_DblClick()
        Dim col As String
        Dim row As String
        Dim planType As String
        Dim a As String
        
        If CheckID(MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)) Then  'get ID_account
                If frmSp_DERatio.index = "2" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0), 1) 'check is C?
                                                                                            
                                If a = "3" Then  'is C
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)
                                                frmSp_DERatio.TxtIDC_DERatio.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_DERatio.TxtNameC_DERatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_DERatio.TxtMoneyC_DERatio.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)
                                                frmSp_DERatio.TxtIDC_DERatio.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_DERatio.TxtNameC_DERatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_DERatio.TxtMoneyC_DERatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        Unload Me
                                Else 'is't C
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�ع...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                ElseIf frmSp_DERatio.index = "1" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a = Left$(MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0), 1) 'check is debt?
                                                                                            
                                If a = "2" Then  'is debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)
                                                frmSp_DERatio.TxtIDDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(0) 'id
                                                frmSp_DERatio.TxtNameDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                frmSp_DERatio.TxtMoneyDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG MFGridPlan_DERatio.TextMatrix(CInt(MFGridPlan_DERatio.row), 0)
                                                frmSp_DERatio.TxtIDDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(0) 'id
                                                frmSp_DERatio.TxtNameDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                frmSp_DERatio.TxtMoneyDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        Unload Me
                                Else 'is't C
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                End If
                End If
        Else
                MsgBox "���ʺѭ�չ���������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
        End If
End Sub



