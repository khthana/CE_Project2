VERSION 5.00
Begin VB.Form frmSp_DRatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5940
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8775
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_DRatio.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5940
   ScaleWidth      =   8775
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_DRatio 
      Caption         =   "�ѵ����ǹ˹���Թ����Թ��Ѿ�����( Debt Ratio )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5805
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8520
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6120
         TabIndex        =   24
         Top             =   2550
         Width           =   1935
      End
      Begin VB.PictureBox Pic_DRatio 
         Height          =   2055
         Left            =   480
         ScaleHeight     =   1995
         ScaleWidth      =   7515
         TabIndex        =   18
         Top             =   3240
         Width           =   7575
         Begin VB.Label LabAnalyse5_DRatio 
            AutoSize        =   -1  'True
            Caption         =   "�з�������˹�������ҡ������ա"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   23
            Top             =   1560
            Width           =   1995
         End
         Begin VB.Label LabAnalyse1_DRatio 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ����ǹ˹���Թ����Թ��Ѿ�����  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   645
            TabIndex        =   22
            Top             =   120
            Width           =   6105
         End
         Begin VB.Label LabAnalyse2_DRatio 
            AutoSize        =   -1  'True
            Caption         =   "���ص����  �ѵ����ǹ˹���Թ��ҡѺ  20%  �ʴ������Թ��Ѿ������� 100 �ҷ ��˹���Թ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   21
            Top             =   480
            Width           =   5970
         End
         Begin VB.Label LabAnalyse3_DRatio 
            AutoSize        =   -1  'True
            Caption         =   "����ͧ���� 20 �ҷ �Թ��Ѿ����ǹ�˭�ͧ�Ԩ��ö֧ 80% ��ʹ˹��֧����ö����˹��"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   20
            Top             =   840
            Width           =   5970
         End
         Begin VB.Label LabAnalyse4_DRatio 
            AutoSize        =   -1  'True
            Caption         =   "��� �ôԵ�ͧ��áԨ�֧��͹��ҧ�� ����ѵ�ҹ���٧�ʴ���Ҹ�áԨ�դ�������§㹡�ê���˹���٧"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   19
            Top             =   1200
            Width           =   6090
         End
      End
      Begin VB.TextBox TxtResult_DRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   2880
         TabIndex        =   17
         Top             =   2160
         Width           =   2175
      End
      Begin VB.TextBox TxtNameDebt_DRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   16
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyDebt_DRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   15
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyAsset_DRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   14
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDDebt_DRatio 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   2
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtIDAsset_DRatio 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtNameAsset_DRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   6
         Top             =   600
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_DRatio 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6120
         TabIndex        =   3
         Top             =   1430
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_DRatio 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6120
         TabIndex        =   4
         Top             =   1795
         Width           =   1935
      End
      Begin VB.CommandButton CmdESC_DRatio 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6120
         TabIndex        =   5
         Top             =   2170
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2280
         TabIndex        =   25
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabAsset 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ѿ�����"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1200
         TabIndex        =   13
         Top             =   660
         Width           =   915
      End
      Begin VB.Label LabDebt 
         AutoSize        =   -1  'True
         Caption         =   "˹���Թ���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1390
         TabIndex        =   12
         Top             =   990
         Width           =   720
      End
      Begin VB.Label LabID_DRatio 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2880
         TabIndex        =   11
         Top             =   315
         Width           =   660
      End
      Begin VB.Label LabName_DRatio 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4800
         TabIndex        =   10
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabResult_DRatio 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ����ǹ˹���Թ����Թ��Ѿ����� ="
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   9
         Top             =   2160
         Width           =   2355
      End
      Begin VB.Label LabPercent_DRatio 
         AutoSize        =   -1  'True
         Caption         =   "%"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5160
         TabIndex        =   8
         Top             =   2160
         Width           =   180
      End
      Begin VB.Label LabMoney_DRatio 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6720
         TabIndex        =   7
         Top             =   330
         Width           =   705
      End
   End
End
Attribute VB_Name = "frmSp_DRatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String


Private Sub CmdCal_DRatio_Click()
    Dim num1 As Double
    Dim num2 As Double
    Dim result As Double
    
    If ((TxtMoneyAsset_DRatio.Text = "") Or (TxtMoneyDebt_DRatio.Text = "") Or (TxtMoneyAsset_DRatio.Text = "" And TxtMoneyDebt_DRatio.Text = "")) Then
        MsgBox "�ӹǹ�Թ�Դ��Ҵ��س�����������ó�...!!! ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
    ElseIf ((TxtIDAsset_DRatio.Text = "") Or (TxtIDDebt_DRatio.Text = "") Or (TxtIDAsset_DRatio.Text = "" And TxtIDDebt_DRatio.Text = "")) Then
        MsgBox "���ʼԴ��Ҵ��س�����������ó�...!!!", vbCritical + vbOKOnly, "���ʼԴ��Ҵ"
    Else
        num1 = CDbl(TxtMoneyAsset_DRatio.Text)
        num2 = CDbl(TxtMoneyDebt_DRatio.Text)
        result = num2 * 100
        result = result / num1
        TxtResult_DRatio.Text = result
    End If
End Sub

Private Sub CmdClear_DRatio_Click()
        TxtIDAsset_DRatio.Text = "" 'id
        TxtNameAsset_DRatio.Text = "" 'name
        TxtMoneyAsset_DRatio.Text = "" 'value debit
        
        TxtIDDebt_DRatio.Text = "" 'id
        TxtNameDebt_DRatio.Text = "" 'name
        TxtMoneyDebt_DRatio.Text = "" 'value debit
        
        TxtResult_DRatio.Text = ""
End Sub

Private Sub CmdESC_DRatio_Click()
    Unload Me
    'Form_Leverage.Show
End Sub

Private Sub CmdSave_Click()
    If TxtResult_DRatio.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateDRatio CDbl(TxtResult_DRatio.Text)
            TxtResult_DRatio.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_DRatio
End Sub

Private Sub TxtIDAsset_DRatio_DblClick()
            TxtIDAsset_DRatio_LostFocus
            index1 = "1" 'mean Debt
            index = "1"
            frmPlan_DRatio.Show
End Sub

Private Sub TxtIDAsset_DRatio_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDAsset_DRatio.Text = "") Then
                        TxtIDAsset_DRatio.Text = "" 'id
                        TxtNameAsset_DRatio.Text = "" 'name
                        TxtMoneyAsset_DRatio.Text = "" 'value debit
                        TxtIDAsset_DRatio.SetFocus
                ElseIf CheckID(TxtIDAsset_DRatio.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDAsset_DRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAsset_DRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDAsset_DRatio.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAsset_DRatio.Text
                                                TxtNameAsset_DRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAsset_DRatio.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAsset_DRatio.Text
                                                TxtNameAsset_DRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAsset_DRatio.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtIDDebt_DRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDAsset_DRatio.Text = ""
                                        TxtNameAsset_DRatio.Text = ""
                                        TxtMoneyAsset_DRatio.Text = ""
                                        TxtIDAsset_DRatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameAsset_DRatio.Text = "" 'name
                        TxtMoneyAsset_DRatio.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDAsset_DRatio.Text = ""
                            TxtNameAsset_DRatio.Text = ""
                            TxtMoneyAsset_DRatio.Text = ""
                            TxtIDAsset_DRatio.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDAsset_DRatio_LostFocus()
      Dim a As String
      If (TxtIDAsset_DRatio.Text = "") Then
                TxtIDAsset_DRatio.Text = "" 'id
                TxtNameAsset_DRatio.Text = "" 'name
                TxtMoneyAsset_DRatio.Text = "" 'value debit
                'TxtIDAsset_DRatio.SetFocus
      ElseIf CheckID(TxtIDAsset_DRatio.Text) = False Then
                TxtIDAsset_DRatio.Text = ""
                TxtNameAsset_DRatio.Text = "" 'name
                TxtMoneyAsset_DRatio.Text = "" 'value debit
       ElseIf CheckID(TxtIDAsset_DRatio.Text) = True Then
                    'And  ( _
                    '(TxtNameAsset_DRatio.Text = "" And TxtMoneyAsset_DRatio.Text = "") or _
                    '(TxtNameAsset_DRatio.Text = "" And TxtMoneyAsset_DRatio.Text = "")Then
                        If TxtIDAsset_DRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDAsset_DRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDAsset_DRatio.Text <> "1") Then
                                    a = Left$(TxtIDAsset_DRatio.Text, 1) 'check is Asset?
                                Else: a = "1"
                                End If
                                                                                            
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDAsset_DRatio.Text
                                                TxtNameAsset_DRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyAsset_DRatio.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDAsset_DRatio.Text
                                                TxtNameAsset_DRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyAsset_DRatio.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtIDDebt_DRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDAsset_DRatio.Text = ""
                                        TxtNameAsset_DRatio.Text = ""
                                        TxtMoneyAsset_DRatio.Text = ""
                                        TxtIDAsset_DRatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameAsset_DRatio.Text = "" 'name
                        TxtMoneyAsset_DRatio.Text = "" 'value debit
                        End If
        End If
End Sub

Private Sub TxtIDDebt_DRatio_DblClick()
        TxtIDDebt_DRatio_LostFocus
        index1 = "2"  'mean Debt
        index = "2"
        frmPlan_DRatio.Show
End Sub

Private Sub TxtIDDebt_DRatio_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDDebt_DRatio.Text = "") Then
                        TxtIDDebt_DRatio.Text = "" 'id
                        TxtNameDebt_DRatio.Text = "" 'name
                        TxtMoneyDebt_DRatio.Text = "" 'value debit
                        TxtIDDebt_DRatio.SetFocus
                ElseIf CheckID(TxtIDDebt_DRatio.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtIDDebt_DRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt_DRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDDebt_DRatio.Text, 1) 'check is debt?
                                                                                            
                                If a$ = "2" Then  'is debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt_DRatio.Text
                                                TxtNameDebt_DRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt_DRatio.Text = acc_data.rsgetPlanD.Fields(3) 'value crebit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt_DRatio.Text
                                                TxtNameDebt_DRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt_DRatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'CmdCal_DRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt_DRatio.Text = ""
                                        TxtNameDebt_DRatio.Text = ""
                                        TxtMoneyDebt_DRatio.Text = ""
                                        TxtIDDebt_DRatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameDebt_DRatio.Text = "" 'name
                        TxtMoneyDebt_DRatio.Text = "" 'value debit
                        End If
                Else: MsgBox "���ʺѭ�չ�����������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDDebt_DRatio.Text = ""
                            TxtNameDebt_DRatio.Text = ""
                            TxtMoneyDebt_DRatio.Text = ""
                            TxtIDDebt_DRatio.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDDebt_DRatio_LostFocus()
       Dim a As String
       If (TxtIDDebt_DRatio.Text = "") Then
                TxtIDDebt_DRatio.Text = "" 'id
                TxtNameDebt_DRatio.Text = "" 'name
                TxtMoneyDebt_DRatio.Text = "" 'value debit
                'TxtIDAsset_DRatio.SetFocus
       ElseIf CheckID(TxtIDDebt_DRatio.Text) = False Then
                TxtIDDebt_DRatio.Text = ""
                TxtNameDebt_DRatio.Text = "" 'name
                TxtMoneyDebt_DRatio.Text = "" 'value debit
       ElseIf CheckID(TxtIDDebt_DRatio.Text) = True Then
                        'And TxtNameDebt_DRatio.Text = "" And TxtMoneyDebt_DRatio.Text = "" Then
                        If TxtIDDebt_DRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt_DRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDDebt_DRatio.Text <> "2") Then
                                    a = Left$(TxtIDDebt_DRatio.Text, 1) 'check is Debt?
                                Else: a = "2"
                                End If
                                                                                            
                                If a = "2" Then  'is Debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt_DRatio.Text
                                                TxtNameDebt_DRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt_DRatio.Text = acc_data.rsgetPlanD.Fields(3) 'value crebit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt_DRatio.Text
                                                TxtNameDebt_DRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt_DRatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'Cmd_Cal.SetFocus  'next text box
                                Else 'is't Debt
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt_DRatio.Text = ""
                                        TxtNameDebt_DRatio.Text = ""
                                        TxtMoneyDebt_DRatio.Text = ""
                                        TxtIDDebt_DRatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameDebt_DRatio.Text = "" 'name
                        TxtMoneyDebt_DRatio.Text = "" 'value debit
                        End If
        End If
End Sub
