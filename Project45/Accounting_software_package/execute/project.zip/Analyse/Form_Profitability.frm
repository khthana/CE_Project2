VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Begin VB.Form Form_Profitability 
   Caption         =   "��������ö㹡�÷ӡ���"
   ClientHeight    =   2760
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6255
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2760
   ScaleWidth      =   6255
   StartUpPosition =   2  'CenterScreen
   WhatsThisButton =   -1  'True
   WhatsThisHelp   =   -1  'True
   Begin VB.Frame Frm_Profitability 
      Caption         =   "��¡�����������ѵ����ǹ�ʴ���������ö㹡�÷ӡ���"
      Height          =   2160
      Left            =   120
      TabIndex        =   1
      Top             =   0
      Width           =   6015
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid gridinv 
         Height          =   1560
         Left            =   240
         TabIndex        =   2
         Top             =   345
         Width           =   5535
         _ExtentX        =   9763
         _ExtentY        =   2752
         _Version        =   393216
         Rows            =   6
         _NumberOfBands  =   1
         _Band(0).Cols   =   2
      End
   End
   Begin VB.CommandButton CmdButESC_Profitability 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   5160
      TabIndex        =   0
      Top             =   2280
      Width           =   975
   End
End
Attribute VB_Name = "Form_Profitability"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub CmdButESC_Profitability_Click()
        Unload Me
        Analyse.Show
End Sub

Private Sub Form_Load()
    Call Setgrid
End Sub
Private Sub Setgrid()

Dim row_temp As Integer
Dim i As Integer
Dim point_grid As Integer

gridinv.ColWidth(0) = 200           'Columns width 0
gridinv.ColWidth(1) = 6000         'Columns width 1

gridinv.TextMatrix(1, 1) = "�ѵ����ǹ�����ط�Ե���ʹ��� �����ѵ�Ҽŵͺ᷹�ʹ���"
gridinv.TextMatrix(2, 1) = "�ѵ�Ҽŵͺ᷹�ҡ���ŧ�ع"

gridinv.row = 1
gridinv.col = 0

End Sub
Private Sub gridinv_DblClick()
    If gridinv.col = 1 Then
    Select Case gridinv.row
        Case 1
                        Unload Me
                        frmSp_NPMargin.Show
        Case 2
                        Unload Me
                        frmSp_ROI.Show
    End Select
    End If
End Sub
