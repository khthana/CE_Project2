VERSION 5.00
Begin VB.Form frmSp_CRatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5325
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8775
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "choose_day.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   55.661
   ScaleMode       =   0  'User
   ScaleWidth      =   8775
   ShowInTaskbar   =   0   'False
   Begin VB.TextBox TxtMoney2_CRatio 
      BackColor       =   &H80000004&
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6240
      TabIndex        =   4
      Top             =   960
      Width           =   1935
   End
   Begin VB.TextBox TxtMoney1_CRatio 
      BackColor       =   &H80000004&
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6240
      TabIndex        =   2
      Top             =   600
      Width           =   1935
   End
   Begin VB.TextBox TxtResult_CRatio 
      BackColor       =   &H80000004&
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   315
      Left            =   2400
      TabIndex        =   15
      Top             =   2160
      Width           =   1935
   End
   Begin VB.TextBox TxtID2_CRatio 
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2400
      TabIndex        =   3
      Top             =   960
      Width           =   1935
   End
   Begin VB.Frame Fram_CRatio 
      Caption         =   "�ѵ�ҷع��ع���¹( Current Ratio )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5205
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8520
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6120
         TabIndex        =   8
         Top             =   2520
         Width           =   1935
      End
      Begin VB.PictureBox Pic_CRatio 
         Height          =   1695
         Left            =   480
         ScaleHeight     =   1635
         ScaleWidth      =   7515
         TabIndex        =   19
         Top             =   3120
         Width           =   7575
         Begin VB.Label LabAnalyse4_CRatio 
            AutoSize        =   -1  'True
            Caption         =   "2.  ����ҡ���� 5.00 �ʴ���� ��áԨ����Ҿ���ͧ���ͤ�������ö㹡�ê���˹���Թ����������"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   480
            TabIndex        =   23
            Top             =   1200
            Width           =   6525
         End
         Begin VB.Label LabAnalyse3_CRatio 
            AutoSize        =   -1  'True
            Caption         =   "1.  ��ҹ��¡��� 5.00 �ʴ���� ��áԨ����Ҿ���ͧ���ͤ�������ö㹡�ê���˹���Թ�������������"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   480
            TabIndex        =   22
            Top             =   840
            Width           =   6720
         End
         Begin VB.Label LabAnalyse2_CRatio 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�Ңͧ�ص��ˡ�������������ҳ  5.00  "
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   2160
            TabIndex        =   21
            Top             =   480
            Width           =   3030
         End
         Begin VB.Label LabAnalyse1_CRatio 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ����ǹ�ع��ع���¹  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   1020
            TabIndex        =   20
            Top             =   120
            Width           =   5355
         End
      End
      Begin VB.CommandButton CmdESC_CRatio 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6120
         TabIndex        =   7
         Top             =   2160
         Width           =   1935
      End
      Begin VB.CommandButton CmdCel_CRatio 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6120
         TabIndex        =   6
         Top             =   1800
         Width           =   1935
      End
      Begin VB.CommandButton Cmd_Cal 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6120
         TabIndex        =   5
         Top             =   1440
         Width           =   1935
      End
      Begin VB.TextBox TxtName2_CRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   10
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtName1_CRatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   9
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtID1_CRatio 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2280
         TabIndex        =   24
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabMoney_CRatio 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6720
         TabIndex        =   18
         Top             =   330
         Width           =   705
      End
      Begin VB.Label LabResult2_CRatio 
         AutoSize        =   -1  'True
         Caption         =   "���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4320
         TabIndex        =   17
         Top             =   2160
         Width           =   240
      End
      Begin VB.Label LabResult_CRatio 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ����ǹ�ع��ع���¹ = "
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   16
         Top             =   2160
         Width           =   1740
      End
      Begin VB.Label LabName3_CRatio 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4800
         TabIndex        =   14
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabID3_CRatio 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2880
         TabIndex        =   13
         Top             =   315
         Width           =   660
      End
      Begin VB.Label Lab2 
         AutoSize        =   -1  'True
         Caption         =   "˹���Թ��ع���¹"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1080
         TabIndex        =   12
         Top             =   990
         Width           =   1095
      End
      Begin VB.Label Lab1 
         AutoSize        =   -1  'True
         Caption         =   "�Թ��Ѿ����ع���¹"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   870
         TabIndex        =   11
         Top             =   660
         Width           =   1290
      End
   End
End
Attribute VB_Name = "frmSp_CRatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String

Private Sub Cmd_Cal_Click()
    Dim num1 As Double
    Dim num2 As Double
    Dim result As Double
    
    If ((TxtMoney1_CRatio.Text = "") Or (TxtMoney2_CRatio.Text = "") Or (TxtMoney1_CRatio.Text = "" And TxtMoney2_CRatio.Text = "")) Then
        MsgBox "�ӹǹ�Թ�Դ��Ҵ��س�����������ó�...!!! ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
    ElseIf ((TxtID1_CRatio.Text = "") Or (TxtID2_CRatio.Text = "") Or (TxtID1_CRatio.Text = "" And TxtID2_CRatio.Text = "")) Then
        MsgBox "���ʼԴ��Ҵ��س�����������ó�...!!!", vbCritical + vbOKOnly, "���ʼԴ��Ҵ"
    Else
        num1 = CDbl(TxtMoney1_CRatio.Text)
        num2 = CDbl(TxtMoney2_CRatio.Text)
        result = num1 / num2
        TxtResult_CRatio.Text = result
    End If
    
End Sub

Private Sub CmdCel_CRatio_Click()
        TxtID1_CRatio.Text = "" 'id
        TxtName1_CRatio.Text = "" 'name
        TxtMoney1_CRatio.Text = "" 'value debit
        TxtID2_CRatio.Text = "" 'id
        TxtName2_CRatio.Text = "" 'name
        TxtMoney2_CRatio.Text = "" 'value debit
        TxtResult_CRatio.Text = ""
End Sub

Private Sub CmdESC_CRatio_Click()
    Unload Me
    'Form_Liquidity.Show
End Sub

Private Sub CmdSave_Click()
    If TxtResult_CRatio.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateCRatio CDbl(TxtResult_CRatio.Text)
            TxtResult_CRatio.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If
End Sub

Private Sub Form_Load()
    chCRatio = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_CRatio
End Sub

Private Sub TxtID1_CRatio_DblClick()
            TxtID1_CRatio_LostFocus
            index1 = "1" 'mean Asset
            index = "1"
            frmPlan_CRatio.Show
End Sub

Private Sub TxtID1_CRatio_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtID1_CRatio.Text = "") Then
                        TxtID1_CRatio.Text = "" 'id
                        TxtName1_CRatio.Text = "" 'name
                        TxtMoney1_CRatio.Text = "" 'value debit
                        TxtID1_CRatio.SetFocus
                ElseIf CheckID(TxtID1_CRatio.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtID1_CRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtID1_CRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtID1_CRatio.Text, 1) 'check is Asset?
                                                                                            
                                If a$ = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtID1_CRatio.Text
                                                TxtName1_CRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoney1_CRatio.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtID1_CRatio.Text
                                                TxtName1_CRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoney1_CRatio.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        TxtID2_CRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtID1_CRatio.Text = ""
                                        TxtName1_CRatio.Text = ""
                                        TxtMoney1_CRatio.Text = ""
                                        TxtID1_CRatio.SetFocus  'key new
                                End If
                        Else
                        TxtName1_CRatio.Text = "" 'name
                        TxtMoney1_CRatio.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtID1_CRatio.Text = ""
                            TxtName1_CRatio.Text = ""
                            TxtMoney1_CRatio.Text = ""
                            TxtID1_CRatio.SetFocus
                End If
        End If
End Sub

Private Sub TxtID1_CRatio_LostFocus()
      Dim a As String
      If (TxtID1_CRatio.Text = "") Then
                TxtID1_CRatio.Text = "" 'id
                TxtName1_CRatio.Text = "" 'name
                TxtMoney1_CRatio.Text = "" 'value debit
                'TxtID1_CRatio.SetFocus
      ElseIf CheckID(TxtID1_CRatio.Text) = False Then
                TxtID1_CRatio.Text = ""
                TxtName1_CRatio.Text = "" 'name
                TxtMoney1_CRatio.Text = "" 'value debit
       ElseIf CheckID(TxtID1_CRatio.Text) = True Then
                        'And TxtName1_CRatio.Text = "" And TxtMoney1_CRatio.Text = "" Then
                        If TxtID1_CRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtID1_CRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtID1_CRatio.Text <> "1") Then
                                    a = Left$(TxtID1_CRatio.Text, 1) 'check is Asset?
                                Else: a = "1"
                                End If
                                
                                If a = "1" Then  'is Asset
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtID1_CRatio.Text
                                                TxtName1_CRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoney1_CRatio.Text = acc_data.rsgetPlanD.Fields(2) 'value debit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtID1_CRatio.Text
                                                TxtName1_CRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoney1_CRatio.Text = acc_data.rsgetPlanG.Fields(2) 'value debit
                                        End If
                                        'TxtID2_CRatio.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�Թ��Ѿ��...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtID1_CRatio.Text = ""
                                        TxtName1_CRatio.Text = ""
                                        TxtMoney1_CRatio.Text = ""
                                        TxtID1_CRatio.SetFocus  'key new
                                End If
                        Else
                        TxtName1_CRatio.Text = "" 'name
                        TxtMoney1_CRatio.Text = "" 'value debit
                        End If
        End If
End Sub

Private Sub check_rs()

            If acc_data.cn_plan.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata recordset
                        acc_data.cn_plan.Close
            End If
            
End Sub

Private Sub TxtID2_CRatio_DblClick()
        TxtID2_CRatio_LostFocus
        index1 = "2" 'mean Debt
        index = "2"
        frmPlan_CRatio.Show
End Sub

Private Sub TxtID2_CRatio_KeyPress(KeyAscii As Integer)
        Dim a As String
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtID2_CRatio.Text = "") Then
                        TxtID2_CRatio.Text = "" 'id
                        TxtName2_CRatio.Text = "" 'name
                        TxtMoney2_CRatio.Text = "" 'value debit
                        TxtID2_CRatio.SetFocus
                ElseIf CheckID(TxtID2_CRatio.Text) = True Then    'if have id_account in table summary_plan_d and g
                        If TxtID2_CRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtID2_CRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtID2_CRatio.Text <> "2") Then
                                    a = Left$(TxtID2_CRatio.Text, 1) 'check is debt?
                                Else: a = "2"
                                End If
                                                                                            
                                If a = "2" Then  'is debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtID2_CRatio.Text
                                                TxtName2_CRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoney2_CRatio.Text = acc_data.rsgetPlanD.Fields(3) 'value crebit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtID2_CRatio.Text
                                                TxtName2_CRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoney2_CRatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'Cmd_Cal.SetFocus  'next text box
                                Else 'is't Asset
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtID2_CRatio.Text = ""
                                        TxtName2_CRatio.Text = ""
                                        TxtMoney2_CRatio.Text = ""
                                        TxtID2_CRatio.SetFocus  'key new
                                End If
                        Else
                        TxtName2_CRatio.Text = "" 'name
                        TxtMoney2_CRatio.Text = "" 'value debit
                        End If
                Else: MsgBox "���ʺѭ�չ�����������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtID2_CRatio.Text = ""
                            TxtName2_CRatio.Text = ""
                            TxtMoney2_CRatio.Text = ""
                            TxtID2_CRatio.SetFocus
                End If
        End If
End Sub

Private Sub TxtID2_CRatio_LostFocus()
       If (TxtID2_CRatio.Text = "") Then
                TxtID2_CRatio.Text = "" 'id
                TxtName2_CRatio.Text = "" 'name
                TxtMoney2_CRatio.Text = "" 'value debit
                'TxtID1_CRatio.SetFocus
       ElseIf CheckID(TxtID2_CRatio.Text) = False Then
                TxtID2_CRatio.Text = ""
                TxtName2_CRatio.Text = "" 'name
                TxtMoney2_CRatio.Text = "" 'value debit
       ElseIf CheckID(TxtID2_CRatio.Text) = True Then
                        'And TxtName2_CRatio.Text = "" And TxtMoney2_CRatio.Text = "" Then
                        If TxtID2_CRatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtID2_CRatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtID2_CRatio.Text, 1) 'check is Debt?
                                                                                            
                                If a$ = "2" Then  'is Debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtID2_CRatio.Text
                                                TxtName2_CRatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoney2_CRatio.Text = acc_data.rsgetPlanD.Fields(3) 'value crebit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtID2_CRatio.Text
                                                TxtName2_CRatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoney2_CRatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'Cmd_Cal.SetFocus  'next text box
                                Else 'is't Debt
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        chCRatio = True  'show plan
                                        TxtID2_CRatio.Text = ""
                                        TxtName2_CRatio.Text = ""
                                        TxtMoney2_CRatio.Text = ""
                                        TxtID2_CRatio.SetFocus  'key new
                                End If
                        Else
                        TxtName2_CRatio.Text = "" 'name
                        TxtMoney2_CRatio.Text = "" 'value debit
                        End If
        End If
End Sub

Function CheckID(cmp As String) As Boolean
     Dim i As Integer
     Dim Sum As Long
     Dim ch As Boolean
     ch = False
     Call check_rs
     acc_data.cn_plan.Open
     acc_data.plan
     Sum = acc_data.rsplan.RecordCount  'total row of plan
     i = 0
     Do While i < Sum
        If cmp = acc_data.rsplan.Fields(0) Then 'check id_account in table plan_account
            ch = True 'have id_account in table plan_account
            Exit Do
        Else:   i = i + 1
                    acc_data.rsplan.MoveNext
        End If
     Loop
     
     If ch = True Then
        Call check_rs
        acc_data.cn_plan.Open
        acc_data.checkSummary
        Sum = acc_data.rscheckSummary.RecordCount  'total row of summary_plan
        i = 0
        Do While i < Sum
            If cmp = acc_data.rscheckSummary.Fields(0) Then
                CheckID = True  'have id_account in table summary_plan_d and g
                Exit Function
            Else:   i = i + 1
                        acc_data.rscheckSummary.MoveNext
            End If
        Loop
        CheckID = False  'have not  id_account in table summary_plan_d and g
     Else: CheckID = False 'have not id_account in table plan_account
     End If
End Function

