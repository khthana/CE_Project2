VERSION 5.00
Begin VB.Form frmSp_DERatio 
   BorderStyle     =   3  'Fixed Dialog
   ClientHeight    =   5370
   ClientLeft      =   255
   ClientTop       =   1410
   ClientWidth     =   8895
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "frmSp_DERatio.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5370
   ScaleWidth      =   8895
   ShowInTaskbar   =   0   'False
   Begin VB.Frame Fram_DERatio 
      Caption         =   "�ѵ����ǹ˹���Թ�����ǹ�ͧ��Ңͧ ( Debt-to-equity Ratio )"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5205
      Left            =   120
      TabIndex        =   0
      Top             =   0
      Width           =   8625
      Begin VB.CommandButton CmdSave 
         Caption         =   "�ѹ�֡���Ѿ��"
         Height          =   375
         Left            =   6120
         TabIndex        =   23
         Top             =   2550
         Width           =   1935
      End
      Begin VB.PictureBox Pic_DERatio 
         Height          =   1695
         Left            =   480
         ScaleHeight     =   1635
         ScaleWidth      =   7515
         TabIndex        =   18
         Top             =   3240
         Width           =   7575
         Begin VB.Label LabAnalyse4_DERatio 
            AutoSize        =   -1  'True
            Caption         =   "��á������Թ�ҡ���˹��з����ҡ"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   22
            Top             =   1200
            Width           =   2280
         End
         Begin VB.Label LabAnalyse3_DERatio 
            AutoSize        =   -1  'True
            Caption         =   "������� ��áԨ���Թ��Ѿ�����ʹ˹����Ъ���˹���Թ���� ��觨��ʴ���Ҹ�áԨ�դ�������§�٧"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   21
            Top             =   840
            Width           =   6165
         End
         Begin VB.Label LabAnalyse2_DERatio 
            AutoSize        =   -1  'True
            Caption         =   "�ѵ�ҹ���ʴ������繶֧��ǹ�ͧ��Ңͧ�������ö��仪���˹���Թ������ ����ѵ�ҹ���٧����"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   720
            TabIndex        =   20
            Top             =   480
            Width           =   6195
         End
         Begin VB.Label LabAnalyse1_DERatio 
            Alignment       =   2  'Center
            AutoSize        =   -1  'True
            Caption         =   "//**********  ����������� �ѵ����ǹ˹���Թ�����ǹ�ͧ��Ңͧ  **********//"
            BeginProperty Font 
               Name            =   "MS Sans Serif"
               Size            =   9.75
               Charset         =   222
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   240
            Left            =   540
            TabIndex        =   19
            Top             =   120
            Width           =   6315
         End
      End
      Begin VB.CommandButton CmdESC_DERatio 
         Caption         =   "¡��ԡ��¡��"
         Height          =   375
         Left            =   6120
         TabIndex        =   5
         Top             =   2170
         Width           =   1935
      End
      Begin VB.CommandButton CmdClear_DERatio 
         Caption         =   "Clear"
         Height          =   375
         Left            =   6120
         TabIndex        =   4
         Top             =   1795
         Width           =   1935
      End
      Begin VB.CommandButton CmdCal_DERatio 
         Caption         =   "�ӹǳ"
         Height          =   375
         Left            =   6120
         TabIndex        =   3
         Top             =   1430
         Width           =   1935
      End
      Begin VB.TextBox TxtNameDebt_DERatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   10
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDDebt_DERatio 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtIDC_DERatio 
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2280
         TabIndex        =   2
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyDebt_DERatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   9
         TabStop         =   0   'False
         Top             =   600
         Width           =   1935
      End
      Begin VB.TextBox TxtMoneyC_DERatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   6120
         TabIndex        =   8
         TabStop         =   0   'False
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtNameC_DERatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   4200
         TabIndex        =   7
         Top             =   960
         Width           =   1935
      End
      Begin VB.TextBox TxtResult_DERatio 
         BackColor       =   &H80000004&
         Enabled         =   0   'False
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   330
         Left            =   3120
         TabIndex        =   6
         Top             =   2160
         Width           =   2175
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "�Ѻ��Ť�ԡ��� ��ͧ���ʺѭ��"
         ForeColor       =   &H000000FF&
         Height          =   195
         Left            =   2280
         TabIndex        =   24
         Top             =   1440
         Width           =   1830
      End
      Begin VB.Label LabMoney_DERatio 
         AutoSize        =   -1  'True
         Caption         =   "�ӹǹ�Թ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   6720
         TabIndex        =   17
         Top             =   330
         Width           =   705
      End
      Begin VB.Label LabPercent_DERatio 
         AutoSize        =   -1  'True
         Caption         =   "%"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   5350
         TabIndex        =   16
         Top             =   2160
         Width           =   180
      End
      Begin VB.Label LabResult_DERatio 
         AutoSize        =   -1  'True
         Caption         =   "�ѵ����ǹ˹���Թ�����ǹ�ͧ��Ңͧ = "
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   480
         TabIndex        =   15
         Top             =   2160
         Width           =   2565
      End
      Begin VB.Label LabName_DERatio 
         AutoSize        =   -1  'True
         Caption         =   "���ͺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   4800
         TabIndex        =   14
         Top             =   315
         Width           =   540
      End
      Begin VB.Label LabID_DERatio 
         AutoSize        =   -1  'True
         Caption         =   "���ʺѭ��"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   2880
         TabIndex        =   13
         Top             =   315
         Width           =   660
      End
      Begin VB.Label LabDebt 
         AutoSize        =   -1  'True
         Caption         =   "˹���Թ���"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1395
         TabIndex        =   12
         Top             =   600
         Width           =   720
      End
      Begin VB.Label LabC 
         AutoSize        =   -1  'True
         Caption         =   "��ǹ�ͧ��Ңͧ"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   9.75
            Charset         =   222
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Left            =   1035
         TabIndex        =   11
         Top             =   960
         Width           =   1080
      End
   End
End
Attribute VB_Name = "frmSp_DERatio"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public index As String
Public index1 As String

Private Sub CmdCal_DERatio_Click()
    Dim num1 As Double
    Dim num2 As Double
    Dim result As Double
    
    If ((TxtMoneyC_DERatio.Text = "") Or (TxtMoneyDebt_DERatio.Text = "") Or (TxtMoneyC_DERatio.Text = "" And TxtMoneyDebt_DERatio.Text = "")) Then
        MsgBox "�ӹǹ�Թ�Դ��Ҵ��س�����������ó�...!!! ", vbCritical + vbOKOnly, "�ӹǹ�Թ�Դ��Ҵ"
    ElseIf ((TxtIDC_DERatio.Text = "") Or (TxtIDDebt_DERatio.Text = "") Or (TxtIDC_DERatio.Text = "" And TxtIDDebt_DERatio.Text = "")) Then
        MsgBox "���ʼԴ��Ҵ��س�����������ó�...!!!", vbCritical + vbOKOnly, "���ʼԴ��Ҵ"
    Else
        num1 = CDbl(TxtMoneyC_DERatio.Text)
        num2 = CDbl(TxtMoneyDebt_DERatio.Text)
        result = num2 * 100
        If num1 <> 0 Then
            result = result / num1
            TxtResult_DERatio.Text = result
        Else: MsgBox "��ǹ�ͧ��Ңͧ�դ���� 0 �������ö �ӹǳ��", vbInformation + vbOKOnly, "Warning"
        End If
    End If
End Sub

Private Sub CmdClear_DERatio_Click()
        TxtIDC_DERatio.Text = "" 'id
        TxtNameC_DERatio.Text = "" 'name
        TxtMoneyC_DERatio.Text = "" 'value debit
        
        TxtIDDebt_DERatio.Text = "" 'id
        TxtNameDebt_DERatio.Text = "" 'name
        TxtMoneyDebt_DERatio.Text = "" 'value debit
        
        TxtResult_DERatio.Text = ""
End Sub

Private Sub CmdESC_DERatio_Click()
    Unload Me
    'Form_Leverage.Show
End Sub

Private Sub CmdSave_Click()
    If TxtResult_DERatio.Text <> "" Then
        Call check_rs
        acc_data.cn_plan.Open
        If MsgBox("�س��ͧ��úѹ�֡�����͡ Report ��������� ?", vbYesNo, "�ѹ�֡������") = vbYes Then
            acc_data.UpdateDERatio CDbl(TxtResult_DERatio.Text)
            TxtResult_DERatio.Text = ""
        End If
        acc_data.cn_plan.Close
    Else:   MsgBox "����բ����źѹ�֡", vbOKOnly + vbInformation, "Warning"
    End If

End Sub

Private Sub Form_Unload(Cancel As Integer)
    Unload frmPlan_DERatio
End Sub

Private Sub TxtIDC_DERatio_DblClick()
            TxtIDC_DERatio_LostFocus
            index1 = "3" 'mean Capital
            index = "2"
            frmPlan_DERatio.Show
End Sub

Private Sub TxtIDC_DERatio_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDC_DERatio.Text = "") Then
                        TxtIDC_DERatio.Text = "" 'id
                        TxtNameC_DERatio.Text = "" 'name
                        TxtMoneyC_DERatio.Text = "" 'value debit
                        TxtIDC_DERatio.SetFocus
                ElseIf CheckID(TxtIDC_DERatio.Text) = True Then    'if have id_account in table summary_plan_DE and g
                        If TxtIDC_DERatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDC_DERatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDC_DERatio.Text, 1) 'check is C?
                                                                                            
                                If a$ = "3" Then  'is C
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDC_DERatio.Text
                                                TxtNameC_DERatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyC_DERatio.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDC_DERatio.Text
                                                TxtNameC_DERatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyC_DERatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'CmdCal_DERatio.SetFocus  'next text box
                                Else 'is't C
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�ع...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDC_DERatio.Text = ""
                                        TxtNameC_DERatio.Text = ""
                                        TxtMoneyC_DERatio.Text = ""
                                        TxtIDC_DERatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameC_DERatio.Text = "" 'name
                        TxtMoneyC_DERatio.Text = "" 'value debit
                        End If
                Else: MsgBox "�ѭ�չ�������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDC_DERatio.Text = ""
                            TxtNameC_DERatio.Text = ""
                            TxtMoneyC_DERatio.Text = ""
                            TxtIDC_DERatio.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDC_DERatio_LostFocus()
      Dim a As String
      If (TxtIDC_DERatio.Text = "") Then
                TxtIDC_DERatio.Text = "" 'id
                TxtNameC_DERatio.Text = "" 'name
                TxtMoneyC_DERatio.Text = "" 'value debit
                'TxtIDC_DERatio.SetFocus
      ElseIf CheckID(TxtIDC_DERatio.Text) = False Then
                TxtIDC_DERatio.Text = ""
                TxtNameC_DERatio.Text = "" 'name
                TxtMoneyC_DERatio.Text = "" 'value debit
       ElseIf CheckID(TxtIDC_DERatio.Text) = True Then
                    'And  ( _
                    '(TxtNameC_DERatio.Text = "" And TxtMoneyC_DERatio.Text = "") or _
                    '(TxtNameC_DERatio.Text = "" And TxtMoneyC_DERatio.Text = "")Then
                        If TxtIDC_DERatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDC_DERatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDC_DERatio.Text <> "3") Then
                                    a = Left$(TxtIDC_DERatio.Text, 1) 'check is C?
                                Else: a = "3"
                                End If
                                                                                            
                                If a = "3" Then  'is C
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDC_DERatio.Text
                                                TxtNameC_DERatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyC_DERatio.Text = acc_data.rsgetPlanD.Fields(3) 'value credit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDC_DERatio.Text
                                                TxtNameC_DERatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyC_DERatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'TxtIDDebt_DERatio.SetFocus  'next text box
                                Else 'is't C
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ�ع...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        'chCRatio = True  'show plan
                                        TxtIDC_DERatio.Text = ""
                                        TxtNameC_DERatio.Text = ""
                                        TxtMoneyC_DERatio.Text = ""
                                        TxtIDC_DERatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameC_DERatio.Text = "" 'name
                        TxtMoneyC_DERatio.Text = "" 'value debit
                        End If
        End If
End Sub

Private Sub TxtIDDebt_DERatio_DblClick()
        TxtIDDebt_DERatio_LostFocus
        index1 = "2" 'mean Debt
        index = "1"
        frmPlan_DERatio.Show
End Sub

Private Sub TxtIDDebt_DERatio_KeyPress(KeyAscii As Integer)
        If KeyAscii = 13 Then
                Dim planType As String
                If (TxtIDDebt_DERatio.Text = "") Then
                        TxtIDDebt_DERatio.Text = "" 'id
                        TxtNameDebt_DERatio.Text = "" 'name
                        TxtMoneyDebt_DERatio.Text = "" 'value debit
                        TxtIDDebt_DERatio.SetFocus
                ElseIf CheckID(TxtIDDebt_DERatio.Text) = True Then    'if have id_account in table summary_plan_DE and g
                        If TxtIDDebt_DERatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt_DERatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                a$ = Left$(TxtIDDebt_DERatio.Text, 1) 'check is debt?
                                                                                            
                                If a$ = "2" Then  'is debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt_DERatio.Text
                                                TxtNameDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(3) 'value crebit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt_DERatio.Text
                                                TxtNameDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        TxtIDC_DERatio.SetFocus  'next text box
                                Else 'is't C
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt_DERatio.Text = ""
                                        TxtNameDebt_DERatio.Text = ""
                                        TxtMoneyDebt_DERatio.Text = ""
                                        TxtIDDebt_DERatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameDebt_DERatio.Text = "" 'name
                        TxtMoneyDebt_DERatio.Text = "" 'value debit
                        End If
                Else: MsgBox "���ʺѭ�չ�����������㹼ѧ�ѭ�������������¡���Դ���...!!! ", vbCritical + vbOKOnly, "���ʺѭ���������ó�"
                            TxtIDDebt_DERatio.Text = ""
                            TxtNameDebt_DERatio.Text = ""
                            TxtMoneyDebt_DERatio.Text = ""
                            TxtIDDebt_DERatio.SetFocus
                End If
        End If
End Sub

Private Sub TxtIDDebt_DERatio_LostFocus()
       Dim a As String
       If (TxtIDDebt_DERatio.Text = "") Then
                TxtIDDebt_DERatio.Text = "" 'id
                TxtNameDebt_DERatio.Text = "" 'name
                TxtMoneyDebt_DERatio.Text = "" 'value debit
                'TxtIDC_DERatio.SetFocus
       ElseIf CheckID(TxtIDDebt_DERatio.Text) = False Then
                TxtIDDebt_DERatio.Text = ""
                TxtNameDebt_DERatio.Text = "" 'name
                TxtMoneyDebt_DERatio.Text = "" 'value debit
       ElseIf CheckID(TxtIDDebt_DERatio.Text) = True Then
                        'And TxtNameDebt_DERatio.Text = "" And TxtMoneyDebt_DERatio.Text = "" Then
                        If TxtIDDebt_DERatio.Text <> "" Then
                                Call check_rs
                                acc_data.cn_plan.Open
                                acc_data.getType TxtIDDebt_DERatio.Text
                                planType = CStr(acc_data.rsgetType.Fields(0)) 'type G or D
                                
                                If (TxtIDDebt_DERatio.Text <> "2") Then
                                    a = Left$(TxtIDDebt_DERatio.Text, 1) 'check is Debt?
                                Else: a = "2"
                                End If
                                                                                            
                                If a = "2" Then  'is Debt
                                        If planType = "D" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanD TxtIDDebt_DERatio.Text
                                                TxtNameDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(1) 'name
                                                TxtMoneyDebt_DERatio.Text = acc_data.rsgetPlanD.Fields(3) 'value crebit
                                        ElseIf planType = "G" Then
                                                Call check_rs
                                                acc_data.cn_plan.Open
                                                acc_data.getPlanG TxtIDDebt_DERatio.Text
                                                TxtNameDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(1) 'name
                                                TxtMoneyDebt_DERatio.Text = acc_data.rsgetPlanG.Fields(3) 'value credit
                                        End If
                                        'Cmd_Cal.SetFocus  'next text box
                                Else 'is't Debt
                                        MsgBox "�ѭ�չ������㹼ѧ�ѭ����������������Ǵ˹���Թ...!!! ", vbCritical + vbOKOnly, "���ʺѭ�ռԴ��Ҵ"
                                        TxtIDDebt_DERatio.Text = ""
                                        TxtNameDebt_DERatio.Text = ""
                                        TxtMoneyDebt_DERatio.Text = ""
                                        TxtIDDebt_DERatio.SetFocus  'key new
                                End If
                        Else
                        TxtNameDebt_DERatio.Text = "" 'name
                        TxtMoneyDebt_DERatio.Text = "" 'value debit
                        End If
        End If
End Sub

