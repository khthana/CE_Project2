VERSION 5.00
Begin VB.Form close_account 
   BackColor       =   &H00FFFFC0&
   Caption         =   "�Դ�ѭ��"
   ClientHeight    =   2145
   ClientLeft      =   1650
   ClientTop       =   1245
   ClientWidth     =   3315
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   2145
   ScaleWidth      =   3315
   Begin VB.CommandButton Command2 
      Caption         =   "¡��ԡ"
      Height          =   375
      Left            =   1080
      TabIndex        =   3
      Top             =   1560
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��ŧ"
      Height          =   375
      Left            =   1080
      TabIndex        =   2
      Top             =   1080
      Width           =   1215
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   1920
      MaxLength       =   4
      TabIndex        =   0
      Top             =   480
      Width           =   1215
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFFC0&
      Caption         =   "��͹�շ���ͧ��ûԴ�ѭ��"
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   1695
   End
End
Attribute VB_Name = "close_account"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Dim idc() As String
Dim vmoney() As Currency
If Text1.Text = "" Then
    Exit Sub
End If

If Not IsNumeric(Text1.Text) Then
   MsgBox "�س��͹�ռԴ��Ҵ", vbOKOnly, "Warning"
   Exit Sub
End If
Dim ans As Integer
ans = MsgBox("�س��㨷��Դ�ѭ��������� ? �س��ӡ�� backup ������㹰ҹ�����������ѧ ?", vbYesNo, "Warning ! ")

If Not (ans = 7) Then
    acc_data.cn_close_acc.Open
    acc_data.concurrent_close
    acc_data.getthis_year
    Dim rc As Integer 'row count
    rc = acc_data.rsgetthis_year.RecordCount
    Dim i As Integer
    Dim l As Integer
    i = 1
    l = rc 'keep row count
    If rc > 0 Then
         ReDim idc(rc, 1) As String
         ReDim vmoney(rc, 2) As Currency
   
         Do
              idc(i, 1) = acc_data.rsgetthis_year.Fields(0)   'id account
              vmoney(i, 1) = acc_data.rsgetthis_year.Fields(1) 'debit
              vmoney(i, 2) = acc_data.rsgetthis_year.Fields(2)  'credit
       
              i = i + 1
              rc = rc - 1
              If rc > 0 Then
                 acc_data.rsgetthis_year.MoveNext
              End If
        Loop Until rc = 0
   End If

   acc_data.rsgetthis_year.Close

   If l > 0 Then
      i = 1
      Do
           acc_data.update_lastyear vmoney(i, 1), vmoney(i, 2), idc(i, 1)
        
           i = i + 1
           l = l - 1
      Loop Until l = 0
    End If

    acc_data.delthis_year ' delete all in grandthis_year table

    acc_data.del_voucher Text1.Text
    MsgBox " �Դ�ѭ���������º���� ", vbOKOnly, "Complete ! "
    acc_data.cn_close_acc.Close
    Unload Me
End If

End Sub

Private Sub Command2_Click()
Unload Me
End Sub
