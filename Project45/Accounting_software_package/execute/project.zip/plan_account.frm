VERSION 5.00
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form data_plan_account 
   Caption         =   "�����żѧ�ѭ��"
   ClientHeight    =   6270
   ClientLeft      =   1005
   ClientTop       =   810
   ClientWidth     =   7980
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form2"
   MDIChild        =   -1  'True
   ScaleHeight     =   6270
   ScaleWidth      =   7980
   Begin TabDlg.SSTab SSTab1 
      Height          =   6015
      Left            =   120
      TabIndex        =   3
      Top             =   120
      Width           =   7725
      _ExtentX        =   13626
      _ExtentY        =   10610
      _Version        =   393216
      TabHeight       =   520
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "plan_account.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame1"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "���"
      TabPicture(1)   =   "plan_account.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame2"
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "���ҧ����"
      TabPicture(2)   =   "plan_account.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame3"
      Tab(2).Control(0).Enabled=   0   'False
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame3 
         Caption         =   "������������żѧ�ѭ��"
         Height          =   5300
         Left            =   -74880
         TabIndex        =   30
         Top             =   360
         Width           =   7300
         Begin VB.TextBox id_account_new 
            Height          =   315
            Left            =   3000
            TabIndex        =   15
            Top             =   360
            Width           =   975
         End
         Begin VB.CommandButton Esc_new 
            Caption         =   "¡��ԡ��¡��"
            Height          =   495
            Left            =   5640
            TabIndex        =   28
            Top             =   4320
            Width           =   1215
         End
         Begin VB.CommandButton Save_new 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   495
            Left            =   4200
            TabIndex        =   26
            Top             =   4320
            Width           =   1215
         End
         Begin VB.Frame Frame7 
            Height          =   615
            Left            =   3000
            TabIndex        =   44
            Top             =   2760
            Width           =   2655
            Begin VB.OptionButton Option16 
               Caption         =   "�ѭ������"
               Height          =   255
               Left            =   1320
               TabIndex        =   25
               Top             =   240
               Width           =   975
            End
            Begin VB.OptionButton Option15 
               Caption         =   "������ѭ��"
               Height          =   255
               Left            =   120
               TabIndex        =   24
               Top             =   240
               Value           =   -1  'True
               Width           =   975
            End
         End
         Begin VB.Frame Frame6 
            Height          =   1335
            Left            =   3000
            TabIndex        =   43
            Top             =   1440
            Width           =   2655
            Begin VB.OptionButton Option14 
               Caption         =   "���.��ü�Ե"
               Height          =   375
               Left            =   1320
               TabIndex        =   23
               Top             =   840
               Width           =   1215
            End
            Begin VB.OptionButton Option13 
               Caption         =   "��������"
               Height          =   375
               Left            =   120
               TabIndex        =   22
               Top             =   840
               Width           =   1095
            End
            Begin VB.OptionButton Option12 
               Caption         =   "�����"
               Height          =   375
               Left            =   1320
               TabIndex        =   21
               Top             =   480
               Width           =   855
            End
            Begin VB.OptionButton Option11 
               Caption         =   "�ع"
               Height          =   375
               Left            =   120
               TabIndex        =   20
               Top             =   480
               Width           =   615
            End
            Begin VB.OptionButton Option10 
               Caption         =   "˹���Թ"
               Height          =   255
               Left            =   1320
               TabIndex        =   19
               Top             =   210
               Width           =   735
            End
            Begin VB.OptionButton Option9 
               Caption         =   "�Թ��Ѿ��"
               Height          =   255
               Left            =   120
               TabIndex        =   18
               Top             =   210
               Value           =   -1  'True
               Width           =   975
            End
         End
         Begin VB.TextBox name_account2_new 
            Height          =   315
            Left            =   3000
            TabIndex        =   17
            Top             =   1080
            Width           =   3500
         End
         Begin VB.TextBox name_account1_new 
            Height          =   315
            Left            =   3000
            TabIndex        =   16
            Top             =   720
            Width           =   3500
         End
         Begin VB.Label Label10 
            Caption         =   "���ʺѭ��"
            Height          =   255
            Left            =   2040
            TabIndex        =   42
            Top             =   360
            Width           =   735
         End
         Begin VB.Label Label9 
            Caption         =   "���ͺѭ��"
            Height          =   255
            Left            =   2160
            TabIndex        =   41
            Top             =   720
            Width           =   615
         End
         Begin VB.Label Label8 
            Caption         =   "���ͺѭ�� ( ���2 )"
            Height          =   255
            Left            =   1680
            TabIndex        =   40
            Top             =   1080
            Width           =   1095
         End
         Begin VB.Label Label7 
            Caption         =   "�������Ǵ�ѭ��㴢ͧ�к�"
            Height          =   255
            Left            =   600
            TabIndex        =   39
            Top             =   1560
            Width           =   2055
         End
         Begin VB.Label Label5 
            Caption         =   "��Դ�ͧ�ѭ��"
            Height          =   375
            Left            =   1680
            TabIndex        =   38
            Top             =   2880
            Width           =   1095
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "��䢼ѧ�ѭ��"
         Height          =   5300
         Left            =   -74880
         TabIndex        =   29
         Top             =   360
         Width           =   7300
         Begin VB.CommandButton save_edit 
            Caption         =   "�ѹ�֡��¡��"
            Height          =   495
            Left            =   4200
            TabIndex        =   46
            Top             =   4320
            Width           =   1215
         End
         Begin VB.CommandButton Esc_edit 
            Cancel          =   -1  'True
            Caption         =   "¡��ԡ��¡��"
            Height          =   495
            Left            =   5640
            TabIndex        =   45
            Top             =   4320
            Width           =   1215
         End
         Begin VB.Frame type_acount 
            Height          =   615
            Left            =   3000
            TabIndex        =   36
            Top             =   2760
            Width           =   2655
            Begin VB.OptionButton Option8 
               Caption         =   "�ѭ������"
               Height          =   375
               Left            =   1320
               TabIndex        =   14
               Top             =   150
               Width           =   975
            End
            Begin VB.OptionButton Option7 
               Caption         =   "������ѭ��"
               Height          =   375
               Left            =   120
               TabIndex        =   13
               Top             =   150
               Width           =   1095
            End
         End
         Begin VB.Frame group_acount 
            Height          =   1335
            Left            =   3000
            TabIndex        =   35
            Top             =   1440
            Width           =   2655
            Begin VB.OptionButton Option6 
               Caption         =   "���.��ü�Ե"
               Height          =   375
               Left            =   1320
               TabIndex        =   12
               Top             =   840
               Width           =   1215
            End
            Begin VB.OptionButton Option5 
               Caption         =   "��������"
               Height          =   375
               Left            =   120
               TabIndex        =   11
               Top             =   840
               Width           =   975
            End
            Begin VB.OptionButton Option4 
               Caption         =   "�����"
               Height          =   375
               Left            =   1320
               TabIndex        =   10
               Top             =   480
               Width           =   855
            End
            Begin VB.OptionButton Option3 
               Caption         =   "�ع"
               Height          =   375
               Left            =   120
               TabIndex        =   9
               Top             =   480
               Width           =   615
            End
            Begin VB.OptionButton Option2 
               Caption         =   "˹���Թ"
               Height          =   375
               Left            =   1320
               TabIndex        =   8
               Top             =   120
               Width           =   735
            End
            Begin VB.OptionButton Option1 
               Caption         =   "�Թ��Ѿ��"
               Height          =   375
               Left            =   120
               TabIndex        =   7
               Top             =   150
               Width           =   975
            End
         End
         Begin VB.TextBox name_account2_edit 
            Height          =   315
            Left            =   3000
            TabIndex        =   2
            Top             =   1080
            Width           =   3500
         End
         Begin VB.TextBox name_account1_edit 
            Height          =   315
            Left            =   3000
            TabIndex        =   1
            Top             =   720
            Width           =   3500
         End
         Begin VB.TextBox id_account_edit 
            BackColor       =   &H80000004&
            Enabled         =   0   'False
            Height          =   315
            Left            =   3000
            Locked          =   -1  'True
            TabIndex        =   0
            Top             =   360
            Width           =   975
         End
         Begin VB.Label Label6 
            Caption         =   "��Դ�ͧ�ѭ��"
            Height          =   375
            Left            =   1680
            TabIndex        =   37
            Top             =   2880
            Width           =   1095
         End
         Begin VB.Label Label4 
            Caption         =   "�������Ǵ�ѭ��㴢ͧ�к�"
            Height          =   255
            Left            =   600
            TabIndex        =   34
            Top             =   1560
            Width           =   2055
         End
         Begin VB.Label Label3 
            Caption         =   "���ͺѭ�� ( ���2 )"
            Height          =   255
            Left            =   1680
            TabIndex        =   33
            Top             =   1080
            Width           =   1095
         End
         Begin VB.Label Label2 
            Caption         =   "���ͺѭ��"
            Height          =   255
            Left            =   2160
            TabIndex        =   32
            Top             =   720
            Width           =   615
         End
         Begin VB.Label Label1 
            Caption         =   "���ʺѭ��"
            Height          =   255
            Left            =   2040
            TabIndex        =   31
            Top             =   360
            Width           =   735
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "�ѧ�ѭ��"
         Height          =   5300
         Left            =   120
         TabIndex        =   27
         Top             =   360
         Width           =   7300
         Begin VB.CommandButton Command1 
            Caption         =   "�͡ Report"
            Height          =   495
            Left            =   2640
            TabIndex        =   47
            Top             =   4440
            Width           =   1215
         End
         Begin VB.CommandButton del_detial 
            Caption         =   "ź��¡��"
            Height          =   495
            Left            =   4200
            TabIndex        =   5
            Top             =   4440
            Width           =   1215
         End
         Begin VB.CommandButton Esc_detial 
            Caption         =   "¡��ԡ��¡��"
            Height          =   495
            Left            =   5760
            TabIndex        =   6
            Top             =   4440
            Width           =   1215
         End
         Begin MSDataGridLib.DataGrid DataGrid1 
            Height          =   3735
            Left            =   120
            TabIndex        =   4
            Top             =   360
            Width           =   6975
            _ExtentX        =   12303
            _ExtentY        =   6588
            _Version        =   393216
            BackColor       =   12648447
            Enabled         =   -1  'True
            ForeColor       =   255
            HeadLines       =   1
            RowHeight       =   15
            FormatLocked    =   -1  'True
            BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
               Name            =   "MS Sans Serif"
               Size            =   8.25
               Charset         =   222
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ColumnCount     =   3
            BeginProperty Column00 
               DataField       =   "id_account"
               Caption         =   "���ʺѭ��"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1054
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column01 
               DataField       =   "name_account"
               Caption         =   "���ͺѭ��"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1054
                  SubFormatType   =   0
               EndProperty
            EndProperty
            BeginProperty Column02 
               DataField       =   "type_account"
               Caption         =   "�������ѭ��"
               BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
                  Type            =   0
                  Format          =   ""
                  HaveTrueFalseNull=   0
                  FirstDayOfWeek  =   0
                  FirstWeekOfYear =   0
                  LCID            =   1054
                  SubFormatType   =   0
               EndProperty
            EndProperty
            SplitCount      =   1
            BeginProperty Split0 
               BeginProperty Column00 
                  ColumnWidth     =   1454.74
               EndProperty
               BeginProperty Column01 
                  ColumnWidth     =   4199.811
               EndProperty
               BeginProperty Column02 
                  ColumnWidth     =   1005.165
               EndProperty
            EndProperty
         End
      End
   End
End
Attribute VB_Name = "data_plan_account"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public id_account As String


Private Sub Command1_Click()
mainReport.Show
End Sub

Private Sub del_detial_Click()
Dim i1 As Integer
Dim i2 As Integer
Dim i3 As Integer
            If Not IsNumeric(DataGrid1.Text) Then
                        MsgBox ("��س����͡������������ʺѭ�����ͷӡ��ź������")
                        
                        Call cheak_dataenvironment   '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        Call detial_account
                        Exit Sub
                        
            End If

            i1 = MsgBox("�س��㨷���ź record id_account= '" & DataGrid1.Text & "' �������", vbYesNo)
            
            If Not (i1 = 7) Then
                        acc_data.check_vitem  ' ��Ǩ㹵��ҧ  voucher_item
                        i2 = acc_data.rscheck_vitem.RecordCount
                        acc_data.rscheck_vitem.Close
                        acc_data.check_lyear  ' ��Ǩ㹵��ҧ�ʹ¡��
                        i3 = acc_data.rscheck_lyear.RecordCount
                        acc_data.rscheck_lyear.Close
                        If (i2 > 0) Or (i3 > 0) Then
                           MsgBox "�������öź�����ͧ�ҡ�ա���������ҹ�к������", vbOKOnly, "Warning ! "
                        Else
                             acc_data.del_id DataGrid1.Text  'delete data base  ���   id
                        End If
                        
                        Call cheak_dataenvironment   '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        Call detial_account
            End If
End Sub

Private Sub Esc_detial_Click()
            Call cheak_dataenvironment
            Unload Me
            'navigator.Show
End Sub

Private Sub Esc_edit_Click()
            Call cheak_dataenvironment
            SSTab1.Tab = 0
            
End Sub

Private Sub Esc_new_Click()
              id_account_new.Text = ""
              name_account1_new.Text = ""
              name_account2_new.Text = ""
              
             Call cheak_dataenvironment
            SSTab1.Tab = 0
End Sub

Private Sub Form_Load()
            Call detial_account
            SSTab1.Tab = 0
End Sub

Private Sub Frame1_Click()
Call cheak_dataenvironment
 acc_data.cn_plan.Open
 acc_data.concurrent_plan
                acc_data.plan
 
                With acc_data.rsplan
                        If .RecordCount > 0 Then      '�� record � table �������?
                                Set DataGrid1.DataSource = acc_data.rsplan
                       End If
                End With
                
                acc_data.cn_plan.Close

End Sub


Private Sub save_edit_Click()
Dim ch1 As String
Dim ch2 As String

        If (0 = Len(id_account_edit.Text)) Then
                MsgBox ("�س������͹���ʺѭ��")
                Exit Sub
        Else
                If Not IsNumeric(id_account_edit.Text) Then
                            MsgBox ("�س��͹���ʺѭ�ռԴ��Ҵ")
                            Exit Sub
                End If
            
                If (Option7.Value = True) Then
                            ch1 = "G"
                Else
                            ch1 = "D"
                End If

                If (Option1.Value = True) Then
                            ch2 = Option1.Caption
               ElseIf (Option2.Value = True) Then
                        ch2 = Option2.Caption
                        ElseIf (Option3.Value = True) Then
                                ch2 = Option3.Caption
                                ElseIf (Option4.Value = True) Then
                                            ch2 = Option4.Caption
                                            ElseIf (Option5.Value = True) Then
                                                        ch2 = Option5.Caption
                                                        ElseIf (Option6.Value = True) Then
                                                                    ch2 = Option6.Caption
                                                                    ElseIf name_account2_edit.Text = "" Then
                                                                             name_account2_edit.Text = "-"
               End If
                
                acc_data.update_account id_account_edit.Text, name_account1_edit.Text, name_account2_edit.Text, ch1, ch2, Len(id_account_edit.Text), id_account
                
                'Len(id_account_edit.Text) = �������дѺ�ͧ�к��ѭ��
                If name_account2_edit.Text = "-" Then
                        name_account2_edit.Text = ""
                End If

                MsgBox ("�ѹ�֡���������º����")
                Call cheak_dataenvironment
                
                If ch1 = "D" Then
                     acc_data.cn_grandly.Open
                     acc_data.concurrent_grand
                     acc_data.get_lastyear id_account_edit.Text
                    If acc_data.rsget_lastyear.RecordCount = 0 Then
                        acc_data.insert_glast id_account_edit.Text, 0, 0
                    End If
                      acc_data.cn_grandly.Close
                End If
                
                SSTab1.Tab = 0
        End If
                        
End Sub

Private Sub save_new_Click()
Dim ch1 As String
Dim ch2 As String
Dim l1 As Integer
Dim id_chk As String
Dim i As Integer
Dim l As Integer
Dim tmp1 As String
Dim tmp2 As String


        If (Option15.Value = True) Then
                ch1 = "G"
        Else
                ch1 = "D"
        End If
        
        If (Option9.Value = True) Then
                ch2 = Option9.Caption
                ElseIf (Option10.Value = True) Then
                            ch2 = Option10.Caption
                        ElseIf (Option11.Value = True) Then
                                ch2 = Option11.Caption
                                ElseIf (Option12.Value = True) Then
                                        ch2 = Option12.Caption
                                        ElseIf (Option13.Value = True) Then
                                                 ch2 = Option13.Caption
                                                 ElseIf (Option14.Value = True) Then
                                                          ch2 = Option14.Caption
        End If
        
        
        If id_account_new.Text = "" Then  ' ��Ǩ�����Դ��Ҵ�ͧ������"���ʺѭ��"
                  MsgBox ("�س�ѧ������͹���ʺѭ��")
                  Call cheak_dataenvironment
                  id_account_new.SetFocus
                  Exit Sub
        End If


       If Not IsNumeric(id_account_new.Text) Then
                   MsgBox ("�س��͹���ʺѭ�ռԴ��Ҵ")
                   Call cheak_dataenvironment
                   id_account_new.SetFocus
        End If

If name_account1_new.Text = "" Then
     MsgBox ("�س�ѧ������͹���ͺѭ��")
     Call cheak_dataenvironment
     name_account1_new.SetFocus
     Exit Sub
End If


acc_data.cn_plan.Open
acc_data.concurrent_plan
acc_data.chk_repeat id_account_new.Text

If acc_data.rschk_repeat.RecordCount > 0 Then   '��Ǵ��ա�ë�͹�ѹ�ͧ�������������
        MsgBox ("ERROR DATA �������ö INSERT �� �Ҩ���������ʺѭ�ի�ӡѺ�������������")
        Call cheak_dataenvironment
        id_account_new.SetFocus
        Exit Sub
End If
If name_account2_new.Text = "" Then
name_account2_new.Text = "-"
End If
acc_data.insert_account id_account_new.Text, name_account1_new.Text, name_account2_new.Text, ch1, ch2, Len(id_account_new.Text)
If ch1 = "D" Then
   acc_data.insert_grandl id_account_new.Text, 0, 0
End If
Call cheak_dataenvironment


id_account_new.Text = ""
name_account1_new.Text = ""
name_account2_new.Text = ""
Option9.Value = True
Option15.Value = True



End Sub

Private Sub SSTab1_Click(PreviousTab As Integer)
               
                Call cheak_dataenvironment   '��Ǩ�ͺ����Դ data base �ͧdata environmant
                
Select Case SSTab1.Tab
Case 0
                'Unload Me
                'data_plan_account.Show
                Call detial_account
Case 1
                'name_account1_edit.SetFocus
                Call edit_tab
Case 2
                id_account_new.SetFocus

End Select

End Sub

Private Sub cheak_dataenvironment()

            If acc_data.cn_plan.State = adStateOpen Then  '��Ǩ�ͺ����Դ data base �ͧdata environmant
                        acc_data.cn_plan.Close
            End If

End Sub

Private Sub detial_account()
            Call cheak_dataenvironment
            acc_data.cn_plan.Open
            acc_data.concurrent_plan
            acc_data.plan
 
                With acc_data.rsplan
                        If .RecordCount > 0 Then      '�� record � table �������?
                                Set DataGrid1.DataSource = acc_data.rsplan
                       End If
    
                End With
            'Call cheak_dataenvironment
End Sub

Private Sub edit_tab()

Dim group1 As String
Dim type1 As String
Dim level_p As String
Dim name2 As String
            
            
            
            If Not IsNumeric(id_account) Then
                    id_account_edit.Text = ""
                    name_account1_edit.Text = ""
                    name_account2_edit.Text = ""
                    
            
                    id_account_edit.Enabled = False
                    name_account1_edit.Enabled = False
                    name_account2_edit.Enabled = False
                    group_acount.Enabled = False
                    type_acount.Enabled = False
                    
                    MsgBox ("��س����͡������������ʺѭ�����ͷӡ����䢢�����")
                    
            Else
                    
                    'name_account1_edit.SetFocus
                    
                    id_account_edit.Enabled = True
                    name_account1_edit.Enabled = True
                    name_account2_edit.Enabled = True
                    group_acount.Enabled = True
                    type_acount.Enabled = True
                    
                    acc_data.cn_plan.Open
                    acc_data.concurrent_plan
                    acc_data.chk_repeat (id_account)
                    id_account_edit.Text = acc_data.rschk_repeat.Fields(0)
                    name_account1_edit.Text = acc_data.rschk_repeat.Fields(1)

                    If ((acc_data.rschk_repeat.Fields(2)) = "-") Then
                            name2 = ""
                    Else
                            name2 = "data" 'for if condition next do pass datafield to text3
                    End If

                    If (name2 = "") Then
                            name_account2_edit.Text = ""
                    Else
                            name_account2_edit.Text = acc_data.rschk_repeat.Fields(2) 'name_account2
                    End If

                    type1 = acc_data.rschk_repeat.Fields(3) 'type_account
                    group1 = acc_data.rschk_repeat.Fields(4) 'group_account
                    level_p = acc_data.rschk_repeat.Fields(5) 'level_account

                    If (type1 = "G") Then  ' set ��Դ�ѭ��
                            Option7.Value = True
                    Else
                            Option8.Value = True
                    End If

                    If (group1 = Option1.Caption) Then
                            Option1.Value = True
                            ElseIf (group1 = Option2.Caption) Then
                                    Option2.Value = True
                                    ElseIf (group1 = Option3.Caption) Then
                                            Option3.Value = True
                                            ElseIf (group1 = Option4.Caption) Then
                                                    Option4.Value = True
                                                    ElseIf (group1 = Option5.Caption) Then
                                                                Option5.Value = True
                                                                Else: Option6.Value = True
                        End If

            End If

End Sub


Private Sub SSTab1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
On Error Resume Next
        id_account = DataGrid1.Text
End Sub
