VERSION 5.00
Begin VB.Form new_row_plan 
   BackColor       =   &H00FFFF80&
   Caption         =   "���������żѧ�ѭ��"
   ClientHeight    =   7095
   ClientLeft      =   3360
   ClientTop       =   2805
   ClientWidth     =   9885
   Icon            =   "new_row_plan.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   7095
   ScaleWidth      =   9885
   WindowState     =   2  'Maximized
   Begin VB.PictureBox Picture2 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   225
      Left            =   7560
      Picture         =   "new_row_plan.frx":0442
      ScaleHeight     =   225
      ScaleWidth      =   240
      TabIndex        =   21
      Top             =   6240
      Width           =   240
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   5400
      Picture         =   "new_row_plan.frx":0974
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   20
      Top             =   6240
      Width           =   240
   End
   Begin VB.CommandButton Command2 
      Caption         =   "EXIT"
      Height          =   495
      Left            =   7440
      TabIndex        =   19
      Top             =   6120
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "SAVE"
      Height          =   495
      Left            =   5280
      TabIndex        =   18
      Top             =   6120
      Width           =   1335
   End
   Begin VB.Frame Frame2 
      BackColor       =   &H00FFFF80&
      Height          =   615
      Left            =   5280
      TabIndex        =   15
      Top             =   4800
      Width           =   3255
      Begin VB.OptionButton Option8 
         BackColor       =   &H00FFFF80&
         Caption         =   "�ѭ������"
         Height          =   255
         Left            =   1920
         TabIndex        =   17
         Top             =   240
         Width           =   1215
      End
      Begin VB.OptionButton Option7 
         BackColor       =   &H00FFFF80&
         Caption         =   "������ѭ��"
         Height          =   255
         Left            =   240
         TabIndex        =   16
         Top             =   240
         Value           =   -1  'True
         Width           =   1455
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00FFFF80&
      Height          =   2175
      Left            =   5280
      TabIndex        =   8
      Top             =   2520
      Width           =   3255
      Begin VB.OptionButton Option6 
         BackColor       =   &H00FFFF80&
         Caption         =   "���.��ü�Ե"
         Height          =   375
         Left            =   1680
         TabIndex        =   14
         Top             =   1200
         Width           =   1215
      End
      Begin VB.OptionButton Option5 
         BackColor       =   &H00FFFF80&
         Caption         =   "��������"
         Height          =   375
         Left            =   240
         TabIndex        =   13
         Top             =   1200
         Width           =   1215
      End
      Begin VB.OptionButton Option4 
         BackColor       =   &H00FFFF80&
         Caption         =   "�����"
         Height          =   495
         Left            =   1680
         TabIndex        =   12
         Top             =   600
         Width           =   1215
      End
      Begin VB.OptionButton Option3 
         BackColor       =   &H00FFFF80&
         Caption         =   "�ع"
         Height          =   255
         Left            =   240
         TabIndex        =   11
         Top             =   720
         Width           =   1095
      End
      Begin VB.OptionButton Option2 
         BackColor       =   &H00FFFF80&
         Caption         =   "˹���Թ"
         Height          =   435
         Left            =   1680
         TabIndex        =   10
         Top             =   120
         Width           =   855
      End
      Begin VB.OptionButton Option1 
         BackColor       =   &H00FFFF80&
         Caption         =   "�Թ��Ѿ��"
         Height          =   315
         Left            =   240
         TabIndex        =   9
         Top             =   240
         Value           =   -1  'True
         Width           =   1215
      End
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Left            =   5280
      MaxLength       =   72
      TabIndex        =   2
      Top             =   1680
      Width           =   3855
   End
   Begin VB.TextBox Text2 
      Height          =   375
      Left            =   5280
      MaxLength       =   72
      TabIndex        =   1
      Top             =   1080
      Width           =   3855
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   5280
      MaxLength       =   11
      TabIndex        =   0
      Top             =   480
      Width           =   2295
   End
   Begin VB.Label Label5 
      BackColor       =   &H00FFFF80&
      Caption         =   "��Դ�ͧ�ѭ��"
      Height          =   375
      Left            =   3000
      TabIndex        =   7
      Top             =   5040
      Width           =   1215
   End
   Begin VB.Label Label4 
      BackColor       =   &H00FFFF80&
      Caption         =   "�������Ǵ�ѭ��㴢ͧ�к�"
      Height          =   375
      Left            =   3120
      TabIndex        =   6
      Top             =   2400
      Width           =   2295
   End
   Begin VB.Label Label3 
      BackColor       =   &H00FFFF80&
      Caption         =   "���ͺѭ�� ( ���2 )"
      Height          =   375
      Left            =   3120
      TabIndex        =   5
      Top             =   1800
      Width           =   1455
   End
   Begin VB.Label Label2 
      BackColor       =   &H00FFFF80&
      Caption         =   "���ͺѭ��"
      Height          =   255
      Left            =   3120
      TabIndex        =   4
      Top             =   1200
      Width           =   855
   End
   Begin VB.Label Label1 
      BackColor       =   &H00FFFF80&
      Caption         =   "���ʺѭ��"
      Height          =   375
      Left            =   3120
      TabIndex        =   3
      Top             =   600
      Width           =   855
   End
End
Attribute VB_Name = "new_row_plan"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
Dim ch1 As String
Dim ch2 As String
Dim l1 As Integer
Dim id_chk As String
Dim i As Integer
Dim l As Integer
Dim tmp1 As String
Dim tmp2 As String

ch2 = text1.Text
l1 = Len(ch2)
If (Option7.Value = True) Then
ch1 = "G"
Else
      ch1 = "D"
End If
If (Option1.Value = True) Then
     ch2 = Option1.Caption
End If
If (Option2.Value = True) Then
    ch2 = Option2.Caption
End If
If (Option3.Value = True) Then
    ch2 = Option3.Caption
End If
If (Option4.Value = True) Then
    ch2 = Option4.Caption
End If
If (Option5.Value = True) Then
   ch2 = Option5.Caption
End If
If (Option6.Value = True) Then
   ch2 = Option6.Caption
End If
If text1.Text = "" Then
     MsgBox ("�س�ѧ������͹���ʺѭ��")
     GoTo again
End If

id_chk = text1.Text
i = Len(id_chk)
If (i = 0) Then
   GoTo again
End If
l = 1
i = i - 1
tmp1 = id_chk
Do Until i < 0
tmp2 = Left$(tmp1, i)
tmp1 = Right$(tmp1, 1)
If (tmp1 < "0") Or (tmp1 > "9") Then
     MsgBox ("�س��͹���ʺѭ�ռԴ��Ҵ")
    GoTo again
End If
tmp1 = tmp2
i = i - 1
Loop

If Text2.Text = "" Then
     MsgBox ("�س�ѧ������͹���ͺѭ��")
     GoTo again
End If


acc_data.cn_plan.Open
acc_data.chk_repeat text1.Text
If acc_data.rschk_repeat.RecordCount > 0 Then
    GoTo problem
End If
If Text3.Text = "" Then
Text3.Text = "-"
End If
acc_data.insert_account text1.Text, Text2.Text, Text3.Text, ch1, ch2, l1

On Error GoTo problem
GoTo complete
problem: MsgBox ("ERROR DATA �������ö INSERT �� �Ҩ���������ʺѭ�ի�ӡѺ�������������")
                  GoTo again
complete:

text1.Text = ""
Text2.Text = ""
Text3.Text = ""
Option1.Value = True
Option7.Value = True
GoTo ends

again: new_row_plan.Show
ends:   acc_data.cn_plan.Close
End Sub

Private Sub Command2_Click()
Unload Me
plan.Show
End Sub


