VERSION 5.00
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form plan 
   BackColor       =   &H00FFFF80&
   Caption         =   "�ѧ�ѭ��"
   ClientHeight    =   4980
   ClientLeft      =   4950
   ClientTop       =   2055
   ClientWidth     =   6570
   Icon            =   "plan.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   4980
   ScaleWidth      =   6570
   WindowState     =   2  'Maximized
   Begin VB.PictureBox Picture4 
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   8520
      Picture         =   "plan.frx":0442
      ScaleHeight     =   255
      ScaleWidth      =   255
      TabIndex        =   8
      Top             =   6480
      Width           =   255
   End
   Begin Crystal.CrystalReport crp1 
      Left            =   10560
      Top             =   1200
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      PrintFileLinesPerPage=   60
   End
   Begin VB.CommandButton Command4 
      Caption         =   "PRINT"
      Height          =   495
      Left            =   8400
      TabIndex        =   7
      Top             =   6360
      Width           =   1575
   End
   Begin VB.PictureBox Picture3 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   6000
      Picture         =   "plan.frx":0974
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   6
      Top             =   6480
      Width           =   240
   End
   Begin VB.PictureBox Picture2 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   3840
      Picture         =   "plan.frx":0A76
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   5
      Top             =   6480
      Width           =   240
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   225
      Left            =   1680
      Picture         =   "plan.frx":0B78
      ScaleHeight     =   225
      ScaleWidth      =   240
      TabIndex        =   4
      Top             =   6480
      Width           =   240
   End
   Begin VB.CommandButton Command3 
      Caption         =   "DELETE"
      Height          =   495
      Left            =   5880
      TabIndex        =   3
      Top             =   6360
      Width           =   1455
   End
   Begin VB.CommandButton Command2 
      Caption         =   "EDIT"
      Height          =   495
      Left            =   3720
      TabIndex        =   2
      Top             =   6360
      Width           =   1455
   End
   Begin VB.CommandButton Command1 
      Caption         =   "NEW"
      Height          =   495
      Left            =   1560
      TabIndex        =   1
      Top             =   6360
      Width           =   1455
   End
   Begin MSDataGridLib.DataGrid DataGrid1 
      Height          =   4815
      Left            =   2160
      TabIndex        =   0
      Top             =   720
      Width           =   7335
      _ExtentX        =   12938
      _ExtentY        =   8493
      _Version        =   393216
      BackColor       =   12648447
      Enabled         =   -1  'True
      ForeColor       =   255
      HeadLines       =   1
      RowHeight       =   15
      FormatLocked    =   -1  'True
      BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ColumnCount     =   3
      BeginProperty Column00 
         DataField       =   "id_account"
         Caption         =   "���ʺѭ��"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1054
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column01 
         DataField       =   "name_account"
         Caption         =   "���ͺѭ��"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1054
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column02 
         DataField       =   "type_account"
         Caption         =   "�������ѭ��"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1054
            SubFormatType   =   0
         EndProperty
      EndProperty
      SplitCount      =   1
      BeginProperty Split0 
         BeginProperty Column00 
            ColumnWidth     =   1454.74
         EndProperty
         BeginProperty Column01 
            ColumnWidth     =   4199.811
         EndProperty
         BeginProperty Column02 
            ColumnWidth     =   1005.165
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "plan"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Public code As String
'Public cnn2 As Connection
'Public newp2 As Command
'Public rsnewp2 As Recordset

Private Sub Command1_Click()
acc_data.cn_plan.Close
Unload Me
new_row_plan.Show
End Sub

Private Sub Command2_Click()
Dim id_p As String
Dim i As Integer
Dim l As Integer
Dim tmp1 As String
Dim tmp2 As String
id_p = DataGrid1.Text
i = Len(id_p)
If (i = 0) Then
   GoTo none
End If
l = 1
i = i - 1
tmp1 = id_p
Do Until i < 0
tmp2 = Left$(tmp1, i)
tmp1 = Right$(tmp1, 1)
If (tmp1 < "0") Or (tmp1 > "9") Then
none:        MsgBox ("��س����͡������������ʺѭ�����ͷӡ����䢢�����")
    GoTo again
End If
tmp1 = tmp2
i = i - 1
Loop
plan_all.set_id (id_p)
acc_data.cn_plan.Close
Unload Me
edit_row_plan.Show
GoTo ex1
again: plan.Show
ex1:
End Sub

Private Sub Command3_Click()
'Dim cn As acc_data ' connection data   environment
Dim id_p1 As String
Dim i1 As Integer
Dim l1 As Integer
Dim tmp11 As String
Dim tmp12 As String
'Dim cnn1 As Connection
'Dim newp As Command
'Dim rsnewp As Recordset
'Set cnn1 = New Connection
'Set newp = New Command
'Set rsnewp = New Recordset

'Set cn = New acc_data

id_p1 = DataGrid1.Text
i1 = Len(id_p1)
If (i1 = 0) Then
   GoTo none1
End If
l1 = 1    'count loop
i1 = i1 - 1 'count loop
tmp11 = id_p1
Do Until i1 < 0 ' loop check id
tmp12 = Left$(tmp11, i1)
tmp11 = Right$(tmp11, 1)
If (tmp11 < "0") Or (tmp11 > "9") Then
none1:        MsgBox ("��س����͡������������ʺѭ�����ͷӡ��ź������")
    GoTo again1
End If
tmp11 = tmp12
i1 = i1 - 1
Loop
i1 = MsgBox("�س��㨷���ź record id_account= '" & id_p1 & "' �������", vbYesNo)
If (i1 = 7) Then
   GoTo again1
End If

acc_data.del_id id_p1  'delect data base  ���   id_p1

'Set cn = Nothing

'With cnn1
'.Provider = "MSDASQL"
'.ConnectionString = "User id=Administrtor;" & _
'                                      "Data Source=cn_accounting;" & _
'                                      "Initial Catalog=accounting_db"
'.Open
'End With

'Set rsnewp = cnn1.Execute("delete from plan_account  where id_account='" & id_p1 & "'")
'On Error GoTo problem

'cnn1.Close
'Set cnn1 = Nothing
'Set newp = Nothing
'Set rsnewp = Nothing
GoTo ex
again1: plan.Show
                GoTo ex1
ex:  acc_data.cn_plan.Close
       Unload Me
       plan.Show
ex1:
End Sub

Private Sub Command4_Click()
    crp1.ReportFileName = App.Path & "\plan2.rpt"
    crp1.Destination = crptToWindow
    crp1.WindowState = crptMaximized
    crp1.Action = 1
End Sub

Private Sub Form_Load()
'Dim sql As String
'Set cnn2 = New Connection
'Set newp2 = New Command
'Set rsnewp2 = New Recordset

'With cnn2
'.Provider = "MSDASQL"
'.ConnectionString = "User id=Administrtor;" & _
 '                                     "Data Source=cn_accounting;" & _
 '                                     "Initial Catalog=accounting_db"
'.Open
'End With

'Set rsnewp2 = cnn2.Execute("select id_account,name_account,type_account  from plan_account")
'With rsnewp2
      'Set DataGrid1.DataSource = rsnewp2
'End With
'sql = "select id_account,name_account,type_account  from plan_account order by id_account"

'With rsnewp2
 '           If .State = adStateOpen Then .Close
  '              .ActiveConnection = cnn2
   '             .CursorType = adOpenStatic
    '            .CursorLocation = adUseClient
     '           .Open sql
      '          If .RecordCount > 0 Then      '�� record � table �������?
       '             Set DataGrid1.DataSource = rsnewp2
              
        '        End If
        'End With
acc_data.cn_plan.Open
acc_data.plan
 
 With acc_data.rsplan
          If .RecordCount > 0 Then      '�� record � table �������?
             Set DataGrid1.DataSource = acc_data.rsplan
         End If
End With
End Sub

Private Sub Form_Unload(Cancel As Integer)
'cnn2.Close
'Set cnn2 = Nothing
'Set newp2 = Nothing
'Set rsnewp2 = Nothing
'acc_data.cn_plan.Close
End Sub
