VERSION 5.00
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form paperWork_report 
   Caption         =   "������д�ɷӡ��"
   ClientHeight    =   2160
   ClientLeft      =   2970
   ClientTop       =   3435
   ClientWidth     =   3645
   LinkTopic       =   "Form1"
   ScaleHeight     =   2160
   ScaleWidth      =   3645
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cancel_buttom 
      Caption         =   "¡��ԡ"
      Height          =   495
      Left            =   840
      TabIndex        =   4
      Top             =   1560
      Width           =   1215
   End
   Begin VB.Frame Frame2 
      Caption         =   "�ʴ��ҧ"
      Height          =   1335
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   3375
      Begin VB.OptionButton to_printer 
         Caption         =   "����ͧ�����"
         Height          =   495
         Left            =   240
         TabIndex        =   3
         Top             =   720
         Width           =   1215
      End
      Begin VB.OptionButton to_monitor 
         Caption         =   "������ҧ��͹�����"
         Height          =   495
         Left            =   240
         TabIndex        =   2
         Top             =   240
         Value           =   -1  'True
         Width           =   1575
      End
   End
   Begin VB.CommandButton commit 
      Caption         =   "��ŧ"
      Height          =   495
      Left            =   2160
      TabIndex        =   0
      Top             =   1560
      Width           =   1215
   End
   Begin Crystal.CrystalReport cry_report_project 
      Left            =   360
      Top             =   1560
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      ReportFileName  =   "C:\project\report_project\��д�ɷӡ��\paper_work.rpt"
      WindowState     =   2
      PrintFileLinesPerPage=   60
   End
End
Attribute VB_Name = "paperWork_report"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cancel_buttom_Click()
        Unload Me
End Sub

Private Sub commit_Click()
    Dim name_company As String
    acc_data.cn_company.Open
    acc_data.get_namec
    name_company = acc_data.rsget_namec.Fields(1)
    acc_data.cn_company.Close
    
    Dim strSelectionFormula As String
    
    'cry_report_project.ReportFileName = App.Path & "\paper_work.rpt"
     cry_report_project.WindowShowGroupTree = False
    cry_report_project.WindowTitle = "�����ͧ"
    
    '���͡����ʴ��Ż��·ҧ
     If to_monitor.Value Then cry_report_project.Destination = crptToWindow
     If to_printer.Value Then cry_report_project.Destination = crptToPrinter
     
    '@@@@@@@@@@@@@@@@@
    cry_report_project.Formulas(2) = "name_company=" & " ' " & name_company & " ' "
    
    cry_report_project.RetrieveDataFiles
    cry_report_project.Action = 1
        
End Sub
'Private Sub lev_plan_account_between_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
 '        If lev_plan_account_between.Value = True Then
  '                  from_lev.Enabled = True
   '                 to_lev.Enabled = True
    '        Else
     '               from_lev.Enabled = False
      '              to_lev.Enabled = False
       '     End If
'End Sub

