VERSION 5.00
Object = "{00025600-0000-0000-C000-000000000046}#5.2#0"; "Crystl32.OCX"
Begin VB.Form plan_report 
   Caption         =   "�����ѧ�ѭ��"
   ClientHeight    =   2085
   ClientLeft      =   6855
   ClientTop       =   2415
   ClientWidth     =   3630
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   2085
   ScaleWidth      =   3630
   Begin VB.CommandButton cancel_but 
      Caption         =   "¡��ԡ"
      Height          =   495
      Left            =   2280
      TabIndex        =   1
      Top             =   1440
      Width           =   1215
   End
   Begin VB.Frame Frame1 
      Caption         =   "�ʴ��ҧ"
      Height          =   1335
      Left            =   120
      TabIndex        =   2
      Top             =   0
      Width           =   3375
      Begin VB.OptionButton to_printer 
         Caption         =   "����ͧ�����"
         Height          =   495
         Left            =   360
         TabIndex        =   4
         Top             =   720
         Width           =   1215
      End
      Begin VB.OptionButton to_monitor 
         Caption         =   "������ҧ��͹�����"
         Height          =   495
         Left            =   360
         TabIndex        =   3
         Top             =   240
         Value           =   -1  'True
         Width           =   1575
      End
   End
   Begin VB.CommandButton commit 
      Caption         =   "��ŧ"
      Height          =   495
      Left            =   960
      TabIndex        =   0
      Top             =   1440
      Width           =   1215
   End
   Begin Crystal.CrystalReport cry_report_project 
      Left            =   360
      Top             =   1440
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   348160
      WindowControlBox=   -1  'True
      WindowMaxButton =   -1  'True
      WindowMinButton =   -1  'True
      WindowState     =   2
      PrintFileLinesPerPage=   60
   End
End
Attribute VB_Name = "plan_report"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cancel_but_Click()
            Unload Me
            
End Sub

Private Sub commit_Click()
    Dim name_company As String
     
     If acc_data.cn_company.State = adStateOpen Then
         acc_data.cn_company.Close
     End If
    
    acc_data.cn_company.Open
    acc_data.get_namec
    name_company = acc_data.rsget_namec.Fields(1)
    acc_data.cn_company.Close
    
    cry_report_project.ReportFileName = App.Path & "\reports\plan_account.rpt"
    cry_report_project.WindowShowGroupTree = False
    cry_report_project.WindowTitle = "�ѧ�ѭ��"
    cry_report_project.WindowShowRefreshBtn = True
       
    
    '���͡����ʴ��Ż��·ҧ
     If to_monitor.Value Then cry_report_project.Destination = crptToWindow
     If to_printer.Value Then cry_report_project.Destination = crptToPrinter
    
    cry_report_project.Formulas(2) = "head_page_company=" & " ' " & name_company & " ' "
    cry_report_project.RetrieveDataFiles
    cry_report_project.Action = 1
 
 End Sub
