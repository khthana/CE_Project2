VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form ENTER_DEPART 
   Caption         =   "���͡�Ңҷ���ͧ������价ӧҹ"
   ClientHeight    =   8235
   ClientLeft      =   1680
   ClientTop       =   1635
   ClientWidth     =   8745
   LinkTopic       =   "Form1"
   ScaleHeight     =   8235
   ScaleWidth      =   8745
   Begin TabDlg.SSTab SSTab1 
      Height          =   7815
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   8205
      _ExtentX        =   14473
      _ExtentY        =   13785
      _Version        =   393216
      Tab             =   1
      TabHeight       =   520
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "ENTER_DEPART.frx":0000
      Tab(0).ControlEnabled=   0   'False
      Tab(0).Control(0)=   "Frame1"
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "Edit"
      TabPicture(1)   =   "ENTER_DEPART.frx":001C
      Tab(1).ControlEnabled=   -1  'True
      Tab(1).Control(0)=   "Frame3"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "New"
      TabPicture(2)   =   "ENTER_DEPART.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame2"
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame3 
         Caption         =   "���"
         Height          =   6615
         Left            =   360
         TabIndex        =   14
         Top             =   840
         Width           =   7455
         Begin VB.CommandButton Command4 
            Caption         =   "Save"
            Height          =   375
            Left            =   5880
            TabIndex        =   36
            Top             =   5760
            Width           =   975
         End
         Begin VB.CommandButton Command3 
            Caption         =   "Esc"
            Height          =   375
            Left            =   4560
            TabIndex        =   35
            Top             =   5760
            Width           =   1095
         End
         Begin VB.TextBox Text10 
            Height          =   980
            Left            =   1680
            TabIndex        =   21
            Text            =   "Text10"
            Top             =   1440
            Width           =   4700
         End
         Begin VB.TextBox Text9 
            Height          =   980
            Left            =   1680
            TabIndex        =   20
            Text            =   "Text9"
            Top             =   2410
            Width           =   4700
         End
         Begin VB.TextBox Text7 
            Height          =   315
            Left            =   1680
            TabIndex        =   19
            Text            =   "Text7"
            Top             =   720
            Width           =   4695
         End
         Begin VB.TextBox Text6 
            Height          =   315
            Left            =   1680
            TabIndex        =   18
            Text            =   "Text6"
            Top             =   3480
            Width           =   1815
         End
         Begin VB.TextBox Text5 
            Height          =   315
            Left            =   1680
            TabIndex        =   17
            Text            =   "Text5"
            Top             =   1080
            Width           =   4695
         End
         Begin VB.TextBox Text2 
            Height          =   315
            Left            =   1680
            TabIndex        =   16
            Text            =   "Text2"
            Top             =   3840
            Width           =   1815
         End
         Begin VB.TextBox Text1 
            Height          =   315
            Left            =   1680
            TabIndex        =   15
            Text            =   "Text1"
            Top             =   360
            Width           =   1455
         End
         Begin VB.Label Label14 
            Caption         =   "����(���� 2)"
            Height          =   255
            Left            =   600
            TabIndex        =   32
            Top             =   1080
            Width           =   975
         End
         Begin VB.Label Label13 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   840
            TabIndex        =   31
            Top             =   3360
            Width           =   735
         End
         Begin VB.Label Label12 
            Caption         =   "�������(����2)"
            Height          =   375
            Left            =   600
            TabIndex        =   30
            Top             =   2400
            Width           =   855
         End
         Begin VB.Label Label11 
            Caption         =   "�����"
            Height          =   255
            Left            =   960
            TabIndex        =   29
            Top             =   3840
            Width           =   615
         End
         Begin VB.Label Label10 
            Caption         =   "�������(������)"
            Height          =   495
            Left            =   360
            TabIndex        =   28
            Top             =   1440
            Width           =   1215
         End
         Begin VB.Label Label9 
            Caption         =   "����(������)"
            Height          =   255
            Left            =   480
            TabIndex        =   27
            Top             =   720
            Width           =   975
         End
         Begin VB.Label Label6 
            Caption         =   "����"
            Height          =   255
            Left            =   1200
            TabIndex        =   26
            Top             =   360
            Width           =   375
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "���ҧ����"
         Height          =   6615
         Left            =   -74640
         TabIndex        =   3
         Top             =   840
         Width           =   7455
         Begin VB.CommandButton Command2 
            Caption         =   "Esc"
            Height          =   375
            Left            =   4320
            TabIndex        =   34
            Top             =   5760
            Width           =   975
         End
         Begin VB.CommandButton Command1 
            Caption         =   "Save"
            Height          =   375
            Left            =   5760
            TabIndex        =   33
            Top             =   5760
            Width           =   975
         End
         Begin VB.TextBox Text4 
            Height          =   315
            Left            =   1680
            TabIndex        =   24
            Text            =   "Text4"
            Top             =   1080
            Width           =   4695
         End
         Begin VB.TextBox Text16 
            Height          =   980
            Left            =   1680
            TabIndex        =   23
            Text            =   "Text16"
            Top             =   2410
            Width           =   4700
         End
         Begin VB.TextBox Text15 
            Height          =   980
            Left            =   1680
            TabIndex        =   22
            Text            =   "Text15"
            Top             =   1440
            Width           =   4700
         End
         Begin VB.TextBox Text14 
            Height          =   315
            Left            =   1680
            TabIndex        =   7
            Text            =   "Text14"
            Top             =   3840
            Width           =   1815
         End
         Begin VB.TextBox Text13 
            Height          =   315
            Left            =   1680
            TabIndex        =   6
            Text            =   "Text13"
            Top             =   3480
            Width           =   1815
         End
         Begin VB.TextBox Text12 
            Height          =   315
            Left            =   1680
            TabIndex        =   5
            Text            =   "Text12"
            Top             =   720
            Width           =   4695
         End
         Begin VB.TextBox Text11 
            Height          =   315
            Left            =   1680
            TabIndex        =   4
            Text            =   "Text11"
            Top             =   360
            Width           =   1455
         End
         Begin VB.Label Label5 
            Caption         =   "����(���� 2)"
            Height          =   255
            Left            =   600
            TabIndex        =   25
            Top             =   1080
            Width           =   975
         End
         Begin VB.Label Label8 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   840
            TabIndex        =   13
            Top             =   3360
            Width           =   735
         End
         Begin VB.Label Label7 
            Caption         =   "�������(����2)"
            Height          =   375
            Left            =   600
            TabIndex        =   12
            Top             =   2400
            Width           =   855
         End
         Begin VB.Label Label4 
            Caption         =   "�����"
            Height          =   255
            Left            =   960
            TabIndex        =   11
            Top             =   3840
            Width           =   615
         End
         Begin VB.Label Label3 
            Caption         =   "�������(������)"
            Height          =   495
            Left            =   360
            TabIndex        =   10
            Top             =   1440
            Width           =   1215
         End
         Begin VB.Label Label2 
            Caption         =   "����(������)"
            Height          =   255
            Left            =   480
            TabIndex        =   9
            Top             =   720
            Width           =   975
         End
         Begin VB.Label Label1 
            Caption         =   "����"
            Height          =   255
            Left            =   1200
            TabIndex        =   8
            Top             =   360
            Width           =   375
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "��������´"
         Height          =   6015
         Left            =   -74520
         TabIndex        =   1
         Top             =   840
         Width           =   6855
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
            Height          =   5535
            Left            =   240
            TabIndex        =   2
            Top             =   240
            Width           =   5535
            _ExtentX        =   9763
            _ExtentY        =   9763
            _Version        =   393216
            _NumberOfBands  =   1
            _Band(0).Cols   =   2
         End
      End
   End
End
Attribute VB_Name = "ENTER_DEPART"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

