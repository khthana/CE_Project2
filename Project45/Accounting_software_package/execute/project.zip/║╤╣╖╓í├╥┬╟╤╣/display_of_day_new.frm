VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   8235
   ClientLeft      =   2055
   ClientTop       =   2040
   ClientWidth     =   6810
   LinkTopic       =   "Form1"
   ScaleHeight     =   8235
   ScaleWidth      =   6810
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

