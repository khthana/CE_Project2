VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form Vat_display 
   Caption         =   "����������"
   ClientHeight    =   5340
   ClientLeft      =   1710
   ClientTop       =   1500
   ClientWidth     =   7650
   LinkTopic       =   "Form2"
   ScaleHeight     =   5340
   ScaleWidth      =   7650
   Begin TabDlg.SSTab SSTab1 
      Height          =   4935
      Left            =   240
      TabIndex        =   0
      Top             =   120
      Width           =   7245
      _ExtentX        =   12779
      _ExtentY        =   8705
      _Version        =   393216
      TabHeight       =   520
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "Vat_display.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame2"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "Edit"
      TabPicture(1)   =   "Vat_display.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame3"
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "New"
      TabPicture(2)   =   "Vat_display.frx":0038
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "Frame1"
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame3 
         Caption         =   "���"
         Height          =   3975
         Left            =   -74760
         TabIndex        =   3
         Top             =   480
         Width           =   6495
         Begin VB.CommandButton Command2 
            Caption         =   "Esc"
            Height          =   375
            Left            =   5040
            TabIndex        =   16
            Top             =   3120
            Width           =   1215
         End
         Begin VB.CommandButton Command1 
            Caption         =   "Save"
            Height          =   375
            Left            =   3600
            TabIndex        =   15
            Top             =   3120
            Width           =   1215
         End
         Begin VB.TextBox Text4 
            Height          =   315
            Left            =   2520
            TabIndex        =   8
            Text            =   "Text4"
            Top             =   1800
            Width           =   735
         End
         Begin VB.TextBox Text3 
            Height          =   315
            Left            =   2520
            TabIndex        =   7
            Text            =   "Text3"
            Top             =   1320
            Width           =   2295
         End
         Begin VB.TextBox Text2 
            Height          =   315
            Left            =   2520
            TabIndex        =   6
            Text            =   "Text2"
            Top             =   960
            Width           =   2295
         End
         Begin VB.TextBox Text1 
            Height          =   315
            Left            =   2520
            TabIndex        =   5
            Text            =   "Text1"
            Top             =   480
            Width           =   495
         End
         Begin VB.Label Label6 
            Caption         =   "%"
            Height          =   255
            Left            =   3360
            TabIndex        =   14
            Top             =   1890
            Width           =   375
         End
         Begin VB.Label Label5 
            Caption         =   "�ѵ��  Vat"
            Height          =   255
            Left            =   1395
            TabIndex        =   13
            Top             =   1875
            Width           =   855
         End
         Begin VB.Label Label4 
            Caption         =   "����(������)"
            Height          =   255
            Left            =   1200
            TabIndex        =   12
            Top             =   960
            Width           =   975
         End
         Begin VB.Label Label3 
            Caption         =   "����(���� 2)"
            Height          =   255
            Left            =   1350
            TabIndex        =   11
            Top             =   1440
            Width           =   855
         End
         Begin VB.Label Label1 
            Caption         =   "����"
            Height          =   255
            Left            =   1920
            TabIndex        =   9
            Top             =   480
            Width           =   375
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "��������´"
         Height          =   4215
         Left            =   240
         TabIndex        =   2
         Top             =   480
         Width           =   6495
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
            Height          =   3495
            Left            =   240
            TabIndex        =   4
            Top             =   480
            Width           =   6015
            _ExtentX        =   10610
            _ExtentY        =   6165
            _Version        =   393216
            _NumberOfBands  =   1
            _Band(0).Cols   =   2
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "���ҧ����"
         Height          =   3975
         Left            =   -74760
         TabIndex        =   1
         Top             =   480
         Width           =   6495
         Begin VB.CommandButton Command4 
            Caption         =   "Esc"
            Height          =   375
            Left            =   5040
            TabIndex        =   27
            Top             =   3120
            Width           =   1215
         End
         Begin VB.CommandButton Command3 
            Caption         =   "Save"
            Height          =   375
            Left            =   3600
            TabIndex        =   26
            Top             =   3120
            Width           =   1215
         End
         Begin VB.TextBox Text8 
            Height          =   315
            Left            =   2520
            TabIndex        =   25
            Text            =   "Text8"
            Top             =   960
            Width           =   2295
         End
         Begin VB.TextBox Text7 
            Height          =   315
            Left            =   2520
            TabIndex        =   24
            Text            =   "Text7"
            Top             =   1320
            Width           =   2295
         End
         Begin VB.TextBox Text6 
            Height          =   315
            Left            =   2520
            TabIndex        =   23
            Text            =   "Text6"
            Top             =   480
            Width           =   495
         End
         Begin VB.TextBox Text5 
            Height          =   315
            Left            =   2520
            TabIndex        =   22
            Text            =   "Text5"
            Top             =   1800
            Width           =   735
         End
         Begin VB.Label Label11 
            Caption         =   "%"
            Height          =   255
            Left            =   3360
            TabIndex        =   21
            Top             =   1890
            Width           =   375
         End
         Begin VB.Label Label10 
            Caption         =   "�ѵ��  Vat"
            Height          =   255
            Left            =   1395
            TabIndex        =   20
            Top             =   1875
            Width           =   855
         End
         Begin VB.Label Label9 
            Caption         =   "����(������)"
            Height          =   255
            Left            =   1200
            TabIndex        =   19
            Top             =   960
            Width           =   975
         End
         Begin VB.Label Label8 
            Caption         =   "����(���� 2)"
            Height          =   255
            Left            =   1350
            TabIndex        =   18
            Top             =   1440
            Width           =   855
         End
         Begin VB.Label Label7 
            Caption         =   "����"
            Height          =   255
            Left            =   1920
            TabIndex        =   17
            Top             =   480
            Width           =   375
         End
      End
   End
   Begin VB.Label Label2 
      Caption         =   "Label2"
      Height          =   495
      Left            =   3360
      TabIndex        =   10
      Top             =   3840
      Width           =   1215
   End
End
Attribute VB_Name = "Vat_display"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

