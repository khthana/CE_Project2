VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form ENTER_COMPANY 
   Caption         =   "Form1"
   ClientHeight    =   9765
   ClientLeft      =   3060
   ClientTop       =   1470
   ClientWidth     =   9135
   LinkTopic       =   "Form1"
   ScaleHeight     =   9765
   ScaleWidth      =   9135
   Begin TabDlg.SSTab SSTab1 
      Height          =   9255
      Left            =   360
      TabIndex        =   0
      Top             =   240
      Width           =   8445
      _ExtentX        =   14896
      _ExtentY        =   16325
      _Version        =   393216
      Tab             =   2
      TabHeight       =   520
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "ENTER_COMPANY.frx":0000
      Tab(0).ControlEnabled=   0   'False
      Tab(0).Control(0)=   "Frame1"
      Tab(0).ControlCount=   1
      TabCaption(1)   =   "Edit"
      TabPicture(1)   =   "ENTER_COMPANY.frx":001C
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "Frame2"
      Tab(1).ControlCount=   1
      TabCaption(2)   =   "New"
      TabPicture(2)   =   "ENTER_COMPANY.frx":0038
      Tab(2).ControlEnabled=   -1  'True
      Tab(2).Control(0)=   "Frame3"
      Tab(2).Control(0).Enabled=   0   'False
      Tab(2).ControlCount=   1
      Begin VB.Frame Frame3 
         Caption         =   "���ҧ����"
         Height          =   8415
         Left            =   240
         TabIndex        =   6
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton Command6 
            Caption         =   "Save"
            Height          =   375
            Left            =   4920
            TabIndex        =   62
            Top             =   7560
            Width           =   1095
         End
         Begin VB.CommandButton Command5 
            Caption         =   "Esc"
            Height          =   375
            Left            =   6360
            TabIndex        =   61
            Top             =   7560
            Width           =   1095
         End
         Begin VB.OptionButton Option4 
            Caption         =   "����"
            Height          =   375
            Left            =   2280
            TabIndex        =   60
            Top             =   6360
            Width           =   1215
         End
         Begin VB.OptionButton Option3 
            Caption         =   "�����¡�͡"
            Height          =   375
            Left            =   2280
            TabIndex        =   59
            Top             =   5880
            Width           =   1335
         End
         Begin VB.Frame Frame5 
            Height          =   1095
            Left            =   2160
            TabIndex        =   58
            Top             =   5760
            Width           =   1695
         End
         Begin VB.TextBox Text22 
            Height          =   980
            Left            =   2160
            TabIndex        =   57
            Text            =   "Text22"
            Top             =   2460
            Width           =   4700
         End
         Begin VB.TextBox Text21 
            Height          =   315
            Left            =   2160
            TabIndex        =   56
            Text            =   "Text21"
            Top             =   720
            Width           =   4700
         End
         Begin VB.TextBox Text20 
            Height          =   315
            Left            =   2160
            TabIndex        =   55
            Text            =   "Text20"
            Top             =   3840
            Width           =   1935
         End
         Begin VB.TextBox Text19 
            Height          =   315
            Left            =   2160
            TabIndex        =   54
            Text            =   "Text19"
            Top             =   3480
            Width           =   1935
         End
         Begin VB.TextBox Text18 
            Height          =   315
            Left            =   2160
            TabIndex        =   53
            Text            =   "Text18"
            Top             =   5400
            Width           =   615
         End
         Begin VB.TextBox Text17 
            Height          =   315
            Left            =   3000
            TabIndex        =   52
            Text            =   "Text17"
            Top             =   5400
            Width           =   2175
         End
         Begin VB.TextBox Text16 
            Height          =   980
            Left            =   2160
            TabIndex        =   51
            Text            =   "Text16"
            Top             =   1080
            Width           =   4700
         End
         Begin VB.TextBox Text15 
            Height          =   315
            Left            =   2160
            TabIndex        =   50
            Text            =   "Text15"
            Top             =   4200
            Width           =   980
         End
         Begin VB.TextBox Text11 
            Height          =   315
            Left            =   2160
            TabIndex        =   31
            Text            =   "Text11"
            Top             =   360
            Width           =   1575
         End
         Begin VB.TextBox Text9 
            Height          =   315
            Left            =   2160
            TabIndex        =   30
            Text            =   "Text9"
            Top             =   5040
            Width           =   1935
         End
         Begin VB.TextBox Text5 
            Height          =   315
            Left            =   2160
            TabIndex        =   29
            Text            =   "Text5"
            Top             =   2100
            Width           =   4700
         End
         Begin VB.Label Label24 
            Caption         =   "�����¡�͡/ ����"
            Height          =   255
            Left            =   240
            TabIndex        =   49
            Top             =   5880
            Width           =   1695
         End
         Begin VB.Label Label23 
            Caption         =   "����������"
            Height          =   255
            Left            =   840
            TabIndex        =   48
            Top             =   5400
            Width           =   975
         End
         Begin VB.Label Label22 
            Caption         =   "����������"
            Height          =   255
            Left            =   960
            TabIndex        =   47
            Top             =   720
            Width           =   975
         End
         Begin VB.Label Label21 
            Caption         =   "�������������"
            Height          =   375
            Left            =   840
            TabIndex        =   46
            Top             =   1080
            Width           =   1095
         End
         Begin VB.Label Label20 
            Caption         =   "�������� 2"
            Height          =   255
            Left            =   1080
            TabIndex        =   45
            Top             =   2160
            Width           =   975
         End
         Begin VB.Label Label19 
            Caption         =   "����������� 2"
            Height          =   495
            Left            =   960
            TabIndex        =   44
            Top             =   2520
            Width           =   1215
         End
         Begin VB.Label Label18 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   1080
            TabIndex        =   43
            Top             =   3525
            Width           =   735
         End
         Begin VB.Label Label17 
            Caption         =   "�����"
            Height          =   255
            Left            =   1200
            TabIndex        =   42
            Top             =   3900
            Width           =   615
         End
         Begin VB.Label Label16 
            Caption         =   "�ѹ������ͺ�ѭ��"
            Height          =   255
            Left            =   600
            TabIndex        =   41
            Top             =   4275
            Width           =   1215
         End
         Begin VB.Label Label15 
            Caption         =   "�ѹ�����������к�"
            Height          =   255
            Left            =   600
            TabIndex        =   40
            Top             =   4680
            Width           =   1215
         End
         Begin VB.Label Label14 
            Caption         =   "�Ţ��Шӵ�Ǽ����������"
            Height          =   255
            Left            =   120
            TabIndex        =   39
            Top             =   5040
            Width           =   1695
         End
         Begin VB.Label Label13 
            Caption         =   "���ʺ���ѷ"
            Height          =   255
            Left            =   1200
            TabIndex        =   38
            Top             =   360
            Width           =   855
         End
      End
      Begin VB.Frame Frame2 
         Caption         =   "���"
         Height          =   8415
         Left            =   -74760
         TabIndex        =   5
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton Command4 
            Caption         =   "Save"
            Height          =   375
            Left            =   4920
            TabIndex        =   37
            Top             =   7560
            Width           =   1095
         End
         Begin VB.CommandButton Command3 
            Caption         =   "Esc"
            Height          =   375
            Left            =   6360
            TabIndex        =   36
            Top             =   7560
            Width           =   1095
         End
         Begin VB.TextBox Text14 
            BackColor       =   &H80000004&
            Height          =   315
            Left            =   3000
            TabIndex        =   34
            Text            =   "Text14"
            Top             =   5400
            Width           =   2175
         End
         Begin VB.TextBox Text13 
            Height          =   315
            Left            =   2160
            TabIndex        =   33
            Text            =   "Text13"
            Top             =   5400
            Width           =   615
         End
         Begin VB.Frame Frame4 
            Height          =   1095
            Left            =   2160
            TabIndex        =   26
            Top             =   5760
            Width           =   1695
            Begin VB.OptionButton Option1 
               Caption         =   "�����¡�͡"
               Height          =   375
               Left            =   120
               TabIndex        =   28
               Top             =   120
               Width           =   1335
            End
            Begin VB.OptionButton Option2 
               Caption         =   "����"
               Height          =   375
               Left            =   120
               TabIndex        =   27
               Top             =   600
               Width           =   1215
            End
         End
         Begin VB.TextBox Text12 
            Height          =   315
            Left            =   2160
            TabIndex        =   15
            Text            =   "Text12"
            Top             =   3840
            Width           =   1935
         End
         Begin VB.TextBox Text10 
            Height          =   980
            Left            =   2160
            TabIndex        =   14
            Text            =   "Text10"
            Top             =   1080
            Width           =   4700
         End
         Begin VB.TextBox Text8 
            Height          =   315
            Left            =   2160
            TabIndex        =   13
            Text            =   "Text8"
            Top             =   2100
            Width           =   4695
         End
         Begin VB.TextBox Text7 
            Height          =   315
            Left            =   2160
            TabIndex        =   12
            Text            =   "Text7"
            Top             =   3480
            Width           =   1935
         End
         Begin VB.TextBox Text6 
            Height          =   980
            Left            =   2160
            TabIndex        =   11
            Text            =   "Text6"
            Top             =   2460
            Width           =   4700
         End
         Begin VB.TextBox Text4 
            Height          =   315
            Left            =   2160
            TabIndex        =   10
            Text            =   "Text4"
            Top             =   4200
            Width           =   980
         End
         Begin VB.TextBox Text3 
            Height          =   315
            Left            =   2160
            TabIndex        =   9
            Text            =   "Text3"
            Top             =   5040
            Width           =   1935
         End
         Begin VB.TextBox Text2 
            Height          =   315
            Left            =   2160
            TabIndex        =   8
            Text            =   "Text2"
            Top             =   720
            Width           =   4695
         End
         Begin VB.TextBox Text1 
            Height          =   315
            Left            =   2160
            TabIndex        =   7
            Text            =   "Text1"
            Top             =   360
            Width           =   1575
         End
         Begin VB.Label Label12 
            Caption         =   "�����¡�͡/ ����"
            Height          =   255
            Left            =   240
            TabIndex        =   35
            Top             =   5880
            Width           =   1695
         End
         Begin VB.Label Label11 
            Caption         =   "����������"
            Height          =   255
            Left            =   840
            TabIndex        =   32
            Top             =   5400
            Width           =   975
         End
         Begin VB.Label Label10 
            Caption         =   "�Ţ��Шӵ�Ǽ����������"
            Height          =   255
            Left            =   120
            TabIndex        =   25
            Top             =   5040
            Width           =   1695
         End
         Begin VB.Label Label9 
            Caption         =   "�ѹ�����������к�"
            Height          =   255
            Left            =   600
            TabIndex        =   24
            Top             =   4680
            Width           =   1215
         End
         Begin VB.Label Label8 
            Caption         =   "�ѹ������ͺ�ѭ��"
            Height          =   255
            Left            =   600
            TabIndex        =   23
            Top             =   4275
            Width           =   1215
         End
         Begin VB.Label Label7 
            Caption         =   "�����"
            Height          =   255
            Left            =   1200
            TabIndex        =   22
            Top             =   3900
            Width           =   615
         End
         Begin VB.Label Label6 
            Caption         =   "���Ѿ��"
            Height          =   255
            Left            =   1080
            TabIndex        =   21
            Top             =   3525
            Width           =   735
         End
         Begin VB.Label Label5 
            Caption         =   "����������� 2"
            Height          =   495
            Left            =   960
            TabIndex        =   20
            Top             =   2520
            Width           =   1215
         End
         Begin VB.Label Label4 
            Caption         =   "�������� 2"
            Height          =   255
            Left            =   1080
            TabIndex        =   19
            Top             =   2160
            Width           =   975
         End
         Begin VB.Label Label3 
            Caption         =   "�������������"
            Height          =   375
            Left            =   840
            TabIndex        =   18
            Top             =   1080
            Width           =   1095
         End
         Begin VB.Label Label2 
            Caption         =   "����������"
            Height          =   255
            Left            =   960
            TabIndex        =   17
            Top             =   720
            Width           =   975
         End
         Begin VB.Label Label1 
            Caption         =   "���ʺ���ѷ"
            Height          =   255
            Left            =   1200
            TabIndex        =   16
            Top             =   360
            Width           =   855
         End
      End
      Begin VB.Frame Frame1 
         Caption         =   "��������´"
         Height          =   8415
         Left            =   -74760
         TabIndex        =   1
         Top             =   480
         Width           =   7935
         Begin VB.CommandButton Command2 
            Caption         =   "Esc"
            Height          =   375
            Left            =   6360
            TabIndex        =   3
            Top             =   7560
            Width           =   1095
         End
         Begin VB.CommandButton Command1 
            Caption         =   "Enter"
            Height          =   375
            Left            =   4920
            TabIndex        =   2
            Top             =   7560
            Width           =   1095
         End
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
            Height          =   4815
            Left            =   120
            TabIndex        =   4
            Top             =   240
            Width           =   6855
            _ExtentX        =   12091
            _ExtentY        =   8493
            _Version        =   393216
            _NumberOfBands  =   1
            _Band(0).Cols   =   2
         End
      End
   End
End
Attribute VB_Name = "ENTER_COMPANY"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

