VERSION 5.00
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "MSHFLXGD.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Begin VB.Form Type_vat 
   Caption         =   "���͡�������ѭ��"
   ClientHeight    =   5010
   ClientLeft      =   4170
   ClientTop       =   2460
   ClientWidth     =   5355
   LinkTopic       =   "Form1"
   ScaleHeight     =   5010
   ScaleWidth      =   5355
   Begin TabDlg.SSTab SSTab1 
      Height          =   4815
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   5205
      _ExtentX        =   9181
      _ExtentY        =   8493
      _Version        =   393216
      Tabs            =   1
      TabHeight       =   520
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   12
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      TabCaption(0)   =   "��������´"
      TabPicture(0)   =   "Type_vat.frx":0000
      Tab(0).ControlEnabled=   -1  'True
      Tab(0).Control(0)=   "Frame1"
      Tab(0).Control(0).Enabled=   0   'False
      Tab(0).ControlCount=   1
      Begin VB.Frame Frame1 
         Caption         =   "�������ѭ��"
         Height          =   4335
         Left            =   130
         TabIndex        =   1
         Top             =   360
         Width           =   4935
         Begin VB.CommandButton Command2 
            Caption         =   "Enter"
            Height          =   375
            Left            =   2160
            TabIndex        =   4
            Top             =   3840
            Width           =   1095
         End
         Begin VB.CommandButton Command1 
            Caption         =   "Esc"
            Height          =   375
            Left            =   3480
            TabIndex        =   3
            Top             =   3840
            Width           =   1095
         End
         Begin MSHierarchicalFlexGridLib.MSHFlexGrid MSHFlexGrid1 
            Height          =   3135
            Left            =   240
            TabIndex        =   2
            Top             =   360
            Width           =   4335
            _ExtentX        =   7646
            _ExtentY        =   5530
            _Version        =   393216
            _NumberOfBands  =   1
            _Band(0).Cols   =   2
         End
      End
   End
End
Attribute VB_Name = "Type_vat"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

