<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.*, register.*, course.* " %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<% 
	HandleStudent hStudent= (HandleStudent)session.getAttribute("StudentInfo");
	HandleRegister hRegister = (HandleRegister)session.getAttribute("Register");
	hRegister.clearAllRegister();		
	String errorMessage = "";
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr> 
      <td height="14" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr> 
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/registration.gif" width="227" height="57"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="17" bgcolor="#FFFFCC" width="67%" align="center">
		<font class="normal1"><b>���� - ���ʡ��</b> <%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></font> 
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= hStudent.getStudent().getId() %></font> 
        <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b><%= hStudent.getCourse().getTname() %></font> 
        <br>
        <font class="normal1"><%= (hStudent.getMinor().getTname() == "") ? "" : "<b>ᢹ��Ԫ�</b> " + hStudent.getMinor().getTname() %></font> 
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= hStudent.getMajor().getTname() %></font> 
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= hStudent.getDepartment().getTname() %></font> 
        <font class="normal1"><b>���&nbsp;</b><%= hStudent.getFaculty().getTname() %></font> 
    </td>
  </tr>
  <tr> 
    <td width="67%" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td height="495" align="center" valign="top" bordercolor="#000000" width="67%">
  <table width="600" border="0" align="center" height="203">
    <tr> 
      <td height="247"> 
            <div align="center"><font class="headline4"><b>����Ԫҷ��������ŧ����¹</b></font></div>
		<br>
            <table width="100%" border="2" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC" align="center" height="100">
              <tr bgcolor="#FFFF99" align="center"> 
                <td width="12%" align="center" height="30" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
				</td>
                <td width="56%" height="40" bgcolor="#006666">
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="10%" height="40" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                </td>
                <td width="10%" height="40" bgcolor="#006666">
                  <div align="center"><font class="headline2"><b>�͹</b></font></div>
                </td>
                <td width="12%" height="40" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>������</b></font></div>
                </td>
              </tr>
              <% 
					int allCredit = 0;
					int showCredit = 0;

					for(int i=0; i<8; i++)
					{
						String subjectID = request.getParameter("subId" + Integer.toString(i + 1));
						String subjectStatus = request.getParameter("subStatus" + Integer.toString(i + 1));

						if(!subjectID.equals(""))
						{				
							Register r = new Register();

							try
							{
								String sec = Integer.toString(Integer.parseInt(request.getParameter("subSec"+Integer.toString(i + 1)).trim()));
								HandleSection hSection = new HandleSection();
								Vector v = hSection.retrieveSection(subjectID, sec);
								Enumeration e = v.elements();

								if(e.hasMoreElements())
								{
									Section section = (Section)e.nextElement();
									HandleSubject hSubject = new HandleSubject();
									v = hSubject.retrieveSubject(subjectID);
									e = v.elements();

									if(e.hasMoreElements())
									{
										Subject subject = (Subject)e.nextElement();
										subject.setSection(section);					
										r.setSubject(subject);
										r.setStudent(hStudent.getStudent());
										r.setSectionType(request.getParameter("subType"+Integer.toString(i + 1)).trim().substring(0,1));									
										r.setRegisterType("C");
										r.setGrade("X");
										r.setSemester(HandleTimeInterval.retrieveSemester());
										r.setYear(HandleTimeInterval.retrieveYear());
									}
								}
								else
								{
									Subject subject = new Subject();
									subject.setId(subjectID);
									subject.setEname(request.getParameter("subName"+Integer.toString(i + 1)));
									subject.setCredit(request.getParameter("subCredit"+Integer.toString(i + 1)));

									Section section = new Section();
									section.setSec(request.getParameter("subSec"+Integer.toString(i + 1)));
									subject.setSection(section);

									r.setSubject(subject);
									errorMessage = "����յ͹�ͧ����ԪҴѧ�����";
									session.setAttribute("errorMessage", errorMessage);
									session.setAttribute("errorRegister", r);

									response.sendRedirect("ErrorSection.jsp");
									return;
								}
							}
							catch(NumberFormatException nfex)
							{
								Subject subject = new Subject();
								subject.setId(subjectID);
								subject.setEname(request.getParameter("subName"+Integer.toString(i + 1)));
								subject.setCredit(request.getParameter("subCredit"+Integer.toString(i + 1)));

								Section section = new Section();
								section.setSec("<b><font class=\"warning1\">?</font></b>");
								subject.setSection(section);

								r.setSubject(subject);
								errorMessage = "���͹���١��ͧ";
								session.setAttribute("errorMessage", errorMessage);				
								session.setAttribute("errorRegister", r);
									
								response.sendRedirect("ErrorSection.jsp");	
								return;		
							}

							showCredit += Integer.parseInt(r.getSubject().getCredit());

							if(!r.getSubject().getGroup().equals("T"))
							{
								allCredit += Integer.parseInt(r.getSubject().getCredit());
							}

							/* check closed section */
							if(r.getSubject().getSection().getStatus().equals("C"))
							{
								errorMessage = "����ԪҴѧ�������١�Դ����� �ô��Ǩ�ͺ����Ԫҷ���Դ�͹�ա����";
								session.setAttribute("errorMessage", errorMessage);
								session.setAttribute("errorRegister", r);

								response.sendRedirect("ErrorSection.jsp");
								return;
							}

							/* check section locked */
							if(subjectStatus.equals("C") && r.getSubject().getSection().getLock().equals("Y"))
							{
								Vector v = hRegister.retrievePreRegisterData(r.getStudent(), r.getSubject());
								Enumeration e = v.elements();

								if(!e.hasMoreElements())
								{
									int currentStudent = Integer.parseInt(r.getSubject().getSection().getCurrentStudent());
									int maxStudent = Integer.parseInt(r.getSubject().getSection().getMaxStudent());

									if(currentStudent >= maxStudent)
									{
										errorMessage = "��ҹ�������öŧ����¹����ԪҴѧ����������ͧ�ҡ *<br>* �չѡ�֡��ŧ����¹����ӹǹ�٧�ش���������˹��������";
										session.setAttribute("errorMessage", errorMessage);
										session.setAttribute("errorRegister", r);

										response.sendRedirect("ErrorSection.jsp");
										return;
									}
								}
							}

							/* check section registered */
							if(subjectStatus.equals("C") && hRegister.checkSectionRegistered(hStudent.getStudent(), r.getSubject()))
							{
								errorMessage = "��ҹ�·ӡ��ŧ����¹����ԪҴѧ����������";
								session.setAttribute("errorMessage", errorMessage);
								session.setAttribute("errorRegister", r);

								response.sendRedirect("ErrorSection.jsp");
								return;
							} 		

							/* check prerequisite */	
							if(subjectStatus.equals("C") && r.getSubject().getPrerequisite() != null)
							{
								if(!hRegister.checkPassedPrerequisite(hStudent.getStudent(), r.getSubject()))
								{
									errorMessage = "�ԪҴѧ������� Prerequisite �ô��Ǩ�ͺ����Ԫҷ���Դ�͹�ա����";
									session.setAttribute("errorMessage", errorMessage);
									session.setAttribute("errorRegister", r);

									response.sendRedirect("ErrorSection.jsp");
									return;
								}
							}
							
							if(subjectStatus.equals("C"))
							{
								// add to register list
								hRegister.setRegister(r, i);
							}

							/* display */
							out.println(
							"<tr>" +
							"<td align=\"center\" bgcolor=\"#669999\" valign=\"top\" width=\"13%\" height=\"30\"><font class=\"normal1\">" + request.getParameter("subId"+Integer.toString(i + 1)) + "</font></td>"+
							"<td bgcolor=\"#669999\" valign=\"top\" width=\"70%\" height=\"30\"><font class=\"normal1\">" + request.getParameter("subName"+Integer.toString(i + 1)) + "</font></td>" +
							"<td bgcolor=\"#669999\" valign=\"top\" width=\"15%\" height=\"30\"><div align=\"center\"><font class=\"normal1\">" + request.getParameter("subCredit"+Integer.toString(i + 1)) + "</font></div></td>" +
							"<td bgcolor=\"#669999\" width=\"6%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + request.getParameter("subSec"+Integer.toString(i + 1)) + "</font></div></td>" +
							"<td bgcolor=\"#669999\" width=\"17%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + request.getParameter("subType"+Integer.toString(i + 1)) + "</font></div></td>" +
							"</tr>");
						}
					}
		
				/* check min, max credit */	
				if(!hRegister.checkMinMaxCredit(allCredit))
				{
					errorMessage = "˹��¡Ե�������ͧ���ŧ����¹����Ԫҹ��������ҡ�Թ�";
					session.setAttribute("errorMessage", errorMessage);
					session.setAttribute("errorRegister", null);

					response.sendRedirect("ErrorSection.jsp");
					return;
				}

				session.setAttribute("showCredit", Integer.toString(showCredit));
			  %>
              <tr bordercolor="#FFFFCC"> 
                <td align="center" bgcolor="#006666" valign="top" colspan="2" height="30" bordercolor="#CCCCCC"> 
                  <div align="right"><font class="headline2"><b>���</b></font></div>
                </td>
                <td bgcolor="#006666" valign="top" height="30" bordercolor="#CCCCCC">
                  <div align="center"><font class="headline2"><b><%= Integer.toString(showCredit) %></b></font></div>
                </td>
                <td bgcolor="#006666" valign="top" height="30" bordercolor="#CCCCCC" colspan="2"><font class="headline2"><b>˹��¡Ե</b></font></td>
              </tr>
            </table>
        <div align="right">
		<form name="form1" method="post" action="RegistrationPage3.jsp">
            <input type="submit" name="Next" value=" ���� ">
            <input type="button" name="Back" value="��Ѻ����" OnClick="history.go(-1)">
        </form>
        </div>
      </td>
    </tr>
  </table>
    </td>
  </tr>
  <tr> 
    <td height="23" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
