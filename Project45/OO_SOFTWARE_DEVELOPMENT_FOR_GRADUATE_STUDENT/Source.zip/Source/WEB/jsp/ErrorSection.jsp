<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*, graduate.*, course.*, register.* "  %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<% 
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	Register errorRegister = (Register)session.getAttribute("errorRegister");
	String errorMessage = (String)session.getAttribute("errorMessage");
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr> 
      <td height="14" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr> 
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/registration.gif" width="227" height="57"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="17" bgcolor="#FFFFCC" width="67%" align="center"> 
		<font class="normal1"><b>���� - ���ʡ��</b> <%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></font> 
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= hStudent.getStudent().getId() %></font> 
        <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b><%= hStudent.getCourse().getTname() %></font> 
        <br>
        <font class="normal1"><%= (hStudent.getMinor().getTname() == "") ? "" : "<b>ᢹ��Ԫ�</b> " + hStudent.getMinor().getTname() %></font> 
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= hStudent.getMajor().getTname() %></font> 
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= hStudent.getDepartment().getTname() %></font> 
        <font class="normal1"><b>���&nbsp;</b><%= hStudent.getFaculty().getTname() %></font> 
    </td>
  </tr>
  <tr> 
    <td width="67%" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td height="495" align="center" valign="top" bordercolor="#000000" width="67%">
  <table width="600" border="0" align="center" height="203">
    <tr> 
      <td height="247"> 
            <div align="center"><font class="warning2"><b>* <%= errorMessage %> *</b></font></div>
		<br>
            <table width="100%" border="2" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC" align="center" height="100">
              <tr bgcolor="#FFFF99" align="center"> 
                <td width="12%" align="center" height="38" bgcolor="#006666">
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="56%" height="38" bgcolor="#006666">
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="10%" height="38" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                </td>
                <td width="10%" height="38" bgcolor="#006666">
                  <div align="center"><font class="headline2"><b>�͹</b></font></div>
                </td>
              </tr>
              <% 
					if(errorRegister != null)
					{
						/* display error register */
						out.println(
						"<tr>" +
						"<td align=\"center\" bgcolor=\"#669999\" valign=\"top\" width=\"12%\" height=\"30\"><font class=\"normal1\">" + errorRegister.getSubject().getId() + "</font></td>"+
						"<td bgcolor=\"#669999\" valign=\"top\" width=\"56%\" height=\"30\"><font class=\"normal1\">" + errorRegister.getSubject().getEname() + "</font></td>" +
						"<td bgcolor=\"#669999\" valign=\"top\" width=\"10%\" height=\"30\"><div align=\"center\"><font class=\"normal1\">" + errorRegister.getSubject().getCredit() + "</font></div></td>" +
						"<td bgcolor=\"#669999\" width=\"10%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + errorRegister.getSubject().getSection().getSec() + "</font></div></td>" +
						"</tr>");	
					}
			  %>
              <tr bordercolor="#FFFFCC" bgcolor="#006666"> 
                <td align="left" valign="top" colspan="5" bordercolor="#CCCCCC" height="2">&nbsp;</td>
              </tr>
            </table>
        <div align="center">
		<form name="form1" method="post" action="PreRegistrationPage3.jsp">
                <input type="button" name="Back" value="��Ѻ����" OnClick="history.go(-1)">
        </form>
        </div>
      </td>
    </tr>
  </table>
    </td>
  </tr>
  <tr> 
    <td height="23" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
