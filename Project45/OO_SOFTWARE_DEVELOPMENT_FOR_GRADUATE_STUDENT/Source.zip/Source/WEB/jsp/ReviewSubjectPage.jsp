<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*, java.text.*, graduate.*, course.* "  %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ��������´�ͧ����Ԫ�</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%	
	Subject subject = new Subject();

	String subjectID = request.getParameter("id");
	String sec = request.getParameter("sec");
	
	HandleSubject hSubject = new HandleSubject();
	HandleSection hSection = new HandleSection();

	Vector v = hSubject.retrieveSubject(subjectID);
	Enumeration e = v.elements();

	if(e.hasMoreElements())
	{
		subject = (Subject)e.nextElement();
		v = hSection.retrieveSection(subjectID, sec);
		e = v.elements();

		if(e.hasMoreElements())
		{
			Section section = (Section)e.nextElement();
			subject.setSection(section);
		}
	}
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="730" bgcolor="#FFFFFF">
  <tr> 
    <td height="14" colspan="5" bgcolor="#000000">
	<font class="headline1">
	<b>
      King Mongkut's Institute of Technology Ladkrabang
	 </b>
	 </font>
	 </td>
  </tr>
  <tr> 
    <td rowspan="5" height="367" align="center" valign="top" width="15%">&nbsp;</td>
    <td width="11%" height="87" align="center" valign="middle"><img src="images/book3.gif" width="65" height="66"></td>
    <td width="34%" height="87" align="center" valign="middle"><img src="images/subject2.gif" width="283" height="65"></td>
    <td width="14%" height="87" align="center" valign="middle"><img src="images/book3.gif" width="65" height="66"></td>
    <td rowspan="5" height="338" width="26%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="128" align="left" colspan="3"> 
      <table width="100%" border="1" cellspacing="1" cellpadding="3" bgcolor="#FFFFCC" bordercolor="#CCCCCC">
        <tr> 
          <td width="35%"><font class="normal1"><b>�����Ԫ�</b></font></td>
          <td width="65%"><font class="normal1">
		  <%= subject.getId() %>
		  </font></td>
        </tr>
        <tr> 
          <td width="35%"><font class="normal1"><b>�����Ԫ������ѧ���</b></font></td>
          <td width="65%"><font class="normal1">
		  <%
				if(subject.getEname() == null || subject.getEname().trim().length() == 0)
				{
					out.print("-");
				}
				else
				{
					out.print(subject.getEname());
				}
		  %>
		  </font></td>
        </tr>
        <tr> 
          <td width="35%"><font class="normal1"><b>�����Ԫ�������</b></font></td>
          <td width="65%"><font class="normal1">
		  <%
				if(subject.getTname() == null || subject.getTname().trim().length() == 0)
				{
					out.print("-");
				}
				else
				{
					out.print(subject.getTname());
				}
		  %>		  
		  </font></td>
        </tr>
        <tr> 
          <td width="35%">
		    <font class="normal1">
			<b> 
            ˹��¡Ե (��ɯ� - ��Ժѵ� - �鹤���)
			</b>
			</font>
		  </td>
          <td width="65%"><font class="normal1">
		  <%
			if(subject.getCredit() == null || subject.getCredit().trim().length() == 0)
			{
				out.print("-");
			}
			else
			{
				out.print(subject.getCredit());
			}		   
		   
		   out.print(" (");
		   
		   if(subject.getLecture() == null || subject.getLecture().trim().length() == 0)
		   {
			   out.print("&nbsp;");
		   }
		   else
		   {
				out.print(subject.getLecture());
		   }
		   
		   out.print(" - ");

		   if(subject.getPractice() == null || subject.getPractice().trim().length() == 0)
		   {
			   out.print("&nbsp;");
		   }
		   else
		   {
			   out.print(subject.getPractice());
		   }

		   out.print(" - ");

  		   if(subject.getResearch() == null || subject.getResearch().trim().length() == 0)
		   {
			   out.print("&nbsp;");
		   }
		   else
		   {
   			   out.print(subject.getResearch());
		   }

		   out.print(")");
		  %>
		  </font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="30" align="center" colspan="3">&nbsp;</td>
  </tr>
  <tr> 
    <td height="495" align="center" valign="top" bordercolor="#000000" colspan="3"> 
      <table width="100%" border="1" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC">
        <tr bgcolor="#006666"> 
          <td colspan="2">
		  <font class="headline3"><b>Section 
		  <%
				int allSection = hSection.getNumberOfSection(subjectID);

				for(int i=1; i<=allSection; i++)
				{
					if(request.getParameter("sec").equals(Integer.toString(i)))
					{
						out.println(Integer.toString(i));
					}
					else
					{
						out.println("<a href=\"ReviewSubjectPage.jsp?id=" + request.getParameter("id") + "&sec=" + Integer.toString(i) + "\"><font color=\"#669999\">" + Integer.toString(i) + "</font></a>");
					}
				}
		   %>
		  </b></font></td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>����͹</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
		  <%
		   if(subject.getSection().getLecturer() == null)
		   {
			   out.print("-");
		   }
		   else
		   {
				out.print(subject.getSection().getLecturer().getTpre() + " ");
				out.print(subject.getSection().getLecturer().getTname() + " ");
				out.print(subject.getSection().getLecturer().getTfamily());
		   }
		  %>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>�ѹ���ҷ���͹</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
		  <%
			    if(subject.getSection().getDay() == null || subject.getSection().getDay().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
					out.print(subject.getSection().getDay());
			   }

	  		   if(subject.getSection().getBeginTime() == null || subject.getSection().getBeginTime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
					out.print(" (" + subject.getSection().getBeginTime() + " - ");
			   }
		   
  			   if(subject.getSection().getEndTime() == null || subject.getSection().getEndTime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
					out.print(subject.getSection().getEndTime() + ")");
			   }
		 %>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>��ͧ������͹</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
		  <%
  		   if(subject.getSection().getRoom() == null || subject.getSection().getRoom().trim().length() == 0)
		   {
			   out.print("-");
		   }
		   else
		   {
				out.print(subject.getSection().getRoom());
		   }
		   %>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>�ѹ�ͺ��ҧ�Ҥ</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
			<%
				if(subject.getSection().getMidTermDate() == null || subject.getSection().getMidTermDate().toString().trim().length() == 0)
				{
					out.print("-");
				}
				else
				{
					String date = new SimpleDateFormat().getDateInstance().format(subject.getSection().getMidTermDate());
					out.print(date);
				}

			   if(subject.getSection().getMidTermBeginTime() == null || subject.getSection().getMidTermBeginTime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
					out.print(" (" + subject.getSection().getMidTermBeginTime() + " - ");
			   }

			   if(subject.getSection().getMidTermEndTime() == null || subject.getSection().getMidTermEndTime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
					out.print(subject.getSection().getMidTermEndTime() + ")");
			   }
		   %>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>��ͧ������ͺ��ҧ�Ҥ</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
		  <%
			   if(subject.getSection().getMidTermRoom() == null || subject.getSection().getMidTermRoom().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
					out.print(subject.getSection().getMidTermRoom());
			   }
			%>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>�ѹ�ͺ����Ш��Ҥ</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
			<%
				if(subject.getSection().getFinTermDate() == null || subject.getSection().getFinTermDate().toString().trim().length() == 0)
				{
					out.print("-");
				}
				else
				{
					String date = new SimpleDateFormat().getDateInstance().format((java.util.Date)subject.getSection().getFinTermDate());
					out.print(date);
				}

			   if(subject.getSection().getFinTermBeginTime() == null || subject.getSection().getFinTermBeginTime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
					out.print(" (" + subject.getSection().getFinTermBeginTime() + " - ");
			   }

			   if(subject.getSection().getFinTermEndTime() == null || subject.getSection().getFinTermEndTime().trim().length() == 0)
			   {
				   out.print("&nbsp;");
			   }
			   else
			   {
					out.print(subject.getSection().getFinTermEndTime() + ")");
			   }
		   %>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>��ͧ������ͺ����Ш��Ҥ</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
		  <%
			   if(subject.getSection().getFinTermRoom() == null || subject.getSection().getFinTermRoom().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
					out.print(subject.getSection().getFinTermRoom());
			   }
			%>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>�ӹǹ�ѡ�֡�ҷ���Ѻ</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
		  <%
			   if(subject.getSection().getMaxStudent() == null || subject.getSection().getMaxStudent().trim().length() == 0)
				{
					out.print("N/A");
				}
				else
				{
					out.print(subject.getSection().getMaxStudent());
				}
		  %>
		  </font>
		  </td>
        </tr>
        <tr bgcolor="#006666"> 
          <td bgcolor="#669999"><font class="headline2"><b>�ӹǹ�ѡ�֡�ҷ��ŧ����¹</b></font></td>
          <td bgcolor="#669999">
		  <font class="normal1">		  
		  <%
			    if(subject.getSection().getCurrentStudent() == null || subject.getSection().getCurrentStudent().trim().length() == 0)
				{
					out.print("N/A");
				}
				else
				{
					out.print(subject.getSection().getCurrentStudent());
				}
		  %>
		  </font>
		  </td>
        </tr>
        <tr bgcolor="#006666"> 
          <td bgcolor="#669999"><font class="headline2"><b>ʶҹС���Դ - �Դ</b></font></td>
          <td bgcolor="#669999">
		  <font class="normal1">
		<%
			if(subject.getSection().getStatus() == null || subject.getSection().getStatus().trim().length() == 0)
			{
				out.print("N/A");
			}
			else
			{
				if(subject.getSection().getStatus().equals("A"))
				{
					out.print("�Դ");
				}
				else
				{
					out.print("�Դ");
				}
			}
		 %>
		  </font>
          </td>
        </tr>
        <tr bgcolor="#006666"> 
          <td colspan="2"><font class="headline3"><b>�ԪҺѧ�Ѻ��͹</b></font></td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>�����Ԫ�</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
			<%
				if(subject.getPrerequisite() != null)
				{
					out.print(subject.getPrerequisite().getId());
				}
				else
				{
					out.print("-");
				}
			%>
		  </font>
		  </td>
        </tr>
        <tr> 
          <td width="35%" bgcolor="#669999"><font class="headline2"><b>�����Ԫ�</b></font></td>
          <td width="65%" bgcolor="#669999">
		  <font class="normal1">
			<%
				if(subject.getPrerequisite() != null)
				{
					out.print(subject.getPrerequisite().getEname());
				}
				else
				{
					out.print("-");
				}
			%>
		  </font>
		  </td>
        </tr>
        <tr bgcolor="#006666"> 
          <td colspan="2"><font class="headline3"><b>��͸Ժ������Ԫ�</b></font></td>
        </tr>
        <tr> 
          <td colspan="2" bgcolor="#669999">
		  <font class="normal1">
		 <%
			   if(subject.getEoutline() == null || subject.getEoutline().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
					out.print(subject.getEoutline());
			   }
		 %>
          </font>
		  </td>
        </tr>
        <tr> 
          <td colspan="2" bgcolor="#669999">
		  <font class="normal1">
		  <p>
		 <%
			   if(subject.getToutline() == null || subject.getToutline().trim().length() == 0)
			   {
				   out.print("-");
			   }
			   else
			   {
					out.print(subject.getToutline());
			   }
		 %>		  
		 </p>
		  </font>
		  </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="58" align="center" valign="top" bordercolor="#000000" colspan="3"></td>
  </tr>
</table>
</body>
</html>
