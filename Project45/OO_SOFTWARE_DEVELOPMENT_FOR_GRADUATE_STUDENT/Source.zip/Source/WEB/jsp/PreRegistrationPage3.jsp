<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.text.*, java.io.*,graduate.*, register.*, course.*, cost.* " %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹��ǧ˹��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<% 	
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandlePreRegister hPreregister = (HandlePreRegister)session.getAttribute("PreRegister");
	HandleCost hCost = new HandleCost();
	String conditions = "";
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr> 
    <td height="14" colspan="4" bgcolor="#000000">
	<font class="headline1"> 
	<b>
      King Mongkut's Institute of Technology Ladkrabang
	</b>
	</font>
	</td>
  </tr>
  <tr> 
    <td rowspan="5" height="367" align="center" valign="top" width="10%">&nbsp;</td>
    <td height="46" align="center" valign="bottom" colspan="2"><img src="images/preregistration.gif" width="425" height="57"></td>
    <td rowspan="5" height="338" width="25%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="17" bgcolor="#FFFFCC" align="center" colspan="2">
		<font class="normal1"><b>���� - ���ʡ��</b> <%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></font> 
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= hStudent.getStudent().getId() %></font> 
        <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b><%= hStudent.getCourse().getTname() %></font> 
        <br>
        <font class="normal1"><%= (hStudent.getMinor().getTname() == "") ? "" : "<b>ᢹ��Ԫ�</b> " + hStudent.getMinor().getTname() %></font> 
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= hStudent.getMajor().getTname() %></font> 
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= hStudent.getDepartment().getTname() %></font> 
        <font class="normal1"><b>���&nbsp;</b><%= hStudent.getFaculty().getTname() %></font> 
    </td>
  </tr>
  <tr> 
    <td height="6" colspan="2"> 
      <div align="center"> <br>
        <font class="headline4"> 
        <b> 
        <%
		out.println("��������´�������� �Ҥ���¹��� " + HandleTimeInterval.retrieveSemester() + " �ա���֡�� " + HandleTimeInterval.retrieveYear());
		%>
        </b> 
		</font>
		<br>
        <br>
      </div>
      <table width="81%" border="2" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC" align="center" height="129">
        <tr bgcolor="#FFFF99"> 
          <td align="center" height="30" bgcolor="#006666"> 
            <div align="center"><font class="headline2"><b>��������´</b></font></div>
          </td>
          <td width="20%" height="40" align="center" bgcolor="#006666"> 
            <div align="center"><font class="headline2"><b>�ӹǹ�Թ (�ҷ)</b></font></div>
          </td>
        </tr>
        <% 
				DecimalFormat format = new DecimalFormat("0.00");
				double totalCost = 0.00f;
				
				if(hStudent.getStudent().getType().equals("C"))
				{
					/********************* Private Cost *********************/	
					conditions = ", student where cost.sco# = student.sco# and cost.type = 'P' and student.std# = '" + hStudent.getStudent().getId() + "' and (cost.semester = '" + HandleTimeInterval.retrieveSemester() + "' or cost.semester = 'A')";
					Vector privateCost = hCost.retrieveCost(conditions);
					Enumeration e = privateCost.elements();

					while(e.hasMoreElements())
					{
						Cost c  = (Cost)e.nextElement();

						if(!c.getName().equals("����������¹����֡��Ẻ���Ҩ���"))
						{
							totalCost = totalCost + Double.parseDouble(c.getValue());

							out.println("<tr>" + 
											   "<td bgcolor=\"#669999\" height=\"27\"><div align=\"left\"><font class=\"normal1\">" + 	c.getName() + "</font></div></td>"+
											   "<td bgcolor=\"#669999\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + c.getValue() + "</font></div></td>" +
											   "</tr>");
						}
					}

					/********************* Common Cost *********************/
					conditions = "where type = 'C' and (semester = '" + HandleTimeInterval.retrieveSemester() + "' OR semester = 'A') ";
					Vector commonCost = hCost.retrieveCost(conditions);
					e = commonCost.elements();

					while(e.hasMoreElements())
					{
						Cost c  = (Cost)e.nextElement();

						if(c.getName().equals("���ŧ����¹����Ԫ�"))
						{
							double value = Double.parseDouble(c.getValue());
							value = value * Double.parseDouble((String)session.getAttribute("showCredit"));	
							totalCost = totalCost + value;

							c.setName(c.getName() + " " + (String)session.getAttribute("showCredit") + " ˹��¡Ե");
							c.setValue(format.format(value));
						}
						else
						{
							totalCost = totalCost + Double.parseDouble(c.getValue());
						}
	
						out.println("<tr>" + 
						"<td bgcolor=\"#669999\" height=\"27\"><div align=\"left\"><font class=\"normal1\">" + c.getName()  + "</font></div></td>"+
						"<td bgcolor=\"#669999\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + c.getValue() + "</font></div></td>" +
						"</tr>");
					}
				}
				else
				{
					/********************* �ѡ�֡���ç��þ���� *********************/
					conditions = "where name = '����������¹����֡��Ẻ���Ҩ���'";
					Vector specialProjectCost = hCost.retrieveCost(conditions);
					Enumeration e = specialProjectCost.elements();

					if(e.hasMoreElements())
					{
						Cost c = (Cost)e.nextElement();

						totalCost = totalCost + Double.parseDouble(c.getValue());

						out.println("<tr>" + 
										   "<td bgcolor=\"#669999\" height=\"27\"><div align=\"left\"><font class=\"normal1\">" + c.getName()  + "</font></div></td>"+
										   "<td bgcolor=\"#669999\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + c.getValue() + "</font></div></td>" +
										   "</tr>");
					}
				}
          %>
        <tr> 
          <td align="center" bgcolor="#006666" height="27"> 
            <div align="right"><font class="headline2"><b>����Թ����ͧ����</b></font></div>
          </td>
          <td bgcolor="#006666" width="9%" height="27"> 
            <div align="center"><font class="headline2"><b><%= format.format(totalCost) %></b></font></div>
          </td>
        </tr>
      </table>
      <table width="81%" align="center">
        <form name="form1" method="post" action="PreRegistrationPage4.jsp">
          <tr> 
            <td> <br>
              <font class="normal3"><b>������ʼ�ҹ�ա���������׹�ѹ���ŧ����¹</b></font> 
              <input type="password" name="password">
            </td>
            <td align="right"> <br>
              <input type="submit" name="Next" value=" ��ŧ ">
              <input type="button" name="Back" value="��Ѻ����" OnClick="history.go(-2)">
            </td>
          </tr>
        </form>
      </table>
    </td>
  </tr>
  <tr> 
    <td width="7%" height="6">&nbsp;</td>
    <td width="58%" height="6">
	<font class="warning1">
	<b>
        <% 
			   String error = request.getParameter("error");
		       String msg = "* ���ʼ�ҹ�Դ��Ҵ ��سһ�͹���ʼ�ҹ����";
		%>
        <%=((error!=null)?msg : "")%>
	</b>
	</font>
	</td>
  </tr>
  <tr> 
    <td height="42" align="center" valign="top" bordercolor="#000000" colspan="2"> 
    </td>
  </tr>
</table>
</body>
</html>
