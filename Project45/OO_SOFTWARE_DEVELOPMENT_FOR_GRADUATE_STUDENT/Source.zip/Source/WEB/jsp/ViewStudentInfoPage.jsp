<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.*, utility.* " %>
<%@  include file ="checksession.inc" %>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ����Ԫҷ���Դ�͹</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<%
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	
	hStudent.getStudent().setRecentAddress(CharsetConverter.MS874ToUnicode(request.getParameter("recentaddress")));
	hStudent.getStudent().setRealAddress(CharsetConverter.MS874ToUnicode(request.getParameter("realaddress")));
	hStudent.getStudent().setHomePhone(CharsetConverter.MS874ToUnicode(request.getParameter("homephone")));
	hStudent.getStudent().setMobilePhone(CharsetConverter.MS874ToUnicode(request.getParameter("mobile")));
	hStudent.getStudent().setEmail(CharsetConverter.MS874ToUnicode(request.getParameter("email")));
	
	// update to database
	hStudent.updateStudent(hStudent.getStudent());
%>
</head>

<body bgcolor="#FFFFFF">
<form method="post" action="viewStudentInfoPage.jsp" name="form">
<table width="100%" border="0" cellspacing="1" cellpadding="3" bgcolor="#FFFFFF">
  <tr> 
    <td height="14" colspan="5" bgcolor="#000000"> <font class="headline1"> <b> 
      King Mongkut's Institute of Technology Ladkrabang </b> </font> </td>
  </tr>
  <tr> 
    <td rowspan="3" height="400" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="14%" height="46" align="right" valign="middle"><img src="images/images2.jpg" width="65" height="60"></td>
      <td width="32%" height="46" align="center" valign="bottom"><img src="images/edit2.gif" width="198" height="85"></td>
    <td width="14%" height="46" align="left" valign="middle"><img src="images/images.jpg" width="65" height="60"></td>
    <td rowspan="3" height="400" width="29%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="53" bgcolor="#FFFFCC" align="center" colspan="3"> 
     <font class="normal1"><b>���� - ���ʡ��</b></font> 
        <span class="normal1"><%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></span> 
        <font class="normal1"><b>����</b></font> <span class="normal1"><%= hStudent.getStudent().getId() %></span><br>
        <font class="normal1"><b>�Ҥ�Ԫ�</b></font> <span class="normal1"><%= hStudent.getDepartment().getTname() %></span> 
        <font class="normal1"><b>���</b></font> <span class="normal1"><%= hStudent.getFaculty().getTname() %></span> 
    </td>
  </tr>
  <tr> 
      <td height="369" align="center" valign="top" bordercolor="#000000" colspan="3"> 
        <table width="100%" border="0" cellspacing="0" cellpadding="0" height="250">
          <tr> 
            <td align="left" valign="top" height="19" width="26%">&nbsp;</td>
            <td align="left" valign="middle" height="19" width="2%">&nbsp;</td>
            <td align="left" valign="middle" height="19" width="72%"><font class="warning1"> 
              </font></td>
        </tr>
        <tr> 
            <td align="right" valign="top" width="26%" height="10"><font class="normal1">�������Ѩ�غѹ</font></td>
            <td align="left" valign="top" width="2%" height="10">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="10"><font class="normal1"><font color="#005CA2"><%= CharsetConverter.MS874ToUnicode(request.getParameter("recentaddress")) %></font></font></td>
        </tr>
        <tr> 
            <td align="right" valign="top" width="26%" height="10"><font class="normal1">�������������¹��ҹ</font></td>
            <td align="left" valign="top" width="2%" height="10">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="10"><font class="normal1"><font color="#005CA2"><%= CharsetConverter.MS874ToUnicode(request.getParameter("realaddress")) %></font></font></td>
        </tr>
        <tr> 
            <td align="right" valign="top" width="26%" height="14"><font class="normal1">���Ѿ���ҹ</font></td>
            <td align="left" valign="top" width="2%" height="14">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="14"><font class="normal1"><font color="#005CA2"><%= CharsetConverter.MS874ToUnicode(request.getParameter("homephone")) %></font></font></td>
        </tr>
        <tr> 
            <td align="right" valign="top" width="26%" height="14"><font class="normal1">���Ѿ������͹���</font></td>
            <td align="left" valign="top" width="2%" height="14">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="14"><font class="normal1"><font color="#005CA2"><%= CharsetConverter.MS874ToUnicode(request.getParameter("mobile")) %></font></font></td>
        </tr>
        <tr> 
          <td align="right" valign="top" width="26%"><font class="normal1">������</font></td>
          <td align="left" valign="top" width="2%">&nbsp; </td>
            <td align="left" valign="top" width="72%" height="30"><font class="normal1"><font color="#005CA2"><%= CharsetConverter.MS874ToUnicode(request.getParameter("email")) %></font></font></td>
        </tr>
      </table>
      <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr> 
            <td height="48" width="35%" rowspan="2">&nbsp;</td>
            <td height="46" width="65%">&nbsp;</td>
        </tr>
        <tr> 
            <td height="34" width="65%"> 
              <input type="button" name="Back" value="��Ѻ��ѧ������ѡ" OnClick="history.go(-2)">
          </td>
        </tr>
      </table>      
    </td>
  </tr>
</table>
</form>
</body>
</html>
