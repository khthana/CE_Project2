<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.text.*, java.io.*,graduate.*, register.*, course.*, cost.* " %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �����š��ŧ����¹</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<% 
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandleRegister hRegister = (HandleRegister)session.getAttribute("Register");
	HandleCost hCost = new HandleCost();

	String conditions = "";
	int allCredit = 0;
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr> 
    <td height="6" colspan="3"> </td>
  </tr>
  <tr> 
    <td rowspan="7" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td bgcolor="#FFFFCC" height="31" align="center" valign="bottom"> 
		<font class="normal1"><b>���� - ���ʡ��</b> <%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></font> 
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= hStudent.getStudent().getId() %></font> 
        <br>
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= hStudent.getMajor().getTname() %></font> 
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= hStudent.getDepartment().getTname() %></font> 
        <font class="normal1"><b>���&nbsp;</b><%= hStudent.getFaculty().getTname() %></font> 
    </td>
    <td rowspan="7" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr> 
    <td width="67%" height="8" align="center"></td>
  </tr>
  <tr>
    <td width="67%" height="17" align="center"><font class="headline4"><b><%= "�����š��ŧ����¹ �Ҥ���¹��� " + HandleTimeInterval.retrieveSemester() + " �ա���֡�� " + HandleTimeInterval.retrieveYear() %></b></font></td>
  </tr>
  <tr> 
    <td width="67%" height="2">&nbsp;</td>
  </tr>
  <tr> 
    <td height="198" align="center" valign="top" bordercolor="#000000" width="67%"> 
      <table width="600" border="0" align="center" height="64">
        <tr> 
          <td height="163"> 
            <div align="center"><font class="headline4"><b>����Ԫҷ��������ŧ����¹</b></font></div>
            <br>
            <table width="100%" border="2" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC" align="center" height="100">
              <tr bgcolor="#FFFF99" align="center"> 
                <td width="12%" align="center" height="30" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="56%" height="40" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                </td>
                <td width="10%" height="40" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                </td>
                <td width="10%" height="40" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>�͹</b></font></div>
                </td>
                <td width="12%" height="40" bgcolor="#006666"> 
                  <div align="center"><font class="headline2"><b>������</b></font></div>
                </td>
              </tr>
              <%
					Vector v = hRegister.retrieveRegisterData(hStudent.getStudent(), HandleTimeInterval.retrieveSemester(), HandleTimeInterval.retrieveYear());
					Enumeration e = v.elements();

					while(e.hasMoreElements())
					{
						Register r = (Register)e.nextElement();

						/* credit to show */
						allCredit = allCredit + Integer.parseInt(r.getSubject().getCredit());	
			
						out.println(
						"<tr>" +
						"<td align=\"center\" bgcolor=\"#669999\" valign=\"top\" width=\"13%\" height=\"30\"><font class=\"normal1\">" + r.getSubject().getId() + "</font></td>"+
						"<td bgcolor=\"#669999\" valign=\"top\" width=\"70%\" height=\"30\"><font class=\"normal1\">" + r.getSubject().getEname() + "</font></td>" +
						"<td bgcolor=\"#669999\" valign=\"top\" width=\"15%\" height=\"30\"><div align=\"center\"><font class=\"normal1\">" + r.getSubject().getCredit() + "</font></div></td>" +
						"<td bgcolor=\"#669999\" width=\"10%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + r.getSubject().getSection().getSec() + "</font></div></td>" +
						"<td bgcolor=\"#669999\" width=\"12%\" height=\"30\" valign=\"bottom\"><div align=\"center\"><font class=\"normal1\">" + ((r.getRegisterType().equals("C")) ? "Credit" : "Audit") + "</font></div></td>" +
						"</tr>");
					}
			 %>
              <tr bordercolor="#FFFFCC"> 
                <td align="center" bgcolor="#006666" valign="top" colspan="2" height="30" bordercolor="#CCCCCC"> 
                  <div align="right"><font class="headline2"><b>���</b></font></div>
                </td>
                <td bgcolor="#006666" valign="top" height="30" bordercolor="#CCCCCC"> 
                  <div align="center"><font class="headline2"><b><%= Integer.toString(allCredit) %></b></font></div>
                </td>
                <td bgcolor="#006666" valign="top" height="30" bordercolor="#CCCCCC" colspan="2"><font class="headline2"><b>˹��¡Ե</b></font></td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="247" align="center" valign="top" bordercolor="#000000" width="67%"> 
      <div align="center"> <br>
        <font class="headline4"><b> 
		��������´��������
        </b></font> <br>
        <br>
      </div>
      <table width="81%" border="2" cellspacing="2" cellpadding="5" bgcolor="#669999" bordercolor="#CCCCCC" align="center" height="129">
        <tr bgcolor="#FFFF99"> 
          <td align="center" height="30" bgcolor="#006666"> 
            <div align="center"><font class="headline2"><b>��������´</b></font></div>
          </td>
          <td width="20%" height="40" align="center" bgcolor="#006666"> 
            <div align="center"><font class="headline2"><b>�ӹǹ�Թ (�ҷ)</b></font></div>
          </td>
        </tr>
        <% 
				DecimalFormat format = new DecimalFormat("0.00");
				double totalCost = 0.00f;
				
				if(hStudent.getStudent().getType().equals("C"))
				{
					/********************* Private Cost *********************/	
					conditions = ", student where cost.sco# = student.sco# and cost.type = 'P' and student.std# = '" + hStudent.getStudent().getId() + "' and (cost.semester = '" + HandleTimeInterval.retrieveSemester() + "' or cost.semester = 'A')";
					Vector privateCost = hCost.retrieveCost(conditions);
					e = privateCost.elements();

					while(e.hasMoreElements())
					{
						Cost c  = (Cost)e.nextElement();

						if(!c.getName().equals("����������¹����֡��Ẻ���Ҩ���"))
						{
							totalCost = totalCost + Double.parseDouble(c.getValue());

							out.println("<tr>" + 
											   "<td bgcolor=\"#669999\" height=\"27\"><div align=\"left\"><font class=\"normal1\">" + c.getName() + "</font></div></td>"+
											   "<td bgcolor=\"#669999\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + c.getValue() + "</font></div></td>" +
											   "</tr>");
						}
					}

					/********************* Common Cost *********************/
					conditions = "where type = 'C' and (semester = '" + HandleTimeInterval.retrieveSemester() + "' OR semester = 'A') ";
					Vector commonCost = hCost.retrieveCost(conditions);
					e = commonCost.elements();

					while(e.hasMoreElements())
					{
						Cost c  = (Cost)e.nextElement();

						if(c.getName().equals("���ŧ����¹����Ԫ�"))
						{							
							double value = Double.parseDouble(c.getValue());
							value = value * allCredit;
							totalCost = totalCost + value;
							
							c.setName(c.getName() + " " + Integer.toString(allCredit) + " ˹��¡Ե");
							c.setValue(format.format(value));
						}
						else
						{
							totalCost = totalCost + Double.parseDouble(c.getValue());
						}
	
						out.println("<tr>" + 
						"<td bgcolor=\"#669999\" height=\"27\"><div align=\"left\"><font class=\"normal1\">" + c.getName()  + "</font></div></td>"+
						"<td bgcolor=\"#669999\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + c.getValue() + "</font></div></td>" +
						"</tr>");
					}
				}
				else
				{
					/********************* �ѡ�֡���ç��þ���� *********************/
					conditions = "where name = '����������¹����֡��Ẻ���Ҩ���'";
					Vector specialProjectCost = hCost.retrieveCost(conditions);
					e = specialProjectCost.elements();

					if(e.hasMoreElements())
					{
						Cost c = (Cost)e.nextElement();

						totalCost = totalCost + Double.parseDouble(c.getValue());

						out.println("<tr>" + 
										   "<td bgcolor=\"#669999\" height=\"27\"><div align=\"left\"><font class=\"normal1\">" + c.getName()  + "</font></div></td>"+
										   "<td bgcolor=\"#669999\" width=\"9%\" height=\"27\"><div align=\"center\"><font class=\"normal1\">" + c.getValue() + "</font></div></td>" +
										   "</tr>");
					}
				}
          %>
        <tr> 
          <td align="center" bgcolor="#006666" height="27"> 
            <div align="right"><font class="headline2"><b>����Թ����ͧ����</b></font></div>
          </td>
          <td bgcolor="#006666" width="9%" height="27"> 
            <div align="center"><font class="headline2"><b><%= format.format(totalCost) %></b></font></div>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr> 
    <td height="59" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
