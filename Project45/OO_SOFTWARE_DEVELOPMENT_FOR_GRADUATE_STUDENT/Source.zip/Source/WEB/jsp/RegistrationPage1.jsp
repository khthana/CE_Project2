<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*,graduate.*, register.* " %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �к�ŧ����¹</title>
<%
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandleRegister hRegister = (HandleRegister)session.getAttribute("Register");
	hRegister.writeAllSubjectToJavaScriptFile();
	hRegister.clearAllRegister();		

	int numberOfSection = 0;
	boolean note = false;
%>

<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<script language="javascript" src="http://161.246.5.86/Script/Script.js">
</script>
<script language="javascript">
	function search(id)
	{
		for(var i=0; i<subjectId.length; i++)
		{
			if(subjectId[i] == id)
			{
				return i;
			}
		}

		return -1;
	}

	function getId(i)
	{
		return subjectId[i];
	}

	function getName(i)
	{
		return subjectName[i];
	}

	function getCredit(i)
	{
		return subjectCredit[i];
	}

	function isDuplicate(subjId1,subjId2)
	{
		return ((subjId1.value == subjId2.value) && (subjId1.name != subjId2.name)) ? true : false;
	}

	function restoreName(subjId,subjName)
	{
		i = search(subjId.value);
		if(i != -1)
		{
			subjName.value = getName(i);
		}
		else
		{
			subjName.value = "";
		}
	}

	function restoreCredit(subjId,subjCredit)
	{
		i = search(subjId.value);
		if(i != -1)
		{
			subjCredit.value = getCredit(i);
		}
		else
		{
			subjCredit.value = "";			
		}
	}

	function checkSection(subjId,subjName,subjCredit,subjSec,subjType)
	{
		var length = subjId.value.length;
		
		// change color
		subjId.style.color = "black";
		subjName.style.color = "black";
		subjCredit.style.color = "black";
		subjSec.style.color = "black";
		subjType.style.color = "black";

		if(length != 8)
		{
			subjId.value = "";
			subjName.value = "";
			subjCredit.value = "";
			subjSec.value = "1";
			subjType.value = "Credit";
		}
		else
		{
			if(isDuplicate(subjId,form.subId1) ||
			   isDuplicate(subjId,form.subId2) ||
			   isDuplicate(subjId,form.subId3) ||
			   isDuplicate(subjId,form.subId4) ||
			   isDuplicate(subjId,form.subId5) ||
			   isDuplicate(subjId,form.subId6) ||
			   isDuplicate(subjId,form.subId7) ||
			   isDuplicate(subjId,form.subId8))
			{
				alert("�����Ԫҫ�� ��سһ�͹�����Ԫ�����");
				subjId.value = "";
				subjName.value = "";
				subjCredit.value = "";
				subjSec.value = "1";
				subjType.value = "Credit";
			}
			else
			{
				i = search(subjId.value);
				if(i != -1)
				{
					subjName.value = getName(i);
					subjCredit.value = getCredit(i);
				}
				else
				{
					subjId.value = "";
					subjName.value = "";
					subjCredit.value = "";
					subjSec.value = "1";
					subjType.value = "Credit";
				}
			}
		}
	}	
</script>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507">
  <tr> 
      <td height="19" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr> 
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/registration.gif" width="227" height="57"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="17" bgcolor="#FFFFCC" width="67%" align="center"> 
		<font class="normal1"><b>���� - ���ʡ��</b> <%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></font> 
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= hStudent.getStudent().getId() %></font> 
        <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b><%= hStudent.getCourse().getTname() %></font> 
        <br>
        <font class="normal1"><%= (hStudent.getMinor().getTname() == "") ? "" : "<b>ᢹ��Ԫ�</b> " + hStudent.getMinor().getTname() %></font> 
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= hStudent.getMajor().getTname() %></font> 
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= hStudent.getDepartment().getTname() %></font> 
        <font class="normal1"><b>���&nbsp;</b><%= hStudent.getFaculty().getTname() %></font> 
    </td>
  </tr>
  <tr> 
    <td align="center" height="48" valign="middle"> 
      <div align="center"><font class="headline4"><b>��¡��ŧ����¹���¹</b></font></div>
    </td>
  </tr>
  <tr> 
    <td height="453" align="center" valign="top" bordercolor="#000000" width="67%"> 
      <form method="post" action="RegistrationPage2.jsp" name="form">
        <table width="600" border="0" align="center" class="normaldetail">
          <tr valign="top" align="center">  
            <td height="225" colspan="2"> 
              <table width="85%" border="1" cellspacing="2" cellpadding="5" align="center" bgcolor="#669999" bordercolor="#CCCCCC">
                <tr align="center"> 
                  <td width="11%" align="center" height="40" bgcolor="#006666">
                    <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                  </td>
                  <td width="56%" height="40" bgcolor="#006666">
                    <div align="center"><font class="headline2"><b>�����Ԫ�</b></font></div>
                  </td>
                  <td width="10%" height="40" bgcolor="#006666">
                    <div align="center"><font class="headline2"><b>˹��¡Ե</b></font></div>
                  </td>
                  <td width="6%" height="40" bgcolor="#006666">
                    <div align="center"><font class="headline2"><b>�͹</b></font></div>
                  </td>
                  <td width="14%" height="40" bgcolor="#006666">
                    <div align="center"><font class="headline2"><b>������</b></font></div>
                  </td>
                </tr>
				<%
						/* get open section */
						Vector v = hRegister.retrieveAllPreRegisterData(hStudent.getStudent());
						Enumeration e = v.elements();

						while(e.hasMoreElements())
						{
							Register r = (Register)e.nextElement();

							String sectionType = (r.getSectionType().equals("C")) ? "Credit" : "Audit";

							if(r.getSubject().getSection().getStatus().equals("A"))
							{
								numberOfSection++;

								// Open section
								out.println
								("<tr>\n" +
							     "<td align=\"center\" bgcolor=\"#669999\" width=\"11%\" height=\"14\">\n" +
								 "<input type = \"hidden\" name=\"subStatus" + Integer.toString(numberOfSection) + "\" value=\"A\">\n" +
								 "<input readonly=\"true\" type=\"text\" name=\"subId" + Integer.toString(numberOfSection) + "\" maxlength=\"8\" size=\"8\" value = \"" + r.getSubject().getId() + "\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
				                 "</td>\n" +
 								 "<td bgcolor=\"#669999\" width=\"56%\" height=\"14\">" +
								 "<input readonly=\"true\" type=\"text\" name=\"subName" + Integer.toString(numberOfSection) + "\" size=\"60\" value = \"" + r.getSubject().getEname() + "\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
								 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"10%\" height=\"14\">" +
			                     "<input readonly=\"true\" type=\"text\" name=\"subCredit" + Integer.toString(numberOfSection) + "\" size=\"5\" value =\"" + r.getSubject().getCredit() + "\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
								 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"6%\" height=\"14\">" +
						         "<input readonly=\"true\" type=\"text\" name=\"subSec" + Integer.toString(numberOfSection) + "\" size=\"3\" value=\"" + r.getSubject().getSection().getSec() + "\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
								 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"14%\" height=\"14\">" +
			                     "<input readonly=\"true\" type=\"text\" name=\"subType" + Integer.toString(numberOfSection) + "\" size=\"8\" value=\"" + sectionType + "\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
								 "</td>\n" +
								 "</tr>\n"
								);

								hRegister.changeRegisterType(r);
							}
							else
							{
								numberOfSection++;
								note = true;

								// Closed section
								out.println
								("<tr>\n" +
							     "<td align=\"center\" bgcolor=\"#669999\" width=\"11%\" height=\"14\">\n" +
								 "<input type = \"hidden\" name=\"subStatus" + Integer.toString(numberOfSection) + "\" value=\"C\">\n" +
								 "<input type=\"text\" name=\"subId" + Integer.toString(numberOfSection) + "\" maxlength=\"8\" size=\"8\" value = \"" + r.getSubject().getId() + "\" style=\"COLOR:#FF0000;\" onBlur=checkSection(form.subId" + Integer.toString(numberOfSection) + ",form.subName" + Integer.toString(numberOfSection) + ",form.subCredit" + Integer.toString(numberOfSection) + ",form.subSec" + Integer.toString(numberOfSection) + ",form.subType" + Integer.toString(numberOfSection) + ")>\n" +
				                 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"56%\" height=\"14\">\n" +
								 "<input readonly=\"true\" type=\"text\" name=\"subName" + Integer.toString(numberOfSection) + "\" size=\"60\" value = \"" + r.getSubject().getEname() + "\" style=\"BORDER: #669999 thin solid;COLOR:#FF0000;BACKGROUND-COLOR: #669999;\">\n" +
								 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"10%\" height=\"14\">\n" +
			                     "<input readonly=\"true\" type=\"text\" name=\"subCredit" + Integer.toString(numberOfSection) + "\" size=\"5\" value =\"" + r.getSubject().getCredit() + "\" style=\"BORDER: #669999 thin solid;COLOR:#FF0000;BACKGROUND-COLOR: #669999;\">\n" +
								 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"6%\" height=\"14\">\n" +
				                 "<input type=\"text\" name=\"subSec" + Integer.toString(numberOfSection) + "\" size=\"3\" value=\"" + r.getSubject().getSection().getSec() + "\" style=\"COLOR:#FF0000;\">\n" +
								 "</td>\n" +
								 "<td bgcolor=\"#669999\" width=\"14%\" height=\"30\" valign=\"bottom\">\n" +
			                     "<select name=\"subType" + Integer.toString(numberOfSection) + "\" style=\"COLOR:#FF0000;\">\n" +
								 "<option value=\"Credit\">Credit</option>\n" +
								 "<option value=\"Audit\">Audit</option>\n" +
								 "</select>\n" +
								 "</td>\n" +
								 "</tr>\n"
								);

								hRegister.unregister(r);
							}
						}

						/* get remainder */
						while(numberOfSection < 8)
						{
							numberOfSection++;

							out.println
							("<tr>\n" +
						     "<td align=\"center\" bgcolor=\"#669999\" width=\"11%\" height=\"14\">\n" +
 						     "<input type = \"hidden\" name=\"subStatus" + Integer.toString(numberOfSection) + "\" value=\"C\">\n" +
							 "<input type=\"text\" name=\"subId" + Integer.toString(numberOfSection) + "\" maxlength=\"8\" size=\"8\" value = \"\" onBlur=checkSection(form.subId" + Integer.toString(numberOfSection) + ",form.subName" + Integer.toString(numberOfSection) + ",form.subCredit" + Integer.toString(numberOfSection) + ",form.subSec" + Integer.toString(numberOfSection) + ",form.subType" + Integer.toString(numberOfSection) + ")>\n" +
			                 "</td>\n" +
							 "<td bgcolor=\"#669999\" width=\"56%\" height=\"14\">\n" +
							 "<input readonly=\"true\" type=\"text\" name=\"subName" + Integer.toString(numberOfSection) + "\" size=\"60\" value = \"\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
							 "</td>\n" +
							 "<td bgcolor=\"#669999\" width=\"10%\" height=\"14\">\n" +
		                     "<input readonly=\"true\" type=\"text\" name=\"subCredit" + Integer.toString(numberOfSection) + "\" size=\"5\" value =\"\" style=\"BORDER: #669999 thin solid;COLOR:#000000;BACKGROUND-COLOR: #669999;\">\n" +
							 "</td>\n" +
							 "<td bgcolor=\"#669999\" width=\"6%\" height=\"14\">\n" +
		                     "<input type=\"text\" name=\"subSec" + Integer.toString(numberOfSection) + "\" size=\"3\" value=\"1\">\n" +
							 "</td>\n" +
							 "<td bgcolor=\"#669999\" width=\"14%\" height=\"30\" valign=\"bottom\">\n" +
		                     "<select name=\"subType" + Integer.toString(numberOfSection) + "\">\n" +
							 "<option value=\"Credit\">Credit</option>\n" +
							 "<option value=\"Audit\">Audit</option>\n" +
							 "</select>\n" +
							 "</td>\n" +
							 "</tr>\n"
							);						
						}
				%>
              </table>
            </td>
          </tr>
          <tr> 
            <td height="50" valign="bottom">
			  <%
				  if(note)
				  {
					  out.print("<b><font  class=\"warning1\">�����˵� : ����Ԫҵ����ᴧ�������Ԫҷ��١�Դ� ��سҴ����͹䢡��ŧ����¹</font></b><br>");
					  note = false;
				  }
			  %>
              <li><font class="normal1"><a href="ReviewCoursePage.jsp" target="_blank">����Ԫҷ���Դ�͹</a></font></li>
			  <li><font class="normal1"><a href="RegisConstraint.html" target="_blank">���͹䢡��ŧ����¹</a></font></li>
            </td>
            <td height="50" align="right" valign="bottom"> 
              <input type="submit" name="Submit" value="   ����   ">
              <input type="reset" name="Reset" value="   ¡��ԡ   ">
            </td>
          </tr>
        </table>
      </form>
    </td>
  </tr>
  <tr> 
    <td height="23" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
