<%@ page contentType = "text/html;charset=MS874" %>
<%@  page session="true"  %>
<%@  page import="java.sql.*, java.util.*, java.io.*, java.text.*, graduate.*, register.*, course.* " %>
<%@  include file ="checksession.inc" %>
<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - �š���֡��</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
<% 
	HandleStudent hStudent = (HandleStudent)session.getAttribute("StudentInfo");
	HandleRegister hRegister = (HandleRegister)session.getAttribute("Register");

	HandleGrade hGrade = new HandleGrade();

	int showCredit = 0;
%>
</head>

<body bgcolor="#FFFFFF">
<table width="100%" border="0" cellspacing="1" cellpadding="3" height="507" bgcolor="#FFFFFF">
  <tr> 
      <td height="14" colspan="3" bgcolor="#000000">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
  </tr>
  <tr> 
    <td rowspan="5" height="367" align="center" valign="top" width="11%">&nbsp;</td>
    <td width="67%" height="46" align="center" valign="bottom"><img src="images/gradeing.gif" width="227" height="71"></td>
    <td rowspan="5" height="338" width="22%">&nbsp;</td>
  </tr>
  <tr> 
    <td height="17" bgcolor="#FFFFCC" width="67%" align="center">
		<font class="normal1"><b>���� - ���ʡ��</b> <%= hStudent.getStudent().getTname() %> <%= hStudent.getStudent().getTfamily() %></font> 
        <font class="normal1"><b>���ʹѡ�֡��&nbsp;</b><%= hStudent.getStudent().getId() %></font> 
        <font class="normal1"><b>��ѡ�ٵ�&nbsp;</b><%= hStudent.getCourse().getTname() %></font> 
        <br>
        <font class="normal1"><%= (hStudent.getMinor().getTname() == "") ? "" : "<b>ᢹ��Ԫ�</b> " + hStudent.getMinor().getTname() %></font> 
        <font class="normal1"><b>�Ң��Ԫ�&nbsp;</b><%= hStudent.getMajor().getTname() %></font> 
        <font class="normal1"><b>�Ҥ�Ԫ�&nbsp;</b><%= hStudent.getDepartment().getTname() %></font> 
        <font class="normal1"><b>���&nbsp;</b><%= hStudent.getFaculty().getTname() %></font> 
    </td>
  </tr>
  <tr> 
    <td width="67%" height="13">&nbsp;</td>
  </tr>
  <tr> 
    <td height="495" align="center" valign="top" bordercolor="#000000" width="67%">
	<%
		String semester = request.getParameter("sem");
 		String year = request.getParameter("year");

		Vector v1 = hRegister.retrieveAllRegisterSemester(hStudent.getStudent());
		Enumeration e1 = v1.elements();

		boolean all = (semester.equals("all")) ? true : false;

		while(e1.hasMoreElements())
		{
			 Register r1 = (Register)e1.nextElement();

			 if(all || (r1.getSemester().equals(semester) && r1.getYear().equals(year)))
			 {
				 out.println(
	  								"<table width=\"600\" border=\"1\" cellspacing=\"2\" cellpadding=\"5\" align=\"center\" bgcolor=\"#669999\" bordercolor=\"#CCCCCC\">" +
							        "<caption>" +
									"<font class=\"headline4\"><b>" + "�Ҥ����֡�ҷ�� " + r1.getSemester() + " �ա���֡�� " + r1.getYear() + "</b></font>" +
									"</caption>" +   						    
								    "<tr bgcolor=\"#FFFF99\">" + 
	 							    "<td width=\"12%\" bgcolor=\"#006666\" align=\"center\" height=\"40\">" +
								    "<font class=\"headline2\"><b>" +
								    "�����Ԫ�" +
								    "</b></font>" +
							        "</td>" +
							        "<td width=\"53%\" bgcolor=\"#006666\" align=\"center\">" +
								    "<font class=\"headline2\"><b>" +
								    "�����Ԫ�" +
							    	"</b></font>" +
									"</td>" +
									"<td width=\"10%\" bgcolor=\"#006666\" align=\"center\">" +
									"<font class=\"headline2\"><b>" +
									"˹��¡Ե" +
									"</b></font>" +
									"</td>" +
									"<td width=\"12%\" bgcolor=\"#006666\" align=\"center\">" +
									"<font class=\"headline2\"><b>" +
									"�š���֡��" +
									"</b></font>" +
									"</td>"+
									"</tr>"
									);
			 }

			Vector v2 = hRegister.retrieveRegisterData(hStudent.getStudent(), r1.getSemester(), r1.getYear());
			Enumeration e2 = v2.elements();

			while(e2.hasMoreElements())
			{
				Register r2 = (Register)e2.nextElement();

				if(r2.getGrade().equals("X"))
				{
					r2.setGrade("&nbsp;");
				}
				else if(r2.getSectionType().equals("C"))
				{
					// calculate total point
					hGrade.calcTotalPoint(r2.getGrade(), Double.parseDouble(r2.getSubject().getCredit()));
					hGrade.calcAllTotalPoint(r2.getGrade(), Double.parseDouble(r2.getSubject().getCredit()));
					// calculate total credit
					hGrade.calcTotalCredit(Double.parseDouble(r2.getSubject().getCredit()));
					hGrade.calcAllTotalCredit(Double.parseDouble(r2.getSubject().getCredit()));
				}
				
				showCredit = showCredit + Integer.parseInt(r2.getSubject().getCredit());
				
	  		    if(all || (r1.getSemester().equals(semester) && r1.getYear().equals(year)))
				{
					out.println("<tr>" +
								       "<td width=\"12%\" bgcolor=\"#669999\" bordercolor=\"#CCCCCC\" align=\"center\" height=\"30\">" +
								       "<font class=\"normal1\">" +
								       r2.getSubject().getId() +
								       "</font>" +
	  							       "</td>" +
								       "<td width=\"53%\" bgcolor=\"#669999\" bordercolor=\"#CCCCCC\" height=\"30\">" +
								       "<font class=\"normal1\">" +
								       r2.getSubject().getEname() +
								       "</font>" +
  								       "</td>" +
								       "<td width=\"10%\" bgcolor=\"#669999\" bordercolor=\"#CCCCCC\" align=\"center\" height=\"30\">" +
								       "<font class=\"normal1\">" +
								       r2.getSubject().getCredit() +
								       "</font>" +
	  							       "</td>" +
								       "<td width=\"12%\" bgcolor=\"#669999\" bordercolor=\"#CCCCCC\" align=\"center\" height=\"30\">" +
								       "<font class=\"normal1\">" +
								       r2.getGrade() +	
								       "</font>" +
	  							       "</td>" +
								       "</tr>");
				}
			}
			
  		    if(all || (r1.getSemester().equals(semester) && r1.getYear().equals(year)))
			{
				DecimalFormat format = new DecimalFormat("0.00");
				
				out.println("<tr bgcolor=\"#006666\">" +
							       "<td colspan=\"4\" align=\"center\" class=\"headline2\"><b>" +
							       "˹��¡Ե��� " + Integer.toString(showCredit) + " ˹��¡Ե" +
							       "</b></td>" +
								   "</tr>" +
					   	           "<tr bgcolor=\"#006666\">" +
						           "<td colspan=\"4\" align=\"center\" class=\"headline2\"><b>" +
						           "GPS " + format.format(hGrade.calcGPS()) +
						           "</b></td>" +
						           "</tr>" +
						           "<tr bgcolor=\"#006666\">" +
						           "<td colspan=\"4\" align=\"center\" class=\"headline2\"><b>" +
						           "GPA " + format.format(hGrade.calcGPA()) +
						           "</b></td>" +
						           "</tr>" +
						           "</table>" +
						           "<br><br><br>");
			}

			showCredit = 0;
			hGrade.setTotalCredit(0.00f);
			hGrade.setTotalPoint(0.00f);
		}
	%>
	</table>
    </td>
  </tr>
  <tr> 
    <td height="23" align="center" valign="top" bordercolor="#000000" width="67%"></td>
  </tr>
</table>
</body>
</html>
