<%@ page contentType="text/html;charset=WINDOWS-874"%>

<html>
<head>
<title>�к����ʹ�ȹѡ�֡�� �дѺ�ѳ�Ե�֡�� - ʶҺѹ෤����վ�Ш��������Ҥس�����Ҵ��кѧ</title>
<link rel="stylesheet" href="StyleSheet/stylesheet.css" type="text/css">
</head>

<body bgcolor="#FFFFFF">
<form method = "post"	 action="/servlet/Login" enctype="application/x-www-form-urlencoded">
  <table width="100%" border="0" cellspacing="1" cellpadding="3" height="507">
    <tr bgcolor="#000000"> 
      <td height="19" colspan="3">
	  <font class="headline1">
	  <b>
        King Mongkut's Institute of Technology Ladkrabang
	  </b>
	  </font>
	  </td>
    </tr>
    <tr bgcolor="#669999"> 
      <td colspan="3" height="46">&nbsp;</td>
    </tr>
    <tr> 
      <td rowspan="4" height="334" valign="top" align="center" width="15%"><img src="images/logo-kmitl.gif" width="139" height="137"></td>
      <td width="65%" height="149" align="left" valign="middle"><img src="images/logo.gif" width="600" height="150"></td>
      <td rowspan="4" height="294" width="20%">&nbsp;</td>
    </tr>
    <tr> 
      <td width="65%" height="218"> 
        <table width="326" border="0" cellspacing="0" height="177" align="center" bordercolor="#006666">
          <tr> 
            <td height="20" bgcolor="#006666" colspan="3"> 
              <div align="center"><font class="headline2"><b>��سҡ�͡���ʹѡ�֡��������ʼ�ҹ</b></font></div>
            </td>
          </tr>
          <tr> 
            <td height="19" bgcolor="#669999" colspan="3">&nbsp;</td>
          </tr>
          <tr> 
            <td bgcolor="#669999" height="33" width="31%"> 
              <div align="right"><font class="normal2">���ʹѡ�֡��</font></div>
            </td>
            <td bgcolor="#669999" height="33" width="6%">&nbsp; </td>
            <td bgcolor="#669999" height="33"> 
              <input type="text" name="username">
            </td>
          </tr>
          <tr> 
            <td bgcolor="#669999" width="31%" height="29"> 
              <div align="right"><font class="normal2">���ʼ�ҹ</font></div>
            </td>
            <td bgcolor="#669999" width="6%" height="29">&nbsp;</td>
            <td bgcolor="#669999" height="29"> 
              <input type="password" name="password">
            </td>
          </tr>
          <tr> 
            <td bgcolor="#669999" width="31%">&nbsp; </td>
            <td bgcolor="#669999" width="6%">&nbsp;</td>
            <td bgcolor="#669999"> 
              <input type="submit" name="Login" value="Login">
            </td>
          </tr>
        </table>
      </td>
    </tr>
    <tr bgcolor="#FFFFFF"> 
      <td width="65%" align="center">
	  <font class="warning1">
	  <b> 
        <% 
			   String error = request.getParameter("error");
		       String msg = "* ��سҷӡ����͡�Թ�����ա���� *";
		%>
        <%=((error!=null)?msg : "")%>
	  </b>
	  </font> 
	  </td>
    </tr>
    <tr bgcolor="#FFFFFF">
      <td width="65%" align="left">
        <%@ include file = "footer.inc" %>
      </td>
    </tr>
  </table>
</form>
</body>
</html>
