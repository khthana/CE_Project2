/*
 * HandleSubject.java
 *
 * Created on 8 �ѹ�Ҥ� 2545, 17:40 �.
 */

package course;

import java.util.*;
import java.sql.*;
import utility.*;

/**
 *
 * @author  KUKI
 */
public class HandleSubject 
{    
    /** Creates a new instance of HandleSubject */
    public HandleSubject() 
    {
    }
    
    public Vector retrieveCoursework(String subCourseID, String semester, String year)
    {
        Vector v = new Vector();
        
        String query = "select * from subject j, coursework c " +
                       "where c.subj# = j.subj# and c.semester = '" + semester + "' and c.year = '" + year + "' and c.sco# = " + subCourseID;            
        try
        {   
            ResultSet rs = DB.getResultSet(query);                  
            
            while(rs.next())
            {
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);                
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;            
    }
    
    public Vector retrieveSubject(String subjectID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM subject WHERE subj# = '" + subjectID + "'";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
    
    public Vector retrieveAllSubject(String courseID, String group)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM subject WHERE co# = " + courseID + " and group = '" + group + "'";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));                
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public Vector retrieveAllSubject(Course course, SubCourse subcourse)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM subject WHERE co# = " + course.getId() + " and sco# = " + subcourse.getId();
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));                
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public Vector retrieveAllSubject(String courseID, String subcourseID, String group)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM subject WHERE co# = " + courseID + " and sco# = " + subcourseID + " and group = '" + group + "'";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));                
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
        
    public Vector retrieveAllSubject(String courseID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM subject WHERE co# = " + courseID;            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));                
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }

    public Vector retrieveAllSubject()
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM subject";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Subject subject = new Subject();  
                
                subject.setId(rs.getString(1));
                subject.setEname(rs.getString(2));
                subject.setTname(rs.getString(3));                
                subject.setGroup(rs.getString(4));
                subject.setCredit(rs.getString(5));
                subject.setLecture(rs.getString(6));
                subject.setPractice(rs.getString(7));
                subject.setResearch(rs.getString(8));
                subject.setEoutline(rs.getString(9));
                subject.setToutline(rs.getString(10));                
                subject.setPrerequisite(retrievePrerequisite(subject));
                
                v.addElement(subject);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    private Subject retrievePrerequisite(Subject subject)
    {
        Subject prerequisite = new Subject();
        
        try
        {
            String query = "SELECT * " +
                           "FROM prerequisite " +
                           "WHERE subj# = '" + subject.getId() + "'";
        
            ResultSet rs = DB.getResultSet(query);
        
            if(rs.next())
            {
                Vector v = retrieveSubject(rs.getString(2));
                Enumeration e = v.elements();
                
                if(e.hasMoreElements())
                {
                    prerequisite = (Subject)e.nextElement();
                }
            }
            else
            {
                prerequisite = null;
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return prerequisite;        
    }
    
    public boolean addSubject(Subject s, Course c, SubCourse sc)
    {
        String query = "INSERT INTO subject(subj#, ename, tname, group, credit, lecture, practice, research, eoutline, toutline, co#, sco#) " +
                       "VALUES('" + s.getId() + "', '" + s.getEname() + "', '" + s.getTname() + "', '" + s.getGroup() + "', '" + s.getCredit() + "', '" + s.getLecture() + "', '" + s.getPractice() + "', '" + s.getResearch() + "', '" + s.getEoutline() + "', '" + s.getToutline() + "', " + c.getId() + ", " + sc.getId() + ")";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                             
    }
    
    public boolean deleteSubject(Subject s, Course c, SubCourse sc)
    {
        String query = "DELETE FROM subject WHERE subj# = '" + s.getId() + "' and co# = " + c.getId() + " and sco# = " + sc.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                                     
    }
    
    public boolean updateSubject(Subject news, Course c, SubCourse sc)
    {
        String query = "UPDATE subject " +
                       "SET " +
                       "subj# = '" + news.getId() + "', " +
                       "ename = '" + news.getEname() + "', " +
                       "tname = '" + news.getTname() + "', " +
                       "group = '" + news.getGroup() + "', " +
                       "credit = '" + news.getCredit() + "', " +
                       "lecture = '" + news.getLecture() + "', " +
                       "practice = '" + news.getPractice() + "', " +
                       "research = '" + news.getResearch() + "', " +
                       "eoutline = '" + news.getEoutline() + "', " +
                       "toutline = '" + news.getToutline() + "' " +                       
                       "WHERE subj# = '" + news.getId() + "' and co# = " + c.getId() + " and sco# = " + sc.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    private boolean updatePrerequisite(Subject news, Subject olds)
    {
        String query = "UPDATE prerequisite " +
                       "SET " +
                       "pre_subj# = '" + news.getPrerequisite().getId() + "' " +
                       "WHERE subj# = '" + olds.getId() + "' ";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean addCoursework(String subjectID, String subcourseID, String semester, String year)
    {
        String query = "INSERT INTO coursework(sco#, subj#, semester, year) " +
                       "VALUES(" + subcourseID + ", '" + subjectID + "', '" + semester + "', '" + year + "')";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;             
    }
    
    public boolean delCoursework(String subjectID, String subcourseID)
    {
        String query = "DELETE FROM coursework WHERE sco# = " + subcourseID + " and subj# = '" + subjectID + "'";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                     
    }
    
    public boolean delAllCoursework(String subcourseID)
    {
        String query = "DELETE FROM coursework WHERE sco# = " + subcourseID;
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                     
    }
    
    public boolean addPrerequisite(Subject subject, Subject prerequisite)
    {
        String query = "INSERT INTO prerequisite(subj#, pre_subj#) " +
                       "VALUES('" + subject.getId() + "', '" + prerequisite.getId() + "')";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                             
    }
    
    public boolean deletePrerequisite(Subject subject, Subject prerequisite)
    {
        String query = "DELETE FROM prerequisite WHERE subj# = '" + subject.getId() + "' and pre_subj# = '" + prerequisite.getId() + "'";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                             
    }    
}
