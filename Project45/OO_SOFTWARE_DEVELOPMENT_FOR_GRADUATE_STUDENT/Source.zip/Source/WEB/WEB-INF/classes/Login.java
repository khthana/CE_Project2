import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import java.sql.*;
import java.util.*;
import graduate.*;
import utility.*;

public class Login extends HttpServlet 
{    
    public void init(ServletConfig config) throws ServletException
    {
	super.init(config);
        DB.connect("Administrator", "nomchit4", "jdbc:db2://161.246.5.90/GRADUATE");                    
    }
    
    public void validate(HttpServletRequest request, HttpServletResponse response) 
        throws ServletException, IOException {
            
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession(true);
        
        Verify verify = new Verify();        

        if(verify.validateStudent(request.getParameter("username"), request.getParameter("password")))
        {
            HandleStudent hStudent = new HandleStudent();
            Vector v = hStudent.retrieveStudentInfo(request.getParameter("username"));
            Enumeration e = v.elements();
            
            if(e.hasMoreElements())
            {
                hStudent = (HandleStudent)e.nextElement();
            }
            
            session.setAttribute("StudentInfo", hStudent);                                        
            session.setAttribute("ISLOGIN", "true");
            response.sendRedirect("../jsp/MainPage.jsp");            
        }
        else
        {
            response.sendRedirect("/jsp/LoginPage.jsp?error=true");            
        }
    }
    
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        validate(request, response);
    }     
}
