/*
 * HandleStudent.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 16:53 �.
 */

package graduate;

import java.util.*;
import java.sql.*;
import organize.*;
import course.*;
import register.*;
import utility.*;
import java.text.*;

/**
 *
 * @author  KUKI
 */
public class HandleStudent 
{    
    private Faculty faculty = new Faculty();
    private Department department = new Department();
    private Major major = new Major();
    private Minor minor = new Minor();
    private Course course = new Course();
    private SubCourse subCourse = new SubCourse();
    private Student student = new Student();
    
    /** Creates a new instance of HandleStudent */
    public HandleStudent() 
    {
    }
    
    public Faculty getFaculty()
    {
        return this.faculty;
    }
    
    public Department getDepartment()
    {
        return this.department;
    }
    
    public Major getMajor()
    {
        return this.major;
    }
    
    public Minor getMinor()
    {
        return this.minor;
    }
    
    public Course getCourse()
    {
        return this.course;
    }
    
    public SubCourse getSubCourse()
    {
        return this.subCourse;
    }
    
    public Student getStudent()
    {
        return this.student;
    }
    
    public void setFaculty(Faculty faculty)
    {
        this.faculty = faculty;
    }
    
    public void setDepartment(Department department)
    {
        this.department = department;
    }
    
    public void setMajor(Major major)
    {
        this.major = major;
    }
    
    public void setMinor(Minor minor)
    {
        this.minor = minor;
    }
    
    public void setCourse(Course course)
    {
        this.course = course;
    }
    
    public void setSubCourse(SubCourse subCourse)
    {
        this.subCourse = subCourse;
    }
    
    public void setStudent(Student student)
    {
        this.student = student;
    }  

    public Vector retrieveStudentInfo(String courseID, String subCourseID, String term, String year)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "select * from student where co# = " + courseID + " and sco# = " + subCourseID + " and interm = '" + term + "' and inyear = '" + year + "'";
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                Student student = new Student();
                
                student.setId(rs.getString(1));
                student.setConsultantId(rs.getString(2));
                student.setEpre(rs.getString(5));
                student.setEname(rs.getString(6));
                student.setEfamily(rs.getString(7));
                student.setTpre(rs.getString(8));
                student.setTname(rs.getString(9));
                student.setTfamily(rs.getString(10));
                student.setSex(rs.getString(20));
                student.setBirthDay(rs.getDate(21));
                student.setOrigin(rs.getString(22));
                student.setCitizen(rs.getString(23));
                student.setReligion(rs.getString(24));
                student.setRecentAddress(rs.getString(25));
                student.setRealAddress(rs.getString(26));
                student.setHomePhone(rs.getString(27));
                student.setMobilePhone(rs.getString(28));
                student.setEmail(rs.getString(29));
                student.setOldInstitute(rs.getString(30));
                student.setOldYearOut(rs.getString(31));
                student.setOldGpa(rs.getString(32));
                student.setOldDegree(rs.getString(33));
                student.setOldSDegree(rs.getString(34));
                student.setOldFaculty(rs.getString(35));
                student.setOldMajor(rs.getString(36));
                student.setFather(rs.getString(37));
                student.setFatherWork(rs.getString(38));
                student.setMother(rs.getString(39));
                student.setMotherWork(rs.getString(40));
                student.setContactor(rs.getString(41));
                student.setContactorWork(rs.getString(42));
                student.setContactorReletionship(rs.getString(43));
                student.setContactorPhone(rs.getString(44));
                student.setContactorAddress(rs.getString(45));
                student.setInDate(rs.getDate(46));
                student.setOutDate(rs.getDate(47));
                student.setInSemester(rs.getString(12));
                student.setInYear(rs.getString(13));
                student.setLocation(rs.getString(48));
                student.setPassword(rs.getString(11));
                student.setType(rs.getString(19));
                
                v.addElement(student);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        } 

        return v;
    }        
       
    public Vector retrieveStudentInfo(String studentID)
    {
        HandleStudent hStudent = new HandleStudent();
        Vector v = new Vector();
        
        Enumeration e = null;        
        ResultSet rs = null;
        
        try
        {
            String query = "SELECT * FROM student WHERE std# = '" + studentID + "'";
            
            rs = DB.getResultSet(query);
            
            if(rs.next())
            {
                // retrieve student
                student.setId(rs.getString(1));
                student.setConsultantId(rs.getString(2));
                student.setEpre(rs.getString(5));
                student.setEname(rs.getString(6));
                student.setEfamily(rs.getString(7));
                student.setTpre(rs.getString(8));
                student.setTname(rs.getString(9));
                student.setTfamily(rs.getString(10));
                student.setSex(rs.getString(20));
                student.setBirthDay(rs.getDate(21));
                student.setOrigin(rs.getString(22));
                student.setCitizen(rs.getString(23));
                student.setReligion(rs.getString(24));
                student.setRecentAddress(rs.getString(25));
                student.setRealAddress(rs.getString(26));
                student.setHomePhone(rs.getString(27));
                student.setMobilePhone(rs.getString(28));
                student.setEmail(rs.getString(29));
                student.setOldInstitute(rs.getString(30));
                student.setOldYearOut(rs.getString(31));
                student.setOldGpa(rs.getString(32));
                student.setOldDegree(rs.getString(33));
                student.setOldSDegree(rs.getString(34));
                student.setOldFaculty(rs.getString(35));
                student.setOldMajor(rs.getString(36));
                student.setFather(rs.getString(37));
                student.setFatherWork(rs.getString(38));
                student.setMother(rs.getString(39));
                student.setMotherWork(rs.getString(40));
                student.setContactor(rs.getString(41));
                student.setContactorWork(rs.getString(42));
                student.setContactorReletionship(rs.getString(43));
                student.setContactorPhone(rs.getString(44));
                student.setContactorAddress(rs.getString(45));
                student.setInDate(rs.getDate(46));
                student.setOutDate(rs.getDate(47));
                student.setInSemester(rs.getString(12));
                student.setInYear(rs.getString(13));
                student.setLocation(rs.getString(48));
                student.setPassword(rs.getString(11));
                student.setType(rs.getString(19));
                
                hStudent.setStudent(student);
                
                // retrieve faculty
                HandleFaculty hFaculty = new HandleFaculty();
                Vector f = hFaculty.retrieveFaculty(rs.getString("fact#"));
                e = f.elements();
                
                if(e.hasMoreElements())
                {
                    faculty = (Faculty)e.nextElement();
                    hStudent.setFaculty(faculty);                    
                }
                
                // retrieve department
                HandleDepartment hDepartment = new HandleDepartment();
                Vector d = hDepartment.retrieveDepartment(rs.getString("dept#"));
                e = d.elements();
                
                if(e.hasMoreElements())
                {
                    department = (Department)e.nextElement();
                    hStudent.setDepartment(department);
                }

                // retrieve major
                HandleMajor hMajor = new HandleMajor();
                Vector mj = hMajor.retrieveMajor(rs.getString("major#"));
                e = mj.elements();
                
                if(e.hasMoreElements())
                {
                    major = (Major)e.nextElement();
                    hStudent.setMajor(major);
                }
                
                // retrieve minor
                HandleMinor hMinor = new HandleMinor();
                Vector mn = hMinor.retrieveMinor(rs.getString("minor#"));
                e = mn.elements();
                
                if(e.hasMoreElements())
                {
                    minor = (Minor)e.nextElement();
                    hStudent.setMinor(minor);                    
                }
                
                // retrieve course
                HandleCourse hCourse = new HandleCourse();
                Vector c = hCourse.retrieveCourse(rs.getString("co#"));
                e = c.elements();
                
                if(e.hasMoreElements())
                {
                    course = (Course)e.nextElement();
                    hStudent.setCourse(course);
                }                                
                
                // retrieve subcourse
                Vector sc = hCourse.retrieveSubCourse(hStudent.getCourse());
                e = sc.elements();
                
                if(e.hasMoreElements())
                {
                    subCourse = (SubCourse)e.nextElement();
                    hStudent.setSubCourse(subCourse);
                }
                
                v.addElement(hStudent);                
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        } 

        return v;
    }
    
    public boolean isProbation(Student s, String semester, String year)
    {
        HandleRegister hRegister = new HandleRegister();
        HandleGrade hGrade = new HandleGrade();        
        
	Vector vTerm = hRegister.retrieveAllRegisterSemester(s);
        Enumeration eTerm = vTerm.elements();
        
        while(eTerm.hasMoreElements())
        {
            /* calculate GPA in each term */            
            Register r = (Register)eTerm.nextElement();
            
            Vector vRegisData = hRegister.retrieveRegisterData(s, r.getSemester(), r.getYear());
            Enumeration eRegisData = vRegisData.elements();

            /* all register section in that term */                             
            while(eRegisData.hasMoreElements())
            {
                Register rData = (Register)eRegisData.nextElement();
                
                if(rData.getGrade().equals("X"))
                {                    
                    // grade incomplete return false                 
                    return false;
		}
		else if(rData.getSectionType().equals("C"))
		{
                    // calculate total point for GPA
                    hGrade.calcAllTotalPoint(rData.getGrade(), Double.parseDouble(rData.getSubject().getCredit()));                    
                    // calculate total credit for GPA
                    hGrade.calcAllTotalCredit(Double.parseDouble(rData.getSubject().getCredit()));
		}
            }
            
            DecimalFormat format = new DecimalFormat("0.00");
            double gpa = Double.parseDouble(format.format(hGrade.calcGPA()));
            
            if(r.getSemester().equals(semester) && r.getYear().equals(year))
            {
                // if is probation return true
                if(gpa < hGrade.getProbationRule()) return true;
            }            
        }
        
        // not probation
        return false;
    }
    
    public boolean isRetry(Student s)
    {
        HandleRegister hRegister = new HandleRegister();
        HandleGrade hGrade = new HandleGrade();        
        
	Vector vTerm = hRegister.retrieveAllRegisterSemester(s);
        Enumeration eTerm = vTerm.elements();
        
        boolean isPro = false;
        
        while(eTerm.hasMoreElements())
        {
            /* calculate GPS in each term */            
            Register r = (Register)eTerm.nextElement();
            
            Vector vRegisData = hRegister.retrieveRegisterData(s, r.getSemester(), r.getYear());
            Enumeration eRegisData = vRegisData.elements();            

            /* all register section in that term */                             
            while(eRegisData.hasMoreElements())
            {
                Register rData = (Register)eRegisData.nextElement();
                
                if(rData.getGrade().equals("X"))
                {                    
                    // grade incomplete return false                 
                    return false;
		}
		else if(rData.getSectionType().equals("C"))
		{
                    // calculate total point for GPS
                    hGrade.calcTotalPoint(rData.getGrade(), Double.parseDouble(rData.getSubject().getCredit()));                    
                    // calculate total credit for GPS
                    hGrade.calcTotalCredit(Double.parseDouble(rData.getSubject().getCredit()));
		}
            }
            
            DecimalFormat format = new DecimalFormat("0.00");
            double gps = Double.parseDouble(format.format(hGrade.calcGPS()));
            
            // check for retry            
            if(isPro)
            {
                if(gps < hGrade.getRetryRule()) return true;
            }
            
            // check for probation
            isPro = isProbation(s, r.getSemester(), r.getYear());                   
            
            hGrade.setTotalCredit(0.00f);
            hGrade.setTotalPoint(0.00f);            
        }
        
        // not retry
        return false;
    }
    
    public Vector getAllStudentInterm(SubCourse subcourse)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "select interm, inyear from student where sco# = " + subcourse.getId() + " group by interm, inyear";
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                String s = new String();
                s = rs.getString(1);
                s = s + "/" + rs.getString(2);
                
                v.addElement(s);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public boolean addStudent(Student s, SubCourse sc, Course c, Minor mn, Major mj, Department dept, Faculty fact)
    {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        
        String birthDay = "";
        String birthDayHead = "";
        if(s.getBirthDay() != null)
        {
            birthDay = format.format(s.getBirthDay()) + "', '";
            birthDayHead = "birthday, ";
        }
        String inDate = "";
        String inDateHead = "";
        if(s.getInDate() != null)
        {
            inDate = format.format(s.getInDate()) + "', '";
            inDateHead = "indate, ";            
        }
        String outDate = "";
        String outDateHead = "";
        if(s.getOutDate() != null)
        {
            outDate = format.format(s.getOutDate()) + "', '";
            outDateHead = "outdate, ";           
        }
        String minor = "";
        String minorHead = "";
        if(mn != null)
        {
            minor = mn.getId() + "', '";
            minorHead = "minor#, ";
        }
        
        String query = "INSERT INTO student(std#, lect#, sco#, epre, ename, efamily, tpre, tname, tfamily, password, interm, inyear, co#, fact#, dept#, major#, " + minorHead + "type, sex, " + birthDayHead + "origin, citizen, religion, recent_addr, register_addr, home_phone, mobile_phone, email, oldinstitute, oldyrout, oldgpa, olddegree, oldsdegree, oldfac, oldmajor, father, father_work, mother, mother_work, contact, co_work, co_relate, co_tel, co_addr, " + inDateHead + outDateHead + "location) " +
                       "VALUES('" + s.getId() + "', '" + s.getConsultantId() + "', " + sc.getId() + ", '" + s.getEpre() + "', '" + s.getEname() + "', '" + s.getEfamily() + "', '" + s.getTpre() + "', '" + s.getTname() + "', '" + s.getTfamily() + "', '" + s.getPassword() + "', '" + s.getInSemester() + "', '" + s.getInYear() + "', " + c.getId() + ", '" + fact.getId() + "', '" + dept.getId() + "', '" + mj.getId() + "', '" + minor + s.getType() + "', '" + s.getSex() + "', '" + birthDay + s.getOrigin() + "', '" + s.getCitizen() + "', '" + s.getReligion() + "', '" +
                                    s.getRecentAddress() + "', '" + s.getRealAddress() + "', '" + s.getHomePhone() + "', '" + s.getMobilePhone() + "', '" + s.getEmail() + "', '" + s.getOldInstitute() + "', '" + s.getOldYearOut() + "', '" + s.getOldGpa() + "', '" + s.getOldDegree() + "', '" + s.getOldSDegree() + "', '" + s.getOldFaculty() + "', '" + s.getOldMajor() + "', '" + 
                                    s.getFather() + "', '" + s.getFatherWork() + "', '" + s.getMother() + "', '" + s.getMotherWork() + "', '" + s.getContactor() + "', '" + s.getContactorWork() + "', '" + s.getContactorReletionship() + "', '" + s.getContactorPhone() + "', '" + s.getContactorAddress() + "', '" + inDate + outDate + s.getLocation() + "')";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean deleteStudent(Student s)
    {
        String query = "DELETE FROM student WHERE std# = '" + s.getId() + "'";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean updateStudent(Student news)
    {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        
        String birthDay = "";
        if(news.getBirthDay() != null)
        {
            birthDay = "birthday = '" + format.format(news.getBirthDay()) + "', ";
        }
        
        String indate = "";
        if(news.getInDate() != null)
        {
            indate = "indate = '" + format.format(news.getInDate()) + "', ";
        }
        
        String outdate = "";
        if(news.getOutDate() != null)
        {
            outdate = "outdate = '" + format.format(news.getOutDate()) + "', ";
        }        
        
        String query = "UPDATE student " +
                       "SET " +
                       "lect# = '" + news.getConsultantId() + "', " +
                       "epre = '" + news.getEpre() + "', " +
                       "ename = '" + news.getEname() + "', " +
                       "efamily = '" + news.getEfamily() + "', " +
                       "tpre = '" + news.getTpre() + "', " +
                       "tname = '" + news.getTname() + "', " +
                       "tfamily = '" + news.getTfamily() + "', " +
                       "password = '" + news.getPassword() + "', " +
                       "type = '" + news.getType() + "', " +
                       "sex = '" + news.getSex() + "', " +
                       birthDay +
                       "origin = '" + news.getOrigin() + "', " +
                       "citizen = '" + news.getCitizen() + "', " +
                       "religion = '" + news.getReligion() + "', " +
                       "recent_addr = '" + news.getRecentAddress() + "', " +
                       "register_addr = '" + news.getRealAddress() + "', " +
                       "home_phone = '" + news.getHomePhone() + "', " +
                       "mobile_phone = '" + news.getMobilePhone() + "', " +
                       "email = '" + news.getEmail() + "', " +
                       "oldinstitute = '" + news.getOldInstitute() + "', " +
                       "oldyrout = '" + news.getOldYearOut() + "', " +
                       "oldgpa = '" + news.getOldGpa() + "', " +
                       "olddegree = '" + news.getOldDegree() + "', " +
                       "oldsdegree = '" + news.getOldSDegree() + "', " +
                       "oldfac = '" + news.getOldFaculty() + "', " +
                       "oldmajor = '" + news.getOldMajor() + "', " +
                       "father = '" + news.getFather() + "', " +
                       "father_work = '" + news.getFatherWork() + "', " +
                       "mother = '" + news.getMother() + "', " +
                       "mother_work = '" + news.getMotherWork() + "', " +
                       "contact = '" + news.getContactor() + "', " +
                       "co_work = '" + news.getContactorWork() + "', " +
                       "co_relate = '" + news.getContactorReletionship() + "', " +
                       "co_tel = '" + news.getContactorPhone() + "', " +
                       "co_addr = '" + news.getContactorAddress() + "', " +
                       indate +
                       outdate +
                       "location = '" + news.getLocation() + "' " +
                       "WHERE " +
                       "std# = '" + news.getId() + "'";                      
                       
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                          
    }
}