package utility;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;

public class Tree
{
    protected DefaultMutableTreeNode rootNode;
    protected DefaultTreeModel treeModel;
    protected JTree tree;
    private Toolkit toolkit = Toolkit.getDefaultToolkit();

    public Tree(DefaultMutableTreeNode rootNode) 
    {
        this.rootNode = rootNode;
        treeModel = new DefaultTreeModel(rootNode);

        tree = new JTree(treeModel);
        tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
        tree.setShowsRootHandles(true);
    }

    /** Remove all nodes except the root node. */
    public void clear() 
    {
        rootNode.removeAllChildren();
        treeModel.reload();
    }

    /** Remove the currently selected node. */
    public void removeCurrentNode() 
    {
        TreePath currentSelection = tree.getSelectionPath();
        if (currentSelection != null) 
	{
            DefaultMutableTreeNode currentNode = (DefaultMutableTreeNode)(currentSelection.getLastPathComponent());
            MutableTreeNode parent = (MutableTreeNode)(currentNode.getParent());
            if (parent != null) 
            {
                treeModel.removeNodeFromParent(currentNode);
                return;
            }
        } 

        // Either there was no selection, or the root was selected.
        toolkit.beep();
    }

    /** Add child to the currently selected node. */
    public DefaultMutableTreeNode addObject(Object child) 
    {
        DefaultMutableTreeNode parentNode = null;
        TreePath parentPath = tree.getSelectionPath();

        if (parentPath == null) 
        {
            parentNode = rootNode;
        } 
	else 
	{
            parentNode = (DefaultMutableTreeNode)(parentPath.getLastPathComponent());
        }

        return addObject(parentNode, child, true);
    }

    public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent, Object child) 
    {
        return addObject(parent, child, false);
    }

    public DefaultMutableTreeNode addObject(DefaultMutableTreeNode parent, Object child,  boolean shouldBeVisible) 
    {
        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);

        if (parent == null) 
	{
            parent = rootNode;
        }

        treeModel.insertNodeInto(childNode, parent, parent.getChildCount());

        // Make sure the user can see the lovely new node.
        if (shouldBeVisible) 
	{
            tree.scrollPathToVisible(new TreePath(childNode.getPath()));
        }

        return childNode;
    }
    
    public boolean isNodeChild(Object child)
    {
        TreePath parentPath = tree.getSelectionPath();
        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode)(parentPath.getLastPathComponent());
        
        for(int i=0; i<parentNode.getChildCount(); i++)
        {
            DefaultMutableTreeNode aNode = (DefaultMutableTreeNode)parentNode.getChildAt(i);
            
            if(aNode.toString().trim().equals(childNode.toString().trim()))
            {
                return true;
            }
        }
        
        return false;
    }
    
    public DefaultMutableTreeNode getChildNode(Object child)
    {
        TreePath parentPath = tree.getSelectionPath();        
        DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(child);
        DefaultMutableTreeNode parentNode = (DefaultMutableTreeNode)(parentPath.getLastPathComponent());
        
        for(int i=0; i<parentNode.getChildCount(); i++)
        {
            DefaultMutableTreeNode aNode = (DefaultMutableTreeNode)parentNode.getChildAt(i);
            if(aNode.toString().trim().equals(childNode.toString().trim()))
            {
                return aNode;
            }            
        }
        
        return null;
    }
    
    public Object getUserObject()
    {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
        return node.getUserObject();        
    }
    
    public void setUserObject(Object obj)
    {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
        node.setUserObject(obj);
        treeModel.reload(node);
    }
    
    public Object getUserObject(int previousParent)
    {        
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
        
        for(int i=0; i<previousParent; i++)
        {
           TreeNode treeNode = node.getParent();
           node = (DefaultMutableTreeNode)treeNode;
        }
        
        return node.getUserObject();                
    }

    public boolean isLeaf()
    {        
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getLastSelectedPathComponent();
        return node.isLeaf();
    }
    
    public JTree getTree()
    {
        return tree;
    }
    
    public void setTree(JTree tree)
    {
        this.tree = tree;
    }    
}
