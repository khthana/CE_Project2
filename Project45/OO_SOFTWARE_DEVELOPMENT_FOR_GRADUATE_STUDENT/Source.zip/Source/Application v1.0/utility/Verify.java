/*
 * Login.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 15:01 �.
 */

package utility;

import java.util.*;
import graduate.*;

/**
 *
 * @author  KUKI
 */
public class Verify 
{
    /** Creates a new instance of Login */
    public Verify() 
    {
    }
    
    public boolean validateRegistrar(String uname, String passwd)
    {
        String query = "SELECT * " +
                       "FROM registrar " +
                       "WHERE reg# = '" + uname + "' AND password = '" + passwd + "'";        
        
        Vector vector = DB.retrieve(query);
        
        if(vector.isEmpty())
        {
            return false;
        }

        return true;
    }
    
    public boolean validateStudent(String uname, String passwd)
    {
        String query = "SELECT * " +
                       "FROM student " +
                       "WHERE std# = '" + uname + "' AND password = '" + passwd + "'";        
        
        Vector vector = DB.retrieve(query);
        
        if(vector.isEmpty())
        {
            return false;
        }

        return true;        
    }    
}
