/*
 * DateUtil.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 14:23 �.
 */

package utility;

import java.util.Date.*;
import java.text.*;
import java.util.*;

/**
 *
 * @author  KUKI
 */
public class DateUtil 
{
    
    /** Creates a new instance of DateUtil */
    public DateUtil() 
    {
    }
    
    public static int compareWithCurrentDate(java.util.Date date)
    {        
        int flag = 0;
        java.util.Date currentDate = new java.util.Date();    
        
        String dateString = new SimpleDateFormat().getDateInstance(3).format(currentDate);
        StringTokenizer st = new StringTokenizer(dateString, "/");
        
        int cDate = Integer.parseInt(st.nextToken());
        int cMonth = Integer.parseInt(st.nextToken());
        int cYear = Integer.parseInt(st.nextToken());	
        
        dateString = new SimpleDateFormat().getDateInstance(3).format(date);
        st = new StringTokenizer(dateString, "/");
        
        int dDate = Integer.parseInt(st.nextToken());
        int dMonth = Integer.parseInt(st.nextToken());
        int dYear = Integer.parseInt(st.nextToken());
        
        if(dYear == cYear) 
        {
            if(dMonth == cMonth)
            {
                if(dDate == cDate)
                {
                    flag = 0;
                }
                else if(dDate > cDate)
                {
                    flag = 1;
                }
                else
                {
                    flag = -1;
                }
            }
            else if(dMonth > cMonth)
            {
                flag = 1;
            }
            else
            {
                flag = -1;
            }
        } 
        else if(dYear > cYear) 
        {
            flag = 1;
        } 
        else
        {
            flag = -1;
        }
        
        return flag;
    }       
}
