/*
 * StudentUI.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 21:14 �.
 */

package graduate;

import javax.swing.tree.*;
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreeSelectionModel;
import java.util.*;
import java.text.*;
import utility.*;
import course.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class StudentUI extends javax.swing.JFrame 
{
    private DefaultMutableTreeNode root;
    private StudentCourseTree scTree;    
    private Tree tree;
    
    private CardLayout cardManager;
    private Component parent;
    private SubCourse subcourse;
    private Faculty faculty;
    private Department department;
    private Major major;
    private Minor minor;
    
    /** Creates new form StudentUI */
    public StudentUI(Component parent, 
                    javax.swing.JComboBox cb1,
                    javax.swing.JComboBox cb2,
                    javax.swing.JComboBox cb3,
                    javax.swing.JComboBox cb4) 
    {
        initComponents();

        this.faculty = (Faculty)cb1.getSelectedItem();
        this.department = (Department)cb2.getSelectedItem();
        this.major = (Major)cb3.getSelectedItem();
        this.minor = (Minor)cb4.getSelectedItem();
        
        String sex[] = {"", "���", "˭ԧ"};
        String date[] = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                         "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
                         "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
                         "31"};
        String type[] = {"", "����", "�ç��þ����"};
        String month[] = {"", "���Ҥ�", "����Ҿѹ��", "�չҤ�", "����¹", "����Ҥ�", "�Զع�¹",
                              "�á�Ҥ�", "�ԧ�Ҥ�", "�ѹ��¹", "���Ҥ�", "��Ȩԡ�¹", "�ѹ�Ҥ�"};
        
        for(int i=0; i<type.length; i++)
        {
            cbStuType.addItem(type[i]);
            cbAddStuType.addItem(type[i]);
        }
                              
        for(int i=0; i<sex.length; i++)
        {
            cbStudentSex.addItem(sex[i]);
            cbAddStudentSex.addItem(sex[i]);
        }
                              
        for(int i=0;i<date.length; i++)
        {
            cbStuBrithDate.addItem(date[i]);
            cbAddStuBrithDate.addItem(date[i]);
            cbInDate.addItem(date[i]);
            cbOutDate.addItem(date[i]);
            cbAddInDate.addItem(date[i]);
            cbAddOutDate.addItem(date[i]);
        }
                              
        for(int i=0;i<month.length; i++)
        {
            cbStuBrithMonth.addItem(month[i]);
            cbAddStuBrithMonth.addItem(month[i]);
            cbInMonth.addItem(month[i]);
            cbOutMonth.addItem(month[i]);
            cbAddInMonth.addItem(month[i]);
            cbAddOutMonth.addItem(month[i]);
        }
        
        if(minor == null)
        {
            root = new DefaultMutableTreeNode("�Ң�" + ((Major)cb3.getSelectedItem()).getTname());            
            tree = new Tree(root);
            scTree = new StudentCourseTree(tree);                
            scTree.retrieveCourseInfo(major);                 
        }
        else
        {
            root = new DefaultMutableTreeNode("�Ң�" + ((Major)cb3.getSelectedItem()).getTname() + " ᢹ�" + ((Minor)cb4.getSelectedItem()).getTname());
            tree = new Tree(root);
            scTree = new StudentCourseTree(tree);                
            scTree.retrieveCourseInfo(major, minor);               
        }
        
        this.parent = parent;
        tree.getTree().setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        cardManager = (CardLayout)mainPanel.getLayout();
        jSplitPane.setOneTouchExpandable(true);
        jScrollPane.setViewportView(tree.getTree());    
        jSplitPane.setDividerLocation(200);        
        
        lbFaculty.setText("���" + ((Faculty)cb1.getSelectedItem()).getTname());
        lbDept.setText("�Ҥ�Ԫ�" + ((Department)cb2.getSelectedItem()).getTname());
        lbMajor.setText("�Ң��Ԫ�" + ((Major)cb3.getSelectedItem()).getTname());
        
        // Listen for when the selection changes
        tree.getTree().addTreeSelectionListener(new TreeSelectionListener() 
        {
            public void valueChanged(TreeSelectionEvent e) 
            {
               DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getTree().getLastSelectedPathComponent();

               if (node == null) return;

               Object nodeInfo = node.getUserObject();

               if(node.getLevel()==0) 
               {                        
                   cardManager.show(mainPanel, "generalInfo");       
               }
               else if(node.getLevel()==1)                        
               {
                   Course c = (Course)nodeInfo;
                   lbCourseName.setText("��ѡ�ٵ� " + c.getTname());
                   cardManager.show(mainPanel, "courseInfo");                          
               }
               else if(node.getLevel()==2)                        
               {
                   SubCourse sc = (SubCourse)nodeInfo;
                   lbSubCourseName.setText(sc.getTname());
                   cardManager.show(mainPanel, "subCourseInfo");                          
               }
               else if(node.getLevel()==3)                        
               {
                   String s = (String)nodeInfo;
                   lbYear.setText("�Ҥ����֡�ҷ�� " + s);
                   cardManager.show(mainPanel, "yearInfo");                          
               }               
               else if(node.getLevel()==4)                        
               {
                   cardManager.show(mainPanel, "studentInfo");
                   Student student = (Student)nodeInfo;
                   
                   // page 1
                   tfStudentID.setText(student.getId());
                   tfStudentEpre.setText(student.getEpre());
                   tfStudentEname.setText(student.getEname());
                   tfStudentEfamily.setText(student.getEfamily());
                   tfStudentTpre.setText(student.getTpre());
                   tfStudentTname.setText(student.getTname());
                   tfStudentTfamily.setText(student.getTfamily());
                   
                   if(!student.getSex().equals(""))
                   {
                       switch(student.getSex().charAt(0))
                       {
                           case 'M':
                               cbStudentSex.setSelectedIndex(1);
                               break;
                           case 'F':                           
                               cbStudentSex.setSelectedIndex(2);                       
                               break;
                           default:
                       }
                   }
                   else
                   {
                       cbStudentSex.setSelectedIndex(0);                                              
                   }
                   
                   if(student.getBirthDay() != null)
                   {
                       SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                       String date = format.format(student.getBirthDay());
                   
                       StringTokenizer st = new StringTokenizer(date,"/");
                       date = st.nextToken();
                       cbStuBrithDate.setSelectedIndex(Integer.parseInt(date));
                       date = st.nextToken();
                       cbStuBrithMonth.setSelectedIndex(Integer.parseInt(date));                    
                       date = st.nextToken();	               
                       tfStuBrithYear.setText(date);
                   }
                   else
                   {
                       cbStuBrithDate.setSelectedIndex(0);
                       cbStuBrithMonth.setSelectedIndex(0);
                       tfStuBrithYear.setText("");
                   }
                   
                   tfStudentOrigin.setText(student.getOrigin());
                   tfStudentCitizen.setText(student.getCitizen());
                   tfStudentReligion.setText(student.getReligion());  
                   
                   // page 2
                   tpRecentAddress.setText(student.getRecentAddress());
                   tpRealAddress.setText(student.getRealAddress());
                   tfHomePhone.setText(student.getHomePhone());
                   tfMobilePhone.setText(student.getMobilePhone());
                   tfEmail.setText(student.getEmail());
                   
                   // page 3
                   tfOldInstitute.setText(student.getOldInstitute());
                   tfOldYearOut.setText(student.getOldYearOut());
                   tfOldGpa.setText(student.getOldGpa());
                   tfOldDegree.setText(student.getOldDegree());
                   tfOldSDegree.setText(student.getOldSDegree());
                   tfOldFaculty.setText(student.getOldFaculty());
                   tfOldMajor.setText(student.getOldMajor());
                   
                   // page 4
                   tfFather.setText(student.getFather());
                   tfFatherWork.setText(student.getFatherWork());
                   tfMother.setText(student.getMother());
                   tfMotherWork.setText(student.getMotherWork());
                   tfContactor.setText(student.getContactor());
                   tfContactorWork.setText(student.getContactorWork());
                   tfContactorReletion.setText(student.getContactorReletionship());
                   tfContactorPhone.setText(student.getContactorPhone());
                   tpContactorAddress.setText(student.getContactorAddress());
                   
                   // page 5
                   
                   cbConsultant.removeAllItems();
                   cbConsultant.addItem(null);
                   
                   Student s = (Student)nodeInfo;
                   
                   HandleLecturer hLecturer = new HandleLecturer();
                   Vector vector = hLecturer.retrieveAllLecturer();
                   Enumeration enum = vector.elements();
                   int i = 1;
                       
                   while(enum.hasMoreElements())
                   {
                       Lecturer l = (Lecturer)enum.nextElement();
                       cbConsultant.addItem(l);                           
                           
                       if(l.getId().equals(s.getConsultantId()))
                       {
                           cbConsultant.setSelectedIndex(i);
                       }   
                       
                       i++;
                   }                       
                   
                   tfSemesterIn.setText(student.getInSemester());
                   tfYearIn.setText(student.getInYear());
                   tfPassword.setText(student.getPassword());
                   tfLocation.setText(student.getLocation());
                   
                   if(!student.getType().equals(""))
                   {
                       switch(student.getType().charAt(0))
                       {
                           case 'C':
                               cbStuType.setSelectedIndex(1);
                               break;
                           case 'S':                           
                               cbStuType.setSelectedIndex(2);                       
                               break;
                           default:
                       }
                   }
                   else
                   {
                       cbStuType.setSelectedIndex(0);                                             
                   }
                   
                   if(student.getInDate() != null)
                   {
                       SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                       String date = format.format(student.getInDate());
                   
                       StringTokenizer st = new StringTokenizer(date,"/");
                       date = st.nextToken();
                       cbInDate.setSelectedIndex(Integer.parseInt(date));
                       date = st.nextToken();
                       cbInMonth.setSelectedIndex(Integer.parseInt(date));                    
                       date = st.nextToken();	               
                       tfInYear.setText(date);
                   }
                   else
                   {
                       cbInDate.setSelectedIndex(0);
                       cbInMonth.setSelectedIndex(0);
                       tfInYear.setText("");
                   } 
                   
                   if(student.getOutDate() != null)
                   {
                       SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                       String date = format.format(student.getOutDate());
                   
                       StringTokenizer st = new StringTokenizer(date,"/");
                       date = st.nextToken();
                       cbOutDate.setSelectedIndex(Integer.parseInt(date));
                       date = st.nextToken();
                       cbOutMonth.setSelectedIndex(Integer.parseInt(date));                    
                       date = st.nextToken();	               
                       tfOutYear.setText(date);
                   }
                   else
                   {
                       cbOutDate.setSelectedIndex(0);
                       cbOutMonth.setSelectedIndex(0);
                       tfOutYear.setText("");
                   }                   
               }               
            }
        });                
        
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        jSplitPane = new javax.swing.JSplitPane();
        jScrollPane = new javax.swing.JScrollPane();
        mainPanel = new javax.swing.JPanel();
        generalPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lbFaculty = new javax.swing.JLabel();
        lbDept = new javax.swing.JLabel();
        lbMajor = new javax.swing.JLabel();
        studentPanel = new javax.swing.JPanel();
        jTabbedPane = new javax.swing.JTabbedPane();
        privateInfoPanel = new javax.swing.JPanel();
        tfStudentReligion = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tfStudentID = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        tfStudentTname = new javax.swing.JTextField();
        jLabel141 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        tfStudentEpre = new javax.swing.JTextField();
        tfStudentEname = new javax.swing.JTextField();
        tfStudentEfamily = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        cbStudentSex = new javax.swing.JComboBox();
        jLabel17 = new javax.swing.JLabel();
        tfStudentTpre = new javax.swing.JTextField();
        jLabel171 = new javax.swing.JLabel();
        jLabel172 = new javax.swing.JLabel();
        jLabel173 = new javax.swing.JLabel();
        tfStudentTfamily = new javax.swing.JTextField();
        tfStudentOrigin = new javax.swing.JTextField();
        tfStudentCitizen = new javax.swing.JTextField();
        jLabel1711 = new javax.swing.JLabel();
        cbStuBrithDate = new javax.swing.JComboBox();
        cbStuBrithMonth = new javax.swing.JComboBox();
        tfStuBrithYear = new javax.swing.JTextField();
        jLabel1712 = new javax.swing.JLabel();
        jLabel1713 = new javax.swing.JLabel();
        addressInfoPanel = new javax.swing.JPanel();
        jLabel111 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tpRecentAddress = new javax.swing.JTextPane();
        jLabel1111 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tpRealAddress = new javax.swing.JTextPane();
        jLabel1112 = new javax.swing.JLabel();
        jLabel1113 = new javax.swing.JLabel();
        tfHomePhone = new javax.swing.JTextField();
        tfEmail = new javax.swing.JTextField();
        jLabel1114 = new javax.swing.JLabel();
        tfMobilePhone = new javax.swing.JTextField();
        studyInfoPanel = new javax.swing.JPanel();
        tfOldGpa = new javax.swing.JTextField();
        jLabel111311 = new javax.swing.JLabel();
        tfOldMajor = new javax.swing.JTextField();
        jLabel111312 = new javax.swing.JLabel();
        tfOldYearOut = new javax.swing.JTextField();
        jLabel111313 = new javax.swing.JLabel();
        tfOldInstitute = new javax.swing.JTextField();
        jLabel111314 = new javax.swing.JLabel();
        tfOldDegree = new javax.swing.JTextField();
        jLabel111315 = new javax.swing.JLabel();
        tfOldSDegree = new javax.swing.JTextField();
        jLabel111316 = new javax.swing.JLabel();
        tfOldFaculty = new javax.swing.JTextField();
        jLabel111317 = new javax.swing.JLabel();
        familyInfoPanel = new javax.swing.JPanel();
        jLabel1113111 = new javax.swing.JLabel();
        jLabel11131111 = new javax.swing.JLabel();
        tfMother = new javax.swing.JTextField();
        tfContactor = new javax.swing.JTextField();
        jLabel111311111 = new javax.swing.JLabel();
        tfFather = new javax.swing.JTextField();
        tfFatherWork = new javax.swing.JTextField();
        jLabel111311112 = new javax.swing.JLabel();
        jLabel11131112 = new javax.swing.JLabel();
        tfContactorWork = new javax.swing.JTextField();
        jLabel111311113 = new javax.swing.JLabel();
        tfMotherWork = new javax.swing.JTextField();
        jLabel111311114 = new javax.swing.JLabel();
        tfContactorPhone = new javax.swing.JTextField();
        jLabel111311115 = new javax.swing.JLabel();
        tfContactorReletion = new javax.swing.JTextField();
        jLabel111311116 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tpContactorAddress = new javax.swing.JTextPane();
        indatePanel = new javax.swing.JPanel();
        cbOutMonth = new javax.swing.JComboBox();
        tfInYear = new javax.swing.JTextField();
        cbInMonth = new javax.swing.JComboBox();
        cbInDate = new javax.swing.JComboBox();
        jLabel17121 = new javax.swing.JLabel();
        jLabel17122 = new javax.swing.JLabel();
        tfOutYear = new javax.swing.JTextField();
        jLabel17123 = new javax.swing.JLabel();
        jLabel171231 = new javax.swing.JLabel();
        tfSemesterIn = new javax.swing.JTextField();
        cbOutDate = new javax.swing.JComboBox();
        jLabel171211 = new javax.swing.JLabel();
        jLabel171212 = new javax.swing.JLabel();
        jLabel1712121 = new javax.swing.JLabel();
        jLabel1712122 = new javax.swing.JLabel();
        jLabel1712123 = new javax.swing.JLabel();
        jLabel1712124 = new javax.swing.JLabel();
        tfLocation = new javax.swing.JTextField();
        tfPassword = new javax.swing.JTextField();
        tfYearIn = new javax.swing.JTextField();
        jLabel171232 = new javax.swing.JLabel();
        cbStuType = new javax.swing.JComboBox();
        cbConsultant = new javax.swing.JComboBox();
        jLabel1712212 = new javax.swing.JLabel();
        btEditStudent = new javax.swing.JButton();
        btDelStudent = new javax.swing.JButton();
        coursePanel = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        lbText = new javax.swing.JLabel();
        lbCourseName = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        subCoursePanel = new javax.swing.JPanel();
        jLabel181 = new javax.swing.JLabel();
        jLabel211 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        lbText1 = new javax.swing.JLabel();
        lbSubCourseName = new javax.swing.JLabel();
        btAddStudent = new javax.swing.JButton();
        yearPanel = new javax.swing.JPanel();
        jLabel1811 = new javax.swing.JLabel();
        jLabel2111 = new javax.swing.JLabel();
        jLabel511 = new javax.swing.JLabel();
        lbYear = new javax.swing.JLabel();
        addStudentPanel = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        privateInfoPanel1 = new javax.swing.JPanel();
        tfAddStudentReligion = new javax.swing.JTextField();
        jLabel112 = new javax.swing.JLabel();
        tfAddStudentID = new javax.swing.JTextField();
        jLabel121 = new javax.swing.JLabel();
        jLabel131 = new javax.swing.JLabel();
        jLabel142 = new javax.swing.JLabel();
        tfAddStudentTname = new javax.swing.JTextField();
        jLabel1411 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        tfAddStudentEpre = new javax.swing.JTextField();
        tfAddStudentEname = new javax.swing.JTextField();
        tfAddStudentEfamily = new javax.swing.JTextField();
        jLabel161 = new javax.swing.JLabel();
        cbAddStudentSex = new javax.swing.JComboBox();
        jLabel174 = new javax.swing.JLabel();
        tfAddStudentTpre = new javax.swing.JTextField();
        jLabel1714 = new javax.swing.JLabel();
        jLabel1721 = new javax.swing.JLabel();
        jLabel1731 = new javax.swing.JLabel();
        tfAddStudentTfamily = new javax.swing.JTextField();
        tfAddStudentOrigin = new javax.swing.JTextField();
        tfAddStudentCitizen = new javax.swing.JTextField();
        jLabel17111 = new javax.swing.JLabel();
        cbAddStuBrithDate = new javax.swing.JComboBox();
        cbAddStuBrithMonth = new javax.swing.JComboBox();
        tfAddStuBrithYear = new javax.swing.JTextField();
        jLabel17124 = new javax.swing.JLabel();
        jLabel17131 = new javax.swing.JLabel();
        addressInfoPanel1 = new javax.swing.JPanel();
        jLabel1115 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tpAddRecentAddress = new javax.swing.JTextPane();
        jLabel11111 = new javax.swing.JLabel();
        jScrollPane21 = new javax.swing.JScrollPane();
        tpAddRealAddress = new javax.swing.JTextPane();
        jLabel11121 = new javax.swing.JLabel();
        jLabel11131 = new javax.swing.JLabel();
        tfAddHomePhone = new javax.swing.JTextField();
        tfAddEmail = new javax.swing.JTextField();
        jLabel11141 = new javax.swing.JLabel();
        tfAddMobilePhone = new javax.swing.JTextField();
        studyInfoPanel1 = new javax.swing.JPanel();
        tfAddOldGpa = new javax.swing.JTextField();
        jLabel1113112 = new javax.swing.JLabel();
        tfAddOldMajor = new javax.swing.JTextField();
        jLabel1113121 = new javax.swing.JLabel();
        tfAddOldYearOut = new javax.swing.JTextField();
        jLabel1113131 = new javax.swing.JLabel();
        tfAddOldInstitute = new javax.swing.JTextField();
        jLabel1113141 = new javax.swing.JLabel();
        tfAddOldDegree = new javax.swing.JTextField();
        jLabel1113151 = new javax.swing.JLabel();
        tfAddOldSDegree = new javax.swing.JTextField();
        jLabel1113161 = new javax.swing.JLabel();
        tfAddOldFaculty = new javax.swing.JTextField();
        jLabel1113171 = new javax.swing.JLabel();
        familyInfoPanel1 = new javax.swing.JPanel();
        jLabel11131113 = new javax.swing.JLabel();
        jLabel111311117 = new javax.swing.JLabel();
        tfAddMother = new javax.swing.JTextField();
        tfAddContactor = new javax.swing.JTextField();
        jLabel1113111111 = new javax.swing.JLabel();
        tfAddFather = new javax.swing.JTextField();
        tfAddFatherWork = new javax.swing.JTextField();
        jLabel1113111121 = new javax.swing.JLabel();
        jLabel111311121 = new javax.swing.JLabel();
        tfAddContactorWork = new javax.swing.JTextField();
        jLabel1113111131 = new javax.swing.JLabel();
        tfAddMotherWork = new javax.swing.JTextField();
        jLabel1113111141 = new javax.swing.JLabel();
        tfAddContactorPhone = new javax.swing.JTextField();
        jLabel1113111151 = new javax.swing.JLabel();
        tfAddContactorReletion = new javax.swing.JTextField();
        jLabel1113111161 = new javax.swing.JLabel();
        jScrollPane31 = new javax.swing.JScrollPane();
        tpAddContactorAddress = new javax.swing.JTextPane();
        indatePanel1 = new javax.swing.JPanel();
        cbAddOutMonth = new javax.swing.JComboBox();
        tfAddInYear = new javax.swing.JTextField();
        cbAddInMonth = new javax.swing.JComboBox();
        cbAddInDate = new javax.swing.JComboBox();
        jLabel171213 = new javax.swing.JLabel();
        jLabel171221 = new javax.swing.JLabel();
        tfAddOutYear = new javax.swing.JTextField();
        jLabel171234 = new javax.swing.JLabel();
        jLabel1712311 = new javax.swing.JLabel();
        tfAddSemesterIn = new javax.swing.JTextField();
        cbAddOutDate = new javax.swing.JComboBox();
        jLabel1712111 = new javax.swing.JLabel();
        jLabel1712125 = new javax.swing.JLabel();
        jLabel17121211 = new javax.swing.JLabel();
        jLabel17121221 = new javax.swing.JLabel();
        jLabel17121231 = new javax.swing.JLabel();
        jLabel17121241 = new javax.swing.JLabel();
        tfAddLocation = new javax.swing.JTextField();
        tfAddPassword = new javax.swing.JTextField();
        tfAddYearIn = new javax.swing.JTextField();
        cbAddStuType = new javax.swing.JComboBox();
        jLabel1712321 = new javax.swing.JLabel();
        jLabel1712211 = new javax.swing.JLabel();
        cbAddConsultant = new javax.swing.JComboBox();
        btAddStudentOk = new javax.swing.JButton();
        btAddStudentCancel = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();

        setTitle("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32 - \u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jSplitPane.setLeftComponent(jScrollPane);

        mainPanel.setLayout(new java.awt.CardLayout());

        generalPanel.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel1.setForeground(java.awt.Color.blue);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        generalPanel.add(jLabel1);
        jLabel1.setBounds(150, 50, 300, 30);

        jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel2.setForeground(java.awt.Color.blue);
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35\u0e1e\u0e23\u0e30\u0e08\u0e2d\u0e21\u0e40\u0e01\u0e25\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e04\u0e38\u0e13\u0e17\u0e2b\u0e32\u0e23\u0e25\u0e32\u0e14\u0e01\u0e23\u0e30\u0e1a\u0e31\u0e07");
        generalPanel.add(jLabel2);
        jLabel2.setBounds(100, 90, 390, 21);

        jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel3.setForeground(java.awt.Color.red);
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        generalPanel.add(jLabel3);
        jLabel3.setBounds(220, 140, 150, 30);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        generalPanel.add(jLabel4);
        jLabel4.setBounds(230, 190, 130, 110);

        lbFaculty.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        lbFaculty.setForeground(java.awt.Color.red);
        lbFaculty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbFaculty.setText("FACULTY");
        generalPanel.add(lbFaculty);
        lbFaculty.setBounds(170, 330, 260, 26);

        lbDept.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        lbDept.setForeground(java.awt.Color.red);
        lbDept.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbDept.setText("DEPARTMENT");
        generalPanel.add(lbDept);
        lbDept.setBounds(170, 370, 260, 26);

        lbMajor.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        lbMajor.setForeground(java.awt.Color.red);
        lbMajor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbMajor.setText("MAJOR");
        generalPanel.add(lbMajor);
        lbMajor.setBounds(170, 410, 260, 26);

        mainPanel.add(generalPanel, "generalInfo");

        studentPanel.setLayout(null);

        jTabbedPane.setForeground(java.awt.Color.darkGray);
        jTabbedPane.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.setLayout(null);

        privateInfoPanel.setForeground(java.awt.Color.darkGray);
        tfStudentReligion.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentReligion);
        tfStudentReligion.setBounds(170, 360, 100, 23);

        jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11.setForeground(java.awt.Color.darkGray);
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        privateInfoPanel.add(jLabel11);
        jLabel11.setBounds(10, 30, 140, 23);

        tfStudentID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfStudentID.setDisabledTextColor(java.awt.Color.black);
        tfStudentID.setEnabled(false);
        privateInfoPanel.add(tfStudentID);
        tfStudentID.setBounds(170, 30, 140, 23);

        jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12.setForeground(java.awt.Color.darkGray);
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("\u0e04\u0e33\u0e19\u0e33\u0e2b\u0e19\u0e49\u0e32\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        privateInfoPanel.add(jLabel12);
        jLabel12.setBounds(10, 60, 140, 23);

        jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel13.setForeground(java.awt.Color.darkGray);
        jLabel13.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13.setText("\u0e04\u0e33\u0e19\u0e33\u0e2b\u0e19\u0e49\u0e32\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        privateInfoPanel.add(jLabel13);
        jLabel13.setBounds(10, 150, 140, 23);

        jLabel14.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel14.setForeground(java.awt.Color.darkGray);
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14.setText("\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        privateInfoPanel.add(jLabel14);
        jLabel14.setBounds(10, 180, 140, 23);

        tfStudentTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentTname);
        tfStudentTname.setBounds(170, 180, 200, 23);

        jLabel141.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel141.setForeground(java.awt.Color.darkGray);
        jLabel141.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel141.setText("\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        privateInfoPanel.add(jLabel141);
        jLabel141.setBounds(10, 90, 140, 23);

        jLabel15.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel15.setForeground(java.awt.Color.darkGray);
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel15.setText("\u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 (\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        privateInfoPanel.add(jLabel15);
        jLabel15.setBounds(10, 120, 140, 23);

        tfStudentEpre.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentEpre);
        tfStudentEpre.setBounds(170, 60, 80, 23);

        tfStudentEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentEname);
        tfStudentEname.setBounds(170, 90, 200, 23);

        tfStudentEfamily.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentEfamily);
        tfStudentEfamily.setBounds(170, 120, 200, 23);

        jLabel16.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel16.setForeground(java.awt.Color.darkGray);
        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16.setText("\u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 (\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        privateInfoPanel.add(jLabel16);
        jLabel16.setBounds(10, 210, 140, 23);

        cbStudentSex.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(cbStudentSex);
        cbStudentSex.setBounds(170, 240, 90, 23);

        jLabel17.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17.setForeground(java.awt.Color.darkGray);
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17.setText("\u0e28\u0e32\u0e2a\u0e19\u0e32");
        privateInfoPanel.add(jLabel17);
        jLabel17.setBounds(10, 360, 140, 23);

        tfStudentTpre.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentTpre);
        tfStudentTpre.setBounds(170, 150, 80, 23);

        jLabel171.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171.setForeground(java.awt.Color.darkGray);
        jLabel171.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171.setText("\u0e1e.\u0e28.");
        privateInfoPanel.add(jLabel171);
        jLabel171.setBounds(440, 270, 30, 23);

        jLabel172.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel172.setForeground(java.awt.Color.darkGray);
        jLabel172.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel172.setText("\u0e40\u0e0a\u0e37\u0e49\u0e2d\u0e0a\u0e32\u0e15\u0e34");
        privateInfoPanel.add(jLabel172);
        jLabel172.setBounds(10, 300, 140, 23);

        jLabel173.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel173.setForeground(java.awt.Color.darkGray);
        jLabel173.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel173.setText("\u0e2a\u0e31\u0e0d\u0e0a\u0e32\u0e15\u0e34");
        privateInfoPanel.add(jLabel173);
        jLabel173.setBounds(10, 330, 140, 23);

        tfStudentTfamily.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentTfamily);
        tfStudentTfamily.setBounds(170, 210, 200, 23);

        tfStudentOrigin.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentOrigin);
        tfStudentOrigin.setBounds(170, 300, 100, 23);

        tfStudentCitizen.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStudentCitizen);
        tfStudentCitizen.setBounds(170, 330, 100, 23);

        jLabel1711.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1711.setForeground(java.awt.Color.darkGray);
        jLabel1711.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1711.setText("\u0e40\u0e1e\u0e28");
        privateInfoPanel.add(jLabel1711);
        jLabel1711.setBounds(10, 240, 140, 23);

        cbStuBrithDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(cbStuBrithDate);
        cbStuBrithDate.setBounds(170, 270, 70, 23);

        cbStuBrithMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(cbStuBrithMonth);
        cbStuBrithMonth.setBounds(300, 270, 130, 23);

        tfStuBrithYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel.add(tfStuBrithYear);
        tfStuBrithYear.setBounds(480, 270, 60, 23);

        jLabel1712.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712.setForeground(java.awt.Color.darkGray);
        jLabel1712.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712.setText("\u0e40\u0e01\u0e34\u0e14\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48");
        privateInfoPanel.add(jLabel1712);
        jLabel1712.setBounds(10, 270, 140, 23);

        jLabel1713.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1713.setForeground(java.awt.Color.darkGray);
        jLabel1713.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1713.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        privateInfoPanel.add(jLabel1713);
        jLabel1713.setBounds(250, 270, 30, 23);

        jTabbedPane.addTab("\u0e2a\u0e48\u0e27\u0e19\u0e15\u0e31\u0e27", privateInfoPanel);

        addressInfoPanel.setLayout(null);

        jLabel111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111.setForeground(java.awt.Color.darkGray);
        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111.setText("E - mail");
        addressInfoPanel.add(jLabel111);
        jLabel111.setBounds(40, 270, 90, 23);

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpRecentAddress.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane1.setViewportView(tpRecentAddress);

        addressInfoPanel.add(jScrollPane1);
        jScrollPane1.setBounds(140, 30, 310, 80);

        jLabel1111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1111.setForeground(java.awt.Color.darkGray);
        jLabel1111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1111.setText("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e1b\u0e31\u0e08\u0e08\u0e38\u0e1a\u0e31\u0e19");
        addressInfoPanel.add(jLabel1111);
        jLabel1111.setBounds(10, 30, 120, 23);

        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpRealAddress.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane2.setViewportView(tpRealAddress);

        addressInfoPanel.add(jScrollPane2);
        jScrollPane2.setBounds(140, 120, 310, 80);

        jLabel1112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1112.setForeground(java.awt.Color.darkGray);
        jLabel1112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1112.setText("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e15\u0e32\u0e21\u0e17\u0e30\u0e40\u0e1a\u0e35\u0e22\u0e19\u0e1a\u0e49\u0e32\u0e19");
        addressInfoPanel.add(jLabel1112);
        jLabel1112.setBounds(10, 120, 120, 23);

        jLabel1113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113.setForeground(java.awt.Color.darkGray);
        jLabel1113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113.setText("\u0e42\u0e17\u0e23\u0e28\u0e31\u0e1e\u0e17\u0e4c\u0e1a\u0e49\u0e32\u0e19");
        addressInfoPanel.add(jLabel1113);
        jLabel1113.setBounds(40, 210, 90, 23);

        tfHomePhone.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addressInfoPanel.add(tfHomePhone);
        tfHomePhone.setBounds(140, 210, 150, 23);

        tfEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addressInfoPanel.add(tfEmail);
        tfEmail.setBounds(140, 270, 230, 23);

        jLabel1114.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1114.setForeground(java.awt.Color.darkGray);
        jLabel1114.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1114.setText("\u0e42\u0e17\u0e23\u0e28\u0e31\u0e1e\u0e17\u0e4c\u0e40\u0e04\u0e25\u0e37\u0e48\u0e2d\u0e19\u0e17\u0e35\u0e48");
        addressInfoPanel.add(jLabel1114);
        jLabel1114.setBounds(40, 240, 90, 23);

        tfMobilePhone.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addressInfoPanel.add(tfMobilePhone);
        tfMobilePhone.setBounds(140, 240, 150, 23);

        jTabbedPane.addTab("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48", addressInfoPanel);

        studyInfoPanel.setLayout(null);

        tfOldGpa.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldGpa);
        tfOldGpa.setBounds(190, 90, 90, 23);

        jLabel111311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311.setForeground(java.awt.Color.darkGray);
        jLabel111311.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2a\u0e16\u0e32\u0e19\u0e28\u0e36\u0e01\u0e29\u0e32\u0e40\u0e14\u0e34\u0e21");
        studyInfoPanel.add(jLabel111311);
        jLabel111311.setBounds(20, 30, 150, 23);

        tfOldMajor.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldMajor);
        tfOldMajor.setBounds(190, 210, 310, 23);

        jLabel111312.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111312.setForeground(java.awt.Color.darkGray);
        jLabel111312.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111312.setText("\u0e1b\u0e35\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        studyInfoPanel.add(jLabel111312);
        jLabel111312.setBounds(20, 60, 150, 23);

        tfOldYearOut.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldYearOut);
        tfOldYearOut.setBounds(190, 60, 90, 23);

        jLabel111313.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111313.setForeground(java.awt.Color.darkGray);
        jLabel111313.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111313.setText("\u0e1c\u0e25\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        studyInfoPanel.add(jLabel111313);
        jLabel111313.setBounds(20, 90, 150, 23);

        tfOldInstitute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldInstitute);
        tfOldInstitute.setBounds(190, 30, 310, 23);

        jLabel111314.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111314.setForeground(java.awt.Color.darkGray);
        jLabel111314.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111314.setText("\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e17\u0e35\u0e48\u0e44\u0e14\u0e49\u0e23\u0e31\u0e1a");
        studyInfoPanel.add(jLabel111314);
        jLabel111314.setBounds(20, 120, 150, 23);

        tfOldDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldDegree);
        tfOldDegree.setBounds(190, 120, 310, 23);

        jLabel111315.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111315.setForeground(java.awt.Color.darkGray);
        jLabel111315.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111315.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e22\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32");
        studyInfoPanel.add(jLabel111315);
        jLabel111315.setBounds(20, 150, 150, 23);

        tfOldSDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldSDegree);
        tfOldSDegree.setBounds(190, 150, 150, 23);

        jLabel111316.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111316.setForeground(java.awt.Color.darkGray);
        jLabel111316.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111316.setText("\u0e04\u0e13\u0e30\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e08\u0e32\u0e01\u0e2a\u0e16\u0e32\u0e19\u0e28\u0e36\u0e01\u0e29\u0e32\u0e40\u0e14\u0e34\u0e21");
        studyInfoPanel.add(jLabel111316);
        jLabel111316.setBounds(20, 180, 150, 23);

        tfOldFaculty.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel.add(tfOldFaculty);
        tfOldFaculty.setBounds(190, 180, 310, 23);

        jLabel111317.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111317.setForeground(java.awt.Color.darkGray);
        jLabel111317.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111317.setText("\u0e2a\u0e32\u0e02\u0e32\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e08\u0e32\u0e01\u0e2a\u0e16\u0e32\u0e19\u0e28\u0e36\u0e01\u0e29\u0e32\u0e40\u0e14\u0e34\u0e21");
        studyInfoPanel.add(jLabel111317);
        jLabel111317.setBounds(20, 210, 150, 23);

        jTabbedPane.addTab("\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32", studyInfoPanel);

        familyInfoPanel.setLayout(null);

        jLabel1113111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111.setForeground(java.awt.Color.darkGray);
        jLabel1113111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 \u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel.add(jLabel1113111);
        jLabel1113111.setBounds(20, 150, 130, 23);

        jLabel11131111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11131111.setForeground(java.awt.Color.darkGray);
        jLabel11131111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11131111.setText("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e02\u0e2d\u0e07\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel.add(jLabel11131111);
        jLabel11131111.setBounds(20, 270, 130, 23);

        tfMother.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfMother);
        tfMother.setBounds(170, 90, 290, 23);

        tfContactor.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfContactor);
        tfContactor.setBounds(170, 150, 290, 23);

        jLabel111311111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311111.setForeground(java.awt.Color.darkGray);
        jLabel111311111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311111.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 \u0e1a\u0e34\u0e14\u0e32");
        familyInfoPanel.add(jLabel111311111);
        jLabel111311111.setBounds(20, 30, 130, 23);

        tfFather.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfFather);
        tfFather.setBounds(170, 30, 290, 23);

        tfFatherWork.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfFatherWork);
        tfFatherWork.setBounds(170, 60, 210, 23);

        jLabel111311112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311112.setForeground(java.awt.Color.darkGray);
        jLabel111311112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311112.setText("\u0e2d\u0e32\u0e0a\u0e35\u0e1e\u0e02\u0e2d\u0e07\u0e1a\u0e34\u0e14\u0e32");
        familyInfoPanel.add(jLabel111311112);
        jLabel111311112.setBounds(20, 60, 130, 23);

        jLabel11131112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11131112.setForeground(java.awt.Color.darkGray);
        jLabel11131112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11131112.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 \u0e21\u0e32\u0e23\u0e14\u0e32");
        familyInfoPanel.add(jLabel11131112);
        jLabel11131112.setBounds(20, 90, 130, 23);

        tfContactorWork.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfContactorWork);
        tfContactorWork.setBounds(170, 180, 210, 23);

        jLabel111311113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311113.setForeground(java.awt.Color.darkGray);
        jLabel111311113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311113.setText("\u0e2d\u0e32\u0e0a\u0e35\u0e1e\u0e02\u0e2d\u0e07\u0e21\u0e32\u0e23\u0e14\u0e32");
        familyInfoPanel.add(jLabel111311113);
        jLabel111311113.setBounds(20, 120, 130, 23);

        tfMotherWork.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfMotherWork);
        tfMotherWork.setBounds(170, 120, 210, 23);

        jLabel111311114.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311114.setForeground(java.awt.Color.darkGray);
        jLabel111311114.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311114.setText("\u0e2d\u0e32\u0e0a\u0e35\u0e1e\u0e02\u0e2d\u0e07\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel.add(jLabel111311114);
        jLabel111311114.setBounds(20, 180, 130, 23);

        tfContactorPhone.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfContactorPhone);
        tfContactorPhone.setBounds(170, 240, 160, 23);

        jLabel111311115.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311115.setForeground(java.awt.Color.darkGray);
        jLabel111311115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311115.setText("\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49\u0e40\u0e01\u0e35\u0e48\u0e22\u0e27\u0e02\u0e49\u0e2d\u0e07\u0e40\u0e1b\u0e47\u0e19");
        familyInfoPanel.add(jLabel111311115);
        jLabel111311115.setBounds(20, 210, 130, 23);

        tfContactorReletion.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel.add(tfContactorReletion);
        tfContactorReletion.setBounds(170, 210, 160, 23);

        jLabel111311116.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311116.setForeground(java.awt.Color.darkGray);
        jLabel111311116.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311116.setText("\u0e40\u0e1a\u0e2d\u0e23\u0e4c\u0e42\u0e17\u0e23\u0e28\u0e31\u0e1e\u0e17\u0e4c\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel.add(jLabel111311116);
        jLabel111311116.setBounds(20, 240, 130, 23);

        jScrollPane3.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpContactorAddress.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane3.setViewportView(tpContactorAddress);

        familyInfoPanel.add(jScrollPane3);
        jScrollPane3.setBounds(170, 275, 310, 90);

        jTabbedPane.addTab("\u0e04\u0e23\u0e2d\u0e1a\u0e04\u0e23\u0e31\u0e27", familyInfoPanel);

        indatePanel.setLayout(null);

        cbOutMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(cbOutMonth);
        cbOutMonth.setBounds(290, 60, 130, 23);

        tfInYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(tfInYear);
        tfInYear.setBounds(470, 30, 70, 23);

        cbInMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(cbInMonth);
        cbInMonth.setBounds(290, 30, 130, 23);

        cbInDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(cbInDate);
        cbInDate.setBounds(160, 30, 80, 23);

        jLabel17121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17121.setForeground(java.awt.Color.darkGray);
        jLabel17121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17121.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        indatePanel.add(jLabel17121);
        jLabel17121.setBounds(250, 60, 30, 23);

        jLabel17122.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17122.setForeground(java.awt.Color.darkGray);
        jLabel17122.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17122.setText("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel.add(jLabel17122);
        jLabel17122.setBounds(10, 60, 130, 23);

        tfOutYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(tfOutYear);
        tfOutYear.setBounds(470, 60, 70, 23);

        jLabel17123.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17123.setForeground(java.awt.Color.darkGray);
        jLabel17123.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17123.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e1c\u0e48\u0e32\u0e19\u0e02\u0e2d\u0e07\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel.add(jLabel17123);
        jLabel17123.setBounds(10, 240, 130, 23);

        jLabel171231.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171231.setForeground(java.awt.Color.darkGray);
        jLabel171231.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171231.setText("\u0e28\u0e39\u0e19\u0e22\u0e4c\u0e17\u0e35\u0e48\u0e40\u0e23\u0e35\u0e22\u0e19");
        indatePanel.add(jLabel171231);
        jLabel171231.setBounds(10, 180, 130, 23);

        tfSemesterIn.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfSemesterIn.setDisabledTextColor(java.awt.Color.black);
        tfSemesterIn.setEnabled(false);
        indatePanel.add(tfSemesterIn);
        tfSemesterIn.setBounds(160, 120, 80, 23);

        cbOutDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(cbOutDate);
        cbOutDate.setBounds(160, 60, 80, 23);

        jLabel171211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171211.setForeground(java.awt.Color.darkGray);
        jLabel171211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171211.setText("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e40\u0e02\u0e49\u0e32\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel.add(jLabel171211);
        jLabel171211.setBounds(10, 30, 130, 23);

        jLabel171212.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171212.setForeground(java.awt.Color.darkGray);
        jLabel171212.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171212.setText("\u0e1b\u0e35\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e40\u0e02\u0e49\u0e32");
        indatePanel.add(jLabel171212);
        jLabel171212.setBounds(10, 150, 130, 23);

        jLabel1712121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712121.setForeground(java.awt.Color.darkGray);
        jLabel1712121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712121.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        indatePanel.add(jLabel1712121);
        jLabel1712121.setBounds(250, 30, 30, 23);

        jLabel1712122.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712122.setForeground(java.awt.Color.darkGray);
        jLabel1712122.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712122.setText("\u0e1e.\u0e28.");
        indatePanel.add(jLabel1712122);
        jLabel1712122.setBounds(430, 30, 30, 23);

        jLabel1712123.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712123.setForeground(java.awt.Color.darkGray);
        jLabel1712123.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712123.setText("\u0e1e.\u0e28.");
        indatePanel.add(jLabel1712123);
        jLabel1712123.setBounds(430, 60, 30, 23);

        jLabel1712124.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712124.setForeground(java.awt.Color.darkGray);
        jLabel1712124.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712124.setText("\u0e20\u0e32\u0e04\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e40\u0e02\u0e49\u0e32");
        indatePanel.add(jLabel1712124);
        jLabel1712124.setBounds(10, 120, 130, 23);

        tfLocation.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(tfLocation);
        tfLocation.setBounds(160, 180, 160, 23);

        tfPassword.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(tfPassword);
        tfPassword.setBounds(160, 240, 190, 23);

        tfYearIn.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfYearIn.setDisabledTextColor(java.awt.Color.black);
        tfYearIn.setEnabled(false);
        indatePanel.add(tfYearIn);
        tfYearIn.setBounds(160, 150, 80, 23);

        jLabel171232.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171232.setForeground(java.awt.Color.darkGray);
        jLabel171232.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171232.setText("\u0e1b\u0e23\u0e30\u0e40\u0e20\u0e17\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel.add(jLabel171232);
        jLabel171232.setBounds(10, 210, 130, 23);

        cbStuType.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(cbStuType);
        cbStuType.setBounds(160, 210, 160, 23);

        cbConsultant.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel.add(cbConsultant);
        cbConsultant.setBounds(160, 90, 190, 23);

        jLabel1712212.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712212.setForeground(java.awt.Color.darkGray);
        jLabel1712212.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712212.setText("\u0e2d\u0e32\u0e08\u0e32\u0e23\u0e22\u0e4c\u0e17\u0e35\u0e48\u0e1b\u0e23\u0e36\u0e01\u0e29\u0e32");
        indatePanel.add(jLabel1712212);
        jLabel1712212.setBounds(10, 90, 130, 23);

        jTabbedPane.addTab("\u0e40\u0e02\u0e49\u0e32\u0e28\u0e36\u0e01\u0e29\u0e32", indatePanel);

        studentPanel.add(jTabbedPane);
        jTabbedPane.setBounds(10, 10, 590, 480);

        btEditStudent.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btEditStudent.setForeground(java.awt.Color.darkGray);
        btEditStudent.setText("\u0e41\u0e01\u0e49\u0e44\u0e02\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        btEditStudent.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btEditStudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditStudentActionPerformed(evt);
            }
        });

        studentPanel.add(btEditStudent);
        btEditStudent.setBounds(160, 510, 140, 24);

        btDelStudent.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelStudent.setForeground(java.awt.Color.darkGray);
        btDelStudent.setText("\u0e25\u0e1a\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        btDelStudent.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelStudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelStudentActionPerformed(evt);
            }
        });

        studentPanel.add(btDelStudent);
        btDelStudent.setBounds(330, 510, 140, 24);

        mainPanel.add(studentPanel, "studentInfo");

        coursePanel.setLayout(null);

        jLabel18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel18.setForeground(java.awt.Color.blue);
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        coursePanel.add(jLabel18);
        jLabel18.setBounds(150, 50, 300, 30);

        jLabel21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel21.setForeground(java.awt.Color.blue);
        jLabel21.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel21.setText("\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35\u0e1e\u0e23\u0e30\u0e08\u0e2d\u0e21\u0e40\u0e01\u0e25\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e04\u0e38\u0e13\u0e17\u0e2b\u0e32\u0e23\u0e25\u0e32\u0e14\u0e01\u0e23\u0e30\u0e1a\u0e31\u0e07");
        coursePanel.add(jLabel21);
        jLabel21.setBounds(100, 90, 390, 21);

        lbText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbText.setForeground(java.awt.Color.red);
        lbText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbText.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        coursePanel.add(lbText);
        lbText.setBounds(220, 270, 150, 30);

        lbCourseName.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbCourseName.setForeground(java.awt.Color.red);
        lbCourseName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbCourseName.setText("TEXT");
        coursePanel.add(lbCourseName);
        lbCourseName.setBounds(30, 320, 520, 30);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        coursePanel.add(jLabel5);
        jLabel5.setBounds(210, 140, 170, 120);

        mainPanel.add(coursePanel, "courseInfo");

        subCoursePanel.setLayout(null);

        jLabel181.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel181.setForeground(java.awt.Color.blue);
        jLabel181.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel181.setText("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        subCoursePanel.add(jLabel181);
        jLabel181.setBounds(150, 50, 300, 30);

        jLabel211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel211.setForeground(java.awt.Color.blue);
        jLabel211.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel211.setText("\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35\u0e1e\u0e23\u0e30\u0e08\u0e2d\u0e21\u0e40\u0e01\u0e25\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e04\u0e38\u0e13\u0e17\u0e2b\u0e32\u0e23\u0e25\u0e32\u0e14\u0e01\u0e23\u0e30\u0e1a\u0e31\u0e07");
        subCoursePanel.add(jLabel211);
        jLabel211.setBounds(100, 90, 390, 21);

        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel51.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        subCoursePanel.add(jLabel51);
        jLabel51.setBounds(210, 140, 170, 120);

        lbText1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbText1.setForeground(java.awt.Color.red);
        lbText1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbText1.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        subCoursePanel.add(lbText1);
        lbText1.setBounds(220, 270, 150, 30);

        lbSubCourseName.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbSubCourseName.setForeground(java.awt.Color.red);
        lbSubCourseName.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbSubCourseName.setText("TEXT");
        subCoursePanel.add(lbSubCourseName);
        lbSubCourseName.setBounds(40, 320, 520, 30);

        btAddStudent.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddStudent.setForeground(java.awt.Color.darkGray);
        btAddStudent.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e23\u0e32\u0e22\u0e0a\u0e37\u0e48\u0e2d\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        btAddStudent.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddStudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddStudentActionPerformed(evt);
            }
        });

        subCoursePanel.add(btAddStudent);
        btAddStudent.setBounds(220, 430, 160, 24);

        mainPanel.add(subCoursePanel, "subCourseInfo");

        yearPanel.setLayout(null);

        jLabel1811.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel1811.setForeground(java.awt.Color.blue);
        jLabel1811.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1811.setText("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        yearPanel.add(jLabel1811);
        jLabel1811.setBounds(150, 50, 300, 30);

        jLabel2111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel2111.setForeground(java.awt.Color.blue);
        jLabel2111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2111.setText("\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35\u0e1e\u0e23\u0e30\u0e08\u0e2d\u0e21\u0e40\u0e01\u0e25\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e04\u0e38\u0e13\u0e17\u0e2b\u0e32\u0e23\u0e25\u0e32\u0e14\u0e01\u0e23\u0e30\u0e1a\u0e31\u0e07");
        yearPanel.add(jLabel2111);
        jLabel2111.setBounds(100, 90, 390, 21);

        jLabel511.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel511.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        yearPanel.add(jLabel511);
        jLabel511.setBounds(210, 140, 170, 120);

        lbYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbYear.setForeground(java.awt.Color.red);
        lbYear.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbYear.setText("TEXT");
        yearPanel.add(lbYear);
        lbYear.setBounds(30, 280, 520, 30);

        mainPanel.add(yearPanel, "yearInfo");

        addStudentPanel.setLayout(null);

        jTabbedPane1.setForeground(java.awt.Color.darkGray);
        jTabbedPane1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.setLayout(null);

        privateInfoPanel1.setForeground(java.awt.Color.darkGray);
        tfAddStudentReligion.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentReligion);
        tfAddStudentReligion.setBounds(170, 360, 100, 23);

        jLabel112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel112.setForeground(java.awt.Color.blue);
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel112.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        privateInfoPanel1.add(jLabel112);
        jLabel112.setBounds(10, 30, 140, 23);

        tfAddStudentID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentID);
        tfAddStudentID.setBounds(170, 30, 140, 23);

        jLabel121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel121.setForeground(java.awt.Color.darkGray);
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel121.setText("\u0e04\u0e33\u0e19\u0e33\u0e2b\u0e19\u0e49\u0e32\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        privateInfoPanel1.add(jLabel121);
        jLabel121.setBounds(10, 60, 140, 23);

        jLabel131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel131.setForeground(java.awt.Color.darkGray);
        jLabel131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel131.setText("\u0e04\u0e33\u0e19\u0e33\u0e2b\u0e19\u0e49\u0e32\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        privateInfoPanel1.add(jLabel131);
        jLabel131.setBounds(10, 150, 140, 23);

        jLabel142.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel142.setForeground(java.awt.Color.darkGray);
        jLabel142.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel142.setText("\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        privateInfoPanel1.add(jLabel142);
        jLabel142.setBounds(10, 180, 140, 23);

        tfAddStudentTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentTname);
        tfAddStudentTname.setBounds(170, 180, 200, 23);

        jLabel1411.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1411.setForeground(java.awt.Color.darkGray);
        jLabel1411.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1411.setText("\u0e0a\u0e37\u0e48\u0e2d (\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        privateInfoPanel1.add(jLabel1411);
        jLabel1411.setBounds(10, 90, 140, 23);

        jLabel151.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel151.setForeground(java.awt.Color.darkGray);
        jLabel151.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel151.setText("\u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 (\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        privateInfoPanel1.add(jLabel151);
        jLabel151.setBounds(10, 120, 140, 23);

        tfAddStudentEpre.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentEpre);
        tfAddStudentEpre.setBounds(170, 60, 80, 23);

        tfAddStudentEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentEname);
        tfAddStudentEname.setBounds(170, 90, 200, 23);

        tfAddStudentEfamily.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentEfamily);
        tfAddStudentEfamily.setBounds(170, 120, 200, 23);

        jLabel161.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel161.setForeground(java.awt.Color.darkGray);
        jLabel161.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel161.setText("\u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 (\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        privateInfoPanel1.add(jLabel161);
        jLabel161.setBounds(10, 210, 140, 23);

        cbAddStudentSex.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(cbAddStudentSex);
        cbAddStudentSex.setBounds(170, 240, 90, 23);

        jLabel174.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel174.setForeground(java.awt.Color.darkGray);
        jLabel174.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel174.setText("\u0e28\u0e32\u0e2a\u0e19\u0e32");
        privateInfoPanel1.add(jLabel174);
        jLabel174.setBounds(10, 360, 140, 23);

        tfAddStudentTpre.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentTpre);
        tfAddStudentTpre.setBounds(170, 150, 80, 23);

        jLabel1714.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1714.setForeground(java.awt.Color.darkGray);
        jLabel1714.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1714.setText("\u0e1e.\u0e28.");
        privateInfoPanel1.add(jLabel1714);
        jLabel1714.setBounds(440, 270, 30, 23);

        jLabel1721.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1721.setForeground(java.awt.Color.darkGray);
        jLabel1721.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1721.setText("\u0e40\u0e0a\u0e37\u0e49\u0e2d\u0e0a\u0e32\u0e15\u0e34");
        privateInfoPanel1.add(jLabel1721);
        jLabel1721.setBounds(10, 300, 140, 23);

        jLabel1731.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1731.setForeground(java.awt.Color.darkGray);
        jLabel1731.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1731.setText("\u0e2a\u0e31\u0e0d\u0e0a\u0e32\u0e15\u0e34");
        privateInfoPanel1.add(jLabel1731);
        jLabel1731.setBounds(10, 330, 140, 23);

        tfAddStudentTfamily.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentTfamily);
        tfAddStudentTfamily.setBounds(170, 210, 200, 23);

        tfAddStudentOrigin.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentOrigin);
        tfAddStudentOrigin.setBounds(170, 300, 100, 23);

        tfAddStudentCitizen.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStudentCitizen);
        tfAddStudentCitizen.setBounds(170, 330, 100, 23);

        jLabel17111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17111.setForeground(java.awt.Color.darkGray);
        jLabel17111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17111.setText("\u0e40\u0e1e\u0e28");
        privateInfoPanel1.add(jLabel17111);
        jLabel17111.setBounds(10, 240, 140, 23);

        cbAddStuBrithDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(cbAddStuBrithDate);
        cbAddStuBrithDate.setBounds(170, 270, 70, 23);

        cbAddStuBrithMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(cbAddStuBrithMonth);
        cbAddStuBrithMonth.setBounds(300, 270, 130, 23);

        tfAddStuBrithYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        privateInfoPanel1.add(tfAddStuBrithYear);
        tfAddStuBrithYear.setBounds(480, 270, 60, 23);

        jLabel17124.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17124.setForeground(java.awt.Color.darkGray);
        jLabel17124.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17124.setText("\u0e40\u0e01\u0e34\u0e14\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48");
        privateInfoPanel1.add(jLabel17124);
        jLabel17124.setBounds(10, 270, 140, 23);

        jLabel17131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17131.setForeground(java.awt.Color.darkGray);
        jLabel17131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17131.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        privateInfoPanel1.add(jLabel17131);
        jLabel17131.setBounds(250, 270, 30, 23);

        jTabbedPane1.addTab("\u0e2a\u0e48\u0e27\u0e19\u0e15\u0e31\u0e27", privateInfoPanel1);

        addressInfoPanel1.setLayout(null);

        jLabel1115.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1115.setForeground(java.awt.Color.darkGray);
        jLabel1115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1115.setText("E - mail");
        addressInfoPanel1.add(jLabel1115);
        jLabel1115.setBounds(40, 270, 90, 23);

        jScrollPane11.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpAddRecentAddress.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane11.setViewportView(tpAddRecentAddress);

        addressInfoPanel1.add(jScrollPane11);
        jScrollPane11.setBounds(140, 30, 310, 80);

        jLabel11111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11111.setForeground(java.awt.Color.darkGray);
        jLabel11111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11111.setText("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e1b\u0e31\u0e08\u0e08\u0e38\u0e1a\u0e31\u0e19");
        addressInfoPanel1.add(jLabel11111);
        jLabel11111.setBounds(10, 30, 120, 23);

        jScrollPane21.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpAddRealAddress.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane21.setViewportView(tpAddRealAddress);

        addressInfoPanel1.add(jScrollPane21);
        jScrollPane21.setBounds(140, 120, 310, 80);

        jLabel11121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11121.setForeground(java.awt.Color.darkGray);
        jLabel11121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11121.setText("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e15\u0e32\u0e21\u0e17\u0e30\u0e40\u0e1a\u0e35\u0e22\u0e19\u0e1a\u0e49\u0e32\u0e19");
        addressInfoPanel1.add(jLabel11121);
        jLabel11121.setBounds(10, 120, 120, 23);

        jLabel11131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11131.setForeground(java.awt.Color.darkGray);
        jLabel11131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11131.setText("\u0e42\u0e17\u0e23\u0e28\u0e31\u0e1e\u0e17\u0e4c\u0e1a\u0e49\u0e32\u0e19");
        addressInfoPanel1.add(jLabel11131);
        jLabel11131.setBounds(40, 210, 90, 23);

        tfAddHomePhone.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addressInfoPanel1.add(tfAddHomePhone);
        tfAddHomePhone.setBounds(140, 210, 150, 23);

        tfAddEmail.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addressInfoPanel1.add(tfAddEmail);
        tfAddEmail.setBounds(140, 270, 230, 23);

        jLabel11141.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11141.setForeground(java.awt.Color.darkGray);
        jLabel11141.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11141.setText("\u0e42\u0e17\u0e23\u0e28\u0e31\u0e1e\u0e17\u0e4c\u0e40\u0e04\u0e25\u0e37\u0e48\u0e2d\u0e19\u0e17\u0e35\u0e48");
        addressInfoPanel1.add(jLabel11141);
        jLabel11141.setBounds(40, 240, 90, 23);

        tfAddMobilePhone.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addressInfoPanel1.add(tfAddMobilePhone);
        tfAddMobilePhone.setBounds(140, 240, 150, 23);

        jTabbedPane1.addTab("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48", addressInfoPanel1);

        studyInfoPanel1.setLayout(null);

        tfAddOldGpa.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldGpa);
        tfAddOldGpa.setBounds(190, 90, 90, 23);

        jLabel1113112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113112.setForeground(java.awt.Color.darkGray);
        jLabel1113112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113112.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2a\u0e16\u0e32\u0e19\u0e28\u0e36\u0e01\u0e29\u0e32\u0e40\u0e14\u0e34\u0e21");
        studyInfoPanel1.add(jLabel1113112);
        jLabel1113112.setBounds(20, 30, 150, 23);

        tfAddOldMajor.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldMajor);
        tfAddOldMajor.setBounds(190, 210, 310, 23);

        jLabel1113121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113121.setForeground(java.awt.Color.darkGray);
        jLabel1113121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113121.setText("\u0e1b\u0e35\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        studyInfoPanel1.add(jLabel1113121);
        jLabel1113121.setBounds(20, 60, 150, 23);

        tfAddOldYearOut.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldYearOut);
        tfAddOldYearOut.setBounds(190, 60, 90, 23);

        jLabel1113131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113131.setForeground(java.awt.Color.darkGray);
        jLabel1113131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113131.setText("\u0e1c\u0e25\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        studyInfoPanel1.add(jLabel1113131);
        jLabel1113131.setBounds(20, 90, 150, 23);

        tfAddOldInstitute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldInstitute);
        tfAddOldInstitute.setBounds(190, 30, 310, 23);

        jLabel1113141.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113141.setForeground(java.awt.Color.darkGray);
        jLabel1113141.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113141.setText("\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e17\u0e35\u0e48\u0e44\u0e14\u0e49\u0e23\u0e31\u0e1a");
        studyInfoPanel1.add(jLabel1113141);
        jLabel1113141.setBounds(20, 120, 150, 23);

        tfAddOldDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldDegree);
        tfAddOldDegree.setBounds(190, 120, 310, 23);

        jLabel1113151.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113151.setForeground(java.awt.Color.darkGray);
        jLabel1113151.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113151.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e22\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32");
        studyInfoPanel1.add(jLabel1113151);
        jLabel1113151.setBounds(20, 150, 150, 23);

        tfAddOldSDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldSDegree);
        tfAddOldSDegree.setBounds(190, 150, 150, 23);

        jLabel1113161.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113161.setForeground(java.awt.Color.darkGray);
        jLabel1113161.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113161.setText("\u0e04\u0e13\u0e30\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e08\u0e32\u0e01\u0e2a\u0e16\u0e32\u0e19\u0e28\u0e36\u0e01\u0e29\u0e32\u0e40\u0e14\u0e34\u0e21");
        studyInfoPanel1.add(jLabel1113161);
        jLabel1113161.setBounds(20, 180, 150, 23);

        tfAddOldFaculty.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        studyInfoPanel1.add(tfAddOldFaculty);
        tfAddOldFaculty.setBounds(190, 180, 310, 23);

        jLabel1113171.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113171.setForeground(java.awt.Color.darkGray);
        jLabel1113171.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113171.setText("\u0e2a\u0e32\u0e02\u0e32\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e08\u0e32\u0e01\u0e2a\u0e16\u0e32\u0e19\u0e28\u0e36\u0e01\u0e29\u0e32\u0e40\u0e14\u0e34\u0e21");
        studyInfoPanel1.add(jLabel1113171);
        jLabel1113171.setBounds(20, 210, 150, 23);

        jTabbedPane1.addTab("\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32", studyInfoPanel1);

        familyInfoPanel1.setLayout(null);

        jLabel11131113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11131113.setForeground(java.awt.Color.darkGray);
        jLabel11131113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11131113.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 \u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel1.add(jLabel11131113);
        jLabel11131113.setBounds(20, 150, 130, 23);

        jLabel111311117.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311117.setForeground(java.awt.Color.darkGray);
        jLabel111311117.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311117.setText("\u0e17\u0e35\u0e48\u0e2d\u0e22\u0e39\u0e48\u0e02\u0e2d\u0e07\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel1.add(jLabel111311117);
        jLabel111311117.setBounds(20, 270, 130, 23);

        tfAddMother.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddMother);
        tfAddMother.setBounds(170, 90, 290, 23);

        tfAddContactor.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddContactor);
        tfAddContactor.setBounds(170, 150, 290, 23);

        jLabel1113111111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111111.setForeground(java.awt.Color.darkGray);
        jLabel1113111111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111111.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 \u0e1a\u0e34\u0e14\u0e32");
        familyInfoPanel1.add(jLabel1113111111);
        jLabel1113111111.setBounds(20, 30, 130, 23);

        tfAddFather.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddFather);
        tfAddFather.setBounds(170, 30, 290, 23);

        tfAddFatherWork.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddFatherWork);
        tfAddFatherWork.setBounds(170, 60, 210, 23);

        jLabel1113111121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111121.setForeground(java.awt.Color.darkGray);
        jLabel1113111121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111121.setText("\u0e2d\u0e32\u0e0a\u0e35\u0e1e\u0e02\u0e2d\u0e07\u0e1a\u0e34\u0e14\u0e32");
        familyInfoPanel1.add(jLabel1113111121);
        jLabel1113111121.setBounds(20, 60, 130, 23);

        jLabel111311121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111311121.setForeground(java.awt.Color.darkGray);
        jLabel111311121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111311121.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25 \u0e21\u0e32\u0e23\u0e14\u0e32");
        familyInfoPanel1.add(jLabel111311121);
        jLabel111311121.setBounds(20, 90, 130, 23);

        tfAddContactorWork.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddContactorWork);
        tfAddContactorWork.setBounds(170, 180, 210, 23);

        jLabel1113111131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111131.setForeground(java.awt.Color.darkGray);
        jLabel1113111131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111131.setText("\u0e2d\u0e32\u0e0a\u0e35\u0e1e\u0e02\u0e2d\u0e07\u0e21\u0e32\u0e23\u0e14\u0e32");
        familyInfoPanel1.add(jLabel1113111131);
        jLabel1113111131.setBounds(20, 120, 130, 23);

        tfAddMotherWork.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddMotherWork);
        tfAddMotherWork.setBounds(170, 120, 210, 23);

        jLabel1113111141.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111141.setForeground(java.awt.Color.darkGray);
        jLabel1113111141.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111141.setText("\u0e2d\u0e32\u0e0a\u0e35\u0e1e\u0e02\u0e2d\u0e07\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel1.add(jLabel1113111141);
        jLabel1113111141.setBounds(20, 180, 130, 23);

        tfAddContactorPhone.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddContactorPhone);
        tfAddContactorPhone.setBounds(170, 240, 160, 23);

        jLabel1113111151.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111151.setForeground(java.awt.Color.darkGray);
        jLabel1113111151.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111151.setText("\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49\u0e40\u0e01\u0e35\u0e48\u0e22\u0e27\u0e02\u0e49\u0e2d\u0e07\u0e40\u0e1b\u0e47\u0e19");
        familyInfoPanel1.add(jLabel1113111151);
        jLabel1113111151.setBounds(20, 210, 130, 23);

        tfAddContactorReletion.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        familyInfoPanel1.add(tfAddContactorReletion);
        tfAddContactorReletion.setBounds(170, 210, 160, 23);

        jLabel1113111161.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113111161.setForeground(java.awt.Color.darkGray);
        jLabel1113111161.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113111161.setText("\u0e40\u0e1a\u0e2d\u0e23\u0e4c\u0e42\u0e17\u0e23\u0e28\u0e31\u0e1e\u0e17\u0e4c\u0e1c\u0e39\u0e49\u0e17\u0e35\u0e48\u0e15\u0e34\u0e14\u0e15\u0e48\u0e2d\u0e44\u0e14\u0e49");
        familyInfoPanel1.add(jLabel1113111161);
        jLabel1113111161.setBounds(20, 240, 130, 23);

        jScrollPane31.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpAddContactorAddress.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane31.setViewportView(tpAddContactorAddress);

        familyInfoPanel1.add(jScrollPane31);
        jScrollPane31.setBounds(170, 275, 310, 90);

        jTabbedPane1.addTab("\u0e04\u0e23\u0e2d\u0e1a\u0e04\u0e23\u0e31\u0e27", familyInfoPanel1);

        indatePanel1.setLayout(null);

        cbAddOutMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(cbAddOutMonth);
        cbAddOutMonth.setBounds(290, 60, 130, 23);

        tfAddInYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(tfAddInYear);
        tfAddInYear.setBounds(470, 30, 70, 23);

        cbAddInMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(cbAddInMonth);
        cbAddInMonth.setBounds(290, 30, 130, 23);

        cbAddInDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(cbAddInDate);
        cbAddInDate.setBounds(160, 30, 80, 23);

        jLabel171213.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171213.setForeground(java.awt.Color.darkGray);
        jLabel171213.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171213.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        indatePanel1.add(jLabel171213);
        jLabel171213.setBounds(250, 60, 30, 23);

        jLabel171221.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171221.setForeground(java.awt.Color.darkGray);
        jLabel171221.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171221.setText("\u0e2d\u0e32\u0e08\u0e32\u0e23\u0e22\u0e4c\u0e17\u0e35\u0e48\u0e1b\u0e23\u0e36\u0e01\u0e29\u0e32");
        indatePanel1.add(jLabel171221);
        jLabel171221.setBounds(10, 90, 130, 23);

        tfAddOutYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(tfAddOutYear);
        tfAddOutYear.setBounds(470, 60, 70, 23);

        jLabel171234.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel171234.setForeground(java.awt.Color.blue);
        jLabel171234.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel171234.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e1c\u0e48\u0e32\u0e19\u0e02\u0e2d\u0e07\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel1.add(jLabel171234);
        jLabel171234.setBounds(10, 240, 130, 23);

        jLabel1712311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712311.setForeground(java.awt.Color.darkGray);
        jLabel1712311.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712311.setText("\u0e28\u0e39\u0e19\u0e22\u0e4c\u0e17\u0e35\u0e48\u0e40\u0e23\u0e35\u0e22\u0e19");
        indatePanel1.add(jLabel1712311);
        jLabel1712311.setBounds(10, 180, 130, 23);

        tfAddSemesterIn.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(tfAddSemesterIn);
        tfAddSemesterIn.setBounds(160, 120, 80, 23);

        cbAddOutDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(cbAddOutDate);
        cbAddOutDate.setBounds(160, 60, 80, 23);

        jLabel1712111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712111.setForeground(java.awt.Color.darkGray);
        jLabel1712111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712111.setText("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e40\u0e02\u0e49\u0e32\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel1.add(jLabel1712111);
        jLabel1712111.setBounds(10, 30, 130, 23);

        jLabel1712125.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712125.setForeground(java.awt.Color.blue);
        jLabel1712125.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712125.setText("\u0e1b\u0e35\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e40\u0e02\u0e49\u0e32");
        indatePanel1.add(jLabel1712125);
        jLabel1712125.setBounds(10, 150, 130, 23);

        jLabel17121211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17121211.setForeground(java.awt.Color.darkGray);
        jLabel17121211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17121211.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        indatePanel1.add(jLabel17121211);
        jLabel17121211.setBounds(250, 30, 30, 23);

        jLabel17121221.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17121221.setForeground(java.awt.Color.darkGray);
        jLabel17121221.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17121221.setText("\u0e1e.\u0e28.");
        indatePanel1.add(jLabel17121221);
        jLabel17121221.setBounds(430, 30, 30, 23);

        jLabel17121231.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17121231.setForeground(java.awt.Color.darkGray);
        jLabel17121231.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17121231.setText("\u0e1e.\u0e28.");
        indatePanel1.add(jLabel17121231);
        jLabel17121231.setBounds(430, 60, 30, 23);

        jLabel17121241.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel17121241.setForeground(java.awt.Color.blue);
        jLabel17121241.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel17121241.setText("\u0e20\u0e32\u0e04\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e40\u0e02\u0e49\u0e32");
        indatePanel1.add(jLabel17121241);
        jLabel17121241.setBounds(10, 120, 130, 23);

        tfAddLocation.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(tfAddLocation);
        tfAddLocation.setBounds(160, 180, 160, 23);

        tfAddPassword.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(tfAddPassword);
        tfAddPassword.setBounds(160, 240, 190, 23);

        tfAddYearIn.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(tfAddYearIn);
        tfAddYearIn.setBounds(160, 150, 80, 23);

        cbAddStuType.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(cbAddStuType);
        cbAddStuType.setBounds(160, 210, 160, 23);

        jLabel1712321.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712321.setForeground(java.awt.Color.blue);
        jLabel1712321.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712321.setText("\u0e1b\u0e23\u0e30\u0e40\u0e20\u0e17\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel1.add(jLabel1712321);
        jLabel1712321.setBounds(10, 210, 130, 23);

        jLabel1712211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1712211.setForeground(java.awt.Color.darkGray);
        jLabel1712211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1712211.setText("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e08\u0e1a\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        indatePanel1.add(jLabel1712211);
        jLabel1712211.setBounds(10, 60, 130, 23);

        cbAddConsultant.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        indatePanel1.add(cbAddConsultant);
        cbAddConsultant.setBounds(160, 90, 190, 23);

        jTabbedPane1.addTab("\u0e40\u0e02\u0e49\u0e32\u0e28\u0e36\u0e01\u0e29\u0e32", indatePanel1);

        addStudentPanel.add(jTabbedPane1);
        jTabbedPane1.setBounds(10, 10, 590, 480);

        btAddStudentOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddStudentOk.setForeground(java.awt.Color.darkGray);
        btAddStudentOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddStudentOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddStudentOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddStudentOkActionPerformed(evt);
            }
        });

        addStudentPanel.add(btAddStudentOk);
        btAddStudentOk.setBounds(200, 510, 90, 24);

        btAddStudentCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddStudentCancel.setForeground(java.awt.Color.darkGray);
        btAddStudentCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btAddStudentCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddStudentCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddStudentCancelActionPerformed(evt);
            }
        });

        addStudentPanel.add(btAddStudentCancel);
        btAddStudentCancel.setBounds(320, 510, 90, 24);

        mainPanel.add(addStudentPanel, "addStudent");

        jSplitPane.setRightComponent(mainPanel);

        getContentPane().add(jSplitPane, java.awt.BorderLayout.CENTER);

        jMenu1.setForeground(java.awt.Color.darkGray);
        jMenu1.setText("\u0e40\u0e21\u0e19\u0e39");
        jMenu1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuBar1.add(jMenu1);
        setJMenuBar(jMenuBar1);

        pack();
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setSize(new java.awt.Dimension(834, 607));
        setLocation((screenSize.width-834)/2,(screenSize.height-607)/2);
    }//GEN-END:initComponents

    private void btEditStudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditStudentActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ�����䢢����� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {
            if(!tfStudentID.getText().equals("") && !tfSemesterIn.getText().equals("") && !tfYearIn.getText().equals("") && cbStuType.getSelectedItem() != null && !tfPassword.getText().equals(""))
            { 
                Student s = (Student)tree.getUserObject();
            
                s.setId(tfStudentID.getText());
                s.setEpre(tfStudentEpre.getText());
                s.setEname(tfStudentEname.getText());
                s.setEfamily(tfStudentEfamily.getText());
                s.setTpre(tfStudentTpre.getText());
                s.setTname(tfStudentTname.getText());
                s.setTfamily(tfStudentTfamily.getText());
                s.setOrigin(tfStudentOrigin.getText());
                s.setCitizen(tfStudentCitizen.getText());
                s.setReligion(tfStudentReligion.getText());
                s.setRecentAddress(tpRecentAddress.getText());
                s.setRealAddress(tpRealAddress.getText());
                s.setHomePhone(tfHomePhone.getText());
                s.setMobilePhone(tfMobilePhone.getText());
                s.setEmail(tfEmail.getText());
                s.setOldInstitute(tfOldInstitute.getText());
                s.setOldYearOut(tfOldYearOut.getText());
                s.setOldGpa(tfOldGpa.getText());
                s.setOldDegree(tfOldDegree.getText());
                s.setOldSDegree(tfOldSDegree.getText());
                s.setOldFaculty(tfOldFaculty.getText());
                s.setOldMajor(tfOldMajor.getText());
                s.setFather(tfFather.getText());
                s.setFatherWork(tfFatherWork.getText());
                s.setMother(tfMother.getText());
                s.setMotherWork(tfMotherWork.getText());
                s.setContactor(tfContactor.getText());
                s.setContactorWork(tfContactorWork.getText());
                s.setContactorReletionship(tfContactorReletion.getText());
                s.setContactorPhone(tfContactorPhone.getText());
                s.setContactorAddress(tpContactorAddress.getText());
                s.setInSemester(tfSemesterIn.getText());
                s.setInYear(tfYearIn.getText());
                s.setLocation(tfLocation.getText());
                s.setPassword(tfPassword.getText());
            
                switch(cbStudentSex.getSelectedIndex())
                {
                    case 1:
                        s.setSex("M");
                        break;
                    case 2:
                        s.setSex("F");
                        break;
                    default:
                        s.setSex("");
                }
            
                switch(cbStuType.getSelectedIndex())
                {
                    case 1:
                        s.setType("C");
                        break;
                    case 2:
                        s.setType("S");
                        break;
                    default:
                        s.setType("");
                }
            
                if(cbStuBrithDate.getSelectedIndex() != 0 && cbStuBrithMonth.getSelectedIndex() != 0 && !tfStuBrithYear.getText().equals(""))
                {
                    try
                    {
                        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                        java.util.Date birthDate = null;                
                        birthDate = format.parse(Integer.toString(cbStuBrithDate.getSelectedIndex()) + "/" + Integer.toString(cbStuBrithMonth.getSelectedIndex()) + "/" + tfStuBrithYear.getText().trim());
                        s.setBirthDay(birthDate);
                    }
                    catch(ParseException pex)
                    {
                        JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                        return;
                    }                           
                }
            
                if(cbInDate.getSelectedIndex() != 0 && cbInMonth.getSelectedIndex() != 0 && !tfInYear.getText().equals(""))
                {
                    try
                    {
                        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                        java.util.Date inDate = null;                
                        inDate = format.parse(Integer.toString(cbInDate.getSelectedIndex()) + "/" + Integer.toString(cbInMonth.getSelectedIndex()) + "/" + tfInYear.getText().trim());
                        s.setInDate(inDate);
                    }
                    catch(ParseException pex)
                    {
                        JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                        return;
                    }                           
                }            
            
                if(cbOutDate.getSelectedIndex() != 0 && cbOutMonth.getSelectedIndex() != 0 && !tfOutYear.getText().equals(""))
                {
                    try
                    {
                        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                        java.util.Date outDate = null;                
                        outDate = format.parse(Integer.toString(cbOutDate.getSelectedIndex()) + "/" + Integer.toString(cbOutMonth.getSelectedIndex()) + "/" + tfOutYear.getText().trim());
                        s.setOutDate(outDate);
                    }
                    catch(ParseException pex)
                    {
                        JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                        return;
                    }                           
                }
                
                if(cbConsultant.getSelectedItem() != null)
                {
                    s.setConsultantId(((Lecturer)cbConsultant.getSelectedItem()).getId());            
                }                
            
                HandleStudent hStudent = new HandleStudent();
                if(hStudent.updateStudent(s))
                {
                    tree.setUserObject(s);
                    JOptionPane.showMessageDialog(null, "�����䢢���������������º����", "Message", JOptionPane.ERROR_MESSAGE);                                                
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                            
            }            
        }
    }//GEN-LAST:event_btEditStudentActionPerformed

    private void btDelStudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelStudentActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {    
            HandleStudent hStudent = new HandleStudent();                
            hStudent.deleteStudent((Student)tree.getUserObject());
            tree.removeCurrentNode();            
        }        
    }//GEN-LAST:event_btDelStudentActionPerformed

    private void btAddStudentOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddStudentOkActionPerformed
        // Add your handling code here:
        if(!tfAddStudentID.getText().equals("") && !tfAddSemesterIn.getText().equals("") && !tfAddYearIn.getText().equals("") && cbAddStuType.getSelectedItem() != null && !tfAddPassword.getText().equals(""))
        { 
            Student s = new Student();
            
            s.setId(tfAddStudentID.getText());
            s.setEpre(tfAddStudentEpre.getText());
            s.setEname(tfAddStudentEname.getText());
            s.setEfamily(tfAddStudentEfamily.getText());
            s.setTpre(tfAddStudentTpre.getText());
            s.setTname(tfAddStudentTname.getText());
            s.setTfamily(tfAddStudentTfamily.getText());
            s.setOrigin(tfAddStudentOrigin.getText());
            s.setCitizen(tfAddStudentCitizen.getText());
            s.setReligion(tfAddStudentReligion.getText());
            s.setRecentAddress(tpAddRecentAddress.getText());
            s.setRealAddress(tpAddRealAddress.getText());
            s.setHomePhone(tfAddHomePhone.getText());
            s.setMobilePhone(tfAddMobilePhone.getText());
            s.setEmail(tfAddEmail.getText());
            s.setOldInstitute(tfAddOldInstitute.getText());
            s.setOldYearOut(tfAddOldYearOut.getText());
            s.setOldGpa(tfAddOldGpa.getText());
            s.setOldDegree(tfAddOldDegree.getText());
            s.setOldSDegree(tfAddOldSDegree.getText());
            s.setOldFaculty(tfAddOldFaculty.getText());
            s.setOldMajor(tfAddOldMajor.getText());
            s.setFather(tfAddFather.getText());
            s.setFatherWork(tfAddFatherWork.getText());
            s.setMother(tfAddMother.getText());
            s.setMotherWork(tfAddMotherWork.getText());
            s.setContactor(tfAddContactor.getText());
            s.setContactorWork(tfAddContactorWork.getText());
            s.setContactorReletionship(tfAddContactorReletion.getText());
            s.setContactorPhone(tfAddContactorPhone.getText());
            s.setContactorAddress(tpAddContactorAddress.getText());
            s.setInSemester(tfAddSemesterIn.getText());
            s.setInYear(tfAddYearIn.getText());
            s.setLocation(tfAddLocation.getText());
            s.setPassword(tfAddPassword.getText());
            
            switch(cbAddStudentSex.getSelectedIndex())
            {
                case 1:
                    s.setSex("M");
                    break;
                case 2:
                    s.setSex("F");
                    break;
                default:
                    s.setSex("");
            }
            
            switch(cbAddStuType.getSelectedIndex())
            {
                case 1:
                    s.setType("C");
                    break;
                case 2:
                    s.setType("S");
                    break;
                default:
                    s.setType("");
            }
            
            if(cbAddStuBrithDate.getSelectedIndex() != 0 && cbAddStuBrithMonth.getSelectedIndex() != 0 && !tfAddStuBrithYear.getText().equals(""))
            {
                try
                {
                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                    java.util.Date birthDate = null;                
                    birthDate = format.parse(Integer.toString(cbAddStuBrithDate.getSelectedIndex()) + "/" + Integer.toString(cbAddStuBrithMonth.getSelectedIndex()) + "/" + tfAddStuBrithYear.getText().trim());
                    s.setBirthDay(birthDate);
                }
                catch(ParseException pex)
                {
                    JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                    return;
                }                           
            }
            
            if(cbAddInDate.getSelectedIndex() != 0 && cbAddInMonth.getSelectedIndex() != 0 && !tfAddInYear.getText().equals(""))
            {
                try
                {
                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                    java.util.Date inDate = null;                
                    inDate = format.parse(Integer.toString(cbAddInDate.getSelectedIndex()) + "/" + Integer.toString(cbAddInMonth.getSelectedIndex()) + "/" + tfAddInYear.getText().trim());
                    s.setInDate(inDate);
                }
                catch(ParseException pex)
                {
                    JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                    return;
                }                           
            }            
            
            if(cbAddOutDate.getSelectedIndex() != 0 && cbAddOutMonth.getSelectedIndex() != 0 && !tfAddOutYear.getText().equals(""))
            {
                try
                {
                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                    java.util.Date outDate = null;                
                    outDate = format.parse(Integer.toString(cbAddOutDate.getSelectedIndex()) + "/" + Integer.toString(cbAddOutMonth.getSelectedIndex()) + "/" + tfAddOutYear.getText().trim());
                    s.setOutDate(outDate);
                }
                catch(ParseException pex)
                {
                    JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                    return;
                }                           
            }
            
            if(cbAddConsultant.getSelectedItem() != null)
            {
                s.setConsultantId(((Lecturer)cbAddConsultant.getSelectedItem()).getId());            
            }
            
            HandleStudent hStudent = new HandleStudent();
            if(hStudent.addStudent(s, (SubCourse)tree.getUserObject(), (Course)tree.getUserObject(1), minor, major, department, faculty))
            {
                cardManager.show(mainPanel, "subCourseInfo");
                
                if(tree.isNodeChild(s.getInSemester() + "/" + s.getInYear()))
                {
                    tree.addObject(tree.getChildNode(s.getInSemester() + "/" + s.getInYear()), s);
                }
                else
                {
                    tree.addObject(tree.addObject(s.getInSemester() + "/" + s.getInYear()), s);                                         
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "�����ʹѡ�֡�Ҵѧ�����㹰ҹ����������", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                            
            }            
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                            
        }
    }//GEN-LAST:event_btAddStudentOkActionPerformed

    private void btAddStudentCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddStudentCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "subCourseInfo");
    }//GEN-LAST:event_btAddStudentCancelActionPerformed

    private void btAddStudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddStudentActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "addStudent");
        cbAddConsultant.removeAllItems();
        cbAddConsultant.addItem(null);
        
        HandleLecturer hLecturer = new HandleLecturer();        
        Vector v = hLecturer.retrieveAllLecturer();
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            cbAddConsultant.addItem((Lecturer)e.nextElement());
        }        
    }//GEN-LAST:event_btAddStudentActionPerformed
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        parent.setEnabled(true);
        this.dispose();
    }//GEN-LAST:event_exitForm
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) 
    {
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField tfAddStudentID;
    private javax.swing.JLabel jLabel511;
    private javax.swing.JLabel lbText;
    private javax.swing.JLabel jLabel17111;
    private javax.swing.JLabel jLabel111311;
    private javax.swing.JTextField tfYearIn;
    private javax.swing.JLabel jLabel174;
    private javax.swing.JComboBox cbOutMonth;
    private javax.swing.JTextField tfAddStudentReligion;
    private javax.swing.JTextField tfAddInYear;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JTextField tfAddEmail;
    private javax.swing.JLabel jLabel141;
    private javax.swing.JTextField tfAddOldGpa;
    private javax.swing.JTextField tfAddContactorWork;
    private javax.swing.JLabel lbCourseName;
    private javax.swing.JComboBox cbAddOutDate;
    private javax.swing.JPanel indatePanel1;
    private javax.swing.JTextField tfContactorWork;
    private javax.swing.JTextField tfContactorPhone;
    private javax.swing.JPanel familyInfoPanel;
    private javax.swing.JLabel jLabel1113111111;
    private javax.swing.JLabel jLabel173;
    private javax.swing.JTextField tfAddPassword;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JTextField tfFather;
    private javax.swing.JTextField tfStudentTpre;
    private javax.swing.JLabel jLabel17121;
    private javax.swing.JTextField tfOldYearOut;
    private javax.swing.JTextField tfAddStudentEfamily;
    private javax.swing.JTextPane tpRealAddress;
    private javax.swing.JLabel jLabel142;
    private javax.swing.JTextField tfContactor;
    private javax.swing.JTextField tfAddMotherWork;
    private javax.swing.JButton btAddStudentCancel;
    private javax.swing.JLabel jLabel1712321;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JPanel generalPanel;
    private javax.swing.JTextField tfAddFather;
    private javax.swing.JTextPane tpRecentAddress;
    private javax.swing.JLabel jLabel11111;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JTextPane tpAddRealAddress;
    private javax.swing.JTextField tfStudentEname;
    private javax.swing.JLabel jLabel1731;
    private javax.swing.JLabel jLabel1113141;
    private javax.swing.JLabel lbText1;
    private javax.swing.JPanel addressInfoPanel1;
    private javax.swing.JLabel jLabel1714;
    private javax.swing.JLabel jLabel17131;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JTextField tfAddStudentTpre;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JLabel jLabel1113111161;
    private javax.swing.JTextField tfAddFatherWork;
    private javax.swing.JLabel jLabel111311111;
    private javax.swing.JPanel familyInfoPanel1;
    private javax.swing.JLabel jLabel17121211;
    private javax.swing.JTextField tfAddOutYear;
    private javax.swing.JTextField tfAddHomePhone;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JTextField tfAddContactor;
    private javax.swing.JLabel jLabel1113111;
    private javax.swing.JLabel jLabel131;
    private javax.swing.JTextPane tpAddRecentAddress;
    private javax.swing.JLabel jLabel111312;
    private javax.swing.JTextField tfAddLocation;
    private javax.swing.JTextField tfAddStudentEpre;
    private javax.swing.JLabel jLabel1113161;
    private javax.swing.JComboBox cbStuBrithMonth;
    private javax.swing.JPanel yearPanel;
    private javax.swing.JComboBox cbStuType;
    private javax.swing.JTextField tfMotherWork;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JComboBox cbStudentSex;
    private javax.swing.JTextField tfAddStudentCitizen;
    private javax.swing.JTextField tfOutYear;
    private javax.swing.JComboBox cbAddConsultant;
    private javax.swing.JTextField tfOldDegree;
    private javax.swing.JTextField tfStudentTfamily;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JTextField tfAddStudentTname;
    private javax.swing.JComboBox cbAddInDate;
    private javax.swing.JLabel jLabel111311114;
    private javax.swing.JLabel jLabel111311113;
    private javax.swing.JTextField tfMobilePhone;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField tfAddMother;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel indatePanel;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel lbYear;
    private javax.swing.JTextField tfStudentEfamily;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JPanel addStudentPanel;
    private javax.swing.JLabel lbDept;
    private javax.swing.JLabel jLabel171221;
    private javax.swing.JTabbedPane jTabbedPane;
    private javax.swing.JLabel jLabel111311117;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JTextField tfOldGpa;
    private javax.swing.JLabel jLabel11131;
    private javax.swing.JLabel jLabel1113111141;
    private javax.swing.JLabel jLabel1113112;
    private javax.swing.JLabel jLabel111311112;
    private javax.swing.JPanel subCoursePanel;
    private javax.swing.JTextField tfAddOldSDegree;
    private javax.swing.JLabel jLabel111311115;
    private javax.swing.JPanel addressInfoPanel;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JTextPane tpContactorAddress;
    private javax.swing.JComboBox cbStuBrithDate;
    private javax.swing.JComboBox cbOutDate;
    private javax.swing.JLabel jLabel171231;
    private javax.swing.JTextField tfOldFaculty;
    private javax.swing.JTextField tfOldInstitute;
    private javax.swing.JLabel lbFaculty;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JComboBox cbAddInMonth;
    private javax.swing.JScrollPane jScrollPane;
    private javax.swing.JTextField tfStudentID;
    private javax.swing.JLabel jLabel1113111131;
    private javax.swing.JLabel jLabel1112;
    private javax.swing.JLabel jLabel1113151;
    private javax.swing.JLabel jLabel172;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JLabel jLabel171234;
    private javax.swing.JLabel jLabel111317;
    private javax.swing.JLabel jLabel111311116;
    private javax.swing.JPanel privateInfoPanel1;
    private javax.swing.JLabel jLabel171232;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JLabel jLabel111316;
    private javax.swing.JTextField tfLocation;
    private javax.swing.JLabel jLabel1113171;
    private javax.swing.JTextField tfAddContactorReletion;
    private javax.swing.JLabel jLabel1811;
    private javax.swing.JLabel jLabel17121231;
    private javax.swing.JLabel jLabel1113;
    private javax.swing.JSplitPane jSplitPane;
    private javax.swing.JComboBox cbAddOutMonth;
    private javax.swing.JTextField tfStuBrithYear;
    private javax.swing.JTextField tfMother;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JTextField tfAddStudentTfamily;
    private javax.swing.JButton btAddStudent;
    private javax.swing.JTextField tfPassword;
    private javax.swing.JButton btAddStudentOk;
    private javax.swing.JLabel lbMajor;
    private javax.swing.JPanel studentPanel;
    private javax.swing.JLabel jLabel1113121;
    private javax.swing.JTextField tfStudentEpre;
    private javax.swing.JScrollPane jScrollPane31;
    private javax.swing.JLabel jLabel171;
    private javax.swing.JTextField tfAddContactorPhone;
    private javax.swing.JTextField tfAddSemesterIn;
    private javax.swing.JTextField tfAddStuBrithYear;
    private javax.swing.JTextField tfAddOldMajor;
    private javax.swing.JComboBox cbAddStuBrithDate;
    private javax.swing.JTextPane tpAddContactorAddress;
    private javax.swing.JLabel jLabel1712311;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel1712122;
    private javax.swing.JLabel jLabel17123;
    private javax.swing.JTextField tfAddOldInstitute;
    private javax.swing.JLabel jLabel1115;
    private javax.swing.JLabel jLabel11131112;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel17122;
    private javax.swing.JLabel jLabel1114;
    private javax.swing.JTextField tfAddYearIn;
    private javax.swing.JLabel jLabel1721;
    private javax.swing.JTextField tfAddOldYearOut;
    private javax.swing.JLabel jLabel11131113;
    private javax.swing.JLabel jLabel1712;
    private javax.swing.JTextField tfStudentTname;
    private javax.swing.JComboBox cbAddStudentSex;
    private javax.swing.JLabel jLabel1711;
    private javax.swing.JLabel jLabel17124;
    private javax.swing.JTextField tfStudentOrigin;
    private javax.swing.JTextField tfStudentCitizen;
    private javax.swing.JLabel jLabel11131111;
    private javax.swing.JTextField tfOldSDegree;
    private javax.swing.JTextField tfFatherWork;
    private javax.swing.JLabel jLabel11121;
    private javax.swing.JTextField tfAddOldDegree;
    private javax.swing.JLabel jLabel111313;
    private javax.swing.JLabel jLabel1713;
    private javax.swing.JLabel jLabel1113111151;
    private javax.swing.JTextField tfSemesterIn;
    private javax.swing.JTextField tfAddMobilePhone;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JLabel jLabel1113131;
    private javax.swing.JTextField tfHomePhone;
    private javax.swing.JLabel jLabel1712212;
    private javax.swing.JLabel jLabel1712211;
    private javax.swing.JLabel jLabel2111;
    private javax.swing.JLabel jLabel11141;
    private javax.swing.JComboBox cbAddStuBrithMonth;
    private javax.swing.JTextField tfInYear;
    private javax.swing.JPanel studyInfoPanel1;
    private javax.swing.JTextField tfAddStudentOrigin;
    private javax.swing.JComboBox cbInMonth;
    private javax.swing.JTextField tfOldMajor;
    private javax.swing.JPanel studyInfoPanel;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JLabel lbSubCourseName;
    private javax.swing.JLabel jLabel1712121;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel privateInfoPanel;
    private javax.swing.JLabel jLabel171212;
    private javax.swing.JTextField tfAddStudentEname;
    private javax.swing.JComboBox cbInDate;
    private javax.swing.JLabel jLabel1712124;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel jLabel111314;
    private javax.swing.JLabel jLabel111315;
    private javax.swing.JComboBox cbAddStuType;
    private javax.swing.JLabel jLabel171211;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField tfContactorReletion;
    private javax.swing.JLabel jLabel1712111;
    private javax.swing.JLabel jLabel17121241;
    private javax.swing.JTextField tfEmail;
    private javax.swing.JPanel coursePanel;
    private javax.swing.JLabel jLabel1111;
    private javax.swing.JButton btDelStudent;
    private javax.swing.JTextField tfStudentReligion;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JLabel jLabel1411;
    private javax.swing.JLabel jLabel1712123;
    private javax.swing.JLabel jLabel17121221;
    private javax.swing.JLabel jLabel171213;
    private javax.swing.JTextField tfAddOldFaculty;
    private javax.swing.JLabel jLabel111311121;
    private javax.swing.JLabel jLabel1113111121;
    private javax.swing.JComboBox cbConsultant;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel jLabel1712125;
    private javax.swing.JButton btEditStudent;
    // End of variables declaration//GEN-END:variables
}
