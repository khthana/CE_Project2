/*
 * StudentInTermTree.java
 *
 * Created on 21 ��Ȩԡ�¹ 2545, 20:59 �.
 */

package graduate;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class StudentInTermTree 
{
    private DefaultMutableTreeNode subCourseNode;
    private DefaultMutableTreeNode inTermNode;
    private Tree tree;
    
    /** Creates a new instance of StudentInTermTree */
    public StudentInTermTree(Tree tree) 
    {
        this.tree = tree;
    }

    public void retrieveInterm(Course course, SubCourse subcourse)
    {
        HandleStudent hStudent = new HandleStudent();
        Vector v = hStudent.getAllStudentInterm(subcourse);        
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            String s = (String)e.nextElement();
            inTermNode = tree.addObject(subCourseNode, s);            
            
            StudentInfoTree stuTree = new StudentInfoTree(tree);
            stuTree.setNode(inTermNode);
            
            StringTokenizer st = new StringTokenizer(s, "/");
            String term = st.nextToken();
            String year = st.nextToken();
            
            stuTree.retrieveStudentInfo(course, subcourse, term, year);            
        }
    }
    
    public void setNode(DefaultMutableTreeNode subCourseNode)
    {
        this.subCourseNode = subCourseNode;
    }     
}
