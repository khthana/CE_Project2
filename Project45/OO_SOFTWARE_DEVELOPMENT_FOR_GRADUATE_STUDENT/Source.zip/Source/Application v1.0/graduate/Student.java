/*
 * Student.java
 *
 * Created on 24 ��Ȩԡ�¹ 2545, 18:13 �.
 */

package graduate;

/**
 *
 * @author  KUKI
 */
public class Student 
{    
    private String id;
    private String epre;
    private String ename;
    private String efamily;
    private String tpre;
    private String tname;
    private String tfamily;
    private String sex;
    private java.util.Date birthDay;
    private String origin;
    private String citizen;
    private String religion;
    private String recentAddress;
    private String realAddress;
    private String homePhone;
    private String mobilePhone;
    private String email;
    private String oldInstitute;
    private String oldYearOut;
    private String oldGpa;
    private String oldDegree;
    private String oldSDegree;
    private String oldFaculty;
    private String oldMajor;
    private String father;
    private String fatherWork;
    private String mother;
    private String motherWork;
    private String contactor;
    private String contactorWork;
    private String contactorReletionship;
    private String contactorPhone;
    private String contactorAddress;
    private java.util.Date inDate;
    private java.util.Date outDate;
    private String inSemester;
    private String inYear;
    private String location;
    private String password;
    private String type;
    private String consultantId;
    
    /** Creates a new instance of Student */
    public Student()
    {
    }    
    
    public String getId() 
    {
        return this.id;
    }
    
    public String getEpre() 
    {
        return this.epre;
    }
    
    public String getEname() 
    {
        return this.ename;
    }
    
    public String getEfamily() 
    {
        return this.efamily;
    }

    public String getTpre() 
    {
        return this.tpre;
    }
    
    public String getTname() 
    {
        return this.tname;
    }
    
    public String getTfamily() 
    {
        return this.tfamily;
    }
    
    public String getSex()
    {
        return this.sex;
    }
    
    public java.util.Date getBirthDay()
    {
        return this.birthDay;
    }
    
    public String getOrigin()
    {
        return this.origin;
    }
    
    public String getCitizen()
    {
        return this.citizen;
    }
    
    public String getReligion()
    {
        return this.religion;
    }
    
    public String getRecentAddress()
    {
        return this.recentAddress;
    }
    
    public String getRealAddress()
    {
        return this.realAddress;
    }
    
    public String getHomePhone()
    {
        return this.homePhone;
    }
    
    public String getMobilePhone()
    {
        return this.mobilePhone;
    }
    
    public String getEmail()
    {
        return this.email;
    }
    
    public String getOldInstitute()
    {
        return this.oldInstitute;
    }
    
    public String getOldYearOut()
    {
        return this.oldYearOut;
    }
    
    public String getOldGpa()
    {
        return this.oldGpa;
    }
    
    public String getOldDegree()
    {
        return this.oldDegree;
    }
    
    public String getOldSDegree()
    {
        return this.oldSDegree;
    }
    
    public String getOldFaculty()
    {
        return this.oldFaculty;
    }
    
    public String getOldMajor()
    {
        return this.oldMajor;
    }
    
    public String getFather()
    {
        return this.father;
    }
    
    public String getFatherWork()
    {
        return this.fatherWork;
    }
    
    public String getMother()
    {
        return this.mother;
    }
    
    public String getMotherWork()
    {
        return this.motherWork;
    }
    
    public String getContactor()
    {
        return this.contactor;
    }
    
    public String getContactorWork()
    {
        return this.contactorWork;
    }
    
    public String getContactorReletionship()
    {
        return this.contactorReletionship;
    }
    
    public String getContactorPhone()
    {
        return this.contactorPhone;
    }
    
    public String getContactorAddress()
    {
        return this.contactorAddress;
    }
    
    public java.util.Date getInDate()
    {
        return this.inDate;
    }
    
    public java.util.Date getOutDate()
    {
        return this.outDate;
    }
    
    public String getInSemester()
    {
        return this.inSemester;
    }
    
    public String getInYear()
    {
        return this.inYear;
    }
    
    public String getLocation()
    {
        return this.location;
    } 
    
    public String getPassword()
    {
        return this.password;
    }
    
    public String getType()
    {
        return this.type;
    }
    
    public String getConsultantId()
    {
        return this.consultantId;
    }
    
    public void setId(String id) 
    {
        this.id = id;
    }
    
    public void setEpre(String epre) 
    {
        this.epre = epre;
    }
    
    public void setEname(String ename) 
    {
        this.ename = ename;
    }
    
    public void setEfamily(String efamily) 
    {
        this.efamily = efamily;
    }
    
    public void setTpre(String tpre) 
    {
        this.tpre = tpre;
    }
    
    public void setTname(String tname) 
    {
        this.tname = tname;
    }
    
    public void setTfamily(String tfamily)
    {
        this.tfamily = tfamily;
    }
    
    public void setSex(String sex)
    {
        this.sex = sex;
    }
    
    public void setBirthDay(java.util.Date birthDay)
    {
        this.birthDay = birthDay;
    }
    
    public void setOrigin(String origin)
    {
        this.origin = origin;
    }
    
    public void setCitizen(String citizen)
    {
        this.citizen = citizen;
    }
    
    public void setReligion(String religion)
    {
        this.religion = religion;
    }
    
    public void setPassword(String password)
    {
        this.password = password;
    }
    
    public void setRecentAddress(String recentAddress)
    {
        this.recentAddress = recentAddress;
    }
    
    public void setRealAddress(String realAddress)
    {
        this.realAddress = realAddress;
    }
    
    public void setHomePhone(String homePhone)
    {
        this.homePhone = homePhone;
    }
    
    public void setMobilePhone(String mobilePhone)
    {
        this.mobilePhone = mobilePhone;
    }
    
    public void setEmail(String email)
    {
        this.email = email;
    }
    
    public void setOldInstitute(String oldInstitute)
    {
        this.oldInstitute = oldInstitute;
    }
    
    public void setOldYearOut(String oldYearOut)
    {
        this.oldYearOut = oldYearOut;
    }
    
    public void setOldGpa(String oldGpa)
    {
        this.oldGpa = oldGpa;
    }
    
    public void setOldDegree(String oldDegree)
    {
        this.oldDegree = oldDegree;
    }
    
    public void setOldSDegree(String oldSDegree)
    {
        this.oldSDegree = oldSDegree;
    }
    
    public void setOldFaculty(String oldFaculty)
    {
        this.oldFaculty = oldFaculty;
    }
    
    public void setOldMajor(String oldMajor)
    {
        this.oldMajor = oldMajor;
    }
    
    public void setFather(String father)
    {
        this.father = father;
    }
    
    public void setFatherWork(String fatherWork)
    {
        this.fatherWork = fatherWork;
    }
    
    public void setMother(String mother)
    {
        this.mother = mother;
    }
    
    public void setMotherWork(String motherWork)
    {
        this.motherWork = motherWork;
    }
    
    public void setContactor(String contactor)
    {
        this.contactor = contactor;
    }
    
    public void setContactorWork(String contactorWork)
    {
        this.contactorWork = contactorWork;
    }
    
    public void setContactorReletionship(String contactorReletionship)
    {
        this.contactorReletionship = contactorReletionship;
    }
    
    public void setContactorPhone(String contactorPhone)
    {
        this.contactorPhone = contactorPhone;
    }
    
    public void setContactorAddress(String contactorAddress)
    {
        this.contactorAddress = contactorAddress;
    }
    
    public void setInDate(java.util.Date inDate)
    {
        this.inDate = inDate;
    }
    
    public void setOutDate(java.util.Date outDate)
    {
        this.outDate = outDate;
    }
    
    public void setInSemester(String inSemester)
    {
        this.inSemester = inSemester;
    }
    
    public void setInYear(String inYear)
    {
        this.inYear = inYear;
    }
    
    public void setLocation(String location)
    {
        this.location = location;
    }
    
    public void setType(String type)
    {
        this.type = type;
    }
    
    public void setConsultantId(String consultantId)
    {
        this.consultantId = consultantId;
    }
    
    public String toString()
    {
        return id;
    }
}
