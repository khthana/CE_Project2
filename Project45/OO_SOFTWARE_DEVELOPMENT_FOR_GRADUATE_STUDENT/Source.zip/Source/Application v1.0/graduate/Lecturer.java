/*
 * Lecturer.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 12:37 �.
 */

package graduate;

/**
 *
 * @author  KUKI
 */
public class Lecturer
{    
    private String id;
    private String epre;
    private String ename;
    private String efamily;
    private String tpre;
    private String tname;
    private String tfamily;
    private String position;    
    
    /** Creates a new instance of Lecturer */
    public Lecturer() 
    {
    }
    
    public String getId() 
    {
        return this.id;
    }
    
    public String getEpre() 
    {
        return this.epre;
    }
    
    public String getEname() 
    {
        return this.ename;
    }
    
    public String getEfamily() 
    {
        return this.efamily;
    }

    public String getTpre() 
    {
        return this.tpre;
    }
    
    public String getTname() 
    {
        return this.tname;
    }
    
    public String getTfamily() 
    {
        return this.tfamily;
    }
    
    public String getPosition()
    {
        return this.position;
    }
    
    public void setId(String id) 
    {
        this.id = id;
    }
    
    public void setEpre(String epre) 
    {
        this.epre = epre;
    }
    
    public void setEname(String ename) 
    {
        this.ename = ename;
    }
    
    public void setEfamily(String efamily) 
    {
        this.efamily = efamily;
    }
    
    public void setTpre(String tpre) 
    {
        this.tpre = tpre;
    }
    
    public void setTname(String tname) 
    {
        this.tname = tname;
    }
    
    public void setTfamily(String tfamily)
    {
        this.tfamily = tfamily;
    }
    
    public void setPosition(String position)
    {
        this.position = position;
    }
    
    public String toString()
    {
        return this.tpre + " " + this.tname + " " + this.tfamily;
    }    
}
