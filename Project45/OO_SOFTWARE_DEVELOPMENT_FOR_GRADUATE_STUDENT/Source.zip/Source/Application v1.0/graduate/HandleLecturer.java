/*
 * HandleLecturer.java
 *
 * Created on 4 �ѹ�Ҥ� 2545, 22:32 �.
 */

package graduate;

import utility.*;
import java.util.*;
import java.sql.*;
import course.*;

/**
 *                                                     
 * @author  KUKI
 */
public class HandleLecturer 
{    
    /** Creates a new instance of HandleLecturer */
    public HandleLecturer() 
    {
    }
    
    public Vector retrieveLecturer(String lecturerID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM lecturer WHERE lect# = '" + lecturerID + "'";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Lecturer l = new Lecturer();  
                
                l.setId(rs.getString(1));
                l.setEpre(rs.getString(2));
                l.setEname(rs.getString(3));
                l.setEfamily(rs.getString(4));                
                l.setTpre(rs.getString(5));
                l.setTname(rs.getString(6));                
                l.setTfamily(rs.getString(7));
                l.setPosition(rs.getString(8));
                
                v.addElement(l);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public Vector retrieveAllLecturer()
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM lecturer";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Lecturer l = new Lecturer();  
                
                l.setId(rs.getString(1));
                l.setEpre(rs.getString(2));
                l.setEname(rs.getString(3));
                l.setEfamily(rs.getString(4));                
                l.setTpre(rs.getString(5));
                l.setTname(rs.getString(6));                
                l.setTfamily(rs.getString(7));
                l.setPosition(rs.getString(8));
                
                v.addElement(l);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public Vector teach(String sectionID)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT l.lect#, l.epre, l.ename, l.efamily, l.tpre, l.tname, l.tfamily, l.position " +
                           "FROM lecturer l, teach t " +
                           "WHERE l.lect# = t.lect# " +
                           "AND t.sec# = " + sectionID;
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Lecturer l = new Lecturer();  
                
                l.setId(rs.getString(1));
                l.setEpre(rs.getString(2));
                l.setEname(rs.getString(3));
                l.setEfamily(rs.getString(4));                
                l.setTpre(rs.getString(5));
                l.setTname(rs.getString(6));                
                l.setTfamily(rs.getString(7));
                l.setPosition(rs.getString(8));
                
                v.addElement(l);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;        
    }
    
    public boolean addTeach(Section s, Lecturer l)
    {
        String query = "INSERT INTO teach(sec#, lect#) " +
                       "VALUES(" + s.getId() + ", '" + l.getId() + "')";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;            
    }
    
    public boolean updateTeach(Section s, Lecturer l)
    {
        String query = "UPDATE teach " +
                       "SET " +
                       "lect# = '" + l.getId() + "' " +
                       "WHERE sec# = " + s.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                    
    }
}
