/*
 * CourseTree.java
 *
 * Created on 28 ���Ҥ� 2546, 14:31 �.
 */

package graduate;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class StudentCourseTree 
{
    private DefaultMutableTreeNode courseNode;
    private Tree tree;
    
    /** Creates a new instance of CourseTree */
    public StudentCourseTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveCourseInfo(Major major)
    {
        HandleCourse hCourse = new HandleCourse();                
        Vector v = hCourse.retrieveMasterCourse(major);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            MasterCourse mCourse = (MasterCourse)e.nextElement();        
            courseNode = tree.addObject(null, mCourse);
            
            StudentSubCourseTree ssbTree = new StudentSubCourseTree(tree);
            ssbTree.setNode(courseNode);           
            ssbTree.retrieveSubCourseInfo(mCourse);
        }
        
        v = hCourse.retrieveDoctorCourse(major);
        e = v.elements();
        
        while(e.hasMoreElements())
        {
            DoctorCourse dCourse = (DoctorCourse)e.nextElement();
            courseNode = tree.addObject(null, dCourse);
            
            StudentSubCourseTree ssbTree = new StudentSubCourseTree(tree);
            ssbTree.setNode(courseNode);            
            ssbTree.retrieveSubCourseInfo(dCourse);            
        }
    }
    
    public void retrieveCourseInfo(Major major, Minor minor)
    {
        HandleCourse hCourse = new HandleCourse();                
        Vector v = hCourse.retrieveMasterCourse(major, minor);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            MasterCourse mCourse = (MasterCourse)e.nextElement();        
            courseNode = tree.addObject(null, mCourse);
            
            StudentSubCourseTree ssbTree = new StudentSubCourseTree(tree);
            ssbTree.setNode(courseNode);            
            ssbTree.retrieveSubCourseInfo(mCourse);
        }
        
        v = hCourse.retrieveDoctorCourse(major, minor);
        e = v.elements();
        
        while(e.hasMoreElements())
        {
            DoctorCourse dCourse = (DoctorCourse)e.nextElement();
            courseNode = tree.addObject(null, dCourse);
            
            StudentSubCourseTree ssbTree = new StudentSubCourseTree(tree);
            ssbTree.setNode(courseNode);            
            ssbTree.retrieveSubCourseInfo(dCourse);            
        }
    }    
}
