/*
 * Registrar.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 0:54 �.
 */

package graduate;

/**
 *
 * @author  KUKI
 */
public class Registrar 
{
    private String id;
    private String epre;
    private String ename;
    private String efamily;
    private String tpre;
    private String tname;
    private String tfamily;
    private String position;
    private String permission;
    private char[] password;
    
    /** Creates a new instance of Registrar */
    public Registrar() 
    {
    }

    public String getId() 
    {
        return this.id;
    }
    
    public String getEpre() 
    {
        return this.epre;
    }
    
    public String getEname() 
    {
        return this.ename;
    }
    
    public String getEfamily() 
    {
        return this.efamily;
    }

    public String getTpre() 
    {
        return this.tpre;
    }
    
    public String getTname() 
    {
        return this.tname;
    }
    
    public String getTfamily() 
    {
        return this.tfamily;
    }
    
    public String getPosition()
    {
        return this.position;
    }
    
    public String getPermission()
    {
        return this.permission;
    }
    
    public char[] getPassword()
    {
        return this.password;
    }
    
    public void setId(String id) 
    {
        this.id = id;
    }
    
    public void setEpre(String epre) 
    {
        this.epre = epre;
    }
    
    public void setEname(String ename) 
    {
        this.ename = ename;
    }
    
    public void setEfamily(String efamily) 
    {
        this.efamily = efamily;
    }
    
    public void setTpre(String tpre) 
    {
        this.tpre = tpre;
    }
    
    public void setTname(String tname) 
    {
        this.tname = tname;
    }
    
    public void setTfamily(String tfamily)
    {
        this.tfamily = tfamily;
    }
    
    public void setPosition(String position)
    {
        this.position = position;
    }
    
    public void setPermission(String permission)
    {
        this.permission = permission;
    }
    
    public void setPassword(char[] password)
    {
        this.password = password;
    }    
}
