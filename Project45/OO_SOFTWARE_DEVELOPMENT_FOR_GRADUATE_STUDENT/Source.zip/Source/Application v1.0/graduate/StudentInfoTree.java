/*
 * StudentInfoTree.java
 *
 * Created on 21 ��Ȩԡ�¹ 2545, 22:50 �.
 */

package graduate;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class StudentInfoTree 
{
    private DefaultMutableTreeNode studentInfoNode;
    private DefaultMutableTreeNode inTermNode;
    private Tree tree;
    
    /** Creates a new instance of StudentInfoTree */
    public StudentInfoTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveStudentInfo(Course course, SubCourse subcourse, String term, String year)
    {
        HandleStudent hStudent = new HandleStudent();
        Vector v = hStudent.retrieveStudentInfo(course.getId(), subcourse.getId(), term, year);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Student student = (Student)e.nextElement();
            studentInfoNode = tree.addObject(inTermNode, student);                        
        }
    }
    
    public void setNode(DefaultMutableTreeNode inTermNode)
    {
        this.inTermNode = inTermNode;
    }     
}
