/*
 * SubCourseTree.java
 *
 * Created on 19 ��Ȩԡ�¹ 2545, 21:44 �.
 */

package graduate;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class StudentSubCourseTree 
{  
    private DefaultMutableTreeNode subCourseNode;
    private DefaultMutableTreeNode courseNode;
    private Tree tree;
    
    /** Creates a new instance of SubCourseTree */
    public StudentSubCourseTree(Tree tree) 
    {
        this.tree = tree;        
    }
    
    public void retrieveSubCourseInfo(Course course)
    {
        HandleCourse hCourse = new HandleCourse();                
        Vector v = hCourse.retrieveSubCourse(course);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            SubCourse subCourse = (SubCourse)e.nextElement();        
            subCourseNode = tree.addObject(courseNode, subCourse);    
            
            StudentInTermTree stuInTree = new StudentInTermTree(tree);
            stuInTree.setNode(subCourseNode);            
            stuInTree.retrieveInterm(course, subCourse);            
        }
    }
    
    public void setNode(DefaultMutableTreeNode courseNode)
    {
        this.courseNode = courseNode;
    }     
}
