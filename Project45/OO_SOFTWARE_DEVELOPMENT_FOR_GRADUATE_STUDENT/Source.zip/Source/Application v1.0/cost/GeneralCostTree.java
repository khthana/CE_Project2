/*
 * GeneralCostTree.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 17:58 �.
 */

package cost;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class GeneralCostTree 
{
    private DefaultMutableTreeNode costNode;    
    private Tree tree;
    
    /** Creates a new instance of GeneralCostTree */
    public GeneralCostTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveGeneralCostInfo()
    {
        HandleCost hCost = new HandleCost();
        Vector v = hCost.retrieveCost("WHERE type = 'C'");
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Cost c = (Cost)e.nextElement();
            costNode = tree.addObject(null, c);
        }
    }    
}
