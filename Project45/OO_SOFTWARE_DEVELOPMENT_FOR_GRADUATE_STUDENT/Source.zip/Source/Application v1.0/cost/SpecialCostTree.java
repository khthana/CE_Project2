/*
 * SpecialCostTree.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 19:56 �.
 */

package cost;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class SpecialCostTree 
{    
    private DefaultMutableTreeNode costNode;    
    private Tree tree;
    
    /** Creates a new instance of SpecialCostTree */
    public SpecialCostTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveSpecialCostInfo(String subCourseID)
    {
        HandleCost hCost = new HandleCost();
        Vector v = hCost.retrieveCost("WHERE type = 'P' and sco# = " + subCourseID);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Cost c = (Cost)e.nextElement();
            costNode = tree.addObject(null, c);
        }
    }      
}
