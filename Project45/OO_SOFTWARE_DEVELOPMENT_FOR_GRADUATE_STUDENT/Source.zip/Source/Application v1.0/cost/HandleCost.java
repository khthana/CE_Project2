/*
 * HandleCost.java
 *
 * Created on 21 ��Ȩԡ�¹ 2545, 20:47 �.
 */

package cost;

import java.util.*;
import java.sql.*;
import utility.*;
import graduate.*;
import register.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class HandleCost 
{    
    /** Creates a new instance of HandleCost */
    public HandleCost() 
    {
    }
    
    public Vector retrieveCost(String conditions)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * " +
                           "FROM cost " + conditions;
                           
        
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Cost cost = new Cost();
            
                cost.setId(rs.getString(1));
                cost.setName(rs.getString(2));
                cost.setValue(rs.getString(3));
                cost.setSemester(rs.getString(4));
                cost.setYear(rs.getString(5));
                cost.setType(rs.getString(6));
            
                v.addElement(cost);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    } 
        
    public Vector retrieveAllCost()
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM cost";
        
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Cost cost = new Cost();
            
                cost.setId(rs.getString(1));
                cost.setName(rs.getString(2));
                cost.setValue(rs.getString(3));
                cost.setSemester(rs.getString(4));
                cost.setYear(rs.getString(5));
                cost.setType(rs.getString(6));
            
                v.addElement(cost);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public boolean addCost(Cost c, SubCourse sco)
    {
        String query = "";
        
        if(sco == null)
        {
            query = "INSERT INTO cost(name, value, semester, year, type) " +
                    "VALUES('" + c.getName() + "', " + c.getValue() + ", '" + c.getSemester() + "', '" + c.getYear() + "', '" + c.getType() + "')";
        }
        else
        {
            query = "INSERT INTO cost(name, value, semester, year, type, sco#) " +
                    "VALUES('" + c.getName() + "', " + c.getValue() + ", '" + c.getSemester() + "', '" + c.getYear() + "', '" + c.getType() + "', " + sco.getId() + ")";            
        }
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean deleteCost(Cost c)
    {
        String query = "DELETE FROM cost WHERE cost# = " + c.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean updateCost(Cost c)
    {
        String query = "UPDATE cost " +
                       "SET " +
                       "name = '" + c.getName() + "', " +
                       "value = " + c.getValue() + ", " +
                       "semester = '" + c.getSemester() + "', " +
                       "year = '" + c.getYear() + "' " +
                       "WHERE cost# = " + c.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                
    }
}
