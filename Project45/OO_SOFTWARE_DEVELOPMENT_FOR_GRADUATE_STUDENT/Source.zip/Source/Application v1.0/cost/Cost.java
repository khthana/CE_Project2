/*
 * Cost.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 12:40 �.
 */

package cost;

/**
 *
 * @author  KUKI
 */
public class Cost 
{
    private String id;
    private String name;
    private String value;
    private String semester;
    private String year;
    private String type;
    
    /** Creates a new instance of Cost */
    public Cost() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public void setValue(String value)
    {
        this.value = value;
    }
    
    public void setSemester(String semester)
    {
        this.semester = semester;
    }
    
    public void setYear(String year)
    {
        this.year = year;
    }
    
    public void setType(String type)
    {
        this.type = type;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public String getValue()
    {
        return this.value;
    }
    
    public String getSemester()
    {
        return this.semester;
    }
    
    public String getYear()
    {
        return this.year;
    }
    
    public String getType()
    {
        return this.type;
    }
    
    public String toString()
    {
        return this.name;
    }
}
