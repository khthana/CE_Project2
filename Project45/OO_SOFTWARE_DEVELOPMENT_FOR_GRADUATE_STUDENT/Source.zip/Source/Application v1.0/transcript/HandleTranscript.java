/*
 * HandleTranscript.java
 *
 * Created on 22 ��Ȩԡ�¹ 2545, 13:35 �.
 */

package transcript;

import graduate.*;
import course.*;
import utility.*;
import java.util.*;
import java.text.*;
import java.sql.*;
import register.*;

/**
 *
 * @author  KUKI
 */
public class HandleTranscript 
{    
    private HandleStudent hStudent;
    
    /** Creates a new instance of HandleTranscript */
    public HandleTranscript(HandleStudent hStudent) 
    {
        this.hStudent = hStudent;
    }
    
    public int getStudentTotalCredit()
    {
        String query = "SELECT j.credit " +
                       "FROM register r, section t, subject j, grade g " +
                       "WHERE g.grade = r.grade and r.sec# = t.sec# and t.subj# = j.subj# and r.std# = '" + hStudent.getStudent().getId() + "' and r.register_type = 'C' " +
                       "and g.point >= 2.50 and r.section_type = 'C'";
        
        ResultSet rs = DB.getResultSet(query);
        
        int totalCredit = 0;
        
        try
        {
            while(rs.next())
            {
                totalCredit = totalCredit + Integer.parseInt(rs.getString(1));
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return totalCredit;
    }
    
    public Vector retrieveCourseTitle()
    {
        String query = "SELECT j.subj#, j.ename, j.credit, r.grade, r.section_type, r.semester, r.year " +
                       "FROM register r, section t, subject j " +
                       "WHERE r.sec# = t.sec# and t.subj# = j.subj# and r.std# = '" + hStudent.getStudent().getId() + "' and r.register_type = 'C' " +
                       "ORDER BY r.year, r.semester";
        
        Vector v = new Vector();
        
        ResultSet rs = DB.getResultSet(query);
        
        try
        {
            while(rs.next())
            {
                Register r = new Register();            
                
                r.getSubject().setId(rs.getString(1));
                r.getSubject().setEname(rs.getString(2));
                r.getSubject().setCredit(rs.getString(3));
                r.setGrade(rs.getString(4));
                r.setSectionType(rs.getString(5));
                r.setSemester(rs.getString(6));
                r.setYear(rs.getString(7));
                
                v.addElement(r);
            }        
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public String getTranscriptData()
    {
        String course = hStudent.getCourse().getFEDegree();
        StringTokenizer st = new StringTokenizer(course, "()");
        
        java.util.Date birthDate = hStudent.getStudent().getBirthDay();
        java.util.Date dateOfAdmission = hStudent.getStudent().getInDate();
        java.util.Date dateOfGraduation = hStudent.getStudent().getOutDate();
        
        SimpleDateFormat format = new SimpleDateFormat("MMMM dd, yyyy", Locale.US);
        DecimalFormat df = new DecimalFormat("0.00");                                                  
        
	HandleRegister hRegister = new HandleRegister();
	HandleGrade hGrade = new HandleGrade();        
        
        String data = "" +
                      "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">" +
                      "<html>" +
                      "<head>" +
                      "<title>Transcript</title>" +
                      "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-874\">" +
                      "<link href=\"style.css\" rel=\"stylesheet\" type=\"text/css\">" +
                      "</head>" +

                      "<body>" +
                      "<table width=\"100%\" height=\"1250\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">" +
                      "<tr>" +
                      "<td height=\"1250\" align=\"center\" valign=\"top\">" +
                      "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +
                      "<td width=\"88%\" align=\"center\" height=\"152\">" +
                      "<p class=\"xl25\">KING MONGKUT'S INSTITUTE OF TECHNOLOGY LADKRABANG</p>" +
                      "<p class=\"xl25\">BANGKOK THAILAND</p>" +
                      "<p class=\"xl28\">SCHOOL OF GRADUATE STUDIES</p>" +
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +
                      "<td width=\"9%\" height=\"128\">&nbsp;</td>" +
                      "<td width=\"40%\">" +
                      "<font class=\"xl34\">Name : </font>" +
                      "<font class=\"xl36\">" + hStudent.getStudent().getEpre().toUpperCase() + " " + hStudent.getStudent().getEname().toUpperCase() + " " + hStudent.getStudent().getEfamily().toUpperCase() + "</font><br>" +
		      "<font class=\"xl34\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font>" +
                      "<font class=\"xl36\">( " + PrintToFile.convertToUnicode(hStudent.getStudent().getTpre() + hStudent.getStudent().getTname() + " " + hStudent.getStudent().getTfamily()) + " )</font><br>" +
		      "<font class=\"xl34\">Date of Birth : </font>" +
		      "<font class=\"xl36\">" + ((birthDate != null) ? format.format(birthDate) : "&nbsp;") + "</font><br>" +
		      "<font class=\"xl34\">Date of Admission : </font>" +
		      "<font class=\"xl36\">" + ((dateOfAdmission != null) ? format.format(dateOfAdmission) : "&nbsp;") + "</font>" +
                      "</td>" +
                      
                      "<td width=\"51%\">" +
		      "<font class=\"xl34\">Record No. : </font>" +
		      "<font class=\"xl36\">" + hStudent.getStudent().getId() + "</font><br>" +
		      "<font class=\"xl34\">Degree : </font>" +
		      "<font class=\"xl36\">" + st.nextToken() + "</font><br>" +
		      "<font class=\"xl34\">Program : </font>" +
		      "<font class=\"xl36\">" + st.nextToken() + "</font><br>" +
		      "<font class=\"xl34\">Date of Graduation : </font>" +
		      "<font class=\"xl36\">" + ((dateOfGraduation != null) ? format.format(dateOfGraduation) : "&nbsp;") + "</font>" +
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +
                      "<td>" +
                      "<hr width=\"95%\" align=\"center\">" +
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "<table width=\"100%\" height=\"560\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">" +
                      "<tr>" +
                      "<td width=\"4%\" align=\"left\" valign=\"top\">&nbsp;</td>" +
                      "<td width=\"96%\" align=\"left\" valign=\"top\">" +
                      "<!-- Generate by program -->";		  
                      
                      
                      Vector vTerm = hRegister.retrieveAllRegisterSemester(hStudent.getStudent());
                      Enumeration eTerm = vTerm.elements();
                      
                      while(eTerm.hasMoreElements())
                      {
                          Register rTerm = (Register)eTerm.nextElement();
                          
                          // display term
                          data = data +
                          "<table width=\"45%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +                                                                          
                          "<tr>" +
                          "<td colspan=\"6\">" +                          
                          "<font class=\"xl123\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<u>" + ((rTerm.getSemester().equals("1")) ? "1st" : "2nd") + " Semester, " + Integer.toString(Integer.parseInt(rTerm.getYear()) - 543) + "</u></font><br>" +
                          "</td>" +
                          "</tr>";

                          Vector vData = hRegister.retrieveRegisterData(hStudent.getStudent(), rTerm.getSemester(), rTerm.getYear());
                          Enumeration eData = vData.elements();

                          while(eData.hasMoreElements())
			  {
                               Register rData = (Register)eData.nextElement();

			       if(rData.getSectionType().equals("C"))
                               {
                                   // calculate total point
                                   hGrade.calcTotalPoint(rData.getGrade(), Double.parseDouble(rData.getSubject().getCredit()));
                                   hGrade.calcAllTotalPoint(rData.getGrade(), Double.parseDouble(rData.getSubject().getCredit()));
                                   // calculate total credit
                                   hGrade.calcTotalCredit(Double.parseDouble(rData.getSubject().getCredit()));
                                   hGrade.calcAllTotalCredit(Double.parseDouble(rData.getSubject().getCredit()));
			       }
				
                               // display course title
                               data = data +
                               "<tr>" +
                               "<td valign=\"top\" align=\"left\" width=\"80\"><font class=\"xl98\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + rData.getSubject().getId() + " </font></td>" +
                               "<td valign=\"top\" align=\"left\" width=\"230\"><font class=\"xl97\">" + rData.getSubject().getEname().toUpperCase() + "</font></td>" +
                               "<td valign=\"top\" align=\"left\" width=\"10\"><font class=\"xl97\">&nbsp;</font></td>" +
                               "<td valign=\"top\" align=\"left\" width=\"20\"><font class=\"xl97\">" + ((rData.getSectionType().equals("C")) ? "Cr" : "Ad") + "</font></td>" +
                               "<td valign=\"top\" align=\"left\" width=\"15\"><font class=\"xl98\">" + rData.getSubject().getCredit() + "</font></td>" +
                               "<td valign=\"top\" align=\"left\"><font class=\"xl98\">" + rData.getGrade() + "</font></td>" +
                               "</tr>";
			  }
                          
                          // display GPA & GPS                          
                          data = data + 
                          "<tr>" +
                          "<td colspan=\"6\">" +
                          "<font class=\"xl98\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GPS : " + df.format(hGrade.calcGPS()) + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GPA : " + df.format(hGrade.calcGPA()) + "</font><br>" +
                          "</td>" +
                          "</tr>" +
                          "</table>";

                          hGrade.setTotalCredit(0.00f);
                          hGrade.setTotalPoint(0.00f);
        	      }                      
                      
                      data = data +
                      "<table width=\"45%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +                      
                      "<tr>" +
                      "<td colspan=\"2\" height=\"20\">&nbsp;" +                      
                      "</td>" +
                      "</tr>" +
                      "<tr>" +
                      "<td width=\"75\" valign=\"top\" align=\"right\">" +
                      "<font class=\"xl97\">THESIS :&nbsp;</font>" +
                      "</td>" +
                      "<td>" +
                      "<font class=\"xl97\">" + getThesisTitle().toUpperCase() + "</font>" +
                      "</td>" +
                      "</tr>" +
                      "<tr>" +
                      "<td colspan=\"2\" height=\"20\">&nbsp;" +                      
                      "</td>" +
                      "</tr>" +                      
                      "</table>";
                      
                      // total credit
                      int sTotalCredit = getStudentTotalCredit();
                      int cTotalCredit = hStudent.getSubCourse().getTotalCredit();
                      double gpa = Double.parseDouble(df.format(hGrade.calcGPA()));
                      boolean isPassThesis = (getThesisResult().equals("F")) ? false : true;
                      
                      boolean isGraduation = ((isPassThesis && gpa >= 3.00 && (sTotalCredit >= cTotalCredit))) ? true : false;
                      
                      data = data +
                      "<table width=\"45%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +                                                
                      "<tr>" +
                      "<td align=\"center\">" +
                      "<font class=\"xl98\">" + ((isGraduation) ? "GRAND&nbsp;&nbsp;TOTAL&nbsp;&nbsp;CREDITS : " : "TOTAL&nbsp;&nbsp;CREDITS&nbsp;&nbsp;HOURS : ") + Integer.toString(sTotalCredit) + "</font><br>" +
                      "<font class=\"xl98\">GPA : " + df.format(gpa) + "</font><br>" +
                      "<font class=\"xl98\">" + ((isGraduation) ? "TRANSCRIPT&nbsp;&nbsp;CLOSED</font><br>" : "&nbsp;</font>") +
                      "<font class=\"xl98\">-----------------------------------------</font>" +
                      "</td>" +
                      "</tr>" +
                      "</table>";                      
                      
                      data = data +
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +
                      "<td><hr width=\"95%\" align=\"center\"></td>" +
                      "</tr>" +
                      "<tr>" +
                      "<td align=\"left\">" +                      
                      "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +                
                      "<td>" +                                         
                      // Grading System                      
                      "<table align=\"left\" width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +
                      "<td width=\"100\" class=\"xl112\" align=\"center\" valign=\"top\">Grading System</td>" +
                      "<td>" +
                      "<font class=\"xl112\">A</font><br>" +
                      "<font class=\"xl112\">B+</font><br>" +
                      "<font class=\"xl112\">B</font><br>" +
                      "<font class=\"xl112\">C+</font><br>" +
                      "<font class=\"xl112\">C</font>" +                      
                      "</td>" +
                      "<td>" +
                      "<font class=\"xl112\">: Excellent</font><br>" +
                      "<font class=\"xl112\">: Very Good</font><br>" +
                      "<font class=\"xl112\">: Good</font><br>" +
                      "<font class=\"xl112\">: Above Average</font><br>" +
                      "<font class=\"xl112\">: Average</font><br>" +                      
                      "</td>" +
                      "<td>" +
                      "<font class=\"xl114\">4.00</font><br>" +
                      "<font class=\"xl114\">3.50</font><br>" +
                      "<font class=\"xl114\">3.00</font><br>" +
                      "<font class=\"xl114\">2.50</font><br>" +
                      "<font class=\"xl114\">2.00</font>" +                                            
                      "</td>" +
                      "<td>" +
                      "<font class=\"xl112\">D+</font><br>" +
                      "<font class=\"xl112\">D</font><br>" +
                      "<font class=\"xl112\">F</font><br>" +
                      "<font class=\"xl112\">S</font><br>" +
                      "<font class=\"xl112\">U</font>" +                                            
                      "</td>" +
                      "<td>" +
                      "<font class=\"xl112\">: Below Average</font><br>" +
                      "<font class=\"xl112\">: Pass</font><br>" +
                      "<font class=\"xl112\">: Failure</font><br>" +
                      "<font class=\"xl112\">: Satisfactory</font><br>" +
                      "<font class=\"xl112\">: Unsatisfactory</font><br>" +                                            
                      "</td>" +
                      "<td>" +
                      "<font class=\"xl114\">1.50</font><br>" +
                      "<font class=\"xl114\">1.00</font><br>" +
                      "<font class=\"xl114\">0.00</font><br>" +
                      "<font class=\"xl114\">&nbsp;</font><br>" +
                      "<font class=\"xl114\">&nbsp;</font>" +                                                                  
                      "</td>" +
                      "</tr>" +                      
                      "<tr>" +
                      "<td colspan=\"7\">" +
                      "<font class=\"xl112\">&nbsp;&nbsp;&nbsp;&nbsp;GPS = Grade Point Semester&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;GPA = Grade Point Average</font><br>" +
                      "<font class=\"xl112\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Ad = Audit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NC = Non-Credit&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;W = Withdrawn</font>" +                      
                      "</td>" +
                      "</tr>" +                      
                      "<tr>" +
                      "<td colspan=\"7\">" +
                      "<font class=\"xl112\">&nbsp;&nbsp;&nbsp;&nbsp;Grading system for Thesis:</font><br>" +
                      "<font class=\"xl112\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;O : Outstanding&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;G : Good&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;I : Incomplete</font><br>" +
                      "<font class=\"xl112\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;F : Fail&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;P : Pass</font>" +                      
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "</td>" +
                      "<td width=\"50%\" valign=\"top\">" +
                      "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">" +
                      "<tr>" +
                      "<td align=\"center\" colspan=\"2\">" +
                      "<font class=\"xl116\">Certified true copy. Not valid without seal.</font><br><br>" +
                      "<font class=\"xl64\">Date Issued&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</font>" +
                      "<font class=\"xl112\">...................</font><br><br>" +
                      "</td>" +
                      "</tr>" +
                      "<tr>" +
                      "<td align=\"center\" valign=\"bottom\">" +
                      "<font class=\"xl112\">..........................................</font><br>" +
                      "<font class=\"xl122\">Miss Supanee Sompan</font><br><br>" +
                      "<font class=\"font39\">REGISTRAR</font>" +
                      "</td>" +
                      "<td align=\"center\">" +
                      "<font class=\"xl112\">..........................................</font><br>" +
                      "<font class=\"xl122\">Assoc.Prof.Dr.Boonwat Attachoo</font><br><br>" +
                      "<font class=\"font39\">DEAN</font>" +                      
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "</td>" +                      
                      "</tr>" +
                      "</table>" +
                      "</td>" +
                      "</tr>" +
                      "</table>" +
                      "</td>" +
                      "</tr>" +                   
                      "</table>" +
                      "</body>" +
                      "</html>";            
                
        return data;
    }
    
    public String getThesisResult()
    {        
        String result = "";
        
        try
        {
            String query = "SELECT e.result " +
                           "FROM thesis t, examthesis e " +
                           "WHERE t.std# = '" + hStudent.getStudent().getId() + "' and t.thesis# = e.thesis#";
            
            ResultSet rs = DB.getResultSet(query);           
        
            if(rs.next())
            {
                result = rs.getString(1);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return result;
    }
    
    public String getThesisTitle()
    {
        String title = "";
        
        try
        {
            String query = "SELECT thesisTopic_en " +
                           "FROM thesis " +
                           "WHERE std# = '" + hStudent.getStudent().getId() + "'";
            
            ResultSet rs = DB.getResultSet(query);           
        
            if(rs.next())
            {
                title = rs.getString(1);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return title;        
    }
}
