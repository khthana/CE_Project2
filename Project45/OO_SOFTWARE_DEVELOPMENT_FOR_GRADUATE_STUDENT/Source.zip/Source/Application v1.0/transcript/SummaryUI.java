/*
 * SummaryPanel.java
 *
 * Created on 22 ��Ȩԡ�¹ 2545, 20:44 �.
 */

package transcript;

import graduate.*;
import course.*;
import utility.*;
import java.util.*;
import java.text.*;
import java.sql.*;
import register.*;
import transcript.*;
import javax.swing.*;

/**
 *
 * @author  KUKI
 */
public class SummaryUI extends javax.swing.JFrame 
{    
    private HandleStudent hStudent;
    private JTable table;
    
    /** Creates new form SummaryPanel */
    public SummaryUI(HandleStudent hStudent) 
    {
        initComponents();
        
        this.hStudent = hStudent;
        
        tfStudentName.setText(hStudent.getStudent().getTpre() + " " + hStudent.getStudent().getTname() + " " + hStudent.getStudent().getTfamily());
        tfTotalCredit.setText(Integer.toString(hStudent.getSubCourse().getTotalCredit()));
        tfCourseName.setText(hStudent.getCourse().getSTDegree());        
        
        HandleTranscript hTranscript = new HandleTranscript(hStudent);
        Vector v = hTranscript.retrieveCourseTitle();
        Enumeration e = v.elements();
        
        // set total credit
        tfSumCredit.setText(Integer.toString(hTranscript.getStudentTotalCredit()));
        
        Object obj[][] = new Object[v.size()][7];
        
        int i = 0;
        
        while(e.hasMoreElements())
        {
            Register r = (Register)e.nextElement();
                
            // 1 row of table
            obj[i][0] = r.getSubject().getId();
            obj[i][1] = r.getSubject().getEname();
            obj[i][2] = r.getSubject().getCredit();
            obj[i][3] = (r.getGrade().equals("X")) ? "" : r.getGrade();
            obj[i][4] = (r.getSectionType().equals("C")) ? "Credit" : "Audit";
            obj[i][5] = r.getSemester();
            obj[i][6] = r.getYear();
                
            i++;            
        }       
        
        // create table
        table = new JTable();
        String columnHead[] = {"�����Ԫ�", "�����Ԫ�", "˹��¡Ե", "�ô", "������", "�Ҥ����֡��", "�ա���֡��"};
            
        table.setModel(new javax.swing.table.DefaultTableModel(obj, columnHead) 
        {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
                
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });            
            
        jScrollPane.setViewportView(table);
        
        // set table properties
        table.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        table.getTableHeader().setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        table.getTableHeader().setForeground(java.awt.Color.darkGray);
        table.setAutoResizeMode(0);            
        table.setRowHeight(18);
            
        // set table column width
        table.getColumn(columnHead[0]).setPreferredWidth(75);
        table.getColumn(columnHead[1]).setPreferredWidth(260);
        table.getColumn(columnHead[2]).setPreferredWidth(50);
        table.getColumn(columnHead[3]).setPreferredWidth(40);
        table.getColumn(columnHead[4]).setPreferredWidth(60);                   
        table.getColumn(columnHead[5]).setPreferredWidth(70);
        table.getColumn(columnHead[6]).setPreferredWidth(70);
        
        // calculate GPA
        HandleRegister hRegister = new HandleRegister();
        HandleGrade hGrade = new HandleGrade();        
        
	Vector vTerm = hRegister.retrieveAllRegisterSemester(hStudent.getStudent());
        Enumeration eTerm = vTerm.elements();
        
        double gpa = 0.00;
        
        while(eTerm.hasMoreElements())
        {
            /* calculate GPA in each term */            
            Register r = (Register)eTerm.nextElement();
            
            Vector vRegisData = hRegister.retrieveRegisterData(hStudent.getStudent(), r.getSemester(), r.getYear());
            Enumeration eRegisData = vRegisData.elements();

            /* all register section in that term */                             
            while(eRegisData.hasMoreElements())
            {
                Register rData = (Register)eRegisData.nextElement();
                
		if(rData.getSectionType().equals("C") && !rData.getGrade().equals("X"))
		{
                    // calculate total point for GPA
                    hGrade.calcAllTotalPoint(rData.getGrade(), Double.parseDouble(rData.getSubject().getCredit()));                    
                    // calculate total credit for GPA
                    hGrade.calcAllTotalCredit(Double.parseDouble(rData.getSubject().getCredit()));
		}
            }            
        }
        
        // set GPA
        DecimalFormat format = new DecimalFormat("0.00");
        tfGPA.setText(format.format(hGrade.calcGPA()));
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        jLabel2 = new javax.swing.JLabel();
        tfCourseName = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jScrollPane = new javax.swing.JScrollPane();
        jLabel311 = new javax.swing.JLabel();
        tfTotalCredit = new javax.swing.JTextField();
        jLabel3111 = new javax.swing.JLabel();
        tfStudentName = new javax.swing.JTextField();
        jLabel3112 = new javax.swing.JLabel();
        tfSumCredit = new javax.swing.JTextField();
        jLabel3113 = new javax.swing.JLabel();
        tfGPA = new javax.swing.JTextField();
        btExit = new javax.swing.JButton();

        getContentPane().setLayout(null);

        setTitle("\u0e15\u0e23\u0e27\u0e08\u0e2a\u0e2d\u0e1a\u0e1c\u0e25\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32 - \u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel2.setForeground(java.awt.Color.blue);
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("\u0e15\u0e23\u0e27\u0e08\u0e2a\u0e2d\u0e1a\u0e1c\u0e25\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(230, 30, 170, 21);

        tfCourseName.setBackground(java.awt.Color.cyan);
        tfCourseName.setEditable(false);
        tfCourseName.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        getContentPane().add(tfCourseName);
        tfCourseName.setBounds(370, 100, 200, 23);

        jLabel31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31.setForeground(java.awt.Color.darkGray);
        jLabel31.setText("\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        getContentPane().add(jLabel31);
        jLabel31.setBounds(320, 100, 50, 23);

        getContentPane().add(jScrollPane);
        jScrollPane.setBounds(40, 140, 530, 320);

        jLabel311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel311.setForeground(java.awt.Color.darkGray);
        jLabel311.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel311.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e2a\u0e30\u0e2a\u0e21");
        getContentPane().add(jLabel311);
        jLabel311.setBounds(40, 480, 70, 23);

        tfTotalCredit.setBackground(java.awt.Color.green);
        tfTotalCredit.setEditable(false);
        tfTotalCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfTotalCredit.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        getContentPane().add(tfTotalCredit);
        tfTotalCredit.setBounds(170, 510, 60, 23);

        jLabel3111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3111.setForeground(java.awt.Color.darkGray);
        jLabel3111.setText("\u0e0a\u0e37\u0e48\u0e2d - \u0e19\u0e32\u0e21\u0e2a\u0e01\u0e38\u0e25");
        getContentPane().add(jLabel3111);
        jLabel3111.setBounds(40, 100, 70, 23);

        tfStudentName.setBackground(java.awt.Color.cyan);
        tfStudentName.setEditable(false);
        tfStudentName.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        getContentPane().add(tfStudentName);
        tfStudentName.setBounds(110, 100, 200, 23);

        jLabel3112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3112.setForeground(java.awt.Color.darkGray);
        jLabel3112.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3112.setText("\u0e40\u0e01\u0e23\u0e14\u0e40\u0e09\u0e25\u0e35\u0e48\u0e22\u0e2a\u0e30\u0e2a\u0e21");
        getContentPane().add(jLabel3112);
        jLabel3112.setBounds(260, 510, 80, 23);

        tfSumCredit.setBackground(java.awt.Color.cyan);
        tfSumCredit.setEditable(false);
        tfSumCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfSumCredit.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        getContentPane().add(tfSumCredit);
        tfSumCredit.setBounds(170, 480, 60, 23);

        jLabel3113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3113.setForeground(java.awt.Color.darkGray);
        jLabel3113.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3113.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e23\u0e27\u0e21\u0e15\u0e32\u0e21\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        getContentPane().add(jLabel3113);
        jLabel3113.setBounds(40, 510, 120, 23);

        tfGPA.setBackground(java.awt.Color.cyan);
        tfGPA.setEditable(false);
        tfGPA.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfGPA.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        getContentPane().add(tfGPA);
        tfGPA.setBounds(345, 510, 60, 23);

        btExit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btExit.setForeground(java.awt.Color.darkGray);
        btExit.setText("\u0e2d\u0e2d\u0e01");
        btExit.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btExitActionPerformed(evt);
            }
        });

        getContentPane().add(btExit);
        btExit.setBounds(490, 510, 80, 24);

        pack();
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setSize(new java.awt.Dimension(620, 598));
        setLocation((screenSize.width-620)/2,(screenSize.height-598)/2);
    }//GEN-END:initComponents

    private void btExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btExitActionPerformed
        // Add your handling code here:
        this.dispose();        
    }//GEN-LAST:event_btExitActionPerformed
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        this.dispose();
    }//GEN-LAST:event_exitForm
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) 
    {
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel3112;
    private javax.swing.JLabel jLabel311;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField tfStudentName;
    private javax.swing.JTextField tfSumCredit;
    private javax.swing.JTextField tfTotalCredit;
    private javax.swing.JTextField tfGPA;
    private javax.swing.JLabel jLabel3113;
    private javax.swing.JButton btExit;
    private javax.swing.JLabel jLabel3111;
    private javax.swing.JTextField tfCourseName;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JScrollPane jScrollPane;
    // End of variables declaration//GEN-END:variables
}
