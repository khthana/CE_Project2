/*
 * HandleRegister.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 21:45 �.
 */

package register;

import java.util.*;
import java.sql.*;
import schedule.*;
import utility.*;
import graduate.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class HandleRegister extends HandlePreRegister
{    
    /** Creates a new instance of HandleRegister */
    public HandleRegister() 
    {
    }
    
    public boolean isExpire()
    {
        HandleTimeSchedule hSchedule = new HandleTimeSchedule();
        // retrieve preregistration time interval
        Vector v = hSchedule.retrieveTimeSchedule("5");
        Enumeration e = v.elements();
        
        if(e.hasMoreElements())
        {
            TimeSchedule schedule = (TimeSchedule)e.nextElement();
            
            if((DateUtil.compareWithCurrentDate(schedule.getBeginDate()) == -1 ||
                DateUtil.compareWithCurrentDate(schedule.getBeginDate()) == 0) &&
               (DateUtil.compareWithCurrentDate(schedule.getEndDate()) == 1 ||
                DateUtil.compareWithCurrentDate(schedule.getEndDate()) == 0))
            {
                return false;
            }
        }
        
        return true;        
    }
    
    public boolean isRegistered(Student s)
    {
        try
        {
            String query = "SELECT * " +
                           "FROM register " +
                           "WHERE year = '" + HandleTimeInterval.retrieveYear() + "' AND semester = '" + HandleTimeInterval.retrieveSemester() + "' AND std# = '" + s.getId() + "' AND register_type = 'C'";
            
            ResultSet rs = DB.getResultSet(query);
            
            if(rs.next())
            {
                return true;
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }        
        
        return false;
    } 

    public Vector retrieveRegisterData(Student s, String semester, String year)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT r.std#, r.sec#, r.year, r.semester, r.register_type, r.section_type, r.grade, t.subj# " +
                           "FROM register r, section t " +
                           "WHERE r.std# = '" + s.getId() + "' " +
                           "AND r.sec# = t.sec# " +                           
                           "AND r.semester = '" + semester + "' " +
                           "AND r.year = '" + year + "' " +
                           "AND r.register_type = 'C'";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {
                Register r = new Register();
                
                r.setStudent(s);                

                HandleSection hSection = new HandleSection();                
                Vector t = hSection.retrieveSection(rs.getString(2));
                Enumeration e = t.elements();
                
                if(e.hasMoreElements())
                {
                    Section section = (Section)e.nextElement();                    
                    HandleSubject hSubject = new HandleSubject();
                    t = hSubject.retrieveSubject(rs.getString(8));
                    e = t.elements();
                    
                    if(e.hasMoreElements())
                    {
                        Subject subject = (Subject)e.nextElement();
                        subject.setSection(section);
                        r.setSubject(subject);                        
                    }                    
                }
                
                r.setYear(rs.getString(3));
                r.setSemester(rs.getString(4));
                r.setRegisterType(rs.getString(5));
                r.setSectionType(rs.getString(6));
                r.setGrade(rs.getString(7));
                
                v.addElement(r);
            }            
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public Vector retrieveRegisterData(Subject s, String semester, String year)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM register WHERE sec# = " + s.getSection().getId() + " and semester = '" + semester + "' and year = '" + year + "' and register_type = 'C'";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {
                Register r = new Register();
                
                HandleStudent hStudent = new HandleStudent();
                Vector vs = hStudent.retrieveStudentInfo(rs.getString(1));
                Enumeration es = vs.elements();
                
                if(es.hasMoreElements())
                {
                    hStudent = (HandleStudent)es.nextElement();
                    r.setStudent(hStudent.getStudent());
                }
                
                r.setSubject(s);
                r.setYear(rs.getString(3));
                r.setSemester(rs.getString(4));
                r.setRegisterType(rs.getString(5));
                r.setSectionType(rs.getString(6));
                r.setGrade(rs.getString(7));
                
                v.addElement(r);
            }              
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }    
    
    public Vector retrieveAllRegisterSemester(Student s)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT year, semester " +
                           "FROM register " +
                           "WHERE std# = '" + s.getId() + "' " +
                           "AND register_type = 'C' " +
                           "GROUP BY year, semester " +
                           "ORDER BY year, semester ";
                           
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {
                Register r = new Register();
                
                r.setYear(rs.getString(1));
                r.setSemester(rs.getString(2));
                
                v.addElement(r);
            }            
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }    
}
