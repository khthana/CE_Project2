/*
 * HandleTimeInterval.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 12:55 �.
 */

package register;

import java.sql.*;
import java.text.*;
import java.util.*;
import utility.*;

/**
 *
 * @author  KUKI
 */
public class HandleTimeInterval 
{    
    /** Creates a new instance of HandleTimeInterval */
    public HandleTimeInterval() 
    {
    }
    
    public static String retrieveSemester()
    {
        java.util.Date currentDate = new java.util.Date(); 
        String semester = null;
        
        try
        {
            String query = "SELECT * " +
                           "FROM Time_Schedule " +
                           "WHERE Time# <= 3";

            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                if(rs.getDate("Begin").before(currentDate) && rs.getDate("End").after(currentDate)) 
                {
                    semester = rs.getString(1);
                }
            }   
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return semester;
    }
    
    public static String retrieveYear()
    {
        String year = null;
        
        try
        {
            String query = "SELECT * " +
                           "FROM Time_Schedule " +
                           "WHERE Time# = 1";

            ResultSet rs = DB.getResultSet(query);
            
            if(rs.next()) 
            {
                String date = new SimpleDateFormat().getDateInstance(3).format(rs.getDate("Begin"));
                StringTokenizer st = new StringTokenizer(date,"/");
                date = st.nextToken();
                date = st.nextToken();
                date = st.nextToken();	
                year = Integer.toString(Integer.parseInt(date));	
            }            
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return year;
    }
}
