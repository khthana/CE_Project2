/*
 * Register.java
 *
 * Created on 8 �ѹ�Ҥ� 2545, 18:24 �.
 */

package register;

import graduate.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class Register 
{
    private String semester = "";
    private String year = "";
    private String register_type = "";
    private String section_type = "";
    private String grade = "";

    private Subject subject = new Subject();
    private Student student = new Student();
    
    /** Creates a new instance of Register */
    public Register() 
    {
    }
    
    public String getSemester()
    {
        return this.semester;
    }
    
    public String getYear()
    {
        return this.year;
    }
    
    public String getRegisterType()
    {
        return this.register_type;
    }
    
    public String getSectionType()
    {
        return this.section_type;
    }
    
    public String getGrade()
    {
        return this.grade;
    }
    
    public Subject getSubject()
    {
        return this.subject;
    }
    
    public Student getStudent()
    {
        return this.student;
    }
    
    public void setSemester(String semester)
    {
        this.semester = semester;
    }
    
    public void setYear(String year)
    {
        this.year = year;
    }
    
    public void setRegisterType(String register_type)
    {
        this.register_type = register_type;
    }
    
    public void setSectionType(String section_type)
    {
        this.section_type = section_type;
    }
    
    public void setGrade(String grade)
    {
        this.grade = grade;
    }
    
    public void setSubject(Subject subject)
    {
        this.subject = subject;
    }
    
    public void setStudent(Student student)
    {
        this.student = student;
    }
}
