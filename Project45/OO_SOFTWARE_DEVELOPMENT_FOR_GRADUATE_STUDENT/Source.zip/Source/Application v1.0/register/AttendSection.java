/*
 * AttendSection.java
 *
 * Created on 9 �ѹ�Ҥ� 2545, 16:58 �.
 */

package register;

import course.*;
import utility.*;

/**
 *
 * @author  KUKI
 */
public class AttendSection 
{    
    /** Creates a new instance of AttendSection */
    public AttendSection() 
    {
    }
    
    public boolean add(Register r)
    {
        String query = "INSERT INTO register(std#, sec#, year, semester, register_type, section_type, grade) " +
                       "VALUES('" + r.getStudent().getId() + "', " + r.getSubject().getSection().getId() + ", '" + r.getYear() + "', '" + r.getSemester() + "', '" + r.getRegisterType() + "', '" + r.getSectionType() + "', '" + r.getGrade() + "')";
        
        if(DB.update(query) != 0)
        {
            HandleSection hSection = new HandleSection();
            hSection.incrementCurrentStudent(r.getSubject().getSection());
            
            return true;
        }
        
        return false;
    }
    
    public boolean drop(Register r)
    {
        String query = "DELETE FROM register WHERE std# = '" + r.getStudent().getId() + "' and sec# = " + r.getSubject().getSection().getId() + " and year = '" + r.getYear() + "' and semester = '" + r.getSemester() + "' and register_type = '" + r.getRegisterType() + "'";
        
        if(DB.update(query) != 0)
        {
            HandleSection hSection = new HandleSection();
            hSection.decrementCurrentStudent(r.getSubject().getSection());
            
            return true;
        }
        
        return false;
    }
    
    public boolean change(Register rnew, Register rold)
    {
        String query = "UPDATE register " +
                       "SET " + 
                       "sec# = " + rnew.getSubject().getSection().getId() + ", " +
                       "section_type = '" + rnew.getSectionType() + "', " +
                       "grade = '" + rnew.getGrade() + "' " +
                       "WHERE " +
                       "std# = '" + rold.getStudent().getId() + "' and " +
                       "sec# = " + rold.getSubject().getSection().getId() + " and " +
                       "year = '" + rold.getYear() + "' and " +
                       "semester = '" + rold.getSemester() + "' ";        

        if(DB.update(query) != 0)
        {            
            Section snew = rnew.getSubject().getSection();            
            Section sold = rold.getSubject().getSection();
            
            if(!snew.getId().equals(sold.getId()))
            {
                HandleSection hSection = new HandleSection();
                hSection.incrementCurrentStudent(rnew.getSubject().getSection());
                hSection.decrementCurrentStudent(rold.getSubject().getSection());
            }
            
            return true;
        }
        
        return false;
    }
    
    public boolean insertGrade(Register r)
    {
        String query = "UPDATE register " +
                       "SET " +
                       "grade = '" + r.getGrade() + "' " +
                       "WHERE std# = '" + r.getStudent().getId() + "' and sec# = " + r.getSubject().getSection().getId() + " and year = '" + HandleTimeInterval.retrieveYear() + "' and semester = '" + HandleTimeInterval.retrieveSemester() + "' and register_type = 'C'";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;      
    }    
}
