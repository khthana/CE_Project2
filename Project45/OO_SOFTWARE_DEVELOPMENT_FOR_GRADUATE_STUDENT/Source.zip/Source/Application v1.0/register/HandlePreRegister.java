/*
 * HandlePreRegister.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 0:04 �.
 */

package register;

import java.util.*;
import java.sql.*;
import java.io.*;
import schedule.*;
import utility.*;
import graduate.*;
import course.*;

/**
 *
 * @author  KUKI
 */
public class HandlePreRegister 
{    
    protected int minCredit = 3;
    protected int maxCredit = 15;

    protected Register register[] = new Register[8];
    
    /** Creates a new instance of HandlePreRegister */
    public HandlePreRegister() 
    {
        for(int i=0; i<register.length; i++)
        {
            register[i] = null;
        }
    }
    
    public int getMinCredit()
    {
        return minCredit;
    }
    
    public int getMaxCredit()
    { 
        return maxCredit;
    }
    
    public Register getRegister(int i)
    {
        return this.register[i];
    }    
    
    public void setMinCredit(int minCredit)
    {
        this.minCredit = minCredit;
    }
    
    public void setMaxCredit(int maxCredit)
    {
        this.maxCredit = maxCredit;
    }
    
    public void setRegister(Register register, int i)
    {
        this.register[i] = register;
    }
    
    public void clearAllRegister()
    {
        for(int i=0; i<register.length; i++)
        {
            register[i] = null;
        }
    }

    public Vector retrievePreRegisterData(Student s, Subject j)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * " +
                           "FROM register " +
                           "WHERE std# = '" + s.getId() + "' " +
                           "AND sec# = " + j.getSection().getId() + " " +
                           "AND year = '" + HandleTimeInterval.retrieveYear() + "' " +
                           "AND semester = '" + HandleTimeInterval.retrieveSemester() + "' " +
                           "AND register_type = 'P' ";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {
                Register r = new Register();
                
                r.setStudent(s);                
                r.setSubject(j);
                r.setYear(rs.getString(4));
                r.setSemester(rs.getString(5));
                r.setRegisterType(rs.getString(6));
                r.setSectionType(rs.getString(7));
                r.setGrade(rs.getString(8));
                
                v.addElement(r);
            }            
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public Vector retrieveAllPreRegisterData(Student s)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT r.std#, r.sec#, r.year, r.semester, r.register_type, r.section_type, r.grade, t.subj# " +
                           "FROM register r, section t " +
                           "WHERE r.std# = '" + s.getId() + "' " +
                           "AND r.sec# = t.sec# " +
                           "AND r.year = '" + HandleTimeInterval.retrieveYear() + "' " +
                           "AND r.semester = '" + HandleTimeInterval.retrieveSemester() + "' " +
                           "AND r.register_type = 'P' ";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {
                Register r = new Register();
                
                r.setStudent(s);                

                HandleSection hSection = new HandleSection();                
                Vector t = hSection.retrieveSection(rs.getString(2));
                Enumeration e = t.elements();
                
                if(e.hasMoreElements())
                {
                    Section section = (Section)e.nextElement();                    
                    HandleSubject hSubject = new HandleSubject();
                    t = hSubject.retrieveSubject(rs.getString(8));
                    e = t.elements();
                    
                    if(e.hasMoreElements())
                    {
                        Subject subject = (Subject)e.nextElement();
                        subject.setSection(section);
                        r.setSubject(subject);                        
                    }                    
                }
                
                r.setYear(rs.getString(3));
                r.setSemester(rs.getString(4));
                r.setRegisterType(rs.getString(5));
                r.setSectionType(rs.getString(6));
                r.setGrade(rs.getString(7));
                
                v.addElement(r);
            }            
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
   
    public void register()    
    {
        for(int i=0; i<register.length; i++)
        {
            if(register[i] != null)
            {
                String query = "INSERT INTO register(std#, sec#, year, semester, register_type, section_type, grade) " + 
                               "VALUES('" + register[i].getStudent().getId() + "', " +
                                      " " + register[i].getSubject().getSection().getId() + ", " +
                                      "'" + register[i].getYear() + "', " +
                                      "'" + register[i].getSemester() + "', " +
                                      "'" + register[i].getRegisterType() + "', " +
                                      "'" + register[i].getSectionType() + "', " +
                                      "'" + register[i].getGrade() + "')";
                
                if(DB.update(query) != 0)
                {
                    HandleSection hSection = new HandleSection();
                    hSection.incrementCurrentStudent(register[i].getSubject().getSection());
                }
            }
        }
    }
    
    public void unregister(Register r)
    {
        String query = "DELETE FROM register " +
                       "WHERE std# = '" + r.getStudent().getId() + "' AND " +
                       "sec# = " + r.getSubject().getSection().getId() + " AND " +
                       "year = '" + r.getYear() + "' AND " +
                       "semester = '" + r.getSemester() + "' AND " +
                       "register_type = '" + r.getRegisterType() + "'";
        
        if(DB.update(query) != 0)
        {  
            HandleSection hSection = new HandleSection();
            hSection.decrementCurrentStudent(r.getSubject().getSection());
        }
    }
    
    public boolean changeRegisterType(Register r)
    {
        String query = "UPDATE register " +
                       "SET register_type = 'C' " +
                       "WHERE std# = '" + r.getStudent().getId() + "' " +
                       "AND sec# = " + r.getSubject().getSection().getId() + " " +
                       "AND year = '" + r.getYear() + "' " +
                       "AND semester = '" + r.getSemester() + "' ";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;          
    }
    
    public boolean isExpire()
    {
        HandleTimeSchedule hSchedule = new HandleTimeSchedule();
        Vector v = hSchedule.retrieveTimeSchedule("4");
        Enumeration e = v.elements();
        
        if(e.hasMoreElements())
        {
            TimeSchedule schedule = (TimeSchedule)e.nextElement();
            
            if((DateUtil.compareWithCurrentDate(schedule.getBeginDate()) == -1 ||
                DateUtil.compareWithCurrentDate(schedule.getBeginDate()) == 0) &&
               (DateUtil.compareWithCurrentDate(schedule.getEndDate()) == 1 ||
                DateUtil.compareWithCurrentDate(schedule.getEndDate()) == 0))
            {
                return false;
            }
        }
        
        return true;
    }
    
    public boolean isRegistered(Student s)
    {
        try
        {
            String query = "SELECT * " +
                           "FROM register " +
                           "WHERE year = '" + HandleTimeInterval.retrieveYear() + "' AND semester = '" + HandleTimeInterval.retrieveSemester() + "' AND std# = '" + s.getId() + "' AND register_type = 'P'";

            ResultSet rs = DB.getResultSet(query);
            
            if(rs.next())
            {
                return true;
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }        
        
        return false;
    }
    
    public boolean checkSectionRegistered(Student student, Subject subject)
    {
        String query = "SELECT * " +
                       "FROM register r, section t, grade g " +
                       "WHERE r.std# = '" + student.getId() + "' " +
                       "and t.subj# = '" + subject.getId() + "' " +
                       "and r.grade = g.grade " +
                       "and r.register_type = 'C' " +
                       "and t.sec# = r.sec# " +
                       "and (g.point >= 2.50 or r.grade = 'X')";     
        
        try
        {
            ResultSet rs = DB.getResultSet(query);
            
            if(rs.next())
            {
                return true;
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }        
        
        return false;
    }
    
    public boolean checkPassedPrerequisite(Student student, Subject subject)
    {
        try
        {
            String query = "SELECT * " +
                           "FROM register r, section t " +
                           "WHERE r.std# = '" + student.getId() + "' " +
                           "AND t.subj# = '" + subject.getPrerequisite().getId() + "' " +
                           "AND t.sec# = r.sec# " +
                           "AND r.grade != 'X' " +
                           "AND r.register_type = 'C'";
              
            ResultSet rs = DB.getResultSet(query);
                 
            if(rs.next())
            {
                return true;
            }     
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return false;
    }
    
    public boolean checkMinMaxCredit(int allCredit)
    {
        return ((minCredit <= allCredit) && (allCredit <= maxCredit)) ? true : false;        
    }
    
    public void writeAllSubjectToJavaScriptFile()
    {
        String subId = "var subjectId = new Array(";
        String subName = "var subjectName = new Array(";
        String subCredit = "var subjectCredit = new Array(";        
        
        HandleSubject hSubject = new HandleSubject();
        Vector v = hSubject.retrieveAllSubject();
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Subject s = (Subject)e.nextElement();
            
            subId = subId + "\"" + s.getId() + "\",";
            subName = subName + "\"" + s.getEname() + "\",";
            subCredit = subCredit + "\"" + s.getCredit() + "\",";            
        }
        
        subId = subId.substring(0,subId.length()-1) + "); ";
        subName = subName.substring(0,subName.length()-1) + "); ";
        subCredit = subCredit.substring(0,subCredit.length()-1) + "); ";
        
        PrintToFile pf = new PrintToFile();
        pf.getDataToOutFile(subId + " " + subName + " " + subCredit, "C:/Program Files/Apache Group/Tomcat 4.1/webapps/ROOT/Script/Script.js");
    }    
}
