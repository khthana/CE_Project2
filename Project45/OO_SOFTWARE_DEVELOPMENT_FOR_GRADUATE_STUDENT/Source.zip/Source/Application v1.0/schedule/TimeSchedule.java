/*
 * Schedule.java
 *
 * Created on 27 �ѹ�Ҥ� 2545, 20:19 �.
 */

package schedule;

/**
 *
 * @author  KUKI
 */
public class TimeSchedule 
{    
    private String id;
    private String name;
    private java.util.Date begin;
    private java.util.Date end;

    
    /** Creates a new instance of Schedule */
    public TimeSchedule() 
    {
    }   
        
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setName(String name)
    {
        this.name = name;
    }
    
    public void setBeginDate(java.util.Date begin)
    {
        this.begin = begin;
    }
    
    public void setEndDate(java.util.Date end)
    {
        this.end = end;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getName()
    {
        return this.name;
    }
    
    public java.util.Date getBeginDate()
    {
        return this.begin;
    }
    
    public java.util.Date getEndDate()
    {
        return this.end;
    }
    
    public String toString()
    {
        return name;
    }
}
