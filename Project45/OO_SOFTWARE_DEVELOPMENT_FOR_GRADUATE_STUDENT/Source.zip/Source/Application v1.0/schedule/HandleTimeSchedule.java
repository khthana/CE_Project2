/*
 * HandleTimeSchedule.java
 *
 * Created on 8 �ѹ�Ҥ� 2545, 1:10 �.
 */

package schedule;

import utility.*;
import java.util.*;
import java.sql.*;
import java.text.*;

/**
 *
 * @author  KUKI
 */
public class HandleTimeSchedule 
{   
    /** Creates a new instance of HandleTimeSchedule */
    public HandleTimeSchedule() 
    {
    }

    public boolean insertSchedule(TimeSchedule sch)
    {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date beginDate = sch.getBeginDate();        
        java.util.Date endDate = sch.getEndDate();      
        
        String query = "INSERT INTO time_schedule(name, begin, end) " +
                       "VALUES('" + sch.getName() + "', '" + format.format(beginDate) + "', '" + format.format(endDate) + "')";

        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;
    }
    
    public boolean deleteSchedule(TimeSchedule sch)
    {
        String query = "DELETE FROM time_schedule " +
                       "WHERE name = '" + sch.getName() + "' ";

        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;
    }
    
    public boolean updateSchedule(TimeSchedule newSch, TimeSchedule oldSch)
    {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date beginDate = newSch.getBeginDate();        
        java.util.Date endDate = newSch.getEndDate();      
        
        String query = "UPDATE time_schedule " +
                       "SET name = '" + newSch.getName() + "', begin = '" + format.format(beginDate) + "', end = '" + format.format(endDate) + "' " +
                       "WHERE name = '" + oldSch.getName() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public Vector retrieveTimeSchedule(String timeID)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM time_schedule WHERE time# = " + timeID;            
            
            ResultSet rs = DB.getResultSet(query);           
        
            if(rs.next())
            {
                TimeSchedule schedule = new TimeSchedule();
                schedule.setId(rs.getString(1));
                schedule.setName(rs.getString(2));
                schedule.setBeginDate(rs.getDate(3));
                schedule.setEndDate(rs.getDate(4));
            
                v.addElement(schedule);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public Vector retrieveAllTimeSchedule()
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM time_schedule ORDER BY time#";
            
            ResultSet rs = DB.getResultSet(query);           
        
            while(rs.next())
            {
                TimeSchedule schedule = new TimeSchedule();
                schedule.setId(rs.getString(1));                
                schedule.setName(rs.getString(2));
                schedule.setBeginDate(rs.getDate(3));
                schedule.setEndDate(rs.getDate(4));
            
                v.addElement(schedule);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }    
}
