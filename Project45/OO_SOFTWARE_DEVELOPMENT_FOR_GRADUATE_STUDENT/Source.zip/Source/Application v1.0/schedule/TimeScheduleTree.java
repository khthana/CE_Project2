/*
 * TimeScheduleTree.java
 *
 * Created on 8 �ѹ�Ҥ� 2545, 1:11 �.
 */

package schedule;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class TimeScheduleTree 
{
    private DefaultMutableTreeNode timeNode;    
    private Tree tree;
    
    /** Creates a new instance of TimeScheduleTree */
    public TimeScheduleTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveTimeScheduleInfo()
    {
        HandleTimeSchedule hSchedule = new HandleTimeSchedule();                
        Vector v = hSchedule.retrieveAllTimeSchedule();
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            TimeSchedule s = (TimeSchedule)e.nextElement();        
            timeNode = tree.addObject(null, s);
        }        
    }    
}
