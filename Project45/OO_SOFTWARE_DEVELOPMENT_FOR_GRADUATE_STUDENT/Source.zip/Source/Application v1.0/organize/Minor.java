/*
 * Minor.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 13:42 �.
 */

package organize;

/**
 *
 * @author  KUKI
 */
public class Minor 
{
    private String id = "";
    private String ename = "";
    private String tname = "";
    
    /** Creates a new instance of Minor */
    public Minor() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public String toString()
    {
        return "ᢹ��Ԫ�" + this.tname;
    }
}
