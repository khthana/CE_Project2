/*
 * HandleDepartment.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 15:30 �.
 */

package organize;

import utility.*;
import java.util.*;
import java.sql.*;

/**
 *
 * @author  KUKI
 */
public class HandleDepartment 
{   
    /** Creates a new instance of HandleDepartment */
    public HandleDepartment() 
    {
    }
    
    public Vector retrieveDepartment(String departmentID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM department WHERE dept# = '" + departmentID + "'";            
            
            ResultSet rs = DB.getResultSet(query);      
        
            if(rs.next())
            {            
                Department d = new Department();  
                
                d.setId(rs.getString(1));
                d.setEname(rs.getString(2));
                d.setTname(rs.getString(3));                
                v.addElement(d);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }   
    
    public Vector retrieveAllDepartment(String facultyID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM department WHERE fact# = '" + facultyID + "' ORDER BY dept#";            
            
            ResultSet rs = DB.getResultSet(query);      
        
            while(rs.next())
            {            
                Department d = new Department();  
                
                d.setId(rs.getString(1));
                d.setEname(rs.getString(2));
                d.setTname(rs.getString(3));                
                v.addElement(d);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }   
    
    public boolean addDepartment(Faculty f, Department d)
    {
        String query = "INSERT INTO department(dept#, ename, tname, fact#) " +
                       "VALUES('" + d.getId() + "', '" + d.getEname() + "', '" + d.getTname() + "', '" + f.getId() + "')";       

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public boolean removeDepartment(Department d)
    {
        String query = "DELETE FROM department " +
                       "WHERE dept# = '" + d.getId() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;    
    }
    
    public boolean updateDepartment(Department newd, Department oldd)
    {
        String query = "UPDATE department " +
                       "SET dept# = '" + newd.getId() + "', ename = '" + newd.getEname() + "', tname = '" + newd.getTname() + "' " +
                       "WHERE dept# = '" + oldd.getId() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
}
