/*
 * Major.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 13:41 �.
 */

package organize;

/**
 *
 * @author  KUKI
 */
public class Major 
{
    private String id = "";
    private String ename = "";
    private String tname = "";
    private Minor minor;
    
    /** Creates a new instance of Major */
    public Major() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public void setMinor(Minor minor)
    {
        this.minor = minor;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public Minor getMinor()
    {
       return this.minor;
    }      
    
    public String toString()
    {
        return "�Ң��Ԫ�" + this.tname;
    }
}
