/*
 * HandleFaculty.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 13:48 �.
 */

package organize;

import utility.*;
import java.util.*;
import java.sql.*;

/**
 *
 * @author  KUKI
 */
public class HandleFaculty 
{    
    /** Creates a new instance of HandleFaculty */
    public HandleFaculty() 
    {
    }
    
    public Vector retrieveFaculty(String facultyID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM faculty WHERE fact# = '" + facultyID + "'";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Faculty f = new Faculty();  
                
                f.setId(rs.getString(1));
                f.setEname(rs.getString(2));
                f.setTname(rs.getString(3));                
                v.addElement(f);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
        
    public Vector retrieveAllFaculty()
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM faculty ORDER BY fact#";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Faculty f = new Faculty();  
                
                f.setId(rs.getString(1));
                f.setEname(rs.getString(2));
                f.setTname(rs.getString(3));                
                v.addElement(f);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public boolean addFaculty(Faculty f)
    {
        String query = "INSERT INTO faculty(fact#, ename, tname) " +
                       "VALUES('" + f.getId() + "', '" + f.getEname() + "', '" + f.getTname() + "')";        
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public boolean removeFaculty(Faculty f)
    {
        String query = "DELETE FROM faculty " +
                       "WHERE fact# = '" + f.getId() + "' ";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public boolean updateFaculty(Faculty newf, Faculty oldf)
    {
        String query = "UPDATE faculty " +
                       "SET fact# = '" + newf.getId() + "', ename = '" + newf.getEname() + "', tname = '" + newf.getTname() + "' " +
                       "WHERE fact# = '" + oldf.getId() + "' ";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
}
