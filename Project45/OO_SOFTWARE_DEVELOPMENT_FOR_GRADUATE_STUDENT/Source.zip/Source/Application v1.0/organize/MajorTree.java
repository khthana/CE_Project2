/*
 * DepartmentTree.java
 *
 * Created on 7 �ѹ�Ҥ� 2545, 0:37 �.
 */

package organize;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class MajorTree 
{
    private DefaultMutableTreeNode departmentNode;
    private DefaultMutableTreeNode majorNode;     
    private Tree tree;    
    
    /** Creates a new instance of DepartmentTree */
    public MajorTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveMajorInfo(String departmentID)
    {
        HandleMajor hMajor = new HandleMajor();                
        Vector v = hMajor.retrieveAllMajor(departmentID);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Major mj = (Major)e.nextElement();        
            majorNode = tree.addObject(departmentNode, mj);
            
            MinorTree mnTree = new MinorTree(tree);
            mnTree.setNode(majorNode);            
            mnTree.retrieveMinorInfo(mj.getId());    
        }
    }
    
    public void setNode(DefaultMutableTreeNode departmentNode)
    {
        this.departmentNode = departmentNode;
    }     
}
