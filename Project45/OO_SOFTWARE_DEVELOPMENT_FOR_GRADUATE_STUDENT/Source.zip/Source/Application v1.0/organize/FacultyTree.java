/*
 * OrganizeTree.java
 *
 * Created on 6 �ѹ�Ҥ� 2545, 22:58 �.
 */

package organize;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class FacultyTree 
{    
    private DefaultMutableTreeNode facultyNode;
    private Tree tree;
    
    /** Creates a new instance of OrganizeTree */
    public FacultyTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveFacultyInfo()
    {
        HandleFaculty hFaculty = new HandleFaculty();                
        Vector v = hFaculty.retrieveAllFaculty();
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Faculty f = (Faculty)e.nextElement();        
            facultyNode = tree.addObject(null, f);

            DepartmentTree dTree = new DepartmentTree(tree);
            dTree.setNode(facultyNode);            
            dTree.retrieveDepartmentInfo(f.getId());
        }
    }    
}
