/*
 * MajorTree.java
 *
 * Created on 7 �ѹ�Ҥ� 2545, 1:24 �.
 */

package organize;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class MinorTree 
{   
    private DefaultMutableTreeNode majorNode;
    private DefaultMutableTreeNode minorNode;     
    private Tree tree;  
    
    /** Creates a new instance of MajorTree */
    public MinorTree(Tree tree) 
    {
        this.tree = tree;
    }
 
    public void retrieveMinorInfo(String majorID)
    {
        HandleMinor hMinor = new HandleMinor();                
        Vector v = hMinor.retrieveAllMinor(majorID);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Minor mn = (Minor)e.nextElement();        
            minorNode = tree.addObject(majorNode, mn);            
        }
    }
    
    public void setNode(DefaultMutableTreeNode majorNode)
    {
        this.majorNode = majorNode;
    }    
}
