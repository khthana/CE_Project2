/*
 * Department.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 13:38 �.
 */

package organize;

/**
 *
 * @author  KUKI
 */
public class Department 
{    
    private String id = "";
    private String ename = "";
    private String tname = "";
    private Major major;
    
    /** Creates a new instance of Department */
    public Department() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public void setMajor(Major major)
    {
        this.major = major;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public Major getMajor()
    {
        return this.major;
    }
    
    public String toString()
    {
        return "�Ҥ�Ԫ�" + this.tname;
    }
}
