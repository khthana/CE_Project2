/*
 * HandleMajor.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 15:44 �.
 */

package organize;

import utility.*;
import java.util.*;
import java.sql.*;

/**
 *
 * @author  KUKI
 */
public class HandleMajor 
{    
    /** Creates a new instance of HandleMajor */
    public HandleMajor() 
    {
    }
    
    public Vector retrieveMajor(String majorID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM major WHERE major# = '" + majorID + "'";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Major mj = new Major();  
                
                mj.setId(rs.getString(1));
                mj.setEname(rs.getString(2));
                mj.setTname(rs.getString(3));                
                v.addElement(mj);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
        
    public Vector retrieveAllMajor(String departmentID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM major WHERE dept# = '" + departmentID + "' ORDER BY major#";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Major mj = new Major();  
                
                mj.setId(rs.getString(1));
                mj.setEname(rs.getString(2));
                mj.setTname(rs.getString(3));                
                v.addElement(mj);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public boolean addMajor(Department d, Major mj)
    {
        String query = "INSERT INTO major(major#, ename, tname, dept#) " +
                       "VALUES('" + mj.getId() + "', '" + mj.getEname() + "', '" + mj.getTname() + "', '" + d.getId() + "')";       

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public boolean removeMajor(Major mj)
    {
        String query = "DELETE FROM major " +
                       "WHERE major# = '" + mj.getId() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;    
    }
    
    public boolean updateMajor(Major newmj, Major oldmj)
    {
        String query = "UPDATE major " +
                       "SET major# = '" + newmj.getId() + "', ename = '" + newmj.getEname() + "', tname = '" + newmj.getTname() + "' " +
                       "WHERE major# = '" + oldmj.getId() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
}
