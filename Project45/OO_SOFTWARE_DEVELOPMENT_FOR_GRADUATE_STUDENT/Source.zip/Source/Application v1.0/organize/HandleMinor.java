/*
 * HandleMinor.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 15:44 �.
 */

package organize;

import utility.*;
import java.util.*;
import java.sql.*;

/**
 *
 * @author  KUKI
 */
public class HandleMinor 
{    
    /** Creates a new instance of HandleMinor */
    public HandleMinor() 
    {
    }
    
    public Vector retrieveMinor(String minorID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM minor WHERE minor# = '" + minorID + "'";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Minor mn = new Minor();  
                
                mn.setId(rs.getString(1));
                mn.setEname(rs.getString(2));
                mn.setTname(rs.getString(3));                
                v.addElement(mn);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
        
    public Vector retrieveAllMinor(String majorID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM minor WHERE major# = '" + majorID + "' ORDER BY minor#";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Minor mn = new Minor();  
                
                mn.setId(rs.getString(1));
                mn.setEname(rs.getString(2));
                mn.setTname(rs.getString(3));                
                v.addElement(mn);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public boolean addMinor(Major mj, Minor mn)
    {
        String query = "INSERT INTO minor(minor#, ename, tname, major#) " +
                       "VALUES('" + mn.getId() + "', '" + mn.getEname() + "', '" + mn.getTname() + "', '" + mj.getId() + "')";       

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public boolean removeMinor(Minor mn)
    {
        String query = "DELETE FROM minor " +
                       "WHERE minor# = '" + mn.getId() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;    
    }
    
    public boolean updateMinor(Minor newmn, Minor oldmn)
    {
        String query = "UPDATE minor " +
                       "SET minor# = '" + newmn.getId() + "', ename = '" + newmn.getEname() + "', tname = '" + newmn.getTname() + "' " +
                       "WHERE minor# = '" + oldmn.getId() + "' ";

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }    
}
