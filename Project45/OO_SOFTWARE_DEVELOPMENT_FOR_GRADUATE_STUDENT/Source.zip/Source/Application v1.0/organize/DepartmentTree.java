/*
 * FacultyTree.java
 *
 * Created on 6 �ѹ�Ҥ� 2545, 23:32 �.
 */

package organize;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class DepartmentTree 
{
    private DefaultMutableTreeNode facultyNode; 
    private DefaultMutableTreeNode departmentNode;
    private Tree tree;    
    
    /** Creates a new instance of FacultyTree */
    public DepartmentTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveDepartmentInfo(String facultyID)
    {
        HandleDepartment hDepartment = new HandleDepartment();                
        Vector v = hDepartment.retrieveAllDepartment(facultyID);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Department d = (Department)e.nextElement();                    
            departmentNode = tree.addObject(facultyNode, d);

            MajorTree mjTree = new MajorTree(tree);
            mjTree.setNode(departmentNode);            
            mjTree.retrieveMajorInfo(d.getId());    
        }
    }
    
    public void setNode(DefaultMutableTreeNode facultyNode)
    {
        this.facultyNode = facultyNode;
    }    
}
