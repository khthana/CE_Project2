/*
 * Faculty.java
 *
 * Created on 5 �ѹ�Ҥ� 2545, 13:34 �.
 */

package organize;

/**
 *
 * @author  KUKI
 */
public class Faculty 
{    
    private String id = "";
    private String ename = "";
    private String tname = "";
    private Department department;
    
    /** Creates a new instance of Faculty */
    public Faculty() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public void setDepartment(Department department)
    {
        this.department = department;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public Department getDepartment()
    {
        return this.department;
    }
    
    public String toString()
    {
        return "���" + this.tname;
    }
}
