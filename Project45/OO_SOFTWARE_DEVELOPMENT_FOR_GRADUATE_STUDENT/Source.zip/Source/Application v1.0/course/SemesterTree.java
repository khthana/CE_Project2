/*
 * SemesterTree.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 0:05 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class SemesterTree 
{      
    private DefaultMutableTreeNode semesterNode;
    private DefaultMutableTreeNode subCourseNode;
    private Tree tree;
    
    /** Creates a new instance of SemesterTree */
    public SemesterTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveTotalSemester(SubCourse subCourse)
    {
        int year = subCourse.getTotalYear();
        
        for(int i=1; i<=year; i++)
        {
            for(int j=1; j<=2; j++)
            {
                semesterNode = tree.addObject(subCourseNode, "�շ�� " + Integer.toString(i) + " �Ҥ����֡�ҷ�� " + Integer.toString(j));
                
                CourseworkTree cwTree = new CourseworkTree(tree);
                cwTree.setNode(semesterNode);            
                cwTree.retrieveCoursework(subCourse, Integer.toString(j), Integer.toString(i));                    
            }
        }
    }
    
    public void setNode(DefaultMutableTreeNode subCourseNode)
    {
        this.subCourseNode = subCourseNode;
    }    
}
