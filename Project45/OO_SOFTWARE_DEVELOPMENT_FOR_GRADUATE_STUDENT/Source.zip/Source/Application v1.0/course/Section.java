/*
 * Section.java
 *
 * Created on 21 ��Ȩԡ�¹ 2545, 20:04 �.
 */

package course;

import graduate.*;

/**
 *
 * @author  KUKI
 */
public class Section 
{
    private String id;
    private String semester;
    private String year;
    private String beginTime;
    private String endTime;
    private String room;    
    private String day;
    
    private java.util.Date midTermDate;
    private String midTermBeginTime;
    private String midTermEndTime;
    private String midTermRoom;    
    
    private java.util.Date finTermDate;
    private String finTermBeginTime;
    private String finTermEndTime;
    private String finTermRoom;    

    private String maxStudent;
    private String currentStudent;
    private String sec;
    private String lock;  
    private String status;
    
    private Lecturer lecturer;
    
    /** Creates a new instance of Section */
    public Section() 
    {
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getSemester()
    {
        return this.semester;
    }
    
    public String getYear()
    {
        return this.year;
    }
    
    public String getBeginTime()
    {
        return this.beginTime;
    }
    
    public String getEndTime()
    {
        return this.endTime;
    }
    
    public String getRoom()
    {
        return this.room;
    }
    
    public String getDay()
    {
        return this.day;
    }
    
    public java.util.Date getMidTermDate()
    {
        return this.midTermDate;
    }
    
    public String getMidTermBeginTime()
    {
        return this.midTermBeginTime;
    }
    
    public String getMidTermEndTime()
    {
        return this.midTermEndTime;
    }
    
    public String getMidTermRoom()
    {
        return this.midTermRoom;
    }
    
    public java.util.Date getFinTermDate()
    {
        return this.finTermDate;
    }
    
    public String getFinTermBeginTime()
    {
        return this.finTermBeginTime;
    }
    
    public String getFinTermEndTime()
    {
        return this.finTermEndTime;
    }
    
    public String getFinTermRoom()
    {
        return this.finTermRoom;
    }    
    
    public String getMaxStudent()
    {
        return this.maxStudent;
    }
    
    public String getCurrentStudent()
    {
        return this.currentStudent;
    }
    
    public String getSec()
    {
        return this.sec;
    }
    
    public String getLock()
    {
        return this.lock;
    }
    
    public String getStatus()
    {
        return this.status;
    }
    
    public Lecturer getLecturer()
    {
        return this.lecturer;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setSemester(String semester)
    {
        this.semester = semester;
    }
    
    public void setYear(String year)
    {
        this.year = year;
    }
    
    public void setBeginTime(String beginTime)
    {
        this.beginTime = beginTime;
    }
    
    public void setEndTime(String endTime)
    {
        this.endTime = endTime;
    }
    
    public void setRoom(String room)
    {
        this.room = room;
    }
    
    public void setDay(String day)
    {
        this.day = day;
    }

    public void setMidTermDate(java.util.Date midTermDate)
    {
        this.midTermDate = midTermDate;
    }
    
    public void setMidTermBeginTime(String midTermBeginTime)
    {
        this.midTermBeginTime = midTermBeginTime;
    }
    
    public void setMidTermEndTime(String midTermEndTime)
    {
        this.midTermEndTime = midTermEndTime;
    }
    
    public void setMidTermRoom(String midTermRoom)
    {
        this.midTermRoom = midTermRoom;
    }        

    public void setFinTermDate(java.util.Date finTermDate)
    {
        this.finTermDate = finTermDate;
    }
    
    public void setFinTermBeginTime(String finTermBeginTime)
    {
        this.finTermBeginTime = finTermBeginTime;
    }
    
    public void setFinTermEndTime(String finTermEndTime)
    {
        this.finTermEndTime = finTermEndTime;
    }
    
    public void setFinTermRoom(String finTermRoom)
    {
        this.finTermRoom = finTermRoom;
    }
    
    public void setMaxStudent(String maxStudent)
    {
        this.maxStudent = maxStudent;
    }
    
    public void setCurrentStudent(String currentStudent)
    {
        this.currentStudent = currentStudent;
    }
    
    public void setSec(String sec)
    {   
        this.sec = sec;
    }
    
    public void setLock(String lock)
    {
        this.lock = lock;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }  
    
    public void setLecturer(Lecturer lecturer)
    {
        this.lecturer = lecturer;
    }
    
    public String toString()
    {
        return "�礪�蹷�� " + sec;
    }
}
