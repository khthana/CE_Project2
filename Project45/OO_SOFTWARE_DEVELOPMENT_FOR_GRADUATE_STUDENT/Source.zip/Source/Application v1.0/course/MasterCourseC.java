/*
 * MasterCourseC.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 18:25 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class MasterCourseC extends MasterCourse
{   
    private String coursework_credit;
    private String comprehensive_credit;
    
    /** Creates a new instance of MasterCourseC */
    public MasterCourseC() 
    {
    }
    
    public void setCourseworkCredit(String coursework_credit)
    {
        this.coursework_credit = coursework_credit;
    }
    
    public String getCourseworkCredit()
    {
        return this.coursework_credit;
    } 
    
    public void setComprehensiveCredit(String comprehensive_credit)
    {
        this.comprehensive_credit = comprehensive_credit;
    }
    
    public String getComprehensiveCredit()
    {
        return this.comprehensive_credit;
    }     
}
