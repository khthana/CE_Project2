/*
 * Course.java
 *
 * Created on 8 �ѹ�Ҥ� 2545, 17:39 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class Course 
{    
    protected String id = "";
    protected String ename = "";
    protected String tname = "";
    protected String ft_degree = "";
    protected String fe_degree = "";
    protected String st_degree = "";
    protected String se_degree = "";
    protected String degree = "";
    protected String total_credit = "";
    protected String total_year = "";
    
    /** Creates a new instance of Course */
    public Course() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public void setFTDegree(String ft_degree)
    {
        this.ft_degree = ft_degree;
    }
    
    public void setFEDegree(String fe_degree)
    {
        this.fe_degree = fe_degree;
    }
    
    public void setSTDegree(String st_degree)
    {
        this.st_degree = st_degree;
    }
    
    public void setSEDegree(String se_degree)
    {
        this.se_degree = se_degree;
    }
    
    public void setDegree(String degree)
    {
        this.degree = degree;
    }
    
    public void setTotalCredit(String total_credit)
    {
        this.total_credit = total_credit;
    }
    
    public void setTotalYear(String total_year)
    {
        this.total_year = total_year;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public String getFTDegree()
    {
        return this.ft_degree;
    }
    
    public String getFEDegree()
    {
        return this.fe_degree;
    }
    
    public String getSTDegree()
    {
        return this.st_degree;
    }
    
    public String getSEDegree()
    {
        return this.se_degree;
    }
    
    public String getDegree()
    {
        return this.degree;
    }
    
    public String getTotalCredit()
    {
        return this.total_credit;
    }
    
    public String getTotalYear()
    {
        return this.total_year;
    }
    
    public String toString()
    {
        return "��ѡ�ٵ� " + this.st_degree;
    }
}
