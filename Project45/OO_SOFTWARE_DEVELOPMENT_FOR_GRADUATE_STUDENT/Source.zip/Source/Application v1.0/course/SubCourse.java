/*
 * SubCourse.java
 *
 * Created on 19 ��Ȩԡ�¹ 2545, 22:09 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class SubCourse 
{
    private String id;
    private String ename;
    private String tname;
    private String type1;
    private String type2;
    private int totalYear;
    private int totalCredit;
    
    /** Creates a new instance of SubCourse */
    public SubCourse() 
    {
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public String getType1()
    {
        return this.type1;
    }
    
    public String getType2()
    {
        return this.type2;
    }
    
    public int getTotalYear()
    {
        return this.totalYear;
    }
    
    public int getTotalCredit()
    {
        return this.totalCredit;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public void setType1(String type1)
    {
        this.type1 = type1;
    }
    
    public void setType2(String type2)
    {
        this.type2 = type2;
    }
    
    public void setTotalYear(int totalYear)
    {
        this.totalYear = totalYear;
    }
    
    public void setTotalCredit(int totalCredit)
    {
        this.totalCredit = totalCredit;
    }
    
    public String toString()
    {
        String type_1 = "";
        String type_2 = "";
        
        switch(this.type1.charAt(0))
        {
            case 'C':
                type_1 = "���ѭ";
                break;
            case 'T':
                type_1 = "���ͧ���¹";
                break;
            default:
        }
        
        switch(this.type2.charAt(0))
        {
            case 'A':
                type_2 = "����";
                break;
            case 'B':
                type_2 = "����";
                break;
            case 'C':
                type_2 = "�����-�ҷԵ��";
                break;
            default:
        }
        
        return this.tname + " (" + type_1 + ", " + type_2 + ")";
    }    
}
