/*
 * CourseworkPrerequisiteTree.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 19:56 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class PrerequisiteTree 
{ 
    private DefaultMutableTreeNode prerequisiteNode;
    private DefaultMutableTreeNode subjectPrerequisiteNode;
    private Tree tree;
    
    /** Creates a new instance of CourseworkPrerequisiteTree */
    public PrerequisiteTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveCourseworkPrerequisite(Subject subject)
    {
        Subject prerequisite = subject.getPrerequisite();       
        prerequisiteNode = tree.addObject(subjectPrerequisiteNode, prerequisite);
    }
    
    public void setNode(DefaultMutableTreeNode subjectPrerequisiteNode)
    {
        this.subjectPrerequisiteNode = subjectPrerequisiteNode;
    }      
    
}
