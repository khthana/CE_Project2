/*
 * Subject.java
 *
 * Created on 21 ��Ȩԡ�¹ 2545, 20:29 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class Subject 
{    
    private String id;
    private String ename;
    private String tname;
    private String group;
    private String credit;    
    private String lecture;
    private String practice;
    private String research;
    private String eoutline;
    private String toutline;
    private Subject prerequisite; 
    private Section section;
    
    /** Creates a new instance of Subject */
    public Subject() 
    {        
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getEname()
    {
        return this.ename;
    }
    
    public String getTname()
    {
        return this.tname;
    }
    
    public String getGroup()
    {
        return this.group;
    }
    
    public String getCredit()
    {
        return this.credit;
    }
    
    public String getLecture()
    {
        return this.lecture;
    }
    
    public String getPractice()
    {
        return this.practice;
    }

    public String getResearch()
    {
        return this.research;
    }
    
    public String getEoutline()
    {
        return this.eoutline;
    }
    
    public String getToutline()
    {
        return this.toutline;
    }
    
    public Subject getPrerequisite()
    {
        return this.prerequisite;
    }
    
    public Section getSection()
    {
        return this.section;
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setEname(String ename)
    {
        this.ename = ename;
    }
    
    public void setTname(String tname)
    {
        this.tname = tname;
    }
    
    public void setGroup(String group)
    {
        this.group = group;
    }
    
    public void setCredit(String credit)
    {
        this.credit = credit;
    }
    
    public void setLecture(String lecture)
    {
        this.lecture = lecture;
    }
    
    public void setPractice(String practice)
    {
        this.practice = practice;
    }

    public void setResearch(String research)
    {
        this.research = research;
    }
    
    public void setEoutline(String eoutline)
    {
        this.eoutline = eoutline;
    }
    
    public void setToutline(String toutline)
    {
        this.toutline = toutline;
    }    
    
    public void setPrerequisite(Subject prerequisite)
    {
        this.prerequisite = prerequisite;
    }
    
    public void setSection(Section section)
    {
        this.section = section;
    }
    
    public String toString()
    {
        return this.id + " " + this.ename;
    }
}
