/*
 * Grade.java
 *
 * Created on 4 �ѹ�Ҥ� 2545, 16:56 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class Grade 
{
    private String id = "";
    private String grade = "";
    private double point = 0.00f;
    private String description = "";
    
    /** Creates a new instance of Grade */
    public Grade() 
    {
    }
    
    public void setId(String id)
    {
        this.id = id;
    }
    
    public void setGrade(String grade)
    {
        this.grade = grade;
    }
    
    public void setPoint(double point)
    {
        this.point = point;
    }
    
    public void setDescription(String description)
    {
        this.description = description;
    }
    
    public String getId()
    {
        return this.id;
    }
    
    public String getGrade()
    {
        return this.grade;
    }
    
    public double getPoint()
    {
        return this.point;
    }
    
    public String getDescription()
    {
        return this.description;
    }
    
    public String toString()
    {
        return this.grade;
    }
}
