/*
 * HandleCourse.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 21:07 �.
 */

package course;

import java.util.*;
import java.sql.*;
import utility.*;
import organize.*;
import java.text.*;

/**
 *
 * @author  KUKI
 */
public class HandleCourse 
{    
    /** Creates a new instance of HandleCourse */
    public HandleCourse() 
    {
    }
    
    public Vector retrieveSubCourse(Course c)
    {
        Vector v = new Vector();
        try
        {
            String query = "SELECT * FROM subcourse WHERE co# = " + c.getId();
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                SubCourse subCourse = new SubCourse();
                
                subCourse.setId(rs.getString(1));
                subCourse.setEname(rs.getString(2));
                subCourse.setTname(rs.getString(3));
                subCourse.setType1(rs.getString(4));
                subCourse.setType2(rs.getString(5));
                subCourse.setTotalCredit(rs.getInt(7));
                subCourse.setTotalYear(rs.getInt(8));
                
                v.addElement(subCourse);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return v;
    }
    
    public Vector retrieveMasterCourse(Major major)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM course WHERE degree = 'M' AND major# = '" + major.getId() + "'";
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                MasterCourse mCourse = new MasterCourse();
                
                mCourse.setId(rs.getString(1));
                mCourse.setEname(rs.getString(2));
                mCourse.setTname(rs.getString(3));
                mCourse.setFTDegree(rs.getString(4));
                mCourse.setFEDegree(rs.getString(5));
                mCourse.setSTDegree(rs.getString(6));
                mCourse.setSEDegree(rs.getString(7));
                mCourse.setDegree(rs.getString(8));  
                
                v.addElement(mCourse);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }            
        
        return v;
    }

    public Vector retrieveDoctorCourse(Major major)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM course WHERE degree = 'D' AND major# = '" + major.getId() + "'";
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                DoctorCourse dCourse = new DoctorCourse();
                
                dCourse.setId(rs.getString(1));
                dCourse.setEname(rs.getString(2));
                dCourse.setTname(rs.getString(3));
                dCourse.setFTDegree(rs.getString(4));
                dCourse.setFEDegree(rs.getString(5));
                dCourse.setSTDegree(rs.getString(6));
                dCourse.setSEDegree(rs.getString(7));
                dCourse.setDegree(rs.getString(8));  
                
                v.addElement(dCourse);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }            
        
        return v;
    }

    public Vector retrieveMasterCourse(Major major, Minor minor)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM course WHERE degree = 'M' AND major# = '" + major.getId() + "' AND minor# = '" + minor.getId() + "'";
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                MasterCourse mCourse = new MasterCourse();
                
                mCourse.setId(rs.getString(1));
                mCourse.setEname(rs.getString(2));
                mCourse.setTname(rs.getString(3));
                mCourse.setFTDegree(rs.getString(4));
                mCourse.setFEDegree(rs.getString(5));
                mCourse.setSTDegree(rs.getString(6));
                mCourse.setSEDegree(rs.getString(7));
                mCourse.setDegree(rs.getString(8));  
                
                v.addElement(mCourse);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }            
        
        return v;
    }

    public Vector retrieveDoctorCourse(Major major, Minor minor)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM course WHERE degree = 'D' AND major# = '" + major.getId() + "' AND minor# = '" + minor.getId() + "'";
            ResultSet rs = DB.getResultSet(query);
            
            while(rs.next())
            {
                DoctorCourse dCourse = new DoctorCourse();
                
                dCourse.setId(rs.getString(1));
                dCourse.setEname(rs.getString(2));
                dCourse.setTname(rs.getString(3));
                dCourse.setFTDegree(rs.getString(4));
                dCourse.setFEDegree(rs.getString(5));
                dCourse.setSTDegree(rs.getString(6));
                dCourse.setSEDegree(rs.getString(7));
                dCourse.setDegree(rs.getString(8));
                
                v.addElement(dCourse);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }            
        
        return v;
    }
    
    public SubCourse retrieveSubCourse(SubCourse subcourse, Course c)
    {
        SubCourse s = null;
        
        try
        {
            String query = "SELECT * FROM subcourse WHERE tname = '" + subcourse.getTname() + "' and co# = " + c.getId();
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {           
                s = new SubCourse();
                
                s.setId(rs.getString(1));
                s.setEname(rs.getString(2));
                s.setTname(rs.getString(3));
                s.setType1(rs.getString(4));
                s.setType2(rs.getString(5));
                s.setTotalCredit(rs.getInt(7));
                s.setTotalYear(rs.getInt(8));                
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return s;                    
    }
    
    public Course retrieveCourse(Course course, Major mj, Minor mn)
    {
        Course c = null;        
        
        try
        {
            String minorCondition = "";
            if(mn != null)
            {
                minorCondition = " and minor# = '" + mn.getId() + "'";
            }
            
            String query = "SELECT * FROM course WHERE st_degree = '" + course.getSTDegree() + "' and major# = '" + mj.getId() + "'" + minorCondition;
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {           
                c = new Course();
                
                c.setId(rs.getString(1));
                c.setEname(rs.getString(2));
                c.setTname(rs.getString(3));
                c.setFTDegree(rs.getString(4));
                c.setFEDegree(rs.getString(5));
                c.setSTDegree(rs.getString(6));
                c.setSEDegree(rs.getString(7));
                c.setDegree(rs.getString(8));
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return c;        
    }
    
    public Vector retrieveCourse(String courseID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM course WHERE co# = " + courseID;            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Course c = new Course();  
                
                c.setId(rs.getString(1));
                c.setEname(rs.getString(2));
                c.setTname(rs.getString(3));
                c.setFTDegree(rs.getString(4));
                c.setFEDegree(rs.getString(5));
                c.setSTDegree(rs.getString(6));
                c.setSEDegree(rs.getString(7));
                c.setDegree(rs.getString(8));
                
                v.addElement(c);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
    
    public Vector retrieveAllCourse()
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM course";            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {
                Course c = new Course();  
                
                c.setId(rs.getString(1));
                c.setEname(rs.getString(2));
                c.setTname(rs.getString(3));
                c.setFTDegree(rs.getString(4));
                c.setFEDegree(rs.getString(5));
                c.setSTDegree(rs.getString(6));
                c.setSEDegree(rs.getString(7));
                c.setDegree(rs.getString(8));
                
                v.addElement(c);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    }
    
    public boolean addCourse(Course c, Major mj, Minor mn)
    {
        String minorHead = "";
        String minor = "";
        if(mn != null)
        {
            minorHead = ", minor#";
            minor = "', '" + mn.getId();
        }
        
        String query = "INSERT INTO course(ename, tname, ft_degree, fe_degree, st_degree, se_degree, degree, major#" + minorHead + ") " +
                       "VALUES('" + c.getEname() + "', '" + c.getTname() + "', '" + c.getFTDegree() + "', '" + c.getFEDegree() + "', '" + c.getSTDegree() + "', '" + c.getSEDegree() + "', '" + c.getDegree() + "', '" + mj.getId() + minor + "')";        
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean deleteCourse(Course c)
    {
        String query = "DELETE FROM course " +
                       "WHERE co# = " + c.getId();

        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;        
    }
    
    public boolean updateCourse(Course c)
    {
        String query = "UPDATE course " +
                       "SET " +
                       "ename = '" + c.getEname() + "', " +
                       "tname = '" + c.getTname() + "', " +
                       "ft_degree = '" + c.getFTDegree() + "', " +
                       "fe_degree = '" + c.getFEDegree() + "', " +
                       "st_degree = '" + c.getSTDegree() + "', " +
                       "se_degree = '" + c.getSEDegree() + "', " +
                       "degree = '" + c.getDegree() + "' " +
                       "WHERE co# = " + c.getId();
        
        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;                        
    }
    
    public boolean addSubCourse(SubCourse s, Course c)
    {
        String query = "INSERT INTO subcourse(ename, tname, std_type, sec_type, co#, total_credit, total_year) " +
                    "VALUES('" + s.getEname() + "', '" + s.getTname() + "', '" + s.getType1() + "', '" + s.getType2() + "', " + c.getId() + ", " + s.getTotalCredit() + ", " + s.getTotalYear() + ")";

        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;                
    }
    
    public boolean deleteSubCourse(SubCourse s)
    {
        String query = "DELETE FROM subcourse " +
                       "WHERE sco# = " + s.getId();

        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;        
    }
    
    public boolean updateSubCourse(SubCourse s)
    {
        String query = "UPDATE subcourse " +
                       "SET " +
                       "ename = '" + s.getEname() + "', " +
                       "tname = '" + s.getTname() + "', " +
                       "std_type = '" + s.getType1() + "', " +
                       "sec_type = '" + s.getType2() + "', " +
                       "total_credit = " + s.getTotalCredit() + " " +
                       "WHERE sco# = " + s.getId();
        
        if(DB.update(query) == 0)
        {
           return false;
        }
        
        return true;                
    }
}
