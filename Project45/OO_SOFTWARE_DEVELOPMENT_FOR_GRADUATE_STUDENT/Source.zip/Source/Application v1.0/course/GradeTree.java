/*
 * GradeTree.java
 *
 * Created on 4 �ѹ�Ҥ� 2545, 17:12 �.
 */

package course;

import utility.*;
import java.util.*;
import javax.swing.tree.*;

/**
 *
 * @author  KUKI
 */
public class GradeTree 
{
    private DefaultMutableTreeNode gradeNode;    
    private Tree tree;
    
    /** Creates a new instance of GradeTree */
    public GradeTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveGradeInfo()
    {
        HandleGrade hGrade = new HandleGrade();
        Vector v = hGrade.retrieveAllGrade();
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Grade g = (Grade)e.nextElement();
            
            if(!g.getGrade().equals("X")) gradeNode = tree.addObject(null, g);
        }
    }      
}
