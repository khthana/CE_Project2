/*
 * DoctorCourse.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 18:18 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class DoctorCourse extends Course
{    
    protected String research_credit;
    
    /** Creates a new instance of DoctorCourse */
    public DoctorCourse() 
    {
    }
    
    public void setResearchCredit(String research_credit)
    {
        this.research_credit = research_credit;
    }
    
    public String getResearchCredit()
    {
        return this.research_credit;
    }
    
    public String toString()
    {
        return "��ѡ�ٵ� " + super.st_degree;
    }
}
