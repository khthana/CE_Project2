/*
 * MasterCourse.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 18:15 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class MasterCourse extends Course
{    
    /** Creates a new instance of MasterCourse */
    public MasterCourse() 
    {
    }
    
    public boolean checkTotalYear(int year)
    {       
        return (year <= 5) ? true : false;
    }
    
    public String toString()
    {
        return "��ѡ�ٵ� " + super.st_degree;
    }    
}
