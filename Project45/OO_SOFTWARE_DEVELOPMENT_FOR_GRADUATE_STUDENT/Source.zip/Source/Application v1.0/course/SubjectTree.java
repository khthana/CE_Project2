/*
 * SubjectTree.java
 *
 * Created on 23 ��Ȩԡ�¹ 2545, 18:01 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class SubjectTree 
{
    private DefaultMutableTreeNode subjectGroupNode;
    private DefaultMutableTreeNode subjectSectionNode;
    private DefaultMutableTreeNode subjectPrerequisiteNode;
    private DefaultMutableTreeNode subjectNode;
    private Tree tree;
    
    /** Creates a new instance of SubjectTree */
    public SubjectTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveAllSubjectInGroup(Course course, SubCourse subcourse, String group)
    {
        HandleSubject hSubject = new HandleSubject();                
        Vector v = hSubject.retrieveAllSubject(course.getId(), subcourse.getId(), group);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Subject subject = (Subject)e.nextElement();        
            subjectNode = tree.addObject(subjectGroupNode, subject);
            
            // get section
            subjectSectionNode = tree.addObject(subjectNode, "�礪��");
            SectionTree sTree = new SectionTree(tree);
            sTree.setNode(subjectSectionNode);
            sTree.retrieveAllSection(subject);
            
            // get prerequisite
            subjectPrerequisiteNode = tree.addObject(subjectNode, "����ԪҺѧ�Ѻ��͹");
            
            if(subject.getPrerequisite() != null)
            {
                PrerequisiteTree preTree = new PrerequisiteTree(tree);
                preTree.setNode(subjectPrerequisiteNode);
                preTree.retrieveCourseworkPrerequisite(subject);                
            }
        }           
    }
    
    public void setNode(DefaultMutableTreeNode subjectGroupNode)
    {
        this.subjectGroupNode = subjectGroupNode;
    }   
}
