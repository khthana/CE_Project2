/*
 * CourseTree.java
 *
 * Created on 28 ���Ҥ� 2546, 14:31 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class CourseTree 
{
    private DefaultMutableTreeNode courseNode;
    private DefaultMutableTreeNode minorNode;
    private Tree tree;
    
    /** Creates a new instance of CourseTree */
    public CourseTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveCourseInfo(Major major)
    {
        HandleCourse hCourse = new HandleCourse();                
        Vector v = hCourse.retrieveMasterCourse(major);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            MasterCourse mCourse = (MasterCourse)e.nextElement();        
            courseNode = tree.addObject(null, mCourse);
            
            SubCourseTree sbTree = new SubCourseTree(tree);
            sbTree.setNode(courseNode);            
            sbTree.retrieveSubCourseInfo(mCourse);
        }
        
        v = hCourse.retrieveDoctorCourse(major);
        e = v.elements();
        
        while(e.hasMoreElements())
        {
            DoctorCourse dCourse = (DoctorCourse)e.nextElement();
            courseNode = tree.addObject(null, dCourse);
            
            SubCourseTree sbTree = new SubCourseTree(tree);
            sbTree.setNode(courseNode);            
            sbTree.retrieveSubCourseInfo(dCourse);            
        }
    }
    
    public void retrieveCourseInfo(Major major, Minor minor)
    {
        HandleCourse hCourse = new HandleCourse();                
        Vector v = hCourse.retrieveMasterCourse(major, minor);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            MasterCourse mCourse = (MasterCourse)e.nextElement();        
            courseNode = tree.addObject(null, mCourse);
            
            SubCourseTree sbTree = new SubCourseTree(tree);
            sbTree.setNode(courseNode);            
            sbTree.retrieveSubCourseInfo(mCourse);
        }
        
        v = hCourse.retrieveDoctorCourse(major, minor);
        e = v.elements();
        
        while(e.hasMoreElements())
        {
            DoctorCourse dCourse = (DoctorCourse)e.nextElement();
            courseNode = tree.addObject(null, dCourse);
            
            SubCourseTree sbTree = new SubCourseTree(tree);
            sbTree.setNode(courseNode);            
            sbTree.retrieveSubCourseInfo(dCourse);            
        }
    }
    
    public void setNode(DefaultMutableTreeNode minorNode)
    {
        this.minorNode = minorNode;
    }    
}
