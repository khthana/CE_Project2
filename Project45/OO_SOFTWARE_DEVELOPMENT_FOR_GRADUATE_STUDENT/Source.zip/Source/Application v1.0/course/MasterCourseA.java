/*
 * MasterCourseA.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 18:21 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class MasterCourseA extends MasterCourse
{
    protected String research_credit;    
    
    /** Creates a new instance of MasterCourseA */
    public MasterCourseA() 
    {
    }
    
    public void setResearchCredit(String research_credit)
    {
        this.research_credit = research_credit;
    }
    
    public String getResearchCredit()
    {
        return this.research_credit;
    }       
}
