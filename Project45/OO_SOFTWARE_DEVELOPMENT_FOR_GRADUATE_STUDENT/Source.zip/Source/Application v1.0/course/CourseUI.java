/*
 * CourseUI.java
 *
 * Created on 27 ���Ҥ� 2546, 0:59 �.
 */

package course;

import javax.swing.tree.*;
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreeSelectionModel;
import java.util.*;
import java.text.*;
import utility.*;
import course.*;
import organize.*;
import cost.*;

/**
 *
 * @author  KUKI
 */
public class CourseUI extends javax.swing.JFrame 
{
    private DefaultMutableTreeNode root;
    private CourseTree cTree;    
    private Tree tree;
    
    private CardLayout cardManager;
    private Component parent;
    private SubCourse subcourse;
    private String year;
    private String semester;
    private Major major;
    private Minor minor;
    
    /** Creates new form CourseUI */
    public CourseUI(Component parent, 
                    javax.swing.JComboBox cb1,
                    javax.swing.JComboBox cb2,
                    javax.swing.JComboBox cb3,
                    javax.swing.JComboBox cb4) 
    {
        initComponents();
        
        major = (Major)cb3.getSelectedItem();
        minor = (Minor)cb4.getSelectedItem();
        
        String type1[] = {"", "���ѭ", "���ͧ���¹"};
        String type2[] = {"", "����", "����", "����� - �ҷԵ��"};
        String degree[] = {"", "��ԭ���", "��ԭ���͡"};
        
        for(int i=0; i<degree.length; i++)
        {
            cbAddDegree.addItem(degree[i]);
            cbDegree.addItem(degree[i]);
        }                              
                              
        for(int i=0; i<type1.length; i++)
        {
            cbSubCourseType1.addItem(type1[i]);            
            cbAddSubCourseType1.addItem(type1[i]);
        }
        
        for(int i=0; i<type2.length; i++)
        {
            cbSubCourseType2.addItem(type2[i]);
            cbAddSubCourseType2.addItem(type2[i]);
        }
        
        if(minor == null)
        {
            root = new DefaultMutableTreeNode("�Ң�" + ((Major)cb3.getSelectedItem()).getTname());            
            tree = new Tree(root);
            cTree = new CourseTree(tree);  
            cTree.retrieveCourseInfo(major);                 
        }
        else
        {
            root = new DefaultMutableTreeNode("�Ң�" + ((Major)cb3.getSelectedItem()).getTname() + " ᢹ��Ԫ�" + ((Minor)cb4.getSelectedItem()).getTname());
            tree = new Tree(root);
            cTree = new CourseTree(tree);
            cTree.retrieveCourseInfo(major, minor);               
        }        
        
        this.parent = parent;
        tree.getTree().setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        cardManager = (CardLayout)mainPanel.getLayout();     
        jSplitPane.setOneTouchExpandable(true);  
        jSplitPane.setDividerLocation(200);        
        jScrollPane.setViewportView(tree.getTree());                        
        
        lbFaculty.setText(((Faculty)cb1.getSelectedItem()).getTname());
        lbDept.setText(((Department)cb2.getSelectedItem()).getTname());
        lbMajor.setText(((Major)cb3.getSelectedItem()).getTname());
        
        // Listen for when the selection changes
        tree.getTree().addTreeSelectionListener(new TreeSelectionListener() 
        {
            public void valueChanged(TreeSelectionEvent e) 
            {
               DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getTree().getLastSelectedPathComponent();

               if (node == null) return;

               Object nodeInfo = node.getUserObject();

               if(node.getLevel()==0) 
               {                        
                   cardManager.show(mainPanel, "courseMain");
               }
               else if(node.getLevel()==1)                        
               {
                   cardManager.show(mainPanel, "courseDetail");                   
                   Course course = (Course)nodeInfo;
                   
                   tfCourseEname.setText(course.getEname());
                   tfCourseTname.setText(course.getTname());
                   tfCourseFEDegree.setText(course.getFEDegree());
                   tfCourseFTDegree.setText(course.getFTDegree());
                   tfCourseSEDegree.setText(course.getSEDegree());
                   tfCourseSTDegree.setText(course.getSTDegree());
                   
                   switch(course.getDegree().charAt(0))
                   {
                       case 'M':
                           cbDegree.setSelectedIndex(1);
                           break;
                       case 'D':                           
                           cbDegree.setSelectedIndex(2);                       
                           break;
                       default:
                   }                   
               }
               else if(node.getLevel()==2)
               {
                   cardManager.show(mainPanel, "subCourseDetail");                   
                   SubCourse subCourse = (SubCourse)nodeInfo;
                   subcourse = subCourse;
                   
                   tfSubCourseEname.setText(subCourse.getEname());
                   tfSubCourseTname.setText(subCourse.getTname());
                   tfTotalSemester.setText(Integer.toString(subCourse.getTotalYear() * 2));
                   tfTotalCredit.setText(Integer.toString(subCourse.getTotalCredit()));
                   
                   switch(subCourse.getType1().charAt(0))
                   {
                       case 'C':
                           cbSubCourseType1.setSelectedIndex(1);
                           break;
                       case 'T':                           
                           cbSubCourseType1.setSelectedIndex(2);                       
                           break;
                       default:
                   }
                   
                   switch(subCourse.getType2().charAt(0))
                   {
                       case 'A':
                           cbSubCourseType2.setSelectedIndex(1);
                           break;
                       case 'B':
                           cbSubCourseType2.setSelectedIndex(2);                       
                           break;
                       case 'C':
                           cbSubCourseType2.setSelectedIndex(3);                       
                           break;
                       default:
                   }                   
               }
               else if(node.getLevel()==3)
               {
                   cbCourseworkID.removeAllItems();
                   cbCourseworkID.addItem(null);
                   
                   HandleSubject hSubject = new HandleSubject();
                   Course c = (Course)tree.getUserObject(2);
                   subcourse = (SubCourse)tree.getUserObject(1);
                   Vector allSubject = hSubject.retrieveAllSubject(c, subcourse);
                   Enumeration eSubject = allSubject.elements();                   
                   
                   while(eSubject.hasMoreElements())
                   {
                       Subject subject = (Subject)eSubject.nextElement();
                       cbCourseworkID.addItem(subject);
                   }                   
                   
                   cardManager.show(mainPanel, "courseworkInfo");                   
                   String s = (String)nodeInfo;
                   lbText.setText("����Ἱ����֡�� " + s);
                   lbSubCourse.setText(subcourse.getTname());
                   lbCoursework.setText("Ἱ����֡�� " + s);
                   
                   StringTokenizer st = new StringTokenizer(s," ");
                   s = st.nextToken();
                   s = st.nextToken();
                   year = s.trim();
                   s = st.nextToken();
                   s = st.nextToken();
                   semester = s.trim();                   
               }
               else if(node.getLevel()==4)
               {
                   cardManager.show(mainPanel, "courseworkSubjectDetail");                   
                   Subject subject = (Subject)nodeInfo;
                   
                   tfCWSubjectID.setText(subject.getId());
                   tfCWSubjectEname.setText(subject.getEname());
                   tfCWSubjectTname.setText(subject.getTname());
                   tfLectureCredit.setText(subject.getLecture());
                   tfPracticeCredit.setText(subject.getPractice());
                   tfReserchCredit.setText(subject.getResearch());                   
               }
            }
        });                        
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        jSplitPane = new javax.swing.JSplitPane();
        jScrollPane = new javax.swing.JScrollPane();
        mainPanel = new javax.swing.JPanel();
        courseMainPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        lbFaculty = new javax.swing.JLabel();
        lbDept = new javax.swing.JLabel();
        lbMajor = new javax.swing.JLabel();
        btAddCourse = new javax.swing.JButton();
        courseDetailPanel = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tfCourseEname = new javax.swing.JTextField();
        tfCourseTname = new javax.swing.JTextField();
        tfCourseFEDegree = new javax.swing.JTextField();
        tfCourseFTDegree = new javax.swing.JTextField();
        tfCourseSEDegree = new javax.swing.JTextField();
        tfCourseSTDegree = new javax.swing.JTextField();
        btEditCourse = new javax.swing.JButton();
        btDelCourse = new javax.swing.JButton();
        cbDegree = new javax.swing.JComboBox();
        jLabel713 = new javax.swing.JLabel();
        btAddSubCourse = new javax.swing.JButton();
        subCourseDetailPanel = new javax.swing.JPanel();
        jLabel111 = new javax.swing.JLabel();
        tfSubCourseEname = new javax.swing.JTextField();
        tfSubCourseTname = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        cbSubCourseType1 = new javax.swing.JComboBox();
        cbSubCourseType2 = new javax.swing.JComboBox();
        jLabel211 = new javax.swing.JLabel();
        jLabel212 = new javax.swing.JLabel();
        jLabel213 = new javax.swing.JLabel();
        tfTotalSemester = new javax.swing.JTextField();
        jLabel214 = new javax.swing.JLabel();
        btAllSubjectInSubcourse = new javax.swing.JButton();
        btEditSubCourse = new javax.swing.JButton();
        btDelSubCourse = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        tfTotalCredit = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        btSpecialCost = new javax.swing.JButton();
        courseworkDetail = new javax.swing.JPanel();
        jLabel1111 = new javax.swing.JLabel();
        jLabel2111 = new javax.swing.JLabel();
        jLabel311 = new javax.swing.JLabel();
        tfCWSubjectTname = new javax.swing.JTextField();
        tfCWSubjectEname = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tfCWSubjectID = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel121 = new javax.swing.JLabel();
        jLabel122 = new javax.swing.JLabel();
        tfLectureCredit = new javax.swing.JTextField();
        tfPracticeCredit = new javax.swing.JTextField();
        tfReserchCredit = new javax.swing.JTextField();
        btDelCoursework = new javax.swing.JButton();
        addCoursePanel = new javax.swing.JPanel();
        jLabel112 = new javax.swing.JLabel();
        tfAddCourseEname = new javax.swing.JTextField();
        tfAddCourseTname = new javax.swing.JTextField();
        tfAddCourseFEDegree = new javax.swing.JTextField();
        tfAddCourseFTDegree = new javax.swing.JTextField();
        tfAddCourseSEDegree = new javax.swing.JTextField();
        tfAddCourseSTDegree = new javax.swing.JTextField();
        jLabel71 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        btAddCourseOk = new javax.swing.JButton();
        btAddCourseCancel = new javax.swing.JButton();
        jLabel711 = new javax.swing.JLabel();
        cbAddDegree = new javax.swing.JComboBox();
        addSubCoursePanel = new javax.swing.JPanel();
        tfAddTotalCredit = new javax.swing.JTextField();
        jLabel91 = new javax.swing.JLabel();
        jLabel81 = new javax.swing.JLabel();
        jLabel2141 = new javax.swing.JLabel();
        tfAddTotalSemester = new javax.swing.JTextField();
        jLabel215 = new javax.swing.JLabel();
        cbAddSubCourseType2 = new javax.swing.JComboBox();
        jLabel2121 = new javax.swing.JLabel();
        jLabel2131 = new javax.swing.JLabel();
        cbAddSubCourseType1 = new javax.swing.JComboBox();
        tfAddSubCourseTname = new javax.swing.JTextField();
        jLabel312 = new javax.swing.JLabel();
        jLabel2112 = new javax.swing.JLabel();
        tfAddSubCourseEname = new javax.swing.JTextField();
        jLabel1112 = new javax.swing.JLabel();
        btAddSubCourseOk = new javax.swing.JButton();
        btAddSubCourseCancel = new javax.swing.JButton();
        addCourseworkPanel = new javax.swing.JPanel();
        jLabel101 = new javax.swing.JLabel();
        btAddCourseworkOk = new javax.swing.JButton();
        btAddCourseworkCancel = new javax.swing.JButton();
        cbCourseworkID = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        lbText = new javax.swing.JLabel();
        courseworkInfoPanel = new javax.swing.JPanel();
        lbSubCourse = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        btAddCoursework = new javax.swing.JButton();
        lbCoursework = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();

        setTitle("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23 - \u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32\u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jSplitPane.setLeftComponent(jScrollPane);

        mainPanel.setLayout(new java.awt.CardLayout());

        courseMainPanel.setLayout(null);

        courseMainPanel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        jLabel1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel1.setForeground(java.awt.Color.blue);
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        courseMainPanel.add(jLabel1);
        jLabel1.setBounds(130, 30, 300, 30);

        jLabel22.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel22.setForeground(java.awt.Color.blue);
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35\u0e1e\u0e23\u0e30\u0e08\u0e2d\u0e21\u0e40\u0e01\u0e25\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e04\u0e38\u0e13\u0e17\u0e2b\u0e32\u0e23\u0e25\u0e32\u0e14\u0e01\u0e23\u0e30\u0e1a\u0e31\u0e07");
        courseMainPanel.add(jLabel22);
        jLabel22.setBounds(80, 70, 390, 21);

        jLabel32.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel32.setForeground(java.awt.Color.red);
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        courseMainPanel.add(jLabel32);
        jLabel32.setBounds(200, 120, 150, 30);

        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        courseMainPanel.add(jLabel41);
        jLabel41.setBounds(210, 170, 130, 110);

        lbFaculty.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        lbFaculty.setForeground(java.awt.Color.red);
        lbFaculty.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbFaculty.setText("FACULTY");
        courseMainPanel.add(lbFaculty);
        lbFaculty.setBounds(150, 300, 260, 26);

        lbDept.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        lbDept.setForeground(java.awt.Color.red);
        lbDept.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbDept.setText("DEPARTMENT");
        courseMainPanel.add(lbDept);
        lbDept.setBounds(150, 340, 260, 26);

        lbMajor.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        lbMajor.setForeground(java.awt.Color.red);
        lbMajor.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbMajor.setText("MAJOR");
        courseMainPanel.add(lbMajor);
        lbMajor.setBounds(150, 380, 260, 26);

        btAddCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCourse.setForeground(java.awt.Color.darkGray);
        btAddCourse.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        btAddCourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseActionPerformed(evt);
            }
        });

        courseMainPanel.add(btAddCourse);
        btAddCourse.setBounds(210, 450, 150, 24);

        mainPanel.add(courseMainPanel, "courseMain");

        courseDetailPanel.setLayout(null);

        jLabel11.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel11.setForeground(java.awt.Color.blue);
        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setText("\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        courseDetailPanel.add(jLabel11);
        jLabel11.setBounds(180, 30, 180, 30);

        jLabel2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2.setForeground(java.awt.Color.darkGray);
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        courseDetailPanel.add(jLabel2);
        jLabel2.setBounds(20, 100, 130, 23);

        jLabel3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3.setForeground(java.awt.Color.darkGray);
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        courseDetailPanel.add(jLabel3);
        jLabel3.setBounds(20, 130, 130, 23);

        jLabel4.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel4.setForeground(java.awt.Color.darkGray);
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        courseDetailPanel.add(jLabel4);
        jLabel4.setBounds(20, 160, 130, 23);

        jLabel5.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel5.setForeground(java.awt.Color.darkGray);
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel5.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        courseDetailPanel.add(jLabel5);
        jLabel5.setBounds(20, 190, 130, 23);

        jLabel6.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel6.setForeground(java.awt.Color.darkGray);
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel6.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e22\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        courseDetailPanel.add(jLabel6);
        jLabel6.setBounds(20, 220, 130, 23);

        jLabel7.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel7.setForeground(java.awt.Color.darkGray);
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e22\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        courseDetailPanel.add(jLabel7);
        jLabel7.setBounds(20, 250, 130, 23);

        tfCourseEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(tfCourseEname);
        tfCourseEname.setBounds(160, 100, 370, 23);

        tfCourseTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(tfCourseTname);
        tfCourseTname.setBounds(160, 130, 370, 23);

        tfCourseFEDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(tfCourseFEDegree);
        tfCourseFEDegree.setBounds(160, 160, 370, 23);

        tfCourseFTDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(tfCourseFTDegree);
        tfCourseFTDegree.setBounds(160, 190, 370, 23);

        tfCourseSEDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(tfCourseSEDegree);
        tfCourseSEDegree.setBounds(160, 220, 370, 23);

        tfCourseSTDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(tfCourseSTDegree);
        tfCourseSTDegree.setBounds(160, 250, 370, 23);

        btEditCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btEditCourse.setForeground(java.awt.Color.darkGray);
        btEditCourse.setText("\u0e41\u0e01\u0e49\u0e44\u0e02\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        btEditCourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btEditCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditCourseActionPerformed(evt);
            }
        });

        courseDetailPanel.add(btEditCourse);
        btEditCourse.setBounds(220, 390, 120, 24);

        btDelCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelCourse.setForeground(java.awt.Color.darkGray);
        btDelCourse.setText("\u0e25\u0e1a\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        btDelCourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelCourseActionPerformed(evt);
            }
        });

        courseDetailPanel.add(btDelCourse);
        btDelCourse.setBounds(360, 390, 120, 24);

        cbDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseDetailPanel.add(cbDegree);
        cbDegree.setBounds(160, 280, 110, 23);

        jLabel713.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel713.setForeground(java.awt.Color.darkGray);
        jLabel713.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel713.setText("\u0e23\u0e30\u0e14\u0e31\u0e1a");
        courseDetailPanel.add(jLabel713);
        jLabel713.setBounds(20, 280, 130, 23);

        btAddSubCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSubCourse.setForeground(java.awt.Color.darkGray);
        btAddSubCourse.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        btAddSubCourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSubCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSubCourseActionPerformed(evt);
            }
        });

        courseDetailPanel.add(btAddSubCourse);
        btAddSubCourse.setBounds(80, 390, 120, 24);

        mainPanel.add(courseDetailPanel, "courseDetail");

        subCourseDetailPanel.setLayout(null);

        jLabel111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel111.setForeground(java.awt.Color.blue);
        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel111.setText("\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        subCourseDetailPanel.add(jLabel111);
        jLabel111.setBounds(150, 30, 180, 30);

        tfSubCourseEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        subCourseDetailPanel.add(tfSubCourseEname);
        tfSubCourseEname.setBounds(160, 100, 250, 23);

        tfSubCourseTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        subCourseDetailPanel.add(tfSubCourseTname);
        tfSubCourseTname.setBounds(160, 130, 250, 23);

        jLabel31.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31.setForeground(java.awt.Color.darkGray);
        jLabel31.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        subCourseDetailPanel.add(jLabel31);
        jLabel31.setBounds(20, 130, 130, 23);

        jLabel21.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel21.setForeground(java.awt.Color.darkGray);
        jLabel21.setText("(\u0e20\u0e32\u0e04\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32)");
        subCourseDetailPanel.add(jLabel21);
        jLabel21.setBounds(240, 220, 80, 23);

        cbSubCourseType1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        subCourseDetailPanel.add(cbSubCourseType1);
        cbSubCourseType1.setBounds(160, 160, 160, 23);

        cbSubCourseType2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        subCourseDetailPanel.add(cbSubCourseType2);
        cbSubCourseType2.setBounds(160, 190, 160, 23);

        jLabel211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel211.setForeground(java.awt.Color.darkGray);
        jLabel211.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        subCourseDetailPanel.add(jLabel211);
        jLabel211.setBounds(20, 100, 130, 23);

        jLabel212.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel212.setForeground(java.awt.Color.darkGray);
        jLabel212.setText("\u0e1b\u0e23\u0e30\u0e40\u0e20\u0e17\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        subCourseDetailPanel.add(jLabel212);
        jLabel212.setBounds(20, 190, 130, 23);

        jLabel213.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel213.setForeground(java.awt.Color.darkGray);
        jLabel213.setText("\u0e0a\u0e19\u0e34\u0e14\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        subCourseDetailPanel.add(jLabel213);
        jLabel213.setBounds(20, 160, 130, 23);

        tfTotalSemester.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfTotalSemester.setDisabledTextColor(java.awt.Color.black);
        tfTotalSemester.setEnabled(false);
        subCourseDetailPanel.add(tfTotalSemester);
        tfTotalSemester.setBounds(160, 220, 63, 23);

        jLabel214.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel214.setForeground(java.awt.Color.darkGray);
        jLabel214.setText("\u0e23\u0e30\u0e22\u0e30\u0e40\u0e27\u0e25\u0e32\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        subCourseDetailPanel.add(jLabel214);
        jLabel214.setBounds(20, 220, 130, 23);

        btAllSubjectInSubcourse.setBackground(new java.awt.Color(0, 204, 204));
        btAllSubjectInSubcourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAllSubjectInSubcourse.setForeground(java.awt.Color.darkGray);
        btAllSubjectInSubcourse.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14\u0e43\u0e19\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        btAllSubjectInSubcourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAllSubjectInSubcourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAllSubjectInSubcourseActionPerformed(evt);
            }
        });

        subCourseDetailPanel.add(btAllSubjectInSubcourse);
        btAllSubjectInSubcourse.setBounds(20, 380, 220, 24);

        btEditSubCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btEditSubCourse.setForeground(java.awt.Color.darkGray);
        btEditSubCourse.setText("\u0e41\u0e01\u0e49\u0e44\u0e02\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        btEditSubCourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btEditSubCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditSubCourseActionPerformed(evt);
            }
        });

        subCourseDetailPanel.add(btEditSubCourse);
        btEditSubCourse.setBounds(20, 340, 220, 24);

        btDelSubCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelSubCourse.setForeground(java.awt.Color.darkGray);
        btDelSubCourse.setText("\u0e25\u0e1a\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        btDelSubCourse.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelSubCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelSubCourseActionPerformed(evt);
            }
        });

        subCourseDetailPanel.add(btDelSubCourse);
        btDelSubCourse.setBounds(260, 340, 220, 24);

        jLabel8.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel8.setForeground(java.awt.Color.darkGray);
        jLabel8.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e23\u0e27\u0e21");
        subCourseDetailPanel.add(jLabel8);
        jLabel8.setBounds(20, 250, 90, 23);

        tfTotalCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        subCourseDetailPanel.add(tfTotalCredit);
        tfTotalCredit.setBounds(160, 250, 63, 23);

        jLabel9.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel9.setForeground(java.awt.Color.darkGray);
        jLabel9.setText("(\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15)");
        subCourseDetailPanel.add(jLabel9);
        jLabel9.setBounds(240, 250, 80, 23);

        btSpecialCost.setBackground(new java.awt.Color(0, 204, 204));
        btSpecialCost.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btSpecialCost.setForeground(java.awt.Color.darkGray);
        btSpecialCost.setText("\u0e23\u0e32\u0e22\u0e01\u0e32\u0e23\u0e04\u0e48\u0e32\u0e43\u0e0a\u0e49\u0e08\u0e48\u0e32\u0e22\u0e40\u0e09\u0e1e\u0e32\u0e30");
        btSpecialCost.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btSpecialCost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSpecialCostActionPerformed(evt);
            }
        });

        subCourseDetailPanel.add(btSpecialCost);
        btSpecialCost.setBounds(260, 380, 220, 24);

        mainPanel.add(subCourseDetailPanel, "subCourseDetail");

        courseworkDetail.setLayout(null);

        jLabel1111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel1111.setForeground(java.awt.Color.blue);
        jLabel1111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1111.setText("\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel1111);
        jLabel1111.setBounds(150, 30, 180, 30);

        jLabel2111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2111.setForeground(java.awt.Color.darkGray);
        jLabel2111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2111.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        courseworkDetail.add(jLabel2111);
        jLabel2111.setBounds(20, 130, 110, 23);

        jLabel311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel311.setForeground(java.awt.Color.darkGray);
        jLabel311.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel311.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        courseworkDetail.add(jLabel311);
        jLabel311.setBounds(20, 160, 110, 23);

        tfCWSubjectTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfCWSubjectTname);
        tfCWSubjectTname.setBounds(160, 160, 300, 23);

        tfCWSubjectEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfCWSubjectEname);
        tfCWSubjectEname.setBounds(160, 130, 300, 23);

        jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel10.setForeground(java.awt.Color.darkGray);
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel10);
        jLabel10.setBounds(20, 100, 110, 23);

        tfCWSubjectID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfCWSubjectID);
        tfCWSubjectID.setBounds(160, 100, 140, 23);

        jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12.setForeground(java.awt.Color.darkGray);
        jLabel12.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e04\u0e49\u0e19\u0e04\u0e27\u0e49\u0e32");
        courseworkDetail.add(jLabel12);
        jLabel12.setBounds(20, 250, 110, 23);

        jLabel121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel121.setForeground(java.awt.Color.darkGray);
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel121.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1a\u0e23\u0e23\u0e22\u0e32\u0e22");
        courseworkDetail.add(jLabel121);
        jLabel121.setBounds(20, 190, 110, 23);

        jLabel122.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel122.setForeground(java.awt.Color.darkGray);
        jLabel122.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel122.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1b\u0e0f\u0e34\u0e1a\u0e31\u0e15\u0e34");
        courseworkDetail.add(jLabel122);
        jLabel122.setBounds(20, 220, 110, 23);

        tfLectureCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfLectureCredit);
        tfLectureCredit.setBounds(160, 190, 60, 23);

        tfPracticeCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfPracticeCredit);
        tfPracticeCredit.setBounds(160, 220, 60, 23);

        tfReserchCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfReserchCredit);
        tfReserchCredit.setBounds(160, 250, 60, 23);

        btDelCoursework.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelCoursework.setForeground(java.awt.Color.darkGray);
        btDelCoursework.setText("\u0e25\u0e1a\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e2d\u0e2d\u0e01\u0e08\u0e32\u0e01\u0e41\u0e1c\u0e19\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        btDelCoursework.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelCoursework.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelCourseworkActionPerformed(evt);
            }
        });

        courseworkDetail.add(btDelCoursework);
        btDelCoursework.setBounds(140, 330, 200, 24);

        mainPanel.add(courseworkDetail, "courseworkSubjectDetail");

        addCoursePanel.setLayout(null);

        jLabel112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel112.setForeground(java.awt.Color.blue);
        jLabel112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel112.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        addCoursePanel.add(jLabel112);
        jLabel112.setBounds(180, 30, 180, 30);

        tfAddCourseEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(tfAddCourseEname);
        tfAddCourseEname.setBounds(160, 100, 370, 23);

        tfAddCourseTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(tfAddCourseTname);
        tfAddCourseTname.setBounds(160, 130, 370, 23);

        tfAddCourseFEDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(tfAddCourseFEDegree);
        tfAddCourseFEDegree.setBounds(160, 160, 370, 23);

        tfAddCourseFTDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(tfAddCourseFTDegree);
        tfAddCourseFTDegree.setBounds(160, 190, 370, 23);

        tfAddCourseSEDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(tfAddCourseSEDegree);
        tfAddCourseSEDegree.setBounds(160, 220, 370, 23);

        tfAddCourseSTDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(tfAddCourseSTDegree);
        tfAddCourseSTDegree.setBounds(160, 250, 370, 23);

        jLabel71.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel71.setForeground(java.awt.Color.blue);
        jLabel71.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel71.setText("\u0e23\u0e30\u0e14\u0e31\u0e1a");
        addCoursePanel.add(jLabel71);
        jLabel71.setBounds(20, 280, 130, 23);

        jLabel61.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel61.setForeground(java.awt.Color.darkGray);
        jLabel61.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel61.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e22\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        addCoursePanel.add(jLabel61);
        jLabel61.setBounds(20, 220, 130, 23);

        jLabel51.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel51.setForeground(java.awt.Color.darkGray);
        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel51.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        addCoursePanel.add(jLabel51);
        jLabel51.setBounds(20, 190, 130, 23);

        jLabel42.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel42.setForeground(java.awt.Color.darkGray);
        jLabel42.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel42.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        addCoursePanel.add(jLabel42);
        jLabel42.setBounds(20, 160, 130, 23);

        jLabel33.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel33.setForeground(java.awt.Color.darkGray);
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel33.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        addCoursePanel.add(jLabel33);
        jLabel33.setBounds(20, 130, 130, 23);

        jLabel23.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel23.setForeground(java.awt.Color.darkGray);
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel23.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        addCoursePanel.add(jLabel23);
        jLabel23.setBounds(20, 100, 130, 23);

        btAddCourseOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCourseOk.setForeground(java.awt.Color.darkGray);
        btAddCourseOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddCourseOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCourseOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseOkActionPerformed(evt);
            }
        });

        addCoursePanel.add(btAddCourseOk);
        btAddCourseOk.setBounds(160, 400, 90, 24);

        btAddCourseCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCourseCancel.setForeground(java.awt.Color.darkGray);
        btAddCourseCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btAddCourseCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCourseCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseCancelActionPerformed(evt);
            }
        });

        addCoursePanel.add(btAddCourseCancel);
        btAddCourseCancel.setBounds(280, 400, 90, 24);

        jLabel711.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel711.setForeground(java.awt.Color.blue);
        jLabel711.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel711.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e22\u0e48\u0e2d\u0e1b\u0e23\u0e34\u0e0d\u0e0d\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        addCoursePanel.add(jLabel711);
        jLabel711.setBounds(20, 250, 130, 23);

        cbAddDegree.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCoursePanel.add(cbAddDegree);
        cbAddDegree.setBounds(160, 280, 110, 23);

        mainPanel.add(addCoursePanel, "addCourse");

        addSubCoursePanel.setLayout(null);

        tfAddTotalCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSubCoursePanel.add(tfAddTotalCredit);
        tfAddTotalCredit.setBounds(160, 250, 63, 23);

        jLabel91.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel91.setForeground(java.awt.Color.darkGray);
        jLabel91.setText("(\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15)");
        addSubCoursePanel.add(jLabel91);
        jLabel91.setBounds(240, 250, 80, 23);

        jLabel81.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel81.setForeground(java.awt.Color.darkGray);
        jLabel81.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e23\u0e27\u0e21");
        addSubCoursePanel.add(jLabel81);
        jLabel81.setBounds(20, 250, 90, 23);

        jLabel2141.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2141.setForeground(java.awt.Color.blue);
        jLabel2141.setText("\u0e23\u0e30\u0e22\u0e30\u0e40\u0e27\u0e25\u0e32\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        addSubCoursePanel.add(jLabel2141);
        jLabel2141.setBounds(20, 220, 130, 23);

        tfAddTotalSemester.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSubCoursePanel.add(tfAddTotalSemester);
        tfAddTotalSemester.setBounds(160, 220, 63, 23);

        jLabel215.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel215.setForeground(java.awt.Color.darkGray);
        jLabel215.setText("(\u0e1b\u0e35\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32)");
        addSubCoursePanel.add(jLabel215);
        jLabel215.setBounds(240, 220, 80, 23);

        cbAddSubCourseType2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSubCoursePanel.add(cbAddSubCourseType2);
        cbAddSubCourseType2.setBounds(160, 190, 160, 23);

        jLabel2121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2121.setForeground(java.awt.Color.blue);
        jLabel2121.setText("\u0e1b\u0e23\u0e30\u0e40\u0e20\u0e17\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        addSubCoursePanel.add(jLabel2121);
        jLabel2121.setBounds(20, 190, 130, 23);

        jLabel2131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2131.setForeground(java.awt.Color.blue);
        jLabel2131.setText("\u0e0a\u0e19\u0e34\u0e14\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        addSubCoursePanel.add(jLabel2131);
        jLabel2131.setBounds(20, 160, 130, 23);

        cbAddSubCourseType1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSubCoursePanel.add(cbAddSubCourseType1);
        cbAddSubCourseType1.setBounds(160, 160, 160, 23);

        tfAddSubCourseTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSubCoursePanel.add(tfAddSubCourseTname);
        tfAddSubCourseTname.setBounds(160, 130, 250, 23);

        jLabel312.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel312.setForeground(java.awt.Color.blue);
        jLabel312.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        addSubCoursePanel.add(jLabel312);
        jLabel312.setBounds(20, 130, 130, 23);

        jLabel2112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2112.setForeground(java.awt.Color.darkGray);
        jLabel2112.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        addSubCoursePanel.add(jLabel2112);
        jLabel2112.setBounds(20, 100, 130, 23);

        tfAddSubCourseEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSubCoursePanel.add(tfAddSubCourseEname);
        tfAddSubCourseEname.setBounds(160, 100, 250, 23);

        jLabel1112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel1112.setForeground(java.awt.Color.blue);
        jLabel1112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1112.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        addSubCoursePanel.add(jLabel1112);
        jLabel1112.setBounds(150, 30, 180, 30);

        btAddSubCourseOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSubCourseOk.setForeground(java.awt.Color.darkGray);
        btAddSubCourseOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddSubCourseOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSubCourseOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSubCourseOkActionPerformed(evt);
            }
        });

        addSubCoursePanel.add(btAddSubCourseOk);
        btAddSubCourseOk.setBounds(130, 330, 90, 24);

        btAddSubCourseCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSubCourseCancel.setForeground(java.awt.Color.darkGray);
        btAddSubCourseCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btAddSubCourseCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSubCourseCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSubCourseCancelActionPerformed(evt);
            }
        });

        addSubCoursePanel.add(btAddSubCourseCancel);
        btAddSubCourseCancel.setBounds(250, 330, 90, 24);

        mainPanel.add(addSubCoursePanel, "addSubCourse");

        addCourseworkPanel.setLayout(null);

        jLabel101.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel101.setForeground(java.awt.Color.darkGray);
        jLabel101.setText("\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        addCourseworkPanel.add(jLabel101);
        jLabel101.setBounds(30, 110, 60, 26);

        btAddCourseworkOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCourseworkOk.setForeground(java.awt.Color.darkGray);
        btAddCourseworkOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddCourseworkOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCourseworkOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseworkOkActionPerformed(evt);
            }
        });

        addCourseworkPanel.add(btAddCourseworkOk);
        btAddCourseworkOk.setBounds(180, 230, 90, 24);

        btAddCourseworkCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCourseworkCancel.setForeground(java.awt.Color.darkGray);
        btAddCourseworkCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btAddCourseworkCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCourseworkCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseworkCancelActionPerformed(evt);
            }
        });

        addCourseworkPanel.add(btAddCourseworkCancel);
        btAddCourseworkCancel.setBounds(300, 230, 90, 24);

        cbCourseworkID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(cbCourseworkID);
        cbCourseworkID.setBounds(110, 110, 400, 26);

        jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel13.setForeground(java.awt.Color.red);
        jLabel13.setText("\u0e2b\u0e21\u0e32\u0e22\u0e40\u0e2b\u0e15\u0e38 : \u0e40\u0e25\u0e37\u0e2d\u0e01\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e17\u0e35\u0e48\u0e15\u0e49\u0e2d\u0e07\u0e01\u0e32\u0e23\u0e40\u0e1e\u0e37\u0e48\u0e2d\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e43\u0e19\u0e41\u0e1c\u0e19\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        addCourseworkPanel.add(jLabel13);
        jLabel13.setBounds(110, 160, 330, 26);

        lbText.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbText.setForeground(java.awt.Color.blue);
        lbText.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbText.setText("TEXT");
        addCourseworkPanel.add(lbText);
        lbText.setBounds(50, 40, 470, 30);

        mainPanel.add(addCourseworkPanel, "addCoursework");

        courseworkInfoPanel.setLayout(null);

        lbSubCourse.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbSubCourse.setForeground(java.awt.Color.blue);
        lbSubCourse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbSubCourse.setText("SUBCOURSE");
        courseworkInfoPanel.add(lbSubCourse);
        lbSubCourse.setBounds(30, 210, 470, 30);

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        courseworkInfoPanel.add(jLabel14);
        jLabel14.setBounds(190, 30, 150, 110);

        btAddCoursework.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCoursework.setForeground(java.awt.Color.darkGray);
        btAddCoursework.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e43\u0e19\u0e41\u0e1c\u0e19\u0e01\u0e32\u0e23\u0e28\u0e36\u0e01\u0e29\u0e32");
        btAddCoursework.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCoursework.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseworkActionPerformed(evt);
            }
        });

        courseworkInfoPanel.add(btAddCoursework);
        btAddCoursework.setBounds(180, 290, 180, 24);

        lbCoursework.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbCoursework.setForeground(java.awt.Color.blue);
        lbCoursework.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbCoursework.setText("TEXT");
        courseworkInfoPanel.add(lbCoursework);
        lbCoursework.setBounds(30, 160, 470, 30);

        mainPanel.add(courseworkInfoPanel, "courseworkInfo");

        jSplitPane.setRightComponent(mainPanel);

        getContentPane().add(jSplitPane, java.awt.BorderLayout.CENTER);

        jMenu1.setForeground(java.awt.Color.darkGray);
        jMenu1.setText("\u0e40\u0e21\u0e19\u0e39");
        jMenu1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuItem1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuItem1.setForeground(java.awt.Color.darkGray);
        jMenuItem1.setText("\u0e2d\u0e2d\u0e01\u0e08\u0e32\u0e01\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });

        jMenu1.add(jMenuItem1);
        jMenuBar1.add(jMenu1);
        jMenu2.setForeground(java.awt.Color.darkGray);
        jMenu2.setText("\u0e04\u0e33\u0e41\u0e19\u0e30\u0e19\u0e33");
        jMenu2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuItem2.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuItem2.setForeground(java.awt.Color.darkGray);
        jMenuItem2.setText("\u0e01\u0e32\u0e23\u0e43\u0e0a\u0e49\u0e07\u0e32\u0e19");
        jMenuItem2.setEnabled(false);
        jMenu2.add(jMenuItem2);
        jMenuItem3.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuItem3.setForeground(java.awt.Color.darkGray);
        jMenuItem3.setText("\u0e40\u0e01\u0e35\u0e48\u0e22\u0e27\u0e01\u0e31\u0e1a\u0e42\u0e1b\u0e23\u0e41\u0e01\u0e23\u0e21");
        jMenuItem3.setEnabled(false);
        jMenu2.add(jMenuItem3);
        jMenuBar1.add(jMenu2);
        setJMenuBar(jMenuBar1);

        pack();
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setSize(new java.awt.Dimension(770, 586));
        setLocation((screenSize.width-770)/2,(screenSize.height-586)/2);
    }//GEN-END:initComponents

    private void btEditSubCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditSubCourseActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ�����䢢����� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {
            if(!tfSubCourseTname.getText().equals("") && cbSubCourseType1.getSelectedIndex() != 0 &&
               cbSubCourseType2.getSelectedIndex() != 0 && !tfTotalSemester.getText().equals(""))
            {
                SubCourse subcourse = (SubCourse)tree.getUserObject();                
                
                subcourse.setId(((SubCourse)tree.getUserObject()).getId());
                subcourse.setEname(tfSubCourseEname.getText());
                subcourse.setTname(tfSubCourseTname.getText());
            
                try
                {
                    subcourse.setTotalCredit(Integer.parseInt(tfTotalCredit.getText()));
                }
                catch(Exception ex)
                {
                    JOptionPane.showMessageDialog(null, "��سҡ�͡���������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                    return;
                }
            
                switch(cbSubCourseType1.getSelectedIndex())
                {
                    case 1:
                        subcourse.setType1("C");
                        break;
                    case 2:
                        subcourse.setType1("T");
                        break;
                    default:
                }
            
                switch(cbSubCourseType2.getSelectedIndex())
                {
                    case 1:
                        subcourse.setType2("A");
                        break;
                    case 2:
                        subcourse.setType2("B");
                        break;
                    case 3:
                        subcourse.setType2("C");
                        break;
                    default:
                }
            
                HandleCourse hCourse = new HandleCourse();
                if(hCourse.updateSubCourse(subcourse))
                {
                    // if update successful
                    tree.setUserObject(subcourse);
                    JOptionPane.showMessageDialog(null, "�����䢢���������������º����", "Message", JOptionPane.ERROR_MESSAGE);                                                                
                }
                else
                {
                    // update fail
                    JOptionPane.showMessageDialog(null, "�Դ��ͼԴ��Ҵ㹡����䢢�������ѡ�ٵ�����", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                    
            }            
        }
    }//GEN-LAST:event_btEditSubCourseActionPerformed

    private void btEditCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditCourseActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ�����䢢����� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {    
            if(!tfCourseSTDegree.getText().equals("") && cbDegree.getSelectedIndex() != 0)
            {
                Course course = (Course)tree.getUserObject();                
                
                course.setId(((Course)tree.getUserObject()).getId());
                course.setEname(tfCourseEname.getText());
                course.setTname(tfCourseTname.getText());
                course.setFTDegree(tfCourseFTDegree.getText());
                course.setFEDegree(tfCourseFEDegree.getText());
                course.setSTDegree(tfCourseSTDegree.getText());
                course.setSEDegree(tfCourseSEDegree.getText());            
            
                switch(cbDegree.getSelectedIndex())
                {
                    case 1:
                        course.setDegree("M");
                        break;
                    case 2:
                        course.setDegree("D");
                        break;
                    default:
                }            
            
                HandleCourse hCourse = new HandleCourse();
                if(hCourse.updateCourse(course))
                {
                    // if update successful
                    tree.setUserObject(course);
                    JOptionPane.showMessageDialog(null, "�����䢢���������������º����", "Message", JOptionPane.ERROR_MESSAGE);                                                                
                }
                else
                {
                    // update fail
                    JOptionPane.showMessageDialog(null, "�Դ��ͼԴ��Ҵ㹡����䢢�������ѡ�ٵ�", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                
                }            
            }
            else
            {
                JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                        
            }            
        }                
    }//GEN-LAST:event_btEditCourseActionPerformed

    private void btSpecialCostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSpecialCostActionPerformed
        // Add your handling code here:
        this.setEnabled(false);
        SpecialCostUI sCostUI = new SpecialCostUI(this, (SubCourse)tree.getUserObject());
        sCostUI.show();
    }//GEN-LAST:event_btSpecialCostActionPerformed

    private void btAllSubjectInSubcourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAllSubjectInSubcourseActionPerformed
        // Add your handling code here:
        this.setEnabled(false);
        SubjectUI subjectUI = new SubjectUI(this, (Course)tree.getUserObject(1), (SubCourse)tree.getUserObject());
        subjectUI.show();
    }//GEN-LAST:event_btAllSubjectInSubcourseActionPerformed

    private void btAddSubCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSubCourseActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "addSubCourse");
    }//GEN-LAST:event_btAddSubCourseActionPerformed

    private void btDelCourseworkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelCourseworkActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {    
            HandleSubject hSubject = new HandleSubject();    
            SubCourse subCourse = (SubCourse)tree.getUserObject(2);
            String s = (String)tree.getUserObject(1);
            
            hSubject.delCoursework(tfCWSubjectID.getText(), subCourse.getId());
            tree.removeCurrentNode();
            
            lbCoursework.setText(s);
            lbSubCourse.setText(subCourse.getTname());
            
            cardManager.show(mainPanel, "courseworkInfo");            
        }        
    }//GEN-LAST:event_btDelCourseworkActionPerformed

    private void btAddCourseworkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseworkActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "addCoursework"); 
    }//GEN-LAST:event_btAddCourseworkActionPerformed

    private void btAddCourseworkOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseworkOkActionPerformed
        // Add your handling code here:
        if(cbCourseworkID.getSelectedItem() != null)
        {
            HandleSubject hSubject = new HandleSubject();
            Subject subject = (Subject)cbCourseworkID.getSelectedItem();
            if(hSubject.addCoursework(subject.getId(), subcourse.getId(), semester, year))
            {
                // if insert successful
                cardManager.show(mainPanel, "courseworkInfo");
                tree.addObject(subject);
                cbCourseworkID.setSelectedIndex(0);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "����ԪҴѧ������������Ἱ������¹����", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��س����͡�����Ԫҷ���ͧ��á�͹", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
        }
    }//GEN-LAST:event_btAddCourseworkOkActionPerformed

    private void btAddCourseworkCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseworkCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "courseworkInfo");                    
    }//GEN-LAST:event_btAddCourseworkCancelActionPerformed

    private void btDelSubCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelSubCourseActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ (������Ἱ����֡�ҷ��������ѡ�ٵ����´ѧ����Ǩж١ź����) ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {    
            HandleCourse hCourse = new HandleCourse();                
            HandleSubject hSubject = new HandleSubject();
            hCourse.deleteSubCourse((SubCourse)tree.getUserObject());            
            hSubject.delAllCoursework(((SubCourse)tree.getUserObject()).getId());
            tree.removeCurrentNode();            
            cardManager.show(mainPanel, "courseMain");            
        }
    }//GEN-LAST:event_btDelSubCourseActionPerformed

    private void btAddSubCourseOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSubCourseOkActionPerformed
        // Add your handling code here:
        if(!tfAddSubCourseTname.getText().equals("") && cbAddSubCourseType1.getSelectedIndex() != 0 &&
           cbAddSubCourseType2.getSelectedIndex() != 0 && !tfAddTotalSemester.getText().equals(""))
        {
            SubCourse subcourse = new SubCourse();
            
            subcourse.setEname(tfAddSubCourseEname.getText());
            subcourse.setTname(tfAddSubCourseTname.getText());
            
            try
            {
                subcourse.setTotalYear(Integer.parseInt(tfAddTotalSemester.getText()));
                subcourse.setTotalCredit(Integer.parseInt(tfAddTotalCredit.getText()));
            }
            catch(Exception ex)
            {
                JOptionPane.showMessageDialog(null, "��سҡ�͡���������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                return;
            }
            
            switch(cbAddSubCourseType1.getSelectedIndex())
            {
                case 1:
                    subcourse.setType1("C");
                    break;
                case 2:
                    subcourse.setType1("T");
                    break;
                default:
            }
            
            switch(cbAddSubCourseType2.getSelectedIndex())
            {
                case 1:
                    subcourse.setType2("A");
                    break;
                case 2:
                    subcourse.setType2("B");
                    break;
                case 3:
                    subcourse.setType2("C");
                    break;
                default:
            }
            
            HandleCourse hCourse = new HandleCourse();
            if(hCourse.addSubCourse(subcourse, (Course)tree.getUserObject()))
            {
                // if insert successful
                cardManager.show(mainPanel, "courseDetail");
                SubCourse s = hCourse.retrieveSubCourse(subcourse, (Course)tree.getUserObject());

                SemesterTree sTree = new SemesterTree(tree);                                
                sTree.setNode(tree.addObject(s));
                sTree.retrieveTotalSemester(s);                            
                
                tfAddSubCourseEname.setText("");
                tfAddSubCourseTname.setText("");
                tfAddTotalSemester.setText("");
                tfAddTotalCredit.setText("");
                cbAddSubCourseType1.setSelectedIndex(0);
                cbAddSubCourseType2.setSelectedIndex(0);                
            }
            else
            {
                // insert fail
                JOptionPane.showMessageDialog(null, "�Դ��ͼԴ��Ҵ㹡��������������ѡ�ٵ�����", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                    
        }
    }//GEN-LAST:event_btAddSubCourseOkActionPerformed

    private void btAddSubCourseCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSubCourseCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "courseDetail");
    }//GEN-LAST:event_btAddSubCourseCancelActionPerformed

    private void btDelCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelCourseActionPerformed
        // Add your handling code here:
        if(tree.isLeaf())
        {
            if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
            {    
                HandleCourse hCourse = new HandleCourse();                
                hCourse.deleteCourse((Course)tree.getUserObject());
                tree.removeCurrentNode();            
                cardManager.show(mainPanel, "courseMain");            
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��س�ź��������ѡ�ٵ�������������͹", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                        
        }         
    }//GEN-LAST:event_btDelCourseActionPerformed

    private void btAddCourseOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseOkActionPerformed
        // Add your handling code here:
        if(!tfAddCourseSTDegree.getText().equals("") && cbAddDegree.getSelectedIndex() != 0)
        {
            Course course = new Course();
            
            course.setEname(tfAddCourseEname.getText());
            course.setTname(tfAddCourseTname.getText());
            course.setFTDegree(tfAddCourseFTDegree.getText());
            course.setFEDegree(tfAddCourseFEDegree.getText());
            course.setSTDegree(tfAddCourseSTDegree.getText());
            course.setSEDegree(tfAddCourseSEDegree.getText());            
            
            switch(cbAddDegree.getSelectedIndex())
            {
                case 1:
                    course.setDegree("M");
                    break;
                case 2:
                    course.setDegree("D");
                    break;
                default:
            }            
            
            HandleCourse hCourse = new HandleCourse();
            if(hCourse.addCourse(course, major, minor))
            {
                // if insert successful
                cardManager.show(mainPanel, "courseMain");
                tree.addObject(hCourse.retrieveCourse(course, major, minor));
                
                tfAddCourseEname.setText("");
                tfAddCourseTname.setText("");
                tfAddCourseFTDegree.setText("");
                tfAddCourseFEDegree.setText("");
                tfAddCourseSTDegree.setText("");
                tfAddCourseSEDegree.setText("");
                cbAddDegree.setSelectedIndex(0);
            }
            else
            {
                // insert fail
                JOptionPane.showMessageDialog(null, "��â�ͼԴ��Ҵ㹡��������������ѡ�ٵ�", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                
            }            
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                        
        }
    }//GEN-LAST:event_btAddCourseOkActionPerformed

    private void btAddCourseCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "courseMain");        
    }//GEN-LAST:event_btAddCourseCancelActionPerformed

    private void btAddCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "addCourse");
    }//GEN-LAST:event_btAddCourseActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        // Add your handling code here:
        parent.setEnabled(true);
        this.dispose();
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        parent.setEnabled(true);
        this.dispose();
    }//GEN-LAST:event_exitForm
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1112;
    private javax.swing.JButton btAddSubCourseOk;
    private javax.swing.JComboBox cbDegree;
    private javax.swing.JButton btEditCourse;
    private javax.swing.JLabel lbText;
    private javax.swing.JComboBox cbSubCourseType2;
    private javax.swing.JLabel jLabel2141;
    private javax.swing.JButton btDelCoursework;
    private javax.swing.JTextField tfCourseSTDegree;
    private javax.swing.JLabel jLabel91;
    private javax.swing.JLabel jLabel212;
    private javax.swing.JLabel jLabel81;
    private javax.swing.JButton btAddCourseOk;
    private javax.swing.JPanel courseworkInfoPanel;
    private javax.swing.JSplitPane jSplitPane;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel2121;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField tfCourseFTDegree;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JComboBox cbSubCourseType1;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel214;
    private javax.swing.JTextField tfAddCourseSEDegree;
    private javax.swing.JButton btDelSubCourse;
    private javax.swing.JLabel lbMajor;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JPanel courseDetailPanel;
    private javax.swing.JLabel jLabel213;
    private javax.swing.JButton btAddSubCourseCancel;
    private javax.swing.JPanel addSubCoursePanel;
    private javax.swing.JTextField tfCWSubjectID;
    private javax.swing.JButton btAddCoursework;
    private javax.swing.JTextField tfAddCourseFTDegree;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JTextField tfAddSubCourseEname;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel addCoursePanel;
    private javax.swing.JButton btAddCourseworkOk;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel courseMainPanel;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JPanel subCourseDetailPanel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JComboBox cbCourseworkID;
    private javax.swing.JTextField tfTotalSemester;
    private javax.swing.JTextField tfTotalCredit;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JButton btAllSubjectInSubcourse;
    private javax.swing.JPanel courseworkDetail;
    private javax.swing.JTextField tfCourseFEDegree;
    private javax.swing.JTextField tfLectureCredit;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton btAddSubCourse;
    private javax.swing.JLabel jLabel211;
    private javax.swing.JTextField tfCourseTname;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel lbCoursework;
    private javax.swing.JTextField tfSubCourseTname;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JTextField tfReserchCredit;
    private javax.swing.JTextField tfAddTotalSemester;
    private javax.swing.JTextField tfSubCourseEname;
    private javax.swing.JTextField tfAddCourseEname;
    private javax.swing.JTextField tfAddCourseTname;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JTextField tfCourseEname;
    private javax.swing.JPanel addCourseworkPanel;
    private javax.swing.JLabel jLabel2112;
    private javax.swing.JComboBox cbAddSubCourseType2;
    private javax.swing.JTextField tfAddSubCourseTname;
    private javax.swing.JLabel jLabel713;
    private javax.swing.JLabel jLabel2111;
    private javax.swing.JButton btAddCourseworkCancel;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel lbSubCourse;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JTextField tfAddCourseFEDegree;
    private javax.swing.JButton btEditSubCourse;
    private javax.swing.JComboBox cbAddSubCourseType1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JTextField tfCourseSEDegree;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton btDelCourse;
    private javax.swing.JLabel lbDept;
    private javax.swing.JLabel jLabel311;
    private javax.swing.JTextField tfAddCourseSTDegree;
    private javax.swing.JLabel jLabel2131;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JComboBox cbAddDegree;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JTextField tfAddTotalCredit;
    private javax.swing.JButton btAddCourseCancel;
    private javax.swing.JLabel jLabel215;
    private javax.swing.JButton btAddCourse;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel1111;
    private javax.swing.JLabel jLabel112;
    private javax.swing.JTextField tfCWSubjectTname;
    private javax.swing.JTextField tfCWSubjectEname;
    private javax.swing.JLabel jLabel711;
    private javax.swing.JLabel jLabel312;
    private javax.swing.JButton btSpecialCost;
    private javax.swing.JLabel lbFaculty;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JTextField tfPracticeCredit;
    private javax.swing.JScrollPane jScrollPane;
    // End of variables declaration//GEN-END:variables
}
