/*
 * MasterCourseB.java
 *
 * Created on 10 �ѹ�Ҥ� 2545, 18:22 �.
 */

package course;

/**
 *
 * @author  KUKI
 */
public class MasterCourseB extends MasterCourseA
{
    private String coursework_credit;
    
    /** Creates a new instance of MasterCourseB */
    public MasterCourseB() 
    {
    }
    
    public void setCourseworkCredit(String coursework_credit)
    {
        this.coursework_credit = coursework_credit;
    }
    
    public String getCourseworkCredit()
    {
        return this.coursework_credit;
    }        
}
