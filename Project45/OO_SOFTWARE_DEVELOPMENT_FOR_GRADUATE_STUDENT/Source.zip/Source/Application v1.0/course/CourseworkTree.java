/*
 * CourseworkTree.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 2:44 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class CourseworkTree 
{
    private DefaultMutableTreeNode semesterNode;
    private DefaultMutableTreeNode courseworkNode;
    private Tree tree;
    
    /** Creates a new instance of CourseworkTree */
    public CourseworkTree(Tree tree) 
    {
        this.tree = tree;         
    }
    
    public void retrieveCoursework(SubCourse subCourse, String semester, String year)
    {
        HandleSubject hSubject = new HandleSubject();                
        Vector v = hSubject.retrieveCoursework(subCourse.getId(), semester, year);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Subject subject = (Subject)e.nextElement();        
            courseworkNode = tree.addObject(semesterNode, subject);
        }        
    }
    
    public void setNode(DefaultMutableTreeNode semesterNode)
    {
        this.semesterNode = semesterNode;
    }      
}
