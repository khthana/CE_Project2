/*
 * CourseworkTypeTree.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 17:52 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class SubjectGroupTree 
{
    private DefaultMutableTreeNode subjectGroupNode;
    private Tree tree;
    
    /** Creates a new instance of CourseworkTypeTree */
    public SubjectGroupTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveSubjectGroup(Course course, SubCourse subcourse)
    {
        SubjectTree sTree = new SubjectTree(tree);
        
        subjectGroupNode = tree.addObject(null, "��Ǵ�ԪҺѧ�Ѻ");        
        sTree.setNode(subjectGroupNode);
        sTree.retrieveAllSubjectInGroup(course, subcourse, "C");
        
        subjectGroupNode = tree.addObject(null, "��Ǵ�Ԫ����͡");
        sTree.setNode(subjectGroupNode);
        sTree.retrieveAllSubjectInGroup(course, subcourse, "E");
        
        subjectGroupNode = tree.addObject(null, "��Ǵ�Ԫ��Է�ҹԾ������������");                
        sTree.setNode(subjectGroupNode);
        sTree.retrieveAllSubjectInGroup(course, subcourse, "T");
    }         
}
