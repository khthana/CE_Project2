/*
 * HandleSection.java
 *
 * Created on 8 �ѹ�Ҥ� 2545, 17:40 �.
 */

package course;

import java.util.*;
import java.sql.*;
import java.text.*;
import utility.*;
import graduate.*;

/**
 *
 * @author  KUKI
 */

public class HandleSection 
{    
    /** Creates a new instance of HandleSection */
    public HandleSection() 
    {
    }
    
    public Section retrieveSection(Section t, Subject s)
    {
        Section section = new Section();
        
        try
        {
            String query = "SELECT * FROM section WHERE subj# = '" + s.getId() + "' and sec = " + t.getSec();
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {                            
                section.setId(rs.getString(1));
                section.setSemester(rs.getString(2));
                section.setYear(rs.getString(3));
                section.setBeginTime(rs.getString(4));
                section.setEndTime(rs.getString(5));
                section.setRoom(rs.getString(6));
                section.setDay(rs.getString(7));
                section.setMidTermDate(rs.getDate(8));
                section.setMidTermBeginTime(rs.getString(9));
                section.setMidTermEndTime(rs.getString(10));
                section.setMidTermRoom(rs.getString(11));
                section.setFinTermDate(rs.getDate(12));
                section.setFinTermBeginTime(rs.getString(13));
                section.setFinTermEndTime(rs.getString(14));
                section.setFinTermRoom(rs.getString(15));
                section.setMaxStudent(rs.getString(16));
                section.setCurrentStudent(rs.getString(17));
                section.setSec(rs.getString(18));
                section.setLock(rs.getString(19));
                section.setStatus(rs.getString(20));
                
                HandleLecturer hLecturer = new HandleLecturer();
                Vector l = hLecturer.teach(section.getId());
                Enumeration e = l.elements();
                
                if(e.hasMoreElements())
                {
                    section.setLecturer((Lecturer)e.nextElement());
                }
                else
                {
                    section.setLecturer(null);
                }                
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
        
        return section;
    }
    
    public Vector retrieveSection(String sectionID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM section WHERE sec# = " + sectionID;
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Section section = new Section();
                
                section.setId(rs.getString(1));
                section.setSemester(rs.getString(2));
                section.setYear(rs.getString(3));
                section.setBeginTime(rs.getString(4));
                section.setEndTime(rs.getString(5));
                section.setRoom(rs.getString(6));
                section.setDay(rs.getString(7));
                section.setMidTermDate(rs.getDate(8));
                section.setMidTermBeginTime(rs.getString(9));
                section.setMidTermEndTime(rs.getString(10));
                section.setMidTermRoom(rs.getString(11));
                section.setFinTermDate(rs.getDate(12));
                section.setFinTermBeginTime(rs.getString(13));
                section.setFinTermEndTime(rs.getString(14));
                section.setFinTermRoom(rs.getString(15));
                section.setMaxStudent(rs.getString(16));
                section.setCurrentStudent(rs.getString(17));
                section.setSec(rs.getString(18));
                section.setLock(rs.getString(19));
                section.setStatus(rs.getString(20));
                
                HandleLecturer hLecturer = new HandleLecturer();
                Vector l = hLecturer.teach(sectionID);
                Enumeration e = l.elements();
                
                if(e.hasMoreElements())
                {
                    section.setLecturer((Lecturer)e.nextElement());
                }
                else
                {
                    section.setLecturer(null);
                }
                
                v.addElement(section);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
    
    public Vector retrieveSection(String subjectID, String sec)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM section WHERE subj# = '" + subjectID + "' AND sec = " + sec;
            
            ResultSet rs = DB.getResultSet(query);                  
        
            if(rs.next())
            {            
                Section section = new Section();
                
                section.setId(rs.getString(1));
                section.setSemester(rs.getString(2));
                section.setYear(rs.getString(3));
                section.setBeginTime(rs.getString(4));
                section.setEndTime(rs.getString(5));
                section.setRoom(rs.getString(6));
                section.setDay(rs.getString(7));
                section.setMidTermDate(rs.getDate(8));
                section.setMidTermBeginTime(rs.getString(9));
                section.setMidTermEndTime(rs.getString(10));
                section.setMidTermRoom(rs.getString(11));
                section.setFinTermDate(rs.getDate(12));
                section.setFinTermBeginTime(rs.getString(13));
                section.setFinTermEndTime(rs.getString(14));
                section.setFinTermRoom(rs.getString(15));
                section.setMaxStudent(rs.getString(16));
                section.setCurrentStudent(rs.getString(17));
                section.setSec(rs.getString(18));
                section.setLock(rs.getString(19));
                section.setStatus(rs.getString(20));
                
                HandleLecturer hLecturer = new HandleLecturer();
                Vector l = hLecturer.teach(section.getId());
                Enumeration e = l.elements();
                
                if(e.hasMoreElements())
                {
                    section.setLecturer((Lecturer)e.nextElement());
                }
                else
                {
                    section.setLecturer(null);
                }
                
                v.addElement(section);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 

    public Vector retrieveAllSection(String subjectID)
    {
        Vector v = new Vector();        
       
        try
        {
            String query = "SELECT * FROM section WHERE subj# = '" + subjectID + "'";
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Section section = new Section();
                
                section.setId(rs.getString(1));
                section.setSemester(rs.getString(2));
                section.setYear(rs.getString(3));
                section.setBeginTime(rs.getString(4));
                section.setEndTime(rs.getString(5));
                section.setRoom(rs.getString(6));
                section.setDay(rs.getString(7));
                section.setMidTermDate(rs.getDate(8));
                section.setMidTermBeginTime(rs.getString(9));
                section.setMidTermEndTime(rs.getString(10));
                section.setMidTermRoom(rs.getString(11));
                section.setFinTermDate(rs.getDate(12));
                section.setFinTermBeginTime(rs.getString(13));
                section.setFinTermEndTime(rs.getString(14));
                section.setFinTermRoom(rs.getString(15));
                section.setMaxStudent(rs.getString(16));
                section.setCurrentStudent(rs.getString(17));
                section.setSec(rs.getString(18));
                section.setLock(rs.getString(19));
                section.setStatus(rs.getString(20));
                
                HandleLecturer hLecturer = new HandleLecturer();
                Vector l = hLecturer.teach(section.getId());
                Enumeration e = l.elements();
                
                if(e.hasMoreElements())
                {
                    section.setLecturer((Lecturer)e.nextElement());
                }
                else
                {
                    section.setLecturer(null);
                }
                
                v.addElement(section);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;
    } 
    
    public int getNumberOfSection(String subjectID)
    {
        int numberOfSection = 0;
        
        try
        {
            String query = "SELECT * FROM section WHERE subj# = '" + subjectID + "'";           
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                numberOfSection++;
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return numberOfSection;
    }
    
    public boolean addSection(Subject subject, Section section)
    {
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");      
        
        String finalDate = "";
        String finalDateHead = "";
        
        if(section.getFinTermDate() != null)
        {
            finalDate = format.format(section.getFinTermDate()) + "', '";
            finalDateHead = "fin_exdate, ";
        }
        
        String beginTime = "";
        String beginTimeHead = "";
        
        if(!section.getBeginTime().equals(""))
        {
            beginTime = section.getBeginTime() + "', '";
            beginTimeHead = "begintime, ";
        }

        String endTime = "";
        String endTimeHead = "";
        
        if(!section.getEndTime().equals(""))
        {
            endTime = section.getEndTime() + "', '";
            endTimeHead = "endtime, ";
        }
        
        String finalBeginTime = "";
        String finalBeginTimeHead = "";
        
        if(!section.getFinTermBeginTime().equals(""))
        {
            finalBeginTime = section.getFinTermBeginTime() + "', '";
            finalBeginTimeHead = "fin_exbtime, ";
        }        
        
        String finalEndTime = "";
        String finalEndTimeHead = "";
        
        if(!section.getFinTermEndTime().equals(""))
        {
            finalEndTime = section.getFinTermEndTime() + "', '";
            finalEndTimeHead = "fin_exetime, ";
        }        
        
        String query = "INSERT INTO section(" + beginTimeHead + endTimeHead + "room, day, " + finalDateHead + finalBeginTimeHead + finalEndTimeHead + "fin_exroom, max_std, cur_std, sec, lock, status, subj#) " +
                       "VALUES('" + beginTime + endTime + section.getRoom() + "', '" + section.getDay() + "', '" + finalDate + finalBeginTime + finalEndTime + section.getFinTermRoom() + "', " + section.getMaxStudent() + ", " + section.getCurrentStudent() + ", " + section.getSec() + ", '" + section.getLock() + "', '" + section.getStatus() + "', '" + subject.getId() + "')";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean removeSection(Subject subject, Section section)
    {
        String query = "DELETE FROM section WHERE subj# = '" + subject.getId() + "' and sec = " + section.getSec();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;         
    }
    
    public boolean incrementCurrentStudent(Section s)
    {
        s.setCurrentStudent(Integer.toString(Integer.parseInt(s.getCurrentStudent()) + 1));
        
        String query = "UPDATE section " +
                       "SET " +
                       "cur_std = " + s.getCurrentStudent() + " WHERE sec# = " + s.getId();

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                 
    }
    
    public boolean decrementCurrentStudent(Section s)
    {
        s.setCurrentStudent(Integer.toString(Integer.parseInt(s.getCurrentStudent()) - 1));
        
        String query = "UPDATE section " +
                       "SET " +
                       "cur_std = " + s.getCurrentStudent() + " WHERE sec# = " + s.getId();

        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;                 
    }
    
    public boolean updateSection(Section news)
    {
        SimpleDateFormat formatDate = new SimpleDateFormat("dd/MM/yyyy");
        
        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");      
        
        String beginTime = "";
        if(!news.getBeginTime().equals(""))
        {
            beginTime = "begintime = '" + news.getBeginTime() + "', ";
        }

        String endTime = "";
        if(!news.getEndTime().equals(""))
        {
            endTime = "endtime = '" + news.getEndTime() + "', ";
        }
        
        String finalBeginTime = "";
        if(!news.getFinTermBeginTime().equals(""))
        {
            finalBeginTime = "fin_exbtime = '" + news.getFinTermBeginTime() + "', ";
        }        
        
        String finalEndTime = "";
        if(!news.getFinTermEndTime().equals(""))
        {
            finalEndTime = "fin_exetime = '" + news.getFinTermEndTime() + "', ";
        }                
        
        String finalDate = "";
        if(news.getFinTermDate() != null)
        {
            finalDate = "fin_exdate = '" + format.format(news.getFinTermDate()) + "', ";
        }        
        
        String query = "UPDATE section " +
                       "SET " +
                       beginTime +
                       endTime +
                       "room = '" + news.getRoom() + "', " +
                       "day = '" + news.getDay() + "', " +
                       finalDate + 
                       finalBeginTime +
                       finalEndTime +
                       "fin_exroom = '" + news.getFinTermRoom() + "', " +
                       "max_std = " + news.getMaxStudent() + ", " +
                       "sec = " + news.getSec() + ", " +
                       "lock = '" + news.getLock() + "' " +
                       "WHERE sec# = " + news.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;
    }
    
    public boolean openSection(Section section, Subject subject)
    {
        String query = "UPDATE section " +
                       "SET status = 'A' WHERE subj# = '" + subject.getId() + "' AND sec = " + section.getSec();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }
    
    public boolean closeSection(Section section, Subject subject)
    {
        String query = "UPDATE section " +
                       "SET status = 'C' WHERE subj# = '" + subject.getId() + "' AND sec = " + section.getSec();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;        
    }    
}
