/*
 * CourseworkUI.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 17:15 �.
 */

package course;

import javax.swing.tree.*;
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.tree.TreeSelectionModel;
import java.util.*;
import java.text.*;
import utility.*;
import course.*;
import organize.*;
import graduate.*;

/**
 *
 * @author  KUKI
 */
public class SubjectUI extends javax.swing.JFrame 
{
    private DefaultMutableTreeNode root;
    private SubjectGroupTree sTree;
    private Tree tree;
    
    private CardLayout cardManager;
    private Component parent;
    private Course course;
    private SubCourse subcourse;
    
    /** Creates new form CourseworkUI */
    public SubjectUI(Component parent, Course course, SubCourse subcourse) 
    {
        initComponents();
        
        String date[] = {"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10",
                             "11", "12", "13", "14", "15", "16", "17", "18", "19", "20",
                             "21", "22", "23", "24", "25", "26", "27", "28", "29", "30",
                             "31"};
        String month[] = {"", "���Ҥ�", "����Ҿѹ��", "�չҤ�", "����¹", "����Ҥ�", "�Զع�¹",
                              "�á�Ҥ�", "�ԧ�Ҥ�", "�ѹ��¹", "���Ҥ�", "��Ȩԡ�¹", "�ѹ�Ҥ�"};
        String day[] = {"", "�ѹ���", "�ѧ���", "�ظ", "����ʺ��", "�ء��", "�����", "�ҷԵ��"};
                              
        String group[] = {"", "�ѧ�Ѻ", "���͡", "�Է�ҹԾ������������"};
        String status[] = {"", "�Դ", "�Դ"};
        
        root = new DefaultMutableTreeNode("����Ԫҷ��������ѡ�ٵ�");
        tree = new Tree(root);
        
        this.parent = parent;
        this.course = course;
        this.subcourse = subcourse;
        tree.getTree().setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        cardManager = (CardLayout)mainPanel.getLayout();     
        cardManager.show(mainPanel, "courseworkInfo");
        jSplitPane.setOneTouchExpandable(true);   

        sTree = new SubjectGroupTree(tree);                
        sTree.retrieveSubjectGroup(course, subcourse);
        jScrollPane.setViewportView(tree.getTree());                                
        
        for(int i=0; i<group.length; i++)
        {
            cbSubjectType.addItem(group[i]);
            cbAddSubjectType.addItem(group[i]);
            cbPreSubjectType.addItem(group[i]);            
        }
        
        for(int i=0; i<status.length; i++)
        {
            cbStatus.addItem(status[i]);
        }
        
        for(int i=0; i<date.length; i++)
        {
            cbAddFinalDate.addItem(date[i]);
            cbFinalDate.addItem(date[i]);
        }
        
        for(int i=0; i<month.length; i++)
        {
            cbAddFinalMonth.addItem(month[i]);
            cbFinalMonth.addItem(month[i]);
        }        
        
        for(int i=0; i<day.length; i++)
        {
            cbAddStudyDay.addItem(day[i]);
            cbStudyDay.addItem(day[i]);
        }
        
        // Listen for when the selection changes
        tree.getTree().addTreeSelectionListener(new TreeSelectionListener() 
        {
            public void valueChanged(TreeSelectionEvent e) 
            {
               DefaultMutableTreeNode node = (DefaultMutableTreeNode)tree.getTree().getLastSelectedPathComponent();

               if (node == null) return;

               Object nodeInfo = node.getUserObject();

               if(node.getLevel()==0) 
               {
                   cardManager.show(mainPanel, "courseworkInfo");
               }
               else if(node.getLevel()==1)                        
               {
                   String s = (String)nodeInfo;
                   lbGroup.setText(s);                   
                   cardManager.show(mainPanel, "courseworkGroup");
               }
               else if(node.getLevel()==2)
               {                   
                   cardManager.show(mainPanel, "courseworkDetail");
                   Subject subject = (Subject)nodeInfo;
                   
                   tfSubjectID.setText(subject.getId());
                   tfSubjectEname.setText(subject.getEname());
                   tfSubjectTname.setText(subject.getTname());
                   tfSubjectCredit.setText(subject.getCredit());
                   tfSubjectLecture.setText(subject.getLecture());
                   tfSubjectPractice.setText(subject.getPractice());
                   tfSubjectResearch.setText(subject.getResearch());
                   
                   switch(subject.getGroup().charAt(0))
                   {
                       case 'C':
                           cbSubjectType.setSelectedIndex(1);
                           break;
                       case 'E':                           
                           cbSubjectType.setSelectedIndex(2);
                           break;
                       case 'T':
                           cbSubjectType.setSelectedIndex(3);
                           break;
                       default:
                   }
                   
                   tpSubjectToutline.setText(subject.getToutline());
                   tpSubjectEoutline.setText(subject.getEoutline());
               }
               else if(node.getLevel()==3)
               {
                   String s = (String)nodeInfo;
                   
                   if(s.equals("�礪��"))
                   {
                       cardManager.show(mainPanel, "addSection");
                       Subject subject = (Subject)tree.getUserObject(1);
                       lbSubjectNameSec.setText(subject.toString());
                   }
                   else if(s.equals("����ԪҺѧ�Ѻ��͹"))
                   {
                       cardManager.show(mainPanel, "addPrerequisite");                       
                       Subject subject = (Subject)tree.getUserObject(1);
                       lbSubjectNamePre.setText(subject.toString());                       
                   }
               }
               else if(node.getLevel()==4)
               {
                   String s = (String)tree.getUserObject(1);
                   
                   if(s.equals("�礪��"))
                   {
                       cardManager.show(mainPanel, "sectionDetail");
                       cbLecturer.removeAllItems();
                       cbLecturer.addItem(null);

                       Section section = (Section)nodeInfo;
                       
                       HandleLecturer hLecturer = new HandleLecturer();
                       Vector vector = hLecturer.retrieveAllLecturer();
                       Enumeration enum = vector.elements();
                       int i = 1;
                       
                       while(enum.hasMoreElements())
                       {
                           Lecturer l = (Lecturer)enum.nextElement();
                           cbLecturer.addItem(l);                           
                           
                           if(section.getLecturer() != null)
                           {
                               if(l.getId().equals(section.getLecturer().getId()))
                               {
                                   cbLecturer.setSelectedIndex(i);
                               }   
                           }
                           
                           i++;
                       }                       
                       
                       tfSecNumber.setText(section.getSec());
                       tfMaxStudent.setText(section.getMaxStudent());
                       tfCurrentStudent.setText(section.getCurrentStudent());
                       cbStudyDay.setSelectedItem(section.getDay());
                       tfStudyRoom.setText(section.getRoom());
                       tfFinalRoom.setText(section.getFinTermRoom());
                       
                       if(section.getFinTermDate() != null)
                       {
                           SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
                           String date = format.format(section.getFinTermDate());
                   
                           StringTokenizer st = new StringTokenizer(date,"/");
                           date = st.nextToken();
                           cbFinalDate.setSelectedIndex(Integer.parseInt(date));
                           date = st.nextToken();
                           cbFinalMonth.setSelectedIndex(Integer.parseInt(date));                    
                           date = st.nextToken();	               
                           tfFinalYear.setText(date);
                       }
                       else
                       {
                           cbFinalDate.setSelectedIndex(0);
                           cbFinalMonth.setSelectedIndex(0);
                           tfFinalYear.setText("");
                       }
                       
                       if(section.getBeginTime() != null)
                       {
                           StringTokenizer st = new StringTokenizer(section.getBeginTime(), ":");   
                           
                           tfStudyStartHour.setText(st.nextToken());
                           tfStudyStartMinute.setText(st.nextToken());
                       }
                       else
                       {
                           tfStudyStartHour.setText("");
                           tfStudyStartMinute.setText("");                           
                       }
                       
                       if(section.getEndTime() != null)
                       {
                           StringTokenizer st = new StringTokenizer(section.getEndTime(), ":");   
                           
                           tfStudyEndHour.setText(st.nextToken());
                           tfStudyEndMinute.setText(st.nextToken());
                       }
                       else
                       {
                           tfStudyEndHour.setText("");
                           tfStudyEndMinute.setText("");                           
                       }
                       
                       if(section.getFinTermBeginTime() != null)
                       {
                           StringTokenizer st = new StringTokenizer(section.getFinTermBeginTime(), ":");   
                           
                           tfFinalStartHour.setText(st.nextToken());
                           tfFinalStartMinute.setText(st.nextToken());
                       }
                       else
                       {
                           tfFinalStartHour.setText("");
                           tfFinalStartMinute.setText("");                           
                       }
                       
                       if(section.getFinTermEndTime() != null)
                       {
                           StringTokenizer st = new StringTokenizer(section.getFinTermEndTime(), ":");   
                           
                           tfFinalEndHour.setText(st.nextToken());
                           tfFinalEndMinute.setText(st.nextToken());
                       }
                       else
                       {
                           tfFinalEndHour.setText("");
                           tfFinalEndMinute.setText("");                           
                       }
                       
                       if(section.getLock().equals("Y"))
                       {
                           rbLockYes.setSelected(true);
                       }
                       else
                       {
                           rbLockNo.setSelected(true);                           
                       }
                       
                       if(section.getStatus().equals("A"))
                       {
                           cbStatus.setSelectedIndex(1);
                       }
                       else
                       {
                           cbStatus.setSelectedIndex(2);                           
                       }
                   }
                   else if(s.equals("����ԪҺѧ�Ѻ��͹"))
                   {
                       cardManager.show(mainPanel, "prerequisiteDetail");
                       Subject subject = (Subject)nodeInfo;
                   
                       tfPreSubjectID.setText(subject.getId());
                       tfPreSubjectEname.setText(subject.getEname());
                       tfPreSubjectTname.setText(subject.getTname());
                       tfPreSubjectCredit.setText(subject.getCredit());
                       tfPreSubjectLecture.setText(subject.getLecture());
                       tfPreSubjectPractice.setText(subject.getPractice());
                       tfPreSubjectResearch.setText(subject.getResearch());
                   
                       switch(subject.getGroup().charAt(0))
                       {
                           case 'C':
                               cbPreSubjectType.setSelectedIndex(1);
                               break;
                           case 'E':                           
                               cbPreSubjectType.setSelectedIndex(2);
                               break;
                           case 'T':
                               cbPreSubjectType.setSelectedIndex(3);
                               break;
                           default:
                       }
                   
                       tpPreSubjectToutline.setText(subject.getToutline());
                       tpPreSubjectEoutline.setText(subject.getEoutline());                       
                   }
               }
            }
        });                        
        
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        radioGroup1 = new javax.swing.ButtonGroup();
        radioGroup2 = new javax.swing.ButtonGroup();
        jSplitPane = new javax.swing.JSplitPane();
        jScrollPane = new javax.swing.JScrollPane();
        mainPanel = new javax.swing.JPanel();
        courseworkDetail = new javax.swing.JPanel();
        jLabel1111 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tfSubjectID = new javax.swing.JTextField();
        jLabel2111 = new javax.swing.JLabel();
        tfSubjectEname = new javax.swing.JTextField();
        jLabel311 = new javax.swing.JLabel();
        tfSubjectTname = new javax.swing.JTextField();
        jLabel3111 = new javax.swing.JLabel();
        cbSubjectType = new javax.swing.JComboBox();
        jLabel121 = new javax.swing.JLabel();
        tfSubjectCredit = new javax.swing.JTextField();
        tfSubjectPractice = new javax.swing.JTextField();
        jLabel122 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tfSubjectResearch = new javax.swing.JTextField();
        jLabel3112 = new javax.swing.JLabel();
        jLabel3113 = new javax.swing.JLabel();
        spToutline = new javax.swing.JScrollPane();
        tpSubjectToutline = new javax.swing.JTextPane();
        spEoutline = new javax.swing.JScrollPane();
        tpSubjectEoutline = new javax.swing.JTextPane();
        btDelSubject = new javax.swing.JButton();
        jLabel1211 = new javax.swing.JLabel();
        tfSubjectLecture = new javax.swing.JTextField();
        jLabel31132 = new javax.swing.JLabel();
        jLabel31133 = new javax.swing.JLabel();
        btEditSubject = new javax.swing.JButton();
        prerequisiteDetail = new javax.swing.JPanel();
        jLabel11111 = new javax.swing.JLabel();
        jLabel101 = new javax.swing.JLabel();
        tfPreSubjectID = new javax.swing.JTextField();
        jLabel21111 = new javax.swing.JLabel();
        tfPreSubjectEname = new javax.swing.JTextField();
        tfPreSubjectTname = new javax.swing.JTextField();
        jLabel31111 = new javax.swing.JLabel();
        jLabel31121 = new javax.swing.JLabel();
        cbPreSubjectType = new javax.swing.JComboBox();
        jLabel1212 = new javax.swing.JLabel();
        tfPreSubjectCredit = new javax.swing.JTextField();
        jLabel12111 = new javax.swing.JLabel();
        tfPreSubjectLecture = new javax.swing.JTextField();
        jLabel1221 = new javax.swing.JLabel();
        tfPreSubjectPractice = new javax.swing.JTextField();
        jLabel123 = new javax.swing.JLabel();
        tfPreSubjectResearch = new javax.swing.JTextField();
        jLabel31131 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        tpPreSubjectToutline = new javax.swing.JTextPane();
        jLabel3114 = new javax.swing.JLabel();
        jScrollPane21 = new javax.swing.JScrollPane();
        tpPreSubjectEoutline = new javax.swing.JTextPane();
        btDelPrerequisite = new javax.swing.JButton();
        jLabel311331 = new javax.swing.JLabel();
        jLabel31134 = new javax.swing.JLabel();
        couseworkInfoPanel = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel321 = new javax.swing.JLabel();
        jLabel3211 = new javax.swing.JLabel();
        courseworkGroupPanel = new javax.swing.JPanel();
        lbGroup = new javax.swing.JLabel();
        btAddCoursework = new javax.swing.JButton();
        jLabel32111 = new javax.swing.JLabel();
        addCourseworkPanel = new javax.swing.JPanel();
        jLabel11112 = new javax.swing.JLabel();
        tfAddSubjectID = new javax.swing.JTextField();
        jLabel102 = new javax.swing.JLabel();
        jLabel21112 = new javax.swing.JLabel();
        tfAddSubjectEname = new javax.swing.JTextField();
        tfAddSubjectTname = new javax.swing.JTextField();
        jLabel31112 = new javax.swing.JLabel();
        jLabel31122 = new javax.swing.JLabel();
        cbAddSubjectType = new javax.swing.JComboBox();
        jLabel1213 = new javax.swing.JLabel();
        tfAddSubjectCredit = new javax.swing.JTextField();
        tfAddSubjectLecture = new javax.swing.JTextField();
        jLabel12112 = new javax.swing.JLabel();
        jLabel1222 = new javax.swing.JLabel();
        tfAddSubjectPractice = new javax.swing.JTextField();
        jLabel124 = new javax.swing.JLabel();
        tfAddSubjectResearch = new javax.swing.JTextField();
        jLabel311321 = new javax.swing.JLabel();
        jLabel311332 = new javax.swing.JLabel();
        spToutline1 = new javax.swing.JScrollPane();
        tpAddSubjectToutline = new javax.swing.JTextPane();
        jLabel3115 = new javax.swing.JLabel();
        jLabel31135 = new javax.swing.JLabel();
        spEoutline1 = new javax.swing.JScrollPane();
        tpAddSubjectEoutline = new javax.swing.JTextPane();
        btAddSubjectOk = new javax.swing.JButton();
        btAddSubjectCancel = new javax.swing.JButton();
        addPrerequisitePanel = new javax.swing.JPanel();
        jLabel111121 = new javax.swing.JLabel();
        btAddPreSubCancel = new javax.swing.JButton();
        btAddPreSubOk = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel1011 = new javax.swing.JLabel();
        cbPreSubID = new javax.swing.JComboBox();
        allSectionDetailPanel = new javax.swing.JPanel();
        lbSubjectNameSec = new javax.swing.JLabel();
        btAddSection = new javax.swing.JButton();
        jLabel3211112 = new javax.swing.JLabel();
        prerequisiteDetailPanel = new javax.swing.JPanel();
        jLabel3211111 = new javax.swing.JLabel();
        btAddPreSubject = new javax.swing.JButton();
        lbSubjectNamePre = new javax.swing.JLabel();
        addSectionPanel = new javax.swing.JPanel();
        tfAddMaxStudent = new javax.swing.JTextField();
        jLabel161 = new javax.swing.JLabel();
        jLabel151 = new javax.swing.JLabel();
        jLabel1421 = new javax.swing.JLabel();
        jLabel1411 = new javax.swing.JLabel();
        jLabel1311 = new javax.swing.JLabel();
        jLabel12211 = new javax.swing.JLabel();
        jLabel12113 = new javax.swing.JLabel();
        jLabel111 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        cbAddLecturer = new javax.swing.JComboBox();
        cbAddStudyDay = new javax.swing.JComboBox();
        tfAddSecNumber = new javax.swing.JTextField();
        tfAddFinalYear = new javax.swing.JTextField();
        jLabel1323 = new javax.swing.JLabel();
        cbAddFinalMonth = new javax.swing.JComboBox();
        jLabel133 = new javax.swing.JLabel();
        cbAddFinalDate = new javax.swing.JComboBox();
        tfAddStudyRoom = new javax.swing.JTextField();
        tfAddStudyStartHour = new javax.swing.JTextField();
        jLabel1441 = new javax.swing.JLabel();
        tfAddStudyStartMinute = new javax.swing.JTextField();
        jLabel12221 = new javax.swing.JLabel();
        tfAddStudyEndHour = new javax.swing.JTextField();
        jLabel1442 = new javax.swing.JLabel();
        tfAddStudyEndMinute = new javax.swing.JTextField();
        tfAddFinalStartHour = new javax.swing.JTextField();
        jLabel1431 = new javax.swing.JLabel();
        tfAddFinalStartMinute = new javax.swing.JTextField();
        jLabel1223 = new javax.swing.JLabel();
        tfAddFinalEndHour = new javax.swing.JTextField();
        jLabel144 = new javax.swing.JLabel();
        tfAddFinalEndMinute = new javax.swing.JTextField();
        tfAddFinalRoom = new javax.swing.JTextField();
        btDelSectionCancel = new javax.swing.JButton();
        btAddSectionOk = new javax.swing.JButton();
        jLabel1112 = new javax.swing.JLabel();
        jLabel1611 = new javax.swing.JLabel();
        rbAddLockYes = new javax.swing.JRadioButton();
        rbAddLockNo = new javax.swing.JRadioButton();
        sectionDetailPanel = new javax.swing.JPanel();
        rbLockNo = new javax.swing.JRadioButton();
        rbLockYes = new javax.swing.JRadioButton();
        jLabel1612 = new javax.swing.JLabel();
        tfCurrentStudent = new javax.swing.JTextField();
        jLabel16111 = new javax.swing.JLabel();
        tfFinalRoom = new javax.swing.JTextField();
        jLabel1511 = new javax.swing.JLabel();
        tfFinalEndMinute = new javax.swing.JTextField();
        jLabel1443 = new javax.swing.JLabel();
        tfFinalEndHour = new javax.swing.JTextField();
        jLabel12231 = new javax.swing.JLabel();
        tfFinalStartMinute = new javax.swing.JTextField();
        jLabel14311 = new javax.swing.JLabel();
        tfFinalStartHour = new javax.swing.JTextField();
        jLabel14211 = new javax.swing.JLabel();
        jLabel14111 = new javax.swing.JLabel();
        cbStatus = new javax.swing.JComboBox();
        jLabel1331 = new javax.swing.JLabel();
        cbFinalMonth = new javax.swing.JComboBox();
        jLabel13231 = new javax.swing.JLabel();
        tfFinalYear = new javax.swing.JTextField();
        tfStudyRoom = new javax.swing.JTextField();
        jLabel13111 = new javax.swing.JLabel();
        jLabel122111 = new javax.swing.JLabel();
        tfStudyStartHour = new javax.swing.JTextField();
        jLabel14411 = new javax.swing.JLabel();
        tfStudyStartMinute = new javax.swing.JTextField();
        jLabel122211 = new javax.swing.JLabel();
        tfStudyEndHour = new javax.swing.JTextField();
        jLabel14421 = new javax.swing.JLabel();
        tfStudyEndMinute = new javax.swing.JTextField();
        jLabel121131 = new javax.swing.JLabel();
        cbStudyDay = new javax.swing.JComboBox();
        cbLecturer = new javax.swing.JComboBox();
        jLabel11121 = new javax.swing.JLabel();
        jLabel1113 = new javax.swing.JLabel();
        tfSecNumber = new javax.swing.JTextField();
        jLabel181 = new javax.swing.JLabel();
        btCloseSection = new javax.swing.JButton();
        btEditSection = new javax.swing.JButton();
        btOpenSection = new javax.swing.JButton();
        btDelSection = new javax.swing.JButton();
        tfMaxStudent = new javax.swing.JTextField();
        jLabel161111 = new javax.swing.JLabel();
        jLabel161112 = new javax.swing.JLabel();
        cbFinalDate = new javax.swing.JComboBox();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();

        setTitle("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32 - \u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14\u0e43\u0e19\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jSplitPane.setLeftComponent(jScrollPane);

        mainPanel.setLayout(new java.awt.CardLayout());

        courseworkDetail.setLayout(null);

        jLabel1111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel1111.setForeground(java.awt.Color.blue);
        jLabel1111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1111.setText("\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel1111);
        jLabel1111.setBounds(190, 30, 180, 30);

        jLabel10.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel10.setForeground(java.awt.Color.darkGray);
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel10);
        jLabel10.setBounds(10, 80, 100, 23);

        tfSubjectID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfSubjectID.setDisabledTextColor(java.awt.Color.black);
        tfSubjectID.setEnabled(false);
        courseworkDetail.add(tfSubjectID);
        tfSubjectID.setBounds(130, 80, 140, 23);

        jLabel2111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel2111.setForeground(java.awt.Color.darkGray);
        jLabel2111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel2111.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        courseworkDetail.add(jLabel2111);
        jLabel2111.setBounds(10, 110, 100, 23);

        tfSubjectEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfSubjectEname);
        tfSubjectEname.setBounds(130, 110, 380, 23);

        jLabel311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel311.setForeground(java.awt.Color.darkGray);
        jLabel311.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel311.setText("\u0e04\u0e33\u0e2d\u0e18\u0e34\u0e1a\u0e32\u0e22\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel311);
        jLabel311.setBounds(10, 370, 100, 23);

        tfSubjectTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfSubjectTname);
        tfSubjectTname.setBounds(130, 140, 380, 23);

        jLabel3111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3111.setForeground(java.awt.Color.darkGray);
        jLabel3111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3111.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        courseworkDetail.add(jLabel3111);
        jLabel3111.setBounds(10, 140, 100, 23);

        cbSubjectType.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        cbSubjectType.setEnabled(false);
        courseworkDetail.add(cbSubjectType);
        cbSubjectType.setBounds(130, 170, 240, 23);

        jLabel121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel121.setForeground(java.awt.Color.darkGray);
        jLabel121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel121.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15");
        courseworkDetail.add(jLabel121);
        jLabel121.setBounds(10, 200, 100, 23);

        tfSubjectCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfSubjectCredit);
        tfSubjectCredit.setBounds(130, 200, 60, 23);

        tfSubjectPractice.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfSubjectPractice);
        tfSubjectPractice.setBounds(290, 230, 60, 23);

        jLabel122.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel122.setForeground(java.awt.Color.darkGray);
        jLabel122.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1b\u0e0f\u0e34\u0e1a\u0e31\u0e15\u0e34");
        courseworkDetail.add(jLabel122);
        jLabel122.setBounds(200, 230, 90, 23);

        jLabel12.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12.setForeground(java.awt.Color.darkGray);
        jLabel12.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e04\u0e49\u0e19\u0e04\u0e27\u0e49\u0e32");
        courseworkDetail.add(jLabel12);
        jLabel12.setBounds(360, 230, 90, 23);

        tfSubjectResearch.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfSubjectResearch);
        tfSubjectResearch.setBounds(450, 230, 60, 23);

        jLabel3112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3112.setForeground(java.awt.Color.darkGray);
        jLabel3112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3112.setText("\u0e2b\u0e21\u0e27\u0e14\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel3112);
        jLabel3112.setBounds(10, 170, 100, 23);

        jLabel3113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3113.setForeground(java.awt.Color.darkGray);
        jLabel3113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3113.setText("(\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        courseworkDetail.add(jLabel3113);
        jLabel3113.setBounds(10, 400, 100, 23);

        spToutline.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpSubjectToutline.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        spToutline.setViewportView(tpSubjectToutline);

        courseworkDetail.add(spToutline);
        spToutline.setBounds(130, 270, 380, 90);

        spEoutline.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpSubjectEoutline.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        spEoutline.setViewportView(tpSubjectEoutline);

        courseworkDetail.add(spEoutline);
        spEoutline.setBounds(130, 373, 380, 90);

        btDelSubject.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelSubject.setForeground(java.awt.Color.darkGray);
        btDelSubject.setText("\u0e25\u0e1a\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        btDelSubject.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelSubject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelSubjectActionPerformed(evt);
            }
        });

        courseworkDetail.add(btDelSubject);
        btDelSubject.setBounds(300, 500, 120, 24);

        jLabel1211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1211.setForeground(java.awt.Color.darkGray);
        jLabel1211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1211.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1a\u0e23\u0e23\u0e22\u0e32\u0e22");
        courseworkDetail.add(jLabel1211);
        jLabel1211.setBounds(10, 230, 100, 23);

        tfSubjectLecture.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        courseworkDetail.add(tfSubjectLecture);
        tfSubjectLecture.setBounds(130, 230, 60, 23);

        jLabel31132.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31132.setForeground(java.awt.Color.darkGray);
        jLabel31132.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31132.setText("\u0e04\u0e33\u0e2d\u0e18\u0e34\u0e1a\u0e32\u0e22\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        courseworkDetail.add(jLabel31132);
        jLabel31132.setBounds(10, 270, 100, 23);

        jLabel31133.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31133.setForeground(java.awt.Color.darkGray);
        jLabel31133.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31133.setText("(\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        courseworkDetail.add(jLabel31133);
        jLabel31133.setBounds(10, 300, 100, 23);

        btEditSubject.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btEditSubject.setForeground(java.awt.Color.darkGray);
        btEditSubject.setText("\u0e41\u0e01\u0e49\u0e44\u0e02\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        btEditSubject.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btEditSubject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditSubjectActionPerformed(evt);
            }
        });

        courseworkDetail.add(btEditSubject);
        btEditSubject.setBounds(150, 500, 120, 24);

        mainPanel.add(courseworkDetail, "courseworkDetail");

        prerequisiteDetail.setLayout(null);

        jLabel11111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel11111.setForeground(java.awt.Color.blue);
        jLabel11111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11111.setText("\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e27\u0e34\u0e0a\u0e32\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e01\u0e48\u0e2d\u0e19");
        prerequisiteDetail.add(jLabel11111);
        jLabel11111.setBounds(190, 30, 180, 30);

        jLabel101.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel101.setForeground(java.awt.Color.darkGray);
        jLabel101.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel101.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e27\u0e34\u0e0a\u0e32");
        prerequisiteDetail.add(jLabel101);
        jLabel101.setBounds(10, 80, 100, 23);

        tfPreSubjectID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectID);
        tfPreSubjectID.setBounds(130, 80, 140, 23);

        jLabel21111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel21111.setForeground(java.awt.Color.darkGray);
        jLabel21111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21111.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        prerequisiteDetail.add(jLabel21111);
        jLabel21111.setBounds(10, 110, 100, 23);

        tfPreSubjectEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectEname);
        tfPreSubjectEname.setBounds(130, 110, 380, 23);

        tfPreSubjectTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectTname);
        tfPreSubjectTname.setBounds(130, 140, 380, 23);

        jLabel31111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31111.setForeground(java.awt.Color.darkGray);
        jLabel31111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31111.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        prerequisiteDetail.add(jLabel31111);
        jLabel31111.setBounds(10, 140, 100, 23);

        jLabel31121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31121.setForeground(java.awt.Color.darkGray);
        jLabel31121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31121.setText("\u0e2b\u0e21\u0e27\u0e14\u0e27\u0e34\u0e0a\u0e32");
        prerequisiteDetail.add(jLabel31121);
        jLabel31121.setBounds(10, 170, 100, 23);

        cbPreSubjectType.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(cbPreSubjectType);
        cbPreSubjectType.setBounds(130, 170, 240, 23);

        jLabel1212.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1212.setForeground(java.awt.Color.darkGray);
        jLabel1212.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1212.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15");
        prerequisiteDetail.add(jLabel1212);
        jLabel1212.setBounds(10, 200, 100, 23);

        tfPreSubjectCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectCredit);
        tfPreSubjectCredit.setBounds(130, 200, 60, 23);

        jLabel12111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12111.setForeground(java.awt.Color.darkGray);
        jLabel12111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12111.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1a\u0e23\u0e23\u0e22\u0e32\u0e22");
        prerequisiteDetail.add(jLabel12111);
        jLabel12111.setBounds(10, 230, 100, 23);

        tfPreSubjectLecture.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectLecture);
        tfPreSubjectLecture.setBounds(130, 230, 60, 23);

        jLabel1221.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1221.setForeground(java.awt.Color.darkGray);
        jLabel1221.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1b\u0e0f\u0e34\u0e1a\u0e31\u0e15\u0e34");
        prerequisiteDetail.add(jLabel1221);
        jLabel1221.setBounds(200, 230, 90, 23);

        tfPreSubjectPractice.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectPractice);
        tfPreSubjectPractice.setBounds(290, 230, 60, 23);

        jLabel123.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel123.setForeground(java.awt.Color.darkGray);
        jLabel123.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e04\u0e49\u0e19\u0e04\u0e27\u0e49\u0e32");
        prerequisiteDetail.add(jLabel123);
        jLabel123.setBounds(360, 230, 90, 23);

        tfPreSubjectResearch.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        prerequisiteDetail.add(tfPreSubjectResearch);
        tfPreSubjectResearch.setBounds(450, 230, 60, 23);

        jLabel31131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31131.setForeground(java.awt.Color.darkGray);
        jLabel31131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31131.setText("\u0e04\u0e33\u0e2d\u0e18\u0e34\u0e1a\u0e32\u0e22\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        prerequisiteDetail.add(jLabel31131);
        jLabel31131.setBounds(10, 270, 100, 23);

        jScrollPane11.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpPreSubjectToutline.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane11.setViewportView(tpPreSubjectToutline);

        prerequisiteDetail.add(jScrollPane11);
        jScrollPane11.setBounds(130, 270, 380, 90);

        jLabel3114.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3114.setForeground(java.awt.Color.darkGray);
        jLabel3114.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3114.setText("\u0e04\u0e33\u0e2d\u0e18\u0e34\u0e1a\u0e32\u0e22\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        prerequisiteDetail.add(jLabel3114);
        jLabel3114.setBounds(10, 370, 100, 23);

        jScrollPane21.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpPreSubjectEoutline.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jScrollPane21.setViewportView(tpPreSubjectEoutline);

        prerequisiteDetail.add(jScrollPane21);
        jScrollPane21.setBounds(130, 373, 380, 90);

        btDelPrerequisite.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelPrerequisite.setForeground(java.awt.Color.darkGray);
        btDelPrerequisite.setText("\u0e25\u0e1a\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e01\u0e48\u0e2d\u0e19");
        btDelPrerequisite.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelPrerequisite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelPrerequisiteActionPerformed(evt);
            }
        });

        prerequisiteDetail.add(btDelPrerequisite);
        btDelPrerequisite.setBounds(230, 500, 140, 24);

        jLabel311331.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel311331.setForeground(java.awt.Color.darkGray);
        jLabel311331.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel311331.setText("(\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        prerequisiteDetail.add(jLabel311331);
        jLabel311331.setBounds(10, 300, 100, 23);

        jLabel31134.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31134.setForeground(java.awt.Color.darkGray);
        jLabel31134.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31134.setText("(\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        prerequisiteDetail.add(jLabel31134);
        jLabel31134.setBounds(10, 400, 100, 23);

        mainPanel.add(prerequisiteDetail, "prerequisiteDetail");

        couseworkInfoPanel.setLayout(null);

        jLabel32.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel32.setForeground(java.awt.Color.blue);
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("\u0e23\u0e30\u0e1a\u0e1a\u0e2a\u0e32\u0e23\u0e2a\u0e19\u0e40\u0e17\u0e28\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32 \u0e23\u0e30\u0e14\u0e31\u0e1a\u0e1a\u0e31\u0e13\u0e11\u0e34\u0e15\u0e28\u0e36\u0e01\u0e29\u0e32");
        couseworkInfoPanel.add(jLabel32);
        jLabel32.setBounds(120, 40, 320, 30);

        jLabel41.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/LogoGrad.gif")));
        couseworkInfoPanel.add(jLabel41);
        jLabel41.setBounds(220, 230, 130, 110);

        jLabel321.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel321.setForeground(java.awt.Color.blue);
        jLabel321.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel321.setText("\u0e2a\u0e16\u0e32\u0e1a\u0e31\u0e19\u0e40\u0e17\u0e04\u0e42\u0e19\u0e42\u0e25\u0e22\u0e35\u0e1e\u0e23\u0e30\u0e08\u0e2d\u0e21\u0e40\u0e01\u0e25\u0e49\u0e32\u0e40\u0e08\u0e49\u0e32\u0e04\u0e38\u0e13\u0e17\u0e2b\u0e32\u0e23\u0e25\u0e32\u0e14\u0e01\u0e23\u0e30\u0e1a\u0e31\u0e07");
        couseworkInfoPanel.add(jLabel321);
        jLabel321.setBounds(100, 90, 370, 30);

        jLabel3211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel3211.setForeground(java.awt.Color.red);
        jLabel3211.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3211.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14\u0e43\u0e19\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        couseworkInfoPanel.add(jLabel3211);
        jLabel3211.setBounds(150, 160, 270, 30);

        mainPanel.add(couseworkInfoPanel, "courseworkInfo");

        courseworkGroupPanel.setLayout(null);

        lbGroup.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbGroup.setForeground(java.awt.Color.blue);
        lbGroup.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        courseworkGroupPanel.add(lbGroup);
        lbGroup.setBounds(90, 140, 370, 30);

        btAddCoursework.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddCoursework.setForeground(java.awt.Color.darkGray);
        btAddCoursework.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e43\u0e19\u0e2b\u0e21\u0e27\u0e14");
        btAddCoursework.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddCoursework.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddCourseworkActionPerformed(evt);
            }
        });

        courseworkGroupPanel.add(btAddCoursework);
        btAddCoursework.setBounds(200, 240, 150, 24);

        jLabel32111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel32111.setForeground(java.awt.Color.red);
        jLabel32111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32111.setText("\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14\u0e43\u0e19\u0e2b\u0e25\u0e31\u0e01\u0e2a\u0e39\u0e15\u0e23\u0e22\u0e48\u0e2d\u0e22");
        courseworkGroupPanel.add(jLabel32111);
        jLabel32111.setBounds(140, 80, 270, 30);

        mainPanel.add(courseworkGroupPanel, "courseworkGroup");

        addCourseworkPanel.setLayout(null);

        jLabel11112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel11112.setForeground(java.awt.Color.blue);
        jLabel11112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11112.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        addCourseworkPanel.add(jLabel11112);
        jLabel11112.setBounds(190, 30, 180, 30);

        tfAddSubjectID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectID);
        tfAddSubjectID.setBounds(130, 80, 140, 23);

        jLabel102.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel102.setForeground(java.awt.Color.blue);
        jLabel102.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel102.setText("\u0e23\u0e2b\u0e31\u0e2a\u0e27\u0e34\u0e0a\u0e32");
        addCourseworkPanel.add(jLabel102);
        jLabel102.setBounds(10, 80, 100, 23);

        jLabel21112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel21112.setForeground(java.awt.Color.darkGray);
        jLabel21112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel21112.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29");
        addCourseworkPanel.add(jLabel21112);
        jLabel21112.setBounds(10, 110, 100, 23);

        tfAddSubjectEname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectEname);
        tfAddSubjectEname.setBounds(130, 110, 380, 23);

        tfAddSubjectTname.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectTname);
        tfAddSubjectTname.setBounds(130, 140, 380, 23);

        jLabel31112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31112.setForeground(java.awt.Color.darkGray);
        jLabel31112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31112.setText("\u0e0a\u0e37\u0e48\u0e2d\u0e27\u0e34\u0e0a\u0e32\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22");
        addCourseworkPanel.add(jLabel31112);
        jLabel31112.setBounds(10, 140, 100, 23);

        jLabel31122.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31122.setForeground(java.awt.Color.darkGray);
        jLabel31122.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31122.setText("\u0e2b\u0e21\u0e27\u0e14\u0e27\u0e34\u0e0a\u0e32");
        addCourseworkPanel.add(jLabel31122);
        jLabel31122.setBounds(10, 170, 100, 23);

        cbAddSubjectType.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        cbAddSubjectType.setEnabled(false);
        addCourseworkPanel.add(cbAddSubjectType);
        cbAddSubjectType.setBounds(130, 170, 240, 23);

        jLabel1213.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1213.setForeground(java.awt.Color.darkGray);
        jLabel1213.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1213.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15");
        addCourseworkPanel.add(jLabel1213);
        jLabel1213.setBounds(10, 200, 100, 23);

        tfAddSubjectCredit.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectCredit);
        tfAddSubjectCredit.setBounds(130, 200, 60, 23);

        tfAddSubjectLecture.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectLecture);
        tfAddSubjectLecture.setBounds(130, 230, 60, 23);

        jLabel12112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12112.setForeground(java.awt.Color.darkGray);
        jLabel12112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12112.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1a\u0e23\u0e23\u0e22\u0e32\u0e22");
        addCourseworkPanel.add(jLabel12112);
        jLabel12112.setBounds(10, 230, 100, 23);

        jLabel1222.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1222.setForeground(java.awt.Color.darkGray);
        jLabel1222.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e1b\u0e0f\u0e34\u0e1a\u0e31\u0e15\u0e34");
        addCourseworkPanel.add(jLabel1222);
        jLabel1222.setBounds(200, 230, 90, 23);

        tfAddSubjectPractice.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectPractice);
        tfAddSubjectPractice.setBounds(290, 230, 60, 23);

        jLabel124.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel124.setForeground(java.awt.Color.darkGray);
        jLabel124.setText("\u0e2b\u0e19\u0e48\u0e27\u0e22\u0e01\u0e34\u0e15\u0e04\u0e49\u0e19\u0e04\u0e27\u0e49\u0e32");
        addCourseworkPanel.add(jLabel124);
        jLabel124.setBounds(360, 230, 90, 23);

        tfAddSubjectResearch.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addCourseworkPanel.add(tfAddSubjectResearch);
        tfAddSubjectResearch.setBounds(450, 230, 60, 23);

        jLabel311321.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel311321.setForeground(java.awt.Color.darkGray);
        jLabel311321.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel311321.setText("\u0e04\u0e33\u0e2d\u0e18\u0e34\u0e1a\u0e32\u0e22\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        addCourseworkPanel.add(jLabel311321);
        jLabel311321.setBounds(10, 270, 100, 23);

        jLabel311332.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel311332.setForeground(java.awt.Color.darkGray);
        jLabel311332.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel311332.setText("(\u0e20\u0e32\u0e29\u0e32\u0e44\u0e17\u0e22)");
        addCourseworkPanel.add(jLabel311332);
        jLabel311332.setBounds(10, 300, 100, 23);

        spToutline1.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpAddSubjectToutline.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        spToutline1.setViewportView(tpAddSubjectToutline);

        addCourseworkPanel.add(spToutline1);
        spToutline1.setBounds(130, 270, 380, 90);

        jLabel3115.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel3115.setForeground(java.awt.Color.darkGray);
        jLabel3115.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3115.setText("\u0e04\u0e33\u0e2d\u0e18\u0e34\u0e1a\u0e32\u0e22\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        addCourseworkPanel.add(jLabel3115);
        jLabel3115.setBounds(10, 370, 100, 23);

        jLabel31135.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel31135.setForeground(java.awt.Color.darkGray);
        jLabel31135.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel31135.setText("(\u0e20\u0e32\u0e29\u0e32\u0e2d\u0e31\u0e07\u0e01\u0e24\u0e29)");
        addCourseworkPanel.add(jLabel31135);
        jLabel31135.setBounds(10, 400, 100, 23);

        spEoutline1.setVerticalScrollBarPolicy(javax.swing.JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        tpAddSubjectEoutline.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        spEoutline1.setViewportView(tpAddSubjectEoutline);

        addCourseworkPanel.add(spEoutline1);
        spEoutline1.setBounds(130, 373, 380, 90);

        btAddSubjectOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSubjectOk.setForeground(java.awt.Color.darkGray);
        btAddSubjectOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddSubjectOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSubjectOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSubjectOkActionPerformed(evt);
            }
        });

        addCourseworkPanel.add(btAddSubjectOk);
        btAddSubjectOk.setBounds(180, 510, 80, 24);

        btAddSubjectCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSubjectCancel.setForeground(java.awt.Color.darkGray);
        btAddSubjectCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btAddSubjectCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSubjectCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSubjectCancelActionPerformed(evt);
            }
        });

        addCourseworkPanel.add(btAddSubjectCancel);
        btAddSubjectCancel.setBounds(290, 510, 81, 24);

        mainPanel.add(addCourseworkPanel, "addSubject");

        addPrerequisitePanel.setLayout(null);

        jLabel111121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel111121.setForeground(java.awt.Color.blue);
        jLabel111121.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel111121.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e02\u0e49\u0e2d\u0e21\u0e39\u0e25\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e01\u0e48\u0e2d\u0e19");
        addPrerequisitePanel.add(jLabel111121);
        jLabel111121.setBounds(190, 30, 210, 30);

        btAddPreSubCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddPreSubCancel.setForeground(java.awt.Color.darkGray);
        btAddPreSubCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btAddPreSubCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddPreSubCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddPreSubCancelActionPerformed(evt);
            }
        });

        addPrerequisitePanel.add(btAddPreSubCancel);
        btAddPreSubCancel.setBounds(300, 230, 90, 24);

        btAddPreSubOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddPreSubOk.setForeground(java.awt.Color.darkGray);
        btAddPreSubOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddPreSubOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddPreSubOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddPreSubOkActionPerformed(evt);
            }
        });

        addPrerequisitePanel.add(btAddPreSubOk);
        btAddPreSubOk.setBounds(180, 230, 90, 24);

        jLabel13.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel13.setForeground(java.awt.Color.red);
        jLabel13.setText("\u0e2b\u0e21\u0e32\u0e22\u0e40\u0e2b\u0e15\u0e38 : \u0e40\u0e25\u0e37\u0e2d\u0e01\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e17\u0e35\u0e48\u0e15\u0e49\u0e2d\u0e07\u0e01\u0e32\u0e23\u0e43\u0e2b\u0e49\u0e40\u0e1b\u0e47\u0e19\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e01\u0e48\u0e2d\u0e19");
        addPrerequisitePanel.add(jLabel13);
        jLabel13.setBounds(110, 160, 330, 26);

        jLabel1011.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1011.setForeground(java.awt.Color.darkGray);
        jLabel1011.setText("\u0e40\u0e25\u0e37\u0e2d\u0e01\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32");
        addPrerequisitePanel.add(jLabel1011);
        jLabel1011.setBounds(30, 110, 60, 26);

        cbPreSubID.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addPrerequisitePanel.add(cbPreSubID);
        cbPreSubID.setBounds(110, 110, 400, 26);

        mainPanel.add(addPrerequisitePanel, "addPrerequisiteDetail");

        allSectionDetailPanel.setLayout(null);

        lbSubjectNameSec.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbSubjectNameSec.setForeground(java.awt.Color.blue);
        lbSubjectNameSec.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbSubjectNameSec.setText("SUBJECT ID");
        allSectionDetailPanel.add(lbSubjectNameSec);
        lbSubjectNameSec.setBounds(20, 50, 520, 30);

        btAddSection.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSection.setForeground(java.awt.Color.darkGray);
        btAddSection.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        btAddSection.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSectionActionPerformed(evt);
            }
        });

        allSectionDetailPanel.add(btAddSection);
        btAddSection.setBounds(210, 240, 150, 24);

        jLabel3211112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel3211112.setForeground(java.awt.Color.red);
        jLabel3211112.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3211112.setText("\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19\u0e17\u0e31\u0e49\u0e07\u0e2b\u0e21\u0e14\u0e17\u0e35\u0e48\u0e40\u0e1b\u0e34\u0e14\u0e2a\u0e2d\u0e19");
        allSectionDetailPanel.add(jLabel3211112);
        jLabel3211112.setBounds(140, 100, 270, 30);

        mainPanel.add(allSectionDetailPanel, "addSection");

        prerequisiteDetailPanel.setLayout(null);

        jLabel3211111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel3211111.setForeground(java.awt.Color.red);
        jLabel3211111.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3211111.setText("\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e01\u0e48\u0e2d\u0e19");
        prerequisiteDetailPanel.add(jLabel3211111);
        jLabel3211111.setBounds(150, 100, 270, 30);

        btAddPreSubject.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddPreSubject.setForeground(java.awt.Color.darkGray);
        btAddPreSubject.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e23\u0e32\u0e22\u0e27\u0e34\u0e0a\u0e32\u0e1a\u0e31\u0e07\u0e04\u0e31\u0e1a\u0e01\u0e48\u0e2d\u0e19");
        btAddPreSubject.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddPreSubject.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddPreSubjectActionPerformed(evt);
            }
        });

        prerequisiteDetailPanel.add(btAddPreSubject);
        btAddPreSubject.setBounds(200, 240, 170, 24);

        lbSubjectNamePre.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        lbSubjectNamePre.setForeground(java.awt.Color.blue);
        lbSubjectNamePre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbSubjectNamePre.setText("SUBJECT ID");
        prerequisiteDetailPanel.add(lbSubjectNamePre);
        lbSubjectNamePre.setBounds(20, 50, 520, 30);

        mainPanel.add(prerequisiteDetailPanel, "addPrerequisite");

        addSectionPanel.setLayout(null);

        tfAddMaxStudent.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddMaxStudent);
        tfAddMaxStudent.setBounds(170, 330, 80, 23);

        jLabel161.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel161.setForeground(java.awt.Color.darkGray);
        jLabel161.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel161.setText("\u0e25\u0e47\u0e2d\u0e04\u0e08\u0e33\u0e19\u0e27\u0e19\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        addSectionPanel.add(jLabel161);
        jLabel161.setBounds(10, 360, 140, 23);

        jLabel151.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel151.setForeground(java.awt.Color.darkGray);
        jLabel151.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel151.setText("\u0e2b\u0e49\u0e2d\u0e07\u0e17\u0e35\u0e48\u0e43\u0e0a\u0e49\u0e2a\u0e2d\u0e1a\u0e44\u0e25\u0e48\u0e1b\u0e23\u0e30\u0e08\u0e33\u0e20\u0e32\u0e04");
        addSectionPanel.add(jLabel151);
        jLabel151.setBounds(10, 300, 140, 23);

        jLabel1421.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1421.setForeground(java.awt.Color.darkGray);
        jLabel1421.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1421.setText("\u0e40\u0e27\u0e25\u0e32\u0e2a\u0e2d\u0e1a\u0e44\u0e25\u0e48\u0e1b\u0e23\u0e30\u0e08\u0e33\u0e20\u0e32\u0e04");
        addSectionPanel.add(jLabel1421);
        jLabel1421.setBounds(10, 270, 140, 23);

        jLabel1411.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1411.setForeground(java.awt.Color.darkGray);
        jLabel1411.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1411.setText("\u0e27\u0e31\u0e19\u0e2a\u0e2d\u0e1a\u0e44\u0e25\u0e48\u0e1b\u0e23\u0e30\u0e08\u0e33\u0e20\u0e32\u0e04");
        addSectionPanel.add(jLabel1411);
        jLabel1411.setBounds(10, 240, 140, 23);

        jLabel1311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1311.setForeground(java.awt.Color.darkGray);
        jLabel1311.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1311.setText("\u0e2b\u0e49\u0e2d\u0e07\u0e17\u0e35\u0e48\u0e43\u0e0a\u0e49\u0e2a\u0e2d\u0e19");
        addSectionPanel.add(jLabel1311);
        jLabel1311.setBounds(10, 210, 140, 23);

        jLabel12211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12211.setForeground(java.awt.Color.darkGray);
        jLabel12211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12211.setText("\u0e40\u0e27\u0e25\u0e32\u0e17\u0e35\u0e48\u0e2a\u0e2d\u0e19");
        addSectionPanel.add(jLabel12211);
        jLabel12211.setBounds(10, 180, 140, 23);

        jLabel12113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12113.setForeground(java.awt.Color.darkGray);
        jLabel12113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12113.setText("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e2a\u0e2d\u0e19");
        addSectionPanel.add(jLabel12113);
        jLabel12113.setBounds(10, 150, 140, 23);

        jLabel111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel111.setForeground(java.awt.Color.blue);
        jLabel111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel111.setText("\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19\u0e17\u0e35\u0e48");
        addSectionPanel.add(jLabel111);
        jLabel111.setBounds(10, 90, 140, 23);

        jLabel18.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel18.setForeground(java.awt.Color.blue);
        jLabel18.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel18.setText("\u0e40\u0e1e\u0e34\u0e48\u0e21\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        addSectionPanel.add(jLabel18);
        jLabel18.setBounds(170, 30, 180, 21);

        cbAddLecturer.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(cbAddLecturer);
        cbAddLecturer.setBounds(170, 120, 200, 23);

        cbAddStudyDay.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(cbAddStudyDay);
        cbAddStudyDay.setBounds(170, 150, 90, 23);

        tfAddSecNumber.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddSecNumber);
        tfAddSecNumber.setBounds(170, 90, 60, 23);

        tfAddFinalYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddFinalYear);
        tfAddFinalYear.setBounds(410, 240, 60, 23);

        jLabel1323.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1323.setForeground(java.awt.Color.darkGray);
        jLabel1323.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1323.setText("\u0e1b\u0e35");
        addSectionPanel.add(jLabel1323);
        jLabel1323.setBounds(380, 240, 20, 23);

        cbAddFinalMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(cbAddFinalMonth);
        cbAddFinalMonth.setBounds(270, 240, 110, 23);

        jLabel133.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel133.setForeground(java.awt.Color.darkGray);
        jLabel133.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel133.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        addSectionPanel.add(jLabel133);
        jLabel133.setBounds(220, 240, 40, 23);

        cbAddFinalDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(cbAddFinalDate);
        cbAddFinalDate.setBounds(170, 240, 50, 23);

        tfAddStudyRoom.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddStudyRoom);
        tfAddStudyRoom.setBounds(170, 210, 180, 23);

        tfAddStudyStartHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddStudyStartHour);
        tfAddStudyStartHour.setBounds(170, 180, 40, 23);

        jLabel1441.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1441.setForeground(java.awt.Color.darkGray);
        jLabel1441.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1441.setText(":");
        addSectionPanel.add(jLabel1441);
        jLabel1441.setBounds(210, 180, 10, 23);

        tfAddStudyStartMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddStudyStartMinute);
        tfAddStudyStartMinute.setBounds(220, 180, 40, 23);

        jLabel12221.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12221.setForeground(java.awt.Color.darkGray);
        jLabel12221.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12221.setText("\u0e16\u0e36\u0e07");
        addSectionPanel.add(jLabel12221);
        jLabel12221.setBounds(270, 180, 20, 23);

        tfAddStudyEndHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddStudyEndHour);
        tfAddStudyEndHour.setBounds(310, 180, 40, 23);

        jLabel1442.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1442.setForeground(java.awt.Color.darkGray);
        jLabel1442.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1442.setText(":");
        addSectionPanel.add(jLabel1442);
        jLabel1442.setBounds(350, 180, 10, 23);

        tfAddStudyEndMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddStudyEndMinute);
        tfAddStudyEndMinute.setBounds(360, 180, 40, 23);

        tfAddFinalStartHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddFinalStartHour);
        tfAddFinalStartHour.setBounds(170, 270, 40, 23);

        jLabel1431.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1431.setForeground(java.awt.Color.darkGray);
        jLabel1431.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1431.setText(":");
        addSectionPanel.add(jLabel1431);
        jLabel1431.setBounds(210, 270, 10, 23);

        tfAddFinalStartMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddFinalStartMinute);
        tfAddFinalStartMinute.setBounds(220, 270, 40, 23);

        jLabel1223.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1223.setForeground(java.awt.Color.darkGray);
        jLabel1223.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1223.setText("\u0e16\u0e36\u0e07");
        addSectionPanel.add(jLabel1223);
        jLabel1223.setBounds(270, 270, 20, 23);

        tfAddFinalEndHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddFinalEndHour);
        tfAddFinalEndHour.setBounds(310, 270, 40, 23);

        jLabel144.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel144.setForeground(java.awt.Color.darkGray);
        jLabel144.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel144.setText(":");
        addSectionPanel.add(jLabel144);
        jLabel144.setBounds(350, 270, 10, 23);

        tfAddFinalEndMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddFinalEndMinute);
        tfAddFinalEndMinute.setBounds(360, 270, 40, 23);

        tfAddFinalRoom.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        addSectionPanel.add(tfAddFinalRoom);
        tfAddFinalRoom.setBounds(170, 300, 180, 23);

        btDelSectionCancel.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelSectionCancel.setForeground(java.awt.Color.darkGray);
        btDelSectionCancel.setText("\u0e22\u0e01\u0e40\u0e25\u0e34\u0e01");
        btDelSectionCancel.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelSectionCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelSectionCancelActionPerformed(evt);
            }
        });

        addSectionPanel.add(btDelSectionCancel);
        btDelSectionCancel.setBounds(260, 450, 90, 24);

        btAddSectionOk.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btAddSectionOk.setForeground(java.awt.Color.darkGray);
        btAddSectionOk.setText("\u0e15\u0e01\u0e25\u0e07");
        btAddSectionOk.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btAddSectionOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAddSectionOkActionPerformed(evt);
            }
        });

        addSectionPanel.add(btAddSectionOk);
        btAddSectionOk.setBounds(140, 450, 90, 24);

        jLabel1112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1112.setForeground(java.awt.Color.darkGray);
        jLabel1112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1112.setText("\u0e2d\u0e32\u0e08\u0e32\u0e23\u0e22\u0e4c\u0e1c\u0e39\u0e49\u0e2a\u0e2d\u0e19");
        addSectionPanel.add(jLabel1112);
        jLabel1112.setBounds(10, 120, 140, 23);

        jLabel1611.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1611.setForeground(java.awt.Color.darkGray);
        jLabel1611.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1611.setText("\u0e08\u0e33\u0e19\u0e27\u0e19\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e23\u0e31\u0e1a");
        addSectionPanel.add(jLabel1611);
        jLabel1611.setBounds(10, 330, 140, 23);

        rbAddLockYes.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        rbAddLockYes.setForeground(java.awt.Color.darkGray);
        rbAddLockYes.setText("Yes");
        radioGroup1.add(rbAddLockYes);
        addSectionPanel.add(rbAddLockYes);
        rbAddLockYes.setBounds(170, 360, 50, 23);

        rbAddLockNo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        rbAddLockNo.setForeground(java.awt.Color.darkGray);
        rbAddLockNo.setSelected(true);
        rbAddLockNo.setText("No");
        radioGroup1.add(rbAddLockNo);
        addSectionPanel.add(rbAddLockNo);
        rbAddLockNo.setBounds(230, 360, 50, 23);

        mainPanel.add(addSectionPanel, "addSectionDetail");

        sectionDetailPanel.setLayout(null);

        rbLockNo.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        rbLockNo.setForeground(java.awt.Color.darkGray);
        rbLockNo.setSelected(true);
        rbLockNo.setText("No");
        radioGroup2.add(rbLockNo);
        sectionDetailPanel.add(rbLockNo);
        rbLockNo.setBounds(230, 390, 50, 23);

        rbLockYes.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        rbLockYes.setForeground(java.awt.Color.darkGray);
        rbLockYes.setText("Yes");
        radioGroup2.add(rbLockYes);
        sectionDetailPanel.add(rbLockYes);
        rbLockYes.setBounds(170, 390, 50, 23);

        jLabel1612.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1612.setForeground(java.awt.Color.darkGray);
        jLabel1612.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1612.setText("\u0e25\u0e47\u0e2d\u0e04\u0e08\u0e33\u0e19\u0e27\u0e19\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32");
        sectionDetailPanel.add(jLabel1612);
        jLabel1612.setBounds(10, 390, 140, 23);

        tfCurrentStudent.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        tfCurrentStudent.setDisabledTextColor(java.awt.Color.black);
        tfCurrentStudent.setEnabled(false);
        sectionDetailPanel.add(tfCurrentStudent);
        tfCurrentStudent.setBounds(170, 360, 80, 23);

        jLabel16111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel16111.setForeground(java.awt.Color.darkGray);
        jLabel16111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel16111.setText("\u0e2a\u0e16\u0e32\u0e19\u0e30\u0e01\u0e32\u0e23\u0e40\u0e1b\u0e34\u0e14 - \u0e1b\u0e34\u0e14");
        sectionDetailPanel.add(jLabel16111);
        jLabel16111.setBounds(10, 420, 140, 23);

        tfFinalRoom.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfFinalRoom);
        tfFinalRoom.setBounds(170, 300, 180, 23);

        jLabel1511.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1511.setForeground(java.awt.Color.darkGray);
        jLabel1511.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1511.setText("\u0e2b\u0e49\u0e2d\u0e07\u0e17\u0e35\u0e48\u0e43\u0e0a\u0e49\u0e2a\u0e2d\u0e1a\u0e44\u0e25\u0e48\u0e1b\u0e23\u0e30\u0e08\u0e33\u0e20\u0e32\u0e04");
        sectionDetailPanel.add(jLabel1511);
        jLabel1511.setBounds(10, 300, 140, 23);

        tfFinalEndMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfFinalEndMinute);
        tfFinalEndMinute.setBounds(360, 270, 40, 23);

        jLabel1443.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1443.setForeground(java.awt.Color.darkGray);
        jLabel1443.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1443.setText(":");
        sectionDetailPanel.add(jLabel1443);
        jLabel1443.setBounds(350, 270, 10, 23);

        tfFinalEndHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfFinalEndHour);
        tfFinalEndHour.setBounds(310, 270, 40, 23);

        jLabel12231.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel12231.setForeground(java.awt.Color.darkGray);
        jLabel12231.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel12231.setText("\u0e16\u0e36\u0e07");
        sectionDetailPanel.add(jLabel12231);
        jLabel12231.setBounds(270, 270, 20, 23);

        tfFinalStartMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfFinalStartMinute);
        tfFinalStartMinute.setBounds(220, 270, 40, 23);

        jLabel14311.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel14311.setForeground(java.awt.Color.darkGray);
        jLabel14311.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14311.setText(":");
        sectionDetailPanel.add(jLabel14311);
        jLabel14311.setBounds(210, 270, 10, 23);

        tfFinalStartHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfFinalStartHour);
        tfFinalStartHour.setBounds(170, 270, 40, 23);

        jLabel14211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel14211.setForeground(java.awt.Color.darkGray);
        jLabel14211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14211.setText("\u0e40\u0e27\u0e25\u0e32\u0e2a\u0e2d\u0e1a\u0e44\u0e25\u0e48\u0e1b\u0e23\u0e30\u0e08\u0e33\u0e20\u0e32\u0e04");
        sectionDetailPanel.add(jLabel14211);
        jLabel14211.setBounds(10, 270, 140, 23);

        jLabel14111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel14111.setForeground(java.awt.Color.darkGray);
        jLabel14111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel14111.setText("\u0e27\u0e31\u0e19\u0e2a\u0e2d\u0e1a\u0e44\u0e25\u0e48\u0e1b\u0e23\u0e30\u0e08\u0e33\u0e20\u0e32\u0e04");
        sectionDetailPanel.add(jLabel14111);
        jLabel14111.setBounds(10, 240, 140, 23);

        cbStatus.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        cbStatus.setEnabled(false);
        sectionDetailPanel.add(cbStatus);
        cbStatus.setBounds(170, 420, 130, 23);

        jLabel1331.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1331.setForeground(java.awt.Color.darkGray);
        jLabel1331.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1331.setText("\u0e40\u0e14\u0e37\u0e2d\u0e19");
        sectionDetailPanel.add(jLabel1331);
        jLabel1331.setBounds(220, 240, 40, 23);

        cbFinalMonth.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(cbFinalMonth);
        cbFinalMonth.setBounds(270, 240, 110, 23);

        jLabel13231.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel13231.setForeground(java.awt.Color.darkGray);
        jLabel13231.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13231.setText("\u0e1b\u0e35");
        sectionDetailPanel.add(jLabel13231);
        jLabel13231.setBounds(380, 240, 20, 23);

        tfFinalYear.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfFinalYear);
        tfFinalYear.setBounds(410, 240, 60, 23);

        tfStudyRoom.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfStudyRoom);
        tfStudyRoom.setBounds(170, 210, 180, 23);

        jLabel13111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel13111.setForeground(java.awt.Color.darkGray);
        jLabel13111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel13111.setText("\u0e2b\u0e49\u0e2d\u0e07\u0e17\u0e35\u0e48\u0e43\u0e0a\u0e49\u0e2a\u0e2d\u0e19");
        sectionDetailPanel.add(jLabel13111);
        jLabel13111.setBounds(10, 210, 140, 23);

        jLabel122111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel122111.setForeground(java.awt.Color.darkGray);
        jLabel122111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel122111.setText("\u0e40\u0e27\u0e25\u0e32\u0e17\u0e35\u0e48\u0e2a\u0e2d\u0e19");
        sectionDetailPanel.add(jLabel122111);
        jLabel122111.setBounds(10, 180, 140, 23);

        tfStudyStartHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfStudyStartHour);
        tfStudyStartHour.setBounds(170, 180, 40, 23);

        jLabel14411.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel14411.setForeground(java.awt.Color.darkGray);
        jLabel14411.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14411.setText(":");
        sectionDetailPanel.add(jLabel14411);
        jLabel14411.setBounds(210, 180, 10, 23);

        tfStudyStartMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfStudyStartMinute);
        tfStudyStartMinute.setBounds(220, 180, 40, 23);

        jLabel122211.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel122211.setForeground(java.awt.Color.darkGray);
        jLabel122211.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel122211.setText("\u0e16\u0e36\u0e07");
        sectionDetailPanel.add(jLabel122211);
        jLabel122211.setBounds(270, 180, 20, 23);

        tfStudyEndHour.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfStudyEndHour);
        tfStudyEndHour.setBounds(310, 180, 40, 23);

        jLabel14421.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel14421.setForeground(java.awt.Color.darkGray);
        jLabel14421.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14421.setText(":");
        sectionDetailPanel.add(jLabel14421);
        jLabel14421.setBounds(350, 180, 10, 23);

        tfStudyEndMinute.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfStudyEndMinute);
        tfStudyEndMinute.setBounds(360, 180, 40, 23);

        jLabel121131.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel121131.setForeground(java.awt.Color.darkGray);
        jLabel121131.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel121131.setText("\u0e27\u0e31\u0e19\u0e17\u0e35\u0e48\u0e2a\u0e2d\u0e19");
        sectionDetailPanel.add(jLabel121131);
        jLabel121131.setBounds(10, 150, 140, 23);

        cbStudyDay.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(cbStudyDay);
        cbStudyDay.setBounds(170, 150, 90, 23);

        cbLecturer.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(cbLecturer);
        cbLecturer.setBounds(170, 120, 200, 23);

        jLabel11121.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel11121.setForeground(java.awt.Color.darkGray);
        jLabel11121.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel11121.setText("\u0e2d\u0e32\u0e08\u0e32\u0e23\u0e22\u0e4c\u0e1c\u0e39\u0e49\u0e2a\u0e2d\u0e19");
        sectionDetailPanel.add(jLabel11121);
        jLabel11121.setBounds(10, 120, 140, 23);

        jLabel1113.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel1113.setForeground(java.awt.Color.darkGray);
        jLabel1113.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel1113.setText("\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19\u0e17\u0e35\u0e48");
        sectionDetailPanel.add(jLabel1113);
        jLabel1113.setBounds(10, 90, 140, 23);

        tfSecNumber.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfSecNumber);
        tfSecNumber.setBounds(170, 90, 60, 23);

        jLabel181.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 18));
        jLabel181.setForeground(java.awt.Color.blue);
        jLabel181.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel181.setText("\u0e23\u0e32\u0e22\u0e25\u0e30\u0e40\u0e2d\u0e35\u0e22\u0e14\u0e02\u0e2d\u0e07\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        sectionDetailPanel.add(jLabel181);
        jLabel181.setBounds(170, 30, 180, 21);

        btCloseSection.setBackground((java.awt.Color) javax.swing.UIManager.getDefaults().get("Button.focus"));
        btCloseSection.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btCloseSection.setForeground(java.awt.Color.darkGray);
        btCloseSection.setText("\u0e1b\u0e34\u0e14\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        btCloseSection.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btCloseSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCloseSectionActionPerformed(evt);
            }
        });

        sectionDetailPanel.add(btCloseSection);
        btCloseSection.setBounds(160, 490, 110, 24);

        btEditSection.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btEditSection.setForeground(java.awt.Color.darkGray);
        btEditSection.setText("\u0e41\u0e01\u0e49\u0e44\u0e02\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        btEditSection.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btEditSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditSectionActionPerformed(evt);
            }
        });

        sectionDetailPanel.add(btEditSection);
        btEditSection.setBounds(290, 490, 110, 24);

        btOpenSection.setBackground((java.awt.Color) javax.swing.UIManager.getDefaults().get("Button.focus"));
        btOpenSection.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btOpenSection.setForeground(java.awt.Color.darkGray);
        btOpenSection.setText("\u0e40\u0e1b\u0e34\u0e14\u0e40\u0e0a\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        btOpenSection.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btOpenSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btOpenSectionActionPerformed(evt);
            }
        });

        sectionDetailPanel.add(btOpenSection);
        btOpenSection.setBounds(30, 490, 110, 24);

        btDelSection.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        btDelSection.setForeground(java.awt.Color.darkGray);
        btDelSection.setText("\u0e25\u0e1a\u0e40\u0e0b\u0e47\u0e04\u0e0a\u0e31\u0e48\u0e19");
        btDelSection.setBorder(new javax.swing.border.BevelBorder(javax.swing.border.BevelBorder.RAISED));
        btDelSection.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDelSectionActionPerformed(evt);
            }
        });

        sectionDetailPanel.add(btDelSection);
        btDelSection.setBounds(420, 490, 110, 24);

        tfMaxStudent.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(tfMaxStudent);
        tfMaxStudent.setBounds(170, 330, 80, 23);

        jLabel161111.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel161111.setForeground(java.awt.Color.darkGray);
        jLabel161111.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel161111.setText("\u0e08\u0e33\u0e19\u0e27\u0e19\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e23\u0e31\u0e1a");
        sectionDetailPanel.add(jLabel161111);
        jLabel161111.setBounds(10, 330, 140, 23);

        jLabel161112.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jLabel161112.setForeground(java.awt.Color.darkGray);
        jLabel161112.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel161112.setText("\u0e08\u0e33\u0e19\u0e27\u0e19\u0e19\u0e31\u0e01\u0e28\u0e36\u0e01\u0e29\u0e32\u0e17\u0e35\u0e48\u0e25\u0e07\u0e17\u0e30\u0e40\u0e1a\u0e35\u0e22\u0e19");
        sectionDetailPanel.add(jLabel161112);
        jLabel161112.setBounds(10, 360, 140, 23);

        cbFinalDate.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        sectionDetailPanel.add(cbFinalDate);
        cbFinalDate.setBounds(170, 240, 50, 23);

        mainPanel.add(sectionDetailPanel, "sectionDetail");

        jSplitPane.setRightComponent(mainPanel);

        getContentPane().add(jSplitPane, java.awt.BorderLayout.CENTER);

        jMenu1.setForeground(java.awt.Color.darkGray);
        jMenu1.setText("\u0e40\u0e21\u0e19\u0e39");
        jMenu1.setFont(new java.awt.Font("Microsoft Sans Serif", 0, 12));
        jMenuBar1.add(jMenu1);
        setJMenuBar(jMenuBar1);

        pack();
        java.awt.Dimension screenSize = java.awt.Toolkit.getDefaultToolkit().getScreenSize();
        setSize(new java.awt.Dimension(761, 613));
        setLocation((screenSize.width-761)/2,(screenSize.height-613)/2);
    }//GEN-END:initComponents

    private void btEditSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditSectionActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ�����䢢����� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {                          
            if(!tfSecNumber.getText().equals(""))
            {
                HandleSection hSection = new HandleSection();
            
                Section s = (Section)tree.getUserObject();
                
                s.setId(((Section)tree.getUserObject()).getId());
                s.setMaxStudent(tfMaxStudent.getText());
                s.setSec(tfSecNumber.getText());
                s.setRoom(tfStudyRoom.getText());
                s.setFinTermRoom(tfFinalRoom.getText());
                s.setDay((String)cbStudyDay.getSelectedItem());
            
                if(rbLockYes.isSelected())
                {
                    s.setLock("Y");
                }
                else
                {
                    s.setLock("N");
                }
            
                if(cbFinalDate.getSelectedIndex() != 0 && cbFinalMonth.getSelectedIndex() != 0 && !tfFinalYear.getText().equals(""))
                {
                    try
                    {
                        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                        java.util.Date finalDate = null;                
                        finalDate = format.parse(Integer.toString(cbFinalDate.getSelectedIndex()) + "/" + Integer.toString(cbFinalMonth.getSelectedIndex()) + "/" + tfFinalYear.getText().trim());
                        s.setFinTermDate(finalDate);
                    }
                    catch(ParseException pex)
                    {
                        JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                        return;
                    }                           
                }
            
                if(!tfStudyStartHour.getText().equals("") && !tfStudyStartMinute.getText().equals(""))
                {
                    s.setBeginTime(tfStudyStartHour.getText() + ":" + tfStudyStartMinute.getText() + ":00");
                }
            
                if(!tfStudyEndHour.getText().equals("") && !tfStudyEndMinute.getText().equals(""))
                {
                    s.setEndTime(tfStudyEndHour.getText() + ":" + tfStudyEndMinute.getText() + ":00");
                }
            
                if(!tfFinalStartHour.getText().equals("") && !tfFinalStartMinute.getText().equals(""))
                {
                    s.setFinTermBeginTime(tfFinalStartHour.getText() + ":" + tfFinalStartMinute.getText() + ":00");
                }

                if(!tfFinalEndHour.getText().equals("") && !tfFinalEndMinute.getText().equals(""))
                {
                    s.setFinTermEndTime(tfFinalEndHour.getText() + ":" + tfFinalEndMinute.getText() + ":00");
                }
            
                if(hSection.updateSection(s))
                {                    
                    HandleLecturer hLecturer = new HandleLecturer();
                
                    if(cbLecturer.getSelectedItem() != null)
                    {
                        hLecturer.updateTeach(s, (Lecturer)cbLecturer.getSelectedItem());
                        s.setLecturer((Lecturer)cbLecturer.getSelectedItem());                        
                    }                
                    
                    tree.setUserObject(s);
                    JOptionPane.showMessageDialog(null, "�����䢢���������������º����", "Message", JOptionPane.ERROR_MESSAGE);                                                
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "�Դ��ͼԴ��Ҵ㹡����䢢������礪��", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                                
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
            }
        }
    }//GEN-LAST:event_btEditSectionActionPerformed

    private void btEditSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditSubjectActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ�����䢢����� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {                            
            if(!tfSubjectID.getText().equals(""))
            {
                HandleSubject hSubject = new HandleSubject();
            
                Subject s = (Subject)tree.getUserObject();
            
                s.setId(tfSubjectID.getText());
                s.setEname(tfSubjectEname.getText());
                s.setTname(tfSubjectTname.getText());
                s.setCredit(tfSubjectCredit.getText());
                s.setLecture(tfSubjectLecture.getText());
                s.setPractice(tfSubjectPractice.getText());
                s.setResearch(tfSubjectResearch.getText());
                s.setEoutline(tpSubjectEoutline.getText());
                s.setToutline(tpSubjectToutline.getText());
            
                switch(cbSubjectType.getSelectedIndex())
                {
                    case 1:
                        s.setGroup("C");
                        break;
                    case 2:
                        s.setGroup("E");
                        break;
                    case 3:
                        s.setGroup("T");
                        break;
                    default:
                }
            
                if(hSubject.updateSubject(s, course, subcourse))
                {
                    // update successful
                    tree.setUserObject(s);
                    JOptionPane.showMessageDialog(null, "�����䢢���������������º����", "Message", JOptionPane.ERROR_MESSAGE);                                                                    
                }
                else
                {
                    // update fail
                    JOptionPane.showMessageDialog(null, "��â�ͼԴ��Ҵ㹡���������Ԫ�", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                
                }
            }
            else
            {
                JOptionPane.showMessageDialog(null, "��سҡ�͡��������Ԫҡ�͹", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                    
            }
        }
    }//GEN-LAST:event_btEditSubjectActionPerformed

    private void btDelSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelSectionActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {                    
            HandleSection hSection = new HandleSection();
            
            if(hSection.removeSection((Subject)tree.getUserObject(2), (Section)tree.getUserObject()))
            {
                tree.removeCurrentNode();            
                cardManager.show(mainPanel, "addSection"); 
            }
        }        
    }//GEN-LAST:event_btDelSectionActionPerformed

    private void btCloseSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCloseSectionActionPerformed
        // Add your handling code here:
        HandleSection hSection = new HandleSection();
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ��ûԴ�礪�� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {                    
            if(hSection.closeSection((Section)tree.getUserObject(), (Subject)tree.getUserObject(2)))
            {
                cbStatus.setSelectedIndex(2);
            }
        }
    }//GEN-LAST:event_btCloseSectionActionPerformed

    private void btOpenSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btOpenSectionActionPerformed
        // Add your handling code here:
        HandleSection hSection = new HandleSection();
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ����Դ�礪�� ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {            
            if(hSection.openSection((Section)tree.getUserObject(), (Subject)tree.getUserObject(2)))
            {
                cbStatus.setSelectedIndex(1);
            }        
        }
    }//GEN-LAST:event_btOpenSectionActionPerformed

    private void btAddSectionOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSectionOkActionPerformed
        // Add your handling code here:
        if(!tfAddSecNumber.getText().equals(""))
        {
            HandleSection hSection = new HandleSection();
            
            Section s = new Section();
            
            s.setMaxStudent(tfAddMaxStudent.getText());
            s.setSec(tfAddSecNumber.getText());
            s.setRoom(tfAddStudyRoom.getText());
            s.setFinTermRoom(tfAddFinalRoom.getText());
            s.setDay((String)cbAddStudyDay.getSelectedItem());
            s.setStatus("C");
            s.setCurrentStudent("0");
            
            if(rbAddLockYes.isSelected())
            {
                s.setLock("Y");
            }
            else
            {
                s.setLock("N");
            }
            
            if(cbAddFinalDate.getSelectedIndex() != 0 && cbAddFinalMonth.getSelectedIndex() != 0 && !tfAddFinalYear.getText().equals(""))
            {
                try
                {
                    SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");            
                    java.util.Date finalDate = null;                
                    finalDate = format.parse(Integer.toString(cbAddFinalDate.getSelectedIndex()) + "/" + Integer.toString(cbAddFinalMonth.getSelectedIndex()) + "/" + tfAddFinalYear.getText().trim());
                    s.setFinTermDate(finalDate);
                }
                catch(ParseException pex)
                {
                    JOptionPane.showMessageDialog(null, "��سҡ�͡�ѹ������١��ͧ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
                    return;
                }                           
            }
            
            if(!tfAddStudyStartHour.getText().equals("") && !tfAddStudyStartMinute.getText().equals(""))
            {
                s.setBeginTime(tfAddStudyStartHour.getText() + ":" + tfAddStudyStartMinute.getText() + ":00");
            }
            
            if(!tfAddStudyEndHour.getText().equals("") && !tfAddStudyEndMinute.getText().equals(""))
            {
                s.setEndTime(tfAddStudyEndHour.getText() + ":" + tfAddStudyEndMinute.getText() + ":00");
            }
            
            if(!tfAddFinalStartHour.getText().equals("") && !tfAddFinalStartMinute.getText().equals(""))
            {
                s.setFinTermBeginTime(tfAddFinalStartHour.getText() + ":" + tfAddFinalStartMinute.getText() + ":00");
            }

            if(!tfAddFinalEndHour.getText().equals("") && !tfAddFinalEndMinute.getText().equals(""))
            {
                s.setFinTermEndTime(tfAddFinalEndHour.getText() + ":" + tfAddFinalEndMinute.getText() + ":00");
            }
            
            // add section to database
            if(hSection.addSection((Subject)tree.getUserObject(1), s))
            {
                s = hSection.retrieveSection(s, (Subject)tree.getUserObject(1));
                HandleLecturer hLecturer = new HandleLecturer();
                
                if(cbAddLecturer.getSelectedItem() != null)
                {
                    hLecturer.addTeach(s, (Lecturer)cbAddLecturer.getSelectedItem());
                }
                
                cardManager.show(mainPanel, "addSection");                    
                s = hSection.retrieveSection(s, (Subject)tree.getUserObject(1));
                tree.addObject(s);                                
            }
            else
            {
                JOptionPane.showMessageDialog(null, "��������礪���Դ��ͼԴ��Ҵ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��سҡ�͡���������ú��ǹ", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                
        }
    }//GEN-LAST:event_btAddSectionOkActionPerformed

    private void btDelSectionCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelSectionCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "addSection");
    }//GEN-LAST:event_btDelSectionCancelActionPerformed

    private void btAddSectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSectionActionPerformed
        // Add your handling code here:        
        cardManager.show(mainPanel, "addSectionDetail");
        cbAddLecturer.removeAllItems();
        cbAddLecturer.addItem(null);
        
        HandleLecturer hLecturer = new HandleLecturer();        
        Vector v = hLecturer.retrieveAllLecturer();
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            cbAddLecturer.addItem((Lecturer)e.nextElement());
        }
    }//GEN-LAST:event_btAddSectionActionPerformed

    private void btAddPreSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddPreSubjectActionPerformed
        // Add your handling code here:
        cbPreSubID.removeAllItems();
        cbPreSubID.addItem(null);
        HandleSubject hSubject = new HandleSubject();
        Vector v = hSubject.retrieveAllSubject(course, subcourse);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Subject subject = (Subject)e.nextElement();
            cbPreSubID.addItem(subject);
        }
        
        cardManager.show(mainPanel, "addPrerequisiteDetail");        
    }//GEN-LAST:event_btAddPreSubjectActionPerformed

    private void btAddPreSubOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddPreSubOkActionPerformed
        // Add your handling code here:
        if(cbPreSubID.getSelectedItem() != null)
        {
            HandleSubject hSubject = new HandleSubject();
            
            Subject prerequisite = (Subject)cbPreSubID.getSelectedItem();            
            Subject subject = (Subject)tree.getUserObject(1);
            
            if(hSubject.addPrerequisite(subject, prerequisite))
            {
                cardManager.show(mainPanel, "courseworkDetail");
                tree.addObject(prerequisite);
                cbPreSubID.setSelectedIndex(0);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "������ԪҴѧ�������������", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                                    
            }           
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��س����͡����ԪҺѧ�Ѻ��͹", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                    
        }
    }//GEN-LAST:event_btAddPreSubOkActionPerformed

    private void btDelPrerequisiteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelPrerequisiteActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {    
            HandleSubject hSubject = new HandleSubject();                
            hSubject.deletePrerequisite((Subject)tree.getUserObject(2), (Subject)tree.getUserObject());
            tree.removeCurrentNode();            
            cardManager.show(mainPanel, "courseworkDetail");            
        }       
    }//GEN-LAST:event_btDelPrerequisiteActionPerformed

    private void btAddPreSubCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddPreSubCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "courseworkDetail");
    }//GEN-LAST:event_btAddPreSubCancelActionPerformed

    private void btDelSubjectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDelSubjectActionPerformed
        // Add your handling code here:
        if(JOptionPane.showConfirmDialog(null, "�׹�ѹ���ź������ ?", "�׹�ѹ", JOptionPane.YES_NO_OPTION) == 0)
        {    
            HandleSubject hSubject = new HandleSubject();                
            hSubject.deleteSubject((Subject)tree.getUserObject(), course, subcourse);
            tree.removeCurrentNode();            
            cardManager.show(mainPanel, "courseworkGroup");            
        }
    }//GEN-LAST:event_btDelSubjectActionPerformed

    private void btAddSubjectOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSubjectOkActionPerformed
        // Add your handling code here:
        if(!tfAddSubjectID.getText().equals(""))
        {
            HandleSubject hSubject = new HandleSubject();
            
            Subject s = new Subject();
            
            s.setId(tfAddSubjectID.getText());
            s.setEname(tfAddSubjectEname.getText());
            s.setTname(tfAddSubjectTname.getText());
            s.setCredit(tfAddSubjectCredit.getText());
            s.setLecture(tfAddSubjectLecture.getText());
            s.setPractice(tfAddSubjectPractice.getText());
            s.setResearch(tfAddSubjectResearch.getText());
            s.setEoutline(tpAddSubjectEoutline.getText());
            s.setToutline(tpAddSubjectToutline.getText());
            
            switch(cbAddSubjectType.getSelectedIndex())
            {
                case 1:
                    s.setGroup("C");
                    break;
                case 2:
                    s.setGroup("E");
                    break;
                case 3:
                    s.setGroup("T");
                    break;
                default:
            }
            
            if(hSubject.addSubject(s, course, subcourse))
            {
                // if insert successful
                cardManager.show(mainPanel, "courseworkGroup");
                DefaultMutableTreeNode subjectNode = tree.addObject(s);
                tree.addObject(subjectNode, "�礪��");
                tree.addObject(subjectNode, "����ԪҺѧ�Ѻ��͹");
                
                tfAddSubjectID.setText("");
                tfAddSubjectEname.setText("");
                tfAddSubjectTname.setText("");
                tfAddSubjectCredit.setText("");
                tfAddSubjectLecture.setText("");
                tfAddSubjectPractice.setText("");
                tfAddSubjectResearch.setText("");
                tpAddSubjectEoutline.setText("");
                tpAddSubjectToutline.setText("");
                cbAddSubjectType.setSelectedIndex(0);                
            }
            else
            {
                // insert fail
                JOptionPane.showMessageDialog(null, "��â�ͼԴ��Ҵ㹡����������Ԫ�", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                
            }
        }
        else
        {
            JOptionPane.showMessageDialog(null, "��سҡ�͡��������Ԫҡ�͹", "�Դ��ͼԴ��Ҵ", JOptionPane.ERROR_MESSAGE);                                    
        }
    }//GEN-LAST:event_btAddSubjectOkActionPerformed

    private void btAddSubjectCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddSubjectCancelActionPerformed
        // Add your handling code here:
        cardManager.show(mainPanel, "courseworkGroup");
    }//GEN-LAST:event_btAddSubjectCancelActionPerformed

    private void btAddCourseworkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAddCourseworkActionPerformed
        // Add your handling code here:
        
        if(lbGroup.getText().equals("��Ǵ�ԪҺѧ�Ѻ"))
        {
            cbAddSubjectType.setSelectedIndex(1);
        }
        else if(lbGroup.getText().equals("��Ǵ�Ԫ����͡"))
        {
            cbAddSubjectType.setSelectedIndex(2);            
        }
        else if(lbGroup.getText().equals("��Ǵ�Ԫ��Է�ҹԾ������������"))
        {
            cbAddSubjectType.setSelectedIndex(3);            
        }       
       
        cardManager.show(mainPanel, "addSubject");
    }//GEN-LAST:event_btAddCourseworkActionPerformed
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        parent.setEnabled(true);
        this.dispose();
    }//GEN-LAST:event_exitForm
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel14411;
    private javax.swing.JButton btEditSection;
    private javax.swing.JComboBox cbStudyDay;
    private javax.swing.JButton btAddSectionOk;
    private javax.swing.JTextField tfFinalStartMinute;
    private javax.swing.JLabel jLabel31121;
    private javax.swing.JLabel jLabel1612;
    private javax.swing.JLabel jLabel1511;
    private javax.swing.JLabel jLabel1221;
    private javax.swing.JLabel jLabel31112;
    private javax.swing.JLabel jLabel14311;
    private javax.swing.JTextField tfMaxStudent;
    private javax.swing.JLabel jLabel161;
    private javax.swing.JPanel prerequisiteDetailPanel;
    private javax.swing.JLabel jLabel1611;
    private javax.swing.JTextField tfAddFinalEndMinute;
    private javax.swing.JLabel jLabel3113;
    private javax.swing.JLabel jLabel3111;
    private javax.swing.JLabel jLabel161112;
    private javax.swing.JLabel jLabel144;
    private javax.swing.JTextField tfFinalYear;
    private javax.swing.ButtonGroup radioGroup1;
    private javax.swing.JLabel jLabel101;
    private javax.swing.JLabel lbSubjectNameSec;
    private javax.swing.JLabel lbGroup;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel3114;
    private javax.swing.JScrollPane spToutline;
    private javax.swing.JLabel jLabel31134;
    private javax.swing.JLabel jLabel3115;
    private javax.swing.JLabel jLabel124;
    private javax.swing.JButton btOpenSection;
    private javax.swing.JLabel jLabel1431;
    private javax.swing.JLabel jLabel31111;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JTextPane tpAddSubjectToutline;
    private javax.swing.JLabel jLabel133;
    private javax.swing.JLabel jLabel11111;
    private javax.swing.JLabel jLabel12113;
    private javax.swing.JLabel jLabel1223;
    private javax.swing.JRadioButton rbAddLockNo;
    private javax.swing.JLabel jLabel321;
    private javax.swing.JTextField tfStudyEndMinute;
    private javax.swing.JLabel jLabel1222;
    private javax.swing.JLabel jLabel31133;
    private javax.swing.JButton btAddSubjectOk;
    private javax.swing.ButtonGroup radioGroup2;
    private javax.swing.JPanel sectionDetailPanel;
    private javax.swing.JLabel jLabel11112;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JButton btAddPreSubject;
    private javax.swing.JTextField tfStudyEndHour;
    private javax.swing.JTextPane tpPreSubjectToutline;
    private javax.swing.JRadioButton rbLockYes;
    private javax.swing.JComboBox cbPreSubID;
    private javax.swing.JTextField tfAddFinalStartHour;
    private javax.swing.JPanel addPrerequisitePanel;
    private javax.swing.JTextField tfSubjectTname;
    private javax.swing.JLabel jLabel14211;
    private javax.swing.JPanel addCourseworkPanel;
    private javax.swing.JLabel jLabel31132;
    private javax.swing.JComboBox cbLecturer;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel1323;
    private javax.swing.JTextField tfPreSubjectEname;
    private javax.swing.JLabel jLabel3211112;
    private javax.swing.JTextField tfFinalRoom;
    private javax.swing.JComboBox cbAddLecturer;
    private javax.swing.JLabel jLabel3211111;
    private javax.swing.JLabel jLabel31135;
    private javax.swing.JTextField tfCurrentStudent;
    private javax.swing.JTextField tfFinalStartHour;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel1421;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel123;
    private javax.swing.JLabel jLabel311;
    private javax.swing.JPanel courseworkGroupPanel;
    private javax.swing.JLabel jLabel12211;
    private javax.swing.JLabel jLabel21111;
    private javax.swing.JTextField tfAddFinalEndHour;
    private javax.swing.JTextField tfAddSubjectEname;
    private javax.swing.JTextField tfAddSubjectResearch;
    private javax.swing.JScrollPane spEoutline1;
    private javax.swing.JButton btDelPrerequisite;
    private javax.swing.JLabel jLabel122;
    private javax.swing.JLabel jLabel3211;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JLabel jLabel32111;
    private javax.swing.JTextField tfAddMaxStudent;
    private javax.swing.JRadioButton rbAddLockYes;
    private javax.swing.JLabel jLabel121;
    private javax.swing.JTextField tfAddFinalYear;
    private javax.swing.JTextField tfSubjectLecture;
    private javax.swing.JButton btDelSection;
    private javax.swing.JComboBox cbAddSubjectType;
    private javax.swing.JScrollPane jScrollPane;
    private javax.swing.JTextField tfSubjectCredit;
    private javax.swing.JLabel jLabel1112;
    private javax.swing.JLabel jLabel151;
    private javax.swing.JTextField tfStudyRoom;
    private javax.swing.JLabel jLabel1331;
    private javax.swing.JTextField tfFinalEndHour;
    private javax.swing.JLabel jLabel16111;
    private javax.swing.JTextField tfAddStudyStartMinute;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JComboBox cbPreSubjectType;
    private javax.swing.JLabel jLabel1113;
    private javax.swing.JTextField tfStudyStartMinute;
    private javax.swing.JTextField tfAddSubjectCredit;
    private javax.swing.JButton btAddPreSubOk;
    private javax.swing.JSplitPane jSplitPane;
    private javax.swing.JLabel jLabel121131;
    private javax.swing.JLabel jLabel111;
    private javax.swing.JLabel jLabel1212;
    private javax.swing.JLabel jLabel14421;
    private javax.swing.JLabel jLabel31122;
    private javax.swing.JLabel jLabel21112;
    private javax.swing.JTextField tfStudyStartHour;
    private javax.swing.JButton btAddCoursework;
    private javax.swing.JLabel jLabel311332;
    private javax.swing.JLabel jLabel12231;
    private javax.swing.JComboBox cbAddFinalDate;
    private javax.swing.JTextField tfAddSubjectTname;
    private javax.swing.JTextField tfAddFinalRoom;
    private javax.swing.JComboBox cbFinalDate;
    private javax.swing.JTextField tfAddFinalStartMinute;
    private javax.swing.JTextField tfAddStudyEndMinute;
    private javax.swing.JTextPane tpPreSubjectEoutline;
    private javax.swing.JComboBox cbFinalMonth;
    private javax.swing.JLabel jLabel1213;
    private javax.swing.JTextField tfAddStudyEndHour;
    private javax.swing.JPanel courseworkDetail;
    private javax.swing.JTextField tfAddSubjectPractice;
    private javax.swing.JTextField tfAddSubjectLecture;
    private javax.swing.JTextField tfAddStudyStartHour;
    private javax.swing.JScrollPane spToutline1;
    private javax.swing.JLabel jLabel31131;
    private javax.swing.JPanel couseworkInfoPanel;
    private javax.swing.JLabel jLabel1311;
    private javax.swing.JComboBox cbAddStudyDay;
    private javax.swing.JLabel jLabel11121;
    private javax.swing.JLabel jLabel311321;
    private javax.swing.JButton btAddPreSubCancel;
    private javax.swing.JTextField tfSecNumber;
    private javax.swing.JButton btAddSubjectCancel;
    private javax.swing.JLabel jLabel1443;
    private javax.swing.JLabel jLabel311331;
    private javax.swing.JLabel jLabel1442;
    private javax.swing.JLabel jLabel181;
    private javax.swing.JTextField tfSubjectPractice;
    private javax.swing.JLabel jLabel14111;
    private javax.swing.JButton btDelSectionCancel;
    private javax.swing.JLabel jLabel12112;
    private javax.swing.JLabel jLabel122211;
    private javax.swing.JTextField tfSubjectEname;
    private javax.swing.JButton btDelSubject;
    private javax.swing.JTextField tfSubjectResearch;
    private javax.swing.JTextField tfAddSecNumber;
    private javax.swing.JLabel jLabel122111;
    private javax.swing.JLabel jLabel2111;
    private javax.swing.JTextField tfAddStudyRoom;
    private javax.swing.JButton btAddSection;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JTextField tfPreSubjectID;
    private javax.swing.JLabel jLabel12111;
    private javax.swing.JLabel jLabel111121;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JTextField tfPreSubjectCredit;
    private javax.swing.JLabel jLabel12221;
    private javax.swing.JLabel jLabel3112;
    private javax.swing.JScrollPane spEoutline;
    private javax.swing.JLabel jLabel13111;
    private javax.swing.JTextField tfAddSubjectID;
    private javax.swing.JTextField tfPreSubjectPractice;
    private javax.swing.JButton btCloseSection;
    private javax.swing.JComboBox cbSubjectType;
    private javax.swing.JLabel jLabel161111;
    private javax.swing.JLabel jLabel1211;
    private javax.swing.JTextPane tpSubjectToutline;
    private javax.swing.JPanel addSectionPanel;
    private javax.swing.JPanel prerequisiteDetail;
    private javax.swing.JRadioButton rbLockNo;
    private javax.swing.JPanel allSectionDetailPanel;
    private javax.swing.JComboBox cbStatus;
    private javax.swing.JLabel jLabel13231;
    private javax.swing.JLabel jLabel1011;
    private javax.swing.JLabel jLabel102;
    private javax.swing.JTextField tfPreSubjectTname;
    private javax.swing.JLabel jLabel1111;
    private javax.swing.JTextField tfPreSubjectLecture;
    private javax.swing.JTextField tfFinalEndMinute;
    private javax.swing.JLabel jLabel1411;
    private javax.swing.JComboBox cbAddFinalMonth;
    private javax.swing.JLabel lbSubjectNamePre;
    private javax.swing.JTextPane tpAddSubjectEoutline;
    private javax.swing.JTextPane tpSubjectEoutline;
    private javax.swing.JLabel jLabel1441;
    private javax.swing.JTextField tfSubjectID;
    private javax.swing.JTextField tfPreSubjectResearch;
    private javax.swing.JButton btEditSubject;
    // End of variables declaration//GEN-END:variables
    
}
