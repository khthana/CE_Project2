/*
 * SubCourseTree.java
 *
 * Created on 19 ��Ȩԡ�¹ 2545, 21:44 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class SubCourseTree 
{  
    private DefaultMutableTreeNode subCourseNode;
    private DefaultMutableTreeNode courseNode;
    private Tree tree;
    
    /** Creates a new instance of SubCourseTree */
    public SubCourseTree(Tree tree) 
    {
        this.tree = tree;        
    }
    
    public void retrieveSubCourseInfo(Course course)
    {
        HandleCourse hCourse = new HandleCourse();                
        Vector v = hCourse.retrieveSubCourse(course);
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            SubCourse subCourse = (SubCourse)e.nextElement();        
            subCourseNode = tree.addObject(courseNode, subCourse);    
            
            SemesterTree semTree = new SemesterTree(tree);
            semTree.setNode(subCourseNode);            
            semTree.retrieveTotalSemester(subCourse);            
        }
    }
    
    public void setNode(DefaultMutableTreeNode courseNode)
    {
        this.courseNode = courseNode;
    }     
}
