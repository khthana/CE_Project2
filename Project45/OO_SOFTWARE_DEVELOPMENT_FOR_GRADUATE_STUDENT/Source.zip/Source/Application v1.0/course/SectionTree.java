/*
 * SectionTree.java
 *
 * Created on 20 ��Ȩԡ�¹ 2545, 18:55 �.
 */

package course;

import java.util.*;
import javax.swing.tree.*;
import utility.*;
import organize.*;

/**
 *
 * @author  KUKI
 */
public class SectionTree 
{
    private DefaultMutableTreeNode sectionNode;
    private DefaultMutableTreeNode subjectSectionNode;
    private Tree tree;
    
    /** Creates a new instance of SectionTree */
    public SectionTree(Tree tree) 
    {
        this.tree = tree;
    }
    
    public void retrieveAllSection(Subject s)
    {
        HandleSection hSection = new HandleSection();
        Vector v = hSection.retrieveAllSection(s.getId());
        Enumeration e = v.elements();
        
        while(e.hasMoreElements())
        {
            Section section = (Section)e.nextElement();            
            tree.addObject(subjectSectionNode, section);
        }
    }
    
    public void setNode(DefaultMutableTreeNode subjectSectionNode)
    {
        this.subjectSectionNode = subjectSectionNode;
    }    
}
