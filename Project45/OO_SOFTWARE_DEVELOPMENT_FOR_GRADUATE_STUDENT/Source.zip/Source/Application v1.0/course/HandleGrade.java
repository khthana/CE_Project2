/*
 * HandleGrade.java
 *
 * Created on 4 �ѹ�Ҥ� 2545, 17:00 �.
 */

package course;

import utility.*;
import java.util.*;
import java.sql.*;

/**
 *
 * @author  KUKI
 */
public class HandleGrade 
{
    private double totalCredit = 0.00f;
    private double totalPoint = 0.00f;
    
    private double allTotalCredit = 0.00f;
    private double allTotalPoint = 0.00f;
    
    private double probationRule = 2.00f;
    private double retryRule = 2.00f;
    
    /** Creates a new instance of HandleGrade */
    public HandleGrade() 
    {
    }
    
    public void setTotalCredit(double totalCredit)
    {
        this.totalCredit = totalCredit;
    }
    
    public void setTotalPoint(double totalPoint)
    {
        this.totalPoint = totalPoint;
    }    
    
    public void setAllTotalCredit(double allTotalCredit)
    {
        this.allTotalCredit = allTotalCredit;
    }
    
    public void setAllTotalPoint(double allTotalPoint)
    {
        this.allTotalPoint = allTotalPoint;
    }
    
    public void setProbationRule(double probationRule)
    {
        this.probationRule = probationRule;
    }
    
    public void setRetryRule(double retryRule)
    {
        this.retryRule = retryRule;
    }
    
    public double getTotalCredit()
    {
        return totalCredit;        
    }
    
    public double getTotalPoint()
    {
        return totalPoint;
    }
    
    public double getAllTotalCredit()
    {
        return allTotalCredit;        
    }
    
    public double getAllTotalPoint()
    {
        return allTotalPoint;
    }    
    
    public double getProbationRule()
    {
        return probationRule;
    }
    
    public double getRetryRule()
    {
        return retryRule;
    }
    
    public void calcTotalCredit(double credit)
    {
        totalCredit = totalCredit + credit;      
    }
    
    public void calcTotalPoint(String grade, double credit)
    {
        Vector v = retrieveGrade(grade);
        Enumeration e = v.elements();
        
        if(e.hasMoreElements())
        {
            Grade g = (Grade)e.nextElement();
            totalPoint = totalPoint + (g.getPoint() * credit);                    
        }

    }
    
    public void calcAllTotalCredit(double credit)
    {
        allTotalCredit = allTotalCredit + credit;      
    }
    
    public void calcAllTotalPoint(String grade, double credit)
    {
        Vector v = retrieveGrade(grade);
        Enumeration e = v.elements();
        
        if(e.hasMoreElements())
        {
            Grade g = (Grade)e.nextElement();
            allTotalPoint = allTotalPoint + (g.getPoint() * credit);                    
        }

    }
    
    public double calcGPA()
    {
        return (allTotalCredit == 0.00f) ? 0.00f : Math.abs(allTotalPoint/allTotalCredit - 0.004);
    }
    
    public double calcGPS()
    {
        return (totalCredit == 0.00f) ? 0.00f : Math.abs(totalPoint/totalCredit - 0.004);         
    }
    
    public Vector retrieveGrade(String grade)
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM grade WHERE grade = '" + grade + "'";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Grade g = new Grade();  
                
                g.setId(rs.getString(1));
                g.setGrade(rs.getString(2));
                g.setPoint(rs.getDouble(3));
                g.setDescription(rs.getString(4));
                
                v.addElement(g);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;        
    }
    
    public Vector retrieveAllGrade()
    {
        Vector v = new Vector();
        
        try
        {
            String query = "SELECT * FROM grade";            
            
            ResultSet rs = DB.getResultSet(query);                  
        
            while(rs.next())
            {            
                Grade g = new Grade();  
                
                g.setId(rs.getString(1));
                g.setGrade(rs.getString(2));
                g.setPoint(rs.getDouble(3));
                g.setDescription(rs.getString(4));
                
                v.addElement(g);
            }
        }
        catch(SQLException sqlex)
        {
            System.out.println(sqlex.toString());
        }
            
        return v;        
    }
    
    public boolean addGrade(Grade g)
    {
        String query = "INSERT INTO grade(grade, point, description) " +
                       "VALUES('" + g.getGrade() + "', " + g.getPoint() + ", '" + g.getDescription() + "')";
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;         
    }
    
    public boolean deleteGrade(Grade g)
    {
        String query = "DELETE FROM grade WHERE grade# = " + g.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;       
    }
    
    public boolean updateGrade(Grade g)
    {
        String query = "UPDATE grade " +
                       "SET " +
                       "grade = '" + g.getGrade() + "', " +
                       "point = " + g.getPoint() + ", " +
                       "description = '" + g.getDescription() + "' " +
                       "WHERE grade# = " + g.getId();
        
        if(DB.update(query) == 0)
        {
            return false;
        }
        
        return true;               
    }
}