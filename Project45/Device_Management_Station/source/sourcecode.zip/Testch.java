package dms;

import java.awt.*;
import javax.swing.JFrame;
import com.klg.jclass.chart.db.jbuilder.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Testch extends JFrame {
  private JBdbChart jBdbChart1 = new JBdbChart();

  public Testch() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.getContentPane().add(jBdbChart1, BorderLayout.CENTER);
  }
}