package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Eventviewer extends JPanel {
  private JLabel jLabel1 = new JLabel();
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JTextField jTextField3 = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JButton jButton1 = new JButton();
  private JPanel jPanel1 = new JPanel();
  private JLabel jLabel3 = new JLabel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JTextField jTextField4 = new JTextField();
  private JTextField jTextField5 = new JTextField();
  private JTextField jTextField6 = new JTextField();
  private JPanel jPanel2 = new JPanel();
  private JRadioButton jRadioButton3 = new JRadioButton();
  private JRadioButton jRadioButton4 = new JRadioButton();
  private JButton jButton2 = new JButton();
  ButtonGroup g1 = new ButtonGroup();
  ButtonGroup g2 = new ButtonGroup();
  private Database db;
  public Eventviewer(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    jLabel1.setText("Event log viewer");
    jLabel1.setBounds(new Rectangle(12, 9, 126, 28));
    this.setLayout(null);
    jTextField1.setBounds(new Rectangle(162, 43, 27, 24));
    jTextField2.setBounds(new Rectangle(194, 43, 27, 24));
    jTextField3.setBounds(new Rectangle(227, 43, 42, 24));
    jLabel2.setText("Enter date to view log");
    jLabel2.setBounds(new Rectangle(17, 47, 123, 23));
    jButton1.setBounds(new Rectangle(275, 50, 67, 20));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBounds(new Rectangle(14, 189, 364, 109));
    jPanel1.setLayout(null);
    jLabel3.setText("Delete log");
    jLabel3.setBounds(new Rectangle(11, 5, 165, 26));
    jRadioButton1.setText("all");
    jRadioButton1.setBounds(new Rectangle(22, 42, 52, 25));
    jRadioButton2.setText("select date");
    jRadioButton2.setBounds(new Rectangle(81, 42, 80, 25));
    jTextField4.setBounds(new Rectangle(224, 49, 42, 24));
    jTextField5.setBounds(new Rectangle(191, 49, 27, 24));
    jTextField6.setBounds(new Rectangle(160, 49, 27, 24));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBounds(new Rectangle(15, 70, 362, 109));
    jPanel2.setLayout(null);
    jRadioButton3.setText("all");
    jRadioButton3.setBounds(new Rectangle(16, 47, 51, 25));
    jRadioButton4.setText("select date");
    jRadioButton4.setBounds(new Rectangle(78, 48, 81, 25));
    jButton2.setText("OK");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(275, 44, 67, 20));
    this.add(jLabel2, null);
    g1.add(jRadioButton3);
    g1.add(jRadioButton4);
    g2.add(jRadioButton1);
    g2.add(jRadioButton2);
    jPanel1.add(jLabel3, null);
    jPanel1.add(jRadioButton1, null);
    jPanel1.add(jRadioButton2, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jTextField2, null);
    jPanel1.add(jTextField3, null);
    jPanel1.add(jButton2, null);
    this.add(jLabel1, null);
    this.add(jPanel2, null);
    jPanel2.add(jRadioButton3, null);
    jPanel2.add(jRadioButton4, null);
    jPanel2.add(jTextField5, null);
    jPanel2.add(jTextField4, null);
    jPanel2.add(jTextField6, null);
    jPanel2.add(jButton1, null);
    this.add(jPanel1, null);
    this.setVisible(true);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    if(jRadioButton3.isSelected())
    {
    String[][] datavalue;
    String[] name;
    int rowcount=0;
    ResultSet rs = db.executeSQLquery("SELECT * FROM EVENT");
    try{
      while(rs.next())
      {
        rowcount++;
      }
    }catch(SQLException sql)
    {}
    name = new String[5];
    name[0] = "EVENTID";
    name[1] = "EVENTNAME";
    name[2] = "EVENTDESCRIPTION";
    name[3] = "EVENTDATE";
    name[4] = "EVENTTIME";

    datavalue = new String[rowcount][5];
    ResultSet rs2 = db.executeSQLquery("SELECT * FROM EVENT");
    int x=0;
    try{
      while(rs2.next())
      {
        datavalue[x][0] = Integer.toString(rs2.getInt(1));
        for(int j=1;j<5;j++)
        {
        datavalue[x][j]=rs2.getString(j+1);
        }
        x++;
      }
    }catch(SQLException sql)
    {}
    Thetable t = new Thetable(name,datavalue);
    t.show();
    }
  else if(jRadioButton4.isSelected())
  {
    String[][] datavalue;
    String[] name;
    String day = jTextField6.getText();
    String month = jTextField5.getText();
    String year = jTextField4.getText();
    String date = year+"-"+month+"-"+day;
    Date edate = Date.valueOf(date);

    int rowcount=0;
    ResultSet rs = db.executeSQLquery("SELECT * FROM EVENT");
    try{
      while(rs.next())
      {
        rowcount++;
      }
      }catch(SQLException sql)
          {}
      name = new String[5];
      name[0] = "EVENTID";
      name[1] = "EVENTNAME";
      name[2] = "EVENTDESCRIPTION";
      name[3] = "EVENTDATE";
      name[4] = "EVENTTIME";

      datavalue = new String[rowcount][5];
      ResultSet rs2 = db.executeSQLquery("SELECT * FROM EVENT");
      int x=0;
      try{
        while(rs2.next())
        {
          datavalue[x][0] = Integer.toString(rs2.getInt(1));
          for(int j=1;j<3;j++)
          {
            datavalue[x][j]=rs2.getString(j+1);
          }
          Date cdate = Date.valueOf(rs2.getString(4));
          if(cdate.compareTo(edate)==0)
          {
           datavalue[x][3]=cdate.toString();
           datavalue[x][4]=rs2.getString(5);
           x++;
          }
        }
        }catch(SQLException sql)
            {}
        Thetable t = new Thetable(name,datavalue);
        t.show();
  }
  }

  void jButton2_actionPerformed(ActionEvent e) {
  if(jRadioButton1.isSelected())
  {
    db.executeSQLupdate("DELETE FROM EVENT");
  }
  else if(jRadioButton2.isSelected())
  {
    String day = jTextField1.getText();
    String month = jTextField2.getText();
    String year = jTextField3.getText();
    String date = year+"-"+month+"-"+day;
    db.executeSQLupdate("DELETE FROM EVENT WHERE EVENTDATE='"+date+"'");
  }
  }
}