package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.math.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frametestwhileloop extends JFrame {
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  //Whiletest wt = new Whiletest();
  Whiletest wt;
  private JButton jButton3 = new JButton();
  public static void main(String[] args) {
   Frametestwhileloop ftwl = new Frametestwhileloop();
   ftwl.setVisible(true);
  }
  public Frametestwhileloop() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    MouseListener m1 = new MouseAdapter()
   {
     public void mouseClicked(MouseEvent e)
     {
       if(e.getClickCount()==1)
       {
          runn();
       }
     }
  };
   MouseListener m2 = new MouseAdapter()
     {
       public void mouseClicked(MouseEvent e)
       {
         if(e.getClickCount()==1)
         {
             stopp();
         }
       }
  };
    jButton1.setBounds(new Rectangle(34, 91, 110, 36));
    jButton1.setText("START");
    jButton1.addActionListener(new Frametestwhileloop_jButton1_actionAdapter(this));
    //jButton1.addMouseListener(m1);
    this.getContentPane().setLayout(null);
    jButton2.setBounds(new Rectangle(166, 89, 105, 37));
    jButton2.setText("STOP");
    //jButton2.addMouseListener(m2);


    jButton3.setBounds(new Rectangle(100, 159, 110, 48));
    jButton3.setText("STOP2");
    jButton3.addActionListener(new Frametestwhileloop_jButton3_actionAdapter(this));
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton3, null);
  }



  void jButton2_actionPerformed(ActionEvent e) {

  }
  public void runn(){
    //Whiletest we = new Whiletest();
    //wt=we;
    //wt.start();

    wt = new Whiletest();
    wt.setName("r1");
    wt.start();


  }

  public void stopp()
  {

  }

  void jButton3_actionPerformed(ActionEvent e) {

  }

  void jButton1_actionPerformed(ActionEvent e) {
     runn();
  }


}

class Frametestwhileloop_jButton3_actionAdapter implements java.awt.event.ActionListener {
  private Frametestwhileloop adaptee;

  Frametestwhileloop_jButton3_actionAdapter(Frametestwhileloop adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}

class Frametestwhileloop_jButton1_actionAdapter implements java.awt.event.ActionListener {
  private Frametestwhileloop adaptee;

  Frametestwhileloop_jButton1_actionAdapter(Frametestwhileloop adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}