package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Adminmain extends JFrame {
  private JPanel jPanel1 = new JPanel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JRadioButton jRadioButton3 = new JRadioButton();
  private JButton jButton1 = new JButton();
  ButtonGroup g1 = new ButtonGroup();
  public Adminmain() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setToolTipText("");
    jPanel1.setBounds(new Rectangle(28, 25, 343, 176));
    jPanel1.setLayout(null);
    jRadioButton1.setText("Device Configuration");
    jRadioButton1.setBounds(new Rectangle(29, 21, 289, 27));
    jRadioButton2.setText("Main Configuration");
    jRadioButton2.setBounds(new Rectangle(28, 59, 229, 28));
    jRadioButton3.setText("Edit Exist Configuration");
    jRadioButton3.setBounds(new Rectangle(25, 101, 287, 31));
    g1.add(jRadioButton1);
    g1.add(jRadioButton2);
    g1.add(jRadioButton3);
    jButton1.setBounds(new Rectangle(125, 223, 124, 31));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(jRadioButton1, null);
    jPanel1.add(jRadioButton2, null);
    jPanel1.add(jRadioButton3, null);
    this.getContentPane().add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {

  }
}