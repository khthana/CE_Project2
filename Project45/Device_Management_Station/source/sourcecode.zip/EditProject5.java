package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.tree.*;
import java.sql.*;
import javax.swing.event.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditProject5 extends JPanel {
  private Database db;
  private String[] deviceobject;
  private boolean plan = false;
  private JComboBox Selectproject = new JComboBox();
  private DefaultListModel listModel;
  private JList Devicelist = new JList();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JLabel List = new JLabel();

  DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");

  JTree Objecttree = new JTree(top);
  JScrollPane treeView = new JScrollPane(Objecttree);
  DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();



  DefaultMutableTreeNode node[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child[] = new DefaultMutableTreeNode[1000];
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JButton Add = new JButton();
  private JButton Remove = new JButton();
  private JComboBox Selectgroup = new JComboBox();
  private JLabel jLabel2 = new JLabel();
  private JTextField Monitortype = new JTextField();
  private JTextField Monitorvalue = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JRadioButton Addgroup = new JRadioButton();
  private JRadioButton Editgroup = new JRadioButton();
  private JRadioButton Deletegroup = new JRadioButton();
  private JTextField Group = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JCheckBox Planning = new JCheckBox();
  private Border border1;
  private Border border2;
  private Border border3;


  public EditProject5(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    this.setLayout(null);
    Selectproject.setBounds(new Rectangle(160, 21, 285, 28));

    jScrollPane1.setBounds(new Rectangle(578, 287, 327, 342));
    Ok.setBounds(new Rectangle(677, 645, 107, 27));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(804, 643, 102, 30));
    Cancel.setText("CANCEL");
    jLabel1.setText("SELECT PROJECT");
    jLabel1.setBounds(new Rectangle(40, 18, 117, 30));
    List.setText("DEVICE LIST");
    List.setBounds(new Rectangle(575, 239, 134, 28));
    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(111, 72, 299, 375));
    Objecttree.setShowsRootHandles(true);
    Add.setBounds(new Rectangle(428, 449, 110, 28));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Remove.setBounds(new Rectangle(429, 507, 108, 28));
    Remove.setText("REMOVE");
    Remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Remove_actionPerformed(e);
      }
    });
    Selectgroup.setBounds(new Rectangle(164, 80, 280, 29));

    jLabel2.setText("SELECT MONITOR GROUP");
    jLabel2.setBounds(new Rectangle(10, 83, 164, 28));
    Monitortype.setBorder(border3);
    Monitortype.setEditable(false);
    Monitortype.setBounds(new Rectangle(165, 164, 263, 28));
    Monitorvalue.setBorder(border3);
    Monitorvalue.setEditable(false);
    Monitorvalue.setBounds(new Rectangle(165, 202, 263, 28));
    jLabel3.setText("MONITOR TYPE");
    jLabel3.setBounds(new Rectangle(42, 166, 113, 22));
    jLabel4.setText("MONITOR VALUE");
    jLabel4.setBounds(new Rectangle(40, 205, 116, 23));
    jPanel1.setBorder(border1);
    jPanel1.setBounds(new Rectangle(574, 13, 155, 102));
    jPanel1.setLayout(verticalFlowLayout1);
    Addgroup.setSelected(true);
    Addgroup.setText("ADD GROUP");
    Addgroup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Addgroup_actionPerformed(e);
      }
    });
    Editgroup.setText("EDIT GROUP");
    Editgroup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Editgroup_actionPerformed(e);
      }
    });
    Deletegroup.setText("DELETE GROUP");
    Deletegroup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Deletegroup_actionPerformed(e);
      }
    });
    Group.setBorder(border3);
    Group.setBounds(new Rectangle(165, 126, 263, 28));
    jLabel5.setText("GROUP NAME");
    jLabel5.setBounds(new Rectangle(40, 127, 103, 25));
    Planning.setBorder(border2);
    Planning.setText("Logging");
    Planning.setBounds(new Rectangle(577, 144, 158, 30));
    this.add(Selectproject, null);
    this.add(jLabel1, null);

    Objecttree.setEditable(true);
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);


    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(65, 287, 327, 342));
    this.add(jLabel2, null);
    this.add(Selectgroup, null);

    jPanel1.add(Addgroup, null);
    jPanel1.add(Editgroup, null);
    jPanel1.add(Deletegroup, null);
    this.add(jScrollPane1, null);
    this.add(Add, null);
    this.add(Remove, null);
    this.add(List, null);
    this.add(jPanel1, null);


    this.add(Group, null);
    this.add(jLabel5, null);
    this.add(jLabel3, null);
    this.add(Monitortype, null);
    this.add(jLabel4, null);
    this.add(Monitorvalue, null);
    this.add(treeView, null);
    this.add(Cancel, null);
    this.add(Ok, null);
    this.add(Planning, null);



   // Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT");
      while (rs.next())
      {
        Selectproject.addItem(rs.getString("PROJECTID"));
      }

      rs = db.executeSQLquery("SELECT * FROM PROJECTGROUP WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "'");
      while (rs.next())
      {
        Selectgroup.addItem(rs.getString("GROUPID"));
      }

    }
    catch(SQLException sql)
    {
      System.out.println("EditProject5 : " + sql);
    }


    listModel = new DefaultListModel();

    listModel.removeAllElements();
    ResultSet rs;
    if (Selectgroup.getSelectedIndex() != -1)
    {
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '" +Selectgroup.getSelectedItem().toString() + "'");
      int count=0;
      while(rs.next())
      {
        count = rs.getInt(1);
      }
      deviceobject = new String[count];
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + Selectgroup.getSelectedItem().toString() + "'");
      int i = 0;
      while(rs.next())
      {

        String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
        deviceobject[i] = temp;
        listModel.addElement(temp);
        System.out.println(temp);
        i++;

      }
    }

    Devicelist = new JList(listModel);
    Devicelist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Devicelist.setSelectedIndex(0);
    Devicelist.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent e) {
        Devicelist_valueChanged(e);
      }
    });


    Selectproject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectproject_actionPerformed(e);
      }
    });

    Selectgroup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectgroup_actionPerformed(e);
      }
    });
    jScrollPane1.getViewport().add(Devicelist, null);
    createNodes();
    buttonGroup1.add(Addgroup);
    buttonGroup1.add(Editgroup);
    buttonGroup1.add(Deletegroup);
  }

  public void createNodes() {
   // Database db = new Database();
    ResultSet rs;
    ResultSet rs2;
    String objectid="";
    String deviceid="";
    int j=0;

    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM OBJECT");
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        j = 0;
        node[i] = new DefaultMutableTreeNode(deviceid);
        top.add(node[i]);

        rs2 = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + deviceid + "'");

        while (rs2.next())
        {
          objectid = rs2.getString("OBJECTID");
          child[j] = new DefaultMutableTreeNode(objectid);
          node[i].add(child[j]);
          j++;

        }

        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

  }

  void Ok_actionPerformed(ActionEvent e) {
  //  Database db = new Database();
    if (Addgroup.isSelected())
    {
      if (Group.getText().compareTo("") != 0 && Monitortype.getText().compareTo("") != 0 && Monitorvalue.getText().compareTo("") != 0 && listModel.getSize() != 0)
      {

        System.out.println("INSERT INTO MONITOR (GROUPID,MONITORTYPE,MONITORVALUE) VALUES('" + Group.getText() + "' , '" + Monitortype.getText() + "' , '" + Monitorvalue.getText() + "')");
        db.executeSQLupdate("INSERT INTO MONITOR (GROUPID,MONITORTYPE,MONITORVALUE) VALUES('" + Group.getText() + "' , '" + Monitortype.getText() + "' , '" + Monitorvalue.getText() + "')");
        System.out.println("INSERT INTO PROJECTGROUP (PROJECTID,GROUPID) VALUES('" + Selectproject.getSelectedItem().toString() + "','" + Group.getText() + "')");
        db.executeSQLupdate("INSERT INTO PROJECTGROUP (PROJECTID,GROUPID) VALUES('" + Selectproject.getSelectedItem().toString() + "','" + Group.getText() + "')");
        for(int i=0;i<listModel.getSize();i++)
        {
          System.out.println("INSERT INTO MONITORGROUP (GROUPID,DEVICEID,OBJECTID) VALUES('" + Group.getText() + "' , '" + listModel.get(i).toString().substring(0,listModel.get(i).toString().indexOf(" , ")) + "' , '" + listModel.get(i).toString().substring(listModel.get(i).toString().indexOf(" , ")+3) + "')");
          db.executeSQLupdate("INSERT INTO MONITORGROUP (GROUPID,DEVICEID,OBJECTID) VALUES('" + Group.getText() + "' , '" + listModel.get(i).toString().substring(0,listModel.get(i).toString().indexOf(" , ")) + "' , '" + listModel.get(i).toString().substring(listModel.get(i).toString().indexOf(" , ")+3) + "')");
        }

        if (Planning.isSelected())
        {
          db.executeSQLupdate("INSERT INTO SUPPORTGROUP (PROJECTID,GROUPID) VALUES ('" + Selectproject.getSelectedItem().toString() + "','"+ Selectgroup.getSelectedItem() + "')");
          String createtable;
          createtable = "CREATE TABLE " + Selectproject.getSelectedItem().toString() + "_" + Selectgroup.getSelectedItem().toString() + "_LOG (ID INT IDENTITY(1,1) PRIMARY KEY, PROJECTID VARCHAR(50), GROUPID VARCHAR(50), ";
          for (int i = 0;i<listModel.getSize();i++)
          {
            createtable += listModel.get(i).toString().substring(0,listModel.get(i).toString().indexOf(" , ")) + listModel.get(i).toString().substring(listModel.get(i).toString().indexOf(" , ")+3) + " VARCHAR(50),";
          }
          createtable = createtable + "THEDATE VARCHAR(50) , THETIME VARCHAR(50))";
          System.out.println("createtable : " + createtable);
          db.executeSQLupdate(createtable);
        }
      }
    }
    else if (Editgroup.isSelected() && Monitortype.getText().compareTo("") != 0 && Monitorvalue.getText().compareTo("") != 0)
    {


      String[] delete = checkdelete();
      String[] add = checkadd();
      for(int i=0;i<delete.length;i++)
      {
        db.executeSQLupdate("DELETE FROM MONITORGROUP WHERE GROUPID = '" + Selectgroup.getSelectedItem() + "' AND DEVICEID = '" + delete[i].substring(0,delete[i].indexOf(" , ")) + "' AND OBJECTID = '" + delete[i].substring(delete[i].indexOf(" , ")+3) + "'");
      }
      for(int i=0;i<add.length;i++)
      {
        //System.out.println(add[i].substring(0,add[i].indexOf(" , ")) + " , " + );
        db.executeSQLupdate("INSERT INTO MONITORGROUP (GROUPID,DEVICEID,OBJECTID) VALUES('" + Selectgroup.getSelectedItem() + "' , '" + add[i].substring(0,add[i].indexOf(" , ")) + "' , '" + add[i].substring(add[i].indexOf(" , ")+3) + "')");
      }

      listModel.removeAllElements();
      ResultSet rs;

      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '" +Selectgroup.getSelectedItem() + "'");
      int count=0;
      try
      {
        while(rs.next())
        {
          count = rs.getInt(1);
        }
        deviceobject = new String[count];
        rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + Selectgroup.getSelectedItem() + "'");
        int i = 0;
        while(rs.next())
        {

          String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
          deviceobject[i] = temp;
          listModel.addElement(temp);
          System.out.println(temp);
          i++;

        }

        db.executeSQLupdate("UPDATE MONITOR SET MONITORTYPE = '" + Monitortype.getText() + "' , MONITORVALUE = '" + Monitorvalue.getText() + "' WHERE GROUPID = '" + Selectgroup.getSelectedItem().toString() + "'");

        if (Planning.isSelected() && plan == false)
        {
          db.executeSQLupdate("INSERT INTO SUPPORTGROUP (PROJECTID,GROUPID) VALUES ('" + Selectproject.getSelectedItem().toString() + "','"+ Selectgroup.getSelectedItem() + "')");
          String createtable;
          createtable = "CREATE TABLE " + Selectproject.getSelectedItem().toString() + "_" + Selectgroup.getSelectedItem().toString() + "_LOG (ID INT IDENTITY(1,1) PRIMARY KEY, PROJECTID VARCHAR(50), GROUPID VARCHAR(50), ";
          for (int j = 0;j<listModel.getSize();j++)
          {
            createtable += listModel.get(j).toString().substring(0,listModel.get(j).toString().indexOf(" , ")) + listModel.get(j).toString().substring(listModel.get(j).toString().indexOf(" , ")+3) + " VARCHAR(50),";
          }
          createtable = createtable + "THEDATE VARCHAR(50) , THETIME VARCHAR(50))";
          System.out.println("createtable : " + createtable);
          db.executeSQLupdate(createtable);

        }
        else if (!Planning.isSelected() && plan == true)
        {
          db.executeSQLupdate("DELETE FROM SUPPORTGROUP WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "' AND GROUPID = '" + Selectgroup.getSelectedItem().toString() +"'" );
        }
        else if (Planning.isSelected() && plan == true && (add.length != 0 || delete.length != 0))
        {
          db.executeSQLupdate("DROP TABLE " + Selectproject.getSelectedItem().toString() + "_" + Selectgroup.getSelectedItem().toString() + "_LOG");
          String createtable;
          createtable = "CREATE TABLE " + Selectproject.getSelectedItem().toString() + "_" + Selectgroup.getSelectedItem().toString() + "_LOG (ID INT IDENTITY(1,1) PRIMARY KEY, PROJECTID VARCHAR(50), GROUPID VARCHAR(50), ";
          for (int j = 0;j<listModel.getSize();j++)
          {
            createtable += listModel.get(j).toString().substring(0,listModel.get(j).toString().indexOf(" , ")) + listModel.get(j).toString().substring(listModel.get(j).toString().indexOf(" , ")+3) + " VARCHAR(50),";
          }
          createtable = createtable + "THEDATE VARCHAR(50) , THETIME VARCHAR(50))";
          System.out.println("createtable : " + createtable);
          db.executeSQLupdate(createtable);
        }
      }
      catch(SQLException ee)
      {
        System.out.println(ee);
      }



    }
    else if (Deletegroup.isSelected())
    {
      db.executeSQLupdate("DELETE FROM SUPPORTGROUP WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "' AND GROUPID = '" + Selectgroup.getSelectedItem().toString() +"'" );
      db.executeSQLupdate("DELETE FROM MONITOR WHERE GROUPID = '" + Selectgroup.getSelectedItem().toString() + "'");

    }



  }

  public void Devicelist_valueChanged(ListSelectionEvent e) {

  }

  void Add_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

 TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
 if (Objecttree.isVisible(pathnode)) {

  if (node.isLeaf()) {
    String leafpath = Objecttree.getLastSelectedPathComponent().toString();
    TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
    String parent = temp.getLastPathComponent().toString();
    //System.out.println(leafpath);
    //System.out.println(parent);
    if (listModel.indexOf(parent + " , " + leafpath) == -1)
    {
      listModel.addElement(parent + " , " + leafpath);
    }

    }
    else if (node.isRoot()) {
        System.out.println("root");
    }
    else if (node.isNodeAncestor(top)) {
      System.out.println("ancestor");
    }
 }


  }

  void Remove_actionPerformed(ActionEvent e) {
    if (Devicelist.getSelectedIndex() != -1)
    {
      listModel.removeElementAt(Devicelist.getSelectedIndex());
    }
  }

  String[] checkdelete()
  {
    String[] str;
    int count=0;
    for (int i = 0;i<deviceobject.length ;i++)
    {
      if (listModel.indexOf(deviceobject[i]) == -1)
      {
        count++;
      }
    }
    str = new String[count];
    count = 0;
    for (int i = 0;i<deviceobject.length ;i++)
    {
      if (listModel.indexOf(deviceobject[i]) == -1)
      {
        str[count] = deviceobject[i];
        count++;
      }
    }
    return str;
  }

  String[] checkadd()
  {
    String[] str;
    int count=0;
    boolean flag = true;
    System.out.println("listModel.getSize : " + listModel.getSize());
    System.out.println("deviceobject.length : " + deviceobject.length);
    for (int i = 0;i<listModel.getSize();i++)
    {
      for (int j = 0;j<deviceobject.length;j++)
      {
        System.out.println("i : " + listModel.get(i).toString() + " j : " + deviceobject[j]);
        if (deviceobject[j].compareTo(listModel.get(i).toString()) == 0)
        {
          flag = false;
        }
      }
      if (flag == true)
      {
        count++;
      }
      flag = true;
    }

    str = new String[count];
    count = 0;
    flag = true;
    for (int i = 0;i<listModel.getSize();i++)
    {
      for (int j = 0;j<deviceobject.length;j++)
      {
        if (deviceobject[j].compareTo(listModel.get(i).toString()) == 0)
        {
          flag = false;
        }
      }
      if (flag == true)
      {
        str[count] = listModel.getElementAt(i).toString();
        count++;
      }
      flag = true;
    }
    return str;
  }

  void Selectproject_actionPerformed(ActionEvent e) {
    ResultSet rs;
   // Database db = new Database();
    Selectgroup.removeAllItems();
    System.out.println("add grouplist");
    try
    {


      rs = db.executeSQLquery("SELECT * FROM PROJECTGROUP WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "'");
      while (rs.next())
      {

        Selectgroup.addItem(rs.getString("GROUPID"));
      }


    }

    catch(SQLException sql)
    {
      System.out.println("EditProject5 : " + sql);
    }

    listModel.removeAllElements();
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '" +Selectgroup.getSelectedItem() + "'");
    int count=0;
    try
    {
      while(rs.next())
    {
      count = rs.getInt(1);
    }
    deviceobject = new String[count];
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + Selectgroup.getSelectedItem() + "'");
    int i = 0;
    while(rs.next())
    {

      String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
      deviceobject[i] = temp;
      listModel.addElement(temp);
      System.out.println(temp);
      i++;

    }
    }
    catch(SQLException ee)
    {
      System.out.println(ee);
    }

  }

  void Selectgroup_actionPerformed(ActionEvent e) {

    listModel.removeAllElements();
    ResultSet rs;
   // Database db = new Database();
    if (Selectgroup.getItemCount() !=0 )
    {
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '" +Selectgroup.getSelectedItem().toString() + "'");
      int count=0;
      try
      {
        while(rs.next())
        {
          count = rs.getInt(1);
        }
        deviceobject = new String[count];
        rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + Selectgroup.getSelectedItem().toString() + "'");
        int i = 0;
        while(rs.next())
        {

          String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
          deviceobject[i] = temp;
          listModel.addElement(temp);
          System.out.println(temp);
          i++;

        }



      }
      catch(SQLException ee)
      {
        System.out.println(e);
      }
    }

  }

  void Editgroup_actionPerformed(ActionEvent e) {
    Selectgroup.setEnabled(true);
    Group.setEditable(false);
    Monitortype.setEditable(true);
    Monitorvalue.setEditable(true);
    ResultSet rs;

    try
    {
    rs = db.executeSQLquery("SELECT * FROM MONITOR WHERE GROUPID = '" + Selectgroup.getSelectedItem().toString() + "'");
        while(rs.next())
        {

          Monitortype.setText(rs.getString("MONITORTYPE"));
          Monitorvalue.setText(rs.getString("MONITORVALUE"));

        }

        rs = db.executeSQLquery("SELECT COUNT(*) FROM SUPPORTGROUP WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "' AND GROUPID = '" + Selectgroup.getSelectedItem().toString() + "'");
        while (rs.next())
        {
          if (rs.getInt(1) > 0)
          {
            Planning.setSelected(true);
            plan = true;
          }
          else
          {
            Planning.setSelected(false);
            plan = false;
          }
        }
    }
    catch (SQLException ee)
    {
      System.out.println(ee);
    }

  }

  void Addgroup_actionPerformed(ActionEvent e) {
    Selectgroup.setEnabled(false);
    Group.setEditable(true);
    Monitortype.setEditable(true);
    Monitorvalue.setEditable(true);
    Monitortype.setText("");
    Monitorvalue.setText("");
    Group.setText("");

    listModel.removeAllElements();

  }

  void Deletegroup_actionPerformed(ActionEvent e) {
    Selectgroup.setEnabled(true);
    Group.setEditable(false);
    Monitortype.setEditable(false);
    Monitorvalue.setEditable(false);
    Monitortype.setText("");
    Monitorvalue.setText("");
    Group.setText("");

  }

}