package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import ipworks.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class SNMPsend extends JFrame {
  private JButton jButton1 = new JButton();
  Snmp snmp = new Snmp();
  public SNMPsend() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    (new SNMPsend().setVisible(true));
  }
  private void jbInit() throws Exception {

    snmp.setActive(true);
    snmp.setCommunity("public");

    snmp.addSnmpEventListener(new ipworks.SnmpEventListener() {
     public void error(SnmpErrorEvent e) {
     }
     public void getNextRequest(SnmpGetNextRequestEvent e) {
     }
     public void getRequest(SnmpGetRequestEvent e) {
      System.out.println(e.sourceAddress);
     }
     public void getResponse(SnmpGetResponseEvent e) {

     }

     public void readyToSend(SnmpReadyToSendEvent e) {
     }
     public void setRequest(SnmpSetRequestEvent e) {
     }
     public void trap(SnmpTrapEvent e) {

     }
     public void PDUTrace(SnmpPDUTraceEvent e) {
     }
     public void informRequest(SnmpInformRequestEvent e) {
     }
     public void getBulkRequest(SnmpGetBulkRequestEvent e) {
     }
    });
    jButton1.setBounds(new Rectangle(97, 103, 91, 35));
    jButton1.setText("ok");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    this.getContentPane().add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    try {
    //snmp.setObjCount(1);
    //snmp.setObjId(1,"1.0.0");		// indexes start at 1
    //snmp.setCommunity("public");

    //snmp.setRemoteHost("161.246.5.99");
    //snmp.setActive(true);
    snmp.setAction(Snmp.snmpSendGetRequest);
  } catch (IPWorksException ipwe) {
    JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
  }
}