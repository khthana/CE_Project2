package dms;

import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Framethread extends Thread {
  int numofdevice = 0;
  String[][] deviceobjectid;
  private Database db;
  MessageHandler m;

  String[] value = new String[3];
  FrameTable frametable;
  FrameText frametext;
  String type;


  public void run()
  {
    while (true)
    {
      System.out.println(numofdevice);
   /*   try
      {
        Thread.currentThread().sleep(1000);
      }
      catch (Exception e)
      {

      }*/
      for (int j=0;j<numofdevice;j++)
      {

        m.constructMessage(deviceobjectid[j][0],deviceobjectid[j][1],"GET","","","");
        m.sendMessage();
        try
        {
          Thread.currentThread().sleep(500);
        }
        catch (Exception ee)
        {

        }
        value[0] = deviceobjectid[j][0];
        value[1] = deviceobjectid[j][1];
        value[2] = m.recieveMessage();
        if (value[2].compareTo("*") == 0)
        {
          value[2] = "not response";
        }
        if (type.compareTo("text") == 0)
        {
          frametext.setvalue(value);
        }
        else if (type.compareTo("table") == 0)
        {
          frametable.setvalue(value);
        }


      }
      if (type.compareTo("text") == 0)
      {
        frametext.write();
      }
      else if (type.compareTo("table") == 0)
      {
        frametable.write();
      }

    }

  }
  public Framethread(int numofdevice,String[][] deviceobjectid,FrameTable frame,Database d) {
    db = d;
    m = new MessageHandler(db);
    this.numofdevice = numofdevice;
    this.deviceobjectid = deviceobjectid;

    this.frametable = frame;
    type = "table";
  }

  public Framethread(int numofdevice,String[][] deviceobjectid,FrameText frame,Database d) {
    db = d;
    m = new MessageHandler(db);
    this.numofdevice = numofdevice;
    this.deviceobjectid = deviceobjectid;

    this.frametext = frame;
    type = "text";
  }
}