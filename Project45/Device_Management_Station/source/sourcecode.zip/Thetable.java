package dms;

import java.awt.*;
import java.util.*;
import javax.swing.*;
import javax.swing.table.*;

class Thetable
                extends 	JFrame
 {
        // Instance attributes used in this example
        private	JPanel		topPanel;
        private	JTable		table;
        private	JScrollPane scrollPane;

        private	String		columnNames[];
        private	String		dataValues[][];


        // Constructor of main frame
        public Thetable(String[] cn,String[][] dv)
        {
                // Set the frame characteristics
                columnNames = cn;
                dataValues = dv;
                setTitle( "Planning and Support" );
                setSize( 300, 200 );
                setBackground( Color.gray );
                this.setVisible(true);
                // Create a panel to hold all other components
                topPanel = new JPanel();
                topPanel.setLayout( new BorderLayout() );
                getContentPane().add( topPanel );



                // Create a new table instance
                table = new JTable( dataValues, columnNames );

                // Configure some of JTable's paramters
                table.setShowHorizontalLines( false );
                table.setRowSelectionAllowed( true );
                table.setColumnSelectionAllowed( true );

                // Change the selection colour
                table.setSelectionForeground( Color.white );
                table.setSelectionBackground( Color.red );

                // Add the table to a scrolling pane
                scrollPane = table.createScrollPaneForTable( table );
                topPanel.add( scrollPane, BorderLayout.CENTER );
        }
 }