package dms;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.tree.*;
import java.sql.*;
//import sck.beans.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Mainconfig extends JFrame {
  private PaneLayout paneLayout1 = new PaneLayout();
  private JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel Projectpanel = new JPanel();
  JPanel Devicepanel = new JPanel();
  JPanel Userpanel = new JPanel();
  private Database db;

  //MibBrowser m = new MibBrowser();
  private JButton Finished = new JButton();
  private JButton Cancel = new JButton();
  private JButton Next = new JButton();
  private JButton Back = new JButton();
  private JPanel Projectpanel1 = new JPanel();
  private Config1 c1;
  private Config2 c2;
  private Config3 c3;
  private Config4 c4;
  private Config5 c5;
  private Config6 c6;

  private Userconfig1 u1;

  private Deviceconfig1 d1;
  private Deviceconfig2 d2;
  private Deviceconfig3 d3;
  private Deviceconfig4 d4;


  private int projectcountpanel = 0;
  private int devicecountpanel = 0;
  private JPanel Devicepanel1 = new JPanel();
  private JPanel Userpanel1 = new JPanel();
  private JButton Okuser = new JButton();
  private JButton Canceluser = new JButton();
  private JButton Backdevice = new JButton();
  private JButton Nextdevice = new JButton();
  private JButton Finisheddevice = new JButton();
  private JButton Canceldevice = new JButton();
  //Database data = new Database();

  public Mainconfig(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    c1 = new Config1(db);
    c2 = new Config2(db);
    c3 = new Config3();
    c4 = new Config4();
    c5 = new Config5();
    c6 = new Config6(db);

    u1 = new Userconfig1();

    d1 = new Deviceconfig1();
    d2 = new Deviceconfig2();
    d3 = new Deviceconfig3();
    d4 = new Deviceconfig4();
    this.setName("CONFIGURATION");
    this.setSize(new Dimension(1024,768));
    this.getContentPane().setLayout(paneLayout1);
    Projectpanel.setLayout(null);
    Devicepanel.setLayout(null);
    Userpanel.setLayout(null);

    Finished.setBounds(new Rectangle(710, 638, 91, 27));
    Finished.setEnabled(false);
    Finished.setText("FINISHED");
    Finished.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Finished_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(807, 638, 83, 27));
    Cancel.setText("CANCEL");
    Cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancel_actionPerformed(e);
      }
    });
    Next.setBounds(new Rectangle(635, 638, 65, 27));
    Next.setText("NEXT");
    Next.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Next_actionPerformed(e);
      }
    });
    Back.setBounds(new Rectangle(562, 638, 67, 27));
    Back.setEnabled(false);
    Back.setText("BACK");
    Back.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Back_actionPerformed(e);
      }
    });
    Projectpanel1.setBounds(new Rectangle(10, 10, 1013, 600));
    Projectpanel1.setLayout(null);

    c1.setBounds(new Rectangle(10, 10, 1000, 700));
    c2.setBounds(new Rectangle(10, 10, 1000, 700));
    c3.setBounds(new Rectangle(10, 10, 1000, 700));
    c4.setBounds(new Rectangle(10, 10, 1000, 700));
    c5.setBounds(new Rectangle(10, 10, 1000, 700));
    c6.setBounds(new Rectangle(10, 10, 1000, 700));

    u1.setBounds(new Rectangle(10, 10, 1000, 700));

    d1.setBounds(new Rectangle(10, 10, 1000, 700));
    d2.setBounds(new Rectangle(10, 10, 1000, 700));
    d3.setBounds(new Rectangle(10, 10, 1000, 700));
    d4.setBounds(new Rectangle(10, 10, 1000, 700));

    /*c1.setVisible(true);
    c2.setVisible(false);
    c3.setVisible(false);
    c4.setVisible(false);
    c5.setVisible(false);
    c6.setVisible(false);

    c1.setEnabled(true);
    c2.setEnabled(false);
    c3.setEnabled(false);
    c4.setEnabled(false);
    c5.setEnabled(false);
    c6.setEnabled(false);*/

    Devicepanel1.setBounds(new Rectangle(2, 1, 818, 498));
    Devicepanel1.setLayout(null);
    Userpanel1.setBounds(new Rectangle(4, 19, 598, 413));
    Userpanel1.setLayout(null);
    Okuser.setBounds(new Rectangle(561, 636, 109, 26));
    Okuser.setText("OK");
    Okuser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Okuser_actionPerformed(e);
      }
    });
    Canceluser.setBounds(new Rectangle(703, 636, 112, 27));
    Canceluser.setText("CANCEL");
    Canceluser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Canceluser_actionPerformed(e);
      }
    });
    Backdevice.setBounds(new Rectangle(504, 647, 97, 30));
    Backdevice.setText("BACK");
    Backdevice.setEnabled(false);
    Backdevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Backdevice_actionPerformed(e);
      }
    });
    Nextdevice.setBounds(new Rectangle(611, 647, 97, 30));
    Nextdevice.setText("NEXT");
    Nextdevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Nextdevice_actionPerformed(e);
      }
    });
    Finisheddevice.setBounds(new Rectangle(720, 647, 97, 30));
    Finisheddevice.setEnabled(false);
    Finisheddevice.setText("FINISHED");
    Finisheddevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Finisheddevice_actionPerformed(e);
      }
    });
    Canceldevice.setBounds(new Rectangle(828, 647, 97, 30));
    Canceldevice.setText("CANCEL");
    Canceldevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Canceldevice_actionPerformed(e);
      }
    });
    this.getContentPane().add(jTabbedPane1, new PaneConstraints("jTabbedPane1", "jTabbedPane1", PaneConstraints.ROOT, 1.0f));
    jTabbedPane1.add(Projectpanel,   "Project Configuration");
    Projectpanel.add(Projectpanel1, null);
    Projectpanel1.add(c1, null);
    jTabbedPane1.add(Devicepanel,   "Device Configuration");
    Devicepanel.add(Devicepanel1, null);
    jTabbedPane1.add(Userpanel, "User Configuration");
    Userpanel.add(Userpanel1, null);
    /*Projectpanel1.add(c2, null);
    Projectpanel1.add(c3, null);
    Projectpanel1.add(c4, null);
    Projectpanel1.add(c5, null);
    Projectpanel1.add(c6, null);*/
    Projectpanel.add(Cancel, null);
    Projectpanel.add(Back, null);
    Projectpanel.add(Next, null);
    Projectpanel.add(Finished, null);

    Userpanel1.add(u1,null);
    Userpanel.add(Canceluser, null);
    Userpanel.add(Okuser, null);

    Devicepanel1.add(d1,null);
    Devicepanel.add(Nextdevice, null);
    Devicepanel.add(Backdevice, null);
    Devicepanel.add(Finisheddevice, null);
    Devicepanel.add(Canceldevice, null);

    this.setTitle("CONFIGURATION");
    //jPanel1.add(m);
  }

/*  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }*/

  void Next_actionPerformed(ActionEvent e) {


    switch (projectcountpanel)
    {
      case 0 :

        if (c1.checkallblank()  == true)
        {
          c1.setVisible(false);
          Projectpanel1.remove(c1);
          c2.setdevice(c1.Deviceselectlist.getItems(),c1.Deviceselectlist.getItemCount());
          c2.createNodes();
          c2.setVisible(true);
          Projectpanel1.add(c2,null);
          Back.setEnabled(true);
          projectcountpanel++;
        }



        break;

      case 1 :
        if (c2.checkallblank()  == true)
        {
        c2.setVisible(false);
        Projectpanel1.remove(c2);
        c3.Objecttree.setModel(c2.Objecttree2.getModel());
        c3.Objecttree.repaint();
        c3.setVisible(true);
        Projectpanel1.add(c3,null);

        projectcountpanel++;
        }
        break;

      case 2 :
        c3.setVisible(false);
        Projectpanel1.remove(c3);
        c4.Objecttree.setModel(c2.Objecttree2.getModel());
        c4.Objecttree.repaint();
        c4.setVisible(true);
        Projectpanel1.add(c4,null);
        projectcountpanel++;
        break;

      case 3 :
        c4.setVisible(false);
        Projectpanel1.remove(c4);
        c5.Objecttree.setModel(c2.Objecttree2.getModel());
        c5.Objecttree.repaint();
        c5.setVisible(true);
        Projectpanel1.add(c5,null);
        projectcountpanel++;
        break;

      case 4 :
        c5.setVisible(false);
        Projectpanel1.remove(c5);
        c6.setVisible(true);
        Projectpanel1.add(c6,null);
        Next.setEnabled(false);
        Finished.setEnabled(true);
        projectcountpanel++;
        break;

      default :
    }


  }

  void Okuser_actionPerformed(ActionEvent e) {
    char[] pass = u1.Password.getPassword();
    char[] confirm = u1.Confirmpass.getPassword();
    String userid = new String(u1.Userid.getText());
    String username = new String(u1.Username.getText());
    String division = new String(u1.Division.getText());
    String type = new String();
    if (u1.Typeadmin.isSelected())
    {
      type = "administrator";
    }
    else
    {
      type = "user";
    }

    if (u1.isPasswordCorrect(pass,confirm) == true && pass.length != 0 && confirm.length != 0 && userid.compareTo("") != 0 && username.compareTo("") != 0 && division.compareTo("") != 0)
    {
      String password = new String(pass);
      db.executeSQLupdate("INSERT INTO USERTABLE (USERID,USERNAME,USERPASSWORD,DIVISION,USERTYPE) VALUES ('"+userid+"','"+username+"','"+password+"','"+division+"','"+type+"')");
      JOptionPane jOptionPane1 = new JOptionPane();
        JOptionPane.showMessageDialog(jOptionPane1, "Inserted data to database",
                        "Information", JOptionPane.INFORMATION_MESSAGE);
      this.dispose();

    }
    else if(!(pass.length != 0 && confirm.length != 0 && userid.compareTo("") != 0 && username.compareTo("") != 0 && division.compareTo("") != 0))
    {
      JOptionPane jOptionPane1 = new JOptionPane();
      JOptionPane.showMessageDialog(jOptionPane1, "Fill all blanks",
                        "Error Message", JOptionPane.ERROR_MESSAGE);
    }
    else
    {
      JOptionPane jOptionPane1 = new JOptionPane();
      JOptionPane.showMessageDialog(jOptionPane1, "Confirm password not match",
                        "Error Message", JOptionPane.ERROR_MESSAGE);
      u1.Password.setText("");
      u1.Confirmpass.setText("");
    }


  }

  void Nextdevice_actionPerformed(ActionEvent e) {
    switch (devicecountpanel)
    {
      case 0 :

        if (d1.Deviceid.getText().compareTo("") != 0 && d1.Devicename.getText().compareTo("") != 0 && d1.Deviceip.getText().compareTo("") != 0 && d1.Deviceprotocol.getSelectedItem().toString().compareTo("") != 0)
        {
          d2.Devicename.setText(d1.Devicename.getText());
          d2.Deviceprotocol.setText(d1.Deviceprotocol.getSelectedItem().toString());
          d1.setVisible(false);
          Devicepanel1.remove(d1);
          d2.setVisible(true);
          Devicepanel1.add(d2,null);
          System.out.println("0");
          Backdevice.setEnabled(true);
          devicecountpanel++;
        }

        break;

      case 1 :

 //       if (d2.mib.getText().compareTo("") != 0)
 //       {
          d2.setVisible(false);
          Devicepanel1.remove(d2);
          d3.setVisible(true);
          Devicepanel1.add(d3,null);
          System.out.println("1");
          devicecountpanel++;
  //      }

        break;

      case 2 :
        if (d3.Objectlist.getItemCount() != 0)
        {
          d3.setVisible(false);
          Devicepanel1.remove(d3);
          d4.setVisible(true);
          Devicepanel1.add(d4,null);
          Nextdevice.setEnabled(false);

          d4.m.load(d2.file);
          //System.out.print(d3.Objectlist.getItemCount()+"count");
          d4.Objectlist.removeAll();
          for (int i=0;i<d3.Objectlist.getItemCount();i++)
          {
            d4.Objectlist.add(d3.Objectlist.getItem(i).substring(0,d3.Objectlist.getItem(i).indexOf(" , ")));
            //System.out.print(d3.Objectlist.getItem(i));

          }


          System.out.println("2");
          Finisheddevice.setEnabled(true);
          devicecountpanel++;
        }

        break;



      default :
    }

  }

  void Backdevice_actionPerformed(ActionEvent e) {
    switch (devicecountpanel)
    {
      case 0 :

        System.out.println("0");
        break;

      case 1 :
        d2.setVisible(false);
        Devicepanel1.remove(d2);
        d1.setVisible(true);
        Devicepanel1.add(d1,null);
        Backdevice.setEnabled(false);
        //System.out.println("1");
        break;

      case 2 :
        d3.setVisible(false);
        Devicepanel1.remove(d3);
        d2.setVisible(true);
        Devicepanel1.add(d2,null);
        //System.out.println("2");
        break;

      case 3 :
        d4.setVisible(false);
        Devicepanel1.remove(d4);
        d3.setVisible(true);
        Devicepanel1.add(d3,null);
        break;

      default :
    }
    Nextdevice.setEnabled(true);
    Finisheddevice.setEnabled(false);
    devicecountpanel--;
  }

  void Finisheddevice_actionPerformed(ActionEvent e) {
    String deviceid = d1.Deviceid.getText();
    String devicename = d1.Devicename.getText();
    String deviceip = d1.Deviceip.getText();
    String deviceprotocol = d1.Deviceprotocol.getSelectedItem().toString();
    String mibfile = d2.mib.getText();
    String[] objectlist = new String[d3.Objectlist.getItemCount()];
    objectlist = d3.Objectlist.getItems();
    String[] objectmaplist = new String[d4.Objectmaplist.getItemCount()];
    objectmaplist = d4.Objectmaplist.getItems();
    String objectid;
    String datatype;
    String snmpobjectid;
    String community;

    if (d4.Objectmaplist.getItemCount() != 0)
    {
      db.executeSQLupdate("INSERT INTO DEVICE (DEVICEID,DEVICENAME,IP,MIBFILE,PROTOCOL) VALUES('"+deviceid+"','"+devicename+"','"+deviceip+"','"+mibfile+"','"+deviceprotocol+"')");

      for(int i=0;i<objectlist.length;i++)
      {
        objectid = objectlist[i].substring(0,objectlist[i].indexOf(" , "));
        datatype = objectlist[i].substring(objectlist[i].indexOf(" , ")+3);

        System.out.println(objectid);
        System.out.println(datatype);
        db.executeSQLupdate("INSERT INTO OBJECT (DEVICEID,OBJECTID,DATATYPE) VALUES('"+deviceid+"','"+objectid+"','"+datatype+"')");

      /*System.out.print(objectlist[i]);
      System.out.println(objectlist[i].indexOf(" , "));
      System.out.println(objectid);
      System.out.println(datatype);*/
      }

      for(int i=0;i<objectmaplist.length;i++)
      {
        String temp;
        objectid = objectmaplist[i].substring(0,objectmaplist[i].indexOf(" , "));
        temp = objectmaplist[i].substring(objectmaplist[i].indexOf(" , ")+3);
        snmpobjectid = temp.substring(0,temp.indexOf(" , "));
        community = objectmaplist[i].substring(objectmaplist[i].lastIndexOf(" , ")+3);

        System.out.println(objectid);
        System.out.println(snmpobjectid);
        System.out.println(community);

        db.executeSQLupdate("INSERT INTO SNMPOBJECT (OBJECTID,DEVICEID,SNMPOBJECTID,COMMUNITY) VALUES('"+objectid+"','"+deviceid+"','"+snmpobjectid+"','"+community+"')");

      /*System.out.print(objectlist[i]);
      System.out.println(objectlist[i].indexOf(" , "));
      System.out.println(objectid);
      System.out.println(datatype);
      System.out.println(objectid);
      System.out.println(snmpobjectid);
      System.out.println(community);*/

      }
      JOptionPane jOptionPane1 = new JOptionPane();
        JOptionPane.showMessageDialog(jOptionPane1, "Inserted data to database",
                        "Information", JOptionPane.INFORMATION_MESSAGE);
      this.dispose();
    }
    else
    {

    }




  }

  void Finished_actionPerformed(ActionEvent e) {
    if (c6.checkallblank() == true)
    {
      String projectid = c1.Projectid.getText();
      String projectname = c1.Projectname.getText();
      String projectdescription = c1.Projectdescription.getText();
      Date date = new Date(System.currentTimeMillis());
      String projectdate = date.toString();
      //String projectdate = c1.dd.getText() + "/" + c1.mm.getText() + "/" + c1.yyyy.getText();
      String[][] deviceobject = new String[2][1000];
      deviceobject = c2.deviceobject;
      int countdeviceobject = c2.countdeviceobject;
      String[] user = c6.Userselect.getItems();
      int countuser = c6.Userselect.getItemCount();
      String[][] group = new String[5][100];
      String[][] monitor = new String[3][100];
      group = c3.group;
      monitor = c3.monitor;
      int countgroup = c3.countgroup;
      int countmonitor = c3.countmonitor;
      String[][] fault = new String[7][100];
      fault = c4.fault;
      int countfault = c4.countfault;
      //String faultid = c4.Faultid.getText();
      //String faultname = c4.Faultname.getText();
      String[] tunelist = c5.Tunelist.getItems();
      int counttune = c5.Tunelist.getItemCount();
      //String[][] action = new String[6][100];
      //action = c4.action;
      //int countaction = c4.countaction;
      boolean[] planning = c3.planning;

      db.executeSQLupdate("INSERT INTO PROJECT (PROJECTID,PROJECTNAME,PROJECTDESCRIPTION,PROJECTDATE) VALUES('"+projectid + "','" + projectname + "','" + projectdescription + "','" + projectdate + "')");
      for (int i=0;i<countdeviceobject;i++)
      {
        db.executeSQLupdate("INSERT INTO PROJECTDEVICE (PROJECTID,DEVICEID,OBJECTID) VALUES('"+projectid + "','" + deviceobject[0][i] + "','" + deviceobject[1][i] + "')");
      }
      for (int i=0;i<countuser;i++)
      {
        db.executeSQLupdate("INSERT INTO PROJECTUSER (USERID,PROJECTID) VALUES('"+user[i] + "','" + projectid + "')");
      }



      for (int i=0;i<countmonitor;i++)
      {
        db.executeSQLupdate("INSERT INTO MONITOR (GROUPID,MONITORTYPE,MONITORVALUE) VALUES('" + monitor[0][i] + "','" +monitor[1][i] + "','" + monitor[2][i] + "')");
        db.executeSQLupdate("INSERT INTO PROJECTGROUP (PROJECTID,GROUPID) VALUES('" + projectid + "','" + monitor[0][i]  + "')");
        if (planning[i] == true)
        {
          String[][] tempdeviceobject;
          int tempcount = 0;
          db.executeSQLupdate("INSERT INTO SUPPORTGROUP (PROJECTID,GROUPID) VALUES ('" + projectid + "','"+ monitor[0][i] + "')");
          for (int j = 0;j<countgroup;j++)
          {
            if (group[0][j].compareTo(monitor[0][i]) == 0)
            {
            tempcount++;
          }
          }
          tempdeviceobject = new String[2][tempcount];
          tempcount = 0;
          for (int j = 0;j<countgroup;j++)
          {
            if (group[0][j].compareTo(monitor[0][i]) == 0)
            {
            tempdeviceobject[0][tempcount] = group[1][j];
            tempdeviceobject[1][tempcount] = group[2][j];
            tempcount++;
          }
          }
          String createtable;
          createtable = "CREATE TABLE " + projectid + "_" + monitor[0][i] + "_LOG (ID INT IDENTITY(1,1) PRIMARY KEY, PROJECTID VARCHAR(50), GROUPID VARCHAR(50), ";
          for (int j = 0;j<tempcount;j++)
          {
            createtable += tempdeviceobject[0][j] + tempdeviceobject[1][j] + " VARCHAR(50),";
          }
          createtable = createtable + "THEDATE VARCHAR(50) , THETIME VARCHAR(50))";
          System.out.println("createtable : " + createtable);
          db.executeSQLupdate(createtable);
        }
      }

      for (int i=0;i<countgroup;i++)
      {
        db.executeSQLupdate("INSERT INTO MONITORGROUP (GROUPID,DEVICEID,OBJECTID) VALUES('" + group[0][i]  + "','" + group[1][i] + "','" + group[2][i] + "')");

      }

      for (int i=0;i<countfault;i++)
      {
        db.executeSQLupdate("INSERT INTO FAULT (FAULTID,FAULTNAME,PROJECTID,DEVICEID,OBJECTID,FAULTCHECK,FAULTVALUE,FAULTVALUE2) VALUES('" + fault[0][i] + "','" + fault[1][i] + "','" + projectid + "','" + fault[2][i] +"','" + fault[3][i] + "','" + fault[4][i] + "','" + fault[5][i] + "','" + fault[6][i] + "')");
      }

      for (int i=0;i<counttune;i++)
      {

        db.executeSQLupdate("INSERT INTO TUNING (PROJECTID,DEVICEID,OBJECTID) VALUES('" + projectid + "','" + tunelist[i].substring(0,tunelist[i].indexOf(" , ")) + "','" + tunelist[i].substring(tunelist[i].indexOf(" , ")+3) + "')");
      }

    /*for (int i=0;i<countaction;i++)
    {
      data.insertdb("INSERT INTO ACTION (ACTIONID,ACTIONNAME,ACTIONVALUE,ACTIONDESCRIPTION,PROJECTID,DEVICEID,OBJECTID) VALUES('" + action[0][i] + "','" + action[1][i] + "','" + action[2][i] + "','" + action[3][i] + "','" + projectid + "','" + action[4][i] + "','" + action[5][i] + "')");
    }*/
      JOptionPane jOptionPane1 = new JOptionPane();
        JOptionPane.showMessageDialog(jOptionPane1, "Inserted data to database",
                        "Information", JOptionPane.INFORMATION_MESSAGE);
      this.dispose();
    }
    else
    {

    }
  }

  void Back_actionPerformed(ActionEvent e) {
    switch (projectcountpanel)
    {
      case 0 :

        System.out.println("0");
        break;

      case 1 :
        c2.setVisible(false);
        Projectpanel1.remove(c2);
        c1.setVisible(true);
        Projectpanel1.add(c1,null);
        Back.setEnabled(false);
        //System.out.println("1");
        break;

      case 2 :
        c3.setVisible(false);
        Projectpanel1.remove(c3);
        c2.setVisible(true);
        Projectpanel1.add(c2,null);
        //System.out.println("2");
        break;

      case 3 :
        c4.setVisible(false);
        Projectpanel1.remove(c4);
        c3.setVisible(true);
        Projectpanel1.add(c3,null);
        break;

      case 4 :
        c5.setVisible(false);
        Projectpanel1.remove(c5);
        c4.setVisible(true);
        Projectpanel1.add(c4,null);
        break;

      case 5 :
        c6.setVisible(false);
        Projectpanel1.remove(c6);
        c5.setVisible(true);
        Projectpanel1.add(c5,null);
        break;
      default :
    }
    Next.setEnabled(true);
    Finished.setEnabled(false);
    projectcountpanel--;
  }

  void Cancel_actionPerformed(ActionEvent e) {
    this.dispose();
    //clear
/*    c1.Projectname.setText("");
    c1.Deviceidlist.removeAll();
    c1.Deviceselectlist.removeAll();
    c1.Projectdescription.setText("");
    c1.Projectid.setText("");
    c1.dd.setText("");
    c1.mm.setText("");
    c1.yyyy.setText("");
    int i=0;

    String[] temp = new String[100];
    try
    {
      ResultSet rs;
      rs = db.selectdb("SELECT DEVICEID FROM DEVICE");
      while(rs.next())
      {
        temp[i] = rs.getString("DEVICEID");

        i++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }
    int j = 0;
    while (j<i)
    {
      c1.Deviceidlist.add(temp[j]);
      j++;
    }
    DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");
    c2.Objecttree.removeAll();
    c2.Objecttree = new JTree(top);
    c2.Objecttree.repaint();
    c2.Objecttree2.removeAll();
    DefaultMutableTreeNode top2 =  new DefaultMutableTreeNode("DEVICE");
    c2.Objecttree2 = new JTree(top2);
    c2.Objecttree2.repaint();

    c3.Objecttree.removeAll();
    c3.Planning.setSelected(false);
    c3.Text.setSelected(true);
    c3.Graphtype.setSelectedIndex(0);
    c3.Group.setText("");
    c3.Grouplist.removeAll();

    c4.Value1.setText("");
    c4.Value2.setText("");
    c4.Lowerbound.setSelected(true);
    c4.Objecttree.removeAll();
    c4.Object.setText("");
    c4.Faultid.setText("");
    c4.Faultname.setText("");

    c5.Objecttree.removeAll();
    c5.Tunelist.removeAll();

    c6.Userlist.removeAll();
    c6.Userselect.removeAll();
    i=0;

    temp = new String[100];
    try
    {
      ResultSet rs;

      rs = db.selectdb("SELECT * FROM USERINFO");
      //rs.first();
      while(rs.next())
      {
        temp[i] = rs.getString("USERID");
        //Servicetype.addItem(temp);
        //System.out.println(temp[i]);
        i++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }
    j = 0;
    while (j<i)
    {
      c6.Userlist.add(temp[j]);
      j++;
    }
*/
  }

  void Canceldevice_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void Canceluser_actionPerformed(ActionEvent e) {
    this.dispose();
  }

}