package dms;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import ipworks.*;
import java.util.Vector;

public class SNMPManager extends Thread{
  Snmp snmp = new Snmp();
 // private String result="0";
  private String result="*";
  private boolean getflag=true;
  public SNMPManager() {

   try {
      SNMPInit();
      //sendGet("161.246.5.99","1.3.6.1.2.1.1.1.0","public");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }


  public void SNMPInit() throws Exception {

    snmp.setActive(true);
    snmp.addSnmpEventListener(new ipworks.SnmpEventListener() {
      public void error(SnmpErrorEvent e) {
      }
      public void getNextRequest(SnmpGetNextRequestEvent e) {
      }
      public void getRequest(SnmpGetRequestEvent e) {
      }
      public void getResponse(SnmpGetResponseEvent e) {
        snmp_getResponse(e);
      }
      public void readyToSend(SnmpReadyToSendEvent e) {
      }
      public void setRequest(SnmpSetRequestEvent e) {

      }
      public void trap(SnmpTrapEvent e) {
        snmp_getTrap(e);
      }
      public void PDUTrace(SnmpPDUTraceEvent e) {
      }
      public void informRequest(SnmpInformRequestEvent e) {
      }
      public void getBulkRequest(SnmpGetBulkRequestEvent e) {
      }
    });
  }



  public void sendGet(String deviceIp,String deviceObjId,String deviceCommunity) {
    System.out.println("SNMPManager sendGet : ");
    try {
      result = "*";
      snmp.setObjCount(1);
      snmp.setObjId(1,deviceObjId);		// indexes start at 1
      snmp.setCommunity(deviceCommunity);
      snmp.setRemoteHost(deviceIp);
      //snmp.setActive(true);
      snmp.setAction(Snmp.snmpSendGetRequest);
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
  }

  public void sendSet(String deviceIp,String deviceObjId,String deviceCommunity,String objType,String objValue) {
    System.out.println("SNMPManager sendSet : ");
    int type = 0;


    try {
      if (objType.compareTo("otInteger") == 0)
      {
        type = Snmp.otInteger;
      }
      else if (objType.compareTo("otOctetString") == 0)
      {
        type = Snmp.otOctetString;
      }
      else if (objType.compareTo("otNull") == 0)
      {
        type = Snmp.otNull;
      }
      else if (objType.compareTo("otObjectID") == 0)
      {
        type = Snmp.otObjectId;
      }
      else if (objType.compareTo("otIPAddress") == 0)
      {
        type = Snmp.otIPAddress;
      }
      else if (objType.compareTo("otCounter32") == 0)
      {
        type = Snmp.otCounter32 ;
      }
      else if (objType.compareTo("otGauge32") == 0)
      {
        type = Snmp.otGauge32 ;
      }
      else if (objType.compareTo("otTimeTicks") == 0)
      {
        type = Snmp.otTimeTicks;
      }
      else if (objType.compareTo("otOpaque") == 0)
      {
        type = Snmp.otOpaque ;
      }
      else if (objType.compareTo("otNSAP") == 0)
      {
        type = Snmp.otNSAP ;
      }
      else if (objType.compareTo("otCounter64") == 0)
      {
        type = Snmp.otCounter64;
      }
      else if (objType.compareTo("otUnsignedInteger32") == 0)
      {
        type = Snmp.otUnsignedInteger32;
      }
      else snmp.setErrorStatus(2);

      snmp.setObjCount(1);
      snmp.setObjId(1,deviceObjId);		// indexes start at 1
      snmp.setCommunity(deviceCommunity);
      snmp.setRemoteHost(deviceIp);
      snmp.setObjType(1,type);

      snmp.setObjValue(1,objValue.getBytes());
      //snmp.setActive(true);
      snmp.setAction(Snmp.snmpSendSetRequest);
      result = "Success";
    } catch (IPWorksException ipwe) {
      result = "error";
      JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
  }
  public void sendGetCon(String deviceIp,String deviceObjId,String deviceCommunity,int interval){
    while(getflag!=false)
    {
     try {

      snmp.setObjCount(1);

      snmp.setObjId(1,deviceObjId);		// indexes start at 1
      snmp.setCommunity(deviceCommunity);
      snmp.setRemoteHost(deviceIp);

      //snmp.setActive(true);
      snmp.setAction(Snmp.snmpSendGetRequest);
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
    }

  }
  public void setgetflag(boolean tt)
  {
    getflag= tt;
  }
  void snmp_getResponse(SnmpGetResponseEvent sgre) {

    try {
      System.out.println("SNMPManager getresponse : " + sgre.sourceAddress);
      String ee = new String(snmp.getObjValue(1));
      System.out.println("SNMPManager getresponse : " +ee);
      result = ee;

    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
    switch (sgre.errorStatus) {
      case 0: result = result; break;
      case 1: result = " [ERROR: tooBig (1)]:"; break;
      case 2: result = " [ERROR: noSuchName (2)]:"; break;
      case 3: result = " [ERROR: badValue (3)]:"; break;
      case 4: result = " [ERROR: readOnly (4)]:"; break;
      case 5: result = " [ERROR: genError (5)]:"; break;
      default: result = " [ERROR: unknown code (" + sgre.errorStatus + ")]:";
    }

  }
  public String getResult()
  {
    /*----------------------------------
    if(result.compareTo("*")==0)
    {
      Dialog1 d = new Dialog1();
      d.annouce("SNMP timeout");
      d.show();
      result="0";
    }
    //----------------------------------*/
    System.out.println("SNMPManager getResult : " + result);
   return result;
  }

  public String setResult()
  {
    return result;

  }
  public void snmp_getTrap(SnmpTrapEvent ee)
  {
     Dialog1 dl1 = new Dialog1();
     dl1.setSize(400,400);
     dl1.annouce(ee.agentAddress+"--"+ee.specificType+"--"+ee.timeStamp);
  }

  public void SetResult(String rs)
  {
    result = rs;
  }


}