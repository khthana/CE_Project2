package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.tree.*;
import java.sql.*;
import javax.swing.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditProject4 extends JPanel {
  private String[] deviceobject;
  private Database db;
  private JComboBox Selectproject = new JComboBox();
  private DefaultListModel listModel;
  private JList Devicelist = new JList();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JLabel List = new JLabel();

  DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");

  JTree Objecttree = new JTree(top);
  JScrollPane treeView = new JScrollPane(Objecttree);
  DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();



  DefaultMutableTreeNode node[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child[] = new DefaultMutableTreeNode[1000];
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JButton Add = new JButton();
  private JButton Remove = new JButton();


  public EditProject4(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(null);
    Selectproject.setBounds(new Rectangle(160, 21, 285, 28));

    jScrollPane1.setBounds(new Rectangle(513, 100, 282, 355));
    Ok.setBounds(new Rectangle(561, 508, 107, 27));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(688, 506, 102, 30));
    Cancel.setText("CANCEL");
    jLabel1.setText("SELECT PROJECT");
    jLabel1.setBounds(new Rectangle(40, 18, 117, 30));
    List.setText("DEVICE LIST");
    List.setBounds(new Rectangle(508, 63, 134, 28));
    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(111, 72, 299, 375));
    Objecttree.setShowsRootHandles(true);
    Add.setBounds(new Rectangle(371, 250, 110, 28));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Remove.setBounds(new Rectangle(371, 308, 110, 28));
    Remove.setText("REMOVE");
    Remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Remove_actionPerformed(e);
      }
    });
    this.add(Selectproject, null);
    this.add(jLabel1, null);

    Objecttree.setEditable(true);
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);


    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(49, 100, 282, 355));
    this.add(treeView, null);
    this.add(jScrollPane1, null);
    this.add(Add, null);
    this.add(Remove, null);
    this.add(List, null);
    this.add(Cancel, null);
    this.add(Ok, null);




   // Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT");
      while (rs.next())
      {
        Selectproject.addItem(rs.getString("PROJECTID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject4 : " + sql);
    }


    listModel = new DefaultListModel();

    listModel.removeAllElements();
    ResultSet rs;

    rs = db.executeSQLquery("SELECT COUNT(*) FROM TUNING WHERE PROJECTID = '" +Selectproject.getSelectedItem() + "'");
    int count=0;
    while(rs.next())
    {
      count = rs.getInt(1);
    }
    deviceobject = new String[count];
    rs = db.executeSQLquery("SELECT * FROM TUNING WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
    int i = 0;
    while(rs.next())
    {

      String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
      deviceobject[i] = temp;
      listModel.addElement(temp);
      System.out.println(temp);
      i++;

    }
    Devicelist = new JList(listModel);
    Devicelist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Devicelist.setSelectedIndex(0);
    Devicelist.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent e) {
        Devicelist_valueChanged(e);
      }
    });


    Selectproject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectproject_actionPerformed(e);
      }
    });

    createNodes();
    jScrollPane1.getViewport().add(Devicelist, null);
  }

  public void createNodes() {
   // Database db = new Database();
    ResultSet rs;
    ResultSet rs2;
    String objectid="";
    String deviceid="";
    int j=0;

    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM OBJECT");
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        j = 0;
        node[i] = new DefaultMutableTreeNode(deviceid);
        top.add(node[i]);

        rs2 = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + deviceid + "'");

        while (rs2.next())
        {
          objectid = rs2.getString("OBJECTID");
          child[j] = new DefaultMutableTreeNode(objectid);
          node[i].add(child[j]);
          j++;

        }

        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

  }

  void Ok_actionPerformed(ActionEvent e) {
   // Database db = new Database();
/*    db.executeSQLupdate("DELETE FROM OBJECT WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
    for (int i=0;i<listModel.getSize();i++)
    {
      String deviceid = listModel.getElementAt(i).toString().substring(0,listModel.getElementAt(i).toString().indexOf(" , "));
      String objectid = listModel.getElementAt(i).toString().substring(listModel.getElementAt(i).toString().indexOf(" , ")+1,listModel.getElementAt(i).toString().length()-1);
      db.executeSQLupdate("INSERT INTO OBJECT (PROJECTID,DEVICEID,OBJECTID) VALUES('" + Selectproject.getSelectedItem() + " , " + deviceid + objectid + "')");
    }
*/
    String[] delete = checkdelete();
    String[] add = checkadd();
    for(int i=0;i<delete.length;i++)
    {
      db.executeSQLupdate("DELETE FROM TUNING WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "' AND DEVICEID = '" + delete[i].substring(0,delete[i].indexOf(" , ")) + "' AND OBJECTID = '" + delete[i].substring(delete[i].indexOf(" , ")+3) + "'");
    }
    for(int i=0;i<add.length;i++)
    {
      //System.out.println(add[i].substring(0,add[i].indexOf(" , ")) + " , " + );
      db.executeSQLupdate("INSERT INTO TUNING (PROJECTID,DEVICEID,OBJECTID) VALUES('" + Selectproject.getSelectedItem() + "' , '" + add[i].substring(0,add[i].indexOf(" , ")) + "' , '" + add[i].substring(add[i].indexOf(" , ")+3) + "')");
    }

    listModel.removeAllElements();
    ResultSet rs;

    rs = db.executeSQLquery("SELECT COUNT(*) FROM TUNING WHERE PROJECTID = '" +Selectproject.getSelectedItem() + "'");
    int count=0;
    try
    {
      while(rs.next())
      {
        count = rs.getInt(1);
      }
      deviceobject = new String[count];
      rs = db.executeSQLquery("SELECT * FROM TUNING WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      int i = 0;
      while(rs.next())
      {

        String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
        deviceobject[i] = temp;
        listModel.addElement(temp);
        System.out.println(temp);
        i++;

      }
    }
    catch(SQLException ee)
    {
      System.out.println(ee);
    }


  }

  public void Devicelist_valueChanged(ListSelectionEvent e) {

  }

  void Add_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

 TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
 if (Objecttree.isVisible(pathnode)) {

  if (node.isLeaf()) {
    String leafpath = Objecttree.getLastSelectedPathComponent().toString();
    TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
    String parent = temp.getLastPathComponent().toString();
    //System.out.println(leafpath);
    //System.out.println(parent);
    if (listModel.indexOf(parent + " , " + leafpath) == -1)
    {
      listModel.addElement(parent + " , " + leafpath);
    }

    }
    else if (node.isRoot()) {
        System.out.println("root");
    }
    else if (node.isNodeAncestor(top)) {
      System.out.println("ancestor");
    }
 }


  }

  void Remove_actionPerformed(ActionEvent e) {
    if (Devicelist.getSelectedIndex() != -1)
    {
      listModel.removeElementAt(Devicelist.getSelectedIndex());
    }
  }

  String[] checkdelete()
  {
    String[] str;
    int count=0;
    for (int i = 0;i<deviceobject.length ;i++)
    {
      if (listModel.indexOf(deviceobject[i]) == -1)
      {
        count++;
      }
    }
    str = new String[count];
    count = 0;
    for (int i = 0;i<deviceobject.length ;i++)
    {
      if (listModel.indexOf(deviceobject[i]) == -1)
      {
        str[count] = deviceobject[i];
        count++;
      }
    }
    return str;
  }

  String[] checkadd()
  {
    String[] str;
    int count=0;
    boolean flag = true;
    System.out.println("listModel.getSize : " + listModel.getSize());
    System.out.println("deviceobject.length : " + deviceobject.length);
    for (int i = 0;i<listModel.getSize();i++)
    {
      for (int j = 0;j<deviceobject.length;j++)
      {
        System.out.println("i : " + listModel.get(i).toString() + " j : " + deviceobject[j]);
        if (deviceobject[j].compareTo(listModel.get(i).toString()) == 0)
        {
          flag = false;
        }
      }
      if (flag == true)
      {
        count++;
      }
      flag = true;
    }

    str = new String[count];
    count = 0;
    flag = true;
    for (int i = 0;i<listModel.getSize();i++)
    {
      for (int j = 0;j<deviceobject.length;j++)
      {
        if (deviceobject[j].compareTo(listModel.get(i).toString()) == 0)
        {
          flag = false;
        }
      }
      if (flag == true)
      {
        str[count] = listModel.getElementAt(i).toString();
        count++;
      }
      flag = true;
    }
    return str;
  }

  void Selectproject_actionPerformed(ActionEvent e) {
    ResultSet rs;
  //  Database db = new Database();
    listModel.removeAllElements();
    rs = db.executeSQLquery("SELECT COUNT(*) FROM TUNING WHERE PROJECTID = '" +Selectproject.getSelectedItem() + "'");
    int count=0;
    try
    {
      while(rs.next())
    {
      count = rs.getInt(1);
    }
    deviceobject = new String[count];
    rs = db.executeSQLquery("SELECT * FROM TUNING WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
    int i = 0;
    while(rs.next())
    {

      String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
      deviceobject[i] = temp;
      listModel.addElement(temp);
      System.out.println(temp);
      i++;

    }
    }
    catch(SQLException ee)
    {
      System.out.println(ee);
    }

  }

}