package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Deviceconfig2 extends JPanel {
  private JButton mibbrowse = new JButton();
  JTextField mib = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  FileInputStream file;
  JTextField Devicename = new JTextField();
  JTextField Deviceprotocol = new JTextField();
  public Deviceconfig2() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setSize(new Dimension(1000,700));
    jLabel3.setBounds(new Rectangle(77, 162, 69, 28));
    jLabel3.setText("Mib");
    mib.setBounds(new Rectangle(121, 163, 411, 32));
    mibbrowse.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mibbrowse_actionPerformed(e);
      }
    });
    mibbrowse.setText("MIB BROWSE");
    mibbrowse.setBounds(new Rectangle(573, 163, 124, 32));
    this.setLayout(null);
    jLabel1.setText("DEVICE NAME :");
    jLabel1.setBounds(new Rectangle(72, 56, 104, 28));
    jLabel2.setText("PROTOCOL :");
    jLabel2.setBounds(new Rectangle(73, 102, 88, 30));
    Devicename.setEditable(false);
    Devicename.setBounds(new Rectangle(185, 55, 298, 32));
    Deviceprotocol.setEditable(false);
    Deviceprotocol.setBounds(new Rectangle(185, 107, 298, 32));
    this.add(jLabel3, null);
    this.add(mib, null);
    this.add(mibbrowse, null);
    this.add(Deviceprotocol, null);
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    this.add(Devicename, null);
  }
  void mibbrowse_actionPerformed(ActionEvent e) {
    JFileChooser chooser = new JFileChooser();
    try {
        if ( chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
          //final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
          mib.setText(chooser.getSelectedFile().getAbsolutePath());
          FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
          file = mibFile;
        }
      }
      catch (Exception ex) {
                //setEnabled(true);
                System.err.println("Catch exception while parsing mib: " + ex );
              }
  }
}