package dms;
//package examples.chart.datasource;


import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import javax.swing.JScrollPane;
import javax.swing.text.PlainDocument;
import com.klg.jclass.chart.JCChart;
import com.klg.jclass.chart.ChartDataView;
import com.klg.jclass.chart.data.JCFileDataSource;
import com.klg.jclass.chart.JCAxis;
import com.klg.jclass.chart.ChartDataEvent;
import com.klg.jclass.util.swing.JCExitFrame;
import com.klg.jclass.chart.data.JCDefaultDataSource;
//import projectsnmp.Frame1;
class ResettingDataSource extends JCDefaultDataSource implements Runnable {
int num;
String[][] deviceobjectid;
double v;
int index = 0;
//SNMPManager snmp = new SNMPManager();
private Database db;
MessageHandler m;
/**
 * y data for this data source
 */

static double[][] y;
/*{
        { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
};*/

/**
 * Point labels for this data source
 */
static String[] pl = {
        "A", "B", "C", "D", "E", "F", "G", "H", "I", "J",
};

/**
 * Series labels for this data source
 */
static String[] sl;
/*= {
        "Dancer",
};*/

/**
 * Parent chart instance.  Used to force repaint after updating
 * the data.
 */
JCChart parentChart;
//FrameGraph f ;
/**
 * Creates the data source with the static
 * member data y, pl, sl.  The base class
 * is JCDefaultDataSource, which handles all
 * the data containment issues.
 */
ResettingDataSource(JCChart parentChart,int num,String[] name,String[][] deviceobjectid,Database d) {




  super(null, y = new double[num][10], pl, sl = name, "Resetter");
  db = d;
  m = new MessageHandler(db);
  for (int i=0;i<num;i++)
  {
    for (int j=0;j<10;j++)
    {
      y[i][j] = 0.0;
    }
  }
  this.parentChart = parentChart;
  this.num = num;
  this.deviceobjectid = deviceobjectid;

        //f = f1;
}

/**
 * Run method for threads.  At a particular
 * interval, chooses a random point and modifies
 * the value to a new random value between 10 and
 * 100.
 */

public void run() {
        while (true) {
                // Wait 3/4 second
                try {
                        Thread.currentThread().sleep(1000);
                }
                catch (Exception e) {
                }

                // Modify a random point
                //int index = (int)(Math.random() * 10);
                //int index2 = (int)(Math.random() * 10);
                double value = Math.random() * 100;
                if (index == 9)
                {
                  index = 0;
                }
                else index++;

                double value2 = Math.random() * 100;
                //y[0][index] = value;
                //*********
                //y[0][index] = f.value;
                //snmp.sendGet("161.246.5.99","1.3.6.1.2.1.4.3.0","public");
                //snmp.sendGet("localhost","1.3.6.1.2.1.11.1.0","public");
                for (int i=0;i<num;i++)
                {

                  m.constructMessage(deviceobjectid[i][0],deviceobjectid[i][1],"GET","","","");
                  m.sendMessage();
                  try
                  {
                        Thread.currentThread().sleep(500);
                  }
                  catch (Exception e)
                  {

                  }

                  y[i][index] = Double.parseDouble(m.recieveMessage());

                }
                /*
                m.constructMessage("DEVICE1","INROUTER1","public","","");
                m.sendMessage();
                y[0][index] = Double.parseDouble(m.recieveMessage());
                m.constructMessage("DEVICE2","INROUTER2","public","","");
                m.sendMessage();
                y[1][index] = Double.parseDouble(m.recieveMessage());
                */
                //y[0][index] = Double.parseDouble(snmp.getResult());
                //*********
                //System.out.println("Reset =" + f.value);
                //y[1][index2] = value2;

                // Force recalculation of chart.  This
                // will recalculate the axis bounds.
                fireChartDataEvent(ChartDataEvent.RESET, 0, 0);
        }

}
  public void set(double a)
  {

    v = a;
  }
}
