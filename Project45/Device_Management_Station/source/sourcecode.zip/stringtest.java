package dms;
import java.util.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class stringtest {
  String[] s;//= new String[100];
  public stringtest() {
    print();
  }
  public static void main(String[] args) {
    stringtest stringtest1 = new stringtest();
  }
  public void print()
  {
     s= new String[100];
     s[1]="pol";
     s[2]="pol2";
     System.out.println(s[1]);
     System.out.println(s[2]);
     System.out.println(s.length);
  }
}