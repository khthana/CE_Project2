package dms;

import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import ipworks.*;
import javax.swing.*;
import java.util.Vector;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Traplistener extends JInternalFrame {
  Snmp snmp1 = new Snmp();
  private Database db;
  Vector trapVector = new Vector();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JButton jButton1 = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JTextArea jTextArea2 = new JTextArea();
  private JList trapList = new JList();
  private String projectname;
  public Traplistener(String pname,Database d) {
    try {
      db = d;
     snmp1.setLocalPort(162);
     projectname=pname;
     jbInit();
   } catch(Exception e) {
     e.printStackTrace();
    }

  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);

    this.setSize(new Dimension(400, 500));
    this.getContentPane().setLayout(null);
    jScrollPane1.setBounds(new Rectangle(21, 82, 347, 154));
    jButton1.setBounds(new Rectangle(76, 274, 242, 30));
    jButton1.setText("start/stop trap listener");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jLabel1.setText("Trap listener");
    jLabel1.setBounds(new Rectangle(26, 31, 231, 33));
    jTextArea2.setBounds(new Rectangle(22, 347, 334, 27));
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jScrollPane1, null);
    jScrollPane1.getViewport().add(trapList, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jTextArea2, null);
    snmp1.addSnmpEventListener(new ipworks.SnmpEventListener() {
      public void error(SnmpErrorEvent e) {
      }
      public void getBulkRequest(SnmpGetBulkRequestEvent e) {
      }
      public void getNextRequest(SnmpGetNextRequestEvent e) {

      }
      public void getRequest(SnmpGetRequestEvent e) {

      }
      public void getResponse(SnmpGetResponseEvent e) {
      }
      public void informRequest(SnmpInformRequestEvent e) {
      }
      public void PDUTrace(SnmpPDUTraceEvent e) {
      }
      public void readyToSend(SnmpReadyToSendEvent e) {
      }
      public void setRequest(SnmpSetRequestEvent e) {

      }
      public void trap(SnmpTrapEvent e) {
        snmp1_trap(e);
      }
    });
  }
  void snmp1_trap(SnmpTrapEvent e) {
   String message = e.sourceAddress;
   switch (e.genericType) {
     case 0 : message += " coldStart"; break;
     case 1 : message += " warmStart"; break;
     case 2 : message += " linkDown"; break;
     case 3 : message += " linkUp"; break;
     case 4 : message += " authenticationFailure"; break;
     case 5 : message += " egpNeighborLoss"; break;
     case 6 : message += " enterpriseSpecific: " + e.specificType; break;
   }
   trapVector.add(message);
   trapList.setListData(trapVector);
   ResultSet rs = db.executeSQLquery("SELECT DEVICENAME FROM DEVICE WHERE IP='"+e.sourceAddress+"'");
   int i=0;
   try{
   while(rs.next())
   {

     i++;
   }
   }catch(SQLException sq)
   {System.out.println("Error connecting Database");}
   String[] s = new String[i];
   ResultSet rs2 = db.executeSQLquery("SELECT DEVICEID FROM DEVICE WHERE IP='"+e.sourceAddress+"'");
   i=0;
   try{
   while(rs2.next())
   {
      s[i]=rs2.getString(1);
   }
   }catch(SQLException sq)
   {System.out.println("Error connecting Database");}
   //s[i] = "thegloskline";
   ResultSet rs3 = db.executeSQLquery("SELECT OBJECTID FROM SNMPOBJECT WHERE SNMPOBJECTID='"+e.enterprise+"' AND DEVICEID = '" + s[i] + "'");
   String ss="";
   try{
     while(rs3.next())
     {
       ss=rs3.getString(1);
     }
   }catch(SQLException sql)
   {System.out.println("Error connecting database");}
   db.executeSQLupdate("INSERT INTO FAULTEVENT (PROJECTID,DEVICEID,OBJECTID,FAULTDESCRIPTION,FAULTDATE,FAULTTIME) VALUES ('"+projectname+"','"+s[0]+"','"+ss+"','Out of range fault','"+(new Date(System.currentTimeMillis()).toString())+"','"+Integer.toString(e.timeStamp)+"')");

  }

  void jButton1_actionPerformed(ActionEvent e) {
    try {
     snmp1.setActive(!snmp1.isActive());
   } catch (IPWorksException ipwe) {
     JOptionPane.showMessageDialog(this, ipwe.getMessage());
   }

   //timer1.Enabled = snmp1.Active;
    jTextArea2.setText(snmp1.isActive() ? "Start Listening" : "Stop Listening");
  }
 /* public static void main(String[] args) {
   (new Traplistener()).setVisible(true);
  }*/
}