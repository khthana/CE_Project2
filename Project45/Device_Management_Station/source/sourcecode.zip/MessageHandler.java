package dms;
import java.sql.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MessageHandler {
  private String destinationdevice;
  private String destinationobject;
  private String operation;
  private String dataforoperation;
  private String datatype;
  private String protocolname;
  private String datavalue;
  //------SNMP global variable Session--------
  private String hostname;
  private String objectid;
  private String community;
  String snmpresult;
  //------SNMP global variable Session--------
  private Database db;
  SNMPManager snmp = new SNMPManager();

  public MessageHandler(Database d) {
    db = d;
  }
  public void constructMessage(String desadd,String desobj,String oper,String dfo,String dt,String value)
  {
      destinationdevice=desadd;
      destinationobject=desobj;
      operation=oper;
      dataforoperation=dfo;
      datatype=dt;
      datavalue = value;
      translateMessage();
  }
  public void translateMessage()
  {
    //if(protocolname.compareTo("SNMP")==0)
    //{
        ResultSet rs = db.executeSQLquery("SELECT IP,PROTOCOL FROM DEVICE WHERE DEVICEID='"+destinationdevice+"'");
        try{
          while(rs.next())
          {

            hostname = rs.getString("IP");
            protocolname = rs.getString("PROTOCOL");
          }
        }catch(SQLException sql)
        {
          System.out.println("Error connecting Database");
        }
    System.out.println(hostname);

    if (destinationobject.compareTo("") == 0)
    {
      objectid = "1.3.6.1.2.1.1.1.0";
      community = "public";
      snmp.SetResult("*");
    }
    else
    {
      ResultSet rs1 = db.executeSQLquery("SELECT SNMPOBJECTID,COMMUNITY FROM SNMPOBJECT WHERE OBJECTID='"+destinationobject+"' AND DEVICEID = '" +destinationdevice+"'");
      try{
        while(rs1.next())
        {
          objectid = rs1.getString("SNMPOBJECTID");
          community = rs1.getString("COMMUNITY");
        }
        }catch(SQLException sql)
        {
          System.out.println("Error connecting Database");
        }
    }



      System.out.println(objectid+"   "+community);
        //}
    }
 public void sendMessage()
 {
   if(operation.compareTo("GET")==0)
   {
     if(protocolname.compareTo("SNMP")==0)
     {
       snmp.sendGet(hostname,objectid,"public");
     }
   }
   else if (operation.compareTo("SET") == 0)
   {
     if (protocolname.compareTo("SNMP") == 0)
     {
       snmp.sendSet(hostname,objectid,community,datatype,datavalue);
     }
   }

  }
 public String recieveMessage()
 {
   if(protocolname.compareTo("SNMP")==0)
   {
   snmpresult = snmp.getResult();
   //snmp.SetResult("*");
   System.out.println(snmpresult);
   }
   return snmpresult;

 }

}
