package dms;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Whiletest extends Thread  {
  public boolean flag=true;

  public Whiletest() {

  }
  public void run() {
          while (flag==true) {
                  // Wait 3/4 second
                  try {
                          Thread.currentThread().sleep(1000);
                  }
                  catch (Exception e) {
                  }

               System.out.println("5555");
          }

}

}
