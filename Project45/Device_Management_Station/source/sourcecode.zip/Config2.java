package dms;

import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import javax.swing.tree.*;
import java.sql.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Config2 extends JPanel {
  //PaneLayout paneLayout1 = new PaneLayout();
  //JPanel jPanel1 = new JPanel();
  String[][] deviceobject = new String[2][1000];
  int countdeviceobject = 0;
  String[] devicelist;
  int devicenum;
  int count=0;
  int childcount=0;
  private Database db;

  //create the tree
  DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");
  DefaultMutableTreeNode top2 =  new DefaultMutableTreeNode("DEVICE");
  JTree Objecttree = new JTree(top);
  JScrollPane treeView = new JScrollPane(Objecttree);
  DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();
  JTree Objecttree2 = new JTree(top2);
  JScrollPane treeView2 = new JScrollPane(Objecttree2);

  DefaultMutableTreeNode node[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child[] = new DefaultMutableTreeNode[1000];

  DefaultMutableTreeNode node2[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child2[] = new DefaultMutableTreeNode[1000];

  private JButton Add = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JButton Remove = new JButton();
  private JLabel jLabel2 = new JLabel();
  private JTextArea Objectdetail = new JTextArea();
  private Border border1;
  private TitledBorder titledBorder1;
  private Border border2;

  public Config2(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void setdevice(String[] a,int b)
  {
    devicelist = a;
    devicenum = b;
  }
/*  public static void main(String arg[])
  {

    Config2 con2 = new Config2();

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = con2.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    con2.setSize(frameSize.width,frameSize.height);
    con2.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    con2.setVisible(true);
  }*/
  private void jbInit() throws Exception {
    //this.getContentPane().setLayout(paneLayout1);
    //jPanel1.setLayout(null);

    //initializes tree and creates tree selection event listener
    //createNodes(top);
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178)),"OBJECT DETAIL");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    this.setSize(new Dimension(1000,700));
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);

    Objecttree2.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    Objecttree2.setShowsRootHandles(true);
/*    jTree1.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
        jTree1_valueChanged(e);
      }
    });*/
    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(111, 72, 299, 375));

    treeView2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView2.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView2.setBounds(new Rectangle(605, 72, 299, 375));

    this.setLayout(null);
    Add.setBounds(new Rectangle(453, 154, 111, 36));
    Add.setBorder(border2);
    Add.setText("ADD");
   // Add.addActionListener(new ActionListener(this));
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    //this.getContentPane().add(jPanel1, new PaneConstraints("jPanel1", "jPanel1", PaneConstraints.ROOT, 0.5f));
    jLabel1.setText("OBJECT TREE");
    jLabel1.setBounds(new Rectangle(111, 19, 244, 34));
    Remove.setBounds(new Rectangle(453, 220, 111, 36));
    Remove.setBorder(border2);
    Remove.setText("REMOVE");
    Remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Remove_actionPerformed(e);
      }
    });
    jLabel2.setText("CHOOSED OBJECT TREE");
    jLabel2.setBounds(new Rectangle(604, 19, 216, 30));
    Objectdetail.setBorder(titledBorder1);
    Objectdetail.setBounds(new Rectangle(114, 482, 789, 108));
    MouseListener ml = new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        int selRow = Objecttree.getRowForLocation(e.getX(), e.getY());
        TreePath selPath = Objecttree.getPathForLocation(e.getX(), e.getY());
        if(selRow != -1) {
          if(e.getClickCount() == 1) {
            //mySingleClick(selRow, selPath);

          }
          else if(e.getClickCount() == 2) {
            //myDoubleClick(selRow, selPath);
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

            TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
            if (Objecttree.isVisible(pathnode)) {

              if (node.isLeaf()) {
                String leafpath = Objecttree.getLastSelectedPathComponent().toString();
                TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
                String parent = temp.getLastPathComponent().toString();
                ResultSet rs;


                String datatype = "";

                try
                {
                  //System.out.println(Servicetype.getItemAt(Servicetype.getSelectedIndex()));

                  rs = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + parent + "' AND OBJECTID = '" + leafpath + "'");

                  while (rs.next())
                  {
                    datatype = rs.getString("DATATYPE");
                  }

                }
                catch(SQLException ex)
                {
                  System.out.println(ex);
                }

                Objectdetail.setText("DEVICEID : " + parent + "\nOBJECTID : " + leafpath + "\nDATATYPE : " + datatype);
              }
              else if (node.isRoot()) {
                System.out.println("root");
              }
              else if (node.isNodeAncestor(top)) {
                System.out.println("ancestor");
              }
            }
          }
        }
      }
    };
    Objecttree.addMouseListener(ml);
    MouseListener m2 = new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        int selRow = Objecttree2.getRowForLocation(e.getX(), e.getY());
        TreePath selPath = Objecttree2.getPathForLocation(e.getX(), e.getY());
        if(selRow != -1) {
          if(e.getClickCount() == 1) {
            //mySingleClick(selRow, selPath);

          }
          else if(e.getClickCount() == 2) {
            //myDoubleClick(selRow, selPath);
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree2.getLastSelectedPathComponent();

            TreePath pathnode = (TreePath)Objecttree2.getLeadSelectionPath();
            if (Objecttree2.isVisible(pathnode)) {

              if (node.isLeaf()) {
                String leafpath = Objecttree2.getLastSelectedPathComponent().toString();
                TreePath temp = Objecttree2.getAnchorSelectionPath().getParentPath();
                String parent = temp.getLastPathComponent().toString();
                ResultSet rs;

               // Database db = new Database();
                String datatype = "";

                try
                {
                  //System.out.println(Servicetype.getItemAt(Servicetype.getSelectedIndex()));

                  rs = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + parent + "' AND OBJECTID = '" + leafpath + "'");

                  while (rs.next())
                  {
                    datatype = rs.getString("DATATYPE");
                  }

                }
                catch(SQLException ex)
                {
                  System.out.println(ex);
                }

                Objectdetail.setText("DEVICEID : " + parent + "\nOBJECTID : " + leafpath + "\nDATATYPE : " + datatype);
              }
              else if (node.isRoot()) {
                System.out.println("root");
              }
              else if (node.isNodeAncestor(top)) {
                System.out.println("ancestor");
              }
            }
          }
        }
      }
    };
    Objecttree2.addMouseListener(m2);
    this.add(Add, null);
    this.add(jLabel1, null);
    this.add(treeView, null);
    this.add(Remove, null);
    this.add(jLabel2, null);
    this.add(treeView2, null);
    this.add(Objectdetail, null);
  }
  /*protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }*/

  //method createNodes to add nodes to the tree
  public void createNodes() {
  //  Database db = new Database();
    ResultSet rs;
    String objectid;
    int j=0;

    for (int i=0;i<devicenum;i++)
    {
      j = 0;
      //System.out.println(devicelist[i]);
      node[i] = new DefaultMutableTreeNode(devicelist[i]);

      top.add(node[i]);

      rs = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + devicelist[i] + "'");
      try
      {
        while (rs.next())
        {
          objectid = rs.getString("OBJECTID");
          child[j] = new DefaultMutableTreeNode(objectid);
          node[i].add(child[j]);
          j++;

        }
      }catch(SQLException ex)
      {
        System.out.println(ex);
      }


    }



/*
      node1 = new DefaultMutableTreeNode("First child");
      top.add(node1);

      child1 = new DefaultMutableTreeNode("First child item 1");
      node1.add(child1);
      child1 = new DefaultMutableTreeNode("First child item 2");
      node1.add(child1);

      child1_level1 = new DefaultMutableTreeNode("Item 2 - child 1");
      child1.add(child1_level1);
      node2 = new DefaultMutableTreeNode("Second child");
      top.add(node2);

      child2 = new DefaultMutableTreeNode("Second child item 1");
      node2.add(child2);
      child2 = new DefaultMutableTreeNode("Second child item 2");
      node2.add(child2);
      child2 = new DefaultMutableTreeNode("Second child item 3");
      node2.add(child2);
*/
   }

   public void createNodes2(String parent,String leaf,DefaultMutableTreeNode top2) {
     int i=0;
     int j=0;
     System.out.println("createNodes2");
     boolean flag = false;
     System.out.println("count = "+count);
     if (count ==0)
     {
System.out.println("000");
       node2[i] = new DefaultMutableTreeNode(parent);
       child2[i] = new DefaultMutableTreeNode(leaf);
       top2.add(node2[i]);
       node2[i].add(child2[i]);
       count++;
     }
     else
     {
       System.out.println("else");
       i=0;
       while(i<count && flag==false)
       {
         System.out.println("count = "+count);
         System.out.println("i = "+i);
         System.out.println(node2[i].toString());

         if (node2[i].toString().compareTo(parent) == 0)
         {
           flag = true;
           j = i;
         }
         else
         {
           j = count;


         }
         i++;
       }




       if (flag == true)
       {
         child2[childcount] = new DefaultMutableTreeNode(leaf);
         node2[j].add(child2[childcount]);

       }
       else
       {
         node2[j] = new DefaultMutableTreeNode(parent);
         child2[childcount] = new DefaultMutableTreeNode(leaf);
         top2.add(node2[j]);
         node2[j].add(child2[childcount]);
         count++;
       }
     }

     childcount++;


     Objecttree2.repaint();




 /*
       node1 = new DefaultMutableTreeNode("First child");
       top.add(node1);

       child1 = new DefaultMutableTreeNode("First child item 1");
       node1.add(child1);
       child1 = new DefaultMutableTreeNode("First child item 2");
       node1.add(child1);

       child1_level1 = new DefaultMutableTreeNode("Item 2 - child 1");
       child1.add(child1_level1);
       node2 = new DefaultMutableTreeNode("Second child");
       top.add(node2);

       child2 = new DefaultMutableTreeNode("Second child item 1");
       node2.add(child2);
       child2 = new DefaultMutableTreeNode("Second child item 2");
       node2.add(child2);
       child2 = new DefaultMutableTreeNode("Second child item 3");
       node2.add(child2);
 */
   }

  void mibbrowse_actionPerformed(ActionEvent e) {
    //this.setEnabled(false);
      JFileChooser chooser = new JFileChooser();
      //ExampleFileFilter filter = new ExampleFileFilter();

      //filter.addExtension("mib");
      //filter.addExtension("gif");
      //filter.setDescription("MIB FILE");
      //chooser.setFileFilter(filter);

      try {
        if ( chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
          //final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
          //mib.setText(chooser.getSelectedFile().getAbsolutePath());

        }
      }
      catch (Exception ex) {
                //setEnabled(true);
                System.err.println("Catch exception while parsing mib: " + ex );
              }
  }



  void Add_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

     TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
     if (Objecttree.isVisible(pathnode)) {

      if (node.isLeaf()) {
        String leafpath = Objecttree.getLastSelectedPathComponent().toString();
        TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
        String parent = temp.getLastPathComponent().toString();
        //System.out.println(leafpath);
        //System.out.println(parent);
        deviceobject[0][countdeviceobject] = parent;
        deviceobject[1][countdeviceobject] = leafpath;
        countdeviceobject++;
        createNodes2(parent,leafpath,top2);
        }
        else if (node.isRoot()) {
            System.out.println("root");
        }
        else if (node.isNodeAncestor(top)) {
          System.out.println("ancestor");
        }
     }




  }

  void Remove_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree2.getLastSelectedPathComponent();

     TreePath pathnode = (TreePath)Objecttree2.getLeadSelectionPath();
     if (Objecttree2.isVisible(pathnode)) {

      if (node.isLeaf()) {


        //String leafpath = Objecttree.getLastSelectedPathComponent().toString();
        //TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
        //String parent = temp.getLastPathComponent().toString();
        //System.out.println(leafpath);
        //System.out.println(parent);
        //deviceobject[0][countdeviceobject] = parent;
        //deviceobject[1][countdeviceobject] = leafpath;
        //countdeviceobject++;
        //createNodes2(parent,leafpath,top2);
        }
        else if (node.isRoot()) {
            System.out.println("root");
        }
        else if (node.isNodeAncestor(top)) {
          System.out.println("ancestor");
        }
     }
  }

  public boolean checkallblank(){

    if (count != 0)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
}

class ActionListener implements java.awt.event.ActionListener {
  private Config2 adaptee;

  ActionListener(Config2 adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.Add_actionPerformed(e);
  }
}