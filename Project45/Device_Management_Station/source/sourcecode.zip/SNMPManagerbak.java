package dms;


import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import ipworks.*;
import java.util.Vector;

public class SNMPManagerbak extends Thread{
  Snmp snmp = new Snmp();
  private String result="0";
  private boolean getflag=true;
  public SNMPManagerbak() {

   try {
      SNMPInit();
      //sendGet("161.246.5.99","1.3.6.1.2.1.1.1.0","public");
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void SNMPInit() throws Exception {

    snmp.setActive(true);
    snmp.addSnmpEventListener(new ipworks.SnmpEventListener() {
      public void error(SnmpErrorEvent e) {
      }
      public void getNextRequest(SnmpGetNextRequestEvent e) {
      }
      public void getRequest(SnmpGetRequestEvent e) {
        snmp_getRequest(e);
      }
      public void getResponse(SnmpGetResponseEvent e) {
        snmp_getResponse(e);
      }
      public void readyToSend(SnmpReadyToSendEvent e) {
      }
      public void setRequest(SnmpSetRequestEvent e) {
      }
      public void trap(SnmpTrapEvent e) {
       snmp_trap(e);
      }
      public void PDUTrace(SnmpPDUTraceEvent e) {
      }
      public void informRequest(SnmpInformRequestEvent e) {
      }
      public void getBulkRequest(SnmpGetBulkRequestEvent e) {
      }
    });
  }
  public void snmp_trap(SnmpTrapEvent ee)
  {
  }


  public void sendGet(String deviceIp,String deviceObjId,String deviceCommunity) {

    try {
      //snmp.setSNMPVersion(1);
      snmp.setObjCount(1);
      snmp.setObjId(1,deviceObjId);
      snmp.setRequestId(5);
      //snmp.setObjType(1,5);
     // indexes start at 1
      snmp.setCommunity(deviceCommunity);
      snmp.setRemoteHost(deviceIp);
      //snmp.setActive(true);
      snmp.setAction(Snmp.snmpSendGetRequest);
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
  }
  public void sendGetCon(String deviceIp,String deviceObjId,String deviceCommunity,int interval){
    while(getflag!=false)
    {
     try {
      //snmp.setSNMPVersion(1);
      snmp.setObjCount(1);
      snmp.setObjId(1,deviceObjId);		// indexes start at 1
      snmp.setCommunity(deviceCommunity);
      snmp.setRemoteHost(deviceIp);
      //snmp.setActive(true);
      snmp.setAction(Snmp.snmpSendGetRequest);
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
    }

  }
  public void setgetflag(boolean tt)
  {
    getflag= tt;
  }
  void snmp_getResponse(SnmpGetResponseEvent sgre) {

    switch (sgre.errorStatus) {
      case 0: result = " [OK]:"; break;
      case 1: result = " [ERROR: tooBig (1)]:"; break;
      case 2: result = " [ERROR: noSuchName (2)]:"; break;
      case 3: result = " [ERROR: badValue (3)]:"; break;
      case 4: result = " [ERROR: readOnly (4)]:"; break;
      case 5: result = " [ERROR: genError (5)]:"; break;
      default: result = " [ERROR: unknown code (" + sgre.errorStatus + ")]:";
    }
    try {
      System.out.println(sgre.sourceAddress);

      String ee = new String(snmp.getObjValue(1));

      System.out.println(ee);

      result = ee;
    } catch (IPWorksException ipwe) {
     JOptionPane.showMessageDialog(null, ipwe.getMessage());
    }
  }
  public void snmp_getRequest(SnmpGetRequestEvent e)
  {
    System.out.println(e.sourceAddress);
    System.out.println(e.sourcePort);
  }
  public String getResult()
  {
   return result;
  }

}