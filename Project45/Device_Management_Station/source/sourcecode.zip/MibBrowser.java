package dms;


import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import javax.swing.text.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java_cup.runtime.*;
import sck.*;
import sck.beans.*;
import sck.beans.MibParser.*;
import sck.beans.VarEvent;

/** MibBrowser is a bean designed to parse mib files (according to SMI V1 syntax).
 *  <P>After selecting an SNMP object, you can get info on it (Object->Info) or
 *  trigger an event (VarEvent) containing this Object after editing (Object->Edit).
 *  This behaviour is useful to interact with the other sck beans, and especially whith PduGenerator.
 *  @see PduGenerator
 *  You can also Drag an SNMP Object (<CTRL> + mouse button to copy it) and drop
 *  it (as a NULL variable) in a SmiDisplay or a pduGenerator.
 *  @see SmiDisplay
 *  @see PduGenerator
 */
public class MibBrowser extends JPanel implements Serializable{

  transient DragJTree t;
  transient DefaultMutableTreeNode root = new DefaultMutableTreeNode(new SNMPobj("iso",1));
  transient parser parser_obj = new parser();
  private JMenuBar menuBar;
  String stt;
  // Not saved : it's the IDE responsability .
  transient private Vector VarListeners_ = new Vector();

  public void load(final FileInputStream mibFile)
{
  this.setEnabled(false);
  //JFileChooser chooser = new JFileChooser();

  try {
   /* if ( chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
      final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
  final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());*/
      Thread worker = new Thread() {
        public void run(){
          parser_obj.setInputStream(new BufferedInputStream(mibFile));
          parser_obj.setRoot(root);

          try{
            final Symbol last = parser_obj.parse(); // We use a thread to avoid
                                                    // starving the event dispatch thread.
            mibFile.close();

            // refresh in the event dispatch thread !
            SwingUtilities.invokeLater( new Runnable(){
              public void run(){
                ((DefaultTreeModel)t.getModel()).reload(); // advertise DefaultTreeModel that he has been modified
                setEnabled(true);
                if (last != null)
                  t.setSelectionPath(new TreePath(((DefaultMutableTreeNode)last.value).getPath()));
              }
            });
          }
          catch (Exception ex) {
            setEnabled(true);
            System.err.println("Catch exception while parsing mib: " + ex );
          }
        }
      };// end worker

      worker.start();
    //}
  }
  catch (Exception ex) {
    System.err.println("Catch exception before parsing mib: " + ex );
    //ex.printStackTrace();
  }

  }

  public String getobj()
  {
   return stt;
  }
  /** A bean needs a constructor without any arg. */
  public MibBrowser(){

    this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

/*
    final JTextField jTextField1 = new JTextField();
    menuBar = new JMenuBar();

    JMenu menu1 = new JMenu("Mib");
    JMenuItem item10 = menu1.add(new LoadAction());
    item10.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L,0,true));

    menuBar.add(menu1);

    JMenu menu2 = new JMenu("Object");
    // first item & Keyboard accelerators
    JMenuItem item20 = menu2.add(new EditAction());
    item20.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,0,true));
    // second item
    JMenuItem item21 = menu2.add(new InfoAction());
    item21.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,0,true));

    menuBar.add(menu2);
    menuBar.setMaximumSize(new Dimension(120,20));
    menuBar.setBorder(null);

    Box menuBox = Box.createHorizontalBox();
    menuBox.add(menuBar);
    menuBox.add(Box.createHorizontalGlue()); // forces left alignment.
*/
    t = new DragJTree(new DefaultTreeModel(root));
    t.putClientProperty("JTree.lineStyle", "Angled");
    t.expandRow(0);

//    jTextField1.setText("");
//    jTextField1.setBounds(new Rectangle(55, 84, 169, 21));
    //contentPane.setLayout(null);

    //add(menuBox);
    add(new JScrollPane(t));
    //add(jTextField1);
    t.addMouseListener( new MouseAdapter() {

     public void mousePressed(MouseEvent e) {
        /* System.out.print("wowwwww");
         int selRow = t.getRowForLocation(e.getX(), e.getY());
         TreePath selPath = t.getPathForLocation(e.getX(), e.getY());
         if(selRow != -1) {
             if(e.getClickCount() == 1) {
                 //mySingleClick(selRow, selPath);
             }
             else if(e.getClickCount() == 2) {
                 //myDoubleClick(selRow, selPath);
             }
         }*/
         TreePath pth = t.getLeadSelectionPath();
      if (pth == null)
        return;
      Object[] nodeList = pth.getPath();
      SNMPobj node = (SNMPobj) (((DefaultMutableTreeNode) nodeList[nodeList.length -1]).getUserObject());
//      jTextField1.setText(SNMPobj.getFullOid(nodeList));
      stt = SNMPobj.getFullOid(nodeList);

     }
 });
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }



  }



  class LoadAction extends AbstractAction {
    public LoadAction(){
      super("Load");
    }

    // actionperformed() is only call in the event dispacth thread (swing design for thread safety) but we spawn
    // a thread (worker) to avoid starving the event dispatch thread. So, to disallow concurrent access to critical
    // section (root for example) we disable LoadAction and enable it after parse is done.


    public void actionPerformed(ActionEvent e){
      this.setEnabled(false);
      JFileChooser chooser = new JFileChooser();
      try {
        if ( chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
          final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());

          Thread worker = new Thread() {
            public void run(){
              parser_obj.setInputStream(new BufferedInputStream(mibFile));
              parser_obj.setRoot(root);

              try{
                final Symbol last = parser_obj.parse(); // We use a thread to avoid
                                                        // starving the event dispatch thread.
                mibFile.close();

                // refresh in the event dispatch thread !
                SwingUtilities.invokeLater( new Runnable(){
                  public void run(){
                    ((DefaultTreeModel)t.getModel()).reload(); // advertise DefaultTreeModel that he has been modified
                    setEnabled(true);
                    if (last != null)
                      t.setSelectionPath(new TreePath(((DefaultMutableTreeNode)last.value).getPath()));
                  }
                });
              }
              catch (Exception ex) {
                setEnabled(true);
                System.err.println("Catch exception while parsing mib: " + ex );
              }
            }
          };// end worker

          worker.start();
        }
      }
      catch (Exception ex) {
        System.err.println("Catch exception before parsing mib: " + ex );
        //ex.printStackTrace();
      }
    }
  }

  class EditAction extends AbstractAction {
    public EditAction(){
      super("Edit");
    }

    // Create a popUpeditor
    public void actionPerformed(ActionEvent e) {
      TreePath pth = t.getLeadSelectionPath();
      if (pth == null)
        return;
      Object[] nodeList = pth.getPath();
      final JDialog editor = new popUpEditor(null,"Object edition",MibBrowser.this,nodeList);
      editor.setVisible(true);
    }
  }

  class popUpEditor extends JDialog implements VarListener{
    private MibBrowser callback;
    private JVarEditor editor;
    private JLabel misc;
    private JButton buttonCANCEL;
    private JButton buttonOK;

    popUpEditor(Frame f, String title, MibBrowser callback, Object[] nodeList){
      super(f,title,true);//modal
      this.callback = callback;

      if (callback.getFont() != null) this.setFont(callback.getFont());
      if (callback.getBackground() != null) this.setBackground(callback.getBackground());
      if (callback.getForeground() != null) this.setForeground(callback.getForeground());

      getContentPane().setLayout(new BorderLayout(2,2));

      // first panel: buttons
      JPanel p1= new JPanel();
      buttonOK = new JButton("OK");
      buttonOK.addActionListener(
        new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e){
            editor.validateVar();
            popUpEditor.this.setVisible(false);
            popUpEditor.this.dispose();
          }
        });
      p1.add(buttonOK);
      buttonCANCEL = new JButton("CANCEL");
      buttonCANCEL.addActionListener(
        new java.awt.event.ActionListener() {
          public void actionPerformed(ActionEvent e){
            popUpEditor.this.setVisible(false);
            popUpEditor.this.dispose();
          }
        });
      p1.add(buttonCANCEL);

      // JvarEditor + JLabel in a Box
      Box box = Box.createVerticalBox();

      editor = new JVarEditor();
      editor.addVarListener(this);
      misc = new JLabel();

      SNMPobj node = (SNMPobj) (((DefaultMutableTreeNode) nodeList[nodeList.length -1]).getUserObject());
      String oid = new String(SNMPobj.getFullOid(nodeList));
      String syntaxString;
      String miscString;

      if (node.getSyntax() == null){
        miscString = new String("Registration point.");
      } else {
        if (node.getSyntax().toString().startsWith("SEQUENCE")){
          miscString = new String(node.getName() + " is a table.");
        } else {
          if (node.getIndex() != null){
            miscString = new String(node.getName() + " is a row." );
          } else{
            SNMPobj parent = (SNMPobj) (((DefaultMutableTreeNode) nodeList[nodeList.length -2]).getUserObject());
            if (parent.getIndex() == null){
              miscString = new String("Leaf: instance is .0");
              oid += ".0";
            } else {
              miscString = new String("Leaf: use index (" + parent.getIndex() + ")" );
            }
            String className = node.getSyntax().getSmiClass().getName();
            editor.setSyntax(className.substring(className.lastIndexOf('.')+1)); // removes prefix
          }
        }
      }
      editor.setOid(oid);
      misc.setText(miscString);

      box.add(editor);
      box.add(misc);
      getContentPane().add(box,"Center");
      getContentPane().add(p1,"South");
      pack();

    }

    public void VarChanged(VarEvent e) {
      callback.triggerVarEvent(e);
      super.dispose();
    }
  }

  class InfoAction extends AbstractAction {

    public InfoAction(){
      super("Info");
    }

    public void actionPerformed(ActionEvent e) {
      TreePath pth = t.getLeadSelectionPath();
      if (pth == null)
        return;
      Object[] nodeList = pth.getPath();
      SNMPobj node = (SNMPobj) (((DefaultMutableTreeNode) nodeList[nodeList.length -1]).getUserObject());

      StringBuffer message = new StringBuffer();
      message.append("Name:        " + node.getName() + "\n");
      message.append("Oid:         " + SNMPobj.getFullOid(nodeList) + "\n");
      if ( node.getStatus() != null)
        message.append("Status:      " + node.getStatus() + "\n");
      if ( node.getAccess() != null)
        message.append("Access:      " + node.getAccess() + "\n");
      if ( node.getSyntax() != null)
        message.append("Syntax:      " + node.getSyntax().toString() + "\n");
      if ( node.getIndex()  != null)
        message.append("Index:       " + node.getIndex()  + "\n");
      if ( node.getDefVal() != null)
        message.append("DefVal:      " + node.getDefVal() + "\n");
      if ( node.getDescription() != null)
        message.append("Description: " + node.getDescription() + "\n");
      if ( node.getReference() != null)
        message.append("Reference:   " + node.getReference() + "\n");
      JOptionPane.showMessageDialog(MibBrowser.this,message.toString(),
                  "Object information",JOptionPane.INFORMATION_MESSAGE);
    }
  }

  /** Used by the inner class: popUpEditor.
   */
  void triggerVarEvent(VarEvent e) {
    Vector liste = new Vector();
    try{
      synchronized (this) {
        liste = (Vector)VarListeners_.clone();
      }
      for (int i = 0; i < liste.size(); i++)
        ((VarListener)liste.elementAt(i)).VarChanged(e);
    }catch ( Exception ex) {
        System.out.println("MibBrowser.triggerVarEvent() : ");
        System.out.println(ex);
    }
  }

  /** Add subscribers for VarEvent generated by this bean.
   */
  public synchronized void addVarListener(VarListener listener){
    VarListeners_.addElement(listener);
  }

  /** Sign off.
   */
  public synchronized void removeVarListener(VarListener listener){
    VarListeners_.removeElement(listener);
  }

  /** Custom serialisation.
   *  Be careful: MibBrowserBean is not serialized (no "hiddenstate" in beanInfo):
   *  these methods are not called by the applet generated from the Beanbox.
   */
  private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
    in.defaultReadObject();

    VarListeners_ = new Vector(); // Beanbox use code generation to re-create bean's connections.
    root = new DefaultMutableTreeNode(new SNMPobj("iso",1));
    t = new DragJTree(new DefaultTreeModel(root));
    t.putClientProperty("JTree.lineStyle", "Angled");
    t.expandRow(0);;
    parser_obj = new parser();

  }

  private void writeObject(ObjectOutputStream out) throws IOException {
    out.defaultWriteObject();
  }

  /** To run in a standalone window. */
  public static void main(String[] args) {
    JFrame f = new JFrame("Mib Browser");
    f.setSize(300, 300);
    f.getContentPane().add(new MibBrowser());
    f.setVisible(true);

    f.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        Window w = e.getWindow();
        w.setVisible(false);
        w.dispose();
        System.exit(0);

      }
    });
  }
  private void jbInit() throws Exception {
    this.setLayout(null);
  }





}

class DragJTree extends JTree implements DragGestureListener {
  // For D&D

  private DragSource dragSource;
  private DragSourceListener dsListener;

  DragJTree(DefaultTreeModel _root) {
    super(_root);
    this.dragSource = DragSource.getDefaultDragSource();

    // DragSourceListener provides visual feedback.
    this.dsListener = new DragSourceListener(){
      public void dragEnter(DragSourceDragEvent e){
        DragSourceContext context = e.getDragSourceContext();

        if ( (e.getDropAction() & DnDConstants.ACTION_COPY) != 0){
          context.setCursor(DragSource.DefaultCopyDrop);
        }else
          context.setCursor(DragSource.DefaultCopyNoDrop);
      }
      public void dragOver(DragSourceDragEvent e){
      }
      public void dragExit(DragSourceEvent e){
      }
      public void dragDropEnd(DragSourceDropEvent e){
      }
      public void dropActionChanged(DragSourceDragEvent e){
      }
    };

    // COPY = drag + <CTRL>
    this.dragSource.createDefaultDragGestureRecognizer(
      this, DnDConstants.ACTION_COPY, this);
  }

  // DragGestureListener: sends the DragSource a startDrag message.
  public void dragGestureRecognized(DragGestureEvent e){

    if (e.getDragAction() != DnDConstants.ACTION_COPY)
      return;
    TreePath pth = getLeadSelectionPath();
    if (pth == null){
      System.out.println("Nothing selected !");
      getToolkit().beep();
    } else {
      Object[] nodeList = pth.getPath();
      SNMPobj node = (SNMPobj) (((DefaultMutableTreeNode) nodeList[nodeList.length -1]).getUserObject());
      String oid = new String(SNMPobj.getFullOid(nodeList));
      SNMPobj parent = (SNMPobj) (((DefaultMutableTreeNode) nodeList[nodeList.length -2]).getUserObject());
      if (parent != null)
        if (parent.getIndex() == null)
          oid += ".0";
      try{
        TransferableVar transferable = new TransferableVar(new Var(oid));
        e.startDrag(DragSource.DefaultCopyNoDrop,transferable,dsListener);
      } catch(Exception ex){
        System.err.println(ex);
      }
    }
  }
}