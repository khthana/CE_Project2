package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class UserLogin extends JInternalFrame{//Dialog {
  private JPanel panel1 = new JPanel();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JTextField jTextField1 = new JTextField();
  private JPasswordField jPasswordField1 = new JPasswordField();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  Database db;
  Dialog1 dialog = new Dialog1();
  private Desktop themain;
  public UserLogin(String title, boolean modal,Desktop tm,Database d) {
    //super(frame, title, modal);
    dialog.setSize(400,400);
    db = d;
    themain = tm;
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
/*  public static void main(String[] args) {
  (new UserLogin().setVisible(true));

  }*/
 /* public UserLogin() {
    this("Userlogin", false);
  }*/
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    panel1.setLayout(null);
    jLabel1.setText("Please enter your username and Password");
    jLabel1.setBounds(new Rectangle(18, 14, 247, 39));
    jLabel2.setText("username");
    jLabel2.setBounds(new Rectangle(29, 81, 76, 34));
    jLabel3.setText("password");
    jLabel3.setBounds(new Rectangle(29, 139, 76, 35));
    jTextField1.setBounds(new Rectangle(128, 84, 172, 30));
    jPasswordField1.setBounds(new Rectangle(127, 144, 174, 32));
    jButton1.setBounds(new Rectangle(123, 210, 88, 33));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(221, 210, 86, 32));
    jButton2.setText("CANCEL");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    this.getContentPane().setBackground(Color.lightGray);
    getContentPane().add(panel1);
    panel1.add(jLabel2, null);
    panel1.add(jLabel3, null);
    panel1.add(jTextField1, null);
    panel1.add(jLabel1, null);
    panel1.add(jPasswordField1, null);
    panel1.add(jButton1, null);
    panel1.add(jButton2, null);
    this.setTitle("USER LOGIN");
  }

  void jButton1_actionPerformed(ActionEvent e) {
    String check = jTextField1.getText();
    String ss="";
    boolean ck=true;
    char[] check2=jPasswordField1.getPassword();
    char[] trans={1};
    try {
    ResultSet rs = db.executeSQLquery("SELECT USERPASSWORD FROM USERTABLE WHERE USERID='"+check+"' AND USERTYPE='user'");
    while (rs.next())
    {
      ss = rs.getString("USERPASSWORD");

    }

    }
    catch (SQLException sqle)
  {
   System.out.println("Error connecting DB");
   System.out.println(sqle.toString());
  }
    trans= ss.toCharArray();
 if (trans.length!=check2.length)
 {
   System.out.println("Password not correct.");
   JOptionPane jOptionPane1 = new JOptionPane();
        JOptionPane.showMessageDialog(jOptionPane1, "Password incorrect , Please re-enter password",
                        "Error Message", JOptionPane.ERROR_MESSAGE);
  // dialog.annouce("Password incorrect, Please re-enter password");
  // dialog.show();
 }
 else
 {

    for(int i=0;i<trans.length;i++)
    {
      if (trans[i]!=check2[i])
        ck=false;
    }
    if (ck==false)
{
  System.out.println("Password not correct.");
  JOptionPane jOptionPane1 = new JOptionPane();
        JOptionPane.showMessageDialog(jOptionPane1, "Password incorrect , Please re-enter password",
                        "Error Message", JOptionPane.ERROR_MESSAGE);
 // dialog.annouce("Password incorrect, Please re-enter password");
 //  dialog.show();
}
else if (ck==true)
{

 System.out.println("Password correct");
 //--------

  db.executeSQLupdate("INSERT INTO EVENT (EVENTNAME,EVENTDESCRIPTION,EVENTDATE,EVENTTIME)VALUES ('Userlogin','Userlogin to project','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
 //--------
 this.dispose();
 //----
    Usermain um = new Usermain(check,themain,db);
    um.show();
 //----
}
}

}
void jButton2_actionPerformed(ActionEvent e) {
       jTextField1.setText("");
       jPasswordField1.setText("");
       this.dispose();
}
}