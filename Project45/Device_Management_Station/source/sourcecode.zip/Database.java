package dms;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;

public class Database {
  Connection dbCon;
  ResultSet ss;
  public Database(String ip,String username,String password) {
    try
    {
      //Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      //dbCon=DriverManager.getConnection("jdbc:odbc:DeviceManagementStation");
      Class.forName("com.microsoft.jdbc.sqlserver.SQLServerDriver");
      dbCon = DriverManager.getConnection ("jdbc:microsoft:sqlserver://"+ip+":1433",username,password);
      //dbCon = DriverManager.getConnection ("jdbc:microsoft:sqlserver://ESLSERVER:1433",username,password);
      JOptionPane jOptionPane1 = new JOptionPane();
      JOptionPane.showMessageDialog(jOptionPane1, "Database Connected",
                        "Information", JOptionPane.INFORMATION_MESSAGE);
    }
      catch(ClassNotFoundException e)
      {
        System.out.println("Error connecting DB");
        System.out.println(e.toString());

      }
      catch(SQLException e)
      {
        JOptionPane jOptionPane1 = new JOptionPane();
        JOptionPane.showMessageDialog(jOptionPane1, "Error connecting database",
                        "Error Message", JOptionPane.ERROR_MESSAGE);
        System.out.println("Error connecting DB");
        System.out.println(e.toString());
      }
  }
  public ResultSet executeSQLquery(String sql)
  {
    try{
       Statement s = dbCon.createStatement();
       ss = s.executeQuery(sql);


     }
     catch (SQLException sqle)
        {
            System.out.println("Error connecting DB");
            System.out.println(sqle.toString());

        }
     return ss;
  }
  public void executeSQLupdate(String sql)
  {
    try{
       Statement s = dbCon.createStatement();
       s.executeUpdate(sql);

     }
     catch (SQLException sqle)
        {
            System.out.println("Error connecting DB");
            System.out.println(sqle.toString());
        }

  }
  public void connecttionclose()
  { try {
    dbCon.close();
  }
  catch (SQLException sqle)
  {
    System.out.println("Error connecting DB");
    System.out.println(sqle.toString());
  }
}
}