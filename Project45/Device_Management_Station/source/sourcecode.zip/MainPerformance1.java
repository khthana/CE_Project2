package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import com.klg.jclass.util.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import javax.swing.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MainPerformance1 extends JInternalFrame{
  private Desktop themain;
  private DefaultListModel listModel;
  private JButton Graph = new JButton();
  private Database db;
  ResultSet rs;
  //FrameGraph u;
  //FrameGraph u2;
  private String projectid;
  public String groupname;
  private JButton Text = new JButton();
  private JButton Picture = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JButton Cemen = new JButton();
  private JMenuBar jMenuBar1 = new JMenuBar();
  private PanelPicture panelpicture;
  //private PanelCemen panelcemen;
  private JPanel jPanel1 = new JPanel();
  private PaneLayout paneLayout2 = new PaneLayout();
  private Border border1;
  private JButton Select = new JButton();
  private JMenu jMenu1 = new JMenu();
  private JMenuItem jMenuClose = new JMenuItem();
  private JButton Tuning = new JButton();
  private JButton Close = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList Grouplist = new JList();
  private JButton Refresh = new JButton();
  public MainPerformance1(String pid,Desktop tm,Database d) {

    try {
      db = d;
      themain = tm;
      projectid = pid;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
   // Refresh.setVisible(false);
    listModel = new DefaultListModel();
    Grouplist = new JList(listModel);
    Grouplist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Grouplist.setSelectedIndex(0);

    Grouplist.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent e) {
        Grouplist_valueChanged(e);
      }
    });


        //Create the list and put it in a scroll pane


    this.getContentPane().setBackground(Color.lightGray);
    this.setSize(new Dimension(800,600));
    rs = db.executeSQLquery("SELECT * FROM PROJECTGROUP WHERE PROJECTID = '" + projectid + "'");
    while(rs.next())
    {
      listModel.addElement(rs.getString("GROUPID"));
      //Grouplist.add(rs.getString("GROUPID"));
    }
    border1 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158)),"ALL DEVICE FOR THIS PROJECT");
    this.getContentPane().setLayout(null);
    Graph.setBounds(new Rectangle(161, 381, 68, 27));
    Graph.setText("Graph");
    Graph.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Graph_actionPerformed(e);
      }
    });
    Text.setBounds(new Rectangle(151, 414, 86, 27));
    Text.setText("Text");
    Text.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Text_actionPerformed(e);
      }
    });
    Picture.setBounds(new Rectangle(159, 442, 68, 27));
    Picture.setText("Picture");
    Picture.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Picture_actionPerformed(e);
      }
    });
    jLabel1.setText("Group");
    jLabel1.setBounds(new Rectangle(17, 14, 148, 29));
    Cemen.setBounds(new Rectangle(156, 474, 68, 25));
    Cemen.setText("Cemen");
    Cemen.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cemen_actionPerformed(e);
      }
    });
    jPanel1.setBorder(border1);
    jPanel1.setBounds(new Rectangle(253, 48, 509, 481));
    jPanel1.setLayout(paneLayout2);

    int numofdevice = 0;
    //String groupid = Grouplist.getSelectedItem();
    //System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM PROJECTDEVICE WHERE PROJECTID = '"+ projectid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    rs = db.executeSQLquery("SELECT * FROM PROJECTDEVICE WHERE PROJECTID = '" + projectid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    int countdevice = 0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM PROJECTDEVICE WHERE PROJECTID = '" + projectid + "'");
    try
    {
      while (rs.next())
      {
        countdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    String[] device = new String[countdevice];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM PROJECTDEVICE WHERE PROJECTID = '" + projectid + "'");
    i = 0;
    try
    {
      while (rs.next())
      {
        device[i] = rs.getString("DEVICEID");
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    panelpicture = new PanelPicture(numofdevice,name,deviceobjectid,countdevice,device,projectid,themain,db);
    panelpicture.repaint();
    //panelcemen = new PanelCemen(numofdevice,name,deviceobjectid,countdevice,device,projectid);
    Select.setBounds(new Rectangle(24, 386, 97, 28));
    Select.setText("SELECT");
    Select.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Select_actionPerformed(e);
      }
    });
    jMenu1.setText("File");
    jMenuClose.setText("Close");
    Tuning.setBounds(new Rectangle(26, 446, 97, 27));
    Tuning.setText("TUNING");
    Tuning.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Tuning_actionPerformed(e);
      }
    });
    //jPanel1.add(panelcemen, new PaneConstraints("panelpicture", "panelpicture", PaneConstraints.ROOT, 0.5f));
    panelpicture.repaint();
    Close.setBounds(new Rectangle(638, 538, 100, 26));
    Close.setText("CLOSE");
    Close.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Close_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(26, 54, 207, 312));
    Refresh.setBounds(new Rectangle(518, 539, 94, 27));
    Refresh.setText("REFRESH");
    Refresh.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Refresh_actionPerformed(e);
      }
    });
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(Select, null);
    this.getContentPane().add(Graph, null);
    this.getContentPane().add(Text, null);
    this.getContentPane().add(Picture, null);
    this.getContentPane().add(Cemen, null);
    this.getContentPane().add(Tuning, null);
    this.getContentPane().add(jPanel1, null);
    /*this.setJMenuBar(jMenuBar1);
    jMenuClose.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e)
      {
        jMenuClose_actionPerformed(e);
      }
    }
    );
    jMenuBar1.add(jMenu1);
    jMenu1.add(jMenuClose);*/
    jPanel1.add(panelpicture, new PaneConstraints("panelpicture", "panelpicture", PaneConstraints.ROOT, 0.5f));
    this.getContentPane().add(Close, null);
    this.getContentPane().add(jScrollPane1, null);
    this.getContentPane().add(Refresh, null);
    jScrollPane1.getViewport().add(Grouplist, null);
    this.setTitle("PERFORMANCE");
    themain.addframe(this);
    Graph.setVisible(false);
    Text.setVisible(false);
    Picture.setVisible(false);
    Cemen.setVisible(false);

  }

  void Graph_actionPerformed(ActionEvent e) {


    String groupid = Grouplist.getSelectedValue().toString();
    int numofdevice = 0;
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println("aa"  + ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

/*
    FrameGraph u = new FrameGraph(3,name,deviceobjectid,"plot");

    u.show();



    FrameGraph u2 = new FrameGraph(2,name,deviceobjectid,"plot");

    u2.show();
*/
    groupname = Grouplist.getSelectedValue().toString();
    JCExitFrame f = new JCExitFrame("Strip Chart Demo");
    StripChart s = new StripChart(numofdevice,name,deviceobjectid,"plot",projectid,groupname,db);
    f.getContentPane().add("Center",s);
    f.pack();
    f.setVisible(true);
  }

  void Text_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedValue().toString();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println("aa"  + ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    FrameText f = new FrameText(numofdevice,name,deviceobjectid,groupid,projectid,themain,db);
    //f.pack();
    f.setSize(new Dimension(800,600));
    f.setVisible(true);

  }

  void Picture_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedValue().toString();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    int countdevice = 0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    try
    {
      while (rs.next())
      {
        countdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    String[] device = new String[countdevice];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    i = 0;
    try
    {
      while (rs.next())
      {
        device[i] = rs.getString("DEVICEID");
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    FramePicture f = new FramePicture(numofdevice,name,deviceobjectid,countdevice,device,projectid,themain,db);
    f.pack();
    f.setSize(new Dimension(1024,768));
    f.setVisible(true);

  }

  void Cemen_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedValue().toString();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    int countdevice = 0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    try
    {
      while (rs.next())
      {
        countdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    String[] device = new String[countdevice];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    i = 0;
    try
    {
      while (rs.next())
      {
        device[i] = rs.getString("DEVICEID");
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    FrameCemen f = new FrameCemen(numofdevice,name,deviceobjectid,countdevice,device,projectid,themain,db);
    f.pack();
    f.setVisible(true);
  }

  void Select_actionPerformed(ActionEvent e) {
    String groupid = Grouplist.getSelectedValue().toString();
    //Grouplist.getSelectedItem();
 //   Database db = new Database();
    String monitortype = "";
    String monitorvalue = "";

    ResultSet rs = db.executeSQLquery("SELECT * FROM MONITOR WHERE GROUPID = '" + groupid + "'");
    try
    {
      while (rs.next())
      {
        monitortype = rs.getString("MONITORTYPE");
        monitorvalue = rs.getString("MONITORVALUE");
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }



    if (monitortype.compareTo("text") == 0)
    {
      int numofdevice = 0;

      System.out.println(groupid);
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
      try
      {
        while (rs.next())
        {
          numofdevice = rs.getInt(1);
        }
      }
      catch(SQLException ex)
      {
        System.out.println("aa"  + ex);
      }
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
      String[] name = new String[numofdevice];
      String[][] deviceobjectid= new String[numofdevice][2];
      System.out.println(numofdevice);
      int i=0;
      try
      {
        while (rs.next())
        {
          deviceobjectid[i][0] = rs.getString("DEVICEID");
          deviceobjectid[i][1] = rs.getString("OBJECTID");
          name[i] = deviceobjectid[i][1];
          i++;
        }
      }
      catch(SQLException ex)
      {
        System.out.println(ex);
      }
      FrameText f = new FrameText(numofdevice,name,deviceobjectid,groupid,projectid,themain,db);
      //f.pack();
      f.setSize(new Dimension(800,600));
      f.setVisible(true);
    }
    else if (monitortype.compareTo("table") == 0)
    {
      int numofdevice = 0;

      System.out.println(groupid);
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
      try
      {
        while (rs.next())
        {
          numofdevice = rs.getInt(1);
        }
      }
      catch(SQLException ex)
      {
        System.out.println("aa"  + ex);
      }
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
      String[] name = new String[numofdevice];
      String[][] deviceobjectid= new String[numofdevice][2];
      System.out.println(numofdevice);
      int i=0;
      try
      {
        while (rs.next())
        {
          deviceobjectid[i][0] = rs.getString("DEVICEID");
          deviceobjectid[i][1] = rs.getString("OBJECTID");
          name[i] = deviceobjectid[i][1];
          i++;
        }
      }
      catch(SQLException ex)
      {
        System.out.println(ex);
      }
      FrameTable f = new FrameTable(numofdevice,name,deviceobjectid,groupid,projectid,themain,db);
      //f.pack();
      f.setSize(new Dimension(800,600));
      f.setVisible(true);
    }
    else if (monitortype.compareTo("graph") == 0)
    {
      int numofdevice = 0;
      System.out.println(groupid);
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
      try
      {
        while (rs.next())
        {
          numofdevice = rs.getInt(1);
        }
      }
      catch(SQLException ex)
      {
        System.out.println("aa"  + ex);
      }
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
      /*
      String[] name = new String[numofdevice];
      String[][] deviceobjectid= new String[numofdevice][2];
      System.out.println(numofdevice);
      int i=0;
      try
      {
        while (rs.next())
        {
          deviceobjectid[i][0] = rs.getString("DEVICEID");
          deviceobjectid[i][1] = rs.getString("OBJECTID");
          name[i] = deviceobjectid[i][1];
          i++;
        }
      }
      catch(SQLException ex)
      {
        System.out.println(ex);
      }
      */  String[] name = new String[numofdevice];

    String[][] deviceobjectid= new String[numofdevice][6];
    // 0 deviceid 1 objectid 2 faultonit 3 howtocheck 4 lower/equal 5 upper
    System.out.println(numofdevice);
    for(int q=0;q<numofdevice;q++)
    {
      for(int s=0;s<6;s++)
      {
        deviceobjectid[q][s]="";
      }
    }
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println("bb"+ex);
    }
//--------------------------------------------------------------------------------------
    int k=i;

    rs = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID='"+projectid+"'");
    try{
    while (rs.next())
    {
      String did = rs.getString("DEVICEID");
      String oid = rs.getString("OBJECTID");

      String fv = rs.getString("FAULTVALUE");
      String fv2= rs.getString("FAULTVALUE2");
      String fc = rs.getString("FAULTCHECK");


       for(int j=0;j<k;j++)
                 { System.out.println(did);
       System.out.println(deviceobjectid[j][0]);
             System.out.println(oid);
             System.out.println(deviceobjectid[j][1]);
             System.out.println(fv);
             System.out.println(fv2);
      System.out.println(fc);

         if((deviceobjectid[j][0].compareTo(did)==0)&&(deviceobjectid[j][1].compareTo(oid)==0))
          {
            deviceobjectid[j][2]="yes";
            deviceobjectid[j][3]= fc;
            deviceobjectid[j][4]= fv;
            deviceobjectid[j][5]= fv2;

          }
        else if(deviceobjectid[j][2].compareTo("yes")!=0){

            deviceobjectid[j][2]="no";
            deviceobjectid[j][3]="";
            deviceobjectid[j][4]="";
            deviceobjectid[j][5]="";
          }
          }
    }
          }catch(SQLException exx)
    {System.out.println(exx);}


          JCExitFrame f = new JCExitFrame("Monitor");

      //JCExitFrame f1 = new JCExitFrame("Strip Chart Demo");

      StripChart s = new StripChart(numofdevice,name,deviceobjectid,monitorvalue,projectid,groupid,db);
      s.passframe(f);
      f.getContentPane().add("Center",s);

      f.pack();
      f.setVisible(true);
      //themain.addframe(f);
    }

  }

  public void jMenuClose_actionPerformed(ActionEvent e) {
    this.dispose();

  }

  void Tuning_actionPerformed(ActionEvent e) {
    FrameTuning f = new FrameTuning(projectid,themain,db);
    f.setSize(new Dimension(900,600));
    f.setVisible(true);
  }

  public void Grouplist_valueChanged(ListSelectionEvent e) {

  }

  void Close_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void Refresh_actionPerformed(ActionEvent e) {
    panelpicture.refresh();
  }
}
