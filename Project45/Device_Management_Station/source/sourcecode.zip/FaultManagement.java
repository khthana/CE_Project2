package dms;
import java.awt.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FaultManagement {
  private Database db;
  String pn="",dn="",on="",rf="";
  Date ssdate,eedate;
  Time sstime,eetime;
  boolean sc;

  FaultListener flis;
  String projectname="";

  public FaultManagement(String pn,Database d) {
    projectname=pn;
    db = d;
    flis= new FaultListener(pn,rf,sc,ssdate,sstime,eedate,eetime,db);
  }

  public void enablefaultlistener(String refresh,boolean ac,Date sdate,Time stime,Date edate,Time etime)
  {
    if(flis.isAlive()==false)
    {
    FaultListener fl = new FaultListener(projectname,refresh,ac,sdate,stime,edate,etime,db);

    flis=fl;
    flis.start();
    }
  }

  public void disablefaultlistener()
  {
    flis.flag=false;
  }
}