package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditProject3 extends JPanel {
  private JComboBox Selectproject = new JComboBox();
  private JList Userlist = new JList();
  private DefaultListModel userlistmodel;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JList Userinproject = new JList();
  private DefaultListModel userinprojectmodel;
  private JButton Add = new JButton();
  private JButton Remove = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private String[] userinproject;
  private int count=0;
  private Database db;
  public EditProject3(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    jLabel3.setText("SELECT PROJECT");
    jLabel3.setBounds(new Rectangle(59, 23, 116, 25));
    jLabel2.setText("USER WORK FOR THIS PROJECT");
    jLabel2.setBounds(new Rectangle(508, 74, 194, 25));
    jLabel1.setText("USER LIST");
    jLabel1.setBounds(new Rectangle(60, 70, 141, 30));
    this.setLayout(null);
    Selectproject.setBounds(new Rectangle(201, 27, 243, 29));
    Selectproject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectproject_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(60, 114, 277, 345));
    jScrollPane2.setBounds(new Rectangle(511, 114, 277, 345));
    Add.setBounds(new Rectangle(376, 232, 85, 28));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Remove.setBounds(new Rectangle(376, 280, 85, 28));
    Remove.setText("REMOVE");
    Remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Remove_actionPerformed(e);
      }
    });
    Ok.setBounds(new Rectangle(560, 495, 103, 31));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(687, 495, 103, 31));
    Cancel.setText("CANCEL");
    this.add(Selectproject, null);
    this.add(jScrollPane1, null);

    this.add(jLabel1, null);
    this.add(jLabel3, null);

    this.add(jScrollPane2, null);
    this.add(Add, null);
    this.add(Remove, null);
    this.add(jLabel2, null);
    this.add(Cancel, null);
    this.add(Ok, null);

    userlistmodel = new DefaultListModel();
    userinprojectmodel = new DefaultListModel();
    userlistmodel.removeAllElements();
    userinprojectmodel.removeAllElements();
    //Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT");
      while (rs.next())
      {
        Selectproject.addItem(rs.getString("PROJECTID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject3 : " + sql);
    }

    userlistmodel.removeAllElements();
    userinprojectmodel.removeAllElements();
    try
    {
      ResultSet rs;

      rs = db.executeSQLquery("SELECT * FROM USERTABLE WHERE USERID NOT IN (SELECT USERID FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "') AND USERTYPE = 'user'");
      //rs.first();
      while(rs.next())
      {
        userlistmodel.addElement(rs.getString("USERID"));
        //System.out.println(rs.getString("USERID"));

      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }


    try
    {
      ResultSet rs;
      rs = db.executeSQLquery("SELECT COUNT(*) FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");

      while(rs.next())
      {
        count = rs.getInt(1);

      }
      userinproject = new String[count];
      rs = db.executeSQLquery("SELECT * FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      count = 0;
      while(rs.next())
      {
        userinprojectmodel.addElement(rs.getString("USERID"));
        userinproject[count] = rs.getString("USERID");
        count++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }

    Userlist = new JList(userlistmodel);
    Userlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Userlist.setSelectedIndex(0);

    Userinproject = new JList(userinprojectmodel);
    Userinproject.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Userinproject.setSelectedIndex(0);

    jScrollPane1.getViewport().add(Userlist, null);
    jScrollPane2.getViewport().add(Userinproject, null);
  }

  void Add_actionPerformed(ActionEvent e) {
    if (Userlist.getSelectedIndex() != -1)
    {
      if (userinprojectmodel.indexOf(Userlist.getSelectedValue()) == -1)
      {
        userinprojectmodel.addElement(Userlist.getSelectedValue());
        userlistmodel.removeElement(Userlist.getSelectedValue());
      }
    }

  }

  void Remove_actionPerformed(ActionEvent e) {
    if (Userinproject.getSelectedIndex() != -1)
    {
      if (userlistmodel.indexOf(Userinproject.getSelectedValue()) == -1)
      {
        userlistmodel.addElement(Userinproject.getSelectedValue());
        userinprojectmodel.removeElement(Userinproject.getSelectedValue());
      }
    }
  }

  void Selectproject_actionPerformed(ActionEvent e) {

    userlistmodel.removeAllElements();
    userinprojectmodel.removeAllElements();
    //Database db = new Database();
    try
    {
      ResultSet rs;

      rs = db.executeSQLquery("SELECT * FROM USERTABLE WHERE USERID NOT IN (SELECT USERID FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "') AND USERTYPE = 'user'");
      //rs.first();
      while(rs.next())
      {
        userlistmodel.addElement(rs.getString("USERID"));


      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }
    try
    {
      ResultSet rs;
      rs = db.executeSQLquery("SELECT COUNT(*) FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");

      while(rs.next())
      {
        count = rs.getInt(1);

      }
      userinproject = new String[count];

      rs = db.executeSQLquery("SELECT * FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      count = 0;
      while(rs.next())
      {
        userinprojectmodel.addElement(rs.getString("USERID"));
        userinproject[count] = rs.getString("USERID");
        count++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }
  }

  void Ok_actionPerformed(ActionEvent e) {
   // Database db = new Database();

    String[] delete = checkdelete();


    String[] add = checkadd();
    for(int i=0;i<delete.length;i++)
    {
      System.out.println("DELETE FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "' AND USERID = '" + delete[i] + "'");
      //db.executeSQLupdate("DELETE FROM PROJECTDEVICE WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "' AND DEVICEID = '" + delete[i].substring(0,delete[i].indexOf(" , ")) + "' AND OBJECTID = '" + delete[i].substring(delete[i].indexOf(" , ")+3) + "'");
      db.executeSQLupdate("DELETE FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "' AND USERID = '" + delete[i] + "'");
    }
    for(int i=0;i<add.length;i++)
    {
      System.out.println("add[i] : " + add[i]);
      System.out.println("INSERT INTO PROJECTUSER (USERID,PROJECTID) VALUES('" + add[i] + "' , '" +Selectproject.getSelectedItem() + "')");
      //db.executeSQLupdate("INSERT INTO PROJECTDEVICE (PROJECTID,DEVICEID,OBJECTID) VALUES('" + Selectproject.getSelectedItem() + "' , '" + add[i].substring(0,add[i].indexOf(" , ")) + "' , '" + add[i].substring(add[i].indexOf(" , ")+3) + "')");
      db.executeSQLupdate("INSERT INTO PROJECTUSER (USERID,PROJECTID) VALUES('" + add[i] + "' , '" +Selectproject.getSelectedItem() + "')");
    }


    userlistmodel.removeAllElements();
    userinprojectmodel.removeAllElements();


    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT");
      while (rs.next())
      {
        Selectproject.addItem(rs.getString("PROJECTID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject3 : " + sql);
    }

    userlistmodel.removeAllElements();
    userinprojectmodel.removeAllElements();
    try
    {
      ResultSet rs;

      rs = db.executeSQLquery("SELECT * FROM USERTABLE WHERE USERID NOT IN (SELECT USERID FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "') AND USERTYPE = 'user'");
      //rs.first();
      while(rs.next())
      {
        userlistmodel.addElement(rs.getString("USERID"));
        //System.out.println(rs.getString("USERID"));

      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }


    try
    {
      ResultSet rs;
      rs = db.executeSQLquery("SELECT COUNT(*) FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");

      while(rs.next())
      {
        count = rs.getInt(1);

      }
      userinproject = new String[count];
      rs = db.executeSQLquery("SELECT * FROM PROJECTUSER WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      count = 0;
      while(rs.next())
      {
        userinprojectmodel.addElement(rs.getString("USERID"));
        userinproject[count] = rs.getString("USERID");
        count++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }

  }

  String[] checkdelete()
  {
    String[] str;
    int count=0;
    for (int i = 0;i<userinproject.length ;i++)
    {
      if (userinprojectmodel.indexOf(userinproject[i]) == -1)
      {
      count++;
    }
    }
    str = new String[count];
    count = 0;
    for (int i = 0;i<userinproject.length ;i++)
    {
      if (userinprojectmodel.indexOf(userinproject[i]) == -1)
      {
      str[count] = userinproject[i];
      count++;
    }
    }
    return str;
  }

  String[] checkadd()
  {
    String[] str;
    int count=0;
    boolean flag = true;
    System.out.println("listModel.getSize : " + userinprojectmodel.getSize());
    System.out.println("deviceobject.length : " + userinproject.length);
    for (int i = 0;i<userinprojectmodel.getSize();i++)
    {
      for (int j = 0;j<userinproject.length;j++)
      {
        System.out.println("i : " + userinprojectmodel.get(i).toString() + " j : " + userinproject[j]);
        if (userinproject[j].compareTo(userinprojectmodel.get(i).toString()) == 0)
        {
          flag = false;
        }
      }
      if (flag == true)
      {
        count++;
      }
      flag = true;
    }

    str = new String[count];
    count = 0;
    flag = true;
    for (int i = 0;i<userinprojectmodel.getSize();i++)
    {
      for (int j = 0;j<userinproject.length;j++)
      {
        if (userinproject[j].compareTo(userinprojectmodel.get(i).toString()) == 0)
        {
          flag = false;
        }
      }
      if (flag == true)
      {
        str[count] = userinprojectmodel.getElementAt(i).toString();
        count++;
      }
      flag = true;
    }
    return str;
  }
}