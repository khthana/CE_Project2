package dms;

import java.awt.*;
import javax.swing.*;
import com.borland.dbswing.*;
import com.borland.dx.sql.dataset.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Deviceconfig1 extends JPanel {
  JTextField Devicename = new JTextField();
  JLabel jLabel1 = new JLabel();
  JTextField Deviceip = new JTextField();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JTextField Deviceid = new JTextField();
  JComboBox Deviceprotocol = new JComboBox();

  public Deviceconfig1() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setSize(new Dimension(1000,700));
    Deviceprotocol.addItem("SNMP");
    Deviceprotocol.addItem("SOAP");

    Devicename.setBounds(new Rectangle(176, 109, 315, 28));
    this.setLayout(null);
    jLabel1.setText("DEVICE NAME :");
    jLabel1.setBounds(new Rectangle(53, 113, 90, 26));
    Deviceip.setBounds(new Rectangle(176, 164, 315, 28));
    jLabel2.setText("IP ADRESS :");
    jLabel2.setBounds(new Rectangle(57, 168, 87, 24));
    jLabel3.setText("PROTOCOL :");
    jLabel3.setBounds(new Rectangle(55, 215, 83, 25));
    jLabel4.setText("DEVICE ID :");
    jLabel4.setBounds(new Rectangle(55, 56, 105, 29));
    Deviceid.setBounds(new Rectangle(176, 55, 315, 28));
    Deviceprotocol.setBounds(new Rectangle(176, 214, 315, 27));
    this.add(Deviceid, null);
    this.add(jLabel4, null);
    this.add(jLabel1, null);
    this.add(Devicename, null);
    this.add(jLabel2, null);
    this.add(Deviceip, null);
    this.add(jLabel3, null);
    this.add(Deviceprotocol, null);
  }

}