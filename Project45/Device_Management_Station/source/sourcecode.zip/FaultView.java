package dms;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FaultView extends JFrame {
  private JTextArea View = new JTextArea();
  private Border border1;
  private JButton Clear = new JButton();
  private JButton Close = new JButton();
  private String[][] fault;
  private Config4 c4;
  private int countfault;
  private String view="";
  private JScrollPane jScrollPane1 = new JScrollPane();
  public FaultView(Config4 con,String[][] f,int c) {
    try {
      countfault = c;
      c4 = con;
      fault = f;
      for(int i = 0;i<countfault;i++)
      {
        view = "FAULTID : " + fault[0][i] + " , FAULTNAME : " + fault[1][i] + " , DEVICEID : " + fault[2][i] + " , OBJECTID : " + fault[3][i] + " , FAULTTYPE : " + fault[4][i] + " , VAULE1 : " + fault[5][i] + " , VAULE2 : " + fault[6][i] + "\n";
        View.append(view);
      }
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    border1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178)),"FAULT DETAIL");
    View.setBorder(border1);
    this.getContentPane().setLayout(null);
    Clear.setBounds(new Rectangle(322, 411, 104, 32));
    Clear.setText("CLEAR");
    Clear.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Clear_actionPerformed(e);
      }
    });
    Close.setBounds(new Rectangle(446, 408, 103, 31));
    Close.setText("CLOSE");
    Close.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Close_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(77, 41, 649, 330));
    this.getContentPane().add(Clear, null);
    this.getContentPane().add(Close, null);
    this.getContentPane().add(jScrollPane1, null);
    jScrollPane1.getViewport().add(View, null);
  }

  void Close_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void Clear_actionPerformed(ActionEvent e) {
    fault = new String[7][100];
    countfault = 0;
    c4.SetFault(fault,countfault);
    View.setText("");
  }


}