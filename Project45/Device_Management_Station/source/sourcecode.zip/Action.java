package dms;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Action extends Thread {
  private String actionid;
  Database db;
  public Action(String aid,Database d) {
    actionid = aid;
    db = d;
  }
  public void run()
  {
     ResultSet rs = db.executeSQLquery("SELECT * FROM ACTION WHERE ACTIONID='"+actionid+"'");
     try{
       while(rs.next())
       {

       }
     }catch (SQLException sql)
     {
       System.out.println("Error connecting Database");
     }
  }
  /*public static void main(String[] args) {
    Action action1 = new Action();
  }*/
}