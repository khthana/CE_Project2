package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Config6 extends JPanel {
  private Database db;
  List Userlist = new List();
  List Userselect = new List();
  private JButton Add = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JButton Remove = new JButton();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JScrollPane jScrollPane2 = new JScrollPane();

  public Config6(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setSize(new Dimension(1000,700));
    int i=0;

    String[] temp = new String[100];
    try
    {
      ResultSet rs;

      rs = db.executeSQLquery("SELECT * FROM USERTABLE WHERE USERTYPE = 'user'");
      //rs.first();
      while(rs.next())
      {
        temp[i] = rs.getString("USERID");
        //Servicetype.addItem(temp);
        //System.out.println(temp[i]);
        i++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }
    int j = 0;
    while (j<i)
    {
      Userlist.add(temp[j]);
      j++;
    }

    this.setLayout(null);
    Add.setBounds(new Rectangle(394, 271, 98, 31));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    jLabel1.setText("CHOOSE USER");
    jLabel1.setBounds(new Rectangle(316, 12, 174, 31));
    Remove.setBounds(new Rectangle(394, 323, 98, 31));
    Remove.setText("REMOVE");
    Remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Remove_actionPerformed(e);
      }
    });
    jLabel2.setText("USER LIST");
    jLabel2.setBounds(new Rectangle(33, 65, 147, 28));
    jLabel3.setText("CHOOSED USER FOR MANAGE THIS PROJECT");
    jLabel3.setBounds(new Rectangle(561, 60, 285, 31));
    jScrollPane1.setBounds(new Rectangle(33, 101, 308, 444));
    jScrollPane2.setBounds(new Rectangle(561, 99, 308, 444));
    this.add(Add, null);
    this.add(Remove, null);
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    this.add(jLabel3, null);
    this.add(jScrollPane1, null);
    this.add(jScrollPane2, null);
    jScrollPane2.getViewport().add(Userselect, null);
    jScrollPane1.getViewport().add(Userlist, null);
  }

  void Add_actionPerformed(ActionEvent e) {
    if (Userlist.getSelectedIndex() != -1)
    {
      Userselect.add(Userlist.getSelectedItem());
      Userlist.remove(Userlist.getSelectedItem());
    }

  }

  void Remove_actionPerformed(ActionEvent e) {
    if (Userselect.getSelectedIndex() != -1)
    {
      Userlist.add(Userselect.getSelectedItem());
      Userselect.remove(Userselect.getSelectedItem());
    }
  }

  public boolean checkallblank(){

    if (Userselect.getItemCount() != 0)
    {
      return true;
    }
    else
    {
      return false;
    }
  }
}