package dms;

import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.text.PlainDocument;
import com.klg.jclass.chart.JCChart;
import com.klg.jclass.chart.ChartDataView;
import com.klg.jclass.chart.data.JCFileDataSource;
import com.klg.jclass.chart.JCAxis;
import com.klg.jclass.chart.ChartDataEvent;
import com.klg.jclass.util.swing.JCExitFrame;
import com.klg.jclass.chart.data.JCDefaultDataSource;
import com.klg.jclass.chart.beans.*;


/**
 * Example of an updating chart that uses RESET
 * events from a data source to show the data
 * updates.  Compare this example to the
 * Repainter example,
 * which uses repaint() to show the data updates.
 */
public class FrameGraph extends JFrame implements Runnable{
private Database db;
private int num;
private String[] name;
private String[][] deviceobjectid;
private String charttype;

/**
 * Chart instance
 */
protected JCChart chart = null;

/**
 * Creates the Resetter example, which consists
 * of a JCChart instance and an updating data source
 * running in a separate thread.
 */
public FrameGraph(int num,String[] name,String[][] deviceobjectid,String charttype,Database d) {
  db = d;
  this.num = num;
    this.name = name;
    this.deviceobjectid = deviceobjectid;
  this.charttype = charttype;
  // Create new chart instance.
    JCChart chart= new JCChart();
    if (charttype.compareTo("plot") == 0)
    {
      chart = new JCChart(JCChart.PLOT);
    }
    else if (charttype.compareTo("pie") == 0)
    {
      chart = new JCChart(JCChart.PIE);
    }
    else if (charttype.compareTo("bar") == 0)
    {
      chart = new JCChart(JCChart.BAR);
    }



    // Create and attach resetting chart data source
    ResettingDataSource uds = new ResettingDataSource(chart,num,name,deviceobjectid,db);
    chart.getDataView(0).setDataSource(uds);

    // Make header visible, and add some text
    chart.getHeader().setVisible(true);

    // By default, header is a JLabel - set its Text property
    ((JLabel)chart.getHeader()).setText("Resetting Chart");

    // Make legend visible
    chart.getLegend().setVisible(true);

    // Make x axis use point labels instead of default value labels.
    chart.getChartArea().getXAxis(0).setAnnotationMethod(JCAxis.POINT_LABELS);




    // Add the chart to the panel
    this.getContentPane().add(chart);

    // Start up a separate updating thread.
    Thread t = new Thread(uds);

    t.start();
    //setLayout(new GridLayout(1,1));
    //setPreferredSize(new Dimension(400, 200));



}

/*public static void main(String args[]) {
    JCExitFrame f = new JCExitFrame("Resetter");
    f.getContentPane().setLayout(new GridLayout(1,1));
    String[] name = new String[3];
    name[0] = "aaa";
    name[1] = "bbb";
    name[2] = "ccc";
    String[][] deviceobjectid = new String[3][2];
    deviceobjectid[0][0] = "DEVICE1";
    deviceobjectid[0][1] = "INROUTER1";
    deviceobjectid[1][0] = "DEVICE1";
    deviceobjectid[1][1] = "INROUTER2";
    deviceobjectid[2][0] = "DEVICE2";
    deviceobjectid[2][1] = "INROUTER3";
    FrameGraph u = new FrameGraph(3,name,deviceobjectid,"pie");
    f.getContentPane().add(u);
    f.pack();
    f.setVisible(true);

}*/


  public FrameGraph() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void run()
  {


  }
  private void jbInit() throws Exception {

    this.getContentPane().setLayout(new GridLayout(1,1));


  }
}