package dms;

import java.util.Vector;
import java.util.Random;
import javax.swing.*;
import com.klg.jclass.chart.JCChart;
import com.klg.jclass.chart.JCAxis;
import com.klg.jclass.chart.ChartDataViewSeries;
import com.klg.jclass.chart.data.JCDefaultDataSource;
import com.klg.jclass.chart.ChartDataEvent;

/**
 * StripChartSource is a Chart Data Source that contains an updating thread
 * that constantly updates the values in it's x and y arrays.  Updates
 * depend on 4 numeric values (updatesPerSecond, scrollBack, pointsPerUpdate,
 * and numberOfPoints) that are set by the calling applet and can change
 * at any time.  When an array is filled, it is scrolled back the specified
 * amount and the early data in it is lost.
 */
class StripChartSource2 extends JCDefaultDataSource implements Runnable {
// Variable for performance
String[][] deviceobjectid;
private Database db;
MessageHandler m;
int num;
// properties set by user via control panel
protected int updatesPerSecond = 1;
protected int scrollBack = 10;
protected int pointsPerUpdate = 10;
protected int numberOfPoints = 100;

// labels to be updated by stats
protected JLabel totalPointsLabel;
protected JLabel pointsPerSecondLabel;

// marks current place in generating points
protected int currentMax = numberOfPoints;
protected int currentLastPoint = 0;

// marks current position in value arrays
protected int currentLastIndex = 0;

private boolean paused = false;
private boolean valUpdated = false;

private Thread kicker = null;
protected boolean dead = false;
protected long startTime = 0;
private String[] pointLabels = null;
protected JCChart chart;
protected  String[] lbls = {
        "Random"
};

/**
 * Re-Start the updating thread if one hasn't already been started.
 * Don't use this to start the thread the first time through.  Use
 * startDataSource() instead.
 */
public synchronized void start() {
        if (!dead)
                return;
        dead = false;
        if (kicker == null) {
                kicker = new Thread(this);
                kicker.start();
        }
}

/**
 * Stop the updating thread.
 */
public synchronized void stop() {
        dead = true;
}

/**
 * Reset the data source.  Create the x and y value arrays, fill them with
 * bogus values, and set the axis min and max according to the number of
 * points we're using.
 */
private void reset() {
        xvalues = new double[1][numberOfPoints];
        yvalues = new double[num][numberOfPoints];
        pointLabels = new String[numberOfPoints];
        seriesLabels = lbls;
        currentMax = numberOfPoints;
        currentLastPoint = -1;
        currentLastIndex = -1;
        for(int i = 0; i < numberOfPoints; i++) {
                xvalues[0][i] = i;
                yvalues[0][i] = Double.MAX_VALUE;
        }
        chart.setBatched(true);
        JCAxis xaxis = chart.getDataView(0).getXAxis();
        xaxis.setMin(0.0);
        xaxis.setMax(currentMax);
        xaxis.setNumSpacing(numberOfPoints/10);
        chart.setBatched(false);
        startTime = System.currentTimeMillis();
}

/**
 * Pause or unpause the updating thread, depending on the value of b.
 */
public synchronized void pause(boolean b) {
        paused = b;
        if (!b) {
                notify();
        }
}

/**
 * Pause the updating thread.
 */
public void pause() {
        pause(true);
}

/**
 * Unpause the updating thread.
 */
public void unpause() {
        pause(false);
}

/**
 * Note that one of the numeric paramters of the data source has been
 * updated so that it will be noted at the correct spot in the thread
 * updating loop.
 */
public void markValUpdate(boolean b)
{
        valUpdated = b;
}

/**
 * Constructor.
 * @param c the chart this data source is a part of.
 */
public StripChartSource2(JCChart c,int num,String[] name,String[][] deviceobjectid,Database d) {

        super(null, null, null, name, "Strip Chart");
        db = d;
        m = new MessageHandler(db);
        lbls = name;
        chart = c;
        this.deviceobjectid = deviceobjectid;
        this.num = num;
        reset();

}

/**
 * Set the labels to update when we have our performance stats.
 * @param tplabel the label that shows total points
 * @param ppslabel the label that shows the number of points per second
 */
public void setLabelsToUpdate(JLabel tplabel, JLabel ppslabel) {
        totalPointsLabel = tplabel;
        pointsPerSecondLabel = ppslabel;
}

/**
 * Start the data source updating thread.
 */
public void startDataSource() {
        startTime = System.currentTimeMillis();
        dead = false;
        kicker = new Thread(this);
        kicker.start();
}

/**
 * The updating thread.
 */
public void run() {
        if(Thread.currentThread() != kicker) {
                throw new RuntimeException("Can't call run from there!");
        }
        int thisUpdatesPerSecond = updatesPerSecond;
        int thisScrollBack = scrollBack;
        int thisPointsPerUpdate = pointsPerUpdate;
        int thisNumberOfPoints = numberOfPoints;
        int delay = (int) (100 / thisUpdatesPerSecond);
        int scrollBackPoints = (int)
                ((double)scrollBack / 100.0 * (double) thisNumberOfPoints);

        Random rand = new Random(startTime);

        while (!dead) {

                try {
                        // number will depend on updates per second
                        Thread.sleep(delay);
                        synchronized(this) {
                                while(paused)
                                        wait();
                        }
                }
                catch(InterruptedException ie) {
                        // this should never happen...
                }

                if (dead)
                        break;

                // if any of the numeric values have been updated, deal with
                // that now
                if (valUpdated) {
                        if (thisUpdatesPerSecond != updatesPerSecond) {
                                thisUpdatesPerSecond = updatesPerSecond;
                                delay = (int) (100 / thisUpdatesPerSecond);
                        }
                        if (thisNumberOfPoints != numberOfPoints) {
                                thisNumberOfPoints = numberOfPoints;
                                reset();
                        }
                        if (thisScrollBack != scrollBack) {
                                thisScrollBack = scrollBack;
                                scrollBackPoints = (int)
                                        ((double)thisScrollBack / 100 * (double) thisNumberOfPoints);
                        }
                        if (thisPointsPerUpdate != pointsPerUpdate) {
                                thisPointsPerUpdate = pointsPerUpdate;
                        }
                        valUpdated = false;
                }

                // generate new points!
                synchronized(this) {

                        double Hold = rand.nextGaussian() + 1;

                        int expectedLastIndex = currentLastIndex + thisPointsPerUpdate;

                        addNewPoints(Hold, expectedLastIndex, thisNumberOfPoints);

                        boolean scrolled = false;
                        while (expectedLastIndex >= thisNumberOfPoints) {
                                scrolled = true;
                                System.arraycopy(xvalues[0], scrollBackPoints, xvalues[0], 0,
                                        thisNumberOfPoints - scrollBackPoints);
                                System.arraycopy(yvalues[0], scrollBackPoints, yvalues[0], 0,
                                        thisNumberOfPoints - scrollBackPoints);
                                currentMax += scrollBackPoints;
                                currentLastIndex -= scrollBackPoints;
                                expectedLastIndex -= scrollBackPoints;
                                addNewPoints(Hold, expectedLastIndex, thisNumberOfPoints);
                                int nextXVal = currentLastPoint + 1;
                                for (int i = currentLastIndex + 1; i < thisNumberOfPoints; i++){
                                        xvalues[0][i] = nextXVal;
                                        nextXVal++;
                                        yvalues[0][i] = Double.MAX_VALUE;
                                }
                        }

                        if (scrolled) {
                                if (chart != null) {
                                        chart.setBatched(true);
                                        JCAxis xaxis = chart.getDataView(0).getXAxis();
                                        xaxis.setMin(currentMax - thisNumberOfPoints);
                                        xaxis.setMax(currentMax);
                                        chart.setBatched(false);
                                }
                        }

                        long curTime = System.currentTimeMillis();

                        totalPointsLabel.setText("" + (currentLastPoint + 1));
                        pointsPerSecondLabel.setText("" + (int) (
                                ((double) (currentLastPoint + 1)) /
                                ((curTime - startTime) / 1000.0) ));

                        fireChartDataEvent(ChartDataEvent.RESET, 0, 0);

                }

        }
        kicker = null;
}

/**
 * Add new points to the x and y arrays.
 * @param Hold randomly generated value used by y val calculations.
 * @param expectedLastIndex the last index of the arrays that we're
 *                          expected to fill up to.
 * @param thisNumberOfPoints the maximum number of points in each array.
 */
protected void addNewPoints(double Hold, int expectedLastIndex,
                                                                                        int thisNumberOfPoints)
{
        for (int i = currentLastIndex + 1;
                        i < thisNumberOfPoints && i <= expectedLastIndex; i++) {
                currentLastPoint++;
                xvalues[0][i] =  currentLastPoint;
                for (int j=0;j<num;j++)
                {

                  m.constructMessage(deviceobjectid[j][0],deviceobjectid[j][1],"GET","","","");
                  m.sendMessage();
                  try
                  {
                        Thread.currentThread().sleep(550);
                  }
                  catch (Exception e)
                  {

                  }
                  String logdata = m.recieveMessage();
                  if (logdata.compareTo("*") == 0)
                  {
                    yvalues[j][i] = 0;
                  }
                  else
                  {
                    yvalues[j][i] = Double.parseDouble(logdata);
                  }
                  //yvalues[j][i] = Double.parseDouble(m.recieveMessage());

                }
                /*yvalues[0][i] = 3.0 * Math.sin(2.0 * (Math.PI / 180.0) *
                        (double)(currentLastPoint)) * Math.sin(6.0 * Hold *
                        (double)(currentLastPoint)) * Hold;
                yvalues[1][i] = 1;
                yvalues[2][i] = 2;*/
                currentLastIndex++;
        }
}

}
