package dms;

import java.awt.*;
import javax.swing.*;
//import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Planandsupport extends JPanel {
  private JLabel jLabel1 = new JLabel();
  private JButton jButton1 = new JButton();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton3 = new JRadioButton();
  private JPanel jPanel1 = new JPanel();
  private JPanel jPanel2 = new JPanel();
  private TitledBorder titledBorder1;
  private ButtonGroup g1 = new ButtonGroup();
  private ButtonGroup g2 = new ButtonGroup();
  private ButtonGroup g3 = new ButtonGroup();
  private JRadioButton jRadioButton4 = new JRadioButton();
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JTextField jTextField3 = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JRadioButton jRadioButton5 = new JRadioButton();
  private JRadioButton jRadioButton6 = new JRadioButton();
  private JTextField jTextField4 = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JTextField jTextField5 = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JTextField jTextField6 = new JTextField();
  private JTextField jTextField7 = new JTextField();
  private JTextField jTextField8 = new JTextField();
  private JLabel jLabel6 = new JLabel();
  private JTextField jTextField9 = new JTextField();
  private JTextField jTextField10 = new JTextField();
  private JTextField jTextField11 = new JTextField();
  private String projectid;

  private Database db;
  private ScrollPane scrollPane1 = new ScrollPane();
  private List Grouplist = new List();
  private JTextField jTextField12 = new JTextField();
  private JTextField jTextField14 = new JTextField();
  private JLabel jLabel7 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JButton jButton2 = new JButton();
  private JPanel jPanel3 = new JPanel();
  private JLabel jLabel9 = new JLabel();
  private JRadioButton jRadioButton7 = new JRadioButton();
  private JRadioButton jRadioButton8 = new JRadioButton();
  private JTextField jTextField13 = new JTextField();
  private JTextField jTextField15 = new JTextField();
  private JTextField jTextField16 = new JTextField();
  private JLabel jLabel10 = new JLabel();
  private JButton jButton3 = new JButton();
  public Planandsupport(String pid,Database d) {
    db = d;
    projectid = pid;
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    ResultSet rs = db.executeSQLquery("SELECT GROUPID FROM SUPPORTGROUP WHERE PROJECTID='"+projectid+"'");
   //-----------------------Edit Muen---
   while(rs.next())
   {
     Grouplist.add(rs.getString("GROUPID"));
    }
    titledBorder1 = new TitledBorder("");
    jLabel1.setText("Planning and Support");
    jLabel1.setBounds(new Rectangle(138, 2, 119, 17));
    this.setLayout(null);
    jButton1.setBounds(new Rectangle(199, 259, 105, 27));
    jButton1.setText("SELECT");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jRadioButton1.setText("line graph");
    jRadioButton3.setText("table");
    scrollPane1.setBounds(new Rectangle(13, 17, 112, 121));
    jTextField12.setBounds(new Rectangle(100, 60, 17, 21));
    jTextField14.setBounds(new Rectangle(175, 59, 17, 21));
    jLabel7.setText(":");
    jLabel7.setBounds(new Rectangle(91, 60, 10, 21));
    jLabel8.setBounds(new Rectangle(168, 58, 10, 21));
    jLabel8.setText(":");
    jButton2.setBounds(new Rectangle(131, 99, 75, 27));
    jButton2.setText("CLEAR");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setBounds(new Rectangle(15, 292, 375, 139));
    jPanel3.setLayout(null);
    jLabel9.setText("Select the group that you want to delete log");
    jLabel9.setBounds(new Rectangle(12, 8, 263, 21));
    jRadioButton7.setText("All log");
    jRadioButton7.setBounds(new Rectangle(13, 31, 103, 25));
    jRadioButton8.setText("only on this date");
    jRadioButton8.setBounds(new Rectangle(12, 61, 125, 25));
    jTextField13.setBounds(new Rectangle(152, 61, 22, 22));
    jTextField15.setBounds(new Rectangle(181, 61, 26, 22));
    jTextField16.setBounds(new Rectangle(215, 61, 39, 22));
    jLabel10.setText("Data logging");
    jLabel10.setBounds(new Rectangle(19, 450, 130, 29));
    jButton3.setBounds(new Rectangle(140, 454, 112, 33));
    jButton3.setText("OPEN");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    g2.add(jRadioButton1);
    g2.add(jRadioButton3);
    g3.add(jRadioButton7);
    g3.add(jRadioButton8);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBounds(new Rectangle(18, 146, 104, 105));
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setBounds(new Rectangle(134, 25, 246, 225));
    jPanel2.setLayout(null);
    this.setBorder(BorderFactory.createRaisedBevelBorder());
    jRadioButton4.setText("Select interval time");
    jRadioButton4.setBounds(new Rectangle(5, 8, 150, 25));
    jTextField1.setBorder(BorderFactory.createEtchedBorder());
    jTextField1.setBounds(new Rectangle(75, 31, 29, 22));
    jTextField2.setBorder(BorderFactory.createEtchedBorder());
    jTextField2.setBounds(new Rectangle(113, 31, 29, 21));
    jTextField3.setBorder(BorderFactory.createEtchedBorder());
    jTextField3.setBounds(new Rectangle(150, 31, 42, 21));
    jLabel2.setText("Date");
    jLabel2.setBounds(new Rectangle(6, 30, 64, 23));
    jRadioButton5.setText("All ");
    jRadioButton5.setBounds(new Rectangle(6, 183, 103, 25));
    jRadioButton6.setText("Select interval day");
    jRadioButton6.setBounds(new Rectangle(10, 85, 126, 25));
    g1.add(jRadioButton4);
    g1.add(jRadioButton5);
    g1.add(jRadioButton6);
    jTextField4.setBounds(new Rectangle(74, 60, 17, 21));
    jLabel3.setText("Time begin");
    jLabel3.setBounds(new Rectangle(6, 60, 64, 21));
    jLabel4.setText("to");
    jLabel4.setBounds(new Rectangle(130, 60, 23, 20));
    jTextField5.setBounds(new Rectangle(151, 59, 17, 21));
    jLabel5.setBounds(new Rectangle(2, 110, 64, 23));
    jLabel5.setText("Date begin");
    jTextField6.setBounds(new Rectangle(75, 112, 29, 22));
    jTextField6.setBorder(BorderFactory.createEtchedBorder());
    jTextField7.setBounds(new Rectangle(114, 112, 29, 22));
    jTextField7.setBorder(BorderFactory.createEtchedBorder());
    jTextField8.setBounds(new Rectangle(150, 112, 42, 21));
    jTextField8.setBorder(BorderFactory.createEtchedBorder());
    jLabel6.setText("to");
    jLabel6.setBounds(new Rectangle(111, 136, 25, 20));
    jTextField9.setBorder(BorderFactory.createEtchedBorder());
    jTextField9.setBounds(new Rectangle(76, 159, 29, 22));
    jTextField10.setBorder(BorderFactory.createEtchedBorder());
    jTextField10.setBounds(new Rectangle(113, 159, 29, 22));
    jTextField11.setBorder(BorderFactory.createEtchedBorder());
    jTextField11.setBounds(new Rectangle(150, 159, 42, 21));
    this.add(jLabel1, null);
    this.add(jButton1, null);
    this.add(jPanel1, null);
    jPanel1.add(jRadioButton1, null);
    jPanel1.add(jRadioButton3, null);
    this.add(jPanel2, null);
    jPanel2.add(jTextField1, null);
    jPanel2.add(jTextField2, null);
    jPanel2.add(jTextField3, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(jRadioButton5, null);
    jPanel2.add(jRadioButton6, null);
    jPanel2.add(jTextField4, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(jLabel4, null);
    jPanel2.add(jTextField5, null);
    jPanel2.add(jLabel5, null);
    jPanel2.add(jTextField7, null);
    jPanel2.add(jTextField8, null);
    jPanel2.add(jLabel6, null);
    jPanel2.add(jTextField6, null);
    jPanel2.add(jTextField9, null);
    jPanel2.add(jTextField10, null);
    jPanel2.add(jTextField11, null);
    jPanel2.add(jRadioButton4, null);
    jPanel2.add(jTextField12, null);
    jPanel2.add(jTextField14, null);
    jPanel2.add(jLabel7, null);
    jPanel2.add(jLabel8, null);
    this.add(scrollPane1, null);
    this.add(jPanel3, null);
    jPanel3.add(jLabel9, null);
    jPanel3.add(jButton2, null);
    jPanel3.add(jRadioButton7, null);
    jPanel3.add(jRadioButton8, null);
    jPanel3.add(jTextField13, null);
    jPanel3.add(jTextField15, null);
    jPanel3.add(jTextField16, null);
    this.add(jLabel10, null);
    this.add(jButton3, null);
    scrollPane1.add(Grouplist, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
     if(jRadioButton1.isSelected())
     {
       System.out.println("Line graph");
       String groupid = Grouplist.getSelectedItem();

       if(jRadioButton5.isSelected())
       {

         int rowcount=0;
        ResultSet rs = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
         // ResultSet rs = db.executeSQLquery("SELECT * FROM DMSTEMP");
          int numcolumn=0;

          try{
            ResultSetMetaData rsmd = rs.getMetaData();
            numcolumn = rsmd.getColumnCount();
           while(rs.next())
           {
             rowcount++;
           }
         }catch(SQLException ee)
         {}
        String[][] serievalue;
        serievalue = new String[numcolumn][rowcount];
        ResultSet rs2 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
        //ResultSet rs2 = db.executeSQLquery("SELECT * FROM DMSTEMP");

        int x=0;
        try{
          while(rs2.next())
          {
            for(int i=4,j=0;i<=numcolumn-2;i++,j++)
            {
              serievalue[j][x] = rs2.getString(i);

            }

            x++;

          }
        }catch(SQLException ee)
        {
        }
        String src=Integer.toString(rowcount);
        String scc=Integer.toString(numcolumn-5);
        Frameplan fp = new Frameplan(serievalue,src,scc);
        fp.show();
       }
       else if(jRadioButton6.isSelected())
       {
         int rowcount2=0;
          ResultSet rs2 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
          //ResultSet rs2 = db.executeSQLquery("SELECT * FROM DMSTEMP");
          int numcolumn2=0;

          try{
            ResultSetMetaData rsmd = rs2.getMetaData();
            numcolumn2 = rsmd.getColumnCount();
           while(rs2.next())
           {
             rowcount2++;
           }
         }catch(SQLException ee)
         {}
        String[][] serievalue2;
        serievalue2 = new String[numcolumn2][rowcount2];
       ResultSet rs3 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
        //ResultSet rs3 = db.executeSQLquery("SELECT * FROM DMSTEMP");
       String sday = jTextField6.getText();
        String smonth = jTextField7.getText();
        String syear = jTextField8.getText();
        String eday = jTextField9.getText();
        String emonth = jTextField10.getText();
        String eyear = jTextField11.getText();
        String sdate = syear+"-"+smonth+"-"+sday;
        String edate = eyear+"-"+emonth+"-"+eday;
        Date stdate = Date.valueOf(sdate);
         Date etdate = Date.valueOf(edate);
       int x=0;
        try{
          while(rs3.next())
          {
            for(int i=4,j=0;i<=numcolumn2-2;i++,j++)
            {
              serievalue2[j][x] = rs3.getString(i);
            }
            Date cdate = Date.valueOf(rs3.getString("THEDATE"));
 if((cdate.compareTo(stdate)>=0)&&(cdate.compareTo(etdate)<=0))
 {


            x++;
 }
          }
        }catch(SQLException ee)
        {
        }
        String src2=Integer.toString(x);
        String scc2=Integer.toString(numcolumn2-5);
        Frameplan fp2 = new Frameplan(serievalue2,src2,scc2);
        fp2.show();

       }
     else if(jRadioButton4.isSelected())
     {
       int rowcount10=0;
         ResultSet rs10 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
         //ResultSet rs2 = db.executeSQLquery("SELECT * FROM DMSTEMP");
         int numcolumn10=0;

         try{
           ResultSetMetaData rsmd10 = rs10.getMetaData();
           numcolumn10 = rsmd10.getColumnCount();
          while(rs10.next())
          {
            rowcount10++;
          }
        }catch(SQLException ee)
        {}
       String[][] serievalue10;
       serievalue10 = new String[numcolumn10][rowcount10];
      ResultSet rs11 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
       //ResultSet rs3 = db.executeSQLquery("SELECT * FROM DMSTEMP");
     //------------------------------------
      String sday2 = jTextField1.getText();
        String smonth2 = jTextField2.getText();
        String syear2 = jTextField3.getText();
        String thours = jTextField4.getText();
        String tmins = jTextField12.getText();
        String thoure = jTextField5.getText();
        String tmine = jTextField14.getText();
        String stime = thours+":"+tmins+":00";
        String etime = thoure+":"+tmine+":00";
        String sdate = syear2+"-"+smonth2+"-"+sday2;

        Date stdate = Date.valueOf(sdate);
        Time tstime = Time.valueOf(stime);
        Time tetime = Time.valueOf(etime);
     //------------------------------------
      int x=0;
       try{
         while(rs11.next())
         {
           for(int i=4,j=0;i<=numcolumn10-2;i++,j++)
           {
             serievalue10[j][x] = rs11.getString(i);
           }
          // Date cdate = Date.valueOf(rs11.getString("THEDATE"));
         Date cdate = Date.valueOf(rs11.getString("THEDATE"));
         Time ctime = Time.valueOf(rs11.getString("THETIME"));
                       //if((stdate.compareTo(cdate)<=0)&&(etdate.compareTo(cdate)<=0))
         if((cdate.compareTo(stdate)==0)&&(ctime.compareTo(tstime)>=0)&&(ctime.compareTo(tetime)<=0))
        {
             x++;
         }
         }
       }catch(SQLException ee)
       {
       }
       String src10=Integer.toString(x);
       String scc10=Integer.toString(numcolumn10-5);
       Frameplan fp10 = new Frameplan(serievalue10,src10,scc10);
        fp10.show();
     }
     }
  /*   else if(jRadioButton2.isSelected())
     {
       System.out.println("Pine graph");
     }*/
     else if(jRadioButton3.isSelected())
     {
       System.out.println("Table");
       String groupid = Grouplist.getSelectedItem();
       int rowcount=0;
       if(jRadioButton5.isSelected())
       {
        ResultSet rs = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
        // ResultSet rs = db.executeSQLquery("SELECT * FROM DMSTEMP");
         try{

           while(rs.next())
           {
             rowcount++;
           }
         }catch(SQLException ee)
         {}

         String columnNames[];
         String dataValues[][];
         ResultSet rs2 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
        // ResultSet rs2 = db.executeSQLquery("SELECT * FROM DMSTEMP");
         try{
           ResultSetMetaData rsmd = rs2.getMetaData();
         int numberOfColumns = rsmd.getColumnCount();

         columnNames = new String[numberOfColumns];
         dataValues = new String[rowcount][numberOfColumns];
          for( int iCtr = 0; iCtr < numberOfColumns; iCtr++ )
                    columnNames[iCtr] = rsmd.getColumnName(iCtr+1);//"Col:" + iCtr;
         int iY=0;
         while(rs2.next())
       {
           for( int iX = 0; iX < numberOfColumns; iX++ )
                         {
             dataValues[iY][iX] = rs2.getString(iX+1);

                         }
           iY++;

       }
       Thetable tt = new Thetable(columnNames,dataValues);
       tt.show();
       }catch(SQLException sql)
       {}


       }
       else if(jRadioButton6.isSelected())
       {
         int rowcount2=0;
          ResultSet rs4 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
         //ResultSet rs4 = db.executeSQLquery("SELECT * FROM DMSTEMP");
         try{

           while(rs4.next())
           {
             rowcount2++;
           }
         }catch(SQLException ee)
         {}
         String columnNames2[];
         String dataValues2[][];
        ResultSet rs5 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
         //ResultSet rs5 = db.executeSQLquery("SELECT * FROM DMSTEMP");
         String sday = jTextField6.getText();
         String smonth = jTextField7.getText();
         String syear = jTextField8.getText();
         String eday = jTextField9.getText();
         String emonth = jTextField10.getText();
         String eyear = jTextField11.getText();
         String sdate = syear+"-"+smonth+"-"+sday;
         String edate = eyear+"-"+emonth+"-"+eday;
         Date stdate = Date.valueOf(sdate);
         Date etdate = Date.valueOf(edate);
         try{
           ResultSetMetaData rsmd = rs5.getMetaData();
      int numberOfColumns2 = rsmd.getColumnCount();

       columnNames2 = new String[numberOfColumns2];
       dataValues2 = new String[rowcount2][numberOfColumns2];
       for( int iCtr = 0; iCtr < numberOfColumns2; iCtr++ )
                  columnNames2[iCtr] = rsmd.getColumnName(iCtr+1);//"Col:" + iCtr;
        //Date cdate = Date.valueOf(rs4.getString("THEDATE"));
       int iY2=0;
        int idate = rs5.findColumn("THEDATE");
        boolean flag=false;
         while(rs5.next())
       {
           //Date cdate = Date.valueOf(rs5.getString("THEDATE"));
        // if((stdate.compareTo(cdate)<=0)&&(edate.compareTo(cdate)>0))
        // {
           flag=false;
           for( int iX2 = 0; iX2 < numberOfColumns2; iX2++ )
                       {

                        if((iX2+1)==idate)
                        {
                           //Date cdate = Date.valueOf(rs5.getString(iX2+1));
                          //Date cdate = rs5.getDate(iX2+1);
                          String tdate = rs5.getString(iX2+1);
                          Date cdate = Date.valueOf(tdate);
                          //if((stdate.compareTo(cdate)<=0)&&(etdate.compareTo(cdate)<=0))
                          if((cdate.compareTo(stdate)>=0)&&(cdate.compareTo(etdate)<=0))
                          {

                            dataValues2[iY2][iX2] = tdate;
                          }
                          else{
                            flag=true;
                          }
                        }
                          else{
                      dataValues2[iY2][iX2] = rs5.getString(iX2+1);
                          }
                       }
           if(flag==false)
           {
                       iY2++;
           }
        // }

         }
         Thetable tt2 = new Thetable(columnNames2,dataValues2);
       tt2.show();
       }catch(SQLException sql)
       {}
       }
       else if(jRadioButton4.isSelected())
       {
         int rowcount3=0;
          ResultSet rs6 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
                 //ResultSet rs6 = db.executeSQLquery("SELECT * FROM DMSTEMP");
                  try{

                    while(rs6.next())
                    {
                      rowcount3++;
                    }
                  }catch(SQLException ee)
                  {}
                  String columnNames3[];
         String dataValues3[][];
          ResultSet rs7 = db.executeSQLquery("SELECT * FROM "+projectid+"_"+groupid+"_"+"LOG");
         //ResultSet rs7 = db.executeSQLquery("SELECT * FROM DMSTEMP");
        String sday2 = jTextField1.getText();
        String smonth2 = jTextField2.getText();
        String syear2 = jTextField3.getText();
        String thours = jTextField4.getText();
        String tmins = jTextField12.getText();
        String thoure = jTextField5.getText();
        String tmine = jTextField14.getText();
        String stime = thours+":"+tmins+":00";
        String etime = thoure+":"+tmine+":00";
        String sdate = syear2+"-"+smonth2+"-"+sday2;

        Date stdate = Date.valueOf(sdate);
        Time tstime = Time.valueOf(stime);
        Time tetime = Time.valueOf(etime);
        try{
        ResultSetMetaData rsmd2 = rs7.getMetaData();
   int numberOfColumns3 = rsmd2.getColumnCount();

    columnNames3 = new String[numberOfColumns3];
    dataValues3 = new String[rowcount3][numberOfColumns3];
    for( int iCtr = 0; iCtr < numberOfColumns3; iCtr++ )
               columnNames3[iCtr] = rsmd2.getColumnName(iCtr+1);//"Col:" + iCtr;
     //Date cdate = Date.valueOf(rs4.getString("THEDATE"));
    int iY3=0;
     int idate = rs7.findColumn("THEDATE");
     int itime = rs7.findColumn("THETIME");
     boolean flag=false;
     boolean flag2=false;
      while(rs7.next())
    {
        //Date cdate = Date.valueOf(rs5.getString("THEDATE"));
     // if((stdate.compareTo(cdate)<=0)&&(edate.compareTo(cdate)>0))
     // {
        flag=false;
        //flag2=false;
        for( int iX3 = 0; iX3 < numberOfColumns3; iX3++ )
                    {

                     if((iX3+1)==idate)
                     {
                        //Date cdate = Date.valueOf(rs5.getString(iX2+1));
                       //Date cdate = rs5.getDate(iX2+1);
                       String tdate = rs7.getString(iX3+1);
                       Date cdate = Date.valueOf(tdate);
                       //if((stdate.compareTo(cdate)<=0)&&(etdate.compareTo(cdate)<=0))
                       if(cdate.compareTo(stdate)==0)
                       {

                         dataValues3[iY3][iX3] = tdate;
                       }
                       else{
                         flag=true;
                       }
                     }
                     else if((iX3+1)==itime)
                     {
                       String ttime = rs7.getString(iX3+1);
                       Time ctime = Time.valueOf(ttime);
                       if((ctime.compareTo(tstime)>=0)&&(ctime.compareTo(tetime)<=0))
                       {
                        dataValues3[iY3][iX3] = ttime;

                       }
                       else{
                         flag=true;
                       }
                     }
                       else{
                   dataValues3[iY3][iX3] = rs7.getString(iX3+1);
                       }
                    }
        if(flag==false)
        {
                    iY3++;
        }
     // }

      }
      Thetable tt3 = new Thetable(columnNames3,dataValues3);
    tt3.show();
    }catch(SQLException sql)
       {}
       }
       }

  }

  void jButton2_actionPerformed(ActionEvent e) {
     String groupselect="";
     groupselect = Grouplist.getSelectedItem();
     if(jRadioButton7.isSelected())
     {
     //db.executeSQLupdate("DELETE FROM DMSTEMP WHERE GROUPID = '"+groupselect+"'");
      db.executeSQLupdate("DELETE FROM "+projectid+"_"+groupselect+"_"+"LOG WHERE GROUPID = '"+groupselect+"'");
     }
     else if(jRadioButton8.isSelected())
     {
       String date="";
       String cday=jTextField13.getText();
       String cmonth=jTextField15.getText();
       String cyear=jTextField15.getText();
       date = date.concat(cyear+"-"+cmonth+"-"+cday);
       //db.executeSQLupdate("DELETE FROM DMSTEMP WHERE GROUPID = '"+groupselect+"' AND THEDATE ='"+date);
       db.executeSQLupdate("DELETE FROM "+projectid+"_"+groupselect+"_"+"LOG WHERE GROUPID = '"+groupselect+"' AND THEDATE ='"+date);

     }
  }

  void jButton3_actionPerformed(ActionEvent e) {
     Datalog dl = new Datalog(projectid,db);
     dl.show();
  }
}