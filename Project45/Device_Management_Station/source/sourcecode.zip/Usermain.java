package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Usermain extends JInternalFrame {
  private List list1 = new List();
  private Database db;
  String un="";
  private Button button1 = new Button();
  private Button button2 = new Button();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JTextArea list2 = new JTextArea();
  private Desktop themain;
  private JScrollPane jScrollPane1 = new JScrollPane();
  public Usermain(String username,Desktop tm,Database d) {
    try {
      db = d;
      un=username;
      themain = tm;
      jbInit();

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /*
  public static void main(String[] args) {
    String username="";
    (new Usermain(username).setVisible(true));
  }*/
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    this.getContentPane().setLayout(null);
    this.getContentPane().setBackground(Color.lightGray);
    setSize(600,600);
    list1.setBounds(new Rectangle(42, 129, 142, 323));
    list1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        list1_actionPerformed(e);
      }
    });
    //---part bb this part to test ---- Remove when test pass.....
    //list1.add("Configeration Management");
    //list1.add("Performance Management");
    //----end part bb
  //  try
    //{
    System.out.println(un);
   ResultSet rs = db.executeSQLquery("SELECT PROJECTID FROM PROJECTUSER WHERE USERID='"+un+"'");
   while (rs.next())
   {
       list1.add(rs.getString("PROJECTID"));
    }

   // }
   // catch (SQLException sql)
   // {
   //   System.out.println("Error connecting Database");
   //   System.out.println(sql.getMessage());
   // }
    button1.setLabel("Open Project");
    button1.setBounds(new Rectangle(332, 488, 106, 23));
    button1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        button1_actionPerformed(e);
      }
    });
    button2.setLabel("close");
    button2.setBounds(new Rectangle(448, 487, 74, 24));
    button2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        button2_actionPerformed(e);
      }
    });
    jLabel1.setText("Device Management Station");
    jLabel1.setBounds(new Rectangle(39, 20, 369, 46));
    jLabel2.setText("Project list");
    jLabel2.setBounds(new Rectangle(35, 67, 149, 34));
    jLabel3.setText("Project\'s description");
    jLabel3.setBounds(new Rectangle(232, 63, 224, 36));
    jScrollPane1.setBounds(new Rectangle(232, 130, 293, 323));
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(list1, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(jScrollPane1, null);
    this.getContentPane().add(button2, null);
    this.getContentPane().add(button1, null);
    jScrollPane1.getViewport().add(list2, null);
    this.setVisible(true);
    themain.addframe(this);

  }
  void list1_actionPerformed(ActionEvent e) {
     //System.out.println(list1.getSelectedIndex());
    //-----When double click the detail of this project will be shown in jTextArea1
    String sli = list1.getSelectedItem();
    try
    {
    ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT WHERE PROJECTID = '"+sli+"'");
    while (rs.next())
    {
      String projectid = rs.getString("PROJECTID");
      String projectname = rs.getString("PROJECTNAME");
      String projectdescription = rs.getString("PROJECTDESCRIPTION");
      String projectdate = rs.getString("PROJECTDATE");
       //System.out.println(service);
       list2.append(projectid + " " + projectname + " " +projectdescription + " " + projectdate + "\n");
    }
    }
    catch (SQLException sql)
    {
      System.out.println("Error connecting to database");
      System.out.println(sql.getMessage());
    }
  }

  void button1_actionPerformed(ActionEvent e) {
     System.out.println(list1.getItem(0));
     Projectmain pn = new Projectmain(list1.getSelectedItem(),un,themain,db);
     pn.show();
     this.dispose();
  }

  void button2_actionPerformed(ActionEvent e) {
      this.dispose();
  }
}