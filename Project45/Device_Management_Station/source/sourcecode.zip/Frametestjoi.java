package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frametestjoi extends JFrame {
  private JButton jButton1 = new JButton();
  SNMPManager snmp = new SNMPManager();
  public Frametestjoi() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

  }
  public static void main(String[] args) {
    Frametestjoi frametestjoi = new Frametestjoi();
  }
  private void jbInit() throws Exception {
    jButton1.setBounds(new Rectangle(97, 182, 125, 37));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    this.getContentPane().add(jButton1, null);
    this.setVisible(true);
  }

  void jButton1_actionPerformed(ActionEvent e) {
     snmp.sendGet("161.246.5.99","1.3.6.1.2.1.1.1","public");
     System.out.println(snmp.getResult());
  }
}