package dms;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FaultPanel extends JPanel implements TreeSelectionListener {
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTree jTreefp = new JTree();
  private JLabel jLabel1 = new JLabel();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JButton jButton7 = new JButton();
  private String projectname="";
  private String devicename="";
  FaultManagement fmm;
  Faultlistenframe flm;
  private Database db;
  private String selectobjectfp;
  private String parentselectobjectfp;
  private JTextArea jTextArea1 = new JTextArea();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JButton jButton3 = new JButton();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JLabel jLabel2 = new JLabel();
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JTextField jTextField3 = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JTextField jTextField4 = new JTextField();
  private JTextField jTextField5 = new JTextField();
  private JTextField jTextField6 = new JTextField();
  private Desktop frame;
  public FaultPanel(JTree jj,FaultManagement fm,String pn,String dn,Desktop f,Database d) {
    db = d;
    jTreefp=jj;
    fmm=fm;
    projectname = pn;
    devicename =dn;
    frame = f;
    fmm = new FaultManagement(projectname,db);
     flm = new Faultlistenframe(projectname,fmm,frame,db);
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(null);
    jScrollPane1.setBounds(new Rectangle(10, 9, 100, 281));
    jLabel1.setText("Object Fault Detection setting information");
    jLabel1.setBounds(new Rectangle(120, 11, 255, 26));
    jScrollPane2.setBounds(new Rectangle(124, 40, 238, 129));
    jButton7.setBounds(new Rectangle(129, 206, 227, 19));
    jButton7.setText("OPEN FAULTLISTENER WINDOW");
    jButton7.addActionListener(new FaultPanel_jButton7_actionAdapter(this));
    jButton1.setBounds(new Rectangle(194, 181, 91, 20));
    jButton1.setText("CLEAR");
    jButton1.addActionListener(new FaultPanel_jButton1_actionAdapter(this));

    jButton2.setBounds(new Rectangle(126, 303, 236, 20));
    jButton2.setText("open fault log");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
     public void actionPerformed(ActionEvent e) {
       jButton2_actionPerformed(e);
     }
    });
    jButton3.setBounds(new Rectangle(127, 402, 234, 20));
    jButton3.setText("delete fault log");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
     public void actionPerformed(ActionEvent e) {
       jButton3_actionPerformed(e);
     }
    });
    jRadioButton1.setText("select date for view fault log");
    jRadioButton1.setBounds(new Rectangle(128, 232, 225, 25));
    jRadioButton2.setText("select date to delete fault log");
    jRadioButton2.setBounds(new Rectangle(129, 339, 221, 25));
    jLabel2.setText("Enter date");
    jLabel2.setBounds(new Rectangle(130, 260, 75, 25));
    jTextField1.setBounds(new Rectangle(222, 259, 26, 27));
    jTextField2.setBounds(new Rectangle(255, 259, 26, 27));
    jTextField3.setBounds(new Rectangle(287, 258, 44, 27));
    jLabel3.setBounds(new Rectangle(127, 368, 75, 25));
    jLabel3.setText("Enter date");
    jTextField4.setBounds(new Rectangle(222, 366, 26, 27));
    jTextField5.setBounds(new Rectangle(254, 366, 26, 27));
    jTextField6.setBounds(new Rectangle(285, 366, 45, 27));
    this.add(jScrollPane1, null);
    this.add(jLabel1, null);
    this.add(jScrollPane2, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    this.add(jButton1, null);
    this.add(jButton7, null);
    this.add(jButton2, null);
    this.add(jButton3, null);
    this.add(jRadioButton1, null);
    this.add(jRadioButton2, null);
    this.add(jLabel2, null);
    this.add(jTextField2, null);
    this.add(jTextField3, null);
    this.add(jTextField1, null);
    this.add(jLabel3, null);
    this.add(jTextField4, null);
    this.add(jTextField5, null);
    this.add(jTextField6, null);
    MouseListener mm = new MouseAdapter()
   {
     public void mouseClicked(MouseEvent e)
     {
       if(e.getClickCount()==2)
       {
         System.out.println("Double click");
         ResultSet rs = db.executeSQLquery("SELECT * FROM FAULT WHERE OBJECTID='"+selectobjectfp+"' AND PROJECTID='"+projectname+"' AND DEVICEID='"+devicename+"'");
         jTextArea1.setText("Fault Detection setting on this object :\n");
         try{
           while(rs.next())
           {
             jTextArea1.append(rs.getString("FAULTNAME")+"  "+rs.getString("PROJECTID")+"  "+rs.getString("FAULTCHECK")+"\n");
           }
         }
         catch(SQLException sql)
         {
           System.out.println("Error connecting Database");
         }
       }

     }
  };
    jTreefp.addMouseListener(mm);
    jTreefp.addTreeSelectionListener(this);
    jScrollPane1.getViewport().add(jTreefp, null);
  }

  public void valueChanged(TreeSelectionEvent ev)
{
     TreePath path=jTreefp.getSelectionPath();
     TreePath parent=path.getParentPath();
     System.out.println("Selection path=" + path.toString());
     parentselectobjectfp = parent.getLastPathComponent().toString();
     System.out.println(parentselectobjectfp);

     System.out.println(jTreefp.getLastSelectedPathComponent().toString());
     selectobjectfp = jTreefp.getLastSelectedPathComponent().toString();
     System.out.println("The object select is " + selectobjectfp);
}


  void jButton1_actionPerformed(ActionEvent e) {
       jTextArea1.setText("");
   // fmm.enablefaultlistener();
  }

  void jButton7_actionPerformed(ActionEvent e) {
     // if(flm.isShowing()==false)
     // {
     // flm = new Faultlistenframe(projectname,fmm);

     // if(flm.isShowing()==false)
     // {
      flm.setVisible(true);
      frame.addframe(flm);
      //}
  }

  void jButton2_actionPerformed(ActionEvent e) {
  System.out.println("View Fault log");
   if(jRadioButton1.isSelected())
   {
     String year = jTextField3.getText();
     String month = jTextField2.getText();
     String day = jTextField1.getText();
     String date = year+"-"+month+"-"+day;
     ResultSet rs = db.executeSQLquery("SELECT * FROM FAULTEVENT WHERE PROJECTID='"+projectname+"' AND FAULTDATE='"+date+"'");
     int rowcount=0;
     try{
     while (rs.next())
     {
       rowcount++;
     }
     } catch (SQLException sql)
     {}
     String[][] datavalue = new String[rowcount][7];
     String[] name = new String[7];
     name[0]="FAULTID";
     name[1]="PROJECTID";
     name[2]="DEVICEID";
     name[3]="OBJECTID";
     name[4]="FAULTDESCRIPTION";
     name[5]="FAULTDATE";
     name[6]="FAULTTIME";
     ResultSet rs2 = db.executeSQLquery("SELECT * FROM FAULTEVENT WHERE PROJECTID='"+projectname+"' AND FAULTDATE='"+date+"'");
     int x=0;
     try{
     while (rs2.next())
     {
       for(int i=0;i<7;i++)
       {
         datavalue[x][i]=rs2.getString(i+1);
       }
       x++;
     }
     } catch (SQLException sql)
     {}
     Thetable tt = new Thetable(name,datavalue);
     tt.show();
   }
   else
   {
     ResultSet rs3 = db.executeSQLquery("SELECT * FROM FAULTEVENT WHERE PROJECTID='"+projectname+"'");
     int rowcount=0;
     try{
     while (rs3.next())
     {
       rowcount++;
     }
     } catch (SQLException sql)
     {}
     String[][] datavalue = new String[rowcount][7];
     String[] name = new String[7];
     name[0]="FAULTID";
     name[1]="PROJECTID";
     name[2]="DEVICEID";
     name[3]="OBJECTID";
     name[4]="FAULTDESCRIPTION";
     name[5]="FAULTDATE";
     name[6]="FAULTTIME";
     ResultSet rs4 = db.executeSQLquery("SELECT * FROM FAULTEVENT WHERE PROJECTID='"+projectname+"'");
     int x=0;
     try{
     while (rs4.next())
     {
       for(int i=0;i<7;i++)
       {
         datavalue[x][i]=rs4.getString(i+1);
       }
       x++;
     }
     } catch (SQLException sql)
     {}
     Thetable tt = new Thetable(name,datavalue);
     tt.show();
   }
  }

  void jButton3_actionPerformed(ActionEvent e) {
   if(jRadioButton2.isSelected())
   {
     String year2 = jTextField3.getText();
     String month2 = jTextField2.getText();
     String day2 = jTextField1.getText();
     String date2 = year2+"-"+month2+"-"+day2;
     db.executeSQLupdate("DELETE FROM FAULTEVENT WHERE PROJECTID='"+projectname+"' AND FAULTDATE='"+date2+"'");
   }
   else
   {
     db.executeSQLupdate("DELETE FROM FAULTEVENT WHERE PROJECTID='"+projectname+"'");
   }
  }
}

class FaultPanel_jButton7_actionAdapter implements java.awt.event.ActionListener {
  private FaultPanel adaptee;

  FaultPanel_jButton7_actionAdapter(FaultPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton7_actionPerformed(e);
  }
}

class FaultPanel_jButton2_actionAdapter implements java.awt.event.ActionListener {
  private FaultPanel adaptee;

  FaultPanel_jButton2_actionAdapter(FaultPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton2_actionPerformed(e);
  }
}

class FaultPanel_jButton1_actionAdapter implements java.awt.event.ActionListener {
  private FaultPanel adaptee;

  FaultPanel_jButton1_actionAdapter(FaultPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton1_actionPerformed(e);
  }
}

class FaultPanel_jButton3_actionAdapter implements java.awt.event.ActionListener {
  private FaultPanel adaptee;

  FaultPanel_jButton3_actionAdapter(FaultPanel adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jButton3_actionPerformed(e);
  }
}