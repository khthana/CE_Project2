package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

public class FrameTable extends JInternalFrame {
  private Database db;
  private Desktop themain;
  // Variable for performance
  int countrowtable = 0;
  String[] value;
  int countvalue =0;
  String projectid = "";
  String[][] deviceobjectid;
  String data = new String("");
  String groupid = "";
  Object[][] data1 = {{"a"}};
 /* = {
            {"Mary", "Campione",
             "Snowboarding", new Integer(5), new Boolean(false)},
            {"Alison", "Huml",
             "Rowing", new Integer(3), new Boolean(true)},
            {"Kathy", "Walrath",
             "Chasing toddlers", new Integer(2), new Boolean(false)},
            {"Sharon", "Zakhour",
             "Speed reading", new Integer(20), new Boolean(true)},
            {"Angela", "Lih",
             "Teaching high school", new Integer(4), new Boolean(false)}
        };*/

  String[] columnNames;
       /* = {"First Name",
                                "Last Name",
                                "Sport",
                                "# of Years",
                                "Vegetarian"};*/

  JTable tabletemp;
  JTable table;

  int numofdevice = 0;
  boolean flag=false;
  Framethread framethread;
  int count = 0;

  private JToggleButton Start = new JToggleButton();
  private JTextField Project = new JTextField();
  private JTextField Group = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private Border border1;
  private JButton Close = new JButton();
  //private JTable Tablemonitor = new JTable();




  public FrameTable() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }



  public FrameTable(int numofdevice,String[] name,String[][] deviceobjectid,String groupid,String projectid,Desktop tm,Database d) {

    try {
      db = d;
      themain =tm;
      this.projectid = projectid;
      this.groupid = groupid;
      this.numofdevice = numofdevice;
      this.deviceobjectid = deviceobjectid;

      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void printDebugData(JTable table) {
    int numRows = table.getRowCount();
    int numCols = table.getColumnCount();
    javax.swing.table.TableModel model = table.getModel();

    System.out.println("Value of data: ");
    for (int i=0; i < numRows; i++) {
      System.out.print("    row " + i + ":");
      for (int j=0; j < numCols; j++) {
        System.out.print("  " + model.getValueAt(i, j));
      }
      System.out.println();
    }
    System.out.println("--------------------------");
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.getContentPane().setBackground(Color.lightGray);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    this.setSize(new Dimension(800,600));
    Project.setText(projectid);
    Group.setText(groupid);
    value = new String[numofdevice];
    columnNames = new String[numofdevice+1];
    columnNames[0] = "Number";
    for (int i=0;i<columnNames.length-1;i++)
    {
      columnNames[i+1] = deviceobjectid[i][0] + " , " + deviceobjectid[i][1];
    }
    table = new JTable(10000, numofdevice+1);
    tabletemp = new JTable(data1, columnNames);
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    table.setColumnModel(tabletemp.getColumnModel());
    table.setPreferredScrollableViewportSize(new Dimension(500, 70));

      /*  if (DEBUG) {
            table.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent e) {
                    printDebugData(table);
                }
            });
        }*/

    //Create the scroll pane and add the table to it.
    JScrollPane scrollPane = new JScrollPane(table);
    scrollPane.setBounds(new Rectangle(25, 105, 711, 421));
    //Add the scroll pane to this window.
    Project.setBorder(border1);
    Project.setEditable(false);
    Project.setBounds(new Rectangle(124, 20, 233, 29));
    Group.setBorder(border1);
    Group.setEditable(false);
    Group.setBounds(new Rectangle(124, 59, 233, 28));
    jLabel1.setText("PROJECT");
    jLabel1.setBounds(new Rectangle(20, 23, 87, 24));
    jLabel2.setText("GROUP");
    jLabel2.setBounds(new Rectangle(22, 62, 90, 25));
    Close.setBounds(new Rectangle(623, 536, 107, 28));
    Close.setText("CLOSE");
    Close.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Close_actionPerformed(e);
      }
    });
    this.getContentPane().add(Project, null);
    this.getContentPane().add(Group, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(Close, null);
    this.getContentPane().add(Start, null);
    this.getContentPane().add(scrollPane, null);

    this.getContentPane().setLayout(null);
/*    addWindowListener(new WindowAdapter() {
       public void windowClosing(WindowEvent e) {
         ActionEvent ee = new ActionEvent("",1,"");
         Close_actionPerformed(ee);
       }
        });*/
    // jScrollPane1.setBounds(new Rectangle(64, 95, 602, 327));
    Start.setText("Start");
    Start.setBounds(new Rectangle(495, 535, 107, 28));
    Start.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Start_actionPerformed(e);
      }
    });
    //this.getContentPane().add(jScrollPane1, null);
    //jScrollPane1.getViewport().add(Tablemonitor, null);
    framethread = new Framethread(numofdevice,deviceobjectid,this,db);
    this.setTitle("MONITOR (TABLE)");
    themain.addframe(this);
  }


  void Start_actionPerformed(ActionEvent e) {
    if (Start.isSelected())
    {
      if (count == 0)
      {
        framethread.start();
        count = 1;
      }
      else
      {
        framethread.resume();
      }


    }
    else
    {
      framethread.suspend();
    }


  }

  public void setvalue(String[] value1)
  {

      value[countvalue] = value1[2];
      countvalue++;
    //System.out.println("Frametable setvalue: temp = " + temp);
    //data = data+temp;

    //System.out.println("Frametable setvalue: data = " + data);

  }

  public void write()
  {

    for(int i=0;i<numofdevice;i++)
    {
      table.setValueAt(Integer.toString(countrowtable+1),countrowtable,0);
      table.setValueAt(value[i],countrowtable,i+1);
    }
    countrowtable++;
    countvalue=0;
    //Textmonitor.setText(data);
    //data = "";

  }

/*  public static void main(String[] args) {
    FrameTable frame = new FrameTable(1,null,null,null,null);
    frame.pack();
    frame.setVisible(true);
  }*/

  void Close_actionPerformed(ActionEvent e) {
    framethread.stop();
    this.dispose();
  }

}