package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Faultlistenframe extends JInternalFrame {
  private JLabel jLabel1 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private String projectname="";
  private Database db;
  FaultManagement fmm;
  private JLabel jLabel2 = new JLabel();
  private JTextField jTextField1 = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private TitledBorder titledBorder1;
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JTextField jTextField2 = new JTextField();
  private JTextField jTextField3 = new JTextField();
  private JTextField jTextField4 = new JTextField();
  private JLabel jLabel4 = new JLabel();
  private JTextField jTextField5 = new JTextField();
  private JTextField jTextField6 = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  private JLabel jLabel7 = new JLabel();
  private JTextField jTextField7 = new JTextField();
  private JTextField jTextField8 = new JTextField();
  private JTextField jTextField9 = new JTextField();
  private JTextField jTextField10 = new JTextField();
  private JTextField jTextField11 = new JTextField();
  private JButton jButton3 = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea jTextArea1 = new JTextArea();
  private JButton Opentraplistener = new JButton();
  private Desktop frame;
  public Faultlistenframe(String pn,FaultManagement fm,Desktop f,Database d) {
    db = d;
    fmm = new FaultManagement(projectname,db);
    projectname=pn;
    fmm=fm;
    frame = f;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    titledBorder1 = new TitledBorder("");
    this.getContentPane().setLayout(null);
    jLabel1.setText("Fault Event List");
    jLabel1.setBounds(new Rectangle(17, 23, 274, 25));
    jButton1.setBounds(new Rectangle(20, 355, 165, 21));
    jButton1.setText("enable");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setText("disable");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(207, 355, 161, 21));
    jLabel2.setText("Polling rate");
    jLabel2.setBounds(new Rectangle(32, 300, 83, 38));
    jTextField1.setBounds(new Rectangle(144, 306, 108, 27));
    jLabel3.setText("millisecs");
    jLabel3.setBounds(new Rectangle(259, 306, 85, 29));
    jPanel1.setBorder(titledBorder1);
    jPanel1.setBounds(new Rectangle(22, 59, 355, 231));
    jPanel1.setLayout(null);
    jRadioButton1.setText("set time to stop fault listener");
    jRadioButton1.setBounds(new Rectangle(18, 16, 222, 25));
    jTextField2.setBounds(new Rectangle(24, 191, 26, 25));
    jTextField3.setBounds(new Rectangle(56, 191, 26, 25));
    jTextField4.setBounds(new Rectangle(88, 191, 44, 25));
    jLabel4.setText("Stop Date");
    jLabel4.setBounds(new Rectangle(24, 162, 79, 24));
    jTextField5.setBounds(new Rectangle(175, 190, 26, 25));
    jTextField6.setBounds(new Rectangle(206, 190, 26, 25));
    jLabel5.setText("Stop Time");
    jLabel5.setBounds(new Rectangle(175, 161, 76, 23));
    jLabel6.setBounds(new Rectangle(19, 44, 78, 24));
    jLabel6.setText("Start Date");
    jLabel7.setBounds(new Rectangle(174, 46, 90, 24));
    jLabel7.setText("Start Time");
    jTextField7.setBounds(new Rectangle(24, 73, 26, 25));
    jTextField8.setBounds(new Rectangle(57, 73, 26, 25));
    jTextField9.setBounds(new Rectangle(174, 72, 26, 25));
    jTextField10.setBounds(new Rectangle(204, 72, 26, 25));
    jTextField11.setBounds(new Rectangle(88, 73, 44, 25));
    jButton3.setBounds(new Rectangle(18, 425, 352, 26));
    jButton3.setText("close this window");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    this.getContentPane().setBackground(Color.lightGray);
    jScrollPane1.setBounds(new Rectangle(17, 469, 355, 30));
    Opentraplistener.setBounds(new Rectangle(18, 386, 353, 25));
    Opentraplistener.setText("Open Trap Listener");
    Opentraplistener.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Opentraplistener_actionPerformed(e);
      }
    });
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(jRadioButton1, null);
    jPanel1.add(jTextField3, null);
    jPanel1.add(jTextField4, null);
    jPanel1.add(jTextField5, null);
    jPanel1.add(jTextField6, null);
    jPanel1.add(jTextField2, null);
    jPanel1.add(jLabel4, null);
    jPanel1.add(jLabel5, null);
    jPanel1.add(jLabel6, null);
    jPanel1.add(jLabel7, null);
    jPanel1.add(jTextField7, null);
    jPanel1.add(jTextField8, null);
    jPanel1.add(jTextField9, null);
    jPanel1.add(jTextField10, null);
    jPanel1.add(jTextField11, null);
    this.getContentPane().add(jButton3, null);
    this.getContentPane().add(jScrollPane1, null);
    this.getContentPane().add(jTextField1, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(Opentraplistener, null);
    jScrollPane1.getViewport().add(jTextArea1, null);
    this.setSize(450,550);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    this.jTextArea1.setText("Enable");
    if(jRadioButton1.isSelected())
   {
      Date sdate = Date.valueOf(jTextField11.getText()+"-"+jTextField8.getText()+"-"+jTextField7.getText());
       Time stime =Time.valueOf(jTextField9.getText()+":"+jTextField10.getText()+":00");
       Date edate = Date.valueOf(jTextField4.getText()+"-"+jTextField3.getText()+"-"+jTextField2.getText());
       Time etime = Time.valueOf(jTextField5.getText()+":"+jTextField6.getText()+":00");
      fmm.enablefaultlistener(jTextField1.getText(),true,sdate,stime,edate,etime);
        }
   else
   {
     Date sdate = Date.valueOf("1111-01-01");
       Time stime =Time.valueOf("00:00:00");
       Date edate = Date.valueOf("1111-01-01");
       Time etime = Time.valueOf("00:00:00");

    fmm.enablefaultlistener(jTextField1.getText(),false,sdate,stime,edate,etime);
   }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    this.jTextArea1.setText("Disable");
    fmm.disablefaultlistener();
  }

  void jButton3_actionPerformed(ActionEvent e) {
     fmm.disablefaultlistener();
     this.dispose();
  }

  void Opentraplistener_actionPerformed(ActionEvent e) {
    Traplistener t = new Traplistener(projectname,db);
    t.setVisible(true);
    t.setSize(400,500);
    frame.addframe(t);

  }
}