package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.io.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditDevice1 extends JPanel {
  private Database db;
  private JComboBox Selectdevice = new JComboBox();
  private JTextField Devicename = new JTextField();
  private JTextField Deviceip = new JTextField();
  private JTextField Deviceid = new JTextField();
  private JComboBox Deviceprotocol = new JComboBox();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private String deviceid = "";
  private String devicename = "";
  private String deviceip = "";
  private String deviceprotocol = "";
  private String mibfile = "";
  private JTextArea Devicedetail = new JTextArea();
  private Border border1;
  private TitledBorder titledBorder1;
  private JButton mibbrowse = new JButton();
  private JTextField mib = new JTextField();
  private JLabel jLabel5 = new JLabel();
  FileInputStream file;
  private JPanel jPanel1 = new JPanel();
  private JRadioButton Edit = new JRadioButton();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JRadioButton Delete = new JRadioButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private JLabel jLabel6 = new JLabel();
  private Border border2;
  private Border border3;

  public EditDevice1(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border3 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    this.setSize(new Dimension(900,600));
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border1,"DEVICE DETAIL");
    this.setLayout(null);
    Selectdevice.setBounds(new Rectangle(134, 75, 241, 29));
    Selectdevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectdevice_actionPerformed(e);
      }
    });
    Devicename.setBorder(border2);
    Devicename.setBounds(new Rectangle(168, 246, 315, 28));
    Deviceip.setBorder(border2);
    Deviceip.setBounds(new Rectangle(168, 297, 315, 28));
    Deviceid.setBorder(border2);
    Deviceid.setBounds(new Rectangle(168, 195, 315, 28));
    Deviceprotocol.setBounds(new Rectangle(168, 347, 315, 28));
    jLabel4.setText("DEVICE ID :");
    jLabel4.setBounds(new Rectangle(47, 195, 105, 29));
    jLabel3.setText("PROTOCOL :");
    jLabel3.setBounds(new Rectangle(47, 347, 83, 25));
    jLabel2.setText("IP ADRESS :");
    jLabel2.setBounds(new Rectangle(47, 297, 87, 24));
    jLabel1.setText("DEVICE NAME :");
    jLabel1.setBounds(new Rectangle(47, 246, 90, 26));
    Devicedetail.setBorder(titledBorder1);
    Devicedetail.setBounds(new Rectangle(555, 45, 328, 324));
    mibbrowse.setBounds(new Rectangle(605, 398, 124, 32));
    mibbrowse.setText("MIB BROWSE");
    mibbrowse.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        mibbrowse_actionPerformed(e);
      }
    });
    mib.setBorder(border2);
    mib.setBounds(new Rectangle(168, 398, 411, 28));
    jLabel5.setText("MIB :");
    jLabel5.setBounds(new Rectangle(47, 398, 69, 28));
    jPanel1.setBorder(border3);
    jPanel1.setBounds(new Rectangle(387, 44, 154, 69));
    jPanel1.setLayout(verticalFlowLayout1);
    Edit.setSelected(true);
    Edit.setText("EDIT");
    Edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_actionPerformed(e);
      }
    });
    Delete.setText("DELETE");
    Delete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete_actionPerformed(e);
      }
    });
    Ok.setBounds(new Rectangle(606, 519, 111, 32));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(742, 521, 98, 29));
    Cancel.setText("CANCEL");
    jLabel6.setText("SELECT DEVICE");
    jLabel6.setBounds(new Rectangle(27, 73, 100, 26));
    this.add(mibbrowse, null);
    this.add(jPanel1, null);
    jPanel1.add(Edit, null);
    jPanel1.add(Delete, null);
    this.add(Devicedetail, null);
    this.add(Ok, null);
    this.add(Cancel, null);
    this.add(jLabel6, null);
    this.add(Selectdevice, null);
    this.add(Deviceid, null);
    this.add(jLabel4, null);
    this.add(jLabel1, null);
    this.add(Devicename, null);
    this.add(jLabel2, null);
    this.add(Deviceip, null);
    this.add(jLabel3, null);
    this.add(Deviceprotocol, null);
    this.add(jLabel5, null);
    this.add(mib, null);
    Deviceprotocol.addItem("SNMP");
    Deviceprotocol.addItem("SOAP");

    //Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE");
      while (rs.next())
      {
        Selectdevice.addItem(rs.getString("DEVICEID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditDevice1 : " + sql);
    }
    buttonGroup1.add(Edit);
    buttonGroup1.add(Delete);

  }

  void Selectdevice_actionPerformed(ActionEvent e) {

    Deviceid.setText("");
    Devicename.setText("");
    Deviceip.setText("");
    mib.setText("");
    Deviceid.setEditable(false);
    Devicename.setEditable(false);
    Deviceip.setEditable(false);
    mib.setEditable(false);

    Deviceprotocol.setSelectedIndex(0);

    //Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE WHERE DEVICEID = '" + Selectdevice.getSelectedItem() + "'");
      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        devicename = rs.getString("DEVICENAME");
        deviceip = rs.getString("IP");
        mibfile = rs.getString("MIBFILE");
        deviceprotocol = rs.getString("PROTOCOL");

      }

      Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + deviceip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + deviceprotocol);
    }
    catch(SQLException sql)
    {
      System.out.println("EditDevice1 : " + sql);
    }
  }
  void mibbrowse_actionPerformed(ActionEvent e) {
    JFileChooser chooser = new JFileChooser();
    try {
      if ( chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
        //final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
        mib.setText(chooser.getSelectedFile().getAbsolutePath());
        FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
        file = mibFile;
      }
    }
    catch (Exception ex) {
      //setEnabled(true);
      System.err.println("Catch exception while parsing mib: " + ex );
    }
  }
  void Edit_actionPerformed(ActionEvent e) {
    //Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE WHERE DEVICEID = '" + Selectdevice.getSelectedItem() + "'");
      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        devicename = rs.getString("DEVICENAME");
        deviceip = rs.getString("IP");
        mibfile = rs.getString("MIBFILE");
        deviceprotocol = rs.getString("PROTOCOL");

      }

      Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + deviceip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + deviceprotocol);
    }
    catch(SQLException sql)
    {
      System.out.println("EditDevice1 : " + sql);
    }
    Deviceid.setText(deviceid);
    Devicename.setText(devicename);
    Deviceip.setText(deviceip);
    mib.setText(mibfile);
    Deviceid.setEditable(true);
    Devicename.setEditable(true);
    Deviceip.setEditable(true);
    mib.setEditable(true);
    Deviceprotocol.setSelectedItem(deviceprotocol);


  }

  void Delete_actionPerformed(ActionEvent e) {
    Deviceid.setText("");
    Devicename.setText("");
    Deviceip.setText("");
    mib.setText("");
    Deviceid.setEditable(false);
    Devicename.setEditable(false);
    Deviceip.setEditable(false);
    mib.setEditable(false);
    Deviceprotocol.setSelectedIndex(0);
  }

  void Ok_actionPerformed(ActionEvent e) {
    if (Edit.isSelected())
    {
      if (checkallblank())
      {
        //Database db = new Database();

        db.executeSQLupdate("UPDATE DEVICE SET DEVICENAME = '" + Devicename.getText() + "' , IP = '" + Deviceip.getText() + "' , MIBFILE = '" + mib.getText() + "' , PROTOCOL = '" + Deviceprotocol.getSelectedItem().toString() + "' WHERE DEVICEID = '" + Selectdevice.getSelectedItem().toString() + "'") ;

      }
    }
    else if (Delete.isSelected())
    {
      //Database db =new Database();

      db.executeSQLupdate("DELETE FROM DEVICE WHERE DEVICEID = '" + Selectdevice.getSelectedItem().toString() + "'");

    }
  }

  public boolean checkallblank()
  {
    if (Selectdevice.getSelectedItem().toString().compareTo("") !=0 && Devicename.getText().compareTo("") !=0 && Deviceip.getText().compareTo("") !=0 && mib.getText().compareTo("") !=0)
    {
      return true;

    }
    return false;
  }


}