package dms;
import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame3 extends JFrame {
  JButton jButton1 = new JButton();
  Connection dbCon;

  boolean flag=true;
  private Database db;
  private JButton jButton2 = new JButton();
  private JTextField jTextField1 = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JPasswordField jPasswordField1 = new JPasswordField();
  private JPasswordField jPasswordField2 = new JPasswordField();
  private JTextField jTextField2 = new JTextField();
  private JTextField jTextField3 = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel6 = new JLabel();

  public Frame3(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();

    }



  }
/*  public static void main(String[] args) {
  (new Frame3().setVisible(true));

  }*/
  private void jbInit() throws Exception {
    jButton1.setBounds(new Rectangle(223, 252, 76, 28));
    jButton1.setText("Add");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    jButton2.setBounds(new Rectangle(305, 252, 71, 29));
    jButton2.setText("cancel");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jTextField1.setBounds(new Rectangle(134, 47, 198, 29));
    jLabel1.setText("username");
    jLabel1.setBounds(new Rectangle(58, 126, 64, 32));
    jLabel2.setText("password");
    jLabel2.setBounds(new Rectangle(59, 162, 67, 29));
    jLabel3.setText("confirm password");
    jLabel3.setBounds(new Rectangle(27, 199, 102, 29));
    jPasswordField1.setBounds(new Rectangle(134, 164, 197, 27));
    jPasswordField2.setBounds(new Rectangle(133, 201, 197, 27));
    jTextField2.setBounds(new Rectangle(133, 86, 198, 29));
    jTextField3.setBounds(new Rectangle(134, 126, 198, 29));
    jLabel5.setText("Name");
    jLabel5.setBounds(new Rectangle(78, 42, 46, 34));
    jLabel4.setText("Sirname");
    jLabel4.setBounds(new Rectangle(67, 85, 48, 32));
    jLabel6.setText("Add user");
    jLabel6.setBounds(new Rectangle(13, 9, 183, 26));
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jPasswordField2, null);
    this.getContentPane().add(jPasswordField1, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jTextField3, null);
    this.getContentPane().add(jTextField2, null);
    this.getContentPane().add(jTextField1, null);
    this.getContentPane().add(jLabel4, null);
    this.getContentPane().add(jLabel5, null);
    this.getContentPane().add(jLabel6, null);
    setSize(500,400);

    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        setVisible(false);
        dispose();
        System.exit(0);
      }
    });
  }

  void jButton1_actionPerformed(ActionEvent e) {
  //------------------
    boolean ck=true;
    String name = jTextField1.getText();
    String sirname = jTextField2.getText();
    String username = jTextField3.getText();
    char[] ch =jPasswordField1.getPassword();
    char[] ch2 =jPasswordField2.getPassword();
    //String password = jPasswordField1.getPassword().toString();
    //String confirm = jPasswordField2.getPassword().toString();
    if (ch.length!=ch.length)
    {
      System.out.println("Password not match");
    }
    else
    {

       for(int i=0;i<ch.length;i++)
       {
         if (ch[i]!=ch2[i])
           ck=false;
       }
    }
    if (ck==false)
    {
      System.out.println("Password not match");
    }
    else if (ck==true)
    {

      db.executeSQLupdate("INSERT INTO usertable VALUES ('0000','"+name+"','"+sirname+"','"+username+"','"+ch+"')");
    }
    //System.out.println(password);
    //System.out.println(confirm);
    //if (password.compareTo(confirm)==0)
    //{
     //db.executeSQLupdate("INSERT INTO usertable VALUES ('0000','"+name+"','"+sirname+"','"+username+"','"+ch+"')");
    //}
    //else
    //{
    //  System.out.println("Password and confirm password do not match.");
    //}
     /*
        //-------------------
     ResultSet ss = db.executeSQLquery("SELECT PASSWORD FROM usertable");
     try{
     while (ss.next())
     {
       System.out.println(ss.getString("PASSWORD"));
     }
     }  catch(SQLException ee)
      {
        System.out.println("Your Username was already used. Please replace it and try again");
        System.out.println(ee.toString());
      }
*/
  }

  void a()
  {

    String name = jTextField1.getText();
    String sirname = jTextField2.getText();
    String username = jTextField3.getText();


    String password = jPasswordField1.getPassword().toString();
    String confirm = jPasswordField2.getPassword().toString();
  try
    {
      Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
      dbCon=DriverManager.getConnection("jdbc:odbc:DeviceManage");

    }
      catch(ClassNotFoundException e)
      {
        System.out.println("Error connecting DB");
        System.out.println(e.toString());
      }
      catch(SQLException e)
      {
        System.out.println("Error connecting DB");
        System.out.println(e.toString());
      }

      try{
       Statement s2 =dbCon.createStatement();
       s2.executeUpdate("INSERT INTO usertable VALUES ('0000','"+name+"','"+sirname+"','"+username+"','"+password+"')");
     }
     catch (SQLException sql)
        {
            System.out.println("Error connecting DB");
            System.out.println(sql.toString());
        }try{
       Statement s = dbCon.createStatement();
       ResultSet ss = s.executeQuery("SELECT USERNAME FROM usertable");

     }
     catch (SQLException sql)
        {
            System.out.println("Error connecting DB");
            System.out.println(sql.toString());
        }
//-------------------------------
/* try{
       Statement s2 =dbCon.createStatement();
       s2.executeUpdate("INSERT INTO usertable VALUES ('0000','"+name+"','"+sirname+"','"+username+"','"+password+"')");
     }
     catch (SQLException sql)
        {
            System.out.println("Error connecting DB");
            System.out.println(sql.toString());
        }*/
//-------------------------------

  }

  void jButton2_actionPerformed(ActionEvent e) {
      jTextField1.setText("");
      jTextField2.setText("");
      jTextField3.setText("");
      jPasswordField1.setText("");
      jPasswordField2.setText("");
  }



}
