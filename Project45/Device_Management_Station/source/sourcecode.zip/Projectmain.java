package dms;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Projectmain extends JInternalFrame implements TreeSelectionListener{
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTree jTree1 = new JTree();
  private JTree jTree2 = new JTree();
  private JButton jButton1 = new JButton();
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu project = new JMenu();
  private JMenu logoff = new JMenu();
  private JMenuItem tologoff = new JMenuItem();
  private JMenuItem toopen = new JMenuItem();
  private JMenuItem toclose = new JMenuItem();
  private String selectobject="";
  private String parentselectobject="";
  private String username="";
  private String projectname="";
  private Database db;
  FaultManagement fm;
  Desktop themain;
  private Logging gl;
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JMenu jMenu1 = new JMenu();
  private JMenuItem jMenuItem1 = new JMenuItem();
  private JMenuItem jMenuItem2 = new JMenuItem();
  private JLabel jLabel1 = new JLabel();
  public Projectmain(String pname,String uname,Desktop f,Database d) {
    db = d;
    username=uname;
    projectname=pname;
    themain=f;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /*
  public static void main(String[] args) {
    String pn="",un="";
    Projectmain projectmain = new Projectmain(pn,un);

    projectmain.setVisible(true);
  }*/
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    this.getContentPane().setLayout(null);
    this.setSize(new Dimension(700, 555));
    this.setTitle("Project's main page :("+projectname+" , user : "+username+")");
    this.getContentPane().setBackground(Color.lightGray);
    jScrollPane1.setBounds(new Rectangle(15, 53, 116, 360));
    jButton1.setBounds(new Rectangle(17, 424, 117, 26));
    jButton1.setText("SELECT");
    jScrollPane2.setBounds(new Rectangle(185, 17, 456, 500));
    jMenu1.setText("Data logging");
    jMenuItem1.setText("enable");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        logenable_actionPerformed(e);
      }
    });
    jMenuItem2.setText("disable");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        logdisable_actionPerformed(e);
      }
    });
    jLabel1.setBounds(new Rectangle(236, 2, 144, 16));
    this.getContentPane().add(jScrollPane1, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jScrollPane2, null);
    this.getContentPane().add(jLabel1, null);
    project.setText("Project");
    logoff.setText("Logoff");
    tologoff.setText("logoff");
    tologoff.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        tologoff_actionPerformed(e);
      }
    });
    logoff.add(tologoff);

    jMenuBar1.add(project);
    jMenuBar1.add(logoff);
    jMenuBar1.add(jMenu1);
    jMenu1.add(jMenuItem1);
    jMenu1.add(jMenuItem2);
     this.setJMenuBar(jMenuBar1);
    buildtree();
    themain.addframe(this);
  }
  public void tologoff_actionPerformed(ActionEvent ee)
  {
    String sdes = "User :"+username+" : LOGOFF";
    db.executeSQLupdate("INSERT INTO EVENT(EVENTNAME,EVENTDESCRIPTION,EVENTDATE,EVENTTIME) VALUES ('Logoff','"+sdes+"','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
    this.dispose();
  }
  public void logenable_actionPerformed(ActionEvent e)
  {
    ResultSet rs = db.executeSQLquery("SELECT * FROM SUPPORTGROUP WHERE PROJECTID='"+projectname+"'");
   int rowcount=0;
   try{
     while(rs.next())
     {
       rowcount++;
     }
   }catch(SQLException sql)
   {}
   String[] name = new String[rowcount];
   ResultSet rs2 = db.executeSQLquery("SELECT * FROM SUPPORTGROUP WHERE PROJECTID='"+projectname+"'");
  int x=0;
  try{
    while(rs2.next())
    {
      name[x]=rs2.getString(2);
      x++;
    }
  }catch(SQLException sql)
   {}
   Logging ll = new Logging(projectname,name,"1000",db);
   gl = ll;
   jLabel1.setText("Logging data enable");
   gl.start();
  }
  public void logdisable_actionPerformed(ActionEvent e)
 {
    jLabel1.setText("Logging data disable");
    gl.tostop();
  }
  public void valueChanged(TreeSelectionEvent ev)
{
       TreePath path=jTree1.getSelectionPath();
       TreePath parent=path.getParentPath();
       System.out.println("Selection path=" + path.toString());
       parentselectobject = parent.getLastPathComponent().toString();
       System.out.println(parentselectobject);

       System.out.println(jTree1.getLastSelectedPathComponent().toString());
       selectobject = jTree1.getLastSelectedPathComponent().toString();
       System.out.println("The object select is " + selectobject);
}
public void buildtree()
{

ResultSet rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM PROJECTDEVICE WHERE PROJECTID='"+projectname+"'");
//ResultSet rs2 = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM FAULT WHERE PROJECTID ='"+projectname+"'" );
MouseListener m1 = new MouseAdapter()
   {
     public void mouseClicked(MouseEvent e)
     {
       if(e.getClickCount()==2)
       {
         System.out.println("Double click");
        // if (parentselectobject.compareTo("Fault Management")==0)
         if (parentselectobject.compareTo("Fault Detection")==0)
         {
           DefaultMutableTreeNode root2 = new DefaultMutableTreeNode(selectobject);
           ResultSet rs3 = db.executeSQLquery("SELECT OBJECTID FROM FAULT WHERE DEVICEID='"+selectobject+"' AND PROJECTID='"+projectname+"'");
           try{
             while(rs3.next())
             {
               DefaultMutableTreeNode temp2 = new DefaultMutableTreeNode(rs3.getString("OBJECTID"));
               root2.add(temp2);
             }
           }catch(SQLException sql)
           {
             System.out.println("Error connecting Database");
           }
           jTree2 = new JTree(root2);
           fm = new FaultManagement(projectname,db);
           FaultPanel fp = new FaultPanel(jTree2,fm,projectname,selectobject,themain,db);
           jScrollPane2.getViewport().add(fp, null);
         }
        //----------------------------------Monitoring
         else if(selectobject.compareTo("Monitoring")==0)
         {
              MainPerformance1 mp= new MainPerformance1(projectname,themain,db);


              mp.setSize(new Dimension(800,600));
              mp.setVisible(true);
         }
         //----------------------------------Planning and Support
         else if(selectobject.compareTo("Planning and Support Management")==0)
         {
             Planandsupport ps = new Planandsupport(projectname,db);
             jScrollPane2.getViewport().add(ps,null);
         }
         //-----------------------------------Asset Management
         else if(selectobject.compareTo("Asset Management")== 0)
         {
             Assetpanel ap = new Assetpanel(projectname,db);
              jScrollPane2.getViewport().add(ap,null);
         }
       }

     }
  };
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("Project");
  DefaultMutableTreeNode pmm = new DefaultMutableTreeNode("Monitoring");
  DefaultMutableTreeNode fmm = new DefaultMutableTreeNode("Fault Detection");
  DefaultMutableTreeNode psmm = new DefaultMutableTreeNode("Planning and Support Management");
  DefaultMutableTreeNode amm = new DefaultMutableTreeNode("Asset Management");
  root.add(pmm);
  root.add(fmm);
  root.add(psmm);
  root.add(amm);
    jScrollPane1.getViewport().add(jTree1, null);
  try{
  while (rs.next())
  {
    //pmm.add(new DefaultMutableTreeNode(rs.getString("DEVICEID")));
    DefaultMutableTreeNode temp = new DefaultMutableTreeNode(rs.getString("DEVICEID"));
    pmm.add(temp);
  }
  }catch(SQLException sql)
  {
    System.out.println("Error connecting Database");
  }
  ResultSet rs2 = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM FAULT WHERE PROJECTID ='"+projectname+"'" );
  try{
    while(rs2.next())
    {
      DefaultMutableTreeNode temp1 = new DefaultMutableTreeNode(rs2.getString("DEVICEID"));
      fmm.add(temp1);
    }
  }catch (SQLException sql1)
  {
    System.out.println("Error Connecting Database");
  }
  ResultSet rs3 = db.executeSQLquery("SELECT GROUPID FROM SUPPORTGROUP WHERE PROJECTID ='"+projectname+"'" );
  try{
    while(rs3.next())
    {
      DefaultMutableTreeNode temp2 = new DefaultMutableTreeNode(rs3.getString("GROUPID"));
      psmm.add(temp2);
    }
  }catch (SQLException sql1)
  {
    System.out.println("Error Connecting Database");
  }
  jTree1 = new JTree(root);
  jTree1.addMouseListener(m1);
  jTree1.addTreeSelectionListener(this);
  jScrollPane1.getViewport().add(jTree1, null);
  jScrollPane1.setBounds(new Rectangle(9, 16, 160, 500));


}

  void jButton2_actionPerformed(ActionEvent e) {
      this.dispose();
  }

}