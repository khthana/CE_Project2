package dms;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Logging extends Thread{
  private String projectname;
  private Thread kicker=null;
  private boolean dead = false;
  private String refresh;
  String[] loggroup;
  private Database db;
  MessageHandler mh;
  public Logging(String pname,String[] group,String rrate,Database d) {
    projectname = pname;
    loggroup = group;
    refresh = rrate;
    db = d;
    mh = new MessageHandler(db);
  }


   public synchronized void tostop() {
        dead = true;
   }
   public void run()
   {
     int numgroup =loggroup.length;
     ResultSet rs = db.executeSQLquery("SELECT * FROM MONITORGROUP");
     int rowcount=0;
     try{
       while(rs.next())
       {
         rowcount++;
       }
     }
     catch(SQLException sql)
     {}
     /*
     String[][] logall = new String[rowcount][3];
     ResultSet rs2 = db.executeSQLquery("SELECT * FROM MONITORGROUP");
     int x=0;
     try{
       while(rs.next())
       {
         logall[x][0]=rs.getString(1);
         logall[x][1]=rs.getString(2);
         logall[x][2]=rs.getString(3);
         x++;
       }
     }
     catch(SQLException sql)
     {}*/
    while(!dead)
    {
 /*     try {
                     Thread.currentThread().sleep(Integer.parseInt(refresh));
     }
     catch (Exception e) {
     }*/
    for(int i=0;i<numgroup;i++)
    {
      ResultSet rs3 = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID ='"+loggroup[i]+"'");
      int gnum=0;
      try{
        while(rs3.next())
        {
          gnum++;
        }

      }catch(SQLException sql)
      {}
      String[] value = new String[gnum];
      ResultSet rs4 = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID ='"+loggroup[i]+"'");
      int w=0;
      String statement = "";
      //----------
      String temp="";
      //----------
      try{
        while(rs4.next())
        {
          String devicename = rs4.getString(2);
          String objectname = rs4.getString(3);
          statement= statement.concat(devicename+objectname+",");
          mh.constructMessage(devicename,objectname,"GET","","","");
          mh.sendMessage();
          try {
            Thread.currentThread().sleep(Integer.parseInt(refresh));
          }
          catch (Exception e) {
          }
          temp=mh.recieveMessage();
          value[w]= temp;

          if(value[w].compareTo("*")!=0)
          {
          w++;
          }
        }
      }catch(SQLException sql)
      {}
      String statement2="";
      for(int m=0;m<gnum;m++)
       {
         statement2= statement2.concat(value[m]+"','");
       }
       if(temp.compareTo("*")!=0)
       {
       db.executeSQLupdate("INSERT INTO "+projectname+"_"+loggroup[i]+"_"+"LOG"+" (PROJECTID,GROUPID,"+statement+"THEDATE,THETIME)VALUES ('"+projectname+"','"+loggroup[i]+"','"+statement2+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
       }
    }
   }
}
}
