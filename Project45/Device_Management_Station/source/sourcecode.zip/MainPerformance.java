package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import com.klg.jclass.util.swing.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MainPerformance extends JFrame {
  JButton jButton1 = new JButton();
  List Grouplist = new List();
  private Database db;
  ResultSet rs;
  FrameGraph u;
  FrameGraph u2;
  //-------------Edit Muen
  private String projectid;
  public String groupname;
  //-------------Edit Muen
  private JButton jButton2 = new JButton();
  public MainPerformance(String pid,Database d) {
    db = d;
    //-----------Edit Muen
    projectid = pid;
    System.out.println(projectid);
    //-----------Edit Muen
    try {
      jbInit();

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    //-----------------------Edit Muen---
    rs = db.executeSQLquery("SELECT * FROM PROJECTGROUP WHERE PROJECTID='"+projectid+"'");
    //-----------------------Edit Muen---
    while(rs.next())
    {
      Grouplist.add(rs.getString("GROUPID"));
    }
    this.getContentPane().setLayout(null);
    jButton1.setBounds(new Rectangle(267, 106, 123, 27));
    jButton1.setText("jButton1");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    Grouplist.setBounds(new Rectangle(53, 39, 147, 194));
    jButton2.setBounds(new Rectangle(268, 154, 123, 30));
    jButton2.setText("jButton2");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(Grouplist, null);
    this.getContentPane().add(jButton2, null);

  }

  void jButton1_actionPerformed(ActionEvent e) {

    int numofdevice = 0;
    String groupid = Grouplist.getSelectedItem();
    groupname = Grouplist.getSelectedItem();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println("aa"  + ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];

    String[][] deviceobjectid= new String[numofdevice][6];
    // 0 deviceid 1 objectid 2 faultonit 3 howtocheck 4 lower/equal 5 upper
    System.out.println(numofdevice);
    for(int q=0;q<numofdevice;q++)
    {
      for(int s=0;s<6;s++)
      {
        deviceobjectid[q][s]="";
      }
    }
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println("bb"+ex);
    }
//--------------------------------------------------------------------------------------
    int k=i;

    rs = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID='"+projectid+"'");
    try{
    while (rs.next())
    {
      String did = rs.getString("DEVICEID");
      String oid = rs.getString("OBJECTID");

      String fv = rs.getString("FAULTVALUE");
      String fv2= rs.getString("FAULTVALUE2");
      String fc = rs.getString("FAULTCHECK");


       for(int j=0;j<k;j++)
                 { System.out.println(did);
       System.out.println(deviceobjectid[j][0]);
             System.out.println(oid);
             System.out.println(deviceobjectid[j][1]);
             System.out.println(fv);
             System.out.println(fv2);
      System.out.println(fc);

         if((deviceobjectid[j][0].compareTo(did)==0)&&(deviceobjectid[j][1].compareTo(oid)==0))
          {
            deviceobjectid[j][2]="yes";
            deviceobjectid[j][3]= fc;
            deviceobjectid[j][4]= fv;
            deviceobjectid[j][5]= fv2;

          }
        else if(deviceobjectid[j][2].compareTo("yes")!=0){

            deviceobjectid[j][2]="no";
            deviceobjectid[j][3]="";
            deviceobjectid[j][4]="";
            deviceobjectid[j][5]="";
          }
          }
    }
          }catch(SQLException exx)
    {System.out.println(exx);}


//----------------------------------------------------------------------------------------
/*
    FrameGraph u = new FrameGraph(3,name,deviceobjectid,"plot");

    u.show();



    FrameGraph u2 = new FrameGraph(2,name,deviceobjectid,"plot");

    u2.show();
*/
    JCExitFrame f = new JCExitFrame("Monitoring");
    //JInternalFrame f = new JInternalFrame("MONITORING");
    StripChart s = new StripChart(numofdevice,name,deviceobjectid,"plot",projectid,groupname,db);
    s.passframe(f);
    f.getContentPane().add("Center",s);
    f.pack();
    f.setVisible(true);
  }

  void jButton2_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedItem();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println("aa"  + ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println("cc"+ex);
    }
    //FrameTable f = new FrameTable(numofdevice,name,deviceobjectid);

    //f.show();

  }
}