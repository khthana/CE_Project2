package dms;
//import java.util.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class testdate {

  public testdate() {
    tuu();
  }
  public static void main(String[] args) {
    testdate testdate1 = new testdate();

  }
  public void tuu()
  {
     //Date d = new Date(System.currentTimeMillis());
    Date d = Date.valueOf("2003-01-26");
    Date d2 = Date.valueOf("2003-01-26");
    //d.setTime(System.currentTimeMillis());
    System.out.println(d.compareTo(d2));
     tuu2();
  }
  public void tuu2()
  {
      Time t =new Time(System.currentTimeMillis());
      System.out.println(t.toString());
  }
}