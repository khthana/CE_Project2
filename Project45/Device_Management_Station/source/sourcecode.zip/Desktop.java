package dms;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Desktop extends JFrame {
  private Database db;
  private JPanel contentPane;
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenuFile = new JMenu();
  private JMenu jMenuProject = new JMenu();
  private JMenu jMenuLogin= new JMenu();
  private JMenuItem jMenuFileExit = new JMenuItem();
  private JMenu jMenuHelp = new JMenu();
  private JMenuItem loginUser = new JMenuItem();
  private JMenuItem jMenuHelpAbout = new JMenuItem();
  private JMenuItem loginAdmin = new JMenuItem();
  //---------------
  private JToolBar jToolBar = new JToolBar();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JButton jButton3 = new JButton();
  private ImageIcon image1;
  private ImageIcon image2;
  private ImageIcon image3;
  private JLabel statusBar = new JLabel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private Panelx jPanel1 = new Panelx();
  private JMenu jMenu1 = new JMenu();
  private JMenuItem jMenuItem1 = new JMenuItem();
  private JMenuItem jMenuItem2 = new JMenuItem();
  private JMenuItem jMenuItem4 = new JMenuItem();
  private JMenu jMenu2 = new JMenu();
  private JMenuItem jMenuItem3 = new JMenuItem();
  private JMenuItem jMenuItem5 = new JMenuItem();
  public  JDesktopPane desktop;
  private JMenu jMenu3 = new JMenu();
  private JMenuItem jMenuItem6 = new JMenuItem();
  //Construct the frame
  public Desktop() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  //Component initialization
  private void jbInit() throws Exception  {
    image1 = new ImageIcon(dms.Desktop.class.getResource("openFile.gif"));
    image2 = new ImageIcon(dms.Desktop.class.getResource("closeFile.gif"));
    image3 = new ImageIcon(dms.Desktop.class.getResource("help.gif"));
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Frame7.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(1024, 768));
    this.setTitle("Device Management Station");
    statusBar.setText(" ");
    jMenuLogin.setText("Login");
    loginUser.setText("Login as user");
    loginUser.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          loginUser_actionPerformed(e);
        }
    }
    );
    loginAdmin.setText("Login as Administrator");
    loginAdmin.addActionListener(new java.awt.event.ActionListener() {
       public void actionPerformed(ActionEvent e) {
         loginAdmin_actionPerformed(e);
       }
    }

                                 );
    jMenuProject.setText("Project");
    jMenuProject.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuProject_actionPerformed(e);
      }
    });
    jMenuFile.setText("File");
    jMenuFileExit.setText("Exit");
    jMenuFileExit.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuFileExit_actionPerformed(e);
      }
    });
    jMenuHelp.setText("Help");
    jMenuHelpAbout.setText("About");
    jMenuHelpAbout.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuHelpAbout_actionPerformed(e);
      }
    });
    jButton1.setIcon(image1);
    jButton1.setToolTipText("Open File");
    jButton2.setIcon(image2);
    jButton2.setToolTipText("Close File");
    jButton3.setIcon(image3);
    jButton3.setToolTipText("Help");
    jMenu1.setText("CCL Project");
    jMenuItem1.setText("open");
    jMenuItem2.setText("About");
    jMenu2.setText("Manage Project");
    jMenuItem3.setText("Configaration");
    jMenuItem3.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuItem3_actionPerformed(e);
      }
    });
    jMenuItem6.addActionListener(new java.awt.event.ActionListener()  {
      public void actionPerformed(ActionEvent e) {
        jMenuItem6_actionPerformed(e);
      }
    });
    jMenuItem5.setText("Edit configuration");
   //
    jMenu3.setText("Connect Database");
    jMenuItem6.setActionCommand("");
    jMenuItem6.setText("Connect");
    jToolBar.add(jButton1);
    jToolBar.add(jButton2);
    jToolBar.add(jButton3);
    jMenuFile.add(jMenuFileExit);
    jMenuFile.add(jMenu2);
    jMenuFile.add(jMenuItem4);
    jMenuHelp.add(jMenuHelpAbout);
    jMenuLogin.add(loginUser);
    jMenuLogin.add(loginAdmin);
    jMenuBar1.add(jMenuFile);
    jMenuBar1.add(jMenuHelp);
    jMenuBar1.add(jMenuProject);
    jMenuBar1.add(jMenuLogin);
    jMenuBar1.add(jMenu3);
    this.setJMenuBar(jMenuBar1);
    contentPane.add(jToolBar, BorderLayout.NORTH);
    contentPane.add(statusBar, BorderLayout.SOUTH);
    //contentPane.add(jPanel1, BorderLayout.CENTER);
    desktop = new JDesktopPane();
    desktop.setBackground(Color.gray);
    contentPane.add(desktop,BorderLayout.CENTER);
    jMenuProject.add(jMenu1);
    jMenu1.add(jMenuItem1);
    jMenu1.add(jMenuItem2);
    jMenu2.add(jMenuItem3);
    jMenu2.add(jMenuItem5);
    jMenu3.add(jMenuItem6);

  }

  //Connect database
  public void jMenuItem6_actionPerformed(ActionEvent e){

    DBLogin f = new DBLogin("Database Connect",true,this);
    f.setSize(400,350);

    f.setVisible(true);
    this.addframe(f);
    //db = f.getDB();

  }
  //File | Exit action performed
  public void jMenuFileExit_actionPerformed(ActionEvent e) {
    System.exit(0);
  }
  //Help | About action performed
  public void jMenuItem3_actionPerformed(ActionEvent e)
  {
    AdminLogin adml = new AdminLogin("Admin login",true,this,db);
    adml.setSize(350,350);
    this.addframe(adml);
    adml.show();
  }
  public void jMenuHelpAbout_actionPerformed(ActionEvent e) {
    Desktop_AboutBox dlg = new Desktop_AboutBox(this);
    Dimension dlgSize = dlg.getPreferredSize();
    Dimension frmSize = getSize();
    Point loc = getLocation();
    dlg.setLocation((frmSize.width - dlgSize.width) / 2 + loc.x, (frmSize.height - dlgSize.height) / 2 + loc.y);
    dlg.setModal(true);
    dlg.pack();
    dlg.show();
  }
  public void loginAdmin_actionPerformed(ActionEvent e)
  {
   AdminLogin al = new AdminLogin("Admin login",true,this,db);
   this.addframe(al);
    al.setSize(350,350);
    al.show();

  }
  public void jMenuProject_actionPerformed(ActionEvent e)
  {

  }
  public void loginUser_actionPerformed(ActionEvent e)
  {
       UserLogin ul = new UserLogin("UserLogin",true,this,db);
       ul.setSize(350,350);
       ul.setVisible(true);
       desktop.add(ul);
       //ul.show();
  }
  //Overridden so we can exit when window is closed
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      jMenuFileExit_actionPerformed(null);
    }
  }
  public void addframe(JInternalFrame jif)
  {
    desktop.add(jif);
  }
  public void setDB(Database d)
  {
    db = d;
  }

}