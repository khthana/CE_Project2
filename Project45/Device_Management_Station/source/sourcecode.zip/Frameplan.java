package dms;

import java.awt.*;
import javax.swing.JFrame;
import com.klg.jclass.chart.beans.*;
import com.klg.jclass.chart.db.jbuilder.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frameplan extends JFrame {
  private SimpleChart simpleChart1 = new SimpleChart();
  String[][] serie;
  String rowcount;
  String columncount;
 //   public Frameplan(){
 public Frameplan(String[][] seriev,String rowc,String colc) {
    try {
      serie =seriev;
     rowcount = rowc;
     columncount = colc;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.getContentPane().add(simpleChart1, BorderLayout.CENTER);
   this.setVisible(true);
    String sdata="";
    String tailnum="";
    String allserie="";
    String cserie="";
    for(int i=0;i<Integer.parseInt(rowcount);i++)
    {
      String t="";
      t = Integer.toString(i);
      t = t.concat(".0");
      tailnum = tailnum.concat(t+" ");

    }
    cserie="";
    for(int j=0;j<Integer.parseInt(columncount);j++)
    {

      String aserie="'Series"+Integer.toString(j+1)+"' ";
      for(int z=0;z<Integer.parseInt(rowcount);z++)
      {
         // aserie = aserie.concat(serie[j][z]+".0 ");
        aserie = aserie.concat(serie[j][z]+" ");
      }
      cserie = cserie.concat(aserie);
    }
    System.out.println(tailnum);
    System.out.println(cserie);

    sdata = "ARRAY 'Muen' "+columncount+" "+rowcount+" "+tailnum+cserie;
    simpleChart1.setData(sdata);
    //simpleChart1.setData("ARRAY 'Muen' 4 5 'Point Label0' 'Point Label1' 'Point Label2' 'Point Label3' 'Point Label4' '' 0.0 1.0 2.0 3.0 4.0 'Series1' 1.0 22.0 19.0 24.0 25.0 'Series2' 2.0 12.0 10.0 12.0 15.0 'Series3' 3.0 16.0 17.0 15.0 23.0 'Series4' 4.0 19.0 15.0 22.0 18.0" );
    //simpleChart1.setData("ARRAY 'Muen' 4 5 0.0 1.0 2.0 3.0 4.0 'Series1' 1.0 22.0 19.0 24.0 25.0 'Series2' 2.0 12.0 10.0 12.0 15.0 'Series3' 3.0 16.0 17.0 15.0 23.0 'Series4' 4.0 19.0 15.0 22.0 18.0" );

  }
/* public static void main(String[] argv)
  {
    Frameplan f5 = new Frameplan();
    f5.show();

  }*/
}