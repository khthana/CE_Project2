package dms;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Testnumber {
  String hh="a";
  public Testnumber() {
    test();
  }
  public static void main(String[] args) {
    Testnumber testnumber1 = new Testnumber();
  }
  public void test()
  {
    int j=Integer.parseInt(hh);
    System.out.println(j);
  }

}