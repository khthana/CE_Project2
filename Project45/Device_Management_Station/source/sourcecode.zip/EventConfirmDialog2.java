package dms;

import java.awt.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EventConfirmDialog2 extends JDialog {
  private JPanel panel1 = new JPanel();
  private JLabel jLabel1 = new JLabel();

  public EventConfirmDialog2(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public EventConfirmDialog2(String dyear,String month,String date) {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jLabel1.setText("jLabel1");
    jLabel1.setBounds(new Rectangle(44, 34, 333, 57));
    getContentPane().add(panel1);
    panel1.add(jLabel1, null);
  }
}