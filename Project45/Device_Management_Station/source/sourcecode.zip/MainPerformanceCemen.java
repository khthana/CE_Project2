package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import com.klg.jclass.util.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MainPerformanceCemen extends JInternalFrame {
  private Desktop themain;
  JButton Graph = new JButton();
  List Grouplist = new List();
  private Database db;
  ResultSet rs;
  //FrameGraph u;
  //FrameGraph u2;
  private String projectid;
  public String groupname;
  private JButton Text = new JButton();
  private JButton Picture = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JButton Cemen = new JButton();
  private JMenuBar jMenuBar1 = new JMenuBar();
  //private PanelPicture panelpicture;
  private PanelCemen panelcemen;
  private JPanel jPanel1 = new JPanel();
  private PaneLayout paneLayout2 = new PaneLayout();
  private Border border1;
  private JButton Select = new JButton();
  public MainPerformanceCemen(String pid,Desktop tm,Database d) {
    try {
      db = d;
      themain = tm;
      projectid = pid;
      jbInit();
      panelcemen.repaint();
      jPanel1.setVisible(true);
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    jPanel1.setVisible(false);
    rs = db.executeSQLquery("SELECT * FROM PROJECTGROUP WHERE PROJECTID = '" + projectid + "'");
    while(rs.next())
    {
      Grouplist.add(rs.getString("GROUPID"));
    }
    border1 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158)),"ALL DEVICE FOR THIS PROJECT");
    this.getContentPane().setLayout(null);
    Graph.setBounds(new Rectangle(95, 578, 68, 27));
    Graph.setText("Graph");
    Graph.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Graph_actionPerformed(e);
      }
    });
    Grouplist.setBounds(new Rectangle(18, 44, 151, 472));
    Text.setBounds(new Rectangle(95, 626, 68, 30));
    Text.setText("Text");
    Text.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Text_actionPerformed(e);
      }
    });
    Picture.setBounds(new Rectangle(95, 676, 68, 27));
    Picture.setText("Picture");
    Picture.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Picture_actionPerformed(e);
      }
    });
    jLabel1.setText("Group");
    jLabel1.setBounds(new Rectangle(17, 14, 148, 29));
    Cemen.setBounds(new Rectangle(95, 715, 68, 25));
    Cemen.setText("Cemen");
    Cemen.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cemen_actionPerformed(e);
      }
    });
    jPanel1.setBorder(border1);
    jPanel1.setBounds(new Rectangle(192, 9, 821, 751));
    jPanel1.setLayout(paneLayout2);

    int numofdevice = 0;
    //String groupid = Grouplist.getSelectedItem();
    //System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM PROJECTDEVICE WHERE PROJECTID = '"+ projectid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    rs = db.executeSQLquery("SELECT * FROM PROJECTDEVICE WHERE PROJECTID = '" + projectid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    int countdevice = 0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM PROJECTDEVICE WHERE PROJECTID = '" + projectid + "'");
    try
    {
      while (rs.next())
      {
        countdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    String[] device = new String[countdevice];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM PROJECTDEVICE WHERE PROJECTID = '" + projectid + "'");
    i = 0;
    try
    {
      while (rs.next())
      {
        device[i] = rs.getString("DEVICEID");
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    //panelpicture = new PanelPicture(numofdevice,name,deviceobjectid,countdevice,device,projectid);
    panelcemen = new PanelCemen(numofdevice,name,deviceobjectid,countdevice,device,projectid,themain,db);
    Select.setBounds(new Rectangle(19, 534, 97, 28));
    Select.setText("SELECT");
    Select.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Select_actionPerformed(e);
      }
    });

    //jPanel1.add(panelpicture, new PaneConstraints("panelpicture", "panelpicture", PaneConstraints.ROOT, 0.5f));
    jPanel1.add(panelcemen, new PaneConstraints("panelpicture", "panelpicture", PaneConstraints.ROOT, 0.5f));
    this.getContentPane().add(Grouplist, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(Select, null);
    this.getContentPane().add(Graph, null);
    this.getContentPane().add(Text, null);
    this.getContentPane().add(Picture, null);
    this.getContentPane().add(Cemen, null);
    this.getContentPane().add(jPanel1, null);
    this.setSize(new Dimension(800,600));


  }

  void Graph_actionPerformed(ActionEvent e) {


    String groupid = Grouplist.getSelectedItem();
    int numofdevice = 0;
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println("aa"  + ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

/*
    FrameGraph u = new FrameGraph(3,name,deviceobjectid,"plot");

    u.show();



    FrameGraph u2 = new FrameGraph(2,name,deviceobjectid,"plot");

    u2.show();
*/
    JCExitFrame f = new JCExitFrame("Strip Chart Demo");
    StripChart s = new StripChart(numofdevice,name,deviceobjectid,"plot",projectid,groupname,db);
    f.getContentPane().add("Center",s);
    f.pack();
    f.setVisible(true);
  }

  void Text_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedItem();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println("aa"  + ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    FrameText f = new FrameText(numofdevice,name,deviceobjectid,groupid,projectid,themain,db);
    f.pack();
    f.setVisible(true);

  }

  void Picture_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedItem();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    int countdevice = 0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    try
    {
      while (rs.next())
      {
        countdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    String[] device = new String[countdevice];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    i = 0;
    try
    {
      while (rs.next())
      {
        device[i] = rs.getString("DEVICEID");
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    FramePicture f = new FramePicture(numofdevice,name,deviceobjectid,countdevice,device,projectid,themain,db);
    f.pack();
    f.setVisible(true);

  }

  void Cemen_actionPerformed(ActionEvent e) {
    int numofdevice = 0;
    String groupid = Grouplist.getSelectedItem();
    System.out.println(groupid);
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
    try
    {
      while (rs.next())
      {
        numofdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    String[] name = new String[numofdevice];
    String[][] deviceobjectid= new String[numofdevice][2];
    System.out.println(numofdevice);
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceobjectid[i][0] = rs.getString("DEVICEID");
        deviceobjectid[i][1] = rs.getString("OBJECTID");
        name[i] = deviceobjectid[i][1];
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    int countdevice = 0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    try
    {
      while (rs.next())
      {
        countdevice = rs.getInt(1);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    String[] device = new String[countdevice];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
    i = 0;
    try
    {
      while (rs.next())
      {
        device[i] = rs.getString("DEVICEID");
        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    FrameCemen f = new FrameCemen(numofdevice,name,deviceobjectid,countdevice,device,projectid,themain,db);
    f.pack();
    f.setVisible(true);
  }

  void Select_actionPerformed(ActionEvent e) {
    String groupid = Grouplist.getSelectedItem();
 //   Database db = new Database();
    String monitortype = "";
    String monitorvalue = "";

    ResultSet rs = db.executeSQLquery("SELECT * FROM MONITOR WHERE GROUPID = '" + groupid + "'");
    try
    {
      while (rs.next())
      {
        monitortype = rs.getString("MONITORTYPE");
        monitorvalue = rs.getString("MONITORVALUE");
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }



    if (monitortype.compareTo("text") == 0)
    {
      int numofdevice = 0;

      System.out.println(groupid);
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
      try
      {
        while (rs.next())
        {
          numofdevice = rs.getInt(1);
        }
      }
      catch(SQLException ex)
      {
        System.out.println("aa"  + ex);
      }
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
      String[] name = new String[numofdevice];
      String[][] deviceobjectid= new String[numofdevice][2];
      System.out.println(numofdevice);
      int i=0;
      try
      {
        while (rs.next())
        {
          deviceobjectid[i][0] = rs.getString("DEVICEID");
          deviceobjectid[i][1] = rs.getString("OBJECTID");
          name[i] = deviceobjectid[i][1];
          i++;
        }
      }
      catch(SQLException ex)
      {
        System.out.println(ex);
      }
      FrameText f = new FrameText(numofdevice,name,deviceobjectid,groupid,projectid,themain,db);
      f.pack();
      f.setVisible(true);
    }
    else if (monitortype.compareTo("table") == 0)
    {

    }
    else if (monitortype.compareTo("graph") == 0)
    {
      int numofdevice = 0;
      System.out.println(groupid);
      rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '"+ groupid + "'");
      try
      {
        while (rs.next())
        {
          numofdevice = rs.getInt(1);
        }
      }
      catch(SQLException ex)
      {
        System.out.println("aa"  + ex);
      }
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + groupid + "'");
      String[] name = new String[numofdevice];
      String[][] deviceobjectid= new String[numofdevice][2];
      System.out.println(numofdevice);
      int i=0;
      try
      {
        while (rs.next())
        {
          deviceobjectid[i][0] = rs.getString("DEVICEID");
          deviceobjectid[i][1] = rs.getString("OBJECTID");
          name[i] = deviceobjectid[i][1];
          i++;
        }
      }
      catch(SQLException ex)
      {
        System.out.println(ex);
      }


      JCExitFrame f = new JCExitFrame("Strip Chart Demo");
      StripChart s = new StripChart(numofdevice,name,deviceobjectid,monitorvalue,projectid,groupname,db);
      f.getContentPane().add("Center",s);
      f.pack();
      f.setVisible(true);
    }



  }
}
