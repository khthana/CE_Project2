package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Userconfig1 extends JPanel {
  JTextField Userid = new JTextField();
  JTextField Username = new JTextField();
  JTextField Division = new JTextField();
  JPasswordField Password = new JPasswordField();
  JPasswordField Confirmpass = new JPasswordField();
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JRadioButton Typeuser = new JRadioButton();
  JRadioButton Typeadmin = new JRadioButton();
  Box box1;

  public Userconfig1() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    box1 = Box.createVerticalBox();
    Userid.setBounds(new Rectangle(176, 37, 235, 29));
    this.setLayout(null);
    Username.setBounds(new Rectangle(177, 89, 236, 30));
    Division.setBounds(new Rectangle(181, 144, 233, 31));
    Password.setBounds(new Rectangle(181, 197, 232, 29));
    Confirmpass.setBounds(new Rectangle(182, 249, 230, 32));
    jLabel1.setText("USERID");
    jLabel1.setBounds(new Rectangle(29, 37, 119, 28));
    jLabel2.setText("USERNAME");
    jLabel2.setBounds(new Rectangle(27, 94, 103, 27));
    jLabel3.setText("DIVISION");
    jLabel3.setBounds(new Rectangle(29, 145, 98, 25));
    jLabel4.setText("PASSWORD");
    jLabel4.setBounds(new Rectangle(26, 200, 106, 28));
    jLabel5.setText("CONFIRM PASSWORD");
    jLabel5.setBounds(new Rectangle(29, 258, 139, 23));
    jLabel6.setText("TYPE");
    jLabel6.setBounds(new Rectangle(28, 315, 117, 31));
    Typeuser.setText("USER");
    Typeuser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Typeuser_actionPerformed(e);
      }
    });
    Typeadmin.setSelected(true);
    Typeadmin.setText("ADMINISTRATOR");
    Typeadmin.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Typeadmin_actionPerformed(e);
      }
    });
    box1.setBounds(new Rectangle(186, 317, 119, 74));
    this.add(Userid, null);
    this.add(Username, null);
    this.add(Division, null);
    this.add(Password, null);
    this.add(Confirmpass, null);
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    this.add(jLabel3, null);
    this.add(jLabel4, null);
    this.add(jLabel5, null);
    this.add(jLabel6, null);
    this.add(box1, null);
    box1.add(Typeadmin, null);
    box1.add(Typeuser, null);
  }

  void Typeuser_actionPerformed(ActionEvent e) {
    if (Typeuser.isSelected() == false)
    {
      Typeuser.setSelected(false);
      Typeadmin.setSelected(true);
    }
    else
    {
      Typeuser.setSelected(true);
      Typeadmin.setSelected(false);
    }


  }

  void Typeadmin_actionPerformed(ActionEvent e) {
    if (Typeadmin.isSelected() == false)
    {
      Typeadmin.setSelected(false);
      Typeuser.setSelected(true);
    }
    else
    {
      Typeadmin.setSelected(true);
      Typeuser.setSelected(false);
    }
  }

  public boolean isPasswordCorrect(char[] input,char[] input2) {

    if (input.length != input2.length)
         return false;
    for (int i = 0;  i < input.length; i ++)
        if (input[i] != input2[i])
          return false;
    return true;
  }

  public String PasswordToString(char[] input)
  {
    String password = new String();
    String temp;
    password.copyValueOf(input);
    /*for (int i = 0;  i < input.length; i ++)
    {
      temp.copyValueOf(input[i]);
      password.concat(temp);

    }*/
    return password;
  }

}