package dms;

import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.sql.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Config1 extends JPanel {
  //PaneLayout paneLayout1 = new PaneLayout();
  //JPanel jPanel1 = new JPanel();
  JTextField Projectname = new JTextField();
  JLabel jLabel1 = new JLabel();
  List Deviceidlist = new List();
  private JButton Add = new JButton();
  List Deviceselectlist = new List();
  private Database db;
  JTextField Projectdescription = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JButton jButton1 = new JButton();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JLabel jLabel7 = new JLabel();
  private JTextArea Devicedetail = new JTextArea();
  private Border border1;
  private Border border2;
  private Border border3;
  private Border border4;
  private TitledBorder titledBorder1;
  private Border border5;
  private Border border6;
  private Border border7;
  private Border border8;
  private Border border9;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private Border border10;
  private Border border11;
  private JPanel jPanel1 = new JPanel();
  private Border border12;
  JTextField Projectid = new JTextField();
  private Border border13;
  private JLabel jLabel2 = new JLabel();


  public Config1(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
 /* public static void main(String arg[])
  {

    Config1 a = new Config1();

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = a.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    a.setSize(frameSize.width,frameSize.height);
    a.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    a.setVisible(true);
  }*/
  private void jbInit() throws Exception {
    //this.getContentPane().setLayout(paneLayout1);
    //jPanel1.setLayout(null);
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    border2 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178)),"DEVICE DETAIL");
    border3 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    border4 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178)),"");
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    border7 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    border8 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158)),"");
    border9 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    border10 = BorderFactory.createCompoundBorder(BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158)),BorderFactory.createEmptyBorder(6,6,6,6));
    border11 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    border12 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158)),"PROJECT INFORMATION");
    border13 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    this.setSize(new Dimension(1000,700));
    this.setLayout(null);
    Projectname.setBorder(border5);
    Projectname.setBounds(new Rectangle(178, 89, 270, 31));
    jLabel1.setBorder(border11);
    jLabel1.setText("Project Name");
    jLabel1.setBounds(new Rectangle(31, 89, 125, 31));
    //jPanel1.add(jLabel1, null);
    //jPanel1.add(projectname, null);
    //jPanel1.add(Next, null);
    //jPanel1.add(Finished, null);
    //jPanel1.add(Cancle, null);
    //this.setLayout(null);
    //this.add(jTextField1, null);
    //this.getContentPane().add(jPanel1, new PaneConstraints("jPanel1", "jPanel1", PaneConstraints.ROOT, 0.5f));
    Add.setBounds(new Rectangle(349, 403, 96, 34));
    Add.setBorder(border6);
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });

    int i=0;

    String[] temp = new String[100];
    try
    {
      ResultSet rs;

      rs = db.executeSQLquery("SELECT DEVICEID FROM DEVICE");
      //rs.first();
      while(rs.next())
      {
        temp[i] = rs.getString("DEVICEID");
        //Servicetype.addItem(temp);
        //System.out.println(temp[i]);
        i++;
      }
    }catch(SQLException ex)
    {
      System.out.print(ex.toString());
    }
    int j = 0;
    while (j<i)
    {
      Deviceidlist.add(temp[j]);
      j++;
    }



    Projectdescription.setBorder(border5);
    Projectdescription.setBounds(new Rectangle(177, 137, 270, 31));
    jLabel3.setBorder(border11);
    jLabel3.setText("Project description");
    jLabel3.setBounds(new Rectangle(31, 137, 125, 31));
    jLabel5.setText("DEVICE LIST");
    jLabel5.setBounds(new Rectangle(55, 271, 198, 33));
    jButton1.setBounds(new Rectangle(349, 462, 96, 34));
    jButton1.setBorder(border7);
    jButton1.setText("REMOVE");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });

    jScrollPane2.setBorder(border9);
    jScrollPane2.setBounds(new Rectangle(480, 311, 256, 289));
    jLabel7.setText("SELECTED DEVICE LIST");
    jLabel7.setBounds(new Rectangle(479, 270, 184, 34));
    Deviceidlist.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Deviceidlist_actionPerformed(e);
      }
    });
    Deviceselectlist.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Deviceselectlist_actionPerformed(e);
      }
    });
    Devicedetail.setBorder(border2);
    Devicedetail.setEditable(false);
    Devicedetail.setBounds(new Rectangle(547, 42, 403, 175));
    jScrollPane1.setBounds(new Rectangle(60, 311, 256, 289));
    jPanel1.setBorder(border12);
    jPanel1.setBounds(new Rectangle(23, 30, 490, 197));
    jPanel1.setLayout(null);
    Projectid.setBorder(border13);
    Projectid.setBounds(new Rectangle(179, 41, 270, 31));
    jLabel2.setBounds(new Rectangle(31, 41, 125, 31));
    jLabel2.setText("Project ID");
    jLabel2.setBorder(border11);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(Projectname, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(Projectid, null);
    jPanel1.add(Projectdescription, null);
    this.add(Devicedetail, null);
    this.add(jLabel5, null);
    this.add(jLabel7, null);
    this.add(jScrollPane2, null);
    this.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(Deviceidlist, null);
    this.add(Add, null);
    this.add(jButton1, null);
    this.add(jPanel1, null);
    jScrollPane2.getViewport().add(Deviceselectlist, null);

  }
  /*protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }*/


  void Add_actionPerformed(ActionEvent e) {
    if (Deviceidlist.getSelectedIndex() != -1)
    {
      Deviceselectlist.add(Deviceidlist.getSelectedItem());
      Deviceidlist.remove(Deviceidlist.getSelectedItem());
    }

  }

  void jButton1_actionPerformed(ActionEvent e) {
    if (Deviceselectlist.getSelectedIndex() != -1)
    {
      Deviceidlist.add(Deviceselectlist.getSelectedItem());
      Deviceselectlist.remove(Deviceselectlist.getSelectedItem());
    }


  }

  public boolean checkallblank(){
 //   Object day = dd.getText();
  //  Object month = mm.getText();
  //  Object year = yyyy.getText();
    if ((Projectid.getText().compareTo("") != 0) && (Projectname.getText().compareTo("") != 0) && (Projectdescription.getText().compareTo("") != 0) && (Deviceselectlist.getItemCount()  != 0))
    {
      return true;
    }
    else
    {
      return false;
    }
  }

  void Deviceidlist_actionPerformed(ActionEvent e) {
    ResultSet rs;
    String deviceid = "";
    String devicename = "";
    String ip = "";
    String mibfile = "";
    String protocol = "";

    try
    {
      //System.out.println(Servicetype.getItemAt(Servicetype.getSelectedIndex()));

      rs = db.executeSQLquery("SELECT * FROM DEVICE WHERE DEVICEID = '" + Deviceidlist.getSelectedItem() + "'");

      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        devicename = rs.getString("DEVICENAME");
        ip = rs.getString("IP");
        mibfile = rs.getString("MIBFILE");
        protocol = rs.getString("PROTOCOL");
      }

    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + ip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + protocol);
  }

  void Deviceselectlist_actionPerformed(ActionEvent e) {
    ResultSet rs;
    String deviceid = "";
    String devicename = "";
    String ip = "";
    String mibfile = "";
    String protocol = "";

    try
    {
      //System.out.println(Servicetype.getItemAt(Servicetype.getSelectedIndex()));

      rs = db.executeSQLquery("SELECT * FROM DEVICE WHERE DEVICEID = '" + Deviceselectlist.getSelectedItem() + "'");

      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        devicename = rs.getString("DEVICENAME");
        ip = rs.getString("IP");
        mibfile = rs.getString("MIBFILE");
        protocol = rs.getString("PROTOCOL");
      }




    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + ip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + protocol);
  }


}