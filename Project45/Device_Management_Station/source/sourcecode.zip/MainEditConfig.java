package dms;

import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.tree.*;
import java.sql.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MainEditConfig extends JFrame {
  private PaneLayout paneLayout1 = new PaneLayout();
  private JTabbedPane jTabbedPane1 = new JTabbedPane();
  JPanel Userpanel = new JPanel();
  private Database db;




  private EditUser1 u1;

  private EditDevice1 d1;
  private EditDevice2 d2;

  private EditProject1 p1;

  private EditProject2 p2;

  private EditProject3 p3;

  private EditProject4 p4;

  private EditProject5 p5;

  private EditProject6 p6;

  private JPanel Userpanel1 = new JPanel();
  private JPanel Device2 = new JPanel();
  private JPanel Devicepanel2 = new JPanel();
  private JPanel Project1 = new JPanel();
  private JPanel Project1panel = new JPanel();
  private JPanel Project2 = new JPanel();
  private JPanel Project2panel = new JPanel();
  private JPanel Project3 = new JPanel();
  private JPanel Project3panel = new JPanel();
  private JPanel Project4 = new JPanel();
  private JPanel Project4panel = new JPanel();
  private JPanel Project5 = new JPanel();
  private JPanel Project5panel = new JPanel();
  private JPanel Project6 = new JPanel();
  private JPanel Project6panel = new JPanel();
  private JPanel Device1 = new JPanel();
  private JPanel Device1panel = new JPanel();


  public MainEditConfig(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    u1 = new EditUser1(db);
    d1 = new EditDevice1(db);

    d2 = new EditDevice2(db);

    p1 = new EditProject1(db);

    p2 = new EditProject2(db);

    p3 = new EditProject3(db);

    p4 = new EditProject4(db);

    p5 = new EditProject5(db);

    p6 = new EditProject6(db);
    this.setSize(new Dimension(1024,768));
    this.getContentPane().setLayout(paneLayout1);
    Userpanel.setLayout(null);





    Userpanel1.setBounds(new Rectangle(10, 10, 1000, 598));
    Userpanel1.setLayout(null);

    u1.setBounds(new Rectangle(10, 10, 985, 699));


    Device2.setLayout(null);
    Devicepanel2.setBounds(new Rectangle(12, 9, 1004, 721));
    Devicepanel2.setLayout(null);
    d2.setBounds(new Rectangle(10, 10, 976, 673));
    Project1.setLayout(null);
    Project1panel.setBounds(new Rectangle(2, 4, 1015, 727));
    Project1panel.setLayout(null);
    p1.setBounds(new Rectangle(6, 5, 980, 704));
    Project2.setLayout(null);
    Project2panel.setBounds(new Rectangle(4, 7, 1014, 730));
    Project2panel.setLayout(null);
    p2.setBounds(new Rectangle(10, 10, 997, 712));
    Project3.setLayout(null);
    Project3panel.setBounds(new Rectangle(17, 14, 998, 720));
    Project3panel.setLayout(null);
    p3.setBounds(new Rectangle(-10, 0, 1002, 704));
    Project4.setLayout(null);
    Project4panel.setBounds(new Rectangle(2, 4, 1014, 735));
    Project4panel.setLayout(null);
    p4.setBounds(new Rectangle(10, 10, 1001, 721));
    Project5.setLayout(null);
    Project5panel.setBounds(new Rectangle(0, 4, 1016, 733));
    Project5panel.setLayout(null);
    p5.setBounds(new Rectangle(10, 10, 1003, 720));
    Project6.setLayout(null);
    Project6panel.setBounds(new Rectangle(5, 5, 1008, 730));
    Project6panel.setLayout(null);
    p6.setBounds(new Rectangle(10, 10, 997, 720));

    Device1.setLayout(null);
    Device1panel.setBounds(new Rectangle(11, 0, 1003, 738));
    Device1panel.setLayout(null);
    d1.setBounds(new Rectangle(10, 10, 967, 692));
    jTabbedPane1.add(Project1,   "EDIT PROJECT");
    Project1.add(Project1panel, null);
    Project1panel.add(p1, null);

    jTabbedPane1.add(Userpanel,  "EDIT USER");
    Userpanel.add(Userpanel1, null);
    Userpanel1.add(u1, null);
    jTabbedPane1.add(Device1,  "EDIT DEVICE");
    Device1.add(Device1panel, null);
    Device1panel.add(d1,null);
    jTabbedPane1.add(Device2,   "EDIT OBJECT");
    Device2.add(Devicepanel2, null);
    Devicepanel2.add(d2, null);
    jTabbedPane1.add(Project3,   "EDIT USER IN PROJECT");
    Project3.add(Project3panel, null);
    Project3panel.add(p3, null);
    jTabbedPane1.add(Project2,   "EDIT DEVICE IN PROJECT");
    Project2.add(Project2panel, null);
    Project2panel.add(p2, null);
    jTabbedPane1.add(Project5,    "EDIT MONITOR");
    Project5.add(Project5panel, null);
    Project5panel.add(p5, null);
    jTabbedPane1.add(Project4,   "EDIT TUNING");
    Project4.add(Project4panel, null);
    Project4panel.add(p4, null);
    jTabbedPane1.add(Project6,    "EDIT FAULT");
    Project6.add(Project6panel, null);
    Project6panel.add(p6, null);

    this.getContentPane().add(jTabbedPane1, new PaneConstraints("jTabbedPane1", "jTabbedPane1", PaneConstraints.ROOT, 0.5f));





    this.setTitle("EDIT CONFIGURATION");

  }

/*  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }*/


  void Okuser_actionPerformed(ActionEvent e) {
    if (u1.getEdit())
    {
      if (checkallblank())
      {
        //Database db = new Database();
        if (u1.getTypeadmin())
        {
          db.executeSQLupdate("UPDATE USERTABLE SET USERNAME = '" + u1.getUsername() + "' , DIVISION = '" + u1.getDivision() + "' , USERPASSWORD = '" + u1.getPassword() + "' , USERTYPE = 'admin' WHERE USERID = '" + u1.getUserid() + "'") ;
        }
        else if (u1.getTypeuser())
        {

          db.executeSQLupdate("UPDATE USERTABLE SET USERNAME = '" + u1.getUsername() + "' , DIVISION = '" + u1.getDivision() + "' , USERPASSWORD = '" + u1.getPassword() + "' , USERTYPE = 'user' WHERE USERID = '" + u1.getUserid() + "'") ;
        }
      }
    }
    else if (u1.getDelete())
    {
      db.executeSQLupdate("DELETE FROM USERTABLE WHERE USERID = '" + u1.getUserid() + "'");
    }

  }







  void Canceldevice_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void Canceluser_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  public boolean checkallblank()
  {
    if (u1.getUserid().compareTo("") !=0 && u1.getUsername().compareTo("") !=0 && u1.getDivision().compareTo("") !=0 && u1.getPassword().compareTo("") !=0 && u1.getConfirmpass().compareTo("") != 0 && u1.getPassword().compareTo(u1.getConfirmpass()) == 0)
    {
      return true;

    }
    return false;
  }
}