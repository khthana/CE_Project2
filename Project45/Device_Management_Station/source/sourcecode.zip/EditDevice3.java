package dms;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditDevice3 extends JPanel {
  private JTextField Community = new JTextField();
  private Mib m = new Mib();
  private List Objectlist = new List();
  private BoxLayout2 boxLayout21 = new BoxLayout2();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private JButton Cancel = new JButton();
  private JButton Ok = new JButton();
  private JTextField Textsnmpobject = new JTextField();
  private JPanel jPanel1 = new JPanel();
  private TitledBorder titledBorder1;
  private JRadioButton Delete1 = new JRadioButton();
  private JTextArea Devicedetail = new JTextArea();
  private JRadioButton Edit = new JRadioButton();
  private JComboBox Selectdevice = new JComboBox();
  private Border border1;
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();

  public EditDevice3() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    jLabel6.setText("SELECTOBJECT");
    jLabel6.setBounds(new Rectangle(31, 32, 93, 27));
    jPanel1.add(Edit, null);
    jPanel1.add(Delete1, null);
    this.add(Ok, null);
    this.add(Cancel, null);
    this.add(m, null);
    this.add(jLabel3, null);
    this.add(Community, null);
    this.add(jLabel5, null);
    this.add(Textsnmpobject, null);
    this.add(jPanel1, null);
    this.add(jLabel4, null);
    titledBorder1 = new TitledBorder(border1,"DETAIL");
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    jLabel5.setText("SNMP OBJECT");
    jLabel5.setBounds(new Rectangle(271, 362, 148, 26));
    m.setLayout(boxLayout21);
    Community.setBounds(new Rectangle(264, 304, 114, 35));
    Community.setText("public");
    this.setLayout(null);
    jLabel4.setText("COMMUNITY");
    jLabel4.setBounds(new Rectangle(263, 263, 83, 25));
    jLabel3.setText("SNMP OBJECT");
    jLabel3.setBounds(new Rectangle(416, 73, 148, 26));
    jLabel2.setText("OBJECT ID");
    jLabel2.setBounds(new Rectangle(36, 76, 119, 25));
    jLabel1.setText("MAP OBJECT");
    jLabel1.setBounds(new Rectangle(428, 14, 210, 32));
    Cancel.setBounds(new Rectangle(626, 549, 106, 27));
    Cancel.setText("CANCEL");
    Cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancel_actionPerformed(e);
      }
    });
    Ok.setBounds(new Rectangle(483, 546, 105, 26));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    m.setBounds(new Rectangle(417, 109, 321, 260));
    Textsnmpobject.setBounds(new Rectangle(269, 402, 281, 30));
    jPanel1.setLayout(verticalFlowLayout1);
    jPanel1.setBounds(new Rectangle(253, 144, 154, 69));
    Delete1.setText("DELETE");
    Delete1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete1_actionPerformed(e);
      }
    });
    Devicedetail.setBorder(titledBorder1);
    Devicedetail.setBounds(new Rectangle(765, 6, 272, 211));
    Edit.setSelected(true);
    Edit.setText("EDIT");
    Edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_actionPerformed(e);
      }
    });
    Selectdevice.setBounds(new Rectangle(137, 36, 250, 29));
    Selectdevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectdevice_actionPerformed(e);
      }
    });
    Objectlist.setBounds(new Rectangle(39, 115, 190, 411));
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    buttonGroup1.add(Edit);
    buttonGroup1.add(Delete1);
    this.add(Devicedetail, null);
    this.add(Objectlist, null);
    this.add(Selectdevice, null);
    this.add(jLabel6, null);
  }
  void Cancel_actionPerformed(ActionEvent e) {

  }
  void Ok_actionPerformed(ActionEvent e) {

  }
  void Delete1_actionPerformed(ActionEvent e) {

  }
  void Edit_actionPerformed(ActionEvent e) {

  }
  void Selectdevice_actionPerformed(ActionEvent e) {

  }
}