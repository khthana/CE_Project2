package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.sql.*;
import javax.swing.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditDevice2 extends JPanel {
  private String deviceid = "";
  private String devicename = "";
  private String deviceip = "";
  private String deviceprotocol = "";
  private String mibfile = "";
  private String objectid = "";
  private String datatype = "";
  private String objectdescription = "";
  private String snmpobjectid = "";
  private String community = "";
  private Database db;
  private JComboBox Datatype = new JComboBox();

  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel1 = new JLabel();
  private JButton Cancel = new JButton();
  private JButton Ok = new JButton();
  private JTextArea Devicedetail = new JTextArea();
  private JPanel jPanel1 = new JPanel();
  private JRadioButton Edit = new JRadioButton();
  private JComboBox Selectdevice = new JComboBox();
  private JRadioButton Delete1 = new JRadioButton();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private Border border1;
  private TitledBorder titledBorder1;
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JRadioButton Add = new JRadioButton();
  private JTextField Community = new JTextField();
  private JTextField Snmpobject = new JTextField();
  private JLabel jLabel6 = new JLabel();
  private JLabel jLabel7 = new JLabel();
  private JList Objectlist = new JList();
  private DefaultListModel listModel;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private Border border2;
  private Border border3;
  private Border border4;
  private Border border5;
  private Border border6;
  private Border border7;
  private JTextField Object = new JTextField();
  private JTextField Objectdescription = new JTextField();
  private Border border8;
  private Border border9;

  public EditDevice2(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border1,"DETAIL");
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border5 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border7 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border8 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border9 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    Datatype.setBounds(new Rectangle(378, 460, 267, 29));
    this.setLayout(null);
    Datatype.addItem("otInteger");
    Datatype.addItem("otOctetString");
    Datatype.addItem("otNull");
    Datatype.addItem("otObjectID");
    Datatype.addItem("otIPAddress");
    Datatype.addItem("otCounter32");
    Datatype.addItem("otGauge32");
    Datatype.addItem("otTimeTicks");
    Datatype.addItem("otOpaque");
    Datatype.addItem("otNSAP");
    Datatype.addItem("otCounter64");
    Datatype.addItem("otUnsignedInteger32");
    jLabel4.setText("OBJECT LIST");
    jLabel4.setBounds(new Rectangle(43, 87, 115, 29));
    jLabel3.setText("DATATYPE");
    jLabel3.setBounds(new Rectangle(378, 431, 102, 29));
    jLabel1.setToolTipText("");
    jLabel1.setText("OBJECT ID");
    jLabel1.setBounds(new Rectangle(378, 264, 81, 31));
    Cancel.setBounds(new Rectangle(753, 587, 106, 32));
    Cancel.setText("CANCEL");
    Cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancel_actionPerformed(e);
      }
    });
    Ok.setBounds(new Rectangle(584, 589, 106, 32));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Devicedetail.setBorder(titledBorder1);
    Devicedetail.setBounds(new Rectangle(577, 16, 364, 230));
    jPanel1.setLayout(verticalFlowLayout1);
    jPanel1.setBorder(border2);
    jPanel1.setBounds(new Rectangle(382, 131, 154, 97));
    Edit.setText("EDIT");
    Edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_actionPerformed(e);
      }
    });
    Selectdevice.setBounds(new Rectangle(156, 32, 260, 29));
    Selectdevice.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectdevice_actionPerformed(e);
      }
    });
    Delete1.setText("DELETE");
    Delete1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete1_actionPerformed(e);
      }
    });
    jLabel2.setText("OBJECT DESCRIPTION");
    jLabel2.setBounds(new Rectangle(378, 349, 144, 29));
    jLabel5.setText("SELECT DEVICE");
    jLabel5.setBounds(new Rectangle(46, 32, 110, 29));
    Add.setSelected(true);
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Community.setBorder(border5);
    Community.setText("public");
    Community.setBounds(new Rectangle(689, 304, 267, 29));
    Snmpobject.setBorder(border7);
    Snmpobject.setBounds(new Rectangle(689, 379, 267, 29));
    jLabel6.setBounds(new Rectangle(689, 349, 148, 26));
    jLabel6.setText("SNMP OBJECT");
    jLabel7.setBounds(new Rectangle(689, 264, 83, 25));
    jLabel7.setText("COMMUNITY");
    jScrollPane1.setBounds(new Rectangle(43, 131, 286, 460));
    Object.setBorder(border8);
    Object.setBounds(new Rectangle(378, 303, 267, 29));
    Objectdescription.setBorder(border9);
    Objectdescription.setBounds(new Rectangle(379, 380, 267, 29));
    jPanel1.add(Add, null);
    jPanel1.add(Edit, null);
    jPanel1.add(Delete1, null);
    this.add(Devicedetail, null);
    this.add(Selectdevice, null);
    this.add(jLabel5, null);
    this.add(jLabel4, null);
    this.add(jLabel3, null);
    this.add(Datatype, null);
    this.add(jScrollPane1, null);


    this.add(jLabel7, null);
    this.add(Community, null);
    this.add(jLabel6, null);
    this.add(Snmpobject, null);
    this.add(Cancel, null);
    this.add(Ok, null);
    this.add(jLabel2, null);
    this.add(jLabel1, null);
    this.add(jPanel1, null);
    listModel = new DefaultListModel();
    listModel.removeAllElements();
    Objectlist = new JList(listModel);
    jScrollPane1.getViewport().add(Objectlist, null);
    Objectlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Objectlist.setSelectedIndex(0);
    Objectlist.addListSelectionListener(new ListSelectionListener()
    {
      public void valueChanged(ListSelectionEvent e) {
        Objectlist_valueChanged(e);
      }
    });

  //  Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE");
      while (rs.next())
      {
        Selectdevice.addItem(rs.getString("DEVICEID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditDevice1 : " + sql);
    }
    buttonGroup1.add(Edit);
    buttonGroup1.add(Delete1);
    buttonGroup1.add(Add);
    this.add(Object, null);
    this.add(Objectdescription, null);
  }
  void Cancel_actionPerformed(ActionEvent e) {

  }
  void Ok_actionPerformed(ActionEvent e) {
    if (Add.isSelected())
    {
      if (checkallblank())
      {
        //Database db = new Database();
        db.executeSQLupdate("INSERT INTO OBJECT (OBJECTID,DEVICEID,DATATYPE,OBJECTDESCRIPTION) VALUES('" + Object.getText() + "' , '" + Selectdevice.getSelectedItem().toString() + "' , '" + Datatype.getSelectedItem().toString() +  "' , '" + Objectdescription.getText() + "')");
        db.executeSQLupdate("INSERT SNMPOBJECT (OBJECTID,DEVICEID,SNMPOBJECTID,COMMUNITY) VALUES('" + Object.getText() + "' , '" + Selectdevice.getSelectedItem().toString() + "' , '" + Snmpobject.getText() + "' , '" + Community.getText() + "')");
        listModel.addElement(Object.getText());
        //Objectlist1.add(Object.getText());
        //db.executeSQLupdate("INSERT INTO OBJECT (OBJECTID,DEVICEID,DATATYPE,OBJECTDESCRIPTION) VALUES('" + "add" + "' , '" + "GLAZINGLINE" + "' , '" + "otInteger" +  "' , '" + "addd" + "')");
      }
    }
    else if (Edit.isSelected())
    {
      if (checkallblank())
      {
      //  Database db = new Database();

        db.executeSQLupdate("UPDATE OBJECT SET DATATYPE = '" + Datatype.getSelectedItem().toString() + "' , OBJECTDESCRIPTION = '" + Objectdescription.getText() + "' WHERE DEVICEID = '" + Selectdevice.getSelectedItem().toString() + "' AND OBJECTID = '" + Object.getText() + "'") ;
        db.executeSQLupdate("UPDATE SNMPOBJECT SET SNMPOBJECTID = '" + Snmpobject.getText() + "' , COMMUNITY = '" + Community.getText() + "' WHERE DEVICEID = '" + Selectdevice.getSelectedItem().toString() + "' AND OBJECTID = '" + Object.getText() + "'") ;
        System.out.println("update editdevice2");
      }
    }
    else if (Delete1.isSelected())
    {
   //   Database db =new Database();

      db.executeSQLupdate("DELETE FROM OBJECT WHERE DEVICEID = '" + Selectdevice.getSelectedItem().toString() + "' AND OBJECTID = '" + objectid + "'");
      //int select = Objectlist1.getSelectedIndex();
      int select = Objectlist.getSelectedIndex();
      listModel.removeElementAt(select);

      //Objectlist1.deselect(select);
      //Objectlist1.remove(select);

    }
  }

  void Edit_actionPerformed(ActionEvent e) {
    if (Objectlist.getSelectedIndex() != -1)
    {
      Objectdescription.setEditable(true);
      Object.setEditable(false);
      Snmpobject.setEditable(true);
      Community.setEditable(true);
    //  Database db = new Database();
      //objectid = Objectlist1.getSelectedItem();
      objectid = Objectlist.getSelectedValue().toString();
      Object.setText(Objectlist.getSelectedValue().toString());
      //Object.setText(Objectlist1.getSelectedItem());
      try
      {
        ResultSet rs = db.executeSQLquery("SELECT obj.OBJECTID,obj.DEVICEID,DATATYPE,OBJECTDESCRIPTION,SNMPOBJECTID,COMMUNITY FROM OBJECT obj,SNMPOBJECT snmp WHERE obj.OBJECTID = snmp.OBJECTID AND obj.DEVICEID = snmp.DEVICEID AND obj.OBJECTID = '" + Objectlist.getSelectedValue().toString() + "' AND obj.DEVICEID = '" + deviceid + "'");
        while (rs.next())
        {
          datatype = rs.getString("DATATYPE");
          objectdescription = rs.getString("OBJECTDESCRIPTION");
          snmpobjectid = rs.getString("SNMPOBJECTID");
          community = rs.getString("COMMUNITY");
        }
        Datatype.setSelectedItem(datatype);
        Objectdescription.setText(objectdescription);
        Snmpobject.setText(snmpobjectid);
        Community.setText(community);
        Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + deviceip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + deviceprotocol + "\nOBJECTID : " + objectid + "\nDATATYPE : " + datatype + "\nOBJECTDESCRIPTION : " + objectdescription + "\nSNMPOBJECTID : " + snmpobjectid + "\nCOMMUNITY : " + community);


      }
      catch(SQLException sql)
      {
        System.out.println("EditDevice2 : " + sql);
      }
    }
    else
    {
      Object.setText("");
      Objectdescription.setText("");
      Snmpobject.setText("");
      Community.setText("public");

    }

  }
  void Selectdevice_actionPerformed(ActionEvent e) {
    listModel.removeAllElements();
    //Objectlist1.removeAll();

  //  Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE WHERE DEVICEID = '" + Selectdevice.getSelectedItem() + "'");
      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        devicename = rs.getString("DEVICENAME");
        deviceip = rs.getString("IP");
        mibfile = rs.getString("MIBFILE");
        deviceprotocol = rs.getString("PROTOCOL");

      }

      Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + deviceip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + deviceprotocol);

      rs = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + Selectdevice.getSelectedItem() + "'");
      while (rs.next())
      {
        //Objectlist1.add(rs.getString("OBJECTID"));
        System.out.println(rs.getString("OBJECTID"));
        listModel.addElement(rs.getString("OBJECTID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditDevice2 : " + sql);
    }

    Object.setText("");
    Objectdescription.setText("");
    Snmpobject.setText("");
    Community.setText("public");

    Object.setEditable(false);
    Objectdescription.setEditable(false);
    Snmpobject.setEditable(false);
    Community.setEditable(false);
  }

  void Delete1_actionPerformed(ActionEvent e) {
    if (Objectlist.getSelectedIndex() != -1)
    {
      Object.setEditable(false);

      Objectdescription.setEditable(false);
      Snmpobject.setEditable(false);
      Community.setEditable(false);
      Snmpobject.setText("");
      Community.setText("public");
      Object.setText("");
      Objectdescription.setText("");
    //  Database db = new Database();
      //objectid = Objectlist1.getSelectedItem();
      objectid = Objectlist.getSelectedValue().toString();
      try
      {
        ResultSet rs = db.executeSQLquery("SELECT obj.OBJECTID,obj.DEVICEID,DATATYPE,OBJECTDESCRIPTION,SNMPOBJECTID,COMMUNITY FROM OBJECT obj,SNMPOBJECT snmp WHERE obj.OBJECTID = snmp.OBJECTID AND obj.DEVICEID = snmp.DEVICEID AND obj.OBJECTID = '" + Objectlist.getSelectedValue().toString() + "' AND obj.DEVICEID = '" + deviceid + "'");
        while (rs.next())
        {
          datatype = rs.getString("DATATYPE");
          objectdescription = rs.getString("OBJECTDESCRIPTION");
          snmpobjectid = rs.getString("SNMPOBJECTID");
          community = rs.getString("COMMUNITY");
        }

        Devicedetail.setText("DEVICEID : " + deviceid + "\nDEVICENAME : " + devicename + "\nIP : " + deviceip + "\nMIBFILE : " + mibfile + "\nPROTOCOL : " + deviceprotocol + "\nOBJECTID : " + objectid + "\nDATATYPE : " + datatype + "\nOBJECTDESCRIPTION : " + objectdescription + "\nSNMPOBJECTID : " + snmpobjectid + "\nCOMMUNITY : " + community);


      }
      catch(SQLException sql)
      {
        System.out.println("EditDevice2 : " + sql);
      }
    }
    else
    {
      Object.setEditable(false);

      Objectdescription.setEditable(false);
      Snmpobject.setEditable(false);
      Community.setEditable(false);
      Snmpobject.setText("");
      Community.setText("public");
      Object.setText("");
      Objectdescription.setText("");
    }
  }


  public boolean checkallblank()
  {
    if (Object.getText().compareTo("") !=0 && Objectdescription.getText().compareTo("") !=0 && Snmpobject.getText().compareTo("") != 0 && Community.getText().compareTo("") != 0)
    {
      return true;

    }
    return false;
  }

  void Add_actionPerformed(ActionEvent e) {
    Object.setEditable(true);
    Objectdescription.setEditable(true);
    Snmpobject.setEditable(true);
    Community.setEditable(true);
    Objectdescription.setText("");
    Object.setText("");
    Snmpobject.setText("");
    Community.setText("public");

  }

  public void Objectlist_valueChanged(ListSelectionEvent e) {

  }
}