package dms;

import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import sck.beans.*;
import javax.swing.tree.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Config5 extends JPanel {

  private DefaultMutableTreeNode top = new DefaultMutableTreeNode("DEVICE");
  JTree Objecttree = new JTree(top);
  private JScrollPane treeView = new JScrollPane(Objecttree);
  List Tunelist = new List();
  private JButton Add = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JButton Remove = new JButton();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  //PaneLayout paneLayout1 = new PaneLayout();
  //JPanel jPanel1 = new JPanel();


  public Config5() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /*public static void main(String arg[])
  {

    Config1 a = new Config1();

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = a.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    a.setSize(frameSize.width,frameSize.height);
    a.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    a.setVisible(true);
  }*/
  private void jbInit() throws Exception {
    //this.getContentPane().setLayout(paneLayout1);
    //jPanel1.setLayout(null);
    this.setSize(new Dimension(1000,700));
    this.setLayout(null);
    Objecttree.setEditable(true);
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);
    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(61, 127, 304, 441));

    Tunelist.setBounds(new Rectangle(589, 127, 304, 441));
    Add.setBounds(new Rectangle(409, 210, 115, 30));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    jLabel1.setText("TUNING");
    jLabel1.setBounds(new Rectangle(355, 18, 253, 38));
    Remove.setBounds(new Rectangle(408, 254, 117, 27));
    Remove.setText("REMOVE");
    Remove.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Remove_actionPerformed(e);
      }
    });
    jLabel2.setText("DEVICE LIST");
    jLabel2.setBounds(new Rectangle(60, 82, 142, 29));
    jLabel3.setText("CHOOSED DEVICE FOR TUNING");
    jLabel3.setBounds(new Rectangle(591, 84, 204, 27));
    this.add(Tunelist, null);
    this.add(Add, null);
    this.add(Remove, null);
    this.add(treeView, null);
    this.add(jLabel2, null);
    this.add(jLabel1, null);
    this.add(jLabel3, null);


    //this.getContentPane().add(m, null);
    //this.getContentPane().add(jPanel1, new PaneConstraints("jPanel1", "jPanel1", PaneConstraints.ROOT, 0.5f));
  }

  void Add_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

    TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
    if (Objecttree.isVisible(pathnode)) {

      if (node.isLeaf()) {
        String leafpath = Objecttree.getLastSelectedPathComponent().toString();
        TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
        String parent = temp.getLastPathComponent().toString();
        //System.out.println(leafpath);
        //System.out.println(parent);
        Tunelist.add(parent+" , "+leafpath);
        //createNodes2(parent,leafpath,top2);
      }
      else if (node.isRoot()) {
        System.out.println("root");
      }
      else if (node.isNodeAncestor(top)) {
        System.out.println("ancestor");
      }
    }
  }

  void Remove_actionPerformed(ActionEvent e) {
    if (Tunelist.getSelectedIndex() != -1)
    {

      Tunelist.remove(Tunelist.getSelectedItem());
    }
  }
  /*protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }*/
}