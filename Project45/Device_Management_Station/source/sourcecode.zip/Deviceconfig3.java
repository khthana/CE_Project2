package dms;

import java.awt.*;
import sck.beans.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Deviceconfig3 extends JPanel {
  JButton Add = new JButton();
  JTextField Object = new JTextField();
  List Objectlist = new List();
  private JComboBox Datatype = new JComboBox();
  private JButton Delete = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  JScrollPane jScrollPane1 = new JScrollPane();
  JLabel jLabel4 = new JLabel();

  public Deviceconfig3() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setSize(new Dimension(1000,700));
    this.setLayout(null);
    Add.setBounds(new Rectangle(406, 213, 106, 32));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Object.setBounds(new Rectangle(91, 194, 267, 32));
    Datatype.setBounds(new Rectangle(93, 273, 267, 32));
    Datatype.addItem("otInteger");
    Datatype.addItem("otOctetString");
    Datatype.addItem("otNull");
    Datatype.addItem("otObjectID");
    Datatype.addItem("otIPAddress");
    Datatype.addItem("otCounter32");
    Datatype.addItem("otGauge32");
    Datatype.addItem("otTimeTicks");
    Datatype.addItem("otOpaque");
    Datatype.addItem("otNSAP");
    Datatype.addItem("otCounter64");
    Datatype.addItem("otUnsignedInteger32");

    Delete.setBounds(new Rectangle(406, 254, 106, 32));
    Delete.setText("DELETE");
    Delete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete_actionPerformed(e);
      }
    });
    jLabel1.setToolTipText("");
    jLabel1.setText("OBJECT ID");
    jLabel1.setBounds(new Rectangle(89, 154, 142, 31));
    jLabel2.setText("ADD OBJECT");
    jLabel2.setBounds(new Rectangle(72, 16, 242, 44));
    jLabel3.setText("DATATYPE");
    jLabel3.setBounds(new Rectangle(90, 244, 102, 29));
    jScrollPane1.setBounds(new Rectangle(564, 96, 283, 336));
    jLabel4.setText("OBJECT LIST");
    jLabel4.setBounds(new Rectangle(563, 57, 115, 29));
    this.add(jLabel2, null);
    this.add(jScrollPane1, null);
    this.add(Object, null);
    this.add(jLabel1, null);
    this.add(jLabel3, null);
    this.add(Datatype, null);
    this.add(Add, null);
    this.add(Delete, null);
    this.add(jLabel4, null);
    jScrollPane1.getViewport().add(Objectlist, null);
  }

  void Add_actionPerformed(ActionEvent e) {

    Objectlist.add(Object.getText()+" , "+Datatype.getItemAt(Datatype.getSelectedIndex()));
    Object.setText("");
  }

  void Delete_actionPerformed(ActionEvent e) {
    if (Objectlist.getSelectedIndex() != -1)
    {
      Objectlist.remove(Objectlist.getSelectedIndex());
    }

  }
}