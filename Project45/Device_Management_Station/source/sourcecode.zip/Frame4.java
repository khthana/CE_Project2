package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame4 extends JFrame {
  private JButton jButton1 = new JButton();
  char[] ch={'1','2','3'};
  char[] ch2={'1','2','3'};
  public Frame4() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    (new Frame4().setVisible(true));
  }
  private void jbInit() throws Exception {
    jButton1.setBounds(new Rectangle(155, 113, 78, 35));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    this.getContentPane().add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    System.out.println(ch.length);


  }

}