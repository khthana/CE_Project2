package dms;

import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import sck.beans.*;
import javax.swing.border.*;
import javax.swing.tree.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Config4 extends JPanel {

  //PaneLayout paneLayout1 = new PaneLayout();
  //JPanel jPanel1 = new JPanel();
  String[][] fault = new String[7][100];
  String[][] action = new String[6][100];
  int countfault = 0;
  int countaction = 0;
  JTextField Value2 = new JTextField();
  private JPanel jPanel1 = new JPanel();
  private JButton Okfault = new JButton();
  private JButton Canclefault = new JButton();
  JRadioButton Range = new JRadioButton();
  JTextField Value1 = new JTextField();
  JRadioButton Upperbound = new JRadioButton();
  JRadioButton Lowerbound = new JRadioButton();
  private Border border1;
  private DefaultMutableTreeNode top = new DefaultMutableTreeNode("DEVICE");
  JTree Objecttree = new JTree(top);
  private JScrollPane treeView = new JScrollPane(Objecttree);
  JTextField Object = new JTextField();
  private JButton Add = new JButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  JTextField Faultid = new JTextField();
  JTextField Faultname = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private JLabel jLabel10 = new JLabel();
  private Border border2;
  private JLabel jLabel4 = new JLabel();
  private JRadioButton Equal = new JRadioButton();
  private JButton View = new JButton();


  //JButton Delete = new JButton();


  public Config4() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /*public static void main(String arg[])
  {

    Config4 a = new Config4();

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = a.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    a.setSize(frameSize.width,frameSize.height);
    a.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    a.setVisible(true);
  }*/

  private void jbInit() throws Exception {
    //this.getContentPane().setLayout(paneLayout1);
    //jPanel1.setLayout(null);
    this.setSize(new Dimension(1000,700));
    border1 = BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(109, 109, 110),new Color(156, 156, 158));
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158));
    jLabel9.setText("Value2");
    jLabel9.setBounds(new Rectangle(158, 217, 71, 26));
    jLabel8.setText("Value1");
    jLabel8.setBounds(new Rectangle(160, 171, 70, 25));
    this.setLayout(null);





    Value2.setBounds(new Rectangle(241, 218, 134, 29));
    jPanel1.setBorder(border1);
    jPanel1.setBounds(new Rectangle(483, 122, 429, 465));
    jPanel1.setLayout(null);
    Okfault.setBounds(new Rectangle(108, 403, 89, 32));
    Okfault.setText("OK");
    Okfault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Okfault_actionPerformed(e);
      }
    });
    Canclefault.setBounds(new Rectangle(254, 406, 89, 32));
    Canclefault.setText("CANCLE");
    Canclefault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Canclefault_actionPerformed(e);
      }
    });
    Range.setText("Range");
    Range.setBounds(new Rectangle(25, 240, 104, 23));
    Value1.setBounds(new Rectangle(241, 169, 130, 28));
    Upperbound.setText("Upperbound");
    Upperbound.setBounds(new Rectangle(25, 208, 106, 19));
    Lowerbound.setSelected(true);
    Lowerbound.setText("Lowerbound");
    Lowerbound.setBounds(new Rectangle(25, 170, 103, 27));
    Lowerbound.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Lowerbound_actionPerformed(e);
      }
    });
    Objecttree.setEditable(true);
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);
    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(28, 119, 293, 457));


    Add.setBounds(new Rectangle(359, 257, 92, 29));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Object.setBounds(new Rectangle(139, 96, 203, 29));
    Faultid.setBounds(new Rectangle(139, 21, 203, 29));
    Faultname.setBounds(new Rectangle(139, 59, 203, 29));
    jLabel1.setText("Fault ID");
    jLabel1.setBounds(new Rectangle(14, 20, 110, 29));
    jLabel2.setText("Fault Name");
    jLabel2.setBounds(new Rectangle(14, 64, 116, 26));
    jLabel3.setText("Device , Object");
    jLabel3.setBounds(new Rectangle(14, 102, 112, 22));
   // jPanel1.add(Delete,null);
    //this.getContentPane().add(m, null);
    //this.getContentPane().add(jPanel1, new PaneConstraints("jPanel1", "jPanel1", PaneConstraints.ROOT, 0.5f));
    jLabel10.setText("FAULT");
    jLabel10.setBounds(new Rectangle(299, 14, 206, 34));
    jLabel4.setText("DEVICE LIST");
    jLabel4.setBounds(new Rectangle(26, 66, 149, 32));
    Equal.setText("Equal");
    Equal.setBounds(new Rectangle(24, 273, 100, 29));
    View.setBounds(new Rectangle(185, 278, 105, 29));
    View.setText("VIEW");
    View.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        View_actionPerformed(e);
      }
    });
    jPanel1.add(Faultid, null);
    jPanel1.add(Faultname, null);
    jPanel1.add(Object, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jLabel3, null);
    jPanel1.add(Okfault, null);
    jPanel1.add(Canclefault, null);
    jPanel1.add(Value1, null);
    jPanel1.add(Lowerbound, null);
    jPanel1.add(Upperbound, null);
    jPanel1.add(Range, null);
    jPanel1.add(Equal, null);
    jPanel1.add(jLabel8, null);
    jPanel1.add(jLabel9, null);
    jPanel1.add(Value2, null);
    jPanel1.add(View, null);
    this.add(jLabel10, null);
    this.add(treeView, null);
    this.add(jLabel4, null);
    this.add(Add, null);
    this.add(jPanel1, null);
    buttonGroup1.add(Lowerbound);
    buttonGroup1.add(Upperbound);
    buttonGroup1.add(Range);
    buttonGroup1.add(Equal);

  }
  /*protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }*/


  void Lowerbound_actionPerformed(ActionEvent e) {

  }

  void Add_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

    TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
    if (Objecttree.isVisible(pathnode)) {

      if (node.isLeaf()) {
        String leafpath = Objecttree.getLastSelectedPathComponent().toString();
        TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
        String parent = temp.getLastPathComponent().toString();
        //System.out.println(leafpath);
        //System.out.println(parent);
        Object.setText(parent+" , "+leafpath);
        //createNodes2(parent,leafpath,top2);
      }
      else if (node.isRoot()) {
        System.out.println("root");
      }
      else if (node.isNodeAncestor(top)) {
        System.out.println("ancestor");
      }
    }
  }

  void Okfault_actionPerformed(ActionEvent e) {

    String temp = Object.getText();
    if (Faultid.getText().compareTo("") != 0 && Faultname.getText().compareTo("") != 0 && temp.compareTo("") != 0 && Value1.getText().compareTo("") != 0)
    {
      fault[0][countfault] = Faultid.getText();
      fault[1][countfault] = Faultname.getText();
      fault[2][countfault] = temp.substring(0,temp.indexOf(" , "));
      fault[3][countfault] = temp.substring(temp.indexOf(" , ")+3);
      if (Lowerbound.isSelected())
      {

        fault[4][countfault] = "LOWERBOUND";
        fault[5][countfault] = Value1.getText();

      }
      else if (Upperbound.isSelected())
      {
        fault[4][countfault] = "UPPERBOUND";
        fault[5][countfault] = Value1.getText();

      }
      else if (Range.isSelected())
      {
        fault[4][countfault] = "RANGE";
        fault[5][countfault] = Value1.getText();
        fault[6][countfault] = Value2.getText();
      }
      else if (Equal.isSelected())
      {
        fault[4][countfault] = "EQUAL";
        fault[5][countfault] = Value1.getText();
      }

      //fault[5][countfault] = Actionid.getText();
      System.out.println(fault[0][countfault] + " , " + fault[1][countfault] + " , " + fault[2][countfault] + " , " + fault[3][countfault]);
      countfault++;

      //clear
      Faultid.setText("");
      Faultname.setText("");
      Object.setText("");
      Value1.setText("");
      Value2.setText("");
      Lowerbound.setSelected(true);
    }


/*    action[0][countaction] = Actionid.getText();
    action[1][countaction] = Actionname.getText();
    action[2][countaction] = Actionvalue.getText();
    action[3][countaction] = Actiondescription.getText();
    action[4][countaction] = temp.substring(0,temp.indexOf(" , "));
    action[5][countaction] = temp.substring(temp.indexOf(" , ")+3);
    countaction++;*/

  }

  void Canclefault_actionPerformed(ActionEvent e) {
    //clear
    Faultid.setText("");
    Faultname.setText("");
    Object.setText("");
    Value1.setText("");
    Value2.setText("");
    Lowerbound.setSelected(true);
  }

  void View_actionPerformed(ActionEvent e) {
    FaultView f = new FaultView(this,fault,countfault);
    f.setVisible(true);
    f.setSize(700,600);

  }

  void SetFault(String[][] f,int c)
  {
    fault = f;
    countfault = c;
  }


}