package dms;
import java.*;
import java.sql.*;
import java.awt.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FaultListener extends Thread {
  Dialog1 d1 = new Dialog1();
  private Database db;
  MessageHandler mh;
  //Dialog1 d = new Dialog1();
  String listenproject="";
  String refresh="";
  Date startdate;
  Date enddate;
  Time starttime;
  Time endtime;
  boolean auto=false;
  int i=0;
  boolean flag2=false;

  boolean flag=true;
  //--------------
  String faultid[];
  String faultn[];
  String device[];
  String object[];
  String up[];
  String low[];
  String tocheck[];
  String datatype[];
  String result="0";
  //--------------
  public FaultListener(String project,String re,boolean at,Date sd,Time st,Date ed,Time et,Database d) {
    d1.setSize(400,400);
    db = d;
    mh = new MessageHandler(db);
    listenproject=project;
    refresh = re;
    startdate = sd;
    starttime = st;
    enddate = ed;
    endtime =et;
    auto = at;
    db = d;
    ResultSet rs3 = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID='"+listenproject+"'");

    try
    {
      while(rs3.next())
      {
        i++;
      }
    }catch(SQLException sql)
    {}
    faultid = new String[i];
    faultn = new String[i];
     device = new String[i];
      object = new String[i];
      up = new String[i];
     low = new String[i];
     tocheck = new String[i];
     datatype = new String[i];
      result="0";
      i=0;
          ResultSet rs = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID='"+listenproject+"'");
          try{
            while(rs.next())
            {
               faultn[i]=rs.getString("FAULTID");
               System.out.println(faultn[i]);
               device[i]=rs.getString("DEVICEID");
               object[i]=rs.getString("OBJECTID");
               tocheck[i] =rs.getString("FAULTCHECK");
               low[i] = rs.getString("FAULTVALUE");
               up[i] = rs.getString("FAULTVALUE2");

               //datatype[i] = rs.getString("ACTIONID");
               System.out.println("faultn : " + faultn[i]);
               i++;

            }

          }catch(SQLException sql)
          {
             System.out.println("Error connecting Database");
           }

          for(int u=0;u<i;u++)
          {
            ResultSet rs2 = db.executeSQLquery("SELECT DATATYPE FROM OBJECT WHERE OBJECTID='"+object[u]+"'");
            try{
              while(rs2.next())
              {
                 datatype[u] = rs2.getString("DATATYPE");
              }
            } catch(SQLException sql)
            {System.out.println("Error connecting Database");}
          }
          for(int u=0;u<i;u++)
          {
            System.out.println(datatype[u]);
          }
  }
  /*public FaultListener()
  {

  }*/
  public void run() {
     /* String faultid[] = new String[1000000];
      String faultn[] = new String[1000000];
      String device[] = new String[1000000];
      String object[] = new String[1000000];
      String up[] = new String[1000000];
      String low[] = new String[1000000];
      String tocheck[] = new String[1000000];
      String action[] = new String[1000000];*/
      String result="0";


         //while (flag==true) {
                 // Wait 3/4 second
           /*
                 try {
                         Thread.currentThread().sleep(1000);
                 }
                 catch (Exception e) {
                 }


                 mh.constructMessage("DEVICE1","INROUTER1","SET"," "," ","SNMP");
                 mh.sendMessage();
                 System.out.println(mh.recieveMessage());
           */
           System.out.println(listenproject);
         /*  i=0;
           ResultSet rs = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID='"+listenproject+"'");
           try{
             while(rs.next())
             {
                faultn[i]=rs.getString("FAULTID");
                System.out.println(faultn[i]);
                device[i]=rs.getString("DEVICEID");
                object[i]=rs.getString("OBJECTID");
                low[i] = rs.getString("FAULTVALUE");
                up[i] = rs.getString("FAULTVALUE2");
                tocheck[i] =rs.getString("FAULTCHECK");
                datatype[i] = rs.getString("ACTIONID");
                i++;

             }

           }catch(SQLException sql)
           {
              System.out.println("Error connecting Database");
           }
*/
     System.out.println(i);
   while (flag==true) {
    //----------------wait
   /*  try {
                     Thread.currentThread().sleep(Integer.parseInt(refresh));
             }
             catch (Exception e) {
                 }*/
     //---------------wait
    //-----------------
    System.out.println("Polling");
    if(auto==true)
    {
      Date thisdate = new Date(System.currentTimeMillis());
      Time thistime = new Time(System.currentTimeMillis());
      System.out.println(thisdate.toString());
      System.out.println(thistime.toString());
      //System.out.println(startdate.toString()+starttime.toString()+" "+enddate.toString()+endtime.toString());
      //if((startdate.compareTo(thisdate)<=0)&&(enddate.compareTo(thisdate)>=0))
      int hours = Integer.parseInt(starttime.toString().substring(0,2));
      System.out.println(hours);
      int minutes = Integer.parseInt(starttime.toString().substring(3,5));
      System.out.println(minutes);
      int houre = Integer.parseInt(endtime.toString().substring(0,2));
      int minutee = Integer.parseInt(endtime.toString().substring(3,5));
      int hourt = Integer.parseInt(thistime.toString().substring(0,2));
      System.out.println(hourt);
      int minutet = Integer.parseInt(thistime.toString().substring(3,5));
      System.out.println(minutet);
      int dates = Integer.parseInt(startdate.toString().substring(8,10));
      System.out.println(dates);
      int months = Integer.parseInt(startdate.toString().substring(5,7));
      int years = Integer.parseInt(startdate.toString().substring(0,4));
      int datee = Integer.parseInt(enddate.toString().substring(8,10));
      int monthe = Integer.parseInt(enddate.toString().substring(5,7));
      int yeare = Integer.parseInt(enddate.toString().substring(0,4));
      int datet = Integer.parseInt(thisdate.toString().substring(8,10));
      System.out.println(datet);
      int montht = Integer.parseInt(thisdate.toString().substring(5,7));
      int yeart = Integer.parseInt(thisdate.toString().substring(0,4));
      if(dates<=datet&&months<=montht&&years<=yeart&&datee>=datet&&monthe>=montht&&yeare>=yeart)
      {
      //if((startdate.compareTo(thisdate)<=0&&enddate.compareTo(thisdate)>=0)||(startdate.toString().compareTo(thisdate.toString())==0))
      //{
      System.out.println("Date OK");
        if(hours<=hourt&&minutes<=minutet&&houre>=hourt&&minutee>=minutet)
        {
        //if((starttime.compareTo(thistime)<=0)&&(endtime.compareTo(thistime)>=0))
       // {
          System.out.println("Time OK");
         flag2=true;
        }
        else
        {
          flag2=false;
        }
      }
      /*if(thistime.compareTo(endtime)>0)
      {
        flag=false;
      }*/
    }
    //-----------------
  if(flag2==true||auto==false)
  {
    //-----------------
   for(int j=0;j<i;j++)
   {
     System.out.println(device[j]);
     System.out.println(object[j]);
     mh.constructMessage(device[j],object[j],"GET","","","");
     mh.sendMessage();
     try {
                     Thread.currentThread().sleep(Integer.parseInt(refresh));
             }
             catch (Exception e) {
                 }
     result = mh.recieveMessage();
     System.out.println(result);
     //-------------------
     if(result.compareTo("*")!=0)
     {
     //-------------------
     if(tocheck[j].compareTo("UPPERBOUND")==0 && datatype[j].compareTo("otInteger")==0 )
     {
          long k = Long.parseLong(result);
          long kk = Long.parseLong(up[j]);
          if(k>kk)
          {
            String sdes ="Upper bound fault :"+listenproject+ ":"+object[j];
           // db.executeSQLupdate("INSERT INTO EVENT (EVENTNAME,EVENTTYPEID,EVENTDESCRIPTION,EVENTDATE,EVENTTIME) VALUES ('Upper Fault occur','01','"+sdes+"','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
            db.executeSQLupdate("INSERT INTO FAULTEVENT (PROJECTID,DEVICEID,OBJECTID,FAULTDESCRIPTION,FAULTDATE,FAULTTIME) VALUES ('"+listenproject+"','"+device[j]+"','"+object[j]+"','Upper bound fault','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
            d1.annouce("Warning :"+listenproject+"::"+device[j]+"::"+object[j]+"is over upper bound\n");
            d1.show();
          }
     }
     else if((tocheck[j].compareTo("LOWERBOUND")==0) && (datatype[j].compareTo("otInteger")==0))
     {
        long k = Long.parseLong(result);
        long kk = Long.parseLong(low[j]);
        if(k<kk)
         {
          String sdes ="Lower bound fault :"+listenproject+ ":"+object[j];
           // db.executeSQLupdate("INSERT INTO EVENT (EVENTNAME,EVENTTYPEID,EVENTDESCRIPTION,EVENTDATE,EVENTTIME)VALUES ('Lower Fault occur','01','"+sdes+"','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
            db.executeSQLupdate("INSERT INTO FAULTEVENT (PROJECTID,DEVICEID,OBJECTID,FAULTDESCRIPTION,FAULTDATE,FAULTTIME) VALUES ('"+listenproject+"','"+device[j]+"','"+object[j]+"','Lower bound fault','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");

            d1.annouce("Warning :"+listenproject+"::"+device[j]+"::"+object[j]+"is over lower bound\n");
           d1.show();
        }
     }
     else if((tocheck[j].compareTo("RANGE")==0) && (datatype[j].compareTo("otInteger")==0))
     {
        long k = Long.parseLong(result);
        long kk = Long.parseLong(low[j]);
        long kkk = Long.parseLong(up[j]);
         if((k<=kk)||(k>=kkk))
          {
            String sdes ="Out bound fault :"+listenproject+ ":"+object[j];
            //db.executeSQLupdate("INSERT INTO EVENT(EVENTNAME,EVENTTYPEID,EVENTDESCRIPTION,EVENTDATE,EVENTTIME) VALUES ('Out Fault occur','01','"+sdes+"','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");
            db.executeSQLupdate("INSERT INTO FAULTEVENT (PROJECTID,DEVICEID,OBJECTID,FAULTDESCRIPTION,FAULTDATE,FAULTTIME) VALUES ('"+listenproject+"','"+device[j]+"','"+object[j]+"','Out of range fault','"+(new Date(System.currentTimeMillis()).toString())+"','"+(new Time(System.currentTimeMillis()).toString())+"')");

            d1.annouce("Warning :"+listenproject+"::"+device[j]+"::"+object[j]+"is out of bound\n");
            d1.show();
        }
     }
     else if((tocheck[j].compareTo("EQUAL")==0) && (datatype[j].compareTo("string")==0))
    {
       long k = Long.parseLong(result);
       long kk = Long.parseLong(low[j]);
       long kkk = Long.parseLong(up[j]);
        if(result.compareTo(low[j])==0)
         {
           d1.annouce("Warning :"+listenproject+"::"+device[j]+"::"+object[j]+"error\n");
           d1.show();
       }
     }
     else if((tocheck[j].compareTo("EQUAL")==0) && (datatype[j].compareTo("otInteger")==0))
   {
      long k = Long.parseLong(result);
      long kk = Long.parseLong(low[j]);
      //long kkk = Long.parseLong(up[j]);
       if(k==kk)
        {
          d1.annouce("Warning :"+listenproject+"::"+device[j]+"::"+object[j]+"the value reach its bound\n");
          d1.show();
      }
     }
   }
 /*  else if(result.compareTo("*")==0){

     d1.annouce("SNMP timeout");
   }*/
   }
   }
   }
}
}