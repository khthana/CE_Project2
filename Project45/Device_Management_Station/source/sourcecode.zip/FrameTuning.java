package dms;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import java.sql.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FrameTuning extends JInternalFrame {
  private Desktop themain;
  private JTextField Value = new JTextField();
  private JButton Set = new JButton();
  private JButton Cancel = new JButton();
  String projectid;
  String leafpath;
  TreePath temp;
  String parent;
  String datatype;
  private Database db;
  MessageHandler m;

  DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");

  JTree Objecttree = new JTree(top);
  JScrollPane treeView = new JScrollPane(Objecttree);
  DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();

  DefaultMutableTreeNode node[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child[] = new DefaultMutableTreeNode[1000];
  private JTextArea Objectdetail = new JTextArea();
  private Border border1;
  private TitledBorder titledBorder1;
  private Border border2;
  private JLabel jLabel1 = new JLabel();


  public FrameTuning(String projectid,Desktop tm,Database d) {
    try {
      db = d;
       m = new MessageHandler(db);
      themain = tm;
      this.projectid = projectid;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border1,"OBJECT DETAIL");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);
    this.createNodes();

    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(111, 72, 299, 375));
    MouseListener ml = new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        int selRow = Objecttree.getRowForLocation(e.getX(), e.getY());
        TreePath selPath = Objecttree.getPathForLocation(e.getX(), e.getY());
        if(selRow != -1) {
          if(e.getClickCount() == 1) {
            //mySingleClick(selRow, selPath);

          }
          else if(e.getClickCount() == 2) {
            //myDoubleClick(selRow, selPath);
            DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

            TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
            if (Objecttree.isVisible(pathnode)) {

              if (node.isLeaf()) {
                leafpath = Objecttree.getLastSelectedPathComponent().toString();
                temp = Objecttree.getAnchorSelectionPath().getParentPath();
                parent = temp.getLastPathComponent().toString();
                ResultSet rs;

             //   Database db = new Database();
                datatype = "";
                String snmpobjectid = "";
                try
                {
                  //System.out.println(Servicetype.getItemAt(Servicetype.getSelectedIndex()));

                  rs = db.executeSQLquery("SELECT SNMPOBJECTID,DATATYPE FROM OBJECT OB,SNMPOBJECT SO WHERE OB.OBJECTID = SO.OBJECTID AND OB.DEVICEID = '" + parent + "' AND OB.OBJECTID = '" + leafpath + "'");

                  while (rs.next())
                  {
                    snmpobjectid = rs.getString("SNMPOBJECTID");
                    datatype = rs.getString("DATATYPE");
                  }

                }
                catch(SQLException ex)
                {
                  System.out.println(ex);
                }

                Objectdetail.setText("DEVICEID : " + parent + "\nOBJECTID : " + leafpath + "\nDATATYPE : " + datatype + "\nSNMPOBJECT : " + snmpobjectid + "\n");
              }
              else if (node.isRoot()) {
                System.out.println("root");
              }
              else if (node.isNodeAncestor(top)) {
                System.out.println("ancestor");
              }
            }
          }
        }
      }
    };
    Objecttree.addMouseListener(ml);

    Objectdetail.setEditable(false);
    Value.setBorder(border2);
    jLabel1.setText("VALUE");
    jLabel1.setBounds(new Rectangle(39, 474, 93, 28));
    Set.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Set_actionPerformed(e);
      }
    });
    this.getContentPane().add(treeView, null);
    Value.setBounds(new Rectangle(147, 470, 241, 31));
    this.getContentPane().setLayout(null);
    Set.setBounds(new Rectangle(506, 445, 86, 32));
    Set.setText("SET");
    Cancel.setBounds(new Rectangle(610, 446, 87, 31));
    Cancel.setText("CANCEL");
    Objectdetail.setBorder(titledBorder1);
    Objectdetail.setBounds(new Rectangle(477, 96, 357, 268));
    this.getContentPane().add(Cancel, null);
    this.getContentPane().add(Set, null);
    this.getContentPane().add(Objectdetail, null);
    this.getContentPane().add(Value, null);
    this.getContentPane().add(jLabel1, null);
    this.setTitle("TUNING");

    themain.addframe(this);
  }


  public void createNodes() {
  //  Database db = new Database();
    ResultSet rs;
    String objectid;
    int j=0;
    String[] devicelist;
    int devicenum =0;
    rs = db.executeSQLquery("SELECT COUNT(DISTINCT DEVICEID) FROM TUNING WHERE PROJECTID = '" + projectid + "'");
    try
    {
      while (rs.next())
      {
        devicenum = rs.getInt(1);
        //System.out.println("FrameTunning devicenum : " +devicenum);
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    devicelist = new String[devicenum];
    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM TUNING WHERE PROJECTID = '" + projectid + "'");
    j=0;
    try
    {
      while (rs.next())
      {
        devicelist[j] = rs.getString("DEVICEID");
        j++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }
    for (int i=0;i<devicenum;i++)
    {
      j = 0;
      //System.out.println(devicelist[i]);
      node[i] = new DefaultMutableTreeNode(devicelist[i]);

      top.add(node[i]);

      rs = db.executeSQLquery("SELECT * FROM TUNING WHERE PROJECTID = '" + projectid + "' AND DEVICEID = '" + devicelist[i] + "'");
      try
      {
        while (rs.next())
        {
          objectid = rs.getString("OBJECTID");
          child[j] = new DefaultMutableTreeNode(objectid);
          node[i].add(child[j]);
          j++;

        }
        }catch(SQLException ex)
        {
          System.out.println(ex);
        }


    }
  }

  void Set_actionPerformed(ActionEvent e) {
    if (Value.getText().compareTo("") != 0 )
    {
      System.out.println(leafpath);
      m.constructMessage(parent,leafpath,"SET","",datatype,Value.getText());
      m.sendMessage();
    }
    else
    {
      Objectdetail.append("Please insert value into the field");
    }

  }

}