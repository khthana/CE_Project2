package dms;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
import java.awt.event.*;
import com.klg.jclass.util.swing.*;
import java.sql.*;



/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FrameChooseObject extends JInternalFrame {
  private Desktop themain;
  private String[] objectofclickdevice;
  private int objectcount = 0;
  private String device;
  private JRadioButton Text = new JRadioButton();
  private JRadioButton Table = new JRadioButton();
  private JRadioButton Graph = new JRadioButton();
  private JLabel jLabel1 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private Border border1;
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JButton Ok = new JButton();
  String projectname;
  private JTextField Device = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JTextArea Objectdetail = new JTextArea();
  private Border border2;
  private TitledBorder titledBorder1;
  private Border border3;
  private Border border4;
  private JPanel jPanel2 = new JPanel();
  private Border border5;
  private Border border6;
  private Database db;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JList Objectlist = new JList();
  private DefaultListModel listModel;
  private JButton Close = new JButton();
  private GridBagLayout gridBagLayout1 = new GridBagLayout();
  private JComboBox Monitorvalue = new JComboBox();
  public FrameChooseObject(String device1,String[] objectclickdevice,int obcount,String pname,Desktop tm,Database d) {


    try {
      db = d;
      themain = tm;
      projectname =pname;
      objectofclickdevice = objectclickdevice;
      objectcount = obcount;
      device = device1;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.getContentPane().setBackground(Color.lightGray);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    listModel = new DefaultListModel();
    Objectlist = new JList(listModel);
    Objectlist.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    Objectlist.setSelectedIndex(0);
    Objectlist.addListSelectionListener(new javax.swing.event.ListSelectionListener()
    {
      public void valueChanged(javax.swing.event.ListSelectionEvent e) {
        Objectlist_valueChanged(e);
      }
    });
    border6 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    this.setSize(new Dimension(800,600));
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border2,"OBJECT DETAIL");
    border3 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border4 = BorderFactory.createEtchedBorder(Color.white,new Color(156, 156, 158));
    border5 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158)),"CHOOSE OBJECT");

    Device.setBorder(border3);
    Device.setEditable(false);
    Device.setText(device);
    border1 = BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(109, 109, 110),new Color(156, 156, 158)),BorderFactory.createEmptyBorder(6,6,6,6));
    this.getContentPane().setLayout(null);
/*    Objectlist1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Objectlist1_actionPerformed(e);
      }
    });*/
    for (int i=0;i<objectcount;i++)
    {
      listModel.addElement(objectofclickdevice[i]);
      //Objectlist1.add(objectofclickdevice[i]);
    }


    Text.setSelected(true);
    Text.setText("Text");
    Table.setText("Table");
    Graph.setText("Graph");
    jLabel1.setText("OBJECT LIST");
    jLabel1.setBounds(new Rectangle(22, 70, 139, 29));
    jPanel1.setBorder(border1);
    jPanel1.setBounds(new Rectangle(367, 99, 241, 111));
    jPanel1.setLayout(gridBagLayout1);
    Ok.setBounds(new Rectangle(404, 261, 97, 32));
    Ok.setBorder(border4);
    Ok.setText("SELECT");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Device.setBounds(new Rectangle(128, 27, 339, 30));
    jLabel2.setText("DEVICE");
    jLabel2.setBounds(new Rectangle(29, 28, 90, 27));
    Objectdetail.setBorder(titledBorder1);
    Objectdetail.setEditable(false);
    Objectdetail.setBounds(new Rectangle(23, 433, 497, 113));
    jPanel2.setBorder(border5);
    jPanel2.setBounds(new Rectangle(21, 26, 696, 360));
    jPanel2.setLayout(null);
    jScrollPane1.setBounds(new Rectangle(17, 104, 276, 227));
    Close.setBounds(new Rectangle(576, 506, 122, 32));
    Close.setText("CLOSE");
    Close.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Close_actionPerformed(e);
      }
    });

    jPanel1.add(Text,           new GridBagConstraints(0, 0, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(5, 5, 0, 91), 69, 0));
    jPanel1.add(Table,       new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 5, 0, 92), 63, 0));
    jPanel1.add(Graph,           new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 5, 5, 0), 4, 0));
    jPanel1.add(Monitorvalue,   new GridBagConstraints(1, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(0, 0, 0, 0), 11, 0));
    jPanel2.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(Objectlist, null);
    this.getContentPane().add(Close, null);
    this.getContentPane().add(Objectdetail, null);
    this.getContentPane().add(jPanel2, null);
    jPanel2.add(Ok, null);
    jPanel2.add(Device, null);
    jPanel2.add(jLabel2, null);
    jPanel2.add(jLabel1, null);
    jPanel2.add(jPanel1, null);
    buttonGroup1.add(Text);
    buttonGroup1.add(Table);
    buttonGroup1.add(Graph);
    this.setTitle("CHOOSE OBJECT");
    Monitorvalue.addItem("plot");
    Monitorvalue.addItem("bar");
    Monitorvalue.addItem("area");
    themain.addframe(this);

  }

  void Ok_actionPerformed(ActionEvent e) {
    String objectselect = Objectlist.getSelectedValue().toString();
    String[] name = new String[1];
    name[0] = objectselect;
    String[][] deviceobjectid= new String[1][2];
    deviceobjectid[0][0] = device;
    deviceobjectid[0][1] = objectselect;
    if (Objectlist.getSelectedIndex()  != -1)
    {
      if (Text.isSelected())
      {
        FrameText f = new FrameText(1,null,deviceobjectid,objectselect,projectname,themain,db);
        //f.pack();
        f.setSize(new Dimension(800,600));
        f.setVisible(true);
      }
      else if(Table.isSelected())
      {
        FrameTable f = new FrameTable(1,name,deviceobjectid,null,projectname,themain,db);
        //f.pack();
        f.setSize(new Dimension(800,600));
        f.setVisible(true);
      }
      else if (Graph.isSelected())
      {


        JCExitFrame f = new JCExitFrame("Strip Chart");
        StripChart2 s = new StripChart2(1,name,deviceobjectid,Monitorvalue.getSelectedItem().toString(),db);
        s.passframe(f);
        f.getContentPane().add("Center",s);
        f.pack();
        f.setVisible(true);
      }
    }



  }



  void Close_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  public void Objectlist_valueChanged(javax.swing.event.ListSelectionEvent e) {
    ResultSet rs;
    String objectid = "";
    String objecttype = "";
    String snmpobjectid = "";
    String community = "";

   // Database db = new Database();
    try
    {
      //System.out.println(Servicetype.getItemAt(Servicetype.getSelectedIndex()));

       rs = db.executeSQLquery("SELECT OB.OBJECTID,DATATYPE,SNMPOBJECTID,COMMUNITY FROM OBJECT OB,SNMPOBJECT SO WHERE OB.OBJECTID = SO.OBJECTID AND OB.OBJECTID = '" + Objectlist.getSelectedValue().toString()  + "' AND OB.DEVICEID = '" + device + "'");

      while (rs.next())
      {
        objectid = rs.getString("OBJECTID");
        objecttype = rs.getString("DATATYPE");
        snmpobjectid = rs.getString("SNMPOBJECTID");
        community = rs.getString("COMMUNITY");

      }

    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

    Objectdetail.setText("OBJECTID : " + objectid + "\nOBJECTTYPE : " + objecttype + "\nSNMPOBJECTID : " + snmpobjectid + "\nCOMMUNITY : " + community);
  }
}