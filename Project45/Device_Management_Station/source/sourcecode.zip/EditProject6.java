package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.tree.*;
import java.sql.*;
import javax.swing.event.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditProject6 extends JPanel {
  private String[] deviceobject;
  private Database db;
  private JComboBox Selectproject = new JComboBox();


  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private JLabel jLabel1 = new JLabel();

  DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");

  JTree Objecttree = new JTree(top);
  JScrollPane treeView = new JScrollPane(Objecttree);
  DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();



  DefaultMutableTreeNode node[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child[] = new DefaultMutableTreeNode[1000];
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JButton Set = new JButton();
  private JComboBox Selectfault = new JComboBox();
  private JLabel jLabel2 = new JLabel();
  private JTextField Faultname = new JTextField();
  private JTextField Faultcheck = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JRadioButton Addfault = new JRadioButton();
  private JRadioButton Editfault = new JRadioButton();
  private JRadioButton Deletefault = new JRadioButton();
  private JTextField Faultid = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JTextField Faultvalue = new JTextField();
  private JLabel jLabel6 = new JLabel();
  private JTextField Faultvalue2 = new JTextField();
  private JLabel jLabel7 = new JLabel();
  private JTextField Deviceid = new JTextField();
  private JTextField Objectid = new JTextField();
  private JLabel jLabel8 = new JLabel();
  private JLabel jLabel9 = new JLabel();
  private Border border1;
  private Border border2;


  public EditProject6(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border2 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    this.setLayout(null);
    Selectproject.setBounds(new Rectangle(190, 21, 285, 28));

    Ok.setBounds(new Rectangle(646, 523, 107, 27));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(773, 521, 102, 30));
    Cancel.setText("CANCEL");
    jLabel1.setText("SELECT PROJECT");
    jLabel1.setBounds(new Rectangle(70, 18, 117, 30));
    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(111, 72, 299, 375));
    Objecttree.setShowsRootHandles(true);
    Set.setBounds(new Rectangle(378, 335, 110, 28));
    Set.setText("SET");
    Set.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Set_actionPerformed(e);
      }
    });
    Selectfault.setBounds(new Rectangle(190, 80, 286, 29));

    jLabel2.setText("SELECT FAULT ID");
    jLabel2.setBounds(new Rectangle(68, 79, 117, 28));
    Faultname.setBorder(border1);
    Faultname.setEditable(false);
    Faultname.setBounds(new Rectangle(649, 203, 228, 28));
    Faultcheck.setBorder(border1);
    Faultcheck.setEditable(false);
    Faultcheck.setBounds(new Rectangle(649, 255, 228, 28));
    jLabel3.setText("FAULT NAME");
    jLabel3.setBounds(new Rectangle(530, 204, 113, 22));
    jLabel4.setText("FAULT CHECK");
    jLabel4.setBounds(new Rectangle(530, 254, 116, 23));
    jPanel1.setBorder(border2);
    jPanel1.setBounds(new Rectangle(537, 14, 155, 102));
    jPanel1.setLayout(verticalFlowLayout1);
    Addfault.setSelected(true);
    Addfault.setText("ADD FAULT");
    Addfault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Addfault_actionPerformed(e);
      }
    });
    Editfault.setText("EDIT FAULT");
    Editfault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Editfault_actionPerformed(e);
      }
    });
    Deletefault.setText("DELETE FAULT");
    Deletefault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Deletefault_actionPerformed(e);
      }
    });
    Faultid.setEnabled(false);
    Faultid.setBorder(border1);
    Faultid.setBounds(new Rectangle(649, 151, 228, 28));
    jLabel5.setText("FAULTID");
    jLabel5.setBounds(new Rectangle(530, 152, 103, 25));
    Faultvalue.setBorder(border1);
    Faultvalue.setBounds(new Rectangle(650, 411, 228, 28));
    jLabel6.setText("FAULT VALUE");
    jLabel6.setBounds(new Rectangle(531, 410, 121, 29));
    Faultvalue2.setBorder(border1);
    Faultvalue2.setBounds(new Rectangle(649, 463, 228, 28));
    jLabel7.setText("FAULT VALUE2");
    jLabel7.setBounds(new Rectangle(530, 466, 107, 30));
    Deviceid.setBorder(border1);
    Deviceid.setBounds(new Rectangle(649, 307, 228, 28));
    Objectid.setBorder(border1);
    Objectid.setBounds(new Rectangle(649, 359, 228, 28));
    jLabel8.setText("DEVICEID");
    jLabel8.setBounds(new Rectangle(530, 304, 110, 25));
    jLabel9.setText("OBJECTID");
    jLabel9.setBounds(new Rectangle(530, 356, 66, 26));

    Objecttree.setEditable(true);
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);


    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(68, 155, 282, 355));

    jPanel1.add(Addfault, null);
    jPanel1.add(Editfault, null);
    jPanel1.add(Deletefault, null);
    this.add(Cancel, null);
    this.add(Ok, null);
    this.add(Selectproject, null);
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    this.add(Selectfault, null);
    this.add(jPanel1, null);
    this.add(jLabel6, null);
    this.add(Faultvalue, null);
//    jScrollPane1.getViewport().add(Devicelist, null);



   // Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT");
      while (rs.next())
      {
        Selectproject.addItem(rs.getString("PROJECTID"));
      }

      rs = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "'");
      while (rs.next())
      {
        Selectfault.addItem(rs.getString("FAULTID"));
      }

    }
    catch(SQLException sql)
    {
      System.out.println("EditProject6 : " + sql);
    }



    ResultSet rs;
/*
    rs = db.executeSQLquery("SELECT COUNT(*) FROM FAULT WHERE FAULTID = '" +Selectfault.getSelectedItem().toString() + "'");
    int count=0;
    while(rs.next())
    {
      count = rs.getInt(1);
    }
    deviceobject = new String[count];*/
    if (Selectfault.getSelectedIndex() != -1)
    {
      rs = db.executeSQLquery("SELECT * FROM FAULT WHERE FAULTID = '" + Selectfault.getSelectedItem().toString() + "'");
      //int i = 0;
      while(rs.next())
      {

        //   String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
        // deviceobject[i] = temp;
        //  listModel.addElement(temp);
        //  System.out.println(temp);
        //   i++;
        Faultid.setText(rs.getString("FAULTID"));
        Faultname.setText(rs.getString("FAULTNAME"));
        Deviceid.setText(rs.getString("DEVICEID"));
        Objectid.setText(rs.getString("OBJECTID"));
        Faultcheck.setText(rs.getString("FAULTCHECK"));
        Faultvalue.setText(rs.getString("FAULTVALUE"));
        Faultvalue2.setText(rs.getString("FAULTVALUE2"));
      }
    }




    Selectproject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectproject_actionPerformed(e);
      }
    });

    Selectfault.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectfault_actionPerformed(e);
      }
    });

    createNodes();

    buttonGroup1.add(Addfault);
    buttonGroup1.add(Editfault);
    buttonGroup1.add(Deletefault);
    this.add(Faultid, null);
    this.add(Objectid, null);
    this.add(treeView, null);
    this.add(Set, null);
    this.add(jLabel5, null);
    this.add(jLabel3, null);
    this.add(jLabel4, null);
    this.add(jLabel8, null);
    this.add(Faultname, null);
    this.add(Faultcheck, null);
    this.add(Deviceid, null);
    this.add(jLabel9, null);
    this.add(jLabel7, null);
    this.add(Faultvalue2, null);
  }

  public void createNodes() {
    //Database db = new Database();
    ResultSet rs;
    ResultSet rs2;
    String objectid="";
    String deviceid="";
    int j=0;

    rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM OBJECT");
    int i=0;
    try
    {
      while (rs.next())
      {
        deviceid = rs.getString("DEVICEID");
        j = 0;
        node[i] = new DefaultMutableTreeNode(deviceid);
        top.add(node[i]);

        rs2 = db.executeSQLquery("SELECT * FROM OBJECT WHERE DEVICEID = '" + deviceid + "'");

        while (rs2.next())
        {
          objectid = rs2.getString("OBJECTID");
          child[j] = new DefaultMutableTreeNode(objectid);
          node[i].add(child[j]);
          j++;

        }

        i++;
      }
    }
    catch(SQLException ex)
    {
      System.out.println(ex);
    }

  }

  void Ok_actionPerformed(ActionEvent e) {
   // Database db = new Database();
    if (Addfault.isSelected())
    {
      if (Objectid.getText().compareTo("") != 0 && Deviceid.getText().compareTo("") != 0 && Faultvalue2.getText().compareTo("") != 0 && Faultvalue.getText().compareTo("") != 0 && Faultid.getText().compareTo("") != 0 && Faultname.getText().compareTo("") != 0 && Faultcheck.getText().compareTo("") != 0)
      {
        db.executeSQLupdate("INSERT INTO FAULT (FAULTID,FAULTNAME,PROJECTID,DEVICEID,OBJECTID,FAULTCHECK,FAULTVALUE,FAULTVALUE2) VALUES('" + Faultid.getText() + "' , '" + Faultname.getText() + "' , '" + Selectproject.getSelectedItem().toString() + "' , '" + Deviceid.getText() + "' , '" + Objectid.getText() + "' , '" + Faultcheck.getText() + "' , '" + Faultvalue.getText() + "' , '" + Faultvalue2.getText() + "')");

      }
    }
    else if (Editfault.isSelected())
    {
      if (Deviceid.getText().compareTo("") != 0 && Faultvalue2.getText().compareTo("") != 0 && Faultvalue.getText().compareTo("") != 0 && Faultid.getText().compareTo("") != 0 && Faultname.getText().compareTo("") != 0 && Faultcheck.getText().compareTo("") != 0)
      {
        db.executeSQLupdate("UPDATE FAULT SET FAULTNAME = '" + Faultname.getText() + "',PROJECTID = '" + Selectproject.getSelectedItem().toString() + "',DEVICEID = '" + Deviceid.getText() + "',OBJECTID = '" +Objectid.getText() +"',FAULTCHECK = '" + Faultcheck.getText() + "',FAULTVALUE = '" + Faultvalue.getText() +"',FAULTVALUE2 = '" + Faultvalue2.getText() + "' WHERE FAULTID = '" + Selectfault.getSelectedItem().toString() + "'");

      }


    }
    else if (Deletefault.isSelected())
    {
      db.executeSQLupdate("DELETE FROM FAULT WHERE FAULTID = '" + Selectfault.getSelectedItem().toString() + "'");
    }



  }

  public void Devicelist_valueChanged(ListSelectionEvent e) {

  }

  void Set_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

 TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
 if (Objecttree.isVisible(pathnode)) {

  if (node.isLeaf()) {
    String leafpath = Objecttree.getLastSelectedPathComponent().toString();
    TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
    String parent = temp.getLastPathComponent().toString();
    //System.out.println(leafpath);
    //System.out.println(parent);
/*    if (listModel.indexOf(parent + " , " + leafpath) == -1)
    {
      listModel.addElement(parent + " , " + leafpath);
    }*/
    Deviceid.setText(parent);
    Objectid.setText(leafpath);

    }
    else if (node.isRoot()) {
        System.out.println("root");
    }
    else if (node.isNodeAncestor(top)) {
      System.out.println("ancestor");
    }
 }


  }

  void Remove_actionPerformed(ActionEvent e) {

  }



  void Selectproject_actionPerformed(ActionEvent e) {
    ResultSet rs;
   // Database db = new Database();
    Selectfault.removeAllItems();

    try
    {


      rs = db.executeSQLquery("SELECT * FROM FAULT WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "'");
      while (rs.next())
      {

        Selectfault.addItem(rs.getString("FAULTID"));
      }


    }

    catch(SQLException sql)
    {
      System.out.println("EditProject6 : " + sql);
    }

 /*   listModel.removeAllElements();
    rs = db.executeSQLquery("SELECT COUNT(*) FROM MONITORGROUP WHERE GROUPID = '" +Selectfault.getSelectedItem() + "'");
    int count=0;
    try
    {
      while(rs.next())
      {
        count = rs.getInt(1);
      }
      deviceobject = new String[count];
      rs = db.executeSQLquery("SELECT * FROM MONITORGROUP WHERE GROUPID = '" + Selectfault.getSelectedItem() + "'");
      int i = 0;
      while(rs.next())
      {

        String temp = rs.getString("DEVICEID") + " , " + rs.getString("OBJECTID");
        deviceobject[i] = temp;
        listModel.addElement(temp);
        System.out.println(temp);
        i++;

      }
    }
    catch(SQLException ee)
    {
      System.out.println(ee);
    }*/

  }

  void Selectfault_actionPerformed(ActionEvent e) {


 /*   ResultSet rs;
   // Database db = new Database();
    if (Selectfault.getItemCount() !=0 )
    {

     // int count=0;
      rs = db.executeSQLquery("SELECT * FROM FAULT WHERE FAULTID = '" + Selectfault.getSelectedItem().toString() + "'");


      try
      {

        while(rs.next())
        {

          Faultid.setText(rs.getString("FAULTID"));
          Faultname.setText(rs.getString("FAULTNAME"));
          Deviceid.setText(rs.getString("DEVICEID"));
          Objectid.setText(rs.getString("OBJECTID"));
          Faultcheck.setText(rs.getString("FAULTCHECK"));
          Faultvalue.setText(rs.getString("FAULTVALUE"));
          Faultvalue2.setText(rs.getString("FAULTVALUE2"));
        }


      }
      catch(SQLException ee)
      {
        System.out.println(e);
      }
    }*/

  }

  void Editfault_actionPerformed(ActionEvent e) {
    Selectfault.setEnabled(true);
    Faultid.setEnabled(false);
    Faultid.setEditable(false);
    Deviceid.setEditable(true);
    Objectid.setEditable(true);
    Faultname.setEditable(true);
    Faultcheck.setEditable(true);
    Faultvalue.setEditable(true);
    Faultvalue2.setEditable(true);

   // Database db = new Database();
    ResultSet rs = db.executeSQLquery("SELECT * FROM FAULT WHERE FAULTID = '" + Selectfault.getSelectedItem().toString() + "'");


      try
      {

        while(rs.next())
        {

          Faultid.setText(rs.getString("FAULTID"));
          Faultname.setText(rs.getString("FAULTNAME"));
          Deviceid.setText(rs.getString("DEVICEID"));
          Objectid.setText(rs.getString("OBJECTID"));
          Faultcheck.setText(rs.getString("FAULTCHECK"));
          Faultvalue.setText(rs.getString("FAULTVALUE"));
          Faultvalue2.setText(rs.getString("FAULTVALUE2"));
        }


      }
      catch(SQLException ee)
      {
        System.out.println(e);
      }
  }

  void Addfault_actionPerformed(ActionEvent e) {
    Selectfault.setEnabled(false);
    Faultid.setEnabled(true);
    Faultid.setEditable(true);
    Faultname.setEditable(true);
    Deviceid.setEditable(true);
    Objectid.setEditable(true);
    Faultcheck.setEditable(true);
    Faultvalue.setEditable(true);
    Faultvalue2.setEditable(true);

    Faultid.setText("");
    Faultname.setText("");
    Deviceid.setText("");
    Objectid.setText("");
    Faultcheck.setText("");
    Faultvalue.setText("");
    Faultvalue2.setText("");


//    listModel.removeAllElements();

  }

  void Deletefault_actionPerformed(ActionEvent e) {
    Selectfault.setEnabled(true);
    Faultid.setEnabled(false);
    Faultname.setEditable(false);
    Deviceid.setEditable(false);
    Objectid.setEditable(false);
    Faultcheck.setEditable(false);
    Faultvalue.setEditable(false);
    Faultvalue2.setEditable(false);

    //Database db = new Database();
    ResultSet rs = db.executeSQLquery("SELECT * FROM FAULT WHERE FAULTID = '" + Selectfault.getSelectedItem().toString() + "'");


      try
      {

        while(rs.next())
        {

          Faultid.setText(rs.getString("FAULTID"));
          Faultname.setText(rs.getString("FAULTNAME"));
          Deviceid.setText(rs.getString("DEVICEID"));
          Objectid.setText(rs.getString("OBJECTID"));
          Faultcheck.setText(rs.getString("FAULTCHECK"));
          Faultvalue.setText(rs.getString("FAULTVALUE"));
          Faultvalue2.setText(rs.getString("FAULTVALUE2"));
        }


      }
      catch(SQLException ee)
      {
        System.out.println(e);
      }
  }

}