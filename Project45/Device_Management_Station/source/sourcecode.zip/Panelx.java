package dms;

import java.awt.*;
import javax.swing.JPanel;
import javax.swing.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Panelx extends JPanel {
  private BorderLayout borderLayout1 = new BorderLayout();

  public Panelx() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(borderLayout1);
  }
  public void paint(Graphics g)
  {
    Image im = Toolkit.getDefaultToolkit().createImage("c:/device.jpg").getScaledInstance(760,760,760);
    ImageIcon imm = new ImageIcon(im);
    imm.paintIcon(this,g,10,10);
  }
}