package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Dialog1 extends JDialog {
  private JPanel panel1 = new JPanel();
  private JButton jButton1 = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea jTextArea1 = new JTextArea();

  public Dialog1(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public Dialog1() {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(null);
    this.setSize(500,500);

    jButton1.setBounds(new Rectangle(129, 246, 98, 40));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(20, 23, 346, 197));
    getContentPane().add(panel1);
    panel1.add(jButton1, null);
    panel1.add(jScrollPane1, null);
    jScrollPane1.getViewport().add(jTextArea1, null);

  }
  public void annouce(String st)
  {
     jTextArea1.append(st);
  }
  void jButton1_actionPerformed(ActionEvent e) {
     this.hide();
  }
}