package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FrameText extends JInternalFrame {
  private Desktop themain;
  // Variable for performance
  private Database db;
  String[][] deviceobjectid;
  String data = new String("");
  String groupid = "";
  String projectid = "";

  int numofdevice = 0;
  boolean flag=false;
  Framethread framethread;
  int count = 0;
  private Border border1;
  private Border border2;
  private JPanel jPanel1 = new JPanel();
  private Border border3;
  private JTextField Group = new JTextField();
  private JToggleButton Start = new JToggleButton();
  private JTextArea Textmonitor = new JTextArea();
  private JLabel jLabel1 = new JLabel();
  private Border border4;
  private TitledBorder titledBorder1;
  private JButton Close = new JButton();




  public FrameText() {
    try {

      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public FrameText(int numofdevice,String[] name,String[][] deviceobjectid,String groupid,String projectid,Desktop tm,Database d) {
    try {
      db =d;
      themain = tm;
      this.groupid = groupid;
      this.projectid = projectid;
      this.numofdevice = numofdevice;
      this.deviceobjectid = deviceobjectid;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setResizable(true);
    this.getContentPane().setBackground(Color.lightGray);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    border1 = BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(109, 109, 110),new Color(156, 156, 158));
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178));
    border3 = new TitledBorder(new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(156, 156, 158)),"MONITOR (TEXT)");
    border4 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border4,"DISPLAY");
    this.setSize(new Dimension(800,600));
    this.getContentPane().setLayout(null);
    jPanel1.setBorder(border3);
    jPanel1.setBounds(new Rectangle(62, 34, 752, 505));
    jPanel1.setLayout(null);
    Group.setBorder(border2);
    Group.setEditable(false);
    Group.setBounds(new Rectangle(136, 50, 358, 34));
    Group.setText(groupid);
    Start.setText("START / STOP");
    Start.setBounds(new Rectangle(578, 363, 129, 33));
    Start.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Start_actionPerformed(e);
      }
    });
    jLabel1.setText("GROUP");
    jLabel1.setBounds(new Rectangle(49, 51, 74, 34));
    Textmonitor.setBorder(titledBorder1);
    Textmonitor.setEditable(false);
    Textmonitor.setBounds(new Rectangle(52, 118, 514, 363));
    Close.setBounds(new Rectangle(578, 416, 129, 29));
    Close.setText("CLOSE");
    Close.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Close_actionPerformed(e);
      }
    });
    jPanel1.add(Group, null);
    jPanel1.add(jLabel1, null);
    jPanel1.add(Textmonitor, null);
    jPanel1.add(Start, null);
    jPanel1.add(Close, null);
    this.getContentPane().add(jPanel1, null);
    framethread = new Framethread(numofdevice,deviceobjectid,this,db);
    this.setTitle("MONITOR (TEXT)");
    themain.addframe(this);

    }


  void Start_actionPerformed(ActionEvent e) {
    if (Start.isSelected())
    {
      if (count == 0)
      {
        framethread.start();
        count = 1;
      }
      else
      {
        framethread.resume();
      }


    }
    else
    {
      framethread.suspend();
    }


  }

  public void setvalue(String[] value)
  {
    //Textmonitor.append(value[0] + " " + value[1] + " " + value[2] + "\n");
    String temp = value[0] + " " + value[1] + "  :  " + value[2] + "\n";
    //System.out.println("Frametable setvalue: temp = " + temp);
    data = data+temp;

    //System.out.println("Frametable setvalue: data = " + data);
  }

  public void write()
  {
    Textmonitor.setText(data);
    data = "";

  }

  void Close_actionPerformed(ActionEvent e) {
    framethread.stop();
    this.dispose();
  }

}