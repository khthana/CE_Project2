package dms;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import ipworks.*;

public class SnmpAgent extends JFrame {
  int sysUpTime = 0;

  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JTextField txtOIDVal0 = new JTextField();
  JTextField txtOIDVal1 = new JTextField();
  JTextField txtOIDVal2 = new JTextField();
  JTextField txtOIDVal3 = new JTextField();
  JTextField txtOIDVal4 = new JTextField();
  JTextField txtOIDVal5 = new JTextField();
  JTextField txtOIDVal6 = new JTextField();
  JButton buttonStartStop = new JButton();
  JButton buttonSendTrap = new JButton();
  JLabel jLabel8 = new JLabel();
  JTextField remoteHost = new JTextField();
  Snmp snmp1 = new Snmp();
  GridBagLayout gridBagLayout1 = new GridBagLayout();

  public SnmpAgent() {
    try {
      snmp1.setLocalPort(161);
      jbInit();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    jLabel1.setText("System Description");
    this.setSize(new Dimension(383, 411));
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    this.setTitle("Snmp Agent");
    this.getContentPane().setLayout(gridBagLayout1);
    jLabel2.setText("System Object ID");
    jLabel3.setText("System Up Time");
    jLabel4.setText("System Contact");
    jLabel5.setText("System Name");
    jLabel6.setToolTipText("");
    jLabel6.setText("System Location");
    jLabel7.setText("System Services");
    txtOIDVal0.setText("My System");
    txtOIDVal1.setText("1.3.6.1.4.1.127.0.0.1");
    txtOIDVal2.setText("0");
    txtOIDVal3.setText("/n software: sales@nsoftware.com");
    txtOIDVal4.setText("localhost");
    txtOIDVal5.setText("(unknown)");
    txtOIDVal6.setText("0");
    buttonStartStop.setText("Start Listening");
    buttonStartStop.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonStartStop_actionPerformed(e);
      }
    });
    buttonSendTrap.setText("Send Trap");
    buttonSendTrap.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonSendTrap_actionPerformed(e);
      }
    });
    jLabel8.setText("Remote Host");
    remoteHost.setText("255.255.255.255");
    snmp1.addSnmpEventListener(new ipworks.SnmpEventListener() {
      public void error(SnmpErrorEvent e) {
      }
      public void getBulkRequest(SnmpGetBulkRequestEvent e) {
      }
      public void getNextRequest(SnmpGetNextRequestEvent e) {
        snmp1_getNextRequest(e);
      }
      public void getRequest(SnmpGetRequestEvent e) {
        snmp1_getRequest(e);
      }
      public void getResponse(SnmpGetResponseEvent e) {
      }
      public void informRequest(SnmpInformRequestEvent e) {
      }
      public void PDUTrace(SnmpPDUTraceEvent e) {
      }
      public void readyToSend(SnmpReadyToSendEvent e) {
      }
      public void setRequest(SnmpSetRequestEvent e) {
        snmp1_setRequest(e);
      }
      public void trap(SnmpTrapEvent e) {
      }
    });
    this.getContentPane().add(txtOIDVal0,  new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(22, 18, 0, 17), 141, 0));
    this.getContentPane().add(remoteHost,  new GridBagConstraints(1, 8, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(19, 18, 0, 17), 106, 0));
    this.getContentPane().add(buttonSendTrap,  new GridBagConstraints(1, 9, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(12, 18, 22, 85), 44, 0));
    this.getContentPane().add(jLabel8,  new GridBagConstraints(0, 8, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(22, 14, 0, 38), 20, 0));
    this.getContentPane().add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(22, 14, 0, 0), 24, 0));
    this.getContentPane().add(jLabel2,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(19, 14, 0, 0), 37, 0));
    this.getContentPane().add(jLabel3,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 14, 0, 0), 40, 0));
    this.getContentPane().add(jLabel4,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 14, 0, 0), 45, 0));
    this.getContentPane().add(jLabel5,  new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 14, 0, 0), 53, 0));
    this.getContentPane().add(jLabel6,  new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 14, 0, 0), 40, 0));
    this.getContentPane().add(jLabel7,  new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(21, 14, 0, 0), 40, 0));
    this.getContentPane().add(txtOIDVal6,  new GridBagConstraints(1, 6, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(19, 18, 0, 17), 192, 0));
    this.getContentPane().add(txtOIDVal5,  new GridBagConstraints(1, 5, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(19, 18, 0, 17), 141, 0));
    this.getContentPane().add(txtOIDVal4,  new GridBagConstraints(1, 4, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(19, 18, 0, 17), 149, 0));
    this.getContentPane().add(txtOIDVal3,  new GridBagConstraints(1, 3, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(19, 18, 0, 17), 9, 0));
    this.getContentPane().add(txtOIDVal2,  new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(19, 18, 0, 17), 192, 0));
    this.getContentPane().add(txtOIDVal1,  new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(17, 18, 0, 17), 88, 0));
    this.getContentPane().add(buttonStartStop,  new GridBagConstraints(1, 7, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(14, 18, 0, 85), 22, 0));
  }

  void this_windowClosing(WindowEvent e) {
    System.exit(0);
  }

  void buttonStartStop_actionPerformed(ActionEvent e) {
    try {
      if (snmp1.isActive()) {
        sysUpTime = 0;
        txtOIDVal2.setText("" + sysUpTime);
      } else {
        snmp1.setRemoteHost(remoteHost.getText());
      }

      snmp1.setActive(!snmp1.isActive());
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(this, ipwe.getMessage());
    }

    //timer1.Enabled = snmp1.Active;
    buttonStartStop.setText(snmp1.isActive() ? "Stop Listening" : "Start Listening");
  }

  void buttonSendTrap_actionPerformed(ActionEvent e) {
    boolean initialState = snmp1.isActive();
    try {
      snmp1.reset();
      snmp1.setTrapEnterprise(txtOIDVal1.getText());
      snmp1.setTrapGenericType(Snmp.tgtEnterpriseSpecific);
      snmp1.setTrapSpecificType(777);
      snmp1.setTrapTimeStamp(Integer.parseInt(txtOIDVal2.getText()));
      snmp1.setRemoteHost(remoteHost.getText());
      snmp1.sendTrap();
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(this, ipwe.getMessage());
    }

    if (!initialState) try {
      snmp1.setActive(false);
    } catch (IPWorksException ipwe) {
    }
  }

  void snmp1_getRequest(SnmpGetRequestEvent e) {
    try {
      snmp1.setRemoteHost(e.sourceAddress);
      snmp1.setRemotePort(e.sourcePort);
      for (int i = 1; i <= snmp1.getObjCount(); i++){
        setOIDVals(getIndex(snmp1.getObjId(i)), i);
      }
      snmp1.sendGetResponse();
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(this, ipwe.getMessage());
    }

    try {
      snmp1.reset();
    } catch (IPWorksException ipwe) {
    }
  }

  void snmp1_getNextRequest(SnmpGetNextRequestEvent e) {
    try {
      snmp1.setRemoteHost(e.sourceAddress);
      snmp1.setRemotePort(e.sourcePort);
      int oidIdx = getIndex(snmp1.getObjId(1)) + 1;
      if (oidIdx >= 0 && oidIdx < 8){ //within OID value range
        snmp1.setObjId(1, "1.3.6.1.2.1.1." + oidIdx + ".0");
        setOIDVals(oidIdx, 1);
        snmp1.sendGetResponse();
      }
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(this, ipwe.getMessage());
    }

    try {
      snmp1.reset();
    } catch (IPWorksException ipwe) {
    }
  }

  private int getIndex(String OID) {
    return
      OID.equals("1.3.6.1.2.1.1.1.0") ? 1 :
      OID.equals("1.3.6.1.2.1.1.2.0") ? 2 :
      OID.equals("1.3.6.1.2.1.1.3.0") ? 3 :
      OID.equals("1.3.6.1.2.1.1.4.0") ? 4 :
      OID.equals("1.3.6.1.2.1.1.5.0") ? 5 :
      OID.equals("1.3.6.1.2.1.1.6.0") ? 6 :
      OID.equals("1.3.6.1.2.1.1.7.0") ? 7 : 0;
  }

  private void setOIDVals(int OIDidx, int Index) throws IPWorksException {
    int type = 0;
    switch(OIDidx) {
      case 1: type = Snmp.otOctetString; break;
      case 2: type = Snmp.otObjectId;break;
      case 3: type = Snmp.otTimeTicks;break;
      case 4: type = Snmp.otOctetString;break;
      case 5: type = Snmp.otOctetString;break;
      case 6: type = Snmp.otOctetString;break;
      case 7: type = Snmp.otInteger;break;
      default: snmp1.setErrorStatus(2); return;
    }

    String value = "";
    switch(OIDidx) {
      case 1: value = txtOIDVal0.getText();break;
      case 2: value = txtOIDVal1.getText();break;
      case 3: value = txtOIDVal2.getText();break;
      case 4: value = txtOIDVal3.getText();break;
      case 5: value = txtOIDVal4.getText();break;
      case 6: value = txtOIDVal5.getText();break;
      case 7: value = txtOIDVal6.getText();break;
    }

    snmp1.setCommunity("public");
    snmp1.setObjType(Index, type);
    snmp1.setObjValue(Index, value.getBytes());
  }

  void snmp1_setRequest(SnmpSetRequestEvent e) {
    try {
      for (int i = 1; i <= snmp1.getObjCount(); i++) {
        int oidIdx = getIndex(snmp1.getObjId(i));
        String value = new String(snmp1.getObjValue(i));
        switch(oidIdx) {
          case 1: txtOIDVal0.setText(value);break;
          case 2: txtOIDVal1.setText(value);break;
          case 3: txtOIDVal2.setText(value);break;
          case 4: txtOIDVal3.setText(value);break;
          case 5: txtOIDVal4.setText(value);break;
          case 6: txtOIDVal5.setText(value);break;
          case 7: txtOIDVal6.setText(value);break;
        }
      }
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(this, ipwe.getMessage());
    }

    try {
      snmp1.reset();
    } catch (IPWorksException ipwe) {
    }
  }

  public static void main(String[] args) {
    (new SnmpAgent()).setVisible(true);
  }
}