package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Testcreatet extends JFrame {
  private JButton jButton1 = new JButton();
  private Database db;
  public Testcreatet(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
 /* public static void main(String[] argv)
  {
    Testcreatet tct = new Testcreatet();
    tct.show();
  }*/
  private void jbInit() throws Exception {
    jButton1.setBounds(new Rectangle(125, 131, 96, 39));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    this.getContentPane().add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    db.executeSQLupdate("CREATE TABLE t1 ( CustId INTEGER PRIMARY KEY, Item VARCHAR, Amount INTEGER)");

  }
}