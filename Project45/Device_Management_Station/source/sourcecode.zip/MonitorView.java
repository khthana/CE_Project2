package dms;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MonitorView extends JFrame {
  private JTextArea View = new JTextArea();
  private Border border1;
  private JButton Clear = new JButton();
  private JButton Close = new JButton();
  private String[][] monitor;
  private String[][] group;
  private boolean[] planning;
  private Config3 c3;
  private int countmonitor;
  private int countgroup;
  private String view="";
  private JScrollPane jScrollPane1 = new JScrollPane();
  public MonitorView(Config3 con,String[][] mon,int countmon,String[][] gr,int countgr,boolean[] plan) {
    try {
      c3 = con;
      countmonitor = countmon;
      monitor = mon;
      countgroup = countgr;
      group = gr;
      planning = plan;
      for(int i = 0;i<countgroup;i++)
      {
        view = "GROUPID : " + group[0][i] + " , DEVICEID : " + group[1][i] + " , OBJECTID : " + group[2][i] + " , MONITORTYPE : " + group[3][i] + " , MONITORVALUE : " + group[4][i] + "\n";
        View.append(view);
      }
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    border1 = new TitledBorder(BorderFactory.createEtchedBorder(Color.white,new Color(178, 178, 178)),"FAULT DETAIL");
    View.setBorder(border1);
    this.getContentPane().setLayout(null);
    Clear.setBounds(new Rectangle(322, 411, 104, 32));
    Clear.setText("CLEAR");
    Clear.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Clear_actionPerformed(e);
      }
    });
    Close.setBounds(new Rectangle(446, 408, 103, 31));
    Close.setText("CLOSE");
    Close.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Close_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(77, 41, 649, 330));
    this.getContentPane().add(Clear, null);
    this.getContentPane().add(Close, null);
    this.getContentPane().add(jScrollPane1, null);
    jScrollPane1.getViewport().add(View, null);
  }

  void Close_actionPerformed(ActionEvent e) {
    this.dispose();
  }

  void Clear_actionPerformed(ActionEvent e) {
    group = new String[5][100];
    monitor = new String[3][100];
    planning = new boolean[100];
    countgroup = 0;
    countmonitor = 0;


    c3.SetMonitor(monitor,countmonitor,group,countgroup,planning);
    View.setText("");
  }


}