package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class AddUser extends JFrame {

  Database db;
  private JTextField jTextField1 = new JTextField();
  private JTextField jTextField2 = new JTextField();
  private JTextField jTextField3 = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel5 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JPasswordField jPasswordField1 = new JPasswordField();
  private JPasswordField jPasswordField2 = new JPasswordField();
  private JLabel jLabel6 = new JLabel();
  private JTextField jTextField4 = new JTextField();
  private JLabel jLabel7 = new JLabel();

  public AddUser(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    //(new AddUser().setVisible(true));


  }
  private void jbInit() throws Exception {
    jTextField1.setBounds(new Rectangle(149, 56, 203, 30));
    this.getContentPane().setLayout(null);
    jTextField2.setBounds(new Rectangle(149, 99, 203, 30));
    jTextField3.setBounds(new Rectangle(149, 142, 203, 30));
    jLabel1.setText("Name");
    jLabel1.setBounds(new Rectangle(7, 56, 98, 32));
    jLabel2.setBounds(new Rectangle(8, 99, 98, 32));
    jLabel2.setText("Sirname");
    jLabel3.setBounds(new Rectangle(9, 140, 98, 32));
    jLabel3.setText("Username");
    jLabel4.setBounds(new Rectangle(10, 228, 98, 32));
    jLabel4.setText("Password");
    jLabel5.setBounds(new Rectangle(10, 273, 117, 32));
    jLabel5.setText("Confirm Password");
    jButton1.setBounds(new Rectangle(156, 346, 87, 30));
    jButton1.setText("Add");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setText("cancel");
    jButton2.setBounds(new Rectangle(253, 346, 87, 30));
    jPasswordField1.setBounds(new Rectangle(148, 230, 203, 32));
    jPasswordField2.setBounds(new Rectangle(147, 274, 203, 32));
    jLabel6.setText("Please Fill all blanks to add new user");
    jLabel6.setBounds(new Rectangle(20, 9, 275, 40));
    jTextField4.setBounds(new Rectangle(149, 184, 201, 35));
    jLabel7.setText("Devision");
    jLabel7.setBounds(new Rectangle(6, 183, 113, 34));
    this.getContentPane().add(jTextField3, null);
    this.getContentPane().add(jTextField2, null);
    this.getContentPane().add(jLabel3, null);
    this.getContentPane().add(jLabel2, null);
    this.getContentPane().add(jTextField1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jLabel6, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(jTextField4, null);
    this.getContentPane().add(jPasswordField1, null);
    this.getContentPane().add(jPasswordField2, null);
    this.getContentPane().add(jLabel5, null);
    this.getContentPane().add(jLabel4, null);
    this.getContentPane().add(jLabel7, null);
    setSize(500,400);

    this.addWindowListener(new WindowAdapter(){
      public void windowClosing(WindowEvent e){
        setVisible(false);
        dispose();
        System.exit(0);
      }
    });
  }

  void jButton1_actionPerformed(ActionEvent e) {
    boolean ck=true;
  String name = jTextField1.getText();
  String sirname = jTextField2.getText();
  String username = jTextField3.getText();
  String devision = jTextField4.getText();
  char[] ch =jPasswordField1.getPassword();
  char[] ch2 =jPasswordField2.getPassword();
  //String password = jPasswordField1.getPassword().toString();
  //String confirm = jPasswordField2.getPassword().toString();
  if (ch.length!=ch2.length)
  {
    System.out.println("Password not match");
    jPasswordField1.setText("");
    jPasswordField2.setText("");
    Dialog1 dialog = new Dialog1();
    dialog.setSize(300,300);
    dialog.annouce("Password not match please re-enter.");
    dialog.show();
  }
  else
  {

     for(int i=0;i<ch.length;i++)
     {
       if (ch[i]!=ch2[i])
         ck=false;
     }
     if (ck==false)
 {
   System.out.println("Password not match");
 }
 else if (ck==true)
 {

   db.executeSQLupdate("INSERT INTO USERINFO VALUES ('"+username+"','"+name+"','"+sirname+"','"+ch+"','"+devision+"')");
    }
  }

  }
}