package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EventConfirmDialog extends JDialog {
  private JPanel panel1 = new JPanel();
  private JLabel jLabel1 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();

  public EventConfirmDialog(Frame frame, String title, boolean modal) {
    super(frame, title, modal);
    try {
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public EventConfirmDialog() {
    this(null, "", false);
  }
  private void jbInit() throws Exception {
    panel1.setLayout(null);
    jLabel1.setText("Are you sure that you want to delete all log file?");
    jLabel1.setBounds(new Rectangle(67, 59, 284, 42));
    jButton1.setBounds(new Rectangle(90, 151, 85, 26));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setText("CANCEL");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(204, 151, 90, 26));
    getContentPane().add(panel1);
    panel1.add(jLabel1, null);
    panel1.add(jButton1, null);
    panel1.add(jButton2, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {

  }

  void jButton2_actionPerformed(ActionEvent e) {

  }
}