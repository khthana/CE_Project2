package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Adminmainpage extends JFrame {
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenu1 = new JMenu();
  private JMenuItem jMenuItem1 = new JMenuItem();
  private JMenuItem jMenuItem2 = new JMenuItem();
  private JMenu jMenu2 = new JMenu();
  private JMenu jMenu3 = new JMenu();
  private JMenuItem jMenuItem3 = new JMenuItem();
  private JMenuItem jMenuItem4 = new JMenuItem();
  private JMenuItem jMenuItem5 = new JMenuItem();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JMenu jMenu4 = new JMenu();
  private JMenuItem jMenuItem6 = new JMenuItem();
  Database db;
  public Adminmainpage(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    jMenu1.setText("Configuration");
    jMenuItem1.setText("Open Configuration");
    jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          openconfig_actionPerformed(e);
        }
    }
    );

    jMenuItem2.setText("Edit Configuration");
    jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          editconfig_actionPerformed(e);
        }
    }
    );
    jMenu2.setText("File");
    jMenu3.setText("Asset Management");
    jMenuItem3.setText("Log off");
    jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          logoff_actionPerformed(e);
        }
    }
    );
    jMenuItem4.setText("Device Record");
    jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          devicerecord_actionPerformed(e);
        }
    }
    );
    jMenuItem5.setText("User Record");
    jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          userrecord_actionPerformed(e);
        }
    }
    );
    jScrollPane1.setBounds(new Rectangle(10, 17, 380, 272));
    jMenu4.setText("Event log");
    jMenuItem6.setText("Event log viewer");
    jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
        public void actionPerformed(ActionEvent e)
        {
          eventviewer_actionPerformed(e);
        }
    }
    );
    jMenuBar1.add(jMenu1);
    jMenuBar1.add(jMenu2);
    jMenuBar1.add(jMenu3);
    jMenuBar1.add(jMenu4);
    jMenu1.add(jMenuItem1);
    jMenu1.add(jMenuItem2);
    jMenu2.add(jMenuItem3);
    jMenu3.add(jMenuItem4);
    jMenu3.add(jMenuItem5);
    this.setJMenuBar(jMenuBar1);
    this.getContentPane().add(jScrollPane1, null);
    jMenu4.add(jMenuItem6);
  }
  public void openconfig_actionPerformed(ActionEvent ee)
  {
     Mainconfig mc = new Mainconfig(db);
     mc.show();
  }
  public void editconfig_actionPerformed(ActionEvent e)
  {
    MainEditConfig me = new MainEditConfig(db);
    me.setSize(new Dimension(1024,768));
    me.setVisible(true);
  }
  public void logoff_actionPerformed(ActionEvent e)
  {
     this.hide();
  }
  public void devicerecord_actionPerformed(ActionEvent e)
  {
    ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE");
    int rowcount=0;
    try{
      while(rs.next())
      {
        rowcount++;
      }
    }catch(SQLException sql)
    {}
    String[][] datavalue = new String[rowcount][4];
    String[] name = new String[4];
    name[0] = "DEVICEID";
    name[1] = "DEVICENAME";
    name[2] = "INTERNET ADDRESS";
    name[3] = "PROTOCOL";
    ResultSet rs2 = db.executeSQLquery("SELECT * FROM  DEVICE");
    int x=0;
    try{
    while(rs2.next())
    {
     datavalue[x][0] = rs2.getString(1);
     datavalue[x][1] = rs2.getString(2);
     datavalue[x][2] = rs2.getString(3);
     datavalue[x][3] = rs2.getString(5);
     x++;
    }
    }catch(SQLException sql)
    {}
    JTable jtable = new JTable(datavalue,name);
    jScrollPane1.getViewport().add(jtable,null);
  }
  public void userrecord_actionPerformed(ActionEvent e)
  {
    ResultSet rs3 = db.executeSQLquery("SELECT * FROM USERTABLE");
     int rowcount3=0;
     try{
       while(rs3.next())
       {
         rowcount3++;
       }
     }catch(SQLException sql)
     {}
     String[][] datavalue = new String[rowcount3][3];
     String[] name = new String[3];
     name[0] = "NAME";
     name[1] = "TYPE";
     name[2] = "DIVISION";

     ResultSet rs4 = db.executeSQLquery("SELECT * FROM  USERTABLE");
     int x=0;
     try{
     while(rs4.next())
     {
      datavalue[x][0] = rs4.getString(2);
      datavalue[x][1] = rs4.getString(3);
      datavalue[x][2] = rs4.getString(5);
      x++;
     }
     }catch(SQLException sql)
     {}
     JTable jtable = new JTable(datavalue,name);
    jScrollPane1.getViewport().add(jtable,null);
  }
  public void eventviewer_actionPerformed(ActionEvent e)
  {
     Eventviewer ev = new Eventviewer(db);
    jScrollPane1.getViewport().add(ev,null);
  }
}