package dms;

import java.awt.*;
import javax.swing.*;
import java.sql.*;
import com.borland.jbcl.layout.*;
import java.awt.event.*;
import javax.swing.border.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditProject1 extends JPanel {

  private String projectid = "";
  private String projectname = "";
  private String projectdescription = "";
  private String projectdate = "";
  private Database db;
  private JComboBox Selectproject = new JComboBox();
  private JTextField Projectname = new JTextField();
  private JTextField Projectdescription = new JTextField();
  private JTextField Projectdate = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private JLabel jLabel4 = new JLabel();
  private JPanel jPanel1 = new JPanel();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private JRadioButton Edit = new JRadioButton();
  private JRadioButton Delete = new JRadioButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea Projectdetail = new JTextArea();
  private Border border1;
  private TitledBorder titledBorder1;
  private Border border2;
  private Border border3;

  public EditProject1(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border1,"PROJECT DETAIL");
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border3 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    this.setLayout(null);
    Selectproject.setBounds(new Rectangle(54, 78, 260, 31));
    Selectproject.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectproject_actionPerformed(e);
      }
    });
    Projectname.setBounds(new Rectangle(240, 172, 250, 30));
    Projectdescription.setBounds(new Rectangle(240, 225, 250, 30));
    Projectdate.setBounds(new Rectangle(240, 277, 250, 30));
    jLabel1.setText("PROJECT NAME");
    jLabel1.setBounds(new Rectangle(49, 175, 105, 30));
    jLabel2.setText("PROJECT DESCRIPTION");
    jLabel2.setBounds(new Rectangle(49, 227, 143, 30));
    jLabel3.setText("PROJECT DATE");
    jLabel3.setBounds(new Rectangle(46, 279, 122, 25));
    Ok.setBounds(new Rectangle(672, 466, 99, 29));
    Ok.setToolTipText("");
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(812, 466, 99, 29));
    Cancel.setText("CANCEL");
    jLabel4.setText("SELECT PROJECT");
    jLabel4.setBounds(new Rectangle(53, 32, 101, 27));
    jPanel1.setBorder(border3);
    jPanel1.setBounds(new Rectangle(368, 50, 116, 61));
    jPanel1.setLayout(verticalFlowLayout1);
    Edit.setSelected(true);
    Edit.setText("EDIT");
    Edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_actionPerformed(e);
      }
    });
    Delete.setBorder(border2);
    Delete.setText("DELETE");
    Delete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(537, 53, 362, 284));
    Projectdetail.setBorder(titledBorder1);
    jPanel1.add(Edit, null);
    jPanel1.add(Delete, null);
    this.add(jScrollPane1, null);
    this.add(Cancel, null);
    this.add(Ok, null);
    jScrollPane1.getViewport().add(Projectdetail, null);
    this.add(Selectproject, null);
    this.add(Projectname, null);
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    this.add(Projectdescription, null);
    this.add(jLabel3, null);
    this.add(Projectdate, null);
    this.add(jLabel4, null);
    this.add(jPanel1, null);

   // Database db = new Database();

    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT");
      while (rs.next())
      {
        Selectproject.addItem(rs.getString("PROJECTID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject1 : " + sql);
    }

    buttonGroup1.add(Edit);
    buttonGroup1.add(Delete);
  }

  void Selectproject_actionPerformed(ActionEvent e) {
    Projectname.setText("");
    Projectdescription.setText("");
    Projectdate.setText("");
    Projectname.setEditable(false);
    Projectdescription.setEditable(false);
    Projectdate.setEditable(false);


  //  Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      while (rs.next())
      {
        projectid = rs.getString("PROJECTID");
        projectname = rs.getString("PROJECTNAME");
        projectdescription = rs.getString("PROJECTDESCRIPTION");
        projectdate = rs.getString("PROJECTDATE");


      }

      Projectdetail.setText("PROJECTID : " + projectid + "\nPROJECTNAME : " + projectname + "\nPROJECTDESCRIPTION : " + projectdescription + "\nPROJECTDATE : " + projectdate);
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject1 : " + sql);
    }
  }

  void Edit_actionPerformed(ActionEvent e) {
   // Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      while (rs.next())
      {
        projectid = rs.getString("PROJECTID");
        projectname = rs.getString("PROJECTNAME");
        projectdescription = rs.getString("PROJECTDESCRIPTION");
        projectdate = rs.getString("PROJECTDATE");


      }

      Projectdetail.setText("PROJECTID : " + projectid + "\nPROJECTNAME : " + projectname + "\nPROJECTDESCRIPTION : " + projectdescription + "\nPROJECTDATE : " + projectdate);
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject1 : " + sql);
    }

    Projectname.setText(projectname);
    Projectdescription.setText(projectdescription);
    Projectdate.setText(projectdate);
    Projectname.setEditable(true);
    Projectdescription.setEditable(true);
    Projectdate.setEditable(true);
  }

  void Delete_actionPerformed(ActionEvent e) {
  //  Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM PROJECT WHERE PROJECTID = '" + Selectproject.getSelectedItem() + "'");
      while (rs.next())
      {
        projectid = rs.getString("PROJECTID");
        projectname = rs.getString("PROJECTNAME");
        projectdescription = rs.getString("PROJECTDESCRIPTION");
        projectdate = rs.getString("PROJECTDATE");


      }

      Projectdetail.setText("PROJECTID : " + projectid + "\nPROJECTNAME : " + projectname + "\nPROJECTDESCRIPTION : " + projectdescription + "\nPROJECTDATE : " + projectdate);
    }
    catch(SQLException sql)
    {
      System.out.println("EditProject1 : " + sql);
    }

    Projectname.setText("");
    Projectdescription.setText("");
    Projectdate.setText("");
    Projectname.setEditable(false);
    Projectdescription.setEditable(false);
    Projectdate.setEditable(false);

  }

  void Ok_actionPerformed(ActionEvent e) {
    if (Edit.isSelected())
    {
      if (checkallblank())
      {
      //  Database db = new Database();

        db.executeSQLupdate("UPDATE PROJECT SET PROJECTNAME = '" + Projectname.getText() + "' , PROJECTDESCRIPTION = '" + Projectdescription.getText() + "' , PROJECTDATE = '" + Projectdate.getText() + "' WHERE PROJECTID = '" + Selectproject.getSelectedItem().toString() + "'") ;

      }
    }
    else if (Delete.isSelected())
    {
    //  Database db =new Database();

      db.executeSQLupdate("DELETE FROM PROJECT WHERE DEVICEID = '" + Selectproject.getSelectedItem().toString() + "'");

    }
  }

  public boolean checkallblank()
  {
    if (Selectproject.getSelectedItem().toString().compareTo("") !=0 && Projectname.getText().compareTo("") !=0 && Projectdate.getText().compareTo("") !=0 && Projectdescription.getText().compareTo("") != 0)
    {
      return true;

    }
    return false;
  }


}