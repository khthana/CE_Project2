package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Datalog extends JFrame {
  private JLabel jLabel1 = new JLabel();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JPanel jPanel1 = new JPanel();
  private JRadioButton jRadioButton1 = new JRadioButton();
  private JRadioButton jRadioButton2 = new JRadioButton();
  private JButton jButton3 = new JButton();
  private JButton jButton4 = new JButton();
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu jMenu1 = new JMenu();
  private Logging gl;
  private JLabel jLabel2 = new JLabel();
  private JTextField jTextField1 = new JTextField();
  private JLabel jLabel3 = new JLabel();
  private String projectname;
  private Database db;
  private ScrollPane scrollPane1 = new ScrollPane();
  private ScrollPane scrollPane2 = new ScrollPane();
  private List list1 = new List();
  private List list2 = new List();
  String[] tname;
  public Datalog(String pname,Database d) {
    db = d;
    projectname = pname;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    ResultSet rs = db.executeSQLquery("SELECT * FROM SUPPORTGROUP WHERE PROJECTID='"+projectname+"'");
    try{
      while(rs.next())
      {
          list1.add(rs.getString(2));
      }
    }catch(SQLException sql)
    {}
    jLabel1.setText("Data logging");
    jLabel1.setBounds(new Rectangle(11, 15, 112, 24));
    this.getContentPane().setLayout(null);
    jButton1.setBounds(new Rectangle(129, 85, 90, 27));
    jButton1.setText("ADD>>");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(129, 130, 91, 31));
    jButton2.setText("<<REMOVE");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setBounds(new Rectangle(14, 207, 354, 133));
    jPanel1.setLayout(null);
    jRadioButton1.setText("all as configuration");
    jRadioButton1.setBounds(new Rectangle(9, 8, 122, 25));
    jRadioButton2.setText("as only  selected");
    jRadioButton2.setBounds(new Rectangle(157, 11, 121, 25));
    jButton3.setBounds(new Rectangle(169, 90, 71, 29));
    jButton3.setText("Start");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jButton4.setBounds(new Rectangle(254, 90, 70, 29));
    jButton4.setText("Stop");
    jButton4.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton4_actionPerformed(e);
      }
    });
    jMenu1.setText("File");
    jLabel2.setText("polling rate");
    jLabel2.setBounds(new Rectangle(59, 47, 77, 26));
    jTextField1.setBounds(new Rectangle(134, 48, 57, 27));
    jLabel3.setText("millisecs");
    jLabel3.setBounds(new Rectangle(204, 47, 58, 27));
    scrollPane1.setBounds(new Rectangle(9, 46, 110, 137));
    scrollPane2.setBounds(new Rectangle(234, 45, 108, 138));
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jButton2, null);
    this.getContentPane().add(jPanel1, null);
    jPanel1.add(jRadioButton1, null);
    jPanel1.add(jButton3, null);
    jPanel1.add(jButton4, null);
    jPanel1.add(jRadioButton2, null);
    jPanel1.add(jLabel2, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jLabel3, null);
    this.getContentPane().add(jButton1, null);
    this.getContentPane().add(scrollPane1, null);
    scrollPane1.add(list1, null);
    this.getContentPane().add(scrollPane2, null);
    scrollPane2.add(list2, null);
    jMenuBar1.add(jMenu1);
    this.setJMenuBar(jMenuBar1);
  }

  void jButton3_actionPerformed(ActionEvent e) {
  if(jRadioButton1.isSelected())
  {
    ResultSet rs = db.executeSQLquery("SELECT * FROM SUPPORTGROUP WHERE PROJECTID='"+projectname+"'");
    int rowcount=0;
    try{
      while(rs.next())
      {
        rowcount++;
      }
    }catch(SQLException sql)
    {}
    String[] name = new String[rowcount];
    ResultSet rs2 = db.executeSQLquery("SELECT * FROM SUPPORTGROUP WHERE PROJECTID='"+projectname+"'");
   int x=0;
   try{
     while(rs2.next())
     {
       name[x]=rs2.getString(2);
       x++;
     }
   }catch(SQLException sql)
    {}
    Logging ll = new Logging(projectname,name,jTextField1.getText(),db);
    gl = ll;
    gl.start();
  }
  else
  {
    int number = list2.getItemCount();
    tname = new String[number];
    for(int x=0;x<number;x++)
    {
      tname[x]=list2.getItem(x);
    }
    Logging ll = new Logging(projectname,tname,jTextField1.getText(),db);
    gl = ll;
    gl.start();
  }
  }

  void jButton4_actionPerformed(ActionEvent e) {
   gl.tostop();
  }

  void jButton1_actionPerformed(ActionEvent e) {
     String select = list1.getSelectedItem();
     int selectindex = list1.getSelectedIndex();
     list1.remove(selectindex);
     list2.add(select);


  }

  void jButton2_actionPerformed(ActionEvent e) {
     String select2 = list2.getSelectedItem();
    int selectindex2 = list2.getSelectedIndex();
    list2.remove(selectindex2);
     list1.add(select2);
  }
}