package dms;


import javax.swing.*;
import java.util.Vector;
import java.awt.*;
import javax.swing.border.*;
import java.awt.event.*;
import ipworks.*;

public class SnmpManager1 extends JFrame {

  final String sysDescr    = "1.3.6.1.2.1.1.1.0";
  final String sysObjectID = "1.3.6.1.2.1.1.2.0";
  final String sysUpTime   = "1.3.6.1.2.1.1.3.0";
  final String sysContact  = "1.3.6.1.2.1.1.4.0";
  final String sysName     = "1.3.6.1.2.1.1.5.0";
  final String sysLocation = "1.3.6.1.2.1.1.6.0";
  final String sysServices = "1.3.6.1.2.1.1.7.0";

  Vector agentsVector = new Vector();
  Vector trapVector = new Vector();

  JPanel jPanel1 = new JPanel();
  JTextField txtOIDVal6 = new JTextField();
  JTextField txtOIDVal5 = new JTextField();
  JTextField txtOIDVal4 = new JTextField();
  JTextField txtOIDVal3 = new JTextField();
  JTextField txtOIDVal2 = new JTextField();
  JTextField txtOIDVal1 = new JTextField();
  JTextField txtOIDVal0 = new JTextField();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel1 = new JLabel();
  JPanel jPanel2 = new JPanel();
  JLabel jLabel9 = new JLabel();
  JButton buttonFind = new JButton();
  JScrollPane jScrollPane1 = new JScrollPane();
  JLabel jLabel10 = new JLabel();
  JList agentList = new JList();
  JPanel jPanel3 = new JPanel();
  JLabel jLabel11 = new JLabel();
  JScrollPane jScrollPane2 = new JScrollPane();
  JList trapList = new JList();
  Snmp snmp1 = new Snmp();
  GridBagLayout gridBagLayout1 = new GridBagLayout();
  GridBagLayout gridBagLayout2 = new GridBagLayout();
  GridBagLayout gridBagLayout3 = new GridBagLayout();
  GridBagLayout gridBagLayout4 = new GridBagLayout();

  public SnmpManager1() {
    try {
      snmp1.setLocalPort(162);
      snmp1.setActive(true);
      jbInit();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    this.setSize(new Dimension(561, 439));
    this.addWindowListener(new java.awt.event.WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        this_windowClosing(e);
      }
    });
    this.setTitle("Snmp Agent");
    this.getContentPane().setLayout(gridBagLayout4);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setLayout(gridBagLayout1);
    txtOIDVal6.setText("0");
    txtOIDVal5.setText("(unknown)");
    txtOIDVal4.setText("localhost");
    txtOIDVal3.setText("/n software: sales@nsoftware.com");
    txtOIDVal2.setText("0");
    txtOIDVal1.setText("1.3.6.1.4.1.127.0.0.1");
    txtOIDVal0.setText("My System");
    jLabel7.setText("System Services");
    jLabel6.setToolTipText("");
    jLabel6.setText("System Location");
    jLabel5.setText("System Name");
    jLabel4.setText("System Contact");
    jLabel3.setText("System Up Time");
    jLabel2.setText("System Object ID");
    jLabel1.setText("System Description");
    jPanel2.setBorder(BorderFactory.createEtchedBorder());
    jPanel2.setLayout(gridBagLayout2);
    jLabel9.setText("Agent List");
    buttonFind.setText("Find Agents");
    buttonFind.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        buttonFind_actionPerformed(e);
      }
    });
    jLabel10.setText("Traps");
    jLabel10.setBounds(new Rectangle(11, 8, 54, 17));
    jPanel3.setBorder(BorderFactory.createEtchedBorder());
    jPanel3.setLayout(gridBagLayout3);
    jLabel11.setText("Traps");
    snmp1.addSnmpEventListener(new ipworks.SnmpEventListener() {
      public void error(SnmpErrorEvent e) {
      }
      public void getBulkRequest(SnmpGetBulkRequestEvent e) {
      }
      public void getNextRequest(SnmpGetNextRequestEvent e) {
      }
      public void getRequest(SnmpGetRequestEvent e) {
      }
      public void getResponse(SnmpGetResponseEvent e) {
      }
      public void informRequest(SnmpInformRequestEvent e) {
      }
      public void PDUTrace(SnmpPDUTraceEvent e) {
      }
      public void readyToSend(SnmpReadyToSendEvent e) {
      }
      public void setRequest(SnmpSetRequestEvent e) {
      }
      public void trap(SnmpTrapEvent e) {
        snmp1_trap(e);
      }
    });
    jPanel1.add(txtOIDVal0,  new GridBagConstraints(1, 0, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(11, 18, 0, 16), 141, 0));
    jPanel1.add(jLabel2,  new GridBagConstraints(0, 1, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(20, 15, 0, 0), 37, 0));
    jPanel1.add(jLabel4,  new GridBagConstraints(0, 3, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(23, 15, 0, 0), 45, 0));
    jPanel1.add(jLabel3,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(23, 15, 0, 0), 40, 0));
    jPanel1.add(txtOIDVal1,  new GridBagConstraints(1, 1, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(17, 18, 0, 16), 88, 0));
    jPanel1.add(jLabel1,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(11, 15, 0, 0), 24, 0));
    jPanel1.add(jLabel5,  new GridBagConstraints(0, 4, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(23, 15, 0, 0), 53, 0));
    jPanel1.add(jLabel6,  new GridBagConstraints(0, 5, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(23, 15, 0, 0), 40, 0));
    jPanel1.add(jLabel7,  new GridBagConstraints(0, 6, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(23, 15, 17, 0), 40, 0));
    jPanel1.add(txtOIDVal6,  new GridBagConstraints(1, 6, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(20, 18, 17, 16), 192, 0));
    jPanel1.add(txtOIDVal5,  new GridBagConstraints(1, 5, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(20, 18, 0, 16), 141, 0));
    jPanel1.add(txtOIDVal4,  new GridBagConstraints(1, 4, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(20, 18, 0, 16), 149, 0));
    jPanel1.add(txtOIDVal3,  new GridBagConstraints(1, 3, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(20, 18, 0, 16), 9, 0));
    jPanel1.add(txtOIDVal2,  new GridBagConstraints(1, 2, 1, 1, 1.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(20, 18, 0, 16), 192, 0));
    this.getContentPane().add(jPanel3,  new GridBagConstraints(0, 1, 2, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(12, 8, 10, 12), 0, 0));
    jPanel3.add(jLabel11,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(5, 10, 0, 462), 32, 0));
    jPanel3.add(jScrollPane2,  new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(8, 10, 8, 12), 255, -63));
    jScrollPane2.getViewport().add(trapList, null);
    this.getContentPane().add(jPanel2,  new GridBagConstraints(0, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(15, 8, 0, 0), 0, 0));
    jPanel2.add(jLabel9,  new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0
            ,GridBagConstraints.WEST, GridBagConstraints.NONE, new Insets(1, 10, 0, 64), 10, 0));
    jPanel2.add(buttonFind,  new GridBagConstraints(0, 2, 1, 1, 0.0, 0.0
            ,GridBagConstraints.CENTER, GridBagConstraints.NONE, new Insets(17, 10, 13, 12), 17, -1));
    jPanel2.add(jScrollPane1,  new GridBagConstraints(0, 1, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(7, 10, 0, 12), -144, 74));
    this.getContentPane().add(jPanel1,  new GridBagConstraints(1, 0, 1, 1, 1.0, 1.0
            ,GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(15, 12, 0, 12), 0, -5));
    jScrollPane1.getViewport().add(agentList, null);

    trapList.setListData(trapVector);
  }

  void this_windowClosing(WindowEvent e) {
    System.exit(0);
  }

  void buttonFind_actionPerformed(ActionEvent e) {
    try {
      agentsVector = new Vector();
      agentList.setListData(agentsVector);
//			blnFindsysName = true;
      snmp1.setObjCount(1);
      snmp1.setObjId(1, sysName);
      snmp1.setRemoteHost("255.255.255.255");
      snmp1.sendGetRequest();
    } catch (IPWorksException ipwe) {
      JOptionPane.showMessageDialog(this, ipwe.getMessage());
    }

  }

  void snmp1_trap(SnmpTrapEvent e) {
    String message = e.sourceAddress;
    switch (e.genericType) {
      case 0 : message += " coldStart"; break;
      case 1 : message += " warmStart"; break;
      case 2 : message += " linkDown"; break;
      case 3 : message += " linkUp"; break;
      case 4 : message += " authenticationFailure"; break;
      case 5 : message += " egpNeighborLoss"; break;
      case 6 : message += " enterpriseSpecific: " + e.specificType; break;
    }
    trapVector.add(message);
    trapList.setListData(trapVector);
  }

  public static void main(String[] args) {
    (new SnmpManager1()).setVisible(true);
  }


}