package dms;



import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class FramePicture extends JFrame implements MouseListener{
  private Desktop themain;
  private Database db;
  Image pic[];
  int[] x = {0,200,400,600,0,200,400,600,0,200,400,600,0,200,400,600};
  int[] y = {0,0,0,0,200,200,200,200,400,400,400,400,600,600,600,600};
  int numofdevice;
  String[] name;
  String[][] deviceobjectid;
  int countdevice;
  String[] device;
  int width = 150;
  int height = 150;
  int clickpositionx = 0;
  int clickpositiony = 0;
  String projectname;
/*  public FramePicture(){
    pic = new Image[1];
    pic[0] = Toolkit.getDefaultToolkit().getImage("C:/pic/musiccontest1.jpg");
    countdevice = 1;
    System.out.println("init");
    addMouseListener(this);
  }*/
  public FramePicture(int numofdevice,String[] name,String[][] deviceobjectid,int countdevice,String[] device,String pname,Desktop tm,Database d) {
    themain = tm;
    db = d;
    //System.out.println("countdevice = " + countdevice);
    this.setSize(new Dimension(1024,768));
    this.numofdevice = numofdevice;
    projectname=pname;
    this.name = name;
    this.deviceobjectid = deviceobjectid;
    this.countdevice = countdevice;
    this.device = device;
    pic = new Image[countdevice];

    for (int i=0;i<countdevice;i++)
    {
      pic[i] = Toolkit.getDefaultToolkit().getImage("C:/pic/musiccontest1.jpg");
    }

    addMouseListener(this);

  }

  public void paint(Graphics g){
    //System.out.println("paint");
    g.setColor(Color.blue);

    //Font font = new Font(g.getFont(),Font.BOLD,16);

    //g.setFont(font);
    for (int i=0;i<countdevice;i++)
    {
      System.out.println("x = " + x[i]);
      g.drawImage(pic[i],x[i],y[i],width,height,this);

      g.drawString(name[i],x[i],y[i]+width+20);

    }


  }

  public void mousePressed(MouseEvent e){
    clickpositionx = e.getX();
    clickpositiony = e.getY();
    int devicenumber = finddevicenumber();
    System.out.println("devicenumber = " + devicenumber);

    String[] objectofclickdevice;
    int objectcount=0;
    if (devicenumber <= countdevice && devicenumber > 0)
    {
      for(int i=0;i<numofdevice;i++)
      {
        if (device[devicenumber - 1].compareTo(deviceobjectid[i][0]) == 0)
        {
          //objectofclickdevice[j] = deviceobjectid[i][1];

          objectcount++;
        }
      }
      System.out.println("mouseclick: objectcount = " + objectcount);
      objectofclickdevice = new String[objectcount];
      objectcount = 0;
      for(int i=0;i<numofdevice;i++)
      {
        if (device[devicenumber - 1].compareTo(deviceobjectid[i][0]) == 0)
        {
          System.out.println("mouseclick: deviobjectid["+i+"][1] = " + deviceobjectid[i][1]);
          objectofclickdevice[objectcount] = deviceobjectid[i][1];
          objectcount++;

        }
      }

      FrameChooseObject f = new FrameChooseObject(device[devicenumber-1],objectofclickdevice,objectcount,projectname,themain,db);
      f.pack();
      f.setVisible(true);
    }

  }
  public void mouseReleased(MouseEvent e){}
  public void mouseExited(MouseEvent e){}
  public void mouseEntered(MouseEvent e){}
  public void mouseClicked(MouseEvent e){}

  public int finddevicenumber()
  {
    int num = 0;
    boolean flag = true;
    int x=0;
    int y=0;
    for(int i=0;i<4;i++)
    {
      for(int j=0;j<4;j++)
      {
        if ((clickpositionx >= x) && (clickpositionx <= x+width) && (clickpositiony >= y) && (clickpositiony <= y+height))
        {

          num = 4*i + j +1;
          //System.out.println("i = " + i + "j = " + j);
        }
        if (x == 600)
        {
          x = 0;
        }
        else
        {
          x += 200;
        }

      }
      if (y == 600)
      {
        y = 0;
      }
      else
      {
        y += 200;
      }

    }
    //System.out.println("num = " + num);
    return num;

  }


}