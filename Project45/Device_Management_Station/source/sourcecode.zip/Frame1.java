package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class Frame1 extends JFrame {
  JButton jButton1 = new JButton();
  SNMPManager ss = new SNMPManager();
  private Database db;
  public Frame1(Database d) {
    try {
      db = d;
      jbInit();

    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
/*  public static void main(String[] args) {
   (new Frame1().setVisible(true));
  }*/
  private void jbInit() throws Exception {

    jButton1.setBounds(new Rectangle(73, 51, 87, 31));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    this.getContentPane().add(jButton1, null);


  }

  void jButton1_actionPerformed(ActionEvent e) {
    //ss.sendGet("161.246.5.109","1.3.6.1.2.1.1.1.0","public");
    String ss="";
    try {
    ResultSet rs = db.executeSQLquery("SELECT PASSWORD FROM usertable");
    while(rs.next())
    {
      ss= rs.getString("PASSWORD");
      System.out.println(ss);
    }
    }
    catch (SQLException sqle)
  {
    System.out.println("Error connecting DB");
    System.out.println(sqle.toString());
  }

  }
}