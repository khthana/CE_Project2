package dms;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class ProjectHandler2 extends JFrame implements TreeSelectionListener {
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTree jTree1 = new JTree();
  private JButton jButton1 = new JButton();
  private JLabel jLabel1 = new JLabel();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JTextArea jTextArea1 = new JTextArea();
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu project = new JMenu();
  private JMenu logoff = new JMenu();
  private JMenuItem tologoff = new JMenuItem();
  private JMenuItem toopen = new JMenuItem();
  private JMenuItem toclose = new JMenuItem();
  private Database db;
  private String username="";
  private String projectname="";
  String selectobject="";
  public ProjectHandler2(String pname,String uname,Database d) {
    db = d;
    username=uname;
    projectname=pname;
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
/*  public static void main(String[] args) {
    String pn="",un="";
    ProjectHandler2 projectHandle = new ProjectHandler2(pn,un,db);
    projectHandle.setVisible(true);
  }*/
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
    this.setSize(700,700);
    this.setTitle("Project's main page : project: "+projectname+" user: "+username);
    jScrollPane1.setBounds(new Rectangle(16, 16, 164, 319));
    jButton1.setBounds(new Rectangle(11, 535, 163, 24));
    jButton1.setText("SELECT");
    jLabel1.setText("Device Information");
    jLabel1.setBounds(new Rectangle(198, 13, 266, 32));
    jScrollPane2.setBounds(new Rectangle(195, 48, 339, 116));
    this.getContentPane().add(jScrollPane1, null);
    this.getContentPane().add(jLabel1, null);
    this.getContentPane().add(jScrollPane2, null);
    this.getContentPane().add(jButton1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    toopen.setText("open project");
    project.setText("Project");
    toclose.setText("close project");
    project.add(toopen);
    project.add(toclose);
    tologoff.setText("logoff user");
    logoff.setText("logoff");
    logoff.add(tologoff);
    jMenuBar1.add(project);
    jMenuBar1.add(logoff);
    this.setJMenuBar(jMenuBar1);
    //jScrollPane1.getViewport().add(jTree1, null);
    buildtree();
  }
  public void valueChanged(TreeSelectionEvent ev)
{
         TreePath path=jTree1.getSelectionPath();
         System.out.println("Selection path=" + path.toString());
         System.out.println(jTree1.getLastSelectedPathComponent().toString());
         selectobject = jTree1.getLastSelectedPathComponent().toString();
         System.out.println("The object select is " + selectobject);
}
public void buildtree()
{

  ResultSet rs = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM PROJECT1 WHERE PROJECTID='"+projectname+"'");
  //ResultSet rs2 = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM FAULT WHERE PROJECTID ='"+projectname+"'" );
  MouseListener m1 = new MouseAdapter()
     {
       public void mouseClicked(MouseEvent e)
       {
         if(e.getClickCount()==2)
         {
           System.out.println("Double click");

         }

       }
    };
    DefaultMutableTreeNode root = new DefaultMutableTreeNode("Project");
    DefaultMutableTreeNode pmm = new DefaultMutableTreeNode("Performance Management");
    DefaultMutableTreeNode fmm = new DefaultMutableTreeNode("Fault Detection");
    DefaultMutableTreeNode psmm = new DefaultMutableTreeNode("Planning and Support Management");
    DefaultMutableTreeNode amm = new DefaultMutableTreeNode("Asset Management");
    root.add(pmm);
    root.add(fmm);
    try{
    while (rs.next())
    {
      //pmm.add(new DefaultMutableTreeNode(rs.getString("DEVICEID")));
      DefaultMutableTreeNode temp = new DefaultMutableTreeNode(rs.getString("DEVICEID"));
      pmm.add(temp);
    }
    }catch(SQLException sql)
    {
      System.out.println("Error connecting Database");
    }
    ResultSet rs2 = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM FAULT WHERE PROJECTID ='"+projectname+"'" );
    try{
      while(rs2.next())
      {
        DefaultMutableTreeNode temp1 = new DefaultMutableTreeNode(rs2.getString("DEVICEID"));
        fmm.add(temp1);
      }
    }catch (SQLException sql1)
    {
      System.out.println("Error Connecting Database");
    }

    jTree1 = new JTree(root);
    jTree1.addMouseListener(m1);
    jTree1.addTreeSelectionListener(this);
    jScrollPane1.getViewport().add(jTree1, null);
    jScrollPane1.setBounds(new Rectangle(9, 16, 160, 500));


}
}