package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class DBLogin extends JInternalFrame {
  private Desktop themain;
  private JPanel panel1 = new JPanel();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JTextField jTextField1 = new JTextField();
  private JPasswordField jPasswordField1 = new JPasswordField();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  Database db;
  Dialog1 dialog = new Dialog1();
  private JTextField Ip = new JTextField();
  private JLabel jLabel4 = new JLabel();
  public DBLogin(String title, boolean modal,Desktop tm) {
    //super(frame, title, modal);
    try {
      themain = tm;
      jbInit();
      pack();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
 /* public static void main(String[] args) {
  (new UserLogin().setVisible(true));

  }*/
 /* public AdminLogin() {
    this( "", false);
  }*/
  private void jbInit() throws Exception {
    this.setTitle("CONNECT TO DATABASE SERVER");
    this.setResizable(true);
    this.setClosable(true);
    this.setOpaque(true);
    this.setMaximizable(true);
    this.setIconifiable(true);
    panel1.setLayout(null);
    jLabel1.setText("Please enter your username and Password");
    jLabel1.setBounds(new Rectangle(18, 14, 247, 39));
    jLabel2.setText("username");
    jLabel2.setBounds(new Rectangle(29, 94, 76, 34));
    jLabel3.setText("password");
    jLabel3.setBounds(new Rectangle(29, 139, 76, 35));
    jTextField1.setBounds(new Rectangle(170, 99, 174, 29));
    jPasswordField1.setBounds(new Rectangle(170, 144, 174, 29));
    jButton1.setBounds(new Rectangle(123, 210, 88, 33));
    jButton1.setText("OK");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.setBounds(new Rectangle(221, 210, 86, 32));
    jButton2.setText("CANCEL");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    Ip.setBounds(new Rectangle(170, 55, 174, 29));
    jLabel4.setText("Computer name or ip");
    jLabel4.setBounds(new Rectangle(27, 56, 125, 22));
    getContentPane().add(panel1);
    panel1.add(jLabel3, null);
    panel1.add(jLabel1, null);
    panel1.add(jButton1, null);
    panel1.add(jButton2, null);
    panel1.add(jLabel4, null);
    panel1.add(Ip, null);
    panel1.add(jTextField1, null);
    panel1.add(jPasswordField1, null);
    panel1.add(jLabel2, null);

  }

  void jButton1_actionPerformed(ActionEvent e) {
    String username = jTextField1.getText();
    String ip = Ip.getText();
    boolean ck=true;
    char[] check2=jPasswordField1.getPassword();
    String password = new String(check2);
    if (username.compareTo("") != 0 && ip.compareTo("") != 0 && password.compareTo("") != 0)
    {
      try
      {
        db = new Database(ip,username,password);
        themain.setDB(db);
        this.dispose();
      }
      catch(Exception ee)
      {

      }
    }



  }
  void jButton2_actionPerformed(ActionEvent e) {
       /*jTextField1.setText("");
       jPasswordField1.setText("");*/
    this.dispose();
  }

  Database getDB()
  {
    return db;
  }

}