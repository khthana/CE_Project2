package dms;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class EditUser1 extends JPanel {
  private Database db;
  private JComboBox Selectuser = new JComboBox();
  private JLabel jLabel1 = new JLabel();
  private JTextArea Userdetail = new JTextArea();
  private Border border1;
  private TitledBorder titledBorder1;
  private JTextField Username = new JTextField();
  private JTextField Division = new JTextField();
  private JPasswordField Confirmpass = new JPasswordField();
  private JPasswordField Password = new JPasswordField();
  private JTextField Userid = new JTextField();
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  private JRadioButton Edit = new JRadioButton();
  private JRadioButton Delete = new JRadioButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JPanel jPanel1 = new JPanel();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();

  private String userid = "";
  private String username = "";
  private String usertype = "";
  private String userpassword = "";
  private String division = "";
  private JRadioButton Typeadmin = new JRadioButton();
  private JRadioButton Typeuser = new JRadioButton();
  private JLabel jLabel7 = new JLabel();
  private ButtonGroup buttonGroup2 = new ButtonGroup();
  private JButton Ok = new JButton();
  private JButton Cancel = new JButton();
  private Border border2;
  private Border border3;


  public EditUser1(Database d) {
    try {
      db = d;
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border2 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    border3 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(142, 142, 142));
    this.setSize(new Dimension(973, 566));
    border1 = new EtchedBorder(EtchedBorder.RAISED,Color.white,new Color(178, 178, 178));
    titledBorder1 = new TitledBorder(border1,"USER DETAIL");
    this.setLayout(null);
    Selectuser.setBounds(new Rectangle(184, 61, 268, 28));
    Selectuser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Selectuser_actionPerformed(e);
      }
    });
    jLabel1.setText("SELECT USER");
    jLabel1.setBounds(new Rectangle(53, 59, 110, 30));
    Userdetail.setBorder(titledBorder1);
    Userdetail.setEditable(false);
    Userdetail.setBounds(new Rectangle(541, 171, 379, 295));
    Username.setBorder(border2);
    Username.setBounds(new Rectangle(199, 206, 251, 30));
    Division.setBorder(border2);
    Division.setBounds(new Rectangle(199, 262, 251, 30));
    Confirmpass.setBorder(border2);
    Confirmpass.setBounds(new Rectangle(199, 372, 251, 30));
    Password.setBorder(border2);
    Password.setBounds(new Rectangle(199, 317, 251, 30));
    Userid.setBorder(border2);
    Userid.setEditable(false);
    Userid.setBounds(new Rectangle(199, 151, 251, 30));
    jLabel5.setBounds(new Rectangle(52, 372, 139, 23));
    jLabel5.setText("CONFIRM PASSWORD");
    jLabel4.setBounds(new Rectangle(49, 314, 106, 28));
    jLabel4.setText("PASSWORD");
    jLabel3.setBounds(new Rectangle(52, 259, 98, 25));
    jLabel3.setText("DIVISION");
    jLabel2.setBounds(new Rectangle(50, 208, 103, 27));
    jLabel2.setText("USERNAME");
    jLabel6.setBounds(new Rectangle(52, 151, 119, 28));
    jLabel6.setText("USERID");
    //Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM USERTABLE");
      while (rs.next())
      {
        Selectuser.addItem(rs.getString("USERID"));
      }
    }
    catch(SQLException sql)
    {
      System.out.println("EditUser1 : " + sql);
    }

    Edit.setSelected(true);
    Edit.setText("EDIT");
    Edit.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Edit_actionPerformed(e);
      }
    });
    Delete.setText("DELETE");
    Delete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete_actionPerformed(e);
      }
    });
    jPanel1.setBorder(border3);
    jPanel1.setBounds(new Rectangle(547, 55, 154, 69));
    jPanel1.setLayout(verticalFlowLayout1);
    Typeadmin.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Typeadmin_actionPerformed(e);
      }
    });
    Typeadmin.setText("ADMINISTRATOR");
    Typeadmin.setBounds(new Rectangle(200, 433, 119, 25));
    Typeadmin.setSelected(true);
    Typeuser.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Typeuser_actionPerformed(e);
      }
    });
    Typeuser.setText("USER");
    Typeuser.setBounds(new Rectangle(200, 458, 56, 25));
    jLabel7.setText("TYPE");
    jLabel7.setBounds(new Rectangle(50, 428, 117, 31));
    Ok.setBounds(new Rectangle(691, 513, 98, 29));
    Ok.setText("OK");
    Ok.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Ok_actionPerformed(e);
      }
    });
    Cancel.setBounds(new Rectangle(818, 511, 100, 32));
    Cancel.setText("CANCEL");
    Cancel.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancel_actionPerformed(e);
      }
    });
    this.add(Userid, null);
    this.add(jLabel6, null);
    this.add(jLabel2, null);
    this.add(jLabel3, null);
    this.add(jLabel4, null);
    this.add(jLabel5, null);
    this.add(Username, null);
    this.add(Division, null);
    this.add(Password, null);
    this.add(Confirmpass, null);
    this.add(Selectuser, null);
    jPanel1.add(Edit, null);
    jPanel1.add(Delete, null);
    this.add(Userdetail, null);
    this.add(Cancel, null);
    this.add(Ok, null);
    this.add(jLabel1, null);
    this.add(Typeadmin, null);
    this.add(Typeuser, null);
    buttonGroup1.add(Edit);
    buttonGroup1.add(Delete);
    buttonGroup2.add(Typeadmin);
    buttonGroup2.add(Typeuser);
    this.add(jLabel7, null);
    this.add(jPanel1, null);
  }

  void Selectuser_actionPerformed(ActionEvent e) {
    Edit.setSelected(false);
    Delete.setSelected(false);
    Userid.setText("");
    Username.setText("");
    Division.setText("");
    Password.setText("");
    Confirmpass.setText("");

    //Database db = new Database();
    try
    {
      ResultSet rs = db.executeSQLquery("SELECT * FROM USERTABLE WHERE USERID = '" + Selectuser.getSelectedItem() + "'");
      while (rs.next())
      {
        userid = rs.getString("USERID");
        username = rs.getString("USERNAME");
        usertype = rs.getString("USERTYPE");
        userpassword = rs.getString("USERPASSWORD");
        division = rs.getString("DIVISION");
      }

      Userdetail.setText("USERID : " + userid + "\nUSERNAME : " + username + "\nUSERTYPE : " + usertype + "\nUSERPASSWORD : " + userpassword + "\nDIVISION : " + division);
    }
    catch(SQLException sql)
    {
      System.out.println("EditUser1 : " + sql);
    }
  }

  void Edit_actionPerformed(ActionEvent e) {
    Userid.setText(userid);
    Username.setText(username);
    Division.setText(division);
    Password.setText(userpassword);
    Confirmpass.setText(userpassword);
    Userid.setEditable(true);
    Username.setEditable(true);
    Division.setEditable(true);
    Password.setEditable(true);
    Confirmpass.setEditable(true);

    if (usertype.compareTo("admin") == 0)
    {
      Typeadmin.setSelected(true);

    }
    else if (usertype.compareTo("user") == 0 )
    {
      Typeuser.setSelected(true);
    }

  }
  void Typeadmin_actionPerformed(ActionEvent e) {

  }
  void Typeuser_actionPerformed(ActionEvent e) {

  }

  public String getUserid()
  {
    return Selectuser.getSelectedItem().toString();
  }

  public String getUsername()
  {
    return Username.getText();
  }

  public String getDivision()
  {
    return Division.getText();
  }

  public String getPassword()
  {
    String password = new String(Password.getPassword());
    return password;
  }

  public String getConfirmpass()
  {
    String confirmpassword = new String(Confirmpass.getPassword());
    return confirmpassword;
  }

  public boolean getTypeadmin()
  {
    return Typeadmin.isSelected();
  }

  public boolean getTypeuser()
  {
    return Typeuser.isSelected();
  }

  public boolean getEdit()
  {
    return Edit.isSelected();
  }

  public boolean getDelete()
  {
    return Delete.isSelected();
  }

  void Ok_actionPerformed(ActionEvent e) {
    if (Edit.isSelected())
    {
      if (checkallblank())
      {
        //Database db = new Database();
        if (Typeadmin.isSelected())
        {
          db.executeSQLupdate("UPDATE USERTABLE SET USERNAME = '" + Username.getText() + "' , DIVISION = '" + Division.getText() + "' , USERPASSWORD = '" + getPassword() + "' , USERTYPE = 'admin' WHERE USERID = '" + Selectuser.getSelectedItem().toString() + "'") ;
        }
        else if (Typeuser.isSelected())
        {

          db.executeSQLupdate("UPDATE USERTABLE SET USERNAME = '" + Username.getText() + "' , DIVISION = '" + Division.getText() + "' , USERPASSWORD = '" + getPassword() + "' , USERTYPE = 'user' WHERE USERID = '" + Selectuser.getSelectedItem().toString() + "'") ;
        }
      }
    }
    else if (Delete.isSelected())
    {
      //Database db =new Database();
      int temp =Selectuser.getSelectedIndex();
      db.executeSQLupdate("DELETE FROM USERTABLE WHERE USERID = '" + Selectuser.getSelectedItem().toString() + "'");

 /*     Selectuser.removeAllItems();

      try
      {
        ResultSet rs = db.executeSQLquery("SELECT * FROM USERTABLE");
        while (rs.next())
        {
          Selectuser.addItem(rs.getString("USERID"));
        }
      }
      catch(SQLException sql)
      {
        System.out.println("EditUser1 : " + sql);
      }
      Selectuser.repaint();*/

    }
  }

  public boolean checkallblank()
  {
    if (Selectuser.getSelectedItem().toString().compareTo("") !=0 && Username.getText().compareTo("") !=0 && Division.getText().compareTo("") !=0 && getPassword().compareTo("") !=0 && getConfirmpass().compareTo("") != 0 && getPassword().compareTo(getConfirmpass()) == 0)
    {
      return true;

    }
    return false;
  }

  void Cancel_actionPerformed(ActionEvent e) {

  }

  void Delete_actionPerformed(ActionEvent e) {
    Userid.setText("");
    Username.setText("");
    Division.setText("");
    Password.setText("");
    Confirmpass.setText("");
    Userid.setEditable(false);
    Username.setEditable(false);
    Division.setEditable(false);
    Password.setEditable(false);
    Confirmpass.setEditable(false);
  }
}