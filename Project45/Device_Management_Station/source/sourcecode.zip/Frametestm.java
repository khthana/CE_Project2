package dms;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frametestm extends JFrame {
  private JButton jButton1 = new JButton();
  private Database db;
  MessageHandler m;
  public Frametestm(Database d) {
    try {
      db = d;
      m = new MessageHandler(db);
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
 /* public static void main(String[] args) {
    Frametestm frametestm = new Frametestm();
    frametestm.setVisible(true);
  }*/
  private void jbInit() throws Exception {
    jButton1.setBounds(new Rectangle(116, 105, 110, 30));
    jButton1.setText("send");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    this.getContentPane().setLayout(null);
    this.getContentPane().add(jButton1, null);
  }

  void jButton1_actionPerformed(ActionEvent e) {
    m.constructMessage("DEVICE1","INROUTER1","SET","","","");
    m.sendMessage();
  }
}