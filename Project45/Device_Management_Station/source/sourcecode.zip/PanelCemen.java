package dms;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class PanelCemen extends JPanel implements MouseListener{
  private Desktop themain;
  private Database db;
  private BorderLayout borderLayout1 = new BorderLayout();
  Image pic[];
  //int[] x = {0,200,400,600,800,0,200,400,600,800,0,200,400,600,800,0,200,400,600,800};
  //int[] y = {0,0,0,0,0,200,200,200,200,200,400,400,400,400,400,600,600,600,600,600};
  int[] x = {0,200,400,600,0,200,400,600,0,200,400,600,0,200,400,600};
  int[] y = {0,0,0,0,200,200,200,200,400,400,400,400,600,600,600,600};
  int numofdevice;
  String[] name;
  String[][] deviceobjectid;
  int countdevice;
  String[] device;
  int width = 150;
  int height = 150;
  int clickpositionx = 0;
  int clickpositiony = 0;
  String projectname;

  public PanelCemen(int numofdevice,String[] name,String[][] deviceobjectid,int countdevice,String[] device,String pname,Desktop tm,Database d) {
    try {
      db = d;
      themain = tm;
      this.setSize(new Dimension(700,700));
      this.setLayout(borderLayout1);
      this.numofdevice = numofdevice;
      projectname=pname;
      this.name = name;
      this.deviceobjectid = deviceobjectid;
      this.countdevice = countdevice;
      this.device = device;
      pic = new Image[countdevice];
/*    for (int i=0;i<countdevice;i++)
    {
      pic[i] = Toolkit.getDefaultToolkit().getImage("C:/pic/musiccontest1.jpg");
    }*/
    pic = new Image[1];
    pic[0] = Toolkit.getDefaultToolkit().getImage(dms.PanelCemen.class.getResource("device.jpg"));
    addMouseListener(this);
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

  }

  public void paint(Graphics g){
    //System.out.println("paint");
/*    for (int i=0;i<countdevice;i++)
    {
      System.out.println("x = " + x[i]);
      g.drawImage(pic[i],x[i],y[i],width,height,this);


    }*/
    g.drawImage(pic[0],0,0,this);

  }

  public void mousePressed(MouseEvent e){
    clickpositionx = e.getX();
    clickpositiony = e.getY();
    int devicenumber = finddevicenumber();
    System.out.println("devicenumber = " + devicenumber);

    String[] objectofclickdevice;
    int objectcount=0;
    if (devicenumber <= countdevice && devicenumber > 0)
    {
      for(int i=0;i<numofdevice;i++)
      {
        if (device[devicenumber - 1].compareTo(deviceobjectid[i][0]) == 0)
        {
          //objectofclickdevice[j] = deviceobjectid[i][1];

          objectcount++;
        }
      }
      System.out.println("mouseclick: objectcount = " + objectcount);
      objectofclickdevice = new String[objectcount];
      objectcount = 0;
      for(int i=0;i<numofdevice;i++)
      {
        if (device[devicenumber - 1].compareTo(deviceobjectid[i][0]) == 0)
        {
          System.out.println("mouseclick: deviobjectid["+i+"][1] = " + deviceobjectid[i][1]);
          objectofclickdevice[objectcount] = deviceobjectid[i][1];
          objectcount++;

        }
      }

      FrameChooseObject f = new FrameChooseObject(device[devicenumber-1],objectofclickdevice,objectcount,projectname,themain,db);
      f.pack();
      f.setSize(new Dimension(1024,768));
      f.setVisible(true);
    }

  }
  public void mouseReleased(MouseEvent e){}
  public void mouseExited(MouseEvent e){}
  public void mouseEntered(MouseEvent e){}
  public void mouseClicked(MouseEvent e){}

  public int finddevicenumber()
  {
    /*int num = 0;
    boolean flag = true;
    int x=0;
    int y=0;
    for(int i=0;i<4;i++)
    {
      for(int j=0;j<4;j++)
      {
        if ((clickpositionx >= x) && (clickpositionx <= x+width) && (clickpositiony >= y) && (clickpositiony <= y+height))
        {

          num = 4*i + j +1;
          //System.out.println("i = " + i + "j = " + j);
        }
        if (x == 600)
        {
          x = 0;
        }
        else
        {
          x += 200;
        }

      }
      if (y == 600)
      {
        y = 0;
      }
      else
      {
        y += 200;
      }

    }
    //System.out.println("num = " + num);
    return num;*/


    int num = 0;
    /*if ((clickpositionx >= 56) && (clickpositionx <= 123) && (clickpositiony >= 198) && (clickpositiony <= 245))
    {
      num = 1;
    }*/
    if ((clickpositionx >= 245) && (clickpositionx <= 360) && (clickpositiony >= 86) && (clickpositiony <= 172))
    {
      num = 1;
    }
    else if ((clickpositionx >= 504) && (clickpositionx <= 611) && (clickpositiony >= 80) && (clickpositiony <= 163))
    {
      num = 2;
    }
    else if ((clickpositionx >= 711) && (clickpositionx <= 813) && (clickpositiony >= 175) && (clickpositiony <= 270))
    {
      num = 3;
    }
    else if ((clickpositionx >= 512) && (clickpositionx <= 621) && (clickpositiony >= 304) && (clickpositiony <= 382))
    {
      num = 4;
    }
    else if ((clickpositionx >= 266) && (clickpositionx <= 363) && (clickpositiony >= 316) && (clickpositiony <= 382))
    {
      num = 5;
    }
    return num;
  }
}