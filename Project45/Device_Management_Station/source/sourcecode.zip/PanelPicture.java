package dms;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class PanelPicture extends JPanel implements MouseListener{
  private Database db;
  private Desktop themain;
  private BorderLayout borderLayout1 = new BorderLayout();
  Image pic[];
  //int[] x = {0,200,400,600,800,0,200,400,600,800,0,200,400,600,800,0,200,400,600,800};
  //int[] y = {0,0,0,0,0,200,200,200,200,200,400,400,400,400,400,600,600,600,600,600};
  //int[] x = {0,200,400,600,0,200,400,600,0,200,400,600,0,200,400,600};
  //int[] y = {0,0,0,0,200,200,200,200,400,400,400,400,600,600,600,600};
  int[] x = {0,150,300,0,150,300,0,150,300};
  int[] y = {0,0,0,150,150,150,300,300,300};
  int numofdevice;
  private String[] name;
  private String[][] deviceobjectid;
  int countdevice;
  String[] device;
  int width = 100;
  int height = 100;
  int clickpositionx = 0;
  int clickpositiony = 0;
  private String projectname;
  private MessageHandler m;

  public PanelPicture(int numofdevice,String[] name,String[][] deviceobjectid,int countdevice,String[] device,String pname,Desktop tm,Database d) {
    try {
      db = d;
      m = new MessageHandler(db);
      themain = tm;
      this.setSize(new Dimension(500,400));
      this.setLayout(borderLayout1);
    this.numofdevice = numofdevice;
    projectname=pname;
    this.name = name;
    this.deviceobjectid = deviceobjectid;
    this.countdevice = countdevice;
    this.device = device;
    pic = new Image[countdevice];
    for (int i=0;i<countdevice;i++)
    {
      m.constructMessage(device[i],"","GET","","","");
      m.sendMessage();
      try
      {
        Thread.currentThread().sleep(100);
      }
      catch (Exception ee)
      {

      }
      String temp = m.recieveMessage();
      if (temp.compareTo("*") == 0)
      {
        pic[i] = Toolkit.getDefaultToolkit().getImage(dms.PanelCemen.class.getResource("exclam.gif"));
      }
      else
      {
        pic[i] = Toolkit.getDefaultToolkit().getImage(dms.PanelCemen.class.getResource("device1.jpg"));
      }

    }




    addMouseListener(this);
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {

  }

  public void paint(Graphics g){
    //System.out.println("paint");
    g.setColor(Color.blue);

    for (int i=0;i<countdevice;i++)
    {
      System.out.println("x = " + x[i]);
      g.drawImage(pic[i],x[i],y[i],width,height,this);
      g.drawString(device[i],x[i],y[i]+width+10);


    }


  }

  public void refresh()
  {
    for (int i=0;i<countdevice;i++)
    {
      m.constructMessage(device[i],"","GET","","","");
      m.sendMessage();
      try
      {
        Thread.currentThread().sleep(100);
      }
      catch (Exception ee)
      {

      }
      String temp = m.recieveMessage();
      if (temp.compareTo("*") == 0)
      {
        pic[i] = Toolkit.getDefaultToolkit().getImage(dms.PanelCemen.class.getResource("exclam.gif"));
      }
      else
      {
        pic[i] = Toolkit.getDefaultToolkit().getImage(dms.PanelCemen.class.getResource("device1.jpg"));
      }

    }

    this.repaint();
  }

  public void mousePressed(MouseEvent e){
    clickpositionx = e.getX();
    clickpositiony = e.getY();
    int devicenumber = finddevicenumber();
    System.out.println("devicenumber = " + devicenumber);

    String[] objectofclickdevice;
    int objectcount=0;
    if (devicenumber <= countdevice && devicenumber > 0)
    {
      for(int i=0;i<numofdevice;i++)
      {
        if (device[devicenumber - 1].compareTo(deviceobjectid[i][0]) == 0)
        {
          //objectofclickdevice[j] = deviceobjectid[i][1];

          objectcount++;
        }
      }
      System.out.println("mouseclick: objectcount = " + objectcount);
      objectofclickdevice = new String[objectcount];
      objectcount = 0;
      for(int i=0;i<numofdevice;i++)
      {
        if (device[devicenumber - 1].compareTo(deviceobjectid[i][0]) == 0)
        {
          System.out.println("mouseclick: deviobjectid["+i+"][1] = " + deviceobjectid[i][1]);
          objectofclickdevice[objectcount] = deviceobjectid[i][1];
          objectcount++;

        }
      }

      FrameChooseObject f = new FrameChooseObject(device[devicenumber-1],objectofclickdevice,objectcount,projectname,themain,db);
      //f.pack();
      f.setSize(new Dimension(800,600));
      f.setVisible(true);
    }

  }
  public void mouseReleased(MouseEvent e){}
  public void mouseExited(MouseEvent e){}
  public void mouseEntered(MouseEvent e){}
  public void mouseClicked(MouseEvent e){}

  public int finddevicenumber()
  {
    int num = 0;
    boolean flag = true;
    int x=0;
    int y=0;
    for(int i=0;i<3;i++)
    {
      for(int j=0;j<3;j++)
      {
        if ((clickpositionx >= x) && (clickpositionx <= x+width) && (clickpositiony >= y) && (clickpositiony <= y+height))
        {

          num = 3*i + j +1;
          //System.out.println("i = " + i + "j = " + j);
        }
        if (x == 300)
        {
          x = 0;
        }
        else
        {
          x += 150;
        }

      }
      if (y == 300)
      {
        y = 0;
      }
      else
      {
        y += 150;
      }

    }
    //System.out.println("num = " + num);
    return num;

  }
}