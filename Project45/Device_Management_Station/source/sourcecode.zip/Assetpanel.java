package dms;

import java.awt.*;
import com.borland.dbswing.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.tree.*;
import javax.swing.event.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Assetpanel extends JPanel implements TreeSelectionListener {
  private JButton jButton1 = new JButton();
  private String projectname;
  private Database db;
  private String selectobject1;
  private String selectobject2;
  private JButton jButton2 = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JButton jButton3 = new JButton();
  private JTree jTree1;
  private JTree jTree2;
  private JScrollPane jScrollPane3 = new JScrollPane();
  private JTextArea jTextArea1 = new JTextArea();
  public Assetpanel(String pname,Database d) {
    db = d;
    projectname = pname;
    try {

      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    this.setLayout(null);
    jButton1.setBounds(new Rectangle(13, 389, 368, 27));
    jButton1.setText("view device in project");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton2.setText("view user in project");
    jButton2.setBounds(new Rectangle(13, 423, 368, 27));
    jScrollPane1.setBounds(new Rectangle(15, 229, 115, 151));
    jScrollPane2.setBounds(new Rectangle(15, 41, 115, 149));
    jLabel1.setText("Device list");
    jLabel1.setBounds(new Rectangle(16, 12, 56, 17));
    jLabel2.setBounds(new Rectangle(15, 198, 102, 24));
    jLabel2.setText("User list");
    jButton3.setBounds(new Rectangle(211, 326, 94, 26));
    jButton3.setText("CLEAR");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    jScrollPane3.setBounds(new Rectangle(146, 40, 241, 256));
    this.add(jButton2, null);
    this.add(jButton1, null);
    this.add(jScrollPane1, null);
    //jScrollPane1.getViewport().add(jTree2, null);
    this.add(jScrollPane2, null);
    //jScrollPane2.getViewport().add(jTree1, null);
    this.add(jLabel2, null);
    this.add(jLabel1, null);
    this.add(jButton3, null);
    this.add(jScrollPane3, null);
    jScrollPane3.getViewport().add(jTextArea1, null);
    buildtree();
  }
  public void buildtree()
  {
    MouseListener m1 = new MouseAdapter()
   {
     public void mouseClicked(MouseEvent e)
     {
       if(e.getClickCount()==2)
       {
         System.out.println("Double click");
         if(selectobject1.compareTo(projectname)!=0)
         {
         ResultSet rs = db.executeSQLquery("SELECT * FROM DEVICE WHERE DEVICEID IN (SELECT DEVICEID FROM PROJECTDEVICE WHERE PROJECTID ='"+projectname+"') AND DEVICEID='"+selectobject1+"'");
             //'"+selectobject1+"' AND PROJECTID='"+projectname+"'");
         jTextArea1.setText("Device profile :\n");
         try{
           while(rs.next())
           {
             jTextArea1.append(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+" "+rs.getString(5)+"\n");
           }
         }
         catch(SQLException sql)
         {
           System.out.println("Error connecting Database");
         }
         }
       }

     }
  };
   MouseListener m2 = new MouseAdapter()
 {
   public void mouseClicked(MouseEvent e)
   {
     if(e.getClickCount()==2)
     {
       System.out.println("Double click");
       if(selectobject2.compareTo(projectname)!=0)
         {
         ResultSet rs2 = db.executeSQLquery("SELECT * FROM USERTABLE WHERE USERID IN (SELECT USERID FROM PROJECTUSER WHERE PROJECTID='"+projectname+"') AND USERID ='"+selectobject2+"'");
         jTextArea1.setText("User profile :\n");
         try{
           while(rs2.next())
           {
             jTextArea1.append(rs2.getString(2)+"  "+rs2.getString(3)+" "+rs2.getString(5)+" "+rs2.getString(6)+"\n");
           }
         }
         catch(SQLException sql)
         {
           System.out.println("Error connecting Database");
         }
         }
     }

   }
  };
     DefaultMutableTreeNode root = new DefaultMutableTreeNode(projectname);
     jTree1 = new JTree(root);
     ResultSet rs10 = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM PROJECTDEVICE WHERE PROJECTID='"+projectname+"'");
     try{
       while(rs10.next())
       {
         DefaultMutableTreeNode temp = new DefaultMutableTreeNode(rs10.getString("DEVICEID"));
         root.add(temp);
       }
     }catch(SQLException sql1)
     {}
     DefaultMutableTreeNode root2 = new DefaultMutableTreeNode(projectname);
     jTree2 = new JTree(root2);
    ResultSet rs11 = db.executeSQLquery("SELECT USERNAME FROM PROJECTUSER WHERE PROJECTID='"+projectname+"'");
    try{
      while(rs11.next())
      {
        DefaultMutableTreeNode temp2 = new DefaultMutableTreeNode(rs11.getString("USERNAME"));
        root2.add(temp2);
      }
    }catch(SQLException sql2)
     {}
    jTree1.addMouseListener(m1);
    jTree2.addMouseListener(m2);
    jTree1.addTreeSelectionListener(this);
    jTree2.addTreeSelectionListener(this);
    jScrollPane2.getViewport().add(jTree1, null);
    jScrollPane1.getViewport().add(jTree2, null);
  }
  public void valueChanged(TreeSelectionEvent ev)
  {
    if(ev.getSource().equals(jTree1)==true)
    {
      TreePath path=jTree1.getSelectionPath();
     System.out.println("Selection path=" + path.toString());
     System.out.println(jTree1.getLastSelectedPathComponent().toString());
     selectobject1 = jTree1.getLastSelectedPathComponent().toString();
     System.out.println("The object select is " + selectobject1);
    }
    else if(ev.getSource().equals(jTree2)==true)
    {
      TreePath path=jTree2.getSelectionPath();
      System.out.println("Selection path=" + path.toString());
      System.out.println(jTree2.getLastSelectedPathComponent().toString());
      selectobject2 = jTree2.getLastSelectedPathComponent().toString();
     System.out.println("The object select is " + selectobject2);
    }
  }
  void jButton1_actionPerformed(ActionEvent e) {
   ResultSet rs33 = db.executeSQLquery("SELECT DISTINCT DEVICEID FROM PROJECTDEVICE WHERE PROJECTID ='"+projectname+"'");
   int rowcount=0;
   try{
   while(rs33.next())
   {
     rowcount++;
   }
   }catch(SQLException sql)
   {

   }
   String[][]  datavalue = new String[rowcount][2];
   String[] name = new String[2];
   name[0]="PROJECTID";
   name[1]="DEVICEID";
   int x=0;
   ResultSet rs22 = db.executeSQLquery("SELECT DISTINCT PROJECTID,DEVICEID FROM PROJECTDEVICE WHERE PROJECTID ='"+projectname+"'");
   try{
   while(rs22.next())
   {
     for(int i=0;i<2;i++)
     {
     datavalue[x][i] = rs22.getString(i+1);
     }
     x++;
   }
   }catch(SQLException sql)
   {

   }
   Thetable tt = new Thetable(name,datavalue);
   tt.show();
  }
  void jButton2_actionPerformed(ActionEvent e) {
    ResultSet rs3 = db.executeSQLquery("SELECT * FROM PROJECTUSER WHERE PROJECTID ='"+projectname+"'");
     int rowcount2=0;
     try{
     while(rs3.next())
     {
       rowcount2++;
     }
     }catch(SQLException sql)
     {

     }
     String[][]  datavalue = new String[rowcount2][2];
     String[] name = new String[2];
     name[0]="USERNAME";
     name[1]="PROJECTID";
     int x=0;
     ResultSet rs4 = db.executeSQLquery("SELECT * FROM PROJECTUSER WHERE PROJECTID ='"+projectname+"'");
     try{
     while(rs4.next())
     {
       for(int i=0;i<2;i++)
       {
       datavalue[x][i] = rs4.getString(i+1);
       }
       x++;
     }
     }catch(SQLException sql)
     {

     }
     Thetable tt = new Thetable(name,datavalue);
   tt.show();
  }

  void jButton3_actionPerformed(ActionEvent e) {
    jTextArea1.setText("");
  }


}