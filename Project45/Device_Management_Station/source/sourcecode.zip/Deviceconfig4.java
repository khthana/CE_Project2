package dms;


import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.border.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Deviceconfig4 extends JPanel {
  Mib m = new Mib();
  List Objectlist = new List();
  JButton Add = new JButton();
  List Objectmaplist = new List();
  private JButton Delete = new JButton();
  private JTextField Community = new JTextField();
  private JLabel jLabel1 = new JLabel();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  private JLabel jLabel4 = new JLabel();
  private BoxLayout2 boxLayout21 = new BoxLayout2();
  private JTextField Textsnmpobject = new JTextField();
  private JRadioButton Tree = new JRadioButton();
  private JRadioButton Textbox = new JRadioButton();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JPanel jPanel1 = new JPanel();
  private VerticalFlowLayout verticalFlowLayout1 = new VerticalFlowLayout();
  private Border border1;
  private JLabel jLabel5 = new JLabel();
  private JLabel jLabel6 = new JLabel();
  //FileInputStream mibfile;
  public Deviceconfig4() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }
  void jbInit() throws Exception {
    border1 = BorderFactory.createEtchedBorder(Color.white,new Color(142, 142, 142));
    this.setSize(new Dimension(1000,700));

    this.setLayout(null);
    m.setLayout(boxLayout21);
    //m.load(mibfile);
    Add.setBounds(new Rectangle(613, 286, 105, 26));
    Add.setText("ADD");
    Add.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Add_actionPerformed(e);
      }
    });
    Delete.setBounds(new Rectangle(613, 326, 106, 27));
    Delete.setText("DELETE");
    Delete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Delete_actionPerformed(e);
      }
    });
    Community.setText("public");
    Community.setBounds(new Rectangle(120, 64, 114, 35));
    jLabel1.setText("MAP OBJECT");
    jLabel1.setBounds(new Rectangle(436, 7, 210, 32));
    jLabel2.setText("OBJECT ID");
    jLabel2.setBounds(new Rectangle(40, 110, 119, 25));
    jLabel3.setText("SNMP OBJECT");
    jLabel3.setBounds(new Rectangle(248, 109, 148, 26));
    jLabel4.setText("COMMUNITY");
    jLabel4.setBounds(new Rectangle(35, 69, 83, 25));
    m.setBounds(new Rectangle(240, 238, 335, 247));
    Textsnmpobject.setBounds(new Rectangle(243, 150, 328, 38));
    Tree.setSelected(true);
    Tree.setText("Tree");
    Tree.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Tree_actionPerformed(e);
      }
    });
    Textbox.setText("Textbox");
    Textbox.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Textbox_actionPerformed(e);
      }
    });
    jPanel1.setBorder(border1);
    jPanel1.setBounds(new Rectangle(425, 44, 101, 66));
    jPanel1.setLayout(verticalFlowLayout1);
    jLabel5.setBounds(new Rectangle(243, 195, 148, 26));
    jLabel5.setText("SNMP OBJECT");
    jLabel6.setText("SELECT SNMP OBJECT BY");
    jLabel6.setBounds(new Rectangle(262, 65, 151, 33));
    Objectlist.setBounds(new Rectangle(35, 145, 160, 411));
    Objectmaplist.setBounds(new Rectangle(759, 152, 211, 405));
    jPanel1.add(Textbox, null);
    jPanel1.add(Tree, null);
    this.add(Objectlist, null);
    this.add(Objectmaplist, null);
    this.add(jLabel5, null);
    this.add(m, null);
    this.add(Textsnmpobject, null);
    this.add(Add, null);
    this.add(Delete, null);
    this.add(jLabel1, null);
    this.add(jLabel2, null);
    this.add(jLabel3, null);
    this.add(Community, null);
    this.add(jLabel4, null);

    this.add(jLabel6, null);
    this.add(jPanel1, null);
    buttonGroup1.add(Tree);
    buttonGroup1.add(Textbox);
    Textsnmpobject.setEnabled(false);
  }

  void Add_actionPerformed(ActionEvent e) {
    String objecttemp =Objectlist.getSelectedItem();
    if (Objectlist.getSelectedIndex() != -1)
    {
      if (Tree.isSelected())
      {
       /* Objectmaplist.add(objecttemp.substring(0,objecttemp.indexOf(" , "))+" , "+m.getobj()+".0"+" , "+Community.getText());
        Objectlist.remove(Objectlist.getSelectedIndex());
        System.out.println(objecttemp.substring(0,objecttemp.indexOf(" , ")));*/
        Objectmaplist.add(objecttemp+" , "+m.getobj()+".0"+" , "+Community.getText());
        Objectlist.remove(Objectlist.getSelectedIndex());
        System.out.println(objecttemp);
      }
      else if (Textbox.isSelected() && Textsnmpobject.getText().compareTo("") != 0)
      {
       /* Objectmaplist.add(objecttemp.substring(0,objecttemp.indexOf(" , "))+" , "+Textsnmpobject.getText()+" , "+Community.getText());
        Objectlist.remove(Objectlist.getSelectedIndex());
        Textsnmpobject.setText("");*/
        Objectmaplist.add(objecttemp+" , "+Textsnmpobject.getText()+" , "+Community.getText());
        Objectlist.remove(Objectlist.getSelectedIndex());
        Textsnmpobject.setText("");
      }
    }




  }

  void Delete_actionPerformed(ActionEvent e) {
    if (Objectmaplist.getSelectedIndex() != -1)
    {
      String temp = Objectmaplist.getSelectedItem();
      Objectlist.add(temp.substring(0,temp.indexOf(" , ")));
      Objectmaplist.remove(Objectmaplist.getSelectedIndex());
    }

  }

  void Textbox_actionPerformed(ActionEvent e) {
    Textsnmpobject.setEnabled(true);
    m.setEnabled(false);
  }

  void Tree_actionPerformed(ActionEvent e) {
    Textsnmpobject.setEnabled(false);
    m.setEnabled(true);
  }
}