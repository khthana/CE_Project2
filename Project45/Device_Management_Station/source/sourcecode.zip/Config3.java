package dms;

import java.awt.*;
import java.awt.event.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.io.*;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileFilter;
import java.sql.*;
import javax.swing.tree.*;
import javax.swing.border.*;
import com.klg.jclass.chart.beans.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2001</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Config3 extends JPanel {
  String[][] group = new String[5][100];
  String[][] monitor = new String[3][100];
  boolean[] planning = new boolean[100];
  int countgroup = 0;
  int countmonitor = 0;
  Connection dbCon;
  //PaneLayout paneLayout1 = new PaneLayout();
  //JPanel jPanel1 = new JPanel();
  JLabel jLabel1 = new JLabel();

  //create the tree
  DefaultMutableTreeNode top =  new DefaultMutableTreeNode("DEVICE");

  JTree Objecttree = new JTree(top);
  JScrollPane treeView = new JScrollPane(Objecttree);
  DefaultTreeCellRenderer treeRenderer = new DefaultTreeCellRenderer();



  DefaultMutableTreeNode node[] = new DefaultMutableTreeNode[1000];
  DefaultMutableTreeNode child[] = new DefaultMutableTreeNode[1000];

  private Border border1;
  private JPanel jPanel2 = new JPanel();
  private Border border2;
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  JRadioButton Text = new JRadioButton();
  JRadioButton Graph = new JRadioButton();
  JRadioButton Table = new JRadioButton();
  private ButtonGroup buttonGroup2 = new ButtonGroup();
  List Grouplist = new List();
  private JButton Addtogroup = new JButton();
  private JButton Okperformance = new JButton();
  private JButton Cancleperformance = new JButton();
  JComboBox Graphtype = new JComboBox();
  JTextField Group = new JTextField();
  private JLabel jLabel2 = new JLabel();
  private JLabel jLabel3 = new JLabel();
  JCheckBox Planning = new JCheckBox();
  private JButton Removefromgroup = new JButton();
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JLabel jLabel4 = new JLabel();
  private JButton View = new JButton();

  public Config3() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /*public static void main(String arg[])
  {

    Config2 con2 = new Config2();

    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = con2.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    con2.setSize(frameSize.width,frameSize.height);
    con2.setLocation((screenSize.width - frameSize.width) / 2, (screenSize.height - frameSize.height) / 2);

    con2.setVisible(true);
  }*/

  private void jbInit() throws Exception {
    this.setSize(new Dimension(1000,700));
    Addtogroup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Addtogroup_actionPerformed(e);
      }
    });
    Okperformance.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Okperformance_actionPerformed(e);
      }
    });
    jLabel2.setText("GROUP ID");
    jLabel2.setBounds(new Rectangle(30, 45, 79, 28));
    jLabel3.setText("GROUP LIST");
    jLabel3.setBounds(new Rectangle(24, 94, 120, 32));
    Planning.setText("logging");
    Planning.setBounds(new Rectangle(27, 7, 157, 27));
    Removefromgroup.setBounds(new Rectangle(336, 266, 154, 32));
    Removefromgroup.setText("Remove From Group");
    Removefromgroup.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Removefromgroup_actionPerformed(e);
      }
    });
    Cancleperformance.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Cancleperformance_actionPerformed(e);
      }
    });
    jScrollPane1.setBounds(new Rectangle(155, 101, 184, 216));
    jLabel4.setText("DEVICE LIST");
    jLabel4.setBounds(new Rectangle(16, 41, 137, 27));
    View.setBounds(new Rectangle(223, 447, 92, 27));
    View.setText("VIEW");
    View.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        View_actionPerformed(e);
      }
    });
    jPanel2.add(jLabel2, null);
    jPanel2.add(Group, null);
    jPanel2.add(Planning, null);
    jPanel2.add(jScrollPane1, null);
    jPanel2.add(jLabel3, null);
    jPanel2.add(Text, null);
    jPanel2.add(Table, null);
    jPanel2.add(Graph, null);
    jPanel2.add(Graphtype, null);
    jPanel2.add(View, null);
    jPanel2.add(Cancleperformance, null);
    jPanel2.add(Okperformance, null);
    jScrollPane1.getViewport().add(Grouplist, null);
    this.add(jLabel1, null);
    this.add(jLabel4, null);
    //this.getContentPane().setLayout(paneLayout1);
    border1 = BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(109, 109, 110),new Color(156, 156, 158));
    border2 = BorderFactory.createCompoundBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED,Color.white,Color.white,new Color(109, 109, 110),new Color(156, 156, 158)),BorderFactory.createEmptyBorder(6,6,6,6));
    this.setLayout(null);
    //jPanel1.setLayout(null);

    Objecttree.setEditable(true);
    Objecttree.getSelectionModel().setSelectionMode(TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);
    Objecttree.setShowsRootHandles(true);


    treeView.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    treeView.setViewportBorder(BorderFactory.createEtchedBorder());
    treeView.setBounds(new Rectangle(15, 72, 282, 355));

    jLabel1.setText("MONITOR");
    jLabel1.setBounds(new Rectangle(310, 7, 206, 32));
    jPanel2.setBorder(border2);
    jPanel2.setBounds(new Rectangle(569, 24, 369, 535));
    jPanel2.setLayout(null);
    Text.setSelected(true);
    Text.setText("TEXT");
    Text.setBounds(new Rectangle(51, 325, 103, 25));
    Graph.setText("GRAPH");
    Graph.setBounds(new Rectangle(50, 410, 99, 25));
    Table.setText("TABLE");
    Table.setBounds(new Rectangle(49, 364, 106, 27));
    //this.getContentPane().add(jPanel1, new PaneConstraints("jPanel1", "jPanel1", PaneConstraints.ROOT, 0.5f));
    Addtogroup.setBounds(new Rectangle(336, 164, 154, 32));
    Addtogroup.setText("Add To Group");
    Okperformance.setBounds(new Rectangle(58, 482, 98, 26));
    Okperformance.setText("OK");
    Cancleperformance.setBounds(new Rectangle(223, 482, 98, 26));
    Cancleperformance.setText("CANCLE");
    Graphtype.setBounds(new Rectangle(176, 407, 149, 26));
    Graphtype.addItem("plot");
    Graphtype.addItem("bar");
    Graphtype.addItem("area");


    Group.setBounds(new Rectangle(155, 47, 184, 27));
    this.add(treeView, null);
    this.add(Addtogroup, null);
    this.add(Removefromgroup, null);
    this.add(jPanel2, null);
    buttonGroup2.add(Text);
    buttonGroup2.add(Table);
    buttonGroup2.add(Graph);
  }



  void mibbrowse_actionPerformed(ActionEvent e) {
    //this.setEnabled(false);
      JFileChooser chooser = new JFileChooser();
      //ExampleFileFilter filter = new ExampleFileFilter();

      //filter.addExtension("mib");
      //filter.addExtension("gif");
      //filter.setDescription("MIB FILE");
      //chooser.setFileFilter(filter);

      try {
        if ( chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
          //final FileInputStream mibFile = new FileInputStream(chooser.getSelectedFile());
          //mib.setText(chooser.getSelectedFile().getAbsolutePath());

        }
      }
      catch (Exception ex) {
                //setEnabled(true);
                System.err.println("Catch exception while parsing mib: " + ex );
              }
  }

  void Canclefault_actionPerformed(ActionEvent e) {
    //Config4 c4 = new Config4();
    //c4.show();
  }

  void Addtogroup_actionPerformed(ActionEvent e) {
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)Objecttree.getLastSelectedPathComponent();

     TreePath pathnode = (TreePath)Objecttree.getLeadSelectionPath();
     if (Objecttree.isVisible(pathnode)) {

      if (node.isLeaf()) {
        String leafpath = Objecttree.getLastSelectedPathComponent().toString();
        TreePath temp = Objecttree.getAnchorSelectionPath().getParentPath();
        String parent = temp.getLastPathComponent().toString();
        //System.out.println(leafpath);
        //System.out.println(parent);
        Grouplist.add(parent+" , "+leafpath);
        //createNodes2(parent,leafpath,top2);
        }
        else if (node.isRoot()) {
            System.out.println("root");
        }
        else if (node.isNodeAncestor(top)) {
          System.out.println("ancestor");
        }
     }
  }

  void Okperformance_actionPerformed(ActionEvent e) {


    String[] grouplist = new String[Grouplist.getItemCount()];
    grouplist = Grouplist.getItems();
    monitor[0][countmonitor] = Group.getText();
    if (Text.isSelected())
    {
      monitor[1][countmonitor] = "text";

    }
    else if (Table.isSelected())
    {
      monitor[1][countmonitor] = "table";

    }
    else if (Graph.isSelected())
    {
      monitor[1][countmonitor] = "graph";

      monitor[2][countmonitor] = Graphtype.getSelectedItem().toString();
    }
    planning[countmonitor] = Planning.isSelected();
    System.out.println(monitor[0][countmonitor] + " , " + monitor[1][countmonitor] + " , " + monitor[2][countmonitor]);
    countmonitor++;

    for(int i=0;i<grouplist.length;i++)
    {
      group[0][countgroup+i] = Group.getText();
      group[1][countgroup+i] = grouplist[i].substring(0,grouplist[i].indexOf(" , "));
      group[2][countgroup+i] = grouplist[i].substring(grouplist[i].indexOf(" , ")+3);
      if (Text.isSelected())
      {
        group[3][countgroup+i] = "text";

      }
      else if (Table.isSelected())
      {
        group[3][countgroup+i] = "table";

      }
      else if (Graph.isSelected())
      {
        group[3][countgroup+i] = "graph";

        group[4][countgroup+i] = Graphtype.getSelectedItem().toString();
      }
      //System.out.println(group[0][countgroup+i] + " , " + group[1][countgroup+i] + " , " + group[2][countgroup+i] + " , " + group[3][countgroup+i]);

      //data.insertdb("INSERT INTO OBJECT (DEVICEID,OBJECTID,DATATYPE) VALUES('"+deviceid+"','"+objectid+"','"+datatype+"')");
      /*System.out.print(objectlist[i]);
      System.out.println(objectlist[i].indexOf(" , "));
      System.out.println(objectid);
      System.out.println(datatype);*/

    }
    countgroup += grouplist.length;


    for (int k=0;k<countgroup;k++)
    {
      System.out.println("Config3 OK : " + group[0][k] + " , " + group[1][k] + " , " + group[2][k] + " , " + group[3][k]);
    }
    //clear
    Planning.setSelected(false);
    Group.setText("");
    Grouplist.removeAll();
    Text.setSelected(true);
    Graphtype.setSelectedIndex(0);

  }

  void Cancleperformance_actionPerformed(ActionEvent e) {
    //clear
    Planning.setSelected(false);
    Group.setText("");
    Grouplist.removeAll();
    Text.setSelected(true);
    Graphtype.setSelectedIndex(0);
  }

  void Removefromgroup_actionPerformed(ActionEvent e) {
    if (Grouplist.getSelectedIndex() != -1)
    {

      Grouplist.remove(Grouplist.getSelectedItem());
    }
  }

  void View_actionPerformed(ActionEvent e) {
    MonitorView f = new MonitorView(this,monitor,countmonitor,group,countgroup,planning);
    f.setVisible(true);
    f.setSize(700,600);
  }

  void SetMonitor(String[][] mon,int countmon,String[][] gr,int countgr,boolean[] plan)
  {
    monitor = mon;
    countmonitor = countmon;
    group = gr;
    countgroup = countgr;
    planning = plan;
  }
}