package dms;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;
import ipworks.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Frame6 extends JFrame {
  private Snmp snmp1 = new Snmp();

  public Frame6() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    Frame6 frame6 = new Frame6();
  }
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(null);
  }

}