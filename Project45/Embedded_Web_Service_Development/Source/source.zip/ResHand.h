// RequestH.h


#ifndef __RESPONSEHANDLER_H
#define __RESPONSEHANDLER_H
#include <stdio.h>

class ResponseHandler
{
	public:
	setObjectSerialize();
	buildSOAPEnvelope();
	checkError();
	buildSOAPFault();
};
#endif