// package
// file name : Str.h
#ifndef __CONST_H
#define __CONST_H
class Constants
{
	  public:
	  // Namespace prefixes.
	  static const char* XMLNS;
	  static const char* SOAP;
	  static const char* SOAP_ENV;
	  static const char* SOAP_ENC;
	  static const char* XSI;
	  static const char* XSD;

	  // Namespace URIs.
	  static const char* XMLNS_URI;
	  static const char* SOAP_ENV_URI;
	  static const char* SOAP_ENC_URI;
	  static const char* XSI1999_URI;
	  static const char* XSD1999_URI;
	  static const char* XSI2000_URI;
	  static const char* XSD2000_URI;
	  static const char* XSI2001_URI;
	  static const char* XSD2001_URI;

	  static const char* XML_SOAP;
	  static const char* XML_SOAP_DEPLOYMENT;
	  static const char* LITERAL_XML;
	  static const char* XMI_ENC;

	  // HTTP header field names.
	  static const char* POST;
	  static const char* HOST;
	  static const char* CONTENT_TYPE;
	  static const char* CONTENT_TYPE_JMS;
	  static const char* CONTENT_LENGTH;
	  static const char* CONTENT_LOCATION;
	  static const char* CONTENT_ID;
	  static const char* SOAP_ACTION;
	  static const char* AUTHORIZATION;
	  static const char* PROXY_AUTHORIZATION;

	  // HTTP header field values.
	  static const char* DEFAULT_CHARSET;
	  static const char* CHARSET_UTF8;
	  static const char* CONTENT_TYPE_V;
	  static const char* CONTENT_TYPE_UTF8;

	  // XML Declaration char*
	  static const char* XML_DECL;

	  // Element names.
	  static const char* ENVELOPE;
	  static const char* BODY;
	  static const char* HEADER;
	  static const char* FAULT;
	  static const char* FAULT_CODE;
	  static const char* FAULT_STRING;
	  static const char* FAULT_ACTOR;
	  static const char* DETAIL;
	  static const char* FAULT_DETAIL_ENTRY;
	  //RPC constants
	  static const char* PARAMETER;
	  static const char* RETURN;
	  static const char* RESPONSE;
	  static const char* NS;
	  // Qualified element names.
	  /*static const char* Q_ENVELOPE	="SOAP-ENV:Envelope";
	  static const char* Q_HEADER	="SOAP-ENV:Header";
	  static const char* Q_BODY		="SOAP-ENV:Body";
	  static const char* Q_FAULT	="SOAP-ENV:Fault";
	  static const char* Q_ACTOR	="SOAP-ENV:actor";*/

	  // Attribute names.
	  static const char* ENCODING_STYLE;
	  static const char* MUST_UNDERSTAND;
	  static const char* TYPE;
	  static const char* A_NULL;
	  static const char* NIL;
	  static const char* ARRAY_TYPE;
	  static const char* REFERENCE;
	  static const char* ID;

	  // Qualified attribute names.
	  static const char* Q_MUST_UNDERSTAND;

	  // Attribute values.
	  static const char* TRUE;

	  // SOAP defined fault codes.
	  static const char* VERSION_MISMATCH;
	  static const char* MUST_UNDERSTAND_F;
	  static const char* CLIENT;
	  static const char* SERVER;
	  static const char* PROTOCOL;

	  // XML-SOAP implementation defined fault codes.
	  static const char* BAD_TARGET_OBJECT_URI;

	  // Error messages.
	  static const char* ERR_MSG_VERSION_MISMATCH;
	  static const char* ERR_BODYTAG;
};
#endif