#include<stdlib.h>
#include<stdio.h>
#include<iostream.h>
#include<conio.h>
#include<process.h>
#include"Parser.h"
#include"ParseE.h"
#include"Soappar.h"
#include"SoapDes.h"
#include"SoapRes.h"
void main()
{
	clrscr();
	const max=2000;
	char a[max];
	char ch;
	int i=0;
	
    const char* TXT_S="txt";
	const char* EXE_S="exe";
	const char* DOT_S=".";
	FILE *stream;
	stream=fopen("soapin.txt","r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>max)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	//close service description file
	fclose(stream);  //	break;
	a[i++]='\n';
	a[i]='\0';
	printf("Request is...\n%s",a);
	//getch();

	Envelope *env;
	env=SOAPParser::parse(a);
	//char *hit;
	//cout<<"env->getEnvelopeEntries()="<<env->getEnvelopeEntries()<<endl;
	//hit=env->getAttribute();
	//cout<<"env->getAttribute()      ="<<hit<<endl;
	//delete hit;
	//hit=env->marshall();
	//cout<<"env->marshall()          ="<<hit<<endl;
	//delete hit;
	Body b=env->getBody();

	//cout<<"b.getMethod.getMethodName()="<<b.getMethod().getMethodName()<<endl;
	//cout<<"b.getMethod.getMethodURL() ="<<b.getMethod().getMethodURL()<<endl;
	//cout<<"b.getMethod.getMethodEnc() ="<<b.getMethod().getMethodEnc()<<endl;
	//cout<<"b.getMethod.getParameter().getParameter()="<<b.getMethod().getParameter().getParameter()<<endl;

	//getch();
	clrscr();
	/*if (SOAPParser::checkServiceName(b.getMethod().getMethodURL()))
	{
		printf("rigdj");
	}
	else
		printf("falsdf");
	char* fileN="sd1.txt\0";
	char* met="getAddressFromName\0";
	if (SOAPParser::checkMethodName(met,fileN))
	{
		printf("right");
	}
	else
		printf("false");*/
	clrscr();
	SOAPDeserialize d;
	//char *m="getAddressFromName\0";
	d.setServiceMethod(b.getMethod().getMethodName());//m);
		
	//char *f="sd1.txt\0";
	char *ts=SOAPParser::getServiceName(b.getMethod().getMethodURL());
	Str fileName;
	const char *mnames="Address";
	if (ts!=NULL)
	{
		fileName=ts;
		delete ts;
	}
	else
	{
		delete ts;
		fileName=mnames;
	}
	fileName+=DOT_S;
	fileName+=TXT_S;
	d.readServiceMap(fileName.getStr());//(b.getMethod().getMethodURL());
	Parameter p=b.getMethod().getParameter();
	//char *in="input.txt\0";
	p.writeFile();
	//getch();
	fileName.replaceAfter(EXE_S,'.');
	char* final=new char[fileName.getSize()+1];
	strcpy(final,fileName.getStr());
	strcat(final,NULL);///replace down
	int ie = spawnl(P_WAIT,final,NULL);
	delete final;
	if (ie==-1)
	{
		perror("Error from spawnl");
		exit(1);
	}
	char* soap=d.serialOutput();
	printf("soap=\n%s",soap);
	final=NULL;
	final=SOAPResponse::buildResponse(env,soap);
	delete soap;
	printf("%s",final);
	stream=fopen("soap.txt","w+");
	fseek(stream,0,SEEK_SET);
	fprintf(stream,"%s",final);
	fclose(stream);
	//getch();
	delete final;


	delete env;
}