// RequestH.h


#ifndef __REQUESTHANDLER_H
#define __REQUESTHANDLER_H
#include <stdio.h>

class RequestHandler
{
	public:
	setObjectDeserialize();
	Envelope& buildSOAPObject();
	checkError();
	buildSOAPFault();
};
#endif