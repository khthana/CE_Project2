#include <stdio.h>
#include <string.h>
int main()
{
	FILE *stream;
	const char* west="Anytown\0";
	const char* in="NY\0";
	const char* sn="Main Street\0";
	const char* ex="456\0";
	const char* nu="7890\0";
	char city[20],state[20],streetName[20],exchange[20],number[20];
	int streetNum=123,zip=12345,areacod=123;
	strcpy(city,west);
	strcpy(state,in);
	strcpy(streetName,sn);
	strcpy(exchange,ex);
	strcpy(number,nu);
	stream = fopen("out1.txt","w+");
	fseek(stream,0,SEEK_SET);
	fprintf(stream,"%s\n",city);

	fprintf(stream,"%d\n",areacod);
	fprintf(stream,"%s\n",exchange);
	fprintf(stream,"%s\n",number);

	fprintf(stream,"%s\n",state);
	fprintf(stream,"%s\n",streetName);
	fprintf(stream,"%d\n",streetNum);
	fprintf(stream,"%d",zip);
	fclose(stream);
	//printf("exit from getAdd.exe\n");
	return 0;
}