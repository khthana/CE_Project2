#include <stdio.h>
#include <conio.h>

class test
{
	public : 
		char* value;
		const char* Value()	const			{ return value; }

};
int main()//(int argc, char *argv[])
{
	printf("Hello, world\n");
	test t1;
	char* v="test";
        t1.value= v;
	printf("value is %s\n",t1.Value());
	getch();
	return 0;

}
