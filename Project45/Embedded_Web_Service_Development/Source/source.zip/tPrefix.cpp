#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include "Prefix.h"
int main()
{
	clrscr();
	PrefixMap p1;
	int i;
	char *pf="prefix";
	char *ns="namesp";
	char s1[30],s2[30],s[20];
	for (int j=0;j<21;j++)
	{
		strcpy(s1,pf);
		strcpy(s2,ns);
		itoa(j,s,10);
		strcat(s1,s);
		strcat(s2,s);
		if(p1.add(s2,s1))
		{
			strcpy(s2,p1.getPrefix(s2));
			cout<<"Prefix: "<<s2<<endl;
			strcpy(s1,p1.getNamespace(s1));
			cout<<"NameSp: "<<s1<<endl;
		}
		else
			cout<<"Bufferoverflow\n";
	}
	cout<<"index want to remove";
	cin>>i;
	int hi=p1.getSize();
	strcpy(s1,pf);
	strcpy(s2,ns);
	itoa(i,s,10);
	strcat(s1,s);
	strcat(s2,s);
	if (p1.remove(s2,s1))
		printf("remove complete %s & %s \n",s2,s1);
	else
		printf("can't remove %s & %s \n",s2,s1);
	char h[10];
	cout<<"press to show";cin>>h;
	hi=p1.getSize();
	for (int k=0;k<hi;k++)
	{
		strcpy(s2,p1.getprefixMap(k));
		cout<<"Prefix: "<<s2<<endl;
		strcpy(s1,p1.getnsMap(k));
		cout<<"NameSp: "<<s1<<endl;
		if (k==8)
		{
			cout<<"First show";
			cin>>h;
		}
	}
	cout<<h;
	strcpy(s1,pf);
	strcpy(s2,ns);
	itoa(i,s,10);
	strcat(s1,s);
	strcat(s2,s);
	PrefixMap p2(p1,s1,s2);
	hi=p2.getSize();
	for (k=0;k<hi;k++)
	{
		strcpy(s2,p2.getprefixMap(k));
		cout<<"Prefix: "<<s2<<endl;
		strcpy(s1,p2.getnsMap(k));
		cout<<"NameSp: "<<s1<<endl;
		if (k==8)
		{
			cout<<"Second Show";
			cin>>h;
		}
	}
	PrefixMap p3;
	p3=p2;
	hi=p3.getSize();
	for (k=0;k<hi;k++)
	{
		strcpy(s2,p3.getprefixMap(k));
		cout<<"Prefix: "<<s2<<endl;
		strcpy(s1,p3.getnsMap(k));
		cout<<"NameSp: "<<s1<<endl;
		if (k==8)
		{
			cout<<"Third Show";
			cin>>h;
		}
	}
	return 0;
}
