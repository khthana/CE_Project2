// temporary.cpp

char* AttributeHandler::getValue(const char* attrName) const	{
		char *temp;int j,k;
		char *temp2;
		for (int i=0; i<4;i++ )
		{
			temp=new char[attributes[i].getSize()+1];
			strcpy(temp,attributes[i].getStr());
			strcat(temp,NULL);
			j=0;
			while (temp[j]!='=' && temp[j]!='\0')
				++j;
			if (strncmp(attrName,temp,j)==0)
			{
				j++;
				if (temp[j]=='"')
				{
					temp2=new char[strlen(temp)-j+3];
					k=0;
					j++;
					while (temp[j]!='"')
					{
						temp2[k++]=temp[j++];
					}
					temp2[k]='\0';
					delete temp;
					return temp2;
				}
			}
			delete temp;
		}
		return NULL;
	}