#include <stdio.h>
#include <conio.h>
#include "SoapDes.h"
int main()
{
	printf("Hello, world\n");
	clrscr();
	SOAPDeserialize d;
	char *m="getAddressFromName\0";
	d.setServiceMethod(m);
	char *f="sd1.txt\0";
	d.readServiceMap(f);
	char* soap=d.serialOutput();
	printf("hello\n%s",soap);
	return 0;
}
