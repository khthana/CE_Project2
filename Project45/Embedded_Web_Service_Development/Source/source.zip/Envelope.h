// SOAP_Envelope.h

#ifndef __ENVELOPE_H
#define __ENVELOPE_H
#include "Const.h"
#include "Str.h"
#include "Header.h"
#include "Body.h"
#include "AttrHand.h"
#include "Qname.h"
#include "Parser.h"
#include "ParseE.h"

class Envelope
{
	private:
	Header header;
	Body   body;
	Str envelopeEntries;
	AttributeHandler attrHandler;
	Str error;
	public:
	Envelope()	{ }

	Envelope(const Body b,const char* envEntries) {
		body=b;
		envelopeEntries=envEntries;	}
	
	Envelope(const Header h,const Body b,const char* envEntries) {
		header=h;
		body=b;
		envelopeEntries=envEntries;	}

	Envelope(const Header h,const Body b,const char* envEntries,const AttributeHandler attr) {
		header=h;
		body=b;
		envelopeEntries=envEntries;
		attrHandler=attr;	}

	Envelope& operator=(const Envelope& value)	{
		header=value.getHeader();
		body=value.getBody();
		envelopeEntries=value.getEnvelopeEntries();
		attrHandler=value.getAttributeHandler();
		error=value.getError();
		return *this;	}
	
	void setAttribute(const char* attrQName, int value) {
		attrHandler.setAttribute(attrQName, value); }

	const char* getAttribute(QName attrQName)	const {
		return attrHandler.getAttribute(attrQName);	}

	const AttributeHandler getAttributeHandler() const	{
		return attrHandler;	}
	
	char* getAttribute() const 	{
		return attrHandler.getAttribute();	}

	void setHeader(Header h)	{
		header=h;	}

	const Header getHeader() const	{
		return header;	}

	void setBody(Body b) 	{
		body=b;	}

	const Body getBody() const 	{
		return body;	}
	
	void setEnvelopeEntries(const char* envEntries)
	{	envelopeEntries=envEntries;	}

	const char* getEnvelopeEntries() const
	{	return envelopeEntries.getStr();	}

	const char* getError() const
	{	return error.getStr();	}

	void setError(const char* e)	{
		error=e;	}

	int getLength()	const {
		return body.getLength()+header.getLength()+envelopeEntries.getSize()+attrHandler.getLength(); }

	char* marshall();

	static Envelope* unmarshall(Parser *pr,ParseEvent *pe);
};
#endif