#include<fstream.h>
#include<string.h>
#include<conio.h>
#include<stdlib.h>
#include<stdio.h>
#include<iostream.h>
#include"Parser.h"
#include"ParseE.h"
