#include <iostream.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include "Header.h"
int main()
{
	clrscr();
	const char* attr="<t:Transaction xmlns:t=\"some-URI\" SOAP-ENV:mustUnderstand=\"1\">5</t:Transaction>";
	Header h1,h2(attr);
	char *hit;
	hit=h1.getAttribute()
	cout<<"h1.getAttribute()    ="<<hit<<endl;
	delete hit;
	cout<<"h1.getHeaderEntries()="<<h1.getHeaderEntries()<<endl;
	hit=h1.marshall();
	cout<<"h1.marshall()        ="<<hit<<endl;
	delete hit;

	hit=h2.getAttribute();
	cout<<"h2.getAttribute()    ="<<hit<<endl;
	delete hit;
	cout<<"h2.getHeaderEntries()="<<h2.getHeaderEntries()<<endl;
	hit=h2.marshall();
	cout<<"h2.marshall()        ="<<hit<<endl;
	delete hit;

	Header *h3;
	h3=Header::unmarshall(h2.getHeaderEntries(),h2.getAttributeHandler());
	Header h4;
	h4=*h3;
	delete h3;

	hit=h4.getAttribute();
	cout<<"h4.getAttribute()    ="<<hit<<endl;
	delete hit;
	cout<<"h4.getHeaderEntries()="<<h4.getHeaderEntries()<<endl;
	hit=h4.marshall();
	cout<<"h4.marshall()        ="<<hit<<endl;
	delete hit;

	return 0;
}