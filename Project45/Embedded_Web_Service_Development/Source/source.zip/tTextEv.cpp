#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include "TextE.h"
#include "ParseE.h"

int main()
{	
	char st[300];
	clrscr();
	char *s="hit";
	TextEvent p(s);
	ParseEvent *ps;
	int i;
	i=p.getType();
	cout<<"p.getType()  =	"<<i<<endl;
	//i=p.endCheck(ps);
	cout<<"p.endCheck(s)=	"<<i<<endl;
	strcpy(st,p.getText());
	cout<<"p.getText()=		"<<st<<endl;
	i=p.getLineNumber();
	cout<<"p.getLineNumber()"<<i<<endl;
	p.setLineNumber(10);
	i=p.getLineNumber();
	cout<<"p.getLineNumber()"<<i<<endl;
	cout<<"p.getError()     "<<p.getError()<<endl;
	p.setError(s);
	cout<<"p.getError()     "<<p.getError()<<endl;
	char *s1="pop";
	p.setText(s1);
	cout<<"p.getText()      "<<p.getText()<<endl;
	return 0;
}