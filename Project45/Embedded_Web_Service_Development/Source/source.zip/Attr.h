// package embeddedXML
// file name : Attr.h
#ifndef __ATTR_H
#define __ATTR_H
#include "Str.h"
#include "Xml.h"
class Attribute
{
	private:
	Str prefix;
	Str name;
	Str value;
	//local variable but have to protect value so declare in global variable

	public:
	//Constructor
	Attribute ()								{ }
    Attribute (const char *n,const char *v);
	Attribute (const char *ns,const char *n,const char *v);
	Attribute (const char *string);
	~Attribute()	{ }
	//function
	const char* getValue () const		
		{ return value.getStr(); }

    const char* getName () const		
		{ return name.getStr(); }

    const char* getNamespace () const	
		{ return prefix.getStr(); }

    char* toString();
	char* toPrefix_Name();
	//char* reCreate();
};
#endif*/