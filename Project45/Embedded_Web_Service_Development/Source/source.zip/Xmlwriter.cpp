// package de.embeddedXML.io
// import import de.kxml.*;
// file name: Xmlwriter.cpp

#ifndef _STRING_H
#define _STRING_H
#include <string.h>
#endif
#ifndef _XMLWRITER_H
#define _XMLWRITER_H
#include "Xmlwriter.h"
#endif

XMLWriter::XMLWriter(char *w)
{
	strcpy(writer,w);
	pending=0;
	indentLevel=0;
	noIndent=32,767;
}

void XMLWriter::checkPending () // throws IOException protected 
{
	if (pending==1)
	{
		char *s;
		s=">";
		strncat(writer,s,1);
		pending=0;
	}
}
void XMLWriter::write (char c) // throws IOException
{
	checkPending();
	if (noIndent>indentLevel)
		noIndent=indentLevel;
	switch (c) {
	case '<': strcat(writer,LT); break;
	case '>': strcat(writer,GT); break;
	case '&': strcat(writer,AMP); break;   
	default: char*s; s=&c; strncat(writer,s,1); 
	}
}
void XMLWriter::write (char* buf, int start, int len) // throws IOException
{
	checkPending();
	if (noIndent>indentLevel)
		noIndent=indentLevel;
	int end=start+len;
	char *ptr;
	char *s;
	s="<>&";
	do
	{
		int i=start;
		while (i<end)
		{
			ptr=strchr(s,buf[i]);
			if (strcmp(ptr,NULL)==0)
				++i;
			else
				break;
		}
		for (int j=start;j<=i-start ;i++ )
		{
			s=&buf[j];
			strncat(temp,s,1);
		}
		if (i==end)
			break;
		write(buf);
		start=i+1;
	}
	while (start<end);
}
void XMLWriter::writeIndent () // throws IOException
{
	int l=indentLevel+2;
	char *s;
	if (l < 2)
		l=2;
	else if (l > strlen(indent))
		l=strlen(indent);
	checkPending();
	//	writer.write ("<!-- i -->");
	for (int i=0;i<=l ;++i )
	{
		s=&indent[j];
		strncat(temp,s,1);
	}
}

void XMLWriter::writeAttribute (char* ns, char* n, char* v)				 // throws IOException
{
	if (strcmp(ns,NULL)==0 || strcmp(ns,NO_NAMESPACE)==0)
	{
		writeAttribute(n,v);
	}
	else 
	{
		char* prefix;
		char*s;
		strcpy(prefix,prefixMap.getPrefix(ns));
		if (strcmp(prefix,NULL)==0 || strcmp(prefix,NO_NAMESPACE)==0)
		{
			int cnt=0;
			do
			{
				cnt++;		
			}
			while (prefixMap.getNamespace (prefix) != NULL);
			s="xmlns:";
			strcpy(prefix,s);
			strcat(prefix,NSPREFIX);
			c=(char)cnt;
			s=&c;
			strncat(prefix,s,1);
			prefixMap.addNamespace(ns);
			writeAttribute(prefix,ns);
		}
		s=":";
		strncat(prefix,s,1);
		strncat(prefix,n);
		writeAttribute(prefix,value);
	}
}

void XMLWriter::writeAttribute (char* n,char* v) // throws IOException
{
	if (pending==0)
	{
		//throw new RuntimeException("can write attr only immediately after a startTag");
	}
	char *s;
	s=" ";
	strncat(temp,s,1);
	strcat(temp,n);
	s="=\"";
	strncat(temp,s,2);
	strcat(Xml.encode(value,Xml.ENCODE_QUOT));
	s="\"";
	strncat(temp,s,1);
}
void XMLWriter::writeStartTag (PrefixMap pfM,char* ns, char* n) // throws IOException
	{
		// check if namespace is default. 
		if (strcmp(ns,NULL)==0)
			strcpy(ns,NO_NAMESPACE);
		char* prefix;
		strcpy(prefix,pfM.getPrefix(ns);
		if (strcmp(prefix,NULL)==0)
		{
			pfM.add(NO_NAMESPACE,ns);
			strcpy(prefix,NO_NAMESPACE);
		}
		char* tag;
		if (strlen(prefix)==0)
		{
			strcpy(tag,n);
		}else{
			strcpy(tag,prefix);
			char*s;s=":";
			strncat(tag,s,1);
			strcat(tag,n);
		}
		// PrefixMap oldMap = current.prefixMap;		
		writeStartTag(prefixMap,tag);

		// if namespace has changed, write out changes...
		// wait for second

	}
void XMLWriter::writeStartTag (char* ns, char* n)    // throws IOException
{
	writeStartTag(NULL,ns,n);
}
void XMLWriter::writeStartTag (PrefixMap prefixMap, char* t) // throws IOException  protected
	{
		current=new State(current, preifxMap, t);
		checkPending();
		if (indentLevel < noIndent) 
	    writeIndent ();
		indentLevel++;
		char *s;
		s="<";
		strncat(temp,s,1);
		strcat(temp,t);
		pending=1;
    }
void XMLWriter::writeEndTag () // throws IOException
	{
		indentLevel--;
		char *s;
		if (pending==1) 
		{
			s=" />";
			strncat(temp,s,3);
			pending=0;
		}
		else {
			if (indentLevel + 1 < noIndent) 
				writeIndent ();
			s="</";
			strncat(temp,s,2);
			strcat(current.tag);
			s=">";
			strncat(temp,s,1);
		}
		if (indentLevel + 1 == noIndent) 
			noIndent = 32676;

		current = current.prev;
    }
void XMLWriter::writeLegacy (int type, char* content) // throws IOException
	{
		checkPending ();
		char *s;
		switch (type) {
		case Xml.COMMENT: 
			s="<!--";
			strncat(temp,s,4);
			strcat(temp,content);
			s="-->";
			strncat(temp,s,3);
			break;
		case Xml.DOCTYPE:
			s="<!DOCTYPE";
			strncat(temp,s,9);
			strcat(content);
			s=">";
			strncat(temp,s,1);
			break;
		case Xml.PROCESSING_INSTRUCTION:
			s="<?";
			strncat(temp,s,2);
			strcat(content);
			s="?>";
			strncat(temp,s,2);
			break;
		}
    }
void XMLWriter::writeRaw (char* s) // throws IOException
	{
		checkPending ();
		strcat(s);
	}