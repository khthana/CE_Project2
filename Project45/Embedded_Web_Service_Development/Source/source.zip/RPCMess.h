// RPCMess.h

#ifndef __RPCMESSAGE_H
#define __RPCMESSAGE_H

#include "Str.h"
#include "Constants.h"
#include "Header.h"

//#include "SOAPCont.h" may be include
class RPCMessage
{
	protected:
	Str targetObjectURI;
	Str fullTargetObjectURI;
	Str methodName;
	Parameter params;
	//Str params;//Vector
	Header header;
	Str encodingStyleURI;
	Str exception;
	//SOAPContext ctx;

	RPCMessage()	{}
	RPCMessage(const char* objectURI, const char* mName,
                       const Parameter& p,const Header& h,
                       const char* encStyleURI/*, SOAPContext ctx*/) {
    setTargetObjectURI(objectURI);
    methodName       = mName;
    params           = p;
    header           = h;
    encodingStyleURI = encStyleURI;
    //ctx              = ctx;
	}

	public:
	void setTargetObjectURI(const char* objectURI);

	const char* getTargetObjectURI() {
		return targetObjectURI.getStr();	}

	void setFullTargetObjectURI(const char* objectURI) {
		setTargetObjectURI(objectURI);	}

	const char* getFullTargetObjectURI() {
		return fullTargetObjectURI.getStr();	}

	void setMethodName(const char* mName) {
		methodName = mName;	}

	const char* getMethodName() {
		return methodName.getStr();	}

	void setParams(const Parameter& p) {
		params = p;
	}

	const Parameter& getParams() {
		return params;	}

	void setHeader(const Header h) {
		header=h;	}

	const Header& getHeader() {
		return header;	}

	void setEncodingStyleURI(const char* enStyleURI) {
		encodingStyleURI = enStyleURI;	}

	const char* getEncodingStyleURI() {
		return encodingStyleURI.getStr();	}

	void setException(const char* ex) {
		exception=ex;	}

	const char* getException() {
		return exception.getStr();	}

	virtual int getType() const=0;

	/*protected void setSOAPContext(SOAPContext ctx) {
		ctx = ctx;	}

	SOAPContext getSOAPContext() {
		return ctx;	}*/

	protected:
	/*Envelope* buildEnvelope(int isResponse) {  //protected
		// Construct a new envelope for this message.
		Envelope* env = new Envelope();
		Body body;
		// must set bodyEntries
		Str bodyEntries = isResponse ? Response.class : Call.class
		//bodyEntries.addElement(new Bean((isResponse ? Response.class : Call.class),this));

		body.setBodyEntries(bodyEntries);
		env.setBody(body);
		env.setHeader(header);
		return env;	}*/
	static RPCMessage* extractFromEnvelope(const Envelope& env, const ServiceManager& svcMgr, int isResponse)	{
		Body body;
		body = env.getBody();
		Str bodyEntries=body.getBodyEntries();
		RPCMessage* msg;
		// Unmarshall the message, which is the first body entry.
		if (bodyEntries.getSize() > 0) {
			// must improve//
			Class toClass = isResponse ? Response.class : Call.class;
			Str declEnvEncStyle = env.getAttribute(new QName(
			Constants.NS_URI_SOAP_ENV, Constants.ATTR_ENCODING_STYLE));
			Str declBodyEncStyle = body.getAttribute(new QName(
			Constants.NS_URI_SOAP_ENV, Constants.ATTR_ENCODING_STYLE));
			Str actualEncStyle;
			actualEncStyle = declBodyEncStyle != NULL ? declBodyEncStyle : declEnvEncStyle;
			msg = RPCMessage::unmarshall(actualEncStyle, msgEl, toClass, svcMgr, respSMR)//, ctx);
			msg.setHeader(env.getHeader());
			return msg;
		} else {
			char *temp;
			temp=Exception::noChildinBody();
			msg->setException(temp);
			delete temp;
		}
	}
	
};

#endif

  void marshall(String inScopeEncStyle, Class javaType, Object src,
                       Object context, Writer sink, NSStack nsStack,
                       XMLJavaMappingRegistry xjmr, SOAPContext ctx)
    throws IllegalArgumentException, IOException {
    nsStack.pushScope();

    RPCMessage msg               = (RPCMessage)src;
    boolean    isResponse        = (javaType == Response.class);
    String     targetObjectURI   = Utils.cleanString(
                                       msg.getFullTargetObjectURI());
    String     methodName        = msg.getMethodName();
    Vector     params            = msg.getParams();
    String     suffix            = isResponse
                                   ? RPCConstants.RESPONSE_SUFFIX
                                   : "";
    String     declMsgEncStyle   = msg.getEncodingStyleURI();
    String     actualMsgEncStyle = declMsgEncStyle != null
                                   ? declMsgEncStyle
                                   : inScopeEncStyle;

    // If this message is a response, check for a fault.
    if (isResponse) {
      Response resp = (Response)msg;

      if (!resp.generatedFault()) {
        // Get the prefix for the targetObjectURI.
        StringWriter nsDeclSW = new StringWriter();
        String targetObjectNSPrefix = nsStack.getPrefixFromURI(
          targetObjectURI, nsDeclSW);

        sink.write('<' + targetObjectNSPrefix + ':' +
                   methodName + suffix + nsDeclSW);

        // Determine the prefix associated with the NS_URI_SOAP_ENV
        // namespace URI.
        String soapEnvNSPrefix = nsStack.getPrefixFromURI(
          Constants.NS_URI_SOAP_ENV, sink);

        if (declMsgEncStyle != null
            && !declMsgEncStyle.equals(inScopeEncStyle)) {
          sink.write(' ' + soapEnvNSPrefix + ':' +
                     Constants.ATTR_ENCODING_STYLE + "=\"" +
                     declMsgEncStyle + '\"');
        }

        sink.write('>' + StringUtils.lineSeparator);

        // Get the returnValue.
        Parameter ret = resp.getReturnValue();

        if (ret != null) {
          String declParamEncStyle = ret.getEncodingStyleURI();
          String actualParamEncStyle = declParamEncStyle != null
                                       ? declParamEncStyle
                                       : actualMsgEncStyle;
          Serializer ser = xjmr.querySerializer(Parameter.class,
                                                actualParamEncStyle);

          ser.marshall(actualMsgEncStyle, Parameter.class, ret, null,
                       sink, nsStack, xjmr, ctx);

          sink.write(StringUtils.lineSeparator);
        }

        serializeParams(params, actualMsgEncStyle, sink, nsStack, xjmr, ctx);

        sink.write("</" + targetObjectNSPrefix + ':' +
                   methodName + suffix + '>' +
                   StringUtils.lineSeparator);
      } else {
        // Get the fault information.
        Fault fault = resp.getFault();

        fault.marshall(actualMsgEncStyle, sink, nsStack, xjmr, ctx);
      }
    } else {
      // Get the prefix for the targetObjectURI.
      StringWriter nsDeclSW = new StringWriter();
      String targetObjectNSPrefix = nsStack.getPrefixFromURI(targetObjectURI,
                                                             nsDeclSW);

      sink.write('<' + targetObjectNSPrefix + ':' +
                 methodName + suffix + nsDeclSW);

      // Determine the prefix associated with the NS_URI_SOAP_ENV
      // namespace URI.
      String soapEnvNSPrefix = nsStack.getPrefixFromURI(
        Constants.NS_URI_SOAP_ENV, sink);

      if (declMsgEncStyle != null
          && !declMsgEncStyle.equals(inScopeEncStyle)) {
        sink.write(' ' + soapEnvNSPrefix + ':' +
                   Constants.ATTR_ENCODING_STYLE + "=\"" +
                   declMsgEncStyle + '\"');
      }

      sink.write('>' + StringUtils.lineSeparator);

      serializeParams(params, actualMsgEncStyle, sink, nsStack, xjmr, ctx);

      sink.write("</" + targetObjectNSPrefix + ':' +
                 methodName + suffix + '>');
    }

    nsStack.popScope();
  }

  private void serializeParams(Vector params, String inScopeEncStyle,
                               Writer sink, NSStack nsStack,
                               XMLJavaMappingRegistry xjmr, SOAPContext ctx)
    throws IOException {
    // If parameters exist, serialize them.
    if (params != null) {
      int size = params.size();

      for (int i = 0; i < size; i++) {
        Parameter param = (Parameter)params.elementAt(i);
        String declParamEncStyle = param.getEncodingStyleURI();
        String actualParamEncStyle = declParamEncStyle != null
                                     ? declParamEncStyle
                                     : inScopeEncStyle;
        Serializer ser = xjmr.querySerializer(Parameter.class,
                                              actualParamEncStyle);

        ser.marshall(inScopeEncStyle, Parameter.class, param, null, sink,
                     nsStack, xjmr, ctx);

        sink.write(StringUtils.lineSeparator);
      }
    }
  }

  static RPCMessage unmarshall(String inScopeEncStyle, Node src,
                                      Class toClass, ServiceManager svcMgr,
                                      SOAPMappingRegistry respSMR,
                                      SOAPContext ctx)
    throws IllegalArgumentException {
    SOAPMappingRegistry smr       = null;
    Element   root                = (Element)src;
    boolean   isResponse          = (toClass == Response.class);
    String    fullTargetObjectURI = null;
    String    targetObjectURI     = null;
    String    methodName          = null;
    Parameter returnValue         = null;
    Fault     fault               = null;
    Vector    params              = null;
    String    declMsgEncStyle     = DOMUtils.getAttributeNS(root,
      Constants.NS_URI_SOAP_ENV, Constants.ATTR_ENCODING_STYLE);
    String    actualMsgEncStyle   = declMsgEncStyle != null
                                    ? declMsgEncStyle
                                    : inScopeEncStyle;

    // Is it a fault?
    if (isResponse && Constants.Q_ELEM_FAULT.matches(root)) {
      fault = Fault.unmarshall(actualMsgEncStyle, root, respSMR, ctx);
    } else {
      // Must be a method call or a faultless response.
      String tagName = root.getLocalName();

      // This is the 'full' URI.
      fullTargetObjectURI = root.getNamespaceURI();
      targetObjectURI = StringUtils.parseFullTargetObjectURI(
                            fullTargetObjectURI);

      // Determine the XML serialization registry based on whether
      // I'm on the server side or on the client side.
      if (!isResponse) {
        // I'm on the server side unmarshalling a call.
        DeploymentDescriptor dd = null;
        try {
          dd = svcMgr.query(targetObjectURI);
          smr = DeploymentDescriptor.buildSOAPMappingRegistry(dd, ctx);
        } catch (SOAPException e) {
          throw new IllegalArgumentException("Unable to resolve " +
                                             "targetObjectURI '" +
                                             targetObjectURI + "'.");
        }
      } else {
        // I'm on the client unmarshalling a response.
        smr = respSMR;
      }
      
      // For RPC, default to SOAP section 5 encoding if no
      // encodingStyle attribute is set.
      smr.setDefaultEncodingStyle(Constants.NS_URI_SOAP_ENC);

      methodName = tagName;

      /*
        Sanity check: the name of the method element should be the
        methodName for a call and should be methodName+"Response"
        for a response. Note: currently no way to know the methodName
        other than from the tag name.
      */
      if (isResponse && methodName.endsWith(RPCConstants.RESPONSE_SUFFIX)) {
        // Strip "Response" from end of tagName to derive methodName.
        methodName = methodName.substring(0, methodName.length() - 8);
      }

      Element tempEl = DOMUtils.getFirstChildElement(root);

      // Get the return value.
      if (isResponse && tempEl != null) {
        String declParamEncStyle = DOMUtils.getAttributeNS(tempEl,
          Constants.NS_URI_SOAP_ENV, Constants.ATTR_ENCODING_STYLE);
        String actualParamEncStyle = declParamEncStyle != null
                                     ? declParamEncStyle
                                     : actualMsgEncStyle;
        Bean returnBean = smr.unmarshall(actualParamEncStyle,
                                         RPCConstants.Q_ELEM_PARAMETER,
                                         tempEl, ctx);

        returnValue = (Parameter)returnBean.value;

        if (declParamEncStyle != null)
        {
          returnValue.setEncodingStyleURI(declParamEncStyle);
        }

        tempEl = DOMUtils.getNextSiblingElement(tempEl);
      }

      // Get the parameters.
      if (tempEl != null) {
        for (params = new Vector();
             tempEl != null;
             tempEl = DOMUtils.getNextSiblingElement(tempEl)) {
          String declParamEncStyle = DOMUtils.getAttributeNS(tempEl,
            Constants.NS_URI_SOAP_ENV, Constants.ATTR_ENCODING_STYLE);
          String actualParamEncStyle = declParamEncStyle != null
                                       ? declParamEncStyle
                                       : actualMsgEncStyle;
          Bean paramBean = smr.unmarshall(actualParamEncStyle,
                                          RPCConstants.Q_ELEM_PARAMETER,
                                          tempEl, ctx);
          Parameter param = (Parameter)paramBean.value;

          if (declParamEncStyle != null) {
            param.setEncodingStyleURI(declParamEncStyle);
          }

          params.addElement(param);
        }
      }
    }

    RPCMessage msg = isResponse
                     ? (fault == null
                        ? (RPCMessage)new Response(fullTargetObjectURI, methodName,
                                                   returnValue, params, null,
                                                   declMsgEncStyle, ctx)
                        : (RPCMessage)new Response(fullTargetObjectURI, methodName,
                                                   fault, params, null,
                                                   declMsgEncStyle, ctx))
                     : (RPCMessage)new Call(fullTargetObjectURI, methodName,
                                            params, null, actualMsgEncStyle, ctx);

    if (msg instanceof Call) {
      ((Call)msg).setSOAPMappingRegistry(smr);
    }

    return msg;
  }
