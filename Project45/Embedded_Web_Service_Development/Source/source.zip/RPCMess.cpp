// RPCMess.cpp

#include "RPCMess.h"

void RPCMessage::setTargetObjectURI(const char* objectURI) {
    // Any incoming URI must be the full URI
    fullTargetObjectURI = objectURI;

    // Now, we should splice the URI into the actual resource to connect to,
    // and the key.
	char *temp;
	temp=new char[strlen(objectURI)+1];
	strcpy(temp,objectURI);
	strncat(temp,NULL,1);
	char c='@';
	char *ptr;
	ptr=strchr(temp,c);
	if (strcmp(ptr,NULL)==0)
		targetObjectURI=objectURI;
	else {
		char *t;
		int size=ptr-temp;
		t=new char[size+1];
		strncpy(t,temp,size);
		strncat(t,NULL,1);
		targetObjectURI=t;
		delete t;
	}
	delete temp;    
}
char* marshall(const char* inScopeEncStyle,RPCMessage* msg,)	{
	//RPCMessage *msg=new RPCMessage();
	int isResponse = msg->getType() ? 1 : 0;
	Str targetObjURI=Xml::encode(msg->getFullTargetObjectURI());
	Str mName=msg->getMehodName();
	Str params=msg->getParams();
	Str suffx=isResponse ? RPCConstants::RESPONSE_SUFFIX : NULL;
	Str declMsgEncStyle=msg->getEn();
	Str actualMsgEncStyle= declMsgEncStyle == NULL ? inScopeEncStyle : declMsgEncStyle;
		char *soap;
		// If this message is a response, check for a fault.
	if (isResponse)
	{
		if (!msg->generatedFault())
		{
			
			// must get prefix from targetObjectURI don't do now
			//Str targetObjNSPrefix=;
			soap=new char[300];
			/*
			strcpy(soap,Xml::LT_S);
			strcat(soap,RPCConstants::NS);
			strcat(soap,Xml::CL_S);
			strcat(soap,mName);
			strcat(soap,suffix);
			strcat(soap,nsDclSW*/

				





		}
	}
		if (isResponse) {
			Response resp = (Response)msg;

		if (!resp.generatedFault()) {
			// Get the prefix for the targetObjectURI.
			StringWriter nsDeclSW = new StringWriter();
			String targetObjectNSPrefix = nsStack.getPrefixFromURI(
			  targetObjectURI, nsDeclSW);

			sink.write('<' + targetObjectNSPrefix + ':' +
					   methodName + suffix + nsDeclSW);

			// Determine the prefix associated with the NS_URI_SOAP_ENV
			// namespace URI.
			String soapEnvNSPrefix = nsStack.getPrefixFromURI(
			  Constants.NS_URI_SOAP_ENV, sink);

			if (declMsgEncStyle != null
				&& !declMsgEncStyle.equals(inScopeEncStyle)) {
			  sink.write(' ' + soapEnvNSPrefix + ':' +
						 Constants.ATTR_ENCODING_STYLE + "=\"" +
						 declMsgEncStyle + '\"');
			}

			sink.write('>' + StringUtils.lineSeparator);

			// Get the returnValue.
			Parameter ret = resp.getReturnValue();

			if (ret != null) {
			  String declParamEncStyle = ret.getEncodingStyleURI();
			  String actualParamEncStyle = declParamEncStyle != null
										   ? declParamEncStyle
										   : actualMsgEncStyle;
			  Serializer ser = xjmr.querySerializer(Parameter.class,
													actualParamEncStyle);

			  ser.marshall(actualMsgEncStyle, Parameter.class, ret, null,
						   sink, nsStack, xjmr, ctx);

			  sink.write(StringUtils.lineSeparator);
			}

			serializeParams(params, actualMsgEncStyle, sink, nsStack, xjmr, ctx);

			sink.write("</" + targetObjectNSPrefix + ':' +
					   methodName + suffix + '>' +
					   StringUtils.lineSeparator);
		  } else {
			// Get the fault information.
			Fault fault = resp.getFault();

			fault.marshall(actualMsgEncStyle, sink, nsStack, xjmr, ctx);
		  }
		} else {
		  // Get the prefix for the targetObjectURI.
		  StringWriter nsDeclSW = new StringWriter();
		  String targetObjectNSPrefix = nsStack.getPrefixFromURI(targetObjectURI,
																 nsDeclSW);

		  sink.write('<' + targetObjectNSPrefix + ':' +
					 methodName + suffix + nsDeclSW);

		  // Determine the prefix associated with the NS_URI_SOAP_ENV
		  // namespace URI.
		  String soapEnvNSPrefix = nsStack.getPrefixFromURI(
			Constants.NS_URI_SOAP_ENV, sink);

		  if (declMsgEncStyle != null
			  && !declMsgEncStyle.equals(inScopeEncStyle)) {
			sink.write(' ' + soapEnvNSPrefix + ':' +
					   Constants.ATTR_ENCODING_STYLE + "=\"" +
					   declMsgEncStyle + '\"');
		  }

		  sink.write('>' + StringUtils.lineSeparator);

		  serializeParams(params, actualMsgEncStyle, sink, nsStack, xjmr, ctx);

		  sink.write("</" + targetObjectNSPrefix + ':' +
					 methodName + suffix + '>');
		}

		nsStack.popScope();
	  }