// package de.embeddedXML.io
// import import de.kxml.*;
// file name: Xmlwriter.h

class XMLWriter
{
	private:
	char writer[3000];
	int pending;  // 0=false 1=true
    int indentLevel;
    int noIndent;
    static char indent [26]
	= {'\r', '\n', 
	   ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	   ' ', ' ', ' ', ' ',  ' ', ' ', ' ', ' ',
	   ' ', ' ', ' ', ' ',  ' ', ' ', ' ', ' '};

	public:
	XMLWriter(char *w);
	//XmlWriter (Writer writer)
	~XMLWriter(){}
	void checkPending (); // throws IOException protected 
	/** closes the XmlWriter by closing the underlying writer */
	// void close () // throws IOException
	/** flushes the XmlWriter. Attention: If a closing
	angle braket is pending, it will be appended before
	flushing the underlying writer. Thus, after flush
	attributes cannot be added any longer */
	// void flush () // throws IOException
	/** writes a single character using the xml escaping rules */
	void write (char c); // throws IOException
	/** writes an character array using the XML escaping rules */
	void write (char* buf, int start, int len);// throws IOException
	void writeIndent (); // throws IOException
	/** writes an attribute with the given namespace. Only allowed
	immediately after writeStartTag or another writeAttribute
	call. */
	void writeAttribute (char* ns, char* n, char* v); // throws IOException
	/** writes a degenerated tag with the given name and attributes */
	void writeAttribute (char* n,char* v); // throws IOException
	void writeStartTag (PrefixMap pfM,char* ns, char* n); // throws IOException
	/** writes a start tag with the given namespace and name */
	void writeStartTag (char* ns, char* n);    // throws IOException

	/** convenience method for writeStartTag ("", name) */
	void writeStartTag (char* n);	// throws IOException

	/** @deprecated 
	Old method for writing a (possibly degenerated)
        tag including the given attributes. Please use subsequent
	calls of the other methods instead! */	
	// wait for think void writeStartTag (char* n, char* attrs, int degenerated/*boolean*/)  //throws IOException
	/*{
		writeStartTag(n);
		for (int i=0;i<attrsattrs.length; i+=2)  
			writeAttribute (attrs [i], attrs [i+1]);
		if (degenerated==1)
			writeEndTag();
	}*/
	/** writes a start tag with the given name */
	void writeStartTag (PrefixMap prefixMap, char* t); // throws IOException  protected

	/** writes an end tag. */
	void writeEndTag (); // throws IOException    
	/** ATTENTION: Application needs to take care about not writing
        illegal character sequences (like comment end in comments) */
	void writeLegacy (int type, char* content); // throws IOException
	
	/** writes a string without escaping. Use with care! Not
	available in wbxml writer */
	void writeRaw (char* s); // throws IOException
};
