/*#include <iostream.h>
#include "hash.h"
#include<bag.h>
#define hashClass __firstUserClass
void HASH::printOn(ostream& outputStream) const
{
	outputStream<<"(Name="<<name;
	outputStream<<", Order="<<order<<")";
}*/
#ifndef _STRING_H
#define _STRING_H
#include <string.h>
#endif
#include <iostream.h>
#include<hashtbl.h>//bag.h>
#include<conio.h>
#define hashClass __firstUserClass
class HASH :public Object
{
	private:
		char *name;
		int order;
	public:
	HASH()
	{
		name=new char;
		name[0]='\0';
		order=0;
	}
	HASH(const char* str,const int a) 
	{
		name= new char[strlen(str)+1];
		strcpy(name,str);
		order=a;
	}
	HASH(const HASH& source)
	{
		name=new char[strlen(source.name)+1];
		strcpy(name,source.name);
		order=source.order;
	}
	~HASH()
	{
		delete name;
	}
	classType isA() const
	{
		return hashClass;
	}
	char* nameOf() const
	{
		return "HASH";
	}
	void printOn(ostream& outputStream) const
	{
		outputStream<<"(Name="<<name;
		outputStream<<", Order="<<order<<")";
	}

	hashValueType hashValue() const
	{                                                                                                                                                  
		hashValueType hvalue=name[0]+order;
		return hvalue;
	}
	int isEqual(const Object& testHASH) const
	{
		return order==((HASH&)testHASH).order&&!strcmp(name,((HASH & )testHASH).name);
	}
};
