// package embeddedXML.parser
// import de.kxml.*; import de.kxml.io.*;
// file name: TextE.h

/** A class for events indicating character data like 
    "normal" text or ignorable whitespace. */
#ifndef __TEXTEVENT_H
#define __TEXTEVENT_H
#include <string.h>
#include "ParseE.h"
#include "Str.h"
class TextEvent : public ParseEvent 
{
	// Attribute
	private:
    Str text;
    Str error;
	public:
	// Constructor
	TextEvent()						{ }
    TextEvent (const char* t)		{ text.set(t); }
	TextEvent& operator= (TextEvent& value)
	{
		text.set(value.getText());
		error.set(value.getError());
		return *this;
	}
	//Destructor
	~TextEvent()					{ }
    //Funtion
    const char* getText() const		{ return text.getStr(); }
	void setText(const char*t)		{ text.set(t); }
    /** returns Xml.TEXT_EVENT */
    int getType() const				{ return 't'; }

	//pure function
	char* getAttribute() const { return NULL; }
	const char* getName() const { return NULL; }
	const char* getNamespace () const { return NULL; }
	char* getValue (const char* attrname) const { return NULL; }
	int getCountAttr() const { return 0; }
	const char* getAttribute (int index) const { return NULL; }
	//const char* getText () const { return NULL; }

    int endCheck (ParseEvent* start); // 0=false 1=true
	void setError (const char* e)	{ error.set(e); }
	const char* getError () const	{ return error.getStr(); }
    char* toString ()	{ 
		char *temp;
		temp=new char[text.getSize()+1];
		strcpy(temp,text.getStr());
		strncat(temp,NULL,1);
		return temp;  }
};
#endif