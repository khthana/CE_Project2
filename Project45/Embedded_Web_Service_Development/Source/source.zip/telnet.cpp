//#include <tcp.h>
#include <stdio.h>
#include <stdlib.h>
#ifdef __cplusplus
extern "C" {
#endif
#include <tcp.h>
#ifdef __cplusplus
}
#endif
#define TELNET_PORT 23
static tcp_Socket *s;
char *userid;
int port;

void telnets(int port)
{
	tcp_Socket telnetsock;
	char buffer[ 512 ];
	int status;
	int len;
	s = &telnetsock;
	tcp_listen( s, port, 0L, 0, NULL, 0);
	sock_wait_established(s, 0, NULL, &status);
	puts("Receiving incomming connection");
	sock_mode( s, TCP_MODE_ASCII );
	sock_puts( s, "Welcome to a sample telnet server.");
	sock_puts( s, "Each line you type will be printed on this screen once you hit return.");
	/* other guy closes connection except if we timeout .... */
	while ( 1 ) {
	sock_wait_input( s , 0, NULL, &status);
	sock_gets( s, buffer, 512 );
	puts( buffer );
	sock_puts(s, buffer);
	}
	sock_err:
	switch (status) {
		case 1 : /* foreign host closed */
				puts("User closed session");
				return;
		case -1: /* timeout */
				printf("\n\rConnection timed out!");
				return;
	}
}
void main()
{
	sock_init();
	telnets( TELNET_PORT);
	exit( 0 );
	return;
}