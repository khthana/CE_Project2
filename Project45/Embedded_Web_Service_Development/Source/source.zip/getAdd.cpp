#include <stdio.h>
#include <string.h>

void main(int argc, char *argv[])
{
	FILE *stream;
	const char* west="West Lafayette";
	const char* in="IN";
	const char* sn="University Drive";
	char city[20],state[20],streetName[20];
	int streetNum=1,zip=4907;
	strcpy(city,west);
	strcpy(state,in);
	strcpy(streetName,sn);
	stream = fopen("out1.txt","w+");
	fseek(stream,0,SEEK_SET);
	fprintf(stream,"%s\n",city);
	fprintf(stream,"%s\n",state);
	fprintf(stream,"%s\n",streetName);
	fprintf(stream,"%d\n",streetNum);
	fprintf(stream,"%d",zip);
	fclose(stream);
	printf("exit from getAdd.exe\n");
	return ;
}	