// AttrHandler.h

#ifndef __ATTRIBUTEHANDLER_H
#define __ATTRIBUTEHANDLER_H
#include "Xml.h"
#include "Attr.h"
#include "Str.h"
#include "QName.h"
class AttributeHandler
{
	private:
	Str attributes[4];
	int size;

	public:
	//Constructor
	AttributeHandler()	{ size=0;	}

	AttributeHandler(const char* attr,int s)
	{	setAttribute(attr,s);	}

	~AttributeHandler(){}

	AttributeHandler& operator=(const AttributeHandler& that);
	
	//Function
	void setAttribute(const char* a,int sizeA);

	int getSize() const
	{	return size;	}

	char* getAttribute() const;

	const char* getAttribute(QName attrQName) const;
	char* getValue(const char* attrName) const	{
		char *temp,*t;
		Attribute *a;
		for (int i=0; i<4;i++ )
		{
			a=new Attribute(attributes[0].getStr());
			t=new char[strlen(a->getNamespace())+strlen(a->getName())+2];
			strcpy(t,NULL);
			if (strcmp(a->getNamespace(),NULL)!=0)
			{
				strcat(t,a->getNamespace());
				strcat(t,Xml::CL_S);
			}
			strcat(t,a->getName());
			strncat(t,NULL,1);
			if (strcmp(attrName,t)==0)
			{
				delete t;
				temp=new char[strlen(a->getValue())+1];
				strcpy(temp,a->getValue());
				delete a;
				strncat(temp,NULL,1);
				return temp;
			}
			delete a;
			delete t;
		}
		return NULL;
	}
	const char* getAttribute(int index) const
	{	return attributes[index].getStr();	}

	int getLength() const
	{	return attributes[0].getSize()+attributes[1].getSize()+attributes[2].getSize()+attributes[3].getSize(); }

	QName* attrToQName(int index) const;
	
	//May be Add soon
	//function that save namespaceURI & prefix into NSStack coming soon======
	//populateNSStack

	char* marshall();

	static AttributeHandler* unmarshall(const char* src,int s);	
};
#endif