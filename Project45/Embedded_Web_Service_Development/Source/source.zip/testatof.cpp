#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <iostream.h>
#include <math.h>
void main ()
{
	clrscr();
	printf("Hello, world\n");
	char t1[30];
	char t2[30];
	int a=6,b=5;
	for (int j=0;j<30 ;j++ )
	{
		t1[j]=0;
		t2[j]=0;
	}
	double tf1,tf2;
	t1[0]='1';
	t1[1]='1';
	t1[2]='.';
	t1[3]='1';
	t1[4]='1';
	t2[0]='1';
	t2[1]='0';
	t2[2]='.';
	t2[3]='1';
	t2[4]='1';

	tf1=atof(t1);
	tf2=atof(t2);
	tf1=(double)a;
	tf2=(double)b;
	printf("string1 = %s float1 = ",t1);
	cout<<tf1<<endl;
	printf("string2 = %s float2 = ",t2);
	cout<<tf2<<endl;
	tf2+=tf1;
	printf("valuae is %f\n",tf2);
	double ag1,ag2;
	int it1=45,it1a=20,it2=30,it2a=101;
	double na1=2.0,na2=3.0;
	ag1=(double)it1+((double)it1a*pow10(na1-(2.0*na1)));
	ag2=(double)it2+((double)it2a*pow10(na2-(2.0*na2)));
	printf("%f %f\n",ag1,ag2);
	printf("ts itoa\n");
	char s[20]="12.34",*end;
	double v=strtod(s,&end);
	printf("%s -> %f",s,v);
//	itoa(it1,s,10);
//	printf("%s",s);
	getch();
	return ;
}
