// package de.embeddedXML.io
// import de.kxml.*;
// file name: Xmlwriter.h
#ifndef __XMLWR_H
#define __XMLWR_H
#include "Prefix.h"
#include "Xml.h"
#include "Attr.h"
#include "Prefix.h"
class XMLWriter
{
	private:
	int countns;
	int pending;  // 0=false 1=true
	char writer[2000];
	Str nameTag[20];
	int size;
	Str error;

	public:
	XMLWriter();
	XMLWriter(const char *w);
	//XmlWriter (Writer writer)
	const char* getWriter() const
	{
		return writer;
	}
	void checkPending (); // throws IOException protected 
	void write (char c); // throws IOException
	void write (char* buf, int start, int len);// throws IOException
	void writeAttribute (const char* attr);
	void writeAttribute (const char* pf,const char* n,const char* v); // throws IOException
	void writeAttribute (const char* n,const char* v); // throws IOException
	void writeStartTag (const char* pf,const char* n); // throws IOException
		/** writes a start tag with the given namespace and name */
		//void writeStartTag (char* ns, char* n);    // throws IOException
	void writeStartTag (const char* t); // throws IOException  protected
	void writeEmptyTag(const char* pf, const char*n, const char* attr);
	void writeEmptyTag(const char* tag, const char* attr);
	void writeEndTag (const char *tag); // throws IOException
	void writeEndTag ();
	void writeTag(const char* tag, const char* attr, const char* value);
	void closeAll();
	void writeLegacy (int type,const char* content); // throws IOException
	void writeRaw (const char* s); // throws IOException
};
#endif