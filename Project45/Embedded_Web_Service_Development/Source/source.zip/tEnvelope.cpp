#include <stdio.h>
#include <iostream.h>
#include <conio.h>
#include "Envelope.h"
#include "Fault.h"
#include "Body.h"
#include "Header.h"
int main()
{
	const char *fs="service 'urn:mimetest' unknown";
	const char *fc="SOAP-ENV:Server";
	//const char *ac="/soap/servlet/rpcrouter";
	Fault f1(fc,fs);
	clrscr();
	char *hit=f1.marshall();
	Body b1(hit);
	const char* attr="<t:Transaction xmlns:t=\"some-URI\" SOAP-ENV:mustUnderstand=\"1\">5</t:Transaction>";
	Header h1(attr);
	delete hit;
	Envelope e1,e2(h1,b1,NULL);

	cout<<"e1.getEnvelopeEntries()="<<e1.getEnvelopeEntries()<<endl;
	hit=e1.getAttribute();
	cout<<"e1.getAttribute()      ="<<hit<<endl;
	delete hit;
	hit=e1.marshall();
	cout<<"e1.marshall()          ="<<hit<<endl;
	delete hit;

	cout<<"e2.getEnvelopeEntries()="<<e2.getEnvelopeEntries()<<endl;
	hit=e1.getAttribute();
	cout<<"e2.getAttribute()      ="<<hit<<endl;
	delete hit;
	hit=e2.marshall();
	cout<<"e2.marshall()          ="<<hit<<endl;
	delete hit;
	getch();

	hit=e2.getHeader().getAttribute();
	cout<<"e2.getHeader().getAttribute()    ="<<hit<<endl;
	delete hit;
	cout<<"e2.getHeader().getHeaderEntries()="<<e2.getHeader().getHeaderEntries()<<endl;
	hit=e2.getHeader().marshall();
	cout<<"e2.getHeader().marshall()        ="<<hit<<endl;
	delete hit;
	

	cout<<"e2.getBody().getBodyEntries()="<<e2.getBody().getBodyEntries()<<endl;
	hit=e2.getBody().getAttribute();
	cout<<"e2.getBody().getAttribute()  ="<<hit<<endl;
	delete hit;
	hit=e2.getBody().marshall();
	cout<<"e2.getBody().marshall()      ="<<hit<<endl;
	delete hit;


	
	
	return 0;
}