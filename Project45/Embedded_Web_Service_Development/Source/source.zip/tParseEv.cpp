#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <stdlib.h>
#include "Legacy.h"
#include "ParseE.h"
int main()
{	
	char st[300];
	clrscr();
	char *s="hit";
	LegacyEvent p(15,s);
	ParseEvent *ps;
	int i;
	i=p.getType();
	cout<<"p.getType()  ="<<i<<endl;
	i=p.endCheck(ps);
	cout<<"p.endCheck(s)="<<i<<endl;
	strcpy(st,p.getText());
	cout<<"p.getText()=  "<<st<<endl;
	return 0;
}
