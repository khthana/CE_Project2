//Call.h

#ifndef __CALL_H
#define __CALL_H
#include "RPCMess.h"
#include "Str.h"
#include "Param.h"

class Call : public RPCMessage
{
	private:
	int to;

	public:
	Call()	{t=0;}

	Call(const char* objectURI, const char* methodName,
                       Vector params, Header header,
                       const char* encodingStyleURI/*, SOAPContext ctx*/) {
    setTargetObjectURI(objectURI);
    methodName       = methodName;
    params           = params;
    header           = header;
    encodingStyleURI = encodingStyleURI;
    /*ctx              = ctx;*/	}

	Call& operator=(const Call& that)	{
		to=that.getTimeout();	}

	void setTimeout(int value)	{
		to=value;	}

	int getTimeout() const {
		return to;	}

	Envelope buildEnvelope()	{
		return RPCMessage::buildEnvelope(0);	}

	static RPCMessage* extractFromEnvelope(const Envelope env, SerrviceManager svcMgr)	{
		return RPCMessage.extractFromEnvelope(env,svcMgr,0);	}

	Response invoke(URL url,const char* SOAPActionURI)	{
		Envelope callEnv=buildEnvelope();
		// Construct default HTTP transport if not specified.
		//Post the call envelope
		// Get the response context.


		




		Envelope callEnv = buildEnvelope();

      // Construct default HTTP transport if not specified.
      if (st == null)
        st = new SOAPHTTPConnection();

      // set the timeout
      if (to != 0 && st instanceof SOAPHTTPConnection) 
        ((SOAPHTTPConnection)st).setTimeout(to);

      // Post the call envelope.
      st.send(url, SOAPActionURI, null, callEnv, smr, ctx);

      // Get the response context.
      SOAPContext respCtx = st.getResponseSOAPContext();

      // Pre-read the response root part as a String to be able to
      // log it in an exception if parsing fails.
      String payloadStr = getEnvelopeString(st);

      // Parse the incoming response stream.
      Document respDoc =
        xdb.parse(new InputSource(new StringReader(payloadStr)));
      Element payload = null;

      if (respDoc != null)
      {
        payload = respDoc.getDocumentElement();
      }
      else  //probably does not happen
      {
        throw new SOAPException (Constants.FAULT_CODE_CLIENT,
          "Parsing error, response was:\n" + payloadStr);
      }

      // Unmarshall the response envelope.
      Envelope respEnv = Envelope.unmarshall(payload, respCtx);

      // Extract the response from the response envelope.
      Response resp = Response.extractFromEnvelope(respEnv, smr, respCtx);

      // Reset the targetObjectURI in case it was changed by the server
      String fullTargetObjectURI = resp.getFullTargetObjectURI();

      if (fullTargetObjectURI != null)
      {
        setTargetObjectURI(fullTargetObjectURI);
      }

      return resp;
};

#endif


  /**
   * Check if response root part is text/xml and return it as a String.
   * Temporarily placing this method here - I think it will be moved to
   * SOAPContext after a redesign of SOAPTransport interaction.
   *
   * @author Wouter Cloetens <wcloeten@raleigh.ibm.com>
   */
/*  public static String getEnvelopeString(SOAPTransport st)
    throws SOAPException, MessagingException, IOException {
    SOAPContext respCtx = st.getResponseSOAPContext();
    BufferedReader in = null;
    String payloadStr = null;

    MimeBodyPart rootPart = respCtx.getRootPart();
    if (rootPart.isMimeType("text/*")) {
      // Get the input stream to read the response envelope from.
      in = st.receive();
      payloadStr = IOUtils.getStringFromReader(in);
    }

    // Check Content-Type of root part of response to see if it's
    // consistent with a SOAP envelope (text/xml).
    if (!rootPart.isMimeType(Constants.HEADERVAL_CONTENT_TYPE)) {
      throw new SOAPException(Constants.FAULT_CODE_PROTOCOL,
        "Unsupported response content type \"" +
        rootPart.getContentType() + "\", must be: \"" +
        Constants.HEADERVAL_CONTENT_TYPE + "\"." +
        (payloadStr == null ? "" : " Response was:\n" + payloadStr));
    }

    return payloadStr;
  }

  /**
   * Invoke this call at the specified URL. Valid only on the client side.
   */
  public Response invoke(URL url, String SOAPActionURI) throws SOAPException
  {
    if (SOAPActionURI == null)
    {
      SOAPActionURI = "";
    }

    // if the smr hasn't been created yet, do it now
    if (smr == null)
    {
      smr = new SOAPMappingRegistry();
    }

    try
    {
      // Build an envelope containing the call.
      
    }
    catch (MessagingException me)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT, me.getMessage(), me);
    }
    catch (IllegalArgumentException e)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT, e.getMessage(), e);
    }
    catch (SAXException e)
    {
      throw new SOAPException(Constants.FAULT_CODE_CLIENT,
                              "Parsing error, response was:\n" +e.getMessage(),
			      e);
    }
    catch (IOException e)
    {
      throw new SOAPException(Constants.FAULT_CODE_PROTOCOL,
                              e.getMessage(), e);
    }
  }
}