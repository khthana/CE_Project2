// SoapEnc.h

#ifndef __SOAPENC_H
#define __SOAPENC_H

class SoapEncoding
{
	public:
	SoapEncoding()	{}
	~SoapEncoding()	{}
	
	char* typeToSoap();
};
#endif