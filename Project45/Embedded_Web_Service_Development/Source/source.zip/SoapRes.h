//SOAPRes.h

#ifndef ____SOAPRESPONSE_H
#define ____SOAPRESPONSE_H

#include "Parser.h"
#include "ParseE.h"
#include "Envelope.h"
#include "Header.h"
#include "Body.h"
#include "Xml.h"
#include "SoapDes.h"

class SOAPResponse
{
	public:
	SOAPResponse() {}

	static char* buildResponse(Envelope *env,const char* param)
	{
		char *temp;
	temp=new char[800+env->getLength()];

	//<SOAP-ENV:ENVELOPE
	strcpy(temp,Xml::LT_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::ENVELOPE);

	//attribute's Envelope
	char *t;
	AttributeHandler attrHandler=env->getAttributeHandler();
	///////if (attrHandler.getLength() > 0)
	///////{
		/////t=attrHandler.marshall();
		t=env->getAttribute();
		strcat(temp,t);
		strcat(temp,NULL);
		delete t;
	///////}
	//>\n
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	/*Header header=env->getHeader();
	if (header.getLength() > 0)
	{
		t=header.marshall();
		strcat(temp,t);
		delete t;
	}*/
	strcat(temp,Xml::LT_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::BODY);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);

	strcat(temp,param);
	strcat(temp,Xml::ENTER_S);

	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::BODY);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);


	//</SOAP-ENV:ENVLOPE>\n
	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::ENVELOPE);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	strcat(temp,NULL);
	return temp;		
	}
};
#endif