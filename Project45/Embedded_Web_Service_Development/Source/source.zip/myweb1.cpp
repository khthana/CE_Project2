#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#define _MaxBuffer_ 1000

#ifdef __cplusplus
extern "C" {
#endif
#include <tcp.h>
#ifdef __cplusplus
}
#endif

tcp_Socket telnetsock;
char buffer[ _MaxBuffer_ ];
int status;
int len, i, a;
char RequestedObject[30] ;
char ParaName[30] ;
char ParaValue[30] ;

char* parseGETPOST(char * s) {
	char *soap="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\">\n<SOAP-ENV:Body>\n<SOAP-ENV:Fault>\n<faultcode>Server</faultcode>\n<faultstring>Input parameter mismatch with Service</faultstring>\n<faultactor>SOAP Request Handler</faultactor>\n</SOAP-ENV:Fault>\n\n</SOAP-ENV:Body>\n</SOAP-ENV:Envelope>\n";
	char *temp=new char[1000];
	strcpy(temp,soap);
	strcat(temp,NULL);
	return temp;
	
}

void clearBuffer(void) {
	for(i=0;i<_MaxBuffer_;i++) {
	 buffer[i] = 0 ;
	}
}

void myhttp(void) {
	static tcp_Socket *s;
	clearBuffer() ;
	s = &telnetsock;
	tcp_listen( s, 80, 0L, 0, NULL, 0);
	sock_wait_established(s, 0, NULL, &status);
	sock_mode(s, TCP_MODE_BINARY) ;
	sock_wait_input(s, 0, NULL, &status) ;
	sock_fastread(s, buffer, 1000) ;
	printf("%s", buffer) ;
	sock_fastread(s, buffer, 1000);
	printf("%s", buffer) ;
	char* temp;
	temp=parseGETPOST(buffer) ;

	sock_puts(s, "HTTP/1.0 200 Ok\n\r")  ;
	sock_puts(s, "Content-Type: text/xml; charset=\"utf-8\"\n\r") ;
	sock_puts(s, "\n\r") ;
	sock_puts(s, temp);
	delete temp;
	

	sock_flush(s) ;

	sock_close(s) ;
	sock_wait_closed(s, 0, NULL, &status) ;

	sock_err:
	switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
			return;
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
			return;
		}
}

void main(void) {
	sock_init();
	while (1)
	{
		myhttp();
		if (kbhit())
		{
			exit(0);
		}
	}
}
