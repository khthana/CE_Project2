#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <conio.h>
//#include
#include<fstream.h>
const max=2000;
char a[max];
enum xmlError { ok = 0,tag_error,else_error};
xmlError ck=ok;
enum typexml { xmlDocument=0, xmlComment, xmlElement, xmlAttribute, xmlUnknown};
class xmlDocument
{
	private : 
		float version;
		char* std;
		typexml t;
	public :
		xmlDocument(){ version=1.0; std="yes";t=xmlDocument;}
		~xmlDocument(){}
		void setVersion(float v){ version=v;};
		void setStd(char* s){std=s;};
		void print(){
			cout<<"Xml Document Objet version := "<<version<<"standalone :="<<std<<endl;
		}
		typexml returntype(){return t;}
};
class xmlComment
{
	private :
		char* comment;
		typexml t;
	public :
		xmlComment(){t=xmlComment;}
		~xmlComment(){}
		void setComment(char* t) {comment=t;}
		void print(){
			cout<<"Xml Comment object :"<<comment<<endl;
		}
		typexml returntype(){return t;}
};
class xmlAttribute
{
	private :
		typexml t;
		char* name;
		float value;
	public :
		xmlAttribute(){t=xmlAttribute;}
		~xmlAttribute(){}
		void setAttrname(char* a) {name=a;}
		void setValue(float v) {value=v;}
		void print(){
			cout<<"Xml Attribute object :"<<name<<" = "<<value<<endl;
		}
		typexml returntype(){return t;}

};
class xmlElement
{
	private :
		typexml t;
		char* element,text;
		xmlAttribute a1;
	public : 
		xmlElement() {t=xmlElement;}
		~xmlElemetn() {}
		void setElement(char* e){element=e;}
		void setText(char* t){text=t;}
		void print(){
			cout<<"Xml Element object : "<<element<<endl;
			cout<<"            text   : "<<text<<endl;
		}
		typexml returntype(){return t;}		

};
int main()
{
	char temp;
	clrscr();
	ifstream read("test1.xml");
	while(read)
	{
	read.getline(a,max);
	cout<<a<<endl;
	int i=0;
	if (a[i]=='<')
	{
		++i;
		if (a[i]=='?')
		{
		
			i+=6;

			if ((a[i]=='v')&&(a[i+1]=='e')&&(a[i+2]=='r')&&(a[i+3]=='s')&&(a[i+4]=='s')&&(a[i+5]=='i')&&(a[i+6]=='o')&&(a[i+7]=='n'))
			{
				xmlDocument1.setVersion(1.0);
			}
			while (a[i]!=' ')
				++i;
		
			if (a[i]=='>')
			{
				ck=ok;
			}
			else {
				if ((a[i]=='s')&&(a[i+1]=='t')&&(a[i+2]=='a')&&(a[i+3]=='n')&&(a[i+4]=='d')&&(a[i+5]=='a')&&(a[i+6]=='l')&&(a[i+7]=='o'))
				{
					while (a[i]!='=')
						++i;
					++i;
					if ((a[i]=='n')&&(a[i]=='o'))
					{
						xmlDocument.setStd(1);
					}
				}
			}
		}else if ((a[i]=='!')&&(a[i+1]=='-')&&(a[i+2]=='-'))
		{
			i+=5;

		}

	}else{
			
	}
	if (ck>0)
	{
		printf("/nerror!");
		break;
	}//if break error
	}//while
	getch();
	return 0;
}