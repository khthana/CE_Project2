#include <stdio.h>
#include <iostream.h>
#include <conio.h>
#include "Body.h"
#include "Fault.h"
int main()
{
	const char *fs="service 'urn:mimetest' unknown";
	const char *fc="SOAP-ENV:Server";
	//const char *ac="/soap/servlet/rpcrouter";
	Fault f1(fc,fs);
	clrscr();
	char *hit=f1.marshall();
	Body b1,b2(hit);
	delete hit;

	cout<<"b1.getBodyEntries()="<<b1.getBodyEntries()<<endl;
	hit=b1.getAttribute();
	cout<<"b1.getAttribute()  ="<<hit<<endl;
	delete hit;
	hit=b1.marshall();
	cout<<"b1.marshall()      ="<<hit<<endl;
	delete hit;

	cout<<"b2.getBodyEntries()="<<b2.getBodyEntries()<<endl;
	hit=b2.getAttribute();
	cout<<"b2.getAttribute()  ="<<hit<<endl;
	delete hit;
	hit=b2.marshall();
	cout<<"b2.marshall()      ="<<hit<<endl;
	delete hit;
	getch();
	Body *b;
	b=Body::unmarshall(b2.getBodyEntries(),b2.getAttributeHandler());
	Body b3(*b);
	delete b;

	cout<<"b3.getBodyEntries()="<<b3.getBodyEntries()<<endl;
	hit=b3.getAttribute();
	cout<<"b3.getAttribute()  ="<<hit<<endl;
	delete hit;
	hit=b3.marshall();
	cout<<"b3.marshall()      ="<<hit<<endl;
	delete hit;

	
	
	return 0;
}