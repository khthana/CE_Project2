#include<conio.h>
#include<stdio.h>
#include<io.h>
#include<string.h>
#include<fcntl.h>
#include <process.h>
#include<stdlib.h>
#include"Str.h"
#include"Const.h"
#define _MaxBuffer_ 2000
#define _MaxStrLen_ 200
#define _MaxParaNum_ 20
#define _MaxOutputMessage_ 1000
#define _HomeDir_ "."
#define _MaxCon_ 5

#ifdef __cplusplus
extern "C" {
#endif
#include <tcp.h>
#ifdef __cplusplus
}
#endif

Str message;
const char *ok="ok";
//------------------------------------------------------
class HTTPRequest{

   public:
     int len, i, a;

     tcp_Socket telnetsock[_MaxCon_];
     int status;
     char buffer[_MaxBuffer_];
     tcp_Socket *soc[_MaxCon_];

     char ParaName[_MaxParaNum_][_MaxStrLen_] ;
     char ParaValue[_MaxParaNum_][_MaxStrLen_] ;
     unsigned char ParaIndex ;

     char OutputMessage[_MaxOutputMessage_] ;

//     void yield(void) ;
     char RequestedObject[_MaxStrLen_] ;
//     HTTPRequest(void) ;
     char* parseGETPOST(char *strin) ;
     void clearAll(void) ;
     void waitHTTP(void) ;
     void outputMessage(tcp_Socket *mysock, char *strin) ;

     void outputImage(tcp_Socket *mysock, char * filename) ;
} ;


HTTPRequest hr ;


//------------------------------------------------------
void HTTPRequest::outputImage(tcp_Socket *mysock, char * filename){

  int handle ;
  int numread = 0;
  char bufferread[1000] ;


  if ((handle = open(filename, O_RDONLY)) == -1) {
    perror("Error:");
    sock_puts(mysock, "HTTP/1.0 404 Not Found\n\n")  ;
   } else {

    sock_puts(mysock, "HTTP/1.0 200 Ok\n")  ;
    sock_puts(mysock, "Data: xxx \n") ;
    sock_puts(mysock, "Server: Com86 Demo \n") ;
    sock_puts(mysock, "Accept-Ranges: bytes \n") ;
    sock_puts(mysock, "Connection: close\n") ;
    // check image type gif
    if (strstr(strlwr(RequestedObject), ".gif")==NULL) {
      sock_puts(mysock, "Content-Type: image/gif\n") ;
    } else if (strstr(strlwr(RequestedObject), ".jpg")==NULL) {
      sock_puts(mysock, "Content-Type: image/jpeg\n") ;
    } else {
      sock_puts(mysock, "Content-Type: image/gif\n") ;
    }

    sock_puts(mysock, "\n") ;

    while (!eof(handle)) {
      numread = _read(handle, bufferread, 1000);
//     printf("-->%d\n", numread) ;
      sock_write(mysock, bufferread, numread) ;
      sock_flush(mysock) ;
    }

    close(handle);
  }

  // close connection
  sock_close(mysock) ;
//  sock_wait_closed(mysock, 0, NULL, &status) ;
  return ;

	sock_err:
	switch (status) {
		case 1 ://foreign host closed
			puts("User closed session");
			return ;
		case -1: // timeout
			printf("\n\rConnection timed out!");
			return ;
		}
}           

//------------------------------------------------------
void HTTPRequest::outputMessage(tcp_Socket *mysock, char *strin)
{
  sock_puts(mysock, "HTTP/1.0 200 Ok\n")  ;
  sock_puts(mysock, "Content-Type: text/xml; charset=\"utf-8\"\n") ;
  sock_puts(mysock, "\n") ;
  sock_puts(mysock, strin) ;
  
  printf("HTTP/1.0 200 Ok\n")  ;
  printf("Content-Type: text/xml; charset=\"utf-8\"\n") ;
  printf("\n") ;
  printf("%s",strin);
	
  
  //printf("%s",strin) ;
  sock_flush(mysock) ;

  // close connection
  sock_close(mysock) ;
//  sock_wait_closed(mysock, 0, NULL, &status) ;
  return ;

	sock_err:
	switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
			return ;
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
			return ;
		}
}
//------------------------------------------------------
char* HTTPRequest::parseGETPOST(char * strin) {
	//char *soap="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\">\n<SOAP-ENV:Body>\n<SOAP-ENV:Fault>\n<faultcode>Server</faultcode>\n<faultstring>Input parameter mismatch with Service</faultstring>\n<faultactor>SOAP Request Handler</faultactor>\n</SOAP-ENV:Fault>\n\n</SOAP-ENV:Body>\n</SOAP-ENV:Envelope>\n";
	char *temp;//=new char[1000];
	//strcpy(temp,soap);
	//strcat(temp,NULL);
	
	
	char *m=new char[strlen(strin)+1];
	strcpy(m,strin);
	strcat(m,NULL);
	if (m[0]=='P')
	{
		printf("Header Ok\n");
		delete m;
		m=new char[3];
		strcpy(m,ok);
		strcat(m,NULL);
		return m;
	}
	else if (m[0]=='<')
	{
		FILE *stream;
		
		char ch;int i=0;
		stream=fopen("soapin.txt","w+");
		fseek(stream,0,SEEK_SET);
		fprintf(stream,"%s",m);
		fclose(stream);
		delete m;
		i = spawnl(P_WAIT,"Soapserv.exe",NULL);
		if (i==-1)
		{
			perror("Error from spawnl");
			exit(1);
		}
		char *a=new char[2000];
		stream=fopen("soap.txt","r+");
		
		fseek(stream,0,SEEK_SET);
		ch=fgetc(stream);i=0;
		while (ch!=EOF)
		{
			if (i>2000)
				break;
			if (ch!=-9)
				a[i++]=ch;
			ch=fgetc(stream);
		}
		a[i]='\0';
		fclose(stream);
		printf("af writ%s",a);
		return a;
	}
}
//------------------------------------------------------
void HTTPRequest::clearAll(void) {
  unsigned char tempc ;
  memset(buffer, 0, _MaxBuffer_) ;
  memset(RequestedObject, 0, _MaxStrLen_) ;
  for(i=0;i<_MaxParaNum_;i++) {
    memset(ParaName[i], 0, _MaxStrLen_) ;
    memset(ParaValue[i], 0, _MaxStrLen_) ;
  }
  memset(OutputMessage, 0, _MaxOutputMessage_) ;
  ParaIndex = 0 ;
}
//------------------------------------------------------
void yield() {
  unsigned char tempc ;
  int i=0;

char *sen;
char *out;

  char temperaturea[5] ;
  char temp[_MaxStrLen_] ;
  char DemoMessage[_MaxBuffer_] ;
	int count=0;

  for (tempc=0;tempc<_MaxCon_;tempc++) {
    if (sock_established(hr.soc[tempc])==1) {
      if (sock_rbused(hr.soc[tempc])>0) { // if data available
	hr.clearAll() ;
	sock_fastread(hr.soc[tempc], hr.buffer, 512) ;
	count++;
	if (strcmp(hr.buffer,NULL)!=0)
	{
		message+=hr.buffer;i++;
	}
	//printf("%s",message.getStr());
	sen=hr.parseGETPOST(hr.buffer) ;
	if (strcmp(sen,ok)==0)
	{
		//printf("ok");
	}else if (sen[0]=='<')
	{
		printf("last%s",sen);
		hr.outputMessage(hr.soc[tempc],sen);
	}
	delete sen;
	
	
      }
    }
  } // for
  if (kbhit()) {
    for(i=0;i<_MaxCon_;i++) {
      sock_abort(hr.soc[i]) ;
    }
    exit(0) ;
  }
}
//------------------------------------------------------
void HTTPRequest::waitHTTP(void) {

  int i ;
  sock_init() ;
  sock_yield(NULL, yield) ;

  ParaIndex = 0 ;
  for(i=0;i<_MaxCon_;i++) {
    soc[i] = &telnetsock[i] ;
  }

  while (1==1) {
	clearAll() ;

	for(i=0;i<_MaxCon_;i++) {

	  printf("Try to listen %d\n", i) ;
	  tcp_listen( soc[i], 80, 0L, 0, NULL, 0);
	  sock_wait_established(soc[i], 0, NULL, &status);
	  printf("Socket %d Connect\n", i) ;
	  sock_mode(soc[i], TCP_MODE_BINARY) ;
	}

//	sock_wait_closed(soc[0], 0, NULL, &status) ;

	while (1==2) {
	  sock_err:
	  switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
		}
	}
  } // forever loop
//        return NULL ;
}
//------------------------------------------------------
void main(void) {
printf("Sever start..\n");

  hr.waitHTTP() ;
}

/*	tcp_listen( soc[1], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[1], 0, NULL, &status);
	printf("Socket 2 Connect\n") ;
	sock_mode(soc[1], TCP_MODE_BINARY) ;

	tcp_listen( soc[2], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[2], 0, NULL, &status);
	printf("Socket 3 Connect\n") ;
	sock_mode(soc[2], TCP_MODE_BINARY) ;

	tcp_listen( soc[3], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[3], 0, NULL, &status);
	printf("Socket 4 Connect\n") ;
	sock_mode(soc[3], TCP_MODE_BINARY) ;

	tcp_listen( soc[4], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[4], 0, NULL, &status);
	printf("Socket 4 Connect\n") ;
	sock_mode(soc[4], TCP_MODE_BINARY) ;
*/