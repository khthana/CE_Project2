// AttrHandler.cpp
#include <string.h>
#include "AttrHand.h"
AttributeHandler& AttributeHandler::operator=(const AttributeHandler& that)
{
	size=that.getSize();
	for(int i=0;i<size;i++)
		attributes[i]=that.getAttribute(i);
	return *this;
}
void AttributeHandler::setAttribute(const char* a,int sizeA)
{
	size=sizeA;
	int len=0,start=0,i=0;
	char *temp, *attr,*s;
	attr=new char[strlen(a)+1];
	strcpy(attr,a);
	strncat(attr,NULL,1);
	do
	{
		start=len+1;
		for (int j=start;attr[j]!=' ' && attr[j]!='\0' ;j++ )
			len++;
		len++;
		if (len-start>0)
		{
			temp=new char[len-start+2];
			strcpy(temp,NULL);
			for (j=start;j<len ;j++ )
			{
				s=&attr[j];
				strncat(temp,s,1);
			}
			attributes[i++]=temp;
			delete temp;
		}
		if (attr[len]=='\0')	break;
	}while (i<size);
	delete attr;
	while (i<4)
		attributes[i++]=NULL;
}
QName* AttributeHandler::attrToQName(int index) const
{
	char temp[200];
	QName *q=new QName();
	strcpy(temp,attributes[index].getStr());
	int i=0,j;
	while (temp[i]!=':' && temp[i]!='\0') i++;
	if (temp[++i]!=':')	
		i=0;
	char s[200];
	strcpy(s,NULL);
	j=0;
	while (temp[i]!='=')
		s[j++]=temp[i++];
	q->setLocalPart(s);
		i+=2;j=0;
	strcpy(s,NULL);
	while (temp[i]!='"')
		s[j++]=temp[i++];
	q->setNamespaceURI(s);
	return q;
}
const char* AttributeHandler::getAttribute(QName attrQName) const
{
	int i=0,index=-1;
	QName *q;
	while (i<size)
	{
		q=attrToQName(i++);
		if (attrQName==*q)
		{
			index=i;break;
		}
		else
			delete q;
	}
	delete q;
	if (index!=-1)
		return attributes[index].getStr();		
	else
		return NULL;
}

/*
private:
char* getPrefixFromURI(const char* namespaceURI)
{
	if (strcmp(namespaceURI,NULL)==0) return NULL ;
	char* nsPrefix;
	nsPrefix=new char[150];
	//strcpy(nsPrefix,NULL);
	strcpy(nsPrefix,namespaceURIs2Prefixes.getPrefix(namespaceURI));
	if (strcmp(nsPrefix,NULL)==0)
	{
		char c[10];
		char* s="ns";
		strncat(nsPrefix,s,2);
		itoa(nsPrefixIndex++,c,10);
		strncat(nsPrefix,c);
		setAttribute(QName(Constants.NS_URI_XMLNS, nsPrefix), namespaceURI);
	}
	return nsPrefix;
}*/
//function that save namespaceURI & prefix into NSStack coming soon======
char* AttributeHandler::getAttribute() const
{
	int i;
	char* temp;
	temp=new char[getLength()+10];
	strcpy(temp,NULL);
	for (i=0;i<size ; i++)
	{
		//if (i!=0)
			strcat(temp,Xml::SP_S);
		strcat(temp,attributes[i].getStr());
	}
	return temp;
}
char* AttributeHandler::marshall()
{
	int i;
	char* temp;
	temp=new char[getLength()+10];
	strcpy(temp,NULL);
	for (i=0;i<size ; i++)
	{
		if (i!=0)
			strcat(temp,Xml::SP_S);
		strcat(temp,attributes[i].getStr());
	}
	return temp;
}
AttributeHandler* AttributeHandler::unmarshall(const char* src,int s)
{
	AttributeHandler* a;
	a=new AttributeHandler(src,s);
	return a;
}	