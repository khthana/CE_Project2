#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <conio.h>
#include <string.h>
#include "StartTag.h"
int main()
{
	clrscr();
	int i;
	//char *pf="prefix";
	char *ns="namespace";
	//char s1[30],s2[30],s[20];

	int degen=0;
	char *n="name";
	StartTag t0;
	StartTag t1(ns,n,degen);
	degen=t1.getLineNumber();
	cout<<degen<<endl;
	char st[300];
	printf("string: ");
	char *tag="<arg2 xsi:type=\"xsd:double\" hit:type=\"xsd:string\">4.0</arg2>\r\n";
	strcpy(st,tag);
	printf("%s",st);
	XMLReader x1(st);
	StartTag t2(x1);
	int si;
	degen=0;
	char* hit;
	hit=t2.getAttribute();
	cout<<"\nt2.getAttribute()  ="<<hit<<endl;
	delete hit;
	//n="xsi:type";
	strcpy(st,t2.getAttribute(0));
	//strcpy(st,t2.getAttribute(1));
	cout<<"t2.getAttribute(1) ="<<st<<endl;
	//delete hit;
	strcpy(st,t2.getAttribute(1));
	//strcpy(st,t2.getAttribute(2));
	cout<<"t2.getAttribute(2) ="<<st<<endl;
	//delete hit;
	////strcpy(st,t2.getAttribute(3));
	//strcpy(st,t2.getAttribute(3));
	////cout<<"t2.getAttribute(3) ="<<st<<endl;
	//delete hit;
	/*strcpy(st,t2.getAttribute(4));
	cout<<"t2.getAttribute(4) ="<<st<<endl;*/
	si=t2.getDegenerated();
	cout<<"t2.getDegenerated()="<<si<<endl;
	si=t2.getCountAttr();
	cout<<"t2.getCountAttr()  ="<<si<<endl;
	hit=t2.toString();
	//strcpy(st,t2.toString());
	cout<<"t2.toString()      ="<<hit<<endl;
	delete hit;
	si=t2.getType();
	cout<<"t2.getType()       ="<<si<<endl;
	strcpy(st,t2.getName());
	cout<<"t2.getName()       ="<<st<<endl;
	strcpy(st,t2.getNamespace());
	cout<<"t2.getNamespace()  ="<<st<<endl;

	t1=t2;
	hit=t1.getAttribute();
	cout<<"\nt1.getAttribute()  ="<<hit<<endl;
	delete hit;
	si=t1.getDegenerated();
	cout<<"t1.getDegenerated()="<<si<<endl;
	hit=t1.toString();
	//strcpy(st,t1.toString());
	cout<<"t1.toString()      ="<<hit<<endl;
	delete hit;
	si=t1.getType();
	cout<<"t1.getType()       ="<<si<<endl;
	strcpy(st,t1.getName());
	cout<<"t1.getName()       ="<<st<<endl;
	strcpy(st,t1.getNamespace());
	cout<<"t1.getNamespace()  ="<<st<<endl;

	return 0;
}
