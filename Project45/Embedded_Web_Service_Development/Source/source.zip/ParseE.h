// package embeddedXML.parser
// import de.kxml.*;
// file name: ParseE.h

/** Abstract superclass for all pull parser events.  In order to avoid
    some typecasts, this class already provides most of the content
    access methods filled in the specialized subclasses.  */
#ifndef __PARSEEVENT_H
#define __PARSEEVENT_H
#include "xml.h"
#include "Prefix.h"
#include "Attr.h"
class ParseEvent 
{
	protected:
    int lineNumber;

    /** returns the line number of the event */
	public:
	ParseEvent()					{ lineNumber= -1; }
	ParseEvent& operator= (const ParseEvent& value)
	{
		lineNumber=value.getLineNumber();
		return *this;
	}
    int getLineNumber() const		{ return lineNumber; }
    /** sets the line number of the event. Used by the parser only. */
	void setLineNumber(int line)	{ lineNumber = line; }
	virtual char* getAttribute() const=0;
	/*{
		return NULL;
	}*/
	/** In the event type is START_TAG, this method returns the attribute 
       at the given index position. For all other event
       types, NULL is returned 
    Attribute getAttribute(int index) const 
	{
		return NULL;
    }    
    /** convenience method for getAttribute (NULL, name). 
    Attribute getAttribute (const char* n) const
	{
		return NULL;
    }
    /** If the event type is START_TAG, the local attribute with the
	given namespace and name is returned.  For all other event
	types, the return value is NULL. 

    Attribute getAttribute(const char* ns,const char* n) const
	{
		return NULL;
    }
    /** If the event type is START_TAG, the number of attributes is
	returned. For all other event types, the return value is NULL 

    int getAttributeCount() const
	{
		return 0;
    }
    /** returns the attribute vector. Returns NULL if not 
        instance of startTag */
	/* think.............Vector getAttributes()
	{
		return NULL;
    }
    /** returns the (local) name of the element started if
        instance of StartTag, NULL otherwise. */
    virtual const char* getName() const=0;//		{ return NULL; }
    /** returns namespace if instance of StartTag, NULL
        otherwise. */ 
    virtual const char* getNamespace () const=0;//	{ return NULL; }
    /** returns the value of the attribute with the given name,
	or NULL, if not instanceof StartTag or if not existing */

    virtual char* getValue (const char* attrname) const=0;
	virtual int getCountAttr() const=0;
	virtual const char* getAttribute (int index) const=0;
	virtual char* toString ()=0;
	/*{
		return NULL;
    }
    /** If the event type is TEXT, PROCESSING_INSTRUCTION,
	or DOCTYPE, the corresponding string is returned. For
	all othe event types, NULL is returned. */

    virtual const char* getText () const=0;//	{ return NULL; }
	virtual int getType () const=0;
	virtual int endCheck (ParseEvent* start)=0;
	virtual const char* getError()const=0;


};
#endif