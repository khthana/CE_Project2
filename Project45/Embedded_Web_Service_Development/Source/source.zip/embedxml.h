#ifndef EMBEDXML_INCLUDED
#define EMBEDXML_INCLUDED
#include <string.h>
#include <stdio.h>
#include <conio.h>
//#include <assert.h>

class XmlDocument;
class XmlElement;
class XmlComment;
class XmlUnknown;
class XmlAttribute;
class XmlText;
class XmlDeclaration;

class XmlBase
{
	friend class XmlNode;
	friend class XmlElement;
	friend class XmlDocument;

  public:
	XmlBase()		{}
	virtual ~XmlBase()	{}
	virtual void Print( FILE* fp, int depth )  = 0;

  protected:
	static const char* SkipWhiteSpace( const char* p );
	static const char* ReadName( const char* p, char* name );
	enum
	{
		XML_NO_ERROR = 0,
		XML_ERROR_OPENING_FILE,
		XML_ERROR_OUT_OF_MEMORY,
		XML_ERROR_PARSING_ELEMENT,
		XML_ERROR_FAILED_TO_READ_ELEMENT_NAME,
		XML_ERROR_READING_ELEMENT_VALUE,
		XML_ERROR_READING_ATTRIBUTES,
		XML_ERROR_PARSING_EMPTY,
		XML_ERROR_READING_END_TAG,
		XML_ERROR_PARSING_UNKNOWN,
		XML_ERROR_PARSING_COMMENT,
		XML_ERROR_PARSING_DECLARATION,

		Xml_ERROR_STRING_COUNT
	};
	static const char* errorString[ 13 ];
};

class XmlNode : public XmlBase
{
  public:
	enum NodeType
	{
		DOCUMENT, ELEMENT, COMMENT, UNKNOWN, TEXT, DECLARATION, TYPECOUNT
	};

	virtual ~XmlNode();
	const char* Value()	const		{ return value; }
	void SetValue( const char* _value )	{ value = _value; }
	void Clear();
	XmlNode* Parent() const			{ return parent; }

	XmlNode* FirstChild()	const		{ return firstChild; }
	XmlNode* FirstChild( const char* value ) const;

	XmlNode* LastChild() const	{ return lastChild; }	
	XmlNode* LastChild( const char* value ) const;
	XmlNode* IterateChildren( XmlNode* previous );
	XmlNode* IterateChildren( const char* value, XmlNode* previous );
	XmlNode* InsertEndChild( const XmlNode& addThis );					
	XmlNode* InsertBeforeChild( XmlNode* beforeThis, const XmlNode& addThis );
	XmlNode* InsertAfterChild(  XmlNode* afterThis, const XmlNode& addThis );
	XmlNode* ReplaceChild( XmlNode* replaceThis, const XmlNode& withThis );
	bool RemoveChild( XmlNode* removeThis );
	XmlNode* PreviousSibling() const			{ return prev; }
	XmlNode* PreviousSibling( const char* ) const;
	XmlNode* NextSibling() const				{ return next; }
	XmlNode* NextSibling( const char* ) const;
	XmlElement* NextSiblingElement() const;
	XmlElement* NextSiblingElement( const char* ) const;
	XmlElement* FirstChildElement()	const;
	XmlElement* FirstChildElement( const char* value ) const;
	virtual int Type()	{ return type; }
	XmlDocument* GetDocument() const;

	XmlDocument* ToDocument()	const	{ return ( type == DOCUMENT ) ? (XmlDocument*) this : 0; }
	XmlElement*  ToElement() const	{ return ( type == ELEMENT  ) ? (XmlElement*)  this : 0; }
	XmlComment*  ToComment() const	{ return ( type == COMMENT  ) ? (XmlComment*)  this : 0; }
	XmlUnknown*  ToUnknown() const	{ return ( type == UNKNOWN  ) ? (XmlUnknown*)  this : 0; }
	XmlText*	   ToText()    const	{ return ( type == TEXT     ) ? (XmlText*)     this : 0; }
	XmlDeclaration* ToDeclaration() const	{ return ( type == DECLARATION ) ? (XmlDeclaration*) this : 0; }

	virtual XmlNode* Clone() const = 0;

  protected:
	XmlNode( NodeType type );
	virtual const char* Parse( const char* ) = 0;
	XmlNode* LinkEndChild( XmlNode* addThis );
	XmlNode* IdentifyAndParse( const char** p );
	void CopyToClone( XmlNode* target ) const	{ target->value = value; }
	
	XmlNode*		parent;		
	NodeType		type;
	XmlNode*		firstChild;
	XmlNode*		lastChild;
	char		value;
	XmlNode*		prev;
	XmlNode*		next;
};
class XmlAttribute : public XmlBase
{
	friend class XmlAttributeSet;

  public:
	XmlAttribute() : prev( 0 ), next( 0 )	{}
	XmlAttribute( const char& _name, const char& _value )	: name( _name ), value( _value ), prev( 0 ), next( 0 ) {}
	const char& Name()  const { return name; }
	const char& Value() const { return value; }
	void SetName( const char& _name )	{ name = _name; }
	void SetValue( const char& _value )	{ value = _value; }
	XmlAttribute* Next();
	XmlAttribute* Previous();
	bool operator==( const XmlAttribute& rhs ) const { return rhs.name == name; }
	bool operator<( const XmlAttribute& rhs )	 const { return name < rhs.name; }
	bool operator>( const XmlAttribute& rhs )  const { return name > rhs.name; }
	const char* Parse( const char* );
	virtual void Print( FILE* fp, int depth );
	void SetDocument( XmlDocument* doc )	{ document = doc; }

  private:
	XmlDocument*	document;
	char		name;
	char		value;

	XmlAttribute*	prev;
	XmlAttribute*	next;
};

class XmlAttributeSet
{
  public:
	XmlAttributeSet();
	~XmlAttributeSet();

	void Add( XmlAttribute* attribute );
	void Remove( XmlAttribute* attribute );

	XmlAttribute* First() const	{ return ( sentinel.next == &sentinel ) ? 0 : sentinel.next; }
	XmlAttribute* Last()  const	{ return ( sentinel.prev == &sentinel ) ? 0 : sentinel.prev; }
	
	XmlAttribute*	Find( const char& name ) const;

  private:
	XmlAttribute sentinel;
};

class XmlElement : public XmlNode
{
  public:
	XmlElement( const char& value );

	virtual ~XmlElement();
	const char* Attribute( const char& name ) const;
	const char* Attribute( const char& name, int* i ) const;
	void SetAttribute( const char& name, 
					   const char& value );
	void SetAttribute( const char& name, 
					   int value );
	void RemoveAttribute( const char& name );
	XmlAttribute* FirstAttribute()	{ return attributeSet.First(); }
	XmlAttribute* LastAttribute()		{ return attributeSet.Last(); }
	virtual XmlNode* Clone() const;
	virtual void Print( FILE* fp, int depth );

  protected:
	virtual const char* Parse( const char* );
	const char* ReadValue( const char* p );

  private:
	XmlAttributeSet attributeSet;
};

class XmlComment : public XmlNode
{
  public:
	XmlComment() : XmlNode( XmlNode::COMMENT ) {}
	virtual ~XmlComment()	{}
	virtual XmlNode* Clone() const;
	virtual void Print( FILE* fp, int depth );

  protected:
	virtual const char* Parse( const char* );
};
class XmlText : public XmlNode
{
  public:
	XmlText()  : XmlNode( XmlNode::TEXT ) {}
	virtual ~XmlText() {}
	virtual XmlNode* Clone() const;
	virtual void Print( FILE* fp, int depth );
	bool Blank();
	virtual const char* Parse( const char* );
};

class XmlDeclaration : public XmlNode
{
  public:
	XmlDeclaration()   : XmlNode( XmlNode::DECLARATION ) {}
	XmlDeclaration( const char& version, const char& encoding, const char& standalone );
	virtual ~XmlDeclaration()	{}
	const char& Version()		{ return version; }
	const char& Encoding()		{ return encoding; }
	const char& Standalone()		{ return standalone; }
	virtual XmlNode* Clone() const;
	virtual void Print( FILE* fp, int depth );

  protected:
	virtual const char* Parse( const char* );

  private:
	char version;
	char encoding;
	char standalone;
};


class XmlUnknown : public XmlNode
{
  public:
	XmlUnknown() : XmlNode( XmlNode::UNKNOWN ) {}
	virtual ~XmlUnknown() {}
	virtual XmlNode* Clone() const;
	virtual void Print( FILE* fp, int depth );

  protected:
	virtual const char* Parse( const char* );
};

class XmlDocument : public XmlNode
{
  public:
	XmlDocument();
	XmlDocument( const char& documentName );
	virtual ~XmlDocument() {}
	bool LoadFile();
	bool SaveFile();
	bool LoadFile( const char& filename );
	bool SaveFile( const char& filename );
	const char* Parse( const char* );
	bool Error()						{ return error; }
	const char& ErrorDesc()		{ return errorDesc; }
	virtual void Print( FILE* fp, int depth = 0 );
	void Print()										{ Print( stdout, 0 ); }
	virtual XmlNode* Clone() const;
	void SetError( int err ) {		assert( err > 0 && err < Xml_ERROR_STRING_COUNT );
									error   = true; 
									errorId = err;
									errorDesc = errorString[ errorId ]; }
  private:
	bool error;
	int  errorId;	
	char errorDesc;
};
#endif