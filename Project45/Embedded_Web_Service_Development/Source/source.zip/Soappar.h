//SoapPar.h

#ifndef __SOAPPARSER_H
#define __SOAPPARSER_H

#include "Parser.h"
#include "ParseE.h"
#include "Envelope.h"
#include "Header.h"
#include "Body.h"
#include "Xml.h"
#include "SoapDes.h"

class SOAPParser 
{
	public:
	SOAPParser() {}

	static Envelope* parse(const char* message)
	{
		Envelope *env;
		env=NULL;
		Parser *pr=new Parser();
		pr->setXMLReader(message);
		ParseEvent *pe;
		Str error;
		char envTag[18];
		strcpy(envTag,Constants::SOAP_ENV);
		strcat(envTag,Xml::CL_S);
		strcat(envTag,Constants::ENVELOPE);
		strcat(envTag,NULL);
		//read to skip PI
		pe=pr->read();
		pe=pr->read();
		if ((pe->getType()==Xml::START_TAG) && (strcmp(pe->getName(),envTag)==0 ))	{
			env=Envelope::unmarshall(pr,pe);
			/*if (strcmp(env->getError(),NULL)!=0)	{
				error=env->getError();	}
			else {
				if (strcmp(env->getBody()->getError(),NULL)!=0)	{
					error=env->getBody()->getError();	}
				//else method parameter header
			}*/
		}
		else
			error=Constants::ENVELOPE;
		return env;
		/* /////// improve buildSOAPFault now return env not care
		if (strcmp(error.getStr(),NULL)!=0)	{
			delete env;
			env=buildSOAPFault(error.getStr());			
		}else{
			return env;		}*/
	}/*
	char* buildSOAPFault(const char *e)
	{
		Str env;
		char *temp=NULL;
		temp=Envelope::setEnvForFault();
		env+=temp;
		if (temp!=NULL)
			delete temp;
		if (strcmp(e,ENVELOPE)
		{
			char *fs="Invalid Something";
			Fault *f=new Fault(Constants::SERVER,fs);
			temp=f->marshall();
			env+=temp;
			if (temp!=NULL)
				delete temp;
		}
		temp=new char[env.getSize()+1];
		strcpy(temp,env.getStr());
		strcat(temp,NULL);
		return temp
	}
	char* setObjectToDeserialize()
	{
		
	}*/
	static char* getServiceName(const char *n)
	{
		FILE *stream;
		int i=0;
		char ch,*a;
		a=new char[1500];
		stream=fopen("lists.txt","r+");
		fseek(stream,0,SEEK_SET);
		ch=fgetc(stream);
		while (ch!=EOF)
		{
			if (i>1500)
				break;
			if (ch!=-9  && ch!='\n')
				a[i++]=ch;
			if (ch=='\n')
				a[i++]=';';
			ch=fgetc(stream);
		}
		a[i++]=';';
		a[i]='\0';
		fclose(stream);
		Str list=a;
		delete a;
		Str name;
		a=NULL;
		while (list.getSize()>0)
		{
			a=list.cut(';');
			name=a;
			if (a!=NULL)
			{
				delete a;
				a=NULL;
			}
			a=name.cut('=');
			if (strcmp(a,n)==0)
			{
				delete a;
				char *hitp=new char[name.getSize()+1];
				strcpy(hitp,name.getStr());
				strcat(hitp,NULL);
				return hitp;

			}
			else if (a!=NULL)
			{
				delete a;
				a=NULL;
			}
		}
		if (a!=NULL)
		{
			delete a;
		}
		return NULL;		
	}
	static int checkServiceName(const char *n)
	{
		//search url in class Method in file that save servicename & serviceurl
		FILE *stream;
		int i=0;
		char ch,*a;
		a=new char[1500];
		stream=fopen("lists.txt","r+");
		fseek(stream,0,SEEK_SET);
		ch=fgetc(stream);
		while (ch!=EOF)
		{
			if (i>1500)
				break;
			if (ch!=-9  && ch!='\n')
				a[i++]=ch;
			if (ch=='\n')
				a[i++]=';';
			ch=fgetc(stream);
		}
		a[i++]=';';
		a[i]='\0';
		fclose(stream);
		Str list=a;
		delete a;
		Str name;
		a=NULL;
		while (list.getSize()>0)
		{
			a=list.cut(';');
			name=a;
			if (a!=NULL)
			{
				delete a;
				a=NULL;
			}
			a=name.cut('=');
			if (strcmp(a,n)==0)
			{
				delete a;
				return 1;
			}
			else if (a!=NULL)
			{
				delete a;
				a=NULL;
			}
		}
		if (a!=NULL)
		{
			delete a;
		}
		return 0;
	}
	static checkMethodName(const char* n,const char* fileName)
	{
		FILE *stream;
		int i=0;
		char ch,*a;
		a=new char[1500];
		stream=fopen(fileName,"r+");//"lists.txt"
		fseek(stream,0,SEEK_SET);
		ch=fgetc(stream);
		while (ch!=EOF)
		{
			if (i>1500)
				break;
			if (ch!=-9  && ch!='\n')
				a[i++]=ch;
			ch=fgetc(stream);
		}
		a[i]='\0';
		fclose(stream);
		Parser *pr=new Parser();
		ParseEvent *pe;
		pr->setXMLReader(a);
		delete a;
		Str name,t;
		Str list;
		pe=pr->read();
		name=pe->getName();
		while (name!=SOAPDeserialize::PROVIDER)
		{
			pe=pr->read();
			name=pe->getName();
		}
		pe=pr->read();
		name=pe->getName();
		while (name!=SOAPDeserialize::PROVIDER)
		{
			list+=name.getStr();
			list+=Xml::SP_S;
			pe=pr->read();
			name=pe->getName();
			while (t!=name.getStr())
			{
				pe=pr->read();
				t=pe->getName();
			}
			pe=pr->read();
			name=pe->getName();
		}
		delete pr;
		while (list.getSize()>0)	{
			a=list.cut(' ');
			if (strcmp(a,n)==0)		{
				delete a;
				return 1;
			}else if (a!=NULL)
			{
				delete a;
				a=NULL;
			}
		}
		if (a!=NULL)
		{
			delete a;
		}
		return 0;
	}
};
#endif