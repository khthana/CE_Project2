#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <iostream.h>
int main(void)
{
    //char string[10];
    //char *str1 = "hit";
    char *de="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http:////schemas.xmlsoap.org//soap//envelope/\" xmlns:xsi=\"http://www.w3.org/1999//XMLSchema-instance\" xmlns:xsd=\"http:////www.w3.org//1999//XMLSchema\">";
    /*char *s="";
    char c='h';
    clrscr();
    strcpy(string,s);
    puts(string);
    strcat(string,str1);
    puts(string);
    s="wi";
    strcat(string,s);
    puts(string);*/
    char *p[20];
	char pi[200];
	for (int i=0;i<20 ;i++ )
	{
		p[i]=new char[strlen(de)];
		strcpy(p[i],de);
		cout<<p[i]<<endl;
		if(i==19)
		{
			cout<<"Hello test\n";
			strcpy(pi,p[i]);
			cout<<pi<<endl;

		}
	}
	for (i=0;i<20 ;i++ )
	{
		delete p[i];
	}

    return 0;
}