#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "Xml.h"
int main()
{
	char s[300],s1[300],*ptr,*ptr2;
	strcpy(s,"<hit value=\"1\">name<&sur\"</hit>");
	ptr=s;
	clrscr();
	puts(ptr);
	cout<<"en :\n";
	char *hit;
	hit=Xml::encode(s);
	//strcpy(s,x1.encode(s));
	puts(hit);
	strcpy(s,"<hit value=\"1\">name<&sur\"</hit>");
	delete hit;
	hit=Xml::encode(s,0);
	//strcpy(s,x1.encode(s,0));
	puts(hit);
	delete hit;
	strcpy(s,"<hit value=\"1\">name<&sur\"</hit>");
	hit=Xml::encode(s,1);
	//strcpy(s,x1.encode(s,1));
	puts(hit);
	delete hit;
	strcpy(s,"<hit value=\"1\">name<&sur\"</hit>");
	hit=Xml::quote(s);
	//strcpy(s,x1.quote(s));
	puts(hit);
	strcpy(s1,hit);
	delete hit;
	/*strcpy(s,"<hit value=\"1\">name<&sur\"</hit>");
	strcpy(s,x1.encode(s,3));
	puts(hit);*/
	cout<<s1<<" will decode to origin\n";
	hit=Xml::decode(s1);
	//strcpy(s,x1.decode(s1));//hit=x1.decode(s);
	cout<<"de :";puts(hit);
	delete hit;
	return 0;
}
