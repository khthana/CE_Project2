//Except.cpp
#include <string.h>
#include "Except.h"
const char* Exception::AN="An '";
const char* Exception::ELEM_MUST_CON="' element must contain a ";
const char* Exception::CHILD_ELEM="child element.";
char* Exception::noChildinBody()
{
	//"An '" + Constants.Q_ELEM_BODY +"' element must contain a "+"child element.");
	char *temp;
	temp=new char[120];
	strcpy(temp,NULL);
	strcat(temp,Exception::AN);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::BODY);
	strcat(temp,Exception::ELEM_MUST_CON);
	strcat(temp,Exception::CHILD_ELEM);
	strcat(temp,NULL);
	return temp;
}