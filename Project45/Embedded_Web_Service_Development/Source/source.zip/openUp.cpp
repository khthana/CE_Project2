#include<conio.h>
#include<stdio.h>
#include<io.h>
#include<string.h>
#include<fcntl.h>
#include<stdlib.h>
#include"am186cc.h"
#include"Str.h"
#include<dos.h>
#define _MaxBuffer_ 2000
#define _MaxStrLen_ 200
#define _MaxParaNum_ 20
#define _MaxOutputMessage_ 1000
#define _HomeDir_ "."
#define _MaxCon_ 5

#ifdef __cplusplus
extern "C" {
#endif
#include <tcp.h>
#ifdef __cplusplus
}
#endif

typedef unsigned char BYTE;
typedef unsigned int WORD;

class PIO {
  public:
  unsigned char Data ;
  void initPIO(void) ;
  unsigned char getBit(unsigned char bitnum) ;
  void setBit(unsigned char bitnum) ;
  void clearBit(unsigned char bitnum) ;
  void setAll(void) ;
  void clearAll(void) ;
} ;

PIO MyPIO ;

//------------------------------------------------------
unsigned char PIO::getBit(unsigned char bitnum) {
  if ((Data & (1<<bitnum)) >0) {
    return 1 ;
  } else {
    return 0 ;
  }
}
//------------------------------------------------------
void PIO::initPIO(void){
  unsigned int temp ;
  // set mode to 1 for bit 38-45 -> output pio
  temp = inport(PIOMODE2) ;
  temp = temp | 0x3fc0 ;
  outport(PIOMODE2, temp) ;
  // set mode to 0 for bit 38-45 -> output pio
  temp = inport(PIODIR2) ;
  temp = temp & ~0x3fc0 ;
  outport(PIODIR2, temp) ;
  Data = inport(PIODATA2) >> 6 ;
}
//------------------------------------------------------
void PIO::setAll(void) {
  unsigned int temp ;
  temp = inport(PIODATA2) ;
  temp = temp | 0x3fc0 ;
  outport(PIODATA2, temp) ;
  Data = 0xff ;
}
//------------------------------------------------------
void PIO::clearAll(void){
  unsigned int temp ;
  temp = inport(PIODATA2) ;
  temp = temp & ~0x3fc0 ;
  outport(PIODATA2, temp) ;
  Data = 0x00 ;
}
//------------------------------------------------------
void PIO::setBit(unsigned char bitnum) {
  unsigned int temp ;
  temp = inport(PIODATA2) ;
  switch (bitnum) {
    case 0 : temp = temp | 0x0040 ; break ;
    case 1 : temp = temp | 0x0080 ; break ;
    case 2 : temp = temp | 0x0100 ; break ;
    case 3 : temp = temp | 0x0200 ; break ;
    case 4 : temp = temp | 0x0400 ; break ;
    case 5 : temp = temp | 0x0800 ; break ;
    case 6 : temp = temp | 0x1000 ; break ;
    case 7 : temp = temp | 0x2000 ; break ;
  }
  outport(PIODATA2, temp) ;
  Data = temp >> 6 ;
}
//------------------------------------------------------
void PIO::clearBit(unsigned char bitnum) {
  unsigned int temp ;
  temp = inport(PIODATA2) ;
  switch (bitnum) {
    case 0 : temp = temp & ~0x0040 ; break ;
    case 1 : temp = temp & ~0x0080 ; break ;
    case 2 : temp = temp & ~0x0100 ; break ;
    case 3 : temp = temp & ~0x0200 ; break ;
    case 4 : temp = temp & ~0x0400 ; break ;
    case 5 : temp = temp & ~0x0800 ; break ;
    case 6 : temp = temp & ~0x1000 ; break ;
    case 7 : temp = temp & ~0x2000 ; break ;
  }
  outport(PIODATA2, temp) ;
  Data = temp >> 6 ;
}
//------------------------------------------------------

class Temperature {
  public:
    unsigned char Temperature ;
    void initTemperatureSensor(void) ;
    int getTemperature(unsigned char SensorNum) ; // 0, 1
} ;

Temperature MyTemp ;

//------------------------------------------------------
int Temperature::getTemperature(unsigned char SensorNum) {
  if (SensorNum==0) {
    return inportb(0x4000) ;
  } else if (SensorNum==1) {
    return inportb(0x4001) ;
  } else {
    return 0 ;
  }
}

//------------------------------------------------------
void Temperature::initTemperatureSensor(void) {
  outportb(0x4003, 0x9b) ;
}

//------------------------------------------------------
void InitSerial() 
{
	
	WORD SysconRegister ;
	WORD PIOMODE1Register, PIODIR1Register ;
	
	/* initital Serial Control Register -> Parity and Stop bit*/
	/* Parity = none , stop bit = 1*/
	
	outport(HSPCON0, 0x60) ;
	
	/* initial Serial Baudrate Divisor Register */
	/* Baudrate = 57600 bps */
	
	outport(HSPBDV, 0x1a) ;

}

//------------------------------------------------------
char ReadChar(void) 
{
	WORD SPSTATRegister ;
	
	/* wait for ready to recieve*/
	do 
	{
	  SPSTATRegister = inport(HSPSTAT) ;
	  /* check RDR bit */
	  SPSTATRegister = SPSTATRegister & 0x0080 ;
	}while (SPSTATRegister<=0);
	return inport(HSPRXD) ;
}

//------------------------------------------------------
char TestIncomeData(void) 
{
	/* check RDR bit */
	if ((inport(HSPSTAT)&0x0080)>0) 
	{
	  return inport(HSPRXD) ;
	} 
	else 
	{
	  return 0 ;
	}
}

//------------------------------------------------------
void SendChar(char sout)
{
	WORD SPSTATRegister ;
	/* wait for ready to send*/
	do 
	{
	  SPSTATRegister = inport(HSPSTAT) ;
	  /* check THRE bit*/
	  SPSTATRegister = SPSTATRegister & 0x0040 ;
	} while (SPSTATRegister<=0);
	outport(HSPTXD, sout) ;
	/* wait for sending completion  */
	do 
	{
	  SPSTATRegister = inport(HSPSTAT) ;
	  /* check TEMT bit */
	  SPSTATRegister = SPSTATRegister & 0x0004 ;
	} while (SPSTATRegister<=0) ;
}

//------------------------------------------------------
void SendString(char * souts) 
{
	int i ;
	for(i=0;i<strlen(souts);i++)
	{
	  SendChar(souts[i]) ;
	}
}
void writeOutput(int t)
{
	FILE *stream;
	stream = fopen("out1.txt","w+");
	fseek(stream,0,SEEK_SET);
	if (t==1)
		fprintf(stream,"1.0\n");
	else
		fprintf(stream,"2.0\n");
	printf("xom");
	fclose(stream);
}

//------------------------------------------------------
void main(void) {

	const char *f1o="fan1open";
	const char *f2o="fan2open";
	const char *f3o="fan3open";
	const char *f4o="fan4open";
	const char *f1c="fan1close";
	const char *f2c="fan2close";
	const char *f3c="fan3close";
	const char *f4c="fan4close";
	const char *l1o="light1open";
	const char *l2o="light2open";
	const char *l3o="light3open";
	const char *l4o="light4open";
	const char *l1c="light1close";
	const char *l2c="light2close";
	const char *l3c="light3close";
	const char *l4c="light4close";
	const char *oall="openall";
	const char *call="closeall";
	const char *PLUS_M="plus";
	char* input;
	unsigned char count_data;
	int count[8];
	int toggle[8];
	int i;

//	MyTemp.initTemperatureSensor() ;
	MyPIO.initPIO() ;
	InitSerial() ;

//	printf("Temp : %d\n", MyTemp.getTemperature(1));
	//printf("Waiting for Connection...\n");
	FILE *stream;
	stream = fopen("input.txt","r+");
	fseek(stream,0,SEEK_SET);
	char ch,*a;i=0;
	a=new char[200];
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>200)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		if (ch=='\n')
			a[i++]=';';
		ch=fgetc(stream);
	}
	a[i++]=';';
	a[i]='\0';
	Str set=a;
	delete a;
	const char *ON_L="7";
	const char *CLOSE_L="9";
	const char *L1="1";
	const char *L2="2";
	const char *L3="3";
	const char *L4="4";

	input=set.cut(';');
	char *lof=set.cut('.');
	set.deleteTo(';');
	char *num=set.cut('.');
	printf("lof=%s num=%s\n",lof,num);
	//if (strcmp(input,PLUS_M)==0)
	//{		
//		
		if ((strcmp(lof,ON_L)==0)&&(strcmp(num,L1)==0))
		{
//			printf("On Light No. 1\n");
			MyPIO.setBit(4);
			writeOutput(1);
		}else if ((strcmp(lof,ON_L)==0)&&(strcmp(num,L2)==0))
		{
//			printf("On Light No. 2\n");
			MyPIO.setBit(5);
			writeOutput(1);
		}else if ((strcmp(lof,ON_L)==0)&&(strcmp(num,L3)==0))
		{
//			printf("On Light No. 3\n");
			MyPIO.setBit(6);
			writeOutput(1);

		}else if ((strcmp(lof,ON_L)==0)&&(strcmp(num,L4)==0))
		{
//			printf("On Light No. 4\n");
			MyPIO.setBit(7);
			writeOutput(1);

		}else if ((strcmp(lof,CLOSE_L)==0)&&(strcmp(num,L1)==0))
		{
//			printf("Off Light No. 1\n");
			MyPIO.clearBit(4);
			writeOutput(1);

		}else if ((strcmp(lof,CLOSE_L)==0)&&(strcmp(num,L2)==0))
		{
//			printf("Off Light No. 2\n");
			MyPIO.clearBit(5);
			writeOutput(1);

		}else if ((strcmp(lof,CLOSE_L)==0)&&(strcmp(num,L3)==0))
		{
//			printf("Off Light No. 3\n");
			MyPIO.clearBit(6);
			writeOutput(1);
		}else if ((strcmp(lof,CLOSE_L)==0)&&(strcmp(num,L4)==0))
		{
//			printf("Off Light No. 4\n");
			MyPIO.clearBit(7);
			writeOutput(1);

		}/*else if ((strcmp(lof,ON_L)==0)&&(strcmp(num,L1)==0))
		{
//			printf("Off All\n");
			MyPIO.clearAll();
			writeOutput(1);

		}else if ((strcmp(lof,ON_L)==0)&&(strcmp(num,L1)==0))
		{
//			printf("On All\n");
			MyPIO.setAll();
			writeOutput(1);

		}*/
		else if ((strcmp(num,L1)==0)||(strcmp(num,L2)==0)||(strcmp(num,L3)==0)||(strcmp(num,L4)==0))
		{
			MyPIO.setBit(4);
			writeOutput(1);
		}
		else{
			writeOutput(0);
		}

	/*}else {
		writeOutput(0);
	}*/
	delete input;
	delete lof;
	delete num;
}