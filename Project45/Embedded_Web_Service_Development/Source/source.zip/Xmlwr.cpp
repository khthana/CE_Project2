// package de.embeddedXML.io
// import de.kxml.*;
// file name: Xmlwriter.cpp

#include <string.h>
#include <stdlib.h>
#include "Xmlwr.h"
//#include "Prefix.h"
XMLWriter::XMLWriter()
{
	/*indent
	= {'\r', '\n', 
	   ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	   ' ', ' ', ' ', ' ',  ' ', ' ', ' ', ' ',
	   ' ', ' ', ' ', ' ',  ' ', ' ', ' ', ' '};*/
	char *s="\r\n                        ";
	strcpy(indent,s);
	strcpy(writer,NULL);
	//temp=NULL;
	//prefixMap = new PrefixMap();
	pending=0;
	indentLevel=0;
	noIndent=32,767;
}
XMLWriter::XMLWriter(const char *w)
{
	/*indent
	= {'\r', '\n', 
	   ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', 
	   ' ', ' ', ' ', ' ',  ' ', ' ', ' ', ' ',
	   ' ', ' ', ' ', ' ',  ' ', ' ', ' ', ' '};*/
	char *s="\r\n                        ";
	strcpy(indent,s);
	strcpy(writer,w);
	//temp=NULL;
	//prefixMap = new PrefixMap();
	pending=0;
	indentLevel=0;
	noIndent=32,767;
}

void XMLWriter::checkPending () // throws IOException protected 
{
	if (pending==1)
	{
		/*char *s;
		s=">";*/
		strncat(writer,Xml::GT_S,1);
		pending=0;
	}
}
void XMLWriter::write (char c) // throws IOException
{
	checkPending();
	if (noIndent>indentLevel)
		noIndent=indentLevel;
	switch (c) {
	case '<': strncat(writer,Xml::LT,4); break;
	case '>': strncat(writer,Xml::GT,4); break;
	case '&': strncat(writer,Xml::AMP,5); break;
	default: char*s; s=&c; strncat(writer,s,1); 
	}
}
void XMLWriter::write (char* buf, int start, int len) // throws IOException
{
	checkPending();
	if (noIndent>indentLevel)
		noIndent=indentLevel;
	int end=start+len;
	char *ptr;
	char *s;
	s="<>&";
	do
	{
		int i=start;
		while (i<end)
		{
			ptr=strchr(s,buf[i]);
			if (strcmp(ptr,NULL)==0)
				++i;
			else
				break;
		}
		int j=i;
		int index=start;
		while (j>start )
		{
			s=&buf[index++];
			strncat(writer,s,1);
			j--;
		}
		if (i==end)
			break;
		write(buf[i]);
		start=i+1;
	}
	while (start<end);
}

void XMLWriter::writeIndent () // throws IOException
{
	int l=indentLevel+2;
	char *s;
	if (l < 2)
		l=2;
	else if (l > strlen(indent))
		l=strlen(indent);
	checkPending();
	//	writer.write ("<!-- i -->");
	for (int i=0;i<=l ;++i )
	{
		s=&indent[i];
		strncat(writer,s,1);
	}
}

void XMLWriter::writeAttribute (PrefixMap& pfM,const char* ns,const char* n,const char* v)				 // throws IOException
{
	if (strcmp(ns,NULL)==0 /*|| strcmp(ns,NO_NAMESPACE)==0*/)
	{
		writeAttribute(n,v);
	}
	else
	{
		char prefix[100];
		char*s;
		strcpy(prefix,pfM.getPrefix(ns));
		if (strcmp(prefix,NULL)==0 || strcmp(prefix,NULL)==0)
		{
			int cnt=0;
			char c[2];
			char t[5];
			do
			{
				s="p";
				strcpy(t,s);
				itoa(cnt,c,10);
				strncat(t,c,2);
				cnt++;
			}
			while (pfM.getNamespace (t) != NULL);
			s="xmlns:";
			strcpy(prefix,s);
			strcat(prefix,t);
			pfM.add(ns,t);
			writeAttribute(prefix,ns);
			strcpy(prefix,t);
		}
		s=":";
		strncat(prefix,s,1);
		strcat(prefix,n);
		writeAttribute(prefix,v);
	}
}

void XMLWriter::writeAttribute (const char* n,const char* v) // throws IOException
{
	if (pending==0)
	{
		//throw new RuntimeException("can write attr only immediately after a startTag");
	}
	char *s;
	strncat(writer,Xml::SP_S,1);
	strcat(writer,n);
	s="=\"";
	strncat(writer,s,2);
	Xml x;
	char *temp;
	temp=x.encode(v,Xml::ENCODE_QUOT);
	strcat(writer,temp);
	delete temp;
	//strcat(writer,x.encode(v,Xml::ENCODE_QUOT));
	s="\"";
	strncat(writer,s,1);
	strncat(writer,NULL,1);
}
void XMLWriter::writeStartTag (PrefixMap& pfM,const char* ns,const char* n) // throws IOException
{
	// check if namespace is default.
	char prefix[100];
	strcpy(prefix,pfM.getPrefix(ns));
	if (strcmp(prefix,NULL)==0)
	{
		if (pfM.add(NULL,ns)==0)
		strcpy(prefix,NULL);
	}
	char tag[200];
	if (strlen(prefix)==0)
	{
		strcpy(tag,n);
	}else{
		strcpy(tag,prefix);
		strncat(tag,Xml::CL_S,1);
		strcat(tag,n);
	}
	// PrefixMap oldMap = current.prefixMap;		
	writeStartTag(tag);

	// if namespace has changed, write out changes...
	// wait for second
}
/*void XMLWriter::writeStartTag (char* ns, char* n)    // throws IOException
{
	writeStartTag(NULL,ns,n);
}*/
void XMLWriter::writeStartTag (/*PrefixMap pfM,*/const char* t) // throws IOException  protected
{
	checkPending();
	if (indentLevel < noIndent) 
		writeIndent ();
	indentLevel++;
	strncat(writer,Xml::LT_S,1);
	strcat(writer,t);
	pending=1;
}
void XMLWriter::writeEndTag (const char *tag) // throws IOException
{
	indentLevel--;
	char *s;
	if (pending==1) 
	{
		s=" />";
		strncat(writer,s,3);
		pending=0;
	}
	else {
	if (indentLevel + 1 < noIndent) 
			writeIndent ();
		s="</";
		strncat(writer,s,2);
		strcat(writer,tag);
		strncat(writer,Xml::GT_S,1);
	}
	if (indentLevel + 1 == noIndent) 
		noIndent = 32676;
	//current = current.prev;
}
void XMLWriter::writeLegacy (int type,const char* content) // throws IOException
{
	checkPending ();
	char *s;
	switch (type) {
	case '-':
		s="<!--";
		strncat(writer,s,4);
		strcat(writer,content);
		s="-->";
		strncat(writer,s,3);
		break;
	case '!':
		s="<!DOCTYPE";
		strncat(writer,s,9);
		strcat(writer,content);
		s=">";
		strncat(writer,s,1);
		break;
	case '?':
		s="<?";
		strncat(writer,s,2);
		strcat(writer,content);
		s="?>";
		strncat(writer,s,2);
		break;
	}
}
void XMLWriter::writeRaw (const char* s) // throws IOException
{
	checkPending ();
	strcat(writer,s);
}