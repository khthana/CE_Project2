// package embeddedXML.parser
// import de.kxml.*; import de.kxml.io.*;
// file name: Dparser.h
#ifndef __PARSER_H
#define __PARSER_H
#include "xml.h"
#include "prefix.h"
#include "attr.h"
#include "ParseE.h"
#include "xmlr.h"
#include "StartTag.h"
#include "Legacy.h"
#include "EndDoc.h"
#include "EndTag.h"
#include "TextE.h"
//#include "PException.h"

class Parser {

    private:
	int size;
    int immediateClose;	// 0=false 1= true//boolean
	int processNamespaces;  //0=false 1=true;
	ParseEvent* next;
	ParseEvent* res;
    XMLReader reader;
    // *********waitforminute Vector qNames = new Vector ();
	Str qNames[30];//char qNames[10][100];
    StartTag startTag;
	EndTag endTag;
	EndDocument endDoc;
	LegacyEvent leg;
	TextEvent textEvent;
	PrefixMap prefixMap;
	char rootElement[40];
	//char temp[200];

	public:
	static const char* ER_TEXT;

    /** creates a new Parser based on the give reader */
	Parser()
	{
		processNamespaces=0;
		immediateClose=0;
		for (int i=0;i<30 ;i++ )
		{
			qNames[i]=NULL;
		}
		size=0;
		next=NULL;
	}
	Parser (const char* r)   // throws IOException
	{
		XMLReader r1(r);
		reader=r1;
		processNamespaces=0;
		immediateClose=0;
		for (int i=0;i<30 ;i++ )
		{
			qNames[i]=NULL;
		}
		size=0;
		next=NULL;
		res=NULL;
		read();
	}
	/*void ignoreTree (StartTag start)
	{
		while (1)
		{
			ParseEvent* event=read();
			switch (event->getType())
			{
				case START_TAG: ignoreTree ((StartTag *) event);break;
				case END_TAG:
				case END_DOCUMENT:
				return;
			}
		}
	}
	int peekType () const
	{
		return peek()->getType ();
	}
	/** tells the parser if it shall resolve namespace prefixes to
	namespaces. Default is true */
	void setProcessNamespaces (int processNs) //Boolean
	{
		processNamespaces=processNs;
	}
	void setXMLReader(const char* r)
	{
		reader.setContent(r);
		//read();
	}
	/** Convenience method for reading text content. Reads text until
        an EndTag or EndDocument is reached.  The EndTag is consumed, too.
        The concatenated text String is returned. If the
	method reaches an StartTag, an Exception is thrown */
	char* readText ()
	{
		char *temp;
		temp=new char[200];
		strcpy(temp,NULL);
		while (1==1) 
		{
			ParseEvent* event=read();
			switch (event->getType()) 
			{
				case '<'://throw new RuntimeException
				//("Illegal StartTag in readText: "+event);
					strcpy(temp,ER_TEXT);
					strcat(temp,event->getText());
					return temp;
					break;
				case 't':
					strcat(temp,event->getText());
					break;
				case '/':
				case '.':
					return temp;
			}
		}
		return temp;
	}
	/** amp is already consumed, consume incl. comma */
    const char parseCharacterEntity ();  // throws IOException

	/* precondition: &lt;!- consumed */
	LegacyEvent parseComment ();   // throws IOException

	/* precondition: &lt! consumed */ 
	LegacyEvent parseDoctype ();   // throws IOException

	TextEvent parseCData ();       // throws IOException
		
	/* precondition: &lt;/ consumed */
	EndTag parseEndTag ();		   // throws IOException

	/** precondition: <? consumed */
	LegacyEvent parsePI ();		   // throws IOException    

	StartTag parseStartTag ();	   // throws IOException

	TextEvent parseText ();		   // throws IOException

	/** precondition: &lt; consumed */
	void parseSpecial ();		   // throws IOException

    /** returns the next parse event without consuming it */
    ParseEvent* peek () const
	{
		return next;
    }
	int isRead()
	{ return reader.peek()!='\n' ? 1 : 0; }
	
	
	ParseEvent* read ();			   // throws IOException
	
    int getLineNumber () const
	{
		return reader.getLineNumber ();
    }
};
#endif