#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include "Prefix.h"
int main()
{
	clrscr();
	PrefixMap p1;
	int i;
	char *pf="prefix";
	char *ns="namesp";
	char s1[30],s2[30],s[20];
	char *st=" xsi:type=\"xsd:double\"";
	i=p1.add(st);
	if (i==0)
		printf("add complete\n");
	else if (i==-1)
		printf("buffer overflow\n");
	else if (i==2)
		printf("change ns&pf\n");
	char *st1=" xsi:type=\"xsd:string\"";
	i=p1.add(st1);
	if (i==0)
		printf("add complete\n");
	else if (i==-1)
		printf("buffer overflow\n");
	else if (i==2)
		printf("change ns&pf\n");
	printf("size = %d\n",p1.getSize());
	for (int k=0;k<p1.getSize() ;k++ )
	{
		strcpy(s2,p1.getnsMap(k));
		cout<<"Prefix: "<<s2<<endl;
		strcpy(s1,p1.getprefixMap(k));
		cout<<"NameSp: "<<s1<<endl;
	}
	return 0;
}
