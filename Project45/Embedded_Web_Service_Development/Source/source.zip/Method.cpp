//Method.cpp

#include "Method.h"

char* Method::marshall()
{
	char *temp;
	temp=new char[getLength()];
	strcpy(temp,Xml::LT_S);
	strcat(temp,Constants::NS);
	const char* s1="1";
	strcat(temp,s1);
	strcat(temp,Xml::CL_S);
	strcat(temp,name.getStr());
	
	//append response
	strcat(temp,Constants::RESPONSE);

	strcat(temp,Xml::SP_S);
	strcat(temp,Constants::XMLNS);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::NS);
	strcat(temp,s1);
	strcat(temp,Xml::EQ_S);
	strcat(temp,Xml::QU_S);
	strcat(temp,url.getStr());
	strcat(temp,Xml::QU_S);
	strcat(temp,Xml::SP_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::ENCODING_STYLE);
	strcat(temp,Xml::EQ_S);
	strcat(temp,Xml::QU_S);
	strcat(temp,encoding.getStr());
	strcat(temp,Xml::QU_S);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	
	///Parameter
	char *t;
	t=parameter.marshall();
	strcat(temp,t);
	delete t;

	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::NS);
	strcat(temp,s1);
	strcat(temp,Xml::CL_S);
	strcat(temp,name.getStr());
	strcat(temp,Xml::GT_S);
	return temp;
}
Method* Method::unmarshall(Parser* pr,ParseEvent *pe)
{
	Method *m;
	m=new Method();
	char *temp;
	int count;
	pe=pr->read();
	Str attr,name,param;
	name=pe->getName();
	m->setMethodName(name.getStr());	
	attr=pe->getAttribute();
	attr.deleteTo('"');
	temp=attr.cut('"');
	m->setMethodURL(temp);
	if (temp!=NULL)	{
		delete temp;
		temp=NULL;	
	}
	attr.deleteTo('=');
	attr.deleteTo('"');
	temp=attr.cut('"');
	m->setMethodEnc(temp);
	if (temp!=NULL)	{
		delete temp;
		temp=NULL;	
	}
	while (pr->isRead()) {
		pe=pr->read();
		temp=pe->toString();
		if ((pe->getType()==Xml::END_TAG)&&(strcmp(pe->getName(),name.getStr())==0))
			break;		
		param+=temp;
		if (temp!=NULL)	{
			delete temp;
			temp=NULL;
		}
	}
	param+=Xml::ENTER_S;
	if (temp!=NULL)	{
		delete temp;
		temp=NULL;
	}
	m->setParameter(param.getStr());
	return m;
}
