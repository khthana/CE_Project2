#include <stdio.h>
#include <conio.h>
#include "Const.h"
int main()
{
	clrscr();
	printf("%s\n",Constants::SOAP_ENV);
	printf("%s\n",Constants::XML_SOAP);
	return 0;
}
