// Address.h
#include "Str.h"
#include "Phone.h"
class Address
{
	private:
	String city_Elem;
	Phone phoneNumber_Elem;
	String state_Elem;
	String streetName_Elem;
	int streetNum_Elem;
	int zip_Elem;	
	
	public:
	Address()	{}
	Address(int st,const char* strName,const char* city,const char* state,int zip,const Phone& p)
	{
		streetNum_Elem	= st;
		streetName_Elem	= strName;
		city_Elem	= city_Elem;
		state_Elem	= state_Elem;
		zip_Elem	= zip_Elem;
		phoneNumber_Elem	= phoneNumber_Elem;
	}
};