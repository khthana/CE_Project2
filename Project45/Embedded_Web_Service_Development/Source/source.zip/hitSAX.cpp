#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <conio.h>
#include<fstream.h>
int main()
{ 
	char in[255],out[255]; 
	FILE *input,*output; 
	scanf("%s",&in); 
	input = fopen(in,"r"); 
	scanf("%s",&out);  
	output = fopen(out,"w");  
	char temp[255];  
	char result_text[255]; 
	int  result_sum[50]; 
	char *index[50];  
	int c,i,j,k;
	while((c = fgetc(input)) != EOF) 
	{  
		printf("%c",c);   
		fputc(c,output);
	}
	return 0;

}