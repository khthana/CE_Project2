#include <stdio.h>
#include <iostream.h>
#include <string.h>
#include <process.h>
#include <conio.h>
#include <stdlib.h>
#include "Str.h"
#include "Parser.h"
#include "ParseE.h"
#include "Const.h"
#include "XmlW.h"
#include "Qname.h"

const char* INT_S="xsd:int";
const char* DOUBLE_S="xsd:double";
const char* LONG_S="xsd:long";
const char* FLOAT_S="xsd:float";
const char* STRING_S="xsd:string";
//const char* CHAR__S="char* ";
const char* CHAR_S="xsd:char";
//const char* UNSIGNED_S="unsigned";
//const char* STATIC_S="static";
//const char* CONST_S="const";
int isNative(const char* s)
{
	if ((strcmp(s,INT_S)==0)||(strcmp(s,DOUBLE_S)==0)||(strcmp(s,LONG_S)==0)
		||(strcmp(s,FLOAT_S)==0)||(strcmp(s,STRING_S)==0)||(strcmp(s,CHAR_S)==0))
		return 1;
	else
		return 0;
}
int main(char **argv)//(void)
{
	clrscr();


	const char* SERVICE="service";
	const char* NAMESPACEID="namespaceid";
	const char* INPUT="input";
	const char* OUTPUT="output";
	const char* PROVIDER="provider";
	const char* MAPPING="mapping";
	const char* MAP="map";
	const char* XMLNS_X="xmlns:x";
	const char* QNAME_A="qname";
	const char* HEADERFILE="headerFile";
	const char* XSI_TYPE="xsi:type";

	FILE *stream,*value,*soap;
	const int max=1500;
	char *a,*methodname,*temp,*m_ns,ch;
	a=new char[max];
	strcpy(a,NULL);
	//char *g="getAddressFromName";
	methodname=new char[19];
	strcpy(methodname,argv[0]);
	strncat(methodname,NULL,1);
	Parser *pr;
	ParseEvent *pe;
	int i=0,nscount=1;
	stream = fopen("cal.txt", "r+");
	/* write some data to the file */
	//fprintf(stream, "%d %c %f", i, c, f);
	/////// set Data from Service Description ///////
	char *ptr1,*ptr2;
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>max)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	//close service description file
	fclose(stream);
	a[i++]='\n';
	a[i]='\0';
	printf("%s",a);
	Attribute *attr;
	Str name;
	Str output,map;
	pr=new Parser();
	pr->setXMLReader(a);
	delete a;
	pe=pr->read();
	name=pe->getName();
	if (strcmp(name.getStr(),SERVICE)==0)
	{
		m_ns=pe->getValue(NAMESPACEID);
		printf("methodNS  =%s\n",m_ns);
		name=pr->read()->getName();
		while (strcmp(name.getStr(),SERVICE)!=0)	{
			if (strcmp(name.getStr(),PROVIDER)==0)	{
				pe=pr->read();
				name=pe->getName();
				while (strcmp(name.getStr(),PROVIDER)!=0)	{
					if (strcmp(name.getStr(),methodname)==0)	{
						while (strcmp(name.getStr(),OUTPUT)!=0)  {
							name=pr->read()->getName();
						}
						pe=pr->read();
						name=pe->getName();
						while (strcmp(name.getStr(),OUTPUT)!=0)	 {
							output+=name.getStr();
							temp=pe->getValue(XSI_TYPE);
							output+=Xml::EQ_S;
							output+=temp;
							output+=Xml::SP_S;
							if (temp!=NULL)
								delete temp;
							pe=pr->read();
							name=pe->getName();
						}
						output+=Xml::ENTER_S;
					}
					while (name!=PROVIDER)
						name=pr->read()->getName();
				}
				pe=pr->read();
				name=pe->getName();
			}
			//else
				//ERROR;
			if (strcmp(name.getStr(),MAPPING)==0)	{
				pe=pr->read();
				name=pe->getName();
				while (strcmp(name.getStr(),MAPPING)!=0)
				{
					while (strcmp(name.getStr(),MAP)==0)	{
						temp=pe->getAttribute();
						map+=temp;
						map+=Xml::SM_S;
						delete temp;
						pe=pr->read();
						name=pe->getName();
						while (name!=MAP)
						{
							map+=name.getStr();
							map+=Xml::EQ_S;
							temp=pe->getValue(XSI_TYPE);
							map+=temp;
							map+=Xml::SP_S;
							if (temp!=NULL)
								delete temp;
							pe=pr->read();
							name=pe->getName();
						}
						pe=pr->read();
						name=pe->getName();
					}
					map+=Xml::ENTER_S;
				}
			}
			//tempporary 
			name=pr->read()->getName();
			//else
			//	break;&ERRROR;
		}//while service
	}//if service
	delete pr;
	cout<<"output="<<output.getStr();
	cout<<"map   ="<<map.getStr();
	getch();

	Str encodingStyle,xmlns_x,qname,headerFile,obj;
	//////output
	temp=output.cut('=');
	obj=temp;
	if (temp!=NULL)
		delete temp;
	////////////may be should or not think...
	temp=output.cut(' ');
	qname=temp;
	if (temp!=NULL)
		delete temp;
	//////map
	map.deleteTo(' ');///link to Attrhandler::getAttribute //if (i!=0) cam improve
	////may be improve by for or while loop and case
	temp=map.cut(' ');
	attr=new Attribute(temp);
	encodingStyle=attr->getValue();
	delete attr;
	if (temp!=NULL)
		delete temp;
	temp=map.cut(' ');
	attr=new Attribute(temp);
	xmlns_x=attr->getValue();
	delete attr;
	if (temp!=NULL)
		delete temp;
	temp=map.cut(' ');
	attr=new Attribute(temp);
	//if (qname==attr->getValue()) break;  ...mayz.. up I^I
	qname=attr->getValue();
	//qname.deleteTo(':');
	cout<<"qname="<<qname.getStr();
	delete attr;
	if (temp!=NULL)
		delete temp;
	temp=map.cut(';');
	attr=new Attribute(temp);
	headerFile=attr->getValue();
	delete attr;
	if (temp!=NULL)
		delete temp;

	XMLWriter x1;
	Str prefix=Constants::NS;
	temp=new char[30];
	strcpy(temp,NULL);
	itoa(nscount++,temp,10);
	prefix+=temp;
	delete temp;
//	printf("prefix=%s\n",prefix.getStr());
	name=methodname;
	name+=Constants::RESPONSE;
	x1.writeStartTag(prefix.getStr(),name.getStr());
	temp=Xml::encode(m_ns);
	delete m_ns;
	x1.writeAttribute(Constants::XMLNS,prefix.getStr(),temp);
	delete temp;
	
	x1.writeAttribute(Constants::SOAP_ENV,Constants::ENCODING_STYLE,encodingStyle.getStr());
	x1.writeStartTag(Constants::RETURN);

	temp=new char[30];
	strcpy(temp,NULL);
	itoa(nscount++,temp,10);
	prefix=Constants::NS;
	prefix+=temp;
	delete temp;
	x1.writeAttribute(Constants::XMLNS,prefix.getStr(),xmlns_x.getStr());
	qname.replaceBefore(prefix.getStr(),':');
	x1.writeAttribute(XSI_TYPE,qname.getStr());

	const char* getAdd="getAdd.exe";
	temp=new char[11];
	strcpy(temp,getAdd);
	strcat(temp,NULL);
	printf("%scalling\n",temp);
	i = spawnl(P_WAIT,temp,NULL);
	if (i==-1)
	{
		perror("Error from spawnl");
		exit(1);
	}
	//perror("EXEC:");
	if (i==-1)
	{
		perror("Error from spawnl");
      exit(1);
	}
	delete temp;
	cout<<"mapdo="<<map.getStr()<<endl;
	getch();

	value= fopen("out1.txt", "r+");
	fseek(stream,0,SEEK_SET);
	a=new char[200];
	ch=fgetc(value);
	i=0;
	while (ch!=EOF)	{
		while (ch!='\n' && ch!=EOF)		{
			a[i++]=ch;
			ch=fgetc(value);
			ch= ch==-9 ? '\n' : ch;
		}
		a[i]='\0';
		temp=map.cut('=');
		ptr1=map.cut(' ');
		if (isNative(ptr1))	{
			attr=new Attribute(Constants::XSI,Constants::TYPE,ptr1);
			if (ptr1!=NULL)
				delete ptr1;
			ptr1=attr->toString();
			x1.writeTag(temp,ptr1,a);
			clrscr();
			printf("%s",x1.getWriter());
			delete attr;
		}
		if (temp!=NULL)
			delete temp;
		if (ptr1!=NULL)
			delete ptr1;
		i=0;
		ch=fgetc(value);
	}
	delete a;
	x1.closeAll();
	cout<<x1.getWriter()<<endl;
	

	
	fclose(value);

	/*<ns1:getAddressFromNameResponse xmlns:ns1="urn:AddressFetcher2" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">

<return xmlns:ns2="urn:xml-soap-address-demo" xsi:type="ns2:address">

<city xsi:type="xsd:string">West Lafayette</city>

<phoneNumber xsi:type="ns2:phone">

<areaCode xsi:type="xsd:int">765</areaCode>

<exchange xsi:type="xsd:string">494</exchange>

<number xsi:type="xsd:string">4900</number>

</phoneNumber>

<state xsi:type="xsd:string">IN</state>

<streetName xsi:type="xsd:string">University Drive</streetName>

<streetNum xsi:type="xsd:int">1</streetNum>

<zip xsi:type="xsd:int">47907</zip>

</return>

</ns1:getAddressFromNameResponse>


	delete methodname;
	/*else 
		ERRROR;	
	/* close the file */
	//printf("%d",countfile);
	
	
	return 0;
}
