#include <stdio.h>

int main()
{
	printf("Calculator was Registered\n");
	printf("List of Services\n");
	printf("1 Address\n");
	printf("2 StockQuote\n");
	printf("3 Calculator\n");

	/*printf("</ns1:minus>\n");
	printf("\n");
	printf("</SOAP-ENV:Body>\n");
	printf("</SOAP-ENV:Envelope>\n\n");
	printf("Response...\n");
	printf("HTTP/1.0 200 OK\n\r");
	printf("Content-Type: text/xml; charset=\"utf-8\"\n\r");
	printf("\n\r");
	printf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	printf("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\">\n");
	printf("<SOAP-ENV:Body>\n");
	printf("<SOAP-ENV:Fault>\n");
	printf("<faultcode>Server</faultcode>\n");
	printf("<faultstring>Input parameter mismatch with Service</faultstring>\n");
	printf("<faultactor>SOAP Request Handler</faultactor>\n");
	printf("</SOAP-ENV:Fault>\n\n");
	printf("</SOAP-ENV:Body>\n");
	printf("</SOAP-ENV:Envelope>\n");*/
	return 0;
}
