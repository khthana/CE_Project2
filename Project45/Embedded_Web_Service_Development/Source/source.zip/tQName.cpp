#include <stdio.h>
#include <conio.h>
#include "Qname.h"
int main()
{
	clrscr();
	char *hit="hit";
	char *kmi="kmitl";
	QName s1,s2(hit,NULL),s3(hit,kmi),s4(s2);
	printf("s1.uri=%s part=%s to=%s\n",s1.getNamespaceURI(),s1.getLocalPart(),s1.toString());
	printf("s2.uri=%s part=%s to=%s\n",s2.getNamespaceURI(),s2.getLocalPart(),s2.toString());
	printf("s3.uri=%s part=%s to=%s\n",s3.getNamespaceURI(),s3.getLocalPart(),s3.toString());
	printf("s4.uri=%s part=%s to=%s\n",s4.getNamespaceURI(),s4.getLocalPart(),s4.toString());
	if (s4==hit)
	{
		printf("s4==HIt\n");
	}
	else
		printf("s4!=HIt\n");
	s1.setNamespaceURI(hit);
	s1.setLocalPart(kmi);
	s2.setNamespaceURI(s1.getNamespaceURI());
	s2.setLocalPart(s1.getLocalPart());
	s4=s3;
	s3=kmi;
	printf("s1.uri=%s part=%s to=%s\n",s1.getNamespaceURI(),s1.getLocalPart(),s1.toString());
	printf("s2.uri=%s part=%s to=%s\n",s2.getNamespaceURI(),s2.getLocalPart(),s2.toString());
	printf("s3.uri=%s part=%s to=%s\n",s3.getNamespaceURI(),s3.getLocalPart(),s3.toString());
	printf("s4.uri=%s part=%s to=%s\n\n",s4.getNamespaceURI(),s4.getLocalPart(),s4.toString());
	if (s1==s2)
		printf("s1==s2\n");
	else
		printf("s1!=s2\n");
	if (s3==s4)
		printf("s3==s4\n");
	else
		printf("s3!=s4\n");
	if (s1.isUndefined())
	{
		printf("s1 Un\n");
	}
	else 
		printf("s1 De\n");
	s1.clear();
	if (s1.isUndefined())
	{
		printf("s1 Un\n");
	}
	else 
		printf("s1 De\n");
	
	//printf("%s\n",NULL);*/
	

	return 0;
}
