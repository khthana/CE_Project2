#include <stdio.h>
#include <conio.h>
#include "AttrHand.h"
int main()
{
	const char* a=" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\"";
	AttributeHandler h1(a,3),h2,hm;
	clrscr();
	printf("test=");
	puts(a);
	char *ptr;
	char *st;
	st=new char[200];
	int i;
	strcpy(st,h1.getAttribute(0));
	ptr=st;
	printf("h1.getAttribute(0)=%s \n",st);
	strcpy(st,h1.getAttribute(1));
	printf("h1.getAttribute(1)=%s\n",st);
	strcpy(st,h1.getAttribute(2));
	printf("h1.getAttribute(2)=%s\n",st);
	const char* an="xmlns:SOAP-ENV";
	ptr=h1.getValue(an);
	printf("h.getAttribute(an)=%s\n",ptr);
	delete st;
	delete ptr;
	return 0;
}
/*
AttributeHandler()	{ size=0;	}
	AttributeHandler(const char* attr,int s)
	{	setAttribute(attr,s);	}
	
	//Function
	void setAttribute(const char* a,int sizeA);
	const char* getAttribute(int index)
	{	return attributes[index].getStr();	}
	int getLength()
	{	return attributes[0].getSize()+attributes[1].getSize()+attributes[2].getSize()+attributes[3].getSize(); }
	QName* attrToQName(int index);
	const char* getAttribute(QName attrQName);
	//May be Add soon
	//function that save namespaceURI & prefix into NSStack coming soon======
	//populateNSStack
	char* marshall();
	static AttributeHandler* unmarshall(const char* src,int s);*/