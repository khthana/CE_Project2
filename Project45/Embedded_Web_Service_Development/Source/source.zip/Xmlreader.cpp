// package de.embeddedXML.io
// import 
// file name: Xmlreader.cpp

#ifndef _STRING_H
#define _STRING_H
#include <string.h>
#endif
#ifndef _XMLREADER_H
#define _XMLREADER_H
#include "Xmlreader.h"
#endif

XMLReader::XMLReader (char *r) // throws IOException
{
	strcpy(reader,r);
	read();
	next=0;
	lineNumber=0;
	columnNumber=0;
	index=0;
}

char* XMLReader::readIdentifier () // throws IOException
{
	char c,*s;
	strcpy(temp,NULL);
	while ((next >= '0' && next <= '9' && strlen(temp) > 0)
		   || (next >= 'a' && next <= 'z')
		   || (next >= 'A' && next <= 'Z')
		   || (next >= 128))
	{
		c=(char) read();
		s=&c;
		strncat(temp,s,1);
	}	
	return temp;
}
char* XMLReader::readTo (char* stopChars) // throws IOException
{
	char *ptr;
	char c,*s;
	strcpy(temp,NULL);
	while (next != -1)
	{
		c=(char)next;
		ptr=strchr(stopChars,c);
		if (strcmp(ptr,NULL)==0)
			break;
		else
		{
			c=(char) read();
			s=&c;
			strncat(temp,s,1);				
		}
	}
	return temp;
}
char* XMLReader::readTo (char stopChar) // throws IOException
{
	//char *temp;
	char c,*s;
	while (next != -1 && next != stopChar)
	{
		c=(char)read();
		s=&c;
		strncat(temp,s,1);
	}
}
int XMLReader::skipTo (char* stopChars) // throws IOException
{
	char *ptr;
	char c,*s;
	//char *temp;
	s="";
	strcpy(temp,s);
	while (next != -1)
	{
		c=(char)next;
		ptr=strchr(stopChars,c);
		if (strcmp(ptr,NULL)==0)
			break;
		else
			read();
	}
	return next;
}
char* XMLReader::readWhile (char* acceptChars) // throws IOException
{
	char *ptr;
	char c,*s;
	//char *temp;
	s="";
	strcpy(temp,s);
	while (next != -1)
	{
		c=(char)next;
		ptr=strchr(acceptChars,c);
		if (strcmp(ptr,NULL)==0)
			break;
		else
		{
			c=(char) read();
			s=&c;
			strncat(temp,s,1);				
		}
	}
	return temp;			
}
