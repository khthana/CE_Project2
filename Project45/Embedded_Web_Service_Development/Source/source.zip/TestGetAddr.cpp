//#include<tcp.h>
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
//#include"LED.h"
#define _MaxBuffer_ 2000

#ifdef __cplusplus
extern "C" {
#endif
#include <tcp.h>
#ifdef __cplusplus
}
#endif
tcp_Socket telnetsock;
char buffer[ _MaxBuffer_ ];
int status;
int len, i, a;
void clearBuffer(void) {
	for(i=0;i<_MaxBuffer_;i++) {
	 buffer[i] = 0 ;
	}
}

void myhttp(void) {
	static tcp_Socket *s;
	clearBuffer() ;
	s = &telnetsock;
	tcp_listen( s, 5555, 0L, 0, NULL, 0);
	sock_wait_established(s, 0, NULL, &status);
	sock_mode(s, TCP_MODE_BINARY) ;
	sock_wait_input(s, 0, NULL, &status) ;
	sock_fastread(s, buffer, 1000) ;
	printf("%s", buffer) ;
	clearBuffer();
	/*sock_fastread(s, buffer, 512) ;
	printf("%s", buffer) ;
	clearBuffer();*/
	
	sock_puts(s,"HTTP/1.0 200 OK\n\r");
	sock_puts(s,"Content-Type: text/xml; charset=\"utf-8\"\n\r");
	//sock_puts(s,"Content-Length: 946\n");
	//sock_puts(s,"Set-Cookie2: JSESSIONID=vj7tfo7bf1;Version=1;Discard;Path=\"/soap\"\n");
	//sock_puts(s,"Set-Cookie: JSESSIONID=vj7tfo7bf1;Path=/soap\n");
	//sock_puts(s,"Servlet-Engine: Tomcat Web Server/3.2.3 (JSP 1.1; Servlet 2.2; Java 1.4.0_01; Windows XP 5.1 x86; java.vendor=Sun Microsystems Inc.)\n");
	sock_puts(s,"\n\r");

	//sock_puts(s,"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
	sock_puts(s,"<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\">\n");
	sock_puts(s,"<SOAP-ENV:Body>\n");
	sock_puts(s,"<ns1:getAddressFromNameResponse xmlns:ns1=\"urn:AddressFetcher\" SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">\n");
	sock_puts(s,"<return xmlns:ns2=\"urn:xml-soap-address-demo\" xsi:type=\"ns2:address\">\n");
	sock_puts(s,"<city xsi:type=\"xsd:string\">Anytown</city>\n");
	sock_puts(s,"<phoneNumber xsi:type=\"ns2:phone\">\n");
	sock_puts(s,"<areaCode xsi:type=\"xsd:int\">123</areaCode>\n");
	sock_puts(s,"<exchange xsi:type=\"xsd:string\">456</exchange>\n");
	sock_puts(s,"<number xsi:type=\"xsd:string\">7890</number>\n");
	sock_puts(s,"</phoneNumber>\n");
	sock_puts(s,"<state xsi:type=\"xsd:string\">NY</state>\n");
	sock_puts(s,"<streetName xsi:type=\"xsd:string\">Main Street</streetName>\n");
	sock_puts(s,"<streetNum xsi:type=\"xsd:int\">123</streetNum>\n");
	sock_puts(s,"<zip xsi:type=\"xsd:int\">12345</zip>\n");
	sock_puts(s,"</return>\n");
	sock_puts(s,"</ns1:getAddressFromNameResponse>\n");
	sock_puts(s,"\n");
	sock_puts(s,"</SOAP-ENV:Body>\n");
	sock_puts(s,"</SOAP-ENV:Envelope>\n");

	sock_flush(s) ;

	sock_close(s) ;
	sock_wait_closed(s, 0, NULL, &status) ;

	sock_err:
	switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
			return;
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
			return;
		}
}

void main(void) {
	sock_init();
	//InitLED() ;
	myhttp() ;
	exit(0) ;

}
