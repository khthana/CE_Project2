#include <stdio.h>
#include <process.h>
#include <conio.h>
#include <string.h>
#include "Str.h"
int main()
{
	clrscr();
	//printf("Hello, world\n");
	char *hit="hit";
	char *kmi="kmitl";
	char *h;
	h=new char[20];
	strcpy(h,NULL);
	Str s1,s2(hit),s3(h),s4(s2);
	delete h;
	printf("s1=%s len=%d\n",s1.getStr(),s1.getSize());
	if(s1.isEmpty())
		printf("true\n");
	else
		printf("false\n");
	printf("s2=%s len=%d\n",s2.getStr(),s2.getSize());
	if(s2.isEmpty())
		printf("true\n");
	else
		printf("false\n");
	printf("s3=%s\n",s3.getStr());
	if(s3.isEmpty())
		printf("true\n");
	else
		printf("false\n");
	printf("s4=%s\n",s4.getStr());
	s1=s2;
	printf("s1=%s len=%d\n",s1.getStr(),s1.getSize());
	if(s1.isEqual(s2))
		printf("true\n");
	else
		printf("false\n");
	s1=kmi;
	printf("s1=%s len=%d\n",s1.getStr(),s1.getSize());
	s1+=s2;
	printf("s1=%s len=%d\n",s1.getStr(),s1.getSize());
	if (s1==s2)
	{
		printf("s1=s2:true");
	}
	else 
		printf("false");

	printf("\ntest\n");
	Str s[3];
	s[0].set(hit);
	s[1].set(kmi);
	s[2].set(hit);
	printf("s[0] = %s \n",s[0].getStr());
	printf("s[0] = %s \n",s[1].getStr());
	printf("s[0] = %s \n",s[2].getStr());
	const char* getAdd="getAdd.exe";
	char *temp=new char[11];
	strcpy(temp,getAdd);
	strcat(temp,NULL);
	printf("%scalling\n",temp);
	execv(temp,NULL);
	//perror("EXEC:");
	delete temp;

	const char *hi="xmlns:x=\"http:\\\\www.kmitl.ac.th\"";
	Str hit1=hi;
	printf("test=%s\n",hit1.getStr());
	char *h3=hit1.cut('=');
	printf("%s is cut so remain=%s\n",h3,hit1.getStr());
	hit1.replaceAfter(hit,'"');
        printf("%s",hit1.getStr());
	hit1.deleteTo('"');
	printf("%s",hit1.getStr());
	delete h3;
	
	return 0;
}
