#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "XmlW.h"
#include "Const.h"

int main()
{
	char s[300],*ptr,*ptr2;
	clrscr();
	XMLWriter x1;
	x1.writeStartTag(Constants::SOAP_ENV,Constants::ENVELOPE);
	x1.writeAttribute(Constants::XMLNS,Constants::SOAP_ENV,Constants::SOAP_ENV_URI);
	x1.writeAttribute(Constants::XMLNS,Constants::XSI,Constants::XSI1999_URI);
	Attribute attr(Constants::XMLNS,Constants::SOAP_ENV,Constants::SOAP_ENV_URI);
	ptr=attr.toString();
	x1.writeEmptyTag(Constants::SOAP_ENV,Constants::HEADER,ptr);
	delete ptr;
	x1.writeStartTag(Constants::BODY);
	x1.writeStartTag(Constants::FAULT);
	ptr="West";
	x1.write(ptr,0,strlen(ptr));
	x1.writeEndTag();
	x1.closeAll();
	strcpy(s,x1.getWriter());
	cout<<s<<endl;
	return 0;
}

//<ns1:plus xmlns:ns1="urn:xml-soap-demo-calculator" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">