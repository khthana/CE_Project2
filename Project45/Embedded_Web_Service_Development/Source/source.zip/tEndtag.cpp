#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <stdlib.h>
#include <string.h>
#include "EndTag.h"
#include "ParseE.h"
#include "StartTag.h"

int main()
{	
	clrscr();
	//PrefixMap p1;
	int i;
	//char *pf="prefix";
	char *ns="namespace";
	/*char s1[30],s2[30],s[20];
	for (int j=0;j<14;j++)
	{
		strcpy(s1,pf);
		strcpy(s2,ns);
		itoa(j,s,10);
		strcat(s1,s);
		strcat(s2,s);
		i=p1.add(s2,s1);
		if(i==0)
		{
			strcpy(s2,p1.getPrefix(s2));
			cout<<"Prefix: "<<s2<<endl;
			strcpy(s1,p1.getNamespace(s1));
			cout<<"NameSp: "<<s1<<endl;
		}
		else if(i==-1)
			cout<<"Bufferoverflow\n";
		else if(i==-2)
		{
			cout<<"Prefix can't override\n";
			continue;
		}
	}*/
	int degen=0;
	char *n="name";
	StartTag t1(ns,n,degen);
	degen=t1.getLineNumber();
	cout<<degen<<endl;
	char st[300];
	printf("string: ");
	char *tag="<arg2 xsi:type=\"xsd:double\">4.0</arg2>\r\n";
	strcpy(st,tag);
	printf("%s",st);
	XMLReader x1(st);
	StartTag t2(x1);
	char *ta1="SOAP:SOAP-ENV";
	EndTag e1(ta1);//(t2);
	char *hit;
	hit=e1.toString();
	//strcpy(st,e1.toString());
	cout<<"e1.toString()      ="<<hit<<endl;
	delete hit;
	/*strcpy(st,e1.getName());
	cout<<"e1.getName()       ="<<st<<endl;
	strcpy(st,e1.getNamespace());
	cout<<"e1.getNamespace()  ="<<st<<endl;*/
	degen=e1.getType();
	cout<<"e1.getType()       ="<<degen<<endl;
	//ParseEvent *pe;
	//degen=e1.endCheck(pe);
	//cout<<"e1.endCheck()      ="<<degen<<endl;
	e1.setError(ns);
	cout<<"e1.getError()      ="<<e1.getError()<<endl;

	return 0;
}