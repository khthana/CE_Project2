//RPCConst.h

#ifndef __RPCCONSTANTS_H
#define __RPCCONSTANTS_H

class RPCConstants
{
	public:
	static const char* ELEM_PARAMETER;
	static const char* ELEM_RETURN;
	static const char* NS;

	// Qualified element names.
	//static QName  Q_ELEM_PARAMETER = new QName(Constants.NS_URI_SOAP_ENV, ELEM_PARAMETER);
	
	// Other constants.
	static const char* RESPONSE_SUFFIX;

};
#endif