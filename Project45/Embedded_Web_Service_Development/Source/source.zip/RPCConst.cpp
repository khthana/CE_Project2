
#include "RPCConst.h"	
const char* RPCConstants::ELEM_PARAMETER = "Parameter";
const char* RPCConstants::ELEM_RETURN = "return";
const char* RPCConstants::NS="ns";
const char* RPCConstants::RESPONSE_SUFFIX = "Response";