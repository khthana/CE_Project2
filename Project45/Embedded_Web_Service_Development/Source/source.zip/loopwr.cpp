#include <stdio.h>

int main()
{
	FILE *stream;
	char* buffer="hello hit";
	char* bu="hello bu";
	stream=fopen("input1.txt","w+");
	//fseek(stream,0L,SEEK_END);
	fprintf(stream,"i%d=\n%s\n",buffer);
	fclose(stream);

	stream=fopen("input1.txt","w+");
	//fseek(stream,0L,SEEK_END);
	fprintf(stream,"i%d=\n%s\n",bu);
	fclose(stream);

	return 0;
}
