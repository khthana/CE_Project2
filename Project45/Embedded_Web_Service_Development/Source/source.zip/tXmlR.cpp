#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <iostream.h>
#include <string.h>
#include "Xmlr.h"

int main()
{
	clrscr();
	char st[300];
	printf("string: ");
	strcpy(st,"<name attr=\"27\"> hit</soap>\n");
	printf("%s",st);
	//scanf("%[^\n]",&st);
	int c;
	char cc;
	XMLReader x1(st);
	
	//int i=0;
	char *rn;
	char *hit;
	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;
	// test readN fn
	rn=x1.readN(1);
	//strcpy(rn,x1.readN(1));
	printf("%s\n",rn);
	delete rn;

	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;

	//test readIdentifier fn
	rn=x1.readIdentifier();
	//strcpy(rn,x1.readIdentifier());
	printf("%s\n",rn);
	delete rn;

	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;

	//tes peek();
	cc=(char)x1.peek();
	printf("%c",cc);

	//test skipWhitespace();
	x1.skipWhitespace();

	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;
	
	// test readTo(*char)
	char *stop;
	stop=":/\"= ";
	rn=x1.readTo(stop);
	//strcpy(rn,x1.readTo(stop));
	printf("%s\n",rn);
	delete rn;

	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;

	//test skipTo(char*)
	char *sk;
	sk="=>";
	//char next=(char)x1.skipTo(sk);
	//printf("%c",next);

	//test readWhile(char*)
	char *w;
	w="hit";
	rn=x1.readWhile(w);
	//strcpy(rn,x1.readWhile(w));
	printf("%s\n",rn);
	delete rn;

	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;
	
	// test readTo(char)
	rn=x1.readTo('o');
	//strcpy(rn,x1.readTo('o'));
	printf("%s\n",rn);
	delete rn;

	hit=x1.getContentNotRead();
	printf("%s",hit);
	delete hit;

	// test read() & eof()
	int e=x1.eof();
	while (e != 1)
	{
		c=x1.read();
		cc=(char)c;
		printf("%c",cc);//cout<<cc;
		e=x1.eof();
		//i++;
		//if(i==400)
		  // break;
	}
	
	//cout<<"st:";cin>>st;
	//XMLReader x2(st);
	return 0;
}
