//Body.cpp
#include <stdio.h>
#include "Body.h"

char* Body::marshall()
{
	char* temp;
	temp=new char[getLength()+50];
	//<SOAP-ENV:Body
	strcpy(temp,Xml::LT_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::BODY);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	char *t;
	//marshall Methods
	t=method.marshall();
	strcat(temp,t);
	delete t;

	//marshall bodyEntries
	if (bodyEntries.getSize() > 0)
	{
		strcat(temp,bodyEntries.getStr());
	}
	//</SOAP-ENV:Body>
	//strcat(temp,Xml::ENTER_S);
	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::BODY);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	return temp;
}
Body* Body::unmarshall(Parser* pr,ParseEvent *pe)
{
	Body *b;
	b=new Body();
	char *temp;
	int count;
	char bodyTag[14];
	strcpy(bodyTag,Constants::SOAP_ENV);
	strcat(bodyTag,Xml::CL_S);
	strcat(bodyTag,Constants::BODY);
	strcat(bodyTag,NULL);
	Method *m;
	m=Method::unmarshall(pr,pe);
	b->setMethod(*m);
	delete m;
	pe=pr->read();
	if ((pe->getType()!=Xml::END_TAG)&&(strcmp(pe->getName(),bodyTag)!=0))
	{
		b->setError(Constants::BODY);
	}
	return b;
}