// SoapEnc.cpp

#include "SoapEnc.h"

char* SoapEncoding::typeToSoap()
{
	char *soap;
	soap=new char[200];
	FILE *
}
