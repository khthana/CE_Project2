// package embeddedXML.parser
// import de.kxml.*;
// file name: EndDoc.h
/** the END_DOCUMENT event */
#ifndef	__ENDDOCUMENT_H
#define __ENDDOCUMENT_H
#include "xml.h"
#include "ParseE.h"

class EndDocument : public ParseEvent 
{
    /** returns END_DOCUMENT */
	private:
	Str error;
	public:
	EndDocument()			{ ParseEvent::ParseEvent(); }
	~EndDocument()			{ }
	EndDocument& operator= (const EndDocument& value)
	{
		//lineNumber=value.getLineNumber();
		error.set(value.getError());
		return *this;
	}
    int getType() const		{ return Xml::END_DOCUMENT; }

	//pure function;
	char* getAttribute() const { return NULL; }
	const char* getName() const { return NULL; }
	const char* getNamespace () const { return NULL; }
	char* getValue (const char* attrname) const { return NULL; }
	const char* getText () const { return NULL; }
	int getCountAttr() const { return 0; }
	const char* getAttribute (int index) const { return NULL; }

	int endCheck(ParseEvent* start)//0=false 1=true
	{
		if (start != NULL)
		{
			//throw new RuntimeException ("Unexpected end of document");
			char *s="Unexpected end of document";
			setError(s);
			return 0;//return false
		}
		return 1;//return true
    }
	void setError(const char* e)	{ error.set(e); }
	const char* getError()const		{ return error.getStr(); }
	char* toString ()	{ return NULL; }

};
#endif