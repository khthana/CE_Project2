//Except.h

#ifndef __EXCEPTION_H
#define __EXCEPTION_H
#include "Const.h"
#include "Xml.h"
//#include "

class Exception
{
	public:
	static const char* ELEM_MUST_CON;
	Exception()		{}
	static char* noChildinBody()
	
};
#endif