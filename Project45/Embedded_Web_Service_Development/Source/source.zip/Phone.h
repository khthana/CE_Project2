//Phone.h
#include "Str.h"
class Phone
{
	private:
	int areaCode_Elem;
	Str exchange_Elem;
	Str number_Elem;
	public:
	Phone()	{}
	Phone(int a,const char* ex,const char* num)	{
		areaCode_Elem	= a;
		exchange_Elem	= ex;
		number_Elem	= num;
	}
};