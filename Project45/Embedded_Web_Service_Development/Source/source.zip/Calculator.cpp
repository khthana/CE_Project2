#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "Str.h"
int main()
{
	const char* PLUS="plus";
	const char* MINUS="minus";
	const char* TIMES="times";
	const char* DIVIDE="divide";

	FILE *stream;
	stream = fopen("input.txt","r+");
	fseek(stream,0,SEEK_SET);
	char ch,*a;int i=0;
	a=new char[200];
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>200)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		if (ch=='\n')
			a[i++]=';';
		ch=fgetc(stream);
	}
	a[i++]=';';
	a[i]='\0';
	fclose(stream);
	Str in=a;
	delete a;
	a=in.cut(';');
	char *b,*s;
	float p1,p2;
	s=in.cut(';');
	b=in.cut(';');
	p1=atof(s);
	p2=atof(b);
	delete s;
	delete b;
	if (strcmp(a,PLUS)==0)	{
		delete a;
		p1+=p2;
	}
	else if (strcmp(a,MINUS)==0)	{
		delete a;
		p1-=p2;
	}
	else if (strcmp(a,TIMES)==0)	{
		delete a;
		p1*=p2;
	}
	else if (strcmp(a,DIVIDE)==0)	{
		delete a;
		p1/=p2;
	}
	else
		p1=0.0;
	stream = fopen("out1.txt","w+");
	fseek(stream,0,SEEK_SET);
	fprintf(stream,"%f\n",p1);
	fclose(stream);
	
	return 0;
}
