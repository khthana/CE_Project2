// package embeddedXML
// file name : Attr.h
#ifndef __ATTR_H
#define __ATTR_H

class Str
{
	private:
    char *str;

	public:
	//Constructor
	Str ()
	{
		str=NULL;
	}
	Str (const char *string);
	{
		toDelete();
		str=new char[strlen(string)+1];
		strcpy(str,string);
		strncat(str,NULL,1);
	}
	Str (const Str& value)
	{
		toDelete();
		str=new char[strlen(value.getStr())+1];
		strcpy(str,value.getStr());
		strncat(str,NULL,1);
	}
	~Str()
	{
		toDelete();
	}

	//overload operator
	SOAPQName& operator=(const SOAPQName& that)
	
	//function
	void toDelete()
	{
		if (str!=NULL)
			delete str;
	}
	const char* getStr () const
	{
		return str;
	}
};
#endif