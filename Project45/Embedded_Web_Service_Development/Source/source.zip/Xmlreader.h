// package de.embeddedXML.io
// import
// file name: Xmlread.h
#ifndef _READER_CONST
#define _READER_CONST
#define BUF_R 3000
#endif
class XMLReader 
{
    private:
	char reader[BUF_R];
    int next;
    int lineNumber;
    int columnNumber;
	int index;
	//local var want to save data
	char temp[300];
	
	public:
	XMLReader (char *r); // throws IOException
	~XMLReader()
	{
		delete reader;
		delete temp;
	}
	//void close () // throws IOException

	/** returns true when the end of the stream is reached */
	int eof () //0=false 1=true
	{
		if (next == -1)
			return 1;
		else
			return 0;
	}
	int getLineNumber ()
	{
		return lineNumber;
	}
	int getColumnNumber ()
	{
		return columnNumber;
	}
	/** skips unicode whitespace chars */
	void skipWhitespace () // throws IOException
	{
		while (next != -1 && next <= 32) 
			read ();
	}

	int read (char* buf, int off, int len) // throws IOException
	{
		int ok=0;
		while (ready()==1 && ok < len)
		{
			int i=read();
			if (i== -1)
				break;
			buf[off++]=(char) i;
			ok++;			
		}
		return ok;
	}
	char* readN (int count) // throws IOException
	{
		char *b;
		b=new char [count];
		read(b,0,count);
		return b;
	}
	
	//int ready() // throws IOException 0=false 1=true
	char* readIdentifier (); // throws IOException

	/** reads a String until any of the given stopChars is reached.
	The stopChar itself is not consumed */
	char* readTo (char* stopChars); // throws IOException

	char* readTo (char stopChar); // throws IOException
	int skipTo (char* stopChars); // throws IOException
	char* readWhile (char* acceptChars); // throws IOException
	int peek ()
	{
		return next;
	}
	int read () // throws IOException
	{
		int result = next;

		if (next != -1) {
			//try {
			next = reader[index];
			/*}
			catch (IOException e) {
			throw new ParseException (e, this);
			}*/
		}

		if (next == 10) {
			lineNumber++;
			columnNumber = 0;
		}
		else columnNumber++;

		return result;
	}
};