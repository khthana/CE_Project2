// package
// file name : Const.cpp
#include "Const.h"
// Namespace prefixes.
const char* Constants::XMLNS    = "xmlns";
const char* Constants::SOAP     = "SOAP";
const char* Constants::SOAP_ENV = "SOAP-ENV";
const char* Constants::SOAP_ENC = "SOAP-ENC";
const char* Constants::XSI      = "xsi";
const char* Constants::XSD      = "xsd";


// Namespace URIs.
const char* Constants::XMLNS_URI    = "http://www.w3.org/2000/xmlns/";
const char* Constants::SOAP_ENV_URI = "http://schemas.xmlsoap.org/soap/envelope/";
const char* Constants::SOAP_ENC_URI = "http://schemas.xmlsoap.org/soap/encoding/";
const char* Constants::XSI1999_URI  = "http://www.w3.org/1999/XMLSchema-instance";
const char* Constants::XSD1999_URI  = "http://www.w3.org/1999/XMLSchema";
const char* Constants::XSI2000_URI  = "http://www.w3.org/2000/10/XMLSchema-instance";
const char* Constants::XSD2000_URI  = "http://www.w3.org/2000/10/XMLSchema";
const char* Constants::XSI2001_URI  = "http://www.w3.org/2001/XMLSchema-instance";
const char* Constants::XSD2001_URI  = "http://www.w3.org/2001/XMLSchema";

const char* Constants::XML_SOAP			  = "http://xml.apache.org/xml-soap";
const char* Constants::XML_SOAP_DEPLOYMENT= "http://xml.apache.org/xml-soap/deployment";
const char* Constants::LITERAL_XML		  = "http://xml.apache.org/xml-soap/literalxml";
const char* Constants::XMI_ENC			  = "http://www.ibm.com/namespaces/xmi";

// HTTP header field names.
const char* Constants::POST				= "POST";
const char* Constants::HOST				= "Host";
const char* Constants::CONTENT_TYPE		= "Content-Type";
const char* Constants::CONTENT_TYPE_JMS	= "ContentType";
const char* Constants::CONTENT_LENGTH	= "Content-Length";
const char* Constants::CONTENT_LOCATION	= "Content-Location";
const char* Constants::CONTENT_ID		= "Content-ID";
const char* Constants::SOAP_ACTION		= "SOAPAction";
const char* Constants::AUTHORIZATION	= "Authorization";
const char* Constants::PROXY_AUTHORIZATION= "Proxy-Authorization";

// HTTP header field values.
const char* Constants::DEFAULT_CHARSET	= "iso-8859-1";
const char* Constants::CHARSET_UTF8		= "utf-8";
const char* Constants::CONTENT_TYPE_V	= "text/xml";
const char* Constants::CONTENT_TYPE_UTF8= "text/xml;charset=utf-8";

// XML Declaration char*
const char* Constants::XML_DECL = "<?xml version='1.0' encoding='UTF-8'?>\r\n";

// Element names.
const char* Constants::ENVELOPE			= "Envelope";
const char* Constants::BODY				= "Body";
const char* Constants::HEADER			= "Header";
const char* Constants::FAULT			= "Fault";
const char* Constants::FAULT_CODE		= "faultcode";
const char* Constants::FAULT_STRING		= "faultstring";
const char* Constants::FAULT_ACTOR		= "faultactor";
const char* Constants::DETAIL			= "detail";
const char* Constants::FAULT_DETAIL_ENTRY= "detailEntry";
// RPC Constants
const char* Constants::PARAMETER = "Parameter";
const char* Constants::RETURN = "return";
const char* Constants::RESPONSE = "Response";
const char* Constants::NS="ns";
// Qualified element names.
/*const char* Q_ENVELOPE	="SOAP-ENV:Envelope";
const char* Q_HEADER	="SOAP-ENV:Header";
const char* Q_BODY		="SOAP-ENV:Body";
const char* Q_FAULT	="SOAP-ENV:Fault";
const char* Q_ACTOR	="SOAP-ENV:actor";*/

// Attribute names.
const char* Constants::ENCODING_STYLE	= "encodingStyle";
const char* Constants::MUST_UNDERSTAND	= "mustUnderstand";
const char* Constants::TYPE				= "type";
const char* Constants::A_NULL			= "null";
const char* Constants::NIL				= "nil";
const char* Constants::ARRAY_TYPE		= "arrayType";
const char* Constants::REFERENCE		= "href";
const char* Constants::ID				= "id";

// Qualified attribute names.
//const char* Q_MUST_UNDERSTAND = "SOAP-ENV:mustUnderstand";

// Attribute values.
const char* Constants::TRUE = "true";

// SOAP defined fault codes.
const char* Constants::VERSION_MISMATCH	= "VersionMismatch";
const char* Constants::MUST_UNDERSTAND_F= "MustUnderstand";
const char* Constants::CLIENT			= "Client";
const char* Constants::SERVER			= "Server";
const char* Constants::PROTOCOL			= "Protocol";

// XML-SOAP implementation defined fault codes.
const char* Constants::BAD_TARGET_OBJECT_URI = ".BadTargetObjectURI";

// Error messages.
const char* Constants::ERR_MSG_VERSION_MISMATCH = 
		"SOAP-ENV:VersionMismatch: Envelope element must be associated with the 'SOAP-ENV' namespace.";
const char* Constants::ERR_BODYTAG="Body must have in Envelope";