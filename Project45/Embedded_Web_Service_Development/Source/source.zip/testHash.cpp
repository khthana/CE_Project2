//#include <iostream.h>
#include "hash.cpp"
//#include<bag.h>

void main ()
{
	HashTable h;
	HASH* ptrh1=new HASH("Hit",27);
	HASH* ptrh2=new HASH("Pop",23);
	HASH* ptrh3=new HASH("bit",28);
	
	h.add(*ptrh1);
	h.add(*ptrh2);
	h.add(*ptrh3);

	cout<<"\nContests of : ";
	h.printOn(cout);

	HASH testHash=(HASH&)h.findMember(*ptrh2);
	if (testHash==NOOBJECT)
	{
		cout<<"\nCan't find Hash";
	}else{
		cout<< "\nFound Hash: ";
		testHash.printOn(cout);
		h.detach(testHash);
	}
	cout<<"\n\nContests of:";
	h.printOn(cout);
}
