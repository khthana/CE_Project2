// package embeddedXML.parser
// import
// file name: Legacy.h
/** Class for ProcessingInstructions and Comments */
#ifndef __LEGACY_H
#define __LEGACY_H
#include <string.h>
#include "ParseE.h"
class ParseException : public ParseEvent
{
	private:
	Str error;
	
	/** creates a new ParseException with the given type and string content */
	public:
	ParseException()	{ }
	ParseException(const char* error1)	{ error.set(error1); }
	~ParseException()	{ }
	ParseException& operator= (const ParseException& value)
	{
		type=value.getType();
		error.set(value.getError());
		return *this;
	}
	int getType()  const
	{
		int c=(char)'e';
		return c;
	}
	/** returns always false.  */
	int endCheck(ParseEvent* start)		{ return 0; }// 0=false 1=true
	const char* getError() const		{ return error.getStr(); }
	void setError(const char* e)		{ error.set(e); }
};
#endif