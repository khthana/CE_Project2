// package embeddedXML.parser
// import
// file name: Legacy.h
/** Class for ProcessingInstructions and Comments */
#ifndef __LEGACY_H
#define __LEGACY_H
#include <string.h>
#include "ParseE.h"
class ParseException : public ParseEvent
{
	private:
	char *error;
	
	/** creates a new ParseException with the given type and string content */
	public:
	ParseException()
	{
		error=NULL;
	}
	ParseException(const char* error1)
	{
		error=new char[strlen(error1)];
		strcpy(error,error1);
	}
	~ParseException()
	{
		delete error;
	}
	ParseException& operator= (const ParseException& value)
	{
		type=value.getType();
		if (error!=NULL)
			delete error;
		error=new char[strlen(value.geterror())];
		strcpy(error,value.geterror());
		return *this;
	}
	int getType()  const
	{
		int c=(char)'e';
		return c;
	}

	/** returns always false.  */
	int endCheck(ParseEvent* start)
	{
		return 0; // 0=false 1=true
	}
	const char* getError() const
	{
		return error;
	}
	void setError(const char* e)
	{
		if (error!=NULL)
			delete error;
		error = new char[strlen(e)];
		strcpy(error,e);
	}
};
#endif