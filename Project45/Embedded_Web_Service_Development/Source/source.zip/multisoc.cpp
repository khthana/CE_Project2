#include<tcp.h>
#include<string.h>
#include<process.h>
#include<stdio.h>
#include<conio.h>
#define _MaxBuffer_ 600

tcp_Socket telnetsock[5];
int status;//,x=1,y=1;
char MyInput ;

static tcp_Socket *s[5];
void waitTelnet(void);
//long counter =100;

void mytelnetd(void) {

int i,j;

       for(j=0;j <5;j++) {
//	sock_puts(s[j],"Press <Esc> to exit\n");
	if (sock_established(s[j])) {
	  if (sock_rbused(s[j])>0)  { // if data available

		MyInput = sock_getc(s[j]) ;
//		printf("From session %d \n input is",j);
		printf("%c",MyInput);
		sock_putc(s[j],MyInput);
		sock_flush(s[j]);
		if(MyInput == 27) {
			  sock_abort(s[j]) ;
			  printf("Session %d abort \n",j);
		}

	  }
	}
      }
}

void waitTelnet() {
	int i ;
	sock_init() ;
	sock_yield(NULL, mytelnetd);

	for(i=0;i<5;i++) {
	    s[i] = &telnetsock[i] ;
	}

 // while (1==1) {

	for(i=0;i<5;i++) {
	  printf("Try to listen %d\n", i) ;
	  tcp_listen( s[i], 23, NULL, 0, NULL, 0);
	  sock_wait_established(s[i], 0, NULL, &status);
	  printf("\nSocket %d Connect \n", i) ;
	  sock_mode(s[i], TCP_MODE_BINARY) ;
/*
	  if(kbhit())
//		sock_wait_closed(soc[0], 0, NULL, &status) ;
		if(getch() ==27) break;
*/
	}
//	sock_wait_closed(soc[0], 0, NULL, &status) ;

   //	while (1==2) {
	  sock_err:
	  switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
			return;
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
			return;
		}
     //	}
 // } // forever loop
//        return NULL ;
}
void main(void) {
	waitTelnet();

}