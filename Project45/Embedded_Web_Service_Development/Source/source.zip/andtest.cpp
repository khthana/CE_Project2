#include <stdio.h>
#include <iostream.h>
#include <conio.h>

int main(int argc, char *argv[])
{
	printf("Hello, world\n");
	int i1=0;
	//int i[20];
	for (int j=0;j<20 ;j++ )
	{
		if (j&i1)
		{
			printf("true");
			cout<<j&i1<<endl;
		}
		else
		{
			printf("false");
			cout<<j&i1<<endl;
		}
	}
	return 0;
}
