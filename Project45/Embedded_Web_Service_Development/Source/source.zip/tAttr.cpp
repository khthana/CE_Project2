#include <stdio.h>
#include <iostream.h>
#include <string.h>
#include <conio.h>
#include "Attr.h"

int main()
{
	clrscr();
	char *n="name";
	char *ns="namespace";
	char *v="value";

	/*cout<<"name : ";
	cin>>n;
	cout<<"value : ";
	cin>>v;
	cout<<"namespace : ";
	cin>>ns;*/
	char s[30],*s1,*s2;
	s1="xmlns:SOAP-ENV=\"value\"";
	s2="SOAP=\"value\"";
	strcpy(s,s1);
	Attribute a1(n,v),a2,a3(ns,n,v);
	char n1[80],n2[840],n3[80],st[80];
	strcpy(n1,a1.getName());
	strcpy(n2,a1.getValue());
	strcpy(n3,a1.getNamespace());
	cout<<"name     :";
	puts(n1);
	cout<<"value    :";
	puts(n2);
	cout<<"Namespace:";
	puts(n3);
	cout<<"toString :";
	char *hit;
	hit=a1.toString();
	//strcpy(st,a1.toString());
	puts(hit);
	delete hit;

	strcpy(n1,a2.getName());
	strcpy(n2,a2.getValue());
	strcpy(n3,a2.getNamespace());
	cout<<"name     :";
	puts(n1);
	cout<<"value    :";
	puts(n2);
	cout<<"Namespace:";
	puts(n3);
	cout<<"toString :";
	hit=a2.toString();
	//strcpy(st,a1.toString());
	puts(hit);
	delete hit;

	strcpy(n1,a3.getName());
	strcpy(n2,a3.getValue());
	strcpy(n3,a3.getNamespace());
	//strcpy(st,a3.toString());
	cout<<"name     :";
	puts(n1);
	cout<<"value    :";
	puts(n2);
	cout<<"Namespace:";
	puts(n3);
	cout<<"toString :";
	hit=a3.toString();
	//strcpy(st,a1.toString());
	puts(hit);
	delete hit;

	Attribute a4(s1);
	strcpy(n1,a4.getName());
	strcpy(n2,a4.getValue());
	strcpy(n3,a4.getNamespace());
	//strcpy(st,a4.toString());
	cout<<"name     :";
	puts(n1);
	cout<<"value    :";
	puts(n2);
	cout<<"Namespace:";
	puts(n3);
	cout<<"toString :";
	hit=a4.toString();
	//strcpy(st,a1.toString());
	puts(hit);
	delete hit;

	Attribute a5(s2);
	strcpy(n1,a5.getName());
	strcpy(n2,a5.getValue());
	strcpy(n3,a5.getNamespace());
	//strcpy(st,a5.toString());
	cout<<"name     :";
	puts(n1); 
	cout<<"value    :";
	puts(n2);
	cout<<"Namespace:";
	puts(n3);
	cout<<"toString :";
	hit=a5.toString();
	//strcpy(st,a1.toString());
	puts(hit);
	delete hit;
	return 0;
}
