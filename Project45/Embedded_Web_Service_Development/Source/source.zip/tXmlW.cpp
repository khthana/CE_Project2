#include <iostream.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include "Xmlwr.h"

int main()
{
	char s[300],s1[300],*ptr,*ptr2;
	char *st="<ns1:plus xmlns:ns1=\"urn:xml-soap-demo-calculator\"";
	strcpy(s,st);
	ptr=s;
	ptr2=s1;
	clrscr();
	PrefixMap p1;
	st="http:\\\\www.kmitl.ac.th";
	char *st1="ns1";
	p1.add(st,st1);
	strcpy(s1,p1.getNamespace(st1));
	puts(ptr2);
	cout<<"st=";puts(ptr);
	XMLWriter x1(NULL);
	st1="plus";
	x1.writeStartTag(p1,st,st1);
	//strcpy(s,x1.getWriter());
	//puts(ptr);
	st1="ns1";
	char *hit="urn:xml-soap-demo-calculator";
	char *h="http:\\\\hit";
	x1.writeAttribute(p1,h,st1,hit);
	char *end="ns1:plus";
	x1.checkPending();
	x1.writeRaw(h);
	x1.writeEndTag(end);
	//test 
	//strcpy(s,"<hit value=\"http:\\\\www.kmitl.ac.th\">name<&sur\"</hit>");
	
	//x1.write(s,0,10);
	strcpy(s,x1.getWriter());
	puts(ptr);
	//x1.writeIndent();
	return 0;
}

//<ns1:plus xmlns:ns1="urn:xml-soap-demo-calculator" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">