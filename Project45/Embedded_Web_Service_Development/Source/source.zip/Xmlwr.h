// package de.embeddedXML.io
// import de.kxml.*;
// file name: Xmlwriter.h
#ifndef __XMLWR_H
#define __XMLWR_H
#include "Prefix.h"
#include "Xml.h"
#include "Attr.h"
#include "Prefix.h"
class XMLWriter
{
	private:
	int pending;  // 0=false 1=true
    int indentLevel;
    int noIndent;
	char writer[1000];
	
	//PrefixMap prefixMap;
    char indent [26];

	//local variable to save data
	//char *temp;//[400]

	public:
	XMLWriter();
	XMLWriter(const char *w);
	//XmlWriter (Writer writer)
	const char* getWriter() const
	{
		return writer;
	}
	void checkPending (); // throws IOException protected 
	/** writes a single character using the xml escaping rules */
	void write (char c); // throws IOException
	/** writes an character array using the XML escaping rules */
	void write (char* buf, int start, int len);// throws IOException
	void writeIndent (); // throws IOException
	/** writes an attribute with the given namespace. Only allowed
	immediately after writeStartTag or another writeAttribute
	call. */
	void writeAttribute (PrefixMap& pfM,const char* ns,const char* n,const char* v); // throws IOException
	/** writes a degenerated tag with the given name and attributes */
	void writeAttribute (const char* n,const char* v); // throws IOException
	void writeStartTag (PrefixMap& pfM,const char* ns,const char* n); // throws IOException
	/** writes a start tag with the given namespace and name */

	//void writeStartTag (char* ns, char* n);    // throws IOException
	/** @deprecated 
	Old method for writing a (possibly degenerated)
        tag including the given attributes. Please use subsequent
	calls of the other methods instead! */	
	// wait for think void writeStartTag (char* n, char* attrs, int degenerated/*boolean*/)  //throws IOException
	/*{
		writeStartTag(n);
		for (int i=0;i<attrsattrs.length; i+=2)  
			writeAttribute (attrs [i], attrs [i+1]);
		if (degenerated==1)
			writeEndTag();
	}*/
	/** writes a start tag with the given name */
	void writeStartTag (/*PrefixMap prefixMap,*/const char* t); // throws IOException  protected

	/** writes an end tag. */
	void writeEndTag (const char *tag); // throws IOException    
	/** ATTENTION: Application needs to take care about not writing
        illegal character sequences (like comment end in comments) */
	void writeLegacy (int type,const char* content); // throws IOException
	/** writes a string without escaping. Use with care! Not
	available in wbxml writer */
	void writeRaw (const char* s); // throws IOException
};
#endif