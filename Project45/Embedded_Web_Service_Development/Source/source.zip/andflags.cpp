#include <stdio.h>
#include <conio.h>
#include <iostream.h>
int main()
{
	printf("Hello, world\n");
	clrscr();
	int i=3;
	int j;
	for (int flags=0;flags<=10 ;flags++ )
		{
		if ((j=flags && i) == 0)
			cout<<flags<<" & "<<i<<"="<<j<<": =true\n";
		else
			cout<<flags<<" & "<<i<<"="<<j<<": =false\n";
		}
	return 0;
}
