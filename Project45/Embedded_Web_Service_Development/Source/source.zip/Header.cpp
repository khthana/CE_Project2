//Header.cpp

#include "Header.h"
char* Header::marshall()
{
	char* temp;
	if (strcmp(headerEntries.getStr(),NULL)!=0)	{
		int s=30+headerEntries.getSize()+attrHandler.getLength();
		temp=new char[s];
		strcpy(temp,NULL);
		strcat(temp,Xml::LT_S);
		strcat(temp,Constants::SOAP_ENV);
		strcat(temp,Xml::CL_S);
		strcat(temp,Constants::HEADER);

		//Attribute marshall()
		char *t;
		t=attrHandler.marshall();
		strcat(temp,t);
		delete t;

		strcat(temp,Xml::GT_S);
		strcat(temp,Xml::ENTER_S);

		//Header Entries  must include;
		strcat(temp,headerEntries.getStr());
		strcat(temp,Xml::ENTER_S);

		strcat(temp,Xml::LT_S);
		strcat(temp,Xml::SL_S);
		strcat(temp,Constants::SOAP_ENV);
		strcat(temp,Xml::CL_S);
		strcat(temp,Constants::HEADER);
		strcat(temp,Xml::GT_S);
		strcat(temp,Xml::ENTER_S);
		strncat(temp,NULL,1);
		return temp;
	}
	return NULL;
}
Header* Header::unmarshall(Parser* pr,ParseEvent *pe)
{
	Header *h;
	char *temp;
	int count;

	char headerTag[16];
	strcpy(headerTag,Constants::SOAP_ENV);
	strcat(headerTag,Xml::CL_S);
	strcat(headerTag,Constants::HEADER);
	strcat(headerTag,NULL);

	pe=pr->read();
	Str param;
	return h;
}