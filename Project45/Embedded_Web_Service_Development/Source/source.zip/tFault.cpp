#include <stdio.h>
#include <iostream.h>
#include <conio.h>
#include "Fault.h"
int main()
{
	const char *fs="service 'urn:mimetest' unknown";
	const char *fc="SOAP-ENV:Server";
	//const char *ac="/soap/servlet/rpcrouter";
	Fault f1,f2(fc,fs);
	clrscr();
	cout<<"f1.getFaultCode     ="<<f1.getFaultCode()<<"\n";
	cout<<"f1.getFaultString   ="<<f1.getFaultString()<<"\n";
	cout<<"f1.getFaultActorURI ="<<f1.getFaultActorURI()<<"\n";
	cout<<"f1.getDetailEntriese="<<f1.getDetailEntries()<<"\n";
	cout<<"f1.getFaultEntries  ="<<f1.getFaultEntries()<<"\n\n";

	cout<<"f2.getFaultCode     ="<<f2.getFaultCode()<<"\n";
	cout<<"f2.getFaultString   ="<<f2.getFaultString()<<"\n";
	cout<<"f2.getFaultActorURI ="<<f2.getFaultActorURI()<<"\n";
	cout<<"f2.getDetailEntriese="<<f2.getDetailEntries()<<"\n";
	cout<<"f2.getFaultEntries  ="<<f2.getFaultEntries()<<"\n\n";
	char *soap;
	soap=f2.marshall();
	cout<<"f2.marshall()="<<soap;
	Fault *f3;
	f3=Fault::unmarshall(fc,fs);
	Fault f4;
	f4=*f3;

	cout<<"f4.getFaultCode     ="<<f4.getFaultCode()<<"\n";
	cout<<"f4.getFaultString   ="<<f4.getFaultString()<<"\n";
	cout<<"f4.getFaultActorURI ="<<f4.getFaultActorURI()<<"\n";
	cout<<"f4.getDetailEntriese="<<f4.getDetailEntries()<<"\n";
	cout<<"f4.getFaultEntries  ="<<f4.getFaultEntries()<<"\n\n";
	return 0;
}