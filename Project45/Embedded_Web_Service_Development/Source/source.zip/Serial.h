//Serial.h

#ifndef __SERIALIZE_H
#define __SERIALIZE_H

class Serialize
{
	public:
	Serialize(){}
	simpleSerialize();
	structSerialize();
	ArraySerialize();
};
#endif