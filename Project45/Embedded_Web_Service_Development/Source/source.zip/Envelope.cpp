//Envelope.cpp

#include <string.h>
#include "Envelope.h"

char* Envelope::marshall()
{
	char *temp;
	temp=new char[300+getLength()];

	//<SOAP-ENV:ENVELOPE
	strcpy(temp,Xml::LT_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::ENVELOPE);

	//attribute's Envelope
	char *t;
	if (attrHandler.getLength() > 0)
	{
		t=attrHandler.marshall();
		strcat(temp,t);
		delete t;
	}
	//>\n
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);

	if (header.getLength() > 0)
	{
		t=header.marshall();
		strcat(temp,t);
		delete t;
	}
	t=body.marshall();
	strcat(temp,t);
	delete t;

	//</SOAP-ENV:ENVLOPE>\n
	strcat(temp,Xml::LT_S);
	strcat(temp,Xml::SL_S);
	strcat(temp,Constants::SOAP_ENV);
	strcat(temp,Xml::CL_S);
	strcat(temp,Constants::ENVELOPE);
	strcat(temp,Xml::GT_S);
	strcat(temp,Xml::ENTER_S);
	return temp;
}
Envelope* Envelope::unmarshall(Parser *pr,ParseEvent *pe)
{
	Envelope *env;
	env=new Envelope();
	char *temp;
	temp=pe->getAttribute();
	env->setAttribute(temp,pe->getCountAttr());
	if (temp!=NULL)
		delete temp;
	pe=pr->read();
	
	///may be improve for header part
	int count;
	char bodyTag[14];
	strcpy(bodyTag,Constants::SOAP_ENV);
	strcat(bodyTag,Xml::CL_S);
	strcat(bodyTag,Constants::BODY);
	strcat(bodyTag,NULL);
	Body *b;
	if ((strcmp(pe->getName(),bodyTag)==0) && (pe->getType()==Xml::START_TAG))
	{
		b=Body::unmarshall(pr,pe);
		env->setBody(*b);
		delete b;
	} else {
		env->setError(Constants::BODY);
	}		
	return env;
}