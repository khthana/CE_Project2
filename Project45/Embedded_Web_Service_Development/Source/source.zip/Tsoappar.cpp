#include<stdlib.h>
#include<stdio.h>
#include<iostream.h>
#include<conio.h>
#include<process.h>
#include"Parser.h"
#include"ParseE.h"
#include"Soappar.h"
#include"SoapDes.h"
#include"SoapRes.h"
void main()
{
	clrscr();
	const max=2000;
	char a[max];
	char ch;
	int i=0;
	
    
	FILE *stream;
	stream=fopen("test1.txt","r+");
	fseek(stream,0,SEEK_SET);
	ch=fgetc(stream);
	while (ch!=EOF)
	{
		if (i>max)
			break;
		if (ch!=-9  && ch!='\n')
			a[i++]=ch;
		ch=fgetc(stream);
	}
	//close service description file
	fclose(stream);  //	break;
	a[i]='\0';
	printf("input=\n%s",a);
	Envelope *env;
	env=SOAPParser::parse(a);
	char *hit;
	cout<<"env->getEnvelopeEntries()="<<env->getEnvelopeEntries()<<endl;
	hit=env->getAttribute();
	cout<<"env->getAttribute()      ="<<hit<<endl;
	delete hit;
	hit=env->marshall();
	cout<<"env->marshall()          ="<<hit<<endl;
	delete hit;
	Body b=env->getBody();

	cout<<"b.getMethod.getMethodName()="<<b.getMethod().getMethodName()<<endl;
	cout<<"b.getMethod.getMethodURL() ="<<b.getMethod().getMethodURL()<<endl;
	cout<<"b.getMethod.getMethodEnc() ="<<b.getMethod().getMethodEnc()<<endl;
	cout<<"b.getMethod.getParameter().getParameter()="<<b.getMethod().getParameter().getParameter()<<endl;

	//getch();
	clrscr();
	if (SOAPParser::checkServiceName(b.getMethod().getMethodURL()))
	{
		printf("rigdj");
	}
	else
		printf("falsdf");
	char* fileN="sd1.txt\0";
	char* met="getAddressFromName\0";
	if (SOAPParser::checkMethodName(met,fileN))
	{
		printf("right");
	}
	else
		printf("false");
	clrscr();
	SOAPDeserialize d;
	char *m="getAddressFromName\0";
	d.setServiceMethod(m);
	char *f="sd1.txt\0";
	d.readServiceMap(f);
	Parameter p=b.getMethod().getParameter();
	//char *in="input.txt\0";
	p.writeFile();
	getch();
	char* soap=d.serialOutput();
	printf("soap=\n%s",soap);
	char* final=SOAPResponse::buildResponse(env,soap);
	delete soap;
	printf("hello\n%s",final);
	stream=fopen("soap.txt","w+");
	fseek(stream,0,SEEK_SET);
	fprintf(stream,"%s",final);
	fclose(stream);
	delete final;
	int ie = spawnl(P_WAIT,"getAdd.exe",NULL);
	if (ie==-1)
	{
		perror("Error from spawnl");
		exit(1);
	}


	delete env;
}