// package de.embeddedXML.io
// import de.kxml.*;
// file name: Xmlwriter.cpp

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "XmlW.h"
//#include "Prefix.h"
XMLWriter::XMLWriter()
{
	strcpy(writer,NULL);
	pending=0;
	size=0;
}
XMLWriter::XMLWriter(const char *w)
{
	strcpy(writer,w);
	pending=0;size=0;
}
void XMLWriter::checkPending () // throws IOException protected 
{
	if (pending==1)	{
		strcat(writer,Xml::GT_S);
		strcat(writer,Xml::ENTER_S);
		pending=0;
	}
}
void XMLWriter::closeAll()
{
	char *st=" />";
	char *et="</";
	while (size>0)	{
		size--;
		if (nameTag[size]!=NULL)	{
			if (pending==1) {
				strncat(writer,st,3);
				pending=0;
			}
			else {
				strncat(writer,et,2);
				strcat(writer,nameTag[size].getStr());
				nameTag[size]=NULL;
				strncat(writer,Xml::GT_S,1);
				strcat(writer,Xml::ENTER_S);
			}
		} else {
			char *e="can't write unname(NULL) endtag";
			error=e;
			printf("\n%s\n",error.getStr());
			break;
		}
	}
}
void XMLWriter::write (char c) // throws IOException
{
	checkPending();
	switch (c) {
	case '<': strncat(writer,Xml::LT,4); break;
	case '>': strncat(writer,Xml::GT,4); break;
	case '&': strncat(writer,Xml::AMP,5); break;
	default: char*s; s=&c; strncat(writer,s,1); 
	}
}
void XMLWriter::write (char* buf, int start, int len) // throws IOException
{
	checkPending();
	int end=start+len;
	char *ptr;
	char *s;
	s="<>&";
	do	{
		int i=start;
		while (i<end)	{
			ptr=strchr(s,buf[i]);
			if (strcmp(ptr,NULL)==0)
				++i;
			else
				break;
		}
		int j=i;
		int index=start;
		while (j>start )	{
			s=&buf[index++];
			strncat(writer,s,1);
			j--;
		}
		if (i==end)
			break;
		write(buf[i]);
		start=i+1;
	}
	while (start<end);
}
void XMLWriter::writeAttribute (const char* attr)// throws IOException
{
	if (pending==0)	{
		char *e="can write attr only immediately after a startTag";
		error=e;
		printf("\n%s\n",error.getStr());
		//throw new RuntimeException("can write attr only immediately after a startTag");
	} else {
		if (strcmp(attr,NULL)!=0)	{
			strncat(writer,Xml::SP_S,1);
			strcat(writer,attr);
			strncat(writer,NULL,1);
		}
	}
}
void XMLWriter::writeAttribute (const char* pf,const char* n,const char* ns)// throws IOException
{
	if (strcmp(pf,NULL)==0)	{
		writeAttribute(n,ns);
	}
	else	{
		Attribute *attr=new Attribute(pf,n,ns);
		char *temp=attr->toPrefix_Name();
		writeAttribute(temp,ns);
		delete attr;
		delete temp;
	}
}
void XMLWriter::writeAttribute (const char* n,const char* v) // throws IOException
{
	if (pending==0)	{
		char *e="can write attr only immediately after a startTag";
		error=e;
		printf("\n%s\n",error.getStr());
		//throw new RuntimeException("can write attr only immediately after a startTag");
	}else	{
		if ((strcmp(n,NULL)!=0)&&(strcmp(v,NULL)!=0))	{
			char *s;
			strncat(writer,Xml::SP_S,1);
			strcat(writer,n);
			s="=\"";
			strncat(writer,s,2);
			char *temp;
			temp=Xml::encode(v,Xml::ENCODE_QUOT);
			strcat(writer,temp);
			delete temp;
			strncat(writer,Xml::QU_S,1);
			strncat(writer,NULL,1);
		}
	}
}
void XMLWriter::writeStartTag (const char* pf,const char* n) // throws IOException
{
	char tag[200];
	if (strlen(pf)==0)
		strcpy(tag,n);
	else{
		strcpy(tag,pf);
		strncat(tag,Xml::CL_S,1);
		strcat(tag,n);
	}		
	writeStartTag(tag);
}
void XMLWriter::writeStartTag (const char* t) // throws IOException  protected
{
	if (strcmp(t,NULL)!=0)	{
		checkPending();
		strncat(writer,Xml::LT_S,1);
		strcat(writer,t);
		nameTag[size++]=t;
		pending=1;
	}
}
void XMLWriter::writeEmptyTag (const char *pf,const char *n,const char *attr) // throws IOException
{
	char *temp;
	temp=new char[strlen(pf)+strlen(n)+2];
	strcpy(temp,pf);
	if (strcmp(pf,NULL)!=0)
		strncat(temp,Xml::CL_S,1);
	strcat(temp,n);
	writeEmptyTag(temp,attr);
	delete temp;
}
void XMLWriter::writeEmptyTag (const char *tag,const char *attr) // throws IOException
{
	if (strcmp(tag,NULL)!=0)	{
		checkPending();
		strncat(writer,Xml::LT_S,1);
		strcat(writer,tag);
		pending=1;
		writeAttribute(attr);
		strncat(writer,Xml::SL_S,1);
		strncat(writer,Xml::GT_S,1);
		pending=0;
	}
}
void XMLWriter::writeEndTag (const char *tag) // throws IOException
{
	char *s;
	if (nameTag[size-1]==tag)	{
		nameTag[--size]==NULL;
		s="</";
		strncat(writer,s,2);
		strcat(writer,tag);
		strncat(writer,Xml::GT_S,1);
		strcat(writer,Xml::ENTER_S);
	}
	else {
		char *e="tagname mismath with endtag";//error tagname mismatch
		error=e;
		printf("\n%s\n",error.getStr());
	}
}
void XMLWriter::writeEndTag()
{
	char *s;
	if (size>0)	{
		size--;
		if (nameTag[size]!=NULL)	{
			s="</";
			strncat(writer,s,2);
			strcat(writer,nameTag[size].getStr());
			nameTag[size]=NULL;
			strncat(writer,Xml::GT_S,1);
			strcat(writer,Xml::ENTER_S);
		}
	}
	else	{
		char *e="can't write endtag without starttag";
		error=e;
		printf("\n%s\n",error.getStr());
	}	
}
void XMLWriter::writeTag(const char* tag, const char* attr, const char* value)
{
	if ((strcmp(tag,NULL)!=0) && (strcmp(value,NULL)!=0))	{
		checkPending();
		strcat(writer,Xml::LT_S);
		strcat(writer,tag);
		if (strcmp(attr,NULL)!=0)	{
			strcat(writer,Xml::SP_S);
			strcat(writer,attr);
		}
		strcat(writer,Xml::GT_S);
		strcat(writer,value);
		strcat(writer,Xml::LT_S);
		strcat(writer,Xml::SL_S);
		strcat(writer,tag);
		strcat(writer,Xml::GT_S);
		strcat(writer,Xml::ENTER_S);
	}
}
void XMLWriter::writeLegacy (int type,const char* content) // throws IOException
{
	checkPending ();
	char *s;
	switch (type) {
	case '-':
		s="<!--";
		strncat(writer,s,4);
		strcat(writer,content);
		s="-->";
		strncat(writer,s,3);
		break;
	case '!':
		s="<!DOCTYPE";
		strncat(writer,s,9);
		strcat(writer,content);
		s=">";
		strncat(writer,s,1);
		break;
	case '?':
		s="<?";
		strncat(writer,s,2);
		strcat(writer,content);
		s="?>";
		strncat(writer,s,2);
		break;
	}
}
void XMLWriter::writeRaw (const char* s) // throws IOException
{
	checkPending ();
	strcat(writer,s);
}