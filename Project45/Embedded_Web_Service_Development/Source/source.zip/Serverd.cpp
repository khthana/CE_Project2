#include<conio.h>
#include<stdio.h>
#include<io.h>
#include<string.h>
#include<fcntl.h>
#include<stdlib.h>
#include"Str.h"
#include"Const.h"
//#include"am186cc.h"
#define _MaxBuffer_ 4000
#define _MaxStrLen_ 200
#define _MaxParaNum_ 20
#define _MaxOutputMessage_ 1000
#define _HomeDir_ "."
#define _MaxCon_ 5

#ifdef __cplusplus
extern "C" {
#endif
#include <tcp.h>
#ifdef __cplusplus
}
#endif
FILE *stream;
Str message;
class HTTPRequest{

   public:
     int len, i, a;

     tcp_Socket httpSock[_MaxCon_];
     int status;
     char buffer[_MaxBuffer_];
     tcp_Socket *soc[_MaxCon_];

     char ParaName[_MaxParaNum_][_MaxStrLen_] ;
     char ParaValue[_MaxParaNum_][_MaxStrLen_] ;
     unsigned char ParaIndex ;

     char OutputMessage[_MaxOutputMessage_] ;

//     void yield(void) ;
     char RequestedObject[_MaxStrLen_] ;
//     HTTPRequest(void) ;
     char* parseGETPOST(char *strin) ;
     void clearAll(void) ;
     void waitHTTP(void) ;
     void outputMessage(tcp_Socket *mysock, char *strin) ;
     void printRequestParam() ;

     void outputImage(tcp_Socket *mysock, char * filename) ;
} ;


HTTPRequest hr ;


//------------------------------------------------------
void HTTPRequest::outputImage(tcp_Socket *mysock, char * filename){

  int handle ;
  int numread = 0;
  char bufferread[1000] ;


  if ((handle = open(filename, O_RDONLY)) == -1) {
    perror("Error:");
    sock_puts(mysock, "HTTP/1.0 404 Not Found\n\n")  ;
   } else {

    sock_puts(mysock, "HTTP/1.0 200 Ok\n")  ;
    sock_puts(mysock, "Data: xxx \n") ;
    sock_puts(mysock, "Server: Com86 Demo \n") ;
    sock_puts(mysock, "Accept-Ranges: bytes \n") ;
    sock_puts(mysock, "Connection: close\n") ;
    // check image type gif
    if (strstr(strlwr(RequestedObject), ".gif")==NULL) {
      sock_puts(mysock, "Content-Type: image/gif\n") ;
    } else if (strstr(strlwr(RequestedObject), ".jpg")==NULL) {
      sock_puts(mysock, "Content-Type: image/jpeg\n") ;
    } else {
      sock_puts(mysock, "Content-Type: image/gif\n") ;
    }

    sock_puts(mysock, "\n") ;

    while (!eof(handle)) {
      numread = _read(handle, bufferread, 1000);
//     printf("-->%d\n", numread) ;
      sock_write(mysock, bufferread, numread) ;
      sock_flush(mysock) ;
    }

    close(handle);
  }

  // close connection
  sock_close(mysock) ;
//  sock_wait_closed(mysock, 0, NULL, &status) ;
  return ;

	sock_err:
	switch (status) {
		case 1 ://foreign host closed
			puts("User closed session");
			return ;
		case -1: // timeout
			printf("\n\rConnection timed out!");
			return ;
		}
}           
//------------------------------------------------------
void HTTPRequest::printRequestParam() {
  int a ;

  printf("-->%s\r\n", RequestedObject) ;

  for (a=0;a<ParaIndex;a++) {
    printf("%s : %s\n\r", ParaName[a], ParaValue[a]) ;
  }
}
//------------------------------------------------------
void HTTPRequest::outputMessage(tcp_Socket *mysock, char *strin)
{
  sock_puts(mysock, "HTTP/1.0 200 Ok\n")  ;
  sock_puts(mysock, "Content-Type: text/xml; charset=\"utf-8\"\n") ;
  sock_puts(mysock, "\n") ;
  sock_puts(mysock, strin) ;
  sock_flush(mysock) ;

  // close connection
  sock_close(mysock) ;
//  sock_wait_closed(mysock, 0, NULL, &status) ;
  return ;

	sock_err:
	switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
			return ;
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
			return ;
		}
}
//------------------------------------------------------
char* HTTPRequest::parseGETPOST(char * strin) {
	//char message[_MaxBuffer_] ;
	//strcpy(message,strin);
	//printf("message..=\n%s\n",message);
	char *soap="<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsi=\"http://www.w3.org/1999/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/1999/XMLSchema\">\n<SOAP-ENV:Body>\n<SOAP-ENV:Fault>\n<faultcode>Server</faultcode>\n<faultstring>Input parameter mismatch with Service</faultstring>\n<faultactor>SOAP Request Handler</faultactor>\n</SOAP-ENV:Fault>\n\n</SOAP-ENV:Body>\n</SOAP-ENV:Envelope>\n";
	char *temp=new char[1000];
	strcpy(temp,soap);
	strcat(temp,NULL);
	return temp;
}
//------------------------------------------------------
void HTTPRequest::clearAll(void) {
  unsigned char tempc ;
  memset(buffer, 0, _MaxBuffer_) ;
  memset(RequestedObject, 0, _MaxStrLen_) ;
  for(i=0;i<_MaxParaNum_;i++) {
    memset(ParaName[i], 0, _MaxStrLen_) ;
    memset(ParaValue[i], 0, _MaxStrLen_) ;
  }
  memset(OutputMessage, 0, _MaxOutputMessage_) ;
  ParaIndex = 0 ;
}
//------------------------------------------------------
void yield() {
  unsigned char tempc ;
  int i ;
  char *sen;
  char *m;
  char *out;

  char temperaturea[5] ;
  char temp[_MaxStrLen_] ;
  //char DemoMessage[_MaxBuffer_] ;
  //strcpy(DemoMessage,NULL);
  

  for (tempc=0;tempc<_MaxCon_;tempc++) {
    if (sock_established(hr.soc[tempc])==1) {
      if (sock_rbused(hr.soc[tempc])>0) { // if data available
	hr.clearAll() ;
	sock_fastread(hr.soc[tempc], hr.buffer, 1000);
	if (strcmp(hr.buffer,NULL)!=0)
	{
		message+=hr.buffer;
	}
	/*stream=fopen("input1.txt","a+");
	fprintf(stream,"%s",hr.buffer);
	fclose(stream);*/
	//out=strstr(message.getStr(),Constants::BODY);
	//////if (message.endString()=='>')
	/////{
		printf("%s",message.getStr());
		sen=hr.parseGETPOST(hr.buffer) ;
		hr.outputMessage(hr.soc[tempc],sen);
		delete sen;
	//////}
	  }
	}

  } // for

  if (kbhit()) {
    for(i=0;i<_MaxCon_;i++) {
      sock_abort(hr.soc[i]) ;
    }
    exit(0) ;
  }
}
//------------------------------------------------------
void HTTPRequest::waitHTTP(void) {

  int i ;
  sock_init() ;
  sock_yield(NULL, yield) ;

  ParaIndex = 0 ;
  for(i=0;i<_MaxCon_;i++) {
    soc[i] = &httpSock[i] ;
  }

  while (1==1) {
	clearAll() ;

	for(i=0;i<_MaxCon_;i++) {

	  printf("Try to listen %d\n", i) ;
	  tcp_listen( soc[i], 80, 0L, 0, NULL, 0);
	  sock_wait_established(soc[i], 0, NULL, &status);

	  printf("Socket %d Connect\n", i) ;
	  sock_mode(soc[i], TCP_MODE_BINARY) ;
	  //printf("mess=%s\n",message.getStr());
	}

//	sock_wait_closed(soc[0], 0, NULL, &status) ;

	while (1==2) {
	  sock_err:
	  switch (status) {
		case 1 :/*foreign host closed */
			puts("User closed session");
		case -1: /* timeout */
			printf("\n\rConnection timed out!");
		}
	}
  } // forever loop
//        return NULL ;
}
//------------------------------------------------------
void main(void) {
  printf("Server start up... \n") ;

  hr.waitHTTP() ;

}

/*	tcp_listen( soc[1], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[1], 0, NULL, &status);
	printf("Socket 2 Connect\n") ;
	sock_mode(soc[1], TCP_MODE_BINARY) ;

	tcp_listen( soc[2], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[2], 0, NULL, &status);
	printf("Socket 3 Connect\n") ;
	sock_mode(soc[2], TCP_MODE_BINARY) ;

	tcp_listen( soc[3], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[3], 0, NULL, &status);
	printf("Socket 4 Connect\n") ;
	sock_mode(soc[3], TCP_MODE_BINARY) ;

	tcp_listen( soc[4], 80, 0L, 0, NULL, 0);
	sock_wait_established(soc[4], 0, NULL, &status);
	printf("Socket 4 Connect\n") ;
	sock_mode(soc[4], TCP_MODE_BINARY) ;
*/