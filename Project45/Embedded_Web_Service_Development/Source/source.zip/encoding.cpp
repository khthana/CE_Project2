#include <stdio.h>
#include <conio.h>
#include <iostream.h>
#include <string.h>
//using namespace std;
//typedef basic_string<char> string;
char in[80];
int main()
{
	printf("Hello, world\n");
	cin>>in;

	return 0;
}
