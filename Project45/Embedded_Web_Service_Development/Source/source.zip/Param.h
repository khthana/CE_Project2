//Parameter.h

#ifndef __PARAMETER_H
#define __PARAMETER_H
#include <stdio.h>
#include "Str.h"
#include "Const.h"
#include "AttrHand.h"
#include "Qname.h"
#include "Parser.h"
#include "ParseE.h"

class Parameter
{
	private:
	Str params;
	Str error;
	
	public:
	Parameter()	{  }

	Parameter(const char* pa) {
		params=pa;	}

	Parameter& operator=(const Parameter& that)	{
		error=that.getError();
		params=that.getParameter();
		return *this;	}

	int getLength() const {
		return params.getSize();	}

	void setParameter(const char* p) {
		params=p;	}
	
	const char* getParameter() {
		return params.getStr();	}
	
	void writeFile() {
		FILE *stream;
		stream=fopen("input.txt","a+");
		fseek(stream,0,SEEK_SET);
		Parser *pr=new Parser();
		ParseEvent *pe;
		pr->setXMLReader(params.getStr());
		pe=pr->read();
		char *temp;
		printf("writeFile=");
		while (pr->isRead())	{
			if (pe->getType()==Xml::TEXT)	{
				temp=pe->toString();
				fprintf(stream,"%s\n",temp);
				printf("%s",temp);
				if (temp!=NULL)
					delete temp;
			}
			pe=pr->read();
		}
		fclose(stream);	}

	void setError(const char* e) {
		error=e;	}
	
	const char* getError() const	{
		return error.getStr();	}
	char* marshall() {
		char* temp;
		temp=new char[getLength()+1];
		strcpy(temp,params.getStr());
		strcat(temp,NULL);
		return temp; }
};
#endif