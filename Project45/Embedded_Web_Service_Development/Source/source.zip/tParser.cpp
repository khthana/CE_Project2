#include <stdio.h>
//#include <stdlib.h>
#include <iostream.h>
#include <conio.h>
#include <string.h>
#include "Parser.h"
#include "ParseE.h"
int main()
{
	clrscr();
	char st[200];
	int i;
	//ParseEvent *pe;
	char *s="<name attr=\"27\">hit</soap>\n";
	printf("%s\n",s);
	Parser *p1;
	p1=new Parser(s);
	p1->read();
	//int type=pe->getType();
	//if (type==START_TAG)
	//	printf("tre");
	delete p1;
	return 0;
}
