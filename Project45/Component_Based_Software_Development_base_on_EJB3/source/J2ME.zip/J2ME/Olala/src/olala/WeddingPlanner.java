package olala;
//REAL !!
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;
import java.util.Vector;

public class WeddingPlanner extends MIDlet implements CommandListener , ItemStateListener{
  private static WeddingPlanner instance;
  private String Customer_ID = new String();
  private String Wedding_Contact = new String();
  private String StMonth[] = {"January" , "February" , "March" , "April" , "May" , "June" , "July" , "August" , "September" , "October" , "November" , "December"};
  private String StCheap[] = {"Yes" , "No"};
  private String StDay[] = {"1" ,"2" ,"3" ,"4" ,"5" ,"6" ,"7" ,"8" ,"9" ,"10" ,"11" ,"12" ,"13" ,"14" ,"15" ,"16" ,"17" ,"18" ,"19" ,"20" ,"21" ,"22" ,"23" ,"24" ,"25" ,"26" ,"27" ,"28" ,"29" ,"30" ,"31"};

  Alert AlertError;

  Form FmHome = new Form("Wedding Planner");
  Form FmRegister = new Form("Register");
  Form FmLogin = new Form("Login");
  Form FmShowContact = new Form("Show Contact");
  Form FmEntertainment = new Form("Entertainment");
  Form FmSearchEntertainment = new Form("Search Entertainment");
  Form FmReserveEntertain = new Form("Reserve Entertainment");
  Form FmResultReserveEntertain = new Form("Result Reserve");
  Form FmSearchTour = new Form("Search Tour");
  Form FmSelectTour = new Form("Tour");

  Form FmReserveTour = new Form("Reserve Tour");
  Form FmTour = new Form("Package Tour");
  List ListResultSearchEntertain = new List ("Result Search" , List.EXCLUSIVE);
  List ListShowJob = new List("Job List" , List.EXCLUSIVE);
  List ListTemp = new List ("Temp" , List.EXCLUSIVE);
  List ListResultSearchTour = new List ("Result Search" , List.EXCLUSIVE);

  StringItem St1;
  StringItem St2;
  StringItem St3;
  StringItem St4;
  StringItem St5;
  StringItem St6 = new StringItem("Deadline","");
  StringItem StWeddingTotalPrice = new StringItem("Total Price","");
  StringItem St7 = new StringItem(" " , "Create New Contact");


  StringItem St11;
  StringItem St12;
  StringItem StEntertain = new StringItem ("Entertain" , "");

  StringItem StTour = new StringItem("Tour" , "");

  TextField Tf1;
  TextField Tf2;
  TextField Tf3;
  TextField Tf4;
  TextField Tf5;

  TextField Tf6;
  TextField Tf7;
  TextField Tf8;
  TextField Tf9;
  TextField Tf10;

  TextField Tf11;
  TextField Tf12;
  TextField Tf13;
  TextField Tf14;

  TextField Tf15;
  TextField Tf16;


  TextField Tf19 = new TextField("Name" , "" , 30 , TextField.ANY);// Wedding Contact name



  ChoiceGroup Cg1;
  ChoiceGroup Cg2;

  ChoiceGroup CgContact_ID = new ChoiceGroup("Contact ID" , Choice.EXCLUSIVE);

  ChoiceGroup CgEntertainStyle = new ChoiceGroup("Style" , Choice.EXCLUSIVE);
  ChoiceGroup CgBandType = new ChoiceGroup("Band Type",Choice.EXCLUSIVE);
  ChoiceGroup CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
  ChoiceGroup CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
  ChoiceGroup CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);
  ChoiceGroup CgStartHour = new ChoiceGroup("Hour" , Choice.EXCLUSIVE);
  ChoiceGroup CgStartMinute = new ChoiceGroup("Minute" , Choice.EXCLUSIVE);
  ChoiceGroup CgDuration = new ChoiceGroup("Duration",Choice.EXCLUSIVE);

  ChoiceGroup CgFinishDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
  ChoiceGroup CgFinishMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
  ChoiceGroup CgFinishYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);

  Command cmRegister = new Command("Register" , Command.SCREEN , 1);
  Command cmLogin = new Command("Login" , Command.SCREEN , 1);
  Command cmToLoginForm = new Command("Login" , Command.SCREEN , 1);
  Command cmToRegistForm = new Command("Register" , Command.SCREEN , 1);
  Command cmBackToHome = new Command("Back" , Command.SCREEN , 1);
  Command cmSelectContact = new Command("Select" , Command.SCREEN , 1);
  Command cmCreateWeddingContact = new Command("Create" , Command.SCREEN , 1);
  Command cmSelectType = new Command("Select" , Command.SCREEN , 1);
  Command cmSearchEntertainment = new Command("Search" , Command.SCREEN , 1);
  Command cmSelectEntertain  = new Command("Select" , Command.SCREEN , 1);
  Command cmBackToEntertain = new Command("Back" , Command.SCREEN , 1);
  Command cmReserveEntertain = new Command("Reserve" , Command.SCREEN , 1);
  Command cmBackToJobList = new Command("OK" , Command.SCREEN , 1);
  Command cmEditEntertain = new Command("Edit" , Command.SCREEN , 1);
  Command cmCancelEntertain = new Command("Cancel" , Command.SCREEN , 1);

  Command cmSearchTour = new Command("Search" , Command.SCREEN , 1);
  Command cmSelectReserveTour = new Command("Reserve" , Command.SCREEN , 1);
  Command cmSelectTour = new Command("Select" , Command.SCREEN , 1);
  Command cmReserveTour = new Command("Reserve" , Command.SCREEN , 1);
  Command cmCancelTour = new Command("Cancel" , Command.SCREEN , 1);
  Command cmTourBackToShowJob = new Command("Back" , Command.SCREEN , 1);

  Command cmBackToContact = new Command("Back" , Command.SCREEN , 1);

  Command cmBackToShowJob = new Command("Back" , Command.SCREEN , 1);

  Command cmEntertainBackToJob = new Command("Back" , Command.SCREEN , 1);

//*******************Hotel Form ***************************************
  Form FmSearchSeminar = new Form("Search Seminar");
  Command cmSeminarSearch = new Command("Search" , Command.SCREEN , 1);

  List ListResultSearchSeminar = new List("Result Seminar" , List.EXCLUSIVE);
  Command cmSelectSeminar = new Command("Select" ,Command.SCREEN , 1);

  Form FmReserveSeminar = new Form("Reserve Seminar");
  StringItem ReserveSeminar = new StringItem("Reserve" , "");
  ChoiceGroup CgServeType = new ChoiceGroup("Serve Type" , ChoiceGroup.EXCLUSIVE);
  TextField TfSeminarMax = new TextField("Maximum" , "" , 3 , TextField.NUMERIC);
  Command cmReserveSeminar = new Command("Reserve" , Command.SCREEN , 1);


  Form FmShowSeminar = new Form("Seminar" );
  StringItem StSeminar = new StringItem("Seminar" , "");
  Command cmCancelSeminar = new Command("Cancel" , Command.SCREEN , 1);

//*********************************************************************
//********************* Photo Studio **********************************
  Form FmInStudio = new Form("Photo in-Studio");
  Command cmSearchInStudio = new Command("Search" , Command.SCREEN , 1);

  List ListInStudio = new List ("in-Studio" , List.EXCLUSIVE);
  Command cmReserveInStudio = new Command("Reserve" , Command.SCREEN , 1);
  Command cmPhotoBackToJob = new Command("Back" , Command.SCREEN , 1);

  Form FmResultReserveInStudio = new Form("in-Studio");
  StringItem StResultInStudio = new StringItem("Result" , "");

  Form FmShowInStudio = new Form ("in-Studio");
  StringItem StInStudio = new StringItem("in-Studio" , "");
  Command cmCancelInStudio = new Command("Cancel" , Command.SCREEN , 1);
//*********************************************************************
//********************* Gift Registries *******************************

  Form FmSearchGift = new Form("Search Gift");
  Command cmSearchGift = new Command("Search" , Command.SCREEN , 1);

  List ListResultSearchGift = new List("Result Search" , List.EXCLUSIVE);
  Command cmGiftBackToJob = new Command("Back" , Command.SCREEN , 1);
  Command cmSelectGift = new Command("Select" , Command.SCREEN , 1);

  Form FmReserveGift = new Form("Reserve Gift");
  StringItem StReserveGift = new StringItem("Reserve" , "");
  Command cmReserveGift = new Command("Reserve" , Command.SCREEN , 1);
  Command cmBackToListGift = new Command("Back" , Command.SCREEN , 1);

  Form FmResultReserveGift = new Form("Result");
  StringItem STResultReserveGift = new StringItem("Result" , "");

  Form FmGift = new Form("Gift");
  StringItem StGift = new StringItem("Gift" , "");
  Command cmCancelGift = new Command("Cancel", Command.SCREEN , 1);

//*********************************************************************

  Form FmPayment = new Form("Payment");
  Command cmPayment = new Command("Pay" , Command.SCREEN , 1);
  Command cmPaid = new Command("Pay" , Command.SCREEN , 1);


//********************************************************************
  Display display;

//  Ticker Tick = new Ticker(" Loading ...");

  Vector ArrayContact_ID = new Vector();
  Vector ArrayDeadline = new Vector();
  Vector ArrayCheckContact = new Vector();
  Vector ArrayTotalPrice = new Vector();
  Vector ArrayResultEntertain ;
  Vector ArrayInStudioSubType;
  Vector ArrayPhotoStudio ;
  Vector ArrayGiftDetail ;
  Vector ArrayGiftSelect ;
  Vector ArrayTourDetail;


  Vector ArraySeminarDetail;
  String Band_ID = new String();
  String Band_Type_ID = new String();
  String Entertain = new String();

  String HotelID = "1";
  String Time = new String();
  /** Constructor */
  public WeddingPlanner() {


    FmHome.addCommand(cmToLoginForm);
    FmHome.addCommand(cmToRegistForm) ;
//    FmHome.setTicker(Tick);
    FmHome.setCommandListener(this) ;
    display = Display.getDisplay(this);

    FmShowContact.append(CgContact_ID);
    FmShowContact.append(St6);
    FmShowContact.append(StWeddingTotalPrice);
    FmShowContact.append(St7);
    FmShowContact.append(Tf19);
    FmShowContact.addCommand(cmBackToHome);
    FmShowContact.addCommand(cmCreateWeddingContact);
    FmShowContact.addCommand(cmSelectContact);
    FmShowContact.addCommand(cmPayment);
    FmShowContact.setItemStateListener(this);
    FmShowContact.setCommandListener(this);

    ListShowJob.addCommand(cmBackToContact);
    ListShowJob.addCommand(cmSelectType);
    ListShowJob.setCommandListener(this);

    ListResultSearchEntertain.addCommand(cmEntertainBackToJob);
    ListResultSearchEntertain.addCommand(cmSelectEntertain);
    ListResultSearchEntertain.setCommandListener(this);

    FmEntertainment.append(StEntertain);
    FmEntertainment.addCommand(cmBackToShowJob);
    FmEntertainment.addCommand(cmCancelEntertain);
    FmEntertainment.setCommandListener(this);
    ListResultSearchTour.addCommand(cmTourBackToShowJob);
    ListResultSearchTour.addCommand(cmSelectTour);
    ListResultSearchTour.setCommandListener(this);

    ListResultSearchTour.addCommand(cmTourBackToShowJob);
    ListResultSearchTour.addCommand(cmSelectTour);
    ListResultSearchTour.setCommandListener(this);


    ListInStudio.addCommand(cmPhotoBackToJob);
    this.ListInStudio.addCommand(cmReserveInStudio);
    ListInStudio.setCommandListener(this);


    ListResultSearchGift.addCommand(cmGiftBackToJob);
    ListResultSearchGift.addCommand(cmSelectGift);
    ListResultSearchGift.setCommandListener(this);

    FmShowInStudio.append(StInStudio);
    FmShowInStudio.addCommand(cmBackToShowJob);
    FmShowInStudio.addCommand(cmCancelInStudio);
    FmShowInStudio.setCommandListener(this);

    FmGift.append(StGift);
    FmGift.addCommand(cmBackToShowJob);
    FmGift.addCommand(cmCancelGift);
    FmGift.setCommandListener(this);

    ListResultSearchSeminar.addCommand(cmSelectSeminar);
    ListResultSearchSeminar.setCommandListener(this);

    FmReserveSeminar.append(ReserveSeminar);
    FmReserveSeminar.append(TfSeminarMax);
    FmReserveSeminar.addCommand(cmReserveSeminar);
    FmReserveSeminar.setCommandListener(this);

    FmTour.append(StTour);
    FmTour.addCommand(cmBackToShowJob);
    FmTour.addCommand(cmCancelTour);
    FmTour.setCommandListener(this);

    FmShowSeminar.append(StSeminar);
    FmShowSeminar.addCommand(cmBackToShowJob);
    FmShowSeminar.addCommand(cmCancelSeminar);
    FmShowSeminar.setCommandListener(this);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  /** Main method */
  public void startApp() {
    display.setCurrent(FmHome);
  }

  /** Handle pausing the MIDlet */
  public void pauseApp() {
  }

  /** Handle destroying the MIDlet */
  public void destroyApp(boolean unconditional) {
  }

  /** Quit the MIDlet */
  public static void quitApp() {
    instance.destroyApp(true);
    instance.notifyDestroyed();
    instance = null;
  }

  public void commandAction (Command cmd , Displayable Disp) {
    if (cmd == cmToRegistForm) {
      St1 = new StringItem("","Groom");// St1 = groom
      St2 = new StringItem("","Bride");// St2 = bride
      St3 = new StringItem("","Birthday");
      St4 = new StringItem("","Birthday");
      St5 = new StringItem("","Login");

      Tf1 = new TextField("Name" , "" , 30 , TextField.ANY); // name Male
      Tf2 = new TextField("Surname" , "" , 30 , TextField.ANY); // surname Male
      Tf3 = new TextField("Address" , "" , 100 , TextField.ANY); // Address Male
      Tf4 = new TextField("Tel." , "" , 11 , TextField.NUMERIC); // Phone
      Tf5 = new TextField("E-mail" , "" , 30 , TextField.EMAILADDR);

      Tf6 = new TextField("Name" , "" , 30 , TextField.ANY); // name Male
      Tf7 = new TextField("Surname" , "" , 30 , TextField.ANY); // surname Male
      Tf8 = new TextField("Address" , "" , 100 , TextField.ANY); // Address Male
      Tf9 = new TextField("Tel." , "" , 11 , TextField.NUMERIC); // Phone
      Tf10 = new TextField("E-mail" , "" , 30 , TextField.EMAILADDR);

      Tf11 = new TextField("Day","",2 , TextField.NUMERIC );
      Tf12 = new TextField("Year" , "" , 4 , TextField.NUMERIC);
      Tf13 = new TextField("Day","",2 , TextField.NUMERIC );
      Tf14 = new TextField("Year" , "" , 4 , TextField.NUMERIC);

      Tf15 = new TextField("Username" , "" , 30 , TextField.ANY);
      Tf16 = new TextField("Password" , "" , 30 , TextField.ANY);

      Cg1 = new ChoiceGroup("Month",Choice.EXCLUSIVE , StMonth , null); // birth month
      Cg2 = new ChoiceGroup("Month",Choice.EXCLUSIVE , StMonth , null); // birth month

      FmRegister.append(St1);
      FmRegister.append(Tf1);
      FmRegister.append(Tf2);
      FmRegister.append(St3);
      FmRegister.append(Tf11);
      FmRegister.append(Cg1);
      FmRegister.append(Tf12);
      FmRegister.append(Tf3);
      FmRegister.append(Tf4);
      FmRegister.append(Tf5);
      FmRegister.append(St2);
      FmRegister.append(Tf6);
      FmRegister.append(Tf7);
      FmRegister.append(St4);
      FmRegister.append(Tf13);
      FmRegister.append(Cg2);
      FmRegister.append(Tf14);
      FmRegister.append(Tf8);
      FmRegister.append(Tf9);
      FmRegister.append(Tf10);
      FmRegister.append(St5);
      FmRegister.append(Tf15);
      FmRegister.append(Tf16);
      FmRegister.addCommand(cmBackToHome);
      FmRegister.addCommand(cmRegister);
      FmRegister.setCommandListener(this);
      display.setCurrent(FmRegister);
    }
    else if (cmd == cmToLoginForm) {
      Tf15 = new TextField("Username" , "" , 30 , TextField.ANY);
      Tf16 = new TextField("Password" , "" , 30 , TextField.ANY);

      FmLogin.append(Tf15);
      FmLogin.append(Tf16);
      FmLogin.addCommand(cmBackToHome);
      FmLogin.addCommand(cmLogin);
      FmLogin.setCommandListener(this);
      display.setCurrent(FmLogin);
    }
    else if (cmd == cmBackToHome) {
      display.setCurrent(FmHome);
      St1 = null;
      St2 = null;
      St3 = null;
      St4 = null;
      St5 = null;
      Tf1 = null;
      Tf2 = null;
      Tf11 = null;
      Tf12 = null;
      Tf3 = null;
      Tf4 = null;
      Tf5 = null;
      Tf6 = null;
      Tf7 = null;
      Tf13 = null;
      Tf14 = null;
      Tf8 = null;
      Tf9 = null;
      Tf10 = null;
      Tf15 = null;
      Tf16 = null;
      Cg1 = null;
      Cg2 = null;
      for (int i = 0 ; i < FmRegister.size() ; i ++ ) {
        FmRegister.delete(i);
        i = 0;
      }
      if (FmRegister.size() > 0) {
        FmRegister.delete(0);
      }
      for (int i = 0 ; i < FmLogin.size() ; i ++ ) {
        FmLogin.delete(i);
        i = 0;
      }
      if (FmLogin.size() > 0) {
        FmLogin.delete(0);
      }
    }
//*******************************************************************
    else if (cmd == cmRegister) {
      String mBirth = Tf11.getString()+ "+" + (Cg1.getSelectedIndex()+1)+ "+" + Tf12.getString() ;
      String fBirth = Tf13.getString()+ "+" + (Cg2.getSelectedIndex()+1)+ "+" + Tf14.getString() ;
      String URL = "?mName="+Tf1.getString()+"&mSurname="+Tf2.getString()+"&mBirthdate="+mBirth+"&mAddress="+Tf3.getString()+"&mPhone="+Tf4.getString()+"&mEmail="+Tf5.getString()+"&fName="+Tf6.getString()+"&fSurname="+Tf7.getString()+"&fBirthdate="+fBirth+"&fAddress="+Tf8.getString()+"&fPhone="+Tf9.getString()+"&fEmail="+Tf10.getString()+"&username="+ Tf15.getString() +"&password=" + Tf16.getString() ;
      String result = new String();
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/Register.jsp" + URL);
      if (result.equals("0")) {
        AlertError = new Alert("Register Fail !" , "Cann't Register" , null , AlertType.ERROR);
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , FmRegister);
        AlertError = null;
      }
      else {

        Tf1 = null;
        Tf2 = null;
        Tf11 = null;
        Tf12 = null;
        Tf3 = null;
        Tf4 = null;
        Tf5 = null;
        Tf6 = null;
        Tf7 = null;
        Tf13 = null;
        Tf14 = null;
        Tf8 = null;
        Tf9 = null;
        Tf10 = null;
        Tf15 = null;
        Tf16 = null;
        Cg1 = null;
        Cg2 = null;

        for (int i = 0 ; i < FmRegister.size() ; i ++ ) {
          FmRegister.delete(i);
          i = 0;
        }
        if (FmRegister.size() > 0) {
          FmRegister.delete(0);
        }
        Tf15 = new TextField("Username" , "" , 30 , TextField.ANY);
        Tf16 = new TextField("Password" , "" , 30 , TextField.ANY);

        FmLogin.append(Tf15);
        FmLogin.append(Tf16);
        FmLogin.addCommand(cmBackToHome);
        FmLogin.addCommand(cmLogin);
        FmLogin.setCommandListener(this);
        display.setCurrent(FmLogin);
      }
      mBirth = null;
      fBirth = null;
      URL = null;
      result = null;
    }

//*******************************************************************
    else if (cmd == cmLogin) {
      Customer_ID = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/Login.jsp?username=" + Tf15.getString() + "&password=" + Tf16.getString());
      String Contact_ID = new String();
      String Contact_Name = new String();
      String Deadline = new String();
      if (Customer_ID.equals("0")) {
        AlertError = new Alert("Login Error !!!" , "Cann't Login." , null , AlertType.ERROR );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , FmLogin);
        AlertError = null;
      }
      else {
        String List_Contact = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ShowContact.jsp?Customer_ID=" + Customer_ID);
        if (List_Contact.equals("0")) {
          display.setCurrent(FmShowContact);
        }
        else {
        int count = 0;
        for (int i = 0; i < List_Contact.length() ; i ++) {
          if (List_Contact.substring(i , i+1).equals("!")){
            count ++;
            if (count == 1) {
              ArrayContact_ID.addElement(List_Contact.substring(0,i));
              List_Contact = List_Contact.substring(i+1 , List_Contact.length());
              i=0;
            }
            if (count == 2) {
              CgContact_ID.append(List_Contact.substring(0,i) , null);
              List_Contact = List_Contact.substring(i+1 , List_Contact.length());
              i=0;
            }
            if (count == 3) {
              ArrayTotalPrice.addElement(List_Contact.substring(0 , i) + " Baht");
              List_Contact = List_Contact.substring(i+1 , List_Contact.length());
              i=0;
            }
            if (count == 4) {
              ArrayDeadline.addElement(List_Contact.substring(0 , i));
              List_Contact = List_Contact.substring(i+1 , List_Contact.length());
              i=0;
              count = 0;
            }
          }
        }
        String Result = (String)ArrayDeadline.elementAt(CgContact_ID.getSelectedIndex());
        if (Result.equals("0")) {
          St6.setText("      -");
        }
        else {
          St6.setText(TranformDate(Result));
        }
        Result = null;
        }
        StWeddingTotalPrice.setText((String)ArrayTotalPrice.elementAt(CgContact_ID.getSelectedIndex()));
        display.setCurrent(FmShowContact);
        List_Contact = null;
      }
      Contact_ID = null;
      Contact_Name = null;
      Deadline = null;
    }

//*******************************************************************
    else if (cmd == cmCreateWeddingContact) {
      String Contact_ID = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CreateWeddingContact.jsp?Customer_ID=" + Customer_ID + "&Contact_Name=" + Tf19.getString());
      ArrayContact_ID.addElement(Contact_ID);
      CgContact_ID.append(Tf19.getString(), null);
      ArrayDeadline.addElement("0");
      ArrayTotalPrice.addElement(" 0");
      if (!((String)ArrayDeadline.elementAt(0)).equals("0")) {
        St6.setText(TranformDate((String)ArrayDeadline.elementAt(0)));
      }
      else
      {
        St6.setText("      -");
      }
      StWeddingTotalPrice.setText((String)ArrayTotalPrice.elementAt(0));
      Tf19.setString("");
      Contact_ID = null;
    }

//*******************************************************************
    else if (cmd == cmSelectContact) {
      ArrayCheckContact.addElement("") ;
      ArrayCheckContact.addElement("") ;
      ArrayCheckContact.addElement("") ;
      ArrayCheckContact.addElement("") ;
      ArrayCheckContact.addElement("") ;
      Wedding_Contact = (String)ArrayContact_ID.elementAt(CgContact_ID.getSelectedIndex()) ;
      CheckContact();
    }

//*******************************************************************
    else if (cmd == cmSelectType) {
      if (ListShowJob.getSelectedIndex() == 0) {
        if (((String)ArrayCheckContact.elementAt(0)).equals("0")) {

           Cg1 = new ChoiceGroup("Place Style" , ChoiceGroup.EXCLUSIVE);
           Cg2 = new ChoiceGroup("Decorate" , ChoiceGroup.EXCLUSIVE);
           CgEntertainStyle = new ChoiceGroup("Capacity" , ChoiceGroup.EXCLUSIVE);
           Tf1 = new TextField("Min Price" , "" , 6 , TextField.NUMERIC);
           Tf2 = new TextField("Max Price" , "" , 6 , TextField.NUMERIC);
           St1 = new StringItem("Reserve Date" , "");
           CgStartDay = new ChoiceGroup("Day" , ChoiceGroup.EXCLUSIVE , StDay , null);
           CgStartMonth = new ChoiceGroup("Month" , ChoiceGroup.EXCLUSIVE , StMonth , null);
           CgStartYear = new ChoiceGroup("Year" , ChoiceGroup.EXCLUSIVE);
           CgDuration = new ChoiceGroup("Time" , ChoiceGroup.EXCLUSIVE);
          Cg1.append("Room" , null);
          Cg1.append("Garden" , null);
          Cg1.append("PoolSide" , null);
          FmSearchSeminar.append(Cg1);
          Cg2.append("Thai" , null);
          Cg2.append("Chinese" , null);
          Cg2.append("International" , null);
          FmSearchSeminar.append(Cg2);
          CgServeType.append("Table" , null);
          CgServeType.append("Buffet" , null);
          FmSearchSeminar.append(CgServeType);
          CgEntertainStyle.append("60-180 persons" , null);
          CgEntertainStyle.append("181-300 persons" , null);
          CgEntertainStyle.append("301-420 persons" , null);
          CgEntertainStyle.append("421-525 persons" , null);
          FmSearchSeminar.append(CgEntertainStyle);
          FmSearchSeminar.append(Tf1);
          FmSearchSeminar.append(Tf2);
          FmSearchSeminar.append(St1);

          CgStartYear.append("2003" , null);
          CgStartYear.append("2004" , null);
          CgStartYear.append("2005" , null);
          FmSearchSeminar.append(CgStartDay);
          FmSearchSeminar.append(CgStartMonth);
          FmSearchSeminar.append(CgStartYear);
          CgDuration.append("6:00 - 11:00" , null);
          CgDuration.append("12:00 - 17:00" , null);
          CgDuration.append("18:00 - 23:00" , null);
          FmSearchSeminar.append(CgDuration);
          FmSearchSeminar.addCommand(cmBackToShowJob);
          FmSearchSeminar.addCommand(cmSeminarSearch);
          FmSearchSeminar.setCommandListener(this);
          FmSearchSeminar.setItemStateListener(this);
          display.setCurrent(FmSearchSeminar) ;
        }
        else {
          String Detail = new String();
          String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ShowSeminar.jsp?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact);
          int count = 0;
          for ( int i = 0 ; i < result.length() ; i ++ ) {
            if (result.substring(i,i+1).equals("!")) {
              count ++;

            if (count == 1) {
              Detail = Detail + "NAME: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 2) {
              Detail = Detail + "PLACE: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 3) {
              Detail = Detail + "STYLE: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 4) {
              Detail = Detail + "SERVE STYLE: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 5) {
              Detail = Detail + "Max. PERSONs: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 6) {
              Detail = Detail + "DATE: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 7) {
              Detail = Detail + "TIME: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 8) {
              Detail = Detail + "PRICE: " + result.substring(0 , i) + " Baht\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            }
          }
          StSeminar.setText(Detail);
          display.setCurrent(this.FmShowSeminar) ;
        }
      }
      if (ListShowJob.getSelectedIndex() == 1) {
        if (((String)ArrayCheckContact.elementAt(1)).equals("0")) {

          St1 = new StringItem("Reserve Date" , "");
          Tf1 = new TextField("Min Price" , "500" , 6 , TextField.NUMERIC);
          Tf2 = new TextField("Max Price" , "" , 6 , TextField.NUMERIC );

         CgEntertainStyle = new ChoiceGroup("Type" , Choice.EXCLUSIVE);
         CgBandType = new ChoiceGroup("Round",Choice.EXCLUSIVE);
         CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
         CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
         CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);

         CgEntertainStyle.append("Wedding" , null);
         CgEntertainStyle.append("Family" , null);
         FmInStudio.append(CgEntertainStyle);
         FmInStudio.append(St1);

         CgStartYear.append("2003" , null);
         CgStartYear.append("2004" , null);
         CgStartYear.append("2005" , null);
         FmInStudio.append(CgStartDay);
         FmInStudio.append(CgStartMonth);
         FmInStudio.append(CgStartYear);
         FmInStudio.append(Tf1);
         FmInStudio.append(Tf2);
         CgBandType.append("9.00 - 11.00" , null);
         CgBandType.append("10.00 - 12.00" , null);
         CgBandType.append("13.00 - 15.00" , null);
         CgBandType.append("14.00 - 16.00" , null);
         CgBandType.append("15.00 - 17.00" , null);
         CgBandType.append("16.00 - 18.00" , null);
         CgBandType.append("17.00 - 19.00" , null);
         CgBandType.append("18.00 - 20.00" , null);
         FmInStudio.append(CgBandType);
         FmInStudio.addCommand(cmBackToShowJob);
         FmInStudio.addCommand(cmSearchInStudio);
         FmInStudio.setCommandListener(this);


          display.setCurrent(FmInStudio) ;
        }
        else {
          String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ShowPhoto.jsp?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact);
          int count = 0;
          String Detail = new String();
          for ( int i = 0 ; i < result.length() ; i ++ ) {
            if (result.substring(i,i+1).equals("!")) {
              count ++;

            if (count == 1) {
              Band_ID = result.substring( 0 , i + 1);
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 2) {
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 3) {
              Detail = Detail + "TYPE NAME: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 4) {
              Detail = Detail + "DETAIL: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 5) {
              Detail = Detail + "RESERVE DATE: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 6) {
              Detail = Detail + "ROUND: " + result.substring(0 , i) + "\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            if (count == 7) {
              Detail = Detail + "PRICE: " + result.substring(0 , i) + " Baht\n";
              result = result.substring( i + 1 , result.length());
              i = 0;
            }
            }
          }
          StInStudio.setText(Detail);
          display.setCurrent(FmShowInStudio) ;
        }
      }
      if (ListShowJob.getSelectedIndex() == 2) {
        if (((String)ArrayCheckContact.elementAt(2)).equals("0")) {

           Tf1 = new TextField("Min Price" , "" , 5 , TextField.NUMERIC);
           Tf2 = new TextField("Max Price" , "" , 5 , TextField.NUMERIC);

         CgEntertainStyle = new ChoiceGroup("Gift Type" , Choice.EXCLUSIVE);
         CgBandType = new ChoiceGroup("Gift Style",Choice.EXCLUSIVE);

         CgEntertainStyle.append("Picture frame" , null);
         CgEntertainStyle.append("Souvenior book" , null);
         CgEntertainStyle.append("Fragance candles" , null);
         CgEntertainStyle.append("Key ring" , null);
         CgEntertainStyle.append("Home accent" , null);
         CgEntertainStyle.append("Wedding card" , null);
         CgEntertainStyle.append("Guestbook" , null);
         CgEntertainStyle.append("Wedding box" , null);
         CgEntertainStyle.append("Others" , null);
         FmSearchGift.append(CgEntertainStyle);
         CgBandType.append("All" , null);
         CgBandType.append("Thai" , null);
         CgBandType.append("International" , null);
         CgBandType.append("Chinese" , null);
         FmSearchGift.append(CgBandType);
         FmSearchGift.append(Tf1);
         FmSearchGift.append(Tf2);
         FmSearchGift.addCommand(cmBackToShowJob);
         FmSearchGift.addCommand(cmSearchGift);
         FmSearchGift.setCommandListener(this);

          display.setCurrent(FmSearchGift) ;
        }
        else {
          String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ShowGift.jsp?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact);
          String Detail = new String();
          int count = 0;
          for ( int i = 0 ; i < result.length() ; i ++ ) {
            if (result.substring(i , i + 1).equals("!")) {
              count ++;
              if (count == 2) {
                Detail = Detail + "TYPE NAME: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 3) {
                Detail = Detail + "DETAIL: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 4) {
                Detail = Detail + "LABEL: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 5) {
                Detail = Detail + "RECEIVE DATE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 6) {
                Detail = Detail + "QUANTITY: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 7) {
                Detail = Detail + "TOTAL PRICE: " + result.substring(0 , i) + " Baht\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
            }
          }
          StGift.setText(Detail);
          Detail = null;
          display.setCurrent(FmGift) ;
        }
      }
      else if (ListShowJob.getSelectedIndex() == 3) {
        if (((String)ArrayCheckContact.elementAt(3)).equals("0")) {
          Tf1 = new TextField("Min Price" , "500" , 6 , TextField.NUMERIC);
          Tf2 = new TextField("Max Price" , "" , 6 , TextField.NUMERIC );
          CgEntertainStyle = new ChoiceGroup("Style" , Choice.EXCLUSIVE);
          CgBandType = new ChoiceGroup("Band Type",Choice.EXCLUSIVE);
          CgStartHour = new ChoiceGroup("Hour" , Choice.EXCLUSIVE);
          CgStartMinute = new ChoiceGroup("Minute" , Choice.EXCLUSIVE);
          CgDuration = new ChoiceGroup("Duration",Choice.EXCLUSIVE);
          CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
          CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
          CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);
          CgEntertainStyle.append("Thai" , null);
          CgEntertainStyle.append("Classic" , null);
          CgEntertainStyle.append("Chinese" , null);
          FmSearchEntertainment.append(CgEntertainStyle);
          CgBandType.append("Thai Wedding Parade",null);
          CgBandType.append("Thai Band",null);
          CgBandType.append("Classic Band",null);
          CgBandType.append("Chinese Band",null);
          FmSearchEntertainment.append(CgBandType);
          FmSearchEntertainment.append(Tf1);
          FmSearchEntertainment.append(Tf2);

          for (int i = 0; i < 24 ; i ++ ) {
            CgStartHour.append(intToString(i) , null);
          }
          CgStartMinute.append("00" , null);
          CgStartMinute.append("30" , null);

          CgDuration.append("3 Hours" , null);
          CgDuration.append("4 Hours" , null);
          CgDuration.append("5 Hours" , null);
          CgDuration.append("6 Hours" , null);
          FmSearchEntertainment.append(CgStartDay);
          CgStartYear.append("2003" , null);
          CgStartYear.append("2004" , null);
          CgStartYear.append("2005" , null);
          FmSearchEntertainment.append(CgStartMonth);
          FmSearchEntertainment.append(CgStartYear);
          FmSearchEntertainment.append(CgStartHour);
          FmSearchEntertainment.append(CgStartMinute);
          FmSearchEntertainment.append(CgDuration);
          FmSearchEntertainment.addCommand(cmBackToShowJob);
          FmSearchEntertainment.addCommand(cmSearchEntertainment);
          FmSearchEntertainment.setCommandListener(this);
          display.setCurrent(FmSearchEntertainment) ;
        }
        else {
          String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ShowEntertain.jsp?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact);
          int count = 0;
          String Detail = new String();
          for ( int i = 0 ; i < result.length() ; i ++ ) {
            if (result.substring(i , i + 1).equals("!")) {
              count ++;
              if (count == 1) {
                Band_ID = result.substring(0,i);
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 2) {
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 3) {
                Detail = Detail + "BAND NAME: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 4) {
                Detail = Detail + "DETAIL: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 5) {
                Detail = Detail + "START DATE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 6) {
                Detail = Detail + "FINISH DATE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 7) {
                Detail = Detail + "PLACE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 8) {
                Detail = Detail + "FUNCTIONTYPE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 10) {
                Detail = Detail + "ADDITIONAL REQUESTS: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 11) {
                Detail = Detail + "DEADLINE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
            }
          }
          StEntertain.setText(Detail);
          Detail = null;
          display.setCurrent(FmEntertainment);
            result = null;
        }
      }
      else if (ListShowJob.getSelectedIndex() == 4) {
        if (((String)ArrayCheckContact.elementAt(4)).equals("0")) {

           St1 = new StringItem("Start Date" , "");// = new StringItem("","Groom");// St1 = groom
           St2 = new StringItem("Finish Date" , "");
           Tf1 = new TextField("Min Price" , "" , 5 , TextField.NUMERIC);// = new TextField("Name" , "" , 30 , TextField.ANY); // name Male
           Tf2 = new TextField("Max Price" , "" , 5 , TextField.NUMERIC);// = new TextField("Surname" , "" , 30 , TextField.ANY); // surname Male

          CgEntertainStyle = new ChoiceGroup("Continent" , Choice.EXCLUSIVE);
          CgBandType = new ChoiceGroup("Country",Choice.EXCLUSIVE);
          CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
          CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
          CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);
           CgDuration = new ChoiceGroup("Grade",Choice.EXCLUSIVE);

          CgFinishDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
          CgFinishMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
          CgFinishYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);

          CgEntertainStyle.append("Asia" , null);
          CgEntertainStyle.append("Australia" , null);
          CgEntertainStyle.append("North America" , null);
          CgEntertainStyle.append("Europe" , null);
          FmSearchTour.append(CgEntertainStyle);
          CgBandType.append("Thai" , null);
          CgBandType.append("Japan" , null);
          CgBandType.append("China" , null);
          CgBandType.append("North Korea" , null);
          CgBandType.append("South Korea" , null);
          CgBandType.append("India" , null);
          CgBandType.append("Russia" , null);
          CgBandType.append("Singapore" , null);
          FmSearchTour.append(CgBandType);

          CgStartYear.append("2003" , null);
          CgStartYear.append("2004" , null);
          CgStartYear.append("2005" , null);

          CgFinishYear.append("2003" , null);
          CgFinishYear.append("2004" , null);
          CgFinishYear.append("2005" , null);
          FmSearchTour.append(St1);
          FmSearchTour.append(CgStartDay);
          FmSearchTour.append(CgStartMonth);
          FmSearchTour.append(CgStartYear);
          FmSearchTour.append(St2);
          FmSearchTour.append(CgFinishDay);
          FmSearchTour.append(CgFinishMonth);
          FmSearchTour.append(CgFinishYear);
          FmSearchTour.append(Tf1);
          FmSearchTour.append(Tf2);
          CgDuration.append("*" , null);
          CgDuration.append("**" , null);
          CgDuration.append("***" , null);
          CgDuration.append("****" , null);
          CgDuration.append("*****" , null);
          FmSearchTour.append(CgDuration);
          FmSearchTour.addCommand(cmBackToShowJob);
          FmSearchTour.addCommand(cmSearchTour);
          FmSearchTour.setItemStateListener(this);
          FmSearchTour.setCommandListener(this);

          display.setCurrent(FmSearchTour) ;
        }
        else {
          String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ShowTour.jsp?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact);
          String Detail = new String();
          int count = 0;
          for ( int i = 0 ; i < result.length() ; i ++ ) {
            if (result.substring(i , i + 1).equals("!")) {
              count ++;
              if (count == 1) {
                Detail = Detail + "JOB ID: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 2) {
                Detail = Detail + "PACKAGE NAME: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
              if (count == 3) {
                Detail = Detail + "START DATE: " + result.substring(0 , i) + "\n";
                result = result.substring( i + 1 , result.length());
                i = 0;
              }
            }
          }
          StTour.setText(Detail);
          display.setCurrent(FmTour) ;
        }
      }
    }

//*******************************************************************
    else if(cmd == cmCancelEntertain) {
      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact + "&Contact_ID=" + Band_ID;
      connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CancelEntertain.jsp" + URL);
      CheckContact();
      URL = null;
    }

//*******************************************************************
    else if (cmd == cmSearchEntertainment) {
      ArrayResultEntertain = new Vector();
      String URL = "?Style=" + CgEntertainStyle.getString(CgEntertainStyle.getSelectedIndex()) + "&Type=" + (CgBandType.getSelectedIndex() + 1)+ "&MinPrice=" + Tf1.getString() + "&MaxPrice=" + Tf2.getString() + "&StartDay=" + (CgStartDay.getSelectedIndex() + 1) + "&StartMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&StartYear=" + CgStartYear.getString(CgStartYear.getSelectedIndex()) + "&StartHour=" + CgStartHour.getString(CgStartHour.getSelectedIndex()) + "&StartMinute=" + CgStartMinute.getString(CgStartMinute.getSelectedIndex()) + "&Duration=" + (CgDuration.getSelectedIndex() + 3);
      String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/SearchEntertain.jsp" + URL);
      if (result.equals("0")) {
        AlertError = new Alert("Not Found !" , "Not Found ." , null , AlertType.INFO );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , FmSearchEntertainment);
        AlertError = null;
      }
      else {

      for (int i = 0 ; i < FmSearchEntertainment.size() ; i ++ ) {
        FmSearchEntertainment.delete(i);
        i = 0;
      }
      if (FmSearchEntertainment.size() > 0) {
        FmSearchEntertainment.delete(0);
      }

      St1 =null;
      St2 = null;
      Tf1 = null;
      Tf2 = null;

     CgBandType = null;
     CgStartDay = null;
     CgStartMonth = null;
     CgStartYear = null;
     CgDuration = null;
     CgFinishDay  = null;
     CgFinishMonth = null;
     CgFinishYear = null;
      CgEntertainStyle = null;
      CgBandType = null;
      CgStartHour = null;
      CgStartMinute = null;
      CgDuration = null;


      int count = 0;
      String Temp = new String();
      String Temp2 = new String();
      for (int i = 0; i < result.length() ; i ++) {
        if (result.substring(i , i+1).equals("!")){
          count ++;
          if (count == 1) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " BAND ID: " + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 2) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " TYPE NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 3) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " BAND TYPE ID: "  + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 4) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " BAND NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 5) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " PRICE AM: "  + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 6) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " PRICE PM: " + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 7) {
            Temp = Temp + result.substring(0 , i) + "!";
            Temp2 = Temp2 + " ENTERTAIN NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 8) {
            Temp = Temp + result.substring(0 , i) + "!";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 9) {
            Temp = Temp + result.substring(0 , i) + "!";
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 10) {
            Temp = Temp + result.substring(0 , i) + "!";
            ArrayResultEntertain.addElement(Temp);
            ListResultSearchEntertain.append(Temp2 , null);
            Temp = "";
            Temp2 = "";
            result = result.substring(i+1 , result.length());
            i=0;
            count = 0;
          }
        }
      }
      Temp = null;
      Temp2 = null;
      ListResultSearchEntertain.append("1",null);
      display.setCurrent(ListResultSearchEntertain);
      }
      URL = null;
      result = null;
    }

//*****************************************************************
    else if (cmd == cmSelectEntertain) {
      String result = (String)ArrayResultEntertain.elementAt(ListResultSearchEntertain.getSelectedIndex());
      if (result.equals("0")) {
        AlertError = new Alert("Error !" , "Error !" , null , AlertType.ERROR );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , ListResultSearchEntertain);
        AlertError = null;

      }
      else {

         St1 = new StringItem ("Type Name" , "");
         St2 = new StringItem ("Band Name" , "");
         St3 = new StringItem ("Price AM" , "");
         St4 = new StringItem ("Price PM" , "");
         St5 = new StringItem ("FROM" , "");
         St11 = new StringItem ("Start Date" , "");
         St12 = new StringItem ("Finish Date" , "");
         Tf3 = new TextField("Additional Request" , "" , 200 , TextField.ANY);
         Tf4 = new TextField("Place" , "" , 50 , TextField.ANY);


          FmReserveEntertain.append(St1);
          FmReserveEntertain.append(St2);
          FmReserveEntertain.append(St3);
          FmReserveEntertain.append(St4);
          FmReserveEntertain.append(St5);
          FmReserveEntertain.append(St11);
          FmReserveEntertain.append(St12);
          FmReserveEntertain.append(Tf3);
          FmReserveEntertain.append(Tf4);
          FmReserveEntertain.addCommand(cmBackToEntertain);
          FmReserveEntertain.addCommand(cmReserveEntertain);
          FmReserveEntertain.setCommandListener(this);



        String Temp_Result = new String();
      int count = 0;
      for (int i = 0; i < result.length() ; i ++) {
        if (result.substring(i , i+1).equals("!")){
          count ++;
          if (count == 1) {
            Band_ID = result.substring(0 , i);
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 2) {
            St1.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 3) {
            Band_Type_ID = result.substring(0 ,i);
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 4) {
            St2.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 5) {
            St3.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 6) {
            St4.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 7) {
            St5.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 8) {
            Entertain = result.substring(0 , i);
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 9) {
            St11.setText(result.substring(0 , i));
            St6.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
          }
          if (count == 10) {
            St12.setText(result.substring(0 , i));
            StWeddingTotalPrice.setText(result.substring(0 , i));
            result = result.substring(i+1 , result.length());
            i=0;
            count = 0;
          }
        }
      }
      Temp_Result = null;
      display.setCurrent(FmReserveEntertain);
      }
      result = null;
    }

//*****************************************************************
    else if (cmd == cmBackToEntertain) {
      for (int i = 0 ; i < FmReserveEntertain.size() ; i ++) {
        FmReserveEntertain.delete(i);
        i = 0;
      }
      if (FmReserveEntertain.size() > 0) {
        FmReserveEntertain.delete(0);
      }
      St1 = null;
      St2 = null;
      St3 = null;
      St4 = null;
      St5 = null;
      St11 = null;
      St12 = null;
      Tf3 = null;
      Tf4 = null;
      display.setCurrent(ListResultSearchEntertain);
    }

//*****************************************************************
    else if (cmd == cmReserveEntertain) {
      String Temp = St6.getText();//use St6 for reserve memory it refer to StStartDate
      String Start_Date1 = new String();
      String Finish_Date1 = new String();
      int count = 0;
      for (int i = 0; i < Temp.length() ; i ++) {
        if (Temp.substring(i , i+1).equals(" ")){
          count ++;
          Start_Date1 = Start_Date1 + Temp.substring(0 , i) + "+";
          Temp = Temp.substring(i+1 , Temp.length());
          i=0;
        }
        if (count == 3) {
          Start_Date1 = Start_Date1 + Temp;
          i = Temp.length();
        }
      }
      count = 0;
      Temp = StWeddingTotalPrice.getText();//use StWedding for reserve memory refer to StFinishDate
      for (int i = 0; i < Temp.length() ; i ++) {
        if (Temp.substring(i , i+1).equals(" ")){
          count ++;
          Finish_Date1 = Finish_Date1 + Temp.substring(0 , i) + "+";
          Temp = Temp.substring(i+1 , Temp.length());
          i=0;
        }
        if (count == 3) {
          Finish_Date1 = Finish_Date1 + Temp;
          i = Temp.length();
        }
      }

      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact + "&Band_ID=" + Band_ID + "&Band_Type_ID=" + Band_Type_ID + "&Start_Date=" + Start_Date1 + "&Finish_Date=" + Finish_Date1 + "&Place=" + Tf4.getString() + "&Price_AM=" + St3.getText() + "&Price_PM=" + St4.getText() + "&Additional=" + Tf3.getString() + "&Entertain=" + Entertain;
      String result = new String();
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ReserveEntertain.jsp" + URL);
      if (result.equals("0")) {
        AlertError = new Alert("Reserve Error !" , "Reserve Entertainment error ." , null , AlertType.ERROR );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , FmReserveEntertain);
        AlertError = null;

      }
      else {
        for (int i = 0; i < ListResultSearchEntertain.size() ; i ++) {
          ListResultSearchEntertain.delete(i);
          i = 0;
        }
        if (ListResultSearchEntertain.size() > 0) {
          ListResultSearchEntertain.delete(0);
        }

        for (int i = 0; i < FmSearchEntertainment.size() ; i ++) {
          FmSearchEntertainment.delete(i);
          i = 0;
        }
        if (FmSearchEntertainment.size() > 0) {
          FmSearchEntertainment.delete(0);
        }
        for (int i = 0; i < FmReserveEntertain.size() ; i ++) {
          FmReserveEntertain.delete(i);
          i = 0;
        }
        if (FmReserveEntertain.size() > 0) {
          FmReserveEntertain.delete(0);
        }

        CgEntertainStyle = null;
        CgBandType = null;
        CgStartHour = null;
        CgStartMinute = null;
        CgDuration = null;
        Tf1 = null;
        Tf2 = null;
        St1 = null;
        St2 = null;
        St3 = null;
        St4 = null;
        St5 = null;
        St11 = null;
        St12 = null;
        Tf3 = null;
        Tf4 = null;

        St1 = new StringItem("Result" , "");
        FmResultReserveEntertain.addCommand(cmBackToJobList);
        FmResultReserveEntertain.append(St1);
        FmResultReserveEntertain.setCommandListener(this);

        ArrayResultEntertain.removeAllElements();
        ArrayResultEntertain = null;
        count = 0;
        String Detail = new String();
        for (int i = 0; i < result.length() ; i ++) {
          if (result.substring(i , i+1).equals(" ")){
            count ++;
            if (count == 1) {
              Detail = Detail + "DEADLINE: " + result.substring( 0 , i ) + "\n";
              result = result.substring(i + 1, result.length());
              i = 0;
            }
            if (count == 2) {
              Detail = Detail + "TOTAL PRICE: " + result.substring( 0 , i ) + "\n";
              result = result.substring(i + 1, result.length());
              i = 0;
            }
          }
        }
        St1.setText(Detail);
        Detail = null;
        display.setCurrent(FmResultReserveEntertain);
      }
      Temp = null;
      Start_Date1 = null;
      Finish_Date1 = null;
      URL = null;
      result = null;
      Entertain = null;
      Band_ID = null;
      Band_Type_ID = null;
    }

//************************************************************************
    else if (cmd == cmBackToJobList) {
      for (int i = 0; i < FmInStudio.size() ; i ++) {
        FmInStudio.delete(i);
        i = 0;
      }
      if (FmInStudio.size() > 0) {
        FmInStudio.delete(0);
      }
      for (int i = 0; i < FmSearchEntertainment.size() ; i ++) {
        FmSearchEntertainment.delete(i);
        i = 0;
      }
      if (FmSearchEntertainment.size() > 0) {
        FmSearchEntertainment.delete(0);
      }
      for (int i = 0; i < FmSearchTour.size() ; i ++) {
        FmSearchTour.delete(i);
        i = 0;
      }
      if (FmSearchTour.size() > 0) {
        FmSearchTour.delete(0);
      }
      for (int i = 0; i < FmSearchGift.size() ; i ++) {
        FmSearchGift.delete(i);
        i = 0;
      }
      if (FmSearchGift.size() > 0) {
        FmSearchGift.delete(0);
      }


      CheckContact();
    }

//***********************************************************************
    else if (cmd == cmSearchTour) {

      ArrayTourDetail = new Vector();
      String result = new String();
      String URL = "?Continent=" + (CgEntertainStyle.getSelectedIndex() + 1) + "&Country=" + CgBandType.getSelectedIndex() + "&StartDay=" + (CgStartDay.getSelectedIndex() + 1) + "&StartMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&StartYear=" + CgStartYear.getSelectedIndex() + "&FinishDay=" + CgFinishDay.getSelectedIndex() + "&FinishMonth=" + CgFinishMonth.getSelectedIndex() + "&FinishYear=" + CgFinishYear.getString(CgFinishYear.getSelectedIndex()) + "&MinPrice=" + Tf1.getString() + "&MaxPrice=" + Tf2.getString() + "&Grade=" + (CgDuration.getSelectedIndex() + 1);
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/SearchTour.jsp" + URL);
      if (!(result.equals("0"))) {
      String Tour = new String();
      String Detail = new String();
      int count = 0;
      for (int i = 0; i < result.length() ; i ++) {
        if (result.substring(i , i+1).equals("!")){
          count ++;
          if (count == 1) {
            Tour = Tour + "PACKAGE ID = " + result.substring(0 , i) + "\n";
            Detail = Detail + result.substring(0 , i) + "!";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 2) {
            Tour = Tour + "PRICE: " + result.substring(0 , i) + " Baht\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 3) {
            Tour = Tour + "TOUR NAME: " + result.substring(0 , i) + "\n";
            Detail = Detail + result.substring(0 , i) + "!";
            result = result.substring(i + 1 , result.length());
            i = 0;
            count = 0;
            ArrayTourDetail.addElement(Detail);
            ListResultSearchTour.append(Tour , null);
            Tour = "";
            Detail = "";
          }
        }
      }

      display.setCurrent(ListResultSearchTour);
      Tour = null;
      Detail = null;
      }
      else {
        AlertError = new Alert("Not Found !" , "Not Found ." , null , AlertType.INFO );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , FmSearchTour);
        AlertError = null;

      }
      result = null;
      URL = null;
    }

//***********************************************************************
    else if (cmd == cmSelectTour) {
      St3 = new StringItem("Tour" , "");
      FmSelectTour.append(St3);
      FmSelectTour.addCommand(cmTourBackToShowJob);
      FmSelectTour.addCommand(cmSelectReserveTour);
      FmSelectTour.setCommandListener(this);
      String result = new String();
      String URL = "?Detail=" + (String)ArrayTourDetail.elementAt(ListResultSearchTour.getSelectedIndex());
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/SearchPackage.jsp" + URL);
      String Detail = new String();
      int count = 0;
      for (int i = 0 ; i < result.length() ; i ++ ) {
        if (result.substring(i , i + 1).equals("!")) {
          count ++ ;
          if (count == 1) {
            Detail = Detail + "PACKAGE NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 2) {
            Detail = Detail + "START DATE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 3) {
            Detail = Detail + "FINISH DATE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 4) {
            Detail = Detail + "DEADLINE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 5) {
            Detail = Detail + "CONTINENT: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 6) {
            Detail = Detail + "COUNTRY: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 7) {
            Detail = Detail + "CITY: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          if (count == 8) {
            Detail = Detail + "PLACE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
            count = 4;
          }

        }
        else if (result.substring(i , i + 1).equals("#")) {
          Detail = Detail + "VEHICLE: " + result.substring(0 , i) + "\n";
          result = result.substring(i + 1 , result.length());
          i = 0;
        }
      }
      St3.setText(Detail);
      display.setCurrent(this.FmSelectTour);
      result = null;
      URL = null;
      Detail = null;
    }

//***********************************************************************
    else if (cmd == cmSelectReserveTour) {

      St4 = new StringItem("TOUR" , "");
      Tf3 = new TextField("QUANTITY" , "" , 2 , TextField.NUMERIC);
      FmReserveTour.append(St4);
      FmReserveTour.append(Tf3);
      FmReserveTour.addCommand(cmTourBackToShowJob);
      FmReserveTour.addCommand(cmReserveTour);
      FmReserveTour.setCommandListener(this);
      int count = 0;
      String Temp = (String)ArrayTourDetail.elementAt(ListResultSearchTour.getSelectedIndex());
      String Detail = new String();
      for (int i = 0 ; i < Temp.length() ; i ++ ){
        if (Temp.substring(i , i + 1).equals("!")) {
          count ++;
          if (count == 1) {
            Detail = Detail + "PACKAGE ID: " + Temp.substring(0 , i) + "\n";
            Temp = Temp.substring(i + 1 , Temp.length());
            i = 0;
          }
          if (count == 2) {
            Detail = Detail + "TOUR NAME: " + Temp.substring(0 , i) + "\n";
            Temp = Temp.substring(i + 1 , Temp.length());
            i = 0;
          }
        }
      }
      St4.setText(Detail);
      display.setCurrent(FmReserveTour);
      Detail = null;
      Temp = null;
    }

//***********************************************************************
    else if (cmd == cmReserveTour) {
      String result = new String();
      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact + "&Quantity=" + this.Tf3.getString() + "&Detail=" + (String)ArrayTourDetail.elementAt(ListResultSearchTour.getSelectedIndex());
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ReserveTour.jsp" + URL);

      ArrayTourDetail.removeAllElements();
      ArrayTourDetail = null;
      result = null;
      URL = null;
//      StTourDetail.setText("");
//      StReserveTour.setText("");
      for (int i = 0 ; i < ListResultSearchTour.size() ; i ++) {
        ListResultSearchTour.delete(i);
        i = 0;
      }
      if (ListResultSearchTour.size() > 0) {
        ListResultSearchTour.delete(0);
      }
      for (int i = 0 ; i < FmSearchTour.size() ; i ++) {
        FmSearchTour.delete(i);
        i = 0;
      }
      if (FmSearchTour.size() > 0) {
        FmSearchTour.delete(0);
      }
      if (FmSelectTour.size() > 0) {
        FmSelectTour.delete(0);
      }
      for (int i = 0 ; i < FmReserveTour.size() ; i ++) {
        FmReserveTour.delete(i);
        i = 0;
      }
      if (FmReserveTour.size() > 0) {
        FmReserveTour.delete(0);
      }

      St1 =null;
      St2 =null;
      St3 = null;
      St4 = null;
      Tf1 =null;
      Tf2 =null;
      Tf3 = null;

     CgEntertainStyle =null;
     CgBandType =null;
     CgStartDay =null;
     CgStartMonth =null;
     CgStartYear =null;
      CgDuration =null;

     CgFinishDay =null;
     CgFinishMonth =null;
     CgFinishYear =null;

      CheckContact();
      result = null;
      URL = null;
    }

//***********************************************************************
    else if (cmd == cmCancelTour) {
      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact;
      connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CancelTour.jsp" + URL);
      URL = null;
      StTour.setText("");
      CheckContact();
    }


//***********************************************************************
    else if (cmd == cmSearchInStudio) {

      ArrayInStudioSubType = new Vector();
      ArrayPhotoStudio = new Vector();
      String result = new String();
      String URL = "?StartDay=" + (CgStartDay.getSelectedIndex() + 1) + "&StartMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&StartYear=" + (CgStartYear.getSelectedIndex() + 2003) + "&MinPrice=" + Tf1.getString() + "&MaxPrice=" + Tf2.getString() + "&Round=" + (CgBandType.getSelectedIndex() + 1) + "&InStudioType=" + (CgEntertainStyle.getSelectedIndex() + 1) + "&Cheap=true";// + CgInStudioCheap.getSelectedIndex();
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/SearchInStudio.jsp" + URL);
      if (result.equals("0")) {
        AlertError = new Alert("Not Found !" , "Not Found ." , null , AlertType.INFO );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , FmInStudio);
        AlertError = null;

      }
      else {
        int count = 0;
        String Temp = new String();
        for (int i = 0; i < result.length() ; i ++) {
          if (result.substring(i , i+1).equals("!")){
            count ++;
            if (count == 1) {
              ArrayInStudioSubType.addElement(result.substring(0 , i));
              result = result.substring(i+1 , result.length());
              i = result.length();
              i = 0;
            }
            else if (count == 2) {
              Temp = Temp + "TYPE NAME: " + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = result.length();
              i = 0;
            }
            else if (count == 3) {
              Temp = Temp + "PRICE: " + result.substring(0 , i) + " Baht\n";
              result = result.substring(i+1 , result.length());
              i = result.length();
              i = 0;
            }
            else if (count == 4) {
              ArrayPhotoStudio.addElement(result.substring(0 , i));
              Temp = Temp + "PHOTO NAME: Photo" + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = result.length();
              i = 0;
              count = 0;
              ListInStudio.append(Temp , null);
              Temp = "";
            }
          }
        }
        display.setCurrent(ListInStudio);
        Temp = null;
      }
      result = null;
      URL = null;
    }

//***********************************************************************
    else if ( cmd == cmReserveInStudio) {
      String result = new String();
      String URL = "?StartDay=" + (CgStartDay.getSelectedIndex() + 1) + "&StartMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&StartYear=" + (CgStartYear.getSelectedIndex() + 2003) + "&PhotoID=" + (String)ArrayPhotoStudio.elementAt(ListInStudio.getSelectedIndex()) + "&Wedding_Contact=" + Wedding_Contact + "&Round=" + (CgBandType.getSelectedIndex() + 1) + "&InStudioType=" + (CgEntertainStyle.getSelectedIndex() + 1) + "&SubType=" + (String)ArrayInStudioSubType.elementAt(ListInStudio.getSelectedIndex()) + "&Customer_ID=" + Customer_ID;
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ReserveInStudio.jsp" + URL);
      for (int i = 0 ; i < ListInStudio.size() ; i ++) {
        ListInStudio.delete(i);
        i = 0;
      }
      if (ListInStudio.size() > 0) {
        ListInStudio.delete(0);
      }
      for (int i = 0 ; i < FmInStudio.size() ; i ++) {
        FmInStudio.delete(i);
        i = 0;
      }
      if (FmInStudio.size() > 0) {
        FmInStudio.delete(0);
      }
      St1 = null;
      Tf1 = null;
      Tf2 = null;

     CgEntertainStyle = null;
     CgBandType = null;
     CgStartDay = null;
     CgStartMonth = null;
     CgStartYear = null;

      ArrayInStudioSubType.removeAllElements() ;
      ArrayInStudioSubType = null;
      ArrayPhotoStudio.removeAllElements();
      ArrayPhotoStudio = null;
      URL = null;
      result = null;
      CheckContact();


    }

//***********************************************************************
    else if ( cmd == cmCancelInStudio) {
      String URL = "?Detail=" + Band_ID + "&Wedding_Contact=" + Wedding_Contact;
      connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CancelPhoto.jsp" + URL);
      StInStudio.setText("");
      CheckContact();
    }

//***********************************************************************
    else if ( cmd == cmBackToShowJob) {
      for (int i = 0; i < FmSearchSeminar.size() ; i ++) {
        FmSearchSeminar.delete(i);
        i = 0;
      }
      if (FmSearchSeminar.size() > 0) {
        FmSearchSeminar.delete(0);
      }
      for (int i = 0; i < FmInStudio.size() ; i ++) {
        FmInStudio.delete(i);
        i = 0;
      }
      if (FmInStudio.size() > 0) {
        FmInStudio.delete(0);
      }
      for (int i = 0; i < FmSearchEntertainment.size() ; i ++) {
        FmSearchEntertainment.delete(i);
        i = 0;
      }
      if (FmSearchEntertainment.size() > 0) {
        FmSearchEntertainment.delete(0);
      }
      for (int i = 0; i < FmSearchTour.size() ; i ++) {
        FmSearchTour.delete(i);
        i = 0;
      }
      if (FmSearchTour.size() > 0) {
        FmSearchTour.delete(0);
      }
      for (int i = 0; i < FmSearchGift.size() ; i ++) {
        FmSearchGift.delete(i);
        i = 0;
      }
      if (FmSearchGift.size() > 0) {
        FmSearchGift.delete(0);
      }
       St1 = null;// = new StringItem("","Groom");// St1 = groom
       St2 = null;// = new StringItem("","Bride");// St2 = bride
       St3 = null;// = new StringItem("","Birthday");
       St4 = null;// = new StringItem("","Birthday");
       St5 = null;// = new StringItem("","Login");

       St11 = null;// = new StringItem ("Type Name" , "");
       St12 = null;// = new StringItem ("Band Name" , "");


       Tf1 = null;
       Tf2 = null;
       Tf3 = null;
       Tf4 = null;
       Tf5 = null;

       Tf6 = null;
       Tf7 = null;
       Tf8 = null;

       Cg1 = null;
       Cg2 = null;

       CgContact_ID  = null;

       CgEntertainStyle  = null;
       CgBandType  = null;
       CgStartDay  = null;
       CgStartMonth  = null;
       CgStartYear  = null;
       CgStartHour  = null;
       CgStartMinute  = null;
       CgDuration  = null;

       CgFinishDay  = null;
       CgFinishMonth  = null;
       CgFinishYear  = null;

      StTour.setText("");
//      StGift.setText("");
      display.setCurrent(ListShowJob);
    }

//***********************************************************************
    else if (cmd == cmSearchGift) {
      ArrayGiftDetail = new Vector();
      ArrayGiftSelect = new Vector();
      String result = new String();
      String URL = "?MinPrice=" + Tf1.getString() + "&MaxPrice=" + Tf2.getString() + "&Type=" + (CgEntertainStyle.getSelectedIndex() + 1) + "&Style=" + CgBandType.getSelectedIndex() + "&Cheap=0";
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/SearchGift.jsp" + URL);
      if (result.equals("0")) {
        AlertError = new Alert("Not Found !" , "Not Found ." , null , AlertType.ERROR );
        AlertError.setTimeout(Alert.FOREVER);
        display.setCurrent(AlertError , this.FmSearchGift );
        AlertError = null;
      }
      else {
        int count = 0;
        String TempResult = new String();
        for (int i = 0; i < result.length() ; i ++) {
          if (result.substring(i , i+1).equals("!")){
            count ++;
            if (count == 3) {
              ArrayGiftDetail.addElement(result.substring(0 , i + 1));
//              TempResult = TempResult + "ID=" + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = 0;
            }
            else if (count == 4) {
              TempResult = TempResult + "NAME: " + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = 0;
            }
            else if (count == 5) {
              TempResult = TempResult + "TYPE NAME: " + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = 0;
            }
            else if (count == 6) {
              TempResult = TempResult + "DETAIL: " + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = 0;
            }
            else if (count == 7) {
              TempResult = TempResult + "PRICE: " + result.substring(0 , i) + " Baht\n";
              result = result.substring(i+1 , result.length());
              i = 0;
            }
            else if (count == 8) {
              TempResult = TempResult + "GIFT NAME: " + result.substring(0 , i) + "\n";
              result = result.substring(i+1 , result.length());
              i = 0;
              count = 0;
              ListResultSearchGift.append(TempResult , null);
              ArrayGiftSelect.addElement(TempResult);
              TempResult = "";
            }
          }
        }
        display.setCurrent(ListResultSearchGift);
        TempResult = null;
      }
      result = null;
      URL = null;
    }

//***********************************************************************
    else if (cmd == cmSelectGift) {

       St1 = new StringItem("Reserve" , "");
       Tf3 = new TextField("Label" , "" , 200 , TextField.ANY);
       St2 = new StringItem("Reserve Date" , "");
       CgStartDay = new ChoiceGroup("Day" , ChoiceGroup.EXCLUSIVE , StDay , null);
       CgStartMonth = new ChoiceGroup("Month" , ChoiceGroup.EXCLUSIVE , StMonth , null);
       CgStartYear = new ChoiceGroup("Year" , ChoiceGroup.EXCLUSIVE);
       Tf4 = new TextField("Address" , "" , 300 , TextField.ANY);
       Tf5 = new TextField("Quantity" , "" , 4 , TextField.NUMERIC);
        FmReserveGift.append(St1);
        FmReserveGift.append(Tf3);
        FmReserveGift.append(St2);

        CgStartYear.append("2003" , null);
        CgStartYear.append("2004" , null);
        CgStartYear.append("2005" , null);

        FmReserveGift.append(CgStartDay);
        FmReserveGift.append(CgStartMonth);
        FmReserveGift.append(CgStartYear);
        FmReserveGift.append(Tf4);
        FmReserveGift.append(Tf5);
        FmReserveGift.addCommand(cmBackToListGift);
        FmReserveGift.addCommand(cmReserveGift);
        FmReserveGift.setCommandListener(this);

      St1.setText((String)ArrayGiftSelect.elementAt(ListResultSearchGift.getSelectedIndex()));
      display.setCurrent(FmReserveGift);
    }

//***********************************************************************
    else if (cmd == cmReserveGift) {
      int count = 0;
      String Type = new String();
      String SubType = new String();
      String GiftNumber= new String();
      String TempReserve = (String)ArrayGiftDetail.elementAt(ListResultSearchGift.getSelectedIndex());
      for (int i = 0; i < TempReserve.length() ; i ++) {
        if (TempReserve.substring(i , i + 1).equals("!")) {
          count ++;
          if (count == 1) {
            Type = TempReserve.substring(0 , i);
            TempReserve = TempReserve.substring(i + 1 , TempReserve.length());
            i = 0;
          }
          else if (count == 2) {
            SubType = TempReserve.substring(0 , i);
            TempReserve = TempReserve.substring(i + 1 , TempReserve.length());
            i = 0;
          }
          else if (count == 3) {
            GiftNumber = TempReserve.substring(0 , i);
            TempReserve = TempReserve.substring(i + 1 , TempReserve.length());
            i = 0;
          }
        }
      }
      String result = new String();
      String URL = "?Customer_ID=" + Customer_ID + "&Type=" + Type + "&SubType=" + SubType + "&Label=" + Tf3.getString() + "&ReceiveDay=" + (CgStartDay.getSelectedIndex() + 1) + "&ReceiveMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&ReceiveYear=" + CgStartYear.getSelectedIndex() + "&Address=" + Tf4.getString() + "&Quantity=" + Tf5.getString() + "&GiftNumber=" + GiftNumber + "&Wedding_Contact=" +Wedding_Contact;
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ReserveGift.jsp" + URL);
      String Detail = new String();
      for (int i = 0; i < result.length() ; i ++) {
        if (result.substring(i , i + 1).equals("!")) {
          count ++;
          if (count == 1) {
            Detail = Detail + "TOTAL PRICE: " + result.substring(0 , i) + " Baht\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 2) {
            Detail = Detail + "RECEIVE DATE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
        }
      }
      for (int i = 0 ; i < FmReserveGift.size() ; i ++) {
        FmReserveGift.delete(i);
      }
      if (FmReserveGift.size() > 0) {
        FmReserveGift.delete(0);
      }
      for (int i = 0 ; i < FmSearchGift.size() ; i ++) {
        FmSearchGift.delete(i);
      }
      if (FmSearchGift.size() > 0) {
        FmSearchGift.delete(0);
      }
       Tf1 =null;
       Tf2 =null;

     CgEntertainStyle =null;
     CgBandType =null;

      STResultReserveGift.setText(Detail);
      display.setCurrent(FmResultReserveGift);
      StReserveGift.setText("");
      result = null;
      URL = null;
      Type = null;
      SubType = null;
      GiftNumber = null;
      TempReserve = null;
      ArrayGiftDetail.removeAllElements();
      ArrayGiftDetail = null;
      ArrayGiftSelect.removeAllElements();
      ArrayGiftSelect = null;
      for (int i = 0 ; i < ListResultSearchGift.size() ; i ++) {
        ListResultSearchGift.delete(i);
        i = 0;
      }
      if (ListResultSearchGift.size() > 0) {
        ListResultSearchGift.delete(0);
      }
      CheckContact();
    }

//***********************************************************************
    else if (cmd == cmBackToListGift) {
      for (int i = 0 ; i < FmReserveGift.size() ; i ++) {
        FmReserveGift.delete(i);
        i = 0;
      }
      if (FmReserveGift.size() > 0) {
        FmReserveGift.delete(0);
      }
      display.setCurrent(ListResultSearchGift) ;
    }

//***********************************************************************
    else if (cmd == cmCancelGift) {
      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact;
      connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CancelGift.jsp" + URL);
      StGift.setText("");
      URL = null;
      CheckContact();
    }

//***********************************************************************
    else if (cmd == cmEntertainBackToJob) {
      for (int i = 0; i < ListResultSearchEntertain.size() ; i ++) {
       ListResultSearchEntertain.delete(i);
       i = 0;
      }
     if (ListResultSearchEntertain.size() > 0) {
       ListResultSearchEntertain.delete(0);
     }

     CgEntertainStyle = new ChoiceGroup("Style" , Choice.EXCLUSIVE);
     CgBandType = new ChoiceGroup("Band Type",Choice.EXCLUSIVE);
     CgStartHour = new ChoiceGroup("Hour" , Choice.EXCLUSIVE);
     CgStartMinute = new ChoiceGroup("Minute" , Choice.EXCLUSIVE);
     CgDuration = new ChoiceGroup("Duration",Choice.EXCLUSIVE);
     CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
     CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
     CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);
     Tf1 = new TextField("Min Price" , "" , 5 , TextField.NUMERIC); // name Male
     Tf2 = new TextField("Max Price" , "" , 5 , TextField.NUMERIC); // surname Male
    CgEntertainStyle.append("Thai" , null);
    CgEntertainStyle.append("Classic" , null);
    CgEntertainStyle.append("Chinese" , null);
    FmSearchEntertainment.append(CgEntertainStyle);
    CgBandType.append("Thai Wedding Parade",null);
    CgBandType.append("Thai Band",null);
    CgBandType.append("Classic Band",null);
    CgBandType.append("Chinese Band",null);
    FmSearchEntertainment.append(CgBandType);
    FmSearchEntertainment.append(Tf1);
    FmSearchEntertainment.append(Tf2);

    for (int i = 0; i < 24 ; i ++ ) {
      CgStartHour.append(intToString(i) , null);
    }
    CgStartMinute.append("00" , null);
    CgStartMinute.append("30" , null);

    CgDuration.append("3 Hours" , null);
    CgDuration.append("4 Hours" , null);
    CgDuration.append("5 Hours" , null);
    CgDuration.append("6 Hours" , null);
    FmSearchEntertainment.append(CgStartDay);
    CgStartYear.append("2003" , null);
    CgStartYear.append("2004" , null);
    CgStartYear.append("2005" , null);
    FmSearchEntertainment.append(CgStartMonth);
    FmSearchEntertainment.append(CgStartYear);
    FmSearchEntertainment.append(CgStartHour);
    FmSearchEntertainment.append(CgStartMinute);
    FmSearchEntertainment.append(CgDuration);
    FmSearchEntertainment.addCommand(cmBackToShowJob);
    FmSearchEntertainment.addCommand(cmSearchEntertainment);
    FmSearchEntertainment.setCommandListener(this);
     display.setCurrent(this.FmSearchEntertainment);
    }

//***********************************************************************
    else if (cmd == cmPhotoBackToJob) {
      for (int i = 0; i < this.ListInStudio.size() ; i ++) {
       ListInStudio.delete(i);
       i = 0;
     }
     if (ListInStudio.size() > 0) {
       ListInStudio.delete(0);
     }
     for (int i = 0 ; i < FmInStudio.size() ; i ++) {
       FmInStudio.delete(i);
       i = 0;
     }
     if (FmInStudio.size() > 0) {
       FmInStudio.delete(0);
     }
     this.ArrayPhotoStudio.removeAllElements();
     ArrayPhotoStudio = null;
     St1 = new StringItem("Reserve Date" , "");
     Tf1 = new TextField("Min Price" , "500" , 6 , TextField.NUMERIC);
     Tf2 = new TextField("Max Price" , "" , 6 , TextField.NUMERIC );

    CgEntertainStyle = new ChoiceGroup("Type" , Choice.EXCLUSIVE);
    CgBandType = new ChoiceGroup("Round",Choice.EXCLUSIVE);
    CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
    CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
    CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);

    CgEntertainStyle.append("Wedding" , null);
    CgEntertainStyle.append("Family" , null);
    FmInStudio.append(CgEntertainStyle);
    FmInStudio.append(St1);

    CgStartYear.append("2003" , null);
    CgStartYear.append("2004" , null);
    CgStartYear.append("2005" , null);
    FmInStudio.append(CgStartDay);
    FmInStudio.append(CgStartMonth);
    FmInStudio.append(CgStartYear);
    FmInStudio.append(Tf1);
    FmInStudio.append(Tf2);
    CgBandType.append("9.00 - 11.00" , null);
    CgBandType.append("10.00 - 12.00" , null);
    CgBandType.append("13.00 - 15.00" , null);
    CgBandType.append("14.00 - 16.00" , null);
    CgBandType.append("15.00 - 17.00" , null);
    CgBandType.append("16.00 - 18.00" , null);
    CgBandType.append("17.00 - 19.00" , null);
    CgBandType.append("18.00 - 20.00" , null);
    FmInStudio.append(CgBandType);
    FmInStudio.addCommand(cmBackToShowJob);
    FmInStudio.addCommand(cmSearchInStudio);
    FmInStudio.setCommandListener(this);
     display.setCurrent(this.FmInStudio);
    }

//***********************************************************************
    else if (cmd == cmGiftBackToJob) {
      for (int i = 0; i < ListResultSearchGift.size() ; i ++) {
       ListResultSearchGift.delete(i);
       i = 0;
     }
     if (ListResultSearchGift.size() > 0) {
       ListResultSearchGift.delete(0);
     }
     for (int i = 0 ; i < FmSearchGift.size() ; i ++) {
       FmSearchGift.delete(i);
       i = 0;
     }
     if (FmSearchGift.size() > 0) {
       FmSearchGift.delete(0);
     }
     this.ArrayGiftDetail.removeAllElements();
     this.ArrayGiftSelect.removeAllElements();
     ArrayResultEntertain = null;
     ArrayGiftSelect = null;
     Tf1 = new TextField("Min Price" , "" , 5 , TextField.NUMERIC);
     Tf2 = new TextField("Max Price" , "" , 5 , TextField.NUMERIC);

   CgEntertainStyle = new ChoiceGroup("Gift Type" , Choice.EXCLUSIVE);
   CgBandType = new ChoiceGroup("Gift Style",Choice.EXCLUSIVE);

   CgEntertainStyle.append("Picture frame" , null);
   CgEntertainStyle.append("Souvenior book" , null);
   CgEntertainStyle.append("Fragance candles" , null);
   CgEntertainStyle.append("Key ring" , null);
   CgEntertainStyle.append("Home accent" , null);
   CgEntertainStyle.append("Wedding card" , null);
   CgEntertainStyle.append("Guestbook" , null);
   CgEntertainStyle.append("Wedding box" , null);
   CgEntertainStyle.append("Others" , null);
   FmSearchGift.append(CgEntertainStyle);
   CgBandType.append("All" , null);
   CgBandType.append("Thai" , null);
   CgBandType.append("International" , null);
   CgBandType.append("Chinese" , null);
   FmSearchGift.append(CgBandType);
   FmSearchGift.append(Tf1);
   FmSearchGift.append(Tf2);
   FmSearchGift.addCommand(cmBackToShowJob);
   FmSearchGift.addCommand(cmSearchGift);
   FmSearchGift.setCommandListener(this);

     display.setCurrent(this.FmSearchGift);
    }

//***********************************************************************
    else if (cmd == cmTourBackToShowJob) {
      for (int i = 0; i < ListResultSearchTour.size() ; i ++) {
       ListResultSearchTour.delete(i);
       i = 0;
     }
     if (ListResultSearchTour.size() > 0) {
       ListResultSearchTour.delete(0);
     }
     for (int i = 0 ; i < FmSearchTour.size() ; i ++) {
       FmSearchTour.delete(i);
       i = 0;
     }
     if (FmSearchTour.size() > 0) {
       FmSearchTour.delete(0);
     }
     ArrayTourDetail.removeAllElements() ;
     ArrayTourDetail = null;
     St1 = new StringItem("Start Date" , "");// = new StringItem("","Groom");// St1 = groom
     St2 = new StringItem("Finish Date" , "");
     Tf1 = new TextField("Min Price" , "" , 5 , TextField.NUMERIC);// = new TextField("Name" , "" , 30 , TextField.ANY); // name Male
     Tf2 = new TextField("Max Price" , "" , 5 , TextField.NUMERIC);// = new TextField("Surname" , "" , 30 , TextField.ANY); // surname Male

    CgEntertainStyle = new ChoiceGroup("Continent" , Choice.EXCLUSIVE);
    CgBandType = new ChoiceGroup("Country",Choice.EXCLUSIVE);
    CgStartDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
    CgStartMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
    CgStartYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);
//           CgStartHour = new ChoiceGroup("Hour" , Choice.EXCLUSIVE);
//           CgStartMinute = new ChoiceGroup("Minute" , Choice.EXCLUSIVE);
     CgDuration = new ChoiceGroup("Grade",Choice.EXCLUSIVE);

    CgFinishDay = new ChoiceGroup("Day" , Choice.EXCLUSIVE , StDay , null);
    CgFinishMonth = new ChoiceGroup("Month" , Choice.EXCLUSIVE , StMonth , null);
    CgFinishYear = new ChoiceGroup("Year" , Choice.EXCLUSIVE);

    CgEntertainStyle.append("Asia" , null);
    CgEntertainStyle.append("Australia" , null);
    CgEntertainStyle.append("North America" , null);
    CgEntertainStyle.append("Europe" , null);
    FmSearchTour.append(CgEntertainStyle);
    CgBandType.append("Thai" , null);
    CgBandType.append("Japan" , null);
    CgBandType.append("China" , null);
    CgBandType.append("North Korea" , null);
    CgBandType.append("South Korea" , null);
    CgBandType.append("India" , null);
    CgBandType.append("Russia" , null);
    CgBandType.append("Singapore" , null);
    FmSearchTour.append(CgBandType);

    CgStartYear.append("2003" , null);
    CgStartYear.append("2004" , null);
    CgStartYear.append("2005" , null);

    CgFinishYear.append("2003" , null);
    CgFinishYear.append("2004" , null);
    CgFinishYear.append("2005" , null);
    FmSearchTour.append(St1);
    FmSearchTour.append(CgStartDay);
    FmSearchTour.append(CgStartMonth);
    FmSearchTour.append(CgStartYear);
    FmSearchTour.append(St2);
    FmSearchTour.append(CgFinishDay);
    FmSearchTour.append(CgFinishMonth);
    FmSearchTour.append(CgFinishYear);
    FmSearchTour.append(Tf1);
    FmSearchTour.append(Tf2);
    CgDuration.append("*" , null);
    CgDuration.append("**" , null);
    CgDuration.append("***" , null);
    CgDuration.append("****" , null);
    CgDuration.append("*****" , null);
    FmSearchTour.append(CgDuration);
    FmSearchTour.addCommand(cmBackToShowJob);
    FmSearchTour.addCommand(cmSearchTour);
    FmSearchTour.setItemStateListener(this);
    FmSearchTour.setCommandListener(this);

     display.setCurrent(this.FmSearchTour);
    }

// *******************************************************************
    else if ( cmd == cmBackToContact) {
      for (int i = 0 ; i < FmPayment.size() ; i ++ ) {
        FmPayment.delete(i);
        i = 0 ;
      }
      if (FmPayment.size() > 0 ) {
        FmPayment.delete(0);
      }
      Tf1 = null;
      Tf2 = null;
      Tf3 = null;
      Tf4 = null;
      St1 = null;
      display.setCurrent(FmShowContact);
    }

//***********************************************************************
    if (cmd == cmSeminarSearch) {
      ArraySeminarDetail = new Vector();
      String result = new String();
      String URL = "?PlaceStyle=" + Cg1.getSelectedIndex() + "&Capacity=" + CgEntertainStyle.getSelectedIndex() + "&StartDay=" + (CgStartDay.getSelectedIndex() + 1) + "&StartMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&StartYear=" + (CgStartYear.getSelectedIndex() + 2003) + "&MinPrice=" + Tf1.getString() + "&MaxPrice=" + Tf2.getString() + "&Time=" + CgDuration.getSelectedIndex() ;
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/SearchHotel.jsp" + URL);
      if (result.equals("0")){}
      else {
      int count = 0;
      String Temp1 = new String();
      String Temp2 = new String();
      for (int i = 0; i < result.length() ; i ++) {
        if (result.substring(i , i + 1).equals("!")) {
          count ++;
          if (count == 1) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 2) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            Temp2 = Temp2 + "SEMINAR NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 3) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            Temp2 = Temp2 + "PLACE STYLE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 4) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            Temp2 = Temp2 + "PRICE:" + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 5) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            Temp2 = Temp2 + "MAX. PERSONs(TABLE): " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 6) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            Temp2 = Temp2 + "MAX. PERSONs(BUFFET): " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 7) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            Temp2 = Temp2 + "HOTEL NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 8) {
            Temp1 = Temp1 + result.substring(0 , i + 1);
            result = result.substring(i + 1 , result.length());
            ListResultSearchSeminar.append(Temp2 , null);
            ArraySeminarDetail.addElement(Temp1);
            Temp1 = "";
            Temp2 = "";
            i = 0;
            count = 0;
          }
        }
      }
      Temp1 = null;
      Temp2 = null;
      display.setCurrent(ListResultSearchSeminar);
      }
    }

    //***********************************************************************
    else if (cmd == cmSelectSeminar) {
      int count = 0;
      String Temp2 = new String();
      String result = (String)ArraySeminarDetail.elementAt(ListResultSearchSeminar.getSelectedIndex());
      for (int i = 0; i < result.length() ; i ++) {
        if (result.substring(i , i + 1).equals("!")) {
          count ++;
          if (count == 1) {
            St6.setText(result.substring(0 , i));
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 2) {
            Temp2 = Temp2 + "SEMINAR NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 3) {
            Temp2 = Temp2 + "PLACE STYLE: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 4) {
            Temp2 = Temp2 + "PRICE:" + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 5) {
            Temp2 = Temp2 + "MAX. PERSONs(TABLE): " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 6) {
            Temp2 = Temp2 + "MAX. PERSONs(BUFFET): " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 7) {
            Temp2 = Temp2 + "HOTEL NAME: " + result.substring(0 , i) + "\n";
            result = result.substring(i + 1 , result.length());
            i = 0;
          }
          else if (count == 8) {
            HotelID = result.substring(0 , i);
            result = result.substring(i + 1 , result.length());
            ReserveSeminar.setText(Temp2);
            Temp2 = "";
            i = 0;
            count = 0;
          }
        }
      }
      Temp2 = null;
      result = null;

      display.setCurrent(FmReserveSeminar);
    }

//***********************************************************************
    else if (cmd == cmReserveSeminar) {
      String result = new String();
      Time = "" + CgDuration.getSelectedIndex();
      if (Time.equals("0")) {
        Time = "7";
      }
      else if (Time.equals("1")) {
        Time = "13";
      }
      else if (Time.equals("2")) {
        Time = "19";
      }
      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact + "&HotelID=" + HotelID + "&SeminarID=" + St6.getText() + "&Dec_Style=" + Cg2.getSelectedIndex() + "&StartDay=" + (CgStartDay.getSelectedIndex() + 1) + "&StartMonth=" + (CgStartMonth.getSelectedIndex() + 1) + "&StartYear=" + (CgStartYear.getSelectedIndex() + 2003) + "&Time=" + CgDuration.getSelectedIndex() + "&Men_Per_Room=" + this.TfSeminarMax.getString() + "&Serve_Style=" + this.CgServeType.getSelectedIndex();
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/ReserveSeminar.jsp" + URL);
      for (int i = 0 ; i < ListResultSearchSeminar.size() ; i ++) {
        ListResultSearchSeminar.delete(i);
        i = 0;
      }
      if (ListResultSearchSeminar.size() > 0) {
        ListResultSearchSeminar.delete(0);
      }
      for (int i = 0 ; i < FmSearchSeminar.size() ; i ++) {
        FmSearchSeminar.delete(i);
        i = 0;
      }
      if (FmSearchSeminar.size() > 0) {
        FmSearchSeminar.delete(0);
      }

      ArraySeminarDetail.removeAllElements();
      ArraySeminarDetail = null;
      result = null;
      CheckContact();
    }

//********************************************************************
    else if (cmd == cmCancelSeminar) {
      String URL = "?Customer_ID=" + Customer_ID + "&Wedding_Contact=" + Wedding_Contact;
      connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CancelSeminar.jsp" + URL);
      StSeminar.setText("");
      URL = null;
      CheckContact();
    }

    //********************************************************************
    else if (cmd == cmPayment) {
      Tf1 = new TextField("Credit No." , "" , 16 , TextField.NUMERIC);
      Tf2 = new TextField("Expire Month" , "" , 2 , TextField.NUMERIC);
      Tf3 = new TextField("Expire Year" , "" , 4 , TextField.NUMERIC);
      Tf4 = new TextField("Code" , "" , 4 , TextField.NUMERIC);
      St1 = new StringItem("Price" , "");
      St1.setText(StWeddingTotalPrice.getText());
      FmPayment.append(Tf1);
      FmPayment.append(Tf2);
      FmPayment.append(Tf3);
      FmPayment.append(Tf4);
      FmPayment.append(St1);
      FmPayment.addCommand(cmBackToContact);
      FmPayment.addCommand(cmPaid);
      FmPayment.setCommandListener(this);
      display.setCurrent(FmPayment);
    }
    else if (cmd == cmPaid) {
      String URL = "?Wedding_Contact=" + Wedding_Contact + "&CreditNo=" + Tf1.getString() + "&ExpireMonth=" + Tf2.getString() + "&ExpireYear=" + Tf3.getString() + "&Password=" + Tf4.getString();
      String result = new String();
      result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/payment.jsp" + URL);
      display.setCurrent(FmShowContact);
    }
  }

  public String connect(String URL) {
      HttpConnection http = null;
      InputStream iStrm = null;

      try {
          http = (HttpConnection) Connector.open(URL);
          http.setRequestMethod(HttpConnection.GET);
          http.setRequestProperty("Connection","close");

          iStrm = http.openInputStream();
          String str;
          int length = (int) http.getLength();
          if (length != -1) {
              byte servletData[] = new byte[length];
              iStrm.read(servletData);
              str = new String(servletData);
          }
          else
          {
              ByteArrayOutputStream bStrm = new ByteArrayOutputStream();

              int ch;
              while (( ch = iStrm.read() )!= -1) {
                  bStrm.write(ch);
              }
              str = new String (bStrm.toByteArray());
              bStrm.close();
          }
          http.close();
          iStrm.close();
          return (str);
      }
      catch (Exception e) {
          System.out.println(e);
          return null;
      }
  }
  public String intToString(int i) {
    Integer temp = new Integer(i);
    return temp.toString();
  }
  private void jbInit() throws Exception {
  }

  public void itemStateChanged(Item item) {
    if (item.equals(CgContact_ID)) {
      String Result = (String)ArrayDeadline.elementAt(CgContact_ID.getSelectedIndex());
      if (Result.equals("0")) {
        St6.setText("      -");
      }
      else {
        St6.setText(TranformDate(Result));
      }
      StWeddingTotalPrice.setText((String)ArrayTotalPrice.elementAt(CgContact_ID.getSelectedIndex()));
      Result = null;
    }
/*    else if (item.equals(CgEntertainStyle)) {
      if (CgEntertainStyle.getSelectedIndex() == 0) {
        for (int i = 0 ; i < CgBandType.size() ; i ++ ) {
          CgBandType.delete(i) ;
          i = 0;
        }
        CgBandType.delete(0) ;
        CgBandType.append("Thai" , null);
        CgBandType.append("Japan" , null);
        CgBandType.append("China" , null);
//        CgBandType.append("North Korea" , null);
//        CgBandType.append("South Korea" , null);
//        CgBandType.append("India" , null);
//        CgBandType.append("Russia" , null);
//        CgBandType.append("Singapore" , null);
      }
      else if (CgEntertainStyle.getSelectedIndex() == 1) {
        for (int i = 0 ; i < CgBandType.size() ; i ++ ) {
          CgBandType.delete(i) ;
          i = 0;
        }
        CgBandType.delete(0) ;
        CgBandType.append("New Zealand" , null);
        CgBandType.append("Australia" , null);
      }
      if (CgEntertainStyle.getSelectedIndex() == 2) {
        for (int i = 0 ; i < CgBandType.size() ; i ++ ) {
          CgBandType.delete(i) ;
          i = 0;
        }
        CgBandType.delete(0) ;
        CgBandType.append("Canada" , null);
//        CgBandType.append("Mexico" , null);
        CgBandType.append("United States" , null);
      }
      if (CgEntertainStyle.getSelectedIndex() == 3) {
        for (int i = 0 ; i < CgBandType.size() ; i ++ ) {
          CgBandType.delete(i) ;
          i = 0;
        }
        CgBandType.delete(0) ;
//        CgBandType.append("Belgium" , null);
        CgBandType.append("Denmark" , null);
        CgBandType.append("France" , null);
        CgBandType.append("Germany" , null);
//        CgBandType.append("Ireland" , null);
//        CgBandType.append("Italy" , null);
        CgBandType.append("Netherlands" , null);
//        CgBandType.append("Norway" , null);
        CgBandType.append("Spain" , null);
//        CgBandType.append("Sweden" , null);
//        CgBandType.append("Switzerland" , null);
//        CgBandType.append("Turkey" , null);
        CgBandType.append("United Kingdom" , null);
      }

    }
/*    else if (item.equals(CgServeType)) {
      if (CgServeType.getSelectedIndex() == 0) {
        for (int i = 0 ; i < CgBandType.size() ; i ++ ) {
          CgBandType.delete(i) ;
          i = 0;
        }
        CgBandType.delete(0) ;
        CgBandType.append("60-180 persons" , null);
        CgBandType.append("181-300 persons" , null);
        CgBandType.append("301-420 persons" , null);
        CgBandType.append("421-525 persons" , null);
      }
      else if (CgServeType.getSelectedIndex() == 1) {
        for (int i = 0 ; i < CgBandType.size() ; i ++ ) {
          CgBandType.delete(i) ;
          i = 0;
        }
        CgBandType.delete(0) ;
        CgBandType.append("120-360 persons" , null);
        CgBandType.append("361-600 persons" , null);
        CgBandType.append("601-840 persons" , null);
        CgBandType.append("841-1050 persons" , null);
      }

    }*/
  }
  public void CheckContact() {
    String result = connect("http://161.246.6.101:7001/OlalaWeddingPlanner/web/CheckContact.jsp?Customer_ID=" + Customer_ID + "&Wedding_Contact_ID=" + Wedding_Contact);

    int count = 0;
    for (int i = 0; i < result.length() ; i ++) {
      if (result.substring(i , i+1).equals("!")){
        count ++;
        if (count == 1) {
          ArrayCheckContact.setElementAt(result.substring(0,i),0);
          result = result.substring(i+1 , result.length());
          i=0;
        }
        if (count == 2) {
          ArrayCheckContact.setElementAt(result.substring(0,i),1);
          result = result.substring(i+1 , result.length());
          i=0;
        }
        if (count == 3) {
          ArrayCheckContact.setElementAt(result.substring(0,i),2);
          result = result.substring(i+1 , result.length());
          i=0;
        }
        if (count == 4) {
          ArrayCheckContact.setElementAt(result.substring(0,i),3);
          result = result.substring(i+1 , result.length());
          i=0;
        }
        if (count == 5) {
          ArrayCheckContact.setElementAt(result.substring(0,i),4);
          result = result.substring(i+1 , result.length());
          i=0;
        }
      }
    }
    for ( int i = 0 ; i < ListShowJob.size() ; i ++ ) {
      ListShowJob.delete(i);
      i = 0;
    }
    if (ListShowJob.size() > 0) {
      ListShowJob.delete(0);
    }

    if (((String)ArrayCheckContact.elementAt(0)).equals("0") ) {
      ListShowJob.append("Hotel            Not reserve.",null);
    }
    else {
      ListShowJob.append("Hotel            Reserve complete.",null);
    }
    if (((String)ArrayCheckContact.elementAt(1)).equals("0") ) {
      ListShowJob.append("Photo Studio      Not reserve.",null);
    }
    else {
      ListShowJob.append("Photo Studio      Reserve complete.",null);
    }
    if (((String)ArrayCheckContact.elementAt(2)).equals("0") ) {
      ListShowJob.append("Gift registries    Not reserve.",null);
    }
    else {
      ListShowJob.append("Gift registries    Reserve complete.",null);
    }
    if (((String)ArrayCheckContact.elementAt(3)).equals("0") ) {
      ListShowJob.append("Entertainment    Not reserve.",null);
    }
    else {
      ListShowJob.append("Entertainment    Reserve complete.",null);
    }
    if (((String)ArrayCheckContact.elementAt(4)).equals("0") ) {
      ListShowJob.append("Package Tour     Not reserve.",null);
    }
    else {
      ListShowJob.append("Package Tour     Reserve complete.",null);
    }
    display.setCurrent(ListShowJob);
    result = null;
  }

  public String TranformDate(String TempDate) {
    int count = 0;
    String TempDay = new String();
    String TempMonth = new String();
    String TempYear = new String();
    for (int i = 0 ; i < TempDate.length() ; i ++ ) {
      if (TempDate.substring(i , i + 1).equals("/")) {
        count ++;
        if (count == 1) {
          TempMonth = TempDate.substring(0 , i);
          TempDate = TempDate.substring(i + 1 , TempDate.length());
          i = 0;
        }
        if (count == 2) {
          TempDay = TempDate.substring(0 , i);
          TempYear = TempDate.substring(i + 1 , TempDate.length());
          i = TempDate.length();
        }
      }
    }
    if (TempMonth.equals("1")) {
      TempMonth = "January";
    }
    else if (TempMonth.equals("2")) {
      TempMonth = "February";
    }
    else if (TempMonth.equals("3")) {
      TempMonth = "March";
    }
    else if (TempMonth.equals("4")) {
      TempMonth = "April";
    }
    else if (TempMonth.equals("5")) {
      TempMonth = "May";
    }
    else if (TempMonth.equals("6")) {
      TempMonth = "June";
    }
    else if (TempMonth.equals("7")) {
      TempMonth = "July";
    }
    else if (TempMonth.equals("8")) {
      TempMonth = "August";
    }
    else if (TempMonth.equals("9")) {
      TempMonth = "September";
    }
    else if (TempMonth.equals("10")) {
      TempMonth = "October";
    }
    else if (TempMonth.equals("11")) {
      TempMonth = "November";
    }
    else if (TempMonth.equals("12")) {
      TempMonth = "December";
    }
    return (TempDay + " " + TempMonth + " " + TempYear);
  }
/*
  public String TranformDate2(String TempDate) {
    int count = 0;
    String TempDay = new String();
    String TempMonth = new String();
    String TempYear = new String();
    for (int i = 0 ; i < TempDate.length() ; i ++ ) {
      if (TempDate.substring(i , i + 1).equals(" ")) {
        count ++;
        if (count == 1) {
          TempDay = TempDate.substring(0 , i);
          TempDate = TempDate.substring(i + 1 , TempDate.length());
          i = 0;
        }
        if (count == 2) {
          TempMonth = TempDate.substring(0 , i);
          TempYear = TempDate.substring(i + 1 , TempDate.length());
          i = TempDate.length();
        }
      }
    }
    if (TempMonth.equals("1") || TempMonth.equals("01")) {
      TempMonth = "January";
    }
    else if (TempMonth.equals("2") || TempMonth.equals("02")) {
      TempMonth = "February";
    }
    else if (TempMonth.equals("3") || TempMonth.equals("03")) {
      TempMonth = "March";
    }
    else if (TempMonth.equals("4") || TempMonth.equals("04")) {
      TempMonth = "April";
    }
    else if (TempMonth.equals("5") || TempMonth.equals("05")) {
      TempMonth = "May";
    }
    else if (TempMonth.equals("6") || TempMonth.equals("06")) {
      TempMonth = "June";
    }
    else if (TempMonth.equals("7") || TempMonth.equals("07")) {
      TempMonth = "July";
    }
    else if (TempMonth.equals("8") || TempMonth.equals("08")) {
      TempMonth = "August";
    }
    else if (TempMonth.equals("9") || TempMonth.equals("09")) {
      TempMonth = "September";
    }
    else if (TempMonth.equals("10")) {
      TempMonth = "October";
    }
    else if (TempMonth.equals("11")) {
      TempMonth = "November";
    }
    else if (TempMonth.equals("12")) {
      TempMonth = "December";
    }
    return (TempDay + " " + TempMonth + " " + TempYear);
  }*/
}
