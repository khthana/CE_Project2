package entertainment3;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService3Home extends javax.ejb.EJBHome {
  public BookingService3 create() throws CreateException, RemoteException;
}