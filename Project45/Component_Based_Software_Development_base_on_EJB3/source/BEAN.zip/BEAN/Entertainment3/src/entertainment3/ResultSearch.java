package entertainment3;

import java.io.*;
import java.util.*;

  public class ResultSearch implements Serializable
    {
      public String Band_Style;
      public String Band_Type_Name;
      public String Band_Name;
      public String Band_Detail;
      public double Band_Price_AM;
      public double Band_Price_PM;

      public ResultSearch(String Band_Style , String Band_Type_Name , String Band_Name , String Band_Detail , double Band_Price_AM , double Band_Price_PM)
      { this.Band_Style = Band_Style;
        this.Band_Type_Name = Band_Type_Name;
        this.Band_Name = Band_Name;
        this.Band_Detail = Band_Detail;
        this.Band_Price_AM = Band_Price_AM;
        this.Band_Price_PM = Band_Price_PM;
      }

      public ResultSearch(){}

      private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
      }
      private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
      }

    }
