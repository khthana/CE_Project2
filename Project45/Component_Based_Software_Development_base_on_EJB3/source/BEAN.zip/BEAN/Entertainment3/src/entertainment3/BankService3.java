package entertainment3;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService3 extends javax.ejb.EJBObject {
  public String UpdatePayDate(int Customer_ID, int Band_Contact_ID) throws RemoteException;
  public double CheckTotalPrice(int Customer_ID, int Band_Contact_ID) throws RemoteException;
}