package entertainment3;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService3Home extends javax.ejb.EJBHome {
  public EntertainService3 create() throws CreateException, RemoteException;
}