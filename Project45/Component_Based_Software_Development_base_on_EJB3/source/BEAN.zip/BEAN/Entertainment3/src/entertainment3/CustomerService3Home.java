package entertainment3;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService3Home extends javax.ejb.EJBHome {
  public CustomerService3 create() throws CreateException, RemoteException;
}