package entertainment3;
import java.io.*;
import java.util.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
public class ResultReserveEntertain implements Serializable
  {
    public int Job_Id;
    public String Deadline_Confirm;
    public double Total_Price;

    public ResultReserveEntertain(int Job_Id , String Deadline_Confirm , double Total_Price)
    { this.Job_Id = Job_Id;
      this.Deadline_Confirm = Deadline_Confirm;
      this.Total_Price = Total_Price;
    }


    public ResultReserveEntertain(){}

    private void writeObject(ObjectOutputStream oos) throws IOException {
      oos.defaultWriteObject();
    }
    private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
      ois.defaultReadObject();
    }

  }
