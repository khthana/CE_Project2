package entertainment3;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService3Home extends javax.ejb.EJBHome {
  public BankService3 create() throws CreateException, RemoteException;
}