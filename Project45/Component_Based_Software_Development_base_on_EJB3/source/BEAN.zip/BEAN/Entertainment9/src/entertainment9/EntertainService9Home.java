package entertainment9;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService9Home extends javax.ejb.EJBHome {
  public EntertainService9 create() throws CreateException, RemoteException;
}