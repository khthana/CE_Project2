package entertainment9;

import javax.ejb.*;
import java.io.*;
import java.sql.*;
import javax.naming.*;
import javax.sql.*;
import java.util.*;
import java.text.*;


public class EntertainService9Bean implements SessionBean {
  SessionContext sessionContext;
  private DataSource datasource;

  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
    try{
      Context ctx = new InitialContext();
      datasource = (DataSource)ctx.lookup( "projectDS" );
    }
    catch(Exception e){}
  }

  public Collection SearchForDetail(String Band_Style, int Band_Type_ID, double Min_Price, double Max_Price) {
    Collection ColResult = null;
    ResultSearch tmpResultSearch = null;
    Connection conn = null;
    PreparedStatement prstmt = null;
    ColResult = new ArrayList();

    String Sub_SQL1 = new String();
    String Sub_SQL2 = new String();

    if (Band_Style.equals("")) {
      Sub_SQL1 = "";
    }
    else {
      Sub_SQL1 = " T1.BAND_STYLE = '"+ Band_Style +"' AND ";
    }

    if ((Band_Type_ID == 0)) {
      Sub_SQL2 = "";
    }
    else {
      Sub_SQL2 = " T2.BAND_TYPE_ID = "+ Band_Type_ID +" AND ";
    }

    String command = "SELECT T1.BAND_STYLE , T1.BAND_TYPE_NAME , T2.BAND_NAME " +
                         " , T2.BAND_DETAIL , T2.BAND_PRICE_AM , T2.BAND_PRICE_PM " +
                     " FROM TYPE_NAME9 T1 , ENTERTAIN9 T2 "+
                     " WHERE (T1.BAND_TYPE_ID = T2.BAND_TYPE_ID) " +
                             " AND ("+ Sub_SQL1 + Sub_SQL2 +
                             "((T2.BAND_PRICE_AM >= ? OR T2.BAND_PRICE_PM >= ?) AND "+
                             " (T2.BAND_PRICE_AM <= ? OR T2.BAND_PRICE_PM <= ?)))";
    ResultSet rs = null;
    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement(command);

        prstmt.setDouble(1,Min_Price);
        prstmt.setDouble(2,Min_Price);
        prstmt.setDouble(3,Max_Price);
        prstmt.setDouble(4,Max_Price);

      rs = prstmt.executeQuery();
      while(rs.next()){
        tmpResultSearch = new ResultSearch(rs.getString(1) , rs.getString(2) , rs.getString(3) ,
                          rs.getString(4) , rs.getDouble(5) , rs.getDouble(6));
        ColResult.add(tmpResultSearch);
      }
      rs.close();
      return ColResult;
    }
    catch(SQLException se){
       System.out.println("Exception between Search for Detail");
       throw new EJBException(se+"errror");}
    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
  }

  public Collection SearchForDetailReserveByContact_ID(int Customer_ID, int Band_Contact_ID) {
    Collection colResult = null;
    ResultSearchReserve tmpResultSearchReserve = null;
    Connection conn = null;
    PreparedStatement prstmt = null;
    colResult = new ArrayList();
    ResultSet rs = null;
    String command = "SELECT T2.JOB_ID , TO_CHAR(T2.START_DATETIME,'DD MM YYYY HH24:MI:SS') "+
                         " , T2.FUNCTION_TYPE "+
                     " FROM BAND_CONTACT9 T1 , BAND_ORDER9 T2 "+
                     " WHERE T1.BAND_CONTACT_ID = T2.BAND_CONTACT_ID AND "+
                           " T1.CUSTOMER_ID = T2.CUSTOMER_ID AND "+
                           " T2.BAND_CONTACT_ID = ? AND T2.CUSTOMER_ID = ?";

    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement(command);
      prstmt.setInt(1,Band_Contact_ID);
      prstmt.setInt(2,Customer_ID);
      rs = prstmt.executeQuery();
      while(rs.next()){
        tmpResultSearchReserve = new ResultSearchReserve(rs.getInt(1),rs.getString(2),rs.getString(3));
        colResult.add(tmpResultSearchReserve);
      }
      rs.close();
      return colResult;
    }
    catch(SQLException se){
      System.out.println(se + "Exception between Search by Contact ID");
      throw new EJBException("Exception Error");
    }
    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
  }

  public Collection SearchForDetailReserveByJob_ID(int Customer_ID, int Band_Contact_ID, int Job_ID) {
    /**@todo Complete this method*/
    Collection colResult = null;
    ResultSearchReserve tmpResultSearchReserve = null;
    Connection conn = null;
    PreparedStatement prstmt = null;
    colResult = new ArrayList();
    ResultSet rs = null;
    String command = "SELECT T2.JOB_ID , T3.BAND_ID , T3.BAND_NAME , TO_CHAR(T2.START_DATETIME,'DD MM YYYY HH24:MI:SS')"+
                            " , TO_CHAR(T2.FINISH_DATETIME,'DD MM YYYY HH24:MI:SS') , T2.PLACE , "+
                            " T2.FUNCTION_TYPE , T2.TOTAL_PRICE , TO_CHAR(T1.PAY_DATE,'DD MM YYYY') , "+
                            " T2.ADDITIONAL_REQUESTS , TO_CHAR(T1.DEADLINE_CONFIRM,'DD MM YYYY') "+
                            "  , T3.BAND_DETAIL , T3.BAND_TYPE_ID " +
                     " FROM BAND_CONTACT9 T1 , BAND_ORDER9 T2 , ENTERTAIN9 T3 "+
                     " WHERE T1.BAND_CONTACT_ID = T2.BAND_CONTACT_ID AND "+
                           " T2.BAND_ID = T3.BAND_ID AND "+
                           " T2.BAND_CONTACT_ID = ? AND T2.CUSTOMER_ID = ? AND T2.JOB_ID = ?";

    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement(command);
      prstmt.setInt(1,Band_Contact_ID);
      prstmt.setInt(2,Customer_ID);
      prstmt.setInt(3,Job_ID);
      rs = prstmt.executeQuery();
      while(rs.next()){
        tmpResultSearchReserve = new ResultSearchReserve(rs.getInt(1),rs.getInt(2),
                                rs.getString(3),rs.getString(4),rs.getString(5),
                                rs.getString(6),rs.getString(7),rs.getDouble(8),
                                rs.getString(9),rs.getString(10),
                                rs.getString(11),rs.getString(12),rs.getInt(13));
        colResult.add(tmpResultSearchReserve);
      }
      rs.close();
      return colResult;
    }
    catch(SQLException se){
      System.out.println(se + "Exception between Search by Contact and Job ID");
    throw new EJBException("Exception Error");}
    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
  }

  public Collection SearchForReserve(String Band_Style, int Band_Type_Id, double Min_Price, double Max_Price, String Start_Datetime, String Finish_Datetime) {
    Connection conn = null;
    PreparedStatement prstmt = null;
    Collection colResult = null;
    ResultReserve tmpResultReserve = null;
    colResult = new ArrayList();
    ResultSet rs = null;
    int i = 0;
    String Sub_SQL1 = new String();
    String Sub_SQL2 = new String();

    if (Band_Style.equals("") ) {
      Sub_SQL1 = "";
    }
    else {
      Sub_SQL1 = " AND T1.BAND_STYLE = '" + Band_Style + "' ";
    }

    if ((Band_Type_Id == 0)) {
      Sub_SQL2 = "";
    }
    else {
      Sub_SQL2 = " AND T1.BAND_TYPE_ID = " + Band_Type_Id;
    }

    String command = "SELECT T1.BAND_STYLE , T1.BAND_TYPE_NAME , T2.BAND_ID "+
                           ", T2.BAND_NAME , T2.BAND_DETAIL , "+
                           " T2.BAND_PRICE_AM , T2.BAND_PRICE_PM , T1.BAND_TYPE_ID "+
                     " FROM TYPE_NAME9 T1 , ENTERTAIN9 T2 , BAND_ORDER9 T3 "+
                     " WHERE T1.BAND_TYPE_ID = T2.BAND_TYPE_ID AND "+
                           " T2.BAND_ID = T3.BAND_ID AND "+
                           " T2.BAND_NAME NOT IN (SELECT T2.BAND_NAME"+
                                                " FROM TYPE_NAME9 T1 , ENTERTAIN9 T2 , BAND_ORDER9 T3 "+
                                                " WHERE  T1.BAND_TYPE_ID = T2.BAND_TYPE_ID AND "+
                                                " T2.BAND_ID = T3.BAND_ID AND "+
                                                " ((TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                                                " BETWEEN T3.START_DATETIME AND T3.FINISH_DATETIME OR "+
                                                " TO_DATE(?,'DD MM YYYY HH24:MI:SS') "+
                                                " BETWEEN T3.START_DATETIME AND T3.FINISH_DATETIME) OR "+

                                                " (T3.START_DATETIME BETWEEN TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                                                " AND TO_DATE (?,'DD MM YYYY HH24:MI:SS') OR "+
                                                " T3.FINISH_DATETIME BETWEEN TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                                                " AND TO_DATE (?,'DD MM YYYY HH24:MI:SS'))) AND "+

                                                " ((T2.BAND_PRICE_AM >= ? OR T2.BAND_PRICE_PM >= ?) AND "+
                                                " (T2.BAND_PRICE_AM <= ? OR T2.BAND_PRICE_PM <= ?)) "+
                                                Sub_SQL1 + Sub_SQL2 +
                                                " )" +
                     "  AND ((T2.BAND_PRICE_AM >= ? OR T2.BAND_PRICE_PM >= ?) AND "+
                     " (T2.BAND_PRICE_AM <= ? OR T2.BAND_PRICE_PM <= ?)) "+
                     Sub_SQL1 + Sub_SQL2 +
              " GROUP BY T1.BAND_STYLE , T1.BAND_TYPE_NAME , T2.BAND_ID , "+
                     "T2.BAND_NAME , T2.BAND_DETAIL , T2.BAND_PRICE_AM , "+
                     "T2.BAND_PRICE_PM , T1.BAND_TYPE_ID";

/*    String command = "SELECT T1.BAND_STYLE , T1.BAND_TYPE_NAME , T2.BAND_NAME , T2.BAND_DETAIL , "+
                           " T2.BAND_PRICE_AM , T2.BAND_PRICE_PM "+
                     "FROM TYPE_NAME T1 , ENTERTAIN T2 , BAND_ORDER T3 "+
                     "WHERE  T1.BAND_TYPE_ID = T2.BAND_TYPE_ID AND "+
                            "T2.BAND_ID = T3.BAND_ID AND "+
                            " (TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                            " NOT BETWEEN T3.START_DATETIME AND T3.FINISH_DATETIME OR "+
                            " TO_DATE(?,'DD MM YYYY HH24:MI:SS') "+
                            " NOT BETWEEN T3.START_DATETIME AND T3.FINISH_DATETIME) AND "+

                            " (T3.START_DATETIME NOT BETWEEN TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                            " AND TO_DATE (?,'DD MM YYYY HH24:MI:SS') OR "+
                            " T3.FINISH_DATETIME NOT BETWEEN TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                            " AND TO_DATE (?,'DD MM YYYY HH24:MI:SS')) AND "+

                            " ((T2.BAND_PRICE_AM >= ? OR T2.BAND_PRICE_PM >= ?) AND "+
                            " (T2.BAND_PRICE_AM <= ? OR T2.BAND_PRICE_PM <= ?)) "+
                            Sub_SQL1 + Sub_SQL2 +
                     " GROUP BY T1.BAND_STYLE , T1.BAND_TYPE_NAME , T2.BAND_NAME , "+
                              " T2.BAND_DETAIL , T2.BAND_PRICE_AM , T2.BAND_PRICE_PM";

*/
    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement(command);

      prstmt.setString(1,Start_Datetime);
      prstmt.setString(2,Finish_Datetime);
      prstmt.setString(3,Start_Datetime);
      prstmt.setString(4,Finish_Datetime);
      prstmt.setString(5,Start_Datetime);
      prstmt.setString(6,Finish_Datetime);
      prstmt.setDouble(7,Min_Price);
      prstmt.setDouble(8,Min_Price);
      prstmt.setDouble(9,Max_Price);
      prstmt.setDouble(10,Max_Price);
      prstmt.setDouble(11,Min_Price);
      prstmt.setDouble(12,Min_Price);
      prstmt.setDouble(13,Max_Price);
      prstmt.setDouble(14,Max_Price);

      rs = prstmt.executeQuery();
      while(rs.next()){
        tmpResultReserve = new ResultReserve(rs.getString(1),rs.getString(2),
                           rs.getInt(3),rs.getString(4),rs.getString(5),
                           rs.getDouble(6),rs.getDouble(7) , rs.getInt(8));
        colResult.add(tmpResultReserve);
        i++;
      }
      rs.close();
      return colResult;
    }
    catch(Exception e){
      System.out.println(e + "Exception between Search for Reserve");
    throw new EJBException("Exception Error");}
    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
  }

  public Collection SearchForDetailReserveByCustomer_ID(int Customer_ID) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    Collection colResult = null;
    ResultContactID tmpResultContact_ID = null;
    colResult = new ArrayList();
    ResultSet rs = null;

    String command = "SELECT BAND_CONTACT_ID , BAND_CONTACT_NAME " +
                     " , TO_CHAR(DEADLINE_CONFIRM,'DD MM YYYY') "+
                     " , TO_CHAR(PAY_DATE,'DD MM YYYY') "+
                     " FROM BAND_CONTACT9 WHERE CUSTOMER_ID = ?";

    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement(command);
      prstmt.setInt(1,Customer_ID);
      rs = prstmt.executeQuery();
      while(rs.next()){
        tmpResultContact_ID = new ResultContactID(rs.getString(2),rs.getInt(1),rs.getString(3) , rs.getString(4));
        colResult.add(tmpResultContact_ID);
      }
      rs.close();
      return colResult;
    }
    catch(SQLException se){
      System.out.println(se + "Exception between Search by Contact and Job ID");
    throw new EJBException("Exception Error");}
    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
  }
}