package entertainment9;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService9Home extends javax.ejb.EJBHome {
  public CustomerService9 create() throws CreateException, RemoteException;
}