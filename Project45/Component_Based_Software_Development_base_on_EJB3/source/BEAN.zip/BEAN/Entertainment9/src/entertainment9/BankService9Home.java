package entertainment9;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService9Home extends javax.ejb.EJBHome {
  public BankService9 create() throws CreateException, RemoteException;
}