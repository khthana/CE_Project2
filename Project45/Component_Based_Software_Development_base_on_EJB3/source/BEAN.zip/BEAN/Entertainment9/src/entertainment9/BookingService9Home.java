package entertainment9;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService9Home extends javax.ejb.EJBHome {
  public BookingService9 create() throws CreateException, RemoteException;
}