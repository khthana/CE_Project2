/**
 * This code was automatically generated at 19:06:14 on 26 ��.�. 2003
 * by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
 *
 * @version WebLogic Server 7.0  Thu Jun 20 11:47:11 PDT 2002 190955 
 * @author Copyright (c) 2003 by BEA Systems, Inc. All Rights Reserved.
 */

package entertainment2;
import weblogic.ejb20.interfaces.WLEnterpriseBean;
public final class BookingService2Bean_gztf2i_HomeImpl
     extends    weblogic.ejb20.internal.StatelessEJBHome
     implements entertainment2.BookingService2Home, weblogic.utils.PlatformConstants
                 
{
  public weblogic.ejb20.internal.MethodDescriptor md_eo_ReserveEntertain_iSiiiSSSSddS;
public weblogic.ejb20.internal.MethodDescriptor md_eo_CancelEntertainByJob_ID_iii;
public weblogic.ejb20.internal.MethodDescriptor md_eo_EditEntertain_iiiiiSSSSS;
public weblogic.ejb20.internal.MethodDescriptor md_eo_CreateContactID;
public weblogic.ejb20.internal.MethodDescriptor md_eo_CancelEntertainByContact_ID_ii;


  public weblogic.ejb20.internal.MethodDescriptor md_ejbCreate;


  

  
  private static java.lang.reflect.Method mth_ejbCreate;
  private static java.lang.reflect.Method mth_postejbCreate;



  

  public weblogic.ejb20.internal.MethodDescriptor md_eo_remove;

  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_javax_ejb_Handle;
  public weblogic.ejb20.internal.MethodDescriptor md_ejbRemove_O;

  static {

    try {

      
  mth_ejbCreate = BookingService2Bean.class.getMethod(
    "ejbCreate", null);

  if (false) {
    mth_postejbCreate = BookingService2Bean.class.getMethod(
        "ejbPostCreate", null); 
  }





    } catch (Exception e) {
      throw new weblogic.utils.AssertionError("Unable to find expected "+
        "methods.  Please check your classpath for stale versions of "+
        "your ejb classes and re-run weblogic.ejbc");
    }
  }


  public BookingService2Bean_gztf2i_HomeImpl() {
    super(BookingService2Bean_gztf2i_EOImpl.class
          );
  }

  
public entertainment2.BookingService2 create ()
   throws java.rmi.RemoteException, javax.ejb.CreateException
{
  try {
    return (entertainment2.BookingService2) super.create(md_ejbCreate);
  } catch (java.lang.Exception e) {
    if (e instanceof java.rmi.RemoteException) {
      throw (java.rmi.RemoteException)e;
    }
    else if (e instanceof javax.ejb.CreateException) {
   throw (javax.ejb.CreateException) e;
}
       else {
         throw new javax.ejb.CreateException ("Error while creating bean: " + 
           e.toString());
       }
  }
}



  

  

  public void remove(java.lang.Object pk) 
    throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_O, pk);
  }

  public void remove(javax.ejb.Handle h)
    throws java.rmi.RemoteException, javax.ejb.RemoveException
  {
    super.remove(md_ejbRemove_javax_ejb_Handle, h);
  }


}

