/**
 * This code was automatically generated at 19:06:14 on 26 ��.�. 2003
 * by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
 *
 * @version WebLogic Server 7.0  Thu Jun 20 11:47:11 PDT 2002 190955 
 * @author Copyright (c) 2003 by BEA Systems, Inc. All Rights Reserved.
 */

package entertainment2;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class BookingService2Bean_gztf2i_EOImpl
    extends weblogic.ejb20.internal.StatelessEJBObject
  implements entertainment2.BookingService2, weblogic.utils.PlatformConstants
{

  public BookingService2Bean_gztf2i_EOImpl() {}

    public entertainment2.ResultReserveEntertain ReserveEntertain(int arg0, java.lang.String arg1, int arg2, int arg3, int arg4, java.lang.String arg5, java.lang.String arg6, java.lang.String arg7, java.lang.String arg8, double arg9, double arg10, java.lang.String arg11)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((BookingService2Bean_gztf2i_HomeImpl)getEJBHome()).md_eo_ReserveEntertain_iSiiiSSSSddS;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0), arg1,new Integer( arg2),new Integer( arg3),new Integer( arg4), arg5, arg6, arg7, arg8,new Double( arg9),new Double( arg10), arg11}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    entertainment2.ResultReserveEntertain result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((BookingService2Bean) __bean).ReserveEntertain( arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment2.BookingService2Bean.ReserveEntertain():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public java.lang.String CancelEntertainByJob_ID(int arg0, int arg1, int arg2)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((BookingService2Bean_gztf2i_HomeImpl)getEJBHome()).md_eo_CancelEntertainByJob_ID_iii;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0),new Integer( arg1),new Integer( arg2)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.lang.String result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((BookingService2Bean) __bean).CancelEntertainByJob_ID( arg0, arg1, arg2);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment2.BookingService2Bean.CancelEntertainByJob_ID():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public entertainment2.ResultReserveEntertain EditEntertain(int arg0, int arg1, int arg2, int arg3, int arg4, java.lang.String arg5, java.lang.String arg6, java.lang.String arg7, java.lang.String arg8, java.lang.String arg9)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((BookingService2Bean_gztf2i_HomeImpl)getEJBHome()).md_eo_EditEntertain_iiiiiSSSSS;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0),new Integer( arg1),new Integer( arg2),new Integer( arg3),new Integer( arg4), arg5, arg6, arg7, arg8, arg9}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    entertainment2.ResultReserveEntertain result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((BookingService2Bean) __bean).EditEntertain( arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment2.BookingService2Bean.EditEntertain():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public int CreateContactID() throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((BookingService2Bean_gztf2i_HomeImpl)getEJBHome()).md_eo_CreateContactID;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { }));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    int result = 0;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((BookingService2Bean) __bean).CreateContactID();
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment2.BookingService2Bean.CreateContactID():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public java.lang.String CancelEntertainByContact_ID(int arg0, int arg1)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((BookingService2Bean_gztf2i_HomeImpl)getEJBHome()).md_eo_CancelEntertainByContact_ID_ii;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0),new Integer( arg1)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.lang.String result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((BookingService2Bean) __bean).CancelEntertainByContact_ID( arg0, arg1);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment2.BookingService2Bean.CancelEntertainByContact_ID():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }



  public void remove()
     throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((BookingService2Bean_gztf2i_HomeImpl)getEJBHome()).md_eo_remove);
  }

}

