package entertainment2;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService2Home extends javax.ejb.EJBHome {
  public BankService2 create() throws CreateException, RemoteException;
}