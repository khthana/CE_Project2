package entertainment2;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService2Home extends javax.ejb.EJBHome {
  public BookingService2 create() throws CreateException, RemoteException;
}