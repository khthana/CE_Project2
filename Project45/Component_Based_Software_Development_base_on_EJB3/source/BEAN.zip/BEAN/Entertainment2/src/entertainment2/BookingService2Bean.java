package entertainment2;

import javax.ejb.*;
import java.rmi.*;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;

public class BookingService2Bean implements SessionBean {
  SessionContext sessionContext;
  private DataSource datasource;
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
    try{
      Context ctx = new InitialContext();
      datasource = (DataSource)ctx.lookup( "projectDS" );
    }
    catch(Exception e){}
  }

  public String CancelEntertainByContact_ID(int Customer_ID, int Band_Contact_ID) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    ResultSet rs = null;
    try{
      conn = datasource.getConnection();
      conn.setAutoCommit(false);

      prstmt = conn.prepareStatement("DELETE FROM BAND_CONTACT2 "+
                                     "WHERE CUSTOMER_ID = ? AND BAND_CONTACT_ID = ?");
      prstmt.setInt(1,Customer_ID);
      prstmt.setInt(2,Band_Contact_ID);
      prstmt.executeUpdate();

      prstmt = conn.prepareStatement("DELETE FROM BAND_ORDER2 "+
                                     "WHERE CUSTOMER_ID = ? AND BAND_CONTACT_ID = ?");
      prstmt.setInt(1,Customer_ID);
      prstmt.setInt(2,Band_Contact_ID);
      prstmt.executeUpdate();

      conn.commit();
      System.out.println("Delete Reserve Complete !!!");
      return ("success");
    }
    catch(SQLException se){
      try{
        conn.rollback();
        System.out.println("Roll Back !!!");
        throw new Exception(se +"  SQL Error : Cannot remove booking ");
      }
      catch(Exception e){
      System.out.println(e+"Rollback Error");
      }
      return("Fail");
    }

    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
}
  public ResultReserveEntertain ReserveEntertain(int Band_Contact_ID, String Band_Contact_Name, int Band_ID, int Customer_ID, int Band_Type_ID, String Start_Datetime, String Finish_Datetime, String Place, String Function_Type, double Price_AM, double Price_PM, String Additional_Requests) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    PreparedStatement prstmt2 = null;
    PreparedStatement prstmt3 = null;
    PreparedStatement prstmt4 = null;
    String auto_increment = "SELECT Job_ID2_AutoIncrement.NEXTVAL FROM DUAL";
    ResultSet rs = null;
    ResultSet rs2 = null;

    try{
      String Start = Start_Datetime;
      Integer Temp = new Integer(0);
      char[] Ch_Start = Start.toCharArray();
      int Day1 = 0 ;
      int Month1 = 0;
      int Year1 = 0;
      String Str_ch = new String();
      int count = 0;
      double Total_Price = 0;
      for (int i = 0 ; i < Start.length() ; i ++)
      {
         if (Ch_Start[i] == ' ' || Ch_Start[i] == ':')
         {
           count ++;
           if (count == 1)
           {
             Day1 = Temp.parseInt(Str_ch);
             Str_ch = "";
           }
           if (count == 2)
           {
             Month1 = Temp.parseInt(Str_ch);
             Str_ch = "";
           }
           if (count == 3)
           {
             Year1 = Temp.parseInt(Str_ch);
             Str_ch = "";
           }
           if (count == 4)
           {
             Integer Hour = new Integer(Str_ch);
             int Check = Hour.intValue();
             if (Check >=17 || Check < 2)
             {
               Total_Price = Price_PM;
             }
             if (Check >=5 && Check < 17)
             {
               Total_Price = Price_AM;
             }

           }

         }
         else
         {
           Str_ch = Str_ch + Ch_Start[i];
         }
      }
      Date Start_Date = new Date(Year1 , Month1 - 1, Day1);
      Date Deadline = new Date(Start_Date.getTime() - 604800000);
      String Deadline_Confirm = Temp.toString(Deadline.getDate()) + " " + Temp.toString(Deadline.getMonth() + 1) + " " +  Temp.toString(Deadline.getYear());



      conn = datasource.getConnection();
      int Job_ID_AutoIncrement = 0;
      prstmt = conn.prepareStatement(auto_increment);
      rs = prstmt.executeQuery();
      while (rs.next())
      {
        Job_ID_AutoIncrement = rs.getInt(1);
      }
      rs.close();

      ResultReserveEntertain result = new ResultReserveEntertain(Job_ID_AutoIncrement,Deadline_Confirm,Total_Price);
      conn.setAutoCommit(false);
      prstmt = conn.prepareStatement(" INSERT INTO BAND_ORDER2 (BAND_CONTACT_ID , BAND_ID , CUSTOMER_ID , "+
                                                              "JOB_ID , BAND_TYPE_ID , START_DATETIME , "+
                                                              "FINISH_DATETIME , PLACE , FUNCTION_TYPE , "+
                                                              "TOTAL_PRICE , ADDITIONAL_REQUESTS )"+
                                     " VALUES (? , ? , ? , ? , ? , to_date(? , 'DD MM YYYY HH24:MI:SS')"+
                                               " , to_date(? , 'DD MM YYYY HH24:MI:SS') , ? , ? , ? , ? )");
      prstmt.setInt(1,Band_Contact_ID);
      prstmt.setInt(2,Band_ID);
      prstmt.setInt(3,Customer_ID);
      prstmt.setInt(4,Job_ID_AutoIncrement);  //Job_ID
      prstmt.setInt(5,Band_Type_ID);
      prstmt.setString(6,Start_Datetime);
      prstmt.setString(7,Finish_Datetime);
      prstmt.setString(8,Place);
      prstmt.setString(9,Function_Type);
      prstmt.setDouble(10,Total_Price);  //Total_Price
//      prstmt.setString(11,"");  //Pay_Date
      prstmt.setString(11,Additional_Requests);
      prstmt.executeUpdate();

      prstmt = conn.prepareStatement("SELECT * FROM BAND_CONTACT2 "+
                                     " WHERE BAND_CONTACT_ID = ? "+
                                     "AND CUSTOMER_ID = ?");
      prstmt.setInt(1,Band_Contact_ID);
      prstmt.setInt(2,Customer_ID);
      rs = prstmt.executeQuery();
      if (rs.next())
      {
        prstmt2 = conn.prepareStatement("SELECT * FROM BAND_CONTACT2 "+
                                       " WHERE ((DEADLINE_CONFIRM < to_date(? , 'DD MM YYYY')) AND "+
                                       " (BAND_CONTACT_ID = ? AND CUSTOMER_ID = ?))");
        prstmt2.setString(1,Deadline_Confirm);
        prstmt2.setInt(2,Band_Contact_ID);
        prstmt2.setInt(3,Customer_ID);
        rs2 = prstmt2.executeQuery();
        if (rs2.next()){
          // edit this row ******************* from return null;
          conn.commit();
          return result;
        }
        else
        {
          prstmt4 = conn.prepareStatement("UPDATE BAND_CONTACT2 "+
                                          " SET DEADLINE_CONFIRM = to_date(? , 'DD MM YYYY') "+
                                          " WHERE (BAND_CONTACT_ID = ? AND CUSTOMER_ID = ? )");
          prstmt4.setString(1,Deadline_Confirm);
          prstmt4.setInt(2,Band_Contact_ID);
          prstmt4.setInt(3,Customer_ID);
          prstmt4.executeUpdate();
          conn.commit();
          return result;
        }
      }
      else
      {

          prstmt3 = conn.prepareStatement("INSERT INTO BAND_CONTACT2 (BAND_CONTACT_ID , CUSTOMER_ID , "+
                                                                   " BAND_CONTACT_NAME , DEADLINE_CONFIRM , PAY_DATE) "+
                                         " VALUES ( ? , ? , ? , to_date(? , 'DD MM YYYY')  , to_date('1 1 2003' , 'DD MM YYYY')) ");
          prstmt3.setInt(1,Band_Contact_ID);
          prstmt3.setInt(2,Customer_ID);
          prstmt3.setString(3,Band_Contact_Name);
          prstmt3.setString(4,Deadline_Confirm);
          prstmt3.executeUpdate();

          conn.commit();
          return result;
        }
      }

    catch(SQLException se){
      try{
        conn.rollback();
        System.out.println(se+"1111111111111111111111111 ");
        throw new Exception(se +"   SQL Error : Cannot remove booking");
      }
      catch(Exception e){System.out.println(e+"Rollback Error");}
      return null;
    }

    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }

  }
  public ResultReserveEntertain EditEntertain(int Band_Contact_ID, int Job_ID, int Band_ID, int Customer_ID, int Band_Type_ID, String Start_Datetime, String Finish_Datetime, String Place, String Function_Type, String Additional_Requests) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    PreparedStatement prstmt2 = null;
    PreparedStatement prstmt3 = null;
    PreparedStatement prstmt4 = null;
    PreparedStatement prstmt5 = null;
    ResultSet rs = null;
    ResultSet rs2 = null;
    try{
      conn = datasource.getConnection();
      conn.setAutoCommit(false);
      prstmt = conn.prepareStatement("DELETE FROM BAND_ORDER2 " +
                                     " WHERE BAND_CONTACT_ID = ? AND " +
                                     " CUSTOMER_ID = ? AND JOB_ID = ?" );
      prstmt.setInt(1,Band_Contact_ID);
      prstmt.setInt(2,Customer_ID);
      prstmt.setInt(3,Job_ID);
      prstmt.executeUpdate();

      String sql_search = "SELECT T2.BAND_PRICE_AM , T2.BAND_PRICE_PM "+
                       " FROM ENTERTAIN2 T2 , BAND_ORDER2 T3 "+
                       " WHERE T2.BAND_ID = T3.BAND_ID AND T2.BAND_ID = ? AND "+
                             " T2.BAND_NAME NOT IN (SELECT T2.BAND_NAME"+
                                                  " FROM ENTERTAIN2 T2 , BAND_ORDER2 T3 "+
                                                  " WHERE T2.BAND_ID = T3.BAND_ID AND T2.BAND_ID = ? AND "+
                                                  " ((TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                                                  " BETWEEN T3.START_DATETIME AND T3.FINISH_DATETIME OR "+
                                                  " TO_DATE(?,'DD MM YYYY HH24:MI:SS') "+
                                                  " BETWEEN T3.START_DATETIME AND T3.FINISH_DATETIME) OR "+

                                                  " (T3.START_DATETIME BETWEEN TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                                                  " AND TO_DATE (?,'DD MM YYYY HH24:MI:SS') OR "+
                                                  " T3.FINISH_DATETIME BETWEEN TO_DATE (?,'DD MM YYYY HH24:MI:SS') "+
                                                  " AND TO_DATE (?,'DD MM YYYY HH24:MI:SS'))) " +
                                                  " )" +
                " GROUP BY  T2.BAND_PRICE_AM , T2.BAND_PRICE_PM";

      prstmt2 = conn.prepareStatement(sql_search);
      prstmt2.setInt(1 , Band_ID);
      prstmt2.setInt(2 , Band_ID);
      prstmt2.setString(3 , Start_Datetime);
      prstmt2.setString(4 , Finish_Datetime);
      prstmt2.setString(5 , Start_Datetime);
      prstmt2.setString(6 , Finish_Datetime);
      prstmt2.setString(7 , Start_Datetime);
      prstmt2.setString(8 , Finish_Datetime);
      rs = prstmt2.executeQuery();
      if(rs.next())
          {     String Start = Start_Datetime;
                Integer Temp = new Integer(0);
                char[] Ch_Start = Start.toCharArray();
                int Day1 = 0 ;
                int Month1 = 0;
                int Year1 = 0;
                String Str_ch = new String();
                double Total_Price = 0;
                int count = 0;
                for (int i = 0 ; i < Start.length() ; i ++)
                {
                    if (Ch_Start[i] == ' ' || Ch_Start[i] == ':')
                    {
                        count ++;
                        if (count == 1)
                        {
                            Day1 = Temp.parseInt(Str_ch);
                            Str_ch = "";
                        }
                        if (count == 2)
                        {
                            Month1 = Temp.parseInt(Str_ch);
                            Str_ch = "";
                        }
                        if (count == 3)
                        {
                            Year1 = Temp.parseInt(Str_ch);
                            Str_ch = "";
                        }
                        if (count == 4)
                        {
                            Integer Hour = new Integer(Str_ch);
                            int Check = Hour.intValue();
                            if (Check >=17 || Check < 2)
                            {
                                Total_Price = rs.getDouble(2);
                            }
                            if (Check >=5 && Check < 17)
                            {
                                Total_Price = rs.getDouble(1);
                            }

                        }

                    }
                    else
                    {
                        Str_ch = Str_ch + Ch_Start[i];
                    }
                }
                Date Start_Date = new Date(Year1 , Month1 - 1 , Day1);
                Date Deadline = new Date(Start_Date.getTime() - 604800000);
                String Deadline_Confirm = Temp.toString(Deadline.getDate()) + " " + Temp.toString(Deadline.getMonth() + 1) + " " +  Temp.toString(Deadline.getYear());

      prstmt3 = conn.prepareStatement(" INSERT INTO BAND_ORDER2 (BAND_CONTACT_ID , BAND_ID , CUSTOMER_ID , "+
                                                              "JOB_ID , BAND_TYPE_ID , START_DATETIME , "+
                                                              "FINISH_DATETIME , PLACE , FUNCTION_TYPE , "+
                                                              "TOTAL_PRICE , ADDITIONAL_REQUESTS )"+
                                     " VALUES (? , ? , ? , ? , ? , to_date(? , 'DD MM YYYY HH24:MI:SS')"+
                                               " , to_date(? , 'DD MM YYYY HH24:MI:SS') , ? , ? , ? , ? )");
      prstmt3.setInt(1,Band_Contact_ID);
      prstmt3.setInt(2,Band_ID);
      prstmt3.setInt(3,Customer_ID);
      prstmt3.setInt(4,Job_ID);  //Job_ID
      prstmt3.setInt(5,Band_Type_ID);
      prstmt3.setString(6,Start_Datetime);
      prstmt3.setString(7,Finish_Datetime);
      prstmt3.setString(8,Place);
      prstmt3.setString(9,Function_Type);
      prstmt3.setDouble(10,Total_Price);  //Total_Price
//      prstmt.setString(11,"");  //Pay_Date
      prstmt3.setString(11,Additional_Requests);
      prstmt3.executeUpdate();

        prstmt4 = conn.prepareStatement("SELECT * FROM BAND_CONTACT2 "+
                                       " WHERE ((DEADLINE_CONFIRM < to_date(? , 'DD MM YYYY')) AND "+
                                       " (BAND_CONTACT_ID = ? AND CUSTOMER_ID = ?))");
        prstmt4.setString(1,Deadline_Confirm);
        prstmt4.setInt(2,Band_Contact_ID);
        prstmt4.setInt(3,Customer_ID);
        rs2 = prstmt4.executeQuery();
        if (rs2.next()){
          // edit this row ******************* from return null;
          conn.commit();
          ResultReserveEntertain result = new ResultReserveEntertain(Job_ID,Deadline_Confirm,Total_Price);
          return result;
        }
        else
        {
          prstmt5 = conn.prepareStatement("UPDATE BAND_CONTACT2 "+
                                          " SET DEADLINE_CONFIRM = to_date(? , 'DD MM YYYY') "+
                                          " WHERE (BAND_CONTACT_ID = ? AND CUSTOMER_ID = ? )");
          prstmt5.setString(1,Deadline_Confirm);
          prstmt5.setInt(2,Band_Contact_ID);
          prstmt5.setInt(3,Customer_ID);
          prstmt5.executeUpdate();
          conn.commit();
          ResultReserveEntertain result = new ResultReserveEntertain(Job_ID,Deadline_Confirm,Total_Price);
          return result;
        }
      }
      else
      {conn.rollback();
       return null;
      }
  }
  catch(SQLException se){
    try{
      conn.rollback();
      System.out.println(se+"Exception between Edit Reserve");
      throw new Exception(se +"  SQL Error : Cannot edit booking");
    }
    catch(Exception e){System.out.println(e+"Rollback Error");}
    return null;
  }

  finally{
    try{
      conn.close();
      prstmt.close();
    }
    catch(Exception e){}
  }
 }
  public int CreateContactID() {

    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    ResultSet rs = null;
    try{
      conn = datasource.getConnection();

      prstmt = conn.prepareStatement("SELECT Contact_ID2_AutoIncrement.nextval FROM dual");
      rs = prstmt.executeQuery();
      rs.next();
      return (rs.getInt(1));
    }
    catch(SQLException se){
        System.out.println("Exception between CreateContact_ID");
        return (0);
    }
    finally{
      try{
        conn.close();
        prstmt.close();
        rs.close();
      }
      catch(Exception e){}
    }
  }
  public String CancelEntertainByJob_ID(int Customer_ID, int Band_Contact_ID, int Job_ID) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    ResultSet rs = null;
    try{
      conn = datasource.getConnection();

      prstmt = conn.prepareStatement("DELETE FROM BAND_ORDER2 "+
                                     " WHERE CUSTOMER_ID = ? AND "+
                                     " BAND_CONTACT_ID = ? AND JOB_ID = ?");
      prstmt.setInt(1,Customer_ID);
      prstmt.setInt(2,Band_Contact_ID);
      prstmt.setInt(3,Job_ID);
      prstmt.executeUpdate();

      System.out.println("Delete Reserve Complete !!!");
      return ("success");
    }
    catch(SQLException se){
      try{
        conn.rollback();
        System.out.println("Roll Back !!!");
        throw new Exception(se +"  SQL Error : Cannot remove booking ");
      }
      catch(Exception e){
      System.out.println(e+"Rollback Error");
      }
      return("Fail");
    }

    finally{
      try{
        conn.close();
        prstmt.close();
      }
      catch(Exception e){}
    }
  }
}

