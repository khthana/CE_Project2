package entertainment2;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService2Home extends javax.ejb.EJBHome {
  public EntertainService2 create() throws CreateException, RemoteException;
}