package entertainment2;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService2Home extends javax.ejb.EJBHome {
  public CustomerService2 create() throws CreateException, RemoteException;
}