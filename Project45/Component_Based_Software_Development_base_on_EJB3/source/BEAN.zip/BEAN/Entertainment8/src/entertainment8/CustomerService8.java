package entertainment8;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService8 extends javax.ejb.EJBObject {
  public String Register(String FirstName, String LastName, String Sex, int Age, String Telephone, String Address, String Email, String Username, String Password) throws RemoteException;
  public int Login_entertainment(String Username, String Password) throws RemoteException;
}