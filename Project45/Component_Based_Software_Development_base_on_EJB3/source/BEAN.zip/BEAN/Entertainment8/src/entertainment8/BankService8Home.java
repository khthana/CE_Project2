package entertainment8;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService8Home extends javax.ejb.EJBHome {
  public BankService8 create() throws CreateException, RemoteException;
}