package entertainment8;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService8Home extends javax.ejb.EJBHome {
  public BookingService8 create() throws CreateException, RemoteException;
}