package entertainment8;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService8Home extends javax.ejb.EJBHome {
  public EntertainService8 create() throws CreateException, RemoteException;
}