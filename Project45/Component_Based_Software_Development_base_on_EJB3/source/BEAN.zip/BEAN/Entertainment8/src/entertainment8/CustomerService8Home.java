package entertainment8;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService8Home extends javax.ejb.EJBHome {
  public CustomerService8 create() throws CreateException, RemoteException;
}