/**
 * This code was automatically generated at 19:13:49 on 26 ��.�. 2003
 * by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
 *
 * @version WebLogic Server 7.0  Thu Jun 20 11:47:11 PDT 2002 190955 
 * @author Copyright (c) 2003 by BEA Systems, Inc. All Rights Reserved.
 */

package entertainment4;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class EntertainService4Bean_aou8jb_EOImpl
    extends weblogic.ejb20.internal.StatelessEJBObject
  implements entertainment4.EntertainService4, weblogic.utils.PlatformConstants
{

  public EntertainService4Bean_aou8jb_EOImpl() {}

    public java.util.Collection SearchForDetailReserveByContact_ID(int arg0, int arg1)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((EntertainService4Bean_aou8jb_HomeImpl)getEJBHome()).md_eo_SearchForDetailReserveByContact_ID_ii;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0),new Integer( arg1)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.util.Collection result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((EntertainService4Bean) __bean).SearchForDetailReserveByContact_ID( arg0, arg1);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment4.EntertainService4Bean.SearchForDetailReserveByContact_ID():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public java.util.Collection SearchForDetailReserveByJob_ID(int arg0, int arg1, int arg2)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((EntertainService4Bean_aou8jb_HomeImpl)getEJBHome()).md_eo_SearchForDetailReserveByJob_ID_iii;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0),new Integer( arg1),new Integer( arg2)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.util.Collection result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((EntertainService4Bean) __bean).SearchForDetailReserveByJob_ID( arg0, arg1, arg2);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment4.EntertainService4Bean.SearchForDetailReserveByJob_ID():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public java.util.Collection SearchForDetail(java.lang.String arg0, int arg1, double arg2, double arg3)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((EntertainService4Bean_aou8jb_HomeImpl)getEJBHome()).md_eo_SearchForDetail_Sidd;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] {  arg0,new Integer( arg1),new Double( arg2),new Double( arg3)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.util.Collection result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((EntertainService4Bean) __bean).SearchForDetail( arg0, arg1, arg2, arg3);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment4.EntertainService4Bean.SearchForDetail():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public java.util.Collection SearchForDetailReserveByCustomer_ID(int arg0)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((EntertainService4Bean_aou8jb_HomeImpl)getEJBHome()).md_eo_SearchForDetailReserveByCustomer_ID_i;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.util.Collection result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((EntertainService4Bean) __bean).SearchForDetailReserveByCustomer_ID( arg0);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment4.EntertainService4Bean.SearchForDetailReserveByCustomer_ID():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public java.util.Collection SearchForReserve(java.lang.String arg0, int arg1, double arg2, double arg3, java.lang.String arg4, java.lang.String arg5)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((EntertainService4Bean_aou8jb_HomeImpl)getEJBHome()).md_eo_SearchForReserve_SiddSS;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] {  arg0,new Integer( arg1),new Double( arg2),new Double( arg3), arg4, arg5}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.util.Collection result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((EntertainService4Bean) __bean).SearchForReserve( arg0, arg1, arg2, arg3, arg4, arg5);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment4.EntertainService4Bean.SearchForReserve():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }



  public void remove()
     throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((EntertainService4Bean_aou8jb_HomeImpl)getEJBHome()).md_eo_remove);
  }

}

