package entertainment4;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService4Home extends javax.ejb.EJBHome {
  public CustomerService4 create() throws CreateException, RemoteException;
}