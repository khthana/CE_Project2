package entertainment4;

import javax.ejb.*;
import javax.naming.*;
import javax.rmi.*;
import javax.sql.*;
import java.sql.*;


public class CustomerService4Bean implements SessionBean {
  SessionContext sessionContext;
  private DataSource datasource;

  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
    try {
      Context ctx = new InitialContext();
    //  Object obj = ctx.lookup("CustomerRemote");
    //  custHome = (CustomerRemoteHome) PortableRemoteObject.narrow(obj , CustomerRemoteHome.class);
   datasource = (DataSource)ctx.lookup( "projectDS" );
    }
    catch (Exception e) {}
  }


  public String Register(String FirstName, String LastName, String Sex, int Age, String Telephone, String Address, String Email, String Username, String Password) {
  Connection conn = null;
  PreparedStatement prstmt = null;
  ResultSet rs = null;
  int Customer_ID_AutoIncrement = 0;

  try {
    conn = datasource.getConnection();
    prstmt = conn.prepareStatement("SELECT USERNAME FROM CUSTOMER4 WHERE USERNAME = ?");
    prstmt.setString(1,Username);
    rs = prstmt.executeQuery();

    if (rs.next()){
      return("Fail");
    }
    else {

      prstmt = conn.prepareStatement("SELECT Customer_ID4_AutoIncrement.nextval from dual");
      rs = prstmt.executeQuery();
      while(rs.next()){
        Customer_ID_AutoIncrement = rs.getInt(1);
      }
      rs.close();

      prstmt = conn.prepareStatement("INSERT INTO CUSTOMER4 VALUES (?,?,?,?,?,?,?,?,?,?)");
      prstmt.setInt(1,Customer_ID_AutoIncrement);
      prstmt.setString(2, FirstName);
      prstmt.setString(3, LastName);
      prstmt.setString(4, Sex);
      prstmt.setInt(5, Age);
      prstmt.setString(6, Telephone);
      prstmt.setString(7, Address);
      prstmt.setString(8, Email);
      prstmt.setString(9, Username);
      prstmt.setString(10, Password);
      prstmt.executeUpdate();
      prstmt.close();
      return("Success");
    }
    }
    catch (Exception e) {
      System.out.println( e + "Exception between Register");
      throw new EJBException("Exception Error");
    }
    finally{
      try{
      conn.close();
      prstmt.close();
      }
      catch (Exception e) {System.out.println(e + "Close connection Exception.");}
    }
}
  public int Login_entertainment(String Username, String Password) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    ResultSet rs = null;
    int customerID = 0;
    String command = "SELECT CUSTOMERID "+
                     "FROM CUSTOMER4 "+
                     "WHERE (USERNAME = ? AND PASSWORD = ?)";
    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement(command);
      prstmt.setString(1,Username);
      prstmt.setString(2,Password);
      rs = prstmt.executeQuery();

      if (rs.next()){
        customerID = rs.getInt(1);
        return(customerID);
      }
      else{return (0);}
    }
    catch(SQLException se){System.out.println(se+"error");
        throw new EJBException();
    }
    finally{
      try{
      rs.close();
      prstmt.close();
      conn.close();
      }
      catch (Exception e) {}
    }
  }

}