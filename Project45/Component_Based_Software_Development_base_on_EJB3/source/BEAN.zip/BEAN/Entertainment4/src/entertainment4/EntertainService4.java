package entertainment4;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService4 extends javax.ejb.EJBObject {
  public Collection SearchForDetail(String Band_Style, int Band_Type_ID, double Min_Price, double Max_Price) throws RemoteException;
  public Collection SearchForDetailReserveByContact_ID(int Customer_ID, int Band_Contact_ID) throws RemoteException;
  public Collection SearchForDetailReserveByJob_ID(int Customer_ID, int Band_Contact_ID, int Job_ID) throws RemoteException;
  public Collection SearchForReserve(String Band_Style, int Band_Type_Id, double Min_Price, double Max_Price, String Start_Datetime, String Finish_Datetime) throws RemoteException;
  public Collection SearchForDetailReserveByCustomer_ID(int Customer_ID) throws RemoteException;
}