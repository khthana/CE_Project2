package entertainment4;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService4Home extends javax.ejb.EJBHome {
  public EntertainService4 create() throws CreateException, RemoteException;
}