package entertainment4;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService4Home extends javax.ejb.EJBHome {
  public BookingService4 create() throws CreateException, RemoteException;
}