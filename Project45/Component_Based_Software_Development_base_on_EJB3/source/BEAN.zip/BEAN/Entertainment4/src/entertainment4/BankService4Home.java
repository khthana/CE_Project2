package entertainment4;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService4Home extends javax.ejb.EJBHome {
  public BankService4 create() throws CreateException, RemoteException;
}