package entertainment;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerServiceHome extends javax.ejb.EJBHome {
  public CustomerService create() throws CreateException, RemoteException;
}