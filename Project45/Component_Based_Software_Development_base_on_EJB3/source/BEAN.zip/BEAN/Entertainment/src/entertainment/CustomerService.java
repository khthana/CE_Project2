package entertainment;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface CustomerService extends javax.ejb.EJBObject {
  public String Register(String FirstName, String LastName, String Sex, int Age, String Telephone, String Address, String Email, String Username, String Password) throws SQLException, RemoteException;
  public int Login_entertainment(String Username, String Password) throws RemoteException;
}