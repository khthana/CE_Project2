package entertainment;

import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;

public class entertainserviceTestClient1 {
  static final private String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  static final private int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private entertainserviceHome entertainserviceHomeObject = null;
  private entertainservice entertainserviceObject = null;

  //Construct the EJB test client
  public entertainserviceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("entertainservice");

      //cast to Home interface
      entertainserviceHomeObject = (entertainserviceHome) PortableRemoteObject.narrow(ref, entertainserviceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://olala101:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public entertainservice create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      entertainserviceObject = entertainserviceHomeObject.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + entertainserviceObject + ".");
    }
    return entertainserviceObject;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public Collection SearchForDetail(String Band_Style, int Band_Type_ID, double Min_Price, double Max_Price) {
    Collection returnValue = null;
    if (entertainserviceObject == null) {
      System.out.println("Error in SearchForDetail(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchForDetail(" + Band_Style + ", " + Band_Type_ID + ", " + Min_Price + ", " + Max_Price + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = entertainserviceObject.SearchForDetail(Band_Style, Band_Type_ID, Min_Price, Max_Price);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchForDetail(" + Band_Style + ", " + Band_Type_ID + ", " + Min_Price + ", " + Max_Price + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchForDetail(" + Band_Style + ", " + Band_Type_ID + ", " + Min_Price + ", " + Max_Price + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchForDetail(" + Band_Style + ", " + Band_Type_ID + ", " + Min_Price + ", " + Max_Price + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection SearchForDetailReserveByContact_ID(int Customer_ID, int Band_Contact_ID) {
    Collection returnValue = null;
    if (entertainserviceObject == null) {
      System.out.println("Error in SearchForDetailReserveByContact_ID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchForDetailReserveByContact_ID(" + Customer_ID + ", " + Band_Contact_ID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = entertainserviceObject.SearchForDetailReserveByContact_ID(Customer_ID, Band_Contact_ID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchForDetailReserveByContact_ID(" + Customer_ID + ", " + Band_Contact_ID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchForDetailReserveByContact_ID(" + Customer_ID + ", " + Band_Contact_ID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchForDetailReserveByContact_ID(" + Customer_ID + ", " + Band_Contact_ID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection SearchForDetailReserveByJob_ID(int Customer_ID, int Band_Contact_ID, int Job_ID) {
    Collection returnValue = null;
    if (entertainserviceObject == null) {
      System.out.println("Error in SearchForDetailReserveByJob_ID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchForDetailReserveByJob_ID(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = entertainserviceObject.SearchForDetailReserveByJob_ID(Customer_ID, Band_Contact_ID, Job_ID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchForDetailReserveByJob_ID(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchForDetailReserveByJob_ID(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchForDetailReserveByJob_ID(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection SearchForReserve(String Band_Style, int Band_Type_Id, double Min_Price, double Max_Price, String Start_Datetime, String Finish_Datetime) {
    Collection returnValue = null;
    if (entertainserviceObject == null) {
      System.out.println("Error in SearchForReserve(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchForReserve(" + Band_Style + ", " + Band_Type_Id + ", " + Min_Price + ", " + Max_Price + ", " + Start_Datetime + ", " + Finish_Datetime + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = entertainserviceObject.SearchForReserve(Band_Style, Band_Type_Id, Min_Price, Max_Price, Start_Datetime, Finish_Datetime);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchForReserve(" + Band_Style + ", " + Band_Type_Id + ", " + Min_Price + ", " + Max_Price + ", " + Start_Datetime + ", " + Finish_Datetime + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchForReserve(" + Band_Style + ", " + Band_Type_Id + ", " + Min_Price + ", " + Max_Price + ", " + Start_Datetime + ", " + Finish_Datetime + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchForReserve(" + Band_Style + ", " + Band_Type_Id + ", " + Min_Price + ", " + Max_Price + ", " + Start_Datetime + ", " + Finish_Datetime + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public Collection SearchForDetailReserveByCustomer_ID(int Customer_ID) {
    Collection returnValue = null;
    if (entertainserviceObject == null) {
      System.out.println("Error in SearchForDetailReserveByCustomer_ID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling SearchForDetailReserveByCustomer_ID(" + Customer_ID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = entertainserviceObject.SearchForDetailReserveByCustomer_ID(Customer_ID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: SearchForDetailReserveByCustomer_ID(" + Customer_ID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: SearchForDetailReserveByCustomer_ID(" + Customer_ID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from SearchForDetailReserveByCustomer_ID(" + Customer_ID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  //Main method

  public static void main(String[] args) {
    entertainserviceTestClient1 client = new entertainserviceTestClient1();
    client.create();
    client.SearchForReserve("thai" , 1 , 500 , 500 , "04 04 2003 14:00:00" , "04 04 2003 15:00:00");
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
  }
}