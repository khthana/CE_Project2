package entertainment;

import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;

public class bookingserviceTestClient1 {
  static final private String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  static final private int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private bookingserviceHome bookingserviceHomeObject = null;
  private bookingservice bookingserviceObject = null;

  //Construct the EJB test client
  public bookingserviceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("bookingservice");

      //cast to Home interface
      bookingserviceHomeObject = (bookingserviceHome) PortableRemoteObject.narrow(ref, bookingserviceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://olala101:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public bookingservice create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      bookingserviceObject = bookingserviceHomeObject.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + bookingserviceObject + ".");
    }
    return bookingserviceObject;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String CancelEntertain(int Customer_ID, int Band_Contact_ID, int Job_ID) {
    String returnValue = "";
    if (bookingserviceObject == null) {
      System.out.println("Error in CancelEntertain(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CancelEntertain(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingserviceObject.CancelEntertain(Customer_ID, Band_Contact_ID, Job_ID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CancelEntertain(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CancelEntertain(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from CancelEntertain(" + Customer_ID + ", " + Band_Contact_ID + ", " + Job_ID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public ResultReserveEntertain ReserveEntertain(int Band_Contact_ID, String Band_Contact_Name, int Band_ID, int Customer_ID, int Band_Type_ID, String Start_Datetime, String Finish_Datetime, String Place, String Function_Type, double Price_AM, double Price_PM, String Additional_Requests) {
    ResultReserveEntertain returnValue = null;
    if (bookingserviceObject == null) {
      System.out.println("Error in ReserveEntertain(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling ReserveEntertain(" + Band_Contact_ID + ", " + Band_Contact_Name + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Price_AM + ", " + Price_PM + ", " + Additional_Requests + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingserviceObject.ReserveEntertain(Band_Contact_ID, Band_Contact_Name, Band_ID, Customer_ID, Band_Type_ID, Start_Datetime, Finish_Datetime, Place, Function_Type, Price_AM, Price_PM, Additional_Requests);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: ReserveEntertain(" + Band_Contact_ID + ", " + Band_Contact_Name + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Price_AM + ", " + Price_PM + ", " + Additional_Requests + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: ReserveEntertain(" + Band_Contact_ID + ", " + Band_Contact_Name + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Price_AM + ", " + Price_PM + ", " + Additional_Requests + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from ReserveEntertain(" + Band_Contact_ID + ", " + Band_Contact_Name + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Price_AM + ", " + Price_PM + ", " + Additional_Requests + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public ResultReserveEntertain EditEntertain(int Band_Contact_ID, int Job_ID, int Band_ID, int Customer_ID, int Band_Type_ID, String Start_Datetime, String Finish_Datetime, String Place, String Function_Type, String Additional_Requests) {
    ResultReserveEntertain returnValue = null;
    if (bookingserviceObject == null) {
      System.out.println("Error in EditEntertain(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling EditEntertain(" + Band_Contact_ID + ", " + Job_ID + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Additional_Requests + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingserviceObject.EditEntertain(Band_Contact_ID, Job_ID, Band_ID, Customer_ID, Band_Type_ID, Start_Datetime, Finish_Datetime, Place, Function_Type, Additional_Requests);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: EditEntertain(" + Band_Contact_ID + ", " + Job_ID + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Additional_Requests + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: EditEntertain(" + Band_Contact_ID + ", " + Job_ID + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Additional_Requests + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from EditEntertain(" + Band_Contact_ID + ", " + Job_ID + ", " + Band_ID + ", " + Customer_ID + ", " + Band_Type_ID + ", " + Start_Datetime + ", " + Finish_Datetime + ", " + Place + ", " + Function_Type + ", " + Additional_Requests + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public int CreateContactID() {
    int returnValue = 0;
    if (bookingserviceObject == null) {
      System.out.println("Error in CreateContactID(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CreateContactID()");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bookingserviceObject.CreateContactID();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CreateContactID()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CreateContactID()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from CreateContactID(): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  //Main method

  public static void main(String[] args) {
    bookingserviceTestClient1 client = new bookingserviceTestClient1();
    client.create();
    client.ReserveEntertain(121,"test",5,21,3,"05 01 2003 10:00:00","05 01 2003 12:00:00","tower","party",100,200,"good");
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
  }
}