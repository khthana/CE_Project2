package entertainment;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface entertainserviceHome extends javax.ejb.EJBHome {
  public entertainservice create() throws CreateException, RemoteException;
}