package entertainment;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface bookingserviceHome extends javax.ejb.EJBHome {
  public bookingservice create() throws CreateException, RemoteException;
}