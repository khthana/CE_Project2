package entertainment;

import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;

public class bankingserviceTestClient1 {
  static final private String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  static final private int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private bankingserviceHome bankingserviceHomeObject = null;
  private bankingservice bankingserviceObject = null;

  //Construct the EJB test client
  public bankingserviceTestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("bankingservice");

      //cast to Home interface
      bankingserviceHomeObject = (bankingserviceHome) PortableRemoteObject.narrow(ref, bankingserviceHome.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://olala101:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public bankingservice create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      bankingserviceObject = bankingserviceHomeObject.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + bankingserviceObject + ".");
    }
    return bankingserviceObject;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String UpdatePayDate(int Customer_ID, int Band_Contact_ID) {
    String returnValue = "";
    if (bankingserviceObject == null) {
      System.out.println("Error in UpdatePayDate(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling UpdatePayDate(" + Customer_ID + ", " + Band_Contact_ID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bankingserviceObject.UpdatePayDate(Customer_ID, Band_Contact_ID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: UpdatePayDate(" + Customer_ID + ", " + Band_Contact_ID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: UpdatePayDate(" + Customer_ID + ", " + Band_Contact_ID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from UpdatePayDate(" + Customer_ID + ", " + Band_Contact_ID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public double CheckTotalPrice(int Customer_ID, int Band_Contact_ID) {
    double returnValue = 0f;
    if (bankingserviceObject == null) {
      System.out.println("Error in CheckTotalPrice(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling CheckTotalPrice(" + Customer_ID + ", " + Band_Contact_ID + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = bankingserviceObject.CheckTotalPrice(Customer_ID, Band_Contact_ID);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: CheckTotalPrice(" + Customer_ID + ", " + Band_Contact_ID + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: CheckTotalPrice(" + Customer_ID + ", " + Band_Contact_ID + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from CheckTotalPrice(" + Customer_ID + ", " + Band_Contact_ID + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  //Main method

  public static void main(String[] args) {
    bankingserviceTestClient1 client = new bankingserviceTestClient1();
    client.create();
   // client.CheckTotalPrice(21,1000);
    client.UpdatePayDate(21,121);
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
  }
}