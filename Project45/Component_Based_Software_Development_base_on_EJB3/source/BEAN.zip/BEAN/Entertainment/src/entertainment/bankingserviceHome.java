package entertainment;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface bankingserviceHome extends javax.ejb.EJBHome {
  public bankingservice create() throws CreateException, RemoteException;
}