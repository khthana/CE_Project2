/**
 * This code was automatically generated at 19:16:36 on 26 ��.�. 2003
 * by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
 *
 * @version WebLogic Server 7.0  Thu Jun 20 11:47:11 PDT 2002 190955 
 * @author Copyright (c) 2003 by BEA Systems, Inc. All Rights Reserved.
 */

package entertainment5;

public final class EntertainService5Bean_aou8ja_Impl
    extends EntertainService5Bean
  implements weblogic.ejb20.interfaces.WLEnterpriseBean
{
  private int __WL_method_state;

  private boolean __WL_busy = false;

  private javax.ejb.EJBContext __WL_EJBContext;

  private javax.transaction.Transaction __WL_bmtx;

  public EntertainService5Bean_aou8ja_Impl()  {}

  public boolean __WL_isBusy() { return __WL_busy; }
  public void __WL_setBusy(boolean b) { __WL_busy = b; }

  public javax.transaction.Transaction __WL_getBeanManagedTransaction() {
    return __WL_bmtx;
  }

  public void __WL_setBeanManagedTransaction(javax.transaction.Transaction tx) {
    __WL_bmtx = tx;
  }

  public javax.ejb.EJBContext __WL_getEJBContext() { return __WL_EJBContext; }
  public void __WL_setEJBContext(javax.ejb.EJBContext ctx) { 
    __WL_EJBContext = ctx; 
  }

  public int __WL_getMethodState() { return __WL_method_state; }
  public void __WL_setMethodState(int state) { __WL_method_state = state; }

  public void ejbActivate() 
    
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJB_ACTIVATE;
      super.ejbActivate();
    } finally {
      __WL_method_state = oldState;
    }
  }

  public void ejbPassivate() 
    
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_EJB_PASSIVATE;
      super.ejbPassivate();
    } finally {
      __WL_method_state = oldState;
    }
  }

  public void ejbRemove() 
    
  {
    int oldState = __WL_method_state;

    try {
      __WL_method_state = STATE_EJB_REMOVE;
      super.ejbRemove();
    } finally {
      __WL_method_state = oldState;
    }
  }
  
  
  public void setSessionContext(javax.ejb.SessionContext ctx)
    
  {
    int oldState = __WL_method_state;
    try {
      __WL_method_state = STATE_SET_CONTEXT;
      super.setSessionContext(ctx);
    } finally {
      __WL_method_state = oldState;
    }
  }



  

  

  // create, find, remove, EJB 2.0 home methods
  
  public void ejbCreate()
    throws javax.ejb.CreateException
  {
    int oldState = __WL_method_state;

    try {
      __WL_method_state = STATE_EJB_CREATE;

      // No return value

       super.ejbCreate();

      // No return result
    } finally {
      __WL_method_state = oldState;
    }
  }




}

