/**
 * This code was automatically generated at 19:15:29 on 26 ��.�. 2003
 * by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
 *
 * @version WebLogic Server 7.0  Thu Jun 20 11:47:11 PDT 2002 190955 
 * @author Copyright (c) 2003 by BEA Systems, Inc. All Rights Reserved.
 */

package entertainment5;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class CustomerService5Bean_85cxmm_EOImpl
    extends weblogic.ejb20.internal.StatelessEJBObject
  implements entertainment5.CustomerService5, weblogic.utils.PlatformConstants
{

  public CustomerService5Bean_85cxmm_EOImpl() {}

    public java.lang.String Register(java.lang.String arg0, java.lang.String arg1, java.lang.String arg2, int arg3, java.lang.String arg4, java.lang.String arg5, java.lang.String arg6, java.lang.String arg7, java.lang.String arg8)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((CustomerService5Bean_85cxmm_HomeImpl)getEJBHome()).md_eo_Register_SSSiSSSSS;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] {  arg0, arg1, arg2,new Integer( arg3), arg4, arg5, arg6, arg7, arg8}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    java.lang.String result = null;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((CustomerService5Bean) __bean).Register( arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment5.CustomerService5Bean.Register():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }

  public int Login_entertainment(java.lang.String arg0, java.lang.String arg1)
     throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((CustomerService5Bean_85cxmm_HomeImpl)getEJBHome()).md_eo_Login_entertainment_SS;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] {  arg0, arg1}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    int result = 0;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((CustomerService5Bean) __bean).Login_entertainment( arg0, arg1);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment5.CustomerService5Bean.Login_entertainment():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }



  public void remove()
     throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((CustomerService5Bean_85cxmm_HomeImpl)getEJBHome()).md_eo_remove);
  }

}

