package entertainment5;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService5Home extends javax.ejb.EJBHome {
  public BankService5 create() throws CreateException, RemoteException;
}