package entertainment5;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService5Home extends javax.ejb.EJBHome {
  public BookingService5 create() throws CreateException, RemoteException;
}