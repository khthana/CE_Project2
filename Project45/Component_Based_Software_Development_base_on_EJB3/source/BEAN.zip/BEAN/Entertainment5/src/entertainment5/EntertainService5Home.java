package entertainment5;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService5Home extends javax.ejb.EJBHome {
  public EntertainService5 create() throws CreateException, RemoteException;
}