package entertainment5;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */
import java.io.*;
import java.util.*;

  public class ResultReserve implements Serializable
    {
      public String Band_Style;
      public String Band_Type_Name;
      public int Band_Type_ID;
      public int Band_ID;
      public String Band_Name;
      public String Band_Detail;
      public double Band_Price_Am;
      public double Band_Price_Pm;
      public ResultReserve(String Band_Style , String Band_Type_Name , int Band_ID , String Band_Name , String Band_Detail ,
                           double Band_Price_Am , double Band_Price_Pm , int Band_Type_ID)
      { this.Band_Style = Band_Style;
        this.Band_Type_Name = Band_Type_Name;
        this.Band_Type_ID = Band_Type_ID;
        this.Band_ID = Band_ID;
        this.Band_Name = Band_Name;
        this.Band_Detail = Band_Detail;
        this.Band_Price_Am = Band_Price_Am;
        this.Band_Price_Pm = Band_Price_Pm;
      }

      public ResultReserve(){}

      private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
      }
      private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
      }

    }
