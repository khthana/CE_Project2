package entertainment5;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService5Home extends javax.ejb.EJBHome {
  public CustomerService5 create() throws CreateException, RemoteException;
}