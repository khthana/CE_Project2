/**
 * This code was automatically generated at 21:20:18 on 26 ��.�. 2003
 * by weblogic.ejb20.ejbc.Ejb2Rmi -- do not edit.
 *
 * @version WebLogic Server 7.0  Thu Jun 20 11:47:11 PDT 2002 190955 
 * @author Copyright (c) 2003 by BEA Systems, Inc. All Rights Reserved.
 */

package entertainment1;

import weblogic.ejb20.interfaces.WLEnterpriseBean;

public final class Enterprise1Bean_st8cog_EOImpl
    extends weblogic.ejb20.internal.StatelessEJBObject
  implements entertainment1.Enterprise1, weblogic.utils.PlatformConstants
{

  public Enterprise1Bean_st8cog_EOImpl() {}

    public int login(int arg0, int arg1) throws java.rmi.RemoteException
  {
    java.lang.Throwable __ee = null;

    weblogic.ejb20.interfaces.InvocationWrapper __wrap;
    weblogic.ejb20.internal.MethodDescriptor __md = 
      ((Enterprise1Bean_st8cog_HomeImpl)getEJBHome()).md_eo_login_ii;
    try {
      __wrap = super.preInvoke(
        __md, weblogic.ejb20.internal.DummyContextHandler.THE_ONE);
    } catch (weblogic.ejb20.internal.NeedRealContextHandlerError e) {
      __wrap = super.preInvoke(
        __md, new weblogic.ejb20.internal.EJBContextHandler(
          __md, new Object [] { new Integer( arg0),new Integer( arg1)}));          
    }

    WLEnterpriseBean __bean = (WLEnterpriseBean) __wrap.getBean();

    int result = 0;

    int __oldState = __bean.__WL_getMethodState();

    try {
      __bean.__WL_setMethodState(WLEnterpriseBean.STATE_BUSINESS_METHOD);
 
      result =  ((Enterprise1Bean) __bean).login( arg0, arg1);
      
    } catch (java.lang.Throwable t) {
      __ee = t;
    }
    finally {
      __bean.__WL_setMethodState(__oldState);
    }

    try {
      super.postInvoke(__wrap, __ee);

    } catch (java.lang.Exception e) {
      if (e instanceof java.rmi.RemoteException) {
        throw (java.rmi.RemoteException)e;
      } 
      
      else {
	throw new java.rmi.UnexpectedException("Unexpected exception in " +
          "entertainment1.Enterprise1Bean.login():" + EOL +	
          weblogic.utils.StackTraceUtils.throwable2StackTrace(e), e);
      } 
    }
    return result;
  }



  public void remove()
     throws javax.ejb.RemoveException, java.rmi.RemoteException
  {
    super.remove(((Enterprise1Bean_st8cog_HomeImpl)getEJBHome()).md_eo_remove);
  }

}

