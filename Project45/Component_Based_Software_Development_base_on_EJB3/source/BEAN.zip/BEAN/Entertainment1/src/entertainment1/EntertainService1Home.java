package entertainment1;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService1Home extends javax.ejb.EJBHome {
  public EntertainService1 create() throws CreateException, RemoteException;
}