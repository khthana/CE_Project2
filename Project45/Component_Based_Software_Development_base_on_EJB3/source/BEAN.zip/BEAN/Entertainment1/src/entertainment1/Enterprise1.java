package entertainment1;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Enterprise1 extends javax.ejb.EJBObject {
  public int login(int a , int b) throws RemoteException;
}