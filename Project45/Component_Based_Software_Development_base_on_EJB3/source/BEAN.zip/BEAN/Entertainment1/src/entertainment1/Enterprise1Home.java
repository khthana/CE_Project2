package entertainment1;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface Enterprise1Home extends javax.ejb.EJBHome {
  public Enterprise1 create() throws CreateException, RemoteException;
}