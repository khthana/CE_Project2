package entertainment1;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService1Home extends javax.ejb.EJBHome {
  public CustomerService1 create() throws CreateException, RemoteException;
}