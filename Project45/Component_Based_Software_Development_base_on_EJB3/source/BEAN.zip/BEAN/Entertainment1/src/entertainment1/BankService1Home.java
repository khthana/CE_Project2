package entertainment1;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService1Home extends javax.ejb.EJBHome {
  public BankService1 create() throws CreateException, RemoteException;
}