package entertainment1;

import javax.naming.*;
import java.util.Properties;
import javax.rmi.PortableRemoteObject;

public class CustomerService1TestClient1 {
  static final private String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.";
  static final private int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private CustomerService1Home customerService1Home = null;
  private CustomerService1 customerService1 = null;

  //Construct the EJB test client
  public CustomerService1TestClient1() {
    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }

    try {
      //get naming context
      Context ctx = getInitialContext();

      //look up jndi name
      Object ref = ctx.lookup("CustomerService1");

      //cast to Home interface
      customerService1Home = (CustomerService1Home) PortableRemoteObject.narrow(ref, CustomerService1Home.class);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded initializing bean access.");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed initializing bean access.");
      }
      e.printStackTrace();
    }
  }

  private Context getInitialContext() throws Exception {
    String url = "t3://olala101:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }

      return new InitialContext(properties);
    }
    catch(Exception e) {
      log("Unable to connect to WebLogic server at " + url);
      log("Please make sure that the server is running.");
      throw e;
    }
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public CustomerService1 create() {
    long startTime = 0;
    if (logging) {
      log("Calling create()");
      startTime = System.currentTimeMillis();
    }
    try {
      customerService1 = customerService1Home.create();
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: create()");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: create()");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from create(): " + customerService1 + ".");
    }
    return customerService1;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public String Register(String FirstName, String LastName, String Sex, int Age, String Telephone, String Address, String Email, String Username, String Password) {
    String returnValue = "";
    if (customerService1 == null) {
      System.out.println("Error in Register(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Register(" + FirstName + ", " + LastName + ", " + Sex + ", " + Age + ", " + Telephone + ", " + Address + ", " + Email + ", " + Username + ", " + Password + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService1.Register(FirstName, LastName, Sex, Age, Telephone, Address, Email, Username, Password);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Register(" + FirstName + ", " + LastName + ", " + Sex + ", " + Age + ", " + Telephone + ", " + Address + ", " + Email + ", " + Username + ", " + Password + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Register(" + FirstName + ", " + LastName + ", " + Sex + ", " + Age + ", " + Telephone + ", " + Address + ", " + Email + ", " + Username + ", " + Password + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from Register(" + FirstName + ", " + LastName + ", " + Sex + ", " + Age + ", " + Telephone + ", " + Address + ", " + Email + ", " + Username + ", " + Password + "): " + returnValue + ".");
    }
    return returnValue;
  }

  public int Login_entertainment(String Username, String Password) {
    int returnValue = 0;
    if (customerService1 == null) {
      System.out.println("Error in Login_entertainment(): " + ERROR_NULL_REMOTE);
      return returnValue;
    }
    long startTime = 0;
    if (logging) {
      log("Calling Login_entertainment(" + Username + ", " + Password + ")");
      startTime = System.currentTimeMillis();
    }

    try {
      returnValue = customerService1.Login_entertainment(Username, Password);
      if (logging) {
        long endTime = System.currentTimeMillis();
        log("Succeeded: Login_entertainment(" + Username + ", " + Password + ")");
        log("Execution time: " + (endTime - startTime) + " ms.");
      }
    }
    catch(Exception e) {
      if (logging) {
        log("Failed: Login_entertainment(" + Username + ", " + Password + ")");
      }
      e.printStackTrace();
    }

    if (logging) {
      log("Return value from Login_entertainment(" + Username + ", " + Password + "): " + returnValue + ".");
    }
    return returnValue;
  }

  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
  //Main method

  public static void main(String[] args) {
    CustomerService1TestClient1 client = new CustomerService1TestClient1();
    client.create();
    client.Register("g","g","g",1 ,"1" ,"g","fg","g","g");
    // Use the client object to call one of the Home interface wrappers
    // above, to create a Remote interface reference to the bean.
    // If the return value is of the Remote interface type, you can use it
    // to access the remote interface methods.  You can also just use the
    // client object to call the Remote interface wrappers.
  }
}