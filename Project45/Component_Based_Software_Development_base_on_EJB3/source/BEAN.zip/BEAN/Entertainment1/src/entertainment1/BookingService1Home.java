package entertainment1;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService1Home extends javax.ejb.EJBHome {
  public BookingService1 create() throws CreateException, RemoteException;
}