package entertainment1;


import javax.ejb.*;
import java.io.*;
import java.sql.*;
import javax.naming.*;
import javax.sql.*;
import java.util.*;
import java.text.*;


public class Enterprise1Bean implements SessionBean {
  SessionContext sessionContext;
  private DataSource datasource;
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  public int login(int a , int b) {
    /**@todo Complete this method*/

    return a+b;
  }
}