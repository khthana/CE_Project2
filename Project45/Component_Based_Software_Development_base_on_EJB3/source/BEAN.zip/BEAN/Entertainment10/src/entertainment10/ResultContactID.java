package entertainment10;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

import java.io.*;
import java.util.*;

public class ResultContactID implements Serializable
{
  public String Band_Contact_Name;
  public int Band_Contact_ID;
  public String Deadline_Confirm;
  public String Pay_Date;

  public ResultContactID(String Band_Contact_Name , int Band_Contact_ID , String Deadline_Confirm , String Pay_Date) {
    this.Band_Contact_Name = Band_Contact_Name;
    this.Band_Contact_ID = Band_Contact_ID;
    this.Deadline_Confirm = Deadline_Confirm;
    this.Pay_Date = Pay_Date;
  }

  public ResultContactID(){}

  private void writeObject(ObjectOutputStream oos) throws IOException {
    oos.defaultWriteObject();
  }
  private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
    ois.defaultReadObject();
  }
}