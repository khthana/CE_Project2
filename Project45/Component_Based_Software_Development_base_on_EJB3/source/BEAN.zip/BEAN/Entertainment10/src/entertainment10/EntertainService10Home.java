package entertainment10;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService10Home extends javax.ejb.EJBHome {
  public EntertainService10 create() throws CreateException, RemoteException;
}