package entertainment10;

import java.io.*;
import java.util.*;

  public class ResultSearchReserve implements Serializable
    {
      public String Band_Name;
      public int Job_Id;
      public int Band_ID;
      public int Band_Type_ID;
      public String Band_Detail;
      public String Start_Datetime;
      public String Finish_Datetime;
      public String Place;
      public String Function_Type;
      public double Total_Price;
      public String Pay_Date;
      public String Additional_Requests;
      public String Deadline_Confirm;

      public ResultSearchReserve(int Job_Id , String Start_Datetime , String Function_Type)
      { this.Job_Id = Job_Id;
        this.Start_Datetime = Start_Datetime;
        this.Function_Type = Function_Type;
      }

      public ResultSearchReserve(int Job_Id , int Band_ID , String Band_Name ,
                                 String Start_Datetime , String Finish_Datetime ,
                                 String Place , String Function_Type ,
                                 double Total_Price , String Pay_Date ,
                                 String Additional_Requests , String Deadline_Confirm ,
                                 String Band_Detail , int Band_Type_ID)
      { this.Job_Id = Job_Id;
        this.Band_ID = Band_ID;
        this.Band_Type_ID = Band_Type_ID;
        this.Band_Name = Band_Name;
        this.Start_Datetime = Start_Datetime;
        this.Finish_Datetime = Finish_Datetime;
        this.Place = Place;
        this.Function_Type = Function_Type;
        this.Total_Price = Total_Price;
        this.Pay_Date = Pay_Date;
        this.Additional_Requests = Additional_Requests;
        this.Deadline_Confirm = Deadline_Confirm;
        this.Band_Detail = Band_Detail;
      }

      public ResultSearchReserve(){}

      private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
      }
      private void readObject(ObjectInputStream ois) throws ClassNotFoundException, IOException {
        ois.defaultReadObject();
      }
    }
