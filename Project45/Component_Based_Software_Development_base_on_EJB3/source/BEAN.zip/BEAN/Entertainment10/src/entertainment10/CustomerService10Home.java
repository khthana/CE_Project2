package entertainment10;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService10Home extends javax.ejb.EJBHome {
  public CustomerService10 create() throws CreateException, RemoteException;
}