package entertainment10;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService10Home extends javax.ejb.EJBHome {
  public BookingService10 create() throws CreateException, RemoteException;
}