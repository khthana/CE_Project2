package entertainment10;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService10Home extends javax.ejb.EJBHome {
  public BankService10 create() throws CreateException, RemoteException;
}