package entertainment10;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService10 extends javax.ejb.EJBObject {
  public String CancelEntertainByContact_ID(int Customer_ID, int Band_Contact_ID) throws RemoteException;
  public ResultReserveEntertain ReserveEntertain(int Band_Contact_ID, String Band_Contact_Name, int Band_ID, int Customer_ID, int Band_Type_ID, String Start_Datetime, String Finish_Datetime, String Place, String Function_Type, double Price_AM, double Price_PM, String Additional_Requests) throws RemoteException;
  public ResultReserveEntertain EditEntertain(int Band_Contact_ID, int Job_ID, int Band_ID, int Customer_ID, int Band_Type_ID, String Start_Datetime, String Finish_Datetime, String Place, String Function_Type, String Additional_Requests) throws RemoteException;
  public int CreateContactID() throws RemoteException;
  public String CancelEntertainByJob_ID(int Customer_ID, int Band_Contact_ID, int Job_ID) throws RemoteException;
}