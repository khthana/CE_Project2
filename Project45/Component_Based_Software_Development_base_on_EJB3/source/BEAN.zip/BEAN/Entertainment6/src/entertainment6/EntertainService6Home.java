package entertainment6;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService6Home extends javax.ejb.EJBHome {
  public EntertainService6 create() throws CreateException, RemoteException;
}