package entertainment6;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BookingService6Home extends javax.ejb.EJBHome {
  public BookingService6 create() throws CreateException, RemoteException;
}