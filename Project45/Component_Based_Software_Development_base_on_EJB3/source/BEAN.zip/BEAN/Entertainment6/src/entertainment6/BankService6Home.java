package entertainment6;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService6Home extends javax.ejb.EJBHome {
  public BankService6 create() throws CreateException, RemoteException;
}