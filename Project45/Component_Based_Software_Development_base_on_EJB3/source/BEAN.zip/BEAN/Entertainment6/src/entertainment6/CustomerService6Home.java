package entertainment6;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService6Home extends javax.ejb.EJBHome {
  public CustomerService6 create() throws CreateException, RemoteException;
}