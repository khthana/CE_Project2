package entertainment6;

import javax.ejb.*;
import javax.naming.*;
import javax.sql.*;
import java.sql.*;


public class BankService6Bean implements SessionBean {
  SessionContext sessionContext;
  private DataSource datasource;
  public void ejbCreate() throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
    try{
      Context ctx = new InitialContext();
      datasource = (DataSource)ctx.lookup( "projectDS" );
    }
    catch(Exception e){}

  }
  public String UpdatePayDate(int Customer_ID, int Band_Contact_ID) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;

    try{
      conn = datasource.getConnection();
      java.util.Date today = new java.util.Date();
      Integer temp = new Integer(0);
      String day1 = temp.toString(today.getDate())+" "+
                    temp.toString(today.getMonth()+1)+" "+
                    temp.toString(today.getYear()+1900);
System.out.println(day1);
      prstmt = conn.prepareStatement("UPDATE BAND_CONTACT6 "+
                                     "SET PAY_DATE = to_date('"+day1+"' , 'DD MM YYYY')"+
                                     "WHERE CUSTOMER_ID = ? AND BAND_CONTACT_ID = ?");
      prstmt.setInt(1,Customer_ID);
      prstmt.setInt(2,Band_Contact_ID);
      prstmt.executeUpdate();
      System.out.println("Update Pay_Date Success");
      return("Success");
    }
    catch(Exception e)
    {
      System.out.println("Can't pay: "+e);
      return("Fail");
    }
  }
  public double CheckTotalPrice(int Customer_ID, int Band_Contact_ID) {
    /**@todo Complete this method*/
    Connection conn = null;
    PreparedStatement prstmt = null;
    ResultSet rs = null;
    try{
      conn = datasource.getConnection();
      prstmt = conn.prepareStatement("SELECT TOTAL_PRICE "+
                                     "FROM BAND_ORDER6 "+
                                     "WHERE CUSTOMER_ID = ? AND BAND_CONTACT_ID = ?");
      prstmt.setInt(1,Customer_ID);
      prstmt.setInt(2,Band_Contact_ID);
      rs = prstmt.executeQuery();
      double total = 0;
      while(rs.next())
      {
        total = total + rs.getDouble(1);
      }
      return total;
    }
    catch(Exception e)
    {
      System.out.println("Can't calculate total price :"+e);
      return 0;
    }
  }
}