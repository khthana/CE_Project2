package entertainment7;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface BankService7Home extends javax.ejb.EJBHome {
  public BankService7 create() throws CreateException, RemoteException;
}