package entertainment7;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CustomerService7Home extends javax.ejb.EJBHome {
  public CustomerService7 create() throws CreateException, RemoteException;
}