package entertainment7;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EntertainService7Home extends javax.ejb.EJBHome {
  public EntertainService7 create() throws CreateException, RemoteException;
}