#!/bin/sh
PLATFORMDIR=C:/bea/weblogic700
BEAHOME=C:/bea

WL_HOME=$PLATFORMDIR/server

export WL_HOME
export BEAHOME
export PLATFORMDIR


BASEDIR=`dirname $0`
BASEDIR=`cd $BASEDIR && pwd`
cd $BASEDIR

 echo Starting Weblogic from: `pwd`

JAVA_HOME=C:/bea/jdk131_03
export JAVA_HOME

ARDIR=$WL_HOME/lib

# Include external environment

if [ -f extEnv.sh ]
then
    . ./extEnv.sh
fi

#
# Export a special class path so we can generate the client proxy JAR files
#
CLASSPATH=$ARDIR/ant/ant.jar:$JAVA_HOME/lib/tools.jar:$JAVA_HOME/jre/lib/rt.jar
export CLASSPATH

CLASSPATH=$PLATFORMDIR/common/lib/log4j.jar:$JAVA_HOME/lib/tools.jar:$ARDIR/knex.jar:$ARDIR/JDIProxy.jar:

POINTBASEJARS=C:/bea/weblogic700/samples/server/eval/pointbase/lib/pbserver42ECF172.jar:C:/bea/weblogic700/samples/server/eval/pointbase/lib/pbclient42ECF172.jar
PB_SHUTDOWN_JARS=$POINTBASEJARS:C:/bea/weblogic700/samples/server/eval/pointbase/lib/pbtools42ECF172.jar
CLASSPATH=$CLASSPATH:$WL_HOME/lib/weblogic.jar:$POINTBASEJARS:$ARDIR/webservices.jar:$ARDIR/webserviceclient.jar:$ARDIR/webserviceclient+ssl.jar

if [ ! -z "$EXT_PRE_CLASSPATH" ]
then
    CLASSPATH=$EXT_PRE_CLASSPATH:$CLASSPATH
fi
if [ ! -z "$EXT_POST_CLASSPATH" ]
then
    CLASSPATH=$CLASSPATH:$EXT_POST_CLASSPATH
fi

PATH=$WL_HOME/bin:$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH
if [ ! -z "$EXT_PRE_SHLIBPATH" ]
then
    PATH=$EXT_PRE_SHLIBPATH:$PATH
fi
if [ ! -z "$EXT_POST_SHLIBPATH" ]
then
    PATH=$PATH:$EXT_POST_SHLIBPATH
fi
export PATH

#
# This script can be used to start WebLogic Server for the purpose
# of running the examples. This script ensures that the server is started
# using the config.xml file found in this directory and that the CLASSPATH
# is set appropriately. This script contains the following variables:
#
# WL_HOME        - The root directory of your WebLogic Server
#                  installation
# JAVA_HOME      - Determines the version of Java used to start
#                  WebLogic Server. This variable must point to the
#                  root directory of a JDK installation and will be set
#                  for you by the WebLogic Server installer.
#                  See the WebLogic platform
#                  support page (http://e-docs.bea.com/wls/platforms/index.html)
#                  for an up-to-date list of supported JVMs on your platform.
# JAVA_OPTIONS   - Java command-line options for running the server.
#
# jDriver for Oracle users: This script assumes that native libraries
# required for jDriver for Oracle have been installed in the proper
# location and that your system LD_LIBRARY_PATH variable has been set appropriately.
# Also note that this script default to the oci816_8 version of the
# shared libraries. If this is not the version you need, please adjust the
# LD_LIBRARY_PATH variable accordingly.
#
# For additional information, refer to Installing and Setting up WebLogic
# Server (http://e-docs.bea.com/wls/docs60/install/index.html).

JAVA_OPTIONS="-Xms64m -Xmx128m -XX:MaxPermSize=65536K"


# PLEASE DOCUMENT YOUR USAGE OF COMMAND LINE PARAMETERS!

JAVA_DEBUG="-Xdebug -Xnoagent 
            -Xrunjdwp:transport=dt_socket,address=8453,server=y,suspend=n"
JAVA_DEBUGPROXY=
DEBUG=true
PROFILE=false
JAVA_PROPERTIES=
LOGGING_FLAG="true"
SERVER_CLASS="weblogic.Server"
VM_MODE="-client" #BUG in JVM - this is a workaround - it should be "-server"

while [ $# -gt 0 ]
do
    case $1 in
    nodebug)
        DEBUG=false
        ;;
    noproxy)
        JAVA_DEBUGPROXY=""
        ;;
    drt)
        JAVA_PROPERTIES="$JAVA_PROPERTIES -Dknex.BrowserDebugOnly=true"
        LOGGING_FLAG="false"
        ;;
    nolog)
        LOGGING_FLAG="false"
        ;;
    production)
        LOGGING_FLAG="false"
        JAVA_PROPERTIES="$JAVA_PROPERTIES -Dweblogic.jws.ProductionMode=true -Dweblogic.ProductionModeEnabled=true"
        ;;
    fullserviceview)
        JAVA_PROPERTIES="$JAVA_PROPERTIES -Dweblogic.jws.debug.FullServiceView=true"
        ;;
    profile)
        if [ -z "$OPTIT_HOME" ]; then
            echo "OPTIT_HOME must be set to OptimizeIt home directory"
            exit 1
        fi
        JAVA_OPTIONS="-Xrunoii -Xbootclasspath/a:$OPTIT_HOME/lib/oibcp.jar $JAVA_OPTIONS"
        SERVER_CLASS="intuitive.audit.GenericAudit $SERVER_CLASS"
        CLASSPATH=$CLASSPATH:$OPTIT_HOME/lib/optit.jar
        VM_MODE="-classic"
        ;;
    esac
    shift
done


#
#  Clustering Support - Edit for your cluster!
#
CLUSTER_PROPERTIES="-Dweblogic.management.discover=false"
if [ "${ADMIN_URL}" != "" ]; then
    CLUSTER_PROPERTIES="-Dweblogic.management.server=${ADMIN_URL}"
fi

if [ -z "${SERVER_NAME}" ]; then
    SERVER_NAME=myServer
fi

JAVA_PROPERTIES="
    ${JAVA_PROPERTIES}
    -Dweblogic.Name=${SERVER_NAME}
    -Dbea.home=$WL_HOME/../.. 
    -Djava.security.policy=$WL_HOME/lib/weblogic.policy 
    -Dweblogic.management.username=system
    -Dweblogic.management.password=sinanuwong
    -Dweblogic.security.SSL.ignoreHostnameVerify=true 
    -Dweblogic.security.SSL.trustedCAKeyStore=./cacerts 
    -Dlog4j.configuration=file:$PLATFORMDIR/common/lib/workshopLogCfg.xml
    -Dweblogic.jws.logging=${LOGGING_FLAG}
    ${CLUSTER_PROPERTIES}
    "

if [ $DEBUG = true ]; then
    JAVA_PROPERTIES="$JAVA_PROPERTIES $JAVA_DEBUG"
    JAVA_DEBUGPROXY="yes"
fi

if [ ! -f config.xml ]; then
  echo "$0: must be run from the $BASEDIR directory." 1>&2
  exit 1
fi

# Check for classes
if [ ! -f $WL_HOME/lib/weblogic.jar ]; then
  echo "The weblogic.jar file was not found in directory $WL_HOME/lib." 1>&2
  exit 1
fi

# Check for JDK
if [ ! -f $JAVA_HOME/bin/java ]; then
  echo "The JDK wasn't found in directory $JAVA_HOME." 1>&2
  exit 1
fi
pwd

# Grab some file descriptors.
maxfiles=`ulimit -H -n`
if [ ! $? -a "$maxfiles" != 1024 ]; then
  if [ "$maxfiles" = "unlimited" ]; then
    maxfiles=1025
  fi
  if [ "$maxfiles" -lt 1024 ]; then
    ulimit -n $maxfiles
  else
    ulimit -n 1024
  fi
fi

# Figure out how to use our shared libraries
case `uname -s` in
AIX)
  if [ -n "$LIBPATH" ]; then
    LIBPATH=$LIBPATH:$WL_HOME/lib/aix
  else
    LIBPATH=$WL_HOME/lib/aix
  fi
  export LIB_PATH
  echo "LIBPATH=$LIBPATH"
;;
HP-UX)
  if [ -n "$SHLIB_PATH" ]; then
    SHLIB_PATH=$SHLIB_PATH:$WL_HOME/lib/hpux11:$WL_HOME/lib/hpux11/oci816_8
  else
    SHLIB_PATH=$WL_HOME/lib/hpux11:$WL_HOME/lib/hpux11/oci816_8
  fi
  export SHLIB_PATH
  echo "SHLIB_PATH=$SHLIB_PATH"
;;
IRIX)
  if [ -n "$LD_LIBRARY_PATH" ]; then
    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$WL_HOME/lib/irix
  else
    LD_LIBRARY_PATH=$WL_HOME/lib/irix
  fi
  export LD_LIBRARY_PATH
  echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
;;
LINUX|Linux)
  ARCHITECTURE=`uname -m`
  if [ -n "$LD_LIBRARY_PATH" ]; then
    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$WL_HOME/lib/linux/${ARCHITECTURE}
  else
    LD_LIBRARY_PATH=$WL_HOME/lib/linux/${ARCHITECTURE}
  fi
  export LD_LIBRARY_PATH
  echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH"

  #NEEDED for running on RedHat 7.1
  LD_ASSUME_KERNEL=2.2.5
  export LD_ASSUME_KERNEL
  if [ ! -f /usr/bin/cut -a $UID != 0 ]; then
    echo cut in /usr/bin NOT found, WebLogic depends on this
    echo Lets create it for you, please enter the root password
    /bin/su -c "ln -s /bin/cut /usr/bin/cut"
  fi
  #
  # Set the thread-stack size
  #
  ulimit -s 2048
;;
OSF1)
  if [ -n "$_RLD_LIST" ]; then
    _RLD_LIST=$_RLD_LIST:$WL_HOME/lib/tru64unix
  else
    _RLD_LIST=$WL_HOME/lib/tru64unix
  fi
  export _RLD_LIST
  echo "_RLD_LIST=$_RLD_LIST"
;;
SunOS)
  if [ -n "$LD_LIBRARY_PATH" ]; then
    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$WL_HOME/lib/solaris:$WL_HOME/lib/solaris/oci816_8
  else
    LD_LIBRARY_PATH=$WL_HOME/lib/solaris:$WL_HOME/lib/solaris/oci816_8
  fi
  export LD_LIBRARY_PATH
  echo "LD_LIBRARY_PATH=$LD_LIBRARY_PATH"
;;
*)
  echo "$0: Don't know how to set the shared library path for `uname -s`.  "
esac

if [ -n "$LD_LIBRARY_PATH" -a -n "$OPTIT_HOME" ]; then
    LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$OPTIT_HOME/lib
fi

#
# Kill Pointbase if it's still running
#
echo 'SHUTDOWN;' | "$JAVA_HOME/bin/java" -cp "$PB_SHUTDOWN_JARS" com.pointbase.tools.toolsCommander com.pointbase.jdbc.jdbcUniversalDriver jdbc:pointbase:server://localhost:9093/cajun 2> /dev/null > /dev/null

#
# Start Pointbase
#
if [ -z "$POINTBASE_OPTS" ]; then
    #POINTBASE_OPTS=/win
    POINTBASE_OPTS=/noconsole
fi

$JAVA_HOME/bin/java $JAVA_OPTIONS -classpath $CLASSPATH com.pointbase.net.netServer $POINTBASE_OPTS /port:9093 /d:0 /pointbase.ini=$BASEDIR/pointbase.ini > pointbase.log 1>&2 &

#
# Start debug proxy
#
if [ -n "$JAVA_DEBUGPROXY" ]; then
    $JAVA_HOME/bin/java -classpath $CLASSPATH JDIProxy.DbgMain & 
fi

#
# Start Weblogic server
#
$JAVA_HOME/bin/java $VM_MODE $JAVA_OPTIONS -classpath $CLASSPATH $JAVA_PROPERTIES $SERVER_CLASS
