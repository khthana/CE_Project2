@echo off

REM
REM    Shutdown WebLogic
REM
set JAVA_HOME=C:\bea\jdk131_03
set PLATFORMHOME=C:\bea\weblogic700
set CLASSPATH=%PLATFORMHOME%\server\lib\weblogic.jar
set ARGUMENTS=weblogic.Admin SHUTDOWN -url t3://localhost:7001 -username system -password sinanuwong

"%JAVA_HOME%\bin\java.exe" -cp "%CLASSPATH%" %ARGUMENTS%


REM
REM    Shutdown Pointbase
REM
set PB_DIR=C:\bea\weblogic700\samples\server\eval\pointbase\lib
set PB_CLASSPATH=%PB_DIR%\pbclient42ECF172.jar;%PB_DIR%\pbtools42ECF172.jar
echo SHUTDOWN; | "%JAVA_HOME%\bin\java.exe" -cp "%PB_CLASSPATH%" com.pointbase.tools.toolsCommander com.pointbase.jdbc.jdbcUniversalDriver jdbc:pointbase:server://localhost:9093/cajun


REM
REM    Shutdown JDI Proxy
REM
set CLASSPATH=%PLATFORMHOME%\server\lib\JDIProxy.jar;%JAVA_HOME%\lib\tools.jar
"%JAVA_HOME%\bin\java" -classpath "%CLASSPATH%" JDIProxy.DbgMain -SHUTDOWN 

exit
