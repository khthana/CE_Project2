<%@ page contentType="text/html; charset=WINDOWS-874" language="java" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body bgcolor="#FFFF99">

<div id="Layer1" style="position:absolute; left:136px; top:45px; width:439px; height:287px; z-index:1"> 
  <p><font color="#333333" size="+4" face="Times New Roman, Times, serif">Login...</font></p>
  <form action="index_after_login.jsp" method="post" name="form1" target="_parent">
    <table width="75%" border="0" align="center">
      <tr> 
        <td width="26%" height="31"><strong><font color="#666666" >Username :</font></strong> 
        </td>
        <td colspan="2"><input name="usernamefield" type="text" id="usernamefield" size="30" maxlength="25"></td>
      </tr>
      <tr> 
        <td height="24"><strong><font color="#666666">Password :</font></strong></td>
        <td colspan="2"><input name="pwdfield" type="password" id="pwdfield" size="30" maxlength="25"></td>
      </tr>
      <tr> 
        <td height="24"><strong></strong></td>
        <td width="26%"><input type="submit" name="Submit" value="Submit"></td>
        <td width="48%"><input name="clear" type="reset" id="clear2" value="clear"></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp; </p>
  </form>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>
<div id="Layer2" style="position:absolute; left:579px; top:27px; width:63px; height:87px; z-index:2"><img src="picture/note.gif" width="50" height="70"></div>
</body>
</html>
