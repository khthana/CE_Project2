<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<SCRIPT LANGUAGE = "VBScript">
<!--
	dim notcomplete 

	sub search_OnClick()
	tmpyears = CInt(form1.year1.value)+543
	years = CStr(tmpyears)
	a = form1.day1.value +"/"+ form1.month1.value +"/"+years
	startdate = CDate(a)
	allowdate = Date()
	if startdate < allowdate then
	msgbox "��ͧ�ͧ��ǧ˹�����ҧ���� 7 �ѹ"
	notcomplete = true
	else
		notcomplete = false
	end if
	end sub
	function form1_onsubmit()
	if (notcomplete = true) then
	form1_onsubmit = false
	end if
	end function
-->
</script>



</head>

<body>
<%
		Integer Temp = new Integer(request.getParameter("Contact_ID"));
		int Contact_ID = Temp.intValue();
		String Contact_Name = request.getParameter("Contact_Name");
		String Temp_Str2 = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
		Contact_Name = Temp_Str2;
%>
<center>���� Contact : <%=Contact_Name%></center>
<div id="Layer1" style="position:absolute; left:98px; top:122px; width:600px; height:345px; z-index:1"> 
  <center>SEARCH </center>
  <form action="resultsearch.jsp" method="post" name="form1" target="_self">
  <input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
  <input type = "hidden" name = "Contact_Name" value = "<%=Contact_Name%>">
  <%
  Date temp_date = new Date();
  Date temp = new Date(temp_date.getTime() + 604800000);
  %>

  <table width="90%" height="172" border="1" align = "center">
	  <tr>
			<td>���� : </td>
			<td><select name = "style" size = "1">
					<option value = "">������</option>
					<option value = "��">��</option>
					<option value = "�ҡ�">�ҡ�</option>
					<option value = "�չ">�չ</option>
			</td>
	  </tr>
      <tr> 
        <td width="18%">��Դ :</td>
        <td colspan="2" width = "*"><select name="type" size="1">
			<option value = "0">--- ������ ---</option>
            <option value="1">���ѹ��ҡ</option>
            <option value="2">ǧ�������</option>
            <option value="3">ǧ�����ʵ�ԧ</option>
            <option value="4">ǧ������ҡ�</option>
            <option value="5">ǧ����ըչ</option>
            <option value="6">�ѡ���ҡ�</option>
            <option value="7">������ش��꡵�</option>
            <option value="8">����Դ�ԧ�</option>
            <option value="9">�ػ�ҡèչ</option>
            <option value="10">����ǻ�Сͺ�ŧ</option>
          </select></td>
      </tr>
      <tr> 
        <td height="24" rowspan = 2>�ѹ - �������������ʴ� :</td>
        <td colspan="2"> �ѹ��� 
		<select name = "day1" >
		<%
				for (int i = 1 ; i <= 31 ; i ++) {
						%>
						<option value = "<%=i%>" <% if ( i == temp.getDate()) { %> <%="selected"%> <%}%>><%=i%>
						</option>
						<%}
						%>
		
		  </select>&nbsp;��͹ 
		 <select name = "month1">
		 <option value = "1" <%if (temp.getMonth() == 0) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "2" <%if (temp.getMonth() == 1) { %><%="selected"%><%}%>>����Ҿѹ��</option>
		 <option value = "3" <%if (temp.getMonth() == 2) { %><%="selected"%><%}%>>�չҤ�</option>
		 <option value = "4" <%if (temp.getMonth() == 3) { %><%="selected"%><%}%>>����¹</option>
		 <option value = "5" <%if (temp.getMonth() == 4) { %><%="selected"%><%}%>>����Ҥ�</option>
		 <option value = "6" <%if (temp.getMonth() == 5) { %><%="selected"%><%}%>>�Զع�¹</option>
		 <option value = "7" <%if (temp.getMonth() == 6) { %><%="selected"%><%}%>>�á�Ҥ�</option>
		 <option value = "8" <%if (temp.getMonth() == 7) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
		 <option value = "9" <%if (temp.getMonth() == 8) { %><%="selected"%><%}%>>�ѹ��¹</option>
		 <option value = "10" <%if (temp.getMonth() == 9) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "11" <%if (temp.getMonth() == 10) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
		 <option value = "12" <%if (temp.getMonth() == 11) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
		</select>&nbsp;�.�. 
		<select name = "year1">
		<option value = "2003">2546</option>
		<option value = "2004">2547</option>
		<option value = "2005">2548</option>
		</select>		</td>
      </tr>
      <tr> 

        <td width="27%" colspan = 2>���� 
		<select name = "hour1">
		<option value = "5">5</option>
		<option value = "6">6</option>
		<option value = "7">7</option>
		<option value = "8">8</option>
		<option value = "9">9</option>
		<option value = "10">10</option>
		<option value = "11">11</option>
		<option value = "12">12</option>
		<option value = "13">13</option>
		<option value = "14">14</option>
		<option value = "15">15</option>
		<option value = "16">16</option>
		<option value = "17">17</option>
		<option value = "18">18</option>
		<option value = "19">19</option>
		<option value = "20">20</option>
		<option value = "21">21</option>
		<option value = "22">22</option>
		<option value = "23">23</option>
		<option value = "0">0</option>
		</select>&nbsp; : &nbsp;

		<select name = "minute1">
		<option value = "00">00</option>
		<option value = "30">30</option>
		</select> �.
		</td>
      </tr>
      <tr> 
        <td>�ӹǹ������� :</td>
        <td colspan="2"><select name="time" size="1">
            <option value="3600000"> 1 ������� </option>
            <option value="7200000"> 2 ������� </option>
            <option value="10800000"> 3 ������� </option>
            <option value="14400000"> 4 ������� </option>
            <option value="18000000"> 5 ������� </option>
            <option value="21600000"> 6 ������� </option>
          </select></td>
      </tr>
	  <tr>
			<td>�Ҥ� :</td>
			<td>�����<input type = "text" name = "min_price" size = 5 maxlength = 5 value = "500"> �ҷ �֧
					<input type = "text" name = "max_price" size = 5 maxlength = 5 value = "500">�ҷ</td>
	  </tr>
    </table>
    <table align = "center">
      <tr>
	  <td><input name="search" type="submit" id="search" value="Search"></td>
      <td><input name="clear" type="reset" id="clear" value="Clear"></td>
    </tr>
	</table>
	</form>
	<table align = "center">
	<tr><td>
		<form action = "./showcontact.jsp" method = "post">
		<input type = "submit" value = "Back"></form></td>
	</tr>
	</table>
	
</div>
</body>
</html>
