<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType="text/html;charset=WINDOWS-874"%>
<%	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		Integer Temp_Integer = new Integer((String)session.getAttribute("Customer_ID"));
		int Customer_ID = Temp_Integer.intValue();
		String Temp_String = request.getParameter("Contact_ID");
		int Contact_ID = Temp_Integer.parseInt(Temp_String);
		Temp_String = request.getParameter("JobId");
		int Job_ID = Temp_Integer.parseInt(Temp_String);

		if(soapProxy.cancel_job_id(Customer_ID,Contact_ID,Job_ID).equals("success"))
		{
				response.sendRedirect("./showcontact.jsp");
		}
%>