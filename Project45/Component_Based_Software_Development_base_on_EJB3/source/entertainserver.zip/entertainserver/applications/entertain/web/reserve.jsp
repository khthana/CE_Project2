<%@ page contentType="text/html; charset=WINDOWS-874" language="java" errorPage="" %>
<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultReserve" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

</head>

<body>
<%
		String Temp_Str = (String)request.getParameter("Contact_ID");
		Integer Temp = new Integer(Temp_Str);
		int Contact_ID = Temp.intValue();

		String Type_Name = request.getParameter("Type_Name");
		String Temp_Str1 = new String(Type_Name.getBytes("ISO8859_1") , "MS874");
		Type_Name = Temp_Str1;
		String Band_Name = request.getParameter("Band_Name");
		String Temp_Str2 = new String(Band_Name.getBytes("ISO8859_1") , "MS874");
		Band_Name = Temp_Str2;
		String Contact_Name = request.getParameter("Contact_Name");
		String Temp_Str9 = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
		Contact_Name = Temp_Str9;
		Temp_Str = (String)request.getParameter("Band_ID");
		int Band_ID = Temp.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("Type_ID");
		int Type_ID = Temp.parseInt(Temp_Str);

		String Start_Datetime = request.getParameter("Start_Datetime");
		String Finish_Datetime = request.getParameter("Finish_Datetime");

		Temp_Str =(String)request.getParameter("Price_AM");
		Double Temp2 = new Double(Temp_Str);
		double Price_AM = Temp2.doubleValue();

		Temp_Str =(String)request.getParameter("Price_PM");
		Double Temp3 = new Double(Temp_Str);
		double Price_PM = Temp3.doubleValue();
%>
<form action = "booking.jsp" method = "post">
<table width = "80%" align = "center" border = 1>
<tr><td align = "">���� Contact</td><td align = "center"><%=Contact_Name%></td></tr>
<tr><td align = "">�������ͧǧ����� - ����ʴ�</td><td align = "center"><%=Type_Name%></td></tr>
<tr><td align = "">����ǧ����� - ����ʴ�</td><td align = "center"><%=Band_Name%></td></tr>
<tr><td align = "">�ѹ���������ʴ�</td><td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = Start_Datetime.toCharArray();
							for(int j = 0;  j < Start_Datetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "">�ѹ����ش����ʴ�</td><td align = "center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =Finish_Datetime.toCharArray();
							for(int j = 0;  j < Finish_Datetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "">��Һ�ԡ�� (5:00 �. - 17:00 �.)</td><td align = "center"><%=Price_AM%> �ҷ</td></tr>
<tr><td align = "">��Һ�ԡ�� (17:00 �. - 2:00 �.)</td><td align = "center"><%=Price_PM%> �ҷ</td></tr>
<tr><td align = "">�ѡɳТͧ�ҹ</td><td align = "center">
		<select name = "Function_Type">
		<option value = "birthday">�ҹ�ѹ�Դ</option>
		<option value = "engage">�ҹ����</option>
		<option value = "wedding">�ҹ�觧ҹ</option>
		<option value = "anniversy">�ҹ�ú�ͺ�觧ҹ</option>
		<option value = "party">�ҹ����§���</option>
		<option value = "educational">�ҹ����§������֡��</option>
		<option value = "exhibition">�Է��ȡ��</option>
		<option value = "fashionshow">Ὺ�����</option>
		<option value = "launch product">�ҹ�Դ����Թ���</option>
		<option value = "body">�ҹȾ</option>
		<option value = "others">����</option>

		</select>
		</td></tr>
<tr><td align = "">ʶҹ���</td><td align = "center">
		<input type = "text" name = "Place" size = 30 maxlength = 50>
		</td></tr>
<tr><td align = "">��������´�������</td><td align = "center">
		<textarea type = "text" name = "Additional_Requests" cols = 40 rows = 3 maxlength = 200 ></textarea>
		</td></tr>
</table>
						<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
						<input type = "hidden" name = "Type_Name" value = "<%=Type_Name%>">
						<input type = "hidden" name = "Band_Name" value = "<%=Band_Name%>">
						<input type = "hidden" name = "Contact_Name" value = "<%=Contact_Name%>">
						<input type = "hidden" name = "Band_ID" value = "<%=Band_ID%>">
						<input type = "hidden" name = "Type_ID" value = "<%=Type_ID%>">
						<input type = "hidden" name = "Start_Datetime" value = "<%=Start_Datetime%>">
						<input type = "hidden" name = "Finish_Datetime" value = "<%=Finish_Datetime%>">
						<input type = "hidden" name = "Price_AM" value = "<%=Price_AM%>">
						<input type = "hidden" name = "Price_PM" value = "<%=Price_PM%>">
						<center><input type = "submit" name = "reserve" value = "Reserve"></center>
</form>
</body>
</html>
