<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultSearchReserve"%>
<%@ page contentType="text/html; charset=WINDOWS-874" language="java" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

</head>

<body>
<%	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		Integer Temp_Integer = new Integer((String)session.getAttribute("Customer_ID"));
		int Customer_ID = Temp_Integer.intValue();
		String Temp_String = request.getParameter("Contact_ID");
		int Contact_ID = Temp_Integer.parseInt(Temp_String);
		String Contact_Name = request.getParameter("Contact_Name");
		String Temp_Str6 = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
		Contact_Name = Temp_Str6;
		ResultSearchReserve ResultSearch[] = soapProxy.search_by_contact_id(Customer_ID , Contact_ID);
		%>
		<table border = 1 align = "center" width = "90%">
		<tr><td align = "center" colspan = 3>��¡�çҹ������� &nbsp;<font color = "blue"><b><%=Contact_Name%></b></font></td></tr>
		<tr>
				<td align = "center">���ʡ���ʴ�</td>	
				<td align = "center">�ѡɳТͧ����ʴ�</td>	
				<td align = "center">������������ʴ�</td>	
		</tr>
		<%
		for (int i = 0 ; i < ResultSearch.length ; i ++) {
			%>
			<tr>
					<td align = "center"><a href = "show_job_detail_paid.jsp?Contact_ID=<%=Contact_ID%>&Job_ID=<%=ResultSearch[i].getJobId()%>"><%=ResultSearch[i].getJobId()%></a></td>
					<td align = "center"><%=ResultSearch[i].getFunctionType()%></td>
					<td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date =ResultSearch[i].getStartDatetime().toCharArray();
							for(int j = 0;  j < ResultSearch[i].getStartDatetime().length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
					</td>
			</tr>
			<%
		}
%>
		</table>
		<center>
		<form action = "./cancelcontact.jsp" method = "post">
		<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
		<input type = "submit" value = "Cancel Contact">
		</form>

		</center>
</body>
</html>
