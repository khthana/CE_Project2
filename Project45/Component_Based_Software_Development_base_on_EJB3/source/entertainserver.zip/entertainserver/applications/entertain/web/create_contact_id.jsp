<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultContactID"%>
<%@ page contentType="text/html; charset=WINDOWS-874" language="java" %>
<%	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		String Contact_Name = request.getParameter("Contact_Name");
		int Contact_ID = 0;
		Contact_ID = soapProxy.create_entertainment_contact_id();
		response.sendRedirect("./search.jsp?Contact_ID="+Contact_ID+"&Contact_Name="+Contact_Name);
%>

