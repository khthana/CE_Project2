<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<%	Entertainbank1_Impl proxy = new Entertainbank1_Impl(); 
		Entertainbank1Soap soapProxy = proxy.getentertainbank1Soap(); 
		Integer Temp_Integer = new Integer((String)session.getAttribute("Customer_ID"));
		int Customer_ID = Temp_Integer.intValue();
		String Temp_String = request.getParameter("Contact_ID");
		int Contact_ID = Temp_Integer.parseInt(Temp_String);
		Temp_String = request.getParameter("price");
		Double tempprice = new Double(Temp_String); 
		double price = tempprice.doubleValue();
		String credit_no = request.getParameter("credit_no");
		Temp_String = request.getParameter("expiremonth");
		int expiremonth = Temp_Integer.parseInt(Temp_String);
		Temp_String = request.getParameter("expireyear");
		int expireyear = Temp_Integer.parseInt(Temp_String);
		String pwd = request.getParameter("pwd");


		if(soapProxy.bank(Customer_ID,Contact_ID,"8888000022220100",credit_no,expiremonth,expireyear,pwd))
		{
			soapProxy.update_pay_date(Customer_ID,Contact_ID);
			out.print("��ҹ����Ф�Һ�ԡ�����º��������");
		}
		else
		{
			out.print("��ҹ�������ö���Ф�Һ�ԡ����");
		}

%>
<center><a href = "./showcontact.jsp">back</a></center>
</body>
</html>
