<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultReserveEntertain"%>
<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

</head>

<body>
<%
	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
	Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
	String temp1 = request.getParameter("JobId");
	Integer tempint = new Integer(temp1);
	int Job_ID = tempint.intValue();
	
	temp1 = request.getParameter("BandID");
	int Band_ID = tempint.parseInt(temp1);

	temp1 = request.getParameter("Contact_ID");
	int Contact_ID = tempint.parseInt(temp1);

	temp1 = request.getParameter("BandTypeID");
	int BandTypeID = tempint.parseInt(temp1);

	String BandName = request.getParameter("BandName");
	String Temp_Str1 = new String(BandName.getBytes("ISO8859_1") , "MS874");
	BandName = Temp_Str1;

	String BandDetail = request.getParameter("BandDetail");
	String Temp_Str2 = new String(BandDetail.getBytes("ISO8859_1") , "MS874");
	BandDetail = Temp_Str2;
	
	String day1 = request.getParameter("day1");
	String month1 = request.getParameter("month1");
	String year1 = request.getParameter("year1");
	String hour1 = request.getParameter("hour1");
	String minute = request.getParameter("minute");
	String numofhour = request.getParameter("numofhour");

	String StartDatetime = day1 + " " + month1 + " " + year1 + " " + hour1 + ":" + minute + ":00"; 

	Integer tempint2 = new Integer(numofhour);
	long num_of_hour = tempint2.longValue();
	Date temp_start_date = new Date(tempint.parseInt(year1),tempint.parseInt(month1) - 1,tempint.parseInt(day1),tempint.parseInt(hour1),tempint.parseInt(minute));
	
	Date temp_finish_date = new Date(temp_start_date.getTime() + num_of_hour);

	String FinishDatetime = tempint.toString(temp_finish_date.getDate()) + " " + tempint.toString(temp_finish_date.getMonth() + 1) + " " + tempint.toString(temp_finish_date.getYear()) + " " + tempint.toString(temp_finish_date.getHours()) + ":" + tempint.toString(temp_finish_date.getMinutes()) + ":00" ;

	String Place = request.getParameter("place");
	String Temp_Str3 = new String(Place.getBytes("ISO8859_1") , "MS874");
	Place = Temp_Str3;


	temp1 = request.getParameter("TotalPrice");
	Double temp2 = new Double(temp1);
	double TotalPrice = temp2.doubleValue();
	
	String FunctionType = request.getParameter("functiontype");
	String Temp_Str4 = new String(FunctionType.getBytes("ISO8859_1") , "MS874");
	FunctionType = Temp_Str4;

	String AdditionalRequests = request.getParameter("additionalrequests");
	String Temp_Str5 = new String(AdditionalRequests.getBytes("ISO8859_1") , "MS874");
	AdditionalRequests = Temp_Str5;
	 
	 Temp_Str5 = (String)session.getAttribute("Customer_ID");
	 int Customer_ID = tempint.parseInt(Temp_Str5);

	ResultReserveEntertain result = soapProxy.edit_reserve_entertainment(Contact_ID,Job_ID,Band_ID,Customer_ID,BandTypeID, StartDatetime,FinishDatetime,Place,FunctionType,AdditionalRequests);
	if (result==null)
	{
	}
	else{
%>
<table width="90%" height="172" border="1">
  	  <tr>
			<td align = "left">���ʡ���ʴ�</td>
			<td><%=Job_ID%></td>
	  </tr>
  	  <tr>
			<td align = "left">����ǧ����� - ����ʴ�</td>
			<td><%=BandName%></td>
	</tr>
  	  <tr>
			<td align = "left">��������´</td>
			<td><%=BandDetail%></td>
	  </tr>
  	  <tr>
			<td align = "left">�������������ʴ�</td>
			<td>					<%=day1%>&nbsp;<%if (month1.equals("1")) out.print("�.�.");
														if (month1.equals("2")) out.print("�.�.");
														if (month1.equals("3")) out.print("��.�.");
														if (month1.equals("4")) out.print("��.�.");
														if (month1.equals("5")) out.print("�.�.");
														if (month1.equals("6")) out.print("��.�.");
														if (month1.equals("7")) out.print("�.�.");
														if (month1.equals("8")) out.print("�.�.");
														if (month1.equals("9")) out.print("�.�.");
														if (month1.equals("10")) out.print("�.�.");
														if (month1.equals("11")) out.print("�.�.");
														if (month1.equals("12")) out.print("�.�.");
											int years = tempint.parseInt(year1);
											years = years+543;
											%>&nbsp;<%=years%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
		</td>
	  </tr>
  	  <tr>
			<td align = "left">��������ش����ʴ�</td>
			<td>		<%=temp_finish_date.getDate()%>&nbsp;<%if (temp_finish_date.getMonth() == 0) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 1) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 2) out.print("��.�.");
							 if (temp_finish_date.getMonth() == 3) out.print("��.�.");
							 if (temp_finish_date.getMonth() == 4) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 5) out.print("��.�.");
							 if (temp_finish_date.getMonth() == 6) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 7) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 8) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 9) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 10) out.print("�.�.");
							 if (temp_finish_date.getMonth() == 11) out.print("�.�.");
							years = temp_finish_date.getYear() +543;
					%>&nbsp;<%=years%>&nbsp;&nbsp;<%=temp_finish_date.getHours()%>:<%
						if(temp_finish_date.getMinutes()==0)  out.print("00");
							 else out.print("30");
						%>&nbsp;�.
			</td>
	  </tr>
  	  <tr>
			<td align = "left">�ѹ����ش��ê��Ф�Һ�ԡ��</td>
			<td>
					<%
							String temp_paydate = "";
							int payday = 0;
							int paymonth = 0;
							int payyear = 0;
							int count = 0;
							char[] temp_date = result.getDeadlineConfirm().toCharArray();
							for(int j = 0;  j < result.getDeadlineConfirm().length(); j++)
							{	
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp_paydate);
													payday = temp_day.intValue();
													temp_paydate = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp_paydate);
													paymonth = temp_month.intValue();
													temp_paydate = "";
											}
									}
									else
									{
											temp_paydate = temp_paydate + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp_paydate);
													payyear = temp_year.intValue();
											}
									}
							}
							payyear = payyear +543;
					%>
					<%=payday%>&nbsp;<%if (paymonth == 1) out.print("�.�.");
														if (paymonth == 2) out.print("�.�.");
														if (paymonth == 3) out.print("��.�.");
														if (paymonth == 4) out.print("��.�.");
														if (paymonth == 5) out.print("�.�.");
														if (paymonth == 6) out.print("��.�.");
														if (paymonth == 7) out.print("�.�.");
														if (paymonth == 8) out.print("�.�.");
														if (paymonth == 9) out.print("�.�.");
														if (paymonth == 10) out.print("�.�.");
														if (paymonth == 11) out.print("�.�.");
														if (paymonth == 12) out.print("�.�.");
											%>&nbsp;<%=payyear%>
			</td>
	  </tr>
  	  <tr>
			<td align = "left">ʶҹ���</td>
			<td><%=Place%></td>
	  </tr>
  	  <tr>
			<td align = "left">�Ҥ�</td>
			<td><%=result.getTotalPrice()%>&nbsp;�ҷ</td>
	  </tr>
  	  <tr>
			<td align = "left">�ѡɳТͧ�ҹ</td>
			<td><%=FunctionType%></td>
	  </tr>
  	  <tr>
			<td align = "left">��������´�������</td>
			<td><%=AdditionalRequests%></td>

	  </tr>
</table>
<%
  }
%>
<br>
<center>		
		<form action = "./showcontact.jsp" method = "post">
		<input type = "submit" value = "Back"></form>
</center>
</body>
</html>
