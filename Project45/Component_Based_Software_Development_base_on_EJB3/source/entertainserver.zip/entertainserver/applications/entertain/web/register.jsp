<%@ page contentType="text/html; charset=WINDOWS-874" language="java" errorPage="" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
<SCRIPT LANGUAGE = "VBScript">
<!--
	dim notcomplete 
	sub Submit_OnClick()
	if (form1.pwdfield.Value <> form1.re_pwdfield.Value) then
		msgbox "��س�����������١��ͧ"
		notcomplete = true
	else
		notcomplete = false
	end if
	end sub
	function form1_onsubmit()
	if (notcomplete = true) then
	form1_onsubmit = false
	end if
	end function
-->
</script>

</head>

<body   bgcolor="#FFFF99" >

<div id="Layer1" style="position:absolute; left:54px; top:25px; width:720px; height:450px; z-index:1"> 
  <p align="left"><font color="#333333" size="+4" face="Times New Roman, Times, serif"><strong>Register...</strong></font></p>
  <form name="form1" method="post" action = "./registing.jsp">
    <table width="58%" height="95%" border="0" align="left" cellpadding="0" cellspacing="0">
      <tr> 
        <td width="25%" height="24"><font color="#666666"><strong>Firstname :</strong></font></td>
        <td colspan="2"><div align="left"> 
            <input name="firstnamefield" type="text" id="firstnamefield4" size="30" maxlength="25">
          </div></td>
      </tr>
      <tr> 
        <td height="26"><font color="#666666"><strong>Lastname :</strong></font></td>
        <td colspan="2"><input name="lastnamefield" type="text" id="lastnamefield4" size="30" maxlength="25"> 
        </td>
      </tr>
      <tr> 
        <td height="21"><font color="#666666"><strong>Address : </strong></font></td>
        <td colspan="2"><textarea name="addressfield" cols="30" rows="3" id="textarea3"></textarea> 
        </td>
      </tr>
      <tr> 
        <td height="21"><font color="#666666"><strong>Sex : </strong></font></td>
        <td colspan="2"><table width="200">
            <tr> 
              <td><label> 
                <input name="sexgroup" type="radio" value="Male" checked>
                <strong> <font color="#666666">Male</font></strong></label></td>
            </tr>
            <tr> 
              <td><label> 
                <input type="radio" name="sexgroup" value="Female">
                <strong><font color="#666666">Female</font></strong></label></td>
            </tr>
          </table></td>
      </tr>
      <tr> 
        <td height="24"><font color="#666666"><strong>Age :</strong></font></td>
        <td colspan="2"><input name="agefield" type="text" id="agefield4" size="5" maxlength="5"> 
        </td>
      </tr>
      <tr> 
        <td height="24"><font color="#666666"><strong>Telephone : </strong></font></td>
        <td colspan="2"><input name="telfield" type="text" id="telfield4" size="20" maxlength="15"> 
        </td>
      </tr>
      <tr> 
        <td height="21"><font color="#666666"><strong>E-Mail :</strong> </font></td>
        <td colspan="2"><input name="emailfield" type="text" id="emailfield4" size="30" maxlength="25"> 
        </td>
      </tr>
      <tr> 
        <td height="21"><font color="#666666"><strong>Username :</strong></font></td>
        <td colspan="2"><input name="usernamefield" type="text" id="usernamefield4" size="30" maxlength="25"> 
        </td>
      </tr>
      <tr> 
        <td height="21"><font color="#666666"><strong>Password :</strong> </font></td>
        <td colspan="2"><input name="pwdfield" type="password" id="pwdfield4" size="30" maxlength="25"> 
        </td>
      </tr>
      <tr> 
        <td height="21"><font color="#666666"><strong>Re-Password :</strong></font></td>
        <td colspan="2"><input name="re_pwdfield" type="password" id="re_pwdfield" size="30" maxlength="25"></td>
      </tr>
      <tr> 
        <td height="29"><p>&nbsp;</p>
          </td>
        <td width="25%"><input  type="submit" name="Submit" value="Register"> </td>
        <td width="50%"><input name="clear" type="reset" id="clear" value="Clear"></td>
      </tr>
    </table>
  </form>
  
 
</div>
<div id="Layer2" style="position:absolute; left:600px; top:22px; width:86px; height:62px; z-index:2"><img src="picture/note.gif" width="50" height="70"></div>
</body>
</html>
