<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body bgcolor="#FF9900" link="#FF9900">
<div id="Layer1" style="position:absolute; left:8px; top:19px; width:190px; height:481px; z-index:1"> 
  <div id="Layer2" style="position:absolute; left:53px; top:11px; width:136px; height:40px; z-index:2"><a href="showcontact.jsp" target="mainFrame"><img src="button/home.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:39px; top:53px; width:136px; height:40px; z-index:2"><a href="thaiband.htm" target="mainFrame"><img src="button/thai.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:25px; top:95px; width:136px; height:40px; z-index:2"><a href="stingband.htm" target="mainFrame"><img src="button/sting.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:13px; top:137px; width:136px; height:40px; z-index:2"><a href="chineseband.htm" target="mainFrame"><img src="button/chinese.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:1px; top:179px; width:136px; height:40px; z-index:2"><a href="classicalband.htm" target="mainFrame"><img src="button/classical.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:1px; top:221px; width:136px; height:40px; z-index:2"><a href="magician.htm" target="mainFrame"><img src="button/magic.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:13px; top:263px; width:136px; height:40px; z-index:2"><a href="liondance.htm" target="mainFrame"><img src="button/liondance.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:25px; top:305px; width:136px; height:40px; z-index:2"><a href="chineseopera.htm" target="mainFrame"><img src="button/chinesopera.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:39px; top:347px; width:136px; height:40px; z-index:2"><a href="dollman.htm" target="mainFrame"><img src="button/dollman.gif" width="128" height="34" border="0"></a></div>
  <div id="Layer2" style="position:absolute; left:53px; top:389px; width:136px; height:40px; z-index:2"><a href="dancer.htm" target="mainFrame"><img src="button/dancer.gif" width="128" height="34" border="0"></a></div>
  <p>&nbsp;</p>
  </div>
</body>
</html>
