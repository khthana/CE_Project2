<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Untitled Document</title>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>
<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultSearch" %>
<%@ page contentType="text/html;charset=WINDOWS-874"%>


<% Entertainment_Impl proxy = new Entertainment_Impl(); %>
<% EntertainmentSoap soapProxy = proxy.getEntertainmentSoap(); %>
<% String result = new String();
		String Username = request.getParameter("usernamefield");
		String Password = request.getParameter("pwdfield");
//result = soapProxy.register("���о���" , "���ͧ��ǧ���ѵ��" , "male" , 20 , "023738174" , "home" , "m_tawan@hotmail.com" , "tee1" , "mue4" );
		result = soapProxy.login( Username , Password);
		if (result.equals("Error")) {
				response.sendRedirect("./login.jsp");
		}
		else {
%>
<frameset rows="80,*" cols="*" framespacing="1" frameborder="yes" border="1" bordercolor="#CCCCCC">
  <frame src="head_after_login.htm" name="topFrame" scrolling="NO" noresize >
  <frameset rows="*" cols="151,*" framespacing="0" frameborder="NO" border="0">
    <frame src="button_after_login.htm" name="leftFrame" scrolling="NO" noresize>
    <frame src="showcontact.jsp" name="mainFrame">
  </frameset>
</frameset>
<noframes><body>

</body></noframes>
<%
		}	
%>
</html>
