<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<SCRIPT LANGUAGE = "VBScript">
<!--
	dim notcomplete 

	sub edit_OnClick()
	tmpyears = CInt(form1.year1.value)+543
	years = CStr(tmpyears)
	a = form1.day1.value +"/"+ form1.month1.value +"/"+years
	startdate = CDate(a)
	allowdate = Date()
	if startdate < allowdate then
	msgbox "��ͧ�ͧ��ǧ˹�����ҧ���� 7 �ѹ"
	notcomplete = true
	else
		notcomplete = false
	end if
	end sub
	function form1_onsubmit()
	if (notcomplete = true) then
	form1_onsubmit = false
	end if
	end function
-->
</script>
</head>

<body>
<%
	String temp1 = request.getParameter("JobId");
	Integer tempint = new Integer(temp1);
	int Job_Id = tempint.intValue();
	
	temp1 = request.getParameter("Contact_ID");
	int Contact_ID = tempint.parseInt(temp1);

	temp1 = request.getParameter("BandID");
	int BandID = tempint.parseInt(temp1);

	temp1 = request.getParameter("BandTypeID");
	int BandTypeID = tempint.parseInt(temp1);

	String BandName = request.getParameter("BandName");
	String Temp_Str1 = new String(BandName.getBytes("ISO8859_1") , "MS874");
	BandName = Temp_Str1;
	String BandDetail = request.getParameter("BandDetail");
	String Temp_Str2 = new String(BandDetail.getBytes("ISO8859_1") , "MS874");
	BandDetail = Temp_Str2;
	String StartDatetime = request.getParameter("StartDatetime");
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = StartDatetime.toCharArray();
							for(int j = 0;  j < StartDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
<%
	String FinishDatetime = request.getParameter("FinishDatetime");
							temp = "";
							int day2 = 0;
							int month2 = 0;
							int year2 = 0;
							count = 0;
							String hour2 = new String();
							minute1 = 0;
							String minute2 = new String();
							temp_date =FinishDatetime.toCharArray();
							for(int j = 0;  j < FinishDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day2 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month2 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year2 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour2 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute2 = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute2 = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year2 = year2 +543;
					%>

<%
	String Place = request.getParameter("Place");
	String Temp_Str3 = new String(Place.getBytes("ISO8859_1") , "MS874");
	Place = Temp_Str3;


	temp = request.getParameter("TotalPrice");
	Double temp2 = new Double(temp);
	double TotalPrice = temp2.doubleValue();
	
	String FunctionType = request.getParameter("FunctionType");
	String Temp_Str4 = new String(FunctionType.getBytes("ISO8859_1") , "MS874");
	FunctionType = Temp_Str4;

	String AdditionalRequests = request.getParameter("AdditionalRequests");
	String Temp_Str5 = new String(AdditionalRequests.getBytes("ISO8859_1") , "MS874");
	AdditionalRequests = Temp_Str5;
%>
<Form action = "result_edit.jsp" method = "post"  name = "form1">
  <table width="90%" height="172" border="1">
  	  <tr>
			<td align = "left">���ʡ���ʴ�</td>
			<td><%=Job_Id%></td>
	  </tr>
  	  <tr>
			<td align = "left">����ǧ����� - ����ʴ�</td>
			<td><%=BandName%></td>
	</tr>
  	  <tr>
			<td align = "left">��������´</td>
			<td><%=BandDetail%></td>
	  </tr>
  	  <tr>
			<td align = "left">�������������ʴ�</td>
			<td>		<select name = "day1" >
			<%
					for (int i = 1 ; i <= 31 ; i ++) {
			%>
					<option value = "<%=i%>" <% if ( i == day1) { %> <%="selected"%> <%}%>><%=i%></option>
			<%
				}
			%>
		</select>&nbsp;��͹ 
		 <select name = "month1">
		 <option value = "1" <%if (month1 == 1) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "2" <%if (month1 == 2) { %><%="selected"%><%}%>>����Ҿѹ��</option>
		 <option value = "3" <%if (month1 == 3) { %><%="selected"%><%}%>>�չҤ�</option>
		 <option value = "4" <%if (month1 == 4) { %><%="selected"%><%}%>>����¹</option>
		 <option value = "5" <%if (month1 == 5) { %><%="selected"%><%}%>>����Ҥ�</option>
		 <option value = "6" <%if (month1 == 6) { %><%="selected"%><%}%>>�Զع�¹</option>
		 <option value = "7" <%if (month1 == 7) { %><%="selected"%><%}%>>�á�Ҥ�</option>
		 <option value = "8" <%if (month1 == 8) { %><%="selected"%><%}%>>�ԧ�Ҥ�</option>
		 <option value = "9" <%if (month1 == 9) { %><%="selected"%><%}%>>�ѹ��¹</option>
		 <option value = "10" <%if (month1 == 10) { %><%="selected"%><%}%>>���Ҥ�</option>
		 <option value = "11" <%if (month1 == 11) { %><%="selected"%><%}%>>��Ȩԡ�¹</option>
		 <option value = "12" <%if (month1 == 12) { %><%="selected"%><%}%>>�ѹ�Ҥ�</option>
		</select>&nbsp;�.�. 
		<select name = "year1">
		<option value = "2003">2546</option>
		<option value = "2004">2547</option>
		<option value = "2005">2548</option>
		</select>
		&nbsp;����		
		<select name = "hour1">
				<%
				for (int i = 0 ; i <= 23 ; i ++) {
				%>
				<option value = "<%=i%>" <%if (tempint.parseInt(hour1) == i) { %><%="selected"%><%}%> ><%=i%></option>
				<%
				}
		%>
		</select>&nbsp; : &nbsp;
		<select name = "minute">
		<option value = "00" <%if (minute.equals("00")) { %><%="selected"%><%}%>>00</option>
		<option value = "30" <%if (minute.equals("30")) { %><%="selected"%><%}%>>30</option>
		</select> �.
		</td>
	  </tr>
  	  <tr>
		<%	Date startdate = new Date(year1,month1,day1, tempint.parseInt(hour1),tempint.parseInt(minute));
				Date finishdate = new Date(year2,month2,day2,tempint.parseInt(hour2),tempint.parseInt(minute2));
				long numofhour = finishdate.getTime()-startdate.getTime();
	
		%>
			<td align = "left">�ӹǹ�������</td>
			<td>		
			<select name = "numofhour">
            <option value="3600000" <%if (numofhour == 3600000) { %><%="selected"%><%}%>> 1 ������� </option>
            <option value="7200000" <%if (numofhour == 7200000) { %><%="selected"%><%}%>> 2 ������� </option>
            <option value="10800000" <%if (numofhour == 10800000) { %><%="selected"%><%}%>> 3 ������� </option>
            <option value="14400000" <%if (numofhour == 14400000) { %><%="selected"%><%}%>> 4 ������� </option>
            <option value="18000000" <%if (numofhour == 18000000) { %><%="selected"%><%}%>> 5 ������� </option>
            <option value="21600000" <%if (numofhour == 21600000) { %><%="selected"%><%}%>> 6 ������� </option>
			</select>
			</td>
	  </tr>
  	  <tr>
			<td align = "left">ʶҹ���</td>
			<td><input type = "text" value ="<%=Place%>" name = "place" size = "30" maxlength = "50"></td>
	  </tr>
  	  <tr>
			<td align = "left">�Ҥ�</td>
			<td><%=TotalPrice%>&nbsp;�ҷ</td>
	  </tr>
  	  <tr>
			<td align = "left">�ѡɳТͧ�ҹ</td>
			<td>
			<select name = "Function_Type">
			<option value = "birthday"<%if (FunctionType.equals("birthday")) { %><%="selected"%><%}%>>�ҹ�ѹ�Դ</option>
			<option value = "engage"<%if (FunctionType.equals("engage")) { %><%="selected"%><%}%>>�ҹ����</option>
			<option value = "wedding"<%if (FunctionType.equals("wedding")) { %><%="selected"%><%}%>>�ҹ�觧ҹ</option>
			<option value = "anniversy"<%if (FunctionType.equals("annivesary")) { %><%="selected"%><%}%>>�ҹ�ú�ͺ�觧ҹ</option>
			<option value = "party"<%if (FunctionType.equals("party")) { %><%="selected"%><%}%>>�ҹ����§���</option>
			<option value = "educational"<%if (FunctionType.equals("educational")) { %><%="selected"%><%}%>>�ҹ����§������֡��</option>
			<option value = "exhibition"<%if (FunctionType.equals("exhibition")) { %><%="selected"%><%}%>>�Է��ȡ��</option>
			<option value = "fashionshow"<%if (FunctionType.equals("fashionshow")) { %><%="selected"%><%}%>>Ὺ�����</option>
			<option value = "launch product"<%if (FunctionType.equals("launch product")) { %><%="selected"%><%}%>>�ҹ�Դ����Թ���</option>
			<option value = "body"<%if (FunctionType.equals("body")) { %><%="selected"%><%}%>>�ҹȾ</option>
			<option value = "others"<%if (FunctionType.equals("others")) { %><%="selected"%><%}%>>����</option>
			</select>
			</td>
	  </tr>
  	  <tr>
			<td align = "left">��������´�������</td>
			<td><textarea name = "additionalrequests" cols = "30"  rows = "2"maxlength = "200"><%=AdditionalRequests%></textarea></td>

	  </tr>
	</table>
		<input type = "hidden" name = "JobId" value = "<%=Job_Id%>">
		<input type = "hidden" name = "BandID" value = "<%=BandID%>">
		<input type = "hidden" name = "BandTypeID" value = "<%=BandTypeID%>">
		<input type = "hidden" name = "BandName" value = "<%=BandName%>">
		<input type = "hidden" name = "BandDetail" value = "<%=BandDetail%>">
		<input type = "hidden" name = "TotalPrice" value = "<%=TotalPrice%> ">
		<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
		<br>
		<center><input type = "submit" value = "edit" name = "edit"></center>
</Form>
</body>
</html>
