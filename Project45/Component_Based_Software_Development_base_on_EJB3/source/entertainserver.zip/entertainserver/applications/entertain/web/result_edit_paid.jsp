<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultReserveEntertain"%>
<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

</head>

<body>
<%
	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
	Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
	String temp1 = request.getParameter("JobId");
	Integer tempint = new Integer(temp1);
	int Job_ID = tempint.intValue();
	
	temp1 = request.getParameter("BandID");
	int Band_ID = tempint.parseInt(temp1);

	temp1 = request.getParameter("Contact_ID");
	int Contact_ID = tempint.parseInt(temp1);

	temp1 = request.getParameter("BandTypeID");
	int BandTypeID = tempint.parseInt(temp1);

	String BandName = request.getParameter("BandName");
	String Temp_Str1 = new String(BandName.getBytes("ISO8859_1") , "MS874");
	BandName = Temp_Str1;

	String BandDetail = request.getParameter("BandDetail");
	String Temp_Str2 = new String(BandDetail.getBytes("ISO8859_1") , "MS874");
	BandDetail = Temp_Str2;
	
	String StartDatetime = request.getParameter("StartDatetime"); 
 	String FinishDatetime = request.getParameter("FinishDatetime");

	String Place = request.getParameter("place");
	String Temp_Str3 = new String(Place.getBytes("ISO8859_1") , "MS874");
	Place = Temp_Str3;


	temp1 = request.getParameter("TotalPrice");
	Double temp2 = new Double(temp1);
	double TotalPrice = temp2.doubleValue();
	
	String FunctionType = request.getParameter("functiontype");
	String Temp_Str4 = new String(FunctionType.getBytes("ISO8859_1") , "MS874");
	FunctionType = Temp_Str4;

	String AdditionalRequests = request.getParameter("additionalrequests");
	String Temp_Str5 = new String(AdditionalRequests.getBytes("ISO8859_1") , "MS874");
	AdditionalRequests = Temp_Str5;
	 
	 Temp_Str5 = (String)session.getAttribute("Customer_ID");
	 int Customer_ID = tempint.parseInt(Temp_Str5);

	ResultReserveEntertain result = soapProxy.edit_reserve_entertainment(Contact_ID,Job_ID,Band_ID,Customer_ID,BandTypeID, StartDatetime,FinishDatetime,Place,FunctionType,AdditionalRequests);
	if (result==null)
	{
	}
	else{
%>
<table width="90%" height="172" border="1">
  	  <tr>
			<td align = "left">���ʡ���ʴ�</td>
			<td><%=Job_ID%></td>
	  </tr>
  	  <tr>
			<td align = "left">����ǧ����� - ����ʴ�</td>
			<td><%=BandName%></td>
	</tr>
  	  <tr>
			<td align = "left">��������´</td>
			<td><%=BandDetail%></td>
	  </tr>
  	  <tr>
			<td align = "left">�������������ʴ�</td>
			<td>	<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = StartDatetime.toCharArray();
							for(int j = 0;  j < StartDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
		</td>
	  </tr>
	  <tr>
			<td align = "left">��������ش����ʴ�</td>
			<td>	<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =FinishDatetime.toCharArray();
							for(int j = 0;  j < FinishDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
			</td>
	  </tr>
  	  <tr>
			<td align = "left">ʶҹ���</td>
			<td><%=Place%></td>
	  </tr>
  	  <tr>
			<td align = "left">�Ҥ�</td>
			<td><%=result.getTotalPrice()%>&nbsp;�ҷ</td>
	  </tr>
  	  <tr>
			<td align = "left">�ѡɳТͧ�ҹ</td>
			<td><%=FunctionType%></td>
	  </tr>
  	  <tr>
			<td align = "left">��������´�������</td>
			<td><%=AdditionalRequests%></td>

	  </tr>
</table>
<%
  }
%>
<br>
<center>		
		<form action = "./showcontact.jsp" method = "post">
		<input type = "submit" value = "Back"></form>
</center>
</body>
</html>
