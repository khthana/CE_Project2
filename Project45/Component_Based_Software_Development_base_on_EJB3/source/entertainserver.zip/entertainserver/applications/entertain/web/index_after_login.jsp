
<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultSearch" %>
<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Olala Entertainment</title>
</head>
<%	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		String result = new String();
		String Username = request.getParameter("usernamefield");
		String Password = request.getParameter("pwdfield");
		int Customer_ID = soapProxy.login_entertainment(Username , Password);
		if (Customer_ID == 0) {
				response.sendRedirect("./index.htm");
		}
		else
		{
				Integer Temp = new Integer(Customer_ID);
				session.setAttribute("Customer_ID" , Temp.toString());
		
		%>
<frameset rows="103,*" cols="*" framespacing="1" frameborder="yes" border="1" bordercolor="#CCCCCC"> 
  <frame src="head_after_login.htm" name="topFrame" scrolling="NO" noresize >
  <frameset rows="*" cols="200,*" framespacing="0" frameborder="NO" border="0"> 
    <frame src="button_after_login.jsp" name="leftFrame" scrolling="NO" noresize>
    <frame src="showcontact.jsp" name="mainFrame">
  </frameset>
</frameset>
<noframes>
<body>
</body>
</noframes> 
<%
		}
%>
</html>
