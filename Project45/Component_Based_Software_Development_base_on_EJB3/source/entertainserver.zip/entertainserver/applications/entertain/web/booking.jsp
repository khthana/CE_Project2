<%@ page contentType="text/html; charset=WINDOWS-874" language="java" errorPage="" %>
<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultReserveEntertain" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

</head>

<body>
<%
		String Temp_Str = (String)request.getParameter("Contact_ID");
		Integer Temp = new Integer(Temp_Str);
		int Contact_ID = Temp.intValue();
		
		String Type_Name = request.getParameter("Type_Name");
		String Temp_Str1 = new String(Type_Name.getBytes("ISO8859_1") , "MS874");
		Type_Name = Temp_Str1;
		String Band_Name = request.getParameter("Band_Name");
		String Temp_Str2 = new String(Band_Name.getBytes("ISO8859_1") , "MS874");
		Band_Name = Temp_Str2;
		String Contact_Name = request.getParameter("Contact_Name");
		String Temp_Str3 = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
		Contact_Name = Temp_Str3;
		Temp_Str = (String)request.getParameter("Band_ID");
		int Band_ID = Temp.parseInt(Temp_Str);

		Temp_Str = (String)request.getParameter("Type_ID");
		int Type_ID = Temp.parseInt(Temp_Str);

		String Start_Datetime = request.getParameter("Start_Datetime");
		String Finish_Datetime = request.getParameter("Finish_Datetime");

		String Function_Type = request.getParameter("Function_Type");
		String Temp_Str4 = new String(Function_Type.getBytes("ISO8859_1") , "MS874");
		Function_Type = Temp_Str4;
		String Place = request.getParameter("Place");
		String Temp_Str5 = new String(Place.getBytes("ISO8859_1") , "MS874");
		Place = Temp_Str5;
		String Additional_Requests = request.getParameter("Additional_Requests");
		String Temp_Str6 = new String(Additional_Requests.getBytes("ISO8859_1") , "MS874");
		Additional_Requests = Temp_Str6;
		Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		Integer Temp3 = new Integer( (String)session.getAttribute("Customer_ID") );
		int Customer_ID = Temp3.intValue();

		Temp_Str =(String)request.getParameter("Price_AM");
		Double Temp4 = new Double(Temp_Str);
		double Price_AM = Temp4.doubleValue();
				
		Temp_Str =(String)request.getParameter("Price_PM");
		Double Temp5 = new Double(Temp_Str);
		double Price_PM = Temp5.doubleValue();
		ResultReserveEntertain Result = soapProxy.reserve_entertainment(Contact_ID , Contact_Name , Band_ID , Customer_ID , Type_ID , Start_Datetime , Finish_Datetime , Place , Function_Type , Price_AM , Price_PM , Additional_Requests);
		if (Result == null) 
		{
//				response.sendRedirect("./data.jsp");
		}
		else
		{
				%>
<table width = "80%" align = "center" border = 1>
<tr><td align = "">���� Contact</td><td align = "center"><%=Contact_Name%></td></tr>
<tr><td align = "">�������ͧǧ����� - ����ʴ�</td><td align = "center"><%=Type_Name%></td></tr>
<tr><td align = "">����ǧ����� - ����ʴ�</td><td align = "center"><%=Band_Name%></td></tr>
<tr><td align = "">�ѹ���������ʴ�</td><td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = Start_Datetime.toCharArray();
							for(int j = 0;  j < Start_Datetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "">�ѹ����ش����ʴ�</td><td align = "center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =Finish_Datetime.toCharArray();
							for(int j = 0;  j < Finish_Datetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
</td></tr>
<tr><td align = "">�ѹ����ش��ê��Ф�Һ�ԡ��</td><td align = "center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							temp_date = Result.getDeadlineConfirm().toCharArray();
							for(int j = 0;  j < Result.getDeadlineConfirm().length(); j++)
							{	
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>
</td></tr>
<tr><td align = "">��Һ�ԡ��</td><td align = "center"><%=Result.getTotalPrice()%> �ҷ</td></tr>
<tr><td align = "">�ѡɳТͧ�ҹ</td><td align = "center"><%=Function_Type%></td></tr>
<tr><td align = "">ʶҹ���</td><td align = "center"><%=Place%></td></tr>
<tr><td align = "">��������´�������</td><td align = "center"><%=Additional_Requests%></td></tr>
</table>
		
				<%
		}
%>
<center><form action = "./showcontact.jsp" method = "post">
		<input type = "submit" value = "Back To Show All Contact"></center>


</body>
</html>
