<%@ page contentType="text/html; charset=WINDOWS-874" language="java" errorPage="" %>
<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultReserve" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html;">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
//-->
</script>
</head>

<body>
<%
		String Contact_Name = request.getParameter("Contact_Name");
		String Temp_Str9 = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
		Contact_Name = Temp_Str9;
		String Style = request.getParameter("style");
		String Temp_Str2 = new String(Style.getBytes("ISO8859_1") , "MS874");
		Style = Temp_Str2;
		String Temp_Str = request.getParameter("day1");
		Integer Temp = new Integer(Temp_Str);
		int Day1 = Temp.intValue();
		
		Temp_Str = request.getParameter("Contact_ID");
		int Contact_ID = Temp.parseInt(Temp_Str);

		Temp_Str = request.getParameter("type"); 
		int Type = Temp.parseInt(Temp_Str);

		Temp_Str = request.getParameter("month1"); 
		int Month1 = Temp.parseInt(Temp_Str);

		Temp_Str = request.getParameter("year1"); 
		int Year1 =  Temp.parseInt(Temp_Str);

		Temp_Str = request.getParameter("hour1");
		int Hour1 =  Temp.parseInt(Temp_Str);

		Temp_Str =  request.getParameter("minute1");
		int Minute1 = Temp.parseInt(Temp_Str);

		Temp_Str =  request.getParameter("time");
		Integer Temp2 = new Integer(Temp_Str);
		long Time = Temp2.longValue();
		Date Temp_Start_Date = new Date(Year1 , Month1 - 1 , Day1 , Hour1 , Minute1 );
		String Start_Date = Temp.toString(Day1) + " " + Temp.toString(Month1) + " " + Temp.toString(Year1) + " "  +Temp.toString(Hour1) + ":" + Temp.toString(Minute1) + ":00" ;

		long Temp_Time = Temp_Start_Date.getTime();
		Date Temp_Finish_Date = new Date(Time + Temp_Time);
		String Finish_Date = Temp.toString(Temp_Finish_Date.getDate()) + " " + Temp.toString(Temp_Finish_Date.getMonth() + 1) + " " +  Temp.toString(Temp_Finish_Date.getYear()) + " " + Temp.toString(Temp_Finish_Date.getHours()) + ":" + Temp.toString(Temp_Finish_Date.getMinutes()) + ":00";

		Temp_Str = request.getParameter("min_price");
		Integer Temp3 = new Integer(Temp_Str);
		double Min_Price = Temp3.doubleValue();

		Temp_Str = request.getParameter("max_price");
		Integer Temp4 = new Integer(Temp_Str);
		double Max_Price = Temp4.doubleValue();

		Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		ResultReserve Result[] = soapProxy.search_entertainment_for_reserve(Style , Type , Min_Price , Max_Price , Start_Date , Finish_Date );
%>
<table border = "1" width = "100%">
<tr><td colspan = 7 align = "center">�Ţͧ��ä���</td></tr>
<tr>
		<td align = "center" width = "">��Դǧ����� - ����ʴ�</td>
		<td align = "center" width = "">����ǧ����� - ����ʴ�</td>
		<td align = "center" width = "">��������´</td>
		<td align = "center" width = "">��Һ�ԡ�� (5:00 �. - 17:00 �.) / �ҷ</td>
		<td align = "center" width = "">��Һ�ԡ�� (17:00 �. - 2:00 �.) / �ҷ</td>
		<td align = "center">�ͧ</td>
</tr>

<%
		for (int i = 0 ; i < Result.length ; i ++ )
		{
				%>
						<form action = "./reserve.jsp" method ="post">						
						<tr>
						<td align = "center"><%=Result[i].getBandTypeName()%></td>
						<td align = "center"><%=Result[i].getBandName()%></td>
						<td align = "center"><%=Result[i].getBandDetail()%></td>
						<td align = "center"><%=Result[i].getBandPriceAm()%></td>
						<td align = "center"><%=Result[i].getBandPricePm()%></td>
						<td align = "center"><input type = "submit" value = "�ͧ" name = "reserve"></td>
						</tr>
						<input type = "hidden" name = "Type_Name" value = "<%=Result[i].getBandTypeName()%>">
						<input type = "hidden" name = "Band_Name" value = "<%=Result[i].getBandName()%>">
						<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
						<input type = "hidden" name = "Contact_Name" value = "<%=Contact_Name%>">
						<input type = "hidden" name = "Band_ID" value = "<%=Result[i].getBandID()%>">
						<input type = "hidden" name = "Type_ID" value = "<%=Result[i].getBandTypeID()%>">
						<input type = "hidden" name = "Start_Datetime" value = "<%=Start_Date%>">
						<input type = "hidden" name = "Finish_Datetime" value = "<%=Finish_Date%>">
						<input type = "hidden" name = "Price_AM" value = "<%=Result[i].getBandPriceAm()%>">
						<input type = "hidden" name = "Price_PM" value = "<%=Result[i].getBandPricePm()%>">
						</form>
				<%
		}
%>
</table>
		<center><form action = "./showcontact.jsp" method = "post">
		<input type = "submit" value = "Back To Show All Contact">
		</form></center>

</body>
</html>
