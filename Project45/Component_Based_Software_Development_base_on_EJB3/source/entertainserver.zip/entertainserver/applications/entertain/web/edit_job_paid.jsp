<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<%
	String temp1 = request.getParameter("JobId");
	Integer tempint = new Integer(temp1);
	int Job_Id = tempint.intValue();
	
	temp1 = request.getParameter("Contact_ID");
	int Contact_ID = tempint.parseInt(temp1);

	temp1 = request.getParameter("BandID");
	int BandID = tempint.parseInt(temp1);

	temp1 = request.getParameter("BandTypeID");
	int BandTypeID = tempint.parseInt(temp1);

	String BandName = request.getParameter("BandName");
	String Temp_Str1 = new String(BandName.getBytes("ISO8859_1") , "MS874");
	BandName = Temp_Str1;
	String BandDetail = request.getParameter("BandDetail");
	String Temp_Str2 = new String(BandDetail.getBytes("ISO8859_1") , "MS874");
	BandDetail = Temp_Str2;
	String StartDatetime = request.getParameter("StartDatetime");
	String FinishDatetime = request.getParameter("FinishDatetime");
	String Place = request.getParameter("Place");
	String Temp_Str3 = new String(Place.getBytes("ISO8859_1") , "MS874");
	Place = Temp_Str3;


	temp1= request.getParameter("TotalPrice");
	Double temp2 = new Double(temp1);
	double TotalPrice = temp2.doubleValue();
	
	String FunctionType = request.getParameter("FunctionType");
	String Temp_Str4 = new String(FunctionType.getBytes("ISO8859_1") , "MS874");
	FunctionType = Temp_Str4;

	String AdditionalRequests = request.getParameter("AdditionalRequests");
	String Temp_Str5 = new String(AdditionalRequests.getBytes("ISO8859_1") , "MS874");
	AdditionalRequests = Temp_Str5;
%>
<Form action = "result_edit_paid.jsp" method = "post">
  <table width="90%" height="172" border="1">
  	  <tr>
			<td align = "left">���ʡ���ʴ�</td>
			<td><%=Job_Id%></td>
	  </tr>
  	  <tr>
			<td align = "left">����ǧ����� - ����ʴ�</td>
			<td><%=BandName%></td>
	</tr>
  	  <tr>
			<td align = "left">��������´</td>
			<td><%=BandDetail%></td>
	  </tr>
  	  <tr>
			<td align = "left">�������������ʴ�</td>
			<td>	<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = StartDatetime.toCharArray();
							for(int j = 0;  j < StartDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
		</td>
	  </tr>
	  <tr>
			<td align = "left">��������ش����ʴ�></td>
			<td>	<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =FinishDatetime.toCharArray();
							for(int j = 0;  j < FinishDatetime.length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
			</td>
	  </tr>
  	  <tr>
			<td align = "left">ʶҹ���</td>
			<td><input type = "text" value ="<%=Place%>" name = "place" size = "30" maxlength = "50"></td>
	  </tr>
  	  <tr>
			<td align = "left">�Ҥ�</td>
			<td><%=TotalPrice%>&nbsp;�ҷ</td>
	  </tr>
  	  <tr>
			<td align = "left">�ѡɳТͧ�ҹ</td>
			<td><input type = "text" value ="<%=FunctionType%>" name = "functiontype" size = "30" maxlength = "50"></td>
	  </tr>
  	  <tr>
			<td align = "left">��������´�������</td>
			<td><textarea name = "additionalrequests" cols = "30"  rows = "2"maxlength = "200"><%=AdditionalRequests%></textarea></td>

	  </tr>
	</table>
		<input type = "hidden" name = "JobId" value = "<%=Job_Id%>">
		<input type = "hidden" name = "BandID" value = "<%=BandID%>">
		<input type = "hidden" name = "BandTypeID" value = "<%=BandTypeID%>">
		<input type = "hidden" name = "BandName" value = "<%=BandName%>">
		<input type = "hidden" name = "BandDetail" value = "<%=BandDetail%>">
		<input type = "hidden" name = "TotalPrice" value = "<%=TotalPrice%> ">
		<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
		<input type = "hidden" name = "StartDatetime" value = "<%=StartDatetime%>">
		<input type = "hidden" name = "FinishDatetime" value = "<%=FinishDatetime%>">
		<br>
		<center><input type = "submit" value = "edit"></center>
</Form>
</body>
</html>
