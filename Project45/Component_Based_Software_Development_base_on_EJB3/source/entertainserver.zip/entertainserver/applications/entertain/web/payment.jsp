<%@ page import="weblogic.jws.proxies.*" %>
<%@ page contentType="text/html;charset=WINDOWS-874"%>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<%	Entertainbank1_Impl proxy = new Entertainbank1_Impl(); 
		Entertainbank1Soap soapProxy = proxy.getentertainbank1Soap(); 
		Integer Temp_Integer = new Integer((String)session.getAttribute("Customer_ID"));
		int Customer_ID = Temp_Integer.intValue();
		String Temp_String = request.getParameter("Contact_ID");
		int Contact_ID = Temp_Integer.parseInt(Temp_String);
		String Contact_Name = request.getParameter("Contact_Name");
		Temp_String = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
		Contact_Name = Temp_String;


		double price = soapProxy.check_total_price(Customer_ID,Contact_ID);
%>
<form action = "resultpay.jsp" method = post>
	<table align = "center">
		<tr>
				<td>����Contact</td>
				<td><%=Contact_Name%></td>
		</tr>
		<tr>
				<td>�����Ţ�ѵ��ôԵ</td>
				<td><input type = "text" name = "credit_no" size = "20" maxlength = "20"></td>
		</tr>
		<tr>
				<td>�ѹ�������</td>
				<td>
				<input type = "text" name = "expiremonth" size = "2" maxlength = "2">&nbsp;
				<input type = "text" name = "expireyear" size = "4" maxlength = "4"></td>
		</tr>
		<tr>
				<td>code</td>
				<td><input type = "text" name = "pwd" size = "4" maxlength = "4"></td>
		</tr>
		<tr>
				<td>�Ҥ�</td>
				<td><%=price%>&nbsp;�ҷ</td>
		</tr>

	</table>
	<center><input type = "hidden" name = "Contact_ID" value = "<%=request.getParameter("Contact_ID")%>">
	<input type = "hidden" name = "price" value = "<%=price%>">
	<input type = "submit" value = "Pay"></center>
</form>
		<center><form action = "./show_job_id.jsp" method = "post">
		<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
		<input type = "hidden" name = "Contact_Name" value = "<%=Contact_Name%>">
		<input type = "submit" value = "Back">
		</form></center>

</body>
</html>
