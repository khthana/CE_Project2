<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultSearch" %>
<%@ page contentType="text/html;charset=WINDOWS-874"%>


<%	 Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 

		String FirstName = request.getParameter("firstnamefield");
		String LastName  = request.getParameter("lastnamefield");
		String Address = request.getParameter("addressfield");
		String Sex = request.getParameter("sexgroup");
		String Temp_Age = request.getParameter("agefield");
		Integer Temp = new Integer(Temp_Age);
		int Age = Temp.intValue();
		String Tel = request.getParameter("telfield");
		String Email = request.getParameter("emailfield");
		String Username = request.getParameter("usernamefield");
		String Password = request.getParameter("pwdfield");
		String Re_Password = request.getParameter("re_pwdfield");

		String result = new String();
		result = soapProxy.register(FirstName , LastName , Sex , Age , Tel , Address , Email , Username , Password);
		response.sendRedirect("./login.jsp");
%>
