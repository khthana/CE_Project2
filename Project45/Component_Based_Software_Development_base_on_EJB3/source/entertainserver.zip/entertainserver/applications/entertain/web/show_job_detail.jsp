<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultSearchReserve"%>
<%@ page contentType="text/html; charset=WINDOWS-874" language="java" %>
<html>
<head>
<title>Untitled Document</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">

</head>

<body>
<%	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		Integer Temp_Integer = new Integer((String)session.getAttribute("Customer_ID"));
		int Customer_ID = Temp_Integer.intValue();
		String Temp_String = request.getParameter("Contact_ID");
		int Contact_ID = Temp_Integer.parseInt(Temp_String);
		Temp_String = request.getParameter("Job_ID");
		int Job_ID = Temp_Integer.parseInt(Temp_String);
		ResultSearchReserve ResultSearch = soapProxy.search_by_job_id(Customer_ID , Contact_ID , Job_ID);
		%>
		<table align = "center" width = "80%">
		<tr><td align = "center">���ʡ���ʴ�</td>
				<td align = "center"><%=ResultSearch.getJobId()%></td>
		</tr>
		<tr><td align = "center">����ǧ����� - ����ʴ�</td>
				<td align = "center"><%=ResultSearch.getBandName()%></td>
		</tr>
		<tr><td align = "center">��������´</td>
				<td align = "center"><%=ResultSearch.getBandDetail()%></td>
		</tr>
		<tr><td align = "center">�������������ʴ�</td>
				<td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							String hour1 = new String();
							int minute1 = 0;
							String minute = new String();
							char[] temp_date = ResultSearch.getStartDatetime().toCharArray();
							for(int j = 0;  j < ResultSearch.getStartDatetime().length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
				</td>
		</tr>
		<tr><td align = "center">��������ش����ʴ�</td>
				<td align = "center">
					<%
							temp = "";
							day1 = 0;
							month1 = 0;
							year1 = 0;
							count = 0;
							hour1 = "";
							minute1 = 0;
							minute = "";
							temp_date =ResultSearch.getFinishDatetime().toCharArray();
							for(int j = 0;  j < ResultSearch.getFinishDatetime().length(); j++)
							{	
									if(temp_date[j] == ' ' || temp_date[j] == ':')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
											if(count == 3)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
													temp = "";
											}
											if(count == 4)
											{
													hour1 = temp;
													temp = "";
											}
											if(count == 5)
											{
												Integer temp_minute = new Integer(temp);
												minute1 = temp_minute.intValue();
												if(minute1 < 10)
												{
														minute = "0" + temp_minute.toString(minute1);
												}
												else
												{
														minute = temp_minute.toString(minute1);
												}
												temp = "";
											}

									}
									else
									{
											temp = temp + temp_date[j];
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>&nbsp;&nbsp;<%=hour1%>:<%=minute%>&nbsp;�.
				</td>
		</tr>
		<tr><td align = "center">ʶҹ���</td>
				<td align = "center"><%=ResultSearch.getPlace()%></td>
		</tr>
		<tr><td align = "center">�Ҥ�</td>
				<td align = "center"><%=ResultSearch.getTotalPrice()%> �ҷ</td>
		</tr>
		<tr><td align = "center">�ѡɳТͧ�ҹ</td>
				<td align = "center"><%=ResultSearch.getFunctionType()%>&nbsp;</td>
		</tr>
        <tr><td align = "center">��������´�������</td>
				<td align = "center"><%=ResultSearch.getAdditionalRequests()%>&nbsp;</td>
		</tr>
		</table>
		<br>
		<br>
		<table align = "center" border = 0>
		<tr><td>
		<Form action = "edit_job.jsp" method = post>
		<input type = "hidden" name = "JobId" value = "<%=ResultSearch.getJobId()%>">
		<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
		<input type = "hidden" name = "BandTypeID" value = "<%=ResultSearch.getBandTypeID()%>">
		<input type = "hidden" name = "BandID" value = "<%=ResultSearch.getBandID()%>">
		<input type = "hidden" name = "BandName" value = "<%=ResultSearch.getBandName()%>">
		<input type = "hidden" name = "BandDetail" value = "<%=ResultSearch.getBandDetail()%>">
		<input type = "hidden" name = "StartDatetime" value = "<%=ResultSearch.getStartDatetime()%>">
		<input type = "hidden" name = "FinishDatetime" value = "<%=ResultSearch.getFinishDatetime()%>">
		<input type = "hidden" name = "Place" value = "<%=ResultSearch.getPlace()%>">
		<input type = "hidden" name = "TotalPrice" value = "<%=ResultSearch.getTotalPrice()%> ">
		<input type = "hidden" name = "FunctionType" value = "<%=ResultSearch.getFunctionType()%>">
		<input type = "hidden" name = "AdditionalRequests" value = "<%=ResultSearch.getAdditionalRequests()%>">
		<input type = "submit" value = "edit">
		</Form>
		</td>
		<td width = 100></td>
		<td>
		<form action = "./canceljob.jsp" method = "post">
		<input type = "hidden" name = "Contact_ID" value = "<%=Contact_ID%>">
		<input type = "hidden" name = "JobId" value = "<%=ResultSearch.getJobId()%>">
		<input type = "submit" value = "Cancel">
		</form>
		</td>
		</table>

</body>
</html>
