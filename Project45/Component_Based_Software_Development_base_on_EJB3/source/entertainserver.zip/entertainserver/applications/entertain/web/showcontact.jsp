<%@ page import="weblogic.jws.proxies.*" %>
<%@ page import="org.openuri.www.ResultContactID"%>
<%@ page contentType="text/html; charset=WINDOWS-874" language="java" %>
<html>
<head>
<title>Olala Entertainment</title>
<LINK rel = "stylesheet"
			 href = "font.css"
			 type= "text/css">
</head>

<body bgcolor="#FFFFFF" >
<%	Entertainment1_Impl proxy = new Entertainment1_Impl(); 
		Entertainment1Soap soapProxy = proxy.getEntertainment1Soap(); 
		Integer Temp = new Integer( (String)session.getAttribute("Customer_ID") );
		int Customer_ID = Temp.intValue();
		ResultContactID ResultContact[] = soapProxy.search_by_customer_id( Customer_ID );
		%>
<table border = "1" width = "100%">
		<tr><td  width = "40%" valign = "top">
		<table border = 1 width = "100%">
		<tr><td align = "center" colspan = 2>��¡�÷���ѧ�������Ф�Һ�ԡ��</td></tr>
		<tr><td align = "center">Contact Name</td><td align = "center">Deadline Confirm</td></tr>
		<%
		Date today = new Date();  
		for (int i = 0 ; i < ResultContact.length ; i ++) {
			String deadline = ResultContact[i].getDeadlineConfirm();
			StringTokenizer tmpDate =new StringTokenizer(deadline," ");
            String dates =tmpDate.nextToken();
            String StringDateNow=tmpDate.nextToken()+"/"+dates+"/"+tmpDate.nextToken();
            java.util.Date deadline_pay = new java.util.Date(StringDateNow); 
			if (ResultContact[i].getPayDate().equals("01 01 2003")&&(deadline_pay.compareTo(today)>=0)) {
			%>
			<tr>
					<td align = "center"><a href = "show_job_id.jsp?Contact_ID=<%=ResultContact[i].getBandContactID()%>&Contact_Name=<%=ResultContact[i].getBandContactName()%>"><%=ResultContact[i].getBandContactName() %></a></td>
					<td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = ResultContact[i].getDeadlineConfirm().toCharArray();
							for(int j = 0;  j < ResultContact[i].getDeadlineConfirm().length(); j++)
							{	
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%></td>
			</tr>
			<%
			}
		}
%>	
		</table>
		</td>
		<td width = "20%" bgcolor = "FFFFCC">&nbsp;</td>
		<td valign = "top">
				<table border = 1 width = "100%">
		<tr><td align = "center" colspan = 2>��¡�÷����Ф�Һ�ԡ������</td></tr>
		<tr><td align = "center">Contact Name</td><td align = "center">Deadline Confirm</td></tr>
		<%
		for (int i = 0 ; i < ResultContact.length ; i ++) {
			if (!(ResultContact[i].getPayDate().equals("01 01 2003"))) {
			%>
			<tr>
					<td align = "center"><a href = "show_job_id_paid.jsp?Contact_ID=<%=ResultContact[i].getBandContactID()%>&Contact_Name=<%=ResultContact[i].getBandContactName()%>"><%=ResultContact[i].getBandContactName() %></a></td>
					<td align = "center">
					<%
							String temp = new String();
							int  day1 = 0;
							int month1 = 0;
							int year1 = 0;
							int count = 0;
							char[] temp_date = ResultContact[i].getDeadlineConfirm().toCharArray();
							for(int j = 0;  j < ResultContact[i].getDeadlineConfirm().length(); j++)
							{	
									if(temp_date[j] == ' ')
									{
											count++;
											if(count == 1)
											{
													Integer temp_day = new Integer(temp);
													day1 = temp_day.intValue();
													temp = "";
											}
											if(count == 2)
											{
													Integer temp_month = new Integer(temp);
													month1 = temp_month.intValue();
													temp = "";
											}
									}
									else
									{
											temp = temp + temp_date[j];
											if(count == 2)
											{
													Integer temp_year = new Integer(temp);
													year1 = temp_year.intValue();
											}
									}
							}
							year1 = year1 +543;
					%>
					<%=day1%>&nbsp;<%if (month1 == 1) out.print("�.�.");
														if (month1 == 2) out.print("�.�.");
														if (month1 == 3) out.print("��.�.");
														if (month1 == 4) out.print("��.�.");
														if (month1 == 5) out.print("�.�.");
														if (month1 == 6) out.print("��.�.");
														if (month1 == 7) out.print("�.�.");
														if (month1 == 8) out.print("�.�.");
														if (month1 == 9) out.print("�.�.");
														if (month1 == 10) out.print("�.�.");
														if (month1 == 11) out.print("�.�.");
														if (month1 == 12) out.print("�.�.");
											%>&nbsp;<%=year1%>					
					</td>
			</tr>
			<%
			}
		}
		%>	
		</table>
		</td>
		</tr>
		</table>
		<br>
		<form action = "create_contact_id.jsp" method = post name = "create" >
		���ҧ Contact ���� ��س��кت��� : <input type = "text" name = "Contact_Name" size = 30 maxlength = 50>
		<input type = "submit" value = "Search for Reserve" name = "search" >
		</form>
</body>

</html>
