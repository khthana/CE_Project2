<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ContactID" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	OlalaTour_Impl proxy = new OlalaTour_Impl(); 
    OlalaTourSoap soapProxy = proxy.getOlalaTourSoap(); 

	String Temp = request.getParameter("Wedding_Contact");
	Integer Dou1 = new Integer(Temp);
	int Wedding_Contact = Dou1.intValue();
	ContactID Contact = soapProxy.tour_GetContactID(Wedding_Contact);
	if (soapProxy.tour_ConfirmBooking(Contact.getTourID() , Contact.getContactID()) ) {
			out.print("1");
	}
	else {
			out.print("0");
	}

%>