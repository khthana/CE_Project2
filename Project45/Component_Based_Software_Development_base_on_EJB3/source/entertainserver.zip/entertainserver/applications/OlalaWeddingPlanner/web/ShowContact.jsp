<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.WeddingContactDetail" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 
	String Temp = request.getParameter("Customer_ID");
	String Output = new String();
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	WeddingContactDetail Result[] = soapProxy.find_Wedding_Contact(Customer_ID);
	if (Result.length == 0) {
		Output = "0";
	}
	else {
	for (int i = 0 ; i < Result.length ; i ++) {
		Output = Output + Result[i].getWeddingContactID() + "!" + Result[i].getWeddingContactName() + "!" + Result[i].getAllprice() + "!" + Result[i].getDeadline() + "!";
	}
	}
	out.print(Output);
%>