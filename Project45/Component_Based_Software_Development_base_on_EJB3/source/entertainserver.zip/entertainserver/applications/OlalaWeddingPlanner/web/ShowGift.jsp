<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Job" %><%@ page import="org.openuri.www.JobDetail" %><%@ page contentType="text/html;charset=WINDOWS-874"%><%
	WeddingplannerGift_Impl proxy = new WeddingplannerGift_Impl(); 
    WeddingplannerGiftSoap soapProxy = proxy.getWeddingplannerGiftSoap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	int JobID = soapProxy.giftListContact(Customer_ID , Wedding_Contact_ID);
	Job JobList[] = soapProxy.giftListJob(Customer_ID , Wedding_Contact_ID , JobID);
	String Output = new String();
	out.print(JobList.length);
	for ( int i = 0 ; i < JobList.length ; i ++ )
	{
		JobDetail Detail = soapProxy.giftShowDetailJob(Wedding_Contact_ID , JobID , JobList[i].getJobId());
		Output = Output + Detail.getContactId() + "!" + Detail.getSubtypeName() + "!" + Detail.getSubtypeDetail() + "!" + Detail.getLabel() + "!" + Detail.getReceiveDate() + "!" + Detail.getQuantity() + "!" + Detail.getJobTotalPrice() + "!";
	}
	out.print(Output);
%>