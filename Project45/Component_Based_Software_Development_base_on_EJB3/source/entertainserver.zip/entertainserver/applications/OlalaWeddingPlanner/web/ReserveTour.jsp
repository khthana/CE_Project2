<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ReturnReserve" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% OlalaTour_Impl proxy = new OlalaTour_Impl(); 
    OlalaTourSoap soapProxy = proxy.getOlalaTourSoap(); 

	String Temp = request.getParameter("Customer_ID");
	Integer Int1 = new Integer(Temp);
	int Customer_ID = Int1.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Int2 = new Integer(Temp);
	int Wedding_Contact = Int2.intValue();
	Temp = request.getParameter("Quantity");
	Integer Int4 = new Integer(Temp);
	int Quantity = Int4.intValue();
	Temp = request.getParameter("Detail");
	int  TourID = 0;
	int PackageID = 0;
	int count = 0;
	for (int i = 0 ; i < Temp.length() ; i ++ ) {
			if (Temp.substring( i , i + 1).equals("!")) {
					count ++ ; 
					if (count == 1) {
							Integer Int3 = new Integer(Temp.substring( 0 , i));
							PackageID = Int3.intValue();
							Temp = Temp.substring( i + 1 , Temp.length());
							i = 0;
					}
					if (count == 2) {
							String Temp2 = Temp.substring( 0 , i);
							Integer Int3 = new Integer(Temp.substring(Temp.length() - 2 , Temp.length() - 1));
							TourID = Int3.intValue();
							Temp = Temp.substring( i + 1 , Temp.length());
							i = 0;
					}
			}
	}
	int Contact = soapProxy.tour_CreateContact(Wedding_Contact , Customer_ID , TourID);
	soapProxy.tour_Reserve(Customer_ID , Wedding_Contact , Contact , TourID , PackageID , Quantity);
%>