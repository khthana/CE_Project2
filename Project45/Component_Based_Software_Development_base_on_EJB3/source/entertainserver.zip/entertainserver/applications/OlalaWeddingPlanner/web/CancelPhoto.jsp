<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% OlalaPhoto_Impl proxy = new OlalaPhoto_Impl(); 
    OlalaPhotoSoap soapProxy = proxy.getOlalaPhotoSoap(); 
	String Detail = request.getParameter("Detail");
	int Contact_ID = 0;
	int count = 0 ;
	String Temp = request.getParameter("Wedding_Contact");
	Integer Int2 = new Integer(Temp);
	int Wedding_Contact = Int2.intValue();
	for (int i = 0 ; i < Detail.length() ; i ++ ) {
			if (Detail.substring( i , i + 1).equals("!")) {
					count ++;
					if (count == 1) {
							Temp = Detail.substring( 0 , i);
							Integer Int1 = new Integer(Temp);
							Contact_ID = Int1.intValue();
							Detail = Detail.substring( i + 1 , Detail.length());
							i = 0;
					}
			}
	}
	out.print(soapProxy.photo_CancelContact(Contact_ID , Wedding_Contact));
%>