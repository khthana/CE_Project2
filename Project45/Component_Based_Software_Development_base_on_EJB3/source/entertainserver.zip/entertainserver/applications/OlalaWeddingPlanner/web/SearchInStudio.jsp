<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ServiceDetail" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	
	OlalaPhoto_Impl proxy = new OlalaPhoto_Impl(); 
    OlalaPhotoSoap soapProxy = proxy.getOlalaPhotoSoap(); 

	String Temp = request.getParameter("MinPrice");
	Integer Dou1 = new Integer(Temp);
	int MinPrice = Dou1.intValue();
	Temp = request.getParameter("MaxPrice");
	Integer Dou2 = new Integer(Temp);
	int MaxPrice = Dou2.intValue();
	Temp = request.getParameter("StartMonth");
	Integer Int1 = new Integer(Temp);
	int Temp_StartMonth = Int1.intValue();
	String StartMonth = new String();
	if (Temp_StartMonth < 10) {
		StartMonth = "0" + Temp_StartMonth;
	}
	else { 
		StartMonth = Int1.toString(Temp_StartMonth);
	}
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int Temp_StartDay = Int2.intValue();
	String StartDay = new String();
	if (Temp_StartDay < 10) {
		StartDay = "0" + Temp_StartDay;
	}
	else {
		StartDay = Int2.toString(Temp_StartDay);
	}
	String ReserveDate = StartDay + " " + StartMonth + " " + request.getParameter("StartYear");
	String InStudioType = request.getParameter("InStudioType");
	Integer Int4 = new Integer(InStudioType);
	int IntInStudioType = Int4.intValue();
	Temp = request.getParameter("Round");
	Integer Int5 = new Integer(Temp);
	int Round = Int5.intValue();
	String Output = new String();
	String Cheap = request.getParameter("Cheap");
	boolean Check_Cheap = true;
	if (Cheap.equals("0")) {
			Check_Cheap = true;
	}
	else {
			Check_Cheap = false;
	}
//	out.print( IntInStudioType + InStudioType + ReserveDate + Round + MinPrice + MaxPrice);
	if (soapProxy.photo_IsTimeAvailable_InStudio(1, IntInStudioType , ReserveDate, Round)) {
		ServiceDetail Result[] = soapProxy.photo_SearchService(0, InStudioType, MinPrice, MaxPrice, Check_Cheap , 0 , 0);
		if (Result.length > 0) {
			for (int i = 0 ; i < Result.length ; i ++ ) {
				Output = Output + Result[i].getSubTypeID() + "!" + Result[i].getSubTypeName() + "!" +  Result[i].getPrice() + "!" + Result[i].getPhotoID() + "!";				
			}
		}
		else {
			out.print("0");
		}
		out.print(Output);
	}
	else {
		out.print("0");
	}
%>