<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.SearchSeminarRoomResult" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner2_Impl proxy = new Weddingplanner2_Impl(); 
    Weddingplanner2Soap soapProxy = proxy.getweddingplanner2Soap(); 
	short t1 = 1;
	short t2 = 0;
	soapProxy.hotelSearchFood(0 , 10000 , "" , "" , "" , true , 1 , 0);
%>