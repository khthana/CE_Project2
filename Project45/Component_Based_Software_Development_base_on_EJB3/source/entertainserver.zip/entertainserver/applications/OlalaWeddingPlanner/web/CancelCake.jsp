<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Temp = request.getParameter("Cake_Job");
	Integer Temp_Integer3 = new Integer(Temp);
	int Cake_Job = Temp_Integer3.intValue();
	Hotelcontact Contact_ID = 	soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact_ID); 
	soapProxy.hotelCancelCake(Customer_ID , Contact_ID.getHotelcontact() , Cake_Job , Wedding_Contact_ID);
%>