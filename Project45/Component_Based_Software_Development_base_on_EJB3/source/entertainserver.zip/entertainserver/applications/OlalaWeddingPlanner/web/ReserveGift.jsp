<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ReturnReserve" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% WeddingplannerGift_Impl proxy = new WeddingplannerGift_Impl(); 
    WeddingplannerGiftSoap soapProxy = proxy.getWeddingplannerGiftSoap(); 

	String Temp = request.getParameter("Customer_ID");
	Integer Int1 = new Integer(Temp);
	int Customer_ID = Int1.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Int2 = new Integer(Temp);
	int Wedding_Contact = Int2.intValue();
	String Type = request.getParameter("Type");
	String SubType = request.getParameter("SubType");
	String Label = request.getParameter("Label");

	Temp = request.getParameter("ReceiveDay");
	Integer Int5 = new Integer(Temp);
	int TempReceiveDay = Int5.intValue();
	String ReceiveDay = new String();
	if (TempReceiveDay < 10) {
		ReceiveDay = "0" + TempReceiveDay;
	}
	else {
		ReceiveDay = Int5.toString(TempReceiveDay);
	}

	Temp = request.getParameter("ReceiveMonth");
	Integer Int6 = new Integer(Temp);
	int TempReceiveMonth = Int6.intValue();
	String ReceiveMonth = new String();
	if (TempReceiveMonth < 10) {
		ReceiveMonth = "0" + TempReceiveMonth;
	}
	else {
		ReceiveMonth = Int5.toString(TempReceiveMonth);
	}

	Temp = request.getParameter("ReceiveYear");
	Integer Int9 = new Integer(Temp);
	int TempReceiveYear = Int9.intValue();
	String ReceiveYear = Int9.toString(TempReceiveYear + 2003);
	String Address = request.getParameter("Address");
	Temp = request.getParameter("Quantity");
	Integer Int11 = new Integer(Temp);
	int Quantity = Int11.intValue();
	Temp = request.getParameter("GiftNumber");
	Integer Int12 = new Integer(Temp);
	int GiftNumber = Int12.intValue();
	String ReceiveDate = ReceiveDay + " " + ReceiveMonth + " " + ReceiveYear + " 12:00:00";

	int GiftContact = soapProxy.giftCreateContact(Customer_ID , "WeddingPlanner" , GiftNumber, Wedding_Contact);
	ReturnReserve Result = soapProxy.giftOrder(Customer_ID , Type, SubType , "AngsanaUPC" , "Black" , Label , ReceiveDate , Address , Quantity , GiftNumber , Wedding_Contact,GiftContact);
	out.print(Result.getPrice() +"!" +Result.getDeadline()+"!");
%>