<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page import="org.openuri.www.SeminarRoomReservationList" %><%@ page import="org.openuri.www.ShowAllJobid" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Hotelcontact Hotel_Contact = soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact_ID);
	ShowAllJobid JobID = soapProxy.hotelShowJobID(Customer_ID , Hotel_Contact.getHotelcontact() , Hotel_Contact.getHotelId());
	int Seminar[] = JobID.getSeminarRoomJobId();
	String Output = new String();
	String Time = new String();
	for (int i = 0 ; i < Seminar.length ; i ++ ) {
			SeminarRoomReservationList Detail = soapProxy.hotelShowReserveSeminar(Seminar[i] , Hotel_Contact.getHotelId());
			if (Detail.getTime6To11Am() == 1) {
					Time = "6.00 - 11.00";
			}
			else if (Detail.getTime12To5Pm() == 1) {
					Time = "12.00 - 17.00";
			}
			else if (Detail.getTime6To11Pm() == 1) {
					Time = "18.00 - 23.00";
			}
			Output = Output + Detail.getSeminarRoomName() + "!" + Detail.getPlaceStyle() + "!" + Detail.getDecStyle() + "!" + Detail.getTableLayout() + "!" + Detail.getMenPerRoom() + "!" + Detail.getReserveDate() + "!" + Time + "!" + Detail.getJobTotalPrice() + "!";
	}
	out.print(Output);






%>