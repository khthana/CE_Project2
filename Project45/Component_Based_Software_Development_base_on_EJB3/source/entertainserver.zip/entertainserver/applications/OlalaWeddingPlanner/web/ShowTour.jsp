<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.TourJobDetailLow" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	OlalaTour_Impl proxy = new OlalaTour_Impl(); 
    OlalaTourSoap soapProxy = proxy.getOlalaTourSoap(); 

	String Temp = request.getParameter("Customer_ID");
	Integer Dou1 = new Integer(Temp);
	int Customer_ID = Dou1.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Dou2 = new Integer(Temp);
	int Wedding_Contact = Dou2.intValue();
	int Contact = soapProxy.tour_HasContact(Wedding_Contact);
	TourJobDetailLow Result[] = soapProxy.tour_GetJobByContact(Contact , Wedding_Contact);
	out.print(Result[0].getJobID() + "!" + Result[0].getPackageName() + "!" + Result[0].getStartDate() + "!");

%>