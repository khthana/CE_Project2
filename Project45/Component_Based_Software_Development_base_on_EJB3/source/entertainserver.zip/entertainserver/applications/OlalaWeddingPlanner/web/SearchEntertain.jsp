<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.EntertainResultsearch" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 

	String Style = request.getParameter("Style");
	if (Style.equals("Thai")) {
		Style = "��";
	}
	else if (Style.equals("Classic")) {
		Style = "�ҡ�";
	}
	else if (Style.equals("Chinese")) {
		Style = "�չ";
	}
	String  Temp = request.getParameter("Type");
	Integer Int1 = new Integer(Temp);
	int Type = Int1.intValue();
	if (Type > 1) {
		Type ++;
	}
	Temp = request.getParameter("MinPrice");
	Integer Dou1 = new Integer(Temp);
	double MinPrice = Dou1.doubleValue();
	Temp = request.getParameter("MaxPrice");
	Integer Dou2 = new Integer(Temp);
	double MaxPrice = Dou2.doubleValue();
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int StartDay = Int2.intValue();
	Temp = request.getParameter("StartMonth");
	Integer Int3 = new Integer(Temp);
	int StartMonth = Int3.intValue();
	Temp = request.getParameter("StartYear");
	Integer Int4 = new Integer(Temp);
	int StartYear = Int4.intValue();
	Temp = request.getParameter("StartHour");
	Integer Int5 = new Integer(Temp);
	int StartHour = Int5.intValue();
	Temp = request.getParameter("StartMinute");
	Integer Int6 = new Integer(Temp);
	int StartMinute = Int6.intValue();
	Date StartDate = new Date (StartYear  , StartMonth - 1 , StartDay , StartHour , StartMinute);
	String  Duration= request.getParameter("Duration");
	long Time = 0;
	if (Duration.equals("3")) {
		Time = 10800000;		
	}
	else 	if (Duration.equals("4")) {
		Time = 14400000 ;
	}
	else 	if (Duration.equals("5")) {
		Time = 18000000 ;
	}
	else 	if (Duration.equals("6")) {
		Time = 21600000 ;
	}
	Date FinishDate = new Date(StartDate.getTime() + Time);
	
	boolean Cheap = true;
	String Near = "";
	int EntertainNumber = 0;
	String Output = new String();
	EntertainResultsearch Result[] = soapProxy.entertainment_Search(Style , Type , MinPrice , MaxPrice , Int1.toString(StartDay) + " " + Int1.toString(StartMonth) + " " + Int1.toString(StartYear) + " " + Int1.toString(StartHour) + ":" + Int1.toString(StartMinute) + ":00" , FinishDate.getDate() + " " + (FinishDate.getMonth() + 1) + " " + FinishDate.getYear() + " " + FinishDate.getHours() + ":" + FinishDate.getMinutes() + ":00" , Cheap , Near , EntertainNumber);

	if (Result.length == 0) {
		Output = "0";
	}
	else {
	for (int i = 0 ; i < Result.length ; i ++) {
		Output = Output + Result[i].getBandId() + "!" + Result[i].getBandTypeName() + "!" + Result[i].getBandTypeId() + "!" + Result[i].getBandName() + "!" + Result[i].getBandPriceAm() + "!" + Result[i].getBandPricePm() + "!" + Result[i].getEntertainmentName() + "!" + Result[i].getEntertainId() + "!" + Int1.toString(StartDay) + " " + Int1.toString(StartMonth) + " " + Int1.toString(StartYear) + " " + Int1.toString(StartHour) + ":" + Int1.toString(StartMinute) + ":00!" + FinishDate.getDate() + " " + (FinishDate.getMonth() + 1) + " " + FinishDate.getYear() + " " + FinishDate.getHours() + ":" + FinishDate.getMinutes() + ":00!"  ;
	}
	}
	out.print(Output);
%>