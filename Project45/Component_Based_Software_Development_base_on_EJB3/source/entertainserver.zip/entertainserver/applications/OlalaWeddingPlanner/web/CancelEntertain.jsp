<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Temp = request.getParameter("Contact_ID");
	Integer Temp_Integer3 = new Integer(Temp);
	int Contact_ID = Temp_Integer3.intValue();
	soapProxy.entertainment_Cancel_Contact(Customer_ID , Contact_ID , Wedding_Contact_ID);
%>