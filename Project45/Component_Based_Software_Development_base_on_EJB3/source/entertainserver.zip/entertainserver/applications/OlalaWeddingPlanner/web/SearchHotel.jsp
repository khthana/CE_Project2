<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.SearchSeminarRoomResult" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Hotelservice_Impl proxy = new Hotelservice_Impl(); 
    HotelserviceSoap soapProxy = proxy.getHotelserviceSoap(); 
	String PlaceStyle = request.getParameter("PlaceStyle");
	if (PlaceStyle.equals("0")) {
			PlaceStyle = "room";
	}
	else	if (PlaceStyle.equals("1")) {
			PlaceStyle = "garden";
	}
	else	if (PlaceStyle.equals("2")) {
			PlaceStyle = "poolside";
	}

	String Capacity = request.getParameter("Capacity");
	int MinCapacity = 0;
	int MaxCapacity = 0;
	if (Capacity.equals("0")) {
			MinCapacity = 40;
			MaxCapacity = 120;
	}
	else	if (Capacity.equals("1")) {
			MinCapacity = 121;
			MaxCapacity = 200;	
	}
	else	if (Capacity.equals("2")) {
//			MinCapacity = 201;
//			MaxCapacity = 280;
			MinCapacity = 0;
			MaxCapacity = 1000;
	}
	else	if (Capacity.equals("3")) {
			MinCapacity = 281;
			MaxCapacity = 350;
	}

	String Temp = request.getParameter("StartMonth");
	Integer Int1 = new Integer(Temp);
	int Temp_StartMonth = Int1.intValue();
	String StartMonth = new String();
	if (Temp_StartMonth < 10) {
		StartMonth = "0" + Temp_StartMonth;
	}
	else { 
		StartMonth = Int1.toString(Temp_StartMonth);
	}
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int Temp_StartDay = Int2.intValue();
	String StartDay = new String();
	if (Temp_StartDay < 10) {
		StartDay = "0" + Temp_StartDay;
	}
	else {
		StartDay = Int2.toString(Temp_StartDay);
	}
	String ReserveDate = StartDay + " " + StartMonth + " " + request.getParameter("StartYear");


	Temp = request.getParameter("MinPrice");
	double MinPrice = Double.parseDouble(Temp);
	Temp = request.getParameter("MaxPrice");
	double MaxPrice = Double.parseDouble(Temp);
	short time1 = 0;
	short time2 = 0;
	short time3 = 0;
	String Time = request.getParameter("Time");
	if (Time.equals("0")) {
			time1 = 1;
	}
	else if (Time.equals("1")) {
			time2 = 1;
	}
	else if (Time.equals("2")) {
			time3 = 1;
	}
//	out.print(PlaceStyle + " " +MinCapacity +" " + MaxCapacity +" " + MinPrice +" " + MaxPrice +" " + ReserveDate +" " + time1 +" " + time2 +" " + time3);
//	soapProxy.searchseminar(" " , " " , 5 , 400 , 0 , 100000 , "01 06 2003" , time1 , time2 ,  time3 , false , 2 , 0 , 0 );
	SearchSeminarRoomResult Result[] = soapProxy.searchseminar(PlaceStyle , " " , MinCapacity , MaxCapacity , MinPrice , MaxPrice , ReserveDate , time1 , time2 , time3 , false , 1 , 0 , 0);
	String Output = new String();
	int RoomID = 0;
	int HotelID = 0;
	
	for (int i = 0 ; i < Result.length ; i ++ ) {
			Output = Output + Result[i].getSeminarRoomId() + "!" + Result[i].getSeminarRoomName() + "!" + Result[i].getPlaceStyle() + "!" + Result[i].getSeminarRoomPrice() + "!" + Result[i].getMaxMenPerRoomTable() + "!" + Result[i].getMaxMenPerRoomBuffet() + "!" + Result[i].getHotelName() + "!" + Result[i].getHotelID() + "!";
	}

	out.print(Output);
//  SearchCakeResult[] hotelSearchCake(" ", 0 , 100000 , 6 , " " , 5 , false , 1 , 0 , 0);
//  SearchRoomResult[] hotelSearchRoom(int amountRoom, java.lang.String roomType, java.lang.String scheckinDate, java.lang.String scheckoutDate, int smoke, double minprice, double maxprice, boolean cheap, int hotelNumber, int region, int district)
//  SearchFoodResult[] hotelSearchFood(double minprice, double maxprice, java.lang.String foodStyle, java.lang.String serveType, java.lang.String foodName, boolean cheap, int hotelNumber, int foodPer)


%>