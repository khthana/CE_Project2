<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.EntertainResultReserve" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 

	String Temp = request.getParameter("Customer_ID");
	Integer Int11 = new Integer(Temp);
	int Customer_ID = Int11.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Int12 = new Integer(Temp);
	int Wedding_Contact = Int12.intValue();
	Temp = request.getParameter("Band_ID");
	Integer Int13 = new Integer(Temp);
	int Band_ID = Int13.intValue();
	Temp = request.getParameter("Band_Type_ID");
	Integer Int14 = new Integer(Temp);
	int Band_Type_ID = Int14.intValue();
	String Start_Date = request.getParameter("Start_Date");
	String Finish_Date = request.getParameter("Finish_Date");
	String Place = request.getParameter("Place");
	Temp = request.getParameter("Price_AM");
	Double Temp11 = new Double(Temp);
	double Price_AM = Temp11.doubleValue();
	Temp = request.getParameter("Price_PM");
	Double Temp12 = new Double(Temp);
	double Price_PM = Temp12.doubleValue();
	String Additional = request.getParameter("Additional");
	Temp = request.getParameter("Entertain");
	Integer Int15 = new Integer(Temp);
	int Entertain = Int15.intValue();
	
	String Output = new String();
	int Entertain_Contact = soapProxy.entertainment_CreateContact(Wedding_Contact, Entertain, Customer_ID);
	if (Entertain_Contact == 0) {
		out.print("0");
	}
	else {
	EntertainResultReserve Result = soapProxy.entertainment_Reserve(Customer_ID , Wedding_Contact , Entertain_Contact , Band_ID , Band_Type_ID , Start_Date , Finish_Date , Place , "Wedding" , Price_AM , Price_PM , Additional , Entertain , "Entertainment");

		if (Result == null) {
			Output = "0";
		}
		else {
			Output = Result.getDeadlineConfirm() + "!" + Result.getTotalPrice() + "!";
		}
		out.print(Output );
	}
%>