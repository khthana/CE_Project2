<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page import="org.openuri.www.FoodReservationList" %><%@ page import="org.openuri.www.ShowAllJobid" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Hotelcontact Hotel_Contact = soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact_ID);
	ShowAllJobid JobID = soapProxy.hotelShowJobID(Customer_ID , Hotel_Contact.getHotelcontact() , Hotel_Contact.getHotelId());
	int Food[] = JobID.getFoodJobId();
	String Output = new String();
	for (int i = 0 ; i < Food.length ; i ++) {
			FoodReservationList Detail = soapProxy.hotelShowReserveFood(Food[i] , Hotel_Contact.getHotelId());
			Output = Output + Detail.getFoodJobId() + "!" + Detail.getFoodPackageId() + "!" + Detail.getServeStyle() + "!" + Detail.getFoodStyle() + "!" + Detail.getFoodServeTime() + "!" + Detail.getServeAmount() + "!" + Detail.getJobTotalPrice() + "!" ;
			
	}
	out.print(Output);





%>