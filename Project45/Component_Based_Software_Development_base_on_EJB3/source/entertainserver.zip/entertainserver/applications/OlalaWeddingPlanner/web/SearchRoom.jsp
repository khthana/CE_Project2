<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.SearchRoomResult" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 

	String Room = request.getParameter("Room");
	if (Room.equals("0")) {
			Room = "single";
	}
	else 	if (Room.equals("1")) {
			Room = "twin";	
	}
	else 	if (Room.equals("2")) {
			Room = "suite";	
	}


	String Temp = request.getParameter("StartMonth");
	Integer Int1 = new Integer(Temp);
	int Temp_StartMonth = Int1.intValue();
	String StartMonth = new String();
	if (Temp_StartMonth < 10) {
		StartMonth = "0" + Temp_StartMonth;
	}
	else { 
		StartMonth = Int1.toString(Temp_StartMonth);
	}
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int Temp_StartDay = Int2.intValue();
	String StartDay = new String();
	if (Temp_StartDay < 10) {
		StartDay = "0" + Temp_StartDay;
	}
	else {
		StartDay = Int2.toString(Temp_StartDay);
	}
	String StartDate = StartDay + " " + StartMonth + " " + request.getParameter("StartYear") + " 12:00:00";

	Temp = request.getParameter("FinishMonth");
	Integer Int3 = new Integer(Temp);
	int Temp_FinishMonth = Int3.intValue();
	String FinishMonth = new String();
	if (Temp_FinishMonth < 10) {
		FinishMonth = "0" + Temp_FinishMonth;
	}
	else { 
		FinishMonth = Int3.toString(Temp_FinishMonth);
	}
	Temp = request.getParameter("FinishDay");
	Integer Int4 = new Integer(Temp);
	int Temp_FinishDay = Int4.intValue();
	String FinishDay = new String();
	if (Temp_FinishDay < 10) {
		FinishDay = "0" + Temp_FinishDay;
	}
	else {
		FinishDay = Int4.toString(Temp_FinishDay);
	}
	String FinishDate = FinishDay + " " + FinishMonth + " " + request.getParameter("FinishYear") + " 12:00:00";

	Temp = request.getParameter("MinPrice");
	Integer Int5 = new Integer(Temp);
	double MinPrice = Int5.doubleValue();
	Temp = request.getParameter("MaxPrice");
	Integer Int6 = new Integer(Temp);
	double MaxPrice = Int6.doubleValue();
	Temp = request.getParameter("Amount");
	Integer Int7 = new Integer(Temp);
	int Amount = Int7.intValue();
	
	Temp = request.getParameter("Smoke");
	Integer Int8 = new Integer(Temp);
	int Smoke = Int8.intValue();
	Temp = request.getParameter("HotelID");
	Integer Int9 = new Integer(Temp);
	int HotelID = Int9.intValue();

//	out.print(MinPrice + " " + MaxPrice + " " + StartDate + " " + FinishDate + " " + Smoke + " " + Amount);
	SearchRoomResult Detail[] = soapProxy.hotelSearchRoom(Amount , Room , StartDate , FinishDate , Smoke , MinPrice , MaxPrice , false , HotelID , 0 , 0);
	String Output = new String();
	if ((Detail.length == 0) || (Detail[0].getRoomSize() == 0)) {
		out.print("0");
	}
	else {
	for (int i = 0 ; i < Detail.length ; i ++ ) {
			Output = Output + Detail[i].getRoomType() + "!" + Detail[i].getRoomPrice() + "!" + Detail[i].getMaximumMenPerRoom() + "!";
	}
	out.print(Output);
	}

%>