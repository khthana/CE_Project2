<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ReturnReserve" %><%@ page contentType="text/html;charset=WINDOWS-874"%><%
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Int1 = new Integer(Temp);
	int Customer_ID = Int1.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Int2 = new Integer(Temp);
	int Wedding_Contact = Int2.intValue();
	Temp = request.getParameter("HotelID");
	Integer Int3 = new Integer(Temp);
	int HotelID = Int3.intValue();
	Temp = request.getParameter("SeminarID");
	Integer Int4 = new Integer(Temp);
	int SeminarID = Int4.intValue();
	String Decorate = request.getParameter("Dec_Style");
	if (Decorate.equals("0")) {
			Decorate = "thai";
	}
	else if (Decorate.equals("1")) {
			Decorate = "chinese";
	}
	else if (Decorate.equals("2")) {
			Decorate = "international";
	}
	Temp = request.getParameter("StartMonth");
	Integer Int5 = new Integer(Temp);
	int Temp_StartMonth = Int5.intValue();
	String StartMonth = new String();
	if (Temp_StartMonth < 10) {
		StartMonth = "0" + Temp_StartMonth;
	}
	else { 
		StartMonth = Int5.toString(Temp_StartMonth);
	}
	Temp = request.getParameter("StartDay");
	Integer Int6 = new Integer(Temp);
	int Temp_StartDay = Int6.intValue();
	String StartDay = new String();
	if (Temp_StartDay < 10) {
		StartDay = "0" + Temp_StartDay;
	}
	else {
		StartDay = Int6.toString(Temp_StartDay);
	}
	String ReserveDate = StartDay + " " + StartMonth + " " + request.getParameter("StartYear");
	short time1 = 0;
	short time2 = 0;
	short time3 = 0;
	String Time = request.getParameter("Time");
	if (Time.equals("0")) {
			time1 = 1;
	}
	else if (Time.equals("1")) {
			time2 = 1;
	}
	else if (Time.equals("2")) {
			time3 = 1;
	}

	Temp = request.getParameter("Men_Per_Room");
	Integer Int8 = new Integer(Temp);
	int Men_Per_Room = Int8.intValue();

	String Table = request.getParameter("Serve_Style");
	if (Table.equals("0")) {
			Table = "buffet";
	}
	else if (Table.equals("0")) {
			Table = "chinese";
	}

	int Contact = soapProxy.hotelCreateContact("WeddingPlanner" , HotelID , Customer_ID , Wedding_Contact);
	soapProxy.hotelReserveSeminar(Customer_ID , Contact , SeminarID , Decorate , ReserveDate , time1 , time2 , time3 , Men_Per_Room , Table , HotelID , Wedding_Contact);




%>