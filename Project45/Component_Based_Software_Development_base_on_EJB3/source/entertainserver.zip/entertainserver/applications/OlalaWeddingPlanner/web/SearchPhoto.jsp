<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.EntertainResultsearch" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 

	String Temp = request.getParameter("MinPrice");
	Integer Dou1 = new Integer(Temp);
	int MinPrice = Dou1.intValue();
	Temp = request.getParameter("MaxPrice");
	Integer Dou2 = new Integer(Temp);
	int MaxPrice = Dou2.inteValue();
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int StartDay = Int2.intValue();
	Temp = request.getParameter("StartMonth");
	Integer Int3 = new Integer(Temp);
	int StartMonth = Int3.intValue();
	Temp = request.getParameter("StartYear");
	Integer Int4 = new Integer(Temp);
	int StartYear = Int4.intValue();
	Temp = request.getParameter("FinishDay");
	Integer Int5 = new Integer(Temp);
	int FinishDay = Int5.intValue();
	Temp = request.getParameter("FinishMonth");
	Integer Int6 = new Integer(Temp);
	int FinishMonth = Int6.intValue();
	Temp = request.getParameter("FinishYear");
	Integer Int7 = new Integer(Temp);
	int FinishYear = Int7.intValue();
	String Continent = request.getParameter("Continent");
	String Country = request.getParameter("Country");
	String Grade = request.getParameter("Grade");

//	boolean Cheap = true;
//	int EntertainNumber = 0;
//	String Output = new String();
//	EntertainResultsearch Result[] = soapProxy.entertainment_Search(Style , Type , MinPrice , MaxPrice , Int1.toString(StartDay) + " " + Int1.toString(StartMonth) + " " + Int1.toString(StartYear) + " " + Int1.toString(StartHour) + ":" + Int1.toString(StartMinute) + ":00" , FinishDate.getDate() + " " + (FinishDate.getMonth() + 1) + " " + FinishDate.getYear() + " " + FinishDate.getHours() + ":" + FinishDate.getMinutes() + ":00" , Cheap , Near , EntertainNumber);

//	if (Result.length == 0) {
//		Output = "0";
//	}
//	else {
//	for (int i = 0 ; i < Result.length ; i ++) {
//		Output = Output + Result[i].getBandId() + "!" + Result[i].getBandTypeName() + "!" + Result[i].getBandTypeId() + "!" + Result[i].getBandName() + "!" + Result[i].getBandPriceAm() + "!" + Result[i].getBandPricePm() + "!" + Result[i].getEntertainmentName() + "!" + Int1.toString(StartDay) + " " + Int1.toString(StartMonth) + " " + Int1.toString(StartYear) + " " + Int1.toString(StartHour) + ":" + Int1.toString(StartMinute) + ":00!" + FinishDate.getDate() + " " + (FinishDate.getMonth() + 1) + " " + FinishDate.getYear() + " " + FinishDate.getHours() + ":" + FinishDate.getMinutes() + ":00!"  ;
//	}
//	}
//	out.print(Output);
%>