<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Payment_Impl proxy = new Payment_Impl(); 
    PaymentSoap soapProxy = proxy.getpaymentSoap(); 
	String Temp = request.getParameter("Wedding_Contact");
	Integer Int1 = new Integer(Temp);
	int Wedding_Contact = Int1.intValue();
	String CreditNo = request.getParameter("CreditNo");
	Temp = request.getParameter("ExpireMonth");
	Integer Int2 = new Integer(Temp);
	int ExpireMonth = Int2.intValue();
	Temp = request.getParameter("ExpireYear");
	Integer Int3 = new Integer(Temp);
	int ExpireYear = Int3.intValue();
	String Password = request.getParameter("Password");

	out.print(soapProxy.confirm(Wedding_Contact , CreditNo , ExpireMonth , ExpireYear , Password));
%>