<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page contentType="text/html;charset=WINDOWS-874"%><%
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Int11 = new Integer(Temp);
	int Customer_ID = Int11.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Int21 = new Integer(Temp);
	int Wedding_Contact = Int21.intValue();
	Temp = request.getParameter("StartMonth");
	Integer Int1 = new Integer(Temp);
	int Temp_StartMonth = Int1.intValue();
	String StartMonth = new String();
	if (Temp_StartMonth < 10) {
		StartMonth = "0" + Temp_StartMonth;
	}
	else { 
		StartMonth = Int1.toString(Temp_StartMonth);
	}
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int Temp_StartDay = Int2.intValue();
	String StartDay = new String();
	if (Temp_StartDay < 10) {
		StartDay = "0" + Temp_StartDay;
	}
	else {
		StartDay = Int2.toString(Temp_StartDay);
	}
	String StartDate = StartDay + " " + StartMonth + " " + request.getParameter("StartYear") + " 12:00:00";

	Temp = request.getParameter("FinishMonth");
	Integer Int3 = new Integer(Temp);
	int Temp_FinishMonth = Int3.intValue();
	String FinishMonth = new String();
	if (Temp_FinishMonth < 10) {
		FinishMonth = "0" + Temp_FinishMonth;
	}
	else { 
		FinishMonth = Int3.toString(Temp_FinishMonth);
	}
	Temp = request.getParameter("FinishDay");
	Integer Int4 = new Integer(Temp);
	int Temp_FinishDay = Int4.intValue();
	String FinishDay = new String();
	if (Temp_FinishDay < 10) {
		FinishDay = "0" + Temp_FinishDay;
	}
	else {
		FinishDay = Int4.toString(Temp_FinishDay);
	}
	String FinishDate = FinishDay + " " + FinishMonth + " " + request.getParameter("FinishYear") + " 12:00:00";
	
	Temp = request.getParameter("Amount");
	Integer Int42 = new Integer(Temp);
	int Amount = Int42.intValue();
	Temp = request.getParameter("Smoke");
	Integer Int43 = new Integer(Temp);
	int Smoke = Int43.intValue();
	String Room = request.getParameter("Room");
	if (Room.equals("0")) {
			Room = "single";
	}
	else 	if (Room.equals("1")) {
			Room = "twin";	
	}
	else 	if (Room.equals("2")) {
			Room = "suite";	
	}
	Hotelcontact Hotel_Contact = soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact);
	soapProxy.hotelReserveRoom(Customer_ID , Hotel_Contact.getHotelcontact() , Amount , Room , StartDate , FinishDate , 0 , Smoke ,Hotel_Contact.getHotelId() , Wedding_Contact );
//	out.print(Customer_ID + " " + Wedding_Contact + " " + StartDate + " " + FinishDate + " " + Amount + " " + Smoke + " " + Room );
%>