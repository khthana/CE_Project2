<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% OlalaTour_Impl proxy = new OlalaTour_Impl(); 
    OlalaTourSoap soapProxy = proxy.getOlalaTourSoap(); 
	String Output = new String();
	String Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	out.print(soapProxy.tour_HasContact(Wedding_Contact_ID));
%>