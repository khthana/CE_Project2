<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.SearchCakeResult" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 

	String Cake_Style = request.getParameter("Cake_Style");
	if (Cake_Style.equals("0")) {
			Cake_Style = "vanilla cream cake";
	}
	else 	if (Cake_Style.equals("1")) {
			Cake_Style = "coffee cream cake";	
	}
	else 	if (Cake_Style.equals("2")) {
			Cake_Style = "fruit cake";	
	}
	else 	if (Cake_Style.equals("3")) {
			Cake_Style = "cream cake";	
	}
	else 	if (Cake_Style.equals("4")) {
			Cake_Style = "sugar cake";	
	}
	else 	if (Cake_Style.equals("5")) {
			Cake_Style = "chocolate cake";	
	}

	String Flavour = request.getParameter("Flavour");
	if (Flavour.equals("0")) {
		Flavour = "banana";
	}
	else	if (Flavour.equals("1")) {
		Flavour = "butter";
	}
	else	if (Flavour.equals("2")) {
		Flavour = "chocolate";
	}
	else	if (Flavour.equals("3")) {
		Flavour = "coffee";
	}
	else	if (Flavour.equals("4")) {
		Flavour = "pandan";
	}
	else	if (Flavour.equals("5")) {
		Flavour = "vanila";
	}

	String Temp = request.getParameter("MinPrice");
	Integer Int1 = new Integer(Temp);
	double MinPrice = Int1.doubleValue();
	Temp = request.getParameter("MaxPrice");
	Integer Int6 = new Integer(Temp);
	double MaxPrice = Int6.doubleValue();
	
	Temp = request.getParameter("Layer");
	Integer Int11 = new Integer(Temp);
	int Layer = Int11.intValue();

	Temp = request.getParameter("HotelID");
	Integer Int9 = new Integer(Temp);
	int HotelID = Int9.intValue();

//	out.print(MinPrice + " " + MaxPrice + " " + StartDate + " " + FinishDate + " " + Smoke + " " + Amount);
	SearchCakeResult Detail[] = soapProxy.hotelSearchCake(Cake_Style , MinPrice , MaxPrice , Layer , Flavour , 7 , false , HotelID , 0 , 0);
	String Output = new String();
	if ((Detail.length == 0) || (Detail[0].getCakeId() == 0)){
		out.print("0");
	}
	else {
	for (int i = 0 ; i < Detail.length ; i ++ ) {
			Output = Output + Detail[i].getCakeId() + "!" + Detail[i].getCakename() + "!" + Detail[i].getCakestyle() + "!"+ Detail[i].getCakeSize() + "!" + Detail[i].getLayer() + "!"+ Detail[i].getFlavour() + "!"+ Detail[i].getCakePrice() + "!";
	}
	out.print(Output);
	}
%>