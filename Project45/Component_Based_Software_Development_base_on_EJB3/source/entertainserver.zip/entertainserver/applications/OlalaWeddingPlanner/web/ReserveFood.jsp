<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page import="org.openuri.www.ShowAllJobid" %><%@ page contentType="text/html;charset=WINDOWS-874"%><%
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Int11 = new Integer(Temp);
	int Customer_ID = Int11.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Int21 = new Integer(Temp);
	int Wedding_Contact = Int21.intValue();
	Temp = request.getParameter("FoodPackage");
	Integer Int13 = new Integer(Temp);
	int FoodPackage = Int13.intValue();
	
	Temp = request.getParameter("Time");
	Integer Int41 = new Integer(Temp);
	int Time = Int41.intValue();
	String RealTime = new String();
	if (Time < 10) {
		RealTime = "0" + Time;
	}
	else {
		RealTime = Int41.toString(Time);
	}
	RealTime = RealTime + ":00:00";

	
	
	Temp = request.getParameter("Amount");
	Integer Int42 = new Integer(Temp);
	short Amount = Int42.shortValue();
	Hotelcontact Hotel_Contact = soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact);

	ShowAllJobid JobID = soapProxy.hotelShowJobID(Customer_ID , Hotel_Contact.getHotelcontact() , Hotel_Contact.getHotelId());
	int Seminar[] = JobID.getSeminarRoomJobId();

	soapProxy.hotelReserveFood(Customer_ID , Hotel_Contact.getHotelcontact() , Seminar[0] , FoodPackage , RealTime , Amount , Hotel_Contact.getHotelId() , Wedding_Contact );
//	out.print(Customer_ID + " " + Wedding_Contact + " " + StartDate + " " + Amount + " " + Seminar[0]);
%>