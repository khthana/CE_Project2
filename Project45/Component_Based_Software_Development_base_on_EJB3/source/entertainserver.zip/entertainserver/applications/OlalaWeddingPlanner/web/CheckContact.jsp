<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ContactID" %><%@ page contentType="text/html;charset=WINDOWS-874"%><%@ page import="org.openuri.www.Hotelcontact" %><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 

	OlalaTour_Impl proxy2 = new OlalaTour_Impl(); 
   OlalaTourSoap soapProxy2 = proxy2.getOlalaTourSoap(); 

	OlalaPhoto_Impl proxy3 = new OlalaPhoto_Impl(); 
    OlalaPhotoSoap soapProxy3 = proxy3.getOlalaPhotoSoap(); 

	WeddingplannerGift_Impl proxy4 = new WeddingplannerGift_Impl(); 
    WeddingplannerGiftSoap soapProxy4 = proxy4.getWeddingplannerGiftSoap(); 

	Weddingplanner1_Impl proxy5 = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy5 = proxy5.getweddingplanner1Soap(); 
	
	String Temp = request.getParameter("Customer_ID");

	String Output = new String();
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact_ID");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
//	out.print("0!0!0!" + soapProxy.entertainment_Contact_List(Customer_ID , Wedding_Contact_ID) + "!" + soapProxy2.tour_HasContact(Wedding_Contact_ID) + "!");
	String Result1 = new String();
	ContactID Contact1 = soapProxy3.photo_HasContact(Wedding_Contact_ID);
	if (Contact1 == null) {
			Result1 = "0";
	}
	else {
			Result1 = "1";
	}
	String Result2 = new String();
	Hotelcontact Contact2 = soapProxy5.hotel_Contact_List(Customer_ID , Wedding_Contact_ID);
	if (Contact2 == null) {
			Result2 = "0";
	}
	else {
			Result2 = "1";
	}
	out.print(Result2 + "!" + Result1 + "!" + soapProxy4.giftListContact(Customer_ID , Wedding_Contact_ID) + "!" + soapProxy.entertainment_Contact_List(Customer_ID , Wedding_Contact_ID) + "!" + soapProxy2.tour_HasContact(Wedding_Contact_ID) + "!");
%>