<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% WeddingplannerGift_Impl proxy = new WeddingplannerGift_Impl(); 
    WeddingplannerGiftSoap soapProxy = proxy.getWeddingplannerGiftSoap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	int Contact_ID = 	soapProxy.giftListContact(Customer_ID , Wedding_Contact_ID); 
	soapProxy.giftCancelContact(Customer_ID , Contact_ID , Wedding_Contact_ID);
%>