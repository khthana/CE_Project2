<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.SearchFoodResult" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 

	String Food_Style = request.getParameter("Food_Style");
	if (Food_Style.equals("0")) {
			Food_Style = "thai";
	}
	else 	if (Food_Style.equals("1")) {
			Food_Style = "chinese";	
	}
	else 	if (Food_Style.equals("2")) {
			Food_Style = "international";	
	}

	String Temp = request.getParameter("Serve_Type");
	String Serve = new String();
	if (Temp.equals("0")) {
			Serve = "table";
	}
	else	if (Temp.equals("")) {
			Serve = "buffet";
	}

	Integer Int5 = new Integer(Temp);
	int Serve_Type = Int5.intValue();

	Temp = request.getParameter("MinPrice");
	Integer Int1 = new Integer(Temp);
	double MinPrice = Int1.doubleValue();
	Temp = request.getParameter("MaxPrice");
	Integer Int6 = new Integer(Temp);
	double MaxPrice = Int6.doubleValue();
	
	Temp = request.getParameter("HotelID");
	Integer Int9 = new Integer(Temp);
	int HotelID = Int9.intValue();

//	out.print(MinPrice + " " + MaxPrice + " " + StartDate + " " + FinishDate + " " + Smoke + " " + Amount);
	SearchFoodResult Detail[] = soapProxy.hotelSearchFood(MinPrice , MaxPrice , Food_Style , Serve , " " , false , HotelID , Serve_Type);
	String Output = new String();
	if ((Detail.length == 0) || (Detail[0].getFoodPackageId() == 0)){
		out.print("0");
	}
	else {
	for (int i = 0 ; i < Detail.length ; i ++ ) {
			Output = Output + Detail[i].getFoodPackageId() + "!" + Detail[i].getFoodStyle() + "!" + Detail[i].getFoodPricePerPerson() + "!"+ Detail[i].getFoodPricePerTable() + "!";
	}
	out.print(Output);
	}
%>