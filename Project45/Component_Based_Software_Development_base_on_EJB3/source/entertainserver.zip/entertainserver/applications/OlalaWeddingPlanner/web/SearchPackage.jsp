<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.PackageDetail" %><%@ page import="org.openuri.www.PackageList" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	OlalaTour_Impl proxy = new OlalaTour_Impl(); 
    OlalaTourSoap soapProxy = proxy.getOlalaTourSoap(); 

	String Temp = request.getParameter("Detail");
	int PackageID = 0 ;
	int TourID = 0 ;
	int count = 0;
	for (int i = 0 ; i < Temp.length() ; i ++ ) {
		if (Temp.substring(i , i + 1).equals("!") ){
			count ++;
			if (count == 1)
			{
				Integer Temp_Integer = new Integer(Temp.substring(0 , i));
				PackageID = Temp_Integer.intValue();		
				Temp = Temp.substring( i + 1 , Temp.length() );
				i = 0;
			}
			if (count == 2)
			{
				Integer Temp_Integer = new Integer(Temp.substring(4 , Temp.length() - 1));
				TourID = Temp_Integer.intValue();					
				Temp = Temp.substring(i + 1 , Temp.length() );
				i = 0;
				count = 0;
			}
		}
	}
	PackageDetail Package = soapProxy.tour_GetPackageDetail(PackageID , TourID);
	String[] Continent = Package.getContinentName();
	String[] Country = Package.getCountryName();
	String[] City = Package.getCityName();
	String[] Place = Package.getPlaceName();
	String PackageName = Package.getPackageName();
	String FinishDate = Package.getFinishDate();
	String StartDate = Package.getStartDate();
	String Deadline = Package.getDeadline();
	String[] VehicleName = Package.getVehicleName();
	String Output = new String();
	Output = PackageName + "!" + StartDate + "!" + FinishDate + "!" + Deadline + "!";
	for (int i = 0 ; i < VehicleName.length ; i ++ ) {
			Output = Output + VehicleName[i] + "#";
	}
	for (int i = 0 ; i < Continent.length ; i ++ ) {
			Output = Output + Continent[i] + "!" + Country[i] + "!" + City[i] + "!" + Place[i] + "!";
	}

out.print(Output);
%>