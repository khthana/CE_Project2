<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Hotelcontact Contact_ID = 	soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact_ID); 
	soapProxy.hotelCancelContact(Wedding_Contact_ID , Contact_ID.getHotelcontact() );
%>