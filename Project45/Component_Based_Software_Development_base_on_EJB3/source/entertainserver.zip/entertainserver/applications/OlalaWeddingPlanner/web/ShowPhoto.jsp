<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.ContactInfo" %><%@ page import="org.openuri.www.ContactID" %><%@ page import="org.openuri.www.JobInStudioDetail" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% OlalaPhoto_Impl proxy = new OlalaPhoto_Impl(); 
    OlalaPhotoSoap soapProxy = proxy.getOlalaPhotoSoap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact = Temp_Integer2.intValue();
	ContactID Contact = soapProxy.photo_GetContactID(Wedding_Contact);
	ContactInfo Detail[] = soapProxy.photo_ShowOrderByContact(Wedding_Contact , Contact.getContactID());
	JobInStudioDetail Job = soapProxy.photo_ShowJobInfo_InStudio(Contact.getPhotoID() , Contact.getContactID() , Detail[0].getJobID());
	String Output = new String();
	Output = Output + Job.getContactID() + "!" + Job.getJobID() + "!" + Job.getSubTypeName() + "!" + Job.getSubTypeDetail() + "!" + Job.getReserveDate() + "!" + Job.getRound() + "!" + Job.getPrice() + "!";
	out.print(Output);

%>