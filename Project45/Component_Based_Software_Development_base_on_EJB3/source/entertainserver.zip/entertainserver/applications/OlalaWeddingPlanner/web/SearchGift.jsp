<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.GiftInfo" %><%@ page import="org.openuri.www.PackageList" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	WeddingplannerGift_Impl proxy = new WeddingplannerGift_Impl(); 
    WeddingplannerGiftSoap soapProxy = proxy.getWeddingplannerGiftSoap(); 

	String Temp = request.getParameter("MinPrice");
	Integer Dou1 = new Integer(Temp);
	double MinPrice = Dou1.intValue();
	Temp = request.getParameter("MaxPrice");
	Integer Dou2 = new Integer(Temp);
	double MaxPrice = Dou2.intValue();

	Temp = request.getParameter("Style");
	String Style = new String();
	if (Temp.equals("1")) {
		Style = "thai";
	}
	else if (Temp.equals("2")) {
		Style = "chinese";
	}
	else if (Temp.equals("3")) {
		Style = "international";
	}
	else if (Temp.equals("0")) {
		Style = "";
	}
	String Type = request.getParameter("Type");
	String Cheap = request.getParameter("Cheap");
	boolean Check_Cheap = true;
	if (Cheap.equals("0")) {
			Check_Cheap = true;
	}
	else {
			Check_Cheap = false;
	}
	String Output = new String();
	GiftInfo Result[] = soapProxy.giftSearch(Type , Style , MinPrice, MaxPrice, Check_Cheap , 0);
	if (Result.length > 0) {
			for ( int i = 0 ; i < Result.length ; i ++ ) {
					Output = Output + Result[i].getTypeId() + "!" + Result[i].getSubtypeId() + "!" + Result[i].getGiftNumber() + "!" + Result[i].getTypeName() + "!" + Result[i].getSubtypeName() + "!" + Result[i].getSubtypeDetail() + "!" + Result[i].getPrice() + "!" + Result[i].getGiftName() + "!";
			}
			out.print(Output);
	}
	else {
			out.print("0");
	} 
%>