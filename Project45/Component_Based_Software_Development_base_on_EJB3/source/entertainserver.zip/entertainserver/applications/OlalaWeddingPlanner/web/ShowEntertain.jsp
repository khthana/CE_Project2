<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.EntertainListJob" %><%@ page import="org.openuri.www.EntertainJobDetail" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	EntertainListJob JobList[] = soapProxy.entertainment_Job_List(Customer_ID , Wedding_Contact_ID);
	String Output = new String();
//	out.print(JobList.length);
	for ( int i = 0 ; i < JobList.length ; i ++ )
	{
		EntertainJobDetail JobDetail = soapProxy.entertainment_Job_Detail(Wedding_Contact_ID , JobList[i].getContactID() , JobList[i].getJobID());
		Output = Output + JobList[i].getContactID() + "!" + JobList[i].getJobID() + "!" +JobDetail.getBandName() + "!" + JobDetail.getDetail() + "!" + JobDetail.getStartDatetime() + "!" + JobDetail.getFinishDatetime() + "!" + JobDetail.getPlace() + "!" + JobDetail.getFunctionType() + "!" + JobDetail.getPayDate() + "!" + JobDetail.getAdditionalRequests() + "!" + JobDetail.getDeadline() + "!" ;
	}
	out.print(Output);
%>