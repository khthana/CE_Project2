<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.PackageList" %><%@ page import="org.openuri.www.PackageList" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	OlalaTour_Impl proxy = new OlalaTour_Impl(); 
    OlalaTourSoap soapProxy = proxy.getOlalaTourSoap(); 

	String Temp = request.getParameter("MinPrice");
	Integer Dou1 = new Integer(Temp);
	int MinPrice = Dou1.intValue();
	Temp = request.getParameter("MaxPrice");
	Integer Dou2 = new Integer(Temp);
	int MaxPrice = Dou2.intValue();
	Temp = request.getParameter("StartDay");
	Integer Int2 = new Integer(Temp);
	int StartDay = Int2.intValue();
	Temp = request.getParameter("StartMonth");
	Integer Int3 = new Integer(Temp);
	int StartMonth = Int3.intValue();
	Temp = request.getParameter("StartYear");
	Integer Int4 = new Integer(Temp);
	int StartYear = Int4.intValue();
	Temp = request.getParameter("FinishDay");
	Integer Int5 = new Integer(Temp);
	int FinishDay = Int5.intValue();
	Temp = request.getParameter("FinishMonth");
	Integer Int6 = new Integer(Temp);
	int FinishMonth = Int6.intValue();
	Temp = request.getParameter("FinishYear");
	Integer Int7 = new Integer(Temp);
	int FinishYear = Int7.intValue();
	String Continent = request.getParameter("Continent");
	Temp = request.getParameter("Country");
	Integer Int8 = new Integer(Temp);
	int Country = Int8.intValue();
	if (Continent.equals("1")) {
		Country = Country + 1;
	}
	else if (Continent.equals("2")) {
		Country = Country + 9;
	}
	else if (Continent.equals("3")) {
		Country = Country + 11;
	}
	else if (Continent.equals("4")) {
		Country = Country + 14;
	}
	String Grade = request.getParameter("Grade");
	String VehicleGrade = new String();
	if (Grade.equals("1") || Grade.equals("2")) {
		VehicleGrade = "1";
	}
	else if (Grade.equals("3")) {
		VehicleGrade = "2";
	}
	else {
		VehicleGrade = "3";
	}

//	out.print(Continent + " " + Country + " " + Grade + " " + StartDay + " " + StartMonth + " " + StartYear + " " + FinishDay + " " + FinishMonth + " " + FinishYear + " " + MinPrice + " " + MaxPrice);
	PackageList Result = soapProxy.tour_Search(1, "" , "" , "" , Int8.toString(Country) , Continent , "1" , "1" , "" , Grade , "" , "2" , 0 , 0 , 0 ,0 , MinPrice , MaxPrice , StartDay , StartMonth , StartYear , FinishDay , FinishMonth , FinishYear , StartDay  , StartMonth , StartYear  , FinishDay, FinishMonth, FinishYear, 1 , 200, false);
	String Output = new String();
	int[] PackageID = Result.getPackageID();
	int[] Price = Result.getPrice();
	String[] TourName = Result.getTourName();
	if (PackageID.length > 0) {
	for (int i = 0 ; i < PackageID.length ; i ++ ) {
		Output = Output + PackageID[i] + "!" + Price[i] + "!" + TourName[i] + "!";
	}
//	out.print(Result.toString());
	out.print(Output);
	}
	else {
	out.print("0");
	}
%>