<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	
	OlalaPhoto_Impl proxy = new OlalaPhoto_Impl(); 
    OlalaPhotoSoap soapProxy = proxy.getOlalaPhotoSoap(); 

	String Temp = request.getParameter("Wedding_Contact");
	Integer Int1 = new Integer(Temp);
	int Wedding_Contact = Int1.intValue();
	String InStudioType = request.getParameter("InStudioType");
	String SubType = request.getParameter("SubType");
	Temp = request.getParameter("StartMonth");
	Integer Int3 = new Integer(Temp);
	int Temp_StartMonth = Int3.intValue();
	String StartMonth = new String();
	if (Temp_StartMonth < 10) {
		StartMonth = "0" + Temp_StartMonth;
	}
	else { 
		StartMonth = Int3.toString(Temp_StartMonth);
	}
	Temp = request.getParameter("StartDay");
	Integer Int4 = new Integer(Temp);
	int Temp_StartDay = Int4.intValue();
	String StartDay = new String();
	if (Temp_StartDay < 10) {
		StartDay = "0" + Temp_StartDay;
	}
	else {
		StartDay = Int4.toString(Temp_StartDay);
	}
	String ReserveDate = StartDay + " " + StartMonth + " " + request.getParameter("StartYear");
	Temp = request.getParameter("Round");
	Integer Int2 = new Integer(Temp);
	int Round = Int2.intValue();

	Temp = request.getParameter("PhotoID");
	Integer Int5 = new Integer(Temp);
	int PhotoID = Int5.intValue();

	Temp = request.getParameter("Customer_ID");
	Integer Int6 = new Integer(Temp);
	int Customer_ID = Int6.intValue();

	String Output = new String();
	soapProxy.photo_CreateContactID(PhotoID, "Wedding Planner" , Wedding_Contact , Customer_ID);
	if (soapProxy.photo_ReserveInStudio(PhotoID, Wedding_Contact, InStudioType, SubType, ReserveDate, Round) == 0) {
		out.print("0");
	}
	else {
		out.print("1");
	}

%>