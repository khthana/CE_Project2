<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 
	String Temp = request.getParameter("Customer_ID");
	String Output = new String();
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	String Contact_Name = request.getParameter("Contact_Name");
	String Temp_Str2 = new String(Contact_Name.getBytes("ISO8859_1") , "MS874");
	Contact_Name = Temp_Str2;
	out.print(soapProxy.create_Wedding_Contact_ID(Customer_ID , Contact_Name));
%>