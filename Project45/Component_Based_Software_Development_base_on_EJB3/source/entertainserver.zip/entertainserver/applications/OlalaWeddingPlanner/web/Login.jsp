<%@ page import="weblogic.jws.proxies.*" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% Weddingplanner_Impl proxy = new Weddingplanner_Impl(); 
    WeddingplannerSoap soapProxy = proxy.getWeddingplannerSoap(); 
	String username = request.getParameter("username");
	String Temp_Str1 = new String(username.getBytes("ISO8859_1") , "MS874");
	username = Temp_Str1;
	String password = request.getParameter("password");
	String Temp_Str2 = new String(password.getBytes("ISO8859_1") , "MS874");
	password = Temp_Str2;
	out.print(soapProxy.login(username,  password));
%>