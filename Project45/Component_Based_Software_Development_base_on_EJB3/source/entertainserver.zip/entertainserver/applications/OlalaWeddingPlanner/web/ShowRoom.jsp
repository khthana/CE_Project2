<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page import="org.openuri.www.RoomReservationList" %><%@ page import="org.openuri.www.ShowAllJobid" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Hotelcontact Hotel_Contact = soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact_ID);
	ShowAllJobid JobID = soapProxy.hotelShowJobID(Customer_ID , Hotel_Contact.getHotelcontact() , Hotel_Contact.getHotelId());
	int Room[] = JobID.getRoomJobId();
	String Output = new String();
	for (int i = 0 ; i < Room.length ; i ++) {
			RoomReservationList Detail = soapProxy.hotelShowReserveRoom(Room[i] , Hotel_Contact.getHotelId());
			Output = Output + Detail.getRoomJobId() + "!" + Detail.getRoomType() + "!" + Detail.getMaximumMenPerRoom() + "!" + Detail.getCheckinDate() + "!" + Detail.getCheckoutDate() + "!" + Detail.getJobTotalPrice() + "!" ;
			
	}
	out.print(Output);





%>