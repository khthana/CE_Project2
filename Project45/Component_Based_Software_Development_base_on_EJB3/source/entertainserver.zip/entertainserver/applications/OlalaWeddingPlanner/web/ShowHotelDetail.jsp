<%@ page import="weblogic.jws.proxies.*" %><%@ page import="org.openuri.www.Hotelcontact" %><%@ page import="org.openuri.www.SeminarRoomReservationList" %><%@ page import="org.openuri.www.ShowAllJobid" %><%@ page contentType="text/html;charset=WINDOWS-874"%><% 
	Weddingplanner1_Impl proxy = new Weddingplanner1_Impl(); 
    Weddingplanner1Soap soapProxy = proxy.getweddingplanner1Soap(); 
	String Temp = request.getParameter("Customer_ID");
	Integer Temp_Integer = new Integer(Temp);
	int Customer_ID = Temp_Integer.intValue();
	Temp = request.getParameter("Wedding_Contact");
	Integer Temp_Integer2 = new Integer(Temp);
	int Wedding_Contact_ID = Temp_Integer2.intValue();
	Hotelcontact Hotel_Contact = soapProxy.hotel_Contact_List(Customer_ID , Wedding_Contact_ID);
	ShowAllJobid JobID = soapProxy.hotelShowJobID(Customer_ID , Hotel_Contact.getHotelcontact() , Hotel_Contact.getHotelId());
	int Seminar[] = JobID.getSeminarRoomJobId();
	int room[] = JobID.getRoomJobId();
	int cake[] = JobID.getCakeJobId();
	int food[] = JobID.getFoodJobId();
	int room1 = 0;
	int cake1 = 0;
	int food1 = 0;
	if (room == null) {
			room1 = 0;
	}
	else {
			room1 = room[0];
	}
	if (cake == null) {
			cake1 = 0;
	}
	else {
			cake1 = cake[0];
	}
	if (food == null) {
			food1 = 0;
	}
	else {
			food1 = food[0];
	}
	out.print(room1 + "!" + food1 + "!" + cake1 + "!");
	
%>