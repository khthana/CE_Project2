@echo off
rem PLEASE DOCUMENT YOUR USAGE OF COMMAND LINE PARAMETERS
rem         (any order, case insensitive)
rem nodebug
rem special
rem drt
rem production
rem nolog
rem nopointbase
rem

rem Parse Command Line Parameters
rem

rem set default parameter values
rem
set debugFlag=true
set specialFlag=false
set drtFlag=false
set productionFlag=false
set loggingFlag=true
set pointbaseFlag=true
set profileFlag=false


FOR %%p IN (%*) DO CALL :SET_PARAM %%p
GOTO :CMD_LINE_DONE
    :SET_PARAM
    if /i "%1" == "nodebug" set debugFlag=false
    if /i "%1" == "special" set specialFlag=true
    if /i "%1" == "drt" set drtFlag=true
    if /i "%1" == "production" set productionFlag=true && set loggingFlag=false
    if /i "%1" == "nolog" set loggingFlag=false
    if /i "%1" == "nopointbase" set pointbaseFlag=false
    if /i "%1" == "profile" set profileFlag=true
    GOTO :EOF
:CMD_LINE_DONE

set WL_HOME=C:\bea\weblogic700
set BEAHOME=C:\bea
set JAVA_HOME=C:\bea\jdk131_03

for %%i in (%0) do set CONFIGDIR=%%~dpi
for %%i in ("%CONFIGDIR%") do set CONFIGDIR=%%~fsi
pushd %CONFIGDIR%

rem Generate short directory names in case there are spaces in them
for %%i in ("%BEAHOME%") do set BEAHOME=%%~fsi
for %%i in ("%WL_HOME%") do set WL_HOME=%%~fsi
for %%i in ("%JAVA_HOME%") do set JAVA_HOME=%%~fsi

set POINTBASEDIR=C:\bea\weblogic700\samples\server
set ARDIR=%WL_HOME%\server\lib

rem
rem Clustering support (edit for your cluster!)
rem 
set CLUSTER_PROPERTIES=-Dweblogic.management.discover=false
if "%ADMIN_URL%" == "" goto notManaged
    set CLUSTER_PROPERTIES=-Dweblogic.management.server=%ADMIN_URL%
:notManaged

set JAVA_PROPERTIES=-Dlog4j.configuration=file:%WL_HOME%\common\lib\workshopLogCfg.xml %CLUSTER_PROPERTIES% 
rem set JAVA_PROPERTIES=%CLUSTER_PROPERTIES% 
set JAVA_DEBUG=-hotspot

if not "%debugFlag%" == "true" goto skipDebug1
    set JAVA_DEBUG=-Xdebug -Xnoagent -Xrunjdwp:transport=dt_socket,address=8453,server=y,suspend=n -Djava.compiler=NONE
    if not "%specialFlag%" == "true" goto skipDebug1
        set JAVA_DEBUG=-Xdebug -Xnoagent -Xrunjdwp:transport=dt_socket,address=8453,server=y,suspend=n
        if not "%drtFlag%" == "true" goto skipDebug1
            set JAVA_DEBUG=-Xdebug -Xnoagent -Xrunjdwp:transport=dt_socket,address=8453,server=y,suspend=n -Dknex.BrowserDebugOnly=true
:skipDebug1

SETLOCAL

set WLS_USER=system
set WLS_PW=sinanuwong
set MEM_ARGS=-Xms64m -Xmx128m
set STARTMODE=%productionFlag%

:special

rem Check that script is being run from the appropriate directory
if exist config.xml goto checkJRE
    echo %0 must be run from the %CONFIGDIR% directory. 1>&2
    goto finish
:checkJRE

dir %JAVA_HOME%\lib > nul
if errorlevel 0 goto runWebLogic
    echo.
    echo The JRE wasn't found in directory %JAVA_HOME%. (JAVA_HOME)
    echo Please edit your environment and set the JAVA_HOME
    echo variable to point to the root directory of your Java installation.
    goto finish
:runWebLogic

set PATH=%WL_HOME%\server\bin;%PATH%

REM
REM Export a special class path so we can generate the client proxy JAR files
REM
set CLASSPATH=%ARDIR%\ant\ant.jar;%JAVA_HOME%\jre\lib\rt.jar

REM
REM SET UP CLASSPATHS
REM
set PRE_CLASSPATH=%WL_HOME%\common\lib\log4j.jar;%ARDIR%\knex.jar;%ARDIR%\JDIProxy.jar

rem
rem pointbase 42 jars
rem
set PB_CLASSPATH=%POINTBASEDIR%\eval\pointbase\lib\pbserver42ECF172.jar;%POINTBASEDIR%\eval\pointbase\lib\pbclient42ECF172.jar

set POST_CLASSPATH=%PB_CLASSPATH%;%ARDIR%\webservices.jar;%ARDIR%\webserviceclient.jar;%ARDIR%\webserviceclient+ssl.jar

rem
rem PROFILING SUPPORT
rem 
set JAVA_PROFILE=
set SERVER_CLASS=weblogic.Server
if "%profileFlag%" == "false" goto skipProfile
if exist %OPTIT_HOME%\lib\optit.jar goto processGCOP
echo Cannot find the Optimizeit library optit.jar under the directory %OPTIT_HOME%
echo Make sure OPTIT_HOME is set correctly!
pause
goto finish
:processGCOP
set GCOPSIZE=10
if not "%GCOPSIZE%"=="" set JAVA_PROPERTIES=%JAVA_PROPERTIES% -DGCOPSIZE=%GCOPSIZE%
set PRE_CLASSPATH=%OPTIT_HOME%\lib\optit.jar;%PRE_CLASSPATH%
set SERVER_CLASS=intuitive.audit.GenericAudit %SERVER_CLASS%
set JAVA_PROFILE=-Xrunoii -Xbootclasspath/a:"%OPTIT_HOME%\lib\oibcp.jar"
:skipProfile

echo Production Mode=%productionFlag%

@REM 
@REM START THE DEBUGGER
@REM
@if "%specialFlag%" == "true" goto skipDebug2
    @if not "%debugFlag%" == "true" goto skipDebug2
        @start "WebLogic Workshop Debugger..." /MIN %JAVA_HOME%\bin\java -classpath %PRE_CLASSPATH%;%WL_HOME%\server\lib\weblogic.jar;%JAVA_HOME%\lib\tools.jar JDIProxy.DbgMain
:skipDebug2

@REM
@REM START POINTBASE
@REM
@if "%pointbaseFlag%" == "true" start "Pointbase" /B /MIN cmd /c %JAVA_HOME%\bin\java -classpath %WL_HOME%\server\lib\weblogic.jar;%PB_CLASSPATH% com.pointbase.net.netServer /port:9093 /d:0 /pointbase.ini=%CONFIGDIR%\pointbase.ini > %CONFIGDIR%\pointbase.log 2>&1


REM if the server_name is set that means we are starting a managed server and
REM don't want to overwrite its value here
if "%SERVER_NAME%"=="" set SERVER_NAME=myServer

@REM STUFF DONE ONLY BY US
@set JAVA_OPTIONS=%JAVA_OPTIONS% %JAVA_PROPERTIES% -Dweblogic.Name=%SERVER_NAME% -Dweblogic.security.SSL.ignoreHostnameVerify=true -Dweblogic.jws.ProductionMode=%productionFlag% -Dweblogic.jws.logging=%loggingFlag% -Dweblogic.security.SSL.trustedCAKeyStore="./cacerts1" -Dweblogic.SystemDataStoreConfigDirectory="%WL_HOME%\server\lib" -XX:MaxPermSize=65536K -Dweblogic.management.pkpassword=sinanuwong 
@set JAVA_VM=%JAVA_VM% %JAVA_DEBUG% %JAVA_PROFILE%

@REM
@REM START WEBLOGIC
@REM

call "%WL_HOME%\server\bin\startWLS.cmd"

:finish
popd
ENDLOCAL
exit
