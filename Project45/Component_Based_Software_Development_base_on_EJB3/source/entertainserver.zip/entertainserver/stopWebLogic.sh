#!/bin/sh
BEAHOME=C:/bea
export BEAHOME

JAVA_HOME=C:/bea/jdk131_03
export JAVA_HOME

WL_HOME=C:/bea/weblogic700/server
export WL_HOME

CLASSPATH=$WL_HOME/lib/weblogic.jar
export CLASSPATH

#
#   Shutdown Webogic
#
$JAVA_HOME/bin/java -cp $CLASSPATH weblogic.Admin SHUTDOWN -url t3://localhost:7001 -username system -password sinanuwong

#
#   Shutdown Pointbase
#
PB_DIR=C:/bea/weblogic700/samples/server/eval/pointbase/lib
PB_CLASSPATH=$PB_DIR/pbclient42ECF172.jar:$PB_DIR/pbtools42ECF172.jar
echo 'SHUTDOWN;' | "$JAVA_HOME/bin/java" -cp "$PB_CLASSPATH" com.pointbase.tools.toolsCommander com.pointbase.jdbc.jdbcUniversalDriver jdbc:pointbase:server://localhost:9093/cajun &> /dev/null

#
#   Shutdown JDIProxy
#
CLASSPATH=$WL_HOME/lib/JDIProxy.jar:$JAVA_HOME/lib/tools.jar
$JAVA_HOME/bin/java -cp $CLASSPATH JDIProxy.DbgMain -SHUTDOWN &> /dev/null



