using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;

namespace DbComponent
{	
	public class ConnectDB
	{
		public String SqlString;
		public SqlDataReader myDataReader;		
		public SqlConnection myConnection;
		public String connectionString;
		
		SqlCommand myCommand;
		SqlTransaction myTransaction;				

		// Connect Database 
		public ConnectDB(string database)
		{
			connectionString = "Server=localhost;database= " +database+ ";uid=sa;pwd=sa;";		
			myConnection = new SqlConnection(connectionString);						
		}

		// ExecuteNonQuery Provide for INSERT / UPDATE / DELETE			
		public string myExecuteNonQuery(string SqlString)
		{		
			myCommand = new SqlCommand();
			myCommand.CommandText=SqlString;
			try
			{
				myConnection.Open();
				myCommand.Connection=myConnection;								
				myTransaction = myConnection.BeginTransaction();
				myCommand.Transaction = myTransaction;				
				myCommand.ExecuteNonQuery();
				//commit end of myTransaction
				myTransaction.Commit();					
			}
			catch(SqlException E)
			{
				//Roll back if error
				myTransaction.Rollback();
				return "Error Exception :  "+ E.ToString();
			}
			myCommand.Connection.Close();
			return "success";
		}

		//ExecuteScalar Provide for SELECT
		public object myExecuteScalar(string SqlString)
		{			
			myCommand = new SqlCommand(SqlString,myConnection);			
			object obj;			
			try
			{
				myConnection.Open();											
				obj = myCommand.ExecuteScalar();				
			}
			catch(SqlException E)
			{
				//Roll back if error
				myTransaction.Rollback();
				return obj = "Error Exception :  "+ E.ToString();
			}
			myCommand.Connection.Close();	
			return obj;
		}
		
		// ExecuteReader Provide for SELECT
		public string myExecuteReader(string SqlString)
		{
			myCommand = new SqlCommand();
			myCommand.CommandText=SqlString;
			try
			{
				myConnection.Open();
				myCommand.Connection=myConnection;								
				myDataReader = myCommand.ExecuteReader();			
				return "success";
			}
			catch(SqlException E)
			{
				//Roll back if error
				myTransaction.Rollback();
				return "Error Exception :  "+ E.ToString();
			}
		}					
		
		public DataSet Query(string SqlString,string tablename)
		{
			DataSet myDataSet;
			myConnection.Open();

			myCommand = new SqlCommand(SqlString, myConnection);
			SqlDataAdapter myDataAdapter = 	new SqlDataAdapter(myCommand); 
			myDataSet = new DataSet();
			try
			{
				myDataAdapter.Fill (myDataSet,tablename );
			} 
			catch (SqlException E) 
			{
				Exception newE = new Exception("Error : Sql Statement ",E);
				throw newE;
				//return  myDataSet;
			}
			return myDataSet;
		}
	}
}
