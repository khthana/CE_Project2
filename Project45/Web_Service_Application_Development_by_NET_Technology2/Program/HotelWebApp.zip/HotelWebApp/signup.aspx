<%@ Page Language="vb" AutoEventWireup="false" Codebehind="signup.aspx.vb" Inherits="HotelWebApp.signup"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>signup</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server" target="index2_RFrame">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:TextBox id="txtName" style="Z-INDEX: 101; LEFT: 172px; POSITION: absolute; TOP: 89px" runat="server" Width="149px" Height="23px"></asp:TextBox>
				<asp:TextBox id="txtUsername" style="Z-INDEX: 117; LEFT: 170px; POSITION: absolute; TOP: 306px" runat="server" Width="149px" Height="23px"></asp:TextBox>
				<asp:TextBox id="txtPassword" style="Z-INDEX: 116; LEFT: 169px; POSITION: absolute; TOP: 333px" runat="server" Width="150px" Height="23px" TextMode="Password"></asp:TextBox>
				<asp:TextBox id="txtSurname" style="Z-INDEX: 102; LEFT: 173px; POSITION: absolute; TOP: 116px" runat="server" Width="147px" Height="23px"></asp:TextBox>
				<asp:TextBox id="txtAddress" style="Z-INDEX: 103; LEFT: 171px; POSITION: absolute; TOP: 171px" runat="server" Width="149px" Height="77px" TextMode="MultiLine" Font-Names="Microsoft Sans Serif"></asp:TextBox>
				<asp:TextBox id="txtTel" style="Z-INDEX: 104; LEFT: 171px; POSITION: absolute; TOP: 254px" runat="server" Width="149px" Height="23px"></asp:TextBox>
				<asp:Label id="Label1" style="Z-INDEX: 105; LEFT: 202px; POSITION: absolute; TOP: 31px" runat="server" Width="89px" Height="14px">��Ѥ���Ҫԡ����</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 106; LEFT: 118px; POSITION: absolute; TOP: 94px" runat="server" Width="15px" Height="12px">����</asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 107; LEFT: 107px; POSITION: absolute; TOP: 118px" runat="server" Width="42px" Height="18px">���ʡ��</asp:Label>
				<asp:Label id="Label4" style="Z-INDEX: 108; LEFT: 115px; POSITION: absolute; TOP: 172px" runat="server" Width="22px" Height="21px">�������</asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 109; LEFT: 108px; POSITION: absolute; TOP: 58px" runat="server" Width="103px" Height="16px">��سҡ�͡Ẻ�����</asp:Label>
				<asp:Label id="Label6" style="Z-INDEX: 110; LEFT: 117px; POSITION: absolute; TOP: 144px" runat="server" Width="26px" Height="20px">��</asp:Label>
				<asp:DropDownList id="ddlSex" style="Z-INDEX: 111; LEFT: 172px; POSITION: absolute; TOP: 144px" runat="server" Width="54px" Height="26px" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="���">���</asp:ListItem>
					<asp:ListItem Value="˭ԧ">˭ԧ</asp:ListItem>
				</asp:DropDownList>
				<asp:Label id="Label7" style="Z-INDEX: 112; LEFT: 252px; POSITION: absolute; TOP: 146px" runat="server" Width="25px" Height="17px">����</asp:Label>
				<asp:Label id="Label8" style="Z-INDEX: 113; LEFT: 94px; POSITION: absolute; TOP: 254px" runat="server" Width="67px" Height="13px">�������Ѿ��</asp:Label>
				<asp:Label id="Label9" style="Z-INDEX: 114; LEFT: 107px; POSITION: absolute; TOP: 283px" runat="server" Width="43px" Height="15px">E-mail </asp:Label>
				<asp:TextBox id="txtEmail" style="Z-INDEX: 115; LEFT: 171px; POSITION: absolute; TOP: 280px" runat="server" Width="148px" Height="23px"></asp:TextBox>
				<asp:Label id="Label10" style="Z-INDEX: 118; LEFT: 93px; POSITION: absolute; TOP: 309px" runat="server" Width="59px" Height="14px">Username</asp:Label>
				<asp:Label id="Label11" style="Z-INDEX: 119; LEFT: 94px; POSITION: absolute; TOP: 333px" runat="server" Width="65px" Height="23px">Password</asp:Label>
				<asp:Label id="Label12" style="Z-INDEX: 120; LEFT: 250px; POSITION: absolute; TOP: 423px" runat="server" Width="58px" Height="36px"></asp:Label>
				<asp:Button id="cmdSubmit" style="Z-INDEX: 121; LEFT: 169px; POSITION: absolute; TOP: 371px" runat="server" Width="68px" Height="25px" Text="Submit"></asp:Button>
				<asp:Button id="cmdReset" style="Z-INDEX: 122; LEFT: 249px; POSITION: absolute; TOP: 371px" runat="server" Width="69px" Height="25px" Text="Reset"></asp:Button>
				<asp:TextBox id="txtAge" style="Z-INDEX: 123; LEFT: 280px; POSITION: absolute; TOP: 143px" runat="server" Width="40px" Height="23px" MaxLength="3"></asp:TextBox></FONT>
		</form>
	</body>
</HTML>
