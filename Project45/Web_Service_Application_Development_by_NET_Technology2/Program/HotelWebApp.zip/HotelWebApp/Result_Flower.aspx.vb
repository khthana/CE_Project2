Public Class Result_Flower
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DataColumn1 As System.Data.DataColumn

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1})
        Me.DataTable1.TableName = "tblAllFlower"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "��������´ᾡࡨ�͡���"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            BindData()
        End If
    End Sub

    Private Sub BindData()
        ' Put user code to initialize the page here


        Dim MinPrice, MaxPrice As Double
        Dim SeminarName As String

        MinPrice = Request.QueryString("MinPrice")
        MaxPrice = Request.QueryString("MaxPrice")
        SeminarName = Request.QueryString("SeminarName")

        Dim find As New HotelRef.HotelService0()
        Dim rs() As HotelRef.CSearchFlowerResult = find.Search_Flower(SeminarName, MinPrice, MaxPrice)
        Dim Count As Integer = rs.Length

        DataSet1.Tables("tblAllFlower").Clear()
        Dim a As DataTable ' Create DataTable
        a = DataSet1.Tables("tblAllFlower")

        Dim r As Integer
        'Dim srt As New HotelRef.HotelService0()
        For r = 0 To Count - 1
            If rs(r).flower_package_id <> 0 Then
                Dim rc As DataRow
                rc = a.NewRow
                rc("��������´ᾡࡨ�͡���") = "<BR>" & rs(r).flower_package_name & "<BR>" & "�Ҥ�  " & rs(r).flower_price & " �ҷ"
                a.Rows.Add(rc)
            End If
        Next r
        DataGrid1.DataBind() ' Bind it!		

    End Sub


End Class
