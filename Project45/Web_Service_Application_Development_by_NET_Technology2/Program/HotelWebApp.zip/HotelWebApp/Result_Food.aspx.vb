Public Class Result_Food
    Inherits System.Web.UI.Page
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents DataColumn1 As System.Data.DataColumn
    Protected WithEvents DataColumn2 As System.Data.DataColumn
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2})
        Me.DataTable1.TableName = "tblAllFood"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "��������´ᾡࡨ"
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "��������´�����"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            BindData()
        End If
    End Sub

    Private Sub BindData()
        ' Put user code to initialize the page here
      
        Dim FoodStyle As String
        Dim ServeType As String
        Dim MinPrice, MaxPrice As Double
        Dim FoodName As String

        FoodStyle = Request.QueryString("FoodStyle")
        ServeType = Request.QueryString("ServeType")
        MinPrice = Request.QueryString("MinPrice")
        MaxPrice = Request.QueryString("MaxPrice")
        FoodName = Request.QueryString("FoodName")
        If FoodName = "" Then
            FoodName = " "
        End If

        Dim find As New HotelRef.HotelService0()
        Dim rs() As HotelRef.CSearchFoodResult = find.Search_Food(MinPrice, MaxPrice, FoodStyle, ServeType, FoodName)
        Dim Count As Integer = rs.Length

        DataSet1.Tables("tblAllFood").Clear()
        Dim a As DataTable ' Create DataTable
        a = DataSet1.Tables("tblAllFood")

        Dim r As Integer
        'Dim srt As New HotelRef.HotelService0()
        For r = 0 To Count - 1
            If rs(r).food_package_id <> 0 Then
                Dim rc As DataRow
                rc = a.NewRow

                Dim fdlst As New HotelRef.HotelService0()

                Dim FoodList() As String = fdlst.Show_FoodList(rs(r).food_package_id)
                Dim i As Integer
                Dim str_foodlst As String
                str_foodlst = "<BR><u>������մѧ���</u><BR><BR>"
                For i = 0 To FoodList.Length - 1
                    str_foodlst = str_foodlst & FoodList(i) & "<BR>"
                Next
                If FoodStyle = "CHINESE" Then
                    FoodStyle = "����èչ"
                End If
                If FoodStyle = "THAI" Then
                    FoodStyle = "�������"
                End If
                If FoodStyle = "INTERNATIONAL" Then
                    FoodStyle = "����ùҹҪҵ�"
                End If
                If FoodStyle = "COFFEE BREAK" Then
                    FoodStyle = "�������ҧ"
                End If
                Dim setx As String
                If rs(r).food_package_id = 1 Or rs(r).food_package_id = 4 Or rs(r).food_package_id = 7 Or rs(r).food_package_id = 10 Then
                    setx = "�� 1"
                End If
                If rs(r).food_package_id = 2 Or rs(r).food_package_id = 5 Or rs(r).food_package_id = 8 Or rs(r).food_package_id = 11 Then
                    setx = "�� 2"
                End If
                If rs(r).food_package_id = 3 Or rs(r).food_package_id = 6 Or rs(r).food_package_id = 9 Or rs(r).food_package_id = 12 Then
                    setx = "�� 3"
                End If
                If ServeType = "pertable" Then
                    ServeType = "��С��"
                Else
                    ServeType = "�ؿ࿵�"
                End If
                rc("��������´ᾡࡨ") = FoodStyle & setx & " " & "<BR>" & "��èѴ�����Ẻ" & ServeType
                rc("��������´�����") = str_foodlst & "<BR>"
                a.Rows.Add(rc)
            End If
        Next r
        DataGrid1.DataBind() ' Bind it!		

    End Sub

End Class
