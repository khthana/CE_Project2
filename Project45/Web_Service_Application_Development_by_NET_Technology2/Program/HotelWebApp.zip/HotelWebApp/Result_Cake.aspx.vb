Public Class Result_Cake
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents DataColumn1 As System.Data.DataColumn
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents DataColumn2 As System.Data.DataColumn

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2})
        Me.DataTable1.TableName = "tblAllCake"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "�Ҿ��"
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "��������´��"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            BindData()
        End If
    End Sub

    Private Sub BindData()
        ' Put user code to initialize the page here
        Dim Style As String
        Dim Layer, Size As Integer
        Dim MinPrice, MaxPrice As Double

        Style = Request.QueryString("Style")
        MinPrice = Request.QueryString("MinPrice")
        MaxPrice = Request.QueryString("MaxPrice")
        Layer = Request.QueryString("Layer")
        Size = Request.QueryString("Size")
        If Style = "" Then
            Style = " "
        End If
      
        Dim find As New HotelRef.HotelService0()
        Dim rs() As HotelRef.CSearchCakeResult = find.Search_Cake2(Style, MinPrice, MaxPrice, Layer, Size)
        Dim Count As Integer = rs.Length

        DataSet1.Tables("tblAllCake").Clear()
        Dim a As DataTable ' Create DataTable
        a = DataSet1.Tables("tblAllCake")

        Dim r As Integer
        For r = 0 To Count - 1
            If rs(r).cake_id <> 0 Then
                Dim rc As DataRow
                rc = a.NewRow

                'Find Cake Flavour
                Dim cf As New HotelRef.HotelService0()
                Dim fla_lst() As String = cf.Show_Cake_Flavour(rs(r).cake_id)

                Dim imgstr As String
                imgstr = "<center><img src=Image/cakeid" & rs(r).cake_id & ".jpg width=100 height=100>" & "</center>"
                rc("�Ҿ��") = imgstr
                Dim detstr As String
                detstr = "<BR>" & rs(r).cakename & "<BR>" & "������  " & rs(r).cakestyle & "<BR>" & "�ӹǹ  " & rs(r).layer & "  ���" & "<BR>" & " ��Ҵ " & rs(r).cake_size & "  �͹�� " & "<BR>" & " �Ҥ�  " & rs(r).cake_price & " �ҷ<BR>"
                detstr = detstr & "����ö���͡�ʪҴ�ͧ��������ѧ���<BR>"
                Dim i As Integer
                For i = 0 To fla_lst.Length - 1
                    detstr = detstr & fla_lst(i) & "<BR>"
                Next i
                rc("��������´��") = detstr & "<BR>"
                a.Rows.Add(rc)
            End If
        Next r
        DataGrid1.DataBind() ' Bind it!		

    End Sub

End Class
