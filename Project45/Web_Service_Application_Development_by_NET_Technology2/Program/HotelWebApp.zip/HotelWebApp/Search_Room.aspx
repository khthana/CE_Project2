<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Search_Room.aspx.vb" Inherits="HotelWebApp.Search_Room"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Search_Room</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<FONT face="Tahoma">
			<FORM id="roomreserve" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" method="post" target="index2_RFrame" runat="server">
				<asp:label id="Label13" style="Z-INDEX: 113; LEFT: 285px; POSITION: absolute; TOP: 103px" runat="server">check out �ѹ���</asp:label><asp:calendar id="Calendar1" style="Z-INDEX: 111; LEFT: 141px; POSITION: absolute; TOP: 100px" runat="server" Width="52px" Font-Names="Microsoft Sans Serif" Font-Size="8pt" BorderStyle="Outset" ToolTip="Checkin Date" Height="100px"></asp:calendar>
				<asp:calendar id="Calendar2" style="Z-INDEX: 110; LEFT: 378px; POSITION: absolute; TOP: 100px" runat="server" Width="52px" Font-Names="Microsoft Sans Serif" Font-Size="8pt" BorderStyle="Outset" ToolTip="Checkout Date" Height="100px"></asp:calendar>
				<asp:label id="Label1" style="Z-INDEX: 109; LEFT: 242px; POSITION: absolute; TOP: 26px" runat="server" Width="81px" BorderStyle="Ridge" Height="7px" BorderWidth="3px">
					<center>������ͧ�ѡ</center>
				</asp:label><asp:dropdownlist id="ddlRoomType" style="Z-INDEX: 102; LEFT: 142px; POSITION: absolute; TOP: 70px" runat="server" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="single">��§�����</asp:ListItem>
					<asp:ListItem Value="twin">��§���</asp:ListItem>
					<asp:ListItem Value="suite">��ͧ�ش</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label5" style="Z-INDEX: 101; LEFT: 77px; POSITION: absolute; TOP: 70px" runat="server">��ͧ�ѡẺ</asp:label><asp:checkbox id="chkSmoke" style="Z-INDEX: 103; LEFT: 334px; POSITION: absolute; TOP: 253px" runat="server" Font-Names="Microsoft San Serif" Text="��ͧ��èͧ��ͧ�ѡ���͹حҵ����ٺ������" Width="201px"></asp:checkbox><asp:button id="cmdSearchRoom" style="Z-INDEX: 104; LEFT: 247px; POSITION: absolute; TOP: 295px" runat="server" Width="75px" Font-Names="Microsoft Sans Serif" Text="�ӡ�ä���"></asp:button><asp:label id="Label8" style="Z-INDEX: 105; LEFT: 58px; POSITION: absolute; TOP: 103px" runat="server">check in �ѹ���</asp:label><asp:label id="Label14" style="Z-INDEX: 106; LEFT: 333px; POSITION: absolute; TOP: 69px" runat="server">�ӹǹ</asp:label><asp:label id="Label15" style="Z-INDEX: 107; LEFT: 423px; POSITION: absolute; TOP: 70px" runat="server">��ͧ</asp:label><asp:dropdownlist id="ddlRoomAmount" style="Z-INDEX: 108; LEFT: 378px; POSITION: absolute; TOP: 67px" runat="server" Width="37px">
					<asp:ListItem Value="1">1</asp:ListItem>
					<asp:ListItem Value="2">2</asp:ListItem>
					<asp:ListItem Value="3">3</asp:ListItem>
					<asp:ListItem Value="4">4</asp:ListItem>
					<asp:ListItem Value="5">5</asp:ListItem>
					<asp:ListItem Value="6">6</asp:ListItem>
					<asp:ListItem Value="7">7</asp:ListItem>
					<asp:ListItem Value="8">8</asp:ListItem>
					<asp:ListItem Value="9">9</asp:ListItem>
					<asp:ListItem Value="10">10</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label12" style="Z-INDEX: 112; LEFT: 256px; POSITION: absolute; TOP: 341px" runat="server" Width="36px" Height="27px"></asp:label><asp:label id="Label2" style="Z-INDEX: 114; LEFT: 60px; POSITION: absolute; TOP: 255px" runat="server" Width="73px" Height="14px">�Ҥ���ͧ�����</asp:label><asp:textbox id="txtMinPrice" style="Z-INDEX: 115; LEFT: 141px; POSITION: absolute; TOP: 253px" runat="server" Width="59px" Height="24px"></asp:textbox><asp:label id="Label3" style="Z-INDEX: 116; LEFT: 211px; POSITION: absolute; TOP: 258px" runat="server" Height="18px">�֧</asp:label><asp:textbox id="txtMaxPrice" style="Z-INDEX: 117; LEFT: 235px; POSITION: absolute; TOP: 253px" runat="server" Width="61px" Height="24px"></asp:textbox><asp:label id="lblError" style="Z-INDEX: 118; LEFT: 339px; POSITION: absolute; TOP: 297px" runat="server" Width="200px" Height="16px"></asp:label></FORM>
		</FONT>
	</body>
</HTML>
