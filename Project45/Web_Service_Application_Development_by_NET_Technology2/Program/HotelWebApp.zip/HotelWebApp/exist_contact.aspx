<%@ Page Language="vb" AutoEventWireup="false" Codebehind="exist_contact.aspx.vb" Inherits="HotelWebApp.exist_contact"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>exist_contact</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="exist_contact" method="post" target="mainFrame" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:datagrid id=DataGrid1 style="Z-INDEX: 101; LEFT: 21px; POSITION: absolute; TOP: 84px" runat="server" PageSize="5" AutoGenerateColumns="False" DataSource="<%# DataTable1 %>" Font-Names="Microsoft Sans Serif" Font-Size="10pt"  CellPadding="0" Width="524px">
					<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="Bisque"></ItemStyle>
					<HeaderStyle Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#FFCCAE"></HeaderStyle>
					<Columns>
						<asp:BoundColumn DataField="Contact ID" SortExpression="Contact ID" HeaderText="Contact ID">
							<HeaderStyle Width="150px"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Contact Name" SortExpression="Contact Name" HeaderText="Contact Name">
							<HeaderStyle Width="450px"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="DeadLine" SortExpression="DeadLine" HeaderText="DeadLine">
							<HeaderStyle Width="150px"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Pay Date" SortExpression="Pay Date" HeaderText="Pay Date">
							<HeaderStyle Width="150px"></HeaderStyle>
						</asp:BoundColumn>
						<asp:ButtonColumn Text="Delete" ButtonType="PushButton" CommandName="Delete"></asp:ButtonColumn>
						<asp:ButtonColumn Text="View" ButtonType="PushButton" CommandName="Edit"></asp:ButtonColumn>
					</Columns>
				</asp:datagrid><asp:label id="lblHeader" style="Z-INDEX: 102; LEFT: 219px; POSITION: absolute; TOP: 47px" runat="server" Width="139px" Height="21px" BorderWidth="3px" BorderStyle="Ridge">��������´��õԴ��ͷ�����</asp:label></FONT></form>
	</body>
</HTML>
