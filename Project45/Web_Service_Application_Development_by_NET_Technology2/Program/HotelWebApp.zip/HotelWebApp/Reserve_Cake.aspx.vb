Public Class cakereserve
    Inherits System.Web.UI.Page
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlFlavour As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlSeminarRoomList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlCakeID As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cmdCakeReserve As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents txtHH As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMM As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblTimeRange As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents lblReserveDate As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents cmdCalPrice As System.Web.UI.WebControls.Button
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTotalPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlCakeamount As System.Web.UI.WebControls.DropDownList

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            Dim i As Integer
            Dim name As New HotelRef.HotelService0()
            Dim ContactID As Integer = Session.Contents("ContactID")
            Dim CSList() As HotelRef.CSeminarReserveInfo = name.Show_All_SeminarRoom_Info(ContactID)
            Dim strAdd As String
            cmdCalPrice.Visible = True
            cmdCakeReserve.Visible = True
            If CSList.Length = 0 Then
                lblError.Text = "!!! ��سҨͧʶҹ���Ѵ����§��͹"
                cmdCalPrice.Visible = False
                cmdCakeReserve.Visible = False
                Exit Sub
            End If
            For i = 0 To CSList.Length - 1
                strAdd = "��èͧ��� " & CSList(i).seminar_room_job_id & "  ��ͧ" & CSList(i).seminar_room_name
                Dim x As New ListItem()
                x.Text = CStr(strAdd)
                x.Value = CInt(CSList(i).seminar_room_job_id)
                ddlSeminarRoomList.Items.Add(x)
            Next i

            'Input Date and Time Range of Seminar Room Reservation
            lblTimeRange.Text = ""
            Dim find As New HotelRef.HotelService0()
            Dim SeminarJobID As Integer
            SeminarJobID = CInt(ddlSeminarRoomList.SelectedItem.Value)

            Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
            Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)

            lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
            Dim t1, t2, t3 As Integer
            t1 = find.Show_SeminarRoom_T1(SeminarJobID)
            t2 = find.Show_SeminarRoom_T2(SeminarJobID)
            t3 = find.Show_SeminarRoom_T3(SeminarJobID)
            If t1 = 1 Then
                lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t2 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t3 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If
        End If
    End Sub

    Private Sub ddlCakeID_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCakeID.SelectedIndexChanged
        'Clear All List
        ddlFlavour.Items.Clear()
        'Add New Value to List
        Dim i, CakeID As Integer
        CakeID = ddlCakeID.SelectedItem.Value()
        Dim Ref As New HotelRef.HotelService0()
        Dim Flavour() As String = Ref.Show_Cake_Flavour(CakeID)
        For i = 0 To Flavour.Length - 1
            ddlFlavour.Items.Add(Flavour(i))
        Next
    End Sub

    Private Sub cmdCakeReserve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCakeReserve.Click
        Dim flavour As String
        Dim cake_id As Integer
        Dim seminar_room_job_id As Integer
        Dim ContactID As Integer
        Dim cake_serve_time As String
        Dim cake_amount As Short
        Dim CustID As Integer

        CustID = Session.Contents("CustID")
        ContactID = Session.Contents("ContactID")
        cake_id = CInt(ddlCakeID.SelectedItem.Value)
        seminar_room_job_id = CInt(ddlSeminarRoomList.SelectedItem.Value)
        cake_amount = ddlCakeamount.SelectedItem.Value
        cake_serve_time = txtHH.Text & ":" & txtMM.Text & ":" & "00"
        flavour = ddlFlavour.SelectedItem.Value

        Dim Res As New HotelRef.HotelService0()
        Dim ret As HotelRef.CReturnReserve

        ret = Res.Reserve_Cake(CustID, flavour, cake_id, seminar_room_job_id, ContactID, cake_serve_time, cake_amount)
        If ret.str_error = "success" Then
            Dim str_ret As String
            Dim findName As New HotelRef.HotelService0()
            Dim JobName As String = findName.Show_SeminarRoom_Name(seminar_room_job_id)
            str_ret = "exist_job_inseminar.aspx?JobID=" & seminar_room_job_id & "&" & "JobName=" & JobName
            Response.Redirect(str_ret)
        Else
            lblError.Visible = True
            lblError.Text = "�������ö�ӡ�èͧ�� <br> ��سҵ�Ǩ�ͺ�������ա����"
        End If
    End Sub

    Private Sub ddlSeminarRoomList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSeminarRoomList.SelectedIndexChanged
        lblTimeRange.Text = ""
        Dim find As New HotelRef.HotelService0()
        Dim SeminarJobID As Integer
        SeminarJobID = CInt(ddlSeminarRoomList.SelectedItem.Value)

        Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
        Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)

        lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
        Dim t1, t2, t3 As Integer
        t1 = find.Show_SeminarRoom_T1(SeminarJobID)
        t2 = find.Show_SeminarRoom_T2(SeminarJobID)
        t3 = find.Show_SeminarRoom_T3(SeminarJobID)
        If t1 = 1 Then
            lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        If t2 = 1 Then
            lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        If t3 = 1 Then
            lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If
    End Sub

    Private Sub cmdCalPrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCalPrice.Click
        Dim customer_id As Integer
        Dim contact_id As Integer
        Dim cake_id As Integer
        Dim cake_amount As Integer

        customer_id = Session.Contents("CustID")
        contact_id = Session.Contents("ContactID")
        cake_id = ddlCakeID.SelectedItem.Value
        cake_amount = ddlCakeamount.SelectedItem.Value
        'Calculate Price
        Dim Price As New HotelRef.HotelService0()
        Dim PriceAll As Double = Price.Price_Reserve_Cake(customer_id, contact_id, cake_id, cake_amount)
        lblTotalPrice.Text = CStr(PriceAll)
    End Sub
End Class
