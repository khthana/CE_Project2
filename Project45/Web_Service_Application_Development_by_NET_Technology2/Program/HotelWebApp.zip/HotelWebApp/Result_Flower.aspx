<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Result_Flower.aspx.vb" Inherits="HotelWebApp.Result_Flower"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Result_Flower</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
			<asp:datagrid id=DataGrid1 style="Z-INDEX: 103; LEFT: 81px; POSITION: absolute; TOP: 72px" runat="server" Width="376px" BorderColor="Transparent" Font-Size="10pt" Font-Names="Microsoft Sans Serif" PageSize="5" AutoGenerateColumns="False" HorizontalAlign="Center" DataSource="<%# DataTable1 %>" CellPadding="0">
				<SelectedItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></SelectedItemStyle>
				<AlternatingItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></AlternatingItemStyle>
				<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="Bisque"></ItemStyle>
				<HeaderStyle Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#FFCCAE"></HeaderStyle>
				<Columns>
					<asp:BoundColumn DataField="��������´ᾡࡨ�͡���" SortExpression="��������´ᾡࡨ�͡���" HeaderText="��������´ᾡࡨ�͡���"></asp:BoundColumn>
				</Columns>
			</asp:datagrid>
			<asp:Label id="Label1" style="Z-INDEX: 104; LEFT: 222px; POSITION: absolute; TOP: 28px" runat="server" Width="97px" BorderWidth="3px" BorderStyle="Ridge" Height="17px">
				<center>���Ѿ���ä���</center>
			</asp:Label>
		</form>
	</body>
</HTML>
