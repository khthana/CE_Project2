Public Class left
    Inherits System.Web.UI.Page
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents cmdCancel As System.Web.UI.WebControls.Button
    Protected WithEvents cmdSignin As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents WebForm1 As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Page.IsPostBack Then
            Session.Clear()
        End If
    End Sub

    Private Sub cmdSignin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSignin.Click
        Dim username As String
        Dim password As String

        username = txtUsername.Text
        password = txtPassword.Text
        Dim chk As New CustomerRef.CustomerService0()

        Dim CustID As Int32
        CustID = chk.Login(username, password)
        If CustID <> 0 Then
            Session.Contents("CustID") = CustID
            Response.Redirect("index_signed.html")
        Else
            lblError.Visible = True
            lblError.Text = "<center>!!! ��� Login �Դ��Ҵ<bR>��سҡ�͡����������</center>"
        End If
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub
End Class
