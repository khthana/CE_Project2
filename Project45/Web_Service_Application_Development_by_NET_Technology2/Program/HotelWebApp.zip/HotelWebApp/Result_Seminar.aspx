<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Result_Seminar.aspx.vb" Inherits="HotelWebApp.Result_Seminar"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Result_Seminar</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<FONT face="Tahoma">
			<FORM id="Form1" method="post" runat="server">
				<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
					<asp:datagrid id=DataGrid1 style="Z-INDEX: 101; LEFT: 34px; POSITION: absolute; TOP: 79px" runat="server" Width="486px" Font-Size="10pt" Font-Names="Microsoft Sans Serif" PageSize="5" AutoGenerateColumns="False" HorizontalAlign="Center" BorderColor="Transparent" DataSource="<%# DataTable1 %>" CellPadding="0">
						<SelectedItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></SelectedItemStyle>
						<AlternatingItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></AlternatingItemStyle>
						<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="Bisque"></ItemStyle>
						<HeaderStyle Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#FFCCAE"></HeaderStyle>
						<Columns>
							<asp:BoundColumn DataField="�Ҿ��ͧ�Ѵ����§" SortExpression="�Ҿ��ͧ�Ѵ����§" HeaderText="�Ҿ��ͧ�Ѵ����§">
								<HeaderStyle Width="350px"></HeaderStyle>
							</asp:BoundColumn>
							<asp:BoundColumn DataField="��������´��ͧ" SortExpression="��������´��ͧ" HeaderText="��������´��ͧ">
								<HeaderStyle Width="250px"></HeaderStyle>
							</asp:BoundColumn>
						</Columns>
					</asp:datagrid>
					<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 236px; POSITION: absolute; TOP: 35px" runat="server" BorderWidth="3px" BorderStyle="Ridge" Height="17px" Width="97px">
						<center>���Ѿ���ä���</center>
					</asp:Label></FONT></FORM>
		</FONT>
	</body>
</HTML>
