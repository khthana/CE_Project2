<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Search_Food.aspx.vb" Inherits="HotelWebApp.Search_Food"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Search_Food</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
			<asp:Label id="Label1" style="Z-INDEX: 114; LEFT: 205px; POSITION: absolute; TOP: 33px" runat="server" Width="151px" Height="17px" BorderStyle="Ridge" BorderWidth="3px" BackColor="Transparent" ForeColor="Black">
				<center>����ᾤࡨ����èѴ����§</center>
			</asp:Label>
			<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 159px; POSITION: absolute; TOP: 82px" runat="server" Width="73px" Height="13px">�����������</asp:Label>
			<asp:DropDownList id="ddlFoodstyle" style="Z-INDEX: 103; LEFT: 241px; POSITION: absolute; TOP: 80px" runat="server" Font-Names="Microsoft Sans Serif">
				<asp:ListItem Value="THAI">��</asp:ListItem>
				<asp:ListItem Value="CHINESE">�չ</asp:ListItem>
				<asp:ListItem Value="INTERNATIONAL">�ҹҪҵ�</asp:ListItem>
				<asp:ListItem Value="COFFEE BREAK">�������ҧ</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label3" style="Z-INDEX: 104; LEFT: 153px; POSITION: absolute; TOP: 117px" runat="server" Width="74px">�ٻẺ��������</asp:Label>
			<asp:DropDownList id="ddlServeType" style="Z-INDEX: 105; LEFT: 241px; POSITION: absolute; TOP: 118px" runat="server" Font-Names="Microsoft Sans Serif">
				<asp:ListItem Value="buffet">�ؿ࿵�</asp:ListItem>
				<asp:ListItem Value="pertable">�Ѵ�����</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label4" style="Z-INDEX: 106; LEFT: 167px; POSITION: absolute; TOP: 155px" runat="server" Width="64px" Height="13px">�Ҥ������ҧ</asp:Label>
			<asp:TextBox id="txtMinPrice" style="Z-INDEX: 107; LEFT: 241px; POSITION: absolute; TOP: 154px" runat="server" Width="72px" MaxLength="5"></asp:TextBox>
			<asp:Label id="Label5" style="Z-INDEX: 108; LEFT: 322px; POSITION: absolute; TOP: 155px" runat="server">�֧</asp:Label>
			<asp:TextBox id="txtMaxPrice" style="Z-INDEX: 109; LEFT: 339px; POSITION: absolute; TOP: 154px" runat="server" Width="71px" MaxLength="5"></asp:TextBox>
			<asp:Label id="Label6" style="Z-INDEX: 110; LEFT: 419px; POSITION: absolute; TOP: 156px" runat="server">�ҷ</asp:Label>
			<asp:Label id="Label7" style="Z-INDEX: 111; LEFT: 81px; POSITION: absolute; TOP: 191px" runat="server" Width="147px">����÷���ͧ���������ᾤࡨ</asp:Label>
			<asp:TextBox id="txtFoodName" style="Z-INDEX: 112; LEFT: 241px; POSITION: absolute; TOP: 190px" runat="server" Width="169px" MaxLength="40"></asp:TextBox>
			<asp:Button id="cmdSearchFood" style="Z-INDEX: 113; LEFT: 241px; POSITION: absolute; TOP: 224px" runat="server" Text="�ӡ�ä���" Font-Names="Microsoft Sans Serif"></asp:Button>
		</form>
	</body>
</HTML>
