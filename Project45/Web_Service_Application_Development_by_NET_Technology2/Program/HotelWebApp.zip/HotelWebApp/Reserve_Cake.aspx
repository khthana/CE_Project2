<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Reserve_Cake.aspx.vb" Inherits="HotelWebApp.cakereserve"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>cakereserve</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:dropdownlist id="ddlCakeamount" style="Z-INDEX: 111; LEFT: 234px; POSITION: absolute; TOP: 243px" runat="server" Width="44px">
					<asp:ListItem Value="1">1</asp:ListItem>
					<asp:ListItem Value="2">2</asp:ListItem>
					<asp:ListItem Value="3">3</asp:ListItem>
					<asp:ListItem Value="4">4</asp:ListItem>
					<asp:ListItem Value="5">5</asp:ListItem>
					<asp:ListItem Value="6">6</asp:ListItem>
					<asp:ListItem Value="7">7</asp:ListItem>
					<asp:ListItem Value="8">8</asp:ListItem>
					<asp:ListItem Value="9">9</asp:ListItem>
				</asp:dropdownlist>
				<asp:label id="Label14" style="Z-INDEX: 126; LEFT: 154px; POSITION: absolute; TOP: 302px" runat="server" Width="70px" Height="8px">�Ҥҷ�����</asp:label>
				<asp:label id="lblTotalPrice" style="Z-INDEX: 120; LEFT: 232px; POSITION: absolute; TOP: 303px" runat="server" Width="81px" Height="18px" BackColor="#FFE0C0">0</asp:label>
				<asp:label id="Label13" style="Z-INDEX: 122; LEFT: 317px; POSITION: absolute; TOP: 304px" runat="server" Width="23px" Height="11px">�ҷ</asp:label>
				<asp:button id="cmdCalPrice" style="Z-INDEX: 125; LEFT: 208px; POSITION: absolute; TOP: 357px" runat="server" Width="78px" Height="24px" Font-Names="Microsoft Sans Serif" Text="�ʴ��Ҥ����"></asp:button>
				<asp:label id="lblError" style="Z-INDEX: 124; LEFT: 201px; POSITION: absolute; TOP: 329px" runat="server" Width="178px" Height="15px"></asp:label>
				<asp:label id="Label11" style="Z-INDEX: 121; LEFT: 250px; POSITION: absolute; TOP: 25px" runat="server" Width="54px" Height="7px" BorderWidth="3px" BorderStyle="Ridge">��觨ͧ��</asp:label><asp:label id="Label10" style="Z-INDEX: 119; LEFT: 178px; POSITION: absolute; TOP: 124px" runat="server" Width="40px" Font-Names="Microsoft Sans Serif" Height="14px" Font-Size="10pt">�ѹ���ͧ</asp:label><asp:label id="lblReserveDate" style="Z-INDEX: 104; LEFT: 233px; POSITION: absolute; TOP: 123px" runat="server" Width="271px" Height="18px"></asp:label><asp:label id="Label9" style="Z-INDEX: 106; LEFT: 152px; POSITION: absolute; TOP: 149px" runat="server" Width="67px" Height="21px">��ǧ���ҷ��ͧ</asp:label><asp:label id="lblTimeRange" style="Z-INDEX: 108; LEFT: 233px; POSITION: absolute; TOP: 150px" runat="server" Width="328px" Height="19px"></asp:label><asp:label id="Label4" style="Z-INDEX: 112; LEFT: 184px; POSITION: absolute; TOP: 58px" runat="server" Width="178px" ForeColor="Black">��¡�èͧ��ͧ����ҷ���ͧ���������</asp:label><asp:dropdownlist id="ddlSeminarRoomList" style="Z-INDEX: 100; LEFT: 155px; POSITION: absolute; TOP: 89px" runat="server" Width="253px" Font-Names="Microsoft Sans Serif" AutoPostBack="True"></asp:dropdownlist><asp:label id="Label2" style="Z-INDEX: 101; LEFT: 163px; POSITION: absolute; TOP: 182px" runat="server" Width="57px">��Դ�ͧ��</asp:label><asp:dropdownlist id="ddlCakeID" style="Z-INDEX: 102; LEFT: 234px; POSITION: absolute; TOP: 182px" runat="server" Width="129px" AutoPostBack="True">
					<asp:ListItem Value="1">chocolate fudge</asp:ListItem>
					<asp:ListItem Value="2">wedding bell</asp:ListItem>
					<asp:ListItem Value="3">white wedding</asp:ListItem>
					<asp:ListItem Value="4">sweety cake</asp:ListItem>
					<asp:ListItem Value="5">fruity nutty</asp:ListItem>
					<asp:ListItem Value="6">strawberry cream </asp:ListItem>
					<asp:ListItem Value="7">coffee lover</asp:ListItem>
					<asp:ListItem Value="8">vanilla cream</asp:ListItem>
					<asp:ListItem Value="9">banana cake</asp:ListItem>
					<asp:ListItem Value="10">almond chocolate</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label3" style="Z-INDEX: 103; LEFT: 171px; POSITION: absolute; TOP: 214px" runat="server" Width="52px">��������</asp:label><asp:dropdownlist id="ddlFlavour" style="Z-INDEX: 105; LEFT: 233px; POSITION: absolute; TOP: 212px" runat="server" Width="130px">
					<asp:ListItem Value="chocolate">chocolate</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label5" style="Z-INDEX: 107; LEFT: 169px; POSITION: absolute; TOP: 243px" runat="server" Width="57px">�ӹǹ��</asp:label><asp:label id="Label7" style="Z-INDEX: 109; LEFT: 299px; POSITION: absolute; TOP: 244px" runat="server">��͹</asp:label><asp:button id="cmdCakeReserve" style="Z-INDEX: 110; LEFT: 298px; POSITION: absolute; TOP: 357px" runat="server" Width="78px" Font-Names="Microsoft Sans Serif" Text="��ŧ" Height="24px"></asp:button><asp:label id="Label1" style="Z-INDEX: 113; LEFT: 152px; POSITION: absolute; TOP: 273px" runat="server" Width="61px" Height="15px">�����������</asp:label><asp:textbox id="txtHH" style="Z-INDEX: 114; LEFT: 233px; POSITION: absolute; TOP: 272px" runat="server" Width="45px" Height="22px"></asp:textbox><asp:label id="Label6" style="Z-INDEX: 115; LEFT: 283px; POSITION: absolute; TOP: 273px" runat="server" Width="28px" Height="20px">���ԡ�</asp:label><asp:textbox id="txtMM" style="Z-INDEX: 116; LEFT: 317px; POSITION: absolute; TOP: 272px" runat="server" Width="45px" Height="22px"></asp:textbox><asp:label id="Label8" style="Z-INDEX: 118; LEFT: 369px; POSITION: absolute; TOP: 274px" runat="server" Width="24px" Height="15px">�ҷ�</asp:label>
				<asp:Label id="Label12" style="Z-INDEX: 123; LEFT: 260px; POSITION: absolute; TOP: 391px" runat="server" Width="49px" Height="29px"></asp:Label></FONT></form>
	</body>
</HTML>
