Public Class Search_Food
    Inherits System.Web.UI.Page
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlFoodstyle As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents txtMaxPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMinPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSearchFood As System.Web.UI.WebControls.Button
    Protected WithEvents txtFoodName As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddlServeType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            txtMinPrice.Text = 0
            txtMaxPrice.Text = 5000
        End If
    End Sub

    Private Sub cmdSearchFood_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearchFood.Click
        'Get All Data From Page
        Dim FoodStyle As String
        Dim ServeType As String
        Dim MinPrice, MaxPrice As Double
        Dim FoodName As String

        'Set All Value 

        FoodStyle = ddlFoodstyle.SelectedItem.Value
        ServeType = ddlServeType.SelectedItem.Value
       
        MinPrice = CDbl(txtMinPrice.Text)
        MaxPrice = CDbl(txtMaxPrice.Text)

        FoodName = txtFoodName.Text

        Dim ret_str As String
        ret_str = "Result_Food.aspx?FoodStyle=" & FoodStyle & "&" & "ServeType=" & ServeType & "&" & "MinPrice=" & MinPrice & "&" & "MaxPrice=" & MaxPrice & "&" & "FoodName=" & FoodName
        Response.Redirect(ret_str)

    End Sub
End Class
