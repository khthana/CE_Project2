Public Class Result_Room
    Inherits System.Web.UI.Page
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents lblRoomType As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblRoomSize As System.Web.UI.WebControls.Label
    Protected WithEvents lblRoomPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Image2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Image1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        
        If Not Page.IsPostBack Then
            Dim r_amount As Integer = Convert.ToInt32(Request.QueryString("r_amount"))
            Dim r_type As String = Convert.ToString(Request.QueryString("r_type"))
            Dim r_size As Integer = Convert.ToInt32(Request.QueryString("r_size"))
            Dim r_price As Double = Convert.ToDouble(Request.QueryString("r_price"))
            Dim r_smoke As Integer = Convert.ToInt32(Request.QueryString("r_smoke"))
            Dim r_men As Integer = Convert.ToInt32(Request.QueryString("r_men"))
            Dim r_ex As Double = Convert.ToDouble(Request.QueryString("r_ex"))
            Dim tmp As String
            If r_type = "single" Then
                tmp = "��ͧ�����"
                Image1.ImageUrl = "Image/single1.jpg"
                Image2.ImageUrl = "Image/single2.jpg"
            End If
            If r_type = "twin" Then
                tmp = "��ͧ���"
                Image1.ImageUrl = "Image/twin1.jpg"
                Image2.ImageUrl = "Image/twin2.jpg"
            End If
            If r_type = "suite" Then
                tmp = "��ͧ�ش"
                Image1.ImageUrl = "Image/suite1.jpg"
                Image2.ImageUrl = "Image/suite2.jpg"
            End If

            lblRoomType.Text = tmp
            lblRoomSize.Text = r_size & "   ���ҧ����"
            lblRoomPrice.Text = r_price & "   �ҷ/�׹"
        End If
    End Sub

End Class