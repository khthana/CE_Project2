Public Class Pay
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdPay As System.Web.UI.WebControls.Button
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdShowPrice As System.Web.UI.WebControls.Button
    Protected WithEvents lblPrice As System.Web.UI.WebControls.Label
    Protected WithEvents ddlContact As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents txtCreditNumber As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtCreditPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents txtMonthExpired As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtYearExpired As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        'view All Contact not pay
        If Not Page.IsPostBack Then
            Dim CustID As Integer
            CustID = Session.Contents("CustID")
            Dim find As New HotelRef.HotelService0()
            Dim res() As HotelRef.CShowContactListResult = find.Show_ContactID_Notpay(CustID)
            Dim i As Integer
            For i = 0 To res.Length - 1
                Dim x As New ListItem()
                x.Text = res(i).hotel_contact_id & " " & res(i).hotel_contact_name
                x.Value = res(i).hotel_contact_id
                ddlContact.Items.Add(x)
            Next i
            txtCreditNumber.Text = "1234123412341234"
        End If
    End Sub

    Private Sub cmdShowPrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdShowPrice.Click
        Dim find As New BankRef.BankService0()
        Dim ContactID As Integer
        ContactID = ddlContact.SelectedItem.Value
        lblPrice.Text = CStr(find.TotalCost(ContactID))
    End Sub

    Private Sub cmdPay_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdPay.Click
        Dim pay As New BankRef.BankService0()
        Dim ContactID As Integer
        Dim accountID As String
        Dim creditcardNumber As String
        Dim expiredMonth As Integer
        Dim expiredYear As Integer
        Dim creditcardPassword As String

        ContactID = ddlContact.SelectedItem.Value
        accountID = "2225554446661201" ' olala hotel_0 account"
        creditcardNumber = txtCreditNumber.Text
        creditcardPassword = txtCreditPassword.Text
        expiredMonth = CInt(txtMonthExpired.Text)
        expiredYear = CInt(txtYearExpired.Text)
        Dim ret As Integer
        ret = pay.PayIt(ContactID, accountID, creditcardNumber, expiredMonth, expiredYear, creditcardPassword)
        Response.Redirect("exist_contact.aspx")
    End Sub

End Class
