<%@ Page Language="vb" AutoEventWireup="false" Codebehind="exist_job_inseminar.aspx.vb" Inherits="HotelWebApp.exist_job_inseminar"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>exist_job_inseminar</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server">
			<FONT class="#ecebd7" face="Tahoma" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
				<asp:label id="lblHeader" style="Z-INDEX: 102; LEFT: 199px; POSITION: absolute; TOP: 31px" runat="server" Height="15px" Font-Size="10pt" Font-Names="Microsoft Sans Serif" BorderColor="Transparent" Width="225px">
					<center>��������´��èͧ�ͧ��ͧ</center>
				</asp:label><FONT face="Microsoft Sans Serif">
					<asp:datagrid id=DataGrid1 style="Z-INDEX: 101; LEFT: 25px; POSITION: absolute; TOP: 117px" runat="server" Font-Size="10pt" Font-Names="Microsoft Sans Serif" BorderColor="Transparent" Width="557px" PageSize="5" AutoGenerateColumns="False" HorizontalAlign="Center" DataSource="<%# DataTable1 %>" CellPadding="0">
						<SelectedItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></SelectedItemStyle>
						<AlternatingItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></AlternatingItemStyle>
						<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="Bisque"></ItemStyle>
						<HeaderStyle Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#FFCCAE"></HeaderStyle>
						<Columns>
							<asp:BoundColumn DataField="Job Id" HeaderText="Job Id">
								<HeaderStyle Width="80pt"></HeaderStyle>
							</asp:BoundColumn>
							<asp:BoundColumn DataField="Job Name" HeaderText="Job Name">
								<HeaderStyle Width="250pt"></HeaderStyle>
							</asp:BoundColumn>
							<asp:BoundColumn DataField="Job Type" SortExpression="Job Type" HeaderText="Job Type">
								<HeaderStyle Width="180pt"></HeaderStyle>
							</asp:BoundColumn>
							<asp:BoundColumn DataField="Job Price" SortExpression="Job Price" HeaderText="Price">
								<HeaderStyle Width="150px"></HeaderStyle>
							</asp:BoundColumn>
							<asp:BoundColumn DataField="Pay Date" SortExpression="Pay Date" HeaderText="Pay Date">
								<HeaderStyle Width="130pt"></HeaderStyle>
							</asp:BoundColumn>
							<asp:ButtonColumn Text="Delete" ButtonType="PushButton" CommandName="Delete"></asp:ButtonColumn>
							<asp:ButtonColumn Text="View" ButtonType="PushButton" CommandName="Edit"></asp:ButtonColumn>
						</Columns>
					</asp:datagrid>
					<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 210px; POSITION: absolute; TOP: 59px" runat="server" Width="48px" Font-Names="Microsoft Sans Serif" Font-Size="10pt" Height="14px">�ѹ���ͧ</asp:Label>
					<asp:Label id="lblReserveDate" style="Z-INDEX: 104; LEFT: 266px; POSITION: absolute; TOP: 58px" runat="server" Width="205px" Height="18px"></asp:Label>
					<asp:Label id="Label2" style="Z-INDEX: 105; LEFT: 185px; POSITION: absolute; TOP: 85px" runat="server" Width="71px" Height="21px">��ǧ���ҷ��ͧ</asp:Label>
					<asp:Label id="lblTimeRange" style="Z-INDEX: 106; LEFT: 266px; POSITION: absolute; TOP: 85px" runat="server" Width="308px" Height="19px"></asp:Label></FONT></FONT>
		</form>
	</body>
</HTML>
