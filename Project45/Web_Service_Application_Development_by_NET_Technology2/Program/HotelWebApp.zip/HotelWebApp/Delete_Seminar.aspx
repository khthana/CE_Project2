<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Delete_Seminar.aspx.vb" Inherits="HotelWebApp.Delete_Seminar"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Delete_Seminar</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 105; LEFT: 178px; POSITION: absolute; TOP: 33px" runat="server" Width="148px" Height="15px" BorderWidth="3px" BorderStyle="Ridge">��������´��èͧ��ͧ�Ѵ����§</asp:label><asp:label id="Label7" style="Z-INDEX: 111; LEFT: 177px; POSITION: absolute; TOP: 186px" runat="server" Width="64px" Height="13px">�Ҥ���ͧ���</asp:label><asp:label id="lblPrice" style="Z-INDEX: 110; LEFT: 256px; POSITION: absolute; TOP: 187px" runat="server" Width="110px"></asp:label><asp:button id="cmdDelete" style="Z-INDEX: 107; LEFT: 146px; POSITION: absolute; TOP: 223px" runat="server" Width="95px" Height="23px" Font-Names="Microsoft Sans Serif" Text="ź��¡�ù��"></asp:button><asp:button id="cmdBack" style="Z-INDEX: 104; LEFT: 256px; POSITION: absolute; TOP: 222px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:button><asp:label id="lblReserveDate" style="Z-INDEX: 106; LEFT: 253px; POSITION: absolute; TOP: 97px" runat="server" Width="205px" Height="18px"></asp:label><asp:label id="lblTimeRange" style="Z-INDEX: 103; LEFT: 253px; POSITION: absolute; TOP: 122px" runat="server" Width="308px" Height="19px"></asp:label><asp:label id="Label2" style="Z-INDEX: 102; LEFT: 172px; POSITION: absolute; TOP: 122px" runat="server" Width="71px" Height="21px">��ǧ���ҷ��ͧ</asp:label><asp:label id="Label3" style="Z-INDEX: 101; LEFT: 197px; POSITION: absolute; TOP: 96px" runat="server" Width="48px" Height="14px" Font-Size="10pt" Font-Names="Microsoft Sans Serif">�ѹ���ͧ</asp:label><asp:label id="Label4" style="Z-INDEX: 108; LEFT: 168px; POSITION: absolute; TOP: 69px" runat="server" Width="68px" Height="15px">������ͧ�Ѵ����§</asp:label><asp:label id="lblHeader" style="Z-INDEX: 109; LEFT: 253px; POSITION: absolute; TOP: 68px" runat="server" Width="176px" Height="21px"></asp:label><asp:label id="Label5" style="Z-INDEX: 112; LEFT: 172px; POSITION: absolute; TOP: 152px" runat="server" Width="66px" Height="15px">�ٻẺʶҹ���</asp:label><asp:label id="lblPlaceStyle" style="Z-INDEX: 113; LEFT: 254px; POSITION: absolute; TOP: 153px" runat="server" Width="109px" Height="19px"></asp:label></FONT></form>
	</body>
</HTML>
