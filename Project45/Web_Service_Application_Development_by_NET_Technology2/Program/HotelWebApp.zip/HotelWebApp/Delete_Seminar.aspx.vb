Public Class Delete_Seminar
    Inherits System.Web.UI.Page
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTimeRange As System.Web.UI.WebControls.Label
    Protected WithEvents lblReserveDate As System.Web.UI.WebControls.Label
    Protected WithEvents cmdBack As System.Web.UI.WebControls.Button
    Protected WithEvents cmdDelete As System.Web.UI.WebControls.Button
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents lblHeader As System.Web.UI.WebControls.Label
    Protected WithEvents lblPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPlaceStyle As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            Dim ContactID, CustID, SeminarJobID As Integer
            ContactID = Session.Contents("ContactID")
            CustID = System.Convert.ToInt32(Session.Contents("CustID"))
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("SeminarJobID"))

            Dim find As New HotelRef.HotelService0()
            Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
            Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)
            lblHeader.Text = "��ͧ" & seminar_name
            lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
            Dim t1, t2, t3 As Integer
            t1 = find.Show_SeminarRoom_T1(SeminarJobID)
            t2 = find.Show_SeminarRoom_T2(SeminarJobID)
            t3 = find.Show_SeminarRoom_T3(SeminarJobID)
            If t1 = 1 Then
                lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t2 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t3 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            Dim find2 As New HotelRef.HotelService0()
            Dim SeminarList As New HotelRef.CSeminarRoomReservationList()
            SeminarList = find2.Show_Reserved_Seminarroom(SeminarJobID)
            lblPrice.Text = CStr(SeminarList.job_total_price)
            Dim tmp As String
            tmp = SeminarList.place_style
            If tmp = "poolside" Then
                lblPlaceStyle.Text = "�ҹ���������¹��"
            End If
            If tmp = "room" Then
                lblPlaceStyle.Text = "��ͧ�Ѵ����§"
            End If
            If tmp = "garden" Then
                lblPlaceStyle.Text = "�ҹ��ǹ"
            End If
        End If
    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
        Response.Redirect("exist_job.aspx")
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        'Delete It
        Dim del As New HotelRef.HotelService0()
        Dim CustID, ContactID, SeminarJobID As Integer

        CustID = Session.Contents("CustID")
        ContactID = Session.Contents("ContactID")
        SeminarJobID = Request.QueryString("SeminarJobID")
        del.Cancel_Seminar_Reservation(CustID, ContactID, SeminarJobID)

        'Redirect Back
        Response.Redirect("exist_job.aspx")
    End Sub
End Class
