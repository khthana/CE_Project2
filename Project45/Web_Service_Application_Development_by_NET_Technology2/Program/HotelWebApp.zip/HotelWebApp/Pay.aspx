<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Pay.aspx.vb" Inherits="HotelWebApp.Pay" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Pay</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server" target="index2_RFrame">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 101; LEFT: 217px; POSITION: absolute; TOP: 38px" runat="server" Height="3px" Width="131px" BorderStyle="Ridge" BorderWidth="3px">
					<center>�����Թ��ҹ�ѵ��ôԵ</center>
				</asp:label>
				<asp:Label id="Label8" style="Z-INDEX: 114; LEFT: 156px; POSITION: absolute; TOP: 240px" runat="server" Width="101px" Height="1px">��������� �ѵ��ôԵ</asp:Label><asp:label id="Label2" style="Z-INDEX: 102; LEFT: 187px; POSITION: absolute; TOP: 79px" runat="server" Height="8px" Width="197px">��س��к� Contact ����ͧ��ê����Թ</asp:label><asp:dropdownlist id="ddlContact" style="Z-INDEX: 103; LEFT: 185px; POSITION: absolute; TOP: 108px" runat="server" Height="24px" Width="194px" Font-Names="Microsoft Sans Serif"></asp:dropdownlist><asp:button id="cmdPay" style="Z-INDEX: 104; LEFT: 289px; POSITION: absolute; TOP: 312px" runat="server" Height="24px" Width="78px" Font-Names="Microsoft Sans Serif" Text="�����Թ"></asp:button><asp:label id="Label3" style="Z-INDEX: 105; LEFT: 165px; POSITION: absolute; TOP: 271px" runat="server" Height="21px" Width="93px">�ʹ�Թ���������</asp:label><asp:button id="cmdShowPrice" style="Z-INDEX: 106; LEFT: 202px; POSITION: absolute; TOP: 312px" runat="server" Height="24px" Width="78px" Font-Names="Microsoft Sans Serif" Text="�ʴ��Ҥ����"></asp:button><asp:label id="lblPrice" style="Z-INDEX: 107; LEFT: 273px; POSITION: absolute; TOP: 275px" runat="server" Height="19px" Width="94px" BackColor="#FFE0C0"></asp:label><asp:label id="Label5" style="Z-INDEX: 108; LEFT: 373px; POSITION: absolute; TOP: 270px" runat="server" Height="1px" Width="2px">�ҷ</asp:label>
				<asp:Label id="Label4" style="Z-INDEX: 109; LEFT: 128px; POSITION: absolute; TOP: 147px" runat="server" Width="132px" Height="2px">��س���������Ţ�ѵ��ôԵ</asp:Label>
				<asp:Label id="Label6" style="Z-INDEX: 110; LEFT: 128px; POSITION: absolute; TOP: 177px" runat="server" Width="130px" Height="6px">��س�������ʼ�ҹ�ѵ��ôԵ</asp:Label>
				<asp:TextBox id="txtCreditNumber" style="Z-INDEX: 111; LEFT: 273px; POSITION: absolute; TOP: 145px" runat="server" Width="163px" Height="23px"></asp:TextBox>
				<asp:TextBox id="txtCreditPassword" style="Z-INDEX: 112; LEFT: 273px; POSITION: absolute; TOP: 175px" runat="server" Width="163px" Height="24px" TextMode="Password"></asp:TextBox>
				<asp:Label id="Label7" style="Z-INDEX: 113; LEFT: 141px; POSITION: absolute; TOP: 211px" runat="server" Width="116px" Height="2px">��͹������� �ѵ��ôԵ</asp:Label>
				<asp:TextBox id="txtMonthExpired" style="Z-INDEX: 115; LEFT: 272px; POSITION: absolute; TOP: 207px" runat="server" Width="94px" Height="24px"></asp:TextBox>
				<asp:TextBox id="txtYearExpired" style="Z-INDEX: 116; LEFT: 272px; POSITION: absolute; TOP: 239px" runat="server" Width="94px" Height="24px"></asp:TextBox></FONT></form>
	</body>
</HTML>
