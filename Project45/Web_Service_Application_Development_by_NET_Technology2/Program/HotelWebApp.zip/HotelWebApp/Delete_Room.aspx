<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Delete_Room.aspx.vb" Inherits="HotelWebApp.Delete_Room"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Delete_Room</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<FONT face="Tahoma">
			<FORM id="Form1" method="post" target="index2_RFrame" runat="server">
				<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
					<asp:Label id="Label5" style="Z-INDEX: 110; LEFT: 189px; POSITION: absolute; TOP: 95px" runat="server" Width="45px" Height="9px">��Դ��ͧ</asp:Label>
					<asp:Button id="cmdDelete" style="Z-INDEX: 118; LEFT: 143px; POSITION: absolute; TOP: 247px" runat="server" Width="95px" Height="23px" Font-Names="Microsoft Sans Serif" Text="ź��¡�ù��"></asp:Button>
					<asp:Label id="Label1" style="Z-INDEX: 115; LEFT: 187px; POSITION: absolute; TOP: 32px" runat="server" Width="129px" Height="15px" BorderStyle="Ridge" BorderWidth="3px">��������´��èͧ��ͧ�ѡ</asp:Label>
					<asp:Label id="Label6" style="Z-INDEX: 109; LEFT: 183px; POSITION: absolute; TOP: 122px" runat="server" Width="47px" Height="19px">��Ҵ��ͧ</asp:Label>
					<asp:Button id="cmdBack" style="Z-INDEX: 108; LEFT: 249px; POSITION: absolute; TOP: 247px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:Button>
					<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 169px; POSITION: absolute; TOP: 68px" runat="server" Width="65px" Height="15px">�����Ţ��ͧ</asp:Label>
					<asp:Label id="Label3" style="Z-INDEX: 103; LEFT: 158px; POSITION: absolute; TOP: 179px" runat="server" Width="82px" Height="2px">�ѹ��� Check in</asp:Label>
					<asp:Label id="Label4" style="Z-INDEX: 104; LEFT: 153px; POSITION: absolute; TOP: 210px" runat="server" Width="88px" Height="1px">�ѹ��� Check out</asp:Label>
					<asp:Label id="lblRoomNo" style="Z-INDEX: 105; LEFT: 252px; POSITION: absolute; TOP: 67px" runat="server" Width="106px" Height="17px"></asp:Label>
					<asp:Label id="lblCheckin" style="Z-INDEX: 106; LEFT: 252px; POSITION: absolute; TOP: 179px" runat="server" Width="191px" Height="1px"></asp:Label>
					<asp:Label id="lblCheckout" style="Z-INDEX: 107; LEFT: 252px; POSITION: absolute; TOP: 210px" runat="server" Width="191px" Height="8px"></asp:Label>
					<asp:Label id="lblRoomType" style="Z-INDEX: 111; LEFT: 252px; POSITION: absolute; TOP: 95px" runat="server" Width="103px" Height="11px"></asp:Label>
					<asp:Label id="lblRoomSize" style="Z-INDEX: 112; LEFT: 252px; POSITION: absolute; TOP: 122px" runat="server" Width="112px" Height="14px"></asp:Label>
					<asp:Label id="Label7" style="Z-INDEX: 113; LEFT: 169px; POSITION: absolute; TOP: 150px" runat="server" Width="64px" Height="13px">�Ҥ���ͧ���</asp:Label>
					<asp:Label id="lblPrice" style="Z-INDEX: 114; LEFT: 252px; POSITION: absolute; TOP: 150px" runat="server" Width="110px"></asp:Label></FONT></FORM>
		</FONT>
	</body>
</HTML>
