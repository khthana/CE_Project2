Public Class seminarreserve
    Inherits System.Web.UI.Page
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlTablelayout As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlSeminarroomname As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents cbxT6to11pm As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbxT6to11am As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Label16 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Calendar1 As System.Web.UI.WebControls.Calendar
    Protected WithEvents cmdCalPrice As System.Web.UI.WebControls.Button
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTotalPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlDecStyle As System.Web.UI.WebControls.DropDownList
    Protected WithEvents cbxT12to5pm As System.Web.UI.WebControls.CheckBox
    Protected WithEvents txtMenPerRoom As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdReserveSeminar As System.Web.UI.WebControls.Button
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents searchroom As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            Calendar1.SelectedDate = DateTime.Now
            txtMenPerRoom.Text = 0
            cbxT6to11am.Checked = True
            'for i = 0 to 
            'ddlSeminarroomname.Items.Add("")
        End If
    End Sub

    Private Sub cmdCalPrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCalPrice.Click
        Dim customer_id As Integer
        Dim hotel_contact_id As Integer
        Dim seminar_room_id As Integer
        Dim dec_style As String
        Dim Sreserve_date As String
        Dim t6to11am, t12to5pm, t6to11pm As Integer
        Dim men_per_room As Integer
        Dim table_layout As String

        Dim Price As New HotelRef.HotelService0()
        Dim StrPrice As String

        'Get Value from Form
        customer_id = Session.Contents("CustID")
        hotel_contact_id = Session.Contents("ContactID")

        seminar_room_id = CInt(ddlSeminarroomname.SelectedItem.Value)
        dec_style = CStr(ddlDecStyle.SelectedItem.Value)

        Dim tmp1 As Date
        tmp1 = Calendar1.SelectedDate
        ' Manage DateTime
        Dim dd1, mm1 As String
        If (tmp1.Day >= 1 And tmp1.Day <= 9) Then
            dd1 = "0" & tmp1.Day
        Else
            dd1 = tmp1.Day
        End If

        If (tmp1.Month >= 1 And tmp1.Month <= 9) Then
            mm1 = "0" & tmp1.Month
        Else
            mm1 = tmp1.Month
        End If
        Sreserve_date = dd1 & " " & mm1 & " " & tmp1.Year
        If cbxT6to11am.Checked Then
            t6to11am = 1
        Else
            t6to11am = 0
        End If
        If cbxT12to5pm.Checked Then
            t12to5pm = 1
        Else
            t12to5pm = 0
        End If
        If cbxT6to11pm.Checked Then
            t6to11pm = 1
        Else
            t6to11pm = 0
        End If

        men_per_room = CInt(txtMenPerRoom.Text)
        table_layout = ddlTablelayout.SelectedItem.Value

        StrPrice = CStr(Price.Price_Reserve_Seminar_Room(customer_id, hotel_contact_id, seminar_room_id, dec_style, Sreserve_date, t6to11am, t12to5pm, t6to11pm, men_per_room, table_layout))
        lblTotalPrice.Text = StrPrice
    End Sub

 
    Private Sub cmdReserveSeminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReserveSeminar.Click
        'Check Date FIRST!
        If Calendar1.SelectedDate <= DateTime.Now Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If lblTotalPrice.Text = "0" Then
            lblError.Text = ""
            lblError.Text = "!!! �Ҥ�����Դ��Ҵ �ô��Ǩ�ͺ������"
            Exit Sub
        End If
        Dim customer_id As Integer
        Dim hotel_contact_id As Integer
        Dim seminar_room_id As Integer
        Dim dec_style As String
        Dim Sreserve_date As String
        Dim t6to11am, t12to5pm, t6to11pm As Integer
        Dim men_per_room As Integer
        Dim table_layout As String

        Dim StrPrice As String

        'Get Value from Form
        customer_id = Session.Contents("CustID")
        hotel_contact_id = Session.Contents("ContactID")

        seminar_room_id = CInt(ddlSeminarroomname.SelectedItem.Value)
        dec_style = CStr(ddlDecStyle.SelectedItem.Value)

        Dim tmp1 As Date
        tmp1 = Calendar1.SelectedDate
        ' Manage DateTime
        Dim dd1, mm1 As String
        If (tmp1.Day >= 1 And tmp1.Day <= 9) Then
            dd1 = "0" & tmp1.Day
        Else
            dd1 = tmp1.Day
        End If

        If (tmp1.Month >= 1 And tmp1.Month <= 9) Then
            mm1 = "0" & tmp1.Month
        Else
            mm1 = tmp1.Month
        End If
        Sreserve_date = dd1 & " " & mm1 & " " & tmp1.Year
        If cbxT6to11am.Checked Then
            t6to11am = 1
        Else
            t6to11am = 0
        End If
        If cbxT12to5pm.Checked Then
            t12to5pm = 1
        Else
            t12to5pm = 0
        End If
        If cbxT6to11pm.Checked Then
            t6to11pm = 1
        Else
            t6to11pm = 0
        End If

        men_per_room = CInt(txtMenPerRoom.Text)
        table_layout = ddlTablelayout.SelectedItem.Value
        If (t6to11am + t12to5pm + t6to11pm = 0) Then

        Else

            'Reserve Seminar Room
            Dim Reserve As New HotelRef.HotelService0()
            Dim ReturnReserve As HotelRef.CReturnReserve = Reserve.Reserve_Seminar_Room(customer_id, hotel_contact_id, seminar_room_id, dec_style, Sreserve_date, t6to11am, t12to5pm, t6to11pm, men_per_room, table_layout)

            Dim i As Integer
            Dim deadline As String
            Dim price As Double
            Dim job_id As Integer
            Dim str_error As String

            job_id = ReturnReserve.job_id
            price = ReturnReserve.price
            deadline = ReturnReserve.deadline
            str_error = ReturnReserve.str_error
            If str_error = "success" Then
                Response.Redirect("exist_job.aspx")
            End If
        End If
    End Sub
End Class
