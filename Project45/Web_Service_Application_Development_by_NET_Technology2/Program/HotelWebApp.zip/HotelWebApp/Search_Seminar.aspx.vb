Public Class Search_Seminar
    Inherits System.Web.UI.Page
    Protected WithEvents ddlTablelayout As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents cbxT6to11pm As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbxT12to5pm As System.Web.UI.WebControls.CheckBox
    Protected WithEvents cbxT6to11am As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Calendar1 As System.Web.UI.WebControls.Calendar
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlPlaceStyle As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Label17 As System.Web.UI.WebControls.Label
    Protected WithEvents Label18 As System.Web.UI.WebControls.Label
    Protected WithEvents txtMaxSize As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMinSize As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMinPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMaxPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label19 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdSearchSeminar As System.Web.UI.WebControls.Button
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            txtMinSize.Text = 0
            txtMaxSize.Text = 300
            txtMinPrice.Text = 0
            txtMaxPrice.Text = 50000
            cbxT6to11am.Checked = True
            Calendar1.SelectedDate = DateTime.Now
        End If
    End Sub

    Private Sub cmdSearchSeminar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearchSeminar.Click
        'Check Date FIRST!
        If Calendar1.SelectedDate <= DateTime.Now Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        'Get All Data From Page
        Dim Place_Style As String
        Dim Sreserve_date As String
        Dim MinSize, MaxSize As Integer
        Dim MinPrice, MaxPrice As Double
        Dim TRange1, TRange2, TRange3 As Integer

        'Set All Value 

        Place_Style = CStr(ddlPlaceStyle.SelectedItem.Value)

        Dim tmp1, tmp2 As Date
        tmp1 = Calendar1.SelectedDate

        'Reserve DateTime
        Dim dd1, mm1 As String
        If (tmp1.Day >= 1 And tmp1.Day <= 9) Then
            dd1 = "0" & tmp1.Day
        Else
            dd1 = tmp1.Day
        End If

        If (tmp1.Month >= 1 And tmp1.Month <= 9) Then
            mm1 = "0" & tmp1.Month
        Else
            mm1 = tmp1.Month
        End If
        Sreserve_date = dd1 & " " & mm1 & " " & tmp1.Year

        'Time Range 1-3
        If cbxT6to11am.Checked = True Then
            TRange1 = 1
        Else
            TRange1 = 0
        End If

        If cbxT12to5pm.Checked = True Then
            TRange2 = 1
        Else
            TRange2 = 0
        End If

        If cbxT6to11pm.Checked = True Then
            TRange3 = 1
        Else
            TRange3 = 0
        End If

        MinSize = CInt(txtMinSize.Text)
        MaxSize = CInt(txtMaxSize.Text)

        MinPrice = CDbl(txtMinPrice.Text)
        MaxPrice = CDbl(txtMaxPrice.Text)

        Dim ret_str As String
        ret_str = "Result_Seminar.aspx?PlaceStyle=" & Place_Style & "&" & "SReserveDate=" & Sreserve_date & "&" & " MinSize=" & MinSize & "&" & "MaxSize=" & MaxSize & "&" & "MinPrice=" & MinPrice & "&" & "MaxPrice=" & MaxPrice & "&" & "TRange1=" & TRange1 & "&" & "TRange2=" & TRange2 & "&" & "TRange3=" & TRange3
        Response.Redirect(ret_str)

    End Sub

End Class
