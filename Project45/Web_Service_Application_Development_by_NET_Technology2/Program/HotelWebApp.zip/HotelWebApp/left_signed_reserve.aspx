<%@ Page Language="vb" AutoEventWireup="false" Codebehind="left_signed_reserve.aspx.vb" Inherits="HotelWebApp.left_signed_reserve"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>left_signed_reserve</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
		<STYLE type="text/css">A:link { COLOR: #494949; TEXT-DECORATION: none }
	A:visited { COLOR: #494949; TEXT-DECORATION: none }
	A:hover { COLOR: #a18355; TEXT-DECORATION: none }
	A.d { FONT-WEIGHT: bold; FONT-SIZE: 12px; COLOR: #494949; FONT-FAMILY: verdana; TEXT-DECORATION: none }
	A.d:visited { FONT-WEIGHT: bold; FONT-SIZE: 12px; COLOR: #494949; FONT-FAMILY: verdana; TEXT-DECORATION: none }
		</STYLE>
		<SCRIPT language="JavaScript">
<!--
var OldColor;
function popNewWin (strDest,strWidth,strHeight) {
newWin = window.open(strDest,"popup","toolbar=no,scrollbars=yes,resizable=yes,width=" + strWidth + ",height=" + strHeight);
}
function mOvr(src,clrOver) {
if (!src.contains(event.fromElement)) {
src.style.cursor = 'hand';
OldColor = src.bgColor;
src.bgColor = clrOver;
}
}
function mOut(src) {
if (!src.contains(event.toElement)) {
src.style.cursor = 'default';
src.bgColor = OldColor;
}
}
function mClk(src) {
if(event.srcElement.tagName=='TD') {
src.children.tags('A')[0].click();
}
}
//-->
		</SCRIPT>
	</HEAD>
	<body text="#000000" bgColor="#ffffff" leftMargin="0" topMargin="0" MS_POSITIONING="GridLayout" marginheight="0" marginwidth="0">
		<form id="left_signed_reserv" method="post" runat="server">
			<TABLE id="Table1" style="Z-INDEX: 101; LEFT: 9px; WIDTH: 139px; POSITION: absolute; TOP: 12px; HEIGHT: 140px" runat="server">
				<tr>
					<td>
						<img src="http://161.246.6.123/HotelWebApp/Image/hotel_cairo_lg.jpg" width="132" height="80">
					</td>
				</tr>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="index_signed.html" target="mainFrame"><B>����¹ Contact �Ѩ�غѹ</B></A></FONT>
					</TD>
				</TR>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="exist_job.aspx" target="index2_RFrame"><B>�٢����š�èͧ������</B></A></FONT>
					</TD>
				</TR>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="140" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="Reserve_Room.aspx" target="index2_RFrame"><B>�ͧ��ͧ�ѡ </B></A></FONT>
					</TD>
				</TR>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="Reserve_Seminar.aspx" target="index2_RFrame"><B>�ͧʶҹ���Ѵ����§ </B></A>
						</FONT>
					</TD>
				</TR>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="Reserve_Cake.aspx" target="index2_RFrame"><B>��觨ͧ��</B></A></FONT>
					</TD>
				</TR>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="Reserve_Food.aspx" target="index2_RFrame"><B>��觨ͧ�����</B></A></FONT>
					</TD>
				</TR>
				<TR bgColor="#ecebd7">
					<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="Reserve_Flower.aspx" target="index2_RFrame"><B>��觨ͧ�͡���</B></A></FONT>
					</TD>
				</TR>
				<TR bgColor="#A08455">
					<TD onmouseover="mOvr(this,'#A08455');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="140" height="20"><FONT face="MS Sans Serif" size="1">
							<A href="index2.html" target="mainFrame"><B><font color="ffffff">�͡�ҡ�к�</font></B></A>
						</FONT>
					</TD>
				</TR>
			</TABLE>
		</form>
	</body>
</HTML>
