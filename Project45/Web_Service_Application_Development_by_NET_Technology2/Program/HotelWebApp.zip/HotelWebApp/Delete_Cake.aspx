<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Delete_Cake.aspx.vb" Inherits="HotelWebApp.Delete_Cake"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Delete_Cake</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<FORM id="Form1" method="post" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:label id="Label2" style="Z-INDEX: 101; LEFT: 175px; POSITION: absolute; TOP: 63px" runat="server" Height="15px" Width="65px">��ͧ�Ѵ����§</asp:label>
				<asp:label id="Label1" style="Z-INDEX: 117; LEFT: 204px; POSITION: absolute; TOP: 28px" runat="server" Height="15px" Width="109px" BorderStyle="Ridge" BorderWidth="3px">��������´��èͧ��</asp:label>
				<asp:label id="Label3" style="Z-INDEX: 102; LEFT: 168px; POSITION: absolute; TOP: 225px" runat="server" Height="2px" Width="66px"> �����������</asp:label>
				<asp:label id="lblSeminarRoom" style="Z-INDEX: 103; LEFT: 256px; POSITION: absolute; TOP: 62px" runat="server" Height="6px" Width="106px"></asp:label>
				<asp:label id="lblServeTime" style="Z-INDEX: 104; LEFT: 257px; POSITION: absolute; TOP: 225px" runat="server" Height="1px" Width="149px"></asp:label>
				<asp:button id="cmdBack" style="Z-INDEX: 105; LEFT: 279px; POSITION: absolute; TOP: 260px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:button>
				<asp:label id="Label5" style="Z-INDEX: 106; LEFT: 189px; POSITION: absolute; TOP: 93px" runat="server" Height="9px" Width="38px">��Դ��</asp:label>
				<asp:label id="Label6" style="Z-INDEX: 107; LEFT: 181px; POSITION: absolute; TOP: 117px" runat="server" Height="16px" Width="48px">��������</asp:label>
				<asp:label id="Label10" style="Z-INDEX: 108; LEFT: 184px; POSITION: absolute; TOP: 142px" runat="server" Height="1px" Width="45px">��Ҵ��</asp:label>
				<asp:label id="Label11" style="Z-INDEX: 109; LEFT: 165px; POSITION: absolute; TOP: 167px" runat="server" Height="4px" Width="65px">�ӹǹ�����</asp:label>
				<asp:label id="lblCakeStyle" style="Z-INDEX: 110; LEFT: 256px; POSITION: absolute; TOP: 90px" runat="server" Height="5px" Width="119px"></asp:label>
				<asp:label id="lblCakeFlavour" style="Z-INDEX: 111; LEFT: 256px; POSITION: absolute; TOP: 116px" runat="server" Height="3px" Width="132px"></asp:label>
				<asp:label id="lblCakeSize" style="Z-INDEX: 112; LEFT: 256px; POSITION: absolute; TOP: 142px" runat="server" Height="19px" Width="91px"></asp:label>
				<asp:label id="lblCakeLayer" style="Z-INDEX: 113; LEFT: 256px; POSITION: absolute; TOP: 166px" runat="server" Height="12px" Width="109px"></asp:label>
				<asp:label id="Label4" style="Z-INDEX: 114; LEFT: 185px; POSITION: absolute; TOP: 200px" runat="server" Height="12px" Width="44px">�Ҥ����</asp:label>
				<asp:label id="lblPrice" style="Z-INDEX: 115; LEFT: 257px; POSITION: absolute; TOP: 199px" runat="server" Height="6px" Width="110px"></asp:label>
				<asp:Label id="Label7" style="Z-INDEX: 116; LEFT: 235px; POSITION: absolute; TOP: 330px" runat="server" Height="24px" Width="48px"></asp:Label>
				<asp:Button id="cmdDelete" style="Z-INDEX: 118; LEFT: 171px; POSITION: absolute; TOP: 261px" runat="server" Height="23px" Width="95px" Font-Names="Microsoft Sans Serif" Text="ź��¡�ù��"></asp:Button></FONT></FORM>
	</body>
</HTML>
