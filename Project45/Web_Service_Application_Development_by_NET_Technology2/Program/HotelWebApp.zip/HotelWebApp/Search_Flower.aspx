<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Search_Flower.aspx.vb" Inherits="HotelWebApp.Search_Flower"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Search_Flower</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
				<asp:dropdownlist id="ddlSeminarroomname" style="Z-INDEX: 110; LEFT: 247px; POSITION: absolute; TOP: 75px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="1">��Ҿ����</asp:ListItem>
					<asp:ListItem Value="2">garden bar</asp:ListItem>
					<asp:ListItem Value="3">����ͧ</asp:ListItem>
					<asp:ListItem Value="4">��⢷��</asp:ListItem>
					<asp:ListItem Value="5">�ѵ���Թ���</asp:ListItem>
					<asp:ListItem Value="6">��ظ��</asp:ListItem>
					<asp:ListItem Value="7">������1</asp:ListItem>
					<asp:ListItem Value="8">������2</asp:ListItem>
					<asp:ListItem Value="9">������3</asp:ListItem>
				</asp:dropdownlist>
				<asp:Label id="Label1" style="Z-INDEX: 115; LEFT: 204px; POSITION: absolute; TOP: 31px" runat="server" BorderWidth="3px" BorderStyle="Ridge" Height="5px" Width="115px">
					<center>����ᾡࡨ�͡���</center>
				</asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 107; LEFT: 354px; POSITION: absolute; TOP: 142px" runat="server" Width="29px">�ҷ</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 101; LEFT: 182px; POSITION: absolute; TOP: 108px" runat="server" Width="52px" Height="3px">�Ҥҵ���ش</asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 102; LEFT: 183px; POSITION: absolute; TOP: 139px" runat="server" Width="52px" Height="4px">�Ҥ��٧�ش</asp:Label>
				<asp:TextBox id="txtMinPrice" style="Z-INDEX: 103; LEFT: 246px; POSITION: absolute; TOP: 108px" runat="server" Width="92px" Height="23px"></asp:TextBox>
				<asp:TextBox id="txtMaxPrice" style="Z-INDEX: 104; LEFT: 246px; POSITION: absolute; TOP: 139px" runat="server" Width="94px" Height="24px"></asp:TextBox>
				<asp:Button id="cmdSearch" style="Z-INDEX: 105; LEFT: 218px; POSITION: absolute; TOP: 187px" runat="server" Width="90px" Text="�ӡ�ä���" Font-Names="Microsoft Sans Serif"></asp:Button>
				<asp:Label id="Label4" style="Z-INDEX: 106; LEFT: 353px; POSITION: absolute; TOP: 110px" runat="server" Width="29px">�ҷ</asp:Label>
				<asp:Label id="label9" style="Z-INDEX: 109; LEFT: 133px; POSITION: absolute; TOP: 77px" runat="server" Width="101px">��ͧ�Ѵ����§����ͧ���</asp:Label></FONT>
		</form>
	</body>
</HTML>
