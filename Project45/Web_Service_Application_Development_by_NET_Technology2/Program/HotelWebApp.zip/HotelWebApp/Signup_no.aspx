<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Signup_no.aspx.vb" Inherits="HotelWebApp.Signup_no"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Signup_no</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server" target="index2_RFrame">
			<FONT style="FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 166px; POSITION: absolute; TOP: 79px" runat="server" Font-Size="13pt" Height="20px" Width="169px">�����Ѥ���Ҫԡ�Դ��Ҵ</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 101; LEFT: 169px; POSITION: absolute; TOP: 127px" runat="server" Font-Size="10pt" Height="8px" Width="164px">��سҵ�Ǩ�ͺ�����ŷ���͡�ա����</asp:Label>
				<asp:Button id="cmdBack" style="Z-INDEX: 103; LEFT: 194px; POSITION: absolute; TOP: 175px" runat="server" Width="105px" Height="24px" Text="��Ѻ˹�� Sign Up" Font-Names="Microsoft Sans Serif"></asp:Button></FONT>
		</form>
	</body>
</HTML>
