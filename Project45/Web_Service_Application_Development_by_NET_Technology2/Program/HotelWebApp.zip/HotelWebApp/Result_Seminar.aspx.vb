Public Class Result_Seminar
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents DataColumn1 As System.Data.DataColumn
    Protected WithEvents DataColumn2 As System.Data.DataColumn
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2})
        Me.DataTable1.TableName = "tblAllSeminar"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "�Ҿ��ͧ�Ѵ����§"
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "��������´��ͧ"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            BindData()
        End If
    End Sub

    Private Sub BindData()
        ' Put user code to initialize the page here
        Dim DecStyle, PlaceStyle, SReserveDate As String
        Dim MinSize, MaxSize As Integer
        Dim MinPrice, MaxPrice As Double
        Dim TRange1, TRange2, TRange3 As Integer

        DecStyle = " "
        PlaceStyle = Request.QueryString("PlaceStyle")
        SReserveDate = Request.QueryString("SReserveDate")
        MinSize = Request.QueryString("MinSize")
        MaxSize = Request.QueryString("MaxSize")
        MinPrice = Request.QueryString("MinPrice")
        MaxPrice = Request.QueryString("MaxPrice")
        TRange1 = Request.QueryString("TRange1")
        TRange2 = Request.QueryString("TRange2")
        TRange3 = Request.QueryString("TRange3")

        Dim find As New HotelRef.HotelService0()
        Dim rs() As HotelRef.CSearchSeminarRoomResult = find.Search_Seminar_Room(PlaceStyle, DecStyle, MinSize, MaxSize, MinPrice, MaxPrice, SReserveDate, TRange1, TRange2, TRange3)
        Dim Count As Integer = rs.Length

        DataSet1.Tables("tblAllSeminar").Clear()
        Dim a As DataTable ' Create DataTable
        a = DataSet1.Tables("tblAllSeminar")

        Dim r As Integer
        'Dim srt As New HotelRef.HotelService0()
        For r = 0 To Count - 1
            If rs(r).seminar_room_id <> 0 Then
                Dim rc As DataRow
                rc = a.NewRow

                rc("�Ҿ��ͧ�Ѵ����§") = "<br><img src=Image/seminarid" & rs(r).seminar_room_id & ".jpg width=250 height=150><br>"
                rc("��������´��ͧ") = "��ͧ" & rs(r).seminar_room_name & "<br>" & "  ��Ҵ " & rs(r).seminar_room_size & " ���ҧ����  " & "<br>" & " �Ҥ� " & rs(r).seminar_room_price & " �ҷ "
                a.Rows.Add(rc)
            End If
        Next r
        DataGrid1.DataBind() ' Bind it!		

    End Sub

End Class
