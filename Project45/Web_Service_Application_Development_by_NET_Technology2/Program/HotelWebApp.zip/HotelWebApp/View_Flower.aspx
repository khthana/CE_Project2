<%@ Page Language="vb" AutoEventWireup="false" Codebehind="View_Flower.aspx.vb" Inherits="HotelWebApp.View_Flower"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>View_Flower</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
				<asp:Label id="Label1" style="Z-INDEX: 114; LEFT: 163px; POSITION: absolute; TOP: 33px" runat="server" Height="15px" Width="160px" BorderStyle="Ridge" BorderWidth="3px">��������´��èͧᾤࡨ�͡���</asp:Label>
				<asp:Label id="lblSeminarRoom" style="Z-INDEX: 115; LEFT: 247px; POSITION: absolute; TOP: 67px" runat="server" Height="6px" Width="148px"></asp:Label>
				<asp:Label id="lblPackageName" style="Z-INDEX: 105; LEFT: 248px; POSITION: absolute; TOP: 95px" runat="server" Height="7px" Width="179px"></asp:Label>
				<asp:Label id="Label8" style="Z-INDEX: 109; LEFT: 247px; POSITION: absolute; TOP: 131px" runat="server" Height="6px" Width="59px"></asp:Label>
				<asp:Label id="Label7" style="Z-INDEX: 113; LEFT: 312px; POSITION: absolute; TOP: 131px" runat="server" Height="11px" Width="16px">�ҷ</asp:Label>
				<asp:Label id="lblServeTime" style="Z-INDEX: 101; LEFT: 247px; POSITION: absolute; TOP: 158px" runat="server" Height="1px" Width="149px"></asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 111; LEFT: 143px; POSITION: absolute; TOP: 159px" runat="server" Height="2px" Width="84px"> ���ҵ��觴͡���</asp:Label>
				<asp:Label id="Label4" style="Z-INDEX: 108; LEFT: 184px; POSITION: absolute; TOP: 132px" runat="server" Height="12px" Width="44px">�Ҥ����</asp:Label>
				<asp:Label id="lblPrice" style="Z-INDEX: 110; LEFT: 247px; POSITION: absolute; TOP: 131px" runat="server" Height="6px" Width="59px"></asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 103; LEFT: 171px; POSITION: absolute; TOP: 68px" runat="server" Height="15px" Width="54px">��ͧ�Ѵ����§</asp:Label>
				<asp:Button id="cmdBack" style="Z-INDEX: 102; LEFT: 194px; POSITION: absolute; TOP: 196px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:Button>
				<asp:Label id="Label6" style="Z-INDEX: 104; LEFT: 148px; POSITION: absolute; TOP: 98px" runat="server" Height="13px" Width="82px">����ᾡࡨ�͡���</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 112; LEFT: 312px; POSITION: absolute; TOP: 131px" runat="server" Height="11px" Width="16px">�ҷ</asp:Label></FONT>
		</form>
	</body>
</HTML>
