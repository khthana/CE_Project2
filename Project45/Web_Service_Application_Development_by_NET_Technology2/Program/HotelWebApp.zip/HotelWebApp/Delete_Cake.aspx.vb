Public Class Delete_Cake
    Inherits System.Web.UI.Page
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents lblCakeLayer As System.Web.UI.WebControls.Label
    Protected WithEvents lblCakeSize As System.Web.UI.WebControls.Label
    Protected WithEvents lblCakeFlavour As System.Web.UI.WebControls.Label
    Protected WithEvents lblCakeStyle As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdBack As System.Web.UI.WebControls.Button
    Protected WithEvents lblServeTime As System.Web.UI.WebControls.Label
    Protected WithEvents lblSeminarRoom As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdDelete As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim CakeJobID As Integer
        CakeJobID = Request.QueryString("CakeJobID")
        Dim detail As New HotelRef.HotelService0()
        Dim lst As HotelRef.CCakeReservationList = detail.Show_Reserved_Cake(CakeJobID)

        lblSeminarRoom.Text = detail.Show_SeminarRoom_Name(lst.seminar_room_job_id)
        lblCakeStyle.Text = lst.cake_style
        lblCakeFlavour.Text = lst.cake_flavour
        lblCakeSize.Text = lst.cake_size & " �͹�� "
        lblCakeLayer.Text = lst.cake_layer & " ��� "
        lblPrice.Text = lst.job_total_price & " �ҷ "
        lblServeTime.Text = lst.cake_serve_time
    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
        Dim SeminarJobID As Integer
        SeminarJobID = Request.QueryString("SeminarJobID")
        Dim str_ret As String
        str_ret = "exist_job_inseminar.aspx?JobID=" & SeminarJobID
        Response.Redirect(str_ret)
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        'Delete it!
        Dim del As New HotelRef.HotelService0()
        Dim CustID, ContactID, CakeJobID As Integer

        CustID = Session.Contents("CustID")
        ContactID = Session.Contents("ContactID")
        CakeJobID = Request.QueryString("CakeJobID")
        del.Cancel_Cake_Reservation(CustID, ContactID, CakeJobID)

        'Redirect Back
        Dim SeminarJobID As Integer
        SeminarJobID = Request.QueryString("SeminarJobID")
        Dim str_ret As String
        str_ret = "exist_job_inseminar.aspx?JobID=" & SeminarJobID
        Response.Redirect(str_ret)
    End Sub
End Class
