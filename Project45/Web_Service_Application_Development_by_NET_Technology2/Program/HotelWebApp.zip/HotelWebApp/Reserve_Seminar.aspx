<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Reserve_Seminar.aspx.vb" Inherits="HotelWebApp.seminarreserve" codePage="874"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>seminarreserve</title>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<FONT face="Tahoma">
			<FORM id="searchroom" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'; BACKGROUND-COLOR: #ecebd7" method="post" runat="server">
				<asp:label id="Label1" style="Z-INDEX: 116; LEFT: 238px; POSITION: absolute; TOP: 23px" runat="server" BorderWidth="3px" BorderStyle="Ridge" Height="15px" Width="91px">�ͧʶҹ���Ѵ����§</asp:label>
				<asp:Label id="Label12" style="Z-INDEX: 122; LEFT: 267px; POSITION: absolute; TOP: 320px" runat="server" Height="14px" Width="36px"></asp:Label>
				<asp:Label id="Label10" style="Z-INDEX: 121; LEFT: 55px; POSITION: absolute; TOP: 255px" runat="server" Height="9px" Width="70px">�Ҥҷ�����</asp:Label>
				<asp:Label id="lblTotalPrice" style="Z-INDEX: 118; LEFT: 143px; POSITION: absolute; TOP: 256px" runat="server" Height="18px" Width="74px" BackColor="#FFE0C0">0</asp:Label>
				<asp:Label id="Label11" style="Z-INDEX: 119; LEFT: 229px; POSITION: absolute; TOP: 256px" runat="server" Height="11px" Width="23px">�ҷ</asp:Label>
				<asp:Button id="cmdCalPrice" style="Z-INDEX: 120; LEFT: 210px; POSITION: absolute; TOP: 287px" runat="server" Height="24px" Width="78px" Text="�ʴ��Ҥ����"></asp:Button><asp:calendar id="Calendar1" style="Z-INDEX: 117; LEFT: 142px; POSITION: absolute; TOP: 98px" runat="server" BorderStyle="Outset" Height="100px" Width="52px" Font-Size="8pt" ToolTip="Reserve Date" Font-Names="Microsoft Sans Serif"></asp:calendar><asp:label id="Label7" style="Z-INDEX: 101; LEFT: 284px; POSITION: absolute; TOP: 101px" runat="server">��ǧ���ҷ���ͧ���</asp:label><asp:label id="Label8" style="Z-INDEX: 102; LEFT: 50px; POSITION: absolute; TOP: 99px" runat="server" Width="82px">��ͧ��èͧ�ѹ���</asp:label><asp:button id="cmdReserveSeminar" style="Z-INDEX: 103; LEFT: 300px; POSITION: absolute; TOP: 287px" runat="server" Width="78px" Font-Names="Microsoft Sans Serif" Text="��ŧ" Height="24px"></asp:button><asp:label id="Label16" style="Z-INDEX: 104; LEFT: 283px; POSITION: absolute; TOP: 63px" runat="server" Width="84px">�ٻẺ��õ���</asp:label><asp:dropdownlist id="ddlDecStyle" style="Z-INDEX: 105; LEFT: 377px; POSITION: absolute; TOP: 63px" runat="server" Width="93px" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="thai">Ẻ��</asp:ListItem>
					<asp:ListItem Value="international">Ẻ�ҡ�</asp:ListItem>
					<asp:ListItem Value="chinese">Ẻ�չ</asp:ListItem>
				</asp:dropdownlist><asp:checkbox id="cbxT6to11am" style="Z-INDEX: 106; LEFT: 374px; POSITION: absolute; TOP: 102px" runat="server" Width="105px" Text="06.00 - 11.00 �."></asp:checkbox><asp:checkbox id="cbxT12to5pm" style="Z-INDEX: 107; LEFT: 374px; POSITION: absolute; TOP: 126px" runat="server" Text="12.00 - 17.00 �."></asp:checkbox><asp:checkbox id="cbxT6to11pm" style="Z-INDEX: 108; LEFT: 374px; POSITION: absolute; TOP: 151px" runat="server" Text="18.00 - 23.00 �."></asp:checkbox><asp:label id="Label2" style="Z-INDEX: 109; LEFT: 72px; POSITION: absolute; TOP: 67px" runat="server" Width="55px">��ͧ�Ѵ����§</asp:label><asp:dropdownlist id="ddlSeminarroomname" style="Z-INDEX: 110; LEFT: 144px; POSITION: absolute; TOP: 64px" runat="server" Width="98px" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="1">��Ҿ����</asp:ListItem>
					<asp:ListItem Value="2">garden bar</asp:ListItem>
					<asp:ListItem Value="3">����ͧ</asp:ListItem>
					<asp:ListItem Value="4">��⢷��</asp:ListItem>
					<asp:ListItem Value="5">�ѵ���Թ���</asp:ListItem>
					<asp:ListItem Value="6">��ظ��</asp:ListItem>
					<asp:ListItem Value="7">������1</asp:ListItem>
					<asp:ListItem Value="8">������2</asp:ListItem>
					<asp:ListItem Value="9">������3</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label3" style="Z-INDEX: 111; LEFT: 288px; POSITION: absolute; TOP: 184px" runat="server" Width="56px"> ��èѴ��ͧ</asp:label><asp:dropdownlist id="ddlTablelayout" style="Z-INDEX: 112; LEFT: 377px; POSITION: absolute; TOP: 184px" runat="server" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="table">��С��</asp:ListItem>
					<asp:ListItem Value="buffet">��������úؿ࿵�</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label4" style="Z-INDEX: 113; LEFT: 288px; POSITION: absolute; TOP: 215px" runat="server" Width="54px">�ӹǹ������</asp:label><asp:textbox id="txtMenPerRoom" style="Z-INDEX: 114; LEFT: 377px; POSITION: absolute; TOP: 214px" runat="server" Width="35px" MaxLength="4"></asp:textbox><asp:label id="Label5" style="Z-INDEX: 115; LEFT: 422px; POSITION: absolute; TOP: 216px" runat="server">���</asp:label>
				<asp:Label id="lblError" style="Z-INDEX: 123; LEFT: 303px; POSITION: absolute; TOP: 255px" runat="server" Width="256px" Height="17px"></asp:Label></FORM>
		</FONT>
	</body>
</HTML>
