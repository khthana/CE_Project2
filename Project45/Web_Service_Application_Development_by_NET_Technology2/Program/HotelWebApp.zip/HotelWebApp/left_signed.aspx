<%@ Page Language="vb" AutoEventWireup="false" Codebehind="left_signed.aspx.vb" Inherits="HotelWebApp.left_signed"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>left_signed</title>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
		<STYLE type="text/css">A:link { COLOR: #494949; TEXT-DECORATION: none }
	A:visited { COLOR: #494949; TEXT-DECORATION: none }
	A:hover { COLOR: #a18355; TEXT-DECORATION: none }
	A.d { FONT-WEIGHT: bold; FONT-SIZE: 12px; COLOR: #494949; FONT-FAMILY: verdana; TEXT-DECORATION: none }
	A.d:visited { FONT-WEIGHT: bold; FONT-SIZE: 12px; COLOR: #494949; FONT-FAMILY: verdana; TEXT-DECORATION: none }
		</STYLE>
		<SCRIPT language="JavaScript">
<!--
var OldColor;
function popNewWin (strDest,strWidth,strHeight) {
newWin = window.open(strDest,"popup","toolbar=no,scrollbars=yes,resizable=yes,width=" + strWidth + ",height=" + strHeight);
}
function mOvr(src,clrOver) {
if (!src.contains(event.fromElement)) {
src.style.cursor = 'hand';
OldColor = src.bgColor;
src.bgColor = clrOver;
}
}
function mOut(src) {
if (!src.contains(event.toElement)) {
src.style.cursor = 'default';
src.bgColor = OldColor;
}
}
function mClk(src) {
if(event.srcElement.tagName=='TD') {
src.children.tags('A')[0].click();
}
}
//-->
		</SCRIPT>
	</HEAD>
	<body MS_POSITIONING="GridLayout">
		<DIV style="Z-INDEX: 101; LEFT: 8px; WIDTH: 10px; POSITION: absolute; TOP: 8px; HEIGHT: 5px" ms_positioning="FlowLayout">
			<FORM id="WebForm1" method="post" runat="server">
			</FORM>
		</DIV>
		<center>
			<asp:Label id="lblWelcome" style="Z-INDEX: 102; LEFT: 34px; POSITION: absolute; TOP: 31px" runat="server" Width="87px" Height="15px" Font-Names="Microsoft Sans Serif" Font-Size="10pt" ForeColor="#A08455" Font-Bold="True"></asp:Label>
		</center>
		<TABLE id="Table1" style="Z-INDEX: 103; LEFT: 8px; WIDTH: 139px; POSITION: absolute; TOP: 56px; HEIGHT: 60px" runat="server">
			<TR bgColor="#ecebd7">
				<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" color="#494949" size="1"><A href="create_contact.aspx" target="index2_RFrame"><B>���ҧ 
								Contact ���� </B></A></FONT>
				</TD>
			</TR>
			<TR bgColor="#ecebd7">
				<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" color="#494949" size="1"><A href="index_signed.html" target="mainFrame"><B>����¹ 
								Contact �Ѩ�غѹ</B></A></FONT></TD>
			</TR>
			<TR bgColor="#ecebd7">
				<TD onmouseover="mOvr(this,'#ECEBD7');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" color="#494949" size="1"><A href="Pay.aspx" target="index2_RFrame"><B>
								�����Թ��� Contact</B></A></FONT></TD>
			</TR>
			<TR bgColor="#a08455">
				<TD onmouseover="mOvr(this,'#A08455');" onclick="mClk(this);" onmouseout="mOut(this);" align="middle" width="132" height="20"><FONT face="MS Sans Serif" color="#494949" size="1"><A href="http://161.246.6.123/HotelWebApp/index2.html" target="_parent"><B>
								<font color="#ffffff">�͡�ҡ�к�</font></B></A></FONT></TD>
			</TR>
		</TABLE>
		<asp:Label id="Label1" style="Z-INDEX: 104; LEFT: 34px; POSITION: absolute; TOP: 10px" runat="server" Font-Size="10pt" Font-Names="Microsoft Sans Serif" Height="12px" Width="94px" ForeColor="#A08455" Font-Bold="True">��¡�õԴ��ͧ͢</asp:Label>
	</body>
</HTML>
