Public Class exist_job
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents DataColumn1 As System.Data.DataColumn
    Protected WithEvents DataColumn3 As System.Data.DataColumn
    Protected WithEvents DataColumn4 As System.Data.DataColumn
    Protected WithEvents DataColumn5 As System.Data.DataColumn
    Protected WithEvents lblHeader As System.Web.UI.WebControls.Label
    Protected WithEvents DataColumn2 As System.Data.DataColumn

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        Me.DataColumn3 = New System.Data.DataColumn()
        Me.DataColumn4 = New System.Data.DataColumn()
        Me.DataColumn5 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2, Me.DataColumn3, Me.DataColumn4, Me.DataColumn5})
        Me.DataTable1.TableName = "tblAllJob"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "Job ID"
        Me.DataColumn1.DataType = GetType(System.Int32)
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "Job Name"
        Me.DataColumn2.MaxLength = 30
        '
        'DataColumn3
        '
        Me.DataColumn3.ColumnName = "Job Type"
        Me.DataColumn3.MaxLength = 20
        '
        'DataColumn4
        '
        Me.DataColumn4.ColumnName = "Job Price"
        Me.DataColumn4.DataType = GetType(System.Double)
        '
        'DataColumn5
        '
        Me.DataColumn5.ColumnName = "Pay Date"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ContactID, CustID As Integer
        ContactID = Session.Contents("ContactID")
        CustID = System.Convert.ToInt32(Session.Contents("CustID"))

        If Not Page.IsPostBack Then
            'Show Only ROOM & SEMINAR ROOM
            Dim Job As New HotelRef.HotelService0()
            Dim x As HotelRef.CShowAllJobid = Job.Show_All_Reserved_Info(CustID, ContactID)
            Dim room_count, seminar_count, cake_count, food_count, flower_count As Integer
            room_count = x.room_job_id.Length
            seminar_count = x.seminar_room_job_id.Length
          
            Dim alive As Integer
            alive = room_count + seminar_count
            If alive = 0 Then
                DataGrid1.Visible = False
                lblHeader.Text = "�������¡�÷��١�ͧ���"
            Else
                DataGrid1.Visible = True
                lblHeader.Text = "��������´��èͧ������"
                BindData()
            End If
        End If
    End Sub

    Private Sub BindData()
        ' Put user code to initialize the page here
        Dim Job As New HotelRef.HotelService0()
        Dim contact_id, customer_id As Integer

        contact_id = System.Convert.ToInt32(Session.Contents("ContactID"))
        customer_id = System.Convert.ToInt32(Session.Contents("CustID"))

        Dim x As HotelRef.CShowAllJobid = Job.Show_All_Reserved_Info(customer_id, contact_id)
        Dim room_count, seminar_count As Integer
        room_count = x.room_job_id.Length
        seminar_count = x.seminar_room_job_id.Length
     
        DataSet1.Tables("tblAllJob").Clear()
        Dim a As DataTable ' Create DataTable
        a = DataSet1.Tables("tblAllJob")

        Dim r As Integer
        Dim srt As New HotelRef.HotelService0()
        ' "room" Insert into DataGrid
        For r = 0 To room_count - 1
            Dim roomname, name2 As String
            roomname = srt.Show_RoomType(x.room_job_id(r))

            If roomname = "single" Then
                name2 = "��ͧ�����"
            End If
            If roomname = "twin" Then
                name2 = "��ͧ���"
            End If
            If roomname = "suite" Then
                name2 = "��ͧ�ش"
            End If

            Dim rc As DataRow
            rc = a.NewRow

            If x.room_job_id(r) <> 0 Then
                rc("Job Id") = x.room_job_id(r)
                rc("Job Name") = name2
                rc("Job Type") = "��ͧ"
                Dim room_pd As HotelRef.CPriceAndDate = Job.Show_Price_Date(x.room_job_id(r), "room")
                rc("Job Price") = room_pd.price
                Dim str_date As String
                If room_pd.paydate = "1/1/2003" Then
                    str_date = "-"
                Else
                    str_date = room_pd.paydate
                End If
                rc("Pay Date") = str_date
                a.Rows.Add(rc)
            End If
        Next r

        ' "seminarroom" Insert into DataGrid
        For r = 0 To seminar_count - 1
            Dim seminarroomname As String
            seminarroomname = srt.Show_SeminarRoom_Name(x.seminar_room_job_id(r))
            Dim rc As DataRow
            rc = a.NewRow

            If x.seminar_room_job_id(r) <> 0 Then
                rc("Job Id") = x.seminar_room_job_id(r)
                rc("Job Name") = seminarroomname
                rc("Job Type") = "��ͧ�Ѵ����§"
                Dim seminarroom_pd As HotelRef.CPriceAndDate = Job.Show_Price_Date(x.seminar_room_job_id(r), "seminar")
                rc("Job Price") = seminarroom_pd.price
                Dim str_date As String
                If seminarroom_pd.paydate = "1/1/2003" Then
                    str_date = "-"
                Else
                    str_date = seminarroom_pd.paydate
                End If
                rc("Pay Date") = str_date
                a.Rows.Add(rc)
            End If
        Next r
        DataGrid1.DataBind() ' Bind it!		

    End Sub

    Private Sub DataGrid1_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.DeleteCommand
        'Pass Parameter (jobID,jobName,jobType)
        'Redirect to Page Confirm 
        'When press ok, Delete Job
        'Redirect from Page Confirm -> exist_job.aspx
        Dim JobID, JobName, JobType As String
        JobID = e.Item.Cells(0).Text
        JobName = e.Item.Cells(1).Text
        JobType = e.Item.Cells(2).Text

        If JobType = "��ͧ" Then
            'Redirect to Delete_Room.aspx
            Dim ret_str As String
            ret_str = "Delete_Room.aspx?RoomJobID=" & JobID
            Response.Redirect(ret_str)
        End If

        If JobType = "��ͧ�Ѵ����§" Then
            'Redirect to Delete_Seminar.aspx
            Dim ret_str As String
            ret_str = "Delete_Seminar.aspx?SeminarJobID=" & JobID
            Response.Redirect(ret_str)
        End If
      
    End Sub

    Private Sub DataGrid1_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.EditCommand
        Dim JobID, JobName, JobType As String
        JobID = e.Item.Cells(0).Text
        JobName = e.Item.Cells(1).Text
        JobType = e.Item.Cells(2).Text

        If JobType = "��ͧ" Then
            'Redirect to View_Room.aspx
            Dim ret_str As String
            ret_str = "View_Room.aspx?JobID=" & JobID
            Response.Redirect(ret_str)
        End If

        If JobType = "��ͧ�Ѵ����§" Then
            'Redirect to exist_job_inseminar.aspx
            Dim ret_str As String
            ret_str = "exist_job_inseminar.aspx?JobID=" & JobID
            Response.Redirect(ret_str)
        End If
    End Sub


End Class
