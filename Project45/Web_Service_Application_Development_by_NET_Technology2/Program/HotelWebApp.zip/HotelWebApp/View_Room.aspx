<%@ Page Language="vb" AutoEventWireup="false" Codebehind="View_Room.aspx.vb" Inherits="HotelWebApp.View_Room"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>View_Room</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server" target="index2_RFrame">
			<FONT face="Tahoma" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
				<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 195px; POSITION: absolute; TOP: 45px" runat="server" Width="127px" Height="15px" BorderStyle="Ridge" BorderWidth="3px">��������´��èͧ��ͧ�ѡ</asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 110; LEFT: 187px; POSITION: absolute; TOP: 107px" runat="server" Height="9px" Width="45px">��Դ��ͧ</asp:Label>
				<asp:Label id="Label6" style="Z-INDEX: 109; LEFT: 181px; POSITION: absolute; TOP: 134px" runat="server" Height="19px" Width="47px">��Ҵ��ͧ</asp:Label>
				<asp:Button id="cmdBack" style="Z-INDEX: 108; LEFT: 212px; POSITION: absolute; TOP: 259px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:Button>
				<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 167px; POSITION: absolute; TOP: 80px" runat="server" Width="65px" Height="15px">�����Ţ��ͧ</asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 103; LEFT: 156px; POSITION: absolute; TOP: 191px" runat="server" Width="82px" Height="2px">�ѹ��� Check in</asp:Label>
				<asp:Label id="Label4" style="Z-INDEX: 104; LEFT: 151px; POSITION: absolute; TOP: 222px" runat="server" Width="88px" Height="1px">�ѹ��� Check out</asp:Label>
				<asp:Label id="lblRoomNo" style="Z-INDEX: 105; LEFT: 250px; POSITION: absolute; TOP: 79px" runat="server" Width="106px" Height="17px"></asp:Label>
				<asp:Label id="lblCheckin" style="Z-INDEX: 106; LEFT: 250px; POSITION: absolute; TOP: 191px" runat="server" Width="191px" Height="1px"></asp:Label>
				<asp:Label id="lblCheckout" style="Z-INDEX: 107; LEFT: 250px; POSITION: absolute; TOP: 222px" runat="server" Width="191px" Height="8px"></asp:Label>
				<asp:Label id="lblRoomType" style="Z-INDEX: 111; LEFT: 250px; POSITION: absolute; TOP: 107px" runat="server" Height="11px" Width="103px"></asp:Label>
				<asp:Label id="lblRoomSize" style="Z-INDEX: 112; LEFT: 250px; POSITION: absolute; TOP: 134px" runat="server" Height="14px" Width="112px"></asp:Label>
				<asp:Label id="Label7" style="Z-INDEX: 113; LEFT: 167px; POSITION: absolute; TOP: 162px" runat="server" Height="13px" Width="64px">�Ҥ���ͧ���</asp:Label>
				<asp:Label id="lblPrice" style="Z-INDEX: 114; LEFT: 250px; POSITION: absolute; TOP: 162px" runat="server" Width="110px"></asp:Label></FONT>
		</form>
	</body>
</HTML>
