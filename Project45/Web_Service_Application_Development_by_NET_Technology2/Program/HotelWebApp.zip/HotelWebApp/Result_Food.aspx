<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Result_Food.aspx.vb" Inherits="HotelWebApp.Result_Food"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Result_Food</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:datagrid id=DataGrid1 style="Z-INDEX: 101; LEFT: 48px; POSITION: absolute; TOP: 66px" runat="server" Font-Size="10pt" Font-Names="Microsoft Sans Serif" PageSize="5" AutoGenerateColumns="False" HorizontalAlign="Center" DataSource="<%# DataTable1 %>" CellPadding="0" Width="437px" BorderColor="Transparent">
					<SelectedItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></SelectedItemStyle>
					<AlternatingItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></AlternatingItemStyle>
					<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="Bisque"></ItemStyle>
					<HeaderStyle Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#FFCCAE"></HeaderStyle>
					<Columns>
						<asp:BoundColumn DataField="��������´ᾡࡨ" HeaderText="��������´ᾡࡨ"></asp:BoundColumn>
						<asp:BoundColumn DataField="��������´�����" HeaderText="��������´�����"></asp:BoundColumn>
					</Columns>
				</asp:datagrid>
				<asp:Label id="Label1" style="Z-INDEX: 102; LEFT: 224px; POSITION: absolute; TOP: 24px" runat="server" Width="97px" BorderWidth="3px" BorderStyle="Ridge" Height="17px">
					<center>���Ѿ���ä���</center>
				</asp:Label></FONT>
		</form>
	</body>
</HTML>
