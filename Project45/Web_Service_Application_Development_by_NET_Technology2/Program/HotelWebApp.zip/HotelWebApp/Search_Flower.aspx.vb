Public Class Search_Flower
    Inherits System.Web.UI.Page
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents txtMinPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMaxPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSearch As System.Web.UI.WebControls.Button
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents label9 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlSeminarroomname As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            txtMinPrice.Text = 0
            txtMaxPrice.Text = 6000
        End If
    End Sub


    Private Sub cmdSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        'Get All Data From Page
        Dim MinPrice, MaxPrice As Double
        Dim SeminarName As String

        'Set All Value 
        MinPrice = CDbl(txtMinPrice.Text)
        MaxPrice = CDbl(txtMaxPrice.Text)
        SeminarName = ddlSeminarroomname.SelectedItem.Text

        Dim ret_str As String
        ret_str = "Result_Flower.aspx?MinPrice=" & MinPrice & "&" & "MaxPrice=" & MaxPrice & "&" & "SeminarName=" & SeminarName
        Response.Redirect(ret_str)

    End Sub
End Class
