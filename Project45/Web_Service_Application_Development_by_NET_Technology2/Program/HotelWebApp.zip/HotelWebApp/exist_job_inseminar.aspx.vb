Public Class exist_job_inseminar
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents DataColumn1 As System.Data.DataColumn
    Protected WithEvents DataColumn2 As System.Data.DataColumn
    Protected WithEvents DataColumn3 As System.Data.DataColumn
    Protected WithEvents DataColumn4 As System.Data.DataColumn
    Protected WithEvents DataColumn5 As System.Data.DataColumn
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents lblReserveDate As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTimeRange As System.Web.UI.WebControls.Label
    Protected WithEvents lblHeader As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        Me.DataColumn3 = New System.Data.DataColumn()
        Me.DataColumn4 = New System.Data.DataColumn()
        Me.DataColumn5 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2, Me.DataColumn3, Me.DataColumn4, Me.DataColumn5})
        Me.DataTable1.TableName = "tblAllJob"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "Job ID"
        Me.DataColumn1.DataType = GetType(System.Int32)
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "Job Name"
        Me.DataColumn2.MaxLength = 30
        '
        'DataColumn3
        '
        Me.DataColumn3.ColumnName = "Job Type"
        Me.DataColumn3.MaxLength = 30
        '
        'DataColumn4
        '
        Me.DataColumn4.ColumnName = "Job Price"
        Me.DataColumn4.DataType = GetType(System.Double)
        '
        'DataColumn5
        '
        Me.DataColumn5.ColumnName = "Pay Date"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim ContactID, CustID, SeminarJobID As Integer
        ContactID = Session.Contents("ContactID")
        CustID = System.Convert.ToInt32(Session.Contents("CustID"))
        SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))

        If Not Page.IsPostBack Then
            'Show Only ROOM & SEMINAR ROOM
            Dim Job As New HotelRef.HotelService0()
            Dim x As HotelRef.CShowAllJobid = Job.Show_All_Reserved_InSeminar(CustID, ContactID, SeminarJobID)
            Dim cake_count, food_count, flower_count As Integer
           
            cake_count = x.cake_job_id.Length
            food_count = x.food_job_id.Length
            flower_count = x.flower_job_id.Length

            Dim alive As Integer
            alive = cake_count + food_count + flower_count
            If alive = 0 Then
                DataGrid1.Visible = False
                lblHeader.Text = "�������¡�÷��١�ͧ���"
            Else
                DataGrid1.Visible = True

                Dim find As New HotelRef.HotelService0()
                Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
                Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)
                lblHeader.Text = "��������´��èͧ�ͧ��ͧ " + seminar_name
                lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
                Dim t1, t2, t3 As Integer
                t1 = find.Show_SeminarRoom_T1(SeminarJobID)
                t2 = find.Show_SeminarRoom_T2(SeminarJobID)
                t3 = find.Show_SeminarRoom_T3(SeminarJobID)
                If t1 = 1 Then
                    lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
                Else
                    lblTimeRange.Text = lblTimeRange.Text & ""
                End If

                If t2 = 1 Then
                    lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
                Else
                    lblTimeRange.Text = lblTimeRange.Text & ""
                End If

                If t3 = 1 Then
                    lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
                Else
                    lblTimeRange.Text = lblTimeRange.Text & ""
                End If
                BindData()
            End If
        End If
    End Sub

    Private Sub BindData()
        ' Put user code to initialize the page here
        Dim Job As New HotelRef.HotelService0()
        Dim ContactID, CustID, SeminarJobID As Integer


        ContactID = System.Convert.ToInt32(Session.Contents("ContactID"))
        CustID = System.Convert.ToInt32(Session.Contents("CustID"))
        SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))

        Dim x As HotelRef.CShowAllJobid = Job.Show_All_Reserved_InSeminar(CustID, ContactID, SeminarJobID)
        Dim cake_count, food_count, flower_count As Integer
       
        cake_count = x.cake_job_id.Length
        food_count = x.food_job_id.Length
        flower_count = x.flower_job_id.Length

        DataSet1.Tables("tblAllJob").Clear()
        Dim a As DataTable ' Create DataTable
        a = DataSet1.Tables("tblAllJob")

        Dim r As Integer
        Dim srt As New HotelRef.HotelService0()
   
        For r = 0 To cake_count - 1
            Dim cakename As String
            cakename = srt.Show_Cake_Name(x.cake_job_id(r))
            Dim rc As DataRow
            rc = a.NewRow

            If x.cake_job_id(r) <> 0 Then
                rc("Job Id") = x.cake_job_id(r)
                rc("Job Name") = cakename
                rc("Job Type") = "��¡����"
                Dim cake_pd As HotelRef.CPriceAndDate = Job.Show_Price_Date(x.cake_job_id(r), "cake")
                rc("Job Price") = cake_pd.price
                Dim tmp As String
                If cake_pd.paydate = "1/1/2003" Then
                    tmp = "-"
                Else
                    tmp = cake_pd.paydate
                End If
                rc("Pay Date") = tmp
                a.Rows.Add(rc)
            End If
        Next r

        For r = 0 To food_count - 1
            Dim foodname, name2 As String
            foodname = srt.Show_Food_Name(x.food_job_id(r))
            If foodname = "THAI" Then
                name2 = "�������"
            End If
            If foodname = "CHINESE" Then
                name2 = "����èչ"
            End If
            If foodname = "INTERNATIONAL" Then
                name2 = "����ùҹҪҵ�"
            End If
            Dim rc As DataRow
            rc = a.NewRow

            If x.food_job_id(r) <> 0 Then
                rc("Job Id") = x.food_job_id(r)
                rc("Job Name") = name2
                rc("Job Type") = "��¡�������"
                Dim food_pd As HotelRef.CPriceAndDate = Job.Show_Price_Date(x.food_job_id(r), "food")
                rc("Job Price") = food_pd.price
                Dim tmp As String
                If food_pd.paydate = "1/1/2003" Then
                    tmp = "-"
                Else
                    tmp = food_pd.paydate
                End If
                rc("Pay Date") = tmp
                a.Rows.Add(rc)
            End If
        Next r

        For r = 0 To flower_count - 1
            Dim flowername As String
            flowername = srt.Show_Flower_Name(x.flower_job_id(r))
            Dim rc As DataRow
            rc = a.NewRow

            If x.flower_job_id(r) <> 0 Then
                rc("Job Id") = x.flower_job_id(r)
                rc("Job Name") = flowername
                rc("Job Type") = "ᾡࡨ�͡���"
                Dim flower_pd As HotelRef.CPriceAndDate = Job.Show_Price_Date(x.flower_job_id(r), "flower")
                rc("Job Price") = flower_pd.price

                Dim tmp As String
                If flower_pd.paydate = "1/1/2003" Then
                    tmp = "-"
                Else
                    tmp = flower_pd.paydate
                End If
                rc("Pay Date") = tmp
                a.Rows.Add(rc)
            End If
        Next r

        DataGrid1.DataBind() ' Bind it!		

    End Sub

    Private Sub DataGrid1_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.DeleteCommand
        Dim JobID, JobName, JobType As String
        JobID = e.Item.Cells(0).Text
        JobName = e.Item.Cells(1).Text
        JobType = e.Item.Cells(2).Text

        If JobType = "��¡����" Then
            'Redirect to Delete_Cake.aspx
            Dim ret_str As String
            Dim SeminarJobID As String
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))
            ret_str = "Delete_Cake.aspx?CakeJobID=" & JobID & "&" & "SeminarJobID=" & SeminarJobID
            Response.Redirect(ret_str)
        End If

        If JobType = "ᾡࡨ�͡���" Then
            'Redirect to Delete_Flower.aspx
            Dim ret_str As String
            Dim SeminarJobID As String
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))
            ret_str = "Delete_Flower.aspx?FlowerJobID=" & JobID & "&" & "SeminarJobID=" & SeminarJobID
            Response.Redirect(ret_str)
        End If

        If JobType = "��¡�������" Then
            'Redirect to Delete_Food.aspx
            Dim ret_str As String
            Dim SeminarJobID As String
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))
            ret_str = "Delete_Food.aspx?FoodJobID=" & JobID & "&" & "SeminarJobID=" & SeminarJobID
            Response.Redirect(ret_str)
        End If

    End Sub

    Private Sub DataGrid1_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.EditCommand
        Dim JobID, JobName, JobType As String
        JobID = e.Item.Cells(0).Text
        JobName = e.Item.Cells(1).Text
        JobType = e.Item.Cells(2).Text

        If JobType = "��¡����" Then
            'Redirect to View_Cake.aspx
            Dim ret_str As String
            Dim SeminarJobID As String
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))
            ret_str = "View_Cake.aspx?CakeJobID=" & JobID & "&" & "SeminarJobID=" & SeminarJobID
            Response.Redirect(ret_str)
        End If

        If JobType = "ᾡࡨ�͡���" Then
            'Redirect to View_Flower.aspx
            Dim ret_str As String
            Dim SeminarJobID As String
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))
            ret_str = "View_Flower.aspx?FlowerJobID=" & JobID & "&" & "SeminarJobID=" & SeminarJobID
            Response.Redirect(ret_str)
        End If

        If JobType = "��¡�������" Then
            'Redirect to View_Food.aspx
            Dim ret_str As String
            Dim SeminarJobID As String
            SeminarJobID = System.Convert.ToInt32(Request.QueryString("JobID"))
            ret_str = "View_Food.aspx?FoodJobID=" & JobID & "&" & "SeminarJobID=" & SeminarJobID
            Response.Redirect(ret_str)
        End If

    End Sub

End Class
