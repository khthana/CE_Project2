<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Reserve_Room.aspx.vb" Inherits="HotelWebApp.roomreserve" codePage="874"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>roomreserve</title>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<META content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<META content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<META content="JavaScript" name="vs_defaultClientScript">
		<META content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<BODY bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<FONT face="Tahoma">
			<FORM id="roomreserve" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" method="post" runat="server" target="index2_RFrame">
				<asp:label id="Label13" style="Z-INDEX: 105; LEFT: 283px; POSITION: absolute; TOP: 98px" runat="server">check out �ѹ���</asp:label>
				<asp:Label id="lblError" style="Z-INDEX: 124; LEFT: 285px; POSITION: absolute; TOP: 277px" runat="server" Width="194px" Height="17px"></asp:Label><asp:dropdownlist id="ddlExtrabed" style="Z-INDEX: 117; LEFT: 464px; POSITION: absolute; TOP: 62px" runat="server" Width="37px">
					<asp:ListItem Value="0">0</asp:ListItem>
					<asp:ListItem Value="1">1</asp:ListItem>
					<asp:ListItem Value="2">2</asp:ListItem>
					<asp:ListItem Value="3">3</asp:ListItem>
					<asp:ListItem Value="4">4</asp:ListItem>
					<asp:ListItem Value="5">5</asp:ListItem>
				</asp:dropdownlist><asp:calendar id="Calendar1" style="Z-INDEX: 111; LEFT: 141px; POSITION: absolute; TOP: 95px" runat="server" Width="52px" Height="100px" Font-Names="Microsoft Sans Serif" Font-Size="8pt" BorderStyle="Outset" ToolTip="Checkin Date"></asp:calendar><asp:calendar id="Calendar2" style="Z-INDEX: 110; LEFT: 378px; POSITION: absolute; TOP: 93px" runat="server" Width="52px" Height="100px" Font-Names="Microsoft Sans Serif" Font-Size="8pt" BorderStyle="Outset" ToolTip="Checkout Date"></asp:calendar><asp:label id="Label1" style="Z-INDEX: 109; LEFT: 247px; POSITION: absolute; TOP: 26px" runat="server" Width="60px" Height="7px" BorderWidth="3px" BorderStyle="Ridge">�ͧ��ͧ�ѡ</asp:label><asp:dropdownlist id="ddlRoomtype" style="Z-INDEX: 101; LEFT: 144px; POSITION: absolute; TOP: 65px" runat="server" Font-Names="Microsoft Sans Serif">
					<asp:ListItem Value="single">��§�����</asp:ListItem>
					<asp:ListItem Value="twin">��§���</asp:ListItem>
					<asp:ListItem Value="suite">��ͧ�ش</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label5" style="Z-INDEX: 100; LEFT: 54px; POSITION: absolute; TOP: 64px" runat="server">��ͧ�ѡẺ</asp:label><asp:checkbox id="chkSmoke" style="Z-INDEX: 102; LEFT: 57px; POSITION: absolute; TOP: 246px" runat="server" Text="��ͧ��èͧ��ͧ�ѡ���͹حҵ����ٺ������" Font-Names="Microsoft San Serif"></asp:checkbox><asp:button id="cmdReserveRoom" style="Z-INDEX: 103; LEFT: 301px; POSITION: absolute; TOP: 307px" runat="server" Width="78px" Text="��ŧ" Font-Names="Microsoft Sans Serif" Height="24px"></asp:button><asp:label id="Label8" style="Z-INDEX: 104; LEFT: 54px; POSITION: absolute; TOP: 98px" runat="server">check in �ѹ���</asp:label><asp:label id="Label14" style="Z-INDEX: 106; LEFT: 285px; POSITION: absolute; TOP: 66px" runat="server">�ӹǹ</asp:label><asp:label id="Label15" style="Z-INDEX: 107; LEFT: 369px; POSITION: absolute; TOP: 67px" runat="server">��ͧ/</asp:label><asp:dropdownlist id="ddlRoomamount" style="Z-INDEX: 108; LEFT: 324px; POSITION: absolute; TOP: 64px" runat="server" Width="37px">
					<asp:ListItem Value="1">1</asp:ListItem>
					<asp:ListItem Value="2">2</asp:ListItem>
					<asp:ListItem Value="3">3</asp:ListItem>
					<asp:ListItem Value="4">4</asp:ListItem>
					<asp:ListItem Value="5">5</asp:ListItem>
					<asp:ListItem Value="6">6</asp:ListItem>
					<asp:ListItem Value="7">7</asp:ListItem>
					<asp:ListItem Value="8">8</asp:ListItem>
					<asp:ListItem Value="9">9</asp:ListItem>
					<asp:ListItem Value="10">10</asp:ListItem>
				</asp:dropdownlist><asp:label id="Label4" style="Z-INDEX: 112; LEFT: 283px; POSITION: absolute; TOP: 248px" runat="server" Width="86px" Height="20px">(�ӹǹ�ѹ������</asp:label><asp:label id="Label6" style="Z-INDEX: 113; LEFT: 422px; POSITION: absolute; TOP: 249px" runat="server" Width="20px" Height="16px">�ѹ)</asp:label><asp:label id="lblTotalday" style="Z-INDEX: 114; LEFT: 381px; POSITION: absolute; TOP: 249px" runat="server" Width="31px" Height="15px" BorderColor="Transparent">0</asp:label><asp:label id="Label7" style="Z-INDEX: 115; LEFT: 395px; POSITION: absolute; TOP: 67px" runat="server" Width="67px" Height="7px">������§�����</asp:label><asp:label id="Label9" style="Z-INDEX: 116; LEFT: 505px; POSITION: absolute; TOP: 65px" runat="server" Width="17px" Height="5px">��ͧ</asp:label><asp:label id="Label10" style="Z-INDEX: 118; LEFT: 58px; POSITION: absolute; TOP: 277px" runat="server" Width="70px" Height="23px">�Ҥҷ�����</asp:label><asp:label id="lblTotalPrice" style="Z-INDEX: 120; LEFT: 145px; POSITION: absolute; TOP: 278px" runat="server" Width="81px" Height="18px" BackColor="#FFE0C0">0</asp:label><asp:label id="Label11" style="Z-INDEX: 121; LEFT: 235px; POSITION: absolute; TOP: 276px" runat="server" Width="23px" Height="11px">�ҷ</asp:label><asp:label id="Label12" style="Z-INDEX: 122; LEFT: 268px; POSITION: absolute; TOP: 336px" runat="server" Width="36px" Height="14px"></asp:label><asp:button id="cmdCalPrice" style="Z-INDEX: 123; LEFT: 207px; POSITION: absolute; TOP: 307px" runat="server" Width="78px" Height="24px" Text="�ʴ��Ҥ����"></asp:button></FORM>
		</FONT>
	</BODY>
</HTML>
