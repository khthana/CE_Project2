<%@ Page Language="vb" AutoEventWireup="false" Codebehind="exist_job.aspx.vb" Inherits="HotelWebApp.exist_job"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>exist_job</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="exist_job" method="post" target="index2_RFrame" runat="server">
			<FONT face="Microsoft Sans Serif">
				<asp:datagrid id=DataGrid1 style="Z-INDEX: 101; LEFT: 41px; POSITION: absolute; TOP: 80px" runat="server" Width="487px" CellPadding="0" DataSource="<%# DataTable1 %>" BorderColor="Transparent" HorizontalAlign="Center" AutoGenerateColumns="False" PageSize="5" Font-Names="Microsoft Sans Serif" Font-Size="10pt">
					<SelectedItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></SelectedItemStyle>
					<AlternatingItemStyle HorizontalAlign="Center" VerticalAlign="Middle"></AlternatingItemStyle>
					<ItemStyle HorizontalAlign="Center" VerticalAlign="Middle" BackColor="Bisque"></ItemStyle>
					<HeaderStyle Font-Bold="True" HorizontalAlign="Center" VerticalAlign="Middle" BackColor="#FFCCAE"></HeaderStyle>
					<Columns>
						<asp:BoundColumn DataField="Job Id" HeaderText="Job Id">
							<HeaderStyle Width="80pt"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Job Name" HeaderText="Job Name">
							<HeaderStyle Width="150pt"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Job Type" SortExpression="Job Type" HeaderText="Job Type">
							<HeaderStyle Width="180pt"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Job Price" SortExpression="Job Price" HeaderText="Price">
							<HeaderStyle Width="150px"></HeaderStyle>
						</asp:BoundColumn>
						<asp:BoundColumn DataField="Pay Date" SortExpression="Pay Date" HeaderText="Pay Date">
							<HeaderStyle Width="130pt"></HeaderStyle>
						</asp:BoundColumn>
						<asp:ButtonColumn Text="Delete" ButtonType="PushButton" CommandName="Delete"></asp:ButtonColumn>
						<asp:ButtonColumn Text="View" ButtonType="PushButton" CommandName="Edit"></asp:ButtonColumn>
					</Columns>
				</asp:datagrid><asp:label id="lblHeader" style="Z-INDEX: 102; LEFT: 217px; POSITION: absolute; TOP: 43px" runat="server" Width="132px" BorderColor="White" Font-Names="Microsoft Sans Serif" Font-Size="10pt" Height="15px">��������´��èͧ������</asp:label></FONT></form>
	</body>
</HTML>
