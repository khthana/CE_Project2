<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Reserve_Food.aspx.vb" Inherits="HotelWebApp.foodreserve" codePage="874"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>foodreserve</title>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="Form1" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" method="post" runat="server">
			<asp:label id="Label1" style="Z-INDEX: 114; LEFT: 194px; POSITION: absolute; TOP: 51px" runat="server" Width="226px">��¡�èͧ��ͧ����ҷ���ͧ�����������èѴ����§</asp:label>
			<asp:label id="Label14" style="Z-INDEX: 125; LEFT: 87px; POSITION: absolute; TOP: 264px" runat="server" Width="60px" Height="8px">�Ҥҷ�����</asp:label>
			<asp:label id="lblTotalPrice" style="Z-INDEX: 119; LEFT: 162px; POSITION: absolute; TOP: 267px" runat="server" Width="81px" Height="18px" BackColor="#FFE0C0">0</asp:label>
			<asp:label id="Label13" style="Z-INDEX: 122; LEFT: 252px; POSITION: absolute; TOP: 271px" runat="server" Width="23px" Height="11px">�ҷ</asp:label>
			<asp:button id="cmdCalPrice" style="Z-INDEX: 124; LEFT: 204px; POSITION: absolute; TOP: 323px" runat="server" Width="78px" Height="24px" Font-Names="Microsoft Sans Serif" Text="�ʴ��Ҥ����"></asp:button>
			<asp:label id="Label11" style="Z-INDEX: 121; LEFT: 271px; POSITION: absolute; TOP: 18px" runat="server" Width="70px" Height="7px" BorderStyle="Ridge" BorderWidth="3px">��觨ͧ�����</asp:label><asp:label id="Label10" style="Z-INDEX: 116; LEFT: 202px; POSITION: absolute; TOP: 111px" runat="server" Width="40px" Font-Names="Microsoft Sans Serif" Font-Size="10pt" Height="14px">�ѹ���ͧ</asp:label><asp:label id="lblReserveDate" style="Z-INDEX: 106; LEFT: 252px; POSITION: absolute; TOP: 112px" runat="server" Width="205px" Height="18px"></asp:label><asp:label id="Label9" style="Z-INDEX: 108; LEFT: 177px; POSITION: absolute; TOP: 136px" runat="server" Width="67px" Height="21px">��ǧ���ҷ��ͧ</asp:label><asp:label id="lblTimeRange" style="Z-INDEX: 111; LEFT: 252px; POSITION: absolute; TOP: 137px" runat="server" Width="328px" Height="19px"></asp:label><asp:button id="cmdFoodreserve" style="Z-INDEX: 115; LEFT: 291px; POSITION: absolute; TOP: 324px" runat="server" Font-Names="Microsoft Sans Serif" Text="��ŧ" Width="78px" Height="24px"></asp:button><asp:dropdownlist id="ddlSeminarRoomList" style="Z-INDEX: 100; LEFT: 182px; POSITION: absolute; TOP: 79px" runat="server" Width="253px" Font-Names="Microsoft Sans Serif" AutoPostBack="True"></asp:dropdownlist><asp:label id="Label2" style="Z-INDEX: 101; LEFT: 42px; POSITION: absolute; TOP: 169px" runat="server" Width="114px">ᾤࡨ����÷���ͧ���</asp:label><asp:dropdownlist id="ddlFoodpackageID" style="Z-INDEX: 102; LEFT: 163px; POSITION: absolute; TOP: 169px" runat="server" Width="157px" Font-Names="Microsoft Sans Serif" AutoPostBack="True">
				<asp:ListItem Value="1">�������ҧ �� 1</asp:ListItem>
				<asp:ListItem Value="2">�������ҧ �� 2</asp:ListItem>
				<asp:ListItem Value="3">�������ҧ �� 3</asp:ListItem>
				<asp:ListItem Value="4">������� �� 1</asp:ListItem>
				<asp:ListItem Value="5">������� �� 2</asp:ListItem>
				<asp:ListItem Value="6">������� �� 3</asp:ListItem>
				<asp:ListItem Value="7">����èչ �� 1</asp:ListItem>
				<asp:ListItem Value="8">����èչ �� 2</asp:ListItem>
				<asp:ListItem Value="9">����èչ �� 3</asp:ListItem>
				<asp:ListItem Value="10">����ùҹҪҵ� �� 1</asp:ListItem>
				<asp:ListItem Value="11">����ùҹҪҵ� �� 2</asp:ListItem>
				<asp:ListItem Value="12">����ùҹҪҵ� �� 3</asp:ListItem>
			</asp:dropdownlist><asp:label id="Label3" style="Z-INDEX: 103; LEFT: 73px; POSITION: absolute; TOP: 206px" runat="server" Width="76px">��������������</asp:label><asp:textbox id="txtHH" style="Z-INDEX: 104; LEFT: 162px; POSITION: absolute; TOP: 204px" runat="server" Width="40px" MaxLength="2"></asp:textbox><asp:label id="Label4" style="Z-INDEX: 105; LEFT: 207px; POSITION: absolute; TOP: 206px" runat="server">���ԡ�</asp:label><asp:label id="Label5" style="Z-INDEX: 107; LEFT: 294px; POSITION: absolute; TOP: 207px" runat="server">�ҷ�</asp:label><asp:textbox id="txtMM" style="Z-INDEX: 109; LEFT: 246px; POSITION: absolute; TOP: 204px" runat="server" Width="40px"></asp:textbox><asp:label id="Label6" style="Z-INDEX: 110; LEFT: 72px; POSITION: absolute; TOP: 236px" runat="server" Width="79px">�ӹǹ����ͧ���</asp:label><asp:textbox id="txtFoodAmount" style="Z-INDEX: 112; LEFT: 162px; POSITION: absolute; TOP: 236px" runat="server" Width="40px" MaxLength="3"></asp:textbox><asp:label id="lblError" style="Z-INDEX: 113; LEFT: 193px; POSITION: absolute; TOP: 298px" runat="server" Width="193px" Height="15px"></asp:label><asp:label id="lblUnit" style="Z-INDEX: 117; LEFT: 213px; POSITION: absolute; TOP: 239px" runat="server" Width="64px" Height="18px"></asp:label><asp:listbox id="lstFoodList" style="Z-INDEX: 118; LEFT: 430px; POSITION: absolute; TOP: 168px" runat="server" Width="160px" Font-Names="Microsoft Sans Serif" Height="104px">
				<asp:ListItem Value="�����͹">�����͹</asp:ListItem>
				<asp:ListItem Value="������о������͹">������о������͹</asp:ListItem>
				<asp:ListItem Value="�Ҩչ���">�Ҩչ���</asp:ListItem>
				<asp:ListItem Value="�Ҩչ��͹">�Ҩչ��͹</asp:ListItem>
				<asp:ListItem Value="᫹���Ԫͺ��">᫹���Ԫͺ��</asp:ListItem>
			</asp:listbox><asp:label id="Label8" style="Z-INDEX: 120; LEFT: 331px; POSITION: absolute; TOP: 169px" runat="server" Width="91px" Height="19px">����¡������ôѧ���</asp:label>
			<asp:Label id="Label7" style="Z-INDEX: 123; LEFT: 319px; POSITION: absolute; TOP: 207px" runat="server" Width="34px" Height="19px">(HH:MM)</asp:Label></form>
	</body>
</HTML>
