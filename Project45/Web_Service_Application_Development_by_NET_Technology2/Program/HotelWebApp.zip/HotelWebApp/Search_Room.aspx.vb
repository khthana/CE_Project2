Public Class Search_Room
    Inherits System.Web.UI.Page
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents chkSmoke As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Calendar2 As System.Web.UI.WebControls.Calendar
    Protected WithEvents Calendar1 As System.Web.UI.WebControls.Calendar
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdSearchRoom As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents txtMinPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMaxPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddlRoomAmount As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlRoomType As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents roomreserve As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        If Not Page.IsPostBack Then
            Calendar1.SelectedDate = DateTime.Now
            Calendar2.SelectedDate = DateTime.Now
            lblError.Visible = False
            txtMinPrice.Text = 0
            txtMaxPrice.Text = 5000
        End If
    End Sub

    Private Sub cmdSearchRoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearchRoom.Click
        'Check Date FIRST!
        If Calendar1.SelectedDate <= DateTime.Now Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If Calendar2.SelectedDate <= DateTime.Now Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If Calendar1.SelectedDate = Calendar2.SelectedDate Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If Calendar2.SelectedDate <= Calendar1.SelectedDate Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        'Get All Data From Page
        Dim amount_room As Integer
        Dim room_type, Schkin_date, Schkout_date As String
        Dim smoke As Integer
        Dim minprice, maxprice As Double
        amount_room = ddlRoomAmount.SelectedItem.Value
        room_type = ddlRoomType.SelectedItem.Value

        Dim tmp1, tmp2 As Date
        tmp1 = Calendar1.SelectedDate
        tmp2 = Calendar2.SelectedDate

        ' Manage DateTime
        Dim dd1, mm1 As String
        If (tmp1.Day >= 1 And tmp1.Day <= 9) Then
            dd1 = "0" & tmp1.Day
        Else
            dd1 = tmp1.Day
        End If

        If (tmp1.Month >= 1 And tmp1.Month <= 9) Then
            mm1 = "0" & tmp1.Month
        Else
            mm1 = tmp1.Month
        End If
        Schkin_date = dd1 & " " & mm1 & " " & tmp1.Year

        Dim dd2, mm2 As String
        If (tmp2.Day >= 1 And tmp2.Day <= 9) Then
            dd2 = "0" & tmp2.Day
        Else
            dd2 = tmp2.Day
        End If

        If (tmp2.Month >= 1 And tmp2.Month <= 9) Then
            mm2 = "0" & tmp2.Month
        Else
            mm2 = tmp2.Month
        End If
        Schkout_date = dd2 & " " & mm2 & " " & tmp2.Year

        If chkSmoke.Checked = True Then
            smoke = 1
        Else
            smoke = 0
        End If

        minprice = CDbl(txtMinPrice.Text)
        maxprice = CDbl(txtMaxPrice.Text)

        'Call Web Method
        Dim Search As New HotelRef.HotelService0()
        Dim result() As HotelRef.CSearchRoomResultAll = Search.Search_Room_By_Date(amount_room, room_type, Schkin_date, Schkout_date, smoke, minprice, maxprice)
        If result(0).room_type <> "" Then
            Dim r_amount As Integer = result(0).room_amount
            Dim r_type As String = result(0).room_type
            Dim r_size As Integer = result(0).room_size
            Dim r_price As Double = result(0).room_price
            Dim r_smoke As Integer = result(0).smoke
            Dim r_men As Integer = result(0).maximum_men_per_room
            Dim r_ex As Double = result(0).extrabed_price

            Dim ret_str As String
            ret_str = "Result_Room.aspx?r_amount=" & r_amount & "&" & "r_type=" & r_type & "&" & "r_size=" & r_size & "&" & "r_price=" & r_price & "&" & "r_smoke=" & r_smoke & "&" & "r_men=" & r_men & "&" & "r_ex=" & r_ex
            Response.Redirect(ret_str)
        Else
            lblError.Visible = True
            lblError.Text = "�������ͧ���������ͧ��÷���˹�"
        End If

    End Sub
End Class
