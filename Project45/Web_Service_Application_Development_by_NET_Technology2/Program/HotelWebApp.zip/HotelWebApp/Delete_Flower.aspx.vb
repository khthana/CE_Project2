Public Class Delete_Flower
    Inherits System.Web.UI.Page
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdBack As System.Web.UI.WebControls.Button
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents lblServeTime As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPackageName As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdDelete As System.Web.UI.WebControls.Button
    Protected WithEvents lblSeminarRoom As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim FlowerJobID As Integer
        FlowerJobID = Request.QueryString("FlowerJobID")
        Dim detail As New HotelRef.HotelService0()
        Dim lst As HotelRef.CFlowerReservationList = detail.Show_Reserved_Flower(FlowerJobID)

        lblSeminarRoom.Text = detail.Show_SeminarRoom_Name(lst.seminar_room_job_id)

        lblPackageName.Text = lst.flower_package_name
        Dim stime As String

        If lst.flower_time_range = 1 Then
            stime = ""
            stime = "��ǧ���"
        End If
        If lst.flower_time_range = 2 Then
            stime = ""
            stime = "��ǧ����"
        End If
        If lst.flower_time_range = 3 Then
            stime = ""
            stime = "��ǧ���"
        End If
        lblServeTime.Text = stime
        lblPrice.Text = lst.job_total_price
    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
        Dim SeminarJobID As Integer
        SeminarJobID = Request.QueryString("SeminarJobID")
        Dim str_ret As String
        str_ret = "exist_job_inseminar.aspx?JobID=" & SeminarJobID
        Response.Redirect(str_ret)
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        'Delete it!
        Dim del As New HotelRef.HotelService0()
        Dim CustID, ContactID, FlowerJobID As Integer

        CustID = Session.Contents("CustID")
        ContactID = Session.Contents("ContactID")
        FlowerJobID = Request.QueryString("FlowerJobID")
        del.Cancel_Flower_Reservation(CustID, ContactID, FlowerJobID)

        'Redirect Back
        Dim SeminarJobID As Integer
        SeminarJobID = Request.QueryString("SeminarJobID")
        Dim str_ret As String
        str_ret = "exist_job_inseminar.aspx?JobID=" & SeminarJobID
        Response.Redirect(str_ret)
    End Sub

End Class
