<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Delete_Food.aspx.vb" Inherits="HotelWebApp.Delete_Food"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Delete_Food</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<FONT face="Tahoma">
			<FORM id="Form1" method="post" runat="server">
				<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
					<asp:Label id="Label3" style="Z-INDEX: 112; LEFT: 153px; POSITION: absolute; TOP: 190px" runat="server" Height="2px" Width="74px"> ��������������</asp:Label>
					<asp:Button id="cmdDelete" style="Z-INDEX: 118; LEFT: 136px; POSITION: absolute; TOP: 228px" runat="server" Height="23px" Width="95px" Font-Names="Microsoft Sans Serif" Text="ź��¡�ù��"></asp:Button>
					<asp:Label id="Label1" style="Z-INDEX: 114; LEFT: 169px; POSITION: absolute; TOP: 33px" runat="server" Height="15px" Width="159px" BorderStyle="Ridge" BorderWidth="3px">��������´��èͧᾤࡨ�����</asp:Label>
					<asp:Label id="Label4" style="Z-INDEX: 110; LEFT: 185px; POSITION: absolute; TOP: 163px" runat="server" Height="12px" Width="44px">�Ҥ����</asp:Label>
					<asp:Label id="lblPrice" style="Z-INDEX: 111; LEFT: 248px; POSITION: absolute; TOP: 162px" runat="server" Height="6px" Width="59px"></asp:Label>
					<asp:Label id="lblServeTime" style="Z-INDEX: 102; LEFT: 248px; POSITION: absolute; TOP: 189px" runat="server" Height="1px" Width="149px"></asp:Label>
					<asp:Label id="Label5" style="Z-INDEX: 105; LEFT: 171px; POSITION: absolute; TOP: 68px" runat="server" Height="15px" Width="54px">��ͧ�Ѵ����§</asp:Label>
					<asp:Label id="lblSeminarRoom" style="Z-INDEX: 101; LEFT: 247px; POSITION: absolute; TOP: 66px" runat="server" Height="6px" Width="148px"></asp:Label>
					<asp:Button id="cmdBack" style="Z-INDEX: 104; LEFT: 244px; POSITION: absolute; TOP: 228px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:Button>
					<asp:Label id="Label6" style="Z-INDEX: 106; LEFT: 148px; POSITION: absolute; TOP: 98px" runat="server" Height="13px" Width="82px">����ᾡࡨ�����</asp:Label>
					<asp:Label id="lblPackageName" style="Z-INDEX: 107; LEFT: 248px; POSITION: absolute; TOP: 95px" runat="server" Height="7px" Width="179px"></asp:Label>
					<asp:Label id="Label10" style="Z-INDEX: 108; LEFT: 152px; POSITION: absolute; TOP: 127px" runat="server" Height="23px" Width="76px">�ѡɳС������</asp:Label>
					<asp:Label id="lblServeStyle" style="Z-INDEX: 109; LEFT: 248px; POSITION: absolute; TOP: 124px" runat="server" Height="5px" Width="147px"></asp:Label>
					<asp:Label id="Label2" style="Z-INDEX: 113; LEFT: 313px; POSITION: absolute; TOP: 162px" runat="server" Height="11px" Width="16px">�ҷ</asp:Label></FONT></FORM>
		</FONT>
	</body>
</HTML>
