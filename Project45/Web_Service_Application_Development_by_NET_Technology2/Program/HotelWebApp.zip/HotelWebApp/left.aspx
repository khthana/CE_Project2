<%@ Page Language="vb" AutoEventWireup="false" Codebehind="left.aspx.vb" Inherits="HotelWebApp.left"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>left</title>
		<META content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<META content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<META content="JavaScript" name="vs_defaultClientScript">
		<META content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<BODY MS_POSITIONING="GridLayout">
		<DIV style="Z-INDEX: 100; LEFT: 8px; WIDTH: 10px; POSITION: absolute; TOP: 8px; HEIGHT: 10px" ms_positioning="text2D">
			<FORM id="WebForm1" method="post" target="mainFrame" runat="server">
				<IMG style="Z-INDEX: 101; LEFT: 3px; POSITION: absolute; TOP: 4px" height="19" alt="" src="Image/signin.jpg" width="132" border="0">
				<asp:textbox id="txtUsername" style="Z-INDEX: 102; LEFT: 5px; POSITION: absolute; TOP: 44px" runat="server" Height="20px" Width="129px"></asp:textbox>
				<asp:textbox id="txtPassword" style="Z-INDEX: 103; LEFT: 5px; POSITION: absolute; TOP: 81px" runat="server" Height="20px" Width="129px" TextMode="Password"></asp:textbox>
				<asp:label id="Label1" style="Z-INDEX: 104; LEFT: 5px; POSITION: absolute; TOP: 27px" runat="server" Height="16px" Width="62px" Font-Names="Microsoft Sans Serif" Font-Bold="True" Font-Size="8pt">Username</asp:label>
				<asp:label id="Label2" style="Z-INDEX: 105; LEFT: 6px; POSITION: absolute; TOP: 64px" runat="server" Width="57px" Height="15px" Font-Size="8pt" Font-Bold="True" Font-Names="Microsoft Sans Serif">Password</asp:label>
				<asp:button id="cmdSignin" style="Z-INDEX: 106; LEFT: 16px; POSITION: absolute; TOP: 105px" runat="server" Width="45px" Height="20px" Font-Size="8pt" Text="Sign In" Font-Names="Microsoft Sans Serif"></asp:button>
				<asp:button id="cmdCancel" style="Z-INDEX: 107; LEFT: 73px; POSITION: absolute; TOP: 105px" runat="server" Width="45px" Height="20px" Font-Size="8pt" Text="Cancel" Font-Names="Microsoft Sans Serif"></asp:button>
				<asp:HyperLink id="HyperLink1" style="Z-INDEX: 108; LEFT: 18px; POSITION: absolute; TOP: 155px" runat="server" Width="102px" Height="16px" Font-Size="10pt" Font-Bold="True" Target="index2_RFrame" NavigateUrl="http://161.246.6.123/HotelWebApp/signup.aspx" Font-Names="Microsoft Sans Serif" ForeColor="SaddleBrown">Sign Up Now!!!</asp:HyperLink></FORM>
		</DIV>
		<asp:Label id="lblError" style="Z-INDEX: 101; LEFT: 12px; POSITION: absolute; TOP: 200px" runat="server" Height="13px" Width="124px" Font-Names="Microsoft Sans Serif" Font-Size="10pt"></asp:Label>
	</BODY>
</HTML>
