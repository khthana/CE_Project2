<%@ Page Language="vb" AutoEventWireup="false" Codebehind="create_contact.aspx.vb" Inherits="HotelWebApp.create_contact"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>create_contact</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server" target="mainFrame">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:label id="Label1" style="Z-INDEX: 101; LEFT: 228px; POSITION: absolute; TOP: 54px" runat="server" Width="123px" Height="17px" BorderStyle="Ridge" BorderWidth="3px" BorderColor="Transparent">
					<center>���ҧ Contact ����</center>
				</asp:label>
				<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 152px; POSITION: absolute; TOP: 113px" runat="server" Width="105px" Height="18px">��سҵ�駪��� Contact</asp:Label>
				<asp:TextBox id="txtContactName" style="Z-INDEX: 104; LEFT: 272px; POSITION: absolute; TOP: 112px" runat="server" Width="161px" Height="24px" Font-Names="Microsoft Sans Serif"></asp:TextBox>
				<asp:Button id="cmdCreate" style="Z-INDEX: 106; LEFT: 249px; POSITION: absolute; TOP: 167px" runat="server" Width="86px" Height="24px" Text="���ҧ Contact" Font-Names="Microsoft Sans Serif"></asp:Button></FONT></form>
	</body>
</HTML>
