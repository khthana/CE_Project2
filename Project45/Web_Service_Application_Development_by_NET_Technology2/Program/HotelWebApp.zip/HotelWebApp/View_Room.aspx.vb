Public Class View_Room
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents lblRoomNo As System.Web.UI.WebControls.Label
    Protected WithEvents lblCheckin As System.Web.UI.WebControls.Label
    Protected WithEvents lblCheckout As System.Web.UI.WebControls.Label
    Protected WithEvents lblRoomType As System.Web.UI.WebControls.Label
    Protected WithEvents lblRoomSize As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPrice As System.Web.UI.WebControls.Label
    Protected WithEvents cmdBack As System.Web.UI.WebControls.Button
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim JobID As Integer
        JobID = Request.QueryString("JobID")
        Dim detail As New HotelRef.HotelService0()
        Dim lst As HotelRef.CRoomReservationList = detail.Show_Reserved_Room(JobID)

        lblRoomNo.Text = lst.room_id
        lblRoomType.Text = lst.room_type
        lblRoomSize.Text = lst.room_size & "  ���ҧ���� "
        lblCheckin.Text = lst.checkin_date
        lblCheckout.Text = lst.checkout_date
        lblPrice.Text = lst.job_total_price & " �ҷ  "
    End Sub

    Private Sub cmdBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdBack.Click
        Response.Redirect("exist_job.aspx")
    End Sub
End Class
