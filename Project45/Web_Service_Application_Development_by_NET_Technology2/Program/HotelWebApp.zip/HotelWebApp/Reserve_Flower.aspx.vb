Public Class flowerreserve
    Inherits System.Web.UI.Page
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlSeminarRoomList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ddlFlowerTimeRange As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents lblPrice As System.Web.UI.WebControls.Label
    Protected WithEvents lblTimeRange As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents lblReserveDate As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlFlowerPackage As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdReserve As System.Web.UI.WebControls.Button
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            Dim i As Integer
            Dim name As New HotelRef.HotelService0()
            Dim ContactID As Integer = Session.Contents("ContactID")
            Dim CSList() As HotelRef.CSeminarReserveInfo = name.Show_All_SeminarRoom_Info(ContactID)
            Dim strAdd As String
            cmdReserve.Visible = True
            If CSList.Length = 0 Then
                lblError.Text = "!!! ��سҨͧʶҹ���Ѵ����§��͹"
                cmdReserve.Visible = False
                Exit Sub
            End If
            For i = 0 To CSList.Length - 1
                strAdd = "��èͧ��� " & CSList(i).seminar_room_job_id & "  ��ͧ" & CSList(i).seminar_room_name
                Dim x As New ListItem()
                x.Text = CStr(strAdd)
                x.Value = CInt(CSList(i).seminar_room_job_id)
                ddlSeminarRoomList.Items.Add(x)
            Next

            'Input Date and Time Range of Seminar Room Reservation
            lblTimeRange.Text = ""
            Dim find As New HotelRef.HotelService0()
            Dim SeminarJobID As Integer
            SeminarJobID = CInt(ddlSeminarRoomList.SelectedItem.Value)

            Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
            Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)

            lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
            Dim t1, t2, t3 As Integer
            t1 = find.Show_SeminarRoom_T1(SeminarJobID)
            t2 = find.Show_SeminarRoom_T2(SeminarJobID)
            t3 = find.Show_SeminarRoom_T3(SeminarJobID)
            If t1 = 1 Then
                lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t2 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t3 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            Dim seminar_room_id As Integer = find.Show_SeminarRoom_ID(SeminarJobID)
            Dim flower_package_id As Integer = ddlFlowerPackage.SelectedItem.Value()

            lblPrice.Text = ""
            Dim price As Double = find.Show_Flower_Price(flower_package_id, seminar_room_id)
            lblPrice.Text = CStr(price)
        End If
    End Sub

    Private Sub ddlSeminarRoomList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSeminarRoomList.SelectedIndexChanged
        lblTimeRange.Text = ""
        Dim find As New HotelRef.HotelService0()
        Dim SeminarJobID As Integer
        SeminarJobID = CInt(ddlSeminarRoomList.SelectedItem.Value)

        Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
        Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)

        lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
        Dim t1, t2, t3 As Integer
        t1 = find.Show_SeminarRoom_T1(SeminarJobID)
        t2 = find.Show_SeminarRoom_T2(SeminarJobID)
        t3 = find.Show_SeminarRoom_T3(SeminarJobID)
        If t1 = 1 Then
            lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        If t2 = 1 Then
            lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        If t3 = 1 Then
            lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        Dim seminar_room_id As Integer = find.Show_SeminarRoom_ID(SeminarJobID)
        Dim flower_package_id As Integer = ddlFlowerPackage.SelectedItem.Value()
        lblPrice.Text = ""
        Dim price As Double = find.Show_Flower_Price(flower_package_id, seminar_room_id)
        lblPrice.Text = CStr(price)

    End Sub

    Private Sub ddlFlowerPackage_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlFlowerPackage.SelectedIndexChanged
        Dim find As New HotelRef.HotelService0()
        Dim seminar_room_job_id As Integer = CInt(ddlSeminarRoomList.SelectedItem.Value)
        Dim seminar_room_id As Integer = find.Show_SeminarRoom_ID(seminar_room_job_id)
        Dim flower_package_id As Integer = ddlFlowerPackage.SelectedItem.Value()

        lblPrice.Text = ""
        Dim price As Double = find.Show_Flower_Price(flower_package_id, seminar_room_id)
        lblPrice.Text = CStr(price)
    End Sub

   
    Private Sub cmdReserve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReserve.Click

        Dim seminar_room_job_id As Integer
        Dim flower_time_range As Integer
        Dim flower_package_id As Short
        Dim seminar_room_id As Integer
        Dim ContactID As Integer
        Dim CustID As Integer

        CustID = Session.Contents("CustID")
        ContactID = Session.Contents("ContactID")
        Dim find As New HotelRef.HotelService0()
        seminar_room_job_id = CInt(ddlSeminarRoomList.SelectedItem.Value)
        seminar_room_id = find.Show_SeminarRoom_ID(seminar_room_job_id)

        flower_package_id = ddlFlowerPackage.SelectedItem.Value
        flower_time_range = ddlFlowerTimeRange.SelectedItem.Value

        Dim Res As New HotelRef.HotelService0()
        Dim ret As HotelRef.CReturnReserve

        ret = Res.Reserve_Flower(CustID, flower_package_id, seminar_room_id, seminar_room_job_id, ContactID, flower_time_range)
        If ret.str_error = "success" Then
            Dim str_ret As String
            Dim findName As New HotelRef.HotelService0()
            Dim JobName As String = findName.Show_SeminarRoom_Name(seminar_room_job_id)
            str_ret = "exist_job_inseminar.aspx?JobID=" & seminar_room_job_id & "&" & "JobName=" & JobName
            Response.Redirect(str_ret)
        End If
    End Sub
End Class
