Public Class Search_Cake
    Inherits System.Web.UI.Page
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlLayer As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlSize As System.Web.UI.WebControls.DropDownList
    Protected WithEvents txtMinPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMaxPrice As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSearch As System.Web.UI.WebControls.Button
    Protected WithEvents ddlStyle As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            txtMinPrice.Text = 0
            txtMaxPrice.Text = 800
        End If
    End Sub

    Private Sub cmdSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        'Get All Data From Page
        Dim Style As String
        Dim Flavour As String
        Dim Layer, Size As Integer
        Dim MinPrice, MaxPrice As Double

        'Set All Value 

        Style = ddlStyle.SelectedItem.Value
        Layer = ddlLayer.SelectedItem.Value
        Size = ddlSize.SelectedItem.Value

        MinPrice = CDbl(txtMinPrice.Text)
        MaxPrice = CDbl(txtMaxPrice.Text)

        Dim ret_str As String
        ret_str = "Result_Cake.aspx?Style=" & Style & "&" & "MinPrice=" & MinPrice & "&" & "MaxPrice=" & MaxPrice & "&" & "Layer=" & Layer & "&" & "Size=" & Size
        Response.Redirect(ret_str)

    End Sub

End Class
