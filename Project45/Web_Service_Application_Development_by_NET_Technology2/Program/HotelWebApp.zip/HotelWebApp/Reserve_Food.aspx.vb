Public Class foodreserve
    Inherits System.Web.UI.Page
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlFoodpackageID As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlSeminarRoomList As System.Web.UI.WebControls.DropDownList
    Protected WithEvents lblTimeRange As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents lblReserveDate As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents lblUnit As System.Web.UI.WebControls.Label
    Protected WithEvents lstFoodList As System.Web.UI.WebControls.ListBox
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents txtHH As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtMM As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtFoodAmount As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdCalPrice As System.Web.UI.WebControls.Button
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTotalPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdFoodreserve As System.Web.UI.WebControls.Button

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            Dim i As Integer
            Dim name As New HotelRef.HotelService0()
            Dim ContactID As Integer = Session.Contents("ContactID")
            Dim CSList() As HotelRef.CSeminarReserveInfo = name.Show_All_SeminarRoom_Info(ContactID)
            Dim strAdd As String
            cmdFoodreserve.Visible = True
            If CSList.Length = 0 Then
                lblError.Text = "!!! ��سҨͧʶҹ���Ѵ����§��͹"
                cmdFoodreserve.Visible = False
                Exit Sub
            End If
            For i = 0 To CSList.Length - 1
                strAdd = "��èͧ��� " & CSList(i).seminar_room_job_id & "  ��ͧ" & CSList(i).seminar_room_name
                Dim x As New ListItem()
                x.Text = CStr(strAdd)
                x.Value = CInt(CSList(i).seminar_room_job_id)
                ddlSeminarRoomList.Items.Add(x)
            Next

            'Initial Food Amount
            txtFoodAmount.Text = "0"

            'Input Date and Time Range of Seminar Room Reservation
            lblTimeRange.Text = ""
            Dim find As New HotelRef.HotelService0()
            Dim SeminarJobID As Integer
            SeminarJobID = CInt(ddlSeminarRoomList.SelectedItem.Value)

            'lblUnit
            Dim tb As String = find.Show_SeminarRoom_Table(SeminarJobID)
            If tb = "table" Then
                lblUnit.Text = "���"
            Else
                lblUnit.Text = "���"
            End If

            Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
            Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)

            lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
            Dim t1, t2, t3 As Integer
            t1 = find.Show_SeminarRoom_T1(SeminarJobID)
            t2 = find.Show_SeminarRoom_T2(SeminarJobID)
            t3 = find.Show_SeminarRoom_T3(SeminarJobID)
            If t1 = 1 Then
                lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t2 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If

            If t3 = 1 Then
                lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
            Else
                lblTimeRange.Text = lblTimeRange.Text & ""
            End If
        End If
    End Sub

    Private Sub ddlSeminarRoomList_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlSeminarRoomList.SelectedIndexChanged
        lblTimeRange.Text = ""
        Dim find As New HotelRef.HotelService0()
        Dim SeminarJobID As Integer
        SeminarJobID = CInt(ddlSeminarRoomList.SelectedItem.Value)

        'lblUnit
        Dim tb As String = find.Show_SeminarRoom_Table(SeminarJobID)
        If tb = "table" Then
            lblUnit.Text = "���"
        Else
            lblUnit.Text = "���"
        End If

        Dim seminar_name As String = find.Show_SeminarRoom_Name(SeminarJobID)
        Dim reserve_date As DateTime = find.Show_SeminarRoom_Date(SeminarJobID)

        lblReserveDate.Text = "�ѹ��� " & CStr(reserve_date.Day) & " ��͹ " & CStr(reserve_date.Month) & " ��  " & CStr(reserve_date.Year)
        Dim t1, t2, t3 As Integer
        t1 = find.Show_SeminarRoom_T1(SeminarJobID)
        t2 = find.Show_SeminarRoom_T2(SeminarJobID)
        t3 = find.Show_SeminarRoom_T3(SeminarJobID)
        If t1 = 1 Then
            lblTimeRange.Text = "�����ѹ��� 6.00-11.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        If t2 = 1 Then
            lblTimeRange.Text = lblTimeRange.Text & "�����ѹ���� 12.00-17.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If

        If t3 = 1 Then
            lblTimeRange.Text = lblTimeRange.Text & "��ǧ��� 18.00-23.00 "
        Else
            lblTimeRange.Text = lblTimeRange.Text & ""
        End If
    End Sub


    Private Sub ddlFoodpackageID_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlFoodpackageID.SelectedIndexChanged
        Dim FoodPackageID As Integer
        FoodPackageID = CInt(ddlFoodpackageID.SelectedItem.Value)
        Dim find As New HotelRef.HotelService0()
        Dim foodlst() As String = find.Show_FoodList(FoodPackageID)
        Dim i As Integer
        lstFoodList.Items.Clear()
        For i = 0 To foodlst.Length - 1
            lstFoodList.Items.Add(foodlst(i))
        Next
    End Sub

    Private Sub cmdFoodreserve_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdFoodreserve.Click
        'Check Time
        If txtHH.Text.Length <> 2 Or txtMM.Text.Length <> 2 Then
            lblError.Text = "!!! ��͡����������͹ҷռԴ��Ҵ"
            Exit Sub
        End If

        If CInt(txtFoodAmount.Text) <= 0 Or txtFoodAmount.Text = "0" Or txtFoodAmount.Text.Length = 0 Then
            lblError.Text = "!!! �ô�кبӹǹ������ͷ��"
            Exit Sub
        End If
        
        'Prepare Variable 
        Dim seminar_room_job_id As Integer
        Dim CustID As Integer
        Dim food_package_id As Integer
        Dim food_serve_time As String
        Dim serve_amount As Integer

        CustID = Session.Contents("CustID")
        seminar_room_job_id = CInt(ddlSeminarRoomList.SelectedItem.Value)

        serve_amount = CInt(txtFoodAmount.Text)
        food_serve_time = txtHH.Text & ":" & txtMM.Text & ":" & "00"

        food_package_id = CInt(ddlFoodpackageID.SelectedItem.Value)

        Dim Res As New HotelRef.HotelService0()
        Dim ret As HotelRef.CReturnReserve

        ret = Res.Reserve_Food(CustID, seminar_room_job_id, food_package_id, food_serve_time, serve_amount)
        If ret.str_error = "success" Then
            Dim str_ret As String
            Dim findName As New HotelRef.HotelService0()
            Dim JobName As String = findName.Show_SeminarRoom_Name(seminar_room_job_id)
            str_ret = "exist_job_inseminar.aspx?JobID=" & seminar_room_job_id
            Response.Redirect(str_ret)
        End If
    End Sub

    Private Sub cmdCalPrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCalPrice.Click
        Dim customer_id As Integer
        Dim contact_id As Integer
        Dim food_package_id As Integer
        Dim serve_amount As Integer
        Dim serve_style As String

        If lblUnit.Text = "���" Then
            serve_style = "table"
        Else
            serve_style = "buffet"
        End If
        customer_id = Session.Contents("CustID")
        contact_id = Session.Contents("ContactID")
        food_package_id = CInt(ddlFoodpackageID.SelectedItem.Value)
        serve_amount = CInt(txtFoodAmount.Text)

        'Calculate Price
        Dim Price As New HotelRef.HotelService0()
        Dim PriceAll As Double = Price.Price_Reserve_Food(serve_style, food_package_id, serve_amount)
        lblTotalPrice.Text = CStr(PriceAll)
    End Sub
End Class
