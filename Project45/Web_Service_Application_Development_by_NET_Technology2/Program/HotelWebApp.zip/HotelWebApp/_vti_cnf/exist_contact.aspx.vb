vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Mar 2003 20:18:37 -0000
vti_extenderversion:SR|4.0.2.5526
