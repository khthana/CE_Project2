vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|15 Mar 2003 19:51:10 -0000
vti_extenderversion:SR|4.0.2.5526
vti_backlinkinfo:VX|index2.html
