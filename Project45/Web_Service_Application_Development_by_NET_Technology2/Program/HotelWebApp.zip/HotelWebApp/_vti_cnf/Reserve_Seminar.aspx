vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|16 Mar 2003 20:32:46 -0000
vti_extenderversion:SR|4.0.2.5526
