Public Class exist_contact
    Inherits System.Web.UI.Page
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataSet1 As System.Data.DataSet
    Protected WithEvents DataTable1 As System.Data.DataTable
    Protected WithEvents DataColumn1 As System.Data.DataColumn
    Protected WithEvents DataColumn2 As System.Data.DataColumn
    Protected WithEvents lblHeader As System.Web.UI.WebControls.Label
    Protected WithEvents DataColumn4 As System.Data.DataColumn
    Protected WithEvents DataColumn3 As System.Data.DataColumn

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DataSet1 = New System.Data.DataSet()
        Me.DataTable1 = New System.Data.DataTable()
        Me.DataColumn1 = New System.Data.DataColumn()
        Me.DataColumn2 = New System.Data.DataColumn()
        Me.DataColumn3 = New System.Data.DataColumn()
        Me.DataColumn4 = New System.Data.DataColumn()
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'DataSet1
        '
        Me.DataSet1.DataSetName = "NewDataSet"
        Me.DataSet1.Locale = New System.Globalization.CultureInfo("th-TH")
        Me.DataSet1.Tables.AddRange(New System.Data.DataTable() {Me.DataTable1})
        '
        'DataTable1
        '
        Me.DataTable1.Columns.AddRange(New System.Data.DataColumn() {Me.DataColumn1, Me.DataColumn2, Me.DataColumn3, Me.DataColumn4})
        Me.DataTable1.TableName = "tblContact"
        '
        'DataColumn1
        '
        Me.DataColumn1.ColumnName = "Contact ID"
        Me.DataColumn1.DataType = GetType(System.Int32)
        '
        'DataColumn2
        '
        Me.DataColumn2.ColumnName = "Contact Name"
        Me.DataColumn2.MaxLength = 50
        '
        'DataColumn3
        '
        Me.DataColumn3.ColumnName = "DeadLine"
        '
        'DataColumn4
        '
        Me.DataColumn4.ColumnName = "Pay Date"
        CType(Me.DataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataTable1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            Dim customer_id As Integer
            customer_id = System.Convert.ToInt32(Session.Contents("CustID"))
            If customer_id = 0 Then
                DataGrid1.Visible = False
                lblHeader.Text = ""
                lblHeader.Text = "��سҷӡ�� LOGIN ��͹"
            End If
            BindData()
        End If
    End Sub

    Public Sub BindData()
        Dim Cust As New CustomerRef.CustomerService0()
        Dim customer_id As Integer

        customer_id = System.Convert.ToInt32(Session.Contents("CustID"))
        Dim j, count As Integer
        Dim x() As CustomerRef.CContactInfo = Cust.ViewHotelContact(customer_id)

        ' Insert Into DataGrid
        DataSet1.Tables("tblContact").Clear()
        Dim a As DataTable
        a = DataSet1.Tables("tblContact")

        count = x.Length

        For j = 0 To count - 1
            Dim rc As DataRow
            rc = a.NewRow
            rc("Contact Id") = x(j).hotel_contact_id
            rc("Contact Name") = x(j).hotel_contact_name
            rc("DeadLine") = x(j).deadline_confirm
            Dim str_date As String
            If x(j).pay_date = "1/1/2003" Then
                str_date = "-"
            Else
                str_date = x(j).pay_date
            End If
            rc("Pay Date") = str_date
            a.Rows.Add(rc)
        Next
        DataGrid1.DataBind()
    End Sub

    Private Sub DataGrid1_EditCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.EditCommand
        Dim tmp, tmp2 As String
        tmp = e.Item.Cells(0).Text
        tmp2 = e.Item.Cells(1).Text
        Session.Contents("ContactID") = tmp
        Session.Contents("ContactName") = tmp2
        Response.Redirect("index_reserve.html")
    End Sub

    Private Sub DataGrid1_DeleteCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid1.DeleteCommand
        Dim del As New HotelRef.HotelService0()
        Dim CustID, ContactID As Integer
        CustID = Session.Contents("CustID")
        ContactID = CInt(e.Item.Cells(0).Text)
        del.Delete_Contact(CustID, ContactID)
        Response.Redirect("index_signed.html")
    End Sub
End Class
