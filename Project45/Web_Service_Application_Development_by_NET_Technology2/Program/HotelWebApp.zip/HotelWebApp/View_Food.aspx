<%@ Page Language="vb" AutoEventWireup="false" Codebehind="View_Food.aspx.vb" Inherits="HotelWebApp.View_Food"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>View_Food</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server">
			<FONT face="Tahoma" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
				<asp:Label id="Label1" style="Z-INDEX: 103; LEFT: 166px; POSITION: absolute; TOP: 30px" runat="server" Height="15px" Width="160px" BorderStyle="Ridge" BorderWidth="3px">��������´��èͧᾤࡨ�����</asp:Label>
				<asp:Label id="Label3" style="Z-INDEX: 112; LEFT: 153px; POSITION: absolute; TOP: 190px" runat="server" Width="74px" Height="2px"> ��������������</asp:Label>
				<asp:Label id="Label4" style="Z-INDEX: 110; LEFT: 185px; POSITION: absolute; TOP: 163px" runat="server" Width="44px" Height="12px">�Ҥ����</asp:Label>
				<asp:Label id="lblPrice" style="Z-INDEX: 111; LEFT: 248px; POSITION: absolute; TOP: 162px" runat="server" Width="59px" Height="6px"></asp:Label>
				<asp:Label id="lblServeTime" style="Z-INDEX: 102; LEFT: 248px; POSITION: absolute; TOP: 189px" runat="server" Width="149px" Height="1px"></asp:Label>
				<asp:Label id="Label5" style="Z-INDEX: 105; LEFT: 171px; POSITION: absolute; TOP: 68px" runat="server" Width="54px" Height="15px">��ͧ�Ѵ����§</asp:Label>
				<asp:Label id="lblSeminarRoom" style="Z-INDEX: 101; LEFT: 247px; POSITION: absolute; TOP: 66px" runat="server" Width="148px" Height="6px"></asp:Label>
				<asp:Button id="cmdBack" style="Z-INDEX: 104; LEFT: 195px; POSITION: absolute; TOP: 227px" runat="server" Width="95px" Font-Names="Microsoft Sans Serif" Text="��Ѻ˹����� Job"></asp:Button>
				<asp:Label id="Label6" style="Z-INDEX: 106; LEFT: 148px; POSITION: absolute; TOP: 98px" runat="server" Width="82px" Height="13px">����ᾡࡨ�����</asp:Label>
				<asp:Label id="lblPackageName" style="Z-INDEX: 107; LEFT: 248px; POSITION: absolute; TOP: 95px" runat="server" Width="179px" Height="7px"></asp:Label>
				<asp:Label id="Label10" style="Z-INDEX: 108; LEFT: 152px; POSITION: absolute; TOP: 127px" runat="server" Width="76px" Height="23px">�ѡɳС������</asp:Label>
				<asp:Label id="lblServeStyle" style="Z-INDEX: 109; LEFT: 248px; POSITION: absolute; TOP: 124px" runat="server" Width="147px" Height="5px"></asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 113; LEFT: 313px; POSITION: absolute; TOP: 162px" runat="server" Width="16px" Height="11px">�ҷ</asp:Label></FONT>
		</form>
	</body>
</HTML>
