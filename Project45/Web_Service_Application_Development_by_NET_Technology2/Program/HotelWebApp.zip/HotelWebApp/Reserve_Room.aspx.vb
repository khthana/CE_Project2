Public Class roomreserve
    Inherits System.Web.UI.Page
    Protected WithEvents ddlRoomamount As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlRoomtype As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label13 As System.Web.UI.WebControls.Label
    Protected WithEvents Calendar2 As System.Web.UI.WebControls.Calendar
    Protected WithEvents Calendar1 As System.Web.UI.WebControls.Calendar
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTotalday As System.Web.UI.WebControls.Label
    Protected WithEvents cmdReserveRoom As System.Web.UI.WebControls.Button
    Protected WithEvents chkSmoke As System.Web.UI.WebControls.CheckBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents ddlExtrabed As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents lblTotalPrice As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents cmdCalPrice As System.Web.UI.WebControls.Button
    Protected WithEvents lblError As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
       
        If Not Page.IsPostBack Then
            Dim str_chkout, str_chkin As String
            Dim chkin, chkout As Date

            Calendar1.SelectedDate = DateTime.Now
            str_chkin = "�ѹ��� " & DateTime.Now.Day & " ��͹ " & DateTime.Now.Month & " �� " & DateTime.Now.Year
            'lblCheckin.Text = str_chkin

            Calendar2.SelectedDate = DateTime.Now
            str_chkout = "�ѹ��� " & DateTime.Now.Day & " ��͹ " & DateTime.Now.Month & " �� " & DateTime.Now.Year
            'lblCheckout.Text = str_chkout
        End If
    End Sub

    'Private Sub Calendar1_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Calendar1.SelectionChanged
    '    Dim chkin, chkout As Date
    '    Dim str_chkout, str_chkin As String

    '    chkin = Calendar1.SelectedDate()
    '    str_chkin = "�ѹ��� " & chkin.Day & " ��͹ " & chkin.Month & " �� " & chkin.Year
    '    ' lblCheckin.Text = str_chkin

    '    chkout = Calendar2.SelectedDate()
    '    str_chkout = "�ѹ��� " & chkout.Day & " ��͹ " & chkout.Month & " �� " & chkout.Year
    '    ' lblCheckout.Text = str_chkout
    'End Sub

    Private Sub Calendar2_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Calendar2.SelectionChanged
        Dim chkout, chkin As Date
        Dim str_chkout, str_chkin As String

        chkout = Calendar2.SelectedDate()
        str_chkout = "�ѹ��� " & chkout.Day & " ��͹ " & chkout.Month & " �� " & chkout.Year
        ' lblCheckout.Text = str_chkout
        chkin = Calendar1.SelectedDate()
        str_chkin = "�ѹ��� " & chkin.Day & " ��͹ " & chkin.Month & " �� " & chkin.Year
        'lblCheckin.Text = str_chkin

        Dim x As TimeSpan
        x = Calendar2.SelectedDate.Subtract(Calendar1.SelectedDate)
        Dim total_day As Int32
        total_day = x.Days
        lblTotalday.Text = total_day
    End Sub

    Private Sub cmdReserveRoom_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReserveRoom.Click
        'Check Date FIRST!
        If Calendar1.SelectedDate <= DateTime.Now Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If Calendar2.SelectedDate <= DateTime.Now Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If Calendar1.SelectedDate = Calendar2.SelectedDate Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If Calendar2.SelectedDate <= Calendar1.SelectedDate Then
            lblError.Text = "!!! �ѹ���ͧ�Դ��Ҵ �ô���͡�ѹ����"
            Exit Sub
        End If

        If lblTotalPrice.Text = "0" Then
            lblError.Text = ""
            lblError.Text = "!!! �Ҥ�����Դ��Ҵ �ô��Ǩ�ͺ������"
            Exit Sub
        End If

        ' Prepare Value to Call Reserve Method
        Dim room_type As String
        Dim room_amount As Integer
        Dim customer_id As Integer
        Dim contact_id As Integer
        Dim chkin_date As String
        Dim chkout_date As String
        Dim amount_extrabed As Integer
        Dim smoke As Integer

        room_type = ddlRoomtype.SelectedItem.Value
        room_amount = ddlRoomamount.SelectedItem.Text
        customer_id = Session.Contents("CustID")
        contact_id = Session.Contents("ContactID")

        Dim tmp1, tmp2 As Date
        tmp1 = Calendar1.SelectedDate
        tmp2 = Calendar2.SelectedDate

        ' Manage DateTime
        Dim dd1, mm1 As String
        If (tmp1.Day >= 1 And tmp1.Day <= 9) Then
            dd1 = "0" & tmp1.Day
        Else
            dd1 = tmp1.Day
        End If

        If (tmp1.Month >= 1 And tmp1.Month <= 9) Then
            mm1 = "0" & tmp1.Month
        Else
            mm1 = tmp1.Month
        End If
        chkin_date = dd1 & " " & mm1 & " " & tmp1.Year

        Dim dd2, mm2 As String
        If (tmp2.Day >= 1 And tmp2.Day <= 9) Then
            dd2 = "0" & tmp2.Day
        Else
            dd2 = tmp2.Day
        End If

        If (tmp2.Month >= 1 And tmp2.Month <= 9) Then
            mm2 = "0" & tmp2.Month
        Else
            mm2 = tmp2.Month
        End If
        chkout_date = dd2 & " " & mm2 & " " & tmp2.Year

        If chkSmoke.Checked = True Then
            smoke = 1
        Else
            smoke = 0
        End If
        amount_extrabed = CInt(ddlExtrabed.SelectedItem.Text)

        'Reserve Room
        Dim Reserve As New HotelRef.HotelService0()
        Dim ReturnReserve() As HotelRef.CReturnReserve = Reserve.Reserve_Room(customer_id, contact_id, room_amount, room_type, chkin_date, chkout_date, amount_extrabed, smoke)

        Dim count As Integer = ReturnReserve.Length
        Dim i As Integer
        Dim deadline As String
        Dim price As Double
        Dim job_id As Integer

        For i = 0 To count - 1
            job_id = ReturnReserve(i).job_id
            price = ReturnReserve(i).price
            deadline = ReturnReserve(i).deadline
        Next

        Response.Redirect("exist_job.aspx")

    End Sub


    Private Sub cmdCalPrice_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdCalPrice.Click
        ' Prepare Value to Call Reserve Method
        Dim room_type As String
        Dim room_amount As Integer
        Dim customer_id As Integer
        Dim contact_id As Integer
        Dim chkin_date As String
        Dim chkout_date As String
        Dim amount_extrabed As Integer
        Dim smoke As Integer

        room_type = ddlRoomtype.SelectedItem.Value
        room_amount = ddlRoomamount.SelectedItem.Text
        customer_id = Session.Contents("CustID")
        contact_id = Session.Contents("ContactID")

        Dim tmp1, tmp2 As Date
        tmp1 = Calendar1.SelectedDate
        tmp2 = Calendar2.SelectedDate

        ' Manage DateTime
        Dim dd1, mm1 As String
        If (tmp1.Day >= 1 And tmp1.Day <= 9) Then
            dd1 = "0" & tmp1.Day
        Else
            dd1 = tmp1.Day
        End If

        If (tmp1.Month >= 1 And tmp1.Month <= 9) Then
            mm1 = "0" & tmp1.Month
        Else
            mm1 = tmp1.Month
        End If
        chkin_date = dd1 & " " & mm1 & " " & tmp1.Year

        Dim dd2, mm2 As String
        If (tmp2.Day >= 1 And tmp2.Day <= 9) Then
            dd2 = "0" & tmp2.Day
        Else
            dd2 = tmp2.Day
        End If

        If (tmp2.Month >= 1 And tmp2.Month <= 9) Then
            mm2 = "0" & tmp2.Month
        Else
            mm2 = tmp2.Month
        End If
        chkout_date = dd2 & " " & mm2 & " " & tmp2.Year

        If chkSmoke.Checked = True Then
            smoke = 1
        Else
            smoke = 0
        End If
        amount_extrabed = CInt(ddlExtrabed.SelectedItem.Text)

        'Calculate Price
        Dim Price As New HotelRef.HotelService0()
        Dim PriceAll As Double = Price.Price_Reserve_Room(customer_id, contact_id, room_amount, room_type, chkin_date, chkout_date, amount_extrabed, smoke)
        lblTotalPrice.Text = CStr(PriceAll)

    End Sub

    'Private Sub ddlRoomamount_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ddlRoomamount.SelectedIndexChanged
    '    ddlExtrabed()
    '    Dim i, room_count As Integer
    '    room_count = CInt(ddlRoomamount.SelectedItem.Text)
    '    ddlExtrabed.Cl()
    '    For i = 1 To room_count
    '        ddlExtrabed.DataTextField = i
    '    Next

    'End Sub
End Class
