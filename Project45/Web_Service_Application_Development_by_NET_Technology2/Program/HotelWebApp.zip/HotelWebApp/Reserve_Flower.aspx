<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Reserve_Flower.aspx.vb" Inherits="HotelWebApp.flowerreserve" codePage="874"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>flowerreserve</title>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<META content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<META content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<META content="JavaScript" name="vs_defaultClientScript">
		<META content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<BODY bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<FORM id="Form1" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" method="post" runat="server">
			<asp:Label id="Label2" style="Z-INDEX: 104; LEFT: 199px; POSITION: absolute; TOP: 60px" runat="server" Width="234px">��¡�èͧ��ͧ����ҷ���ͧ�������ᾤࡨ�͡���</asp:Label>
			<asp:label id="lblError" style="Z-INDEX: 116; LEFT: 221px; POSITION: absolute; TOP: 280px" runat="server" Width="165px" Height="15px"></asp:label>
			<asp:label id="Label11" style="Z-INDEX: 115; LEFT: 257px; POSITION: absolute; TOP: 24px" runat="server" Width="107px" Height="7px" BorderWidth="3px" BorderStyle="Ridge">��觨ͧᾡࡨ�͡���</asp:label>
			<asp:label id="Label10" style="Z-INDEX: 113; LEFT: 207px; POSITION: absolute; TOP: 119px" runat="server" Width="40px" Font-Names="Microsoft Sans Serif" Height="14px" Font-Size="10pt">�ѹ���ͧ</asp:label>
			<asp:label id="lblReserveDate" style="Z-INDEX: 105; LEFT: 263px; POSITION: absolute; TOP: 120px" runat="server" Width="220px" Height="18px"></asp:label>
			<asp:label id="Label9" style="Z-INDEX: 109; LEFT: 182px; POSITION: absolute; TOP: 146px" runat="server" Width="67px" Height="21px">��ǧ���ҷ��ͧ</asp:label>
			<asp:label id="lblTimeRange" style="Z-INDEX: 112; LEFT: 263px; POSITION: absolute; TOP: 147px" runat="server" Width="328px" Height="19px"></asp:label>
			<asp:dropdownlist id="ddlSeminarRoomList" style="Z-INDEX: 106; LEFT: 188px; POSITION: absolute; TOP: 89px" runat="server" Width="253px" Font-Names="Microsoft Sans Serif" AutoPostBack="True"></asp:dropdownlist>
			<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 93px; POSITION: absolute; TOP: 185px" runat="server" Width="156px" Height="11px">ᾤࡨ�͡����дѺ��ͧ�Ѵ����§</asp:Label>
			<asp:DropDownList id="ddlFlowerPackage" style="Z-INDEX: 102; LEFT: 265px; POSITION: absolute; TOP: 184px" runat="server" Width="232px" Font-Names="Microsoft Sans Serif" AutoPostBack="True">
				<asp:ListItem Value="1">ᾤࡨ A �͡����觧ҹ</asp:ListItem>
				<asp:ListItem Value="2">ᾤࡨ B �͡����дѺ��ͧ+�Ƿ�</asp:ListItem>
				<asp:ListItem Value="3">ᾤࡨ C �͡����дѺ�Ƿ�</asp:ListItem>
			</asp:DropDownList>
			<asp:Button id="cmdReserve" style="Z-INDEX: 103; LEFT: 265px; POSITION: absolute; TOP: 306px" runat="server" Width="78px" Font-Names="Microsoft Sans Serif" Text="��ŧ" Height="24px"></asp:Button>
			<asp:DropDownList id="ddlFlowerTimeRange" style="Z-INDEX: 107; LEFT: 265px; POSITION: absolute; TOP: 247px" runat="server" Width="67px" Height="18px">
				<asp:ListItem Value="1">��ǧ���</asp:ListItem>
				<asp:ListItem Value="2">��ǧ����</asp:ListItem>
				<asp:ListItem Value="3">��ǧ���</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label3" style="Z-INDEX: 108; LEFT: 142px; POSITION: absolute; TOP: 249px" runat="server" Width="106px" Height="10px">��ǧ���ҡ�èͧ�͡���</asp:Label>
			<asp:Label id="Label4" style="Z-INDEX: 110; LEFT: 157px; POSITION: absolute; TOP: 216px" runat="server" Width="90px" Height="15px">�Ҥ�ᾡࡨ�͡���</asp:Label>
			<asp:Label id="lblPrice" style="Z-INDEX: 111; LEFT: 265px; POSITION: absolute; TOP: 217px" runat="server" Width="43px"></asp:Label>
			<asp:Label id="Label5" style="Z-INDEX: 114; LEFT: 324px; POSITION: absolute; TOP: 217px" runat="server" Width="33px">�ҷ</asp:Label>
			<asp:Label id="Label6" style="Z-INDEX: 117; LEFT: 286px; POSITION: absolute; TOP: 341px" runat="server" Width="46px" Height="27px"></asp:Label></FORM>
	</BODY>
</HTML>
