<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Signup_yes.aspx.vb" Inherits="HotelWebApp.Signup_yes"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Signup_yes</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 101; LEFT: 99px; POSITION: absolute; TOP: 91px" runat="server" Width="344px" Height="20px" Font-Size="13pt">�Թ�յ�͹�Ѻ����к���Ҫԡ Olala Hotel Bangkok</asp:Label>
				<asp:Label id="Label2" style="Z-INDEX: 102; LEFT: 183px; POSITION: absolute; TOP: 136px" runat="server" Width="144px" Height="8px">��سҷӡ�� Login �������к�</asp:Label></FONT>
		</form>
	</body>
</HTML>
