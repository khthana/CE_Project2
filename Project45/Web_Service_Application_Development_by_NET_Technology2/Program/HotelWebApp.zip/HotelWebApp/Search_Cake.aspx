<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Search_Cake.aspx.vb" Inherits="HotelWebApp.Search_Cake"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Search_Cake</title>
		<meta name="GENERATOR" content="Microsoft Visual Studio.NET 7.0">
		<meta name="CODE_LANGUAGE" content="Visual Basic 7.0">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" bgColor="#ecebd7">
		<form id="Form1" method="post" runat="server" style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'">
			<asp:Label id="Label1" style="Z-INDEX: 115; LEFT: 211px; POSITION: absolute; TOP: 34px" runat="server" Width="58px" Height="5px" BorderStyle="Ridge" BorderWidth="3px">
				<center>������</center>
			</asp:Label>
			<asp:dropdownlist id="ddlStyle" style="Z-INDEX: 116; LEFT: 197px; POSITION: absolute; TOP: 74px" runat="server" Width="129px" AutoPostBack="True" Font-Names="Microsoft Sans Serif">
				<asp:ListItem Value=" ">����к�</asp:ListItem>
				<asp:ListItem Value="chocolate cake">chocolate cake</asp:ListItem>
				<asp:ListItem Value="sugar cake">sugar cake</asp:ListItem>
				<asp:ListItem Value="cream cake">cream cake</asp:ListItem>
				<asp:ListItem Value="fruit cake">fruit cake</asp:ListItem>
				<asp:ListItem Value="coffee cream cake">coffee cream cake</asp:ListItem>
				<asp:ListItem Value="vanilla cream cake">vanilla cream cake</asp:ListItem>
			</asp:dropdownlist>
			<asp:DropDownList id="ddlSize" style="Z-INDEX: 106; LEFT: 197px; POSITION: absolute; TOP: 143px" runat="server" Width="38px">
				<asp:ListItem Value="2">2</asp:ListItem>
				<asp:ListItem Value="3">3</asp:ListItem>
				<asp:ListItem Value="4">4</asp:ListItem>
				<asp:ListItem Value="5">5</asp:ListItem>
				<asp:ListItem Value="6">6</asp:ListItem>
				<asp:ListItem Value="7">7</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label2" style="Z-INDEX: 100; LEFT: 124px; POSITION: absolute; TOP: 80px" runat="server" Width="44px" Height="6px">������</asp:Label>
			<asp:Label id="Label4" style="Z-INDEX: 102; LEFT: 119px; POSITION: absolute; TOP: 113px" runat="server" Width="63px" Height="6px">�ӹǹ���</asp:Label>
			<asp:DropDownList id="ddlLayer" style="Z-INDEX: 103; LEFT: 197px; POSITION: absolute; TOP: 107px" runat="server" Width="38px">
				<asp:ListItem Value="1">1</asp:ListItem>
				<asp:ListItem Value="2">2</asp:ListItem>
				<asp:ListItem Value="3">3</asp:ListItem>
				<asp:ListItem Value="4">4</asp:ListItem>
				<asp:ListItem Value="5">5</asp:ListItem>
				<asp:ListItem Value="6">6</asp:ListItem>
				<asp:ListItem Value="7">7</asp:ListItem>
				<asp:ListItem Value="8">8</asp:ListItem>
				<asp:ListItem Value="9">9</asp:ListItem>
			</asp:DropDownList>
			<asp:Label id="Label5" style="Z-INDEX: 104; LEFT: 120px; POSITION: absolute; TOP: 144px" runat="server" Width="44px" Height="6px">��Ҵ��</asp:Label>
			<asp:Label id="Label6" style="Z-INDEX: 107; LEFT: 249px; POSITION: absolute; TOP: 112px" runat="server" Width="19px">���</asp:Label>
			<asp:Label id="Label7" style="Z-INDEX: 108; LEFT: 250px; POSITION: absolute; TOP: 143px" runat="server" Width="30px">�͹��</asp:Label>
			<asp:Label id="Label8" style="Z-INDEX: 109; LEFT: 121px; POSITION: absolute; TOP: 178px" runat="server" Width="62px" Height="6px">�Ҥ������ҧ</asp:Label>
			<asp:TextBox id="txtMinPrice" style="Z-INDEX: 110; LEFT: 197px; POSITION: absolute; TOP: 176px" runat="server" Width="57px" MaxLength="5" Font-Names="Microsoft Sans Serif"></asp:TextBox>
			<asp:Label id="Label9" style="Z-INDEX: 111; LEFT: 263px; POSITION: absolute; TOP: 179px" runat="server">�֧</asp:Label>
			<asp:TextBox id="txtMaxPrice" style="Z-INDEX: 112; LEFT: 283px; POSITION: absolute; TOP: 177px" runat="server" Width="62px" MaxLength="5" Font-Names="Microsoft Sans Serif"></asp:TextBox>
			<asp:Label id="Label10" style="Z-INDEX: 113; LEFT: 355px; POSITION: absolute; TOP: 178px" runat="server">�ҷ</asp:Label>
			<asp:Button id="cmdSearch" style="Z-INDEX: 114; LEFT: 196px; POSITION: absolute; TOP: 215px" runat="server" Font-Names="Microsoft Sans Serif" Text="�ӡ�ä���"></asp:Button>
		</form>
	</body>
</HTML>
