Public Class left_signed
    Inherits System.Web.UI.Page
    Protected WithEvents lblWelcome As System.Web.UI.WebControls.Label
    Protected WithEvents WebForm1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Table1 As System.Web.UI.HtmlControls.HtmlTable

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim CustID As Int32
        CustID = Session.Contents("CustID")
        Dim Cust As New CustomerRef.CustomerService0()
        Dim CustName As String
        CustName = Cust.ViewFirstname(CustID)
        If CustName <> "" Then
            lblWelcome.Text = "�س" + CustName
        Else
            lblWelcome.Text = ""
        End If
    End Sub

End Class
