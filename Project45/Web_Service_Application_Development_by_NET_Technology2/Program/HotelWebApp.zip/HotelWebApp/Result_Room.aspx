<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Result_Room.aspx.vb" Inherits="HotelWebApp.Result_Room"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title>Result_Room</title>
		<meta content="Microsoft Visual Studio.NET 7.0" name="GENERATOR">
		<meta content="Visual Basic 7.0" name="CODE_LANGUAGE">
		<meta content="JavaScript" name="vs_defaultClientScript">
		<meta content="http://schemas.microsoft.com/intellisense/ie5" name="vs_targetSchema">
	</HEAD>
	<body bgColor="#ecebd7" MS_POSITIONING="GridLayout">
		<form id="Form1" method="post" runat="server">
			<FONT style="FONT-SIZE: 10pt; FONT-FAMILY: 'Microsoft Sans Serif'" face="Tahoma">
				<asp:Label id="Label1" style="Z-INDEX: 100; LEFT: 268px; POSITION: absolute; TOP: 28px" runat="server" Width="97px" Height="17px" BorderStyle="Ridge" BorderWidth="3px">
					<center>���Ѿ���ä���</center>
				</asp:Label>
				<asp:ImageButton id="Image1" style="Z-INDEX: 110; LEFT: 120px; POSITION: absolute; TOP: 74px" runat="server" Height="122px" Width="189px" ImageAlign="Middle"></asp:ImageButton>
				<asp:label id="Label2" style="Z-INDEX: 103; LEFT: 221px; POSITION: absolute; TOP: 222px" runat="server" Width="89px" Height="13px">��ͧ����������繪�Դ</asp:label>
				<asp:label id="Label3" style="Z-INDEX: 104; LEFT: 249px; POSITION: absolute; TOP: 286px" runat="server" Width="57px" Height="2px"> �Ҥ���ͧ�ѡ</asp:label>
				<asp:label id="Label4" style="Z-INDEX: 105; LEFT: 246px; POSITION: absolute; TOP: 254px" runat="server" Width="61px" Height="8px"> ��Ҵ��ͧ�ѡ</asp:label>
				<asp:label id="lblRoomType" style="Z-INDEX: 106; LEFT: 320px; POSITION: absolute; TOP: 221px" runat="server" Width="103px" Height="6px"></asp:label>
				<asp:label id="lblRoomSize" style="Z-INDEX: 107; LEFT: 320px; POSITION: absolute; TOP: 252px" runat="server" Width="108px" Height="3px"></asp:label>
				<asp:ImageButton id="Image2" style="Z-INDEX: 102; LEFT: 321px; POSITION: absolute; TOP: 74px" runat="server" Width="189px" Height="122px" ImageAlign="Middle"></asp:ImageButton>
				<asp:Label id="lblRoomPrice" style="Z-INDEX: 108; LEFT: 320px; POSITION: absolute; TOP: 285px" runat="server" Width="107px" Height="2px"></asp:Label>
				<asp:Label id="Label7" style="Z-INDEX: 109; LEFT: 287px; POSITION: absolute; TOP: 335px" runat="server" Height="26px" Width="40px"></asp:Label></FONT></form>
	</body>
</HTML>
