Public Class signup
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents txtName As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtSurname As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents txtAddress As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtTel As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents txtEmail As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents Label11 As System.Web.UI.WebControls.Label
    Protected WithEvents Label12 As System.Web.UI.WebControls.Label
    Protected WithEvents txtPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents txtUsername As System.Web.UI.WebControls.TextBox
    Protected WithEvents cmdSubmit As System.Web.UI.WebControls.Button
    Protected WithEvents cmdReset As System.Web.UI.WebControls.Button
    Protected WithEvents txtAge As System.Web.UI.WebControls.TextBox
    Protected WithEvents ddlSex As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not Page.IsPostBack Then
            txtName.Text = ""
            txtSurname.Text = ""
            txtAddress.Text = ""
            txtEmail.Text = ""
            txtTel.Text = ""
            txtAge.Text = ""
            txtUsername.Text = ""
            txtPassword.Text = ""
        End If
    End Sub

    Private Sub cmdReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdReset.Click
        txtName.Text = ""
        txtSurname.Text = ""
        txtAddress.Text = ""
        txtEmail.Text = ""
        txtTel.Text = ""
        txtAge.Text = ""
        txtUsername.Text = ""
        txtPassword.Text = ""
    End Sub

    Private Sub cmdSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSubmit.Click
        Dim fname As String = txtName.Text
        Dim lname As String = txtSurname.Text
        Dim usern As String = txtUsername.Text
        Dim pass As String = txtPassword.Text

        'If fname = "" Or fname = " " Then
        '    lblError.Text = "��سҡ�͡ ����"
        '    Exit Sub
        'End If
        'If lname = "" Or lname = " " Then
        '    lblError.Text = "��سҡ�͡ ���ʡ��"
        '    Exit Sub
        'End If
        'If usern = "" Or usern = " " Then
        '    lblError.Text = "��سҡ�͡ Username"
        '    Exit Sub
        'End If
        'If pass = "" Or pass = "" Then
        '    lblError.Text = "��سҡ�͡ Password"
        '    Exit Sub
        'End If

        Dim sex As String = ddlSex.SelectedItem.Value
        Dim age As Short = txtAge.Text
        Dim tel As String = txtTel.Text
        Dim addr As String = txtAddress.Text
        Dim email As String = txtEmail.Text

        Dim regis As New CustomerRef.CustomerService0()
        Dim canSignUp As Boolean
        canSignUp = regis.Signup(fname, lname, sex, age, tel, addr, email, usern, pass)
        If canSignUp = True Then
            Response.Redirect("Signup_yes.aspx")
        Else
            Response.Redirect("Signup_no.aspx")
        End If

    End Sub
End Class
