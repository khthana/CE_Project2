import java.io.*;

class XMLparser {

    /** member of this**/
    public String output_tag[]=new String[50];  //Get node first attribute let's put tag
    public String output_tag_attr[]=new String[50]; //attribute of current tag;
    public String output_value[]=new String[50]; //,another put value
    private int NumberOfAttribute=0;  //Use for getcurrent before next();




    /** Creates a new instance of XMLparser */

    XMLparser() {}//Constructure

    void Parser(String str)

    {
        String version=new String("unknow");

        boolean open_tag;
        open_tag=false;

        boolean close_tag;
        close_tag=true;


        //  Loop variable /
        int i;
        i=0;
        int j;
        j=0;
        int k;
        k=0;
        /****************/

        char debug;// used for debug in some time

      for (i=0;i<str.length()-1;i++)
      {
     debug=str.charAt(i);
      if ((str.charAt(i)=='<')&&(open_tag==false)&&(close_tag==true))// check open tag
      {open_tag=true;close_tag=false;}

      else if (open_tag)//check tag
      {
           switch(str.charAt(i))
                {

                case'?':{

                    for (j=i;(str.charAt(j)!='v');j++){}
                    System.out.println("XML Version = "+str.substring(j+9,j+12));//Display Version
                    for(j=j+12;(str.charAt(j)!='e');j++){}
                    for(k=j;(str.charAt(k)!='?');k++){}
                    System.out.println("XML Encoding = "+str.substring(j+10,k-1));//Display Encoding
                    //for (j=i;(str.charAt(j)!='>');j++){  System.out.println(str.charAt(j));}
                    for(j=k;(str.charAt(j)!='>');j++){close_tag=true;}
                    for(j=k;(str.charAt(j)!='\n');j++){open_tag=false;}
                    i=j;
                break;
                }

                case'!':{
                    for (j=i;(str.charAt(j)!='D');j++){}
                    for(k=j;(str.charAt(k)!='U');k++){}
                    System.out.println("Document type = "+str.substring(j+8,k-1));//Display Doctype

                    for(j=k-1;(str.charAt(j)!='>');j++){close_tag=true;}
                    i=str.length();

                break;
                }  //end teg
               default:;break;
           }//End switch i+1
     }

     else if ((str.charAt(i)=='>')&&(open_tag==false))
     {}

      }//end for string loop

      }//end function parser



/// get node of parser
    boolean Getnode(String str)
    {


        int count=0;

                //  Loop variable /
        int i;
        i=0;
        int j;
        j=0;
        int k;
        k=0;

        boolean open_tag;
        open_tag=false;

//A
        boolean a_href_tag;
        a_href_tag=false;

//B
        boolean b_tag;
        b_tag=false;
        boolean body_tag;
        body_tag=false;
        boolean big_tag;
        big_tag=false;
     //  <br /> not use

//F
        boolean form_tag; //form
        form_tag=false;
//H
        boolean h1_tag;
        h1_tag=false;
        boolean h2_tag;
        h2_tag=false;
        boolean h3_tag;
        h3_tag=false;
        boolean h4_tag;
        h4_tag=false;
        boolean h5_tag;
        h5_tag=false;
        boolean h6_tag;
        h6_tag=false;
        boolean h7_tag;
        h7_tag=false;

        boolean  head_tag;
        head_tag=false;

        boolean html_tag;
        html_tag=false;

        //  <hr /> not use
//i
        boolean i_tag;
        i_tag=false;
        //img not used
//l
        boolean li_tag;
        li_tag=false;
//Ool
        boolean ol_tag;
        ol_tag=false;
//P
        boolean p_tag;
        p_tag=false;

//T
        boolean title_tag;
        title_tag=false;
//U
        boolean ul_tag;
        ul_tag=false;

        boolean u_tag;
        u_tag=false;


        char debug;// used for debug in some time
        char debug2;// used for debug in some time

        for (i=0;i<str.length()-1;i++)
      {
       debug=str.charAt(i);
       debug2=str.charAt(i+1);
    // open_tag_debug=open_tag;
      if ((str.charAt(i)=='<')&&(open_tag==false))// check open tag
      {open_tag=true;}

     else if (open_tag)
     {
     switch  (str.charAt(i))
                {

               case'a':{
                   if ((str.charAt(i+2)=='h')&&(a_href_tag==false))
                   {

                        for(j=i;(str.charAt(j)!='"');j++){}
                        for(k=j+1;(str.charAt(k)!='"');k++){}
                        System.out.println("<a href= "+str.substring(j+1,k));//Display Atribute
                        output_tag_attr[count]=str.substring(j+1,k);
                        output_tag[count]="<a href>";

                      //  System.out.println(""+str.substring(j+1,k));//Display Encoding
                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding
                        output_value[count++]=str.substring(j+1,k);

                        NumberOfAttribute=NumberOfAttribute+1;

                        a_href_tag=true;
                        open_tag=false;
                        break;
                   }
                        break;
                        }

               case'b':{


                 if ((str.charAt(i+1)=='>')&&(b_tag==false))
                 {
                   System.out.println("<b>");
                  output_tag[count]="<b>";
                  output_tag_attr[count]="NONE";

                  for(j=i;(str.charAt(j)!='>');j++){}
                  for(k=j;(str.charAt(k)!='<');k++){}
                  System.out.println(""+str.substring(j+1,k));//Display Encoding

                  output_value[count++]=str.substring(j+1,k);
                  NumberOfAttribute=NumberOfAttribute+1;

                  b_tag=true;
                  open_tag=false;
                  break;
                 }

                 if ((str.charAt(i+1)=='o')&&(body_tag==false))
                 {
                   System.out.println("<body>");
                   output_tag[count]="<body>";
                   output_tag_attr[count]="NONE";

                   for(j=i;(str.charAt(j)!='>');j++){}
                   for(k=j;(str.charAt(k)!='<');k++){}
                   System.out.println(""+str.substring(j+1,k));//Display Encoding

                   output_value[count++]=str.substring(j+1,k);
                   NumberOfAttribute=NumberOfAttribute+1;

                   body_tag=true;
                   open_tag=false;
                   break;
                 }

                  if ((str.charAt(i+1)=='i')&&(big_tag==false))//big tag
                    {
                        System.out.println("<big>");
                        output_tag[count]="<big>";
                        output_tag_attr[count]="NONE";

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        big_tag=true;
                        open_tag=false;
                        break;
                    }

                  //Must cut <br/> or not coz not used but we will use <br />
                    if (((str.charAt(i+1)=='r')&&(str.charAt(i+2)=='/')&&(str.charAt(i+3)=='>')) || ((str.charAt(i+1)=='r')&&(str.charAt(i+3)=='/')&&(str.charAt(i+4)=='>')))
                    {

                        output_tag[count]="<br/>";
                        output_tag_attr[count]="NONE";
                        System.out.println("<br />");

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;
                        open_tag=false;
                        break;
                    }

                    break;
                    }


               case'f':{
                 if ((str.charAt(i+1)=='o')&&(str.charAt(i+2)=='r')&&(str.charAt(i+3)=='m')&&(form_tag==false))
                       {
                  output_tag[count]="<form>";

                  for(j=i+4;(str.charAt(j)!='>');j++){}
                  System.out.println("<form>");

                  System.out.println("form attribute ->"+str.substring(i+4,j));//Display Atribute
                  output_tag_attr[count]=str.substring(i+4,j);

                  for(j=i;(str.charAt(j)!='>');j++){}
                  for(k=j;(str.charAt(k)!='<');k++){}
                  System.out.println(""+str.substring(j+1,k));//Display Encoding
                  output_value[count++]=str.substring(j+1,k);

                  NumberOfAttribute=NumberOfAttribute+1;


                  form_tag=true;
                  open_tag=false;
                        break;
                       }

                  break;
                }//End form

               case'h':{

                   if ((str.charAt(i+1)=='1')&&(h1_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h1>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("<h1>");
                        h1_tag=true;
                        open_tag=false;
                        break;
                    }

                           if ((str.charAt(i+1)=='2')&&(h2_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h2>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("<h2>");
                        h2_tag=true;
                        open_tag=false;
                        break;
                    }

                       if ((str.charAt(i+1)=='3')&&(h3_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h3>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("<h3>");
                        h3_tag=true;
                        open_tag=false;
                        break;
                    }

                        if ((str.charAt(i+1)=='4')&&(h4_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h4>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("<h4>");
                        h4_tag=true;
                        open_tag=false;
                        break;
                    }

                        if ((str.charAt(i+1)=='5')&&(h5_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h5>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                       System.out.println("<h5>");
                        h5_tag=true;
                        open_tag=false;
                        break;
                    }

                        if ((str.charAt(i+1)=='6')&&(h6_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h6>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;
                       System.out.println("<h6>");
                        h6_tag=true;
                        open_tag=false;
                        break;
                    }

                        if ((str.charAt(i+1)=='7')&&(h7_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<h7>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                       System.out.println("<h7>");
                        h7_tag=true;
                        open_tag=false;
                        break;
                    }

                    if ((str.charAt(i+1)=='e')&&(head_tag==false))
                    {
                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<head>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;
                        System.out.println("<head>");
                        head_tag=true;
                        open_tag=false;
                        break;
                    }

                   //Must cut <hr/> or not coz not used but we will use <hr />
                    if ((str.charAt(i+1)=='r')&&(str.charAt(i+3)=='/')&&(str.charAt(i+4)=='>'))
                    {
             //           t="hr";
                        System.out.println("<hr />");
                        output_tag[count]="<hr/>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]="NONE";
                        NumberOfAttribute=NumberOfAttribute+1;

                        open_tag=false;
                        break;
                    }

                    if ((str.charAt(i+1)=='t')&&(html_tag==false))
                    {
                        System.out.println("<html>");
                        output_tag[count]="<html>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]="NONE";
                        NumberOfAttribute=NumberOfAttribute+1;
                        html_tag=true;
                        open_tag=false;
                        break;
                    }
                    break;

                        }

               case'i':{
                if ((str.charAt(i+1)=='>') && (i_tag==false))
                {
                  System.out.println("<i>");
                 output_tag[count]="<i>";
                 output_tag_attr[count]="NONE";

                 for(j=i;(str.charAt(j)!='>');j++){}
                 for(k=j;(str.charAt(k)!='<');k++){}
                 System.out.println(""+str.substring(j+1,k));//Display Encoding

                 output_value[count++]=str.substring(j+1,k);
                 NumberOfAttribute=NumberOfAttribute+1;

                 i_tag=true;
                 open_tag=false;
                 break;
                }

//imgage
                if (str.charAt(i+1)=='m')

                    {
                    output_tag[count]="<img>";

                    for(j=i+3;(str.charAt(j)!='>');j++){}
                    System.out.println("<img>");

                    System.out.println("img attribute ->"+str.substring(i+3,j));//Display Atribute
                    output_tag_attr[count]=str.substring(i+3,j);

                    for(j=i;(str.charAt(j)!='>');j++){}
                    for(k=j;(str.charAt(k)!='<');k++){}
                    System.out.println(""+str.substring(j+1,k));//Display Encoding
                    output_value[count++]=str.substring(j+1,k);

                    NumberOfAttribute=NumberOfAttribute+1;

                    open_tag=false;
                        break;
                    }


                 if ((str.charAt(i+1)=='n')&&(form_tag==true))

                   {
                   output_tag[count]="<input>";

                 for(j=i+5;(str.charAt(j)!='>');j++){}
                 System.out.println("<input>");

                 System.out.println("input attribute ->"+str.substring(i+5,j));//Display Atribute
                 output_tag_attr[count]=str.substring(i+5,j);

                 for(j=i;(str.charAt(j)!='>');j++){}
                 for(k=j;(str.charAt(k)!='<');k++){}
                 System.out.println(""+str.substring(j+1,k));//Display Encoding
                 output_value[count++]=str.substring(j+1,k);

                 NumberOfAttribute=NumberOfAttribute+1;

                 open_tag=false;
                        break;
                   }

                 break;
                        }

                case'l':{

                    if ((str.charAt(i+1)=='i')&&((ul_tag==true)||(ol_tag==true)))
                    {

                      for(j=i;(str.charAt(j)!='>');j++){}
                      for(k=j;(str.charAt(k)!='<');k++){}
                      System.out.println(""+str.substring(j+1,k));//Display Encoding

                      output_tag[count]="<li>";
                      output_tag_attr[count]="NONE";
                      output_value[count++]=str.substring(j+1,k);
                      NumberOfAttribute=NumberOfAttribute+1;

                      System.out.println("<li>");
                      li_tag=true;
                      open_tag=false;
                      break;

                    }
                      break;
                        }

                case'p':{

                    if ((str.charAt(i+1)=='>')&&(p_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<p>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("<p>");
                        p_tag=true;
                        open_tag=false;
                        break;
                    }break;
                        }
                        //Unorder list
                case'u':{

                  if ((str.charAt(i+1)=='>')&&(u_tag==false))
                    {
                    output_tag[count]="<u>";
                    output_tag_attr[count]="NONE";
                    System.out.println("<u>");

                    for(j=i;(str.charAt(j)!='>');j++){}
                    for(k=j;(str.charAt(k)!='<');k++){}
                    System.out.println(""+str.substring(j+1,k));//Display Encoding
                    output_value[count++]=str.substring(j+1,k);
                    NumberOfAttribute=NumberOfAttribute+1;
                    open_tag=false;
                    u_tag=true;
                    break;
                    }

                  if ((str.charAt(i+1)=='l')&&(ul_tag==false))
                    {
                    output_tag[count]="<ul>";
                    output_tag_attr[count]="NONE";
                    System.out.println("<ul>");

                    for(j=i;(str.charAt(j)!='>');j++){}
                    for(k=j;(str.charAt(k)!='<');k++){}
                    System.out.println(""+str.substring(j+1,k));//Display Encoding

                    output_value[count++]=str.substring(j+1,k);
                    NumberOfAttribute=NumberOfAttribute+1;
                    open_tag=false;
                    ul_tag=true;
                    break;

                    }break;

                        }

                case't':{

                  if ((str.charAt(i+1)=='i')&&(title_tag==false))
                    {

                        for(j=i;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println(""+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="<title>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("<title>");
                        title_tag=true;
                        open_tag=false;
                        break;
                    }break;
                        }


         /// ===================  For End TAG Must Decare Here  =================== ///
               case'/':{

                    if ((str.charAt(i+1)=='a')&&(a_href_tag==true))
                    {
                      for(j=i+1;(str.charAt(j)!='>');j++){}
                      for(k=j;(str.charAt(k)!='<');k++){}
                      output_tag[count]="</a>";
                      output_tag_attr[count]="NONE";
                      output_value[count++]=str.substring(j+1,k);
                      NumberOfAttribute=NumberOfAttribute+1;
                        System.out.println("</a>");
                        a_href_tag=false;
                        open_tag=false;
                        break;

                    }

                    if (str.charAt(i+1)=='b')
                    {
                      if ((str.charAt(i+2)=='>')&&(b_tag==true))
                      {
                        for(j=i+1;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        output_tag[count]="</b>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;
                        System.out.println("</b>");
                        b_tag=false;
                        open_tag=false;
                        break;

                      }

                      if ((str.charAt(i+2)=='i')&&(body_tag==true))
                      {
                        for(j=i+1;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        output_tag[count]="</big>";
                        output_tag_attr[count]="NONE";
                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;
                        System.out.println("</big>");
                        big_tag=false;
                        open_tag=false;
                        break;}

                        if ((str.charAt(i+2)=='o')&&(body_tag==true))
                        {
                        System.out.println("</body>");
                        body_tag=false;
                        open_tag=false;
                        break;}


                    }//Body

                    if (str.charAt(i+1)=='f')
                    {
                      for(j=i+1;(str.charAt(j)!='>');j++){}
                      for(k=j;(str.charAt(k)!='<');k++){}
                      output_tag[count]="</form>";
                      output_tag_attr[count]="NONE";
                      output_value[count++]=str.substring(j+1,k);
                      NumberOfAttribute=NumberOfAttribute+1;

                          System.out.println("</form>");
                         form_tag=false;
                         open_tag=false;
                         break;
                    }

                    if (str.charAt(i+1)=='h')
                    {

                        if ((str.charAt(i+2)=='1')&&(h1_tag==true))
                        {
                          //Used  for replace
                          for(j=i+1;(str.charAt(j)!='>');j++){}
                          for(k=j;(str.charAt(k)!='<');k++){}
                          output_tag[count]="</h1>";
                          output_tag_attr[count]="NONE";

                          System.out.println("Between </h1> -> "+str.substring(j+1,k));
                          output_value[count++]=str.substring(j+1,k);
                          NumberOfAttribute=NumberOfAttribute+1;
                          System.out.println("</h1>");
                          h1_tag=false;
                          open_tag=false;
                          break;}

                        if ((str.charAt(i+2)=='e')&&(head_tag==true))
                        {
                        System.out.println("</head>");
                        head_tag=false;
                        open_tag=false;
                        break;}

                    if ((str.charAt(i+2)=='t')&&(html_tag==true))
                    {   System.out.println("</html>");
                        html_tag=false;
                        open_tag=false;
                        break;}

                    }//head //html

                    // italic
                    if ((str.charAt(i+1)=='i')&&(i_tag==true))
                    {
                      for(j=i+1;(str.charAt(j)!='>');j++){}
                      for(k=j;(str.charAt(k)!='<');k++){}
                      output_tag[count]="</i>";
                      output_tag_attr[count]="NONE";
                      output_value[count++]=str.substring(j+1,k);
                      NumberOfAttribute=NumberOfAttribute+1;
                      System.out.println("</i>");
                      i_tag=false;
                      open_tag=false;
                      break;
                    }

                    if ((str.charAt(i+1)=='l')&&(str.charAt(i+2)=='i')&&(li_tag==true))
                    {

                      //Used  for replace error
                      for(j=i+1;(str.charAt(j)!='>');j++){}
                      for(k=j;(str.charAt(k)!='<');k++){}
                      System.out.println("Between </li> -> "+str.substring(j+1,k));//Display Encoding

                      output_tag[count]="</li>";
                      output_tag_attr[count]="NONE";

                      output_value[count++]=str.substring(j+1,k);
                         NumberOfAttribute=NumberOfAttribute+1;
                        System.out.println("</li>");
                        li_tag=false;
                        open_tag=false;
                        break;

                    }
                    if ((str.charAt(i+1)=='p')&&(p_tag==true))
                    {


                        //Used  for replace error
                        for(j=i+1;(str.charAt(j)!='>');j++){}
                        for(k=j;(str.charAt(k)!='<');k++){}
                        System.out.println("Between </p> -> "+str.substring(j+1,k));//Display Encoding

                        output_tag[count]="</p>";
                        output_tag_attr[count]="NONE";

                        output_value[count++]=str.substring(j+1,k);
                        NumberOfAttribute=NumberOfAttribute+1;

                        System.out.println("</p>");
                        p_tag=false;
                        open_tag=false;
                        break;
                    }//p

                    if (str.charAt(i+1)=='u')
                    {

                      if((str.charAt(i+2)=='l')&&(ul_tag==true))
                      {
                      //Used  for replace error
                         for(j=i+1;(str.charAt(j)!='>');j++){}
                         for(k=j;(str.charAt(k)!='<');k++){}
                         System.out.println("Between </ul> -> "+str.substring(j+1,k));//Display Encoding

                         output_tag[count]="</ul>";
                         output_tag_attr[count]="NONE";

                         output_value[count++]=str.substring(j+1,k);
                         NumberOfAttribute=NumberOfAttribute+1;
                         System.out.println("</ul>");
                         ul_tag=false;
                         open_tag=false;
                         break;
                      }

                   if((str.charAt(i+2)=='>')&&(u_tag==true))
                   {
                     for(j=i+1;(str.charAt(j)!='>');j++){}
                     for(k=j;(str.charAt(k)!='<');k++){}
                     System.out.println("Between </u> -> "+str.substring(j+1,k));//Display Encoding

                     output_tag[count]="</u>";
                     output_tag_attr[count]="NONE";

                     output_value[count++]=str.substring(j+1,k);
                     NumberOfAttribute=NumberOfAttribute+1;
                     System.out.println("</u>");
                     u_tag=false;
                     open_tag=false;
                     break;
                    }
                     break;
                    }

                    if ((str.charAt(i+1)=='t')&&(title_tag==true))
                    {
                        System.out.println("</title>");
                        title_tag=false;
                        open_tag=false;
                        break;
                    }//title

                    break;}
                 default:{
                          open_tag=false;
                        //  System.out.println(str.substring(i,i+6));
                          break;}

           }//End switch i+1

     }//end if


       }//end for string for

                  return true;

    }//End function Getnode


 String Getparameter(String str,String name)
 {

 // This function will return value of name that ur asked for.
     String value=new String("");
     return(value);
 }

 int Get_count()
 {
      return(NumberOfAttribute);
 }


 void decrease_count()
 {
    NumberOfAttribute--;
 }

 void increase_count()
 {
    NumberOfAttribute++;

 }

}


