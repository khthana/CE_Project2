import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.*;
import javax.microedition.io.*;

import GUI2.*;

class Mail extends Canvas implements CommandListener
{
    
    private PWB midlet;
    private Display dis;
    private Image im1,im2,im3,im4,im5,im6,im7,im8,im11,im12,imalert,imalert2;
    private Menu menu;
    private int px=0,py=0;
    private Command cmExit;
    private Command cmOpenURL;
    private Command cmBookmark;
    private Command cmNextPage;
    private Command cmBackPage;
    private Command cmReload;
    private Command cmStopPage;
    private Command cmHome;
    private Form fmComposeMail;
    private TextField tfTo;
    private TextField tfSubject;
    private TextField tfDetail;
    private TextField tfFrom;
    private Command cmComposeOk;
    private Command cmBackMail;
    private String errResponse;
    
    Mail(PWB midlet,Display d)
    {
        menu=new GUI2.Menu();
        this.midlet=midlet;
        dis=d;
        try
        {
            im1=Image.createImage(menu.menu1);
            im2=Image.createImage(menu.menu2);
            im3=Image.createImage(menu.menu3s);
            im4=Image.createImage(menu.menu4);
            im5=Image.createImage(menu.menu5);
            im6=Image.createImage(menu.menu6);
            im7=Image.createImage(menu.menu7);
         //   im8=Image.createImage("/menu8.png");
            im11=Image.createImage("/mail1.png");
            im12=Image.createImage("/mail2.png");
            imalert=Image.createImage("/alert.png");
            imalert2=Image.createImage("/alert2.png");
        }
        catch (Exception e)
        {
            System.out.println("Hello1");
        }
        cmExit=new Command("Exit PWB",Command.EXIT,1);
        addCommand(cmExit);
        
        setCommandListener(this);            
    }
    
    protected void paint(Graphics g)
    {
        g.setColor(255,255,255);
        g.fillRect(0,0,getWidth(),getHeight());
        
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.fillRoundRect(2,2,getWidth()-2,menu.menu_h-1,10,8);      
        
        g.setColor(0,0,0);
        g.drawString("Email & Message",75,25,0);
        
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.drawLine(2,40,getWidth()-2,40);

        g.drawImage(im1,0*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im2,1*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im3,2*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im4,3*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im5,4*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im6,5*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im7,6*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        //g.drawImage(im8,0*menu.menu_w,25,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im11,menu.getx(11),menu.gety(11),Graphics.TOP | Graphics.LEFT);
        g.drawImage(im12,menu.getx(12),menu.gety(12),Graphics.TOP | Graphics.LEFT);
    }
    protected void pointerPressed(int x,int y)
    {
        px=x;py=y;
        int tmp=menu.SelectedMenu(px,py);
        System.out.println(tmp);
        switch (tmp)
        {
            case 1:midlet.ShowWeb(this.midlet,dis);break;
            case 2:midlet.ShowScript();break;
            //case 3:midlet.ShowMail();break;
            case 4:midlet.ShowFTP();break;
            case 5:midlet.ShowUser();break;
            case 6:midlet.ShowSetting();break;
            case 7:midlet.ShowInfo();break;
            //case 8:midlet.;
            case 11:showForm(null,null,null,null);break;
            
        }
    }
    public void showForm(String t,String f,String s,String d)
    {
          fmComposeMail=new Form("Compose mail:");
          tfTo=new TextField("To:","notta2524@yahoo.com",20,TextField.ANY);
          tfSubject=new TextField("Subject:",s,30,TextField.ANY);
          tfFrom=new TextField("From:",s,30,TextField.ANY);
          tfDetail=new TextField("Detail:",d,100,TextField.ANY);
          cmComposeOk=new Command("Send Mail",Command.SCREEN,0);
          cmBackMail=new Command("Back Mail",Command.SCREEN,1);
          fmComposeMail.addCommand(cmComposeOk);
          fmComposeMail.addCommand(cmBackMail);
          fmComposeMail.append(tfTo);
          fmComposeMail.append(tfFrom);
          fmComposeMail.append(tfSubject);
          fmComposeMail.append(tfDetail);
          fmComposeMail.setCommandListener(this);
          dis.setCurrent(fmComposeMail);
    }
    
 
/*--------------------------------------------------------------------------*/
    public void commandAction(Command c,Displayable d)
    {
        if (c==cmExit)
        {
            midlet.exitMIDlet();
        }
        else if(c==cmComposeOk)
        {
            
            String to=tfTo.getString();
            String subject=tfSubject.getString();
            String detail=tfDetail.getString();
            String from=tfFrom.getString();
            
            if ((to.equals("")) || (subject.equals("")) || (detail.equals("")))
            {
               
                showForm(to,from,subject,detail);
            }
            else
            {
                try
                {
                MyMail mym=new MyMail();;
                mym.Sendmail(to,from,subject,detail);
                }
                catch (Exception e)
                {
                    Alert alert2=new Alert(null,"       ---------+"+errResponse+"--------  ",imalert2,null);
                    alert2.setTimeout(Alert.FOREVER);
                    showForm(to,from,subject,detail);
                    dis.setCurrent(alert2,fmComposeMail);
                }
                Alert alert=new Alert(null,"     ---------Message has been sent!--------  ",imalert,null);
                dis.setCurrent(alert,fmComposeMail);
            }
        }
        else if (c==cmBackMail)
        {
            dis.setCurrent(this);
        }
    }
   
}
