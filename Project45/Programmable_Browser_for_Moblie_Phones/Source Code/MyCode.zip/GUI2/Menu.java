package GUI2;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Menu extends Canvas {
    
    
    public int menu_w=25;//defaul 25
    public int menu_h=25;//defaul 25
    public int titile_h=14;
    public int bg_r=0;//defaul 153
    public int bg_g=0;//defaul 204
    public int bg_b=0;//defaul 51

    public String title=null;

    public String menu1="/menu1.png";
    public String menu2="/menu2.png";
    public String menu3="/menu3.png";
    public String menu4="/menu4.png";
    public String menu5="/menu5.png";
    public String menu6="/menu6.png";
    public String menu7="/menu7.png";
    // public Sting menu8s="/menu8s.png";
    public String menu1s="/menu1s.png";
    public String menu2s="/menu2s.png";
    public String menu3s="/menu3s.png";
    public String menu4s="/menu4s.png";
    public String menu5s="/menu5s.png";
    public String menu6s="/menu6s.png";
    public String menu7s="/menu7s.png";
    public String blist="/blist.png";
    public String PWBlogo="/PWBlogo.png";
    public String alert2="/alert2.png";
   // public Sting menu8s="/menu8s.png";
    private int position=0;
    private int tmp=0;
    private MyData my=null;
    
    public Menu() 
    {           
        System.out.println("This is Menu()");
        my=new MyData();
        my.openBrowserStore();
        String color=my.readBrowserData(4);
        System.out.println("color:"+color);
        if (color.equals("green"))
        {
            setRGB(153,204,51);
        }
        else if (color.equals("blue"))
        {
            setRGB(68,140,203);
        }
        else if (color.equals("violet"))
        {
            setRGB(153,0,204);
        }
         else if (color.equals("pink"))
        {
            setRGB(255,102,204);
        }
         else if (color.equals("red"))
        {
            setRGB(204,0,0);
        }
         else if (color.equals("orange"))
        {
            setRGB(255,153,0);
        }
        my.closeBrowserStore();
    }
    protected void paint(Graphics g)
    {
           
    }
    
    protected void setRGB(int r,int g,int b)
    {
        bg_r=r;
        bg_g=g;
        bg_b=b;
    }
    
    public int getx(int p)
    {
        tmp=p;
        int x=0;
         switch (tmp)
        {
            case 11:x=4;break;
            case 12:x=74;break;
            case 13:x=144;break;
            case 21:x=4;break;
            case 22:x=74;break;
            case 23:x=144;break;
            case 31:x=4;break;
            case 32:x=74;break;
            case 33:x=144;break;
        }
         return x;
    }
    public int gety(int p)
    {
        tmp=p;
        int y=0;
        System.out.println("y:"+tmp);
        switch (tmp)
        {
            case 11:y=50;break;
            case 12:y=50;break;
            case 13:y=50;break;
            case 21:y=120;break;
            case 22:y=120;break;
            case 23:y=120;break;
            case 31:y=190;break;
            case 32:y=190;break;
            case 33:y=190;break;
        }
         return y;
    }
    
    public int SelectedMenu(int x,int y)
    {   
        int position=0;
        if ((x>0*menu_w)&&(x<1*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 1;
        else if ((x>1*menu_w)&&(x<2*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 2;
        else if ((x>2*menu_w)&&(x<3*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 3;
        else if ((x>3*menu_w)&&(x<4*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 4;
        else if ((x>4*menu_w)&&(x<5*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 5;
        else if ((x>5*menu_w)&&(x<6*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position=6;
        else if ((x>6*menu_w)&&(x<7*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 7;
        else if ((x>7*menu_w)&&(x<8*menu_w)&&(y>0*menu_w)&&(y<1*menu_h))
            position= 8;
        if ((x>4)&&(x<64)&&(y>50)&&(y<90))
            position= 11;
        else if ((x>74)&&(x<134)&&(y>50)&&(y<90))
            position= 12;
        else if ((x>144)&&(x<204)&&(y>50)&&(y<90))
            position= 13;
        else if ((x>4)&&(x< 64)&&(y>120)&&(y<160))
            position= 21;
        else if ((x>70)&&(x<134)&&(y>120)&&(y<160))
            position= 22;
        else if ((x>144)&&(x<204)&&(y>120)&&(y<160))
            position= 23;
        else if ((x>4)&&(x<64)&&(y>190)&&(y<230))
            position= 31;
        else if ((x>74)&&(x<134)&&(y>190)&&(y<230))
            position= 32;
        else if ((x>144)&&(x<204)&&(y>190)&&(y<230))
            position= 33;
        return position;
    }
    
}
