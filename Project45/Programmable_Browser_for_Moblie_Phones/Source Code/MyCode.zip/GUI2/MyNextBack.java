package GUI2;

import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.rms.*;

public class MyNextBack 
{
  private RecordStore rs = null;    // Record store
  static final String REC_STORE = "db_3"; // Name of record store
  public int count;
  public MyNextBack()
  {
    openNBStore();   // Create the record store 
    count=1;
//  readNBData();     // Read back the records
        
//closeNBStore();  // Close record store
   //deleteNBStore(); // Remove the record store
  }

  public void openNBStore()
  {
    try
    {
      rs = RecordStore.openRecordStore(REC_STORE,true);
    }
    catch (Exception e)
    {
      System.err.println("Error in openNBStore()-->" + e.toString());
    }
  }    
  
  public void closeNBStore()
  {
    try
    {
      rs.closeRecordStore();
    }
    catch (Exception e)
    {
      System.err.println("Error in closeNBStore()-->" + e.toString());
    }
  }

  public void deleteNBStore()
  {
    if (RecordStore.listRecordStores() != null)
    {
      try
      {
        RecordStore.deleteRecordStore(REC_STORE);
      }
      catch (Exception e)
      {
       System.err.println("Error in deleteNBStore()-->" + e.toString());
      }
    }      
  }

  public void writeNBData(String s,int index)
  {
    System.out.println("This is writeNBData("+s+","+index+")");
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      
      byte[] record;
      
      if (rs.getNumRecords()==0)
      {              
            // Clear any buffered data
            strmDataType.writeUTF(s);
            strmDataType.flush();

            // Get stream data into byte array and write record
            record = strmBytes.toByteArray();
            rs.addRecord(record, 0, record.length);      
            System.out.println("write bookmarkInit successful");
            // Toss any data in the internal array so writes 
            // starts at beginning (of the internal array)
            strmBytes.reset();
      }
      else
      {
              // Write Java data types      
              strmDataType.writeUTF(s);               
              // Clear any buffered data
              strmDataType.flush();
              // Get stream data into byte array and write record
              record = strmBytes.toByteArray();
              rs.setRecord(index,record, 0, record.length);      
              // Toss any data in the internal array so writes 
              // starts at beginning (of the internal array)
              strmBytes.reset(); 
      }
      strmBytes.close();
      strmDataType.close();
    }
    catch (Exception e)
    {
      System.err.println("Error in writeNBData()-->" + e.toString());
    }
  }
 
   public void addNB(String str1)
  {
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      
      byte[] record;
            
      // Clear any buffered data
      strmDataType.writeUTF(str1);
      strmDataType.flush();

      // Get stream data into byte array and write record
      record = strmBytes.toByteArray();
 
      rs.addRecord(record, 0, record.length);      
      System.out.println("add NextBack successful");
      // Toss any data in the internal array so writes 
      // starts at beginning (of the internal array)
      strmBytes.reset();
      
      strmBytes.close();
      strmDataType.close();
     
    }
    catch (Exception e)
    {
      System.err.println("Error in addNBData()-->" + e.toString());
    }
  }
 
  public String readNBData(int index)
  {
    String str=new String("");
    System.out.println("This is writeNBData("+index+")");    
    try
    {
      // Careful: Make sure this is big enough!
      // Better yet, test and reallocate if necessary      
      byte[] recData = new byte[1000];
      // Read from the specified byte array
      ByteArrayInputStream strmBytes = new ByteArrayInputStream(recData);
      // Read Java data types from the above byte array
      DataInputStream strmDataType = new DataInputStream(strmBytes);
      rs.getRecord(index, recData, 0);
      str=strmDataType.readUTF().toString();
      strmBytes.close();
      strmDataType.close();        
    }      
    catch (Exception e)
    {
      System.err.println("Error in readNBData()-->" + e.toString());
    }
     return str;
}
public int  count()
{
    return count;
}
  public String showNBData()
  {
    String str=new String("");
    System.out.println("This is showNBData()");    
    try
    {
      // Careful: Make sure this is big enough!
      // Better yet, test and reallocate if necessary      
      byte[] recData = new byte[1000];
      // Read from the specified byte array
      ByteArrayInputStream strmBytes = new ByteArrayInputStream(recData);
      // Read Java data types from the above byte array
      DataInputStream strmDataType = new DataInputStream(strmBytes);;
      
      for (int i = 1; i <= rs.getNumRecords(); i++)
      {
        // Get data into the byte array
        rs.getRecord(i, recData, 0);
        // Read back the data types      
        System.out.println("Record #" + i);        
        System.out.println("UTF: " + strmDataType.readUTF());            
        System.out.println("--------------------");        
        // Reset so read starts at beginning of array 
        strmBytes.reset();
      }
      strmBytes.close();
      strmDataType.close();         
    }      
    catch (Exception e)
    {
      System.err.println("Error in showNBData()-->" + e.toString());
    }
     return str;
}
   public int length()
  {
    int x=0;
     try
    {
      x=rs.getNumRecords();
    }
    catch (Exception e)
    {
      System.err.println("Error in length()-->" + e.toString());
    }
    return x;  
  }
   public void addcount()
   {       
       count++;
       if (count>length())
       count=length();
   }
   public void subcount()
   {
       count--;
       if (count<1)
       count=1;
   }
}
