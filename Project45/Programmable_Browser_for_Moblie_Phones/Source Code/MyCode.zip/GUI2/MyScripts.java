package GUI2;

import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.rms.*;

public class MyScripts 
{
  private RecordStore rs = null;    // Record store
  private String stringsInit1 = "TestScript";
  private String stringsInit2 = "t=0;"; 
  static final String REC_STORE = "db_5"; // Name of record store

  public MyScripts()
  {
    openScriptsStore();   // Create the record store 
    writeScriptsInit();  // Write a series of records
//    readScriptsData();     // Read back the records
        
  // closeScriptsStore();  // Close record store
 //  deleteScriptsStore(); // Remove the record store
  }

  public void openScriptsStore()
  {
    try
    {
      // The second parameter indicates that the record store
    	// should be created if it does not exist
      rs = RecordStore.openRecordStore(REC_STORE, true );
    }
    catch (Exception e)
    {
      db(e.toString());
    }
  }    
  
  public void closeScriptsStore()
  {
    try
    {
      rs.closeRecordStore();
    }
    catch (Exception e)
    {
      db(e.toString());
    }
  }

  public void deleteScriptsStore()
  {
    if (RecordStore.listRecordStores() != null)
    {
      try
      {
        RecordStore.deleteRecordStore(REC_STORE);
      }
      catch (Exception e)
      {
        db(e.toString());
      }
    }      
  }

  /*--------------------------------------------------
  * Create three arrays to write to record store
  *-------------------------------------------------*/

  /*--------------------------------------------------
  * Write to record store using streams.
  *-------------------------------------------------*/  
  public void writeScriptsInit()
  {
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      
      byte[] record;
      if (rs.getNumRecords()==0)
      {              
            // Clear any buffered data
            strmDataType.writeUTF(stringsInit1);
            strmDataType.writeUTF(stringsInit2);
            strmDataType.flush();

            // Get stream data into byte array and write record
            record = strmBytes.toByteArray();

            rs.addRecord(record, 0, record.length);      
            System.out.println("write ScriptsInit successful");
            // Toss any data in the internal array so writes 
            // starts at beginning (of the internal array)
            strmBytes.reset();
      }
      strmBytes.close();
      strmDataType.close();
     
    }
    catch (Exception e)
    {
      db(e.toString());
    }
  }
  
  public void addScripts(String str1,String str2)
  {
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      
      byte[] record;
            
      // Clear any buffered data
      strmDataType.writeUTF(str1);
      strmDataType.writeUTF(str2);
      strmDataType.flush();

      // Get stream data into byte array and write record
      record = strmBytes.toByteArray();
 
      rs.addRecord(record, 0, record.length);      
      System.out.println("add ScriptsInit successful");
      // Toss any data in the internal array so writes 
      // starts at beginning (of the internal array)
      strmBytes.reset();
      
      strmBytes.close();
      strmDataType.close();
     
    }
    catch (Exception e)
    {
      db(e.toString());
    }
  }

  /*--------------------------------------------------
  * Read from the record store using streams
  *-------------------------------------------------*/
  public void writeScriptsData(String s1,String s2,int index)
  {
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      
      byte[] record;
      // Write Java data types      
      strmDataType.writeUTF(s1); 
      strmDataType.writeUTF(s2);
      // Clear any buffered data
      strmDataType.flush();
      // Get stream data into byte array and write record
      record = strmBytes.toByteArray();
      rs.setRecord(index,record, 0, record.length);      
      // Toss any data in the internal array so writes 
      // starts at beginning (of the internal array)
      strmBytes.reset();  
      strmBytes.close();
      strmDataType.close();
      System.out.println("write "+s1+" successful");
      System.out.println("write "+s2+" successful");
    }
    catch (Exception e)
    {
      db(e.toString());
    }
  }
 
 
 
  public String readScriptsData(int r,int c)
  {
      String str1=new String("");
      String str2=new String("");
      System.out.println("Hello readScriptsData():" + r);
    try
    {
      // Careful: Make sure this is big enough!
      // Better yet, test and reallocate if necessary      
      byte[] recData = new byte[1000];
      // Read from the specified byte array
      ByteArrayInputStream strmBytes = new ByteArrayInputStream(recData);
      // Read Java data types from the above byte array
      DataInputStream strmDataType = new DataInputStream(strmBytes); 
      // Get data into the byte array
      rs.getRecord(r, recData, 0);
      System.out.println("Hello readScriptsData():" + r); 
      if (c==1) str1=strmDataType.readUTF();
      else 
      {
          //get url field
          strmDataType.readUTF();
          str1=strmDataType.readUTF();
      }
      strmBytes.reset();
      strmDataType.close();         
    }      
    catch (Exception e)
    {
      System.err.println("Msg:error in : readScripts()" + e);
    }
     return str1;
  }
  
  public void deleteScriptsData(int index)
  {
    try
    {
      rs.deleteRecord(index);      
    }      
    catch (Exception e)
    {
      db(e.toString());
    }
  }
 
  /*--------------------------------------------------
  * Simple message to console for debug/errors
  * When used with Exceptions we should handle the 
  * error in a more appropriate manner.
  *-------------------------------------------------*/
  private void db(String str)
  {
    System.err.println("Msg: " + str);
  }
  
  public int length()
  {
    int x=0;
     try
    {
      x=rs.getNumRecords();
    }
    catch (Exception e)
    {
      db(e.toString());
    }
    return x;  
  }
}
