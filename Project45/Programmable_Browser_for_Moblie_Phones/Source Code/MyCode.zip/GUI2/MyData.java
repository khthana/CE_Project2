package GUI2;

import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.rms.*;

public class MyData 
{
  private RecordStore rs = null;    // Record store
  private String[] stringsInit = {"PWBlogo",
                                  "PWBlogo" ,
                                  "standard",
                                  "green",
                                   "Input Script empty",
                                    "Output Script empty"};
                                  
  static final String REC_STORE = "db_1"; // Name of record store

  public MyData()
  {
    openBrowserStore();   // Create the record store 
    writeBrowserInit();  // Write a series of records
//  readBrowserData();     // Read back the records
        
//closeBrowserStore();  // Close record store
//   deleteBrowserStore(); // Remove the record store
  }

  public void openBrowserStore()
  {
    try
    {
      rs = RecordStore.openRecordStore(REC_STORE,true);
    }
    catch (Exception e)
    {
      System.err.println("Error in openBrowserStore()-->" + e.toString());
    }
  }    
  
  public void closeBrowserStore()
  {
    try
    {
      rs.closeRecordStore();
    }
    catch (Exception e)
    {
      System.err.println("Error in closeBrowserStore()-->" + e.toString());
    }
  }

  public void deleteBrowserStore()
  {
    if (RecordStore.listRecordStores() != null)
    {
      try
      {
        RecordStore.deleteRecordStore(REC_STORE);
      }
      catch (Exception e)
      {
       System.err.println("Error in deleteBrowserStore()-->" + e.toString());
      }
    }      
  }

  /*--------------------------------------------------
  * Create three arrays to write to record store
  *-------------------------------------------------*/

  /*--------------------------------------------------
  * Write to record store using streams.
  *-------------------------------------------------*/  
  public void writeBrowserInit()
  {
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      byte[] record;
      if (rs.getNumRecords()==0)//check when first installation in mobile
      {
          for (int i = 0; i < stringsInit.length; i++)
          {
            // Write Java data types      
            strmDataType.writeUTF(stringsInit[i]);              
            // Clear any buffered data
            strmDataType.flush();
            // Get stream data into byte array and write record
            record = strmBytes.toByteArray();
            rs.addRecord(record, 0, record.length);      
            // Toss any data in the internal array so writes 
            // starts at beginning (of the internal array)
            strmBytes.reset();
          }
      }
      strmBytes.close();
      strmDataType.close();
     
    }
    catch (Exception e)
    {
      
    }
  }

  /*--------------------------------------------------
  * Read from the record store using streams
  *-------------------------------------------------*/
  public void writeBrowserData(String s,int index)
  {
   //System.out.println("This is writeBrowserData("+s+","+index+")");
    try
    {
      // Write data into an internal byte array
      ByteArrayOutputStream strmBytes = new ByteArrayOutputStream();
      // Write Java data types into the above byte array
      DataOutputStream strmDataType = new DataOutputStream(strmBytes);
      
      byte[] record;
      // Write Java data types      
      strmDataType.writeUTF(s);               
      // Clear any buffered data
      strmDataType.flush();
      // Get stream data into byte array and write record
      record = strmBytes.toByteArray();
      rs.setRecord(index,record, 0, record.length);      
      // Toss any data in the internal array so writes 
      // starts at beginning (of the internal array)
      strmBytes.reset();  
      strmBytes.close();
      strmDataType.close();
    }
    catch (Exception e)
    {
      System.err.println("Error in writeBrowserData()-->" + e.toString());
    }
  }
 
 
 
  public String readBrowserData(int index)
  {
    String str=new String("");
    //System.out.println("This is writeBrowserData("+index+")");    
    try
    {
      // Careful: Make sure this is big enough!
      // Better yet, test and reallocate if necessary      
      byte[] recData = new byte[1000];
      // Read from the specified byte array
      ByteArrayInputStream strmBytes = new ByteArrayInputStream(recData);
      // Read Java data types from the above byte array
      DataInputStream strmDataType = new DataInputStream(strmBytes);
      rs.getRecord(index, recData, 0);
      str=strmDataType.readUTF().toString();
      strmBytes.close();
      strmDataType.close();        
    }      
    catch (Exception e)
    {
      System.err.println("Error in readBrowserData()-->" + e.toString());
    }
     return str;
}

  public String showBrowserData()
  {
    String str=new String("");
    System.out.println("This is showBrowserData()");    
    try
    {
      // Careful: Make sure this is big enough!
      // Better yet, test and reallocate if necessary      
      byte[] recData = new byte[1000];
      // Read from the specified byte array
      ByteArrayInputStream strmBytes = new ByteArrayInputStream(recData);
      // Read Java data types from the above byte array
      DataInputStream strmDataType = new DataInputStream(strmBytes);;
      
      for (int i = 1; i <= rs.getNumRecords(); i++)
      {
        // Get data into the byte array
        rs.getRecord(i, recData, 0);
        // Read back the data types      
        System.out.println("Record #" + i);        
        System.out.println("UTF: " + strmDataType.readUTF());            
        System.out.println("--------------------");        
        // Reset so read starts at beginning of array 
        strmBytes.reset();
      }
      strmBytes.close();
      strmDataType.close();         
    }      
    catch (Exception e)
    {
      System.err.println("Error in showBrowserData()-->" + e.toString());
    }
     return str;
}
   public int length()
  {
    int x=0;
     try
    {
      x=rs.getNumRecords();
    }
    catch (Exception e)
    {
     // db(e.toString());
    }
    return x;  
  }
}
