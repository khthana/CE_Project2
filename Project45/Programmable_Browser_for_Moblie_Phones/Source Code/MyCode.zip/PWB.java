import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.rms.*;

public class PWB extends javax.microedition.midlet.MIDlet
{
    public Display display;
    private Web canvas1;
    private Script canvas2;
    private Mail canvas3;
    private FTP canvas4;
    private User canvas5;
    private Setting canvas6;
    private Info canvas7;

    public PWB()
    {
        display=Display.getDisplay(this); 
        canvas1=new Web(this,display);
        canvas2=new Script(this,display);
        canvas3=new Mail(this,display);
        canvas4=new FTP(this,display);
        canvas5=new User(this,display);
        canvas6=new Setting(this,display);
        canvas7=new Info(this,display);
    }
     
    public void startApp() //throws MIDletStateChangeException
    {
        display.setCurrent(canvas1);      
    }
    
    public void pauseApp() 
    {
    }
    
    public void destroyApp(boolean unconditional) 
    {
    }
    public void exitMIDlet()
    {
        destroyApp(true);
        notifyDestroyed();
    }
    public void ShowWeb(PWB p,Display d)
    {
        Web canvas1=new Web(this,d);
        display.setCurrent(canvas1);
    }
    public void ShowScript()
    {
        display.setCurrent(canvas2);
    }
    public void ShowMail()
    {
        display.setCurrent(canvas3);
    }
    public void ShowFTP()
    {
        display.setCurrent(canvas4);
    }
    public void ShowUser()
    {
        display.setCurrent(canvas5);
    }
    public void ShowSetting()
    {
        display.setCurrent(canvas6);
    }
    public void ShowInfo()
    {
        display.setCurrent(canvas7);
    }
}


