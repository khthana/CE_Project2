public class ColorRGB
{
  public int r,g,b;
  ColorRGB(){r=0;g=0;b=0;}
}