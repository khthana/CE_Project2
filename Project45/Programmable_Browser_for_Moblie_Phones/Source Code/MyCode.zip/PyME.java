import javax.microedition.lcdui.*;
import com.pyme.Py;
import GUI2.*;

public class PyME extends Py {
  private MyData my;
  private Display dis;
  private PWB midlet;

  public PyME(String source, MyData my, Display dis, PWB midlet) {
    super(source);
    this.my = my;
    this.dis = dis;
    this.midlet = midlet;
  }

  public void pyEvent(int eventType, String eventMsg) {
    if (eventType == STDOUT) {
      my.openBrowserStore();
      my.writeBrowserData(eventMsg, 5);
      my.closeBrowserStore();
    }
    else if (eventType == OPENURL) {
      my.openBrowserStore();
      my.writeBrowserData(eventMsg,1);
      System.out.println(eventMsg);
//      my.writeBrowserData("http://161.246.4.3/~s2010113/etc.html", 1);
      my.closeBrowserStore();
      midlet.ShowWeb(this.midlet,dis);
    }
  }

}