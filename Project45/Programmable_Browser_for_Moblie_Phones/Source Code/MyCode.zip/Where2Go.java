import java.io.*;

public class Where2Go

{
  private int start_point[]=new int[50]; //used 4 record point of link
  private int end_point[]=new int[50];
  private int line_focus[]=new int[50];
  private int count;

  private String url[]=new String[50];


  Where2Go()
  {
   count=0;
   for (int i=0;i<50;i++)
        {
           start_point[i] =0;
           end_point[i] =0;
           line_focus[i] =0;
           url[i]=null;
        }
  }

  void next()
  {
  count++;
  }

  void previous()
  {
  count--;
  }

  //Uset in for loops;
  int RetCount()
  {
  return (count);
  }


  void AddStartPt(int st)
  {
  start_point[count]=st;
  System.out.println(" X pixel = "+st);
  }

  void AddEndPt(int st)
  {
  end_point[count]=st;
    System.out.println(" End X pixel = "+st);
  }

  void AddLine(int st)
  {
  line_focus[count]=st;
  System.out.println(" Y pixel = "+st);
    System.out.println("End Y pixel = "+(st+12));
  }

  void AddLink(String st)
  {
  url[count]=st;
  }

  int RetStart_Point(int i)
  {
    return(start_point[i]);
  }

  int RetEnd_Point(int i)
  {
    return(end_point[i]);
  }

  int RetLine(int i)
  {
  return(line_focus[i]);
  }
  
  String RetURL(int i)
  {
      return (url[i]);
  }

}