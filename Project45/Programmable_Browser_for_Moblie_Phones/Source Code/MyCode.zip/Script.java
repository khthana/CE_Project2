import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import GUI2.*;

class Script extends Canvas implements CommandListener
{
    private Display dis;
    private PWB midlet;
    private Image im1,im2,im3,im4,im5,im6,im7,im8,im11,im12,im13,imalert,imalert2;
    private Menu menu;
    private int px=0,py=0;
    private Command cmExit;
    private Command cmRunScript;
    private Command cmBackScript;

    private Form fmScriptEditor;
    private Command cmSaveAsScript;
    private Command cmSaveScript;
    private Command cmSelectScript;
    private Command cmCancelSelect;
    private Command cmOkScript;
    private Command cmSaveAsOK;
    private List lsScript;
    private String ScriptName=null;


    private TextField tfGetNewScript;
    private int sindex=0;
    private boolean selectedchk;
    private String sstr=null;

    private MyData my;
    private MyScripts mys;
    private TextField tfScriptEditor;
    private List lsEventList;

    Script(PWB midlet,Display d)
    {
        menu=new GUI2.Menu();
        this.midlet=midlet;
        dis=d;
        my=new MyData();
        mys=new MyScripts();
        try
        {
            im1=Image.createImage(menu.menu1);
            im2=Image.createImage(menu.menu2s);
            im3=Image.createImage(menu.menu3);
            im4=Image.createImage(menu.menu4);
            im5=Image.createImage(menu.menu5);
            im6=Image.createImage(menu.menu6);
            im7=Image.createImage(menu.menu7);
            imalert=Image.createImage("/alert.png");
            imalert2=Image.createImage("/alert2.png");
            //   im8=Image.createImage("/menu8.png");
            if (my.readBrowserData(3).equals("standard"))
            {
                im11=Image.createImage("/script1.png");
                im12=Image.createImage("/script2.png");
                im13=Image.createImage("/script3.png");
            }
            else if (my.readBrowserData(3).equals("ocean"))
            {
                im11=Image.createImage("/xscript1.png");
                im12=Image.createImage("/xscript2.png");
                im13=Image.createImage("/xscript3.png");
            }

        }
        catch (Exception e)
        {
            System.err.println("Error in scipt()-->" + e.toString());
        }
        cmExit=new Command("Exit PWB",Command.EXIT,1);
        cmRunScript=new Command("Run Script",Command.SCREEN,2);
        cmBackScript=new Command("Back Script",Command.SCREEN,2);
        addCommand(cmExit);
        addCommand(cmRunScript);
        my.closeBrowserStore();
        setCommandListener(this);
    }

    protected void paint(Graphics g)
    {
        g.setColor(255,255,255);
        g.fillRect(0,0,getWidth(),getHeight());

        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.fillRoundRect(2,2,getWidth()-2,menu.menu_h-1,10,8);

        g.drawImage(im1,0*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im2,1*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im3,2*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im4,3*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im5,4*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im6,5*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im7,6*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        //g.drawImage(im8,0*menu.menu_w,25,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im11,menu.getx(11),menu.gety(11),Graphics.TOP | Graphics.LEFT);
        g.drawImage(im12,menu.getx(12),menu.gety(12),Graphics.TOP | Graphics.LEFT);
        g.drawImage(im13,menu.getx(13),menu.gety(13),Graphics.TOP | Graphics.LEFT);
        g.setColor(0,0,0);
        g.drawString("Script",95,25,0);

        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.drawLine(2,40,getWidth()-2,40);
    }
    protected void pointerPressed(int x,int y)
    {
        px=x;py=y;
        int tmp=menu.SelectedMenu(px,py);
        System.out.println(tmp);
        switch (tmp)
        {
            case 1:midlet.ShowWeb(this.midlet,dis);break;
            //case 2:midlet.ShowScript();break;
            case 3:midlet.ShowMail();break;
            case 4:midlet.ShowFTP();break;
            case 5:midlet.ShowUser();break;
            case 6:midlet.ShowSetting();break;
            case 7:midlet.ShowInfo();break;
            //case 8:midlet.;
            case 11:ScriptEditor(sstr);break;
            //case 12:midlet.ShowInfo();break;
            case 13:ShowConsole();break;

        }
    }
    public void ScriptEditor(String sstr)
    {
           String tmp=sstr;
           String sname;
           if (ScriptName==null)
           {
               sname="New Script";
           }
           else
           {
               sname=ScriptName;
           }
           fmScriptEditor=new Form("Script Editor:");
           tfScriptEditor=new TextField("Edit your script:"+sname,tmp,500,TextField.ANY);
           cmSelectScript=new Command("Select Script",Command.SCREEN,2);
           cmSaveScript=new Command("Save",Command.SCREEN,2);
           cmSaveAsScript=new Command("Save As",Command.SCREEN,2);
           cmOkScript=new Command("OK",Command.SCREEN,2);


           fmScriptEditor.append(tfScriptEditor);
           fmScriptEditor.addCommand(cmBackScript);
           fmScriptEditor.addCommand(cmSelectScript);
           fmScriptEditor.addCommand(cmSaveAsScript);
           fmScriptEditor.addCommand(cmSaveScript);
           fmScriptEditor.addCommand(cmOkScript);

           sstr=tfScriptEditor.getString();

           fmScriptEditor.setCommandListener(this);
           dis.setCurrent(fmScriptEditor);
    }

    public void ShowConsole()
    {
            Form fmConsole=new Form("Script Console:");
            fmConsole.addCommand(cmBackScript);
            my.openBrowserStore();
            String sc=my.readBrowserData(5);

            Alert a1=new Alert(null,"       ---------Output Script empty !--------  ",imalert,null);
            if (sc.equals("Output Script empty"))
            {
                my.closeBrowserStore();
                dis.setCurrent(a1,this);
            }
            else
            {
             fmConsole.append(sc);
             my.closeBrowserStore();
             dis.setCurrent(fmConsole);
             fmConsole.setCommandListener(this);
            }
    }

     public void SaveAs()
     {
            mys=new MyScripts();
            mys.addScripts(tfGetNewScript.getString(),tfScriptEditor.getString());
            sindex=mys.length();
            sstr=tfScriptEditor.getString();
            ScriptName=tfGetNewScript.getString();
            mys.closeScriptsStore();
            Alert a1=new Alert(null,"       ---------Save as Script OK !--------  ",imalert,null);
            dis.setCurrent(a1,this);
    }
     //**********************************************************************************










     public void commandAction(Command c,Displayable d)
    {
        if (c==cmExit)
        {
            midlet.exitMIDlet();
        }






        else if (c==cmBackScript)
        {
            dis.setCurrent(this);
        }







        else if (c==cmRunScript)
        {
            my.openBrowserStore();
            String sc=my.readBrowserData(5);
            System.out.println(sc);

            PyME py = new PyME(sc, my, dis, midlet);
            py.Interprete();
            //insert class to interprete here
            //input is sc
            System.out.println("SC is :"+sc);

            Alert a=new Alert(null,"       ---------Input Script empty !--------  ",imalert2,null);
            Alert a1=new Alert(null,"      ---------Run Script OK !--------  ",imalert,null);
            if (sc.equals("TestScript"))
            {
                my.closeBrowserStore();
                dis.setCurrent(a,this);
            }
            else
            {
//                 my.writeBrowserData(sc,5);
//                 my.closeBrowserStore();
//                 dis.setCurrent(a1,this);
            }


        }










        else if (c==cmSaveAsScript)//show box to input script name
        {
            Form fmSaveAs=new Form("Save Script name as");
            tfGetNewScript=new TextField("Save as:",null,500,TextField.ANY);
            cmSaveAsOK=new Command("OK",Command.SCREEN,1);
            Command cmCancel=new Command("Cancel",Command.SCREEN,2);

            fmSaveAs.append(tfGetNewScript);
            fmSaveAs.addCommand(cmSaveAsOK);
            fmSaveAs.addCommand(cmCancel);

            dis.setCurrent(fmSaveAs);
            fmSaveAs.setCommandListener(this);
        }
        else if (c==cmSaveAsOK)
        {
            SaveAs();
        }





        else if (c==cmSelectScript)//show script name
        {
            mys=new MyScripts();
            int length=mys.length();

            String options[]=new String[length];//make array option=number of record in bookmark

            for (int i=0;i<length;i++)
            {
                options[i]=mys.readScriptsData(i+1,1);//get data(since 1) to array
                System.out.println("my i:"+i);
            }

            lsScript=new List("My Bookmark:",List.IMPLICIT,options,null);
            lsScript.addCommand(cmBackScript);

            lsScript.setCommandListener(this);

            dis.setCurrent(lsScript);

            mys.closeScriptsStore();
        }






        else if (c==List.SELECT_COMMAND)//get url in which bookmark show
        {
            mys.openScriptsStore();
            sstr=mys.readScriptsData(lsScript.getSelectedIndex()+1,2);
            ScriptName=mys.readScriptsData(lsScript.getSelectedIndex()+1,1);//getSelectedIndex() start=0
            sindex=lsScript.getSelectedIndex()+1;
            ScriptEditor(sstr);
         }






        else if (c==cmSaveScript)
        {
            mys.openScriptsStore();

            if (ScriptName.equals(null))
            {
                SaveAs();
            }
            else
            {
                mys.writeScriptsData(ScriptName,tfScriptEditor.getString(),sindex);
                sstr=tfScriptEditor.getString();
                 Alert a1=new Alert(null,"       ---------Save Script OK !--------  ",imalert,null);
                mys.closeScriptsStore();
                ScriptEditor(tfScriptEditor.getString());
            }
            mys.closeScriptsStore();


        }

        else if (c==cmOkScript)
        {
            my.openBrowserStore();
            my.writeBrowserData(tfScriptEditor.getString(),5);
            Alert a1=new Alert(null,"       --------Script Selected to Run !--------  ",imalert,null);
            dis.setCurrent(a1,this);
            my.closeBrowserStore();
        }

    }
}
