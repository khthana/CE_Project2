import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.*;
import javax.microedition.io.*;

import GUI2.*;




public class MyMail {
    
    private String errResponse;
    private String defaultMail=new String("notta2524@yahoo.com");
    public MyMail() 
    {
    }
     
    public void Sendmail(String t,String f,String s,String d) throws IOException
  {
        HttpConnection http = null;
        InputStream iStrm = null;
        boolean ret = false;


        String Sender=f;
        String Subject_of_Sender=s;
        String Address_of_Reciver=t;
        String Data=d;

       // Data is passed at the end of url for GET
        String url = "http://161.246.5.84:8080/mail?name="+Sender+"&email="+defaultMail+"&send="+Address_of_Reciver+"&text="+Data+"&subject="+s;

        try
        {
          http = (HttpConnection) Connector.open(url);

          //----------------
          // Client Request
          //----------------
          // 1) Send request method
          http.setRequestMethod(HttpConnection.GET);
          // 2) Send header information - none
          // 3) Send body/data -  data is at the end of URL

          //----------------
          // Server Response
          //----------------
          iStrm = http.openInputStream();
          // Three steps are processed in this method call
          ret = processServerResponse(http, iStrm);
          
        }
        finally
        {
          // Clean up
          if (iStrm != null)
            iStrm.close();
          if (http != null)
            http.close();
        }

        // Process request failed, show alert
        //if (ret == false)
         // showAlert(errorMsg);
  }
  
private boolean processServerResponse(HttpConnection http, InputStream iStrm) throws IOException
  {
    //Reset error message
    String errorMsg = null;

    // 1) Get status Line
    if (http.getResponseCode() == HttpConnection.HTTP_OK)
    {
      // 2) Get header information - none

      // 3) Get body (data)
      int length = (int) http.getLength();
      String str;
      if (length != -1)
      {
        byte servletData[] = new byte[length];
        iStrm.read(servletData);
        str = new String(servletData);
      }
      else  // Length not available...
      {
        ByteArrayOutputStream bStrm = new ByteArrayOutputStream();

        int ch;
        while ((ch = iStrm.read()) != -1)
          bStrm.write(ch);

        str = new String(bStrm.toByteArray());
        bStrm.close();
      }

     // Update the string item on the display
     errResponse=str;
     return true;

    }
    else
      // Use message from the servlet
      errResponse =http.getResponseMessage();

    return false;
  }
}
