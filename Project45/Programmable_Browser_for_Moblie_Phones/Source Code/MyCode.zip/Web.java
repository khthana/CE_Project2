import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import java.io.*;
import GUI2.*;

class Web extends Canvas implements CommandListener
{
    //core
    private Display dis;
    private PWB midlet;
    private Menu menu;
    private Image im1,im2,im3,im4,im5,im6,im7,im8,blist;
    private Image imlogo,imalert2,imalert,imm;
    private String tmpt;
    private int px=0,py=0;
    private String url;//current url to display
    private MyData my;//comnect my data
    private MyBookmark myb;//connect my bookmark
    private boolean chkinit;//check when it first install in mobile
    //main menu
    private Command cmExit;
    private Command cmOpenURL;
    private Command cmBookmark;
    private Command cmNextPage;
    private Command cmBackPage;
    private Command cmBack;
    private Command cmReload;
    private Command cmStopPage;
    private Command cmHome;
    private Command cmOK;
    //bookmark
    private List lsBookmark;
    private Command cmAddBookmark;
    private Command cmBookmarkOK;
    private Command cmBackBookmark;
    private Form fmBookmarkName;
    private TextField tfBookmarkName;
    private Image images[]=null;
    //open url
    private Form fmURL;
    private TextField tfURL;
    private String mstr="";
    private MyNextBack mynb;
    //========= for display function
    //Define constant
    private final int MinPoint=1,MaxPoint=200,MinLine=38,MaxLine=218;
    private int CurrentLine=38,CurrentPoint=1,goto_NextLine=12;
    private int Current_tag_value_attribute=0;
    private int Page=1; // Now i am stay where this page is
    private Where2Go Link=new Where2Go();
    private ColorRGB RGB=new ColorRGB();
    //checker
    boolean unorderlist=false;
    XMLparser parserz=new XMLparser();
    private Graphics gtmp;

    Web(PWB midlet,Display d)
    {
        //init interface
        menu=new GUI2.Menu();
        this.midlet=midlet;
        dis=d;
        //init data
        chkinit=true;

        my=new MyData();
        //my.showBrowserData();
        if (my.length()==1)
        {
        my.writeBrowserData(my.readBrowserData(2),1);//copy home to url to display
        System.out.println("this is URL in WEB():"+url);//debug
        my.closeBrowserStore();
        }
        //init bookmark
        myb=new MyBookmark();
        mynb=new MyNextBack();
        int length=myb.length();//records in bookmark
        //init alert

        //init image
        try
        {
            im1=Image.createImage(menu.menu1s);
            im2=Image.createImage(menu.menu2);
            im3=Image.createImage(menu.menu3);
            im4=Image.createImage(menu.menu4);
            im5=Image.createImage(menu.menu5);
            im6=Image.createImage(menu.menu6);
            im7=Image.createImage(menu.menu7);
            // im8=Image.createImage("/menu8.png");
            blist=Image.createImage(menu.blist);//use in bookmark
            imlogo=Image.createImage(menu.PWBlogo);//logo when it is default home
            imalert2=Image.createImage(menu.alert2);
        }
        catch (Exception e)
        {
            System.out.println("error1");
        }
        //init button for main menu
        cmExit=new Command("Exit PWB",Command.EXIT,1);
        cmBack=new Command("Back",Command.SCREEN,2);
        cmOpenURL=new Command("Open URL",Command.OK,2);
        cmBookmark=new Command("Bookmark",Command.OK,2);
        cmNextPage=new Command("Next",Command.OK,2);
        cmBackPage=new Command("Back",Command.OK,2);
        cmReload=new Command("Reload",Command.SCREEN,2);
        cmStopPage=new Command("Stop",Command.SCREEN,2);
        cmHome=new Command("Home",Command.SCREEN,2);

        addCommand(cmExit);
        addCommand(cmOpenURL);
        addCommand(cmBackPage);
        addCommand(cmNextPage);
        addCommand(cmReload);
        addCommand(cmStopPage);
        addCommand(cmHome);
        addCommand(cmBookmark);
        setCommandListener(this);
    }
 //******************************************************************************************
    protected void paint(Graphics g)
    {
        my.openBrowserStore();
        //my.showBrowserData();
        url=my.readBrowserData(1);
        //this back ground color
        g.setColor(255,255,255);
        g.fillRect(0,0,getWidth(),getHeight());
        //top menu area
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.fillRoundRect(2,2,getWidth()-2,menu.menu_h-1,10,8);
        //head
       /* if (chkinit || url.equals("PWBlogo"))
        {
        g.setColor(0,0,0);
        g.drawString("Web Browser",75,25,0);
        }*/
        chkinit=false;
        //line
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.drawLine(2,40,getWidth()-2,40);
        //draw menu
        g.drawImage(im1,0*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im2,1*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im3,2*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im4,3*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im5,4*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im6,5*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im7,6*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        //g.drawImage(im8,0*menu.menu_w,25,Graphics.TOP | Graphics.LEFT);
        System.out.println("***********************************************");
        System.out.println("this is url in paint():"+url);
        System.out.println("***********************************************");

        if (url.equals("PWBlogo"))
        {
            g.drawImage(imlogo,(getWidth()-100)/2,(getHeight()-100)/2,Graphics.TOP | Graphics.LEFT);
            g.setColor(0,0,0);
            g.drawString("Mobile Edition",73,150,0);
        }
        else
        {
           //show XHTML Here
          try
            {
           processRequest();
            ShowXML(g);
            }
            catch (Exception e)
            {
            System.err.println("Msg: " + e.toString());
            }
        }
        g.drawString(mstr,80,45,0);
        my.closeBrowserStore();
    }

    protected void pointerPressed(int x,int y)
    {
        px=x;py=y;
        int real_y1,real_y2,sx,sy,real_x1,real_x2,line;
        int now=0;
        boolean clicked=false;
        String st=null;
        int tmp=menu.SelectedMenu(px,py);

         //for check menu link
        /*System.out.println("PX:"+px);
        System.out.println("PY:"+py);*/
         for (int i=0;i<10;i++)
         {
            real_x1=Link.RetStart_Point(i);
            real_x2=Link.RetEnd_Point(i);
            line=Link.RetLine(i);
            real_y1=line;
            real_y2=real_y1+12;
            /*System.out.println("**********************************");
            System.out.println("real_x1:"+real_x1);
            System.out.println("real_x2:"+real_x2);
            System.out.println("real_y1:"+real_y1);
            System.out.println("real_y2:"+real_y2);
            System.out.println("line:"+line);*/
            st=Link.RetURL(i);
            //System.out.println("URL:"+st);
            //area to click
            if ((px>real_x1) && (px<real_x2) && (py>real_y1) && (py<real_y2))
            {
              now=i;
              clicked=true;
              System.out.println("checked:"+clicked);
              my.openBrowserStore();
              mynb.openNBStore();
              mynb.addcount();
              mynb.writeNBData(my.readBrowserData(1),mynb.count);
              my.writeBrowserData(mynb.readNBData(mynb.count),1);
              System.out.println("count is:"+mynb.count());
              mynb.closeNBStore();
              my.closeBrowserStore();               
            }
         }

         if (clicked)
         {
            my.openBrowserStore();
            my.writeBrowserData(st,1);
            my.closeBrowserStore();
            Web canvas1=new Web(this.midlet,dis);
            midlet.ShowWeb(this.midlet,dis);
         }
        switch (tmp)
        {
            //case 1:midlet.ShowWeb();
            case 2:midlet.ShowScript();break;
            case 3:midlet.ShowMail();break;
            case 4:midlet.ShowFTP();break;
            case 5:midlet.ShowUser();break;
            case 6:midlet.ShowSetting();break;
            case 7:midlet.ShowInfo();break;
            //case 8:midlet.;

        }
    }
   //******************************************************************************************
    public void commandAction(Command c,Displayable d)
    {
        if (c==cmExit)
        {
            midlet.exitMIDlet();
        }
        else if (c==cmOpenURL)
        {
            System.out.println("This is cmOpenURL()");
            fmURL=new Form("Open URL:");
            tfURL=new TextField("Insert Your Address",url,80,TextField.URL);
            cmBack=new Command("Cancel",Command.BACK,2);
            cmOK=new Command("OK",Command.SCREEN,2);
            fmURL.addCommand(cmOK);
            fmURL.addCommand(cmBack);
            fmURL.append(tfURL);
            fmURL.setCommandListener(this);
          //  gtmp.getGraphics(imm);

            dis.setCurrent(fmURL);
        }
        else if (c==cmBack)//back to web()
        {
            midlet.ShowWeb(this.midlet,dis);
        }
        else if (c==cmOK)//ok to set url=input
        {
            my.openBrowserStore();
            my.writeBrowserData(tfURL.getString(),1);
            my.closeBrowserStore();
            //add next history

            mynb.openNBStore();
            if (mynb.length()<=mynb.count)
            mynb.addNB(tfURL.getString());
            else if (mynb.length()>mynb.count)
            mynb.writeNBData(tfURL.getString(),mynb.count);
            System.out.println("count is:"+mynb.count());
            mynb.addcount();
            mynb.closeNBStore();
            Web canvas1=new Web(this.midlet,dis);
            midlet.ShowWeb(this.midlet,dis);
            //midlet.ShowWeb();
        }
        else if (c==cmBookmark)//load bookamark to show
        {
            System.out.println("This is cmBookmark()");
            myb=new MyBookmark();
            cmAddBookmark=new Command("Add",Command.SCREEN,2);
            int length=myb.length();
            String options[]=new String[length];//make array option=number of record in bookmark

            for (int i=0;i<length;i++)
            {
                options[i]=myb.readBookmarkData(i+1,1);//get data(since 1) to array
            }

            lsBookmark=new List("My Bookmark:",List.IMPLICIT,options,null);
            lsBookmark.addCommand(cmAddBookmark);//show add bookmark
            lsBookmark.addCommand(cmBack);
            lsBookmark.setCommandListener(this);

            dis.setCurrent(lsBookmark);
            myb.closeBookmarkStore();
        }
        else if (c==cmAddBookmark)//add current url to bookmark
        {
            System.out.println("This is AddBookmark()");
            fmBookmarkName=new Form("Add Bookmark:");
            tfBookmarkName=new TextField("Type name","<name>",15,TextField.ANY);
            cmBookmarkOK=new Command("OK",Command.OK,2);
            fmBookmarkName.append(tfBookmarkName);
            fmBookmarkName.addCommand(cmBack);
            fmBookmarkName.addCommand(cmBookmarkOK);//and ok
            fmBookmarkName.setCommandListener(this);
            dis.setCurrent(fmBookmarkName);


        }
        else if (c==cmBookmarkOK)//ok to add bookmark
        {
            System.out.println("This is cmBookmarkOK()");
            boolean chkstr=true;
            myb.openBookmarkStore();
            myb.addBookmark(tfBookmarkName.getString(),url);
            System.out.println("data is:"+tfBookmarkName.getString());
            myb.closeBookmarkStore();
            Web canvas1=new Web(this.midlet,dis);
            midlet.ShowWeb(this.midlet,dis);
        }
        else if (c==cmHome)
        {
            my.openBrowserStore();
            my.writeBrowserData(my.readBrowserData(2),1);
            myb.closeBookmarkStore();

            Web canvas1=new Web(this.midlet,dis);
            dis.setCurrent(canvas1);
        }
        else if (c==cmNextPage)
        {
            my.openBrowserStore();
            mynb.openNBStore();

            mynb.addcount();

            my.writeBrowserData(mynb.readNBData(mynb.count),1);
            System.out.println("count is:"+mynb.count());
            mynb.closeNBStore();
            my.closeBrowserStore();
             Web canvas1=new Web(this.midlet,dis);
            midlet.ShowWeb(this.midlet,dis);
        }
        else if (c==cmBackPage)
        {
            my.openBrowserStore();
            mynb.openNBStore();
            mynb.subcount();
            my.writeBrowserData(mynb.readNBData(mynb.count),1);
            System.out.println("in cmBackPage count is:"+mynb.count());
            //mynb.showNBData();
            mynb.closeNBStore();
            my.closeBrowserStore();
            midlet.ShowWeb(this.midlet,dis);
        }
        else if (c==List.SELECT_COMMAND)//get url in which bookmark show
        {
            url=myb.readBookmarkData(lsBookmark.getSelectedIndex()+1,2);//getSelectedIndex() start=0
            my.openBrowserStore();
            my.writeBrowserData(url,1);
            my.closeBrowserStore();
            midlet.ShowWeb(this.midlet,dis);
         }
        else if (c==cmReload)//reload page
        {
            midlet.ShowWeb(this.midlet,dis);

        }
    }
//******************************************************************************************
public void processRequest() throws IOException
  {
    HttpConnection http = null;
    InputStream iStrm = null;

    try
    {
      // Create the connection
      http = (HttpConnection) Connector.open(url);
      http.setRequestMethod(HttpConnection.GET);
      http.setRequestProperty("User-Agent", "Profile/MIDP-1.0 Configuration/CLDC-1.0");
      if (http.getResponseCode() == HttpConnection.HTTP_OK)
      {

       String str;
        iStrm = http.openInputStream();
        int length = (int) http.getLength();
        if (length != -1)
        {
          // Read data in one chunk
          byte serverData[] = new byte[length];
          iStrm.read(serverData);
          str = new String(serverData);
        }
        else  // Length not available...
        {
          ByteArrayOutputStream bStrm = new ByteArrayOutputStream();

          // Read data one character at a time
          int ch;
          while ((ch = iStrm.read()) != -1)
            bStrm.write(ch);

          str = new String(bStrm.toByteArray());
          bStrm.close();
        }

       // String lstr=new String(str.toLowerCase());

        parserz.Parser(str);
        parserz.Getnode(str);

      }
    }
    finally
    {
      // Clean up
      if (iStrm != null)
        iStrm.close();
      if (http != null)
        http.close();
    }
  }


    //====== part of function for display in browser

     protected int NextOutPut()
    {

        if (NotEmpty())
        {
        Current_tag_value_attribute++;
        parserz.decrease_count();
        }
        return 0;
    }

    protected int Back_to_pre_OutPut()
   {

       if (NotEmpty())
       {
       Current_tag_value_attribute--;
       parserz.increase_count();
       }
       return 0;
   }

    protected int center()
    {
    return 0;
    }

     boolean NotEmpty()
    {

       if (parserz.Get_count()==0)
        {return false;}
       else
        {return true;}
    }


       protected int ShowXML(Graphics g)
    {
        while (NotEmpty())
        {

            if(parserz.output_tag[Current_tag_value_attribute]=="<a href>")
            {
                //Flag for position of begin and end of link
                String str=parserz.output_value[Current_tag_value_attribute];
                Link.AddLink(parserz.output_tag_attr[Current_tag_value_attribute]);
                Link.AddStartPt(CurrentPoint);
                Link.AddEndPt(Cal_Pixel_of_char(str,0,str.length(),g));
                Link.AddLine(CurrentLine);
                Link.next();

                RGB.r=0;
                RGB.g=0;
                RGB.b=255;

                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_UNDERLINED,Font.SIZE_MEDIUM));
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM));
            }

            if(parserz.output_tag[Current_tag_value_attribute]=="</a>")
              {
              RGB.r=0;
              RGB.g=0;
              RGB.b=0;
              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
              }

              if(parserz.output_tag[Current_tag_value_attribute]=="<b>")
               {
                  g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_BOLD,Font.SIZE_MEDIUM));
                  Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
                  g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM));
             }

             if(parserz.output_tag[Current_tag_value_attribute]=="</b>")
             {
               Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
             }

            if(parserz.output_tag[Current_tag_value_attribute]=="<big>")
             {
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_BOLD,Font.SIZE_MEDIUM));
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM));
             }

             if(parserz.output_tag[Current_tag_value_attribute]=="</big>")
              {
                 Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
              }

            if(parserz.output_tag[Current_tag_value_attribute]=="<body>")
             {
               if (parserz.output_tag_attr[Current_tag_value_attribute]!="")
               {DrawBg(parserz.output_tag_attr[Current_tag_value_attribute],g);}

               Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
             }
             if(parserz.output_tag[Current_tag_value_attribute]=="<br/>")
             {
               CurrentPoint=1;
               CurrentLine+=goto_NextLine;
               Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
             }

            if(parserz.output_tag[Current_tag_value_attribute]=="<form>")
             {
              String type,name,value;

              NextOutPut();
              System.out.println(parserz.output_tag[Current_tag_value_attribute]);

              // loop for find input tag.
                while (parserz.output_tag[Current_tag_value_attribute]!="</form>")
                {
//                  for (int i=0;char at .....;i++)
                // u must find for tag of input and display it
                // if == type then type="asdsa"
                // if == name then name="asdsa"
                // if == value then value="asdsa"
                //Display picture of form  OK?

                  NextOutPut();
                }//end while
                Back_to_pre_OutPut();

              }

            if(parserz.output_tag[Current_tag_value_attribute]=="</form>")
            {
              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
            }

            if(parserz.output_tag[Current_tag_value_attribute]=="<h1>")
            {
                //Flag for position of begin and end of link
                //String str=parserz.output_value[Current_tag_value_attribute];
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_LARGE));
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM));
            }

            if(parserz.output_tag[Current_tag_value_attribute]=="</h1>")
            {

              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
            }


            if(parserz.output_tag[Current_tag_value_attribute]=="<hr/>")
            {
                  //drawLine(1,1,1,1);
            }

//italic
              if(parserz.output_tag[Current_tag_value_attribute]=="<i>")
            {
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_ITALIC,Font.SIZE_MEDIUM));
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
                g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM));
            }

              if(parserz.output_tag[Current_tag_value_attribute]=="</i>")
            {
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
            }

              if(parserz.output_tag[Current_tag_value_attribute]=="<img>")
            {
             Image(parserz.output_tag_attr[Current_tag_value_attribute],g,parserz.output_value[Current_tag_value_attribute]);
            }

// List
            if(parserz.output_tag[Current_tag_value_attribute]=="<li>")
            {
                CurrentPoint=1;
      //        CurrentLine+=goto_NextLine;

  // Unorder List Here !!!
              if (unorderlist )
              {

              g.fillRect(CurrentPoint,CurrentLine+6,4,4);
              CurrentPoint =CurrentPoint+7;
              parserz.output_value[Current_tag_value_attribute]=parserz.output_value[Current_tag_value_attribute];
              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
              }            //End Unorder List

            }

//Under Line;
            if(parserz.output_tag[Current_tag_value_attribute]=="<u>")
            {
              g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_UNDERLINED ,Font.SIZE_MEDIUM));
              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
              g.setFont(Font.getFont(Font.FACE_SYSTEM,Font.STYLE_PLAIN,Font.SIZE_MEDIUM));
            }

//UnOrder list
            if(parserz.output_tag[Current_tag_value_attribute]=="<ul>")
            {
              unorderlist=true;
              CurrentPoint=1;
              CurrentLine+=goto_NextLine;
              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
            }

            if(parserz.output_tag[Current_tag_value_attribute]=="</ul>")
            {
              unorderlist=false;
              CurrentPoint=1;
              CurrentLine+=goto_NextLine;
              Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
            }


               if(parserz.output_tag[Current_tag_value_attribute]=="<p>")
            {
                System.out.println("<P> in ShowXML  "+parserz.output_value[Current_tag_value_attribute]);

                CurrentPoint=1;
                CurrentLine+=goto_NextLine;
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);

            }
            if(parserz.output_tag[Current_tag_value_attribute]=="</p>")
            {
                Display(parserz.output_value[Current_tag_value_attribute],g,RGB);
            }

            if(parserz.output_tag[Current_tag_value_attribute]=="<title>")
            {
                g.setColor(0,0,0);
                g.drawString(parserz.output_value[Current_tag_value_attribute],0,(CurrentLine-12),0);
                g.setColor(0,0,0);
            }

        NextOutPut();

        }
    return 0;
    }

       int P2CutStr(String str,Graphics g) //It will return substring of Str

       {
           // DeBug Zone *-*-*-*-*-*-*-*-*----*-*-*-*-*-*-*-*-*-*-*-*-*-*-*
           //System.out.println(str);
           //System.out.println("MaxPoint ="+MaxPoint);System.out.println("Pixel Substr Lenght = "+Cal_Pixel_of_char(str,0,str.length(),g));
           //System.out.println("Substr Lenght = "+str.length());
           // DeBug Zone *-*-*-*-*-*-*-*-*----*-*-*-*-*-*-*-*-*-*-*-*-*-*-**

           if ( (MaxPoint) < (Cal_Pixel_of_char(str,0,str.length(),g)) )
                {
                      for (int i =0;i<str.length();i++)
                  {

                    if ((MaxPoint) < (Cal_Pixel_of_char(str,0,i,g)+CurrentPoint))
                    {/*System.out.println("Display Strln= "+(i-1));*/return (i-1);}
                   }

                 }
             else{/*System.out.println("Doing Else By Cut at "+ str.length());*/return (str.length());}
             return 0;
       }
        void Display(String str,Graphics g,ColorRGB RGB)
       {
                int Old_StrPosition=0,P2CutStrPosition=0;
                String Old_str=str;

                g.setColor(RGB.r,RGB.g,RGB.b);

                  while ((str.length()>1))
                 {


                   //Calculate a Position of Strinng
                   P2CutStrPosition=P2CutStr(str,g);
                   Old_str=str;


                   //Display String on the Screen
                   g.drawString(str.substring(0,P2CutStrPosition),CurrentPoint,CurrentLine,0);
                   // Calculate Pixel of CurrentPoint in this case.
                   CurrentPoint+=Cal_Pixel_of_char(str,0,P2CutStrPosition,g);

                   // Mod Current point for making sure! that it never have over value more thne Max
                   if ((CurrentPoint)+10>=(MaxPoint)){CurrentPoint=0;}
                   //Increase CurrentLine
                   CurrentLine+=goto_NextLine;
                   str=Old_str.substring(P2CutStrPosition,Old_str.length());
                 }// End While
                //CurrentLine-=goto_NextLine;  // Don't know error ,May be coz by unknow tag
       }
       int Cal_Pixel_of_char(String str,int i,int j,Graphics g) //It will return substring of Str
       {
           return (g.getFont().substringWidth(str,i,j));
       }


       void Image(String attribute,Graphics g,String value)
       {
          int width=0,hight=0;
          String url,alt;


         //Seperate a String attribute
         int i,j,k;

         for(i=0;(attribute.charAt(i)!='s')&&(attribute.charAt(i+1)!='r')&&(attribute.charAt(i+2)!='c');i++){}
         for (j=i+3;(attribute.charAt(j)!='"');j++){}
         for (k=j+1;(attribute.charAt(k)!='"');k++){}
              url=attribute.substring(j+1,k);
System.out.println("Pass src is : "+attribute.substring(j+1,k));//Display Encoding


         for(i=k;(attribute.charAt(i)!='w')&&(attribute.charAt(i+1)!='i')&&(attribute.charAt(i+2)!='d')&&(attribute.charAt(i+3)!='t')&&(attribute.charAt(i+4)!='h');i++){}
         for (j=i+3;(attribute.charAt(j)!='"');j++){}
         for (k=j+1;(attribute.charAt(k)!='"');k++){}
          width=Integer.parseInt(attribute.substring(j+1,k));
System.out.println("Pass width is : "+attribute.substring(j+1,k));//Display Encoding
          for(i=k;(attribute.charAt(i)!='h')&&(attribute.charAt(i+1)!='i')&&(attribute.charAt(i+2)!='g')&&(attribute.charAt(i+3)!='h')&&(attribute.charAt(i+4)!='t');i++){}
          for (j=i+3;(attribute.charAt(j)!='"');j++){}
          for (k=j+1;(attribute.charAt(k)!='"');k++){}
           hight=Integer.parseInt(attribute.substring(j+1,k));
     System.out.println("Pass hight is : "+attribute.substring(j+1,k));//Display Encoding

     for(i=k;(attribute.charAt(i)!='a')&&(attribute.charAt(i+1)!='l')&&(attribute.charAt(i+2)!='t');i++){}
     for (j=i+3;(attribute.charAt(j)!='"');j++){}
     for (k=j+1;(attribute.charAt(k)!='"');k++){}
      alt=attribute.substring(j+1,k);
System.out.println("Pass alt is : "+attribute.substring(j+1,k));//Display Encoding


          System.out.println("Finished img");//Display Encoding

          // Display img by get size Here!!!

          DisplayImg(url,width,hight,value,alt,g);

       }


       void DisplayImg(String url,int w,int h,String value,String alt,Graphics g)
       {
         try
          {
            Image im;
            if ((im = getImage(url)) != null)
            {
               try
                {

                 if ( (w!=0) && (h!=0))
                 {
                   if ((w>200)||(h>200))
                       {CurrentLine+=goto_NextLine;
                        g.drawString(alt,CurrentPoint,CurrentLine,0);
                        CurrentLine+=goto_NextLine;
                        CurrentPoint=MinPoint;
                        Display(value,g,RGB);
                       }
                   else
                   {CurrentPoint=MinPoint;
                    g.drawImage(im,CurrentPoint,CurrentLine,Graphics.TOP | Graphics.LEFT);
                    CurrentLine+=im.getHeight();
                    Display(value,g,RGB);
                   }
                 }

                 else if ((w==0)||(h==0))
                 {
                   if( (im.getHeight()>200) || (im.getWidth()>200))

                   {CurrentLine+=goto_NextLine;
                    g.drawString(alt,CurrentPoint,CurrentLine,0);
                    CurrentLine+=goto_NextLine;
                    CurrentPoint=MinPoint;
                    Display(value,g,RGB);
                   }
                   else
                   {CurrentPoint=MinPoint;
                    g.drawImage(im,CurrentPoint,CurrentLine,Graphics.TOP | Graphics.LEFT);
                    CurrentLine+=im.getHeight();
                    Display(value,g,RGB);
                   }
                 }
                }
                catch (Exception e)
                {

                }
            }

            else
            {
                //display.setCurrent(fmViewPng);
            }
          }
          catch (Exception e)
          {
            System.err.println("Msg: " + e.toString());
          }


       }


 /*--------------------------------------------------
  * Open connection and download png into a byte array.
  *-------------------------------------------------*/
  private Image getImage(String url) throws IOException
  {
    ContentConnection connection = (ContentConnection) Connector.open(url);

    // * There is a bug in MIDP 1.0.3 in which read() sometimes returns
    //   an invalid length. To work around this, I have changed the
    //   stream to DataInputStream and called readFully() instead of read()
//    InputStream iStrm = connection.openInputStream();
    DataInputStream iStrm = connection.openDataInputStream();

    ByteArrayOutputStream bStrm = null;
    Image im = null;

    try
    {
      // ContentConnection includes a length method
      byte imageData[];
      int length = (int) connection.getLength();
      if (length != -1)
      {
        imageData = new byte[length];

        // Read the png into an array
//        iStrm.read(imageData);
        iStrm.readFully(imageData);
      }
      else  // Length not available...
      {
        bStrm = new ByteArrayOutputStream();

        int ch;
        while ((ch = iStrm.read()) != -1)
          bStrm.write(ch);

        imageData = bStrm.toByteArray();
        bStrm.close();
      }

      // Create the image from the byte array
      im = Image.createImage(imageData, 0, imageData.length);
    }
    finally
    {
      // Clean up
      if (iStrm != null)
        iStrm.close();
      if (connection != null)
        connection.close();
      if (bStrm != null)
        bStrm.close();
    }
    return (im == null ? null : im);
  }

// Display Background

  void DrawBg(String UrlPic,Graphics g)
  {
    try
     {
       Image im;

if ((im = getImage(UrlPic)) != null)
       {
          try
           {
            g.drawImage(im,MinPoint,MinLine+3,Graphics.TOP | Graphics.LEFT);
           }
    catch (Exception e)
           {
           }
       }
    }
catch (Exception e)
     {
       System.err.println("Msg: " + e.toString());
     }


  }


}
