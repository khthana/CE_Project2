import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import GUI2.*;

class Setting extends Canvas implements CommandListener
{
    
    private PWB midlet;
    private Display dis;
    private Image im1,im2,im3,im4,im5,im6,im7,im8,im11,im12,im13;
    private Image imhome,imdefault,imchoice,imalert;
    private Image imcolor,imstyle,imred,imgreen,imblue,impink,imorange,imviolet,imforrest,imocean;
    private Menu menu;
    private int px=0,py=0;
    private Command cmExit;
    private Command cmOpenURL;
    private Command cmBookmark;
    private Command cmNextPage;
    private Command cmBackPage;
    private Command cmReload;
    private Command cmStopPage;
    private Command cmHome;
    //set browser
    private List lsSetBrowser;
    private List lsSetHome;
    private Command cmSetHomeOK;
    private Command cmBackSetting;
    private Command cmBackSetHome;
    private TextField tfSetHome;
    private MyData my;
    private MyBookmark myb;
    private int chkid;
    private Alert a,a1,a2;
    //set look
    private List lsSetLook;
    private List lsSetColor;
    private List lsSetStyle;
    
    Setting(PWB midlet,Display d)
    {
        menu=new GUI2.Menu();
        this.midlet=midlet;
        myb=new MyBookmark();
        dis=d;
        my=new MyData();
        String inf=my.readBrowserData(3);
        System.out.println("this is URL in Setting interface():"+inf);
        
        try
        {
            im1=Image.createImage(menu.menu1);
            im2=Image.createImage(menu.menu2);
            im3=Image.createImage(menu.menu3);
            im4=Image.createImage(menu.menu4);
            im5=Image.createImage(menu.menu5);
            im6=Image.createImage(menu.menu6s);
            im7=Image.createImage(menu.menu7);            
         //   im8=Image.createImage("/menu8.png");
            imdefault=Image.createImage("/default.png");
            imchoice=Image.createImage("/choice.png");
            imalert=Image.createImage("/alert.png");
            imhome=Image.createImage("/home.png");
            if (my.readBrowserData(3).equals("standard"))
            {
                im11=Image.createImage("/set1.png");
                im12=Image.createImage("/set2.png");
                im13=Image.createImage("/set3.png");
            }
            else if (my.readBrowserData(3).equals("ocean"))
            {
                im11=Image.createImage("/xset1.png");
                im12=Image.createImage("/xset2.png");
                im13=Image.createImage("/xset3.png");
            }
            imocean=Image.createImage("/xset1.png");
            imforrest=Image.createImage("/set1.png");
            imgreen=Image.createImage("/c_green.png");
            imblue=Image.createImage("/c_blue.png");
            imviolet=Image.createImage("/c_violet.png");
            impink=Image.createImage("/c_pink.png");
            imred=Image.createImage("/c_red.png");
            imorange=Image.createImage("/c_orange.png");
            imcolor=Image.createImage("/color.png");
            imstyle=Image.createImage("/style.png");    
        }
        catch (Exception e)
        {
             System.err.println("Error in setting()-->" + e.toString());
        }
        cmExit=new Command("Exit PWB",Command.EXIT,1);
        cmBackSetting=new Command("Back Setting",Command.SCREEN,1);
        cmSetHomeOK=new Command("OK",Command.SCREEN,2);
        a=new Alert(null,"       ---------Set Home Page OK !--------  ",imalert,null);
        a2=new Alert(null,"      -------Restart to see changing !--------  ",imalert,null);
        addCommand(cmExit);
        my.closeBrowserStore();
        
        setCommandListener(this);            
    }
    
    protected void paint(Graphics g)
    {
        g.setColor(255,255,255);
        g.fillRect(0,0,getWidth(),getHeight());
        
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.fillRoundRect(2,2,getWidth()-2,menu.menu_h-1,10,8);
        
        g.setColor(0,0,0);
        g.drawString("Setting",95,25,0);
        
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.drawLine(2,40,getWidth()-2,40);

        g.drawImage(im1,0*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im2,1*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im3,2*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im4,3*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im5,4*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im6,5*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im7,6*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        //g.drawImage(im8,0*menu.menu_w,25,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im11,menu.getx(11),menu.gety(11),Graphics.TOP | Graphics.LEFT);
        g.drawImage(im12,menu.getx(12),menu.gety(12),Graphics.TOP | Graphics.LEFT);
        g.drawImage(im13,menu.getx(13),menu.gety(13),Graphics.TOP | Graphics.LEFT);
    }
    protected void pointerPressed(int x,int y)
    {
        px=x;py=y;
        int tmp=menu.SelectedMenu(px,py);
        System.out.println(tmp);
        switch (tmp)
        {
            case 1:midlet.ShowWeb(this.midlet,dis);break;
            case 2:midlet.ShowScript();break;
            case 3:midlet.ShowMail();break;
            case 4:midlet.ShowFTP();break;
            case 5:midlet.ShowUser();break;
            //case 6:midlet.ShowSetting();break;
            case 7:midlet.ShowInfo();break;
            case 11:chkid=3;setLook();break;
            case 12:chkid=1;setBrowser();break;
            //case 8:midlet.;
            
        }
    }
    
    public void setLook()
    {
        String options[]={"Color","Style"};
        Image images[]={imcolor,imstyle};
        lsSetLook=new List("Look & Feel setting:",List.IMPLICIT,options,images); 
        lsSetLook.addCommand(cmBackSetting);
        lsSetLook.setCommandListener(this);
        dis.setCurrent(lsSetLook);
    }
    
    public void setColor()
    {
        String options[]={"Green","Blue","Violet","Pink","Red","Orange"};        
        Image images[]={imgreen,imblue,imviolet,impink,imred,imorange};
        lsSetColor=new List("Set Browser Color:",List.IMPLICIT,options,images); 
        lsSetColor.addCommand(cmBackSetting);
        lsSetColor.setCommandListener(this);
        dis.setCurrent(lsSetColor);
    }
    
    public void setStyle()
    {
        String options[]={"Forrest style <default>","Ocean style"};
        Image images[]={imforrest,imocean};
        lsSetStyle=new List("Set Browser Style:",List.IMPLICIT,options,images); 
        lsSetStyle.addCommand(cmBackSetting);
        lsSetStyle.setCommandListener(this);
        dis.setCurrent(lsSetStyle);
    }
    
    public void setMyColor(String sc)
    {
        my.openBrowserStore();
        my.writeBrowserData(sc,4);
        my.closeBrowserStore();
        dis.setCurrent(a2,this);
    }
    
    public void setMyStyle(String ss)
    {
        my.openBrowserStore();
        my.writeBrowserData(ss,3);
        my.closeBrowserStore();
        dis.setCurrent(a2,this);
    }
    
    public void setBrowser()
    {
        String options[]={"Home page","Default all"};
        Image images[]={imhome,imdefault};
        lsSetBrowser=new List("Browser Setting:",List.IMPLICIT,options,images); 
        System.out.println("this is setBrowser():");
        lsSetBrowser.addCommand(cmBackSetting);
        lsSetBrowser.setCommandListener(this);
        dis.setCurrent(lsSetBrowser);
    }
    
    public void setHome()
    {
        String options[]={"Use blank","Use default","Use current","Set Home page"};
        Image images[]={imchoice,imchoice,imchoice,imchoice};
        System.out.println("this is setHome():");
        lsSetHome=new List("Set Home page:",List.IMPLICIT,options,images);
        lsSetHome.addCommand(cmBackSetting);
        lsSetHome.setCommandListener(this);
        dis.setCurrent(lsSetHome);
    }
    
    public void setMyHome()
    {
        my.openBrowserStore();
        my.readBrowserData(1);  
        cmSetHomeOK=new Command("OK",Command.OK,1);
        Form fmSetHome=new Form("Set Home page:");  
        tfSetHome=new TextField("Type your address",my.readBrowserData(1),50,TextField.ANY);
        fmSetHome.append(tfSetHome);
        fmSetHome.addCommand(cmSetHomeOK);
        fmSetHome.addCommand(cmBackSetting);
        fmSetHome.setCommandListener(this);
        my.closeBrowserStore();
        dis.setCurrent(fmSetHome);   
    }
    
    public void DefaultAll()
    {
        my.openBrowserStore();
        my.writeBrowserData("http://127.0.0.1.project/default.html",1);
        my.writeBrowserData("PWBlogo",2);
        my.closeBrowserStore();
        
        myb.openBookmarkStore();
        int x=0;
        System.out.println("this is default all():"+myb.length());
        for (int i=0;i<myb.length();i++)
        {
            x=myb.length()-i;
            if (x!=1)
            myb.deleteBookmarkData(x);
        }
        myb.writeBookmarkData("TestBrowser","http://127.0.0.1/project/m2.htm",1);
        myb.closeBookmarkStore();
        a1=new Alert(null,"      ---------Set Default for all !--------  ",imalert,null);
        dis.setCurrent(a1,this);
    }
    public void commandAction(Command c,Displayable d)
    {
        if (c==cmExit)
        {
            midlet.exitMIDlet();
        }
        else if (c==cmBackSetting)
        {
            dis.setCurrent(this);
        }
        else if (c==cmSetHomeOK)
        {
            my.openBrowserStore();
            my.writeBrowserData(tfSetHome.getString(),2);
            my.closeBrowserStore();
            dis.setCurrent(a,this);
        }
        else if (c==List.SELECT_COMMAND)
        {
            if (chkid==1)
            {
                //get url from bookmarkstore
                switch (lsSetBrowser.getSelectedIndex())
                {
                    case 0:chkid=2;setHome();break;
                    case 1:DefaultAll();break;
                }
            }
            else if (chkid==2)
            {              
                switch (lsSetHome.getSelectedIndex())
                {
                    //use blank
                    case 0:
                        my.openBrowserStore();
                        my.writeBrowserData("blank",2);
                        my.closeBrowserStore();
                        dis.setCurrent(a,this);
                        break;
                    //use default
                    case 1:
                        my.openBrowserStore();
                        my.writeBrowserData("PWBlogo",2);
                        my.closeBrowserStore();
                        dis.setCurrent(a,this);
                        break;
                    //use current
                    case 2:
                        my.openBrowserStore();
                        my.readBrowserData(1);                   
                        my.writeBrowserData(my.readBrowserData(1),2);
                        my.closeBrowserStore();
                        dis.setCurrent(a,this);
                        break;
                    //set
                    case 3:
                        setMyHome();
                        break;
                }  
             
            }
            else if (chkid==3)
            {
                switch (lsSetLook.getSelectedIndex())
                {
                    case 0:chkid=4;setColor();break;
                    case 1:chkid=5;setStyle();break;
                }
            }
             else if (chkid==4)
            {//"Green","Blue","Violet","Pink","Red","Orange"};
                switch (lsSetColor.getSelectedIndex())
                {
                    case 0:setMyColor("green");break;
                    case 1:setMyColor("blue");break;
                    case 2:setMyColor("violet");break;
                    case 3:setMyColor("pink");break;
                    case 4:setMyColor("red");break;
                    case 5:setMyColor("orange");break;
                }
            }
             else if (chkid==5)
            {
                switch (lsSetStyle.getSelectedIndex())
                {
                    case 0:setMyStyle("standard");break;
                    case 1:setMyStyle("ocean");break;
                }
            }
         }
    }
   
}
