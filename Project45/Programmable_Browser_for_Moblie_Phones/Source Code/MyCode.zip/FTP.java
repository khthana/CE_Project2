import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import GUI2.*;

class FTP extends Canvas implements CommandListener
{
    
    private PWB midlet;
    private Display dis;
    private Image im1,im2,im3,im4,im5,im6,im7,im8;
    private Menu menu;
    private int px=0,py=0;
    private Command cmExit;
    private Command cmOpenURL;
    private Command cmBookmark;
    private Command cmNextPage;
    private Command cmBackPage;
    private Command cmReload;
    private Command cmStopPage;
    private Command cmHome;

    
    FTP(PWB midlet,Display d)
    {
        menu=new GUI2.Menu();
        this.midlet=midlet;
        dis=d;
        try
        {
            im1=Image.createImage(menu.menu1);
            im2=Image.createImage(menu.menu2);
            im3=Image.createImage(menu.menu3);
            im4=Image.createImage(menu.menu4s);
            im5=Image.createImage(menu.menu5);
            im6=Image.createImage(menu.menu6);
            im7=Image.createImage(menu.menu7);
         //   im8=Image.createImage("/menu8.png");
        }
        catch (Exception e)
        {
            System.out.println("Hello1");
        }
        cmExit=new Command("Exit PWB",Command.EXIT,1);
        cmBackPage=new Command("Back",Command.SCREEN,2);
        cmOpenURL=new Command("Open URL",Command.SCREEN,2);
        cmBookmark=new Command("Bookmark",Command.SCREEN,2);
        cmNextPage=new Command("Next",Command.SCREEN,2);
        cmReload=new Command("Reload",Command.SCREEN,2);
        cmStopPage=new Command("Stop",Command.SCREEN,2);
        cmHome=new Command("Home",Command.SCREEN,2);
        addCommand(cmExit);
        
        setCommandListener(this);            
    }
    
    protected void paint(Graphics g)
    {
        g.setColor(255,255,255);
        g.fillRect(0,0,getWidth(),getHeight());
        
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.fillRoundRect(2,2,getWidth()-2,menu.menu_h-1,10,8);
        
        g.setColor(0,0,0);
        g.drawString("FTP&Remote system",75,25,0);
        
        g.setColor(menu.bg_r,menu.bg_g,menu.bg_b);
        g.drawLine(2,40,getWidth()-2,40);

        g.drawImage(im1,0*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im2,1*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im3,2*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im4,3*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im5,4*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im6,5*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        g.drawImage(im7,6*menu.menu_w,0,Graphics.TOP | Graphics.LEFT);
        //g.drawImage(im8,0*menu.menu_w,25,Graphics.TOP | Graphics.LEFT);
    }
    protected void pointerPressed(int x,int y)
    {
        px=x;py=y;
        int tmp=menu.SelectedMenu(px,py);
        System.out.println(tmp);
        switch (tmp)
        {
            case 1:midlet.ShowWeb(this.midlet,dis);break;
            case 2:midlet.ShowScript();break;
            case 3:midlet.ShowMail();break;
            //case 4:midlet.ShowFTP();break;
            case 5:midlet.ShowUser();break;
            case 6:midlet.ShowSetting();break;
            case 7:midlet.ShowInfo();break;
            //case 8:midlet.;
            
        }
    }
    public void commandAction(Command c,Displayable d)
    {
        if (c==cmExit)
        {
            midlet.exitMIDlet();
        }
        /*else if (c==cmOpenURL)
        {
            midlet.display.setCurrent(fmMain);
        }*/
    }
   
}
