<%@ WebService Language="vb" Codebehind="Service1.asmx.vb" Class="shop_B.Service1" %>
