<%@ WebService Language="vb" Codebehind="Service1.asmx.vb" Class="shop_A.Service1" %>
