<%@ Import Namespace=shop_A %>
<script language="vb" runat="server">
	Private Sub queryProduct(sender As System.Object,e As EventArgs)
	Dim wService As New shop_A.Service1() 
	
	label1.Text = wService.showDetail(text1.Text) 
End	Sub
</script>
<form runat="server" ID="Form1">
	Enter ProDuct ID :
	<asp:TextBox id="text1" runat="server" />
	<asp:button text="submit" onclick="queryProduct" runat="server" id="Button1" />
	<br>
	Product Price :
	<asp:label id="label1" runat="server" />
</form>
