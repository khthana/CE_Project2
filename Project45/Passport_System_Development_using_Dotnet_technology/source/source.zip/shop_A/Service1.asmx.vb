Imports System.Web.Services
Imports System.Data
Imports System.Data.SqlClient
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
    End Sub

#End Region

    ' WEB SERVICE EXAMPLE
    ' The HelloWorld() example service returns the string Hello World.
    ' To build, uncomment the following lines then save and build the project.
    ' To test this web service, ensure that the .asmx file is the start page
    ' and press F5.
    '

    <WebMethod()> Public Function showDetail(ByVal productID As String) As String
        Return getDetail(productID)
    End Function

    Private Function getDetail(ByVal productID As String) As String
        Dim objdataReader As SqlDataReader
        Dim objConn As SqlConnection
        Dim objCmd As SqlCommand
        Dim StrConn As String = "server=localhost;database=shop_A;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim sql As String

        check = Left(productID, 3)
        If check = "cpu" Then
            sql = "select * from cpu where ID = '" & productID & "'"
        ElseIf check = "ram" Then
            sql = "select * from ram where ID = '" & productID & "'"
        ElseIf check = "hdd" Then
            sql = "select * from hdd where ID = '" & productID & "'"
        ElseIf check = "mbd" Then
            sql = "select * from mbd where ID = '" & productID & "'"
        ElseIf check = "vga" Then
            sql = "select * from vga where ID = '" & productID & "'"
        ElseIf check = "pda" Then
            sql = "select * from pda where ID = '" & productID & "'"
        ElseIf check = "cdd" Then
            sql = "select * from cdd where ID = '" & productID & "'"
        ElseIf check = "mon" Then
            sql = "select * from mon where ID = '" & productID & "'"
        ElseIf check = "snd" Then
            sql = "select * from snd where ID = '" & productID & "'"
        ElseIf check = "spk" Then
            sql = "select * from spk where ID = '" & productID & "'"
        ElseIf check = "mdm" Then
            sql = "select * from mdm where ID = '" & productID & "'"
        ElseIf check = "pnt" Then
            sql = "select * from pnt where ID = '" & productID & "'"
        ElseIf check = "scn" Then
            sql = "select * from scn where ID = '" & productID & "'"
        ElseIf check = "ups" Then
            sql = "select * from ups where ID = '" & productID & "'"
        ElseIf check = "scs" Then
            sql = "select * from scs where ID = '" & productID & "'"
        ElseIf check = "bup" Then
            sql = "select * from bup where ID = '" & productID & "'"
        ElseIf check = "cam" Then
            sql = "select * from cam where ID = '" & productID & "'"
        ElseIf check = "hub" Then
            sql = "select * from hub where ID = '" & productID & "'"
        ElseIf check = "lan" Then
            sql = "select * from lan where ID = '" & productID & "'"
        ElseIf check = "hdc" Then
            sql = "select * from hdc where ID = '" & productID & "'"
        ElseIf check = "nbk" Then
            sql = "select * from nbk where ID = '" & productID & "'"
        ElseIf check = "mcd" Then
            sql = "select * from mcd where ID = '" & productID & "'"
        ElseIf check = "opt" Then
            sql = "select * from opt where ID = '" & productID & "'"
        Else : sql = "select * from cpu where ID = '" & productID & "'"

        End If


        objConn = New SqlConnection(StrConn)
        objCmd = New SqlCommand(sql, objConn)
        objConn.Open()
        objdataReader = objCmd.ExecuteReader()

        If objdataReader.Read() Then
            valReturn = objdataReader("Price")
        Else
            valReturn = "Sorry,not found"
        End If
        objdataReader.Close()

        Return valReturn

    End Function

End Class
