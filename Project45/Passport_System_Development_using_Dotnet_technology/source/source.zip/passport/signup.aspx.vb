Imports System.Web.Services
Imports System.Web.Mail
Imports System.Data.SqlClient
Imports System.Data
Imports System.io
Imports System.Web
Imports Encryption
Imports System.Text
Imports passport.net.serviceobjects.ws2
Public Class signup
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents password1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents password2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents submit1 As System.Web.UI.WebControls.Button
    Protected WithEvents Occupation As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dobyear As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dobmonth As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dobdate As System.Web.UI.WebControls.DropDownList
    Protected WithEvents sex2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents sex1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents sex As System.Web.UI.WebControls.TextBox
    Protected WithEvents country As System.Web.UI.WebControls.DropDownList
    Protected WithEvents zone As System.Web.UI.WebControls.DropDownList
    Protected WithEvents email1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Zip As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents city As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents sername As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents name As System.Web.UI.WebControls.TextBox
    Protected WithEvents form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents CheckEmail2 As System.Web.UI.WebControls.RegularExpressionValidator
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents address As System.Web.UI.WebControls.TextBox
    Protected WithEvents Form2 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents Label15 As System.Web.UI.WebControls.Label
    Protected WithEvents Label14 As System.Web.UI.WebControls.Label
    Protected WithEvents Button4 As System.Web.UI.WebControls.Button
    Protected WithEvents Button3 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents q_secret As System.Web.UI.WebControls.TextBox
    Protected WithEvents a_secret As System.Web.UI.WebControls.TextBox
    Protected WithEvents reset1 As System.Web.UI.HtmlControls.HtmlInputButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myAdapter As SqlDataAdapter
    Dim myCommand As SqlCommand
    Dim myConnString As String
    Dim IV() As Byte = Encoding.ASCII.GetBytes("init vec")
    Dim Key() As Byte = Encoding.ASCII.GetBytes("password")
    Dim email As String
    Dim pass As String
    Public test As String = " test"
    Public Function encrypt(ByVal pt As String) As String
        Dim plainText() As Byte = Encoding.ASCII.GetBytes(pt)
        Dim algorithmID As EncryptionAlgorithm
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim enc As Encryptor = New Encryptor(EncryptionAlgorithm.Des)
        Dim cipherText() As Byte = Nothing
        Dim ct As String
        enc.IV = IV
        cipherText = enc.Encrypt(plainText, Key)
        IV = enc.IV
        Key = enc.Key
        ct = Convert.ToBase64String(cipherText)

        Return ct
    End Function
    '  Public Function decrypt(ByVal ct As String) As String
    '   Dim cipherText() As Byte = Convert.FromBase64String(ct)
    '  Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
    ' Dim dec As Decryptor = New Decryptor(algorithm)
    'Dim plainText() As Byte = Nothing
    '     Dim pt As String
    '    dec.IV = IV
    '   ' Go ahead and decrypt.
    '  plainText = dec.Decrypt(cipherText, Key)
    ' pt = Encoding.ASCII.GetString(plainText)
    ' Look at your plain text.
    '        Return pt
    '   End Function
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
        myConnection = New SqlConnection(myConnString)
        myConnection.Open()


        If Session("id") = Nothing Then
            Session("id") = 1
            'Response.Redirect("main.aspx")
        End If
    End Sub
    Sub Page_UnLoad()
        myConnection.Close()
    End Sub
    Sub Page_Error(ByVal sender As Object, ByVal e As EventArgs)

        Response.Redirect("reg_error.aspx")
        Context.ClearError()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Label1.Visible = "false"
        Label2.Visible = "false"
        Label3.Visible = "false"

        Dim email As String = email1.Text
        Dim p1 As String = password1.Text
        Dim p2 As String = password2.Text
        Dim check As String = "@"
        Dim temp As Integer
        Dim tmp As Integer
        Dim temp1 As Integer = Len(p1)
        Dim temp2 As Integer = Len(p2)
        Dim net As New net.serviceobjects.ws2.DOTSEmailValidate()


        If email <> "" And p1 <> "" And p2 <> "" Then
            temp = InStr(email, check)
            tmp = InStr(email, ".")

            Label1.Visible = "false"
            Label2.Visible = "false"
            Label3.Visible = "false"
            If temp = 0 Or tmp = 0 Then
                Label1.Text = "�س��͡�ٻẺ Email �Դ !"
                Label1.Visible = "true"
            ElseIf temp1 < 6 Or temp2 < 6 Then
                If temp1 < 6 Then
                    Label2.Text = "��سҡ�͡ Password ���ҧ���� 6 ��� !"
                    Label2.Visible = "true"
                End If
                If temp2 < 6 Then
                    Label3.Text = "��سҡ�͡ Password	�׹�ѹ�Դ ���ҧ���� 6 ��� !"
                    Label3.Visible = "true"
                End If

            ElseIf p1 <> p2 Then
                Label2.Text = "�س��͡ Password	���ç�ѹ !"
                Label2.Visible = "true"
                Label3.Text = "�س��͡ Password	�׹�ѹ ���ç�ѹ !"
                Label3.Visible = "true"
          

            Else
                If net.ValidateEmail(email1.Text, "WS10-YMQ2-CXI3").SyntaxCheck <> "Passed" Or net.ValidateEmail(email1.Text, "WS10-YMQ2-CXI3").SMTPCheck <> "Passed" Or net.ValidateEmail(email1.Text, "WS10-YMQ2-CXI3").DNSCheck <> "Passed" Then

                    Label1.Text = "��������������ŧ����¹����������ԧ"
                    Label1.Visible = True
                Else
                    Dim dtCmd As SqlDataAdapter
                    Dim dtSet As New DataSet()
                    mySelectQuery = "SELECT * from member where email = '" & email & "'"
                    dtCmd = New SqlDataAdapter(mySelectQuery, myConnection)
                    dtCmd.Fill(dtSet)

                    If dtSet.Tables(0).Rows.Count = 0 Then

                        Session("id") = 2
                        Session("email") = email1.Text
                        Session("pass") = p1
                        Response.Redirect("signup.aspx")
                    End If
                    Label1.Text = "���������ӡ��ŧ����¹����"
                    Label1.Visible = True
                End If
            End If
        Else
                If email = "" Then
                    Label1.Text = "�س������͡ Email !"
                    Label1.Visible = "true"
                End If
                If p1 = "" Then
                    Label2.Text = "�س������͡ Password !"
                    Label2.Visible = "true"
                End If
                If p2 = "" Then
                    Label3.Text = "�س������͡ �����׹�ѹ Password !"
                    Label3.Visible = "true"
                End If


            End If
    End Sub



    Private Sub submit1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles submit1.Click
        Label5.Visible = "false"
        Label6.Visible = "false"
        Label7.Visible = "false"
        Label4.Visible = "false"
        Label8.Visible = False
        Label9.Visible = False

        If name.Text <> "" And sername.Text <> "" And city.Text <> "" And Zip.Text <> "" And dobdate.SelectedItem.Text <> "none" And dobmonth.SelectedItem.Value <> "none" And dobyear.SelectedItem.Text <> "none" Then

            If sex1.Checked Then
                sex.Text = sex1.Text
            ElseIf sex2.Checked Then
                sex.Text = sex2.Text
            End If

            Session("name") = name.Text
            Session("surname") = sername.Text
            Session("address") = address.Text
            Session("province") = city.Text
            Session("zipcode") = Zip.Text
            Session("country") = country.SelectedItem.Text
            Session("zonetime") = zone.SelectedItem.Text
            Session("sex") = sex.Text
            Session("month") = dobmonth.SelectedItem.Value
            Session("day") = dobdate.SelectedItem.Text
            Session("year") = dobyear.SelectedItem.Text
            Session("job") = Occupation.SelectedItem.Text

            '     ' ��Ǩ�ͺ��������Ṻ���������
            '     If attachment <> Nothing And attachment.PostedFile.ContentLength > 0 Then
            '         ' ��˹� directory ����Ѻ����������Ǥ��� 
            '         Dim tempDir As New DirectoryInfo(Server.MapPath("temp/"))

            '         If tempDir.Exists = False Then
            '             tempDir.Create()
            '         End If
            '         ' �֧���� upload �����
            '         Dim postedFile As HttpPostedFile
            '         postedFile = attachment.PostedFile

            '         ' ��Ң���������ǡѺ�����
            '         Dim originalPostedFileInfo As FileInfo
            '         originalPostedFileInfo = New FileInfo(postedFile.FileName)

            '         ' ���੾�Ъ�������� (�����Ҫ��� directory ��������� directory �ͧ����ͧ�����)
            '         Dim postedFileName As String
            '         postedFileName = originalPostedFileInfo.Name
            '         Dim postedFileInfo As FileInfo
            '         postedFileInfo = New FileInfo(tempDir.FullName + postedFileName)

            '         ' ૿�������� server
            '         Try
            '             postedFile.SaveAs(postedFileInfo.FullName)
            '         Catch
            'Response.Write("Cannot temporarily save an attachment on the server.");
            '         End Try

            ' End If


            Session("id") = 3
            Response.Redirect("signup.aspx")

        Else
                If name.Text = "" Then
                    Label5.Text = "�س������͡ ���� !"
                    Label5.Visible = "true"
                End If
                If sername.Text = "" Then
                    Label6.Text = "�س������͡ ���ʡ�� !"
                    Label6.Visible = "true"
                End If
                If address.Text = "" Then
                    Label9.Text = "�س������͡ ������� !"
                    Label9.Visible = "true"
                End If
                If city.Text = "" Then
                    Label7.Text = "�س������͡ �ѧ��Ѵ !"
                    Label7.Visible = "true"
                End If
                If Zip.Text = "" Then
                    Label4.Text = "�س������͡ ������ɳ��� !"
                    Label4.Visible = "true"
                End If
                If dobdate.SelectedItem.Text = "none" Or dobmonth.SelectedItem.Text = "none" Or dobyear.SelectedItem.Text = "none" Then
                    Label8.Text = "�ѹ��͹���Դ�ͧ�س�������ó� !"
                    Label8.Visible = "true"
                End If




        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Session("id") = 1
        Response.Redirect("signup.aspx")
    End Sub
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Session("id") = 2
        Response.Redirect("signup.aspx")
    End Sub
    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Label14.Visible = False
        Label15.Visible = False

        If q_secret.Text <> "" And q_secret.Text <> "" Then

            myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnString)
            myConnection.Open()

            If sex1.Checked Then
                sex.Text = sex1.Text
            ElseIf sex2.Checked Then
                sex.Text = sex2.Text
            End If
            mySelectQuery = "INSERT INTO member(email,password,status) " & _
              "VALUES ('" & Session("email") & "','" & Session("pass") & "','0')"
            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()

            mySelectQuery = "INSERT INTO biography(email,name,surname,address,province,zipcode,country,timezone,sex,birthday,job) " & _
              "VALUES ('" & Session("email") & "','" & Session("name") & "','" & Session("surname") & "','" & Session("address") & "','" & Session("province") & _
              "','" & Session("zipcode") & "','" & Session("country") & "','" & Session("zonetime") & "','" & Session("sex") & _
              "','" & Session("month") & "/" & Session("day") & "/" & Session("year") & _
              "','" & Session("job") & "')"
            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()

            mySelectQuery = "INSERT INTO secret(email,q_secret,a_secret) " & _
                         "VALUES ('" & Session("email") & "','" & q_secret.Text & "','" & a_secret.Text & "')"
            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()

            Dim myMail = New MailMessage()
            myMail.To = Session("email")
            myMail.From = "admin@passport.net"
            myMail.Subject = "Passport For Member"
            myMail.Body = "��Ҫԡ passport : " & Session("email") & _
                         "���ʼ�ҹ�ͧ�س��� : " & Session("pass") & _
                          "----------------------------" & _
                         "˹���ǻ䫵���ѡ�ͧ��� : http://network07.ce.kmitl.ac.th/passport/main.aspx"

            myMail.BodyFormat = MailFormat.Text
            SmtpMail.SmtpServer = "mail.kmitl.ac.th"
            SmtpMail.Send(myMail)

            Response.Redirect("reg_complete.aspx?e=" & encrypt(Session("email")))
            Session.Contents.Remove("email")
            Session.Contents.Remove("pass")
            Session.Contents.Remove("name")
            Session.Contents.Remove("surname")
            Session.Contents.Remove("address")
            Session.Contents.Remove("province")
            Session.Contents.Remove("zipcode")
            Session.Contents.Remove("country")
            Session.Contents.Remove("zonetime")
            Session.Contents.Remove("sex")
            Session.Contents.Remove("month")
            Session.Contents.Remove("day")
            Session.Contents.Remove("year")
            Session.Contents.Remove("job")
            Session.Contents.Remove("id")




        Else
            If q_secret.Text = "" Then
                Label14.Text = "�س������͡ �Ӷ�� !"
                Label14.Visible = "true"
            End If
            If a_secret.Text = "" Then
                Label15.Text = "�س������͡ �ӵͺ !"
                Label15.Visible = "true"
            End If

        End If
    End Sub
End Class
