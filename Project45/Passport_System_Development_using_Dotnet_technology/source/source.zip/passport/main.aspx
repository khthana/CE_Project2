<%@ Page Language="vb" AutoEventWireup="false" Codebehind="main.aspx.vb" Inherits="passport.main"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>

<HTML>
  <HEAD>
<title>Passport</title>
<meta content=True name=vs_showGrid>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
<meta http-equiv=Content-Type content="text/html; charset=tis-620">
  </HEAD>
<body bgColor=#ffffff leftMargin=5 topMargin=0 rightMargin=5 marginwidth="5" marginheight="0">
<!-- Begin ////////////// Logo Header ///////////////// -->
<DIV align=center>
<table cellSpacing=0 cellPadding=0 width=608 align=center border=0>
  <tr>
    <td width="100%">
      <table cellSpacing=0 cellPadding=0 width="100%" border=0 
      >
        <tr>
          <td vAlign=center align=left width=468><IMG height=60 alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width=468 border=0 ></td>
          <td vAlign=center align=right width=140><A href="main.aspx" ><IMG height=44 alt="Passport System" src="image\passport.jpg" width=140 border=0 > 
            </A></td></tr></table></td></tr></table></DIV>
<!-- End ////////////// Logo Header ///////////////// -->

<!-- Begin ////////////// Menu ///////////////// -->
<DIV align=center>
<table cellSpacing=0 cellPadding=0 width=608 align=center border=0>
  <tr>
    <td bgColor=#0033cc rowSpan=3>
      <table cellSpacing=0 cellPadding=0 width=1 border=0 
        >
        <tr>
          <td height=21></td></tr></table></td>
    <td bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 width=606 border=0>
        <tr>
          <td height=1></td></tr></table></td>
    <td bgColor=#0033cc rowSpan=3>
      <table cellSpacing=0 cellPadding=0 width=1 border=0 
        >
        <tr>
          <td height=21><FONT face=Tahoma 
            ></FONT></td></tr></table></td></tr>
  <tr>
    <td bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 width="100%" border=0 
      >
        <tr>
          <td width="100%">
            <table cellSpacing=0 cellPadding=0 width="100%" border=0 
            >
              <tr>
                <td bgColor=#ffffff>
                  <table cellSpacing=0 cellPadding=0 width=1 border=0 
                  >
                    <tr>
                      <td height=23 
                ></td></tr></table></td>
                <td vAlign=center align=middle bgColor=#ffffff 
                ><A href="main.aspx" ><font face=verdana,sans-serif 
                  color=#0033cc size=1>˹���á Passport 
                  System</font></A></td>
                <td><font color=#0033cc size=4 
                  >|</font></td>
                <td vAlign=center align=middle><A href="memberservice.aspx" ><font 
                  face=verdana,sans-serif color=#ffffff size=1 
                  >��ԡ����Ҫԡ</font></A></td>
                <td><font color=#ffffff size=4 
                  >|</font></td>
                <td vAlign=center align=middle bgColor=#0033cc 
                ><A href="web_member.aspx"><font 
                  face=verdana,sans-serif color=#ffffff size=1 
                  >������ª���䫷�</font></A></td>
                <td><font color=#ffffff size=4 
                  >|</font></td>
                <td vAlign=center align=middle bgColor=#0033cc 
                ><A href="privilege.aspx" ><font 
                  face=verdana,sans-serif color=#ffffff size=1 
                  >�Է����ǹ�ؤ��</font></A></td>
                <td>
                  <table cellSpacing=0 cellPadding=0 width=1 border=0 
                  >
                    <tr>
                      <td height=19 
                ></td></tr></table></td></tr></table></td>
          <td><font color=#ffffff size=4 
            >|</font></td>
          <td vAlign=center align=middle bgColor=#0033cc>
            <P>
            <form id=Form1 runat="server"><asp:imagebutton id=ImageButton1 runat="server" ImageUrl="image\signin.gif"></asp:imagebutton></P></td></tr></table></td></tr>
  <tr>
    <td bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 width=606 border=0>
        <tr>
          <td height=1></td></tr></table></td></tr></table></DIV>


<!-- End ////////////// Menu ///////////////// -->

<!-- Begin ////////////// Spacer ///////////////// -->
<DIV align=center>
<table cellSpacing=0 cellPadding=0 width=608 align=center border=0>
  <tr>
    <td bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 border=0>
        <tr>
          <td height=15></td></tr></table></td></tr></table></DIV>
<!-- End ////////////// Spacer ///////////////// -->

<!-- Begin ////////////// Content ///////////////// -->
<DIV align=center>
<table cellSpacing=0 cellPadding=0 width=613 align=center border=0>
  <tr>
    <td vAlign=top width=19 bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 width=19 border=0 
        >
        <tr>
          <td bgColor=#ffffff><IMG height=22 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ><IMG height=19 src="image\dblue_tl_19x19.gif" width=19 border=0 ></td></tr>
        <tr>
          <td></td></tr>
        <TR>
          <TD><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></TD></TR></table></td>
    <td vAlign=top width=374>
      <table cellSpacing=0 cellPadding=0 width=374 border=0>
        <tr>
          <td style="WIDTH: 400px" bgColor=#ffffff 
        ></td></tr></table>
      <table cellSpacing=0 cellPadding=0 width=374 border=0>
        <TR>
          <TD style="HEIGHT: 21px" width=17 bgColor=#0033cc 
          ></TD>
          <TD style="HEIGHT: 21px" width=340 bgColor=#0033cc colSpan=2 
          ></TD>
          <TD style="HEIGHT: 21px" width=17 bgColor=#0033cc 
          ></TD></TR>
        <tr>
          <td width=17 rowSpan=12></td>
          <td width=340 bgColor=#ffffff colSpan=2></td>
          <td width=17 rowSpan=12><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=17 border=0 ></td></tr>
        <tr>
          <td bgColor=#ffffff colSpan=2><IMG height=13 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td vAlign=top width=28><IMG height=13 src="/UI/Common/images/big_arrow_8x13.gif" width=8 vspace=3 border=0 ></td>
          <td width=312>�ͧ�һ��� <b 
            >ŧ���������</b>&nbsp; Passport System<br 
            ><IMG alt="������к� Passport System" src="image\signin.gif" vspace=5 border=0 >&nbsp;<br></td>
        <tr>
          <td colSpan=2><IMG height=13 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td colSpan=2><IMG height=13 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td vAlign=top width=28><IMG height=13 src="/UI/Common/images/big_arrow_8x13.gif" width=8 vspace=3 border=0 ></td>
          <td width=312 
            >�红�������ǹ��������������ѵ�&nbsp;Passport 
            System �ͧ�س 
            ����ҡ�س���͡�����觢����Ź������������ѹ���ѵ��ѵ�㹢�з��سŧ��������� 
            ��з����䫷����պ�ԡ�ôѧ������ʹͺ�ԡ�þ���������س��</td></tr>
        <tr>
          <td vAlign=top width=28><IMG height=1 src="/UI/Common/images/TRans1x1.gif" width=8 vspace=3 border=0 ></td></tr>
        <tr>
          <td colSpan=2><IMG height=10 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td width=340 colSpan=2><FONT size=3 
            ><B></B></FONT></td></tr>
        <tr>
          <td colSpan=2><IMG height=20 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td width=340 colSpan=2>
            <table cellSpacing=0 cellPadding=0 width=340 border=0 
            >
              <tr>
                <td width=1 bgColor=#0033cc rowSpan=3 
                  ><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td>
                <td bgColor=#0033cc colSpan=3><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td>
                <td width=1 bgColor=#0033cc rowSpan=3 
                  ><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
              <tr>
                <td vAlign=bottom width=103><IMG height=96 alt=������ʹ��� hspace=0 src="\passport\image\security_lock.gif" width=97 border=0 ></td>
                <td vAlign=top width=227><IMG height=5 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 >&nbsp;<br 
                  > 
<asp:Image id=Image2 runat="server" ImageUrl="image\shop.gif"></asp:Image>&nbsp; 
                  ŧ���������ҡ��������������ͧ㴡������ա�����������Թ������ 
                  �·��������������ѵ�����Ѻ&nbsp;Passport System 
                  �ͧ�س���Ѻ����������ͧ�ҡ෤����մ�ҹ������ʹ��·ҧ�͹�Ź��ѹ�ç����Է���Ҿ 
                  ��� <A href="/Consumer/PrivacyPolicy.asp?lc=1054" ><FONT 
                  color=green 
                  >��º�´�ҹ�Է����ǹ�ؤ���ѹ����Ǵ</FONT></A>�س���ŨѴ��õ�����͡����ǡѺ����觢����Ţͧ�س����������ѹ</td>
                <td><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=8 border=0 ></td></tr>
              <tr>
                <td bgColor=#0033cc colSpan=3><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr></table></td></tr>
        <tr>
          <td colSpan=2><IMG height=20 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=17 border=0 ></td>
          <td colSpan=2><A href="signup.aspx" >ŧ����¹����&nbsp;Passport System 
            �����!</A><br><IMG height=5 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ><br 
            ><A href="privilege.aspx" >���¹��������������ǡѺ&nbsp;Passport 
            System</A></td>
          <td><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=17 border=0 ></td></tr>
        <tr>
          <td width=374 colSpan=4>
            <table cellSpacing=0 cellPadding=0 width="100%" border=0 
            >
              <tr>
                <td><IMG height=29 src="image\whitecurve_bl_29x29.gif" width=29 border=0 ></td>
                <td colSpan=2 &nbsp;></td>
                <td align=right><IMG height=29 src="image\whitecurve_br_29x29.gif" width=29 border=0 ></td></tr></table></td></tr></table></td>
		<!-- END LEFT CONTENT -->
		
		<!-- BEGIN MIDDLE GUTTER -->
    <td vAlign=top width=22 bgColor=#0033cc>
      <TABLE cellSpacing=0 cellPadding=0 width=22 border=0 
        >
        <TR>
          <td vAlign=top bgColor=#ffffff></td></TR>
        <tr>
          <td><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr></TABLE></td><!-- END MIDDLE GUTTER -->
    <td vAlign=top width=179 bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 width=179 bgColor=#ffffff border=0 
      >
        <tr>
          <td vAlign=top bgColor=#ffffff></td></tr>
        <tr>
          <td vAlign=top bgColor=#0033cc><IMG height=22 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
        <tr>
          <td>
						<!-- RIGHT NAV CONTENT -->
            <table cellSpacing=0 cellPadding=0 width=179 border=0 
            >
              <tr>
                <td colSpan=2><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td>
                <td align=right><IMG height=9 src="/UI/Common/images/sharpcurve_tr_9x9.gif" width=9 border=0 ></td></tr>
              <tr>
                <td><IMG height=1 src="" width=9 border=0 
                  ><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td><asp:imagebutton id=ImageButton2 runat="server" ImageUrl="image\register.jpg"></asp:imagebutton></FORM></td>
                <td><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=9 border=0 ></td></tr></table>
            <table cellSpacing=0 cellPadding=0 width="100%" border=0 
            >
              <tr>
                <td rowSpan=12><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=9 border=0 ></td>
                <td colSpan=2 height=40>
                  <P><asp:image id=Image1 runat="server" ImageUrl="image\nav_members_78x14.gif"></asp:image><asp:label id=Label1 runat="server" Font-Bold="True" ForeColor="Magenta" Visible="False">Label</asp:label></P></td>
                <td width=9 rowSpan=12><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=9 border=0 ></td></tr>
              <tr>
                <td vAlign=top width=12></td>
                <TD><asp:hyperlink id=HyperLink1 runat="server" NavigateUrl="forget_pass.aspx">������ʼ�ҹ</asp:hyperlink></TD></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td><asp:hyperlink id=HyperLink2 runat="server" NavigateUrl="change_bio.aspx">����������������ѵԢͧ�س</asp:hyperlink></td></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td><asp:hyperlink id=HyperLink3 runat="server" NavigateUrl="change_pass.aspx">��˹����ʼ�ҹ�ͧ�س����</asp:hyperlink></td></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td><asp:hyperlink id=HyperLink4 runat="server" NavigateUrl="change_secret.aspx">��˹��Ӷ������繤����Ѻ�ͧ�س����</asp:hyperlink></td></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td><asp:hyperlink id=HyperLink5 runat="server" NavigateUrl="del_passport.aspx">�Դ�ѭ�� passport</asp:hyperlink></td></tr>
              <tr>
                <td colSpan=2 height=40><IMG alt=���͡�ä�� src="image\nav_business_99x14.gif" border=0 ></td></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td>
<asp:HyperLink id=HyperLink6 runat="server" NavigateUrl="http://network07.ce.kmitl.ac.th/comprice/main.aspx">�ҤҤ���������</asp:HyperLink><A 
                  href="http://www.microsoft.com/myservices/passport/" 
                  ></A></td></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td>
<asp:HyperLink id=HyperLink7 runat="server" NavigateUrl="asdf">�Ҥ�����</asp:HyperLink></td></tr>
              <tr>
                <td vAlign=top width=12><IMG height=7 hspace=2 src="/UI/Common/images/small_arrow_4x7.gif" width=4 vspace=3 border=0 ></td>
                <td></td></tr>
              <tr>
                <td colSpan=2 height=40></td></tr>
              <tr>
                <td colSpan=2></td></tr>
              <tr>
                <td colSpan=4><IMG height=6 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></td></tr>
              <tr>
                <td vAlign=bottom><IMG height=9 src="/UI/Common/images/sharpcurve_bl_9x9.gif" width=9 border=0 ></td>
                <td colSpan=3></td></tr></table>
						<!-- END RIGHT NAV CONTENT --></td></tr></table></td>
    <td vAlign=top width=19 bgColor=#0033cc>
      <table cellSpacing=0 cellPadding=0 width=19 border=0 
        >
        <tr>
          <td bgColor=#ffffff><IMG height=22 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ><IMG height=19 src="image\dblue_tr_19x19.gif" width=19 border=0 ></td></tr>
        <tr>
          <td></td></tr>
        <TR>
          <TD><IMG height=1 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></TD></TR></table></td></tr>
  <TR>
    <TD bgColor=#0033cc colSpan=5><IMG height=30 src="/UI/Common/images/Trans1x1.gif" width=1 border=0 ></TD></TR></table></DIV>	
	
	
	
	

<!-- End ////////////// Content ///////////////// -->

<!-- Begin ////////////// Footer ///////////////// -->
<DIV align=center>
<table cellSpacing=0 cellPadding=0 width=608 align=center border=0>
  <tr vAlign=top>
    <td align=middle width="100%"><font 
      ><A style="FONT-SIZE: 10pt" href="/Intl/Default.asp?lc=1054" ></A></font></td></tr>
  <tr>
    <td align=middle width="100%"><font 
      >
      <CENTER><FONT color=#006666 
      >Copyright 2002 - 2003, All Rights Reserved.</FONT> 
      </CENTER><A style="FONT-SIZE: 10pt" href="privilege.aspx" >�Ӫ��ᨧ�Է����ǹ�ؤ��</A> 
      |&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx" >˹���á Passport 
      System</A></font></td></tr>
  <tr>
    <td width="100%"></td></tr></table></DIV>
<!-- End   ////////////// Footer ///////////////// -->
<CENTER>&nbsp;</CENTER>
</body>
</HTML>