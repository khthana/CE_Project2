<%@ Page Language="vb" AutoEventWireup="false" Codebehind="del_passport_complete.aspx.vb" Inherits="passport.del_passport_complete"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<!-- Center Area -->
		<P align="center">
		</P>
		<FONT color="#006666">
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD width="100%">
							<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
								<TR>
									<TD vAlign="center" align="left" width="468">
										<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
									</TD>
									<TD vAlign="center" align="right" width="140">
										<A href="main.aspx"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
										</A>
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</P>
			</TABLE>
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TBODY>
						<TR>
							<TD bgColor="#0033cc" rowSpan="3">
								<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
									<TR>
										<TD height="21">
											<STRONG></STRONG>
										</TD>
									</TR>
								</TABLE>
							</TD>
							<TD bgColor="#ffffff">
								<TABLE cellSpacing="0" cellPadding="0" width="606" border="0">
									<TBODY>
										<TR>
											<TD bgColor="#0033cc" height="1">
												<TABLE height="328" cellSpacing="0" cellPadding="3" width="589" border="0">
													<TBODY>
														<TR>
															<TD vAlign="top" align="middle" width="100%"> <!-- Form area -->
																<TABLE class="box1" height="322" cellSpacing="0" cellPadding="0" width="605" bgColor="antiquewhite" border="0">
																	<FORM id="fsign" name="fsign" action="webform8.aspx" method="post" runat="server">
																		<TBODY>
																			<TR>
																				<TD bgColor="#ffffff">
																					<TABLE height="284" width="100%" border="0">
																						<TBODY>
																							<TR>
																								<TD style="WIDTH: 529px" align="left" bgColor="#0033cc" colSpan="2">
																									<STRONG>&nbsp;<FONT color="#ffffff"> &nbsp;</FONT></STRONG><FONT color="#ffffff"><STRONG>
																											<FONT size="4">�ѭ��&nbsp;Passport �١�Դ����� </FONT>
																											<BR>
																										</STRONG></FONT>
																								</TD>
																							</TR>
																							<TR>
																								<TD align="left" bgColor="#ffffff" colSpan="2">
																									<P align="center">
																										�س��Դ�ѭ�� Passport �ѹ������������
																									</P>
																									<P align="center">
																										<STRONG></STRONG>
																									</P>
																									<STRONG></STRONG>
																									<P align="center">
																										<asp:label id="Label1" runat="server" ForeColor="Red" Font-Size="Medium">Label</asp:label>
																									</P>
																								</TD>
																							</TR>
																							<FONT color="#ffffff"><STRONG><FONT color="#0033cc"></FONT></STRONG>
																								<P align="center">
																								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>
																							<P>
																							</P>
																							<P>
																							</P>
																							<P>
																							</P>
																							<P>
																							</P>
																							<P align="center">
																							</P>
																							<P>
																							</P>
																							<TR>
																								<TD align="left" bgColor="#ffffff" colSpan="2">
																									<P align="center">
																										<asp:button id="Button1" runat="server" Text="�������"></asp:button>
																									</P>
																								</TD>
																							</TR>
																							<TR>
																								<TD style="WIDTH: 258px">
																									<P align="left">
																									</P>
																								</TD>
																							</TR>
																							<TR>
																								<TD style="WIDTH: 258px" align="middle">
																									<P align="center">
																									</P>
																								</TD>
																							</TR>
			</P>
			</TBODY></TABLE></TD></TR></FORM></TBODY></TABLE> <!-- End Form Area --> 
			</TD></TR> <!-- Copyright Bar --> 
			</TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
			<TD bgColor="#0033cc" rowSpan="3">
				<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
					<TR>
						<TD height="21">
						</TD>
					</TR>
				</TABLE>
			</TD>
			</TR></TBODY></TABLE></P></FONT>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">
			<A style="FONT-SIZE: 10pt" href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A> |&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx">˹���á 
				Passport System</A>
		</P>
	</body>
</HTML>
