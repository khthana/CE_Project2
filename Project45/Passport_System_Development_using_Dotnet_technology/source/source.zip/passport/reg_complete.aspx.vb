Imports System.Data
Imports Encryption
Imports System.text
Public Class reg_complete
    Inherits System.Web.UI.Page
    Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Datagrid2 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents P1 As System.Web.UI.HtmlControls.HtmlGenericControl
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Imagebutton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents text1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
            Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim IV() As Byte = Encoding.ASCII.GetBytes("init vec")
    Dim Key() As Byte = Encoding.ASCII.GetBytes("password")



    Public Function encrypt(ByVal pt As String) As String
        Dim plainText() As Byte = Encoding.ASCII.GetBytes(pt)
        Dim algorithmID As EncryptionAlgorithm
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim enc As Encryptor = New Encryptor(EncryptionAlgorithm.Des)
        Dim cipherText() As Byte = Nothing
        Dim ct As String
        enc.IV = IV
        cipherText = enc.Encrypt(plainText, Key)
        IV = enc.IV
        Key = enc.Key
        ct = Convert.ToBase64String(cipherText)

        Return ct
    End Function
    Public Function decrypt(ByVal ct As String) As String
        Try

        Dim cipherText() As Byte = Convert.FromBase64String(ct)
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim dec As Decryptor = New Decryptor(algorithm)
        Dim plainText() As Byte = Nothing
        Dim pt As String
        dec.IV = IV
        ' Go ahead and decrypt.
        plainText = dec.Decrypt(cipherText, Key)
        pt = Encoding.ASCII.GetString(plainText)
        ' Look at your plain text.
            Return pt

        Catch
            Response.Redirect("reg_error.aspx")

        End Try

    End Function

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Label1.Text = decrypt(Request.QueryString("e"))


    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click

        Response.Redirect("login.aspx?url=" & Session("url"))


    End Sub
End Class
