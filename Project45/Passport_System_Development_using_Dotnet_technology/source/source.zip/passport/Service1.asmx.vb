Imports System.Web.Services
Imports System.Data
Imports System.Data.SqlClient
Imports System
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
    End Sub

#End Region

    ' WEB SERVICE EXAMPLE
    ' The HelloWorld() example service returns the string Hello World.
    ' To build, uncomment the following lines then save and build the project.
    ' To test this web service, ensure that the .asmx file is the start page
    ' and press F5.
    '

    <WebMethod()> Public Function getName(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("name").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getSurname(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("surname").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getCountry(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("country").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getAddress(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("address").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function

    <WebMethod()> Public Function getProvince(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("province").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getZipcode(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("zipcode").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getTimezone(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("timezone").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getSex(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("sex").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getBirthday(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("birhtday").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getJob(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from biography where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("job").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getLogin(ByVal Email As String, ByVal Password As String) As Boolean
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            Return True
        Else
            Return False
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function Login(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        Dim myCommand As SqlCommand
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "update member set status = '1' where email = '" & Email & "'"
            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()
            Return "login complete"
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function Logout(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        Dim myCommand As SqlCommand
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "update member set status = '0' where email = '" & Email & "'"
            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()
            Return "logout complete"
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function

    <WebMethod()> Public Function getQ_secret(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from secret where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("q_secret").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function
    <WebMethod()> Public Function getA_secret(ByVal Email As String, ByVal Password As String) As String
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String = "server=localhost;database=passport;Trusted_Connection=yes"
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String
        mySelectQuery = "select * from member where email = '" & Email & "' and password = '" & Password & "'"
        myConnection = New SqlConnection(myConnstring)
        objCmd = New SqlCommand(mySelectQuery, myConnection)
        myConnection.Open()
        objdataReader = objCmd.ExecuteReader()
        If objdataReader.Read() Then
            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "select * from secret where email='" & Email & "'"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            Dim mydataRow As DataRow
            Dim t As String
            Dim n As Integer
            For Each mydataRow In dtSet.Tables(0).Rows
                Return mydataRow("a_secret").ToString()
            Next
        Else
            Return "Sorry,not found"
        End If
        objdataReader.Close()
    End Function

End Class

