Imports System.web
Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.text


    Public Class logout
        Inherits System.Web.UI.Page
        Protected WithEvents Label1 As System.Web.UI.WebControls.Label
        Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
        Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
        Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
        Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

        'This call is required by the Web Form Designer.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

        End Sub

        Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
            'CODEGEN: This method call is required by the Web Form Designer
            'Do not modify it using the code editor.
            InitializeComponent()
        End Sub

#End Region

        Dim IV() As Byte = Encoding.ASCII.GetBytes("init vec")
        Dim Key() As Byte = Encoding.ASCII.GetBytes("password")
        Dim email As String

        Public Function encrypt(ByVal pt As String) As String
            Dim plainText() As Byte = Encoding.ASCII.GetBytes(pt)
            Dim algorithmID As EncryptionAlgorithm
            Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
            Dim enc As Encryptor = New Encryptor(EncryptionAlgorithm.Des)
            Dim cipherText() As Byte = Nothing
            Dim ct As String
            enc.IV = IV
            cipherText = enc.Encrypt(plainText, Key)
            IV = enc.IV
            Key = enc.Key
            ct = Convert.ToBase64String(cipherText)

            Return ct
        End Function
        Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
            'Put user code to initialize the page here
            Dim objdataReader As SqlDataReader
            Dim myConnection As SqlConnection
            Dim objCmd As SqlCommand
            Dim myConnstring As String
            Dim valReturn As String
            Dim check As String
            Dim mySelectQuery As String
            Dim myCommand As SqlCommand

            myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnstring)
            myConnection.Open()
            mySelectQuery = "update member set status = '0' where email = '" & Request.Cookies("passport").Value & "'"
            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()

            Label1.Text = Request.Cookies("passport").Value
            Response.Cookies("passport").Value = "logoutted"
            Response.Cookies("passport").Expires = Now.AddDays(1)
            Response.Cookies("passport").Path = "/passport"
            Response.Cookies("passport").Secure = False

        Session("url") = Request.QueryString("url")


        End Sub

        Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Response.Redirect(Session("url") & "?o=" & encrypt("logoutted"))
        End Sub
    End Class
