Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.text
Imports System.web
Public Class main
    Inherits System.Web.UI.Page
    Protected WithEvents Image2 As System.Web.UI.WebControls.Image
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
        Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents online As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink4 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink5 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink6 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents HyperLink7 As System.Web.UI.WebControls.HyperLink
                        Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim login As Boolean

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        'Dim temp As String
        Label1.Visible = False
        Try
            Dim MyCookie As HttpCookie
            MyCookie = Request.Cookies("passport")

            If MyCookie.Value = "logoutted" Then
                ImageButton1.ImageUrl = "image\signin.GIF"
                HyperLink2.Enabled = False
                HyperLink2.NavigateUrl = ""
                HyperLink3.Enabled = False
                HyperLink3.NavigateUrl = ""
                HyperLink4.Enabled = False
                HyperLink4.NavigateUrl = ""
                HyperLink5.Enabled = False
                HyperLink5.NavigateUrl = ""

                login = False
            Else
                ImageButton1.ImageUrl = "image\signout.GIF"
                HyperLink2.Enabled = True
                HyperLink2.NavigateUrl = "change_bio.aspx"
                HyperLink3.Enabled = True
                HyperLink3.NavigateUrl = "change_pass.aspx"
                HyperLink4.Enabled = True
                HyperLink4.NavigateUrl = "change_secret.aspx"
                HyperLink5.Enabled = True
                HyperLink5.NavigateUrl = "del_passport.aspx"

                Label1.Text = MyCookie.Value
                Label1.Visible = True
                login = True
            End If
        Catch
            ImageButton1.ImageUrl = "image\signin.GIF"
            HyperLink2.Enabled = False
            HyperLink2.NavigateUrl = ""
            HyperLink3.Enabled = False
            HyperLink3.NavigateUrl = ""
            HyperLink4.Enabled = False
            HyperLink4.NavigateUrl = ""
            HyperLink5.Enabled = False
            HyperLink5.NavigateUrl = ""
            login = False
        End Try

    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        If login = True Then
            Response.Redirect("logout.aspx")
        Else
            Response.Redirect("login.aspx")
        End If


    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Session("id") = 1
        Response.Redirect("signup.aspx")


    End Sub

End Class
