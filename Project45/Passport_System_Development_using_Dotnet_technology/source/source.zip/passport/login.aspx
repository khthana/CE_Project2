<%@ Page Language="vb" AutoEventWireup="false" Codebehind="login.aspx.vb" Inherits="passport.login"%>
<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
		<!-- Center Area -->
		<P align="center">
			<FONT color="#006666">
				<TABLE height="83" cellSpacing="0" cellPadding="0" width="611" border="0">
					<TR>
						<TD width="100%">
							<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
								<TR>
									<TD vAlign="center" align="left" width="468">
										<P align="left">
											<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
										</P>
									</TD>
									<TD vAlign="center" align="right" width="140">
										<A href="main.aspx"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
										</A>
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE> <!-- End ////////////// Logo Header ///////////////// --> <!-- Begin ////////////// Menu ///////////////// -->
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD bgColor="#0033cc" rowSpan="3">
							<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
								<TR>
									<TD height="21">
									</TD>
								</TR>
							</TABLE>
						</TD>
						<TD bgColor="#ffffff">
							<TABLE cellSpacing="0" cellPadding="0" width="606" border="0">
								<TR>
									<TD bgColor="#0033cc" height="1">
										<TABLE height="265" cellSpacing="0" cellPadding="3" width="466" border="0">
											<TR>
												<TD vAlign="top" align="middle" width="100%"> <!-- Form area -->
													<TABLE class="box1" height="100%" cellSpacing="0" cellPadding="0" width="100%" bgColor="antiquewhite" border="0">
														<FORM id="fsign" name="fsign" action="webform8.aspx" method="post" runat="server">
															<TBODY>
																<TR>
																	<TD bgColor="#ffffff">
																		<TABLE height="227" border="0">
																			<TR>
																				<TD align="left" colSpan="2">
																					<FONT size="+1"><B>Sign in</B></FONT>
																				</TD>
																			</TR>
																			<TR>
																				<TD>
																					�������������
																				</TD>
																				<TD>
																					<asp:textbox id="email" runat="server"></asp:textbox>
																					<asp:regularexpressionvalidator id="CheckEmail2" runat="server" ErrorMessage="<br>E-mail Address not Completed" ControlToValidate="email" Display="Dynamic" ValidationExpression="\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"></asp:regularexpressionvalidator>
																					<FONT color="red">
																						<asp:label id="Label1" runat="server" visible="false"></asp:label>
																					</FONT>
																				</TD>
																			</TR>
																			<TR>
																				<TD>
																					���ʼ�ҹ
																				</TD>
																				<TD>
																					<asp:textbox id="password1" runat="server" MaxLength="10" TextMode="Password"></asp:textbox>
																					<FONT color="red">
																						<asp:label id="Label2" runat="server" visible="false"></asp:label>
																					</FONT>
																				</TD>
																			</TR>
																			&nbsp;
																			<TR>
																				<TD>
																				</TD>
																				<TD>
																					<P> <!--<INPUT type="checkbox" id=rem name=rem> �����ʼ�ҹ���-->
																					</P>
																					<P>
																						<FONT color="red">
																							<asp:label id="Label3" runat="server" visible="false"></asp:label>
																						</FONT>
																						<BR>
																						������ʼ�ҹ��ԡ<A href="forget_pass.aspx"><FONT color="green">�����</FONT></A>&nbsp;&nbsp;&nbsp;&nbsp; 
																						&nbsp;
																						<asp:imagebutton id="ImageButton1" runat="server" ImageUrl="image\button_login_blue.GIF" AlternateText="Login �������к�"></asp:imagebutton>
																					</P>
																				</TD>
																			</TR>
																			<TR>
																				<TD align="middle" colSpan="2">
																				</TD>
																			</TR>
																			<TR>
																				<TD align="left" colSpan="2">
																				</TD>
																			</TR>
																			<TR>
																				<TD align="left" colSpan="2">
																					����Ѻ������ѧ�����ŧ����¹����Ҫԡ����&nbsp; <A href="register1.aspx"></A>
																					&nbsp;
																					<asp:imagebutton id="ImageButton2" runat="server" ImageUrl="image\register.jpg"></asp:imagebutton>
																					������Ѥ�����Ҫԡ
																				</TD>
																			</TR>
																		</TABLE>
																	</TD>
																</TR>
														</FORM>
													</TABLE> <!-- End Form Area -->
												</TD>
											</TR> <!-- Copyright Bar -->
										</TABLE>
									</TD>
								</TR>
							</TABLE>
						</TD>
						<TD bgColor="#0033cc" rowSpan="3">
							<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
								<TR>
									<TD height="21">
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
					</TBODY>
				</TABLE>
			</FONT>
		</P>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">
			&nbsp; <A style="FONT-SIZE: 10pt" href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A>
			|&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx">˹���á Passport </A>
		</P>
	</body>
</HTML>
