Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.text
Imports System.web
Public Class login
    Inherits System.Web.UI.Page
    Protected WithEvents email As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents password1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton3 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Button3 As System.Web.UI.WebControls.Button
    Protected WithEvents Button4 As System.Web.UI.WebControls.Button
    Protected WithEvents CheckEmail2 As System.Web.UI.WebControls.RegularExpressionValidator
        Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim myAdapter As SqlDataAdapter
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Dim recordAffected As Integer
    Dim IV() As Byte = Encoding.ASCII.GetBytes("init vec")
    Dim Key() As Byte = Encoding.ASCII.GetBytes("password")
    Public Function encrypt(ByVal pt As String) As String
        Dim plainText() As Byte = Encoding.ASCII.GetBytes(pt)
        Dim algorithmID As EncryptionAlgorithm
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim enc As Encryptor = New Encryptor(EncryptionAlgorithm.Des)
        Dim cipherText() As Byte = Nothing
        Dim ct As String
        enc.IV = IV
        cipherText = enc.Encrypt(plainText, Key)
        IV = enc.IV
        Key = enc.Key
        ct = Convert.ToBase64String(cipherText)

        Return ct
    End Function
    Public Function decrypt(ByVal ct As String) As String
        Dim cipherText() As Byte = Convert.FromBase64String(ct)
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim dec As Decryptor = New Decryptor(algorithm)
        Dim plainText() As Byte = Nothing
        Dim pt As String
        dec.IV = IV
        ' Go ahead and decrypt.
        plainText = dec.Decrypt(cipherText, Key)
        pt = Encoding.ASCII.GetString(plainText)
        ' Look at your plain text.
        Return pt
    End Function

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        
        If Request.QueryString("url") = Nothing Then
            Session("url") = "main.aspx"
        Else
            Session("url") = Request.QueryString("url")
        End If



    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        Try


            Dim em As String = email.Text
            Dim p1 As String = password1.Text
            Label1.Visible = "false"
            Label2.Visible = "false"
            Label3.Visible = "false"

            If em <> "" And p1 <> "" Then

                Dim dtCmd As SqlDataAdapter
                Dim dtSet As New DataSet()
                Dim myConnString As String

                myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
                myConnection = New SqlConnection(myConnString)
                myConnection.Open()
                mySelectQuery = "SELECT * from member where email = '" & email.Text & "' and password='" & password1.Text & "' "
                dtCmd = New SqlDataAdapter(mySelectQuery, myConnection)
                dtCmd.Fill(dtSet)

                If dtSet.Tables(0).Rows.Count = 1 Then

                    myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
                    myConnection = New SqlConnection(myConnString)
                    myConnection.Open()
                    mySelectQuery = "update member set status = '0' where email = '" & email.Text & "'"
                    myCommand = New SqlCommand(mySelectQuery, myConnection)
                    myCommand.ExecuteNonQuery()

                    Response.Cookies("passport").Value = email.Text
                    Response.Cookies("passport").Expires = Now.AddDays(1)
                    Response.Cookies("passport").Path = "/passport"
                    Response.Cookies("passport").Secure = False

                    'Response.Cookies("passport").Value = email.Text
                    'Response.Cookies("passport").Expires = Now.AddDays(1)
                    'Response.Cookies("passport").Path = "/comprice"
                    'Response.Cookies("passport").Secure = False

                    Response.Redirect("login_complete.aspx")
                Else
                    Label3.Text = "email ���� password ����͡���١��ͧ ��سҡ�͡�����ա���� !"
                    Label3.Visible = "true"
                End If

            Else
                If em = "" Then
                    Label1.Text = "�س������͡ Email !"
                    Label1.Visible = "true"
                End If
                If p1 = "" Then
                    Label2.Text = "�س������͡ Password !"
                    Label2.Visible = "true"
                End If


            End If
        Catch
            Response.Redirect("login_error.aspx")
        End Try
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click

    End Sub

    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        Response.Redirect("signup.aspx")
    End Sub
End Class
