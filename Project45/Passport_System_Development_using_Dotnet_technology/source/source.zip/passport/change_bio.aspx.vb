Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.Text
Imports System.web
Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents submit1 As System.Web.UI.WebControls.Button
    Protected WithEvents Occupation As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents dobyear As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dobmonth As System.Web.UI.WebControls.DropDownList
    Protected WithEvents dobdate As System.Web.UI.WebControls.DropDownList
    Protected WithEvents sex2 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents sex1 As System.Web.UI.WebControls.RadioButton
    Protected WithEvents sex As System.Web.UI.WebControls.TextBox
    Protected WithEvents country As System.Web.UI.WebControls.DropDownList
    Protected WithEvents zone As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Zip As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents city As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents sername As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents name As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents address As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
            Protected WithEvents form1 As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Dim myConnString As String


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Put user code to initialize the page here

        Label1.Text = Request.Cookies("passport").Value
        myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
        myConnection = New SqlConnection(myConnString)
        myConnection.Open()
        mySelectQuery = "select * from biography where email='" & Request.Cookies("passport").Value & "'"
        Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
        Dim dtSet As New DataSet()

        mysqlDataAdater.Fill(dtSet)

        Dim mydataRow As DataRow
        Dim t As String
        Dim n As Integer
        'Me.ListBox1.Items.Clear()
        'Me.TextBox1.Clear()
        For Each mydataRow In dtSet.Tables(0).Rows

            name.Text = mydataRow("name").ToString()
            sername.Text = mydataRow("surname").ToString()
            address.Text = mydataRow("address").ToString()
            city.Text = mydataRow("province").ToString()
            Zip.Text = mydataRow("zipcode").ToString()

            t = mydataRow("timezone").ToString()                 'timezone
            n = 1
            Do While zone.SelectedItem.Text <> t
                zone.SelectedIndex = n
                n += 1
            Loop

            t = mydataRow("country").ToString()                 'country
            n = 1
            Do While country.SelectedItem.Text <> t
                country.SelectedIndex = n
                n += 1
            Loop

            If mydataRow("country").ToString() = "���" Then
                sex1.Checked() = True
            ElseIf mydataRow("country").ToString() = "˭ԧ" Then
                sex2.Checked() = True
            End If



            Dim t_tmp As DateTime = mydataRow("birthday").ToString()
            If t_tmp.Month = "1" Then                   'month
                t = "���Ҥ�"
            ElseIf t_tmp.Month = "2" Then
                t = "����Ҿѹ��"
            ElseIf t_tmp.Month = "3" Then
                t = "�չҤ�"
            ElseIf t_tmp.Month = "4" Then
                t = "����¹"
            ElseIf t_tmp.Month = "5" Then
                t = "����Ҥ�"
            ElseIf t_tmp.Month = "6" Then
                t = "�Զع�¹"
            ElseIf t_tmp.Month = "7" Then
                t = "�á�Ҥ�"
            ElseIf t_tmp.Month = "8" Then
                t = "�ԧ�Ҥ�"
            ElseIf t_tmp.Month = "9" Then
                t = "�ѹ��¹"
            ElseIf t_tmp.Month = "10" Then
                t = "���Ҥ�"
            ElseIf t_tmp.Month = "11" Then
                t = "��Ȩԡ�¹"
            ElseIf t_tmp.Month = "12" Then
                t = "�ѹ�Ҥ�"
            End If
            n = 1
            Do While dobmonth.SelectedItem.Text <> t
                dobmonth.SelectedIndex = n
                n += 1
            Loop
            t = t_tmp.Day                                   'day
            n = 1
            Do While dobdate.SelectedItem.Text <> t
                dobdate.SelectedIndex = n
                n += 1
            Loop
            t = t_tmp.Year                                  'year
            n = 1
            Do While dobyear.SelectedItem.Text <> t
                dobyear.SelectedIndex = n
                n += 1
            Loop

            t = mydataRow("job").ToString()                 'job
            n = 1
            Do While Occupation.SelectedItem.Text <> t
                Occupation.SelectedIndex = n
                n += 1
            Loop
        Next

    End Sub


    Private Sub submit1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles submit1.Click
        Label5.Visible = "false"
        Label6.Visible = "false"
        Label7.Visible = "false"
        Label4.Visible = "false"
        Label8.Visible = False
        Label2.Visible = False

        If name.Text <> "" And sername.Text <> "" And city.Text <> "" And Zip.Text <> "" And dobdate.SelectedItem.Text <> "none" And dobmonth.SelectedItem.Text <> "none" And dobyear.SelectedItem.Text <> "none" Then

            myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnString)
            myConnection.Open()

            If sex1.Checked Then
                sex.Text = sex1.Text
            ElseIf sex2.Checked Then
                sex.Text = sex2.Text
            End If
            If dobmonth.SelectedItem.Value = "0" Then
                If dobmonth.SelectedItem.Text = "���Ҥ�" Then
                    dobmonth.SelectedItem.Value = "1"
                ElseIf dobmonth.SelectedItem.Text = "����Ҿѹ��" Then
                    dobmonth.SelectedItem.Value = "2"
                ElseIf dobmonth.SelectedItem.Text = "�չҤ�" Then
                    dobmonth.SelectedItem.Value = "3"
                ElseIf dobmonth.SelectedItem.Text = "����¹" Then
                    dobmonth.SelectedItem.Value = "4"
                ElseIf dobmonth.SelectedItem.Text = "����Ҥ�" Then
                    dobmonth.SelectedItem.Value = "5"
                ElseIf dobmonth.SelectedItem.Text = "�Զع�¹" Then
                    dobmonth.SelectedItem.Value = "6"
                ElseIf dobmonth.SelectedItem.Text = "�á�Ҥ�" Then
                    dobmonth.SelectedItem.Value = "7"
                ElseIf dobmonth.SelectedItem.Text = "�ԧ�Ҥ�" Then
                    dobmonth.SelectedItem.Value = "8"
                ElseIf dobmonth.SelectedItem.Text = "�ѹ��¹" Then
                    dobmonth.SelectedItem.Value = "9"
                ElseIf dobmonth.SelectedItem.Text = "���Ҥ�" Then
                    dobmonth.SelectedItem.Value = "10"
                ElseIf dobmonth.SelectedItem.Text = "��Ȩԡ�¹" Then
                    dobmonth.SelectedItem.Value = "11"
                ElseIf dobmonth.SelectedItem.Text = "�ѹ�Ҥ�" Then
                    dobmonth.SelectedItem.Value = "12"
                End If
            End If

            mySelectQuery = "update biography " & _
            " set name = '" & name.Text & "'," & _
            " surname =  '" & sername.Text & "'," & _
            " address =  '" & address.Text & "'," & _
            " province = '" & city.Text & "'," & _
            " zipcode = '" & Zip.Text & "'," & _
            " country = '" & country.SelectedItem.Text & "'," & _
            " timezone = '" & zone.SelectedItem.Text & "'," & _
            " sex = '" & sex.Text & "'," & _
            " birthday = '" & dobmonth.SelectedItem.Value & "/" & dobdate.SelectedItem.Text & "/" & dobyear.SelectedItem.Text & "'," & _
            " job = '" & Occupation.SelectedItem.Text & "'" & _
            " where email = '" & Request.Cookies("passport").Value & "'"


            myCommand = New SqlCommand(mySelectQuery, myConnection)
            myCommand.ExecuteNonQuery()

            Response.Redirect("change_bio_complete.aspx")

        Else
            If name.Text = "" Then
                Label5.Text = "�س������͡ ���� !"
                Label5.Visible = "true"
            End If
            If sername.Text = "" Then
                Label6.Text = "�س������͡ ���ʡ�� !"
                Label6.Visible = "true"
            End If
            If city.Text = "" Then
                Label7.Text = "�س������͡ �ѧ��Ѵ !"
                Label7.Visible = "true"
            End If
            If Zip.Text = "" Then
                Label4.Text = "�س������͡ ������ɳ��� !"
                Label4.Visible = "true"
            End If
            If dobdate.SelectedItem.Text = "none" Or dobmonth.SelectedItem.Text = "none" Or dobyear.SelectedItem.Text = "none" Then
                Label8.Text = "�ѹ��͹���Դ�ͧ�س�������ó� !"
                Label8.Visible = "true"
            End If




        End If

    End Sub

End Class
