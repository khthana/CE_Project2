<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Page Language="vb" AutoEventWireup="false" Codebehind="login_complete.aspx.vb" Inherits="passport.login_complete"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
		<!-- Center Area -->
		<P align="center">
		</P>
		<FONT color="#006666">
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD width="100%">
							<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
								<TR>
									<TD vAlign="center" align="left" width="468">
										<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
									</TD>
									<TD vAlign="center" align="right" width="140">
										<A href="main.aspx"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
										</A>
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</P>
			<P align="center">
				<TABLE class="box1" height="220" cellSpacing="0" cellPadding="0" width="606" bgColor="antiquewhite" border="2">
					<FORM id="Form1" name="fsign" action="webform8.aspx" method="post" runat="server">
						<TBODY>
							<TR>
								<TD bgColor="#ffffff">
									<TABLE height="174" width="599" border="0">
										<TBODY>
											<TR>
												<TD style="WIDTH: 529px" align="left" bgColor="#0033cc" colSpan="2">
													<STRONG>&nbsp;</STRONG><FONT color="#ffffff"><STRONG>&nbsp;</STRONG> <STRONG>�������к��� 
															: </STRONG>
														<asp:label id="Label1" runat="server" ForeColor="#C0FFC0" Font-Bold="True">Label</asp:label>
													</FONT><FONT color="#ffffff"></STRONG></FONT>
												</TD>
											</TR>
											<TR>
												<TD align="left" bgColor="#ffffff" colSpan="2">
													<P align="center">
														<FONT color="#3366cc">&nbsp;</FONT><FONT class="PPErrBoldTxt" color="#3399ff" size="4">��й�����ҹ���������к� 
															Passport ����</FONT>
													</P>
													<P align="center">
														<STRONG></STRONG>
													</P>
													<STRONG></STRONG>
													<P align="center">
														&nbsp;
														<asp:Image id="Image1" runat="server" ImageUrl="image\join_interesting.gif"></asp:Image>
														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
														<asp:button id="Button1" runat="server" Text="���Թ��õ��"></asp:button>
													</P>
												</TD>
											</TR>
											<FONT color="#ffffff"><STRONG><FONT color="#0033cc"></FONT></STRONG>
												<P align="center">
												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P align="center">
											</P>
											<P>
											</P>
											<P align="center">
											</P>
											<P>
											</P>
											<P align="center">
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
			</P>
			</TBODY></TABLE></TD></TR></FORM></TBODY></TABLE></P></FONT>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">
			<A style="FONT-SIZE: 10pt" href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A> |&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx">˹���á 
				Passport System</A>
		</P>
	</body>
</HTML>
