<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>
<%@ Page Language="vb" AutoEventWireup="false" Codebehind="memberservice.aspx.vb" Inherits="passport.memberservice"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<!-- Center Area -->
		<P align="center">
		</P>
		<FONT color="#006666">
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD width="100%" bgColor="#ffffff">
							<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
								<TR>
									<TD vAlign="center" align="left" width="468">
										<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
									</TD>
									<TD vAlign="center" align="right" width="140">
										<A href="/Consumer/Default.asp?lc=1054"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
										</A>
									</TD>
								</TR>
							</TABLE>
							<TABLE cellSpacing="0" cellPadding="0" width="608" align="center" border="0">
								<TR>
									<TD bgColor="#0033cc" rowSpan="3">
										<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
											<TR>
												<TD height="21">
												</TD>
											</TR>
										</TABLE>
									</TD>
									<TD bgColor="#0033cc">
										<TABLE cellSpacing="0" cellPadding="0" width="606" border="0">
											<TR>
												<TD height="1">
												</TD>
											</TR>
										</TABLE>
									</TD>
									<TD bgColor="#0033cc" rowSpan="3">
										<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
											<TR>
												<TD height="21">
													<FONT face="Tahoma"></FONT>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
									<TD bgColor="#0033cc">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR>
												<TD width="100%">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD bgColor="#ffffff">
																<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
																	<TR>
																		<TD height="23">
																		</TD>
																	</TR>
																</TABLE>
															</TD>
															<TD vAlign="center" align="middle" bgColor="#0033cc">
																<A href="main.aspx"><FONT face="verdana,sans-serif" color="#ffffff" size="1">˹���á 
																		Passport System</FONT></A>
															</TD>
															<TD>
																<FONT color="#ffffff" size="4">|</FONT>
															</TD>
															<TD vAlign="center" align="middle" bgColor="#ffffff">
																<A href="memberservice.aspx"><FONT face="verdana,sans-serif" color="#0033cc" size="1">��ԡ����Ҫԡ</FONT></A>
															</TD>
															<TD>
																<FONT color="#ffffff" size="4">|</FONT>
															</TD>
															<TD vAlign="center" align="middle" bgColor="#0033cc">
																<A href="web_member.aspx"><FONT face="verdana,sans-serif" color="#ffffff" size="1">������ª���䫷�</FONT></A>
															</TD>
															<TD>
																<FONT color="#ffffff" size="4">|</FONT>
															</TD>
															<TD vAlign="center" align="middle" bgColor="#0033cc">
																<A href="privilege.aspx"><FONT face="verdana,sans-serif" color="#ffffff" size="1">�Է����ǹ�ؤ��</FONT></A>
															</TD>
															<TD>
																<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
																	<TR>
																		<TD height="19">
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD>
													<FONT color="#ffffff" size="4">|</FONT>
												</TD>
												<TD vAlign="center" align="middle" bgColor="#0033cc">
													<P>
														<FORM id="Form1" runat="server">
															<asp:imagebutton id="ImageButton1" runat="server" ImageUrl="image\signin.gif"></asp:imagebutton>
													</P>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
									<TD bgColor="#0033cc">
										<TABLE cellSpacing="0" cellPadding="0" width="606" border="0">
											<TR>
												<TD height="1">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
							</TABLE>
							</FORM>
						</TD>
					</TR>
				</TABLE>
			</P>
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD bgColor="#0033cc" rowSpan="3">
							<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
								<TR>
									<TD height="21">
									</TD>
								</TR>
							</TABLE>
						</TD>
						<TD bgColor="#ffffff">
							<TABLE cellSpacing="0" cellPadding="0" width="606" border="0">
								<TR>
									<TD bgColor="#0033cc" height="1">
										<TABLE height="328" cellSpacing="0" cellPadding="3" width="589" border="0">
											<TR>
												<TD vAlign="top" align="middle" width="100%"> <!-- Form area -->
													<TABLE class="box1" height="322" cellSpacing="0" cellPadding="0" width="605" bgColor="antiquewhite" border="0">
														<TBODY>
															<TR>
																<TD bgColor="#ffffff">
																	<TABLE height="284" width="100%" border="0">
																		<TR>
																			<TD align="left" bgColor="#0033cc" colSpan="2">
																				<FONT color="#ffffff">��ǹ��ԡ����Ҫԡ�ͧ Passport System</FONT> <FONT color="#ffffff">
																					�ͧ�س</FONT>
																				<asp:label id="Label1" runat="server" ForeColor="White" Font-Bold="True">Label</asp:label>
																			</TD>
																		</TR>
																		<TR>
																			<TD style="WIDTH: 289px" align="left" bgColor="lightgrey">
																				<STRONG>��ͧ�������¹�ŧ�ҧ���</STRONG>
																			</TD>
																			<TD align="left" bgColor="lightgrey" colSpan="2">
																				<STRONG>��ͧ��ê�������ͺҧ���</STRONG>
																			</TD>
																		</TR>
																		<TR>
																			<TD style="WIDTH: 289px">
																				<P align="justify">
																					<U>
																						<asp:hyperlink id="HyperLink1" runat="server" NavigateUrl="change_bio.aspx">����������ѵ� Passport</asp:hyperlink>
																					</U>
																				</P>
																			</TD>
																			<TD>
																				<P align="justify">
																					<U>
																						<asp:hyperlink id="HyperLink6" runat="server" NavigateUrl="forget_pass.aspx">������ʼ�ҹ</asp:hyperlink>
																					</U>
																				</P>
																			</TD>
																		</TR>
																		<TR>
																			<TD style="WIDTH: 289px">
																				<asp:hyperlink id="HyperLink2" runat="server" NavigateUrl="change_secret.aspx">����¹�Ӷ������繤����Ѻ</asp:hyperlink>
																			</TD>
																			<TD align="left" bgColor="lightgrey" colSpan="2">
																				<STRONG>��ͧ��÷�Һ��������´�������</STRONG>
																			</TD>
																		</TR>
																		<p>
																			<FONT color="#ffffff"><STRONG><FONT color="#0033cc"></FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>
																			<TR>
																				<TD style="WIDTH: 289px">
																					<asp:hyperlink id="HyperLink3" runat="server" NavigateUrl="change_pass.aspx">����¹���ʼ�ҹ</asp:hyperlink>
																				</TD>
																				<TD>
																					<P> <!--<INPUT type="checkbox" id=rem name=rem> �����ʼ�ҹ���-->
																					</P>
																					<P align="justify">
																						<asp:hyperlink id="HyperLink5" runat="server">�Ӷ���ӵͺ�ͧ�������ǡѺ Passport </asp:hyperlink>
																					</P>
																				</TD>
																			</TR>
																			<TR>
																				<TD align="middle" colSpan="2">
																					<P align="left">
																						<asp:hyperlink id="HyperLink4" runat="server" NavigateUrl="del_passport.aspx">�Դ�ѭ�� Passport �ͧ�س</asp:hyperlink>
																					</P>
																				</TD>
																			</TR>
																			<TR>
																				<TD style="HEIGHT: 22px" align="left" colSpan="2">
																					<P>
																					</P>
																				</TD>
																			</TR>
																			<TR>
																				<TD align="left" colSpan="2">
																				</TD>
																			</TR>
																		</p>
																	</TABLE>
																</TD>
															</TR>
														</TBODY>
													</TABLE> <!-- End Form Area -->
												</TD>
											</TR> <!-- Copyright Bar -->
										</TABLE>
									</TD>
								</TR>
							</TABLE>
						</TD>
						<TD bgColor="#0033cc" rowSpan="3">
							<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
								<TR>
									<TD height="21">
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</P>
		</FONT>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">
			<A style="FONT-SIZE: 10pt" href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A> |&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx">˹���á 
				Passport System</A>
		</P>
	</body>
</HTML>
