Imports System.Web.Services
Imports System.Web.Mail
Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.Text
Public Class forget_pass
    Inherits System.Web.UI.Page
                            
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Dim myConnString As String
    Dim dtCmd As SqlDataAdapter
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents CheckEmail2 As System.Web.UI.WebControls.RegularExpressionValidator
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Dim dtSet As New DataSet()


    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Request.QueryString("url") <> Nothing Then
            Response.Redirect(Request.QueryString("url"))

        End If
        Response.Redirect("main.aspx")

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label1.Visible = False
        If TextBox1.Text <> "" Then
            Dim myConnString As String
            Dim pass As String
            myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnString)
            myConnection.Open()
            mySelectQuery = "SELECT * from member where email = '" & TextBox1.Text & "' "
            dtCmd = New SqlDataAdapter(mySelectQuery, myConnection)
            dtCmd.Fill(dtSet)

            If dtSet.Tables(0).Rows.Count = 1 Then
                Dim mydataRow As DataRow
                Dim t As String
                Dim n As Integer
                'Me.ListBox1.Items.Clear()
                'Me.TextBox1.Clear()
                For Each mydataRow In dtSet.Tables(0).Rows

                    pass = mydataRow("password").ToString()

                Next
                Dim myMail = New MailMessage()
                myMail.To = TextBox1.Text
                myMail.From = "admin@passport.net"
                myMail.Subject = "Passport For Member"
                myMail.Body = "�֧ ��Ҫԡ passport : " & TextBox1.Text & _
                             "���ʼ�ҹ�ͧ�س��� : " & pass & "" & _
                              "---------------------------->" & _
                             "˹���ǻ䫵���ѡ�ͧ��� : http://network07.ce.kmitl.ac.th/passport/main.aspx"

                myMail.BodyFormat = MailFormat.Text
                SmtpMail.SmtpServer = "mail.kmitl.ac.th"
                SmtpMail.Send(myMail)

                Session("email") = TextBox1.Text
                Response.Redirect("forget_pass_complete.aspx")
            Else
                Label1.Text = "email ��͡���١��ͧ ��سҡ�͡�����ա���� !"
                Label1.Visible = True
            End If

        Else
            If TextBox1.Text = "" Then
                Label1.Text = "�س������͡ Email !"
                Label1.Visible = "true"
            End If


        End If


    End Sub
End Class
