Imports System.Web.Services
Imports System.Data
Imports System.Data.SqlClient
Imports System.web
Public Class Web_member
    Inherits System.Web.UI.Page
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
            Protected WithEvents Datagrid2 As System.Web.UI.WebControls.DataGrid
        Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim login As Boolean
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here

        Try
            Dim MyCookie As HttpCookie
            MyCookie = Request.Cookies("passport")

            If MyCookie.Value = "logoutted" Then
                ImageButton1.ImageUrl = "image\signin.GIF"
                login = False
            Else
                ImageButton1.ImageUrl = "image\signout.GIF"
                login = True
            End If

        Catch
            ImageButton1.ImageUrl = "image\signin.GIF"
            login = False
        End Try

        'Put user code to initialize the page here
        Dim objdataReader As SqlDataReader
        Dim myConnection As SqlConnection
        Dim objCmd As SqlCommand
        Dim myConnstring As String
        Dim valReturn As String
        Dim check As String
        Dim mySelectQuery As String

        myConnstring = "server=localhost;database=passport;Trusted_Connection=yes"
        myConnection = New SqlConnection(myConnstring)
        myConnection.Open()
        mySelectQuery = "select * from web_member"
        Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
        Dim dtSet As New DataSet()
        mysqlDataAdater.Fill(dtSet)
        Datagrid2.DataSource = dtSet
        Datagrid2.DataBind()
        'Repeater1.DataSource = dtSet
        'Repeater1.DataBind()


    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        If login = True Then
            Response.Redirect("logout.aspx")
        Else
            Response.Redirect("login.aspx")
        End If
    End Sub
End Class
