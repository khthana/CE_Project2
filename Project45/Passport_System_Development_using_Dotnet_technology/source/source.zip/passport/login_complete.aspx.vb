Imports Encryption
Imports System.text
Public Class login_complete
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim IV() As Byte = Encoding.ASCII.GetBytes("init vec")
    Dim Key() As Byte = Encoding.ASCII.GetBytes("password")
    Public Function encrypt(ByVal pt As String) As String
        Dim plainText() As Byte = Encoding.ASCII.GetBytes(pt)
        Dim algorithmID As EncryptionAlgorithm
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim enc As Encryptor = New Encryptor(EncryptionAlgorithm.Des)
        Dim cipherText() As Byte = Nothing
        Dim ct As String
        enc.IV = IV
        cipherText = enc.Encrypt(plainText, Key)
        IV = enc.IV
        Key = enc.Key
        ct = Convert.ToBase64String(cipherText)

        Return ct
    End Function
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Label1.Text = Request.Cookies("passport").Value
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Response.Redirect(Session("url") & "?e=" & encrypt(Request.Cookies("passport").Value))
    End Sub
End Class
