<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Page Language="vb" AutoEventWireup="false" Codebehind="change_bio.aspx.vb" Inherits="passport.WebForm1"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<!-- Center Area -->
		<P align="center">
		</P>
		<FONT color="#111111">
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD width="100%">
							<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
								<TR>
									<TD vAlign="center" align="left" width="468">
										<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
									</TD>
									<TD vAlign="center" align="right" width="140">
										<A href="main.aspx"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
										</A>
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</P>
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" align="center" bgColor="#0033cc" border="1">
					<TR>
						<TD bgColor="#0033cc" rowSpan="3">
							<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
								<TR>
									<TD height="21">
									</TD>
								</TR>
							</TABLE>
						</TD>
						<TD bgColor="#ffffff">
							<TABLE cellSpacing="0" cellPadding="0" width="606" bgColor="#0033cc" border="0">
								<TR>
									<TD bgColor="#0033cc" height="1">
										<TABLE cellSpacing="0" cellPadding="3" width="100%" border="0">
											<TR align="left">
												<TD style="HEIGHT: 72px" vAlign="top" width="100%"> <!-- status step -->
													<DIV class="box1">
														<FONT color="#ffffff" size="+1">����������ѵ� Passport �ͧ�س</FONT>
														<asp:label id="Label1" Font-Bold="True" ForeColor="White" runat="server">Label</asp:label>
													</DIV>
												</TD>
											</TR>
											<TR>
												<TD vAlign="top" align="middle" width="100%" bgColor="#ffffff"> <!-- Form area -->
													<TABLE class="box1" height="100%" cellSpacing="0" cellPadding="0" width="100%" bgColor="#c6dfff" border="0">
														<FORM id="form1" name="form1" onsubmit="return isValid()" action="webform10.aspx" method="post" runat="server">
															<TBODY>
																<TR>
																	<TD width="120">
																		����
																	</TD>
																	<TD>
																		<asp:textbox id="name" runat="server" size="10"></asp:textbox>
																		<asp:label id="Label5" ForeColor="Red" runat="server" Visible="False">Label</asp:label>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		���ʡ��
																	</TD>
																	<TD>
																		<asp:textbox id="sername" runat="server" size="10"></asp:textbox>
																		<asp:label id="Label6" ForeColor="Red" runat="server" Visible="False">Label</asp:label>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		�������
																	</TD>
																	<TD>
																		<asp:textbox id="address" runat="server" size="50" autocomplete="off" maxlength="50"></asp:textbox>
																		<asp:label id="Label2" ForeColor="Red" runat="server" Visible="False">Label</asp:label>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		�ѧ��Ѵ
																	</TD>
																	<TD>
																		<asp:textbox id="city" runat="server" size="50" autocomplete="off" maxlength="50"></asp:textbox>
																		<asp:label id="Label7" ForeColor="Red" runat="server" Visible="False">Label</asp:label>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		������ɳ���
																	</TD>
																	<TD>
																		<asp:textbox id="Zip" runat="server" size="50" autocomplete="off" maxlength="50"></asp:textbox>
																		<asp:label id="Label4" ForeColor="Red" runat="server" Visible="False">Label</asp:label>
																	</TD>
																</TR>
																<TR>
																	<TD style="HEIGHT: 10px" width="120">
																		⫹����
																	</TD>
																	<TD style="HEIGHT: 10px">
																		<asp:dropdownlist id="zone" runat="server" Height="22px" Width="144px">
																			<asp:ListItem Text="Afghanistan, +4:30 Hr" />
																			<asp:ListItem Text="Albania,(Standard Time Zone)  +1  Hr  " />
																			<asp:ListItem Text="Albania,(Daylight Saving Time)     +2  Hr" />
																			<asp:ListItem Text="Algeria,   +1  Hr " />
																			<asp:ListItem Text="American Samoa,    -11  Hr" />
																			<asp:ListItem Text="Amundsen - Scott Station, South Pole (Standard Time Zone)  +12  Hr " />
																			<asp:ListItem Text="Amundsen - Scott Station, South Pole (Daylight Saving Time)  +11  Hr  " />
																			<asp:ListItem Text="Andorra,(Standard Time Zone)    +1  Hr  " />
																			<asp:ListItem Text="Andorra,(Daylight Saving Time)    +2  Hr  " />
																			<asp:ListItem Text="Angola,   +1  Hr  " />
																			<asp:ListItem Text="Anguilla,  -4 Hr" />
																			<asp:ListItem Text="Antigua and Barbuda,  -4  Hr " />
																			<asp:ListItem Text="Argentina,   -3 Hr" />
																			<asp:ListItem Text="Armenia, (Standard Time Zone)  +4  Hr" />
																			<asp:ListItem Text="Armenia, (Daylight Saving Time)   +5  Hr  " />
																			<asp:ListItem Text="Aruba,    -4 Hr  " />
																			<asp:ListItem Text="Australia,Sydney (Standard Time Zone)   +10 Hr" />
																			<asp:ListItem Text="Australia,Sydney (Daylight Saving Time)  +11 Hr" />
																			<asp:ListItem Text="Australia,Perth  (Standard Time Zone)  +8 Hr  " />
																			<asp:ListItem Text="Australia,Perth  (Daylight Saving Time) +9 Hr  " />
																			<asp:ListItem Text="Australia,   Australian Antarctic Territory -Davis      +7 Hr  " />
																			<asp:ListItem Text="Australia,    Australian Antarctic Territory -Mawson      +6 Hr" />
																			<asp:ListItem Text="Australia,    Australian Antarctic Territory -Casey      +8 Hr  " />
																			<asp:ListItem Text="Australia,    McDonald Islands      +5 Hr  " />
																			<asp:ListItem Text="Australia,    Heard Island      +5 Hr  " />
																			<asp:ListItem Text="Australia,    Territory of Ashmore and Cartier Islands     +8 Hr" />
																			<asp:ListItem Text="Australia,    Christmas Island     +7:00 Hr  " />
																			<asp:ListItem Text="Australia,    Cocos (Keeling) Islands     +6:30 Hr  " />
																			<asp:ListItem Text="Australia,    Nepean and Phillip Island     +11:30 Hr " />
																			<asp:ListItem Text="Australia,    Norfolk Island    +11:30 Hr  " />
																			<asp:ListItem Text="Australia,   Queensland  +8 Hr " />
																			<asp:ListItem Text="Australia,   The Northern Territory   +9:30 Hr" />
																			<asp:ListItem Text="Australia - South Australia,  (Standard Time Zone)          +9:30  Hr  " />
																			<asp:ListItem Text="Australia - South Australia,  (Daylight Saving Time)          +10:30  Hr " />
																			<asp:ListItem Text="Australia - Lord Howe Island, (Standard Time Zone)      +10:30  Hr  " />
																			<asp:ListItem Text="Australia - Lord Howe Island, (Daylight Saving Time)     +11  Hr  " />
																			<asp:ListItem Text="Australia - Eastern Standard Time ,  (Standard Time Zone)      +10  Hr" />
																			<asp:ListItem Text="Australia - Eastern Standard Time ,  (Daylight Saving Time)      +11  Hr  " />
																			<asp:ListItem Text="Australia - Central Standard Time , (Standard Time Zone)      +9:30  Hr  " />
																			<asp:ListItem Text="Australia - Central Standard Time , (Daylight Saving Time)      +10:30  Hr " />
																			<asp:ListItem Text="Australia - Western  Standard Time ,       +8  Hr  " />
																			<asp:ListItem Text="Australia - Australia Capital Territory, (Standard Time Zone)      +10  Hr " />
																			<asp:ListItem Text="Australia - Australia Capital Territory, (Daylight Saving Time)      +11  Hr " />
																			<asp:ListItem Text="Australia - New South Wales,  (Standard Time Zone)      +10  Hr " />
																			<asp:ListItem Text="Australia - New South Wales,  (Daylight Saving Time)      +11  Hr" />
																			<asp:ListItem Text="Australia - Tasmania, (Standard Time Zone)      +10  Hr" />
																			<asp:ListItem Text="Australia - Tasmania, (Daylight Saving Time)      +11  Hr  " />
																			<asp:ListItem Text="Australia - Victoria, (Standard Time Zone)         +10  Hr" />
																			<asp:ListItem Text="Australia - Victoria, (Daylight Saving Time)        +11  Hr  " />
																			<asp:ListItem Text="Australia - Macquarie Island , (Standard Time Zone)       +10 Hr" />
																			<asp:ListItem Text="Australia - Macquarie Island , (Daylight Saving Time)       +11 Hr " />
																			<asp:ListItem Text="Austria, (Standard Time Zone)    +1  Hr" />
																			<asp:ListItem Text="Austria, (Daylight Saving Time)    +2  Hr" />
																			<asp:ListItem Text="Azerbaijan, (Standard Time Zone)    +4  Hr" />
																			<asp:ListItem Text="Azerbaijan, (Daylight Saving Time)    +5  Hr " />
																			<asp:ListItem Text="Bahamas,(Standard Time Zone),-3  Hr " />
																			<asp:ListItem Text="Bahamas,(Daylight Saving Time),-2  Hr " />
																			<asp:ListItem Text="Bahrain, +3  Hr " />
																			<asp:ListItem Text="Bangladesh,  +6 Hr  " />
																			<asp:ListItem Text="Barbados,        -4  Hr " />
																			<asp:ListItem Text="Belarus,  (Standard Time Zone)    +2  Hr  " />
																			<asp:ListItem Text="Belarus,  (Daylight Saving Time)    +3  Hr  " />
																			<asp:ListItem Text="Belgium,  (Standard Time Zone)    +1  Hr  " />
																			<asp:ListItem Text="Belgium,  (Daylight Saving Time)    +2  Hr  " />
																			<asp:ListItem Text="Belize,        -6  Hr" />
																			<asp:ListItem Text="Benin,         +1  Hr " />
																			<asp:ListItem Text="Bermuda (Standard Time Zone)     -4 Hr " />
																			<asp:ListItem Text="Bermuda (Daylight Saving Time)     -3 Hr  " />
																			<asp:ListItem Text="Bhutan,  +6 Hr" />
																			<asp:ListItem Text="Bolivia,    -4 Hr  " />
																			<asp:ListItem Text="Bosnia Herzegovina,  (Standard Time Zone)    +1  Hr " />
																			<asp:ListItem Text="Bosnia Herzegovina,  (Daylight Saving Time)    +2  Hr" />
																			<asp:ListItem Text="Botswana,  +2 Hr" />
																			<asp:ListItem Text="Brazil,Buenos Aires,(Standard Time Zone)   -3 Hr" />
																			<asp:ListItem Text="Brazil,Buenos Aires,(Daylight Saving Time)   -2 Hr" />
																			<asp:ListItem Text="Brazil,Cuiaba,(Standard Time Zone)     -4 Hr " />
																			<asp:ListItem Text="Brazil,Cuiaba,(Daylight Saving Time)     -3 Hr" />
																			<asp:ListItem Text="Brazil,Fortaleza  -3 Hr " />
																			<asp:ListItem Text="Brazil,Georgetown,(Standard Time Zone)   -3 Hr" />
																			<asp:ListItem Text="Brazil,Georgetown,(Daylight Saving Time)   -2 Hr" />
																			<asp:ListItem Text="Brazil,Maceio,(Standard Time Zone)   -3 Hr  " />
																			<asp:ListItem Text="Brazil,Maceio,(Daylight Saving Time)   -2 Hr  " />
																			<asp:ListItem Text="Brazil,Manaus   -4 Hr  " />
																			<asp:ListItem Text="Brazil,Montevideo,(Standard Time Zone)   -3 Hr" />
																			<asp:ListItem Text="Brazil,Montevideo,(Daylight Saving Time)   -2 Hr" />
																			<asp:ListItem Text="Brazil,Noronha - Fernando de Noronha   -2 Hr" />
																			<asp:ListItem Text="Brazil,Porto Acre   -5 Hr" />
																			<asp:ListItem Text="Brazil,Rio de Janeiro,(Standard Time Zone)   -3 Hr" />
																			<asp:ListItem Text="Brazil,Rio de Janeiro,(Daylight Saving Time)   -2 Hr" />
																			<asp:ListItem Text="Brazil,Sao Paulo,(Standard Time Zone)   -3 Hr" />
																			<asp:ListItem Text="Brazil,Sao Paulo,(Daylight Saving Time)   -2 Hr" />
																			<asp:ListItem Text="British Indian Ocean Terr.          +5 Hr " />
																			<asp:ListItem Text="Brunei Darussalum,   +8  Hr   " />
																			<asp:ListItem Text="Bulgaria,  (Standard Time Zone)    +2  Hr" />
																			<asp:ListItem Text="Bulgaria,  (Daylight Saving Time)    +3  Hr " />
																			<asp:ListItem Text="Burkina Faso,   +0 Hr     " />
																			<asp:ListItem Text="Burundi,   +2 Hr     " />
																			<asp:ListItem Text="Byelorussian SSR,  (Standard Time Zone)    +2  Hr  " />
																			<asp:ListItem Text="Byelorussian SSR,  (Daylight Saving Time)    +3  Hr  " />
																			<asp:ListItem Text="Cambodia,   +7 Hr    " />
																			<asp:ListItem Text="Cameroon,   +1 Hr  " />
																			<asp:ListItem Text="Canada, Atlantic Standard Time Zone     -4  Hr " />
																			<asp:ListItem Text="Canada, Atlantic Daylight Saving Time      -3  Hr " />
																			<asp:ListItem Text="Canada, Central Standard Time Zone     -6  Hr " />
																			<asp:ListItem Text="Canada, Central Daylight Saving Time     -5  Hr" />
																			<asp:ListItem Text="Canada, Eastern Standard Time Zone     -5  Hr " />
																			<asp:ListItem Text="Canada, Eastern Daylight Saving Time     -4  Hr " />
																			<asp:ListItem Text="Canada, Mountain Standard Time Zone     -7  Hr" />
																			<asp:ListItem Text="Canada, Mountain Daylight Saving Time    -6  Hr " />
																			<asp:ListItem Text="Canada, Newfoundland Standard Time Zone      -3.30  Hr  " />
																			<asp:ListItem Text="Canada, Newfoundland Daylight Saving Time     -2.30  Hr   " />
																			<asp:ListItem Text="Canada, Pacific Standard Time Zone      -8  Hr" />
																			<asp:ListItem Text="Canada, Pacific Daylight Saving Time     -7  Hr" />
																			<asp:ListItem Text="Canada,       Brit. Columbia - Vancouver, (Standard Time Zone)  -8 Hr  " />
																			<asp:ListItem Text="Canada,       Brit. Columbia - Vancouver, (Daylight Saving Time)  -7 Hr  " />
																			<asp:ListItem Text="Canada, east British Columbia,(Standard Time Zone)   -7 Hr " />
																			<asp:ListItem Text="Canada, east British Columbia,(Daylight Saving Time)   -6 Hr" />
																			<asp:ListItem Text="Canada, Edmonton - Alberta, (Standard Time Zone)   -7 Hr  " />
																			<asp:ListItem Text="Canada, Edmonton - Alberta, (Daylight Saving Time)   -6 Hr " />
																			<asp:ListItem Text="Canada, Dawson - north Yukon,(Standard Time Zone)  -8 Hr   " />
																			<asp:ListItem Text="Canada, Dawson - north Yukon,(Daylight Saving Time)   -7 Hr    " />
																			<asp:ListItem Text="Canada, Dawson Creek & Fort St.John ,British columbia  -7 Hr    " />
																			<asp:ListItem Text="Canada, Glace Bay - Nova Scotia,(Standard Time Zone)  -4 Hr " />
																			<asp:ListItem Text="Canada, Glace Bay - Nova Scotia,(Daylight Saving Time)   -3 Hr " />
																			<asp:ListItem Text="Canada, Goose Bay - E Labrador,(Standard Time Zone)    -4 Hr " />
																			<asp:ListItem Text="Canada, Goose Bay - E Labrador,(Daylight Saving Time)   -3 Hr  " />
																			<asp:ListItem Text="Canada, Halifax - Nova Scotia(most locations),(Standard Time Zone)   -4 Hr   " />
																			<asp:ListItem Text="Canada, Halifax - Nova Scotia(most locations),(Daylight Saving Time)   -3 Hr  " />
																			<asp:ListItem Text="Canada, Inuvik - west Northwest Territories,(Standard Time Zone)   -7 Hr " />
																			<asp:ListItem Text="Canada, Inuvik - west Northwest Territories,(Daylight Saving Time)   -6 Hr " />
																			<asp:ListItem Text="Canada,       Manitoba - Winnipeg, (Standard Time Zone)   -6 Hr" />
																			<asp:ListItem Text="Canada,       Manitoba - Winnipeg, (Daylight Saving Time)   -5 Hr " />
																			<asp:ListItem Text="Canada, Montreal,(Standard Time Zone)  -5 Hr" />
																			<asp:ListItem Text="Canada, Montreal,(Daylight Saving Time)  -4 Hr" />
																			<asp:ListItem Text="Canada, NB,W Labrador,E Quebec(Standard Time Zone)   -4 Hr  " />
																			<asp:ListItem Text="Canada, NB,W Labrador,E Quebec  (Daylight Saving Time)   -3 Hr   " />
																			<asp:ListItem Text="Canada,       Newfoundland - St.John's,  (Standard Time Zone)   -3:30 Hr" />
																			<asp:ListItem Text="Canada,       Newfoundland - St.John's,  (Daylight Saving Time)   -2:30 Hr" />
																			<asp:ListItem Text="Canada, Nipigon,Ontario & Quebec (Standard Time Zone)     -5  Hr  " />
																			<asp:ListItem Text="Canada, Nipigon,Ontario & Quebec (Daylight Saving Time)    -4  Hr  " />
																			<asp:ListItem Text="Canada,      Nova Scotia - Halifax, (Standard Time Zone)     -4 Hr  " />
																			<asp:ListItem Text="Canada,      Nova Scotia - Halifax, (Daylight Saving Time)     -3 Hr " />
																			<asp:ListItem Text="Canada, Ontario  (Standard Time Zone)     -5  Hr  " />
																			<asp:ListItem Text="Canada, Ontario  (Daylight Saving Time)    -4  Hr" />
																			<asp:ListItem Text="Canada,  Ontario - Ottawa, (Standard Time Zone)   -5 Hr " />
																			<asp:ListItem Text="Canada,  Ontario -Ottawa, (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="Canada, Ontario - Toronto, (Standard Time Zone)   -5 Hr  " />
																			<asp:ListItem Text="Canada, Ontario - Toronto, (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="Canada, Pangnirtung - Northwest territories (Standard Time Zone)     -6  Hr   " />
																			<asp:ListItem Text="Canada, Pangnirtung - Northwest territories (Daylight Saving Time)    -5  Hr" />
																			<asp:ListItem Text="Canada, Prince Edward Island (Standard Time Zone)   -4 Hr" />
																			<asp:ListItem Text="Canada, Prince Edward Island (Daylight Saving Time)   -3 Hr  " />
																			<asp:ListItem Text="Canada, Quebec (most locations) (Standard Time Zone)     -5  Hr " />
																			<asp:ListItem Text="Canada, Quebec (most locations) (Daylight Saving Time)    -4  Hr" />
																			<asp:ListItem Text="Canada, Quebec - Quebec, (Standard Time Zone)   -5 Hr  " />
																			<asp:ListItem Text="Canada, Quebec - Quebec, (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="Canada, Rainny River & Fort Frances, Ontario(Standard Time Zone)     -6  Hr  " />
																			<asp:ListItem Text="Canada, Rainny River & Fort Frances, Ontario(Daylight Saving Time)    -5  Hr" />
																			<asp:ListItem Text="Canada, Rakin Inlet - Northwest Territories (Standard Time Zone)     -6  Hr " />
																			<asp:ListItem Text="Canada, Rakin Inlet - Northwest Territories (Daylight Saving Time)    -5  Hr  " />
																			<asp:ListItem Text="Canada, Regina - Saskatchewan - most locations,     -6 Hr" />
																			<asp:ListItem Text="Canada, Saint Johns - New Foundland Island (Standard Time Zone)     -3:30  Hr  " />
																			<asp:ListItem Text="Canada, Saint Johns - New Foundland Island (Daylight Saving Time)    -2:30  Hr" />
																			<asp:ListItem Text="Canada, Swift Current - Saskatchewan - midwest,     -6 Hr " />
																			<asp:ListItem Text="Canada,       The Northwest territories - Aklavik ,  (Standard Time Zone)    -7 Hr" />
																			<asp:ListItem Text="Canada,       The Northwest territories - Aklavik ,  (Daylight Saving Time)    -6 Hr" />
																			<asp:ListItem Text="Canada, Thunder Bay - Ontario (Standard Time Zone)     -5  Hr  " />
																			<asp:ListItem Text="Canada, Thunder Bay - Ontario (Daylight Saving Time)    -4  Hr  " />
																			<asp:ListItem Text="Canada, Vancouver - west British Columbia (Standard Time Zone)     -8  Hr " />
																			<asp:ListItem Text="Canada, Vancouver - west British Columbia  (Daylight Saving Time)    -7  Hr " />
																			<asp:ListItem Text="Canada, west Saskatchewan(Standard Time Zone)   -7 Hr" />
																			<asp:ListItem Text="Canada, west Saskatchewan(Daylight Saving Time)   -6 Hr " />
																			<asp:ListItem Text="Canada, White Horse - south Yukon(Standard Time Zone)     -8  Hr " />
																			<asp:ListItem Text="Canada, White Horse - south Yukon(Daylight Saving Time)    -7  Hr" />
																			<asp:ListItem Text="Canada,  west Ontario(Standard Time Zone)     -6  Hr" />
																			<asp:ListItem Text="Canada, west Ontario(Daylight Saving Time)    -5  Hr  " />
																			<asp:ListItem Text="Canada, Winnipeg - Manitoba (Standard Time Zone)     -6  Hr  " />
																			<asp:ListItem Text="Canada, Winnipeg - Manitoba (Daylight Saving Time)    -5  Hr" />
																			<asp:ListItem Text="Canada, Yellowknife - central Northwest Territories(Standard Time Zone)     -7  Hr" />
																			<asp:ListItem Text="Canada, Yellowknife - central Northwest Territories(Daylight Saving Time)    -6  Hr" />
																			<asp:ListItem Text="Cayman Islands,    -5 Hr  " />
																			<asp:ListItem Text="Cape Verde,    -1 Hr   " />
																			<asp:ListItem Text="Casey - Casey Station, Bailey Peninsula +8 Hr   " />
																			<asp:ListItem Text="Central African Republic,+1 Hr    " />
																			<asp:ListItem Text="Chad,+1 Hr  " />
																			<asp:ListItem Text="Chile,(Standard Time Zone)  -4 Hr  " />
																			<asp:ListItem Text="Chile,(Daylight Saving Time)   -3 Hr     " />
																			<asp:ListItem Text="Chile- Easter Island, (Standard Time Zone) -6  Hr  " />
																			<asp:ListItem Text="Chile- Easter Island, (Daylight Saving Time) -5  Hr    " />
																			<asp:ListItem Text="China, Beijing +8 Hr" />
																			<asp:ListItem Text="China, Hongkong (Standard Time Zone)   +8 Hr" />
																			<asp:ListItem Text="China, Hongkong (Daylight Saving Time)   +9 Hr " />
																			<asp:ListItem Text="China, Kwangchow +8 Hr" />
																			<asp:ListItem Text="China, Peking  +8 Hr" />
																			<asp:ListItem Text="China, Penang  +8 Hr" />
																			<asp:ListItem Text="China, Shanghai  +8 Hr" />
																			<asp:ListItem Text="Christmas Island,+7 Hr  " />
																			<asp:ListItem Text="Cocos (Keeling) Islands,+6:30 Hr" />
																			<asp:ListItem Text="Colombia,       -5 Hr    " />
																			<asp:ListItem Text="Comoros         +3   Hr  " />
																			<asp:ListItem Text="Congo,Brazzaville   +1 Hr   " />
																			<asp:ListItem Text="Congo Dem. Rep.,Kinshasa  +1 Hr    " />
																			<asp:ListItem Text="Congo Dem. Rep.,Lubumbashi  +2 Hr  " />
																			<asp:ListItem Text="Cook Islands, (Standard Time Zone)         -10 Hr  " />
																			<asp:ListItem Text="Cook Islands, (Daylight Saving Time)         -9 Hr  " />
																			<asp:ListItem Text="Costa Rica,         -6 Hr       " />
																			<asp:ListItem Text="Cote D'Ivoire,       +0 Hr   " />
																			<asp:ListItem Text="Croatia, (Standard Time Zone)    +1  Hr  " />
																			<asp:ListItem Text="Croatia, (Daylight Saving Time)    +2  Hr" />
																			<asp:ListItem Text="Cuba,(Standard Time Zone)         -5 Hr    " />
																			<asp:ListItem Text="Cuba,(Daylight Saving Time)        -4  Hr       " />
																			<asp:ListItem Text="Cyprus, (Standard Time Zone)          +2  Hr     " />
																			<asp:ListItem Text="Cyprus, (Daylight Saving Time)          +3   Hr  " />
																			<asp:ListItem Text="Czech Republic, (Standard Time Zone)    +1  Hr  " />
																			<asp:ListItem Text="Czech Republic, (Daylight Saving Time)    +2  Hr  " />
																			<asp:ListItem Text="Denmark, Copenhagen  (Standard Time Zone)    +1  Hr" />
																			<asp:ListItem Text="Denmark, Copenhagen  (Daylight Saving Time)    +2  Hr  " />
																			<asp:ListItem Text="Denmark - Faroe Islands,(Standard Time Zone)     +0  Hr  " />
																			<asp:ListItem Text="Denmark - Faroe Islands,(Daylight Saving Time)     +1  Hr" />
																			<asp:ListItem Text="Djibouti,     +3 Hr   " />
																			<asp:ListItem Text="Dominica,         -4 Hr     " />
																			<asp:ListItem Text="Dominican Republic,         -4 Hr     " />
																			<asp:ListItem Text="DumontDUrville - Dumont-d'Urville Base,Terre - Adelie     +10 Hr   " />
																			<asp:ListItem Text="East Timor,           +9 Hr " />
																			<asp:ListItem Text="Ecuador,         -5 Hr    " />
																			<asp:ListItem Text="Ecuador - Galapagos Islands,         -6 Hr " />
																			<asp:ListItem Text="Egypt (Standard Time Zone),          +2 Hr  " />
																			<asp:ListItem Text="Egypt (Daylight Saving Time),          +3 Hr  " />
																			<asp:ListItem Text="El Salvador,-6 Hr " />
																			<asp:ListItem Text="Equatorial Guinea,           +1 Hr  " />
																			<asp:ListItem Text="Eritrea,           +3 Hr " />
																			<asp:ListItem Text="Estonia,  (Standard Time Zone)          +2  Hr     " />
																			<asp:ListItem Text="Estonia,  (Daylight Saving Time)          +3   Hr " />
																			<asp:ListItem Text="Ethiopia,           +3 Hr  " />
																			<asp:ListItem Text="Falkland Islands - Malvinas (Standard Time Zone),         -4 Hr  " />
																			<asp:ListItem Text="Falkland Islands - Malvinas (Daylight Saving Time),         -3 Hr  " />
																			<asp:ListItem Text="Faroe Islands (Standard Time Zone),          +0 Hr  " />
																			<asp:ListItem Text="Faroe Islands (Daylight Saving Time),          +1 Hr  " />
																			<asp:ListItem Text="Fiji, +12  Hr " />
																			<asp:ListItem Text="Finland,   (Standard Time Zone)          +2  Hr   " />
																			<asp:ListItem Text="Finland,   (Daylight Saving Time)          +3   Hr  " />
																			<asp:ListItem Text="France,Guadeloupe      -4 Hr " />
																			<asp:ListItem Text="France,French Guiana      -3 Hr " />
																			<asp:ListItem Text="France,French Polynesia - Gambier Islands     -9 Hr " />
																			<asp:ListItem Text="France,French Polynesia - Marquesas Islands     -9:30 Hr " />
																			<asp:ListItem Text="France,French Polynesia - Tahiti - Society Islands     -10 Hr " />
																			<asp:ListItem Text="France,Kerguelen       +5 Hr " />
																			<asp:ListItem Text="France,Martinique      -4 Hr " />
																			<asp:ListItem Text="France,Mayotte       +3 Hr " />
																			<asp:ListItem Text="France,Nice   (Standard Time Zone)          +1  Hr   " />
																			<asp:ListItem Text="France,Nice   (Daylight Saving Time)          +2   Hr  " />
																			<asp:ListItem Text="France,New Caledonia  (Standard Time Zone)      +11 Hr  " />
																			<asp:ListItem Text="France,New Caledonia  (Daylight Saving Time)      +12 Hr" />
																			<asp:ListItem Text="France,Paris   (Standard Time Zone)          +1  Hr  " />
																			<asp:ListItem Text="France,Paris   (Daylight Saving Time)          +2   Hr" />
																			<asp:ListItem Text="French Southern Territories      +5 Hr " />
																			<asp:ListItem Text="Gabon       +1 Hr" />
																			<asp:ListItem Text="Gambia      +0 Hr  " />
																			<asp:ListItem Text="Gaza Strip,  (Standard Time Zone)       +2 Hr" />
																			<asp:ListItem Text="Gaza Strip,  (Daylight Saving Time)        +3 Hr" />
																			<asp:ListItem Text="Georgia,  (Standard Time Zone)    +4  Hr " />
																			<asp:ListItem Text="Georgia,  (Daylight Saving Time)   +5  Hr" />
																			<asp:ListItem Text="Germany,   (Standard Time Zone)          +1  Hr    " />
																			<asp:ListItem Text="Germany,   (Daylight Saving Time)          +2   Hr  " />
																			<asp:ListItem Text="Ghana      +0 Hr " />
																			<asp:ListItem Text="Gibraltar,    (Standard Time Zone)          +1  Hr   " />
																			<asp:ListItem Text="Gibraltar,    (Daylight Saving Time)          +2   Hr  " />
																			<asp:ListItem Text="Greece,  (Standard Time Zone)       +2 Hr " />
																			<asp:ListItem Text="Greece,  (Daylight Saving Time)        +3 Hr  " />
																			<asp:ListItem Text="Greenland,Godtab - southwest Greenland (Standard Time Zone) -3 Hr " />
																			<asp:ListItem Text="Greenland,Godtab - southwest Greenland (Daylight Saving Time) -2 Hr " />
																			<asp:ListItem Text="Greenland,Scoresbysund east Greenland (Standard Time Zone) -1 Hr" />
																			<asp:ListItem Text="Greenland,Scoresbysund east Greenland (Daylight Saving Time) -0 Hr" />
																			<asp:ListItem Text="Greenland,Thule - northwest Greenland (Standard Time Zone) -4 Hr  " />
																			<asp:ListItem Text="Greenland,Thule - northwest Greenland (Daylight Saving Time) -3 Hr" />
																			<asp:ListItem Text="Grenada,       -4  Hr   " />
																			<asp:ListItem Text="Guadeloupe,-4 Hr   " />
																			<asp:ListItem Text="Guatemala,-6 Hr   " />
																			<asp:ListItem Text="Guinea,Conakry +0 Hr " />
																			<asp:ListItem Text="Guinea Bissau,Bissau +0 Hr" />
																			<asp:ListItem Text="Guyana-4 Hr  " />
																			<asp:ListItem Text="Haiti,(Standard Time Zone)      -5 Hr " />
																			<asp:ListItem Text="Haiti,(Daylight Saving Time)      -4 Hr   " />
																			<asp:ListItem Text="Honduras,      -6 Hr  " />
																			<asp:ListItem Text="Hungary,   (Standard Time Zone)          +1  Hr   " />
																			<asp:ListItem Text="Hungary,   (Daylight Saving Time)          +2   Hr" />
																			<asp:ListItem Text="Iceland 0 Hr" />
																			<asp:ListItem Text="India,  +5:30 Hr" />
																			<asp:ListItem Text="Indonesia,Bali, Borneo & Celebes          +8 Hr  " />
																			<asp:ListItem Text="Indonesia,Irian Jaya & The Moluccas         +9 Hr" />
																			<asp:ListItem Text="Indonesia,Java & Sumatra          +7 Hr  " />
																			<asp:ListItem Text="Indonesia,Bali - Denpasar          +8 Hr" />
																			<asp:ListItem Text="Indonesia,Bali - Singaraja          +8 Hr" />
																			<asp:ListItem Text="Indonesia,Flores - Endeh          +8 Hr  " />
																			<asp:ListItem Text="Indonesia,Halmahera - Ternate          +9 Hr" />
																			<asp:ListItem Text="Indonesia,Irian Jaya - Jayapura          +9 Hr " />
																			<asp:ListItem Text="Indonesia,Java - Bandung          +7 Hr  " />
																			<asp:ListItem Text="Indonesia,Java - Jakarta          +7 Hr" />
																			<asp:ListItem Text="Indonesia,Java - Malang          +7 Hr" />
																			<asp:ListItem Text="Indonesia,Java - Semarang          +7 Hr " />
																			<asp:ListItem Text="Indonesia,Java - Surabaya         +7 Hr  " />
																			<asp:ListItem Text="Indonesia,Java - Surakarta          +7 Hr" />
																			<asp:ListItem Text="Indonesia,Lombok - Mataram          +8 Hr  " />
																			<asp:ListItem Text="Indonesia,Seram - Ambon          +9 Hr" />
																			<asp:ListItem Text="Indonesia,Sumatera - Medan         +7 Hr " />
																			<asp:ListItem Text="Indonesia,Sumatera - Palembang          +7 Hr  " />
																			<asp:ListItem Text="Indonesia,Sumbawa - Raba          +8 Hr " />
																			<asp:ListItem Text="Indonesia,West Timor - Kupang          +8 Hr " />
																			<asp:ListItem Text="Iran, (Standard Time Zone)  +3:30 Hr  " />
																			<asp:ListItem Text="Iran, (Daylight Saving Time)  +4:30 Hr  " />
																			<asp:ListItem Text="Iraq, (Standard Time Zone)    +3 Hr  " />
																			<asp:ListItem Text="Iraq, (Daylight Saving Time)   +4 Hr " />
																			<asp:ListItem Text="Ireland,   (Standard Time Zone)          +0  Hr     " />
																			<asp:ListItem Text="Ireland,   (Daylight Saving Time)          +1   Hr " />
																			<asp:ListItem Text="Israel, (Standard Time Zone)          +2 Hr" />
																			<asp:ListItem Text="Israel, (Daylight Saving Time)          +3 Hr" />
																			<asp:ListItem Text="Italy ,   (Standard Time Zone)          +1  Hr  " />
																			<asp:ListItem Text="Italy ,   (Daylight Saving Time)          +2   Hr   " />
																			<asp:ListItem Text="Jamaica,      -5 Hr " />
																			<asp:ListItem Text="Japan,   +9 Hr  " />
																			<asp:ListItem Text="Jordan, (Standard Time Zone)   +2 Hr  " />
																			<asp:ListItem Text="Jordan, (Daylight Saving Time)   +3 Hr  " />
																			<asp:ListItem Text="Kazakstan,Alma-Ata - east  Kazakstan ,  (Standard Time Zone)         +6 Hr " />
																			<asp:ListItem Text="Kazakstan,Alma-Ata - east  Kazakstan ,  (Daylight Saving Time)         +7 Hr  " />
																			<asp:ListItem Text="Kazakstan,Aqtau - west  Kazakstan ,  (Standard Time Zone)            +4 Hr  " />
																			<asp:ListItem Text="Kazakstan,Aqtau - west  Kazakstan ,  (Daylight Saving Time)            +5 Hr  " />
																			<asp:ListItem Text="Kazakstan,Aqtobe - central  Kazakstan ,  (Standard Time Zone)         +5 Hr  " />
																			<asp:ListItem Text="Kazakstan,Aqtobe - central  Kazakstan ,  (Daylight Saving Time)         +6 Hr " />
																			<asp:ListItem Text="Kenya,           +3 Hr  " />
																			<asp:ListItem Text="Kiribati,Line Islands           +14  Hr" />
																			<asp:ListItem Text="Kiribati,Phoenix Islands           +13  Hr" />
																			<asp:ListItem Text="Kiribati, Gilbert Islands           +12 Hr " />
																			<asp:ListItem Text="Korea, North  +9 Hr " />
																			<asp:ListItem Text="Korea, South  +9 Hr  " />
																			<asp:ListItem Text="Kosovo,   (Standard Time Zone)          +1  Hr " />
																			<asp:ListItem Text="Kosovo,   (Daylight Saving Time)          +2   Hr  " />
																			<asp:ListItem Text="Kuwait+3 Hr" />
																			<asp:ListItem Text="Kyrgyzstan,  (Standard Time Zone)         +5 Hr " />
																			<asp:ListItem Text="Kyrgyzstan,  (Daylight Saving Time)         +6 Hr" />
																			<asp:ListItem Text="Laos,  +7 Hr  " />
																			<asp:ListItem Text="Latvia,  (Standard Time Zone)          +2 Hr" />
																			<asp:ListItem Text="Latvia,  (Daylight Saving Time)          +3 Hr  " />
																			<asp:ListItem Text="Lebanon,   (Standard Time Zone)         +2 Hr " />
																			<asp:ListItem Text="Lebanon,   (Daylight Saving Time)         +3 Hr " />
																			<asp:ListItem Text="Lesotho,  +2 Hr " />
																			<asp:ListItem Text="Liberia,  +0 Hr  " />
																			<asp:ListItem Text="Libyan Arab Jamahiriya(Standard Time Zone),   +2 Hr" />
																			<asp:ListItem Text="Libyan Arab Jamahiriya(Daylight Saving Time),   +3 Hr" />
																			<asp:ListItem Text="Liechtenstein,   (Standard Time Zone)          +1  Hr    " />
																			<asp:ListItem Text="Liechtenstein,   (Daylight Saving Time)          +2   Hr " />
																			<asp:ListItem Text="Lithuania, (Standard Time Zone),   +2 Hr" />
																			<asp:ListItem Text="Lithuania, (Daylight Saving Time),   +3 Hr  " />
																			<asp:ListItem Text="Luxembourg,   (Standard Time Zone)          +1  Hr   " />
																			<asp:ListItem Text="Luxembourg,   (Daylight Saving Time)          +2   Hr   " />
																			<asp:ListItem Text="Macau,  +8  Hr" />
																			<asp:ListItem Text="Macedonia,   (Standard Time Zone)          +1  Hr  " />
																			<asp:ListItem Text="Macedonia,   (Daylight Saving Time)          +2   Hr" />
																			<asp:ListItem Text="Madagascar,  +3  Hr  " />
																			<asp:ListItem Text="Malawi,  +2  Hr " />
																			<asp:ListItem Text="Malaysia,  +8 Hr" />
																			<asp:ListItem Text="Maldives,  +5 Hr " />
																			<asp:ListItem Text="Mali,Bamako  +0  Hr" />
																			<asp:ListItem Text="Mali,Timbuktu  +0  Hr  " />
																			<asp:ListItem Text="Malta,   (Standard Time Zone)          +1  Hr   " />
																			<asp:ListItem Text="Malta,   (Daylight Saving Time)          +2   Hr" />
																			<asp:ListItem Text="Marshall Islands, Kwajalein         +12   Hr" />
																			<asp:ListItem Text="Marshall Islands, Majuro(most locations)         +12   Hr  " />
																			<asp:ListItem Text="Martinique,   -4 Hr  " />
																			<asp:ListItem Text="Mauritania,    +0 Hr " />
																			<asp:ListItem Text="Mauritius,    +4 Hr  " />
																			<asp:ListItem Text="Mawson - Mawson Station,Holme Bay    +6  Hr " />
																			<asp:ListItem Text="McMurdo - McMurdo Station,Ross Island  (Standard Time Zone)            +12   Hr  " />
																			<asp:ListItem Text="McMurdo - McMurdo Station,Ross Island   (Daylight Saving Time)           +11   Hr  " />
																			<asp:ListItem Text="Mexico,Acapulco,(Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="Mexico,Acapulco,(Daylight Saving Time)   -5 Hr" />
																			<asp:ListItem Text="Mexico,Aguascalientes,(Standard Time Zone)    -6 Hr   " />
																			<asp:ListItem Text="Mexico,Aguascalientes,(Daylight Saving Time)   -5 Hr " />
																			<asp:ListItem Text="Mexico,Chihuahua,(Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="Mexico,Chihuahua,(Daylight Saving Time)   -4 Hr      -8 Hr " />
																			<asp:ListItem Text="Mexico,Ensenada - most locations  (Daylight Saving Time)  -7 Hr  " />
																			<asp:ListItem Text="Mexico,Guadalajara,(Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="Mexico,Guadalajara,(Daylight Saving Time)   -5 Hr " />
																			<asp:ListItem Text="Mexico,Leon,(Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="Mexico,Leon,(Daylight Saving Time)   -5 Hr  " />
																			<asp:ListItem Text="Mexico,Mazatlan (Standard Time Zone)    -7 Hr " />
																			<asp:ListItem Text="Mexico,Mazatlan (Daylight Saving Time)   -6 Hr  " />
																			<asp:ListItem Text="Mexico,Merida,(Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="Mexico,Merida,(Daylight Saving Time)   -5 Hr" />
																			<asp:ListItem Text="Mexico,Mexicali,(Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="Mexico,Mexicali,(Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="Mexico,Mexico-city,(Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="Mexico,Mexico-city,(Daylight Saving Time)   -5 Hr " />
																			<asp:ListItem Text="Mexico,Monterrey,(Standard Time Zone)    -6 Hr   " />
																			<asp:ListItem Text="Mexico,Monterrey,(Daylight Saving Time)   -5 Hr " />
																			<asp:ListItem Text="Mexico,San Luis potosi,(Standard Time Zone)    -6 Hr" />
																			<asp:ListItem Text="Mexico,San Luis potosi,(Daylight Saving Time)   -5 Hr" />
																			<asp:ListItem Text="Mexico,Tijuana - north Baja California (Standard Time Zone)  -8 Hr" />
																			<asp:ListItem Text="Mexico,Tijuana - north Baja California (Daylight Saving Time)  -7 Hr " />
																			<asp:ListItem Text="Mexico,Veracruz,(Standard Time Zone)    -6 Hr   " />
																			<asp:ListItem Text="Mexico,Veracruz,(Daylight Saving Time)   -5 Hr   " />
																			<asp:ListItem Text="Micronesia, Kosrae  +11 Hr  " />
																			<asp:ListItem Text="Micronesia, Ponape(pohnpei) +11 Hr " />
																			<asp:ListItem Text="Micronesia, Truk(Chuuk) +10 Hr" />
																			<asp:ListItem Text="Micronesia, Yap +10 Hr " />
																			<asp:ListItem Text="Moldova, (Standard Time Zone)     +2 Hr  " />
																			<asp:ListItem Text="Moldova, (Daylight Saving Time)    +3 Hr" />
																			<asp:ListItem Text="Moldova, (Standard Time Zone),   +2 Hr " />
																			<asp:ListItem Text="Moldova, (Daylight Saving Time),   +3 Hr" />
																			<asp:ListItem Text="Monaco,(Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Monaco,(Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Mongolia,   (Standard Time Zone)         +8 Hr" />
																			<asp:ListItem Text="Mongolia,   (Daylight Saving Time)         +9 Hr  " />
																			<asp:ListItem Text="Montserrat, -4  Hr" />
																			<asp:ListItem Text="Morocco  0  Hr" />
																			<asp:ListItem Text="Mozambique, +2 Hr" />
																			<asp:ListItem Text="Myanmar,        +6:30 Hr" />
																			<asp:ListItem Text="Namibia(Standard Time Zone),           +1 Hr" />
																			<asp:ListItem Text="Namibia(Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Nauru,           +12 Hr " />
																			<asp:ListItem Text="Nepal,           +5:45 Hr  " />
																			<asp:ListItem Text="Netherlands, Amsterdam,  (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Netherlands, Amsterdam,  (Daylight Saving Time),           +2 Hr  " />
																			<asp:ListItem Text="Netherlands,Aruba - Oranjestad    -4 Hr " />
																			<asp:ListItem Text="Netherlands,Rotterdam (Standard Time Zone)     +1 Hr " />
																			<asp:ListItem Text="Netherlands,Rotterdam (Daylight Saving Time)     +2 Hr  " />
																			<asp:ListItem Text="Netherlands,Netherlands Antilles - Willemstad    -4 Hr  " />
																			<asp:ListItem Text="New Caledonia  (Standard Time Zone)      +11 Hr " />
																			<asp:ListItem Text="New Caledonia  (Daylight Saving Time)      +12 Hr   " />
																			<asp:ListItem Text="New Zealand,Auckland - most locations (Standard Time Zone)+12 Hr  " />
																			<asp:ListItem Text="New Zealand,Auckland - most locations (Daylight Saving Time)+13 Hr" />
																			<asp:ListItem Text="New Zealand, Chatham Island,  (Standard Time Zone)       +12:45 Hr " />
																			<asp:ListItem Text="New Zealand, Chatham Island,  (Daylight Saving Time)       +13:45 Hr" />
																			<asp:ListItem Text="New Zealand,Wellington  (Standard Time Zone)+12 Hr " />
																			<asp:ListItem Text="New Zealand,Wellington  (Daylight Saving Time)+13 Hr" />
																			<asp:ListItem Text="Nicaragua,       -6 Hr" />
																			<asp:ListItem Text="Niger,    +1 Hr" />
																			<asp:ListItem Text="Nigeria,    +1 Hr  " />
																			<asp:ListItem Text="Niue   -11 Hr   " />
																			<asp:ListItem Text="Norfolk  Island       +11:30 Hr  " />
																			<asp:ListItem Text="North Korea,    +9 Hr " />
																			<asp:ListItem Text="Norway, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Norway, (Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Northern Mariana Islands - Saipan    +10 Hr  " />
																			<asp:ListItem Text="Oman,         +4 Hr" />
																			<asp:ListItem Text="Pakistan,+5 Hr  " />
																			<asp:ListItem Text="Palau,+9 Hr " />
																			<asp:ListItem Text="Palmer - Palmer Station, Anvers Island (Standard Time Zone)   -4  Hr  " />
																			<asp:ListItem Text="Palmer - Palmer Station, Anvers Island (Daylight Saving Time)   -3  Hr   " />
																			<asp:ListItem Text="Panama,   -5  Hr" />
																			<asp:ListItem Text="Papua New Guinea+10  Hr  " />
																			<asp:ListItem Text="Paraguay,(Standard Time Zone)   -4 Hr" />
																			<asp:ListItem Text="Paraguay,(Daylight Saving Time)   -3 Hr  " />
																			<asp:ListItem Text="Peru,   -5 Hr" />
																			<asp:ListItem Text="Pitcairn,   -8 Hr   " />
																			<asp:ListItem Text="Puerto Rico,   -4 Hr    " />
																			<asp:ListItem Text="Philippines, +8 Hr" />
																			<asp:ListItem Text="Poland, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Poland, (Daylight Saving Time),           +2 Hr " />
																			<asp:ListItem Text="Portugal - Madeira, (Standard Time Zone)               0  Hr  " />
																			<asp:ListItem Text="Portugal - Madeira, (Daylight Saving Time)  +1  Hr " />
																			<asp:ListItem Text="Portugal- Azores, (Standard Time Zone)     -1  Hr  " />
																			<asp:ListItem Text="Portugal- Azores, (Daylight Saving Time)                  0  Hr" />
																			<asp:ListItem Text="Portugal- Lisbon, (Standard Time Zone)                  0  Hr  " />
																			<asp:ListItem Text="Portugal- Lisbon, (Daylight Saving Time)     +1  Hr " />
																			<asp:ListItem Text="Portugal- Porto, (Standard Time Zone)      +0  Hr " />
																			<asp:ListItem Text="Portugal- Porto, (Daylight Saving Time)     +1  Hr " />
																			<asp:ListItem Text="Puerto Rico,    -4  Hr " />
																			<asp:ListItem Text="Qatar,     +3  Hr " />
																			<asp:ListItem Text="Reunion,    +4 Hr " />
																			<asp:ListItem Text="Romania, (Standard Time Zone),   +2 Hr " />
																			<asp:ListItem Text="Romania, (Daylight Saving Time),   +3 Hr " />
																			<asp:ListItem Text="Russia,Anadyr - Bering Sea, (Standard Time Zone),   +12 Hr  " />
																			<asp:ListItem Text="Russia,Anadyr - Bering Sea, (Daylight Saving Time),   +13 Hr" />
																			<asp:ListItem Text="Russia,Chelyabinsk,   (Standard Time Zone), +5 Hr" />
																			<asp:ListItem Text="Russia,Chelyabinsk,   (Daylight Saving Time)+6 Hr" />
																			<asp:ListItem Text="Russia,Irkutsk - Lake Baikal , (Standard Time Zone)+8 Hr" />
																			<asp:ListItem Text="Russia,Irkutsk - Lake Baikal , (Daylight Saving Time),+9 Hr" />
																			<asp:ListItem Text="Russia,Kaliningrad , (Standard Time Zone),   +2 Hr " />
																			<asp:ListItem Text="Russia,Kaliningrad , (Daylight Saving Time),   +3 Hr" />
																			<asp:ListItem Text="Russia,Kamchatka,   (Standard Time Zone),   +12 Hr" />
																			<asp:ListItem Text="Russia,Kamchatka,   (Daylight Saving Time),   +13 Hr" />
																			<asp:ListItem Text="Russia,Kazan, (Standard Time Zone),   +3 Hr" />
																			<asp:ListItem Text="Russia,Kazan, (Daylight Saving Time),   +4 Hr" />
																			<asp:ListItem Text="Russia,Krasnoyarsk - Yenesai River, (Standard Time Zone),       +7 Hr " />
																			<asp:ListItem Text="Russia,Krasnoyarsk - Yenesai River, (Daylight Saving Time),      +8 Hr" />
																			<asp:ListItem Text="Russia,Kaliningrad , (Standard Time Zone),   +3 Hr  " />
																			<asp:ListItem Text="Russia,Kaliningrad , (Daylight Saving Time),   +4 Hr " />
																			<asp:ListItem Text="Russia,Magadan & Sakhalin,   (Standard Time Zone)+11 Hr " />
																			<asp:ListItem Text="Russia,Magadan & Sakhalin,   (Daylight Saving Time),          +12 Hr " />
																			<asp:ListItem Text="Russia,Murmansk , (Standard Time Zone),   +3 Hr " />
																			<asp:ListItem Text="Russia,Murmansk , (Daylight Saving Time),   +4 Hr  " />
																			<asp:ListItem Text="Russia,Novgorod , (Standard Time Zone),   +3 Hr" />
																			<asp:ListItem Text="Russia,Novgorod , (Daylight Saving Time),   +4 Hr" />
																			<asp:ListItem Text="Russia,Novosibirsk,  (Standard Time Zone),       +6 Hr" />
																			<asp:ListItem Text="Russia,Novosibirsk, (Daylight Saving Time),      +7 Hr " />
																			<asp:ListItem Text="Russia,Omsk - west Siberia,  (Standard Time Zone),       +6 Hr" />
																			<asp:ListItem Text="Russia,Omsk - west Siberia, (Daylight Saving Time),      +7 Hr " />
																			<asp:ListItem Text="Russia,Perm ,   (Standard Time Zone), +5 Hr " />
																			<asp:ListItem Text="Russia,Perm ,   (Daylight Saving Time)+6 Hr" />
																			<asp:ListItem Text="Russia,Saint Peterburg, (Standard Time Zone),   +3 Hr  " />
																			<asp:ListItem Text="Russia,Saint Peterburg, (Daylight Saving Time),   +4 Hr" />
																			<asp:ListItem Text="Russia,Samara - Caspian Sea  (Standard Time Zone),   +4 Hr  " />
																			<asp:ListItem Text="Russia,Samara - Caspian Sea  (Daylight Saving Time),   +5 Hr" />
																			<asp:ListItem Text="Russia,Sverdlovsk ,   (Standard Time Zone), +5 Hr  " />
																			<asp:ListItem Text="Russia,Sverdlovsk ,   (Daylight Saving Time)+6 Hr " />
																			<asp:ListItem Text="Russia,Ufa,   (Standard Time Zone), +5 Hr " />
																			<asp:ListItem Text="Russia,Ufa,   (Daylight Saving Time)+6 Hr" />
																			<asp:ListItem Text="Russia,Vladivostok - Amur River ,   (Standard Time Zone)+10 Hr " />
																			<asp:ListItem Text="Russia,Vladivostok - Amur River ,   (Daylight Saving Time),          +11 Hr" />
																			<asp:ListItem Text="Russia,Yakutsk - Lena River ,   (Standard Time Zone)+10 Hr " />
																			<asp:ListItem Text="Russia,Yakutsk - Lena River ,   (Daylight Saving Time),          +11 Hr  " />
																			<asp:ListItem Text="Russia,Yekaterinburg - Urals  (Standard Time Zone), +5 Hr" />
																			<asp:ListItem Text="Russia,Yekaterinburg - Urals  (Daylight Saving Time)+6 Hr  " />
																			<asp:ListItem Text="Rwanda,+2 Hr  " />
																			<asp:ListItem Text="Saint Helena,+0 Hr   " />
																			<asp:ListItem Text="Saint Kitts & Nevis,   -4 Hr   " />
																			<asp:ListItem Text="Saint Lucia,   -4 Hr" />
																			<asp:ListItem Text="Saint Pierre and Miquelon, (Standard Time Zone)  -3 Hr" />
																			<asp:ListItem Text="Saint Pierre and Miquelon, (Daylight Saving Time)  -2 Hr  " />
																			<asp:ListItem Text="Saint Vincent & Granadines,   -4 Hr  " />
																			<asp:ListItem Text="Samoa,   -11 Hr  " />
																			<asp:ListItem Text="San Marino, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="San Marino, (Daylight Saving Time),           +2 Hr " />
																			<asp:ListItem Text="Sao Tome and Principe 0 Hr  " />
																			<asp:ListItem Text="Saudi Arabia,+3 Hr" />
																			<asp:ListItem Text="Senegal,+0 Hr " />
																			<asp:ListItem Text="Seychelles,+4 Hr " />
																			<asp:ListItem Text="Scotland          0 Hr" />
																			<asp:ListItem Text="Sierra Leone,+0 Hr  " />
																			<asp:ListItem Text="Singapore,       +8 Hr  " />
																			<asp:ListItem Text="Slovakia, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Slovakia, (Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Slovenia, (Standard Time Zone),           +1 Hr" />
																			<asp:ListItem Text="Slovenia, (Daylight Saving Time),           +2 Hr  " />
																			<asp:ListItem Text="Solomon Islands +11 Hr" />
																			<asp:ListItem Text="Somalia +3 Hr " />
																			<asp:ListItem Text="South Africa, +2 Hr  " />
																			<asp:ListItem Text="South Korea, +9 Hr  " />
																			<asp:ListItem Text="Spain,Ceuta - Ceuta & Mellila(Standard Time Zone) +3 Hr  " />
																			<asp:ListItem Text="Spain,Ceuta - Ceuta & Mellila(Daylight Saving Time) +4 Hr" />
																			<asp:ListItem Text="Spain,Madrid, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Spain,Madrid, (Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Spain - Canary Islands,  (Standard Time Zone)          +0  Hr " />
																			<asp:ListItem Text="Spain - Canary Islands,  (Daylight Saving Time)          +1  Hr" />
																			<asp:ListItem Text="Sri Lanka,   +5:30 Hr " />
																			<asp:ListItem Text="Sudan,           +3 Hr " />
																			<asp:ListItem Text="Suriname,  -3 Hr" />
																			<asp:ListItem Text="Svalbard and Jan Mayan Island,  -1 Hr " />
																			<asp:ListItem Text="Swaziland,   +2 Hr " />
																			<asp:ListItem Text="Sweden, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Sweden, (Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Switzerland, (Standard Time Zone),           +1 Hr  " />
																			<asp:ListItem Text="Switzerland, (Daylight Saving Time),           +2 Hr" />
																			<asp:ListItem Text="Syria,  (Standard Time Zone)          +2  Hr" />
																			<asp:ListItem Text="Syria,  (Daylight Saving Time)          +3  Hr  " />
																			<asp:ListItem Text="Taiwan,  (Standard Time Zone)          +8  Hr  " />
																			<asp:ListItem Text="Taiwan,  (Daylight Saving Time)          +9  Hr " />
																			<asp:ListItem Text="Tajikistan,   +5 Hr  " />
																			<asp:ListItem Text="Tanzania,  +3 Hr  " />
																			<asp:ListItem Text="Tibet,  +6 Hr" />
																			<asp:ListItem Text="Thailand,  +7 Hr  " />
																			<asp:ListItem Text="Togo,   +0 Hr " />
																			<asp:ListItem Text="Tokelau,      -10  Hr  " />
																			<asp:ListItem Text="Tonga,       +13  Hr  " />
																			<asp:ListItem Text="Trinidad & Tobago,  -4 Hr " />
																			<asp:ListItem Text="Tunisia,   +1 Hr  " />
																			<asp:ListItem Text="Turks & Caicos Island,(Standard Time Zone)      -5 Hr " />
																			<asp:ListItem Text="Turks & Caicos Island,(Daylight Saving Time)       -4 Hr  " />
																			<asp:ListItem Text="Turkey,  (Standard Time Zone)          +2  Hr" />
																			<asp:ListItem Text="Turkey,  (Daylight Saving Time)          +3  Hr" />
																			<asp:ListItem Text="Turkmenistan,       +5 Hr " />
																			<asp:ListItem Text="Tuvalu,       +12 Hr  " />
																			<asp:ListItem Text="U.A.E.,        +4 Hr" />
																			<asp:ListItem Text="U.K. - Anguilla,    -4 Hr  " />
																			<asp:ListItem Text="U.K. - Belfast - Northern Ireland,  (Standard  Time Zone)          +0  Hr" />
																			<asp:ListItem Text="U.K. - Belfast - Northern Ireland,  (Summer Time)          +1  Hr" />
																			<asp:ListItem Text="U.K. - Bermuda,    -3 Hr  " />
																			<asp:ListItem Text="U.K. -  Birmingham, (Standard Time Zone)  0 Hr  " />
																			<asp:ListItem Text="U.K. -   Birmingham, (Summer Time)  +1 Hr " />
																			<asp:ListItem Text="U.K. - Falkland Islands, (Standard Time Zone)  -4 Hr  " />
																			<asp:ListItem Text="U.K. - Falkland Islands, (Summer Time)  -3 Hr  " />
																			<asp:ListItem Text="U.K. - Gibraltar, (Standard Time Zone) +1  Hr " />
																			<asp:ListItem Text="U.K. - Gibraltar, (Summer Time)  +2  Hr " />
																			<asp:ListItem Text="U.K. - Grand Cayman, (Standard Time Zone) +1  Hr  " />
																			<asp:ListItem Text="U.K. - Grand Cayman, (Summer Time)  +2  Hr " />
																			<asp:ListItem Text="U.K. - Greenwich  Mean Time      +0  Hr" />
																			<asp:ListItem Text="U.K. - Leeds, (Standard Time Zone)  0 Hr" />
																			<asp:ListItem Text="U.K. -  Leeds, (Summer Time)  +1 Hr  " />
																			<asp:ListItem Text="U.K. -  Liverpool, (Standard Time Zone)  0 Hr" />
																			<asp:ListItem Text="U.K. -  Liverpool, (Summer Time)  +1 Hr  " />
																			<asp:ListItem Text="U.K. - London - Great Britain,  (Standard  Time Zone)          +0  Hr" />
																			<asp:ListItem Text="U.K. - London - Great Britain,  (Summer Time)          +1  Hr" />
																			<asp:ListItem Text="U.K. -  Manchester, (Standard Time Zone)  0 Hr" />
																			<asp:ListItem Text="U.K. -  Manchester, (Summer Time)  +1 Hr  " />
																			<asp:ListItem Text="U.K. - Monserrat,  (Standard  Time Zone)-4  Hr" />
																			<asp:ListItem Text="U.K. - Monserrat,  (Summer Time)-3  Hr  " />
																			<asp:ListItem Text="U.K. -  New Castle, (Standard Time Zone)  0 Hr" />
																			<asp:ListItem Text="U.K. -  New Castle, (Summer Time)  +1 Hr  " />
																			<asp:ListItem Text="U.K. - Northern Ireland,   (Standard  Time Zone)          +0  Hr " />
																			<asp:ListItem Text="U.K. - Northern Ireland,   (Summer Time)          +1  Hr  " />
																			<asp:ListItem Text="U.K. - Pitcairn,   -8  Hr  " />
																			<asp:ListItem Text="U.K. - Scotland,  (Standard  Time Zone)          +0  Hr  " />
																			<asp:ListItem Text="U.K. - Scotland,  (Summer Time)          +1  Hr  " />
																			<asp:ListItem Text="U.K. - Virgin Islands,     -4  Hr  " />
																			<asp:ListItem Text="U.S.A.,  ALaska Time Zone  (Standard Time Zone)  -9 Hr " />
																			<asp:ListItem Text="U.S.A.,  ALaska Time Zone  (Daylight Saving Time)  -8 Hr  " />
																			<asp:ListItem Text="U.S.A.,  Pacific Time Zone  (Standard Time Zone)  -8 Hr" />
																			<asp:ListItem Text="U.S.A.,  Pacific Time Zone  (Daylight Saving Time)  -7 Hr" />
																			<asp:ListItem Text="U.S.A.,  Mountain Time Zone  (Standard Time Zone)    -7 Hr  " />
																			<asp:ListItem Text="U.S.A.,  Mountain Time Zone  (Daylight Saving Time)    -6 Hr " />
																			<asp:ListItem Text="U.S.A., Central Time Zone  (Standard Time Zone)     -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Central Time Zone  (Daylight Saving Time)     -5 Hr " />
																			<asp:ListItem Text="U.S.A.,  Eastern Time Zone  (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Eastern Time Zone  (Daylight Saving Time)    -4 Hr" />
																			<asp:ListItem Text="U.S.A., American Samoa  -11 Hr" />
																			<asp:ListItem Text="U.S.A., East Indiana  -5 Hr " />
																			<asp:ListItem Text="U.S.A., Johnston Atoll  -10 Hr " />
																			<asp:ListItem Text="U.S.A.,  Palau  +9 Hr " />
																			<asp:ListItem Text="U.S.A., Puerto Rico  -4 Hr " />
																			<asp:ListItem Text="U.S.A., Guam  +10 Hr" />
																			<asp:ListItem Text="U.S.A., North Mariana Islands  +10 Hr " />
																			<asp:ListItem Text="U.S.A.,  Marshall Islands  +12 Hr  " />
																			<asp:ListItem Text="U.S.A., Micronesia, Kosrae   -11 Hr " />
																			<asp:ListItem Text="U.S.A., Micronesia, Ponape(pohnpei)  -11 Hr " />
																			<asp:ListItem Text="U.S.A., Micronesia, Truk(Chuuk)  -10 Hr  " />
																			<asp:ListItem Text="U.S.A., Micronesia, Yap   -10 Hr" />
																			<asp:ListItem Text="U.S.A., Midway Islands   -11 Hr  " />
																			<asp:ListItem Text="U.S.A., Virgin Islands  -4 Hr " />
																			<asp:ListItem Text="U.S.A., Wake Island  +12 Hr " />
																			<asp:ListItem Text="U.S.A., Alabama  (Standard Time Zone)   -6 Hr " />
																			<asp:ListItem Text="U.S.A., Alabama  (Daylight Saving Time)   -5 Hr " />
																			<asp:ListItem Text="U.S.A.,Alaska - Adak - Aleutian Islands (Standard Time Zone)  -10 Hr " />
																			<asp:ListItem Text="U.S.A.,Alaska - Adak - Aleutian Islands (Daylight Saving Time)  -9 Hr  " />
																			<asp:ListItem Text="U.S.A.,Alaska - Anchorage (Standard Time Zone)   -9 Hr" />
																			<asp:ListItem Text="U.S.A.,Alaska - Anchorage (Daylight Saving Time)    -8 Hr " />
																			<asp:ListItem Text="U.S.A.,Alaska - Fairbanks  (Standard Time Zone)  -9 Hr " />
																			<asp:ListItem Text="U.S.A.,Alaska - Fairbanks  (Daylight Saving Time)  -8 Hr   " />
																			<asp:ListItem Text="U.S.A.,Alaska - Juneau  (Standard Time Zone)  -9 Hr" />
																			<asp:ListItem Text="U.S.A.,Alaska - Juneau (Daylight Saving Time)  -8 Hr " />
																			<asp:ListItem Text="U.S.A.,Alaska - Nome (Standard Time Zone)  -9 Hr" />
																			<asp:ListItem Text="U.S.A.,Alaska - Nome (Daylight Saving Time)  -8 Hr " />
																			<asp:ListItem Text="U.S.A.,Alaska - Unalaska (Standard Time Zone)   -9 Hr" />
																			<asp:ListItem Text="U.S.A.,Alaska - Unalaska (Daylight Saving Time)   -8 Hr  " />
																			<asp:ListItem Text="U.S.A.,Alaska - Yakutat - Alaska panhandle neck (Standard Time Zone)  -9 Hr" />
																			<asp:ListItem Text="U.S.A.,Alaska - Yakutat - Alaska panhandle neck (Daylight Saving Time)  -8 Hr  " />
																			<asp:ListItem Text="U.S.A., Arizona -7 Hr  " />
																			<asp:ListItem Text="U.S.A.,  Akansas -6 Hr  " />
																			<asp:ListItem Text="U.S.A.,California (Standard Time Zone)  -8 Hr " />
																			<asp:ListItem Text="U.S.A.,California (Daylight Saving Time)  -7 Hr" />
																			<asp:ListItem Text="U.S.A.,Colorado (Standard Time Zone)   -7 Hr  " />
																			<asp:ListItem Text="U.S.A., Colorado (Daylight Saving Time)   -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Connecticut (Standard Time Zone)   -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Connecticut (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A., Florida - Jacksonville  (Standard Time Zone)   -5 Hr " />
																			<asp:ListItem Text="U.S.A., Florida - Jacksonville   (Daylight Saving Time)  -4 Hr " />
																			<asp:ListItem Text="U.S.A., Florida - Miami (Standard Time Zone)     -5 Hr " />
																			<asp:ListItem Text="U.S.A., Florida - Miami (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="U.S.A., Florida - Pensacola (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Florida - Pensacola (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., Florida - Saint Peterburg (Standard Time Zone)  -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Florida - Saint Peterburg (Daylight Saving Time)  -4 Hr  " />
																			<asp:ListItem Text="U.S.A., Florida -Tampa (Standard Time Zone)   -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Florida -Tampa (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="U.S.A., Georgia (Standard Time Zone)     -5 Hr " />
																			<asp:ListItem Text="U.S.A., Georgia (Daylight Saving Time)    -4 Hr  " />
																			<asp:ListItem Text="U.S.A., Hawaii - Honolulu   +10 Hr " />
																			<asp:ListItem Text="U.S.A., Idaho (Standard Time Zone)   -7 Hr  " />
																			<asp:ListItem Text="U.S.A. Idaho (Daylight Saving Time)    -6 Hr " />
																			<asp:ListItem Text="U.S.A., Illinois (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Illinois (Daylight Saving Time)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Indiana (most locations)  -5  Hr  " />
																			<asp:ListItem Text="U.S.A., Iowa (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Iowa (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., Kansas (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A.,Kansas (Daylight Saving Time)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. Kentucky (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A. Kentucky (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="U.S.A., Louisiana (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Louisiana (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., Maine (Standard Time Zone)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., Maine (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A., Mariana Islands Guam +10 Hr  " />
																			<asp:ListItem Text="U.S.A., Maryland (Standard Time Zone)    -5 Hr " />
																			<asp:ListItem Text="U.S.A., Maryland (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="U.S.A., Massachusetts (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Massachusetts (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A., Michigan (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A., Michigan (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="U.S.A., Minnesota (Standard Time Zone)    -6 Hr" />
																			<asp:ListItem Text="U.S.A., Minnesota (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., Mississippi (Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="U.S.A., Mississippi (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., Missouri (Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="U.S.A., Missouri (Daylight Saving Time)    -5 Hr " />
																			<asp:ListItem Text="U.S.A., Montana (Standard Time Zone)    -7 Hr  " />
																			<asp:ListItem Text="U.S.A., Montana (Daylight Saving Time)    -6 Hr " />
																			<asp:ListItem Text="U.S.A., Nebraska (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A., Nebraska (Daylight Saving Time)    -5 Hr " />
																			<asp:ListItem Text="U.S.A., Nevada (Standard Time Zone)    -9 Hr " />
																			<asp:ListItem Text="U.S.A., Nevada (Daylight Saving Time)    -8 Hr  " />
																			<asp:ListItem Text="U.S.A., New Hampshire (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A., New Hampshire (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="U.S.A., New Jersey (Standard Time Zone)    -5 Hr" />
																			<asp:ListItem Text="U.S.A., New Jersey (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A., New Mexico (Standard Time Zone)    -7 Hr" />
																			<asp:ListItem Text="U.S.A.,  New Mexico (Daylight Saving Time)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A. New York (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A. New York (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A. North Carolina (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A. North Carolina (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A. North Dakota (Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="U.S.A. North Dakota (Daylight Saving Time)    -5 Hr " />
																			<asp:ListItem Text="U.S.A.  Northern Mariana (Standard Time Zone)    +10  Hr  " />
																			<asp:ListItem Text="U.S.A.  Northern Mariana (Daylight Saving Time)    +11  Hr  " />
																			<asp:ListItem Text="U.S.A. Ohio (Standard Time Zone)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. Ohio (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="U.S.A. Oklahoma (Standard Time Zone)    -6 Hr" />
																			<asp:ListItem Text="U.S.A. Oklahoma (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A. Oregon (Standard Time Zone)    -8 Hr " />
																			<asp:ListItem Text="U.S.A. Oregon (Daylight Saving Time)    -7 Hr " />
																			<asp:ListItem Text="U.S.A. Pennsylvania (Standard Time Zone)    -5 Hr" />
																			<asp:ListItem Text="U.S.A. Pennsylvania (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A. Rhode Island (Standard Time Zone)    -5 Hr" />
																			<asp:ListItem Text="U.S.A. Rhode Island (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="U.S.A. South Carolina (Standard Time Zone)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. South Carolina (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="U.S.A.South Dakota (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A.South Dakota (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A.Tennessee (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A.Tennessee (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A. Texas,Arlington (Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="U.S.A. Texas,Arlington (Daylight Saving Time)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A. Texas,Austin (Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="U.S.A. Texas,Austin (Daylight Saving Time)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. Texas,Dallas (Standard Time Zone)    -6 Hr" />
																			<asp:ListItem Text="U.S.A. Texas,Dallas (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A. Texas, El Paso (Standard Time Zone)   -7 Hr" />
																			<asp:ListItem Text="U.S.A. Texas, El Paso (Daylight Saving Time)    -6 Hr" />
																			<asp:ListItem Text="U.S.A. Texas,Houston (Standard Time Zone)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A. Texas,Houston (Daylight Saving Time)    -5 Hr" />
																			<asp:ListItem Text="U.S.A. Utah (Standard Time Zone)    -7 Hr" />
																			<asp:ListItem Text="U.S.A. Utah (Daylight Saving Time)    -6 Hr" />
																			<asp:ListItem Text="U.S.A. Vermont (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A. Vermont (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A. Virginia (Standard Time Zone)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. Virginia (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="U.S.A. Washington-Seattle (Standard Time Zone)    -8 Hr" />
																			<asp:ListItem Text="U.S.A. Washington-Seattle (Daylight Saving Time)   -7 Hr  " />
																			<asp:ListItem Text="U.S.A. Washington-D.C.  (Standard Time Zone)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. Washington-D.C.  (Daylight Saving Time)   -4 Hr" />
																			<asp:ListItem Text="U.S.A. West Virginia   (Standard Time Zone)    -5 Hr  " />
																			<asp:ListItem Text="U.S.A. West Virginia   (Daylight Saving Time)   -4 Hr " />
																			<asp:ListItem Text="U.S.A. Wisconsin  (Standard Time Zone)    -6 Hr " />
																			<asp:ListItem Text="U.S.A. Wisconsin  (Daylight Saving Time)   -5 Hr  " />
																			<asp:ListItem Text="U.S.A. Wyoming  (Standard Time Zone)    -7 Hr  " />
																			<asp:ListItem Text="U.S.A. Wyoming  (Daylight Saving Time)    -6 Hr  " />
																			<asp:ListItem Text="U.S.A. Bahamas (Standard Time Zone)    -3 Hr" />
																			<asp:ListItem Text="U.S.A. Bahamas (Daylight Saving Time)    -2 Hr  " />
																			<asp:ListItem Text="U.S.A. Boston  (Standard Time Zone)    -5 Hr " />
																			<asp:ListItem Text="U.S.A. Boston  (Daylight Saving Time)   -4 Hr  " />
																			<asp:ListItem Text="U.S.A.,Boise - south Idaho & east Oregon (Standard Time Zone)  -7 Hr" />
																			<asp:ListItem Text="U.S.A.,Boise - south Idaho & east Oregon (Daylight Saving Time)  -6 Hr " />
																			<asp:ListItem Text="U.S.A.Cleveland, Ohio  -5 Hr" />
																			<asp:ListItem Text="U.S.A.,Chicago (Standard Time Zone)  -6 Hr" />
																			<asp:ListItem Text="U.S.A.,Chicago (Daylight Saving Time)  -5 Hr  " />
																			<asp:ListItem Text="U.S.A.,Denver (Standard Time Zone)  -7 Hr  " />
																			<asp:ListItem Text="U.S.A.,Denver (Daylight Saving Time)  -6 Hr   " />
																			<asp:ListItem Text="U.S.A.,Detroit - Michigan  (Standard Time Zone)  -5 Hr" />
																			<asp:ListItem Text="U.S.A.,Detroit - Michigan  (Daylight Saving Time)  -4 Hr   " />
																			<asp:ListItem Text="U.S.A.,    Hawaii Honolulu +10 Hr " />
																			<asp:ListItem Text="U.S.A.,Indianapolis - Indiana (most locations)  -5  Hr " />
																			<asp:ListItem Text="U.S.A.,Juneau - Alaska panhandle (Standard Time Zone)  -9 Hr " />
																			<asp:ListItem Text="U.S.A.,Juneau - Alaska panhandle (Daylight Saving Time)  -8 Hr " />
																			<asp:ListItem Text="U.S.A.,Knox - Indiana - Starke County -5 Hr " />
																			<asp:ListItem Text="U.S.A.,Los Angeles (Standard Time Zone)  -8 Hr" />
																			<asp:ListItem Text="U.S.A.,Los Angeles (Daylight Saving Time)  -7 Hr " />
																			<asp:ListItem Text="U.S.A.,Louisville - Kentucky (Standard Time Zone)  -5 Hr" />
																			<asp:ListItem Text="U.S.A.,Louisville - Kentucky (Daylight Saving Time)  -4 Hr  " />
																			<asp:ListItem Text="U.S.A.,Marengo - Indiana - Crawford County -5 Hr " />
																			<asp:ListItem Text="U.S.A.,Menominee - Michigan -Wisconsin border (Standard Time Zone)  -6 Hr " />
																			<asp:ListItem Text="U.S.A.,Menominee - Michigan -Wisconsin border (Daylight Saving Time)  -5 Hr" />
																			<asp:ListItem Text="U.S.A.      Mexico -6 Hr " />
																			<asp:ListItem Text="U.S.A.      New Orleans -6 Hr " />
																			<asp:ListItem Text="U.S.A.,New York  (Standard Time Zone)  -5 Hr  " />
																			<asp:ListItem Text="U.S.A.,New York  (Daylight Saving Time)  -4 Hr  " />
																			<asp:ListItem Text="U.S.A.,Phoenix - Arizona  -7 Hr" />
																			<asp:ListItem Text="U.S.A.    Philadelphia  (Standard Time Zone)  -5 Hr" />
																			<asp:ListItem Text="U.S.A.    Philadelphia  (Daylight Saving Time)  -4 Hr" />
																			<asp:ListItem Text="U.S.A.  San Francisco  (Standard Time Zone)  -8 Hr  " />
																			<asp:ListItem Text="U.S.A.  San Francisco  (Daylight Saving Time)  -7 Hr  " />
																			<asp:ListItem Text="U.S.A.,Shiprock - Navajo (Standard Time Zone)  -7 Hr " />
																			<asp:ListItem Text="U.S.A.,Shiprock - Navajo (Daylight Saving Time)  -6 Hr   " />
																			<asp:ListItem Text="U.S.A.  Virgin Islands  -4   Hr" />
																			<asp:ListItem Text="U.S.A.,Vevay - Indiana - Switzerland County  -5 Hr  " />
																			<asp:ListItem Text="U.S.S.R.   Leningrad  +3 Hr" />
																			<asp:ListItem Text="U.S.S.R.       Moscow +3 Hr" />
																			<asp:ListItem Text="U.S.S.R.       Taskent  +6 Hr" />
																			<asp:ListItem Text="U.S.S.R.   Volgograd  +4 Hr" />
																			<asp:ListItem Text="Uganda, +3  Hr " />
																			<asp:ListItem Text="Ukraine, (Standard Time Zone),   +2 Hr " />
																			<asp:ListItem Text="Ukraine, (Daylight Saving Time),   +3 Hr " />
																			<asp:ListItem Text="United Arab Emirates    +4 Hr" />
																			<asp:ListItem Text="Uruguay    -3 Hr" />
																			<asp:ListItem Text="Uzbekistan    +5 Hr " />
																			<asp:ListItem Text="Vanuatu    +11 Hr" />
																			<asp:ListItem Text="Vatican City State , (Standard Time Zone),           +1 Hr" />
																			<asp:ListItem Text="Vatican City State , (Daylight Saving Time),           +2 Hr " />
																			<asp:ListItem Text="Venezuela   -4 Hr" />
																			<asp:ListItem Text="Vietnam       +7 Hr " />
																			<asp:ListItem Text=" Virgin Islands(British) , -4  Hr" />
																			<asp:ListItem Text=" Virgin Islands(U.S.A.) , -4  Hr  " />
																			<asp:ListItem Text="Wallis and Futuna Islands  +12 Hr " />
																			<asp:ListItem Text="Western Sahara   +0 Hr  " />
																			<asp:ListItem Text="West Indies,   -5 Hr" />
																			<asp:ListItem Text="Yemen +3 Hr " />
																			<asp:ListItem Text="Yugoslavia - Serbia, (Standard Time Zone),           +1 Hr " />
																			<asp:ListItem Text="Yugoslavia - Serbia, (Daylight Saving Time),           +2 Hr  " />
																			<asp:ListItem Text="Zambia     +2 Hr" />
																			<asp:ListItem Text="Zimbabwe   +2 Hr" />
																		</asp:dropdownlist>
																	</TD>
																</TR>
																<TR>
																	<TD style="HEIGHT: 20px" width="120">
																		�����
																	</TD>
																	<TD style="HEIGHT: 20px">
																		<asp:dropdownlist id="country" Runat="server">
																			<asp:ListItem Text="none" />
																			<asp:ListItem Text="��ա" />
																			<asp:ListItem Text="��չҴ�" />
																			<asp:ListItem Text="���" />
																			<asp:ListItem Text="����٪�" />
																			<asp:ListItem Text="����ҹ�" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="�ҵ���" />
																			<asp:ListItem Text="�ҹ�" />
																			<asp:ListItem Text="���Ժҵ�" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="������˹��" />
																			<asp:ListItem Text="��ʵ��ԡ�" />
																			<asp:ListItem Text="��Ǻ�" />
																			<asp:ListItem Text="���Ҥ��" />
																			<asp:ListItem Text="���ǵ" />
																			<asp:ListItem Text="ह��" />
																			<asp:ListItem Text="᤹Ҵ�" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="����ᴹ" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="�Ժ��ŵ���" />
																			<asp:ListItem Text="�չ" />
																			<asp:ListItem Text="����" />
																			<asp:ListItem Text="�ͧ����ǫ�" />
																			<asp:ListItem Text="�����" />
																			<asp:ListItem Text="���ش�������" />
																			<asp:ListItem Text="����Ѻ��" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="�ٴҹ" />
																			<asp:ListItem Text="���Թ���" />
																			<asp:ListItem Text="ૹ�� �Ե�� �͹�� ����" />
																			<asp:ListItem Text="ૹ�� ����෹" />
																			<asp:ListItem Text="ૹ�� ��ʵҵ����" />
																			<asp:ListItem Text="ૹ������" />
																			<asp:ListItem Text="ૹ�������" />
																			<asp:ListItem Text="ૹ���Թૹ��" />
																			<asp:ListItem Text="䫻���" />
																			<asp:ListItem Text="�����" />
																			<asp:ListItem Text="�Թᴹ�����ط��Թ�����觺�ԵԪ" />
																			<asp:ListItem Text="ഹ����" />
																			<asp:ListItem Text="��Թԡ�" />
																			<asp:ListItem Text="��չ�ഴ" />
																			<asp:ListItem Text="�ͧ�" />
																			<asp:ListItem Text="��á�" />
																			<asp:ListItem Text="�ٹ����" />
																			<asp:ListItem Text="��������ʶҹ" />
																			<asp:ListItem Text="����ѹ" />
																			<asp:ListItem Text="�ҹ����" />
																			<asp:ListItem Text="��" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�Ԥ��ҡ��" />
																			<asp:ListItem Text="��Ǥ�������" />
																			<asp:ListItem Text="��ǫ��Ź��" />
																			<asp:ListItem Text="������Ź��" />
																			<asp:ListItem Text="������Ź���͹������" />
																			<asp:ListItem Text="๻��" />
																			<asp:ListItem Text="����" />
																			<asp:ListItem Text="����" />
																			<asp:ListItem Text="乨�����" />
																			<asp:ListItem Text="��ҫ��" />
																			<asp:ListItem Text="���� ����������" />
																			<asp:ListItem Text="�ͷ��ҹ�" />
																			<asp:ListItem Text="�ѧ�����" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="����Ҵ��" />
																			<asp:ListItem Text="�����ù" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="���ë�" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="�����ٴ�" />
																			<asp:ListItem Text="����" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�ҡ�ʶҹ" />
																			<asp:ListItem Text="�ҹ���" />
																			<asp:ListItem Text="�һ�ǹ�ǡչ�" />
																			<asp:ListItem Text="���ҡ���" />
																			<asp:ListItem Text="�����" />
																			<asp:ListItem Text="���" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="�õ���" />
																			<asp:ListItem Text="��Ź��" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�Ԩ�" />
																			<asp:ListItem Text="�Թ�Ź��" />
																			<asp:ListItem Text="���Ի�Թ��" />
																			<asp:ListItem Text="�ù�� ��ҹ�" />
																			<asp:ListItem Text="�ٯҹ" />
																			<asp:ListItem Text="�ͧ�����" />
																			<asp:ListItem Text="�͹�����Ѱ" />
																			<asp:ListItem Text="�����Է��" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="��ŵ�" />
																			<asp:ListItem Text="��ŴԿ��" />
																			<asp:ListItem Text="�����" />
																			<asp:ListItem Text="����ԹԤ" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="���¹�����" />
																			<asp:ListItem Text="������ԡ" />
																			<asp:ListItem Text="���͡�" />
																			<asp:ListItem Text="���ù����" />
																			<asp:ListItem Text="���ù" />
																			<asp:ListItem Text="�����" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="������˹��" />
																			<asp:ListItem Text="�����ѹ" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�ѡ�������" />
																			<asp:ListItem Text="�ѷ����" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="�����" />
																			<asp:ListItem Text="�źҹ͹" />
																			<asp:ListItem Text="������" />
																			<asp:ListItem Text="���ҵ�" />
																			<asp:ListItem Text="��๫�����" />
																			<asp:ListItem Text="�����Թ �����Ź�� ��ԵԪ" />
																			<asp:ListItem Text="���´���" />
																			<asp:ListItem Text="����ѧ��" />
																			<asp:ListItem Text="�໹" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="��ҫ��Ź��" />
																			<asp:ListItem Text="���������Ź��" />
																			<asp:ListItem Text="���ഹ" />
																			<asp:ListItem Text="�˾ѹ��Ѱ������" />
																			<asp:ListItem Text="���Ѱ����ԡ�" />
																			<asp:ListItem Text="���Ѱ����Ѻ�����÷��" />
																			<asp:ListItem Text="�Ҹ�ó�Ѱ��ի" />
																			<asp:ListItem Text="�Ҹ�ó�Ѱ��Թԡѹ" />
																			<asp:ListItem Text="�ԧ����" />
																			<asp:ListItem Text="������Фء" />
																			<asp:ListItem Text="�������������" />
																			<asp:ListItem Text="��������Ҹ�������᫹�Ԫ" />
																			<asp:ListItem Text="�����������͹" />
																			<asp:ListItem Text="������������͹" />
																			<asp:ListItem Text="������й������������¹�" />
																			<asp:ListItem Text="���������������" />
																			<asp:ListItem Text="���������" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�ѧ���" />
																			<asp:ListItem Text="�ѧ�����" />
																			<asp:ListItem Text="�ѹ�ԡ����к���ٴ�" />
																			<asp:ListItem Text="����ਹ�Թ�" />
																			<asp:ListItem Text="���������" />
																			<asp:ListItem Text="���ٺ�" />
																			<asp:ListItem Text="�Ե���" />
																			<asp:ListItem Text="�Թ���" />
																			<asp:ListItem Text="�Թⴹ����" />
																			<asp:ListItem Text="��������" />
																			<asp:ListItem Text="�����ҹ" />
																			<asp:ListItem Text="���Ի��" />
																			<asp:ListItem Text="���ء���" />
																			<asp:ListItem Text="�١�Ŵ�" />
																			<asp:ListItem Text="�͡�Ҵ���" />
																			<asp:ListItem Text="�͸������" />
																			<asp:ListItem Text="�����Ҵ���" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="�Ϳ�ԡ���" />
																			<asp:ListItem Text="��Ũ�����" />
																			<asp:ListItem Text="�������" />
																			<asp:ListItem Text="���ҹ" />
																			<asp:ListItem Text="�ͫ��Ź��" />
																			<asp:ListItem Text="���Ź��" />
																			<asp:ListItem Text="��ͧ��" />
																			<asp:ListItem Text="�͹�����" />
																			<asp:ListItem Text="�ѧ����" />
																			<asp:ListItem Text="�ε�" />
																		</asp:dropdownlist>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		��
																	</TD>
																	<TD>
																		<asp:textbox id="sex" runat="server" Visible="False"></asp:textbox>
																		<asp:radiobutton id="sex1" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" Runat="server" text="���" checked="True" groupname="sex"></asp:radiobutton>
																		<asp:radiobutton id="sex2" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" Runat="server" text="˭ԧ" groupname="sex"></asp:radiobutton>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		�ѹ/��͹/���Դ
																	</TD>
																	<TD>
																		<asp:dropdownlist id="dobdate" Runat="server">
																			<asp:ListItem Text="none" />
																			<asp:ListItem Text="1" />
																			<asp:ListItem Text="2" />
																			<asp:ListItem Text="3" />
																			<asp:ListItem Text="4" />
																			<asp:ListItem Text="5" />
																			<asp:ListItem Text="6" />
																			<asp:ListItem Text="7" />
																			<asp:ListItem Text="8" />
																			<asp:ListItem Text="9" />
																			<asp:ListItem Text="10" />
																			<asp:ListItem Text="11" />
																			<asp:ListItem Text="12" />
																			<asp:ListItem Text="13" />
																			<asp:ListItem Text="14" />
																			<asp:ListItem Text="15" />
																			<asp:ListItem Text="16" />
																			<asp:ListItem Text="17" />
																			<asp:ListItem Text="18" />
																			<asp:ListItem Text="19" />
																			<asp:ListItem Text="20" />
																			<asp:ListItem Text="21" />
																			<asp:ListItem Text="22" />
																			<asp:ListItem Text="23" />
																			<asp:ListItem Text="24" />
																			<asp:ListItem Text="25" />
																			<asp:ListItem Text="26" />
																			<asp:ListItem Text="27" />
																			<asp:ListItem Text="28" />
																			<asp:ListItem Text="29" />
																			<asp:ListItem Text="30" />
																			<asp:ListItem Text="31" />
																		</asp:dropdownlist>
																		&nbsp;
																		<asp:dropdownlist id="dobmonth" Runat="server">
																			<asp:ListItem Text="none" Value="0" />
																			<asp:ListItem Text="���Ҥ�" Value="1" />
																			<asp:ListItem Text="����Ҿѹ��" Value="2" />
																			<asp:ListItem Text="�չҤ�" Value="3" />
																			<asp:ListItem Text="����¹" Value="4" />
																			<asp:ListItem Text="����Ҥ�" Value="5" />
																			<asp:ListItem Text="�Զع�¹" Value="6" />
																			<asp:ListItem Text="�á�Ҥ�" Value="7" />
																			<asp:ListItem Text="�ԧ�Ҥ�" Value="8" />
																			<asp:ListItem Text="�ѹ��¹" Value="9" />
																			<asp:ListItem Text="���Ҥ�" Value="10" />
																			<asp:ListItem Text="��Ȩԡ�¹" Value="11" />
																			<asp:ListItem Text="�ѹ�Ҥ�" Value="12" />
																		</asp:dropdownlist>
																		&nbsp;�.�.
																		<asp:dropdownlist id="dobyear" Runat="server">
																			<asp:ListItem Text="none" />
																			<asp:ListItem Text="1941" />
																			<asp:ListItem Text="1942" />
																			<asp:ListItem Text="1943" />
																			<asp:ListItem Text="1944" />
																			<asp:ListItem Text="1945" />
																			<asp:ListItem Text="1946" />
																			<asp:ListItem Text="1947" />
																			<asp:ListItem Text="1948" />
																			<asp:ListItem Text="1949" />
																			<asp:ListItem Text="1950" />
																			<asp:ListItem Text="1951" />
																			<asp:ListItem Text="1952" />
																			<asp:ListItem Text="1953" />
																			<asp:ListItem Text="1954" />
																			<asp:ListItem Text="1955" />
																			<asp:ListItem Text="1956" />
																			<asp:ListItem Text="1957" />
																			<asp:ListItem Text="1958" />
																			<asp:ListItem Text="1959" />
																			<asp:ListItem Text="1960" />
																			<asp:ListItem Text="1961" />
																			<asp:ListItem Text="1962" />
																			<asp:ListItem Text="1963" />
																			<asp:ListItem Text="1964" />
																			<asp:ListItem Text="1965" />
																			<asp:ListItem Text="1966" />
																			<asp:ListItem Text="1967" />
																			<asp:ListItem Text="1968" />
																			<asp:ListItem Text="1969" />
																			<asp:ListItem Text="1970" />
																			<asp:ListItem Text="1971" />
																			<asp:ListItem Text="1972" />
																			<asp:ListItem Text="1973" />
																			<asp:ListItem Text="1974" />
																			<asp:ListItem Text="1975" />
																			<asp:ListItem Text="1976" />
																			<asp:ListItem Text="1977" />
																			<asp:ListItem Text="1978" />
																			<asp:ListItem Text="1979" />
																			<asp:ListItem Text="1980" />
																			<asp:ListItem Text="1981" />
																			<asp:ListItem Text="1982" />
																			<asp:ListItem Text="1983" />
																			<asp:ListItem Text="1984" />
																			<asp:ListItem Text="1985" />
																			<asp:ListItem Text="1986" />
																			<asp:ListItem Text="1987" />
																			<asp:ListItem Text="1988" />
																			<asp:ListItem Text="1989" />
																			<asp:ListItem Text="1990" />
																			<asp:ListItem Text="1991" />
																			<asp:ListItem Text="1992" />
																			<asp:ListItem Text="1993" />
																			<asp:ListItem Text="1994" />
																			<asp:ListItem Text="1995" />
																			<asp:ListItem Text="1996" />
																			<asp:ListItem Text="1997" />
																			<asp:ListItem Text="1998" />
																			<asp:ListItem Text="1999" />
																			<asp:ListItem Text="2000" />
																			<asp:ListItem Text="2001" />
																			<asp:ListItem Text="2002" />
																		</asp:dropdownlist>
																		<asp:label id="Label8" ForeColor="Red" runat="server" Visible="False">Label</asp:label>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																		�Ҫվ
																	</TD>
																	<TD>
																		<asp:dropdownlist id="Occupation" Runat="server">
																			<asp:ListItem Text="none" />
																			<asp:ListItem Text="��úѭ��/����Թ" />
																			<asp:ListItem Text="�Ǵǧ���������� (��� �)" />
																			<asp:ListItem Text="�Ǵǧ���������� (�Թ������)" />
																			<asp:ListItem Text="����֡��" />
																			<asp:ListItem Text="��ԡ��/ʹѺʹع�١���" />
																			<asp:ListItem Text="����֡��/��ý֡ͺ��" />
																			<asp:ListItem Text="���ǡ�" />
																			<asp:ListItem Text="��èѴ����дѺ������/������" />
																			<asp:ListItem Text="������/������ҹ�����" />
																			<asp:ListItem Text="�����ú�ҹ���ͧ/����ͧ͸Ի��" />
																			<asp:ListItem Text="�Ѻ���ҡ�����ҧ" />
																			<asp:ListItem Text="�ص��ˡ�����ü�Ե/��ü�Ե/��û�Ժѵԡ��" />
																			<asp:ListItem Text="�ԪҪվ �ҧ���ᾷ�� �ҧ������ ������ �)" />
																			<asp:ListItem Text="����Ԩ����оѲ��" />
																			<asp:ListItem Text="���³" />
																			<asp:ListItem Text="��â��/��õ�Ҵ/����ɳ�" />
																			<asp:ListItem Text="�Ҫվ�����/��Ңͧ�Ԩ���" />
																			<asp:ListItem Text="�ѡ�֡��" />
																			<asp:ListItem Text="��ͤ��/��ҧ�����" />
																			<asp:ListItem Text="��ҧ�ҹ/�ͧҹ����" />
																			<asp:ListItem Text="��� �" />
																		</asp:dropdownlist>
																	</TD>
																</TR>
																<TR>
																	<TD width="120">
																	</TD>
																	<TD>
																	</TD>
																</TR>
																&nbsp;
																<TR>
																	<TD>
																	</TD>
																	<TD>
																		<asp:button id="submit1" runat="server" Text="��Ѻ��ا"></asp:button>
																		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																	</TD>
																</TR>
														</FORM>
													</TABLE> <!-- End Form Area -->
												</TD>
											</TR> <!-- Copyright Bar -->
											<TR align="middle" bgColor="#0e1c96">
												<TD class="verdana" vAlign="top" bgColor="#ffffff">
													<asp:hyperlink id="HyperLink1" runat="server" NavigateUrl="memberservice.aspx">��Ѻ�˹���к���ԡ����Ҫԡ</asp:hyperlink>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
							</TABLE>
						</TD>
						<TD style="WIDTH: 108px" bgColor="#0033cc" rowSpan="3">
							<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
								<TR>
									<TD height="21">
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
					</TBODY>
				</TABLE>
			</P>
			</TABLE>
			<P align="center">
			</P>
		</FONT>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">
			<A style="FONT-SIZE: 10pt" href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A> |&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx">˹���á 
				Passport System</A>
		</P>
	</body>
</HTML>
