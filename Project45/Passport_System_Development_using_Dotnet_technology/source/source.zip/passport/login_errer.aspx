<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="System.Data.SqlClient"%>

<HTML>
  <HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
  </HEAD>
	<body leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
		<!-- Center Area -->
		<P align="center">
		</P>
		<FONT color="#006666">
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TR>
						<TD width="100%">
							<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
								<TR>
									<TD vAlign="center" align="left" width="468">
										<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
									</TD>
									<TD vAlign="center" align="right" width="140">
										<A href="main.aspx"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
										</A>
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</P>
			<P align="center">
				<TABLE class="box1" height="322" cellSpacing="0" cellPadding="0" width="605" bgColor="antiquewhite" border="2">
					<FORM id="Form1" name="fsign" action="webform8.aspx" method="post" runat="server">
						<TBODY>
							<TR>
								<TD bgColor="#ffffff">
									<TABLE height="284" width="100%" border="0">
										<TBODY>
											<TR>
												<TD style="WIDTH: 529px" align="left" bgColor="#0033cc" colSpan="2">
													<STRONG>&nbsp;<FONT color="#ffffff"> &nbsp;</FONT></STRONG><FONT color="#ffffff"><STRONG>�ѭ��&nbsp;Passport 
															�١�Դ�����&nbsp;<FONT color="#ffffff">&nbsp;</FONT></STRONG><FONT color="#ffffff"><STRONG>ŧ��������� 
																Passport</STRONG></FONT>
														<BR></STRONG></FONT>
												</TD>
											</TR>
											<TR>
												<TD align="left" bgColor="#ffffff" colSpan="2">
													<P align="center">
														&nbsp;<FONT class="PPErrBoldTxt" color="red" size="4">�س��ӡ��ŧ����������������������ͧ�ҡ�Ҩ�Դ�ҡ�����Դ��Ҵ㹡����������</FONT>
													</P>
													<P align="center">
														<STRONG></STRONG>
													</P>
													<STRONG></STRONG>
													<P align="center">
													</P>
												</TD>
											</TR>
											<FONT color="#ffffff"><STRONG><FONT color="#0033cc"></FONT></STRONG>
												<P align="center">
												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P>
											</P>
											<P align="center">
											</P>
											<P>
											</P>
											<P align="center">
											</P>
											<TR>
												<TD align="left" bgColor="#ffffff" colSpan="2">
													<P align="left">
														<B><FONT size="4">�س����ö:</FONT></B>&nbsp;&nbsp; <FONT color="red">
													</P>
		</FONT></TD></TR></P>
		<TR>
			<TD align="left" bgColor="#ffffff" colSpan="2">
				<UL>
					<LI>
						<DIV align="left">
							�ô���ѡ���� �����ͧ&nbsp;<U><a href="login.aspx" ><FONT color="green" 6ff?>ŧ���������</FONT></a></U> &nbsp;�ա����
						</DIV>
					</LI>
				</UL>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 258px">
				<P align="left">
				</P>
			</TD>
		</TR>
		<TR>
			<TD style="WIDTH: 258px" align="middle">
				<P align="center">
				</P>
			</TD>
		</TR></TBODY></TABLE></TD></TR></FORM></TBODY></TABLE></P></FONT>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">&nbsp;<A style="FONT-SIZE: 10pt" 
href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A> |&nbsp;<A 
style="FONT-SIZE: 10pt" href="main.aspx">˹���á Passport </A>
		</P>
	</body>
</HTML>