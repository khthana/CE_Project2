Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.Text
Public Class del_passport_confirm
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Dim myConnString As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Label1.Text = Request.Cookies("passport").Value
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Response.Redirect("memberservice")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Label2.Visible = False


        If TextBox2.Text <> "" Then


            Dim dtCmd As SqlDataAdapter
            Dim dtSet As New DataSet()
            Dim myConnString As String

            myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnString)
            myConnection.Open()
            mySelectQuery = "SELECT * from member where email = '" & Request.Cookies("passport").Value & "' and password='" & TextBox2.Text & "' "
            dtCmd = New SqlDataAdapter(mySelectQuery, myConnection)
            dtCmd.Fill(dtSet)
            If dtSet.Tables(0).Rows.Count = 1 Then

                mySelectQuery = "delete member " & _
                " where email = '" & Request.Cookies("passport").Value & "'"
                myCommand = New SqlCommand(mySelectQuery, myConnection)
                myCommand.ExecuteNonQuery()

                mySelectQuery = "delete biography " & _
                " where email = '" & Request.Cookies("passport").Value & "'"
                myCommand = New SqlCommand(mySelectQuery, myConnection)
                myCommand.ExecuteNonQuery()

                mySelectQuery = "delete secret " & _
                " where email = '" & Request.Cookies("passport").Value & "'"
                myCommand = New SqlCommand(mySelectQuery, myConnection)
                myCommand.ExecuteNonQuery()

                Response.Redirect("del_passport_complete.aspx")
            Else
                Label2.Text = "email ���� password ����͡���١��ͧ ��سҡ�͡�����ա���� !"
                Label2.Visible = True
            End If

        Else
                If TextBox2.Text = "" Then
                    Label2.Text = "�س������͡ Password !"
                    Label2.Visible = "true"
                End If


        End If
    End Sub
End Class
