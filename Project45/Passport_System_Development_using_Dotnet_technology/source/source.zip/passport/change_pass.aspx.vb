Imports System.Data.SqlClient
Imports System.Data
Imports Encryption
Imports System.Text
Public Class change_pass
    Inherits System.Web.UI.Page
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
            Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
        Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Textbox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Textbox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents fsign As System.Web.UI.HtmlControls.HtmlForm

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Dim myConnString As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Label1.Text = Request.Cookies("passport").Value
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Label2.Visible = False
        Label3.Visible = False
        Label4.Visible = False

        Dim check As String = "@"
        Dim p1 As String = TextBox3.Text
        Dim p2 As String = TextBox4.Text
        Dim temp1 As Integer = Len(p1)
        Dim temp2 As Integer = Len(p2)

        If Textbox2.Text <> "" And TextBox3.Text <> "" And TextBox4.Text <> "" Then
           
            Label1.Visible = "false"
            Label2.Visible = "false"
            Label3.Visible = "false"

            If temp1 < 6 Or temp2 < 6 Then
                If temp1 < 6 Then
                    Label3.Text = "��سҡ�͡ Password ���ҧ���� 6 ��� !"
                    Label3.Visible = "true"
                End If
                If temp2 < 6 Then
                    Label4.Text = "��سҡ�͡ Password	�׹�ѹ�Դ ���ҧ���� 6 ��� !"
                    Label4.Visible = "true"
                End If

            ElseIf p1 <> p2 Then
                Label3.Text = "�س��͡ Password	���ç�ѹ !"
                Label3.Visible = "true"
                Label4.Text = "�س��͡ Password	�׹�ѹ ���ç�ѹ !"
                Label4.Visible = "true"

            Else
                Dim dtCmd As SqlDataAdapter
                Dim dtSet As New DataSet()
                Dim myConnString As String

                myConnString = "server=localhost;database=passport;Trusted_Connection=yes"
                myConnection = New SqlConnection(myConnString)
                myConnection.Open()
                mySelectQuery = "SELECT * from member where email = '" & Request.Cookies("passport").Value & "' and password='" & Textbox2.Text & "' "
                dtCmd = New SqlDataAdapter(mySelectQuery, myConnection)
                dtCmd.Fill(dtSet)

                If dtSet.Tables(0).Rows.Count = 1 Then

                    mySelectQuery = "update member " & _
                  " set password = '" & TextBox3.Text & "'" & _
                  " where email = '" & Request.Cookies("passport").Value & "'"

                    myCommand = New SqlCommand(mySelectQuery, myConnection)
                    myCommand.ExecuteNonQuery()

                    Response.Redirect("change_pass_complete.aspx")
                End If
                Label2.Text = "email ���� password ����͡���١��ͧ ��سҡ�͡�����ա���� !"
                Label2.Visible = True
            End If
        Else
            If Textbox2.Text = "" Then
                Label2.Text = "�س������͡ Password !"
                Label2.Visible = "true"
            End If
            If TextBox3.Text = "" Then
                Label3.Text = "�س������͡ Password ���� !"
                Label3.Visible = "true"
            End If
            If TextBox4.Text = "" Then
                Label4.Text = "�س������͡ �����׹�ѹ Password ���� !"
                Label4.Visible = "true"
            End If


        End If
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class
