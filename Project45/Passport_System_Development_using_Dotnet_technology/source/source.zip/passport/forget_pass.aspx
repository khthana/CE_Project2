<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Page Language="vb" AutoEventWireup="false" Codebehind="forget_pass.aspx.vb" Inherits="passport.forget_pass"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
		<!-- Center Area -->
		<P align="center">
		</P>
		<FONT color="#006666">
			<P align="center">
				<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
					<TBODY>
						<TR>
							<TD width="100%">
								<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
									<TR>
										<TD vAlign="center" align="left" width="468">
											<IMG height="60" alt="����ҳ�ࢵ�ͧ .NET Passport" src="image\head.jpg" width="468" border="0">
										</TD>
										<TD vAlign="center" align="right" width="140">
											<A href="main.aspx"><IMG height="44" alt="Passport System" src="image\passport.jpg" width="140" border="0">
											</A>
										</TD>
									</TR>
								</TABLE>
								<TABLE cellSpacing="0" cellPadding="0" width="608" border="0">
									<TBODY>
										<TR>
											<TD bgColor="#0033cc" rowSpan="3">
												<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
													<TR>
														<TD height="21">
														</TD>
													</TR>
												</TABLE>
											</TD>
											<TD bgColor="#ffffff">
												<TABLE cellSpacing="0" cellPadding="0" width="606" border="0">
													<TBODY>
														<TR>
															<TD bgColor="#0033cc" height="1">
																<TABLE height="328" cellSpacing="0" cellPadding="3" width="589" border="0">
																	<TBODY>
																		<TR>
																			<TD vAlign="top" align="middle" width="100%"> <!-- Form area -->
																				<TABLE class="box1" height="322" cellSpacing="0" cellPadding="0" width="605" bgColor="antiquewhite" border="0">
																					<FORM id="fsign" name="fsign" action="webform8.aspx" method="post" runat="server">
																						<TBODY>
																							<TR>
																								<TD bgColor="#ffffff">
																									<TABLE height="284" width="100%" border="0">
																										<TBODY>
																											<TR>
																												<TD style="WIDTH: 612px" align="left" bgColor="#0033cc" colSpan="2">
																													<STRONG><FONT color="#ffffff">&nbsp;������ʼ�ҹ</FONT></STRONG>
																													<asp:image id="Image1" runat="server" ImageUrl="image\shop.gif"></asp:image>
																												</TD>
																											</TR>
																											<TR>
																												<TD style="WIDTH: 612px" align="left" bgColor="#ffffff" colSpan="2">
																													<P>
																														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; �ҡ������ʼ�ҹ�ѭ��&nbsp; 
																														Passport �ͧ�س ��س� ��ԡ������ <STRONG>�����ʼ�ҹ</STRONG> ���������ʼ�ҹ��ѧ 
																														Email address ���س��ŧ����¹�Ѻ�ҧ Passport �ͧ��� ���ͤ�����ʹ��¢ͧ 
																														�ѭ�� passport �ͧ�س&nbsp;
																													</P>
																												</TD>
																												<TD rowSpan="3">
																												</TD>
																											</TR>
																											<FONT color="#ffffff"><STRONG><FONT color="#0033cc"></FONT></STRONG>
																												<P>
																												&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT>
																											<P>
																											</P>
																											<P>
																											</P>
																											<TR>
																												<TD style="WIDTH: 126px" align="left" bgColor="#ffffff">
																													<P align="center">
																														&nbsp;Email :
																													</P>
																												</TD>
																												<TD style="WIDTH: 646px" align="left" bgColor="#ffffff">
																													<P>
																														<asp:textbox id="TextBox1" runat="server"></asp:textbox>
																														<asp:regularexpressionvalidator id="CheckEmail2" runat="server" ValidationExpression="\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*" Display="Dynamic" ControlToValidate="textbox1" ErrorMessage="<br>E-mail Address not Completed"></asp:regularexpressionvalidator>
																													</P>
																												</TD>
																												<TD style="WIDTH: 612px" align="left" bgColor="#ffffff" colSpan="2">
																												</TD>
																												<TD>
																												</TD>
																											</TR>
																											<TR>
																												<TD style="WIDTH: 126px" align="left" bgColor="#ffffff">
																												</TD>
																												<TD style="WIDTH: 646px" align="left" bgColor="#ffffff">
																													<asp:label id="Label1" runat="server" ForeColor="Red" Visible="False">Label</asp:label>
																												</TD>
																												<TD style="WIDTH: 612px" align="left" bgColor="#ffffff" colSpan="2">
																												</TD>
																												<TD>
																												</TD>
																											</TR>
																											<TR>
																												<TD style="WIDTH: 612px; HEIGHT: 22px" align="left" colSpan="2">
																													<P align="center">
																														<asp:button id="Button2" runat="server" Text="�����ʼ�ҹ"></asp:button>
																														&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																														<asp:button id="Button1" runat="server" Text="¡��ԡ"></asp:button>
																													</P>
																												</TD>
																											</TR>
																											<TR>
																												<TD style="WIDTH: 612px; HEIGHT: 22px" align="left" colSpan="2">
																												</TD>
																											</TR>
																											<TR>
																												<TD style="WIDTH: 612px; HEIGHT: 22px" align="left" colSpan="2">
																													<P align="center">
																														<asp:hyperlink id="HyperLink1" runat="server" NavigateUrl="memberservice.aspx">��Ѻ�˹���к���ԡ����Ҫԡ</asp:hyperlink>
																													</P>
																												</TD>
																											</TR>
			</P> </TBODY></TABLE></TD></TR></FORM></TBODY></TABLE><!-- End Form Area --> </TD></TR><!-- Copyright Bar --> 
			</TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
			<TD bgColor="#0033cc" rowSpan="3">
				<TABLE cellSpacing="0" cellPadding="0" width="1" border="0">
					<TR>
						<TD height="21">
						</TD>
					</TR>
				</TABLE>
			</TD>
			</TR></TBODY></TABLE></TD></TR></TBODY></TABLE></P>
			<P align="center">
			</P>
		</FONT>
		<P align="center">
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT><FONT color="#000000">
			</FONT>
		</P>
		<P align="center">
			<A style="FONT-SIZE: 10pt" href="privilege.aspx">�Ӫ��ᨧ�Է����ǹ�ؤ��</A> |&nbsp;<A style="FONT-SIZE: 10pt" href="main.aspx">˹���á 
				Passport System</A>
		</P>
	</body>
</HTML>
