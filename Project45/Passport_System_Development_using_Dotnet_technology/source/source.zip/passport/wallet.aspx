<html dir="ltr">
	<head>
		<meta HTTP-EQUIV="Content-Type" content="text/html; charset=iso-8859-1">
		<title>Please sign in</title>
		<link rel="stylesheet" type="text/css" href="/1033/L/PPIE.css">
			<script language="JavaScript"><!-- //
var CBSigninTxt1 = "", CBSigninTxt2 = "";
var CBLoginHead = "", CBLoginBody = "", CBLoginOnLoad = "";
var CBToken = "PASSPORT_UI", CBBodyDefault = "", CBLogo = "http://www.passportimages.com/walletlogo.gif", CBLogoHREF = "";
var PPCBBodyPre = "", PPCBBodyPost = "";
function MPS_BodyOnload() { if (CBLoginOnLoad != "") { eval(CBLoginOnLoad); } }
function MPS_NormalizeURL(szURL) {
  var szNURL = szURL;
  if (window.location.protocol == "http:"){
   if (szURL.substring(0,5).toLowerCase() == "https")
    szNURL = "http" + szURL.substring(5, szURL.length);}
  return(szNURL);
}
// --></script>
			<script language="JavaScript" src="http://wallet.passport.com/cobrand.asp?PP_SERVICE=login&PP_PAGE=ppLogin&lid=1033"></script>
			<script language="JavaScript"><!-- //
if (CBLogo > " ") { CBLogo = MPS_NormalizeURL(CBLogo); }
if (CBLoginHead) { document.write(CBLoginHead); }
// --></script>
			<script language="JavaScript">
<!-- //
	if (top != self) 
	{
		top.location.replace(self.location.href.toLowerCase());
	}
function email2domain(sName)
{
	var len = sName.length;
	var iAt = sName.indexOf('@');
	var outName = "passport_com";
	var inDomain = sName.substr(iAt+1, len);
	var DomainSplit = "charter.com;compaq.net;default;hotmail.com;msn.com;passport.com;webtv.net";
	DomainSplit = DomainSplit.split(";");
	var i;
	for (i = 0; i < DomainSplit.length; i++)
	{
		if (DomainSplit[i].toLowerCase() == inDomain.toLowerCase() )
		{
			
			
			outName = "";
			var tmp = DomainSplit[i];
			var x = 0;
			var ch;
			for( x = 0; x < tmp.length; x++)
			{
				ch = tmp.charAt(x);
				if((ch == '.') || (ch=='-'))
					ch = '_';
				outName = outName + ch;
			}
			break;
		}
	}
	return outName;
}
function email2login(sName)
{
	if( !sName )
		return null;
	
	var outName = sName;
	
	var len = sName.length;
	var iAt = sName.indexOf('@');
	var inDomain = sName.substr(iAt+1, len);
	var DomainSplit = "charter.com;compaq.net;default;hotmail.com;msn.com;passport.com;webtv.net";
	DomainSplit = DomainSplit.split(";");
	var i;
	for (i = 0; i < DomainSplit.length; i++)
	{
		if (DomainSplit[i].toLowerCase() == inDomain.toLowerCase() )
		{
			
			
			outName = sName.substr(0, iAt);
			break;
		}
	}
	return outName;
}
function OnOtherSubmitEventHandler()
{
  DoOtherSubmit();
  return false;
}
function OnLoginSubmitEventHandler()
{
  return DoSubmit();
  return false;
}
function DoOtherSubmit()
{
	document.form1.submit();
}
function DoSubmit()
{
	var actionform, selectIndex, lvalue;
	lvalue = document.form1.login.value
	if (!lvalue)
	{
		alert("Please type your e-mail address.");
		return false;
	}
	if(lvalue.charAt(0) > '~')
	{
		alert("Please switch your Input Method Editor(IME) to the Half-Width ASCII setting and retype your e-mail address.");
		return false;
	}
	if((lvalue.indexOf('@') == -1) || (lvalue.indexOf('.') == -1))
	{
		alert("Please type your complete e-mail address. Example: someone@microsoft.com.");
		return false;
	}
	if(!document.form1.passwd.value)
	{
		alert("Please type your password.");
		return false;
	}
	eval("actionform = document." + email2domain(lvalue));
	var loginName = email2login(lvalue);
	
	if( typeof(actionform) == "undefined")
		actionform = document.form1;
			actionform.login.value = loginName;
			actionform.passwd.value = document.form1.passwd.value;
			actionform.sec.value = document.form1.sec.checked ? document.form1.sec.value : "";
			actionform.mspp_shared.value = document.form1.mspp_shared.checked ? document.form1.mspp_shared.value : "";
		actionform.submit();
			return false;
}
// -->
			</script>
	</head>
	<body topmargin="0" leftmargin="0" rightmargin="0" marginheight="0" marginwidth="0" onload="MPS_BodyOnload()" class="PPPageBG">
		<noscript>
			<center>
				<table cellpadding="0" cellspacing="0" border="0" width="500">
					<tr>
						<td>
							<img src="http://www.passportimages.com/walletlogo.gif" width="468" height="60" border="0" alt=".NET Passport wallet">
						</td>
					</tr>
					<tr>
						<td>
		</noscript>
		<script language="JavaScript"><!-- //
if (!CBBodyDefault) 
{
  CBBodyDefault = '<center><table cellpadding="0" cellspacing="0" border="0" width="608"><tr><td>';
  if (CBLogo) 
  {
    if (CBLogoHREF) 
    { 
      CBBodyDefault += '<a href="' + CBLogoHREF + '" target="_top"><img src="' + CBLogo + '" width="468" height="60" border="0" alt="' + '.NET Passport wallet' + '"></a></td>'; 
    } else {
      CBBodyDefault += '<img src="' + CBLogo + '" width="468" height="60" border="0" alt="' + '.NET Passport wallet' + '"></td>';
    }
    CBBodyDefault += '<td><img src="/images/T.gif" width="140" height="1" border="0"></td></tr>';
    CBBodyDefault += '<tr><td colspan="2" valign="top">' + CBSigninTxt1 + '<img src="/images/T.gif" width="1" height="13" border="0"></td></tr></table>';
  } else {
    CBBodyDefault += '<img src="/images/T.gif" width="1" height="1" border="0"></td></tr>';
    CBBodyDefault += '<tr><td valign="top">' + CBSigninTxt1 + '<img src="/images/T.gif" width="1" height="13" border="0"></td></tr></table>';
  }
  CBBodyDefault += '<table cellpadding="0" cellspacing="0" border="0" width="608"><tr><td width="308" valign="top">' + CBToken + '</td><td width="5"><img src="/images/T.gif" width="5" height="1"></td><td width="100%" valign="top">' + CBSigninTxt2 + '</td></tr></table></center>';
}
var ppuiIndex = -1;
var ppuiCB = false;
if (CBLoginBody) {
	ppuiCB = true;
	ppuiIndex = CBLoginBody.indexOf(CBToken);
}
if (ppuiIndex == -1) {
	CBLoginBody = CBBodyDefault;
	ppuiIndex = CBLoginBody.indexOf(CBToken);
}
PPCBBodyPre = CBLoginBody.substring(0, ppuiIndex);
PPCBBodyPost = CBLoginBody.substring(ppuiIndex + CBToken.length);
document.write(PPCBBodyPre);
// --></script>
		<table cellpadding="0" cellspacing="0" border="0" width="308" class="PPDynamicTbl">
			<form TARGET="_top" name="charter_com" action="https://login.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" METHOD="post">
				<input type="hidden" name="login"> <input type="hidden" Name="domain" Value="charter.com">
				<input type="hidden" name="passwd"> <input type="hidden" name="sec"> <input type="hidden" name="mspp_shared">
			</form>
			<form TARGET="_top" name="compaq_net" action="https://msnialogin.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" METHOD="post">
				<input type="hidden" name="login"> <input type="hidden" Name="domain" Value="compaq.net">
				<input type="hidden" name="passwd"> <input type="hidden" name="sec"> <input type="hidden" name="mspp_shared">
			</form>
			<form TARGET="_top" name="hotmail_com" action="https://loginnet.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" METHOD="post">
				<input type="hidden" name="login"> <input type="hidden" Name="domain" Value="hotmail.com">
				<input type="hidden" name="passwd"> <input type="hidden" name="sec"> <input type="hidden" name="mspp_shared">
			</form>
			<form TARGET="_top" name="msn_com" action="https://msnialogin.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" METHOD="post">
				<input type="hidden" name="login"> <input type="hidden" Name="domain" Value="msn.com">
				<input type="hidden" name="passwd"> <input type="hidden" name="sec"> <input type="hidden" name="mspp_shared">
			</form>
			<form TARGET="_top" name="passport_com" action="https://login.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" METHOD="post">
				<input type="hidden" name="login"> <input type="hidden" Name="domain" Value="passport.com">
				<input type="hidden" name="passwd"> <input type="hidden" name="sec"> <input type="hidden" name="mspp_shared">
			</form>
			<form TARGET="_top" name="webtv_net" action="https://login.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" METHOD="post">
				<input type="hidden" name="login"> <input type="hidden" Name="domain" Value="webtv.net">
				<input type="hidden" name="passwd"> <input type="hidden" name="sec"> <input type="hidden" name="mspp_shared">
			</form>
			<form target="_top" name="form1" action="https://login.passport.com/ppsecure/post.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&tw=30&fs=1&kv=5&cbid=7&ts=-10&da=passport.com&ver=2.1.0002.506&tpf=40e73faf266f2da992987bd9b723b67e" method="post" onsubmit="return(OnLoginSubmitEventHandler());">
				<input type="hidden" name="notinframe" value="1">
				<tr class="PPModuleBrd">
					<td rowspan="200">
						<img src="/images/T.gif" width="2" height="1" border="0">
					</td>
					<td>
						<img src="/images/T.gif" width="304" height="1" border="0">
					</td>
					<td rowspan="200">
						<img src="/images/T.gif" width="2" height="1" border="0">
					</td>
				</tr>
				<tr class="PPModuleTtlTbl">
					<td width="100%">
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td rowspan="2">
									<img src="/images/T.gif" width="10" height="34" border="0">
								</td>
								<td width="100%">
									<img src="/images/T.gif">
								</td>
								<td>
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td rowspan="2">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td class="PPModuleTtlTxt">
									.NET Passport Sign-in
								</td>
								<td nowrap align="right" class="PPHelp">
									<script language="JavaScript">window.name='msnMain';</script>
									<a href="javascript:var h_win=window.open('/PaneHelp.srf?lc=1033&plc=1033&PHKey=ppLogin&PHIsID=60180','_helpdriver','toolbar=0,status=0,menubar=0,width=100,height=100,left=100,top=2000,resizable=0');" target="_top">
										Help</a>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0">
							<tr>
								<td>
									<img src="/images/T.gif" width="1" height="10" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="304">
							<tr>
								<td rowspan="5">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="90" height="2" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="194" height="2" border="0">
								</td>
								<td rowspan="5">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td class="PPRLabelText">
									<label for="loginid">E-mail Address&nbsp;</label>
								</td>
								<td>
									<input type="text" name="login" id="loginid" class="PPRField" tabindex="1" maxlength="129" size="25" value="<Type your e-mail address>" autocomplete="OFF" onClick="SelText();">
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<img src="/images/T.gif" width="1" height="2" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="304">
							<tr>
								<td rowspan="5">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="90" height="2" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="194" height="2" border="0">
								</td>
								<td rowspan="5">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td class="PPRLabelText">
									Password&nbsp;
								</td>
								<td>
									<input type="password" name="passwd" maxlength="16" class="PPRField" size="25" tabindex="2" autocomplete="OFF">
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<img src="/images/T.gif" width="1" height="2" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="304">
							<tr>
								<td rowspan="5">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="85" height="2" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="199" height="2" border="0">
								</td>
								<td rowspan="5">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td>
									<img src="/images/T.gif">
								</td>
								<td class="PPSmallDesText">
									<label for="sec"><input type="checkbox" id="sec" name="sec" tabindex="3" value="rem" onclick="this.form.mspp_shared.checked=false">Sign 
										me in automatically.</label>
								</td>
							</tr>
							<tr>
								<td colspan="2">
									<img src="/images/T.gif" width="1" height="2" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="304">
							<tr>
								<td rowspan="3">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="284" height="2" border="0">
								</td>
								<td rowspan="3">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td align="right">
									<input type="submit" tabindex="4" value=" Sign In " id="submit1" name="submit1" class="PPRSbmtBtn">
								</td>
							</tr>
							<tr>
								<td>
									<img src="/images/T.gif" width="1" height="8" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td>
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td width="100%" class="PPLineBreak">
									<img src="/images/T.gif">
								</td>
								<td>
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td colspan="3">
									<img src="/images/T.gif" width="1" height="8" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="304">
							<tr>
								<td rowspan="2">
									<img src="/images/T.gif" width="5" height="1" border="0">
								</td>
								<td class="PPSmallDesText">
									<label for="mspp_shared"><input type="checkbox" tabindex="5" id="mspp_shared" name="mspp_shared" value="1" onclick="this.form.sec.checked=false">
										I'm using a public computer.</label>
								</td>
								<td rowspan="2">
									<img src="/images/T.gif" width="5" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td>
									<img src="/images/T.gif" width="1" height="10" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr width="100%">
					<td>
						<table cellpadding="0" cellspacing="0" border="0" width="100%">
							<tr>
								<td width="100%" valign="bottom">
									<table cellpadding="0" cellspacing="0" border="0" width="100%">
										<tr>
											<td background="/images/yellow.gif">
												<img src="/images/T.gif" width="1" height="4" border="0">
											</td>
										</tr>
									</table>
								</td>
								<td align="right">
									<a href="http://www.passport.net/default.asp?lc=1033&id=7&cbid=7" target="_top"><img src="http://www.passportimages.com/1033/dotnetlogoBIG.gif" alt="www.passport.com" height="34" width="153" border="0"></a>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr class="PPNoPassportTbl">
					<td>
						<table border="0" cellpadding="0" cellspacing="0" width="304">
							<tr>
								<td rowspan="3">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td>
									<img src="/images/T.gif" width="284" height="2" border="0">
								</td>
								<td rowspan="3">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td>
									<table border="0" cellpadding="0" cellspacing="0" width="100%">
										<tr>
											<td>
												<img src="/images/T.gif" width="1" height="30" border="0">
											</td>
											<td width="100%" Continue class="PPSmallDesText">
												Don't have a .NET Passport?&nbsp; <a href="http://register.passport.net/reg.srf?lc=1033&id=7&ru=https://wallet.passport.com/ppsecure/default.asp%3flc%3d1033%26mo%3ddefault&kv=5&cbid=7&ct=1043351137&tw=30&ts=-10&ver=2.1.0002.506&tpf=08098c73501dafb1fa080e87a718e2f9" target="_top">
													Get one now.</a>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td>
									<img src="/images/T.gif" width="1" height="2" border="0">
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr class="PPFooterTbl">
					<td align="center">
						<table cellpadding="0" cellspacing="0" border="0" width="100%" class="PPFooterTbl">
							<tr>
								<td rowspan="2">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
								<td width="100%">
									<img src="/images/T.gif" width="1" height="5" border="0">
								</td>
								<td rowspan="2">
									<img src="/images/T.gif" width="10" height="1" border="0">
								</td>
							</tr>
							<tr>
								<td class="PPFooterTxt">
									<nobr><a href="http://memberservices.passport.net/memberservice.srf?lc=1033&id=7&cbid=7" target="_top">
											Member Services</a>&nbsp;</nobr> <nobr><a href="http://www.passport.net/consumer/termsofuse.asp?lc=1033&id=7&cbid=7" target="_top">
											Terms of Use</a>&nbsp;</nobr> <nobr><a href="http://www.passport.net/consumer/privacypolicy.asp?lc=1033&id=7&cbid=7" target="_top">
											Privacy Statement</a></nobr>
									<br>
									<img src="/images/T.gif" width="1" height="5" border="0">
									<br>
									Some elements &copy; 1999 - 2003 Microsoft&reg; Corporation. All rights 
									reserved.
									<br>
									<img src="/images/T.gif" width="1" height="5" border="0">
								</td>
							</tr>
						</table>
						<!-- ServerInfo: LAWPPLOGU6A001 2002.09.13.16.46.12 Live1 HMStage:1 -->
						<!-- Version: 2.5  Build 248 -->
					</td>
				</tr>
				<tr class="PPModuleBrd">
					<td>
						<img src="/images/T.gif" width="304" height="2" border="0">
					</td>
				</tr>
			</form>
		</table>
		<script language="JavaScript">
<!-- //
function BodyOnLoad()
{
			if (document.form1.login) {
		document.form1.login.focus();
		document.form1.login.select();
	}
	}
function SelText()
{
	if (document.form1.login.value == "<Type your e-mail address>")
	{
	document.form1.login.value = "";
	}
}
BodyOnLoad();
// -->
		</script>
		<noscript>
			<img src="/images/noscript.gif" width="1" height="1">
		</noscript>
		<noscript>
			</td></tr></table></center>
		</noscript>
		<script language="JavaScript"><!-- //
if (PPCBBodyPost) { document.write(PPCBBodyPost); }		
// --></script>
	</body>
</html>
