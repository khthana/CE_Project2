Imports System.web
Public Class privilege
    Inherits System.Web.UI.Page
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim login As Boolean
    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Try
            Dim MyCookie As HttpCookie
            MyCookie = Request.Cookies("passport")

            If MyCookie.Value = "logoutted" Then
                ImageButton1.ImageUrl = "image\signin.GIF"
                login = False
            Else
                ImageButton1.ImageUrl = "image\signout.GIF"
                login = True
            End If

        Catch
            ImageButton1.ImageUrl = "image\signin.GIF"
            login = False
        End Try
    End Sub

    Private Sub ImageButton1_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton1.Click
        If login = True Then
            Response.Redirect("logout.aspx")
        Else
            Response.Redirect("login.aspx")
        End If
    End Sub
End Class
