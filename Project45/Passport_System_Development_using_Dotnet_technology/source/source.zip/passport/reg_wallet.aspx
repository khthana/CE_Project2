<html>
	<head>
		<meta http-equiv="content-type" content="text/html; charset=iso-8859-1">
		</meta>
		<meta HTTP-EQUIV="Expires" CONTENT="0">
		<link ID="walletCSS" REL="StyleSheet" HREF="../ui/en/css/wallet.css" TYPE="text/css">
			<link ID="passportCSS" REL="StyleSheet" HREF="../ui/en/css/passport.css" TYPE="text/css">
				<title>Microsoft .NET Passport Wallet: Enter Payment Information</title>
				<script>
var binit = false;
var includeFiles = 0;
function Init() {
	if ((includeFiles == 2) && (!binit)) {
		binit = true;
		PWS_Card_Initialize();
	}
}
				</script>
				<script language="javascript">
// abbreviation for expiration (for expiraction date on credit card)
// If a 3 character abbreviation is not possible, then set it to ""
var L_Exp_Text = "Exp";
var L_CorrectErrors_Text = "Please correct the following error(s):";

var L_Accepts_Text = "This merchant only accepts:";
var L_NeedCard_Text = "You need to enter a card to complete this transaction.";
var L_NeedAddress_Text = "You need to enter an address to complete this transaction.";
var L_CardExpired_Text = "You cannot use this card because it has expired.";
var L_AddressUsedAsBilling_Text = "This address is being used as the billing address for more than 1 card. Edit this address anyway?";
var L_AddressUsedAsBillingChoice_Text = "This address is being used as the billing address for 1 or more of your cards.  If you want to enter a new shipping address without changing your billing address, press the Cancel button below and then press the New button on the page to enter a new shipping address.  Otherwise, press OK below to change both your billing and shipping address.";
var L_RemainderHidden_Text = "(remainder hidden)";
var L_CountriesAccepted_Text = "This merchant only ships to the following countries:";
var GiftCertBalance = "Display my MSN Gift Certificate balance";
var AddressType = 0;
var LCID = 1033;
var L_US_Text = "United States";
var L_CA_Text = "Canada";
var L_UK_Text = "United Kingdom";
var L_AU_Text = "Australia";
var L_IE_Text = "Ireland"; 
var L_FR_Text = "France";
var L_DE_Text = "Germany";
var L_IT_Text = "Italy";
var L_JP_Text = "Japan";
var L_PR_Text = "Puerto Rico";
var L_FI_Text = "Finland";
var L_CH_Text = "Switzerland";
var L_AT_Text = "Austria";
var L_DK_Text = "Denmark";
var L_SE_Text = "Sweden";
var L_NO_Text = "Norway";
var L_NL_Text = "Netherlands";
var L_NZ_Text = "New Zealand";
var L_MX_Text = "Mexico";
var L_BR_Text = "Brazil";
var L_AR_Text = "Argentina";
var L_ES_Text = "Spain";
var L_PT_Text = "Portugal";
var L_IL_Text = "Israel";
var L_HK_Text = "Hong Kong S.A.R.";
var L_CN_Text = "China";
var L_KR_Text = "Korea";
var L_TW_Text = "Taiwan";
var L_SG_Text = "Singapore";
var L_BE_Text = "Belgium";
var L_GR_Text = "Greece";
var L_HU_Text = "Hungary";
var L_IN_Text = "India";
var L_MY_Text = "Malaysia";
var L_PL_Text = "Poland";
var L_RU_Text = "Russia"; 
var L_UA_Text = "Ukraine";
var L_ZA_Text = "South Africa";
var L_TR_Text = "Turkey";
				</script>
				<script language="javascript">
var L_CantDeleteAddress_Text = "Can't delete this address. It is being used as the billing address for 1 or more of your cards.";

var L_BillingShippingDescription_Text = "Shipping Address and Billing Address cannot have the same description";;
var L_Consent_Text = "To make your future purchases at .NET Passport sites easier, the information you provided will be saved in your Microsoft .NET Passport. For your next purchase, just select a card and address you saved, or add additional cards or addresses to your .NET Passport.\n\nClick OK to save the information and continue with your transaction.";

var L_NoShippingCountry_Text = "The merchant does not ship to the country indicated in your address.";
var L_CantUseShippingAsBilling_Text = "You cannot use your billing address as your shipping address because\r\nthe merchant does not ship to your billing address country.";

var L_NeedStateBilling_Text = "You must enter a state/province for this billing address";
var L_NeedStateShipping_Text = "You must enter a state/province for this shipping address";
var L_InvalidStateBilling_Text = "Please enter a valid 2 digit state abbreviation (e.g. MA) for this billing address";
var L_InvalidStateShipping_Text = "Please enter a valid 2 digit state abbreviation (e.g. MA) for this shipping address";
var L_NeedPostalBilling_Text = "You must enter a ZIP (Postal) Code for this billing address";
var L_NeedPostalShipping_Text = "You must enter a ZIP (Postal) Code for this shipping address";
var L_InvalidPostalBilling_Text = "Invalid ZIP (Postal) Code for this billing address";
var L_InvalidPostalShipping_Text = "Invalid ZIP (Postal) Code for this shipping address";
var L_NeedPhoneBilling_Text = "You must enter a phone number for this billing address";
var L_NeedPhoneShipping_Text = "You must enter a phone number for this shipping address";
var L_InvalidPhoneBilling_Text = "Invalid phone number for this billing address: use format ###-###-####";
var L_InvalidPhoneShipping_Text = "Invalid phone number for this shipping address: use format ###-###-####";
var L_NeedEmail_Text = "You must enter an email address";
var L_NeedEmailBilling_Text = "You must enter an email address for this billing address";
var L_NeedEmailShipping_Text = "You must enter an email address for this shipping address";
var L_InvalidEmail_Text = "Invalid email address: use format abc@def.com";
var L_InvalidEmailBilling_Text = "Invalid email address for this billing address: use format abc@def.com";
var L_InvalidEmailShipping_Text = "Invalid email address for this shipping address: use format abc@def.com";
var L_LongEmail_Text = "The email address is too long";
var L_LongEmailBilling_Text = "The email address for this billing address is too long";
var L_LongEmailShipping_Text = "The email address for this shipping address is too long";
var L_CardExpired_Text = "You cannot enter a card expiration date in the past";
var L_NeedCard_Text = "You must enter a card number";
var L_InvalidCard_Text = "The credit card number you typed does not match the card type. Please check the card type and number and try again.";
var L_NeedCardName_Text = "You must enter the name as it appears on the card";
var L_NeedCardDescription_Text = "You must enter a description for this card";
var L_CardDescriptionUsed_Text = "You already have a card with this description.  Please enter a different description.";
var L_NeedFirstNameBilling_Text = "You must enter a first name for this billing address";
var L_NeedFirstNameShipping_Text = "You must enter a first name for this shipping address";
var L_NeedLastNameBilling_Text = "You must enter a last name for this billing address";
var L_NeedLastNameShipping_Text = "You must enter a last name for this shipping address";
var L_NeedDescriptionBilling_Text = "You must enter a description for this billing address";
var L_NeedDescriptionShipping_Text = "You must enter a description for this shipping address";
var L_BillingDescriptionUsed_Text = "You already have an address with this description.  Please enter a different description for this billing address.";
var L_ShippingDescriptionUsed_Text = "You already have an address with this description.  Please enter a different description for this shipping address.";
var L_NeedStreet1Billing_Text = "You must enter a value for address line 1 for this billing address";
var L_NeedStreet1Shipping_Text = "You must enter a value for address line 1 for this shipping address";
var L_NeedCityBilling_Text = "You must enter a city for this billing address";
var L_NeedCityShipping_Text = "You must enter a city for this shipping address";
				</script>
				<script language="javascript">
var visaName = "Visa";
var visaShortName = "Visa";
var visaClone = "visa";
var visaAccepted = true;
var mastName = "Mastercard";
var mastShortName = "Mastercard";
var mastClone = "mast";
var mastAccepted = true;
var amerName = "American Express";
var amerShortName = "Amer. Express";
var amerClone = "amer";
var amerAccepted = true;
var discName = "Discover";
var discShortName = "Discover";
var discClone = "disc";
var discAccepted = false;
var dineName = "Diners Club";
var dineShortName = "Diners Club";
var dineClone = "dine";
var dineAccepted = true;
var jcbName = "JCB";
var jcbShortName = "JCB";
var jcbClone = "jcb";
var jcbAccepted = false;
var msgcName = "MSN Gift Certificate";
var msgcShortName = "MSN Gift Cert";
var msgcClone = "visa";
var msgcAccepted = true;
var nicoName = "Nicos";
var nicoShortName = "Nicos";
var nicoClone = "nico";
var nicoAccepted = false;
var dcName = "DC";
var dcShortName = "DC";
var dcClone = "dc";
var dcAccepted = false;
var ucarName = "UCard";
var ucarShortName = "UCard";
var ucarClone = "ucar";
var ucarAccepted = false;
var compName = "CompUSA";
var compShortName = "CompUSA";
var compClone = "comp";
var compAccepted = false;
var ucName = "UC";
var ucShortName = "UC";
var ucClone = "uc";
var ucAccepted = false;
var saisName = "Saison";
var saisShortName = "Saison";
var saisClone = "sais";
var saisAccepted = false;
var bcName = "BC";
var bcShortName = "BC";
var bcClone = "bc";
var bcAccepted = false;
var kookName = "Kookmin";
var kookShortName = "Kookmin";
var kookClone = "kook";
var kookAccepted = false;
var samsName = "Samsung";
var samsShortName = "Samsung";
var samsClone = "sams";
var samsAccepted = false;
var lgName = "LG";
var lgShortName = "LG";
var lgClone = "lg";
var lgAccepted = false;
var radiName = "RadioShack";
var radiShortName = "RadioShack";
var radiClone = "radi";
var radiAccepted = false;
var bombName = "Bombay";
var bombShortName = "Bombay";
var bombClone = "bomb";
var bombAccepted = false;
var sbuxName = "Starbucks card";
var sbuxShortName = "Starbucks card";
var sbuxClone = "sbux";
var sbuxAccepted = false;
var allCardTypes = "visa,mast,amer,disc,dine,jcb,msgc,nico,dc,ucar,comp,uc,sais,bc,kook,sams,lg,radi,bomb,sbux,";
var allCardsAccepted = "\r\nVisa\r\nMastercard\r\nAmerican Express\r\nDiners Club\r\nMSN Gift Certificate";
				</script>
				<script language="javascript" src="../client/common13.js"></script>
				<script language="javascript" src="../client/card13.js"></script>
				<SCRIPT LANGUAGE="JavaScript">
<!-- //
var requireStateList = "AU,BR,CA,CN,IN,JP,US";
var optionalZipList = "HK,";

var CBLogo = "https://www.passportimages.com/walletlogo.gif";
var CBWalletTxt1 = "";
var CBWalletTxt2 = "";

var CBWalletTxt3 = "Done";

var CBWalletTitle = "Enter Payment Information";
var CBWalletTop = "";
var CBWalletAddress = "";
var CBWalletTxt2HideHeader = false;
var CBWalletBody = "";
var CBWalletHead = "";
var CBWalletOnLoad = "";

var CBShippingAddress = "Shipping Address";
var CBYourShippingAddresses = "Your Shipping Address(es)";
var CBNewShippingAddress = "Press 'New' to add a shipping address";

// -->
				</SCRIPT>
				<SCRIPT LANGUAGE="JavaScript" SRC="https://wallet.passport.com/cobrand.asp?lid=1033&PP_SERVICE=wallet&pwsp=n&pwsc=n&pwsd=c"></SCRIPT>
				<SCRIPT LANGUAGE="JavaScript">
<!-- //
function PWS_MakeSecureURL(url) {
	var secureURL = url;
	if (url.substring(0, 5) != "https") {
		if (url.substring(0, 4) == "http") {
			secureURL = "https" + url.substring(4, url.length);
		}
	}
	return(secureURL);
}

function PWS_BodyOnload() {
	if (CBWalletOnLoad != "") {
		eval(CBWalletOnLoad);
	}
}

CBLogo = PWS_MakeSecureURL(CBLogo);
if (CBWalletHead) {
	document.write(CBWalletHead);
}
// -->
				</SCRIPT>
	</head>
	<body topmargin="0" leftmargin="0" rightmargin="0" marginheight="0" marginwidth="0" onLoad="Init();PWS_BodyOnload()">
		<script language="JavaScript"><!-- //
var CBToken = "PASSPORT_UI";
var CBBodyDefault = '<center><table border=0 cellpadding=0 cellspacing=0><tr><td align=left>';

var sLogoPath;

if (-1 == CBLogo.indexOf("WalletLogo.gif"))
{
	CBLogo = "https://www.passportimages.com/walletlogo.gif";
}

if (CBLogo.length > 0) 
{
	sLogoPath = CBLogo;
}
else
{
	sLogoPath = "https://www.passportimages.com/walletlogo.gif";
}					

    CBBodyDefault += '<IMG SRC="' + sLogoPath + '" BORDER=0 WIDTH=468 HEIGHT=60 ' + 'ALT=".NET Passport wallet">';

CBBodyDefault += '</td></tr><tr><td>' + CBToken + '</td></tr></table></center>';

	var blnNewCobranding = false;
	var ppuiIndex = -1;
	if (CBWalletBody) {
		ppuiIndex = CBWalletBody.indexOf(CBToken);
		blnNewCobranding = true;
	}
	if (ppuiIndex == -1) {
		CBWalletBody = CBBodyDefault;
		ppuiIndex = CBWalletBody.indexOf(CBToken);
	}
	var PPCBBodyPre = CBWalletBody.substring(0, ppuiIndex);
	var PPCBBodyPost = CBWalletBody.substring(ppuiIndex + CBToken.length);
	document.write(PPCBBodyPre);

if (!blnNewCobranding) {
	if (CBWalletTop != "") {
		var text = " <table WIDTH=590 BORDER=0 CELLPADDING=0 CELLSPACING=0>";
		text += "  <tr>";
		text += "   <td HEIGHT=10>" + CBWalletTop + "</td>";
		text += "  </tr>";
		text += " </table>";
		document.write(text);
	}
}
// --></script>
		<table border="0" cellpadding="0" cellspacing="0" width="590">
			<tr>
				<td rowspan="5" class="walletborder">
					<img src="/images/trans_pixel.gif" width="2" height="1">
				</td>
				<td colspan="3" class="walletborder">
					<img src="/images/trans_pixel.gif" width="1" height="1">
				</td>
				<td rowspan="5" class="walletborder">
					<img src="/images/trans_pixel.gif" width="2" height="1">
				</td>
			</tr>
			<tr>
				<td colspan="3" class="walletborder">
					<table WIDTH="586" BORDER="0" CELLPADDING="0" CELLSPACING="0">
						<tr>
							<td class="walletheadertext" WIDTH="4">
								<img src="/images/trans_pixel.gif" width="4" height="30">
							</td>
							<td class="walletheadertext" WIDTH="390" ALIGN="left">
								<font><b>
										<SCRIPT LANGUAGE="JavaScript">document.write(CBWalletTitle);</SCRIPT>
									</b></font>
							</td>
							<td class="walletheadertext" WIDTH="20" ALIGN="right">
								<IMG height="20" src="/images/padlock.gif" width="15">
							</td>
							<td class="walletheadertext" WIDTH="78" ALIGN="left" VALIGN="center">
								<font SIZE="1"><font style="font-size: 8pt; font-weight: normal">Secure Site</font></font>
							</td>
							<td class="walletheadertext" WIDTH="2" valign="middle">
								<img src="/images/white_pixel.gif" width="1" height="25">
							</td>
							<td class="walletheadertext" WIDTH="76" ALIGN="center">
								<a HREF="http://login.passport.com/logout.srf?lc=1033&id=7&ru=https%3A%2F%2Fwallet%2Epassport%2Ecom%2Fppsecure%2FCancel%2Easp%3Fmid%3D7%26ru%3Dhttp%253A%252F%252Fwww%252Epassport%252Enet%252Fdirectory%252Fdefault%252Easp%253Flc%253D1033%253F%255Fcc%253DUS%2526%255Flang%253Den%26dr%3DC%252CA%26ca%3Dvisa%252Cmast%252Camer%252Cdine%26lc%3D1033%26mo%3Ddefault%26cu%3D1">
									<IMG SRC="https://www.passportimages.com/1033/signout.gif" CLASS="PassportSignOut" BORDER="0" ALT="Sign out of .NET Passport sites" /></a>
							</td>
						</tr>
						<tr>
							<td class="walletborder" colspan="7">
								<IMG src="/images/trans_pixel.gif" width="1" height="1">
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td bgcolor="#eeeee2">
					<img src="/images/trans_pixel.gif" width="4" height="1">
				</td>
				<td bgcolor="#eeeee2">
					<form NAME="PWS_Data">
						<input TYPE="hidden" NAME="PWS_CardNumberChanged" VALUE="0"><input TYPE="hidden" NAME="PWS_CardDescriptionChanged" VALUE="0"><input TYPE="hidden" NAME="PWS_BillingDescriptionChanged" VALUE="0"><input TYPE="hidden" NAME="PWS_Focus" VALUE="Card">
						<input TYPE="hidden" NAME="PWS_C_D_Description" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_ID" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_Type" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_NumberEnc" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_NumberPortion" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_ExpirationMonth" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_ExpirationYear" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_Name" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_BankID" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_InsertDate" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_AddressID" VALUE=""><input TYPE="hidden" NAME="PWS_C_D_Default" VALUE="1"><input TYPE="hidden" NAME="PWS_A_D_Email" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Postal" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Country" VALUE="TH"><input TYPE="hidden" NAME="PWS_A_D_FirstName" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_LastName" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Description" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Street1" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Street2" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_City" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_State" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Phone" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_ID" VALUE=""><input TYPE="hidden" NAME="PWS_A_D_Default" VALUE="1"><input TYPE="hidden" NAME="PWS_A_D_RefCount" VALUE="0">
					</form>
					<center>
						<font class="walletbodytext">
							<table WIDTH="590" BORDER="0" CELLPADDING="0" CELLSPACING="0" bgcolor="#eeeee2">
								<form NAME="PWS_UI" ACTION="https://wallet.passport.com/ppsecure/CardSubmit.asp?mid=7&ru=http%3A%2F%2Fwww%2Epassport%2Enet%2Fdirectory%2Fdefault%2Easp%3Flc%3D1033%3F%5Fcc%3DUS%26%5Flang%3Den&dr=C%2CA&ca=visa%2Cmast%2Camer%2Cdine&lc=1033&mo=default&cu=1" METHOD="post" AUTOCOMPLETE="OFF">
									<input TYPE="hidden" NAME="PWS_Init" VALUE="0"><input type="hidden" name="Ecom_SchemaVersion" value="http://www.ecml.org/version/1.0">
									<!-- Credit Card & Cobranding -->
									<tr>
										<td WIDTH="275" ROWSPAN="2" COLSPAN="2">
											<table BORDER="0" CELLPADDING="0" CELLSPACING="0">
												<tr>
													<td ALIGN="left" COLSPAN="2">
														<input TYPE="hidden" NAME="CardID" VALUE=""><font class="walletbodytext"><b>Payment 
																Information</b></font>
													</td>
												</tr>
												<tr>
													<td WIDTH="100" ALIGN="left">
														<font class="walletbodytext">Card type:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<select NAME="Ecom_Payment_Card_Type" SIZE="1" onChange="PWS_Card_SetDescription()"><option value="visa">Visa</option><option value="mast">Mastercard</option><option value="amer">American 
																Express</option><option value="dine">Diners Club</option></select>
													</td>
													<td>
														<img SRC="/images/trans_pixel.gif" height="1" width="20">
													</td>
												</tr>
												<tr>
													<td align="left" nowrap>
														<font class="walletbodytext">Card number:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_Payment_Card_Number" MAXLENGTH="19" SIZE="21" onChange="PWS_Card_NumberChanged()">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Name&nbsp;on&nbsp;card:</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_Payment_Card_Name" MAXLENGTH="64" SIZE="21" onChange="PWS_Card_SetDescription()">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Expiration:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<select NAME="Ecom_Payment_Card_ExpDate_Month">
															<option value="1">
																01</option>
															<option value="2">
																02</option>
															<option value="3">
																03</option>
															<option value="4">
																04</option>
															<option value="5">
																05</option>
															<option value="6">
																06</option>
															<option value="7">
																07</option>
															<option value="8">
																08</option>
															<option value="9">
																09</option>
															<option value="10">
																10</option>
															<option value="11">
																11</option>
															<option value="12">
																12</option>
														</select>&nbsp;/&nbsp;<select name="Ecom_Payment_Card_ExpDate_Year">
															<option value='2003'>
																2003</option><option value='2004'>2004</option><option value='2005'>2005</option><option value='2006'>2006</option><option value='2007'>2007</option><option value='2008'>2008</option><option value='2009'>2009</option><option value='2010'>2010</option><option value='2011'>2011</option><option value='2012'>2012</option><option value='2013'>2013</option>
														</select>
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Description:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="CardDescription" MAXLENGTH="20" SIZE="21" onChange="PWS_Card_DescriptionChanged()">
													</td>
												</tr>
												<tr>
													<td>
													</td>
													<td class="helptext">
														Type a description that will help you identify this card (such as <b>business</b>
														or <b>personal</b>).
													</td>
												</tr>
											</table>
										</td>
										<td WIDTH="275" ALIGN="left" VALIGN="top">
											<table WIDTH="275" HEIGHT="43" BORDER="0" CELLPADDING="0" CELLSPACING="0">
												<tr>
													<td WIDTH="275" ALIGN="left" VALIGN="center" COLSPAN="2">
														<font class="walletbodytext"><font size="1">&nbsp;.NET Passport wallet accepts these 
																payment types</font>
													</td>
												</tr>
												<tr>
													<td WIDTH="275" HEIGHT="19" ALIGN="left" VALIGN="bottom" COLSPAN="2">
														<table BORDER="0" CELLPADDING="2" CELLSPACING="0">
															<tr>
																<td ID="visa">
																	<IMG align="absBottom" height="21" src="/images/small_visa13.gif" width="32" ALT="Visa">
																</td>
																<td ID="mast">
																	<IMG align="absBottom" height="21" src="/images/small_mast13.gif" width="32" ALT="Mastercard">
																</td>
																<td ID="amer">
																	<IMG align="absBottom" height="21" src="/images/small_amer13.gif" width="32" ALT="American Express">
																</td>
																<td ID="dine">
																	<IMG align="absBottom" height="21" src="/images/small_dine13.gif" width="32" ALT="Diners Club">
																</td>
															</tr>
														</table>
													</td>
												</tr>
												<tr>
													<td WIDTH="5" VALIGN="bottom">
														<IMG height="1" src="/images/trans_pixel.gif" width="5">
													</td>
													<td WIDTH="270" HEIGHT="3" ALIGN="left" VALIGN="bottom">
														<IMG align="absBottom" height="1" src="/images/black_pixel.gif" width="275">
													</td>
												</tr>
												<tr>
													<td WIDTH="275" HEIGHT="5" COLSPAN="1">
													</td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td WIDTH="275" HEIGHT="100" ALIGN="left" VALIGN="top">
											<script>document.write(CBWalletTxt1);</script>
										</td>
									</tr>
									<tr>
										<td colspan="3">
											<hr noshade size="1">
										</td>
									</tr>
									<!-- Vertical spacer -->
									<tr>
										<td COLSPAN="3" HEIGHT="5">
										</td>
									</tr>
									<!-- Billing Address -->
									<tr>
										<td ALIGN="left" COLSPAN="3">
											<font class="walletbodytext"><b>Billing Address</b></font>
										</td>
									</tr>
									<tr>
										<td ALIGN="left" VALIGN="top" WIDTH="275">
											<table BORDER="0" CELLPADDING="0" CELLSPACING="0">
												<tr>
													<td WIDTH="100" align="left">
														<font class="walletbodytext">First name:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_Name_First" MAXLENGTH="64" SIZE="21" onChange="PWS_Billing_SetDescription()">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Last name:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_Name_Last" MAXLENGTH="64" SIZE="21" onChange="PWS_Billing_SetDescription()">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Address&nbsp;line&nbsp;1:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_Street_Line1" MAXLENGTH="64" SIZE="21">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Address&nbsp;line&nbsp;2:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_Street_Line2" MAXLENGTH="64" SIZE="21">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">City:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_City" MAXLENGTH="64" SIZE="21">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">State/province:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_StateProv" MAXLENGTH="64" SIZE="21">
													</td>
												</tr>
											</table>
										</td>
										<td>
											<img SRC="/images/trans_pixel.gif" height="1" width="20">
										</td>
										<td ALIGN="left" VALIGN="top" WIDTH="275">
											<table BORDER="0" CELLPADDING="0" CELLSPACING="0">
												<tr>
													<td WIDTH="100" align="left">
														<font class="walletbodytext">Postal&nbsp;code:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Postal_PostalCode" MAXLENGTH="15" SIZE="21">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Country/region:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<select NAME="Ecom_BillTo_Postal_CountryCode" SIZE="1">
															<option value="">
																-Not Listed-
															</option>
															<option value="AR">
																Argentina
															</option>
															<option value="AU">
																Australia
															</option>
															<option value="AT">
																Austria
															</option>
															<option value="BE">
																Belgium
															</option>
															<option value="BR">
																Brazil
															</option>
															<option value="CA">
																Canada
															</option>
															<option value="CN">
																China
															</option>
															<option value="DK">
																Denmark
															</option>
															<option value="FI">
																Finland
															</option>
															<option value="FR">
																France
															</option>
															<option value="DE">
																Germany
															</option>
															<option value="GR">
																Greece
															</option>
															<option value="HK">
																Hong Kong S.A.R.
															</option>
															<option value="HU">
																Hungary
															</option>
															<option value="IN">
																India
															</option>
															<option value="IE">
																Ireland
															</option>
															<option value="IL">
																Israel
															</option>
															<option value="IT">
																Italy
															</option>
															<option value="JP">
																Japan
															</option>
															<option value="KR">
																Korea
															</option>
															<option value="MY">
																Malaysia
															</option>
															<option value="MX">
																Mexico
															</option>
															<option value="NL">
																Netherlands
															</option>
															<option value="NZ">
																New Zealand
															</option>
															<option value="NO">
																Norway
															</option>
															<option value="PL">
																Poland
															</option>
															<option value="PT">
																Portugal
															</option>
															<option value="PR">
																Puerto Rico
															</option>
															<option value="RU">
																Russia
															</option>
															<option value="SG">
																Singapore
															</option>
															<option value="ZA">
																South Africa
															</option>
															<option value="ES">
																Spain
															</option>
															<option value="SE">
																Sweden
															</option>
															<option value="CH">
																Switzerland
															</option>
															<option value="TW">
																Taiwan
															</option>
															<option value="TR">
																Turkey
															</option>
															<option value="UA">
																Ukraine
															</option>
															<option value="UK">
																United Kingdom
															</option>
															<option value="US">
																United States
															</option>
														</select>
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Phone:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Telecom_Phone_Number" MAXLENGTH="32" SIZE="21">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">E-mail:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="Ecom_BillTo_Online_Email" MAXLENGTH="129" SIZE="21">
													</td>
												</tr>
												<tr>
													<td align="left">
														<font class="walletbodytext">Description:&nbsp;</font>
													</td>
													<td ALIGN="left">
														<input NAME="BillingDescription" MAXLENGTH="20" SIZE="21" onChange="PWS_Billing_DescriptionChanged()">
													</td>
												</tr>
												<tr>
													<td>
													</td>
													<td class="helptext">
														Type a description that will help you identify this address.
													</td>
												</tr>
											</table>
										</td>
									</tr>
									<tr>
										<td colspan="3">
											<hr noshade size="1">
										</td>
									</tr>
									<tr>
										<td ALIGN="left" COLSPAN="3" nowrap>
											<input TYPE="hidden" NAME="CardDefault" VALUE="1"><font class="walletbodytext"><b></font>
										</td>
									</tr>
								</form>
								<form NAME="PWS_Hidden" ACTION="https://wallet.passport.com/ppsecure/CardSubmit.asp?mid=7&ru=http%3A%2F%2Fwww%2Epassport%2Enet%2Fdirectory%2Fdefault%2Easp%3Flc%3D1033%3F%5Fcc%3DUS%26%5Flang%3Den&dr=C%2CA&ca=visa%2Cmast%2Camer%2Cdine&lc=1033&mo=default&cu=1" METHOD="post" onSubmit="return false">
									<input TYPE="hidden" NAME="PWS_C_Count" VALUE="0"><input TYPE="hidden" NAME="PWS_A_Count" VALUE="0">
									<input TYPE="hidden" NAME="CardID" VALUE> <input TYPE="hidden" NAME="CardType" VALUE>
									<input TYPE="hidden" NAME="CardNumber" VALUE> <input TYPE="hidden" NAME="CardExpirationMonth" VALUE>
									<input TYPE="hidden" NAME="CardExpirationYear" VALUE> <input TYPE="hidden" NAME="CardName" VALUE>
									<input TYPE="hidden" NAME="CardBankID" VALUE> <input TYPE="hidden" NAME="CardAddressID" VALUE>
									<input TYPE="hidden" NAME="CardDefault" VALUE> <input TYPE="hidden" NAME="CardMode" VALUE>
									<input TYPE="hidden" NAME="CardDescription" VALUE> <input TYPE="hidden" NAME="BillingEmail" VALUE>
									<input TYPE="hidden" NAME="BillingPostal" VALUE> <input TYPE="hidden" NAME="BillingCountry" VALUE>
									<input TYPE="hidden" NAME="BillingFirstName" VALUE> <input TYPE="hidden" NAME="BillingLastName" VALUE>
									<input TYPE="hidden" NAME="BillingDescription" VALUE> <input TYPE="hidden" NAME="BillingStreet1" VALUE>
									<input TYPE="hidden" NAME="BillingStreet2" VALUE> <input TYPE="hidden" NAME="BillingCity" VALUE>
									<input TYPE="hidden" NAME="BillingState" VALUE> <input TYPE="hidden" NAME="BillingPhone" VALUE>
									<input TYPE="hidden" NAME="BillingID" VALUE> <input TYPE="hidden" NAME="BillingDefault" VALUE>
									<input TYPE="hidden" NAME="BillingMode" VALUE> <input TYPE="hidden" NAME="PWS_Operation" VALUE>
								</form>
								<!-- Vertical spacer -->
								<tr>
									<td COLSPAN="3" HEIGHT="5">
									</td>
								</tr>
								<!-- Buttons -->
								<tr>
									<td COLSPAN="3" align="center">
										<table BORDER="0" CELLPADDING="0" CELLSPACING="0">
											<tr>
												<td ALIGN="left">
													<font class="walletbodytext"></font>
												</td>
												<td ALIGN="middle">
													<table border="0" cellpadding="0" cellspacing="0">
														<tr>
															<td>
																<img src="/images/button_left.gif">
															</td>
															<td valign="top">
																<table cellpadding="0" cellspacing="0" border="0" background="/images/button_fill.gif" height="100%">
																	<tr>
																		<td height="21" align="center">
																			<a href="javascript:PWS_Card_Continue()" class="walletbutton">Save</a>
																		</td>
																	</tr>
																	<tr>
																		<td height="1">
																			<img src="/images/trans_pixel.gif" height="1" width="55">
																</table>
															</td>
															<td>
																<img src="/images/button_right.gif">
															</td>
														</tr>
													</table>
												</td>
												<td WIDTH="10">
												</td>
												<td ALIGN="middle">
													<table border="0" cellpadding="0" cellspacing="0">
														<tr>
															<td>
																<img src="/images/button_left.gif">
															</td>
															<td valign="top">
																<table cellpadding="0" cellspacing="0" border="0" background="/images/button_fill.gif" height="100%">
																	<tr>
																		<td height="21" align="center">
																			<a href="javascript:PWS_Card_Cancel()" class="walletbutton">Cancel</a>
																		</td>
																	</tr>
																	<tr>
																		<td height="1">
																			<img src="/images/trans_pixel.gif" height="1" width="55">
																</table>
															</td>
															<td>
																<img src="/images/button_right.gif">
															</td>
														</tr>
													</table>
												</td>
											</tr>
										</table>
									</td>
								</tr>
							</table>
							<!-- Vertical spacer -->
							<table WIDTH="590" HEIGHT="10" BORDER="0" CELLPADDING="0" CELLSPACING="0" bgcolor="#eeeee2">
								<tr>
									<td HEIGHT="10">
									</td>
								</tr>
							</table>
						</font>
					</center>
					<script>
Init();
					</script>
				</td>
				<td bgcolor="#eeeee2">
					<img src="/images/trans_pixel.gif" width="4" height="1">
				</td>
			</tr>
			<tr>
				<td colspan="3" bgcolor="#eeeee2">
					<!--.NET branding -->
					<table cellpadding="0" cellspacing="0" border="0" width="100%">
						<tr>
							<td width="100%" colspan="2">
								<img src="/images/trans_pixel.gif" width="1" height="25" border="0">
							</td>
						</tr>
						<tr>
							<td width="100%" valign="bottom">
								<table cellpadding="0" cellspacing="0" border="0" width="100%">
									<tr>
										<td background="/images/yellow1.gif">
											<img src="/images/trans_pixel.gif" width="1" height="4" border="0">
										</td>
									</tr>
								</table>
							</td>
							<td align="right">
								<img src="https://www.passportimages.com/1033/dotnetlogoBIG.gif" alt="www.passport.com" height="34" width="153" border="0">
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td>
					<img src="/images/trans_pixel.gif" width="4" height="1">
				</td>
				<td> <!-- footer -->
					<table BORDER="0" CELLPADDING="5" CELLSPACING="0">
						<tr>
							<td ALIGN="left">
								<FONT class="footertext"><a href="http://memberservices.passport.net/memberservice.srf?lc=1033" target="passport">
										Member Services</a>&nbsp;<script>
if (!blnNewCobranding) {
	document.write('<A HREF="http://www.passport.net/consumer/termsofuse.asp?lc=1033" target=passport>Terms of Use</A>&nbsp;');
	document.write('<A HREF="http://www.passport.net/consumer/privacypolicy.asp?lc=1033" target=passport>Privacy Statement</A>');
}
									</script></FONT>
							</td>
						</tr>
						<tr>
							<td ALIGN="left">
								<FONT class="footertext">Some elements &copy; 1999 - 2002 Microsoft 
								Corporation. All rights reserved.
							</td>
						</tr>
					</table>
					<!--ServerInfo: LAWPPWAL6C002 2002.09.13.16.46.12  -->
					<!--Version: 2.1sp2 Build 515.1 -->
				</td>
				<td>
					<img src="/images/trans_pixel.gif" width="4" height="1">
				</td>
			</tr>
			<tr>
				<td colspan="5" class="walletborder">
					<img src="/images/trans_pixel.gif" width="590" height="2">
				</td>
			</tr>
		</table>
		<SCRIPT>
document.write(PPCBBodyPost);
		</SCRIPT>
	</body>
</html>
