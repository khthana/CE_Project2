<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="comprice.th.ac.kmitl.ce.network07" %>
<%@ Import Namespace="comprice.th.ac.kmitl.ce.network071" %>
<!--#include file = "head.inc"-->
<SCRIPT language="vb" Runat="Server">
Dim myConnection As SqlConnection
Dim mySelectQuery As String
Dim myCommand As SqlDataAdapter
Dim NumRow_A As Integer
Dim NumRow_B As Integer
Dim PriceA As String
Dim PriceB As String
Dim compare As Integer
Sub Page_Load()
	Dim check As String
    Dim myConnString As String
 	Dim ds As DataSet = new DataSet()    
	Dim dtView As Dataview   
	
	Dim wServiceA As New comprice.th.ac.kmitl.ce.network07.Service1() 
	PriceA = wServiceA.showDetail(Request.QueryString("id")) 
	Dim wServiceB As New comprice.th.ac.kmitl.ce.network071.Service1() 
	PriceB = wServiceB.showDetail(Request.QueryString("id"))
	if PriceA < PriceB then 
		compare = 1 
	else if PriceB < PriceA then 
		compare = 2 
	else 
		compare =3 
	end if
	myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
		label0.Text = Request.QueryString("id")
	check = Left(label0.Text,3)
	if check = "cpu" then
		mySelectQuery = "select * from cpu where ID = '" & Request.QueryString("id")&"'"
	else if check = "ram" then			
		mySelectQuery = "select * from ram where ID = '" & Request.QueryString("id")&"'"
	else if check = "hdd" then			
		mySelectQuery = "select * from hdd where ID = '" & Request.QueryString("id")&"'"
	else if check = "mbd" then			
		mySelectQuery = "select * from mbd where ID = '" & Request.QueryString("id")&"'"
	else if check = "vga" then			
		mySelectQuery = "select * from vga where ID = '" & Request.QueryString("id")&"'"
	else if check = "pda" then			
		mySelectQuery = "select * from pda where ID = '" & Request.QueryString("id")&"'"
	else if check = "cdd" then			
		mySelectQuery = "select * from cdd where ID = '" & Request.QueryString("id")&"'"
	else if check = "mon" then			
		mySelectQuery = "select * from mon where ID = '" & Request.QueryString("id")&"'"
	else if check = "snd" then			
		mySelectQuery = "select * from snd where ID = '" & Request.QueryString("id")&"'"
	else if check = "spk" then			
		mySelectQuery = "select * from spk where ID = '" & Request.QueryString("id")&"'"
	else if check = "mdm" then			
		mySelectQuery = "select * from mdm where ID = '" & Request.QueryString("id")&"'"
	else if check = "pnt" then			
		mySelectQuery = "select * from pnt where ID = '" & Request.QueryString("id")&"'"
	else if check = "scn" then			
		mySelectQuery = "select * from scn where ID = '" & Request.QueryString("id")&"'"
	else if check = "ups" then			
		mySelectQuery = "select * from ups where ID = '" & Request.QueryString("id")&"'"
	else if check = "scs" then			
		mySelectQuery = "select * from scs where ID = '" & Request.QueryString("id")&"'"
	else if check = "bup" then			
		mySelectQuery = "select * from bup where ID = '" & Request.QueryString("id")&"'"
	else if check = "cam" then			
		mySelectQuery = "select * from cam where ID = '" & Request.QueryString("id")&"'"
	else if check = "hub" then			
		mySelectQuery = "select * from hub where ID = '" & Request.QueryString("id")&"'"
	else if check = "lan" then			
		mySelectQuery = "select * from lan where ID = '" & Request.QueryString("id")&"'"
	else if check = "hdc" then			
		mySelectQuery = "select * from hdc where ID = '" & Request.QueryString("id")&"'"
	else if check = "nbk" then			
		mySelectQuery = "select * from nbk where ID = '" & Request.QueryString("id")&"'"
	else if check = "mcd" then			
		mySelectQuery = "select * from mcd where ID = '" & Request.QueryString("id")&"'"
	else if check = "opt" then			
		mySelectQuery = "select * from opt where ID = '" & Request.QueryString("id")&"'"
		
	end if			
	
	myConnection = New SqlConnection(myConnString) 
	myConnection.Open() 
	
	If Not Page.IsPostBack Then 
		myCommand = New SqlDataAdapter(mySelectQuery,myConnection) 
		myCommand.Fill(ds) 
		DataGrid_A.DataSource = ds 
		DataGrid_A.DataBind() 
		DataGrid_B.DataSource = ds 
		DataGrid_B.DataBind() 
		myConnection.Close() 
	End If 
End Sub 
	
Sub Page_Error(sender As Object, e As EventArgs) 
		Dim pageEx As String = Server.GetLastError().ToString() 
		pageEx = "<center><h2>��ª���˹ѧ��ͷ�����͡��� ...�ô��ԡ�ѧ���� Back</h2></center>" 
		Response.Write(pageEx) 
		Context.ClearError() 
End Sub
</SCRIPT>
<body runat="server" bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
	<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
		<tr bgColor="#0066cc">
			<TD style="WIDTH: 74px" align="middle">
				<IMG alt="" src="image\page.gif">
			</TD>
			<td>
				<TABLE height="50" width="100%" bgColor="#0066cc">
					<TR>
						<TD style="WIDTH: 544px" align="middle">
							<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
											<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
							</FONT>
						</TD>
						<td align="middle">
							<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
									<%=Day(Now)%>
									/<%=Month(Now)%>
									/<%=(Year(Now))%>
								</FONT></FONT>
						</td>
					</TR>
				</TABLE>
			</td>
		</tr>
	</table>
	<P align="left">
		<hr>
	<P>
	</P>
	<P>
	</P>
	<H2>
		<FONT face="MS Sans Serif" size="3">��������´�ͧ�ػ�ó�ͧ��ҹ��ҧ� </FONT>
		<asp:label id="label0" runat="server" visible="False"></asp:label>
	</H2>
	<% if PriceA <> "Sorry,not 	found" then %>
	<asp:datagrid id="DataGrid_A" runat="server" Font-Size="8pt" Font-Name="Verdana" BorderColor="#E7E7FF" BackColor="White" HeaderStyle-ForeColor="#000040" HeaderStyle-Font-Bold="True" Border="1" Cellpadding="3" AlternatingItemStyle-BackColor="#EFEFEF" CssClass="DataGrid" HeaderStyle-BackColor="#aaaadd" PagerStyle-Mode="NumericPages" BorderStyle="None" GridLines="Horizontal" BorderWidth="1px" Font-Names="Verdana">
		<FooterStyle ForeColor="#4A3C8C" BackColor="#B5C7DE"></FooterStyle>
		<HeaderStyle Font-Bold="True" ForeColor="#F7F7F7" BackColor="#4A3C8C"></HeaderStyle>
		<PagerStyle HorizontalAlign="Right" ForeColor="#4A3C8C" BackColor="#E7E7FF" Mode="NumericPages"></PagerStyle>
		<SelectedItemStyle Font-Bold="True" ForeColor="#F7F7F7" BackColor="#738A9C"></SelectedItemStyle>
		<AlternatingItemStyle BackColor="#F7F7F7"></AlternatingItemStyle>
		<ItemStyle ForeColor="#4A3C8C" BackColor="#E7E7FF"></ItemStyle>
		<Columns>
			<asp:TemplateColumn>
				<HeaderTemplate></HeaderTemplate>
				<ItemTemplate>
					<a href='order.aspx?id=<%#Container.DataItem("ID")%>&price=<%#PriceA%>&shop=Pantip'>
						add basket</a>
				</ItemTemplate>
				<FooterTemplate></FooterTemplate>
			</asp:TemplateColumn>
			<asp:TemplateColumn>
				<HeaderTemplate>
					<table width="100">
						shop
					</table>
				</HeaderTemplate>
				<ItemTemplate>
					�ѹ�Ծ���ҫ��
				</ItemTemplate>
				<FooterTemplate></FooterTemplate>
			</asp:TemplateColumn>
			<asp:TemplateColumn>
				<HeaderTemplate>
					<table width="50">
						Price
					</table>
				</HeaderTemplate>
				<ItemTemplate>
					<%if compare = 1 or compare = 3 then %>
					<b>
						<% end if %>
						<%Response.Write(PriceA) %>
						<asp:label id="Label2" runat="server" visible="False"></asp:label>
				</ItemTemplate>
				<FooterTemplate></FooterTemplate>
			</asp:TemplateColumn>
		</Columns>
	</asp:datagrid>
	<% end if %>
	<% if PriceB <> "Sorry,not found" then %>
	<asp:datagrid id="DataGrid_B" runat="server" Font-Size="8pt" Font-Name="Verdana" BorderColor="#E7E7FF" BackColor="White" HeaderStyle-ForeColor="#000040" HeaderStyle-Font-Bold="True" Border="1" Cellpadding="3" AlternatingItemStyle-BackColor="#EFEFEF" CssClass="DataGrid" HeaderStyle-BackColor="#e8f8ff" PagerStyle-Mode="NumericPages" BorderStyle="None" GridLines="Horizontal" BorderWidth="1px" Font-Names="Verdana">
		<FooterStyle ForeColor="#4A3C8C" BackColor="#B5C7DE"></FooterStyle>
		<HeaderStyle Font-Bold="True" ForeColor="#F7F7F7" BackColor="Teal"></HeaderStyle>
		<PagerStyle HorizontalAlign="Right" ForeColor="#4A3C8C" BackColor="#E7E7FF" Mode="NumericPages"></PagerStyle>
		<SelectedItemStyle Font-Bold="True" ForeColor="#F7F7F7" BackColor="#738A9C"></SelectedItemStyle>
		<AlternatingItemStyle BackColor="#F7F7F7"></AlternatingItemStyle>
		<ItemStyle ForeColor="#4A3C8C" BackColor="#99FFCC"></ItemStyle>
		<Columns>
			<asp:TemplateColumn>
				<HeaderTemplate></HeaderTemplate>
				<ItemTemplate>
					<a href='order.aspx?id=<%#Container.DataItem("ID")%>&price=<%#PriceB%>&shop=Tawanna'>
						add basket</a>
				</ItemTemplate>
				<FooterTemplate></FooterTemplate>
			</asp:TemplateColumn>
			<asp:TemplateColumn>
				<HeaderTemplate>
					<table width="100">
						shop
					</table>
				</HeaderTemplate>
				<ItemTemplate>
					���ѹ��
				</ItemTemplate>
				<FooterTemplate></FooterTemplate>
			</asp:TemplateColumn>
			<asp:TemplateColumn>
				<HeaderTemplate>
					<table width="50">
						Price
					</table>
				</HeaderTemplate>
				<ItemTemplate>
					<%if compare = 2 or compare = 3 	then %>
					<b>
						<% end if %>
						<%Response.Write(PriceB)%>
						<asp:label id="Label3" runat="server" visible="False"></asp:label>
				</ItemTemplate>
				<FooterTemplate></FooterTemplate>
			</asp:TemplateColumn>
		</Columns>
	</asp:datagrid>
	<% end if %>
	<hr>
	<center>
		<A href="main.aspx">��Ѻ令���</A>
	</center>
	<CENTER>
		<CENTER>
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
		</CENTER>
	</CENTER>
</body>
