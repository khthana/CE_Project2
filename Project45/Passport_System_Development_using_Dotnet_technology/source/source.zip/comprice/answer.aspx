<%@ Page Language="vb" AutoEventWireup="false" Codebehind="answer.aspx.vb" Inherits="comprice.answer"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc" -->
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<SCRIPT language="vb" Runat="Server">


Sub Page_Load()

	session.contents.remove(ID)
		

End Sub 

Sub Page_UnLoad()

End Sub

		</SCRIPT>
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
		<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
			<tr bgColor="#0066cc">
				<TD style="WIDTH: 74px" align="middle">
					<IMG alt="" src="image\page.gif">
				</TD>
				<td>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<td align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</td>
						</TR>
					</TABLE>
				</td>
			</tr>
		</table>
		<P>
		</P>
		<UL>
			<LI>
				<FONT face="Tahoma"><STRONG>WEBBOARD </STRONG></FONT><FONT face="Tahoma">
			</LI>
		</UL>
		<HR width="100%" SIZE="1">
		<P>
			</FONT><asp:repeater id="Repeater1" runat="server">
				<ItemTemplate>
					<tr align="left" bgcolor="#ccccff">
						<td style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							��з���ӴѺ���:&nbsp;&nbsp;<b><%# Container.DataItem("id_question")%></b>&nbsp;&nbsp;&nbsp;&nbsp; 
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							��Ǣ��:&nbsp;&nbsp;<b><%# Container.DataItem("topic")%></b>
						</td>
					</tr>
					<tr bgcolor="LightCyan">
						<td align="left" style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<%# Container.DataItem("note")%>
							<p align="left">
								����:&nbsp;&nbsp;<%# Container.DataItem("name")%>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								email:&nbsp;&nbsp;<%# Container.DataItem("email")%>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								Posted:&nbsp;&nbsp;<%# Container.DataItem("date")%>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								IP ����ͧ����駡�з��:&nbsp;&nbsp;<%# Container.DataItem("ip")%>
						</td>
					</tr>
				</ItemTemplate>
				<HeaderTemplate>
					<table align="center" border="0" cellspacing="1" cellpadding="2" width="100%">
				</HeaderTemplate>
				<FooterTemplate>
					</table>
				</FooterTemplate>
			</asp:repeater>
		</P>
		<form id="Form1" action="" runat="server">
			<P>
				&nbsp;
				<asp:panel id="Panel1" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="Small" Width="324px" Height="20px" BackColor="#FFE0C0" Font-Bold="True" BorderColor="White" ForeColor="Blue" HorizontalAlign="Center">�ԭ�����ʴ������Դ���</asp:panel>
			</P>
			<P>
				<asp:label id="Label1" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="46px" Height="21px" BackColor="#FFE0C0">�ҡ�س*</asp:label>
				<asp:textbox id="name" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="193px" Height="21px" BackColor="Info"></asp:textbox>
			</P>
			<P>
				<asp:label id="Label2" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="45px" Height="22px" BackColor="#FFE0C0">������</asp:label>
				<asp:textbox id="email" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="193px" Height="22px" BackColor="Info"></asp:textbox>
			</P>
			<P>
				<asp:label id="Label4" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="45px" Height="124px" BackColor="#FFE0C0">��ͤ���*</asp:label>
				<asp:textbox id="note" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="337px" Height="126px" BackColor="Info" TextMode="MultiLine"></asp:textbox>
			</P>
			<P align="left">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<asp:button id="Reset" runat="server" Width="59px" Height="24px" ForeColor="Blue" Text="Reset"></asp:button>
				&nbsp;&nbsp;&nbsp;
				<asp:button id="Submit" runat="server" ForeColor="Blue" Text="Submit"></asp:button>
			</P>
		</form>
		<P>
		</P>
		<P>
			<asp:panel id="Panel4" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="Small" Width="439px" Height="6px" BackColor="#FF8080" Font-Bold="True" HorizontalAlign="Center" Visible="False">!!! �س�ѧ��͡��������ǹ�Ӥѭ���ú 
��سҡ�͡���ú���¤�Ѻ</asp:panel>
		</P>
		<P>
			<asp:repeater id="Repeater2" runat="server">
				<HeaderTemplate>
					<table align="center" border="0" cellspacing="0" cellpadding="2" width="100%">
				</HeaderTemplate>
				<FooterTemplate>
					</table>
				</FooterTemplate>
				<ItemTemplate>
					<tr bgcolor="#FFE0C0">
						<td style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							���ͺ��з��:&nbsp;&nbsp;<%# Container.DataItem("name")%>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
							email:&nbsp;&nbsp;<%# Container.DataItem("email")%>
						</td>
					</tr>
					<tr bgcolor="LemonChiffon">
						<td align="left" style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<%# Container.DataItem("note")%>
							<p align="left">
								Posted:&nbsp;&nbsp;<%# Container.DataItem("date")%>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
								IP ����ͧ���ͺ��з��:&nbsp;&nbsp;<%# Container.DataItem("ip")%>
							</p>
						</td>
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
					<tr bgcolor="#ffffff">
					</tr>
				</ItemTemplate>
			</asp:repeater>
		</P>
		<P>
			<hr>
		<P>
		</P>
		<CENTER>
			<A href="main.aspx">��Ѻ令���</A>&nbsp;&nbsp;
		</CENTER>
		<CENTER>
			<CENTER>
				<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
			</CENTER>
		</CENTER>
	</body>
</HTML>
