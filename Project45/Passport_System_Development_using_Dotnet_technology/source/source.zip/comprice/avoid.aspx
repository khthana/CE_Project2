<%@ Import Namespace="System.Web.SessionState.HttpSessionState" %>
<%@ Import Namespace="System.Data"%>
<%@ Page Language="vb" AutoEventWireup="false" Codebehind="avoid.aspx.vb" Inherits="comprice.avoid"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc" -->
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<SCRIPT Language="vb" Runat="Server">


Sub Page_Load()

	session.contents.remove(ID)
		

End Sub 

Sub Page_UnLoad()

End Sub

		</SCRIPT>
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
			<tr bgColor="#0066cc">
				<TD style="WIDTH: 74px" align="middle">
					<IMG alt="" src="image\page.gif">
				</TD>
				<td>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<td align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</td>
						</TR>
					</TABLE>
				</td>
			</tr>
		</table>
		<br>
		<br>
		<DIV align="center">
			<font size="5" color="red">��سҷӡ�� Login ������͹</font>
		</DIV>
		<DIV align="center">
			<br>
			<a href="https://network07.ce.kmitl.ac.th/passport/login.aspx?url=http://network07.ce.kmitl.ac.th/comprice/main.aspx">
				��ԡ������ҵ�ͧ�����ҡ�Ѻ价ӡ�� login</a>
			<br>
			<a href="main.aspx">��ԡ������ҵ�ͧ�����ҡ�Ѻ˹���á�ͧ web </a>
		</DIV>
	</body>
</HTML>
