<%@ Page Language="vb" AutoEventWireup="false" Codebehind="newque<BODY><BODY><BODY><BODY>stion.aspx.vb" Inherits="comprice.newquestion"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<TITLE></</TITLE>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<!--#include file = "head.inc" -->
		<SCRIPT language="vb" Runat="Server">


Sub Page_Load()

	session.contents.remove(ID)
		

End Sub 

Sub Page_UnLoad()

End Sub

		</SCRIPT>
	</HEAD>
	<DIV align="center">
		<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" align="center" borderColorLight="#0066cc" border="1">
			<tr bgColor="#0066cc">
				<TD style="WIDTH: 74px" align="middle">
					<IMG alt="" src="image\page.gif">
				</TD>
				<td>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<td align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</td>
						</TR>
					</TABLE>
				</td>
			</tr>
		</table>
	</DIV>
	<P align="center">
	</P>
	<UL>
		<LI>
			<DIV align="left">
				<FONT face="Tahoma"><STRONG>WEBBOARD </STRONG></FONT><FONT face="Tahoma">
			</DIV>
		</LI>
	</UL>
	<DIV align="center">
		<HR width="100%" SIZE="1">
	</DIV>
	<P align="left">
		<asp:panel id="Panel1" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="Small" Width="729px" Height="20px" BackColor="#FFE0C0" Font-Bold="True" BorderColor="White" ForeColor="Blue" HorizontalAlign="Center">
			�ԭ�����ʴ������Դ���</asp:panel>
	</P>
	<P align="center">
	</P>
	<P align="center">
	</P>
	<P align="center">
	</P>
	<P align="center">
	</P>
	<P align="center">
	</P>
	<P align="center">
	</P>
	<P align="center">
	</P>
	<P align="center">
		<FORM id="Form1" method="post" runat="server">
			<P align="justify">
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<asp:label id="Label1" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="46px" Height="21px" BackColor="#FFE0C0">
					�ҡ�س*</asp:label>
				<asp:textbox id="name" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="193px" Height="21px" BackColor="Info">
				</asp:textbox>
			</P>
			<P>
			</P>
			<FONT face="Tahoma">
				<P align="left">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<asp:label id="Label2" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="45px" Height="22px" BackColor="#FFE0C0">
						������</asp:label>
					<asp:textbox id="email" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="193px" Height="22px" BackColor="Info">
					</asp:textbox>
				</P>
				<P align="left">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<asp:label id="Label3" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="45px" Height="21px" BackColor="#FFE0C0" DESIGNTIMEDRAGDROP="1126">
						��Ǣ��*</asp:label>
					<asp:textbox id="topic" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="227px" Height="22px" BackColor="Info">
					</asp:textbox>
				</P>
				<P align="left">
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<asp:label id="Label4" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="45px" Height="124px" BackColor="#FFE0C0">
						��ͤ���*</asp:label>
			</FONT>
			<asp:textbox id="note" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="280px" Height="124px" BackColor="Info" TextMode="MultiLine">
			</asp:textbox>
	</P>
	<P align="left">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<asp:hyperlink id="BackMain" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="X-Small" Width="68px" Height="24px" BackColor="#FFE0C0" ForeColor="Blue" BorderStyle="Groove" NavigateUrl="Webboard.aspx">
			��Ѻ˹����ѡ</asp:hyperlink>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<asp:button id="Submit" runat="server" ForeColor="Blue" Text="Submit">
		</asp:button>
		<asp:button id="Reset" runat="server" Width="59px" Height="24px" ForeColor="Blue" Text="Reset">
		</asp:button>
	</P>
	<P align="center">
		<asp:panel id="Panel2" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="Small" Width="439px" Height="6px" BackColor="#FF8080" Font-Bold="True" HorizontalAlign="Center" Visible="False">
			!!! �س�ѧ��͡��������ǹ�Ӥѭ���ú ��سҡ�͡���ú���¤�Ѻ</asp:panel>
	</P>
	<P align="left">
		</FONT>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</P>
	</FORM>
	<P>
	<P>
	</P>
	<P>
		<HR>
	<P>
	</P>
	<CENTER>
		<A href="main.aspx">��Ѻ令���</A>&nbsp;&nbsp;
	</CENTER>
	<CENTER>
		<CENTER>
			<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
		</CENTER>
	</CENTER>
	<P>
	</P>
</HTML>
