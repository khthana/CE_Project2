<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>
<META http-equiv="Content-Type" content="text/html; charset=windows-874">
<!--#include file = "head.inc"-->
<SCRIPT language="vb" Runat="Server">
Dim myConnection As SqlConnection
Dim mySelectQuery As String
Dim myAdapter As SqlDataAdapter
Dim myCommand As SqlCommand
Dim Price As String


Sub Page_Load()
	try
	    If request.cookies("passport").value = "logoutted" Then
            'Response.Redirect("main.aspx")
            Response.Redirect("avoid.aspx")
        End If
		
	catch
	Response.Redirect("avoid.aspx")
	end try
	
	Dim check As String
    Dim myConnString As String
    Dim ds As DataSet = new DataSet() 

	myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
		label0.Text = Request.QueryString("id")
		label1.Text = Request.QueryString("price")
		label2.Text = Request.QueryString("shop")
		Price = Request.QueryString("price")
		
		
	check = Left(label0.Text,3)
	if check = "cpu" then
		mySelectQuery = "select * from cpu where ID = '" & Request.QueryString("id")&"'"
	else if check = "ram" then			
		mySelectQuery = "select * from ram where ID = '" & Request.QueryString("id")&"'"
	else if check = "hdd" then			
		mySelectQuery = "select * from hdd where ID = '" & Request.QueryString("id")&"'"
	else if check = "mbd" then			
		mySelectQuery = "select * from mbd where ID = '" & Request.QueryString("id")&"'"
	else if check = "vga" then			
		mySelectQuery = "select * from vga where ID = '" & Request.QueryString("id")&"'"
	else if check = "pda" then			
		mySelectQuery = "select * from pda where ID = '" & Request.QueryString("id")&"'"
	else if check = "cdd" then			
		mySelectQuery = "select * from cdd where ID = '" & Request.QueryString("id")&"'"
	else if check = "mon" then			
		mySelectQuery = "select * from mon where ID = '" & Request.QueryString("id")&"'"
	else if check = "snd" then			
		mySelectQuery = "select * from snd where ID = '" & Request.QueryString("id")&"'"
	else if check = "spk" then			
		mySelectQuery = "select * from spk where ID = '" & Request.QueryString("id")&"'"
	else if check = "mdm" then			
		mySelectQuery = "select * from mdm where ID = '" & Request.QueryString("id")&"'"
	else if check = "pnt" then			
		mySelectQuery = "select * from pnt where ID = '" & Request.QueryString("id")&"'"
	else if check = "scn" then			
		mySelectQuery = "select * from scn where ID = '" & Request.QueryString("id")&"'"
	else if check = "ups" then			
		mySelectQuery = "select * from ups where ID = '" & Request.QueryString("id")&"'"
	else if check = "scs" then			
		mySelectQuery = "select * from scs where ID = '" & Request.QueryString("id")&"'"
	else if check = "bup" then			
		mySelectQuery = "select * from bup where ID = '" & Request.QueryString("id")&"'"
	else if check = "cam" then			
		mySelectQuery = "select * from cam where ID = '" & Request.QueryString("id")&"'"
	else if check = "hub" then			
		mySelectQuery = "select * from hub where ID = '" & Request.QueryString("id")&"'"
	else if check = "lan" then			
		mySelectQuery = "select * from lan where ID = '" & Request.QueryString("id")&"'"
	else if check = "hdc" then			
		mySelectQuery = "select * from hdc where ID = '" & Request.QueryString("id")&"'"
	else if check = "nbk" then			
		mySelectQuery = "select * from nbk where ID = '" & Request.QueryString("id")&"'"
	else if check = "mcd" then			
		mySelectQuery = "select * from mcd where ID = '" & Request.QueryString("id")&"'"
	else if check = "opt" then			
		mySelectQuery = "select * from opt where ID = '" & Request.QueryString("id")&"'"
		
	end if			
	myConnection = New SqlConnection(myConnString) 
	myConnection.Open() 
	
	If Not Page.IsPostBack Then 
		myAdapter = New SqlDataAdapter(mySelectQuery,myConnection) 
		myAdapter.Fill(ds) 
		DataGrid1.DataSource = ds 
		DataGrid1.DataBind() 
	End If 
End Sub 

Sub Page_UnLoad()
	myConnection.Close()
End Sub



Sub clickButton1(Sender As Object, e As EventArgs)
	
	if text1.text < 1 or text1.text > 99 then
		label4.text="�س����ä��͡�ӹǹ�Թ����������ҧ 1-99"
		label4.visible=true
	else		
	
	mySelectQuery = "INSERT INTO orderDetail (ID, quantity, orderID, price ,shop ,status,pre_date) " & _
			"VALUES ('" & label0.Text & "'," & text1.Text & ",'" & request.cookies("passport").value & _
			"'," & label1.Text & ",'" & label2.Text & "','�͡����觫���','" & now & "')"

	myCommand = New SqlCommand(mySelectQuery, myConnection)
	myCommand.ExecuteNonQuery()

	Response.Redirect("orderlist.aspx")
	end if
End Sub

	</SCRIPT>
<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
	<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
		<tr bgColor="#0066cc">
			<TD style="WIDTH: 74px" align="middle">
				<IMG alt="" src="image\page.gif">
			</TD>
			<td>
				<TABLE height="50" width="100%" bgColor="#0066cc">
					<TR>
						<TD style="WIDTH: 544px" align="middle">
							<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
											<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
							</FONT>
						</TD>
						<td align="middle">
							<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
									<%=Day(Now)%>
									/<%=Month(Now)%>
									/<%=(Year(Now))%>
								</FONT></FONT>
						</td>
					</TR>
				</TABLE>
			</td>
		</tr>
	</table>
	<hr>
	<H2>
		<FONT size="3">�ô�кبӹǹ����ͧ�����觫���</FONT>
	</H2>
	<asp:label id="label0" runat="server" visible="false" />
	<asp:label id="Label1" runat="server" visible="false" />
	<asp:label id="Label2" runat="server" visible="false" />
	<p>
		<TABLE width="80%">
			<TR>
				<TD width="75%" bgcolor="#ffff99">
					<form id="Form1" runat="server">
						<P>
							<asp:datagrid id="DataGrid1" runat="server" Font-Size="8pt" Font-Name="Verdana" BorderColor="#E7E7FF" BackColor="White" HeaderStyle-ForeColor="#000040" HeaderStyle-Font-Bold="True" Border="1" Cellpadding="3" AlternatingItemStyle-BackColor="#EFEFEF" CssClass="DataGrid" HeaderStyle-BackColor="#e8f8ff" PagerStyle-Mode="NumericPages" BorderStyle="None" GridLines="Horizontal" BorderWidth="1px" Font-Names="Verdana">
								<FooterStyle ForeColor="#4A3C8C" BackColor="#B5C7DE"></FooterStyle>
								<HeaderStyle Font-Bold="True" ForeColor="#333300" BackColor="#FFFF33"></HeaderStyle>
								<PagerStyle HorizontalAlign="Right" ForeColor="#4A3C8C" BackColor="#E7E7FF" Mode="NumericPages"></PagerStyle>
								<SelectedItemStyle Font-Bold="True" ForeColor="#F7F7F7" BackColor="#738A9C"></SelectedItemStyle>
								<AlternatingItemStyle BackColor="#F7F7F7"></AlternatingItemStyle>
								<ItemStyle ForeColor="#4A3C8C" BackColor="#FFFF99"></ItemStyle>
								<Columns>
									<asp:TemplateColumn>
										<HeaderTemplate></HeaderTemplate>
										<ItemTemplate></ItemTemplate>
										<FooterTemplate></FooterTemplate>
									</asp:TemplateColumn>
									<asp:TemplateColumn>
										<HeaderTemplate></HeaderTemplate>
										<ItemTemplate></ItemTemplate>
										<FooterTemplate></FooterTemplate>
									</asp:TemplateColumn>
									<asp:TemplateColumn>
										<HeaderTemplate>
											<table width="50">
												Price
											</table>
										</HeaderTemplate>
										<ItemTemplate>
											<%Response.Write(Price) %>
											<asp:label id="Label3" runat="server" visible="False" />
										</ItemTemplate>
										<FooterTemplate></FooterTemplate>
									</asp:TemplateColumn>
								</Columns>
							</asp:datagrid>
							<br>
							�ӹǹ����ͧ�����觫��� :
							<asp:textbox id="text1" runat="server" size="10" />
							<font color="#ff0000">
								<asp:label id="Label4" runat="server" visible="false" />
							</font>
						</P>
						<P>
						</P>
						<P>
							<hr>
						<P>
						</P>
						<P>
							<asp:button id="button1" onclick="clickButton1" runat="server" Text="�ѹ�֡"></asp:button>
						</P>
					</form>
				</TD>
			</TR>
		</TABLE>
		<hr>
		<center>
			<A href="main.aspx">��Ѻ令���</A>
		</center>
		<CENTER>
			<CENTER>
				<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
			</CENTER>
		</CENTER>
</body>
