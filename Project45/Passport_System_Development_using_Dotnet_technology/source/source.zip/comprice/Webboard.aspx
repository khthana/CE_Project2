<%@Import namespace="System.Data.SqlTypes"%>
<%@Import namespace="System.Data.SqlClient"%>
<%@Import namespace="System.Data.OleDb"%>
<%@Import namespace="System.Data"%>
<%@Import namespace="System"%>
<%@ Page Language="vb" AutoEventWireup="false" Codebehind="Webboard.aspx.vb" Inherits="comprice.Webboard"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc" -->
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
		<SCRIPT language="vb" Runat="Server">


Sub Page_Load()

	session.contents.remove(ID)
		

End Sub 

Sub Page_UnLoad()

End Sub

		</SCRIPT>
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
		<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
			<tr bgColor="#0066cc">
				<TD style="WIDTH: 74px" align="middle">
					<IMG alt="" src="image\page.gif">
				</TD>
				<td>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<td align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</td>
						</TR>
					</TABLE>
				</td>
			</tr>
		</table>
		<P>
			<FORM id="Form2" method="post" runat="server">
		</P>
		<UL>
			<LI>
				<FONT face="Tahoma"><STRONG>WEBBOARD </STRONG></FONT><FONT face="Tahoma">
			</LI>
		</UL>
		<HR width="100%" SIZE="1">
		<P align="right">
			<asp:label id="Label1" runat="server" Height="11px" Width="57px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif">
					���ҡ�з��</asp:label>
			&nbsp; </FONT>
			<asp:textbox id="TextBox1" runat="server" Height="23px" Width="156px" ForeColor="Black" BorderColor="White" BackColor="White"></asp:textbox>
			<asp:button id="Search" runat="server" Width="106px" Height="24px" BackColor="#E0E0E0" BorderColor="White" ForeColor="Blue" Text="Search"></asp:button>
		</P>
		<P>
			<asp:hyperlink id="HyperLink2" runat="server" Height="15px" Width="54px" Font-Size="X-Small" Font-Names="Microsoft Sans Serif" NavigateUrl="newquestion.aspx">
					��駡�з��</asp:hyperlink>
		</P>
		</FORM>
		<P>
			<asp:Repeater id="Repeater1" runat="server">
				<HeaderTemplate>
					<table border="0" width="100%" cellspacing="2">
						<tr bgcolor="#0099cc">
							<th width="10%">
								Number</th>
							<th width="20%">
								Created</th>
							<th width="35%">
								Topic</th>
							<th width="20%">
								Topic Starter</th>
							<th>
								Reader Poser</th>
						</tr>
				</HeaderTemplate>
				<ItemTemplate>
					<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'" bgcolor="PapayaWhip">
						<td align="center">
							<%# Container.DataItem("ID_Question") %>
						</td>
						<td>
							<%# Container.DataItem("Date") %>
						</td>
						<td>
							&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID_Question") %>" target="_blank">
								<%# Container.DataItem("Topic") %>
							</a>
							<!--<%# Container.DataItem("Topic") %>-->
						</td>
						<td>
							&nbsp;&nbsp;
							<%# Container.DataItem("Name") %>
						</td>
						<td align="center">
							<%# Container.DataItem("NAnswer") %>
						</td>
					</tr>
				</ItemTemplate>
				<AlternatingItemTemplate>
					<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'" bgcolor="Lavender">
						<td align="center">
							<%#Container.DataItem("ID_Question")%>
						</td>
						<td>
							<%# Container.DataItem("Date") %>
						</td>
						<td>
							&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID_Question") %>" target="_blank">
								<%# Container.DataItem("Topic") %>
							</a>
							<!--<%# Container.DataItem("Topic") %>-->
						</td>
						<td>
							&nbsp;&nbsp;
							<%# Container.DataItem("Name") %>
						</td>
						<td align="center">
							<%# Container.DataItem("NAnswer") %>
						</td>
					</tr>
				</AlternatingItemTemplate>
				<FooterTemplate>
					</table>
					<div align="right" class="text">
						<a href="newquestion.aspx">��駡�з��</a>
					</div>
				</FooterTemplate>
			</asp:Repeater>
		</P>
		<P align="center">
			<asp:label id="Label2" runat="server" Height="21px" Width="145px" ForeColor="Red" Font-Size="Small" Font-Names="Microsoft Sans Serif">
					�ѧ����դ��ʡ�з���Ѻ</asp:label>
		</P>
		<P align="center">
			<asp:hyperlink id="HyperLink1" runat="server" Font-Names="Microsoft Sans Serif" Font-Size="Small" Width="85px" Height="21px" NavigateUrl="newquestion.aspx?new=1">
					��駡�з������</asp:hyperlink>
		</P>
		<P align="center">
			<asp:panel id="Panel2" runat="server" Height="31px" Width="194px" ForeColor="Black" BackColor="#FF8080" Font-Size="Large" Font-Names="Microsoft Sans Serif">��辺��з�����ͧ���</asp:panel>
		</P>
		<P align="center">
			<asp:panel id="Panel3" runat="server" Height="51px" Width="865px">
				<asp:Repeater id="Repeater2" runat="server">
					<HeaderTemplate>
						<table border="0" width="100%" cellspacing="2">
							<tr bgcolor="#0099cc">
								<th width="10%">
									Number</th>
								<th width="20%">
									Created</th>
								<th width="35%">
									Topic</th>
								<th width="20%">
									Topic Starter</th>
								<th>
									Reader Poser</th>
							</tr>
					</HeaderTemplate>
					<FooterTemplate>
						</table>
					</FooterTemplate>
					<ItemTemplate>
						<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<td align="center" bgcolor="PapayaWhip">
								<%#Container.DataItem("ID_Question")%>
							</td>
							<td bgcolor="Lavender">
								<%# Container.DataItem("Date") %>
							</td>
							<td bgcolor="PapayaWhip">
								&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID_Question") %>" target="_blank">
									<%# Container.DataItem("Topic") %>
								</a>
								<!--<%# Container.DataItem("Topic") %>-->
							</td>
							<td bgcolor="Lavender">
								&nbsp;&nbsp;
								<%# Container.DataItem("Name") %>
							</td>
							<td align="center" bgcolor="PapayaWhip">
								<%# Container.DataItem("NAnswer") %>
							</td>
						</tr>
					</ItemTemplate>
					<AlternatingItemTemplate>
						<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<td align="center" bgcolor="PapayaWhip">
								<%#Container.DataItem("ID_Question")%>
							</td>
							<td bgcolor="Lavender">
								<%# Container.DataItem("Date") %>
							</td>
							<td bgcolor="PapayaWhip">
								&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID_Question") %>" target="_blank">
									<%# Container.DataItem("Topic") %>
								</a>
								<!--<%# Container.DataItem("Topic") %>-->
							</td>
							<td bgcolor="Lavender">
								&nbsp;&nbsp;
								<%# Container.DataItem("Name") %>
							</td>
							<td align="center" bgcolor="PapayaWhip">
								<%# Container.DataItem("NAnswer") %>
							</td>
						</tr>
					</AlternatingItemTemplate>
				</asp:Repeater>
			</asp:panel>
		</P>
		<P>
		</P>
		<P>
			&nbsp;
			<asp:panel id="Panel4" runat="server" Height="19px" Width="866px">
				<asp:Repeater id="Repeater3" runat="server">
					<HeaderTemplate>
						<table border="0" width="100%" cellspacing="2">
						<!--<tr bgcolor="#0099cc">
									<th width="10%">
										Number</th>
									<th width="20%">
										Created</th>
									<th width="35%">
										Topic</th>
									<th width="20%">
										Topic Starter</th>
									<th>
										Reader Poser</th>
								</tr>-->
					</HeaderTemplate>
					<FooterTemplate>
						</table>
					</FooterTemplate>
					<ItemTemplate>
						<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<td align="center" width="10%" bgcolor="PapayaWhip">
								<%#Container.DataItem("ID")%>
							</td>
							<td width="20%" bgcolor="Lavender">
								<%# Container.DataItem("Date") %>
							</td>
							<td width="35%" bgcolor="PapayaWhip">
								&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID") %>" target="_blank">
									<%# Container.DataItem("Topic") %>
								</a>
								<!--<%# Container.DataItem("Topic") %>-->
							</td>
							<td width="20%" bgcolor="Lavender">
								&nbsp;&nbsp;
								<%# Container.DataItem("Name") %>
							</td>
							<td align="center" bgcolor="PapayaWhip">
								<%# Container.DataItem("NAnswer") %>
							</td>
						</tr>
					</ItemTemplate>
					<AlternatingItemTemplate>
						<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<td align="center" width="10%" bgcolor="PapayaWhip">
								<%#Container.DataItem("ID")%>
							</td>
							<td width="20%" bgcolor="Lavender">
								<%# Container.DataItem("Date") %>
							</td>
							<td width="35%" bgcolor="PapayaWhip">
								&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID") %>" target="_blank">
									<%# Container.DataItem("Topic") %>
								</a>
								<!--<%# Container.DataItem("Topic") %>-->
							</td>
							<td width="20%" bgcolor="Lavender">
								&nbsp;&nbsp;
								<%# Container.DataItem("Name") %>
							</td>
							<td align="center" bgcolor="PapayaWhip">
								<%# Container.DataItem("NAnswer") %>
							</td>
						</tr>
					</AlternatingItemTemplate>
				</asp:Repeater>
			</asp:panel>
		</P>
		<P>
			&nbsp;
			<asp:Panel id="Panel5" runat="server" Height="19px" Width="865px">
				<asp:Repeater id="Repeater4" runat="server">
					<HeaderTemplate>
						<table border="0" width="100%" cellspacing="2">
							<tr bgcolor="#0099cc">
								<th width="10%">
									Number</th>
								<th width="20%">
									Created</th>
								<th width="35%">
									Topic</th>
								<th width="20%">
									Topic Starter</th>
								<th>
									Reader Poser</th>
							</tr>
					</HeaderTemplate>
					<FooterTemplate>
						</table>
					</FooterTemplate>
					<ItemTemplate>
						<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<td align="center" width="10%" bgcolor="PapayaWhip">
								<%#Container.DataItem("ID")%>
							</td>
							<td width="20%" bgcolor="Lavender">
								<%# Container.DataItem("Date") %>
							</td>
							<td width="35%" bgcolor="PapayaWhip">
								&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID") %>" target="_blank">
									<%# Container.DataItem("Topic") %>
								</a>
								<!--<%# Container.DataItem("Topic") %>-->
							</td>
							<td width="20%" bgcolor="Lavender">
								&nbsp;&nbsp;
								<%# Container.DataItem("Name") %>
							</td>
							<td align="center" bgcolor="PapayaWhip">
								<%# Container.DataItem("NAnswer") %>
							</td>
						</tr>
					</ItemTemplate>
					<AlternatingItemTemplate>
						<tr style="FONT-SIZE: 12px; FONT-FAMILY: 'Microsoft Sans Serif'">
							<td align="center" width="10%" bgcolor="PapayaWhip">
								<%#Container.DataItem("ID")%>
							</td>
							<td width="20%" bgcolor="Lavender">
								<%# Container.DataItem("Date") %>
							</td>
							<td width="35%" bgcolor="PapayaWhip">
								&nbsp; <a href="answer.aspx?id=<%# Container.DataItem("ID") %>" target="_blank">
									<%# Container.DataItem("Topic") %>
								</a>
								<!--<%# Container.DataItem("Topic") %>-->
							</td>
							<td width="20%" bgcolor="Lavender">
								&nbsp;&nbsp;
								<%# Container.DataItem("Name") %>
							</td>
							<td align="center" bgcolor="PapayaWhip">
								<%# Container.DataItem("NAnswer") %>
							</td>
						</tr>
					</AlternatingItemTemplate>
				</asp:Repeater>
			</asp:Panel>
		</P>
		<P align="center">
			&nbsp;
			<asp:hyperlink id="HyperLink3" runat="server" Font-Size="X-Small" Font-Names="Microsoft Sans Serif" NavigateUrl="Webboard.aspx" Visible="False">
					��Ѻ˹����ѡ</asp:hyperlink>
		</P>
		<P>
			<HR>
		<P>
		</P>
		<P>
		</P>
		<P>
		</P>
		<CENTER>
			<A href="main.aspx">��Ѻ令���</A>&nbsp;&nbsp;
		</CENTER>
		<CENTER>
			<CENTER>
				<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
			</CENTER>
		</CENTER>
	</body>
</HTML>
