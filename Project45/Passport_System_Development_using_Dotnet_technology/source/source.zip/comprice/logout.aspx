<%@ Import Namespace="System.Web.SessionState.HttpSessionState" %>
<%@ Import Namespace="System.Data"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc" -->
		<SCRIPT Language="vb" Runat="Server">


Sub Page_Load()

	session.contents.remove(ID)
		

End Sub 

Sub Page_UnLoad()

End Sub

		</SCRIPT>
		<META http-equiv="Content-Type" content="text/html; charset=windows-874">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<DIV align="center">
			<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1" align="center">
				<tr bgColor="#0066cc">
					<TD style="WIDTH: 74px" align="middle">
						<IMG alt="" src="image\page.gif">
					</TD>
					<td>
						<TABLE height="50" width="100%" bgColor="#0066cc">
							<TR>
								<TD style="WIDTH: 544px" align="middle">
									<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
													<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
									</FONT>
								</TD>
								<td align="middle">
									<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
											<%=Day(Now)%>
											/<%=Month(Now)%>
											/<%=(Year(Now))%>
										</FONT></FONT>
								</td>
							</TR>
						</TABLE>
					</td>
				</tr>
			</table>
		</DIV>
		<br>
		<br>
		<DIV align="center">
			<FONT size="5" color="#000000">�س�ӡ���͡�ҡ�к����º��������</FONT>
		</DIV>
		<DIV align="center">
			<br>
			<a href="webform8.aspx">��ԡ������ҵ�ͧ�����ҡ�Ѻ价ӡ�� login ����</a>
			<br>
			<a href="webform4.aspx">��ԡ������ҵ�ͧ�����ҡ�Ѻ˹���á�ͧ web </a>
		</DIV>
		<DIV align="center">
			<CENTER>
				<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
			</CENTER>
		</DIV>
	</body>
</HTML>
