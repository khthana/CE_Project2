<%@ Page Language="vb" AutoEventWireup="false" Codebehind="orderlist.aspx.vb" Inherits="comprice.orderlist"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>
<!--#include file = "head.inc"-->
<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
	<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
		<tr bgColor="#0066cc">
			<TD style="WIDTH: 74px" align="middle">
				<IMG alt="" src="image\page.gif">
			</TD>
			<td>
				<TABLE height="50" width="100%" bgColor="#0066cc">
					<TR>
						<TD style="WIDTH: 544px" align="middle">
							<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
											<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
							</FONT>
						</TD>
						<td align="middle">
							<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
									<%=Day(Now)%>
									/<%=Month(Now)%>
									/<%=(Year(Now))%>
								</FONT></FONT>
						</td>
					</TR>
				</TABLE>
			</td>
		</tr>
	</table>
	<hr>
	<H2>
		<FONT size="3">��¡����觫��ͧ͢ </FONT>
		<asp:label id="Label3" runat="server" ForeColor="#8080FF" Font-Size="Medium">Label</asp:label>
	</H2>
	<p>
		<form id="Form1" runat="server">
			<asp:datagrid id="datagrid1" runat="server" OnUpdateCommand="update" OnDeleteCommand="delete" OnCancelCommand="cancel" OnEditCommand="edit" DataKeyField="ID" AutoGenerateColumns="False" CellPadding="4" BackColor="White" BorderStyle="None" BorderWidth="1px" BorderColor="#3366CC" Width="945px" Height="165px">
				<FooterStyle ForeColor="#003399" BackColor="#99CCCC"></FooterStyle>
				<HeaderStyle Font-Size="Small" ForeColor="#CCCCFF" BackColor="#003399"></HeaderStyle>
				<PagerStyle HorizontalAlign="Left" ForeColor="#003399" BackColor="#99CCCC" Mode="NumericPages"></PagerStyle>
				<SelectedItemStyle Font-Bold="True" ForeColor="#CCFF99" BackColor="#009999"></SelectedItemStyle>
				<ItemStyle ForeColor="#003399" BackColor="White"></ItemStyle>
				<Columns>
					<asp:TemplateColumn>
						<ItemTemplate>
							<asp:LinkButton runat="server" Text="���" CommandName="Edit" CausesValidation="false"></asp:LinkButton>
						</ItemTemplate>
						<EditItemTemplate>
							<asp:LinkButton runat="server" Text="�ѹ�֡" CommandName="Update"></asp:LinkButton>
							&nbsp;
							<asp:LinkButton runat="server" Text="¡��ԡ" CommandName="Cancel" CausesValidation="false"></asp:LinkButton>
						</EditItemTemplate>
					</asp:TemplateColumn>
					<asp:ButtonColumn Text="ź" CommandName="delete"></asp:ButtonColumn>
					<asp:BoundColumn DataField="Id" ReadOnly="True" HeaderText="�����Թ���"></asp:BoundColumn>
					<asp:BoundColumn DataField="shop" ReadOnly="True" HeaderText="������ҹ���"></asp:BoundColumn>
					<asp:BoundColumn DataField="price" ReadOnly="True" HeaderText="�Ҥ� (�ҷ)" DataFormatString="{0:c}"></asp:BoundColumn>
					<asp:BoundColumn DataField="qty" HeaderText="�ӹǹ (����)"></asp:BoundColumn>
					<asp:BoundColumn DataField="amt" ReadOnly="True" HeaderText="�ӹǹ�Թ (�ҷ)" DataFormatString="{0:c}"></asp:BoundColumn>
					<asp:BoundColumn DataField="status" ReadOnly="True" HeaderText="ʶҹТͧ�Թ���"></asp:BoundColumn>
					<asp:BoundColumn DataField="pre_date" ReadOnly="True" HeaderText="�ѹ���ҷ�����͡ŧö��"></asp:BoundColumn>
					<asp:BoundColumn DataField="pos_date" ReadOnly="True" HeaderText="�ѹ���ҷ������觫���"></asp:BoundColumn>
				</Columns>
			</asp:datagrid>
			<hr>
			<CENTER>
				<asp:label id="Label1" runat="server">������ʼ�ҹ passport �ͧ��ҹ�ա���������׹�ѹ�����觫���</asp:label>
				<asp:textbox id="TextBox1" runat="server" TextMode="Password"></asp:textbox>
				&nbsp;
				<asp:label id="Label2" runat="server" Visible="False" ForeColor="Red">Label</asp:label>
			</CENTER>
			<CENTER>
				<A href="main.aspx">��Ѻ令���</A> &nbsp;
				<asp:linkbutton id="link1" runat="server" Text="��觫���"></asp:linkbutton>
			</CENTER>
			<CENTER>
				<CENTER>
					<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
				</CENTER>
			</CENTER>
		</form>
</body>
