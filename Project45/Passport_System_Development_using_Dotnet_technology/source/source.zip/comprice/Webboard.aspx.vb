Imports System.Web
Imports System.Web.Services
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Public Class Webboard
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SqlConn = New System.Data.SqlClient.SqlConnection()
        Me.OleDbConn = New System.Data.OleDb.OleDbConnection()
        '
        'SqlConn
        '
        Me.SqlConn.ConnectionString = "data source=OHM;initial catalog=webboard;integrated security=SSPI;persist securit" & _
        "y info=False;workstation id=OHM;packet size=4096"
        '
        'OleDbConn
        '
        Me.OleDbConn.ConnectionString = "Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial " & _
        "Catalog=webboard;Data Source=OHM;Use Procedure for Prepare=1;Auto Translate=True" & _
        ";Packet Size=4096;Workstation ID=OHM;Use Encryption for Data=False;Tag with colu" & _
        "mn collation when possible=False"

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Public total, pageno, pagesize, totalpage, endrecord As Integer
                                                                        Protected WithEvents OleDbConn As System.Data.OleDb.OleDbConnection
    Protected WithEvents SqlConn As System.Data.SqlClient.SqlConnection
    Protected WithEvents Search As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Repeater1 As System.Web.UI.WebControls.Repeater
        Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
                                Protected WithEvents Form2 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents HyperLink3 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents Repeater4 As System.Web.UI.WebControls.Repeater
    Protected WithEvents Panel5 As System.Web.UI.WebControls.Panel
    Protected WithEvents Repeater3 As System.Web.UI.WebControls.Repeater
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Protected WithEvents Repeater2 As System.Web.UI.WebControls.Repeater
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
            Public update As String

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        update = "test"
        Repeater1.Visible = False
        Repeater2.Visible = False
        Repeater3.Visible = False
        Repeater4.Visible = False

        'Create a connection
        Dim mySqlConnection As New SqlConnection("server=localhost;trusted_connection=yes;database=Webboard")

        'Create the DataAdapter
        Dim mySqlDataAdapter As New SqlDataAdapter("select * from Question", mySqlConnection)

        'Create and populate the DataSet
        Dim myDataSet As New DataSet()
        mySqlDataAdapter.Fill(myDataSet, "Question")

        total = myDataSet.Tables("Question").Rows.Count
        If total = 0 Then   'not have recordset
            Label2.Visible = True
            HyperLink1.Visible = True
            HyperLink2.Visible = False
            Repeater1.Visible = False
            Repeater2.Visible = False
            HyperLink3.Visible = False
        Else 'have recordset
            Label2.Visible = False
            HyperLink1.Visible = False
            HyperLink2.Visible = True
            Repeater1.Visible = True
            Repeater2.Visible = False
            HyperLink3.Visible = False

        End If
        Panel2.Visible = False
        mySqlConnection.Close()

        Dim myCommand As OleDbCommand
        Dim myReader As OleDbDataReader

        myCommand = New OleDbCommand("select * from Question order by id_question desc", OleDbConn)

        If OleDbConn.State <> ConnectionState.Open Then
            OleDbConn.Open()
        End If

        If OleDbConn.State = ConnectionState.Open Then
            myReader = myCommand.ExecuteReader
        End If
        Repeater1.DataSource = myReader
        Repeater1.DataBind()
    End Sub


    Private Sub Search_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Search.Click
        Dim original, count As Integer
        Dim int As Integer
        Dim mysqldataadapter As SqlDataAdapter
        Dim mydataset As New DataSet()
        Dim cmdstr As String
        Dim name As String = TextBox1.Text

        cmdstr = "select * from question where topic like '%" & name & "%' or name like '%" & name & "%' or note like '%" & name & "%' or email='" & name & "'"
        mysqldataadapter = New SqlDataAdapter(cmdstr, SqlConn)

        'create the dataset
        mysqldataadapter.Fill(mydataset, "question")

        original = 160
        count = 0
        Repeater2.Visible = False
        Repeater3.Visible = False
        Repeater4.Visible = False
        Panel2.Visible = False
        HyperLink3.Visible = True

        If TextBox1.Text = "" Or TextBox1.Text = "'" Then
            Panel2.Visible = True
            Label2.Visible = False
            HyperLink1.Visible = False
            HyperLink2.Visible = False
            Repeater1.Visible = False
            Repeater2.Visible = False
        Else
            Panel3.Style.Add("TOP", "160px")
            HyperLink3.Visible = True
            If mydataset.Tables(0).Rows.Count = 0 Then
                Panel2.Visible = True
                Label2.Visible = False
                HyperLink1.Visible = False
                HyperLink2.Visible = False
                Repeater1.Visible = False
                Repeater2.Visible = False
            Else
                Repeater2.DataSource = mydataset.Tables(0)
                count = mydataset.Tables(0).Rows.Count
                Repeater2.DataBind()
                Repeater2.Visible = True
                Panel2.Visible = False
                Label2.Visible = False
                HyperLink1.Visible = False
                HyperLink2.Visible = False
                Repeater1.Visible = False
            End If

        End If
    End Sub


End Class
