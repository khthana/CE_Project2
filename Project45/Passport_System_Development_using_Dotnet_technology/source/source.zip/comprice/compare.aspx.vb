
Imports System.Data.SqlClient
Imports System.Data




Public Class WebForm4
    Inherits System.Web.UI.Page
    Protected WithEvents label0 As System.Web.UI.WebControls.Label
    Protected WithEvents DataGrid_A As System.Web.UI.WebControls.DataGrid
    Protected WithEvents DataGrid_B As System.Web.UI.WebControls.DataGrid
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

   
End Class
