Imports System.Data
Imports System.Data.SqlClient
Imports System.Data.SqlTypes
Imports System.Data.OleDb
Public Class answer
    Inherits System.Web.UI.Page
                                                        Protected WithEvents OleDbConn As System.Data.OleDb.OleDbConnection
    Protected WithEvents Repeater1 As System.Web.UI.WebControls.Repeater
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents name As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents email As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents note As System.Web.UI.WebControls.TextBox
    Protected WithEvents Reset As System.Web.UI.WebControls.Button
    Protected WithEvents Submit As System.Web.UI.WebControls.Button
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Protected WithEvents Repeater2 As System.Web.UI.WebControls.Repeater
    Protected WithEvents SqlConn As System.Data.SqlClient.SqlConnection
        
#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.OleDbConn = New System.Data.OleDb.OleDbConnection()
        Me.SqlConn = New System.Data.SqlClient.SqlConnection()
        '
        'OleDbConn
        '
        Me.OleDbConn.ConnectionString = "Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial " & _
        "Catalog=webboard;Data Source=OHM;Use Procedure for Prepare=1;Auto Translate=True" & _
        ";Packet Size=4096;Workstation ID=OHM;Use Encryption for Data=False;Tag with colu" & _
        "mn collation when possible=False"
        '
        'SqlConn
        '
        Me.SqlConn.ConnectionString = "data source=OHM;initial catalog=webboard;integrated security=SSPI;persist securit" & _
        "y info=False;workstation id=OHM;packet size=4096"

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Panel4.Visible = False
        'Create the OleDbDataAdepter
        Dim cmdStr As String
        Dim myCommand As OleDbCommand
        Dim myReader As OleDbDataReader
        cmdStr = "select * from Question where id_question=" & CInt(Request.QueryString("id")) & ""
        myCommand = New OleDbCommand(cmdStr, OleDbConn)
        If OleDbConn.State <> ConnectionState.Open Then
            OleDbConn.Open()
        End If
        If OleDbConn.State = ConnectionState.Open Then
            myReader = myCommand.ExecuteReader
        End If
        Repeater1.DataSource = myReader
        Repeater1.DataBind()
        myReader.Close()
        OleDbConn.Close()

        'Create the OleDbDataAdepter
        cmdStr = "select * from answer where id_question=" & CInt(Request.QueryString("id")) & ""
        myCommand = New OleDbCommand(cmdStr, OleDbConn)
        If OleDbConn.State <> ConnectionState.Open Then
            OleDbConn.Open()
        End If
        If OleDbConn.State = ConnectionState.Open Then
            myReader = myCommand.ExecuteReader
        End If
        Repeater2.DataSource = myReader
        Repeater2.DataBind()
        myReader.Close()
        OleDbConn.Close()
    End Sub

    Private Sub Page_Unload()
        OleDbConn.Close()
        SqlConn.Close()
    End Sub

    Private Sub Submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Submit.Click
        If name.Text = "" Or note.Text = "" Then
            Panel4.Visible = True
        Else
            'creat the SqldataAdapter
            Dim cmdStr As String
            Dim mySqlAdapter2 As SqlDataAdapter
            cmdStr = "select NAnswer from Question where id_question=" & CInt(Request.QueryString("id")) & ""
            mySqlAdapter2 = New SqlDataAdapter(cmdStr, SqlConn)

            'Create the dataset
            Dim mydataSet As New DataSet()
            mySqlAdapter2.Fill(mydataSet, "Question")

            Dim myDataTable As DataTable
            myDataTable = mydataSet.Tables("Question")

            Dim Nans As Integer : Nans = 0
            Nans = myDataTable.Rows(0).Item(0) 'value Nanswer
            Nans += 1

            'Create the OleDbDataAdapter
            Dim myCommand As OleDbCommand
            Dim myReader As OleDbDataReader
            cmdStr = "update question set nanswer=" & Nans & " where id_question=" & CInt(Request.QueryString("id")) & ""
            myCommand = New OleDbCommand(cmdStr, OleDbConn)
            If OleDbConn.State <> ConnectionState.Open Then
                OleDbConn.Open()
            End If

            If OleDbConn.State = ConnectionState.Open Then
                myReader = myCommand.ExecuteReader
            End If
            myReader.Close()
            OleDbConn.Close()
            SqlConn.Close()

            Dim name As String
            Dim note As String
            Dim date_ As String
            Dim email As String
            Dim ip As String
            Dim thmonth(12) As String
            thmonth(0) = "���Ҥ�" : thmonth(1) = "����Ҿѹ��" : thmonth(2) = "�չҤ�" : thmonth(3) = "����¹"
            thmonth(4) = "����Ҥ�" : thmonth(5) = "�Զع�¹" : thmonth(6) = "�á�Ҥ�" : thmonth(7) = "�ԧ�Ҥ�"
            thmonth(8) = "�ѹ��¹" : thmonth(9) = "���Ҥ�" : thmonth(10) = "��ɨԡ�¹" : thmonth(11) = "�ѹ�Ҥ�"

            name = Replace(Replace(Request.Form("name"), "<", "&lt;"), ">", "&gt;")
            note = Replace(Replace(Request.Form("note"), "<", "&lt;"), ">", "&gt;")
            date_ = Day(Now()) & " " & thmonth(Month(Now()) - 1) & " " & _
                    Right(Year(Now()) + 543, 2) & ", " & TimeValue(Now())
            email = Replace(Replace(Request.Form("email"), "<", "&lt;"), ">", "&gt;")
            ip = Request.ServerVariables("remote_addr")

            'Create the OleDbDataAdapter
            cmdStr = "INSERT INTO answer(ID_Question, Name, Date, Note, Email, IP) " & _
                     "VALUES ('" & CInt(Request.QueryString("id")) & "', '" & name & "', '" & date_ & "', '" & note & "', '" & email & "', '" & ip & "');"
            myCommand = New OleDbCommand(cmdStr, OleDbConn)

            If OleDbConn.State <> ConnectionState.Open Then
                OleDbConn.Open()
            End If
            If OleDbConn.State = ConnectionState.Open Then
                myCommand.ExecuteReader()
            End If
            Response.Redirect("answer.aspx?id=" & CInt(Request.QueryString("id")) & "")

            OleDbConn.Close()
            SqlConn.Close()
        End If
    End Sub

    Private Sub Reset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Reset.Click
        name.Text = ""
        email.Text = ""
        note.Text = ""
        Panel4.Visible = False
    End Sub
End Class
