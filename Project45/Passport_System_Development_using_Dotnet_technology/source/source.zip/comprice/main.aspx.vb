Imports System.Data.SqlClient
Imports comprice.th.ac.kmitl.ce.network072
Imports System.Data
Imports Encryption
Imports System.text
Public Class main
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Public iNumRows As Integer
    Dim sSQL As String
    Dim Npage As String
    Public checkGRID1 As Boolean
    Public checkGRID2 As Boolean
    Dim login As Boolean
    Protected WithEvents text1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents DropDownList1 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ImageButton1 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents ImageButton2 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
            Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    
    Dim IV() As Byte = Encoding.ASCII.GetBytes("init vec")
    Dim Key() As Byte = Encoding.ASCII.GetBytes("password")
    Dim email As String
    Protected WithEvents LinkButton1 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents Datagrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Datagrid2 As System.Web.UI.WebControls.DataGrid
                    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Imagebutton3 As System.Web.UI.WebControls.ImageButton
        Protected WithEvents Imagebutton4 As System.Web.UI.WebControls.ImageButton
    Protected WithEvents Dropdownlist2 As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Textbox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents P1 As System.Web.UI.HtmlControls.HtmlGenericControl
                Protected WithEvents LinkButton3 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton4 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton5 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton6 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton7 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton8 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton9 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton10 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton11 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton12 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
        Protected WithEvents LinkButton2 As System.Web.UI.WebControls.LinkButton
                                                                                                Protected WithEvents LinkButton13 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton14 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton15 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton16 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton17 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton18 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton19 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton20 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton21 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton22 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton23 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton24 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton25 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton26 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton27 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton28 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton29 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton30 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton31 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton32 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton33 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton34 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton35 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents Panel2 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image1 As System.Web.UI.WebControls.Image
    Protected WithEvents Image3 As System.Web.UI.WebControls.Image
                                                Protected WithEvents Image2 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel3 As System.Web.UI.WebControls.Panel
                                                Protected WithEvents Image4 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel4 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image5 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel5 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image6 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel6 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image7 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel7 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image8 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel8 As System.Web.UI.WebControls.Panel
            Protected WithEvents Image10 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel10 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image11 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel11 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image12 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel12 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image13 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel13 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image14 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel14 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image15 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel15 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image16 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel16 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image17 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel17 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image18 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel18 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image19 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel19 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image20 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel20 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image21 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel21 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image22 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel22 As System.Web.UI.WebControls.Panel
    Protected WithEvents Image23 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel23 As System.Web.UI.WebControls.Panel
            Protected WithEvents LinkButton36 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton37 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton38 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton39 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton40 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton41 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton42 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton43 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton44 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton45 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton46 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton47 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton48 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton49 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton50 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton51 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton52 As System.Web.UI.WebControls.LinkButton
                Protected WithEvents LinkButton54 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton56 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton57 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton58 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton59 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton60 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton61 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton62 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton63 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton53 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton55 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton64 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton65 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton66 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton67 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton68 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton69 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton71 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton72 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton73 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton74 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton75 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton76 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton77 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton78 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton79 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton80 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton81 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton82 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton70 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton83 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton84 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton85 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton86 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton87 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton89 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton88 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton90 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton91 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton92 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton93 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton94 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton95 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton96 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton97 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton99 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton100 As System.Web.UI.WebControls.LinkButton
            Protected WithEvents LinkButton103 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton104 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton105 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton106 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton107 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton98 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton102 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton108 As System.Web.UI.WebControls.LinkButton
            Protected WithEvents LinkButton111 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton112 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton101 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton109 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton110 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton113 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton114 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton115 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton116 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton117 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton118 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton119 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton120 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton121 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton122 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton123 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton124 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton125 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton126 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton127 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton129 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton130 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton131 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton132 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton128 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton133 As System.Web.UI.WebControls.LinkButton
                Protected WithEvents LinkButton137 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton138 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton142 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton141 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton140 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton139 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton134 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton136 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton143 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton144 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton145 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton146 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton148 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton150 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton151 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton152 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton153 As System.Web.UI.WebControls.LinkButton
        Protected WithEvents LinkButton155 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton156 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton157 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton158 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton159 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton160 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton161 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton162 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton163 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton164 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton135 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton147 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton149 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton154 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton165 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton166 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton167 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton168 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton169 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton170 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton171 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton172 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton173 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton174 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton175 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton176 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton177 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton178 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton179 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton180 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton181 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton182 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton183 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton184 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton185 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton186 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton187 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton188 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton189 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton190 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton191 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton192 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton193 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton194 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton195 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton196 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton197 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton198 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton199 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton200 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton201 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton202 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton203 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton204 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton205 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton206 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton207 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton208 As System.Web.UI.WebControls.LinkButton
            Protected WithEvents LinkButton211 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton212 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton209 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton210 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton213 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton214 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton215 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton217 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton218 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton219 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton220 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton221 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton222 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton223 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton224 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton225 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton226 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton227 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton228 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton229 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton230 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton216 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton231 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton232 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton233 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton234 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton235 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton236 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton237 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton238 As System.Web.UI.WebControls.LinkButton
                                Protected WithEvents LinkButton246 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton247 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton248 As System.Web.UI.WebControls.LinkButton
                                                                                                                            Protected WithEvents HyperLink1 As System.Web.UI.WebControls.HyperLink
                                                                                                                                                                            Protected WithEvents DataGrid3 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Image9 As System.Web.UI.WebControls.Image
    Protected WithEvents DataGrid4 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Image26 As System.Web.UI.WebControls.Image
    Protected WithEvents Image25 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel24 As System.Web.UI.WebControls.Panel
                                    Protected WithEvents HyperLink2 As System.Web.UI.WebControls.HyperLink
    Protected WithEvents LinkButton244 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton243 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton242 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton241 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton240 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents LinkButton239 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents Image24 As System.Web.UI.WebControls.Image
    Protected WithEvents Panel9 As System.Web.UI.WebControls.Panel
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        Dim ooo As String

    Public Function encrypt(ByVal pt As String) As String
        Dim plainText() As Byte = Encoding.ASCII.GetBytes(pt)
        Dim algorithmID As EncryptionAlgorithm
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim enc As Encryptor = New Encryptor(EncryptionAlgorithm.Des)
        Dim cipherText() As Byte = Nothing
        Dim ct As String
        enc.IV = IV
        cipherText = enc.Encrypt(plainText, Key)
        IV = enc.IV
        Key = enc.Key
        ct = Convert.ToBase64String(cipherText)

        Return ct
    End Function
    Public Function decrypt(ByVal ct As String) As String
        '     Try

        Dim cipherText() As Byte = Convert.FromBase64String(ct)
        Dim algorithm As EncryptionAlgorithm = EncryptionAlgorithm.Des
        Dim dec As Decryptor = New Decryptor(algorithm)
        Dim plainText() As Byte = Nothing
        Dim pt As String
        dec.IV = IV
        ' Go ahead and decrypt.
        plainText = dec.Decrypt(cipherText, Key)
        pt = Encoding.ASCII.GetString(plainText)
        ' Look at your plain text.
        Return pt

        '        Catch
        '           Response.Redirect("reg_error.aspx")

        '      End Try

    End Function

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        'Dim web_passport As New th.ac.kmitl.ce.network072.Service1()
        Try
            ooo = decrypt(Request.QueryString("o"))
            If ooo <> "" Then
                Response.Cookies("passport").Value = "logoutted"
                Response.Cookies("passport").Expires = Now.AddDays(1)
                Response.Cookies("passport").Path = "/comprice"
                Response.Cookies("passport").Secure = False
                Response.Write("logout")
                ImageButton2.ImageUrl = "image\signin.GIF"
                login = False
            End If

        Catch
            Try

                email = decrypt(Request.QueryString("e"))
                Response.Cookies("passport").Value = email
                Response.Cookies("passport").Expires = Now.AddDays(1)
                Response.Cookies("passport").Path = "/comprice"
                Response.Cookies("passport").Secure = False
                Response.Write("login")
                ImageButton2.ImageUrl = "image\signout.GIF"
                login = True
            Catch
                Try
                    Dim MyCookie As HttpCookie
                    MyCookie = Request.Cookies("passport")
                    If MyCookie.Value = "logoutted" Then
                        ImageButton2.ImageUrl = "image\signin.GIF"
                        login = False
                    Else
                        ImageButton2.ImageUrl = "image\signout.GIF"
                        login = True
                    End If
                Catch
                    Response.Cookies("passport").Value = "logoutted"
                    Response.Cookies("passport").Expires = Now.AddDays(1)
                    Response.Cookies("passport").Path = "/comprice"
                    Response.Cookies("passport").Secure = False
                    ImageButton2.ImageUrl = "image\signin.GIF"
                    login = False
                End Try

            End Try

        End Try



   


        Dim myConnString As String

        myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
        myConnection = New SqlConnection(myConnString)
        myConnection.Open()

        If Session("page") = Nothing Then
            Session("page") = 1
            'Session("page").timeout = 10

        End If

        If Request.QueryString("show") <> "" Then
            Panel24.Visible = False
            checkGRID2 = False
            checkGRID1 = True
            If text1.Text <> "" And DropDownList1.SelectedItem.Value <> "<none>" Then
                checkGRID2 = True
                checkGRID1 = False
            End If

            If Request.QueryString("show") = "cpu" And Session("page") = 1 Then
                Panel1.Visible = True
            ElseIf Request.QueryString("show") = "ram" And Session("page") = 1 Then
                Panel2.Visible = True
            ElseIf Request.QueryString("show") = "hdd" And Session("page") = 1 Then
                Panel3.Visible = True
            ElseIf Request.QueryString("show") = "mbd" And Session("page") = 1 Then
                Panel4.Visible = True
            ElseIf Request.QueryString("show") = "vga" And Session("page") = 1 Then
                Panel5.Visible = True
            ElseIf Request.QueryString("show") = "pda" And Session("page") = 1 Then
                Panel6.Visible = True
            ElseIf Request.QueryString("show") = "cdd" And Session("page") = 1 Then
                Panel7.Visible = True
            ElseIf Request.QueryString("show") = "mon" And Session("page") = 1 Then
                Panel8.Visible = True
            ElseIf Request.QueryString("show") = "snd" And Session("page") = 1 Then
                Panel9.Visible = True
            ElseIf Request.QueryString("show") = "spk" And Session("page") = 1 Then
                Panel10.Visible = True
            ElseIf Request.QueryString("show") = "mdm" And Session("page") = 1 Then
                Panel11.Visible = True
            ElseIf Request.QueryString("show") = "pnt" And Session("page") = 1 Then
                Panel12.Visible = True
            ElseIf Request.QueryString("show") = "scn" And Session("page") = 1 Then
                Panel13.Visible = True
            ElseIf Request.QueryString("show") = "ups" And Session("page") = 1 Then
                Panel14.Visible = True
            ElseIf Request.QueryString("show") = "scs" And Session("page") = 1 Then
                Panel15.Visible = True
            ElseIf Request.QueryString("show") = "bup" And Session("page") = 1 Then
                Panel16.Visible = True
            ElseIf Request.QueryString("show") = "cam" And Session("page") = 1 Then
                Panel17.Visible = True
            ElseIf Request.QueryString("show") = "hub" And Session("page") = 1 Then
                Panel18.Visible = True
            ElseIf Request.QueryString("show") = "lan" And Session("page") = 1 Then
                Panel19.Visible = True
            ElseIf Request.QueryString("show") = "hdc" And Session("page") = 1 Then
                Panel20.Visible = True
            ElseIf Request.QueryString("show") = "nbk" And Session("page") = 1 Then
                Panel21.Visible = True
            ElseIf Request.QueryString("show") = "mcd" And Session("page") = 1 Then
                Panel22.Visible = True
            ElseIf Request.QueryString("show") = "opt" And Session("page") = 1 Then
                Panel23.Visible = True

            End If

            ' If DropDownList1.SelectedItem.Value = "<none>" Then

            'checkGRID1 = True
            'End If
            'If Page.IsPostBack = False Then
            'sSQL = "select * from " & Request.QueryString("show")

            '   BindData1(Label6.Text)
            'End If
        Else
            Dim objdataReader As SqlDataReader
            Dim myConnection As SqlConnection
            Dim objCmd As SqlCommand
            'Dim myConnstring As String
            Dim valReturn As String
            Dim check As String
            Dim mySelectQuery As String

            myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnString)
            myConnection.Open()
            mySelectQuery = "select * from topten"
            Dim mysqlDataAdater As New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet As New DataSet()
            mysqlDataAdater.Fill(dtSet)
            DataGrid4.DataSource = dtSet
            DataGrid4.DataBind()
            Panel24.Visible = True

            mySelectQuery = "select * from M_update"
            mysqlDataAdater = New SqlDataAdapter(mySelectQuery, myConnection)
            Dim dtSet1 As New DataSet()
            mysqlDataAdater.Fill(dtSet1)
            DataGrid3.DataSource = dtSet1
            DataGrid3.DataBind()

            Panel1.Visible = False
            Panel2.Visible = False
            Panel3.Visible = False
            Panel4.Visible = False
            Panel5.Visible = False
            Panel6.Visible = False
            Panel7.Visible = False
            Panel8.Visible = False
            Panel9.Visible = False
            Panel10.Visible = False
            Panel11.Visible = False
            Panel12.Visible = False
            Panel13.Visible = False
            Panel14.Visible = False
            Panel15.Visible = False
            Panel16.Visible = False
            Panel17.Visible = False
            Panel18.Visible = False
            Panel19.Visible = False
            Panel20.Visible = False
            Panel21.Visible = False
            Panel23.Visible = False

            Datagrid2.CurrentPageIndex = 0
            Npage = DropDownList1.SelectedItem.Value
            checkGRID2 = True
            checkGRID1 = False
            If Page.IsPostBack = False Then
                Dim searchName As String, lengthOfName As Integer

                searchName = Trim(text1.Text)
                lengthOfName = Len(searchName)
                If DropDownList1.SelectedItem.Text <> "<none>" Then

                    If searchName <> "" Then
                        If Npage = "cpu" Then
                            Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"

                        ElseIf Npage = "ram" Then
                            Label6.Text = "Brand Like '*" & searchName & "*' OR Type Like '*" & searchName & "*' OR Size Like '*" & searchName & "*'"

                        ElseIf Npage = "hdd" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Size Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "mbd" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Chipset Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "vga" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR GraphicsChip Like '*" & searchName & "*'OR RAM Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "pda" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Speed Like '*" & searchName & "*'OR Memory Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "cdd" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR X Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "mon" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Size Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "snd" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "spk" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "mdm" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Type Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "pnt" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "scn" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "ups" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "scs" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Type Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "bup" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "cam" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Resolution Like '*" & searchName & "*'AND Memory Like '*" & searchName & "*'"

                        ElseIf Npage = "hub" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Port Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "lan" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                        ElseIf Npage = "hdc" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                        ElseIf Npage = "nbk" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR [CPU Type/Speed] Like '*" & searchName & "*'OR RAM Like '*" & searchName & "*'AND HDD Like '*" & searchName & "*'"

                        ElseIf Npage = "mcd" Then
                            Label6.Text = "Brand Like '*" & searchName & "*'OR Type Like '*" & searchName & "*'OR Size Like '*" & searchName & "*'"

                        ElseIf Npage = "opt" Then
                            Label6.Text = "More Like '*" & searchName & "*'"

                        End If
                    Else
                        Label6.Text = "Brand Like ''"
                    End If
                    sSQL = "select * from " & Npage
                    BindData2(Label6.Text)
                End If
            End If
        End If


    End Sub

    Sub Page_UnLoad()
        myConnection.Close()

    End Sub

    'Sub Page_Error(sender As Object, e As EventArgs) 
    '		Dim pageEx As String = Server.GetLastError().ToString() 
    '		Response.Redirect("Errorpage.aspx") 
    '		Context.ClearError() 
    'End Sub

    Sub showPage1(ByVal s As Object, ByVal e As DataGridPageChangedEventArgs)
        Datagrid1.CurrentPageIndex = e.NewPageIndex
        BindData1(Label6.Text)
    End Sub
    Sub showPage2(ByVal s As Object, ByVal e As DataGridPageChangedEventArgs)
        Datagrid2.CurrentPageIndex = e.NewPageIndex
        BindData2(Label6.Text)
    End Sub
    Sub BindData1(ByVal cond1 As String)
        Dim dtCmd1 As SqlDataAdapter
        Dim iLoop1 As Integer
        Dim dtView1 As DataView
        Dim dtSet1 As New DataSet()
        Dim kf As Integer = 0
        Dim kl As Integer = 0
        Dim searchName As String
        kf = InStr(cond1, "*")
        kl = InStr(kf, cond1, "'")
        searchName = Mid(cond1, kf + 1, kl - kf - 2)

        sSQL = "select * from " & Request.QueryString("show")
        dtCmd1 = New SqlDataAdapter(sSQL, myConnection)
        dtCmd1.Fill(dtSet1)
        dtView1 = dtSet1.Tables(0).DefaultView
        dtView1.RowFilter = cond1
        iNumRows = dtView1.Count
        If iNumRows >= 0 Then
            Datagrid1.DataSource = dtView1
            Datagrid1.DataBind()
        End If
        Label7.Text = "��ª����ػ�ó����դ���� keyword : <b>" & searchName & "</b> ���Ǵ  : <b>" & Request.QueryString("show") & "</b>" & " : �� " & iNumRows & " ��¡��"
    End Sub


    Sub BindData2(ByVal cond2 As String)
        Dim dtCmd2 As SqlDataAdapter
        Dim iLoop2 As Integer
        Dim dtView2 As DataView
        Dim dtSet2 As New DataSet()

        sSQL = "select * from cpu"
        dtCmd2 = New SqlDataAdapter(sSQL, myConnection)
        dtCmd2.Fill(dtSet2, "cpu")
        dtCmd2.SelectCommand.CommandText = "select * from ram"
        dtCmd2.Fill(dtSet2, "ram")
        dtCmd2.SelectCommand.CommandText = "select * from hdd"
        dtCmd2.Fill(dtSet2, "hdd")
        dtCmd2.SelectCommand.CommandText = "select * from hdd"
        dtCmd2.Fill(dtSet2, "hdd")
        dtCmd2.SelectCommand.CommandText = "select * from mbd"
        dtCmd2.Fill(dtSet2, "mbd")
        dtCmd2.SelectCommand.CommandText = "select * from vga"
        dtCmd2.Fill(dtSet2, "vga")
        dtCmd2.SelectCommand.CommandText = "select * from pda"
        dtCmd2.Fill(dtSet2, "pda")
        dtCmd2.SelectCommand.CommandText = "select * from cdd"
        dtCmd2.Fill(dtSet2, "cdd")
        dtCmd2.SelectCommand.CommandText = "select * from mon"
        dtCmd2.Fill(dtSet2, "mon")
        dtCmd2.SelectCommand.CommandText = "select * from snd"
        dtCmd2.Fill(dtSet2, "snd")
        dtCmd2.SelectCommand.CommandText = "select * from spk"
        dtCmd2.Fill(dtSet2, "spk")
        dtCmd2.SelectCommand.CommandText = "select * from mdm"
        dtCmd2.Fill(dtSet2, "mdm")
        dtCmd2.SelectCommand.CommandText = "select * from pnt"
        dtCmd2.Fill(dtSet2, "pnt")
        dtCmd2.SelectCommand.CommandText = "select * from scn"
        dtCmd2.Fill(dtSet2, "scn")
        dtCmd2.SelectCommand.CommandText = "select * from ups"
        dtCmd2.Fill(dtSet2, "ups")
        dtCmd2.SelectCommand.CommandText = "select * from scs"
        dtCmd2.Fill(dtSet2, "scs")
        dtCmd2.SelectCommand.CommandText = "select * from bup"
        dtCmd2.Fill(dtSet2, "bup")
        dtCmd2.SelectCommand.CommandText = "select * from cam"
        dtCmd2.Fill(dtSet2, "cam")
        dtCmd2.SelectCommand.CommandText = "select * from hub"
        dtCmd2.Fill(dtSet2, "hub")
        dtCmd2.SelectCommand.CommandText = "select * from lan"
        dtCmd2.Fill(dtSet2, "lan")
        dtCmd2.SelectCommand.CommandText = "select * from hdc"
        dtCmd2.Fill(dtSet2, "hdc")
        dtCmd2.SelectCommand.CommandText = "select * from nbk"
        dtCmd2.Fill(dtSet2, "nbk")
        dtCmd2.SelectCommand.CommandText = "select * from mcd"
        dtCmd2.Fill(dtSet2, "mcd")
        dtCmd2.SelectCommand.CommandText = "select * from opt"
        dtCmd2.Fill(dtSet2, "opt")
        dtView2 = dtSet2.Tables(DropDownList1.SelectedItem.Value).DefaultView
        dtView2.RowFilter = cond2
        iNumRows = dtView2.Count
        If iNumRows >= 0 Then
            Datagrid2.DataSource = dtView2
            Datagrid2.DataBind()
        End If
        Label7.Text = "��ª����ػ�ó����դ���� keyword : <b>" & text1.Text & "</b> ���Ǵ  : <b>" & DropDownList1.SelectedItem.Text & "</b>" & " : �� " & iNumRows & " ��¡��"

    End Sub

    Sub clickButton1(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("page") = 2
        Panel1.Visible = False
        Panel2.Visible = False
        Panel3.Visible = False
        Panel4.Visible = False
        Panel5.Visible = False
        Panel6.Visible = False
        Panel7.Visible = False
        Panel8.Visible = False
        Panel9.Visible = False
        Panel10.Visible = False
        Panel11.Visible = False
        Panel12.Visible = False
        Panel13.Visible = False
        Panel14.Visible = False
        Panel15.Visible = False
        Panel16.Visible = False
        Panel17.Visible = False
        Panel18.Visible = False
        Panel19.Visible = False
        Panel20.Visible = False
        Panel21.Visible = False
        Panel23.Visible = False
        Panel24.Visible = False
        Datagrid2.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Npage = DropDownList1.SelectedItem.Value
        checkGRID2 = True
        checkGRID1 = False


        'if page.IsPostBack = True Then
        Dim searchName As String, lengthOfName As Integer

        searchName = Trim(text1.Text)
        lengthOfName = Len(searchName)


        If DropDownList1.SelectedItem.Text = "<none>" Then
            Label7.Text = "<font color=red size=3>��س����͡��Ǵ�ͧ�ػ�ó�㹡�ä����Թ��� !!</font>"
            iNumRows = 0
        Else

            If searchName <> "" Then
                If Npage = "cpu" Then
                    Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"

                ElseIf Npage = "ram" Then
                    Label6.Text = "Brand Like '*" & searchName & "*' OR Type Like '*" & searchName & "*' OR Size Like '*" & searchName & "*'"

                ElseIf Npage = "hdd" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Size Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "mbd" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Chipset Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "vga" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR GraphicsChip Like '*" & searchName & "*'OR RAM Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "pda" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Speed Like '*" & searchName & "*'OR Memory Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "cdd" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR X Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "mon" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Size Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "snd" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "spk" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "mdm" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Type Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "pnt" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "scn" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "ups" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "scs" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Type Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "bup" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "cam" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Resolution Like '*" & searchName & "*'AND Memory Like '*" & searchName & "*'"

                ElseIf Npage = "hub" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Port Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "lan" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR Interface Like '*" & searchName & "*'AND More Like '*" & searchName & "*'"

                ElseIf Npage = "hdc" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR More Like '*" & searchName & "*'"

                ElseIf Npage = "nbk" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Model Like '*" & searchName & "*'OR [CPU Type/Speed] Like '*" & searchName & "*'OR RAM Like '*" & searchName & "*'AND HDD Like '*" & searchName & "*'"

                ElseIf Npage = "mcd" Then
                    Label6.Text = "Brand Like '*" & searchName & "*'OR Type Like '*" & searchName & "*'OR Size Like '*" & searchName & "*'"

                ElseIf Npage = "opt" Then
                    Label6.Text = "More Like '*" & searchName & "*'"

                End If
            Else
                Label6.Text = "Brand Like ''"
            End If
            sSQL = "select * from " & Npage
            BindData2(Label6.Text)
        End If
        'End if		


    End Sub


    Private Sub ImageButton2_Click(ByVal sender As System.Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles ImageButton2.Click
        If login = True Then
            'Response.Redirect("http://network07.ce.kmitl.ac.th/passport/logout.aspx")
            Response.Redirect("https://network07.ce.kmitl.ac.th/passport/logout.aspx?url=http://network07.ce.kmitl.ac.th/comprice/main.aspx")
        Else
            'Response.Redirect("http://network07.ce.kmitl.ac.th/passport/login.aspx")
            Response.Redirect("https://network07.ce.kmitl.ac.th/passport/login.aspx?url=http://network07.ce.kmitl.ac.th/comprice/main.aspx")
        End If
    End Sub

    Private Sub LinkButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        If login = True Then
            Response.Redirect("orderlist.aspx")

        Else
            Response.Redirect("avoid.aspx")

        End If
    End Sub

    Private Sub LinkButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton2.Click

        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "celeron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from " & Request.QueryString("show")
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2

    End Sub

    Private Sub LinkButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton3.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Pentium !!!"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton4.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Pentium 4"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton5.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Xeon"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton6.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Duron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton7.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Duron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton9.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Duron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton10.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Duron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton11.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Duron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton12.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        searchName = "Duron"
        Label6.Text = "Brand Like '*" & searchName & "*' OR Model Like '*" & searchName & "*' OR Speed Like '*" & searchName & "*'OR Feature Like '*" & searchName & "*'"
        sSQL = "select * from cpu"
        BindData1(Label6.Text)
        Panel1.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton13.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=cpu")

    End Sub

    Private Sub LinkButton14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton14.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=ram")
    End Sub

    Private Sub LinkButton15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton15.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=hdd")
    End Sub

    Private Sub LinkButton17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton17.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=vga")
    End Sub

    Private Sub LinkButton16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton16.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=mbd")
    End Sub

    Private Sub LinkButton18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton18.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=pda")
    End Sub

    Private Sub LinkButton19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton19.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=cdd")
    End Sub

    Private Sub LinkButton20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton20.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=mon")
    End Sub

    Private Sub LinkButton21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton21.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=snd")
    End Sub

    Private Sub LinkButton22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton22.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=spk")
    End Sub

    Private Sub LinkButton23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton23.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=mdm")
    End Sub

    Private Sub LinkButton24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton24.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=pnt")
    End Sub

    Private Sub LinkButton25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton25.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=scn")
    End Sub

    Private Sub LinkButton26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton26.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=ups")
    End Sub

    Private Sub LinkButton27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton27.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=scs")
    End Sub

    Private Sub LinkButton28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton28.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=bup")
    End Sub

    Private Sub LinkButton29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton29.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=cam")
    End Sub

    Private Sub LinkButton30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton30.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=hub")
    End Sub

    Private Sub LinkButton31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton31.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=lan")
    End Sub

    Private Sub LinkButton32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton32.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=hdc")
    End Sub

    Private Sub LinkButton33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton33.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=nbk")
    End Sub

    Private Sub LinkButton34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton34.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=mcd")
    End Sub

    Private Sub LinkButton35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton35.Click
        Session("page") = 1
        Response.Redirect("main.aspx?show=opt")
    End Sub

    Private Sub LinkButton36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton36.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*sdram*' and Size Like '*32*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton37.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*sdram*' and Size Like '*64*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton38.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*sdram*' and Size Like '*128*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton39_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton39.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*sdram*' and Size Like '*256*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton40.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*sdram*' and Size Like '*512*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton41_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton41.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*ddr*' and Size Like '*64*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton42.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*ddr*' and Size Like '*128*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton43.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*ddr*' and Size Like '*256*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton44_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton44.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*ddr*' and Size Like '*512*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton45_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton45.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*rd*' and Size Like '*64*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton46_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton46.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*rd*' and Size Like '*128*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton47_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton47.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*rd*' and Size Like '*256*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton48_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton48.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*rd*' and Size Like '*512*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton50_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton50.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Apacer*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton49_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton49.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Kingston*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton51_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton51.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*IBM*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton52_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton52.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Infineon*'"
        sSQL = "select * from ram"
        BindData1(Label6.Text)
        Panel2.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton54_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton54.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*IBM*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

 

    Private Sub LinkButton56_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton56.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Maxtor*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton57_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton57.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Quantum*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton58_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton58.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Seagate*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton59_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton59.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Wtd*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton60_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton60.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*IDE*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton61_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton61.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*SCSI*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton62_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton62.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*firewire*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton63_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton63.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*USB*'"
        sSQL = "select * from hdd"
        BindData1(Label6.Text)
        Panel3.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton53_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton53.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*370*' and form Like 'ATX' "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton55_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton55.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*370*' and form Like 'm-ATX' "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton64_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton64.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*370*' and form Like 'FlexATX' "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton65_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton65.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Socket A*' and form Like 'ATX' "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton66_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton66.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Socket A*' and form Like 'm-ATX' "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton67_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton67.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Socket 423*' and form Like 'ATX' or Interface Like '*Socket 478*' and form Like 'ATX' "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton68_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton68.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Socket 423*' and form Like 'm-ATX' or Interface Like '*Socket 478*' and form Like 'm-ATX'  "
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton69_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton69.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Socket 423*' and form Like 'FlexATX' or Interface Like '*Socket 478*' and form Like 'FlexATX'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton71_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton71.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Dual*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton72_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton72.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*Slot 1*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton73_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton73.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*ASUS*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton74_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton74.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*MSI*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton75_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton75.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Intel*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton76_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton76.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Gigabyte*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton77_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton77.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*DFI*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton78_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton78.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Chipset Like '*i8*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton79_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton79.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Chipset Like '*Amd*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton80_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton80.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Chipset Like '*Via*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton81_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton81.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Chipset Like '*Sis*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton82_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton82.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Chipset Like '*Ali*'"
        sSQL = "select * from mbd"
        BindData1(Label6.Text)
        Panel4.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton70_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton70.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*AGP 4X*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton83_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton83.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*AGP 2X*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton84_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton84.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*****'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton85_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton85.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*PCI*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton86_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton86.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "GraphicsChip Like '*TNT2*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton87_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton87.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "GraphicsChip Like '*GF*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton88_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton88.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "GraphicsChip Like '*ATi*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton89_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton89.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "GraphicsChip Like '*SiS*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton90_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton90.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Asus*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton91_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton91.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Creative*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton92_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton92.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Elsa*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton93_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton93.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Gigabyte*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton94_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton94.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*VDO Editing Card*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton95_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton95.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*TV*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton96_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton96.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*TV Tuners*'"
        sSQL = "select * from vga"
        BindData1(Label6.Text)
        Panel5.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton97_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton97.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Palm M1*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton99_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton99.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Palmv*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton100_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton100.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Palm M5*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton103_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton103.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Acer*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton104_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton104.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Casio*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton105_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton105.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Compaq*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton106_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton106.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*HP*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton107_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton107.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*3com*'"
        sSQL = "select * from pda"
        BindData1(Label6.Text)
        Panel6.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton98_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton98.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*IDE*'"
        sSQL = "select * from cdd"
        BindData1(Label6.Text)
        Panel7.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton102_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton102.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*SCSI*'"
        sSQL = "select * from cdd"
        BindData1(Label6.Text)
        Panel7.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton108_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton108.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*USB*'"
        sSQL = "select * from cdd"
        BindData1(Label6.Text)
        Panel7.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton111_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton111.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*DVD'"
        sSQL = "select * from cdd"
        BindData1(Label6.Text)
        Panel7.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton112_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton112.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*DVD-RW*'"
        sSQL = "select * from cdd"
        BindData1(Label6.Text)
        Panel7.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton101_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton101.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More not Like '*Flat*' and More not Like '*FD*' and More not Like '*tri*' and More not Like '*LCD*' and Size Like '*14*' or More not Like '*Flat*' and More not Like '*FD*' and More not Like '*LCD*' and More not Like '*tri*' and Size Like '*15*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton109_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton109.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More not Like '*Flat*' and More not Like '*FD*' and More not Like '*tri*' and More not Like '*LCD*' and Size Like '*17*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton110_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton110.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More not Like '*Flat*' and More not Like '*FD*' and More not Like '*tri*' and More not Like '*LCD*' and Size Like '*19*' or More not Like '*Flat*' and More not Like '*FD*' and More not Like '*tri*' and More not Like '*LCD*' and Size Like '*20*' or More not Like '*Flat*' and More not Like '*FD*' and More not Like '*tri*' and More not Like '*LCD*' and Size Like '*21*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton113_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton113.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*Flat*' and Size Like '*15*' or More Like '*FD*' and Size Like '*15*' or More Like '*tri*' and Size Like '*15*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton114_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton114.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*Flat*' and Size Like '*17*' or More Like '*FD*' and Size Like '*17*' or More Like '*tri*' and Size Like '*17*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton115_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton115.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*Flat*' and Size Like '*19*' or More Like '*FD*' and Size Like '*19*' or More Like '*tri*' and Size Like '*19*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton116_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton116.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*LCD*' and Size Like '*14*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton117_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton117.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*LCD*' and Size Like '*15*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton118_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton118.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*LCD*' and Size Like '*17*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton119_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton119.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*LCD*' and Size Like '*19*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton120_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton120.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Sony*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton121_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton121.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Samsung*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton122_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton122.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Philip*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton123_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton123.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*LG*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton124_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton124.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Mag*'"
        sSQL = "select * from mon"
        BindData1(Label6.Text)
        Panel8.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton125_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton125.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More not Like '*Sub*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton126_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton126.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*USB*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton127_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton127.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*Sub*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton129_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton129.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Altec*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton130_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton130.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Boston*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton131_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton131.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Creative*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton132_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton132.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Philips*'"
        sSQL = "select * from spk"
        BindData1(Label6.Text)
        Panel10.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton128_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton128.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*External*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton133_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton133.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*Internal*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton137_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton137.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*USB*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton138_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton138.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*PCMCIA*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton139_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton139.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*3Com US.Robitic*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton140_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton140.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Aztech*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton141_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton141.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Pheenet*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton142_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton142.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*D-Link*'"
        sSQL = "select * from mdm"
        BindData1(Label6.Text)
        Panel11.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton134_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton134.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*A3*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton135_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton135.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*S100*' or Model Like '*S200*'or Model Like '*S400*'or Model Like '*IJ650*'or Model Like '*c20*'or Model Like '*c40*'or Model Like '*c50*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton136_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton136.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*S300*' or Model Like '*S450*'or Model Like '*S520*'or Model Like '*S6300*'or Model Like '*c60*'or Model Like '*c80*'or Model Like '*Photo 810*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton143_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton143.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*S100p*' or Model Like '*S200sp*'or Model Like '*ij600*'or Model Like '*c20sx*'or Model Like '*Photo 830*'or Model Like '*dj 656c*'or Model Like '*z25*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton144_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton144.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*s520*' or Model Like '*s6300*'or Model Like '*s820*'or Model Like '*Photo*'or Model Like '*DJ 1220c*'or Model Like '*dj 920c*'or Model Like '*dj 948c*' or Model Like '*dj 990cxi*' or Model Like '*Picture Maker P200*' or Model Like '*AJ-2100*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton145_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton145.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*BJC-55*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton146_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton146.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Aculaser*' or Model Like '*Laser Color*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton148_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton148.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*HL*' or Model Like '*LBP*'or Model Like '*Laser*' and Model not Like '*Laser Color*'or Model Like '*LBP*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton150_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton150.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*HL-1670n*' or Model Like '*c2000*'or Model Like '*c8000*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton151_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton151.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*HL-1670n*' or Model Like '*c8500*'or Model Like '*5000*'or Model Like '*8550*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton152_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton152.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*LQ-2080i*' or Model Like '*LQ-2180i*'or Model Like '*591*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton153_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton153.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*LQ-580*' or Model Like '*LQ-300+*'or Model Like '*Lx-300+*'or Model Like '*380*'or Model Like '*390*'or Model Like '*590*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton155_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton155.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Dye-sub Printer*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton156_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton156.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Large Formatte Printer*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton157_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton157.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Cutter*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton158_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton158.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Printer Server*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton159_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton159.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Brother*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton160_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton160.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Canon*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton161_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton161.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Epson*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton162_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton162.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*HP*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton163_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton163.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Lexmark*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton164_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton164.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Oki*'"
        sSQL = "select * from pnt"
        BindData1(Label6.Text)
        Panel12.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton147_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton147.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More not Like '*USB*'and More not Like '*SCSI*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton149_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton149.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*USB*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton154_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton154.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*SCSI*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton165_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton165.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*2450 SU Photo*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton166_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton166.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Canon*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton167_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton167.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Epson*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton168_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton168.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*HP*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton169_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton169.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Umax*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton170_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton170.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*600X1200*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton171_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton171.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*600X2400*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton172_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton172.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*1200X1200*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton173_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton173.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*1200X2400*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton174_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton174.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*1600X3200*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton175_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton175.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*2400X2400*'"
        sSQL = "select * from scn"
        BindData1(Label6.Text)
        Panel13.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton176_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton176.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*APC*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton177_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton177.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Leonics*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton178_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton178.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Syndrome*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton179_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton179.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*500*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton180_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton180.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*600*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton181_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton181.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*750*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton182_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton182.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*1000*'"
        sSQL = "select * from ups"
        BindData1(Label6.Text)
        Panel14.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton183_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton183.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*AHA*'"
        sSQL = "select * from scs"
        BindData1(Label6.Text)
        Panel15.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton184_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton184.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Zip*' or Brand Like '*SuperDisk*' or Brand Like '*Jazz*'"
        sSQL = "select * from bup"
        BindData1(Label6.Text)
        Panel16.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton185_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton185.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*MicroDrive*' or Brand Like '*Samsung*'"
        sSQL = "select * from bup"
        BindData1(Label6.Text)
        Panel16.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton186_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton186.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Fujitsu*'"
        sSQL = "select * from bup"
        BindData1(Label6.Text)
        Panel16.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton187_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton187.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Seagate*'"
        sSQL = "select * from bup"
        BindData1(Label6.Text)
        Panel16.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton188_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton188.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Resolution Like '*0.*' or Resolution Like '*1.*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton189_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton189.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Resolution Like '*2.1*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton190_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton190.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Resolution Like '*3.*' or Resolution Like '*4.*' or Resolution Like '*5.*' or Resolution Like '*6.*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton191_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton191.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Canon*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton192_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton192.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Epson*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton193_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton193.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Fuji*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton194_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton194.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Kodak*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton195_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton195.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Nikon*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton196_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton196.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Sony*'"
        sSQL = "select * from cam"
        BindData1(Label6.Text)
        Panel17.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton197_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton197.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Port Like '4' or Port Like '5'or Port Like '8'or Port Like '9'or Port Like '*12*'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton198_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton198.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Port Like '*16*' or Port Like '20'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton199_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton199.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Port Like '*24*'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton200_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton200.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*Stack*'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton201_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton201.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*3Com*'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton202_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton202.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Syslink*'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton203_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton203.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Linksys*'"
        sSQL = "select * from hub"
        BindData1(Label6.Text)
        Panel18.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton204_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton204.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*3Com*'"
        sSQL = "select * from lan"
        BindData1(Label6.Text)
        Panel19.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton205_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton205.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*D-Link*'"
        sSQL = "select * from lan"
        BindData1(Label6.Text)
        Panel19.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton206_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton206.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*D-Link*'"
        sSQL = "select * from lan"
        BindData1(Label6.Text)
        Panel19.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton207_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton207.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*5*' and More Like '*line*'"
        sSQL = "select * from hdc"
        BindData1(Label6.Text)
        Panel20.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton208_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton208.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*400 line*'"
        sSQL = "select * from hdc"
        BindData1(Label6.Text)
        Panel20.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton211_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton211.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Sony*'"
        sSQL = "select * from hdc"
        BindData1(Label6.Text)
        Panel20.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton212_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton212.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*JVC*'"
        sSQL = "select * from hdc"
        BindData1(Label6.Text)
        Panel20.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton209_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton209.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Ram Like '*256*' or Ram Like '*512*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton210_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton210.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Ram Like '*64*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton213_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton213.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "CPU type/peed Like '*1.*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton214_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton214.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Display Like '*14.*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton215_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton215.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Display Like '*15.*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton217_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton217.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Desk*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton218_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton218.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*XP*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton219_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton219.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Athlon*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton220_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton220.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Athlon*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton221_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton221.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Duron*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton222_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton222.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Celeron*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton223_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton223.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*P!!!*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton224_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton224.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Crusoe*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton225_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton225.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "[CPU Type/Speed] Like '*Cyrix*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton226_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton226.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Acer*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton227_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton227.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Compaq*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton228_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton228.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Fujitsu*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton229_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton229.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*IBM*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton230_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton230.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Toshiba*'"
        sSQL = "select * from nbk"
        BindData1(Label6.Text)
        Panel21.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton216_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton216.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Kingston*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton231_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton231.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Apacer*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton232_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton232.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Transend*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton233_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton233.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Sandisk*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton234_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton234.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*CompactFlash*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton235_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton235.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*SmartMedia*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton236_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton236.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*MemoryStick*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton237_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton237.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*MultiMediaCard*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton238_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton238.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*Secure Digital*'"
        sSQL = "select * from mcd"
        BindData1(Label6.Text)
        Panel22.Visible = False
        Session("page") = 2
    End Sub


    Private Sub LinkButton246_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton246.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Type Like '*Gamepad*'"
        sSQL = "select * from opt"
        BindData1(Label6.Text)
        Panel23.Visible = False
        Session("page") = 2
    End Sub
    Private Sub LinkButton247_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton247.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*JoyStick*'"
        sSQL = "select * from opt"
        BindData1(Label6.Text)
        Panel23.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton248_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinkButton248.Click
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "More Like '*Card*'"
        sSQL = "select * from opt"
        BindData1(Label6.Text)
        Panel23.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton239_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*ISA*'"
        sSQL = "select * from snd"
        BindData1(Label6.Text)
        Panel9.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton240_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Interface Like '*PCI*'"
        sSQL = "select * from snd"
        BindData1(Label6.Text)
        Panel9.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton241_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*Audigy*'"
        sSQL = "select * from snd"
        BindData1(Label6.Text)
        Panel9.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton242_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Model Like '*AudigyPlatinumEX*'"
        sSQL = "select * from snd"
        BindData1(Label6.Text)
        Panel9.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton243_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*Creative*'"
        sSQL = "select * from snd"
        BindData1(Label6.Text)
        Panel9.Visible = False
        Session("page") = 2
    End Sub

    Private Sub LinkButton244_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Datagrid1.CurrentPageIndex = 0   '������� index ��Ѻ�Ҫ���˹���á
        Dim searchName As String
        checkGRID1 = True
        checkGRID2 = False
        Label6.Text = "Brand Like '*X-Wave*'"
        sSQL = "select * from snd"
        BindData1(Label6.Text)
        Panel9.Visible = False
        Session("page") = 2
    End Sub
 
End Class
