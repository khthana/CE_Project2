<%@ Page Language="vb" AutoEventWireup="false" Codebehind="main.aspx.vb" Inherits="comprice.main"%>
<!--#include file = "head.inc"-->
<SCRIPT id="Script1" runat="server" Lanauage="vb">
				
</SCRIPT>
<BODY bgColor="#ffffff" leftMargin="0" topMargin="0" marginheight="0" marginwidth="0">
	<DIV align="center">
		<TABLE cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" align="center" borderColorLight="#0066cc" border="1">
			<TR bgColor="#0066cc">
				<TD style="WIDTH: 96px" align="middle">
					<IMG alt="Comprice" src="image\page.gif">
				</TD>
				<TD>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<TD align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</TD>
						</TR>
					</TABLE>
				</TD>
			</TR>
			<TR bgColor="#0066cc">
				<TD class="head" style="WIDTH: 96px; HEIGHT: 13px" alian="center">
					<P align="left">
						<B><FONT color="#ffffff"><IMG alt="��Ǵ�ػ�ó�" src="image\down_blues.gif">&nbsp;��Ǵ�ػ�ó�</FONT></B>
					</P>
				</TD>
				<TD style="WIDTH: 554px; HEIGHT: 13px">
					<TABLE height="36" width="690" bgColor="#0066cc">
						<TR>
							<FORM id="Form1" runat="server">
								<TD style="WIDTH: 610px" align="middle">
									<FONT face="Tahoma"><IMG height="19" alt="�����ػ�ó�" src="image\open_book20.gif" width="22"></FONT><FONT face="Times New Roman"><FONT color="#ffffff">�����ػ�ó�</FONT>
										<asp:textbox id="text1" runat="server" Width="80px" Height="22px"></asp:textbox>
										<FONT color="#ffffff">��Ǵ
											<asp:dropdownlist id="DropDownList1" runat="server">
												<asp:ListItem Selected="true" Text="<none>" />
												<asp:ListItem Text="CPU" Value="cpu" />
												<asp:ListItem Text="Memory" Value="ram" />
												<asp:ListItem Text="HardDisk" Value="hdd" />
												<asp:ListItem Text="Mainboard" Value="mbd" />
												<asp:ListItem Text="Display Card" Value="vga" />
												<asp:ListItem Text="PDA" Value="pda" />
												<asp:ListItem Text="CDrom ��� DVD" Value="cdd" />
												<asp:ListItem Text="Monitor" Value="mon" />
												<asp:ListItem Text="SoundCard" Value="snd" />
												<asp:ListItem Text="��⾧" Value="spk" />
												<asp:ListItem Text="Modem" Value="mdm" />
												<asp:ListItem Text="Printer" Value="pnt" />
												<asp:ListItem Text="Scanner" Value="scn" />
												<asp:ListItem Text="UPS" Value="ups" />
												<asp:ListItem Text="SCSI Controller" Value="scs" />
												<asp:ListItem Text="Backup Unit" Value="bup" />
												<asp:ListItem Text="���ͧ�ԨԵ��" Value="cam" />
												<asp:ListItem Text="Hub" Value="hub" />
												<asp:ListItem Text="LanCard" Value="lan" />
												<asp:ListItem Text="Handy Camera" Value="hdc" />
												<asp:ListItem Text="NoteBook" Value="nbk" />
												<asp:ListItem Text="Memory Card" Value="mcd" />
												<asp:ListItem Text="���� ��� Optional" Value="opt" />
											</asp:dropdownlist>
											<asp:imagebutton id="ImageButton1" onclick="Clickbutton1" runat="server" AlternateText="�������ͤ���" ImageUrl="image\botton_go.gif"></asp:imagebutton>
										</FONT></FONT>
								</TD>
								<TD style="WIDTH: 91px" align="middle">
									<P align="left">
										</FONT><FONT face="MS Sans Serif" size="2"><FONT face="Tahoma">&nbsp;</FONT>
											<asp:hyperlink id="HyperLink1" runat="server" NavigateUrl="webboard.aspx" ForeColor="White">����ʹ���</asp:hyperlink>
										</FONT>
									</P>
								</TD>
								<TD style="WIDTH: 124px" align="middle">
									<IMG alt="��¡����觫���" src="image\basket.gif">&nbsp;
									<asp:linkbutton id="LinkButton1" runat="server" ForeColor="White" Font-Size="X-Small">��¡����觫���</asp:linkbutton>
								</TD>
								<TD style="WIDTH: 102px" align="middle">
									&nbsp;
									<asp:imagebutton id="ImageButton2" runat="server" ImageUrl="image\signin.gif"></asp:imagebutton>
								</TD>
						</TR>
					</TABLE>
				</TD>
			</TR>
			<TR vAlign="top">
				<TD style="WIDTH: 96px" width="85">
					<UL type="circle">
						<LI>
							<DIV align="left">
								<FONT face="Tahoma">
									<asp:hyperlink id="HyperLink2" runat="server" Width="75px" Height="8px" NavigateUrl="main.aspx">Main Page</asp:hyperlink>
								</FONT>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton13" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ CPU">CPU</asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton14" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Memory ">Memory </asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton15" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ HardDisk">HardDisk</asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton16" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Mainboard ">Mainboard </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton17" runat="server" Width="82px" Height="2px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Display Card ">Display Card </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton18" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ PDA ">PDA </asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton19" runat="server" Width="116px" Height="4px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ CDrom ��� DVD ">CDrom ��� DVD </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton20" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Monitor">Monitor</asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton21" runat="server" Width="71px" Height="12px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ SoundCard ">SoundCard </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton22" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ ��⾧">��⾧</asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton23" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Modem">Modem</asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton24" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Printer ">Printer </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton25" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Scanner ">Scanner </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton26" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ UPS">UPS</asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton27" runat="server" Width="105px" Height="2px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ SCSI Controller">SCSI Controller</asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton28" runat="server" Width="82px" Height="4px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Backup Unit ">Backup Unit </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton29" runat="server" Width="102px" Height="1px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ ���ͧ�ԨԵ�� ">���ͧ�ԨԵ�� </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton30" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Hub">Hub</asp:linkbutton>
								<BR>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton31" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ LanCard ">LanCard </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton32" runat="server" Width="95px" Height="16px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Handy Camera ">Handy Camera </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton33" runat="server" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ NoteBook ">NoteBook </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton34" runat="server" Width="97px" Height="13px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ Memory Card ">Memory Card </asp:linkbutton>
							</DIV>
						<LI>
							<DIV align="left">
								<asp:linkbutton id="LinkButton35" runat="server" Width="123px" Height="8px" ToolTip="��Ǩ�ͺ�Ҥ����Ǵ ���� ��� Optional ">���� ��� Optional </asp:linkbutton>
							</DIV>
						</LI>
					</UL>
				</TD>
				<TD style="WIDTH: 542px">
					<P>
						<asp:label id="Label6" runat="server" visible="False"></asp:label>
						<asp:label id="Label7" runat="server"></asp:label>
					</P>
					<P id="P1" runat="server">
						<%if checkGRID1 = true and checkGRID2 = false and iNumRows >0 then %>
						<asp:datagrid id="Datagrid1" runat="server" Width="624px" Height="213px" Font-Size="8pt" AllowPaging="True" PageSize="10" Font-Names="Verdana" Font-Name="Verdana" Cellpadding="6" AlternatingItemStyle-BackColor="#EFEFEF" CssClass="DataGrid" HeaderStyle-BackColor="#aaaaaa" HeaderStyle-ForeColor="#000040" HeaderStyle-Font-Bold="True" PagerStyle-Mode="NumericPages" OnPageIndexChanged="showpage1">
							<HeaderStyle Font-Bold="True" ForeColor="#000040" BackColor="#B0C4DE"></HeaderStyle>
							<PagerStyle Mode="NumericPages"></PagerStyle>
							<AlternatingItemStyle BackColor="#EFEFEF"></AlternatingItemStyle>
							<ItemStyle BackColor="White"></ItemStyle>
							<Columns>
								<asp:TemplateColumn>
									<HeaderTemplate></HeaderTemplate>
									<ItemTemplate>
										<a href='compare.aspx?id=<%#Container.DataItem("ID")%>'>compare</a>
									</ItemTemplate>
									<FooterTemplate></FooterTemplate>
								</asp:TemplateColumn>
							</Columns>
						</asp:datagrid>
						<%else if checkGRID1 = false and checkGRID2 = true and iNumRows >0 then %>
						<asp:datagrid id="Datagrid2" runat="server" Width="624px" Height="213px" Font-Size="8pt" AllowPaging="True" PageSize="10" Font-Names="Verdana" Font-Name="Verdana" Cellpadding="6" AlternatingItemStyle-BackColor="#EFEFEF" CssClass="DataGrid" HeaderStyle-BackColor="#aaaaaa" HeaderStyle-ForeColor="#000040" HeaderStyle-Font-Bold="True" PagerStyle-Mode="NumericPages" OnPageIndexChanged="showpage2">
							<HeaderStyle Font-Bold="True" ForeColor="#000040" BackColor="#B0C4DE"></HeaderStyle>
							<PagerStyle Mode="NumericPages"></PagerStyle>
							<AlternatingItemStyle BackColor="#EFEFEF"></AlternatingItemStyle>
							<ItemStyle BackColor="White"></ItemStyle>
							<Columns>
								<asp:TemplateColumn>
									<HeaderTemplate></HeaderTemplate>
									<ItemTemplate>
										<a href='compare.aspx?id=<%#Container.DataItem("ID")%>'>compare</a>
									</ItemTemplate>
									<FooterTemplate></FooterTemplate>
								</asp:TemplateColumn>
							</Columns>
						</asp:datagrid>
						<% end if %>
					</P>
					<P>
						<FONT face="Tahoma"></FONT>
					</P>
					<P>
						<asp:panel id="Panel1" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image1" runat="server" ImageUrl="image\ppp\clogo115.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD>
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">CPU ( Processor )</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
																			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Intel'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=116&amp;cid=116">
																					<B>Intel</B></A>&nbsp;&nbsp;<FONT color="#696969">(67)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton2" runat="server">Celeron</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton3" runat="server">Pentium III </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton4" runat="server">Pentium 4 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton5" runat="server">Xeon </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='AMD'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=117&amp;cid=117">
																					<B>AMD</B></A>&nbsp;&nbsp;<FONT color="#696969">(35)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton6" runat="server">Duron </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton7" runat="server">Athlon/Athlon XP </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton8" runat="server">Athlon 4 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton9" runat="server">Athlon MP </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='VIA'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=118&amp;cid=118">
																					<B>VIA</B></A>&nbsp;&nbsp;<FONT color="#696969">(11)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton10" runat="server">Cyrix MII </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton11" runat="server">Cyrix MIII </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton12" runat="server">C3 </asp:LinkButton>
																			</P>
																		</TD>
																		<TD width="50%">
																			<FONT face="Tahoma"></FONT>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel2" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													<asp:Image id="Image3" runat="server" Height="93px" Width="143px" ImageUrl="image\ppp\clogo236.gif"></asp:Image>
													&nbsp;
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD>
																<P align="center">
																	<STRONG><FONT color="#ffffff">Memory&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</FONT></STRONG>
																</P>
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="15" src="file:///C:\Inetpub\wwwroot\comprice\image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<P>
																	<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																		<TR>
																			<TD vAlign="top" width="50%">
																				<P>
																					<A onmouseover="window.status='SDRAM'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=237&amp;cid=237">
																						<B>SDRAM</B></A>&nbsp;&nbsp;<FONT color="#696969">(22)</FONT>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton36" runat="server">32 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton37" runat="server">64 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton38" runat="server">128 MB</asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton39" runat="server">256 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton40" runat="server">512 MB </asp:LinkButton>
																				</P>
																			</TD>
																			<TD vAlign="top" width="50%">
																				<P>
																					<A onmouseover="window.status='DDR SDRAM'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=607&amp;cid=607">
																						<B>DDR SDRAM</B></A>&nbsp;&nbsp;<FONT color="#696969">(11)</FONT>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton41" runat="server">64 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton42" runat="server">128 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton43" runat="server">256 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton44" runat="server">512 MB </asp:LinkButton>
																				</P>
																			</TD>
																		</TR>
																		<TR>
																			<TD vAlign="top" width="50%">
																				<P>
																					<A onmouseover="window.status='RDRAM (RAMBUS)'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=238&amp;cid=238">
																						<B>RDRAM (RAMBUS)</B></A>&nbsp;&nbsp;<FONT color="#696969">(8)</FONT>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton45" runat="server">64 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton46" runat="server">128 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton47" runat="server">256 MB </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton48" runat="server">512 MB </asp:LinkButton>
																				</P>
																			</TD>
																			<TD vAlign="top" width="50%">
																				<P>
																					<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=612&amp;cid=612">
																						<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(76)</FONT>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton49" runat="server">Kingston </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton50" runat="server">Apacer </asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton51" runat="server">IBM</asp:LinkButton>
																					<BR>
																					-&nbsp;
																					<asp:LinkButton id="LinkButton52" runat="server">Infineon</asp:LinkButton>
																				</P>
																				<P>
																					<FONT face="Tahoma"></FONT>
																				</P>
																			</TD>
																		</TR>
																	</TABLE>
																</P>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel3" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image2" runat="server" Height="97px" Width="176px" ImageUrl="image\ppp\online-storage-world.jpg"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD>
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			Hard&nbsp;Disk&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=156&amp;cid=156">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(151)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton54" runat="server">IBM </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton56" runat="server">Maxtor </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton57" runat="server">Quantum </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton58" runat="server">Seagate </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton59" runat="server">Western Digital</asp:LinkButton>
																			</P>
																			<P>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Hard Drives'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=154&amp;cid=154">
																					<B>Hard Drives</B></A>&nbsp;&nbsp;<FONT color="#696969">(90)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton60" runat="server">IDE </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton61" runat="server">Ultra SCSI </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton62" runat="server">Firewire </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton63" runat="server">USB </asp:LinkButton>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel4" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image4" runat="server" ImageUrl="image\ppp\clogo334.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Mainboard</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='SOCKET 370 for PIII/Celeron'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=336&amp;cid=336">
																					<B>SOCKET 370 for PIII/Celeron</B></A>&nbsp;&nbsp;<FONT color="#696969">(92)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton53" runat="server">ATX </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton55" runat="server">MicroATX </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton64" runat="server">FlexATX </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='SOCKET A for Athlon/Duron'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=339&amp;cid=339">
																					<B>SOCKET A for Athlon/Duron</B></A>&nbsp;&nbsp;<FONT color="#696969">(76)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton65" runat="server">ATX</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton66" runat="server">MicroATX</asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='SOCKET 423/478 for P4'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=587&amp;cid=587">
																					<B>SOCKET 423/478 for P4</B></A>&nbsp;&nbsp;<FONT color="#696969">(59)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton67" runat="server">ATX </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton68" runat="server">Micro ATX </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton69" runat="server">Flex ATX </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Other Mainboards'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=342&amp;cid=342">
																					<B>Other Mainboards</B></A>&nbsp;&nbsp;<FONT color="#696969">(29)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton71" runat="server">Dual CPU </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton72" runat="server">Slot 1 </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=341&amp;cid=341">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(168)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton73" runat="server">ASUS </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton74" runat="server">MSI</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton75" runat="server">INTEL </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton76" runat="server">GIGABYTE </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton77" runat="server">DFI </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Chipset'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=596&amp;cid=596">
																					<B>Chipset</B></A>&nbsp;&nbsp;<FONT color="#696969">(257)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton78" runat="server">Intel </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton79" runat="server">AMD </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton80" runat="server">Via </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton81" runat="server">SiS </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton82" runat="server">ALi </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel5" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image5" runat="server" ImageUrl="image\ppp\clogo294.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			Display 
																			Card&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Graphic Card'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=299&amp;cid=299">
																					<B>Graphic Card</B></A>&nbsp;&nbsp;<FONT color="#696969">(80)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton70" runat="server">AGP 4x </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton83" runat="server">AGP/AGP 2x</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton84" runat="server">All 2D/3D Card </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton85" runat="server">PCI </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Graphic Processor Unit'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=743&amp;cid=743">
																					<B>Graphic Processor Unit</B></A>&nbsp;&nbsp;<FONT color="#696969">(76)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton86" runat="server">nVidia Riva TNT 2</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton87" runat="server">nVidia GeForce MX/2/3/4 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton88" runat="server">ATI </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton89" runat="server">SiS </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brands'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=313&amp;cid=313">
																					<B>Popular Brands</B></A>&nbsp;&nbsp;<FONT color="#696969">(31)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton90" runat="server">ASUS </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton91" runat="server">Creative </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton92" runat="server">ELSA </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton93" runat="server">GIGABYTE </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Other Graphic Card'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=308&amp;cid=308">
																					<B>Other Graphic Card</B></A>&nbsp;&nbsp;<FONT color="#696969">(7)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton94" runat="server">Digital Video Edit </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton95" runat="server">TV Coder </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton96" runat="server">TV Tuners/Video Card </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel6" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image6" runat="server" ImageUrl="image\ppp\clogo69.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">PDA</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Palm'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=70&amp;cid=70">
																					<B>Palm</B></A>&nbsp;&nbsp;<FONT color="#696969">(12)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton97" runat="server">Palm m100/105/125/130 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton99" runat="server">Palm V/ Vx </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton100" runat="server">Palm m500/505/515 </asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Pocket PC '; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=75&amp;cid=75">
																					<B>Pocket PC </B></A>&nbsp;&nbsp;<FONT color="#696969">(21)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton103" runat="server">Acer </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton104" runat="server">CASIO </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton105" runat="server">COMPAQ </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton106" runat="server">HP </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton107" runat="server">3com</asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
																<P>
																</P>
																<P>
																	<FONT face="Tahoma"></FONT>
																</P>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel7" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image7" runat="server" ImageUrl="image\ppp\clogo153.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">CD-rom ��� DVD-rom</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='CD ROM/R/RW Drives'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=155&amp;cid=155">
																					<B>CD ROM/R/RW Drives</B></A>&nbsp;&nbsp;<FONT color="#696969">(107)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton98" runat="server">IDE </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton102" runat="server">SCSI </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton108" runat="server">USB </asp:LinkButton>
																				<BR>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='DVD Drive'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=717&amp;cid=717">
																					<B>DVD Drive</B></A>&nbsp;&nbsp;<FONT color="#696969">(14)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton111" runat="server">DVD Drive </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton112" runat="server">DVD+RW/DVD RAM </asp:LinkButton>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
																<P>
																	<FONT face="Tahoma"></FONT>
																</P>
																<P>
																	<FONT face="Tahoma"></FONT>
																</P>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel8" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image8" runat="server" ImageUrl="image\ppp\clogo362.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Monitor</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='CRT Monitor'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=642&amp;cid=642">
																					<B>CRT Monitor</B></A>&nbsp;&nbsp;<FONT color="#696969">(58)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton101" runat="server">14-15 inch </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton109" runat="server">17 inch </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton110" runat="server">19 inch and up </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Flat Screen Monitor'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=643&amp;cid=643">
																					<B>Flat Screen Monitor</B></A>&nbsp;&nbsp;<FONT color="#696969">(47)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton113" runat="server">15 inch </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton114" runat="server">17 inch </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton115" runat="server">19 inch and up </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='LCD Monitor'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=365&amp;cid=365">
																					<B>LCD Monitor</B></A>&nbsp;&nbsp;<FONT color="#696969">(42)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton116" runat="server">14 inch LCD Monitors </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton117" runat="server">15 inch LCD Monitors </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton118" runat="server">17 inch LCD Monitors </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton119" runat="server">18 inch and up </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=636&amp;cid=636">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(66)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton120" runat="server">SONY </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton121" runat="server">SAMSUNG </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton122" runat="server">PHILIPS </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton123" runat="server">LG </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton124" runat="server">MAG </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<FONT face="Tahoma"></FONT>
					</P>
					<P>
						<asp:panel id="Panel10" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image10" runat="server" ImageUrl="image\ppp\clogo255.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			��⾧&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Speakers'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=257&amp;cid=257">
																					<B>Speakers</B></A>&nbsp;&nbsp;<FONT color="#696969">(34)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton125" runat="server">2-way Speaker </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton126" runat="server">USB Speakers </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton127" runat="server">Speakers with subwoofer </asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Speakers Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=258&amp;cid=258">
																					<B>Speakers Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(25)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton129" runat="server">Altec Lansing </asp:LinkButton>
																				<BR>
																				-&nbsp;<A onmouseover="window.status='�Boston Acoustic'; return true;" onmouseout="window.status=''; return true;" href="search.asp?p_cid=258&amp;cid=503">�</A>
																				<asp:LinkButton id="LinkButton130" runat="server">Boston Acoustic </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton131" runat="server">Creative </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton132" runat="server">Philips </asp:LinkButton>
																			</P>
																			<P>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel11" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image11" runat="server" ImageUrl="image\ppp\clogo182.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Modem</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Modems'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=183&amp;cid=183">
																					<B>Modems</B></A>&nbsp;&nbsp;<FONT color="#696969">(34)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton128" runat="server">External </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton133" runat="server">Internal </asp:LinkButton>
																			</P>
																			<P>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Other Modems'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=187&amp;cid=187">
																					<B>Other Modems</B></A>&nbsp;&nbsp;<FONT color="#696969">(17)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton137" runat="server">USB Modem </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton138" runat="server">PCMCIA Modem </asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=186&amp;cid=186">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(16)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton139" runat="server">3 COM US. Robotics</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton140" runat="server">Aztech </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton141" runat="server">Pheenet</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton142" runat="server">D-Link </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
					</P>
					<P>
						<asp:panel id="Panel12" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image12" runat="server" ImageUrl="image\ppp\clogo50.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Printer</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='InkJet Printers'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=54&amp;cid=54">
																					<B>InkJet Printers</B></A>&nbsp;&nbsp;<FONT color="#696969">(97)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton134" runat="server">InkJet Printer  ��Ҵ A3 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton135" runat="server">InkJet �������Ǿ����ӵ�ӡ��� 10 �蹵�͹ҷ�</asp:LinkButton>
																				<BR>
																				-
																				<asp:LinkButton id="LinkButton136" runat="server">InkJet �������Ǿ������٧���������ҡѺ 10 �蹵�͹ҷ� </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton143" runat="server">InkJet �Ҥһ����Ѵ </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton144" runat="server">Photo InkJet </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton145" runat="server">Portable InkJet </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Laser Printers'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=52&amp;cid=52">
																					<B>Laser Printers</B></A>&nbsp;&nbsp;<FONT color="#696969">(143)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton146" runat="server">Color Laser Printer </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton148" runat="server">Laser Printer ����Ѻ office ����� </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton150" runat="server">Network Printer </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton151" runat="server">Laser Printer ��Ҵ A3 </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Dot Matrix Printers'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=53&amp;cid=53">
																					<B>Dot Matrix Printers</B></A>&nbsp;&nbsp;<FONT color="#696969">(21)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton152" runat="server">Dot Matrix ������ </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton153" runat="server">Dot Matrix ������ </asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Other Printers'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=55&amp;cid=55">
																					<B>Other Printers</B></A>&nbsp;&nbsp;<FONT color="#696969">(0)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton155" runat="server">Dye-sub Printer </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton156" runat="server">Large Formatte Printer </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton157" runat="server">Printer/Cutter </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton158" runat="server">Print Server </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=628&amp;cid=628">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(202)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton159" runat="server">Brother </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton160" runat="server">Canon </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton161" runat="server">EPSON </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton162" runat="server">HP </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton163" runat="server">Lexmark </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton164" runat="server">OKI </asp:LinkButton>
																			</P>
																		</TD>
																		<TD width="50%">
																			<FONT face="Tahoma"></FONT>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel13" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image13" runat="server" ImageUrl="image\ppp\clogo316.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Scanner</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Flat Bed'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=318&amp;cid=318">
																					<B>Flat Bed</B></A>&nbsp;&nbsp;<FONT color="#696969">(74)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton147" runat="server">Parallel </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton149" runat="server">SCSI </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton154" runat="server">USB </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton165" runat="server">FireWire/IEEE 1394 </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=320&amp;cid=320">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(48)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton166" runat="server">Canon </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton167" runat="server">EPSON </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton168" runat="server">HP </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton169" runat="server">UMAX </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Resolution'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=703&amp;cid=703">
																					<B>Resolution</B></A>&nbsp;&nbsp;<FONT color="#696969">(74)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton170" runat="server">600x1200 dpi </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton171" runat="server">600x2400 dpi</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton172" runat="server">1200x1200 dpi </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton173" runat="server">1200x2400 dpi </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton174" runat="server">1600x3200 dpi</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton175" runat="server">2400x2400 dpi �����٧���� </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel14" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image14" runat="server" ImageUrl="image\ppp\clogo427.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">UPS</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Manufacturers'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=433&amp;cid=433">
																					<B>Manufacturers</B></A>&nbsp;&nbsp;<FONT color="#696969">(17)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton176" runat="server">APC </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton177" runat="server">Leonics</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton178" runat="server">Syndrome</asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Off-Line UPS'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=430&amp;cid=430">
																					<B>Off-Line UPS</B></A>&nbsp;&nbsp;<FONT color="#696969">(39)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton179" runat="server">500 VA </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton180" runat="server">600 VA </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton181" runat="server">750 VA </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton182" runat="server">1000 VA</asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
																<P>
																</P>
																<P>
																</P>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel15" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image15" runat="server" ImageUrl="image\ppp\clogo294.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			SCSI&nbsp;Controller&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=341&amp;cid=341">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(1)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton183" runat="server">AHA</asp:LinkButton>
																				<BR>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																			<P>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel16" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image16" runat="server" ImageUrl="image\ppp\clogo334.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Backup Unit</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Other Storage Devices'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=729&amp;cid=729">
																					<B>Other Storage Devices</B></A>&nbsp;&nbsp;<FONT color="#696969">(32)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton184" runat="server">Floppy Drive/Super Drive </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton185" runat="server">Micro Drive </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton186" runat="server">MO Drive </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton187" runat="server">Tape Backup </asp:LinkButton>
																				<BR>
																			</P>
																			<P>
																			</P>
																			<P>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel17" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image17" runat="server" ImageUrl="image\ppp\clogo274.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">&nbsp;Digital</FONT></STRONG>&nbsp;<STRONG><FONT color="#ffffff">Camera&nbsp;</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
																			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Digital Camera'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=275&amp;cid=275">
																					<B>Digital Camera</B></A>&nbsp;&nbsp;<FONT color="#696969">(144)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton188" runat="server">1.3 Mpixels and lower </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton189" runat="server">2.1 Mpixels </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton190" runat="server">3.3 Mpixels ���� </asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brands'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=277&amp;cid=277">
																					<B>Popular Brands</B></A>&nbsp;&nbsp;<FONT color="#696969">(119)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton191" runat="server">Canon </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton192" runat="server">EPSON </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton193" runat="server">FUJI </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton194" runat="server">KODAK </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton195" runat="server">Nikon </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton196" runat="server">SONY </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel18" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image18" runat="server" ImageUrl="image\ppp\clogo51.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Hub</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='HUB'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=93&amp;cid=93">
																					<B>HUB</B></A>&nbsp;&nbsp;<FONT color="#696969">(29)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton197" runat="server">4-12 Ports Hub </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton198" runat="server">16-20 Ports Hub </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton199" runat="server">24 Ports Hub and up </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton200" runat="server">Stackable Hub </asp:LinkButton>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Network by Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=749&amp;cid=749">
																					<B>Network by Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(23)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton201" runat="server">3Com </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton202" runat="server">Syslink</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton203" runat="server">Linksys </asp:LinkButton>
																			</P>
																		</TD>
																		<TD width="50%">
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel19" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image19" runat="server" ImageUrl="image\ppp\clogo51.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Lan Card</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Network by Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=749&amp;cid=749">
																					<B>Network by Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(23)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton204" runat="server">3Com </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton205" runat="server">D-Link</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton206" runat="server">Linksys </asp:LinkButton>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel20" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image20" runat="server" ImageUrl="image\ppp\clogo274.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Handy Camera</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Digital Camera'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=275&amp;cid=275">
																					<B>Digital Camera</B></A>&nbsp;&nbsp;<FONT color="#696969">(144)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton207" runat="server">500 line ����</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton208" runat="server">400 line</asp:LinkButton>
																				<BR>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brands'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=277&amp;cid=277">
																					<B>Popular Brands</B></A>&nbsp;&nbsp;<FONT color="#696969">(59)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton211" runat="server">Sony</asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton212" runat="server">JVC</asp:LinkButton>
																				<BR>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel21" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image21" runat="server" ImageUrl="image\ppp\clogo210.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">NoteBook</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
																			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='NoteBook'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=623&amp;cid=623">
																					<B>NoteBook</B></A>&nbsp;&nbsp;<FONT color="#696969">(254)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton209" runat="server">High-End Notebook </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton210" runat="server">Economy Notebook </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton213" runat="server">Ultra Portable Notebook </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton214" runat="server">Notebook ����ը͢�Ҵ 14.1" </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton215" runat="server">Notebook ����ը͢�Ҵ 15" ���� </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton217" runat="server">Desk Note </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Processors'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=211&amp;cid=211">
																					<B>Processors</B></A>&nbsp;&nbsp;<FONT color="#696969">(276)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton218" runat="server">AMD AthlonXP </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton219" runat="server">AMD Athlon4 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton220" runat="server">AMD Duron </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton221" runat="server">Intel Celeron </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton222" runat="server">Intel Pentium III </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton223" runat="server">Intel Pentium 4 </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton224" runat="server">Transmeta Crusoe </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton225" runat="server">VIA Cyrix III </asp:LinkButton>
																			</P>
																		</TD>
																	</TR>
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=213&amp;cid=213">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(190)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton226" runat="server">ACER </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton227" runat="server">COMPAQ </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton228" runat="server">Fujitsu </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton229" runat="server">IBM </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton230" runat="server">TOSHIBA </asp:LinkButton>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel22" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image22" runat="server" ImageUrl="image\ppp\clogo236.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Memory Card</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=612&amp;cid=612">
																					<B>Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(76)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton216" runat="server">Kingston </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton231" runat="server">Apacer </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton232" runat="server">Transend </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton233" runat="server">SanDisk </asp:LinkButton>
																			</P>
																			<P>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Flash Memory'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=617&amp;cid=617">
																					<B>Flash Memory</B></A>&nbsp;&nbsp;<FONT color="#696969">(67)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton234" runat="server">Compact Flash </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton235" runat="server">Smart Media </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton236" runat="server">Memory Stick </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton237" runat="server">MultiMedia Card (MMC) </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton238" runat="server">SD Card (Secure Digital) </asp:LinkButton>
																			</P>
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<asp:panel id="Panel23" runat="server" Width="624px" Height="329px" Visible="False">
							<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
								<TR>
									<TD>
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#669966">
												<TD vAlign="top">
													&nbsp;
													<asp:Image id="Image23" runat="server" ImageUrl="image\ppp\clogo200.gif"></asp:Image>
												</TD>
												<TD width="100%" bgColor="#669966">
													<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
															</TD>
															<TD>
															</TD>
														</TR>
														<TR>
															<TD style="HEIGHT: 18px">
																<STRONG><FONT color="#ffffff">
																		<P align="center">
																			<STRONG><FONT color="#ffffff">Options</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																		</P>
																	</FONT></STRONG>
															</TD>
															<TD style="HEIGHT: 18px">
															</TD>
														</TR>
														<TR>
															<TD>
																<IMG height="5" src="../images/space.gif" width="1" border="0">
															</TD>
															<TD>
															</TD>
														</TR>
													</TABLE>
												</TD>
												<TD vAlign="top">
													<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR>
								<TR>
								</TR>
								<TR bgColor="#eeeedd" nowrap>
									<TD>
										<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
												���������Ҥ� Update �������¤�Ѻ</B></FONT>
									</TD>
								</TR>
								<TR bgColor="#696969">
									<TD>
										<IMG height="1" src="../images/space.gif" width="1" border="0">
									</TD>
								</TR>
								<TR>
									<TD style="HEIGHT: 262px" align="middle">
										<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
											<TR bgColor="#eeeedd">
												<TD>
													<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
														<TR>
															<TD align="middle">
																<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																	<TR>
																		<TD vAlign="top" width="50%">
																			<P>
																				<A onmouseover="window.status='Game Controller'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=539&amp;cid=539">
																					<B>Game Controller</B></A>&nbsp;&nbsp;<FONT color="#696969">(20)</FONT>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton246" runat="server">Game Pad </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton247" runat="server">JoyStick </asp:LinkButton>
																				<BR>
																				-&nbsp;
																				<asp:LinkButton id="LinkButton248" runat="server">Other Game Accessories </asp:LinkButton>
																			</P>
																			<P>
																			</P>
																		</TD>
																		<TD vAlign="top" width="50%">
																			<P>
																				<FONT face="Tahoma"></FONT>
																			</P>
																		</TD>
																	</TR>
																</TABLE>
																<P>
																</P>
																<P>
																	<FONT face="Tahoma"></FONT>
																</P>
															</TD>
														</TR>
													</TABLE>
												</TD>
											</TR>
										</TABLE>
									</TD>
								</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
							</TABLE>
						</asp:panel>
					</P>
					<P>
						<FONT face="Tahoma"><FONT face="Tahoma"></FONT></FONT></ASP:PA face="Tahoma" 
						<FONT></FONT>
					</P>
					<FONT face="Tahoma">
						<P>
					</FONT><FONT face="Tahoma">
						<P>
							<FONT face="Tahoma"><FONT face="Tahoma"></FONT></FONT>
						</P>
						<P>
						</P>
						<P>
							<asp:panel id="Panel24" runat="server" Width="701px" Height="677px">
								<P align="left">
									&lt;&lt;
									<asp:Image id="Image25" runat="server" ImageUrl="image\ppp\i-want-to-find-products.gif"></asp:Image>
								</P>
								<P>
									<TABLE cellSpacing="1" cellPadding="1" width="300" border="0">
										<TR>
											<TD align="left">
												<P align="left">
													&nbsp;
													<TABLE style="WIDTH: 266px; HEIGHT: 174px" borderColor="deeppink" cellSpacing="1" cellPadding="1" width="266" border="1">
														<TR bgColor="deeppink">
															<TD>
																<FONT accessKey="" face="Tahoma" color="deeppink">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																	<asp:Image id="Image26" runat="server" ImageUrl="image\ppp\topten.bmp"></asp:Image>
																</FONT>
															</TD>
														</TR>
														<TR>
															<TD>
																<B>
																	<asp:DataGrid id="DataGrid4" runat="server" Height="182px" Width="334px" BackColor="White" BorderStyle="None" BorderWidth="1px" BorderColor="#CCCCCC" CellPadding="3" AutoGenerateColumns="False">
																		<FooterStyle ForeColor="#000066" BackColor="White"></FooterStyle>
																		<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#006699"></HeaderStyle>
																		<PagerStyle HorizontalAlign="Left" ForeColor="#000066" BackColor="White" Mode="NumericPages"></PagerStyle>
																		<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#669999"></SelectedItemStyle>
																		<ItemStyle ForeColor="#000066"></ItemStyle>
																		<Columns>
																			<asp:BoundColumn DataField="ID" HeaderText="�ӴѺ���"></asp:BoundColumn>
																			<asp:TemplateColumn HeaderText="�Թ���">
																				<ItemTemplate>
																					<a href='compare.aspx?id=<%#Container.DataItem("OrderID")%>'>
																						<asp:Label id="Label1" runat="server" text='<%#Container.DataItem("product")%>'></asp:Label>
																					</a>
																				</ItemTemplate>
																			</asp:TemplateColumn>
																		</Columns>
																	</asp:DataGrid>
																</B>
															</TD>
														</TR>
													</TABLE>
												</P>
												<P align="left">
												</P>
											</TD>
											<TD>
											</TD>
										</TR>
										<TR>
											<TD align="middle">
												<TABLE height="288" cellSpacing="1" cellPadding="1" width="608" border="1">
													<TR>
														<TD>
															<asp:Image id="Image9" runat="server" ImageUrl="image\ppp\m_update.bmp"></asp:Image>
														</TD>
													</TR>
													<TR>
														<TD>
															<FONT face="Tahoma">
																<asp:DataGrid id="DataGrid3" runat="server" Height="227px" Width="681px" BackColor="White" BorderStyle="None" BorderWidth="1px" BorderColor="#CCCCCC" CellPadding="3" AutoGenerateColumns="False">
																	<FooterStyle ForeColor="#000066" BackColor="White"></FooterStyle>
																	<HeaderStyle Font-Bold="True" ForeColor="White" BackColor="#006699"></HeaderStyle>
																	<PagerStyle HorizontalAlign="Left" ForeColor="#000066" BackColor="White" Mode="NumericPages"></PagerStyle>
																	<SelectedItemStyle Font-Bold="True" ForeColor="White" BackColor="#669999"></SelectedItemStyle>
																	<ItemStyle ForeColor="#000066"></ItemStyle>
																	<Columns>
																		<asp:TemplateColumn>
																			<ItemTemplate>
																				<img src='<%#Container.DataItem("Picture")%>'> </img>
																			</ItemTemplate>
																		</asp:TemplateColumn>
																		<asp:TemplateColumn HeaderText="�Թ���">
																			<ItemTemplate>
																				<a href='compare.aspx?id=<%#Container.DataItem("OrderID")%>'>
																					<asp:Label id="Label1" runat="server" text='<%#Container.DataItem("product")%>'></asp:Label>
																				</a>
																			</ItemTemplate>
																		</asp:TemplateColumn>
																		<asp:TemplateColumn HeaderText="��������´" ItemStyle-Width="50%" ItemStyle-Height="50%" HeaderStyle-Width="70%">
																			<ItemTemplate>
																				<asp:Label id="Label3" runat="server" text='<%#Container.DataItem("Detail")%>'></asp:Label>
																			</ItemTemplate>
																		</asp:TemplateColumn>
																	</Columns>
																</asp:DataGrid>
															</FONT>
														</TD>
													</TR>
												</TABLE>
											</TD>
											<TD>
											</TD>
										</TR>
									</TABLE>
								</P>
								<P>
							</asp:panel>
					</FONT></P>
					<P>
						<FONT face="Tahoma"></FONT><FONT face="Tahoma"></FONT>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</P>
					<P>
					</FONT>
					<P>
					</P>
					<P>
						<FONT face="Tahoma"></FONT>
					</P>
					<FONT face="Tahoma">
						<P>
							<asp:panel id="Panel9" runat="server" Height="19px" Width="385px" Visible="False">
								<TABLE height="411" cellSpacing="0" cellPadding="0" width="622" border="0">
									<TR>
										<TD>
											<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
												<TR bgColor="#669966">
													<TD vAlign="top">
														&nbsp;
														<asp:image id="Image24" runat="server" ImageUrl="image\ppp\clogo255.gif"></asp:image>
													</TD>
													<TD width="100%" bgColor="#669966">
														<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
															<TR>
																<TD>
																	<IMG height="5" src="../images/space.gif" width="10" border="0">&nbsp;
																</TD>
																<TD>
																</TD>
															</TR>
															<TR>
																<TD style="HEIGHT: 18px">
																	<STRONG><FONT color="#ffffff">
																			<P align="center">
																				<STRONG><FONT color="#ffffff">SoundCard</FONT></STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
																			</P>
																		</FONT></STRONG>
																</TD>
																<TD style="HEIGHT: 18px">
																</TD>
															</TR>
															<TR>
																<TD>
																	<IMG height="5" src="../images/space.gif" width="1" border="0">
																</TD>
																<TD>
																</TD>
															</TR>
														</TABLE>
													</TD>
													<TD vAlign="top">
														<IMG height="16" src="image\ppp\white-corner-ne.gif" width="10" border="0">
													</TD>
												</TR>
											</TABLE>
										</TD>
									</TR>
									<TR>
									</TR>
									<TR bgColor="#eeeedd" nowrap>
										<TD>
											<IMG height="15" src="../images/space.gif" width="10" border="0"><FONT color="#006699"><B>��Ǩ���Թ��ҷ��س��ͧ��� 
													���������Ҥ� Update �������¤�Ѻ</B></FONT>
										</TD>
									</TR>
									<TR bgColor="#696969">
										<TD>
											<IMG height="1" src="../images/space.gif" width="1" border="0">
										</TD>
									</TR>
									<TR>
										<TD style="HEIGHT: 262px" align="middle">
											<TABLE cellSpacing="0" cellPadding="0" width="100%" border="0">
												<TR bgColor="#eeeedd">
													<TD>
														<TABLE cellSpacing="0" cellPadding="10" width="100%" border="0">
															<TR>
																<TD align="middle">
																	<TABLE cellSpacing="0" cellPadding="5" width="90%" border="0">
																		<TBODY>
																			<TR>
																				<TD vAlign="top" width="50%">
																					<P>
																						<A onmouseover="window.status='Sound Card'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=256&amp;cid=256">
																							<B>Sound Card</B></A>&nbsp;&nbsp;<FONT color="#696969">(17)</FONT>
																						<BR>
																						-&nbsp;
																						<asp:linkbutton id="LinkButton239" runat="server">ISA </asp:linkbutton>
																						<BR>
																						-&nbsp;
																						<asp:linkbutton id="LinkButton240" runat="server">PCI </asp:linkbutton>
																						<BR>
																						-&nbsp;
																						<asp:linkbutton id="LinkButton241" runat="server">Hi-end Sound Card </asp:linkbutton>
																						<BR>
																						-&nbsp;
																						<asp:linkbutton id="LinkButton242" runat="server">Professional Sound Card </asp:linkbutton>
																					</P>
																				</TD>
																				<P>
																				</P>
																</TD>
																<TD vAlign="top" width="50%">
																	<P>
																		<A onmouseover="window.status='Soundcard Popular Brand'; return true;" style="COLOR: #337777; TEXT-DECORATION: none" onmouseout="window.status=''; return true;" href="search.asp?p_cid=691&amp;cid=691">
																			<B>Soundcard Popular Brand</B></A>&nbsp;&nbsp;<FONT color="#696969">(9)</FONT>
																		<BR>
																		-&nbsp;
																		<asp:linkbutton id="LinkButton243" runat="server">Creative </asp:linkbutton>
																		<BR>
																		-&nbsp;<FONT face="Tahoma">
																			<asp:linkbutton id="LinkButton244" runat="server">X-Wave</asp:linkbutton>
																		</FONT>
																	</P>
																</TD>
															</TR>
														</TABLE>
														<P>
														</P>
														<P>
														</P>
														<P>
														</P>
														<P>
														</P>
														<P>
														</P>
													</TD>
												</TR>
											</TABLE>
										</TD>
									</TR>
								</TABLE>
				</TD>
			</TR> <!-- Start: Scoop Section *** --> <!-- End: Scoop Section *** -->
		</TABLE>
		</asp:panel></P>
		<P>
			</FONT>&nbsp;
		</P>
		</TD></FORM></TR>
		<DIV>
		</DIV>
		<P align="center">
			<FONT face="Tahoma"></FONT>
		</P>
		</TD></TR></TBODY>
		<DIV>
		</DIV>
		</TABLE>
	</DIV>
	<P align="center">
		<FONT color="#006666">Copyright 2002 - 2003, All Rights Reserved.</FONT>
	</P>
</BODY>
