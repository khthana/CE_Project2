<%@ Import Namespace="System.Data"%>
<%@ Import Namespace="System.Data.SqlClient"%>
<HTML>
	<HEAD>
		<title></title>
		<!--#include file = "head.inc"-->
		<SCRIPT Language="vb" Runat="Server">
Dim myConnection As SqlConnection
Dim mySelectQuery As String
Dim myAdapter As SqlDataAdapter
Dim myCommand As SqlCommand
Sub Page_Load()


    Dim myConnString As String

	myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
	myConnection = New SqlConnection(myConnString) 
	myConnection.Open() 
	
	
	

End Sub 

Sub Page_UnLoad()
	myConnection.Close()
End Sub

Sub clickButton1(Sender As Object, e As EventArgs)
	label1.visible="false"
	label2.visible="false"
	label3.visible="false"
	
	Dim em As string = email.text 
	Dim p1 As String = password1.text
	Dim p2 As String = password2.text
	Dim check As String = "@"
	Dim temp As Integer
	Dim temp1 As Integer = len(p1)
	Dim temp2 As Integer = len(p2)
	 
	if em<>"" and p1 <> "" and p2 <> "" then
			temp = instr(em,check)
			label1.visible="false"
			label2.visible="false"
			label3.visible="false"
			if temp = 0 then
				label1.text="�س��͡�ٻẺ Email �Դ !"
				label1.visible="true"
			else if temp1 < 6 or temp2 < 6 then
				if temp1 < 6 then
					label2.text="��سҡ�͡ Password ���ҧ���� 6 ��� !"
					label2.visible="true"
				end if
				if temp2 < 6 then
					label3.text="��سҡ�͡ Password	�׹�ѹ�Դ ���ҧ���� 6 ��� !"
					label3.visible="true"
				end if
									
			else if p1 <> p2 then
				label2.text="�س��͡ Password	���ç�ѹ !"
				label2.visible="true"
				label3.text="�س��͡ Password	�׹�ѹ ���ç�ѹ !"
				label3.visible="true"

			else				
				Dim AAA As string = email.text & "&password=" & password2.text
				Response.Redirect("regis2.aspx?email="& AAA)		
			end if				
	else
			if em="" then
			label1.text="�س������͡ Email !"
			label1.visible="true"
			end if
			if p1 = "" then
			label2.text="�س������͡ Password !"
			label2.visible="true"
			end if
			if p2 ="" then
			label3.text="�س������͡ �����׹�ѹ Password !"
			label3.visible="true"
			end if
		
				
	end if

	
End Sub
		</SCRIPT>
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
			<tr bgColor="#0066cc">
				<TD style="WIDTH: 74px" align="middle">
					<IMG alt="" src="image\page.gif">
				</TD>
				<td>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<td align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</td>
						</TR>
					</TABLE>
				</td>
			</tr>
		</table>
		<!-- Center Area -->
		<table width="100%" border="0" cellspacing="0" cellpadding="3">
			<tr align="left">
				<td width="100%" valign="top">
					<!-- status step -->
					<div class="box1">
						<font size="+1"><b><u>ŧ����¹���������</u></b></font>
						<br>
						��سһ�ԺѵԵ����鹵͹���仹��
						<br>
						<IMG id="imgone" style="DISPLAY: none" SRC="image/next.gif" align="absMiddle"> <span id="stepone">
							Step 1: ��͡�������������������ʼ�ҹ�ͧ�س</span>
						<br>
						<IMG id="imgtwo" style="DISPLAY: none" SRC="image/next.gif" align="absMiddle"> <span id="steptwo">
							Step 2: ��͡��������ǹ��Ǣͧ�س</span>
						<br>
						<!--<IMG id="imgthree" style="display: none;" SRC="image/next.gif" align=absmiddle> <span id="stepthree">Step 3: �׹�ѹ�����Ѥ���Ҫԡ�ͧ�س</span><br>-->
						���ͷӡ��ŧ����¹����Ҫԡ
					</div>
					<!-- End status step -->
				</td>
			</tr>
			<tr>
				<td width="100%" valign="top" align="middle">
					<!-- Form area -->
					<table class="box1" width="100%" height="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="antiquewhite">
						<form runat="server" method="post" id="fsign" name="frmpass">
							<TBODY>
								<tr>
									<td width="120"> <!--<div class=jpop><font color=blue><b><u>�Ը���</u></b></font></div>-->
										&nbsp;
									</td>
									<td>
										��ͧ���١������ͧ���� <sup><font color="red">*</font></sup> ���繵�ͧ��͡
									</td>
								</tr>
								<tr>
									<td width="120">
										������������� <SUP><FONT color="red">*</FONT></SUP>
									</td>
									<td>
										<asp:textbox id="email" runat="server" />
										<font color="red">
											<asp:label id="Label1" runat="server" visible="false" />
										</font>
									</td>
								</tr>
								<tr>
									<td width="120">
										���ʼ�ҹ <SUP><FONT color="red">*</FONT></SUP>
									</td>
									<td>
										<asp:textbox id="password1" runat="server" MaxLength="10" TextMode="Password">
											<sup><font color="red">*</font></sup></asp:textbox>
										<font color="red">
											<asp:label id="Label2" runat="server" visible="false" />
										</font>
									</td>
								</tr>
								<tr>
									<td width="120">
									</td>
									<td>
										<sup>����ѡ��, ����Ţ��������ͧ�������ҧ���� 6 ���</sup>
									</td>
								</tr>
								<tr>
									<td width="120">
										��������ʼ�ҹ�ա���� <SUP><FONT color="red">*</FONT></SUP>
									</td>
									<td>
										<asp:textbox id="password2" runat="server" MaxLength="10" TextMode="Password">
											<sup><font color="red">*</font></sup></asp:textbox>
										<font color="red">
											<asp:label id="Label3" runat="server" visible="false" />
										</font>
									</td>
								</tr>
								<tr>
									<INPUT type="hidden" name="ref" value="member_account.asp">
									<td>
									</td>
									<td>
										<asp:Button Text="�ӵ���" OnClick="clickButton1" runat="server" id="Button1" Height="22px" />
										<input type="reset" id="reset1" runat="server" value="Reset" NAME="reset1">
									</td>
								</tr>
						</form>
					</table>
					<!-- End Form Area -->
				</td>
			</tr>
			<!-- Copyright Bar -->
			<tr align="middle" bgcolor="#0e1c96">
				<td class="verdana" valign="top">
					<img src="image/copyright.gif" width="460" height="11" border="0"></a>
				</td>
			</tr>
			</TBODY>
		</table>
		<!-- #EndTemplate -->
	</body>
</HTML>
