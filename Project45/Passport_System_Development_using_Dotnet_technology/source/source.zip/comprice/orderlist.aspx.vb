Imports System.Data.SqlClient
Imports comprice.th.ac.kmitl.ce.network072
Imports System.Data
Imports Encryption
Imports System.text
Imports System.Web.Services
Imports System.Web.Mail

Public Class orderlist
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Protected WithEvents datagrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents link1 As System.Web.UI.WebControls.LinkButton
    Protected WithEvents Form1 As System.Web.UI.HtmlControls.HtmlForm
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Dim myConnection As SqlConnection
    Dim mySelectQuery As String
    Dim myCommand As SqlCommand
    Dim myConnString As String
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Dim dtCmd As SqlDataAdapter

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Try
            If Request.Cookies("passport").Value = "logoutted" Then
                Response.Redirect("main.aspx")
            End If

        Catch
            Response.Redirect("http://network07.ce.kmitl.ac.th/passport/login.aspx?url=http://network07.ce.kmitl.ac.th/comprice/main.aspx")
        End Try

        Dim myConnString As String
        myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
        myConnection = New SqlConnection(myConnString)
        myConnection.Open()

        Label3.Text = Request.Cookies("passport").Value

        If Not Page.IsPostBack Then BindData()
    End Sub


    Sub Page_UnLoad()
        myConnection.Close()
    End Sub

    Sub BindData()
        Dim dtCmd As SqlDataAdapter
        Dim dtSet As New DataSet()
        Dim dtView As DataView

        'mySelectQuery = "SELECT orderDetail.date,orderDetail.status,orderDetail.shop,orderDetail.price,orderDetail.quantity AS qty,orderDetail.price * orderDetail.quantity AS amt,orderDetail.ID " & _
        mySelectQuery = "SELECT *,orderDetail.quantity AS qty,orderDetail.price * orderDetail.quantity AS amt,orderDetail.ID " & _
           "FROM orderDetail " & _
                    "WHERE orderID = '" & Request.Cookies("passport").Value & "'"
        'mySelectQuery = "select * from orderDetail"
        dtCmd = New SqlDataAdapter(mySelectQuery, myConnection)
        dtCmd.Fill(dtSet)
        dtView = dtSet.Tables(0).DefaultView

        datagrid1.DataSource = dtView
        'datagrid1.DataSource = dtSet
        datagrid1.DataBind()
        If dtSet.Tables(0).Rows.Count = 0 Then
            link1.Visible = False
        Else
            link1.Visible = True
        End If
    End Sub

    Sub edit(ByVal s As Object, ByVal e As DataGridCommandEventArgs)
        datagrid1.EditItemIndex = e.Item.ItemIndex
        BindData()
    End Sub

    Sub cancel(ByVal s As Object, ByVal e As DataGridCommandEventArgs)
        datagrid1.EditItemIndex = -1
        BindData()
    End Sub

    Sub delete(ByVal s As Object, ByVal e As DataGridCommandEventArgs)
        mySelectQuery = "DELETE FROM orderDetail WHERE ID ='" & _
          datagrid1.DataKeys.Item(e.Item.ItemIndex) & _
          "' And OrderId = '" & Request.Cookies("passport").Value & "'"

        myCommand = New SqlCommand(mySelectQuery, myConnection)
        myCommand.ExecuteNonQuery()

        datagrid1.EditItemIndex = -1
        BindData()
    End Sub

    Sub update(ByVal s As Object, ByVal e As DataGridCommandEventArgs)
        Try

        mySelectQuery = "UPDATE OrderDetail SET quantity = " & _
          CType(e.Item.Cells(5).Controls(0), TextBox).Text & _
          " WHERE ID = '" & _
          datagrid1.DataKeys.Item(e.Item.ItemIndex) & _
          "' And OrderId = '" & Request.Cookies("passport").Value & "'"

        myCommand = New SqlCommand(mySelectQuery, myConnection)
        myCommand.ExecuteNonQuery()

        datagrid1.EditItemIndex = -1
            BindData()
        Catch
            Response.Redirect("errorpage.aspx")

        End Try
    End Sub

    Private Sub link1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles link1.Click
        Label2.Visible = False
        Dim web_passport As New th.ac.kmitl.ce.network072.Service1()
        If TextBox1.Text <> "" Then
            Dim myConnString As String
            Dim pass As String
            Dim dtSet As DataSet
            myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
            myConnection = New SqlConnection(myConnString)
            myConnection.Open()

            If web_passport.getLogin(Request.Cookies("passport").Value, TextBox1.Text) = True Then

                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                'Dim iLoop As Integer
                'Dim myAdapter As SqlDataAdapter
                'Dim ds As DataSet = New DataSet()
                'mySelectQuery = "select * from OrderDetail where OrderId = '" & Request.Cookies("passport").Value & "' and status = '�͡����觫���'"
                'myConnection = New SqlConnection(myConnString)
                'myConnection.Open()
                'myAdapter = New SqlDataAdapter(mySelectQuery, myConnection)
                'myAdapter.Fill(ds)

                'Dim iNumRows As Integer = ds.Tables(0).Rows.Count

                'Dim myAdapter1 As SqlDataAdapter
                'Dim ds1 As DataSet = New DataSet()
                'mySelectQuery = "select * from Topten "
                'myConnection = New SqlConnection(myConnString)
                'myConnection.Open()
                'myAdapter1 = New SqlDataAdapter(mySelectQuery, myConnection)
                'myAdapter1.Fill(ds1)

                'For iLoop = 0 To iNumRows

                '    mySelectQuery = "select * from topten where OrderId = '" & Request.Cookies("passport").Value & "' and status = '�͡����觫���'"
                '    myConnection = New SqlConnection(myConnString)
                '    myConnection.Open()
                '    myAdapter = New SqlDataAdapter(mySelectQuery, myConnection)
                '    myAdapter.Fill(ds)
                'Next


                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                mySelectQuery = "UPDATE OrderDetail SET status = '��觫������º����' , pos_date ='" & Now & _
                                "' where OrderId = '" & Request.Cookies("passport").Value & "' and status = '�͡����觫���'"
                myCommand = New SqlCommand(mySelectQuery, myConnection)
                myCommand.ExecuteNonQuery()

                mySelectQuery = "insert into Orders(orderid,orderdate,name,surname,address,province,zipcode)" & _
              "values('" & Request.Cookies("passport").Value & "','" & Now & _
              "','" & web_passport.getName(Request.Cookies("passport").Value, TextBox1.Text) & _
              "','" & web_passport.getSurname(Request.Cookies("passport").Value, TextBox1.Text) & _
              "','" & web_passport.getAddress(Request.Cookies("passport").Value, TextBox1.Text) & _
              "','" & web_passport.getProvince(Request.Cookies("passport").Value, TextBox1.Text) & _
              "','" & web_passport.getZipcode(Request.Cookies("passport").Value, TextBox1.Text) & "')"

                myCommand = New SqlCommand(mySelectQuery, myConnection)
                myCommand.ExecuteNonQuery()



                Dim myMail = New MailMessage()
                myMail.To = Request.Cookies("passport").Value
                myMail.From = "admin@comprice.net"
                myMail.Subject = "�׹�ѹ�����觫����Թ���"
                myMail.Body = "��ҹ����觫����Թ��ҡѺ�ҧ comprice �Թ��ҨШѴ������ͷ�ҹ��ӡ���͹�Թ��Һѭ�բͧ��� "

                myMail.BodyFormat = MailFormat.Text
                SmtpMail.SmtpServer = "mail.kmitl.ac.th"
                SmtpMail.Send(myMail)



                Response.Redirect("order_complete.aspx")



            Else
                    Label2.Text = "email ��͡���١��ͧ ��سҡ�͡�����ա���� !"
                    Label2.Visible = True
            End If

        Else
        If TextBox1.Text = "" Then
            Label2.Text = "�س������͡ ���ʼ�ҹ !"
            Label2.Visible = "true"
        End If


        End If


    End Sub
End Class
