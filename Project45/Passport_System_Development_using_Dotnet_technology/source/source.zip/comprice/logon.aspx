<%@ Import Namespace="System.Data.SqlClient"%>
<%@ Import Namespace="System.Data"%>
<!--#include file = "head.inc"-->
<HTML>
	<HEAD>
		<title></title>
		<SCRIPT Language="vb" Runat="Server">
Dim myConnection As SqlConnection
Dim myAdapter As SqlDataAdapter
Dim mySelectQuery As String
Dim myCommand As SqlCommand
Dim recordAffected as integer 
Sub Page_Load()
    Dim myConnString As String

	myConnString = "server=localhost;database=computer;Trusted_Connection=yes"
	myConnection = New SqlConnection(myConnString) 
	myConnection.Open() 
	

End Sub 

Sub Page_UnLoad()
	myConnection.Close()
End Sub

Sub clickButton1(sender As Object, e As System.Web.UI.ImageClickEventArgs)
	
	Dim em As string = email.text 
	Dim p1 As String = password1.text
	label1.visible="false"
	label2.visible="false"
	label3.visible="false"
					
	if em<>"" and p1 <>""  then
			
			mySelectQuery = "Select count(*)" & _
			"From Member " & _
			"where email='"& email.text &"' and password='" & password1.text &"' "

			myCommand = New SqlCommand(mySelectQuery, myConnection)
			
			recordAffected = Cint(myCommand.ExecuteScalar())
			if  recordAffected = 1 then
					Session("id") = Session.SessionID
					Response.Redirect("webform11.aspx")		
			else 
				label3.text="email ���� password ����͡���١��ͧ ��سҡ�͡�����ա���� !"
				label3.visible="true"
				
			end if		
								
	else
			if em="" then
			label1.text="�س������͡ Email !"
			label1.visible="true"
			end if
			if p1="" then
			label2.text="�س������͡ Password !"
			label2.visible="true"
			end if
			
				
	end if

	
End Sub
		</SCRIPT>
		<!-- #BeginEditable "doctitle" -->
		<!-- #EndEditable -->
		<meta http-equiv="Content-Type" content="text/html; charset=tis-620">
	</HEAD>
	<body bgColor="#ffffff" leftMargin="0" topMargin="0" marginwidth="0" marginheight="0">
		<table cellSpacing="0" borderColorDark="#0066cc" cellPadding="0" width="100%" borderColorLight="#0066cc" border="1">
			<tr bgColor="#0066cc">
				<TD style="WIDTH: 74px" align="middle">
					<IMG alt="" src="image\page.gif">
				</TD>
				<td>
					<TABLE height="50" width="100%" bgColor="#0066cc">
						<TR>
							<TD style="WIDTH: 544px" align="middle">
								<FONT face="LilyUPC" size="4">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<FONT face="MS Sans Serif" size="2"><STRONG><FONT color="#ffffff">
												<FONT size="4">Comprice</FONT></FONT>&nbsp;</STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</FONT></FONT><FONT face="MS Sans Serif" size="2">
								</FONT>
							</TD>
							<td align="middle">
								<FONT face="MS Sans Serif" size="2">&nbsp;&nbsp;&nbsp;&nbsp;<FONT color="#ffffff">&nbsp;�ѹ���&nbsp;
										<%=Day(Now)%>
										/<%=Month(Now)%>
										/<%=(Year(Now))%>
									</FONT></FONT>
							</td>
						</TR>
					</TABLE>
				</td>
			</tr>
		</table>
		<!-- Center Area -->
		<table cellSpacing="0" cellPadding="3" width="100%" border="0">
			<tr>
				<td vAlign="top" align="middle" width="100%">
					<!-- Form area -->
					<table class="box1" height="100%" cellSpacing="0" cellPadding="0" width="100%" bgColor="antiquewhite" border="0">
						<form runat="server" id="fsign" name="fsign" action="webform8.aspx" method="post">
							<TBODY>
								<tr>
									<td>
										<table border="0">
											<tr>
												<td align="left" colSpan="2">
													<font size="+1"><b>Sign in</b></font>
												</td>
											</tr>
											<tr>
												<td>
													�������������
												</td>
												<td>
													<asp:textbox id="email" runat="server" />
													<font color="red">
														<asp:label id="Label1" runat="server" visible="false" />
													</font>
												</td>
											</tr>
											<tr>
												<td>
													���ʼ�ҹ
												</td>
												<td>
													<asp:textbox id="password1" runat="server" MaxLength="10" TextMode="Password"></asp:textbox>
													<font color="red">
														<asp:label id="Label2" runat="server" visible="false" />
													</font>
												</td>
											</tr>
											<INPUT type="hidden" value="member_account.asp" name="ref">
											<tr>
												<td>
												</td>
												<td>
													<P> <!--<INPUT type="checkbox" id=rem name=rem> �����ʼ�ҹ���-->
													</P>
													<P>
														<font color="red">
															<asp:label id="Label3" runat="server" visible="false"></asp:label>
														</font>
														<br>
														������ʼ�ҹ��ԡ<A href="member_resetpassword.asp">�����</A>
													</P>
												</td>
											</tr>
											<tr>
												<td align="middle" colSpan="2">
													<asp:ImageButton id="ImageButton1" ImageUrl="image\button_login_blue.GIF" OnClick="Clickbutton1" runat="server"></asp:ImageButton>
												</td>
											</tr>
											<tr>
												<td align="left" colSpan="2">
													<A href="webform9.aspx"><font size="+1"><b>Sign up</b></font></A>
												</td>
											</tr>
											<tr>
												<td align="left" colSpan="2">
													����Ѻ������ѧ�����ŧ����¹����Ҫԡ ��ԡ<A href="webform9.aspx">�����</A>������Ѥ�����Ҫԡ
												</td>
											</tr>
										</table>
									</td>
								</tr>
						</form>
					</table>
					<!-- End Form Area -->
				</td>
			</tr>
			<!-- Copyright Bar -->
			<tr align="middle" bgColor="#0e1c96">
				<td class="verdana" vAlign="top">
					<A href="https://www.amarin.co.th/" target="_blank"><IMG height="11" src="image/copyright.gif" width="460" border="0"></A>
				</td>
			</tr>
			</TBODY>
		</table>
		<!-- #EndTemplate -->
	</body>
</HTML>
