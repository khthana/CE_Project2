<? // ���������Ǣ�ͧ����� insert_book.php  , function.php [insert_person()] ?>
<?
include("database.php");
include("function.php");
include("connect_db.php");
require_once("headeradmin.php");
check_permit();

?>

<? header_admin("�����ؤ�ҡ�");?>
<br><br>

<form action="insert_person.php" method="post">
<table align="center" border="1" bordercolor="#FFFFFF" cellspacing="0">
	<tr align="center" bgcolor ="#3366CC">
		<td colspan="2">
			<font face="MS Sans Serif" size="3" color="#FFFFFF"><b>�����ؤ�ҡ�����</b></font>
		</td>
	</tr>
	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>ID : </b></font></td> 
		<td bgcolor="#DDEEEE"><input type="text" name="DoctorID" maxlength ="10" size="30"></td>
	</tr>
	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>����-ʡ�� : </b></font></td>
		<td bgcolor="#DDEEEE"><input type="text" name="DoctorName" maxlength ="100" size="30"></td>
	</tr>
	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>��������Ǫҭ : </b></font></td>
		<td bgcolor="#DDEEEE">  <select size="1" name="CatID"> 

<?
		$result = show_data("categories");
		while($row = mysql_fetch_array($result,MYSQL_ASSOC)) 
		{
?>
		<option value="<?=$row["CatID"]?>"><?=$row["CatName"]?></option>
<?
		}
?>
		</td>
	</tr>

	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>������� : </b></td>
		<td bgcolor="#DDEEEE"><textarea cols="50" row="2" name="Address" maxlength="100"></textarea></td></font>
	</tr>

	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>���Ѿ����Ͷ�� : </b></font></td>
		<td bgcolor="#DDEEEE"><input type="text" name="MobilePhone" maxlength ="100" size="30"></td>
	</tr>

	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>���Ѿ���ҹ : </b></font></td>
		<td bgcolor="#DDEEEE"><input type="text" name="Phone" maxlength ="100" size="30"></td>
	</tr>

	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>������ : </b></font></td>
		<td bgcolor="#DDEEEE"><input type="text" name="Email" maxlength ="100" size="30"></td>
	</tr>

	<tr>
		<td bgcolor="#EEEEFF"><font face="MS Sans serif"><b>����ٻ�Ҿ : </b></font></td>
		<td bgcolor="#DDEEEE"><input type="text" name="Picture"></td>
	</tr>

	<tr bgcolor="#EEEEFF" align="center">
		<td colspan="2"><input type="submit" name="save" value="�����ؤ�ҡ�����"></td>
	</tr>

</table>
</form>

<?
echo "<br><br>";
require_once("footer.php");
?>
