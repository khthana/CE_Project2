<?php
	include("function.php");
	
	head_html("��͡��ҷ�ҡ�к�");
	
	session_start();
	session_destroy();
	header("Location: index.php"); 
	
	end_head_html();
?>