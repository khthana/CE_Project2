<?
		include("database.php");
		include("function.php");
		require_once("connect_db.php");
		require_once("headerofficer.php");
		check_session();
		header_officer("�׺�鹢����ž�ѡ�ҹ");	

		$dbname = "hospital";	
		$tblname = "tbldoctor";	
		mysql_select_db($dbname) or die("���͡�ҹ�����������");
		
		$sql_search = "select * from $tblname where $type like '%$search%' order by DoctorID,DoctorName";	
		$db_query_search = mysql_db_query($dbname, $sql_search);
		$num_rows_search = mysql_num_rows($db_query_search);
		$num_fields = mysql_num_fields($db_query_search);
?>
	<TABLE cellSpacing="0"cellPadding="0" width="100%" align="center" >
	<TR>
		<TD><font face = "MS Sans Serif" color="#000000" size="2"></font>&nbsp; <BR>
      
	  <TABLE borderColor=black cellSpacing=0 cellPadding=2 width="100%" border="0">
        <TBODY>
        <TR>
 <? 

			$pagesize = 20;
			$status_admin="";
			$status1 = "../image/icon_pin.gif ";
			if (empty($page)){
				$page=1;
			}   

		$q_sql = "select * from $tblname where $type like '%$search%'  order by  DoctorID";
			$q_db_query = mysql_db_query ($dbname, $q_sql);
			$num_rows = mysql_num_rows($q_db_query);
			$rt = $num_rows%$pagesize;	// �Ҩӹǹ˹�ҷ�����

			if($rt!=0) 
				{ 
					$totalpage = floor($num_rows/$pagesize)+1; 
				}
			else 
				{
					$totalpage = floor($num_rows/$pagesize); 
				}

			$goto = ($page-1)*$pagesize;	// ��˹�ҷ��С��ⴴ�

			$sql = "select * from $tblname order by DoctorID ASC limit $goto,$pagesize";
			$db_query = mysql_db_query ($dbname, $sql);
				if (!$db_query)
					{ 
						echo("��硫Ԥ�ǵ����� SQL ����� " . mysql_error() ); 
						exit;
					}
				else	 
					{
						$nums_rows = mysql_num_rows($db_query);	 
					}

?>
		</TR>
		</TBODY>
	</TABLE><br><br>
	
	<TABLE  cellSpacing=0 cellPadding=2 width="100%" border=1>
	<TBODY>
		<TR bgColor=#CCCCCC>
			<TD align=middle width="7%"><font face = "MS Sans Serif" color="#000000" size="1"><B>����</B></FONT></TD>
			<TD align=middle width="15%"><font face = "MS Sans Serif" color="#000000" size="1"><B>����</B></FONT></TD>
			<TD align=middle width="20%"><font face = "MS Sans Serif" color="#000000" size="1"><B>�������</B></FONT></TD>
			<TD align=middle width="15%"><font face = "MS Sans Serif" color="#000000" size="1"><B>��Ǵ�����������Ǫҭ </B></FONT></TD>
			<TD align=middle width="13%"><font face = "MS Sans Serif" color="#000000" size="1"><B>�������Ѿ����Ͷ��</B></FONT></TD>
			<TD align=middle width="13%"><font face = "MS Sans Serif" color="#000000" size="1"><B>�������Ѿ���ҹ</B></FONT></TD>
			<TD align=middle width="4%"><font face = "MS Sans Serif" color="#000000" size="1"><B>������</B></FONT></TD>
		</TR>

<?	

// �������ǹ��ǵ��ҧ
$swap="#cce9fd";
for ($i=0;$i < $num_rows_search;$i++)
	{
		
							$result = mysql_fetch_array($db_query_search);
							@$doctorid = $result[DoctorID];
							@$doctorname = $result[DoctorName];
							@$address = $result[Address];
							@$catid = $result[CatID];
							@$mobilephone = $result[MobilePhone];
							@$phone = $result[Phone];
							@$email = $result[Email];


if(($total_borrow >= 1)&&($total_borrow <=5))
							{
							$status = "<img src =\"image/icon_new.gif \" border =\"0\">";
							}
							else if($total_borrow >= 1){
							$status = " <IMG  src =\"image/icon_reply.gif\" border =\"0\">";
						}
					else{
							$status = "<img src =\"image/icon_pin.gif \" border =\"0\">";
							
							}

print <<<EOT
<TR bgColor="99FFFF">
    <TD width="7%"><font face = "MS Sans Serif" color="#000000" size="1">$doctorid </font></TD>
    <TD width="15%"><font face = "MS Sans Serif" color="#000000" size="1">$doctorname</FONT></TD>
    <TD width="20%"><font face = "MS Sans Serif" color="#000000" size="1">$address</FONT></TD>
    <TD width="15%"><font face = "MS Sans Serif" color="#000000" size="1">$catid</FONT></TD>
	<TD width="13%"><font face = "MS Sans Serif" color="#000000" size="1">$mobilephone</FONT></TD>
	<TD width="13%"><font face = "MS Sans Serif" color="#000000" size="1">$phone</FONT></TD>
	<TD width="10%"><font face = "MS Sans Serif" color="#000000" size="1">$email</FONT></TD></TR>

EOT;
	}

//end While

echo "<tr bgcolor=\"#CCCCCC\"><font face = \"MS Sans Serif\" color=\"#0000FF\" size=\"2\"> �ʴ��š�ä��Ң����ŷ���դ���� [<font face = \"MS Sans Serif\" color=\"#000000\" size=\"2\">".$search."</font><font face = \"MS Sans Serif\" color=\"#0000FF\" size=\"2\">] </font>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;<font face = \"MS Sans Serif\" color=\"#0000FF\" size=\"2\"> �鹾� </font><font face = \"MS Sans Serif\" color=\"#000000\" size=\"2\"><b>". $i."</b></font><font face = \"MS Sans Serif\" color=\"#0000FF\" size=\"2\"> �á����</font>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;<A Href="."form_search6.php".">��Ѻ令������� </A></tr><br>";

mysql_close();	// �Դ�����������

?> 
</center></TD></TR></TBODY></TABLE><br><br>
<? 
	require_once("footer.php"); 
?>

