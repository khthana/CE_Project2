<?
		include("database.php");
		include("function.php");
		require_once("connect_db.php");
		require_once("headeradmin.php");
		require_once("connect_db.php");
		require_once("check_data.php");
		check_permit();
		header_admin("�׺�鹢����ž�ѡ�ҹ");	
?>	
		<br><br>
		<table align="center" >
                      <tr> 
							<td width="300" align="center">
								<form name="form1" method="post" action="search1.php">
									<tr bgcolor="#6699CC"> 
										<td colspan="3" align="center">
											<font face = "MS Sans Serif" color="#FFFFFF" size="2"><b>�׺�鹢����ž�ѡ�ҹ</b></font>
										</td>
									</tr>
									
									<tr> 
										<td bgcolor="#33FFFF"><font face = "MS Sans Serif" color="#000000" size="2"><b>���Ҩҡ:</b></font>
											<SELECT  name=type>
												<OPTION  value = DoctorID>- ���ʾ�ѡ�ҹ</OPTION>
												<OPTION  value = DoctorName>- ���� ���� ���ʡ��</OPTION>
												<OPTION  value = MobilePhone>- �������Ѿ����Ͷ��</OPTION>
												<OPTION  value = Phone>- �������Ѿ���ҹ</OPTION>
												<OPTION  value = Email>- ������</OPTION>
											</SELECT>
										</td>
										
										<td bgcolor="#33FFFF">
											<font face = "MS Sans Serif" color="#000000" size="2"><b>����: </b></font>
											<input type="text" name="search" >
										</td>
                            
										<td>
											<input type="submit" name="Search" value="���Ң�����">
										</td>
									</tr>
                            </form>
						</td>
                    </tr>
		</table>
		<br><br>
<? 
	require_once("footer.php"); 
?>