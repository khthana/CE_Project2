<?php
		include("function.php");
		require_once("connect_db.php");
		require_once("headeradmin.php");
		require_once("connect_db.php");
		require_once("check_data.php");
		check_permit();
		header_admin("���������ż����ҹ");	

?>
	<br>
	<table width="50%" border="0" cellspacing="10" cellpadding="0" align="center">
              <tr>
                        <td>
                                <table width="100%" border="0" cellspacing="1" cellpadding="0">
                                        <tr>
                                                <td>
                                                        <table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#A6A6FF" bordercolor="#EC4D00">
                                                                <tr>
                                                                        <td align="center"><font face = "MS Sans Serif" color="#000000" size="2">���������ż����ҹ</font></td>
                                                                </tr>																
                                                        </table>
                                                </td>
                                        </tr>
                                        <tr>
                                                <td>
                                                        <form method="post" action="process_user_profile.php?mode=add" name="form">
                                                                <table width="100%" border="0" cellspacing="1" cellpadding="0">
																		<tr>
                                                                                <td bgcolor="#F3F3F3"  align="right" width="30%">&nbsp;</td>
                                                                                <td bgcolor="#F3F3F3" width="70%">&nbsp;</td>
                                                                        </tr> 
                                                                			<tr>
                                                                                <td bgcolor="#F3F3F3"  align="right" width="30%">���ͨ�ԧ : </td>
                                                                                <td bgcolor="#F3F3F3" width="70%"><input type="text" name="first_name"></td>
                                                                        </tr> 
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">���ʡ�� : </td>
                                                                                <td bgcolor="#F3F3F3"><input type="text" name="last_name"></td>
                                                                        </tr>  
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">&nbsp;</td>
                                                                                <td bgcolor="#F3F3F3">&nbsp;</td>
                                                                        </tr>    
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">���ͼ���� : </td>
                                                                                <td bgcolor="#F3F3F3"><input type="text" name="user_name"></td>
                                                                        </tr>
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">���ʼ�ҹ : </td>
                                                                                <td bgcolor="#F3F3F3"><input type="password" name="pass"></td>
                                                                        </tr>
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">&nbsp;</td>
                                                                                <td bgcolor="#F3F3F3">&nbsp;</td>
                                                                        </tr>                                                                                                                                                                                                                                                                                       
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">ʶҹ� : </td>
                                                                                <td bgcolor="#F3F3F3">
                                                                                		<select name="status" size="1">
																													<option value="0">������</option>
																													<option value="1">��ѡ�ҹ</option>
																													<option value="2">��Ҫԡ</option>
																												</select>
                                                                                </td>
                                                                        </tr>
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3" align="right">&nbsp;</td>
                                                                                <td bgcolor="#F3F3F3">&nbsp;</td>
                                                                        </tr>
                                                                        <tr>
                                                                                <td bgcolor="#F3F3F3"></td>
                                                                                <td bgcolor="#F3F3F3"><input type="submit" value="����Ѻ"><input type="reset" value="¡��ԡ"></td>
                                                                        </tr>
                                                                </table>
                                                        </form>
                                                </td>
                                        </tr>                                                                                                                                                                                                                                                                                 
                                </table>
                        </td>
                </tr>
	</table>

<?php
	require_once("footer.php");
?>