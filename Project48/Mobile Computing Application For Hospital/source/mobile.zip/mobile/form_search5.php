<?
		include("database.php");
		include("function.php");	
		require_once("connect_db.php");
		require_once("headerofficer.php");
		require_once("connect_db.php");
		require_once("check_data.php");
		check_session();
		header_officer("�׺�鹢����ž�ѡ�ҹ");		
?>	
		<br><br>
		<table align="center" >
                      <tr> 
							<td width="300" align="center">
								<form name="form1" method="post" action="search5.php">
									<tr bgcolor="#6699CC"> 
										<td colspan="3" align="center">
											<font face = "MS Sans Serif" color="#FFFFFF" size="2"><b>�׺�鹢�������</b></font>
										</td>
									</tr>
									
									<tr> 
										<td bgcolor="#33FFFF"><font face = "MS Sans Serif" color="#000000" size="2"><b>���Ҩҡ:</b></font>
											<SELECT  name=type>
												<OPTION  value = DgID>- ������</OPTION>
												<OPTION  value = DgName>- ������</OPTION>
											</SELECT>
										</td>
										
										<td bgcolor="#33FFFF">
											<font face = "MS Sans Serif" color="#000000" size="2"><b>����: </b></font>
											<input type="text" name="search" >
										</td>
                            
										<td>
											<input type="submit" name="Search" value="���Ң�����">
										</td>
									</tr>
                            </form>
						</td>
                    </tr>
		</table>
		<br><br>
<? 
	require_once("footer.php"); 
?>