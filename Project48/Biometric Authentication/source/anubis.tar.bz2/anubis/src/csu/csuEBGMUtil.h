/*
$RCSfile: csuEBGMUtil.h,v $
$Author: a2c $
$Date: 2005/12/07 17:19:45 $
*/

/*
Copyright (c) 2003 Colorado State University

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom
the Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
*/

/*
 * some modified by Atsushi Suga for anubis applications
 *
 * added
 *
 * in GaborJet
 *    char * vertLabel;
 *
 * in FaceGraph
 *    char * faceLabel;
 *    char * fg_image_fname;
 */

#ifndef CSU_GABOR_INCLUDED
#define CSU_GABOR_INCLUDED

#include <csuCommon.h>

#define LABELMAX 100

#define GFTYPE FTYPE
/*#define GFTYPE int*/

double WiskottDCFree;

/*************************** Gabor Parameters ******************************/

/* These parameters hold on to the information
 * needed for the gabor kernel.  For many
 * applications, it is assumed that every other
 * gabor kernel is identical but out of phase by
 * 90 degrees (even and odd).  Jets assume this
 * structure and store complex values.  Therefore
 * a jet stores length/2 complex values. */
typedef struct{
    int length;

    GFTYPE* wavelength;
    GFTYPE* angle;
    GFTYPE* phase;
    GFTYPE* aspect;
    GFTYPE* radius;
    int*    size;

    /* Precomputed parameters for displacement estimation */
    GFTYPE* kx;
    GFTYPE* ky;
} gabor_jet_params;

typedef gabor_jet_params *GaborJetParams;

/* Allocate/Free space for the Jet Params */
GaborJetParams makeJetParams(int size);
void freeJetParams(GaborJetParams params);


/******************************** Gabor Mask *******************************/

/* This structure holds on to images of gabor kernels that
 * are used in convolution to determine the gabor coeffecents
 */
typedef struct{
    int size;
    Image *masks;

    GaborJetParams params;
} jet_masks;

typedef jet_masks* JetMasks;

/* Allocate/Free space for the Jet Masks */
JetMasks makeJetMasks(int size);
void     freeJetMasks(JetMasks masks);

Image makeGaborMask(FTYPE wavelength, FTYPE angle, FTYPE phase, FTYPE aspect, FTYPE radius, int size);

JetMasks readMasksFile(const char* filename);

/******************************* Gabor Jets ********************************/
/* Gabor Jet Structure
*
* This structure uses containes the convolution values for a set
* of gabor filters at a paticular location.  Structure elements
* include the location x,y and length of the jet, and the values.
* see Wiskott (Sec. 2.1.1)
*/
/* add original data type char* vertLabel */
typedef struct{
    char* vertLabel;/* add by anubis */
  
    int length;
    GFTYPE x, y;

    /* Complex specification for the coeffiecients */
    GFTYPE* realPart;
    GFTYPE* imagPart;

    /* Polar transformation of the above complex numbers*/
    GFTYPE* mag;
    GFTYPE* ang;

    /* Parameters used to generate gabor kernels */
    GaborJetParams params;
} gabor_jet;

typedef gabor_jet *GaborJet;

GaborJet makeGaborJet  (int length);
void     freeGaborJet  (GaborJet jet);
GaborJet extractJet    (GFTYPE x, GFTYPE y, Image im, JetMasks masks);
void     setExtractJet (GaborJet jet, GFTYPE x, GFTYPE y, Image im, JetMasks masks);
void     dump_gabor_jet(GaborJet jet);
/******************************* Jet Bunch *********************************/

/*
A Jet bunch is a collection of gabor jets that have been extracted from the
same facidual point on the face.  The idea is to form a "bunch" (collection)
of example jets that represent that point.  When trying to localize a point
in a novel image the code can choose a jet that is more similar to the image
being matched.
*/

typedef struct{
    int allocsize;
    int size;

    GaborJet* jets;
} jet_bunch;

typedef jet_bunch *JetBunch;


JetBunch makeJetBunch();
void freeJetBunch(JetBunch bunch);
int addJetToBunch(JetBunch bunch, GaborJet jet);


/************************* Gabor Graph Discription *************************/

typedef struct{
    int vert1, vert2;
} Edge;

typedef struct{
    FTYPE x, y;
} Vert;

typedef struct{
    int numVert;
    int numEdge;
    Vert* verts;
    Edge* edges;
    char** vertLabels;

    JetBunch* bunch;
} graph_discription;

typedef graph_discription *GraphDiscription;

/* This function reads in a discription of a graph and loads it into
 * a graph discription structure.  The file format is asci were the
 * first token is the number of vericies followed by verticy labels
 * and guess x, y coordinates.  This is followed by the number of edges
 * and the indexes of the vericies that they connect.
 */
GraphDiscription readGraphDiscription(const char* filename);
void             saveGraphDiscription(const char* filename,GraphDiscription);
void             freeGraphDiscription(GraphDiscription gd);


/******************************* Face Graph ********************************/

typedef struct {
    char * faceLabel; /* added by anubis */
    char * fg_image_fname; /* added by anubis */
  
    int geosize; /* numbers of the located point. */
    int totalsize; /* number fo the located points and interpolated points */
    GaborJetParams params;
    GaborJet* jets;
} face_graph;

typedef face_graph* FaceGraph;

FaceGraph makeFaceGraph( int geosize, int totalsize );
void freeFaceGraph( FaceGraph );
void freeFaceGraphElemWithDeAlloc( FaceGraph fg );

FaceGraph loadFaceGraph(char *filename);
void saveFaceGraph(char *filename, FaceGraph);



/*********************** Extra Utility Functions ***************************/
Image makeJetImage(const JetMasks masks, const Image im);
Image makeComplexImage(const Image jetImage);
JetMasks readMasksFile(const char* filename);




#endif



