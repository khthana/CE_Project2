
#include "ModelVertex.h"

//=====================================
BOOL CModel::CreateVertexBuffer(VERTEX2* vtData,long num)
{
	num = sizeof(*vtData) * num;
	void* pVertices;
	m_Graphics->GetDeviceCOM()->CreateVertexBuffer(num,
					  0,D3DFVF_VERTEX2,
					  D3DPOOL_DEFAULT,&pVB);
	
	if(FAILED(pVB->Lock(0,num,(BYTE**)&pVertices,0)))
	{
		MessageBox(NULL,"Cannot lock vertex data","Class CModel2: Error",
			MB_ICONERROR | MB_OK);
		return false ;
	}

	memcpy(pVertices,vtData,num);
	if(FAILED(pVB->Unlock()))
	{
		MessageBox(NULL,"Cannot unlock vertex data","Class CModel: Error",
			MB_ICONERROR | MB_OK);
		return false ;
	}
    
	m_Graphics->GetDeviceCOM()->SetStreamSource(0,pVB,sizeof(VERTEX2));
	m_Graphics->GetDeviceCOM()->SetVertexShader(D3DFVF_VERTEX2);
    m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ZENABLE, true);
	return true;
}
//=====================================
BOOL CModel::CreateSkybox(cGraphics *pGraph)
{
	if(pGraph == NULL)return false;
	m_Graphics = pGraph;

	TextureName szTextName[6][25] =
	 {
		 "dessert//PosX.bmp","dessert//NegX.bmp",
		 "dessert//PosY.bmp","dessert//NegY.bmp",
		 "dessert//PosZ.bmp","dessert//NegZ.bmp"
	 };
	VERTEX2 vtBox[]=
	{
			
	// Positive X (Right face)
    { 25.0f, -25.0f,  25.0f,color, 0.0f , 1.0f },
    { 25.0f,  25.0f,  25.0f,color, 0.0f , 0.0f },
    { 25.0f, -25.0f, -25.0f,color, 1.0f , 1.0f },
    { 25.0f,  25.0f, -25.0f,color, 1.0f , 0.0f },
    // Negative X (Left face)
    {-25.0f, -25.0f, -25.0f,color, 0.0f , 1.0f },
    {-25.0f,  25.0f, -25.0f,color, 0.0f , 0.0f },
    {-25.0f, -25.0f,  25.0f,color, 1.0f , 1.0f },
    {-25.0f,  25.0f,  25.0f,color, 1.0f , 0.0f },
    // Positive Y (Top face)
    {-25.0f,  25.0f,  25.0f,color, 0.0f , 1.0f },
    {-25.0f,  25.0f, -25.0f,color, 0.0f , 0.0f },
    { 25.0f,  25.0f,  25.0f,color, 1.0f , 1.0f },
    { 25.0f,  25.0f, -25.0f,color, 1.0f , 0.0f },
    // Negative Y (Bottom face)
    {-25.0f, -25.0f, -25.0f,color, 0.0f , 1.0f },
    {-25.0f, -25.0f,  25.0f,color, 0.0f , 0.0f },
    { 25.0f, -25.0f, -25.0f,color, 1.0f , 1.0f },
    { 25.0f, -25.0f,  25.0f,color, 1.0f , 0.0f },
    // Positive Z (Front face)
    {-25.0f, -25.0f,  25.0f,color, 0.0f , 1.0f },
    {-25.0f,  25.0f,  25.0f,color, 0.0f , 0.0f },
    { 25.0f, -25.0f,  25.0f,color, 1.0f , 1.0f },
    { 25.0f,  25.0f,  25.0f,color, 1.0f , 0.0f },
    // Negative Z (Back face)
    { 25.0f, -25.0f, -25.0f,color, 0.0f , 1.0f },
    { 25.0f,  25.0f, -25.0f,color, 0.0f , 0.0f },
    {-25.0f, -25.0f, -25.0f,color, 1.0f , 1.0f },
    {-25.0f,  25.0f, -25.0f,color, 1.0f , 0.0f }

	};
	
    short bnumVt = sizeof(vtBox)/sizeof(vtBox[1]);
	CreateVertexBuffer(vtBox,bnumVt);
	
	//Create texture from file
	for(int i=0;i<=5;i++)
	{
		if(FAILED(D3DXCreateTextureFromFile(m_Graphics->GetDeviceCOM(), szTextName[i], &pTexBox[i])))
		{ MessageBox(NULL,"Cannot create texture data","Class CModel: Error",
				MB_ICONERROR | MB_OK);
		}
	}
	//Bilinear Texture
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTEXF_LINEAR);
    m_Graphics->GetDeviceCOM()->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTEXF_LINEAR);
    m_Graphics->GetDeviceCOM()->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTEXF_POINT);

	return true;


}
//=====================================
void CModel::RenderSkyBox()
{
	m_Graphics->GetDeviceCOM()->SetStreamSource(0,pVB,sizeof(VERTEX2));
	m_Graphics->GetDeviceCOM()->SetVertexShader(D3DFVF_VERTEX2);

    m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ZENABLE, TRUE);
	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	//Set Texture addressing to clamp
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_ADDRESSU,D3DTADDRESS_CLAMP);
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_ADDRESSV,D3DTADDRESS_CLAMP);
	for(int nTexture=0;nTexture<=5;nTexture++)
	{		
		m_Graphics->GetDeviceCOM()->SetTexture(0,pTexBox[nTexture])	;
		m_Graphics->GetDeviceCOM()->DrawPrimitive(D3DPT_TRIANGLESTRIP,nTexture * 4,2);
	}

}
//============Load Model===============
BOOL CModel::LoadModelMd2(cGraphics *pGraph,char* filename,char* texture)
{
	if(pGraph == NULL) return 0;
	else m_Graphics = pGraph;
	int j,k=0;
	float max_tex_u =0;
	float max_tex_v =0;
	FILE *modelfile;
	byte buffer[2048*4+128];

	if((modelfile = fopen(filename,"rb"))==NULL)
		MessageBox(NULL,"Cannot open file","Class CModel: Error",
			      MB_ICONERROR | MB_OK);

	m_data = new SMesh[MAX_FRAMES];
	
	fread(&md2header,sizeof(md2header),1,modelfile);
	fseek(modelfile,md2header.ofs_st,0);
	fread(&ttCor,1,sizeof(textureCoordinate_t) * md2header.num_st,modelfile);
	m_data[0].numVertex  = md2header.num_xyz;
	//find height and width of texture
	fseek(modelfile,md2header.ofs_tris,0);
	for(int i=0; i<md2header.num_tris;i++)
	{    
		fread(&tri,1,sizeof(triangle_t),modelfile);   
		
		max_tex_u = max( max_tex_u, ttCor[tri.textureIndices[0]].s ); 
		max_tex_u = max( max_tex_u, ttCor[tri.textureIndices[1]].s ); 
		max_tex_u = max( max_tex_u, ttCor[tri.textureIndices[2]].s ); 
		max_tex_v = max( max_tex_v, ttCor[tri.textureIndices[0]].t );
		max_tex_v = max( max_tex_v, ttCor[tri.textureIndices[1]].t ); 
		max_tex_v = max( max_tex_v, ttCor[tri.textureIndices[2]].t );
	}
	
	for(i=0; i< md2header.num_frames;i++)
	{   
	    fseek(modelfile,md2header.ofs_frames+(i*md2header.framesize),0);
		out = (frame_t *)buffer;
		fread(out,1,md2header.framesize,modelfile);
		fseek(modelfile,md2header.ofs_tris,0);
		k=0;
		
		for( j=0; j<md2header.num_tris;j++)
		{   
			fread(&tri,1,sizeof(triangle_t),modelfile); 
			m_data[i].vtModel[k].x = out->vertices[tri.vertexIndices[2]].vertex[0] * out->scale[0]+out->translate[0];
			m_data[i].vtModel[k].z = out->vertices[tri.vertexIndices[2]].vertex[1] * out->scale[1]+out->translate[1];
			m_data[i].vtModel[k].y = out->vertices[tri.vertexIndices[2]].vertex[2] * out->scale[2]+out->translate[2];
			m_data[i].vtModel[k].color = color;
			m_data[i].vtModel[k].tu= ttCor[tri.textureIndices[2]].s / max_tex_u;
			m_data[i].vtModel[k].tv= ttCor[tri.textureIndices[2]].t / max_tex_v;
			++k;
			m_data[i].vtModel[k].x = out->vertices[tri.vertexIndices[1]].vertex[0] * out->scale[0]+out->translate[0];
			m_data[i].vtModel[k].z = out->vertices[tri.vertexIndices[1]].vertex[1] * out->scale[1]+out->translate[1];
			m_data[i].vtModel[k].y = out->vertices[tri.vertexIndices[1]].vertex[2] * out->scale[2]+out->translate[2];
			m_data[i].vtModel[k].color = color;
			m_data[i].vtModel[k].tu= ttCor[tri.textureIndices[1]].s / max_tex_u;
			m_data[i].vtModel[k].tv= ttCor[tri.textureIndices[1]].t / max_tex_v;
			++k;
			m_data[i].vtModel[k].x = out->vertices[tri.vertexIndices[0]].vertex[0] * out->scale[0]+out->translate[0];
			m_data[i].vtModel[k].z = out->vertices[tri.vertexIndices[0]].vertex[1] * out->scale[1]+out->translate[1];
			m_data[i].vtModel[k].y = out->vertices[tri.vertexIndices[0]].vertex[2] * out->scale[2]+out->translate[2];
			m_data[i].vtModel[k].color = color;
			m_data[i].vtModel[k].tu= ttCor[tri.textureIndices[0]].s / max_tex_u;
			m_data[i].vtModel[k].tv= ttCor[tri.textureIndices[0]].t / max_tex_v;
			++k;
			
			 
	
		}
	}

	//find bound of model
	for(i=0;i<k;i++)
	{
		maxX = max( maxX, m_data[0].vtModel[i].x ); 
		maxY = max( maxY, m_data[0].vtModel[i].y ); 
		maxZ = max( maxZ, m_data[0].vtModel[i].z ); 
		minX = min( minX, m_data[0].vtModel[i].x );
		minY = min( minY, m_data[0].vtModel[i].y ); 
		minZ = min( minZ, m_data[0].vtModel[i].z );
	}

	fclose(modelfile);
    m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ZENABLE, true);
	

	    
    m_Graphics->GetDeviceCOM()->SetRenderState (D3DRS_FILLMODE,D3DFILL_SOLID );
	m_Texture.Load(m_Graphics,texture);

		// Set the RGBA for diffuse reflection.
	mat.Diffuse.r = 1.0f;
	mat.Diffuse.g = 1.0f;
	mat.Diffuse.b = 1.0f;
	mat.Diffuse.a = 1.0f;

	// Set the RGBA for ambient reflection.
	mat.Ambient.r = 1.0f;
	mat.Ambient.g = 1.0f;
	mat.Ambient.b = 1.0f;
	mat.Ambient.a = 0.0f;

	// Set the color and sharpness of specular highlights.
	mat.Specular.r = 0.0f;
	mat.Specular.g = 0.0f;
	mat.Specular.b = 0.0f;
	mat.Specular.a = 0.0f;
	mat.Power = 50.0f;

	// Set the RGBA for emissive color.
	mat.Emissive.r = 0.0f;
	mat.Emissive.g = 0.0f;
	mat.Emissive.b = 0.0f;
	mat.Emissive.a = 0.0f;
	return true;
}
//===========================================
void  CModel::GetBound(float &mxX,float &mxY,float &mxZ,	\
						float &mnX,float &mnY,float &mnZ)
{
	mxX = maxX;  mnX = minX;
	mxY = maxY;	 mnY = minY;
	mxZ = maxZ;  mnZ = minZ;
}
//============ Release Interface ======

//=====================================
CModel::ReleaseVertex()
{
	if(pVB !=NULL)
		pVB->Release();

	m_Texture.Free();
	for(int i=0;i<=5;i++)
	if(pTexBox[i]!=NULL)
	{
		pTexBox[i]->Release();
		pTexBox[i] = NULL;
	}
	if(m_data!=NULL)
	delete[] m_data;
	
	pVB = NULL;
	m_data = NULL;
}
//=====================================
BOOL CModel::RenderModel(BOOL b,int Frame) 
{ 
	m_Graphics->GetDeviceCOM()->SetVertexShader(D3DFVF_VERTEX2);
	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);
	m_Graphics->GetDeviceCOM()->SetRenderState (D3DRS_ZENABLE ,D3DZB_USEW);
	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ZENABLE , true);
	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ZWRITEENABLE , true);
  //Draw
	
	
	m_Graphics->GetDeviceCOM()->SetMaterial(&mat);
	m_Graphics->SetTexture(0,&m_Texture);	
	 	
	HRESULT hr = m_Graphics->GetDeviceCOM()->DrawPrimitiveUP(D3DPT_TRIANGLELIST,               //Type
                                                   md2header.num_tris,              //Count
                                                   (BYTE**)&m_data[Frame].vtModel[0], //Pointer to data
                                                   sizeof(VERTEX2));             //Size vertex
									   
  	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ALPHABLENDENABLE,false);
  return (SUCCEEDED(hr));
}

/*	
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_MODULATE);
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_COLORARG2,D3DTA_CURRENT);
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_ALPHAARG1,D3DTA_DIFFUSE);
	m_Graphics->GetDeviceCOM()->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);

	m_Graphics->GetDeviceCOM()->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
	m_Graphics->GetDeviceCOM()->SetTextureStageState(1,D3DTSS_ALPHAOP,D3DTOP_DISABLE);
	
	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);
    m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
	
//	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_ONE);
//	m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_ONE);
   //This enables Alpha Blending
    m_Graphics->GetDeviceCOM()->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);
*/