#include "vector"
#include "string.h"
struct SAnimation
{
	//start and end of an animation
	int start, end;
	//Name
	std::string name;
	//current frame of the animation
	float cur;
	//increase =faster, decrease =slower animation
	float add;
};
struct Md3Headerformat
{
   char  ident[4];
   int  version;

   char name[68];  // model name

   //int  flags;

   int  numFrames;
   int  numTags;       
   int  numSurfaces;

   int  numSkins;

   int  ofsFrames;        // offset for first frame
   int  ofsTags;          // numFrames * numTags
   int  ofsSurfaces;      // first surface, others follow

   int  ofsEnd;           // end of fil

};

typedef struct
{
	float x,y,z;
} vector3 ;

typedef struct
{
	vector3 min_bound;
	vector3 max_bound;
	vector3 local_original;
	float radius;
	char strName[64];
} frame_Md3 ; 

typedef struct
{
	char strName[64];
	vector3 origin;
	float axis[3][3];
} tag_Md3;

typedef struct
{
	char ident[4] ;
	char name[68];
	int  num_frame;
	int  num_shader;
	int  num_vert;
	int  num_tri;
	int  ofs_tri;
	int  headerSize;
	int  ofs_uv;
	int  ofs_vertex;
	int  surfaceSize;
} surface_Md3;

typedef struct
{
	int vertexIndex[3];
} triangle_Md3;

typedef struct
{
	float s,t ;
} textureCo_Md3;

typedef struct
{
	signed short vertex[3];
	unsigned char normal[2];
} vertex_Md3 ;
//========================
struct Md2Headerformat
{      
	  int ident;
	  int version;

	  int skinwidth;			//Width and height of frame
	  int skinheight;			//Should be dividable by 8

	  int framesize;

	  int num_skins;			//Number of skintextures
	  int num_xyz;			
	  int num_st;
	  int num_tris;				//Count of triangles
	  int num_glcmds;
	  int num_frames;			//Count of fames

	//Some file offsets
	  int ofs_skins;
	  int ofs_st;
	  int ofs_tris;
	  int ofs_frames;
	  int ofs_glcmds; 
	  int ofs_end;
};

typedef struct
{
   byte vertex[3];
   byte lightNormalIndex;
} triangleVertex_t;

typedef struct
{
   float scale[3];
   float translate[3];
   char name[16];
   triangleVertex_t vertices[1];
} frame_t;

typedef struct
{
   short vertexIndices[3];
   short textureIndices[3];
} triangle_t;

typedef struct
{
  short s, t;
} textureCoordinate_t;

