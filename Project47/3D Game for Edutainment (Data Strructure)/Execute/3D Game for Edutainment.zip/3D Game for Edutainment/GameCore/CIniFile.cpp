#include "CIniFile.h"
bool CIniFile::find_label(FILE *stream,char *cmpstr,char stlab,char elab)
{char c[1];int i;bool founded=false;
				//find[
				while(c[0]!=stlab&&!feof(stream))
				{
					fread(c,sizeof(char),1,stream);
				}
				i=-1;//find ] for end read
				do
				{	
					fread(c,sizeof(char),1,stream);
					i++;
				}while(c[0]!=elab&&cmpstr[i]==c[0]&&!feof(stream));
			    if(c[0]==elab&&i==(int)strlen(cmpstr)){founded=true;}//find real else find new '[' don't care ']'
							return founded;
}
//private:
bool CIniFile::find_sublabel(FILE *stream,char *cmpstr,char lab,char elab)//comparestring &new more priority label&end sublabel
{char c[1];int i;bool founded=false;//lab is '[' more priority label
		
		  while(founded==false&&c[0]!='['&&!feof(stream))//search until find '[' or end of file
		  {i=0;
			while(c[0]!=10&&c[0]!=lab&&!feof(stream))//find end line
			{
					fread(c,sizeof(char),1,stream);
			}
			while(c[0]==10&&c[0]!=lab&&!feof(stream))//find first name
			{
					fread(c,sizeof(char),1,stream);
			}
			while(c[0]!=elab&&cmpstr[i]==c[0]&&c[0]!=lab&&!feof(stream))//compare name until end sublabel
			{
				fread(c,sizeof(char),1,stream);
				i++;
			}
				if(c[0]==elab&&i==(int)strlen(cmpstr)){founded=true;}
		  }
				return founded;
}
void CIniFile::cpy_str_from_file(char *cpystr,FILE *stream)
{char c[1];int i;
			//get string to animation name
			i=0;
			
			while(c[0]!=10&&!feof(stream))
			{	
			fread(c,sizeof(char),1,stream);
			if(c[0]!=10&&!feof(stream)){
			cpystr[i]=c[0];
			i++;}
			}
			//cout<<strlen(cpystr)<<"\n";
			cpystr[i]=0;
	
}
//public:
CIniFile::~CIniFile()
{
	 delete [] m_filename ;
}
void CIniFile::SetFileName(char* file)
{int num;
	  num=strlen(file);
	  m_filename = new char [num+1];
	  for(int i=0;i<(int)strlen(file);i++)
	  m_filename[i]=file[i];
	  m_filename[i]=0;
}
		//state 0 find label //state 1 find name = //state2 get value
bool CIniFile::GetStringValue(char* ani_name,char* main_name,char* name)
{
		FILE *stream;
		char c[1];
		bool founded=false;
		//non fseek because find label state 0
		stream=fopen(m_filename,"r");
		if(stream!=NULL)
		{   c[0]=NULL;
			while(!feof(stream)&&founded==false)//if(can't founded find until be founded)
			{
			founded = find_label(stream,main_name,'[',']');
			}//state0

		if(founded)//state 1
		{	
			founded=false;

			founded=find_sublabel(stream,name,'[','=');

		  if(founded)//state2
		  {		  

		  cpy_str_from_file(ani_name,stream);
		  }else{/*cout<<"not founded in state 1";*/}
		}else{/*cout<<"not founded in state 0";*/}
	  fclose(stream);//end state 0
	 } 	
	  else
	 {
	 /*cout<<"error for open \n";*/
	 }
	  return founded;
}	
bool CIniFile::GetIntValue(int &value,char* main_name,char* name)
{FILE *stream;char strvalue[3];
		char c[1];
		bool founded=false;
		//non fseek because find label state 0
		stream=fopen(m_filename,"r");
		if(stream!=NULL)
		{   c[0]=NULL;
			while(!feof(stream)&&founded==false)//if(can't founded find until be founded)
			{
			founded = find_label(stream,main_name,'[',']');
			}//state0

		if(founded)//state 1
		{	
			founded=false;

			founded=find_sublabel(stream,name,'[','=');

		  if(founded)//state2
		  {	
		  cpy_str_from_file(strvalue,stream);
		  value = atoi(strvalue);
		  }else{/*cout<<"not founded in state 1";*/}
		}else{/*cout<<"not founded in state 0";*/}
	  fclose(stream);//end state 0
	 } 	
	  else
	 {
	 /*cout<<"error for open \n";*/
	 }
	  return founded;
}