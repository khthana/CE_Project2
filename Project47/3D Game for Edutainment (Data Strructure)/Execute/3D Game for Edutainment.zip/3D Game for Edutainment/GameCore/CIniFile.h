
#ifndef _CINIFILE_H_
#define	_CINIFILE_H_

//#include<iostream.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
class CIniFile
{private:
	char *m_filename;
protected:
	bool find_label(FILE *stream,char *cmpstr,char stlab,char elab);//comparestring &start label&end label
	
private:
	bool find_sublabel(FILE *stream,char *cmpstr,char lab,char elab);//comparestring &new more priority label&end sublabel
	
	void cpy_str_from_file(char *cpystr,FILE *stream);
	
public:
	~CIniFile();
	
	void SetFileName(char* file);
	
	bool GetStringValue(char* ani_name,char* main_name,char* name);
		
	bool GetIntValue(int &value,char* main_name,char* name);
	
};

#endif