#ifndef _MD2TOOL_H_
#define _MD2TOOL_H_

#ifndef _CORE_GLOBAL_H_
#include "Core_Global.h"
#endif

#ifndef _MODELVERTEX_H_
#include "ModelVertex.h"
#endif

#ifndef  _CINIFILE_H_
#include "CIniFile.h"
#endif

class cMD2_tool
{
  protected:
    cGraphics     *m_Graphics;
    cWorldPosition m_Pos;
	CModel m_MD2;
	int m_curanim;
	CIniFile m_fileAnimation;


  public:
	 //Look @comments for SAnimation
	//Must be filled externally (see GameInit in main.cpp)
	std::vector <SAnimation> m_anim;

	  cMD2_tool();
    ~cMD2_tool();

    BOOL LoadModelMd2(cGraphics *Graphics,char *filename,char* texture);
	VOID SetFileAnimation(char *filename);
	BOOL LoadAnimation(char *animationname);

    BOOL Free();

    BOOL Move(FLOAT XPos, FLOAT YPos, FLOAT ZPos);
    BOOL MoveRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd);

    BOOL Rotate(FLOAT XRot, FLOAT YRot, FLOAT ZRot);
    BOOL RotateRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd);

    BOOL Scale(FLOAT XScale, FLOAT YScale, FLOAT ZScale);
    BOOL ScaleRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd);

    D3DXMATRIX *GetMatrix();

    FLOAT GetXPos();
    FLOAT GetYPos();
    FLOAT GetZPos();
    FLOAT GetXRotation();
    FLOAT GetYRotation();
    FLOAT GetZRotation();
    FLOAT GetXScale();
    FLOAT GetYScale();
    FLOAT GetZScale();

    void  GetBound(FLOAT &maxX,FLOAT &maxY,FLOAT &maxZ,	
				  FLOAT &minX,FLOAT &minY,FLOAT &minZ);

    BOOL Update();
	BOOL UpdateModel(BOOL b,char *name);
    BOOL RenderModel(BOOL B,int frame);
	BOOL RenderModel(BOOL b);
};
#endif