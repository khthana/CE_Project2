#ifndef _MODELVERTEX_H_
#define _MODELVERTEX_H_

#include "Core_Global.h"
#include "ModelFormat.h"

const int MAX_FRAMES=200;
const int MAX_VERTEX=2400;
const DWORD color=0x7FFFFFFF;     //ARGB 

	struct VERTEX
	{
		FLOAT x,y,z,rhw;
		DWORD color;
		FLOAT tu,tv;
	};
    #define D3DFVF_VERTEX (D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1)
	struct VERTEX2
	{
		FLOAT x, y, z;
		DWORD color;
		FLOAT tu, tv;
	};
	#define D3DFVF_VERTEX2 (D3DFVF_XYZ |D3DFVF_DIFFUSE|D3DFVF_TEX1)
	
	struct VERTEX3
	{
		FLOAT x,y,z;
		DWORD color;
		FLOAT tu1,tv1;
		FLOAT tu2,tv2;
	};
	#define D3DFVF_VERTEX3 (D3DFVF_XYZ |D3DFVF_DIFFUSE|D3DFVF_TEX3)
class CModel 
{
protected:
	cGraphics *m_Graphics;
	cTexture m_Texture;

	IDirect3DTexture8*  pTexBox[6]   ;
	IDirect3DVertexBuffer8* pVB;
	D3DLIGHT8 d3dLight;
	D3DMATERIAL8 mat;
	typedef char TextureName;
	
	Md2Headerformat md2header;
	int numFrame;
	int numVertex;
	frame_t *out;
	triangle_t tri;
	textureCoordinate_t ttCor[MAX_VERTEX];
	float maxX,maxY,maxZ,minX,minY,minZ;
		
	//Struct for MD2 Model keep all vertex
	struct SMesh
	{
	    unsigned long numVertex;
		VERTEX2 vtModel[MAX_VERTEX]; 
	};
	
	 SMesh  *m_data; 
	
public:   
	CModel(){ 
		m_data = NULL; maxX=maxY=maxZ=minX=minY=minZ=0;
		pVB = NULL;
		for(int i=0;i<6;i++)
			pTexBox[i]=NULL;
	}
	~CModel()
	{ 
		ReleaseVertex();
	}
	BOOL CreateVertexBuffer(VERTEX2*,long);
	BOOL CreateSkybox(cGraphics *pGraph);
	BOOL RenderModel(BOOL b,int Frame=0);
	void RenderSkyBox();
	BOOL LoadModelMd2(cGraphics *pGraph,char* filename,char* texture);
	virtual void LoadModelMd3(LPSTR pathname,LPSTR filename){};
	VERTEX2* GetPointFVF(){return m_data[0].vtModel;}
	unsigned long GetNumVertices(){ 
		if(m_data!=NULL)return m_data[0].numVertex;
			else return 0;}
	long GetFVF(){return D3DFVF_VERTEX2;}
	void SetFrame(char* name,int offset=0);
	void GetBound(float &maxX,float &maxY,float &maxZ,	\
				  float &minX,float &minY,float &minZ);
		ReleaseVertex();

		 
};

#endif