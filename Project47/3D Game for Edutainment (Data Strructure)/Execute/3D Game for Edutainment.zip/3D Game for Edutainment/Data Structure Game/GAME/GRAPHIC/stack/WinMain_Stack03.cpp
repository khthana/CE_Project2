/**************************************************
WinMain.cpp
Chapter 12 NodeTree Demo

Programming Role-Playing Games with DirectX
by Jim Adams (01 Jan 2002)

Required libraries:
  D3D8.LIB, D3DX8.LIB, and DINPUT8.LIB
**************************************************/

#include "Core_Global.h"
#include "Frustum.h"
#include "NodeTree.h"
#include "SkyBox.h"
#include "ModelVertex.h"
#include "cMD2_Obj.h"
#include "camera.h"
#include <time.h>
#include "Window.h"

//Stack

class cApp : public cApplication
{
  private:
    cGraphics       m_Graphics;
    cCamera_obj     m_Camera;
    cLight          m_Light;

    cSound          m_Sound;
    cSoundData      m_SndData;
    cSoundChannel   m_SndChannel[3];

    cSkyBox         m_SkyBox;

    cInput          m_Input;
    cInputDevice    m_Keyboard;
    cInputDevice    m_Mouse;

    cMesh           m_Mesh;
    cNodeTreeMesh   m_NodeTreeMesh;
	cMD2_Obj		MD2;
	cMD2_Obj		plate;
	cMD2_Obj		boxs[24];
    float           m_XPos, m_YPos, m_ZPos;
	cWindow			m_Window;
	cFont			m_Font;


  public:
    cApp();

    BOOL Init();
    BOOL Shutdown();
    BOOL Frame();
	BOOL Move_Box();
	BOOL Move_Stack(int plate_p);
	BOOL Randomize();
	BOOL RandomBoxColor24();
	BOOL ReQueueBox();
	BOOL MoveTmp();
	BOOL KeepToTmp(int line_py);
	BOOL ChkSen2();
	float	line_p[3],line_x[7],line_y[4],line_z;
	int		p_box[7][4],p_stack[3],b_color[27],b_tmp[15];
	char	*sentence,*sentence2,text_time[20],*rank;
	int		end_count,s_time,t_time,start;
};

cApp::cApp()
{
	m_Width  = 640; //1024;
	m_Height = 480;//768;
	m_Style  = /*WS_BORDER | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU |*/ WS_POPUP   ;
	strcpy(m_Class, "3D EDUTAINMENT");
	strcpy(m_Caption, "Stack");
}

BOOL cApp::Init()
{
	short i;

	sentence= "Stack : Size = 3";
	sentence2="Number : 0/3 , Empty Stack.";
	rank=" ";
	strcpy(&text_time[0]," ");
	s_time=time(0);
	t_time=100;
	start=0;

	end_count=0;

	p_box[0][0] = 0;
	p_box[0][1] = 1;
	p_box[0][2] = 2;
	p_box[0][3] = 3;
	p_box[1][0] = 4;
	p_box[1][1] = 5;
	p_box[1][2] = 6;
	p_box[1][3] = 7;
	p_box[2][0] = 8;
	p_box[2][1] = 9;
	p_box[2][2] = 10;
	p_box[2][3] = 11;
	p_box[3][0] = 100;	//100 = no box here
	p_box[3][1] = 100;
	p_box[3][2] = 100;
	p_box[3][3] = 100;
	p_box[4][0] = 100;
	p_box[4][1] = 100;
	p_box[4][2] = 100;
	p_box[4][3] = 100;	
	p_box[5][0] = 100;
	p_box[5][1] = 100;
	p_box[5][2] = 100;
	p_box[5][3] = 100;
	p_box[6][0] = 100;
	p_box[6][1] = 100;
	p_box[6][2] = 100;
	p_box[6][3] = 100;

	b_tmp[0]=12;
	b_tmp[1]=13;
	b_tmp[2]=14;
	b_tmp[3]=15;
	b_tmp[4]=16;
	b_tmp[5]=17;
	b_tmp[6]=18;
	b_tmp[7]=19;
	b_tmp[8]=20;
	b_tmp[9]=21;
	b_tmp[10]=22;
	b_tmp[11]=23;
	b_tmp[12]=100;
	b_tmp[13]=100;
	b_tmp[14]=100;

	p_stack[0] = 100;
	p_stack[1] = 100;
	p_stack[2] = 100;

	// Initialize the graphics device and set display mode
	m_Graphics.Init();
	m_Graphics.SetMode(GethWnd(),FALSE, TRUE);
	m_Graphics.SetPerspective(D3DX_PI/4, 1.3333f, 1.0f, 20000.0f);
	ShowMouse(FALSE);

	// Enable lighting and setup light
	m_Graphics.EnableLighting(TRUE);
	m_Graphics.SetAmbientLight(48,48,48);
	m_Graphics.EnableLight(0, TRUE);
	m_Light.SetAttenuation0(0.5f);
	m_Light.SetRange(10000.0f);

	// Initialize input and input devices
	m_Input.Init(GethWnd(), GethInst());
	m_Keyboard.Create(&m_Input, KEYBOARD);
	m_Mouse.Create(&m_Input, MOUSE, TRUE);

	// Load the mesh and create an NodeTree mesh from it
	m_Mesh.Load(&m_Graphics, "GRAPHIC\\stack\\stack.x", "GRAPHIC\\stack\\");
	m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);

	// Position view at origin
	m_XPos = m_YPos = m_ZPos = 0.0f;

	// Setup the sky box
	m_SkyBox.Create(&m_Graphics);
	//BENZ MD2 obj
	MD2.SetComponent(&m_NodeTreeMesh);
	m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
	MD2.Move(700.0f,500,0);
	MD2.Scale(0.1f,0.1f,0.1f);

	line_p[0]=120.0f;
	line_p[1]=180.0f;
	line_p[2]=240.0f;

	line_x[0]=-300.0f;
	line_x[1]=-200.0f;
	line_x[2]=-100.0f;
	line_x[3]=   0.0f;
	line_x[4]= 100.0f;
	line_x[5]= 200.0f;
	line_x[6]= 300.0f;

	line_y[0]=-200.0f;
	line_y[1]=-130.0f;
	line_y[2]= -60.0f;
	line_y[3]=  10.0f;

	line_z=10.0f;
	
	
	plate.SetComponent(&m_NodeTreeMesh);
	plate.Move(line_p[1],  0,0.0f);
//-200,-300 -200 -100 0 100 200 -200,+300
//-130,-300                     -130,+300
// -60,-300                      -60,+300
//  10,-300                       10,+300
	for(i=0;i<24;i++)
	{
		boxs[i].SetComponent(&m_NodeTreeMesh);
		boxs[i].SetFileAnimation("graphic\\knight\\tris.ini");
		boxs[i].LoadAnimation("stand");
	}

	Move_Box();
	MoveTmp();
	//BENZ MD2 animation
	MD2.SetFileAnimation("graphic\\knight\\tris.ini");
	plate.SetFileAnimation("graphic\\knight\\tris.ini");

	MD2.LoadAnimation("stand");
	plate.LoadAnimation("stand");
	/*benz code*/
	char *sky[6];
	sky[0] =	"..\\data//sky//hill//EnvYPos.bmp";
	sky[1] =	"..\\data//sky//hill//EnvYNeg.bmp";
	sky[2] =	"..\\data//sky//hill//EnvXNeg.bmp";
	sky[3] =	"..\\data//sky//hill//EnvXPos.bmp";
	sky[4] =	"..\\data//sky//hill//EnvZPos.bmp";
	sky[5] =	"..\\data//sky//hill//EnvZNeg.bmp";

	MD2.LoadModelMd2(&m_Graphics,"GRAPHIC//knight//tris.md2","GRAPHIC//knight//black.bmp");
	plate.LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box210909.md2","GRAPHIC//stack//plate.jpg");

	Randomize();
	RandomBoxColor24();

	/*benz code*/
	for(i=0;i<6;i++)
	m_SkyBox.LoadTexture(i, sky[i]);

	m_Camera.Zoom(300);

	m_Font.Create(&m_Graphics,"Arial",35,TRUE);
	m_Window.Create(&m_Graphics,&m_Font);

	return TRUE;
}

BOOL cApp::Shutdown()
{
	// Free sounds
	for(short i=0;i<3;i++)
	m_SndChannel[i].Free();
	m_SndData.Free();
	m_Sound.Shutdown();
	// Free meshes
	m_NodeTreeMesh.Free();
	m_Mesh.Free();

	// Shutdown input
	m_Mouse.Free();
	m_Keyboard.Free();
	m_Input.Shutdown();

	// Shutdown graphics
	m_Graphics.Shutdown();
	MD2.Free();
	plate.Free();
	boxs[0].Free();
	boxs[1].Free();
	boxs[2].Free();
	boxs[3].Free();
	boxs[4].Free();
	boxs[5].Free();
	boxs[6].Free();
	boxs[7].Free();
	boxs[8].Free();
	boxs[9].Free();
	boxs[10].Free();
	boxs[11].Free();
	boxs[12].Free();
	boxs[13].Free();
	boxs[14].Free();	
	boxs[15].Free();
	boxs[16].Free();
	boxs[17].Free();
	boxs[18].Free();
	boxs[19].Free();
	boxs[20].Free();
	boxs[21].Free();
	boxs[22].Free();
	boxs[23].Free();

	m_Window.Free();
	m_Font.Free();
	return TRUE;
}

BOOL cApp::Move_Box()
{
	for(int ly=0;ly<=3;ly++)
	{
		for(int lx=0;lx<=6;lx++)
		{
			if(p_box[lx][ly]!=100)
				boxs[p_box[lx][ly]].Move(line_y[ly],  line_z,line_x[lx]);
		}
	}
	return TRUE;
}

BOOL cApp::Move_Stack(int plate_p)
{
	plate.Move(line_p[1],  0,line_x[plate_p]);
	for(int lp=0;lp<=2;lp++)
	{
		if(p_stack[lp]!=100)
			boxs[p_stack[lp]].Move(line_p[lp],  line_z,line_x[plate_p]);
	}
	return TRUE;
}

BOOL cApp::Randomize()
{
	int seed;
	seed = (unsigned)time(0);
	srand(seed);
	return TRUE;
}

BOOL cApp::RandomBoxColor24()
{
	int color[24];
	int pos=rand()%24;
	short i;
	int color_set;
	for(i=0;i<24;i++)color[i]=0;

	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=1;
	}
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=2;
	}
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=3;
	}
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=4;
	}

	color_set=(rand()%4) +1;
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=color_set;
	}

	color_set=(rand()%4) +1;
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=color_set;
	}

	for(i=0;i<24;i++)
	{
		switch (color[i])
		{
			case 1 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab1.jpg");
						b_color[i]=3;break;
			case 2 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab2.jpg");
						b_color[i]=4;break;
			case 3 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab3.jpg");
						b_color[i]=5;break;
			case 4 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab4.jpg");
						b_color[i]=6;break;
		}
	}

	return TRUE;
}

BOOL cApp::ReQueueBox()
{
	for(int box_loop=0;box_loop<=13;box_loop++)
	{
		b_tmp[box_loop]=b_tmp[box_loop+1];
	}
	b_tmp[14]=100;
	return TRUE;
}

BOOL cApp::MoveTmp()
{
	for(int tmp_loop=0;tmp_loop<=14;tmp_loop++)
	{
		boxs[b_tmp[tmp_loop]].Move(-300.0f,  line_z,300.0f);
	}

	return TRUE;
}

BOOL cApp::KeepToTmp(int line_py)
{
	end_count++;
	boxs[p_box[line_py][0]].Move(-300.0f,  line_z,300.0f);
	boxs[p_box[line_py][1]].Move(-300.0f,  line_z,300.0f);
	boxs[p_box[line_py][2]].Move(-300.0f,  line_z,300.0f);
	boxs[p_box[line_py][3]].Move(-300.0f,  line_z,300.0f);
	return TRUE;
}

BOOL cApp::ChkSen2()
{
	sentence2="Number : 0/3 , Empty Stack.";
	if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100)
	{
		sentence2="Number : 1/3";
	}
	if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100)
	{
		sentence2="Number : 2/3";
	}
	if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100)
	{
		sentence2="Number : 3/3 , Full Stack.";
	}
	return TRUE;
}

BOOL cApp::Frame()
{
	static DWORD  Timer = timeGetTime();
	unsigned long Elapsed=0;

	D3DXVECTOR2   vecDir;
	cFrustum      Frustum,Frustum2;
	cLight        Light;
	char* play=NULL;
	static int moving=0;
//	static long s_time = time(0),f_time = time(0);
	static int change=10,set_camera=1,plate_p=3;
	char num_time[10];

	// Reacquire input
	m_Mouse.Acquire(TRUE);
	// Calculate elapsed time (plus speed boost)
	Elapsed = (timeGetTime() - Timer);//delay 30 milisec
	Timer = timeGetTime();
	// Get input
	m_Keyboard.Read();
	//  m_Mouse.Read();

	// Process input and update everything.
	// ESC quits program
	if(m_Keyboard.GetKeyState(KEY_ESC) == TRUE)
		return FALSE;

	int speed=5;

	if(change>0)
	{
		Sleep(200);
	}

	if(end_count==6)
	{
//		sentence="Finish!!";
		sentence2="Finish!!";
		end_count=0;
		change=2;
		start=3;
	}

//***** check stack line is full?
	if(p_box[3][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(3);
		p_box[3][0] = 100;
		p_box[3][1] = 100;
		p_box[3][2] = 100;
		p_box[3][3] = 100;
		change=4;
		MoveTmp();
	}
	if(p_box[4][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(4);
		p_box[4][0] = 100;
		p_box[4][1] = 100;
		p_box[4][2] = 100;
		p_box[4][3] = 100;
		change=4;
		MoveTmp();
	}
	if(p_box[5][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(5);
		p_box[5][0] = 100;
		p_box[5][1] = 100;
		p_box[5][2] = 100;
		p_box[5][3] = 100;
		change=4;
		MoveTmp();
	}
	if(p_box[6][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(6);
		p_box[6][0] = 100;
		p_box[6][1] = 100;
		p_box[6][2] = 100;
		p_box[6][3] = 100;
		change=4;
		MoveTmp();
	}
	if(change==3)
	{
		Move_Box();
		Move_Stack(plate_p);
		change=1;
	}
//******************************************* begin move
	// Left
	if(moving==1)
	{
		if(change==0)
		{
			if(plate_p>0)plate_p--;
			Move_Stack(plate_p);
			change=2;
			moving=0;
			if(start==0)start=1;
		}
	}
	// Right
	if(moving==2)
	{
		if(change==0)
		{
			if(plate_p<6)
			{
				plate_p++;
				Move_Stack(plate_p);
			}
			change=2;
			moving=0;
			if(start==0)start=1;
		}
	}
	// POP Up
	if(moving==3)
	{
		if(change==0)
		{
			if(start==0)start=1;
			sentence="Stack : Can't POP here!";
			if(plate_p>=3&&plate_p<=6)
			{
				sentence="Stack : Can't POP!";
				if(p_box[plate_p][0]==100&&p_box[plate_p][1]==100&&p_box[plate_p][2]==100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][0]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][0]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][0]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
				else if(p_box[plate_p][0]!=100&&p_box[plate_p][1]==100&&p_box[plate_p][2]==100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][1]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][1]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][1]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
				else if(p_box[plate_p][0]!=100&&p_box[plate_p][1]!=100&&p_box[plate_p][2]==100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][2]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][2]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][2]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
				else if(p_box[plate_p][0]!=100&&p_box[plate_p][1]!=100&&p_box[plate_p][2]!=100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][3]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][3]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][3]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
			}
			if(change==1)
			{
				sentence="Stack : POP!";
				change++;
			}
		}
	}
	// PUSH Down
	if(moving==4)
	{
		if(change==0)
		{
			if(start==0)start=1;
			sentence= "Stack : Can't PUSH here!";
			if(plate_p>=0&&plate_p<=2)
			{
				sentence= "Stack : Can't PUSH!";
				if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100)
				{
					p_stack[0] = p_box[plate_p][3];
					p_box[plate_p][3] = p_box[plate_p][2];
					p_box[plate_p][2] = p_box[plate_p][1];
					p_box[plate_p][1] = p_box[plate_p][0];
					p_box[plate_p][0] = b_tmp[0];
					ReQueueBox();
					// and relist of queue
					Move_Box();
					MoveTmp();
					Move_Stack(plate_p);
					moving=0;
					change=1;
				}
				if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100)
				{
					p_stack[1] = p_box[plate_p][3];
					p_box[plate_p][3] = p_box[plate_p][2];
					p_box[plate_p][2] = p_box[plate_p][1];
					p_box[plate_p][1] = p_box[plate_p][0];
					p_box[plate_p][0] = b_tmp[0];
					ReQueueBox();
					// and relist of queue
					Move_Box();
					MoveTmp();
					Move_Stack(plate_p);
					moving=0;
					change=1;
				}
				if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]==100)
				{
					p_stack[2] = p_box[plate_p][3];
					p_box[plate_p][3] = p_box[plate_p][2];
					p_box[plate_p][2] = p_box[plate_p][1];
					p_box[plate_p][1] = p_box[plate_p][0];
					p_box[plate_p][0] = b_tmp[0];
					ReQueueBox();
					// and relist of queue
					Move_Box();
					MoveTmp();
					Move_Stack(plate_p);
					moving=0;
					change=1;
				}
				if(change==1)
				{
					sentence= "Stack : PUSH!";
					change++;
				}
			}
		}
	}


//******************************************* end move
//***** Key Input Check start*****//


	if(m_Keyboard.GetKeyState(KEY_LEFT) == TRUE)
	{
		if(change==0)
		{
			moving=1;
			change=1;
		}
	}
	if(m_Keyboard.GetKeyState(KEY_RIGHT) == TRUE)
	{
		if(change==0)
		{
			moving=2;
			change=1;
		}
	}
	if(m_Keyboard.GetKeyState(KEY_UP) == TRUE)
	{
		if(change==0)
		{
			moving=3;
			change=1;
		}
	}
	if(m_Keyboard.GetKeyState(KEY_DOWN) == TRUE)
	{
		if(change==0)
		{
			moving=4;
			change=1;
		}
	}

	ChkSen2();
	//***** Key Input Check end*****//

	if(start==1)	// set time!
	{
		start=2;
		s_time=time(0);
	}
	if(start==2)	// show time!
	{
		//t_time-(time(0)-s_time)
		strcpy(&text_time[0],"Time : ");
		_itoa((t_time-(time(0)-s_time)),num_time,10);
		strcat(&text_time[0],num_time);
		change=1;
	}

	if((t_time-(time(0)-s_time)<=0)||start==3)	//FINISH
	{
		strcpy(&text_time[0],"Time : ");
		_itoa((t_time-(time(0)-s_time)),num_time,10);
		strcat(&text_time[0],num_time);
		sentence2="Finish!!";
		rank="Very Good!!!!";
		if(t_time-(time(0)-s_time)<=60)
			rank="Good.";
		if(t_time-(time(0)-s_time)<=40)
			rank="Slow.";
		if(t_time-(time(0)-s_time)<=20)
			rank="Very Slow.";
		if(t_time-(time(0)-s_time)<=0)
			rank="Try Again.";
	}


	BOOL bfootonEarth=FALSE;
	MD2.CheckEarthMoveMent(Elapsed,&bfootonEarth);
	BOOL bfootonObj=FALSE;
	MD2.UpdateMoveMent();
	plate.UpdateMoveMent();
	for(int loop_b=0;loop_b<24;loop_b++)
	{
		boxs[loop_b].UpdateMoveMent();
		boxs[loop_b].UpdateModel( TRUE,"stand",Elapsed);
	}
	//key controll

	plate.UpdateModel( TRUE,"stand",Elapsed);

		m_XPos=MD2.GetXPos();
		m_YPos=MD2.GetYPos();
		m_ZPos=MD2.GetZPos();




	bool bmode=true;
	float dmouseX,dmouseY;
	dmouseX=dmouseY=0;
	dmouseX=(float)m_Mouse.GetXDelta();
	dmouseY=(float)m_Mouse.GetYDelta();

	//camera 3 RD
	if(set_camera==1)
	{
		m_Camera.Camera_Obj(Elapsed,dmouseX,150,bmode);
		set_camera=0;
	}

  // Position light
	m_Light.Move(0,200.0f, 0);
	m_Graphics.SetLight(0, &m_Light);

	// Set camera and calculate frustum
	m_Graphics.SetCamera(&m_Camera);
	Frustum.Construct(&m_Graphics,0);
	Frustum2.Construct(&m_Graphics,1000);

	if(change>0)
	{
		// Render everything
		m_Graphics.ClearZBuffer(1.0f);
		play = "stand";
		if(m_Graphics.BeginScene() == TRUE)
		{
			m_Graphics.EnableZBuffer(FALSE);
			m_Graphics.EnableLighting(FALSE);
			m_SkyBox.Render(&m_Camera);
			m_Graphics.EnableZBuffer(TRUE);
			m_Graphics.EnableLighting(TRUE);
			m_NodeTreeMesh.Render(&Frustum);
			MD2.Rotate(0,m_Camera.GetYRotation(),0);
			if(!(bmode||m_Camera.GetZoom()<=65))MD2.RenderModel(FALSE);
		}
		if(Frustum2.CheckSphere(plate.GetXPos(),plate.GetYPos(),plate.GetZPos(),plate.m_XYZRadius))
			plate.RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[0].GetXPos(),boxs[0].GetYPos(),boxs[0].GetZPos(),boxs[0].m_XYZRadius))
			boxs[0].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[1].GetXPos(),boxs[1].GetYPos(),boxs[1].GetZPos(),boxs[1].m_XYZRadius))
			boxs[1].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[2].GetXPos(),boxs[2].GetYPos(),boxs[2].GetZPos(),boxs[2].m_XYZRadius))
			boxs[2].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[3].GetXPos(),boxs[3].GetYPos(),boxs[3].GetZPos(),boxs[3].m_XYZRadius))
			boxs[3].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[4].GetXPos(),boxs[4].GetYPos(),boxs[4].GetZPos(),boxs[4].m_XYZRadius))
			boxs[4].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[5].GetXPos(),boxs[5].GetYPos(),boxs[5].GetZPos(),boxs[5].m_XYZRadius))
			boxs[5].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[6].GetXPos(),boxs[6].GetYPos(),boxs[6].GetZPos(),boxs[6].m_XYZRadius))
			boxs[6].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[7].GetXPos(),boxs[7].GetYPos(),boxs[7].GetZPos(),boxs[7].m_XYZRadius))
			boxs[7].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[8].GetXPos(),boxs[8].GetYPos(),boxs[8].GetZPos(),boxs[8].m_XYZRadius))
			boxs[8].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[9].GetXPos(),boxs[9].GetYPos(),boxs[9].GetZPos(),boxs[9].m_XYZRadius))
			boxs[9].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[10].GetXPos(),boxs[10].GetYPos(),boxs[10].GetZPos(),boxs[10].m_XYZRadius))
			boxs[10].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[11].GetXPos(),boxs[11].GetYPos(),boxs[11].GetZPos(),boxs[11].m_XYZRadius))
			boxs[11].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[12].GetXPos(),boxs[12].GetYPos(),boxs[12].GetZPos(),boxs[12].m_XYZRadius))
			boxs[12].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[13].GetXPos(),boxs[13].GetYPos(),boxs[13].GetZPos(),boxs[13].m_XYZRadius))
			boxs[13].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[14].GetXPos(),boxs[14].GetYPos(),boxs[14].GetZPos(),boxs[14].m_XYZRadius))
			boxs[14].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[15].GetXPos(),boxs[15].GetYPos(),boxs[15].GetZPos(),boxs[15].m_XYZRadius))
			boxs[15].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[16].GetXPos(),boxs[16].GetYPos(),boxs[16].GetZPos(),boxs[16].m_XYZRadius))
			boxs[16].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[17].GetXPos(),boxs[17].GetYPos(),boxs[17].GetZPos(),boxs[17].m_XYZRadius))
			boxs[17].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[18].GetXPos(),boxs[18].GetYPos(),boxs[18].GetZPos(),boxs[18].m_XYZRadius))
			boxs[18].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[19].GetXPos(),boxs[19].GetYPos(),boxs[19].GetZPos(),boxs[19].m_XYZRadius))
			boxs[19].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[20].GetXPos(),boxs[20].GetYPos(),boxs[20].GetZPos(),boxs[20].m_XYZRadius))
			boxs[20].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[21].GetXPos(),boxs[21].GetYPos(),boxs[21].GetZPos(),boxs[21].m_XYZRadius))
			boxs[21].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[22].GetXPos(),boxs[22].GetYPos(),boxs[22].GetZPos(),boxs[22].m_XYZRadius))
			boxs[22].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[23].GetXPos(),boxs[23].GetYPos(),boxs[23].GetZPos(),boxs[23].m_XYZRadius))
			boxs[23].RenderModel(TRUE);

	    m_Graphics.EndScene();
		m_Font.Print(sentence,200,600,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(sentence2,200,670,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(text_time,750,600,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(rank,750,670,0,0,D3DCOLOR_RGBA(255,0,0,255));
	
		m_Graphics.Display();
		change--;
	}
  return TRUE;
}

int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR szCmdLine, int nCmdShow)
{
  cApp App;
  return App.Run();
}


