/**************************************************
WinMain.cpp
Chapter 12 NodeTree Demo

Programming Role-Playing Games with DirectX
by Jim Adams (01 Jan 2002)

Required libraries:
  D3D8.LIB, D3DX8.LIB, and DINPUT8.LIB
**************************************************/

#include "Core_Global.h"
#include "Frustum.h"
#include "NodeTree.h"
#include "SkyBox.h"
#include "ModelVertex.h"
#include "cMD2_Obj.h"
#include "camera.h"
#include "Window.h"
#include<time.h>
#include<dos.h>

class linklistgame
{
private:
	int num_train,item_in,now_train;
	int time_up;
	int command;					//command is No. of item to pick up for find password

	int item[5][10];
	char door_pass[4];
	char user_pass[5];

	char Exit;
	int ttime;
	int starttime;
	int got_pass;
	int pass_door;

	void randomize();
	void convert_cond(char&,int);
	void convert_pass(int,char&,int);

public:

	//linklistgame();
	void init();
	bool checkgotpass(char*);
	int user_passcount();
	char* user_passget();
	void user_passset(char*);
	bool true_password();
	bool next_stage();
	bool set_starttime();
	int checktime();
};
//////////////////////////////////////////////////// 
void linklistgame::init()
{
	num_train = 5,item_in = 10;
	now_train = 0;
	time_up = 0;	

	Exit = 'N';
	ttime = 120;
	starttime = time(0);
	got_pass = 0;
	pass_door = 0;

	for(int i = 0;i < 5;i++)
		for(int j = 0;j < 10;j++)
			item[i][j] = 0;
	
	for(i = 0;i < 4;i++)
	{
		door_pass[i] = 0;
		user_pass[i] = 0;
	}

	/////////////////////////////
	//random item in train
	
	randomize();
	
	for(i = 0;i < 5;i++)
	{
		int pos_item = rand() % 10;
		item[i][pos_item] = rand() % 10000;
	}
}
/////////////////////////////////////
void linklistgame::convert_cond(char &door_pass,int length)
{
	for(int j = 0;j < length;j++)
	{
		if((*(&door_pass + j) == 0) || (*(&door_pass + j) == 'a'))
		{
			if(j != 0)
			{
				*(&door_pass + j) = *(&door_pass + j - 1);
				*(&door_pass + j - 1) = 'a';		
				convert_cond(door_pass,j);
			}
		}							
	}
}

/////////////////////////////////////
void linklistgame::convert_pass(int item,char &door_pass,int length)
{
	_itoa(item,&door_pass,10);
					
	if(item < 1000)
	{		
		convert_cond(door_pass,length);

		for(int k = 0;k < 4;k++)
		{		
			if(*(&door_pass + k) == 'a')*(&door_pass + k) ='0';						
		}
	}	

}
/////////////////////////////////////
void linklistgame::randomize()
{
	int seed;
	seed = (unsigned)time(0);
	srand(seed);
}
/////////////////////////////////////
bool linklistgame::checkgotpass(char *MSG)
{
	int boxnumber = 99;
	if(strcmp(MSG,"BOX 1") == 0)boxnumber = 0;
	if(strcmp(MSG,"BOX 2") == 0)boxnumber = 1;
	if(strcmp(MSG,"BOX 3") == 0)boxnumber = 2;
	if(strcmp(MSG,"BOX 4") == 0)boxnumber = 3;
	if(strcmp(MSG,"BOX 5") == 0)boxnumber = 4;
	if(strcmp(MSG,"BOX 6") == 0)boxnumber = 5;
	if(strcmp(MSG,"BOX 7") == 0)boxnumber = 6;
	if(strcmp(MSG,"BOX 8") == 0)boxnumber = 7;
	if(strcmp(MSG,"BOX 9") == 0)boxnumber = 8;
	if(strcmp(MSG,"BOX 0") == 0)boxnumber = 9;
	//if(boxnumber == 0){strcpy(MSG,"got box 1");return true;}
	if(boxnumber == 99)return false;

	if(item[now_train][boxnumber] != 0)
	{					
		got_pass = 1;

		for(int k = 0;k < 4;k++)
		{		
			door_pass[k] = 0;						
		}

		//change door password
		convert_pass(item[now_train][boxnumber],*door_pass,4);
					
		//item[now_train][boxnumber] = 0;

		//cout<<"door password is "<<door_pass<<endl;
		strcpy(MSG,"Password is ");
		strcat(MSG,door_pass);
		return true;
	}
	else
	{
		//cout<<"Not found"<<endl;
		strcpy(MSG,"Not found");
		return true;
	}
				
	return false;
}
//////////////////////////////////////////////////// 
int linklistgame::user_passcount()
{
	for(int i = 0;i < 5;i++)
	{
		if(user_pass[i] == NULL)break;
	}
	return i;
}
//////////////////////////////////////////////////// 
char* linklistgame::user_passget()
{	
	return &user_pass[0];
}
//////////////////////////////////////////////////// 
void linklistgame::user_passset(char *c_MMSG)
{
	strcpy(user_pass,c_MMSG);
}
//////////////////////////////////////////////////// 
bool linklistgame::set_starttime()
{
	starttime = time(0);
	return true;
}
//////////////////////////////////////////////////// 
bool linklistgame::true_password()
{
	pass_door = 1;

	for(int k = 0;k < 4;k++)
		if(user_pass[k] != door_pass[k])
				pass_door = 0;

	if(pass_door)
	{
		return true;
	}
	else
		return false;
}
//////////////////////////////////////////////////// 
bool linklistgame::next_stage()
{
	now_train++;
	if(now_train > 4)return true;	
	return false;
}
//////////////////////////////////////////////////// 
int linklistgame::checktime()
{	
	int presenttime = 0;
	
	presenttime = time(0);
	if((presenttime - starttime) >= ttime)
	{
		return(0);
	}
	else
	{
		//cout"time :: "<<(ttime - (presenttime - starttime))/60<<" : "<<((ttime - (presenttime - starttime))%60)<<endl;
		return(ttime - (presenttime - starttime));//return time left
	}	
}
//////////////////////////////////////////////////// 
//////////////////////////////////////////////////// 
class cApp : public cApplication
{
//////////////////////////////////////
  private:
    cGraphics       m_Graphics;
    cCamera_obj     m_Camera;
    cLight          m_Light;

    cSound          m_Sound;
    cSoundData      m_SndData;
    cSoundChannel   m_SndChannel[3];

    cSkyBox         m_SkyBox;

    cInput          m_Input;
    cInputDevice    m_Keyboard;
    cInputDevice    m_Mouse;

    cMesh           m_Mesh;
    cNodeTreeMesh   m_NodeTreeMesh;
	cMD2_Obj		MD2,box[10],door_lock;
	
	cWindow			m_Window;
	cFont			m_Font,m_input,m_showtime;


    float           m_XPos, m_YPos, m_ZPos;
	float			c_Lpos[3],c_Wpos[3];
	long			mouseX,mouseY;	
	linklistgame	game;
	int				pos_state;
	char			*sentense;
	char			*u_pass;
	char			password[20];
	char			tmp[20];
	char			move;
	bool			keyboard;
	/////////////////////////////////////	
	BOOL Delay(int);
	void getmousepos(char*);
	bool clickitem(char*);
	bool clickkeyboard(char*);
	void enterpass(char*);


  public:
    cApp();

    BOOL Init();
    BOOL Shutdown();
    BOOL Frame();
////////////////////////////////////////////////////
};

////////////////////////////////////////////////////
cApp::cApp()
{ 
  m_Width  = 640; //1024;
  m_Height = 480;//768;
  m_Style  = /*WS_BORDER | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU|*/WS_POPUP   ;
  strcpy(m_Class, "DATA STRUCTURE EDUTAINMENT");
  strcpy(m_Caption, "LINKEDLIST");

  /*init graphic before get adapter display*/
  m_Graphics.Init();
  D3DDISPLAYMODE d3ddm;
  m_Graphics.GetDirect3DCOM()->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);
  m_Height= d3ddm.Height;
  m_Width=  d3ddm.Width;
}
////////////////////////////////////////////////////

BOOL cApp::Init()
{
  short i;

  // Initialize the graphics device and set display mode
  //m_Graphics.Init();
  m_Graphics.SetMode(GethWnd(),TRUE, TRUE);
  m_Graphics.SetPerspective(D3DX_PI/4, 1.3333f, 1.0f, 20000.0f);
  ShowMouse(TRUE); 

  // Enable lighting and setup light
  m_Graphics.EnableLighting(TRUE);
  m_Graphics.SetAmbientLight(48,48,48);
  m_Graphics.EnableLight(0, TRUE);
  m_Light.SetAttenuation0(0.5f);
  m_Light.SetRange(1000.0f);

  // Initialize input and input devices
  m_Input.Init(GethWnd(), GethInst());
  m_Keyboard.Create(&m_Input, KEYBOARD);
  m_Mouse.Create(&m_Input, MOUSE, TRUE);  

  // Load the mesh and create an NodeTree mesh from it
  m_Mesh.Load(&m_Graphics,"GRAPHIC\\linklist\\train.x", "GRAPHIC\\linklist\\");
  m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);

  // Position view at origin
  m_XPos = m_YPos = m_ZPos = 0.0f;

  ///////////////////////////////////////
  c_Lpos[0] = 640.0f;
  c_Wpos[0] = 0.0f;
  c_Lpos[1] = 200.0f;
  c_Wpos[1] = 0.0f;
  c_Lpos[2] = -220.0f;
  c_Wpos[2] = 0.0f;
  pos_state = 0;
  mouseX=mouseY = 0;
  strcpy(password,"");
  keyboard = false;
  u_pass = "";
  ///////////////////////////////////////

  // Setup the sky box
  m_SkyBox.Create(&m_Graphics);
  //BENZ MD2 obj
  MD2.SetComponent(&m_NodeTreeMesh);
  m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
  ///////////////////////////////////////
  MD2.Move(c_Lpos[0],50,c_Wpos[0]);

  box[0].SetComponent(&m_NodeTreeMesh);
  box[1].SetComponent(&m_NodeTreeMesh);
  box[2].SetComponent(&m_NodeTreeMesh);
  box[3].SetComponent(&m_NodeTreeMesh);
  box[4].SetComponent(&m_NodeTreeMesh);
  box[5].SetComponent(&m_NodeTreeMesh);
  box[6].SetComponent(&m_NodeTreeMesh);
  box[7].SetComponent(&m_NodeTreeMesh);
  box[8].SetComponent(&m_NodeTreeMesh);
  box[9].SetComponent(&m_NodeTreeMesh);

  box[0].Move(-220.0f,10,-100.0f);
  box[1].Move(-110.0f,10,100.0f);
  box[2].Move(-450.0f,10,-100.0f);
  box[3].Move(-600.0f,10,-100.0f);
  box[4].Move(50.0f,10,-100.0f);
  box[5].Move(250.0f,10,-100.0f);
  box[6].Move(-500.0f,10,100.0f);
  box[7].Move(70.0f,10,100.0f);
  box[8].Move(300.0f,10,100.0f);
  box[9].Move(-220.0f,10,100.0f);

  box[0].Scale(0.2f,0.2f,0.2f);
  box[1].Scale(0.2f,0.2f,0.2f);
  box[2].Scale(0.2f,0.2f,0.2f);
  box[3].Scale(0.2f,0.2f,0.2f);
  box[4].Scale(0.2f,0.2f,0.2f);
  box[5].Scale(0.2f,0.2f,0.2f);
  box[6].Scale(0.2f,0.2f,0.2f);
  box[7].Scale(0.2f,0.2f,0.2f);
  box[8].Scale(0.2f,0.2f,0.2f);
  box[9].Scale(0.2f,0.2f,0.2f);
  ///////////////////////////////////////

  //BENZ MD2 animation
	MD2.SetFileAnimation("graphic\\knight\\tris.ini");	

	box[0].SetFileAnimation("graphic\\knight\\tris.ini");
	box[1].SetFileAnimation("graphic\\knight\\tris.ini");
	box[2].SetFileAnimation("graphic\\knight\\tris.ini");
	box[3].SetFileAnimation("graphic\\knight\\tris.ini");
	box[4].SetFileAnimation("graphic\\knight\\tris.ini");
	box[5].SetFileAnimation("graphic\\knight\\tris.ini");
	box[6].SetFileAnimation("graphic\\knight\\tris.ini");
	box[7].SetFileAnimation("graphic\\knight\\tris.ini");
	box[8].SetFileAnimation("graphic\\knight\\tris.ini");
	box[9].SetFileAnimation("graphic\\knight\\tris.ini");
	
	MD2.LoadAnimation("stand");

	box[0].LoadAnimation("stand");
	box[1].LoadAnimation("stand");
	box[2].LoadAnimation("stand");
	box[3].LoadAnimation("stand");
	box[4].LoadAnimation("stand");
	box[5].LoadAnimation("stand");
	box[6].LoadAnimation("stand");
	box[7].LoadAnimation("stand");
	box[8].LoadAnimation("stand");
	box[9].LoadAnimation("stand");
	 
/*benz code*/
char *sky[6];
	sky[0] =	"..\\data//sky//hill//EnvYPos.bmp";
	sky[1] =	"..\\data//sky//hill//EnvYNeg.bmp";
	sky[2] =	"..\\data//sky//hill//EnvXNeg.bmp";
	sky[3] =	"..\\data//sky//hill//EnvXPos.bmp";
	sky[4] =	"..\\data//sky//hill//EnvZPos.bmp";
	sky[5] =	"..\\data//sky//hill//EnvZNeg.bmp";

	MD2.LoadModelMd2(&m_Graphics,"GRAPHIC//knight//tris.md2","GRAPHIC//knight//solo.bmp");
	
	box[0].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[1].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[2].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[3].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[4].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[5].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[6].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[7].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[8].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[9].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");

	//init linklist game
	game.init();

/*benz code*/
  for(i=0;i<6;i++)
    m_SkyBox.LoadTexture(i, sky[i]);

  // Initialize the sound system to play with
  m_Sound.Init(GethWnd());
  m_SndData.LoadWAV("..\\Data\\Cricket.wav");
  for(i=0;i<3;i++)
    m_SndChannel[i].Create(&m_Sound, &m_SndData);

  
  m_Camera.Zoom(300);

  //GUI
  m_Font.Create(&m_Graphics,"Arial",20,TRUE);
  m_showtime.Create(&m_Graphics,"Arial",20,TRUE);
  m_input.Create(&m_Graphics,"Arial",40,TRUE);
  m_Window.Create(&m_Graphics,&m_Font);
  m_Window.Create(&m_Graphics,&m_showtime);
  m_Window.Create(&m_Graphics,&m_input);
  
  return TRUE;
}

////////////////////////////////////////////////////
BOOL cApp::Shutdown()
{
  // Free sounds
  for(short i=0;i<3;i++)
  m_SndChannel[i].Free();
  m_SndData.Free();
  m_Sound.Shutdown();

  // Free meshes
  m_NodeTreeMesh.Free();
  m_Mesh.Free();

  // Shutdown input
  m_Mouse.Free();
  m_Keyboard.Free();
  m_Input.Shutdown();

  // Shutdown graphics
  m_Graphics.Shutdown();
  MD2.Free();
  door_lock.Free();
  box[0].Free();
  box[1].Free();
  box[2].Free();
  box[3].Free();
  box[4].Free();
  box[5].Free();
  box[6].Free();
  box[7].Free();
  box[8].Free();
  box[9].Free();  
  

  m_Font.Free();
  m_input.Free();
  m_showtime.Free();
  m_Window.Free();

  return TRUE;
}

////////////////////////////////////////////////////
BOOL cApp::Frame()
{
  static DWORD  Timer = timeGetTime();
  unsigned long Elapsed=0;

  D3DXVECTOR2   vecDir;
  cFrustum      Frustum,Frustum2;
  cLight        Light;
  char* play=NULL;

  m_Mouse.Acquire(TRUE);


  // Calculate elapsed time (plus speed boost)
//while((float)Elapsed<30)
  Elapsed = (timeGetTime() - Timer);//delay 30 milisec
  Timer = timeGetTime();


  // Get input
  m_Keyboard.Read();
  m_Mouse.Read();

  // Process input and update everything.
  // ESC quits program
  if(m_Keyboard.GetKeyState(KEY_ESC) == TRUE)
    return FALSE;

  

  MD2.MoveDown(1);
  
  bool bmode=true;

  if(!keyboard)
  {
  if(m_Keyboard.GetKeyState(KEY_UP) == TRUE) 
  {
	  pos_state++;
	  if(pos_state > 2)pos_state = 2;   
	  MD2.Move(c_Lpos[pos_state],50,c_Wpos[pos_state]);
	  Sleep(150);
	 
  }
  if(m_Keyboard.GetKeyState(KEY_DOWN) == TRUE) 
  {
	  pos_state--;
	  if(pos_state < 0)pos_state = 0;   
	  MD2.Move(c_Lpos[pos_state],50,c_Wpos[pos_state]);
	  Sleep(150);
  } 
  }
 
  BOOL bfootonEarth=FALSE;
  MD2.CheckEarthMoveMent(Elapsed,&bfootonEarth);
  //box[0].CheckEarthMoveMent(Elapsed,NULL);
  
  BOOL bfootonObj=FALSE;
  //MD2.Checkcollision(&box,&bfootonObj);
 
  MD2.UpdateMoveMent();
  box[0].UpdateMoveMent();
  box[1].UpdateMoveMent();
  box[2].UpdateMoveMent();
  box[3].UpdateMoveMent();
  box[4].UpdateMoveMent();
  box[5].UpdateMoveMent();
  box[6].UpdateMoveMent();
  box[7].UpdateMoveMent();
  box[8].UpdateMoveMent();
  box[9].UpdateMoveMent();
  //key controll 
	MD2.UpdateModel( TRUE,"stand",Elapsed);
	box[0].UpdateModel( TRUE,"stand",Elapsed);
	box[1].UpdateModel( TRUE,"stand",Elapsed);
	box[2].UpdateModel( TRUE,"stand",Elapsed);
	box[3].UpdateModel( TRUE,"stand",Elapsed);
	box[4].UpdateModel( TRUE,"stand",Elapsed);
	box[5].UpdateModel( TRUE,"stand",Elapsed);
	box[6].UpdateModel( TRUE,"stand",Elapsed);
	box[7].UpdateModel( TRUE,"stand",Elapsed);
	box[8].UpdateModel( TRUE,"stand",Elapsed);
	box[9].UpdateModel( TRUE,"stand",Elapsed);

		m_XPos=MD2.GetXPos();
		m_YPos=MD2.GetYPos();
		m_ZPos=MD2.GetZPos();
  
	
	char c_MMSG[20];

	float dmouseX,dmouseY;
	
	dmouseX=dmouseY=0;
	dmouseX=(float)m_Mouse.GetXDelta();
	dmouseY=(float)m_Mouse.GetYDelta();

/****************************************/
	getmousepos(&c_MMSG[0]);
	if(keyboard)
	{
		if(clickkeyboard(&c_MMSG[0]))
		{
			if(strcmp(c_MMSG,"KEY C") == 0)
			{
				door_lock.Free();
				game.user_passset("");
				strcpy(tmp,"");
			}
			else
			if(strcmp(c_MMSG,"KEY E") == 0)
			{
				door_lock.Free();
				keyboard = false;
				if(game.true_password())
				{
					strcpy(tmp,"ACCESS GRANT");
					game.user_passset("");
					if(game.next_stage())
					{
						strcpy(tmp,"CONGRATULATION");
					}
					else
					{
						pos_state = 0;
						MD2.Move(c_Lpos[pos_state],50,c_Wpos[pos_state]);
						Sleep(150);
					}
				}
				else
					strcpy(tmp,"ACCESS DENIED");					
				
			}
			else
			{
				strcpy(tmp,"");
				enterpass(&c_MMSG[0]);
				//char tmp[20];
				strcpy(tmp,c_MMSG);
				u_pass = tmp;
				
			}
			
		}
	}
	else
	if(clickitem(&c_MMSG[0]))
	{
		if(strcmp(c_MMSG,"DOOR") != 0)
		{
			if(game.checkgotpass(&c_MMSG[0]))
				if(strcmp(c_MMSG,"Not found") != 0)strcpy(password,c_MMSG);
		}
		else
		{
			if(keyboard == false)
			{
				door_lock.SetComponent(&m_NodeTreeMesh);
				door_lock.Move(-300.0f,50,0.0f);
				door_lock.Scale(0.5f,0.5f,0.5f);
				door_lock.Rotate(90,0,0);
				door_lock.SetFileAnimation("graphic\\knight\\tris.ini");
				door_lock.LoadAnimation("stand");
				door_lock.LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//backtext.md2","GRAPHIC//linklist//keypad.jpg");
				door_lock.UpdateMoveMent();
				door_lock.UpdateModel( TRUE,"stand",Elapsed);				
				keyboard = true;
			}		
		}	

	}
	sentense=c_MMSG;
	if(strcmp(password,"") != 0)sentense = password;
	if(strcmp(tmp,"ACCESS GRANT") == 0)sentense = tmp;
	if(strcmp(tmp,"ACCESS DENIED") == 0)sentense = tmp;
	if(strcmp(tmp,"CONGRATULATION") == 0)sentense = tmp;
/****************************************/

	//camera 3 RD
//	m_Camera.Camera_Obj(Elapsed,dmouseX,0,bmode);
  m_Camera.Camera_Obj(Elapsed,0,0,bmode);
  // Position light
  m_Light.Move(m_XPos, m_YPos+60.0f, m_ZPos);
  m_Graphics.SetLight(0, &m_Light);

  // Set camera and calculate frustum
  m_Graphics.SetCamera(&m_Camera);
  Frustum.Construct(&m_Graphics,0);
  Frustum2.Construct(&m_Graphics,1000);
  // Render everything
  m_Graphics.ClearZBuffer(1.0f);
  play = "stand";
  if(m_Graphics.BeginScene() == TRUE) {
    m_Graphics.EnableZBuffer(FALSE);
    m_Graphics.EnableLighting(FALSE);
    m_SkyBox.Render(&m_Camera);
    m_Graphics.EnableZBuffer(TRUE);
    m_Graphics.EnableLighting(TRUE);
    m_NodeTreeMesh.Render(&Frustum);

	MD2.Rotate(0,m_Camera.GetYRotation(),0);

  }	

	if(Frustum2.CheckSphere(box[0].GetXPos(),box[0].GetYPos(),box[0].GetZPos(),box[0].m_XYZRadius))
		box[0].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[1].GetXPos(),box[1].GetYPos(),box[1].GetZPos(),box[1].m_XYZRadius))
		box[1].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[2].GetXPos(),box[2].GetYPos(),box[2].GetZPos(),box[2].m_XYZRadius))
		box[2].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[3].GetXPos(),box[3].GetYPos(),box[3].GetZPos(),box[3].m_XYZRadius))
		box[3].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[4].GetXPos(),box[4].GetYPos(),box[4].GetZPos(),box[4].m_XYZRadius))
		box[4].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[5].GetXPos(),box[5].GetYPos(),box[5].GetZPos(),box[5].m_XYZRadius))
		box[5].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[6].GetXPos(),box[6].GetYPos(),box[6].GetZPos(),box[6].m_XYZRadius))
		box[6].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[7].GetXPos(),box[7].GetYPos(),box[7].GetZPos(),box[7].m_XYZRadius))
		box[7].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[8].GetXPos(),box[8].GetYPos(),box[8].GetZPos(),box[8].m_XYZRadius))
		box[8].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[9].GetXPos(),box[9].GetYPos(),box[9].GetZPos(),box[9].m_XYZRadius))
		box[9].RenderModel(TRUE);
	if(keyboard)
		if(Frustum2.CheckSphere(door_lock.GetXPos(),door_lock.GetYPos(),door_lock.GetZPos(),door_lock.m_XYZRadius))
			door_lock.RenderModel(TRUE);

	m_Graphics.EnableAlphaBlending(FALSE);
	
    m_Graphics.EndScene();
	
	int timeleft = game.checktime();

	if(timeleft != 0)
	{
	
		char showtime[5],tmpstr[2];

		_itoa(timeleft/60,tmpstr,10);
		strcpy(showtime,tmpstr);
		_itoa(timeleft%60,tmpstr,10);
		strcat(showtime,":");
		strcat(showtime,tmpstr);
	
		m_showtime.Print(showtime,10,10,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(sentense,420,10,0,0,D3DCOLOR_RGBA(255,255,255,255));
		if(keyboard)m_input.Print(u_pass,470,250,0,0,D3DCOLOR_RGBA(0,0,0,255));
	}
	else
	{
		m_Font.Print("Time out",420,10,0,0,D3DCOLOR_RGBA(255,255,255,255));		
	}	
  
    m_Graphics.Display();

	if(timeleft == 0)
	{
		Sleep(1000);
		return false;
	}
	if(strcmp(tmp,"ACCESS GRANT") == 0)
	{
		Sleep(2000);
		strcpy(tmp,"");
	}
	else if(strcmp(tmp,"ACCESS DENIED") == 0)
	{
		Sleep(2000);
		strcpy(tmp,"");
	}
	else if(strcmp(tmp,"CONGRATULATION") == 0)
	{
		Sleep(3000);
		strcpy(tmp,"");
		return false;
	}
	else if(strcmp(password,"") != 0)
	{
		Sleep(2000);
		strcpy(password,"");
	}
	else if(strcmp(c_MMSG,"Not found") == 0)
	{
		Sleep(800);
	}
	strcpy(c_MMSG,"");

  return TRUE;
}
/////////////////////////////////////
void cApp::enterpass(char *c_MMSG)
{
	char tmp_MSG[2];

	if(strcmp(c_MMSG,"KEY 0") == 0)strcpy(tmp_MSG,"0");
	if(strcmp(c_MMSG,"KEY 1") == 0)strcpy(tmp_MSG,"1");
	if(strcmp(c_MMSG,"KEY 2") == 0)strcpy(tmp_MSG,"2");
	if(strcmp(c_MMSG,"KEY 3") == 0)strcpy(tmp_MSG,"3");
	if(strcmp(c_MMSG,"KEY 4") == 0)strcpy(tmp_MSG,"4");
	if(strcmp(c_MMSG,"KEY 5") == 0)strcpy(tmp_MSG,"5");
	if(strcmp(c_MMSG,"KEY 6") == 0)strcpy(tmp_MSG,"6");
	if(strcmp(c_MMSG,"KEY 7") == 0)strcpy(tmp_MSG,"7");
	if(strcmp(c_MMSG,"KEY 8") == 0)strcpy(tmp_MSG,"8");
	if(strcmp(c_MMSG,"KEY 9") == 0)strcpy(tmp_MSG,"9");

	char *tmp_pass;
	int count = game.user_passcount();
	tmp_pass = game.user_passget();
	if(count < 4)
	{	
		if(count != 0)
		{
			strcat(tmp_pass,tmp_MSG);
		}
		else
			strcpy(tmp_pass,tmp_MSG);
	
		game.user_passset(tmp_pass);
	}

		strcpy(c_MMSG,tmp_pass);
	
}
/////////////////////////////////////
void cApp::getmousepos(char *m_MMSG)
{
	char test1[10];	
	strcpy(m_MMSG,"LINKLIST GAME");
	mouseX=mouseY = 0;
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON) ==TRUE)
	{
			mouseX=m_Mouse.GetXPos();
			mouseY=m_Mouse.GetYPos();
			Sleep(100);

			strcpy(m_MMSG,"Left Mouse@");
			_itoa((int)mouseX,test1,10);
			strcat(m_MMSG,test1);
			strcat(m_MMSG,",");
			_itoa((int)mouseY,test1,10);
			strcat(m_MMSG,test1);	
	}
}
/////////////////////////////////////
bool cApp::clickkeyboard(char *c_MSG)
{
		if((mouseX > 617) && (mouseX < 750) && (mouseY > 340) && (mouseY < 399)){strcpy(c_MSG,"KEY 9");return true;}
		if((mouseX > 436) && (mouseX < 559) && (mouseY > 340) && (mouseY < 399)){strcpy(c_MSG,"KEY 8");return true;}
		if((mouseX > 262) && (mouseX < 353) && (mouseY > 340) && (mouseY < 399)){strcpy(c_MSG,"KEY 7");return true;}
		if((mouseX > 621) && (mouseX < 764) && (mouseY > 412) && (mouseY < 509)){strcpy(c_MSG,"KEY 6");return true;}
		if((mouseX > 436) && (mouseX < 559) && (mouseY > 412) && (mouseY < 509)){strcpy(c_MSG,"KEY 5");return true;}
		if((mouseX > 252) && (mouseX < 342) && (mouseY > 412) && (mouseY < 509)){strcpy(c_MSG,"KEY 4");return true;}
		if((mouseX > 628) && (mouseX < 777) && (mouseY > 532) && (mouseY < 609)){strcpy(c_MSG,"KEY 3");return true;}
		if((mouseX > 432) && (mouseX < 564) && (mouseY > 532) && (mouseY < 609)){strcpy(c_MSG,"KEY 2");return true;}
		if((mouseX > 237) && (mouseX < 531) && (mouseY > 532) && (mouseY < 609)){strcpy(c_MSG,"KEY 1");return true;}
		if((mouseX > 427) && (mouseX < 564) && (mouseY > 622) && (mouseY < 699)){strcpy(c_MSG,"KEY 0");return true;}
		if((mouseX > 224) && (mouseX < 326) && (mouseY > 422) && (mouseY < 699))
		{
			strcpy(c_MSG,"KEY C");			
			keyboard = false;
			return true;
		}
		if((mouseX > 633) && (mouseX < 787) && (mouseY > 422) && (mouseY < 699)){strcpy(c_MSG,"KEY E");return true;}		

		return false;
}
/////////////////////////////////////
bool cApp::clickitem(char *c_MSG)
{
	if(pos_state == 0)
	{
		if((mouseX > 255) && (mouseX < 292) && (mouseY > 472) && (mouseY < 488)){strcpy(c_MSG,"BOX 1");return true;}
		if((mouseX > 343) && (mouseX < 364) && (mouseY > 441) && (mouseY < 453)){strcpy(c_MSG,"BOX 2");return true;}
		if((mouseX > 396) && (mouseX < 442) && (mouseY > 423) && (mouseY < 431)){strcpy(c_MSG,"BOX 3");return true;}
		if((mouseX > 611) && (mouseX < 628) && (mouseY > 422) && (mouseY < 432)){strcpy(c_MSG,"BOX 9");return true;}
		if((mouseX > 627) && (mouseX < 644) && (mouseY > 430) && (mouseY < 440)){strcpy(c_MSG,"BOX 8");return true;}
		if((mouseX > 662) && (mouseX < 687) && (mouseY > 443) && (mouseY < 456)){strcpy(c_MSG,"BOX 7");return true;}
		if((mouseX > 765) && (mouseX < 806) && (mouseY > 483) && (mouseY < 503)){strcpy(c_MSG,"BOX 6");return true;}
	}
	if(pos_state == 1)
	{
		if((mouseX > 272) && (mouseX < 307) && (mouseY > 462) && (mouseY < 481)){strcpy(c_MSG,"BOX 3");return true;}
		if((mouseX > 358) && (mouseX < 381) && (mouseY > 434) && (mouseY < 447)){strcpy(c_MSG,"BOX 4");return true;}
		if((mouseX > 386) && (mouseX < 405) && (mouseY > 424) && (mouseY < 435)){strcpy(c_MSG,"BOX 5");return true;}
		if((mouseX > 634) && (mouseX < 655) && (mouseY > 431) && (mouseY < 442)){strcpy(c_MSG,"BOX 0");return true;}
		if((mouseX > 714) && (mouseX < 750) && (mouseY > 463) && (mouseY < 481)){strcpy(c_MSG,"BOX 9");return true;}
		if((mouseX > 787) && (mouseX < 836) && (mouseY > 490) && (mouseY < 518)){strcpy(c_MSG,"BOX 8");return true;}
		
	}	
	if(pos_state == 2)
	{
		
		if((mouseX > 72) && (mouseX < 140) && (mouseY > 529) && (mouseY < 561)){strcpy(c_MSG,"BOX 4");return true;}
		if((mouseX > 249) && (mouseX < 286) && (mouseY > 470) && (mouseY < 491)){strcpy(c_MSG,"BOX 5");return true;}
		if((mouseX > 815) && (mouseX < 871) && (mouseY > 508) && (mouseY < 530)){strcpy(c_MSG,"BOX 0");return true;}
		if((mouseX > 456) && (mouseX < 567) && (mouseY > 300) && (mouseY < 500)){strcpy(c_MSG,"DOOR");return true;}
	}
	return false;
}
///////////////////////////////////////////////////////////////////////////////////
int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR szCmdLine, int nCmdShow)
{
  cApp App;
  return App.Run();
}
