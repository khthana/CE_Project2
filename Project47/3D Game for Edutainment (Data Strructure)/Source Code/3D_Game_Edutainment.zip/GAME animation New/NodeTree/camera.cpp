#include"camera.h"
cCamera_tool::cCamera_tool()
{
	m_fdmouseX=0;
	m_fdmouseY=0;
	m_fZoom=0;
	m_fRotateBase=0;
};
cCamera_tool::~cCamera_tool()
{

};
BOOL cCamera_tool::PointRel(FLOAT XEyeAdd,FLOAT YEyeAdd,FLOAT ZEyeAdd ,FLOAT XAtBase ,FLOAT YAtBase,FLOAT ZAtBase)
{
	return cCamera_tool::Point(XEyeAdd+XAtBase,YEyeAdd+YAtBase,ZEyeAdd+ZAtBase,XAtBase,YAtBase,ZAtBase);
};

BOOL cCamera_tool::ThirdViewXYPlain(FLOAT dmouseX,FLOAT dmouseY,FLOAT XAtBase ,FLOAT YAtBase,FLOAT ZAtBase)
{	
	m_fdmouseX+=dmouseX;
	m_fdmouseY+=dmouseY;
	
	return cCamera_tool::PointRel((FLOAT)cos(m_fdmouseX+m_fRotateBase)*m_fZoom,
																  m_fdmouseY,
								 (FLOAT)sin(m_fdmouseX+m_fRotateBase)* m_fZoom,
								 XAtBase,YAtBase,ZAtBase);
};

/*ThirdViewXYPlain component*/ 
BOOL cCamera_tool::Zoom(FLOAT zoom)
{
	m_fZoom=zoom;
	return TRUE;
};
BOOL cCamera_tool::ZoomRel(FLOAT zoomrel)
{
	m_fZoom+=zoomrel;

	return TRUE;
};
FLOAT cCamera_tool::GetYRotation()//not include base change
{
  return m_YRot+m_fRotateBase;
}

BOOL cCamera_tool::SetRotateBase(FLOAT rotate)
{
	m_fRotateBase=rotate;
	return TRUE;
};
BOOL cCamera_tool::RotateBaseRel(FLOAT rotateRel)
{
	m_fRotateBase+=rotateRel;
	return TRUE;
};
FLOAT cCamera_tool::GetZoom()
{
	return m_fZoom;
}
/*ThirdViewXYPlain component*/
//warning use component before check collision

/*FirstViewXYPlain*/
BOOL cCamera_tool::FirstViewXYPlain(FLOAT dmouseX,FLOAT dmouseY,FLOAT XPos ,FLOAT YPos,FLOAT ZPos)
{

	/*initial for ThirdView*/
	  //must restart at back of model
	  m_fRotateBase=0;
	  //rotate camera to same direction when back to third mode
	  m_fdmouseX-=dmouseX;
	  m_fdmouseY+=(tanf(dmouseY)*m_fZoom);

	  
	  //First View
	  Move(XPos, YPos, ZPos);
	  //RotateRel(CamAngleY, CamAngleX, 0.0f);
	  Rotate(this->GetXRotation()+dmouseY, -m_fdmouseX-1.57f, 0.0f);


	return TRUE;
}


/**********camera_obj***********/
cCamera_obj::cCamera_obj()
{

	cCamera_tool::cCamera_tool();
}

cCamera_obj::~cCamera_obj()
{
	cCamera_tool::~cCamera_tool();
}

void cCamera_obj::SetComponent(cNodeTreeMesh *pnodetree,cMD2_Obj *pMD2 )
{
	m_pnodetree=pnodetree;
	m_pMD2Obj=pMD2;
}
//for game shooting action
BOOL cCamera_obj::Camera_Obj(FLOAT Elapsed,FLOAT dmouseX,FLOAT dmouseY,BOOL bmode)
{
		FLOAT tmp=0;
		FLOAT Height=0;

	//get mouse rotate for 3rd
	FLOAT mouseX,mouseY;
	mouseX=mouseY=0;

		//limited of camera
		if(atanf(m_fdmouseY/m_fZoom)>1)dmouseY=-fabs(dmouseY);
		if(atanf(m_fdmouseY/m_fZoom)<-0.75)dmouseY=fabs(dmouseY);
		if(this->m_fZoom>200)this->m_fZoom=200;
		if(this->m_fZoom<65)this->m_fZoom=65;


//for third view
	mouseX=-(dmouseX * Elapsed / 4000.0f);
	mouseY=(dmouseY * Elapsed / 50.0f);

	this->ZoomRel(4* Elapsed / 40.0f); //when not collision zoom out

   //third view
  if(!(bmode||this->GetZoom()<65)){
	
/*camera collision*/
	this->ThirdViewXYPlain(mouseX,
						   mouseY, 								
						   m_pMD2Obj->GetXPos(),
						   m_pMD2Obj->GetYPos()+m_pMD2Obj->m_Head,
						   m_pMD2Obj->GetZPos());
		//lowwer camera collsion
	  if( TRUE==m_pnodetree->CheckIntersect(this->GetXPos()+m_pMD2Obj->m_XMove
											,this->GetYPos()-4
											,this->GetZPos()+m_pMD2Obj->m_ZMove
											, m_pMD2Obj->GetXPos()
											,m_pMD2Obj->GetYPos()
											,m_pMD2Obj->GetZPos() 
											  ,&tmp
											  ))  
		{
		Height=0;		
		Height = m_pnodetree->GetHeightBelow(this->GetXPos(),this->GetYPos(),this->GetZPos());
		if(Height<this->GetYPos())
		{
			mouseX=0;
			mouseY=fabs(mouseY);
		}
		//zoom near
		//if(m_Camera.GetZoom()>100)
		this->ZoomRel(-tmp-4* Elapsed / 40.0f);
								
		}else//use else for protect some slope plane
		//upper camera collsion
	  if( TRUE==m_pnodetree->CheckIntersect(this->GetXPos()+m_pMD2Obj->m_XMove
											,this->GetYPos()+4
											,this->GetZPos()+m_pMD2Obj->m_ZMove
											, m_pMD2Obj->GetXPos()
											,m_pMD2Obj->GetYPos()
											,m_pMD2Obj->GetZPos() 
											,&tmp))  
	  {
		Height=0;		
		Height = m_pnodetree->GetHeightBelow(this->GetXPos(),this->GetYPos(),this->GetZPos());
		if(Height>this->GetYPos())
		{
			mouseX=0;
			mouseY=-fabs(mouseY);
		//zoom near
		//if(m_Camera.GetZoom()>100)
		//Zoom in until not collision and don't include try to zoom out
		this->ZoomRel(-tmp-4* Elapsed / 40.0f);
		}
	  }
/*camera collision*/
		//if collision rotate back before view it
		this->ThirdViewXYPlain(mouseX,
							   mouseY, 								
							   m_pMD2Obj->GetXPos(),
						       m_pMD2Obj->GetYPos()+m_pMD2Obj->m_Head,
							   m_pMD2Obj->GetZPos());
		
  
  
  }

  //first persion
    if(bmode||this->GetZoom()<=65){  
						mouseX=	  dmouseX / 200.0f;
						mouseY=	  dmouseY / 200.0f;
  // Position camera
	this->FirstViewXYPlain(mouseX,
							  mouseY,
							  m_pMD2Obj->GetXPos(),
							  m_pMD2Obj->GetYPos()+m_pMD2Obj->m_Head, /*+ 45.0f*/
							  m_pMD2Obj->GetZPos()/* + ZMove*/);
	}
	

  return TRUE;
}

	

