#include "MD2tool.h"
cMD2_tool::cMD2_tool()
{
  m_curanim=0;
  m_Graphics       = NULL;
}

cMD2_tool::~cMD2_tool()
{
  Free();
}
BOOL cMD2_tool::Free()
{
  m_Graphics     = NULL;
  m_MD2.ReleaseVertex();
 
  return TRUE;
}
cMD2_tool::Move(FLOAT XPos,FLOAT YPos,FLOAT ZPos)
{
 return m_Pos.Move(XPos,YPos,ZPos);
}
cMD2_tool::MoveRel(FLOAT XAdd,FLOAT YAdd,FLOAT ZAdd)
{
 return m_Pos.MoveRel(XAdd,YAdd,ZAdd);
}
cMD2_tool::Rotate(FLOAT XRot,FLOAT YRot,FLOAT ZRot)
{
 return m_Pos.Rotate(XRot,YRot,ZRot);
}
cMD2_tool::RotateRel(FLOAT XAdd,FLOAT YAdd,FLOAT ZAdd)
{
 return m_Pos.RotateRel(XAdd,YAdd,ZAdd);
}

BOOL cMD2_tool::Scale(FLOAT XScale, FLOAT YScale, FLOAT ZScale)
{
  return m_Pos.Scale(XScale, YScale, ZScale);
}

BOOL cMD2_tool::ScaleRel(FLOAT XAdd, FLOAT YAdd, FLOAT ZAdd)
{
  return m_Pos.ScaleRel(XAdd, YAdd, ZAdd);
}

D3DXMATRIX *cMD2_tool::GetMatrix()
{
  return m_Pos.GetMatrix(); 
}

FLOAT cMD2_tool::GetXPos()
{
  return m_Pos.GetXPos();
}

FLOAT cMD2_tool::GetYPos()
{
  return m_Pos.GetYPos();
}

FLOAT cMD2_tool::GetZPos()
{
  return m_Pos.GetZPos();
}

FLOAT cMD2_tool::GetXRotation()
{
  return m_Pos.GetXRotation();
}

FLOAT cMD2_tool::GetYRotation()
{
  return m_Pos.GetYRotation();
}

FLOAT cMD2_tool::GetZRotation()
{
  return m_Pos.GetZRotation();
}

FLOAT cMD2_tool::GetXScale()
{
  return m_Pos.GetXScale();
}

FLOAT cMD2_tool::GetYScale()
{
  return m_Pos.GetYScale();
}

FLOAT cMD2_tool::GetZScale()
{
  return m_Pos.GetZScale();
}

void cMD2_tool::GetBound(FLOAT &maxX,FLOAT &maxY,FLOAT &maxZ,	\
						FLOAT &minX,FLOAT &minY,FLOAT &minZ)
{
	
  m_MD2.GetBound(maxX,maxY,maxZ,	
				 minX,minY,minZ);
}

BOOL cMD2_tool::Update()
{
  // Update the world position
  m_Pos.Update(m_Graphics);

  return TRUE;
}
/*model .MD2*/
BOOL cMD2_tool::LoadModelMd2(cGraphics *Graphic,char *filename,char *texture)
{
	if(Graphic == NULL) return 0;
	else m_Graphics=Graphic;

  return m_MD2.LoadModelMd2(Graphic,filename,texture);
}

VOID cMD2_tool::SetFileAnimation(char *filename)
{
	 m_cfilename=filename;
}
BOOL cMD2_tool::LoadAnimation(char *animationname)
{
	CIniFile m_fileAnimation;

	m_fileAnimation.SetFileName(m_cfilename);

		SAnimation a;
		char name[30],speed[30];
		BOOL bname,bspeed,bstart,bend;

	bname	=m_fileAnimation.GetStringValue (name   , animationname , "name");
	bspeed	=m_fileAnimation.GetStringValue (speed   , animationname ,"speed");
	bstart	=m_fileAnimation.GetIntValue    (a.start, animationname , "start");
	bend	=m_fileAnimation.GetIntValue    (a.end  , animationname , "end");

	a.add=atof(speed);
	a.name=name;
	a.cur = a.start;
	this->m_anim.push_back (a);

	if(bname&&bspeed&&bstart&&bend)return TRUE;
	else return FALSE;
}

BOOL cMD2_tool::RenderModel(BOOL b,int frame)
{	
	cWorldPosition Pos;//for MD2 only
		
		m_Pos.Copy(&Pos);
		Pos.RotateRel(0,-1.57f,0);  //rotate for MD2 modle only
		m_Graphics->GetDeviceCOM()->SetTransform(D3DTS_WORLD, Pos.GetMatrix(m_Graphics)/*D3DXMATRIX*/);
		
	return m_MD2.RenderModel(b,frame);
}

BOOL cMD2_tool::UpdateModel(BOOL b,char *name,FLOAT Elapsed)
{
int play=-1;

	//Loop through all animation names
	for (int l=0;l<m_anim.size();l++)
	{
		//found it ???
		if (strcmp (m_anim[l].name.c_str(), name)==0)
		{	
			//if animation has been changed then restart
			if(l!=m_curanim)
				m_anim[l].cur=m_anim[l].start;
			
			//if need update then update
			if (b)
				m_anim[l].cur += m_anim[l].add*Elapsed;

			//restart animation
			if (m_anim[l].cur >= m_anim[l].end)
				m_anim[l].cur = m_anim[l].start;

			play=l;

			break;
		}
	}
		//tell current animation
		m_curanim=l;
		if (play==-1) return FALSE;
		/*if (play>=GetFrameCount()) return FALSE;*/
		else return TRUE;
}
BOOL cMD2_tool::RenderModel(BOOL b)
{

		RenderModel(b,m_anim[m_curanim].cur);
		return TRUE;
}
/*new plan if m_anim == minute value -1 ,-2 it can be reward when it end*/