/**************************************************
WinMain.cpp
Chapter 12 NodeTree Demo

Programming Role-Playing Games with DirectX
by Jim Adams (01 Jan 2002)

Required libraries:
  D3D8.LIB, D3DX8.LIB, and DINPUT8.LIB
**************************************************/

#include "Core_Global.h"
#include "Frustum.h"
#include "NodeTree.h"
#include "SkyBox.h"
#include "ModelVertex.h"
#include "cMD2_Obj.h"
#include "camera.h"
#include "Window.h"
#include <String.h>
#include <time.h>
#include<dos.h>

class linklistgame
{
private:
	int num_train,item_in,now_train;
	int time_up;
	int command;					//command is No. of item to pick up for find password

	int item[5][10];
	char door_pass[4];
	char user_pass[5];

	char Exit;
	int ttime;
	int starttime;
	int got_pass;
	int pass_door;

	void randomize();
	void convert_cond(char&,int);
	void convert_pass(int,char&,int);

public:

	//linklistgame();
	void init();
	bool checkgotpass(char*);
	int user_passcount();
	char* user_passget();
	void user_passset(char*);
	bool true_password();
	bool next_stage();
	bool set_starttime();
	int checktime();
};
//////////////////////////////////////////////////// 
void linklistgame::init()
{
	num_train = 5,item_in = 10;
	now_train = 0;
	time_up = 0;	

	Exit = 'N';
	ttime = 120;
	starttime = time(0);
	got_pass = 0;
	pass_door = 0;

	for(int i = 0;i < 5;i++)
		for(int j = 0;j < 10;j++)
			item[i][j] = 0;
	
	for(i = 0;i < 4;i++)
	{
		door_pass[i] = 0;
		user_pass[i] = 0;
	}

	/////////////////////////////
	//random item in train
	
	randomize();
	
	for(i = 0;i < 5;i++)
	{
		int pos_item = rand() % 10;
		item[i][pos_item] = rand() % 10000;
	}
}
/////////////////////////////////////
void linklistgame::convert_cond(char &door_pass,int length)
{
	for(int j = 0;j < length;j++)
	{
		if((*(&door_pass + j) == 0) || (*(&door_pass + j) == 'a'))
		{
			if(j != 0)
			{
				*(&door_pass + j) = *(&door_pass + j - 1);
				*(&door_pass + j - 1) = 'a';		
				convert_cond(door_pass,j);
			}
		}							
	}
}

/////////////////////////////////////
void linklistgame::convert_pass(int item,char &door_pass,int length)
{
	_itoa(item,&door_pass,10);
					
	if(item < 1000)
	{		
		convert_cond(door_pass,length);

		for(int k = 0;k < 4;k++)
		{		
			if(*(&door_pass + k) == 'a')*(&door_pass + k) ='0';						
		}
	}	

}
/////////////////////////////////////
void linklistgame::randomize()
{
	int seed;
	seed = (unsigned)time(0);
	srand(seed);
}
/////////////////////////////////////
bool linklistgame::checkgotpass(char *MSG)
{
	int boxnumber = 99;
	if(strcmp(MSG,"BOX 1") == 0)boxnumber = 0;
	if(strcmp(MSG,"BOX 2") == 0)boxnumber = 1;
	if(strcmp(MSG,"BOX 3") == 0)boxnumber = 2;
	if(strcmp(MSG,"BOX 4") == 0)boxnumber = 3;
	if(strcmp(MSG,"BOX 5") == 0)boxnumber = 4;
	if(strcmp(MSG,"BOX 6") == 0)boxnumber = 5;
	if(strcmp(MSG,"BOX 7") == 0)boxnumber = 6;
	if(strcmp(MSG,"BOX 8") == 0)boxnumber = 7;
	if(strcmp(MSG,"BOX 9") == 0)boxnumber = 8;
	if(strcmp(MSG,"BOX 0") == 0)boxnumber = 9;
	//if(boxnumber == 0){strcpy(MSG,"got box 1");return true;}
	if(boxnumber == 99)return false;

	if(item[now_train][boxnumber] != 0)
	{					
		got_pass = 1;

		for(int k = 0;k < 4;k++)
		{		
			door_pass[k] = 0;						
		}

		//change door password
		convert_pass(item[now_train][boxnumber],*door_pass,4);
					
		//item[now_train][boxnumber] = 0;

		//cout<<"door password is "<<door_pass<<endl;
		strcpy(MSG,"Password is ");
		strcat(MSG,door_pass);
		return true;
	}
	else
	{
		//cout<<"Not found"<<endl;
		strcpy(MSG,"Not found");
		return true;
	}
				
	return false;
}
//////////////////////////////////////////////////// 
int linklistgame::user_passcount()
{
	for(int i = 0;i < 5;i++)
	{
		if(user_pass[i] == NULL)break;
	}
	return i;
}
//////////////////////////////////////////////////// 
char* linklistgame::user_passget()
{	
	return &user_pass[0];
}
//////////////////////////////////////////////////// 
void linklistgame::user_passset(char *c_MMSG)
{
	strcpy(user_pass,c_MMSG);
}
//////////////////////////////////////////////////// 
bool linklistgame::set_starttime()
{
	starttime = time(0);
	return true;
}
//////////////////////////////////////////////////// 
bool linklistgame::true_password()
{
	pass_door = 1;

	for(int k = 0;k < 4;k++)
		if(user_pass[k] != door_pass[k])
				pass_door = 0;

	if(pass_door)
	{
		return true;
	}
	else
		return false;
}
//////////////////////////////////////////////////// 
bool linklistgame::next_stage()
{
	now_train++;
	if(now_train > 4)return true;	
	return false;
}
//////////////////////////////////////////////////// 
int linklistgame::checktime()
{	
	int presenttime = 0;
	
	presenttime = time(0);
	if((presenttime - starttime) >= ttime)
	{
		return(0);
	}
	else
	{
		//cout"time :: "<<(ttime - (presenttime - starttime))/60<<" : "<<((ttime - (presenttime - starttime))%60)<<endl;
		return(ttime - (presenttime - starttime));//return time left
	}	
}

////////////////////////////////
class cApp : public cApplication
{
  private:
    cGraphics       m_Graphics;
    cCamera_obj     m_Camera;
    cLight          m_Light;

    cSound          m_Sound;
    cSoundData      m_SndData;
    cSoundChannel   m_SndChannel[3];

    cSkyBox         m_SkyBox;

    cInput          m_Input;
    cInputDevice    m_Keyboard;
    cInputDevice    m_Mouse;

    cMesh           m_Mesh;
    cNodeTreeMesh   m_NodeTreeMesh;
	cMD2_Obj		MD2;

	///Array
	cMD2_Obj		chair[4][6];
	cMD2_Obj		bgtext_r,bgtext_b;
	///
	
	cWindow			m_Window,m_Window2;

	cFont			m_Title,m_array,m_stack,m_queue,m_linklist,m_recur,m_showmouse;
	cFont			m_Font,m_Font2;

	long			mouseX,mouseY;

	char			*sentense;

    float           m_XPos, m_YPos, m_ZPos;
	float			c_Lpos[3],c_Wpos[3];
	bool			menu_yes,Array_yes,Stack_yes,Queue_yes,Linklist_yes,Recur_yes;
	///Stack
	cMD2_Obj		plate;
	cMD2_Obj		boxs[24];
	///
	float	line_p[3],line_x[7],line_y[4],line_z;
	int		p_box[7][4],p_stack[3],b_color[27],b_tmp[15];
	char	text_time[20];
	int		end_count,s_time,t_time,start;
	///Queue
	cMD2_Obj		Plane,q_button[7],bgtext_l,bgtext_t;
	///
	char q_text[14][20],*randname,text_score[20];
	int  round;
	int  color[6][3],status[10],queue[4],zone,park;
	///Linklist
	cMD2_Obj		box[10],door_lock;
	///
	cFont			m_input,m_showtime;
	linklistgame	game;
	int				pos_state;
	char			*u_pass;
	char			password[20];
	char			tmp[20];
	char			move;
	bool			keyboard;

	///Recursive
	cMD2_Obj		b1,b2,b3,b4,b5;
	cWindow			W_Text;
	cFont			F_Text;
	char *M_Text1,*M_Text2,*M_Recur[7],*t_a,*t_b,*t_c;
	int red[7],green[7],blue[7],delay;
	///
	//Array variables	
	char *sentence,*sentence2,*rank;
	char *S_Status,*S_Name,*S_Event,*S_Event2,*m_score;
	char *col_a,*col_b,*col_c,*col_d,*row_1,*row_2,*row_3,*row_4,*row_5,*row_0;
	int  chair_stat[4][6],customer,n_col,n_row,state,targetX,targetY,targetX2,targetY2,score,maxscore,count;
	int  checkclick,tmpX,tmpY;

	bool clickitem(char*);
	bool clickkeyboard(char*);
	void enterpass(char*);

  public:
    cApp();
    BOOL Init();
    BOOL Shutdown();

    BOOL Frame();

	void getmousepos(char*);
	BOOL Randomize();

	//Menu Function
	bool clickmenu(char*);
	bool closemenu();

	//Array Function
	bool initarray();
	BOOL SetEvent();
	BOOL ChkPosition(long,long);
	bool closearray();
	//Stack Function
	bool initstack();
	BOOL Move_Box();
	BOOL Move_Stack(int plate_p);
	BOOL RandomBoxColor24();
	BOOL ReQueueBox();
	BOOL MoveTmp();
	BOOL KeepToTmp(int line_py);
	BOOL ChkSen2();
	bool closestack();
	//Queue Function
	bool initqueue();
	BOOL MoveLanding(int round);
	BOOL MoveTakeoff(int round);
	BOOL RandName(char *name);
	bool closequeue();
	//linkedlist Function
	bool initlinklist();
	bool closelinklist();
	//Recursive Function
	bool initrecursive();
	bool closerecursive();
};
/**************************************************************************************/
cApp::cApp()
{ 
  m_Width  = 640; //1024;
  m_Height = 480;//768;
  m_Style  = /*WS_BORDER | WS_CAPTION | WS_MINIMIZEBOX | WS_SYSMENU|*/WS_POPUP   ;
  strcpy(m_Class, "3D Game for Edutainment");
  strcpy(m_Caption, "Airport");

   m_Graphics.Init();
  D3DDISPLAYMODE d3ddm;
  m_Graphics.GetDirect3DCOM()->GetAdapterDisplayMode(D3DADAPTER_DEFAULT, &d3ddm);
  m_Height= d3ddm.Height;
  m_Width=  d3ddm.Width;
}
/**************************************************************************************/
BOOL cApp::Init()
{
  short i;

  // Initialize the graphics device and set display mode  
  m_Graphics.SetMode(GethWnd(),TRUE, TRUE);
  m_Graphics.SetPerspective(D3DX_PI/4, 1.3333f, 1.0f, 20000.0f);
  ShowMouse(TRUE);

  // Enable lighting and setup light
  m_Graphics.EnableLighting(TRUE);
  m_Graphics.SetAmbientLight(48,48,48);
  m_Graphics.EnableLight(0, TRUE);
  m_Light.SetAttenuation0(0.5f);
  m_Light.SetRange(1000.0f);

  // Initialize input and input devices
  m_Input.Init(GethWnd(), GethInst());
  m_Keyboard.Create(&m_Input, KEYBOARD);
  m_Mouse.Create(&m_Input, MOUSE, TRUE);  

/********************************/ 
  //init menu
/********************************/ 

  menu_yes = true;
  Array_yes= false;
  Stack_yes= false;
  Queue_yes= false;
  Linklist_yes= false;
  Recur_yes= false;

  // Load the mesh and create an NodeTree mesh from it  

  m_Mesh.Load(&m_Graphics,"GRAPHIC\\MENU\\airport.x", "GRAPHIC\\MENU\\");  
  m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);
  
  // Position view at origin
  m_XPos = m_YPos = m_ZPos = 0.0f;

  // Setup the sky box
  m_SkyBox.Create(&m_Graphics);

  //BENZ MD2 obj
  MD2.SetComponent(&m_NodeTreeMesh);
  m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
  MD2.Move(0,50,-400);   
/********************************/ 

  //BENZ MD2 animation
  MD2.SetFileAnimation("graphic\\knight\\tris.ini");	
  MD2.LoadAnimation("stand"); 

char *sky[6];
	sky[0] =	"..\\data//sky//hill//EnvYPos.bmp";
	sky[1] =	"..\\data//sky//hill//EnvYNeg.bmp";
	sky[2] =	"..\\data//sky//hill//EnvXNeg.bmp";
	sky[3] =	"..\\data//sky//hill//EnvXPos.bmp";
	sky[4] =	"..\\data//sky//hill//EnvZPos.bmp";
	sky[5] =	"..\\data//sky//hill//EnvZNeg.bmp";

	MD2.LoadModelMd2(&m_Graphics,"GRAPHIC//knight//tris.md2","GRAPHIC//knight//solo.bmp");
  for(i=0;i<6;i++)
    m_SkyBox.LoadTexture(i, sky[i]);
  // Initialize the sound system to play with
  m_Sound.Init(GethWnd());
  m_SndData.LoadWAV("..\\Data\\Cricket.wav");
  for(i=0;i<3;i++)
    m_SndChannel[i].Create(&m_Sound, &m_SndData);  
  m_Camera.Zoom(300);

/********************************/ 	
/********************************/ 	
	m_Title.Create(&m_Graphics,"Arial",70,TRUE);
	m_array.Create(&m_Graphics,"Arial",40,TRUE);
	m_stack.Create(&m_Graphics,"Arial",40,TRUE);
	m_showmouse.Create(&m_Graphics,"Arial",40,TRUE);
	m_queue.Create(&m_Graphics,"Arial",40,TRUE);
	m_linklist.Create(&m_Graphics,"Arial",40,TRUE);
	m_recur.Create(&m_Graphics,"Arial",40,TRUE);
	m_Window.Create(&m_Graphics,&m_Title);
	m_Window.Create(&m_Graphics,&m_array);
	m_Window.Create(&m_Graphics,&m_stack);
	m_Window.Create(&m_Graphics,&m_showmouse);
	m_Window.Create(&m_Graphics,&m_queue);
	m_Window.Create(&m_Graphics,&m_linklist);
	m_Window.Create(&m_Graphics,&m_recur);

/********************************/ 
/********************************/ 

  return TRUE;
}

BOOL cApp::Shutdown()
{
  // Free sounds
  for(short i=0;i<3;i++)
  m_SndChannel[i].Free();
  m_SndData.Free();
  m_Sound.Shutdown();

  // Free meshes
  m_NodeTreeMesh.Free();
  m_Mesh.Free();

  // Shutdown input
  m_Mouse.Free();
  m_Keyboard.Free();
  m_Input.Shutdown();

  // Shutdown graphics
  m_Graphics.Shutdown();
  MD2.Free();
  
  m_Window.Free();
/**************************/
//menu
/**************************/
  m_Title.Free();
  m_array.Free();
  m_stack.Free();
  m_showmouse.Free();
  m_queue.Free();
  m_linklist.Free();
  m_recur.Free();
/**************************/
//Array
/**************************/
  m_Font.Free();
  m_Window2.Free();
  m_Font2.Free();

	bgtext_r.Free();
	bgtext_b.Free();
	for(int chair_x=0;chair_x<4;chair_x++)
		for(int chair_y=0;chair_y<6;chair_y++)
			chair[chair_x][chair_y].Free();
/**************************/
//Stack
/**************************/
	boxs[0].Free();
	boxs[1].Free();
	boxs[2].Free();
	boxs[3].Free();
	boxs[4].Free();
	boxs[5].Free();
	boxs[6].Free();
	boxs[7].Free();
	boxs[8].Free();
	boxs[9].Free();
	boxs[10].Free();
	boxs[11].Free();
	boxs[12].Free();
	boxs[13].Free();
	boxs[14].Free();	
	boxs[15].Free();
	boxs[16].Free();
	boxs[17].Free();
	boxs[18].Free();
	boxs[19].Free();
	boxs[20].Free();
	boxs[21].Free();
	boxs[22].Free();
	boxs[23].Free();
/**************************/
//queue
/**************************/

bgtext_l.Free();
	bgtext_t.Free();

	Plane.Free();
	for(short j=0;j<7;j++)
		q_button[j].Free();
/**************************/
//linklist
/**************************/
	 door_lock.Free();
  box[0].Free();
  box[1].Free();
  box[2].Free();
  box[3].Free();
  box[4].Free();
  box[5].Free();
  box[6].Free();
  box[7].Free();
  box[8].Free();
  box[9].Free();  
	m_input.Free();
  m_showtime.Free();
/**************************/
//recursive
/**************************/
  b1.Free();
	b2.Free();
	b3.Free();
	b4.Free();
	b5.Free();
	F_Text.Free();
	W_Text.Free();
  return TRUE;
}

/////////////////////////////////////
//Frame Function
/////////////////////////////////////
BOOL cApp::Frame()
{
  static DWORD  Timer = timeGetTime();
  unsigned long Elapsed=0;

  D3DXVECTOR2   vecDir;
  cFrustum      Frustum,Frustum2;
  cLight        Light;
  char*			play = NULL; 
  static int moving=0;
  static int change=10,plate_p=3;
  static int disk_total=0,move_round=0;
  static float t_cur=-100,t_tmp=0,t_tar=100;
  static int type=0;
  char num_time[10];
	  
  // Reacquire input
  m_Mouse.Acquire(TRUE);

  // Calculate elapsed time (plus speed boost)
  Elapsed = (timeGetTime() - Timer);//delay 30 milisec
  Timer = timeGetTime();

  // Get input
  m_Keyboard.Read();

  if(menu_yes || Array_yes || Queue_yes || Linklist_yes)
	m_Mouse.Read();

  // Process input and update everything.
  // ESC quits program
  if(m_Keyboard.GetKeyState(KEY_ESC) == TRUE)
  {
	if(Array_yes)closearray();
	if(Stack_yes)closestack();
	if(Linklist_yes)closelinklist();
	if(Recur_yes)closerecursive();
	if(Queue_yes)closequeue();
    return FALSE;  
  }
	if(Linklist_yes || menu_yes)
		MD2.MoveDown(1);
  bool bmode=true;
 /********************************************/
  //Array
 /********************************************/
  if(Array_yes)
  {
	static char test1[50];	

	char test2[50];
	mouseX=m_Mouse.GetXPos();
	mouseY=m_Mouse.GetYPos();
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON) ==TRUE)
	{
		if(state==1)
		{
			n_col=6;
			n_row=6;
			ChkPosition(mouseX,mouseY);
			sentence2 = " ";
			if( (n_col!=6)&&(n_row!=6) )
			{
				checkclick=0;
				if( (n_col==targetX)&&(n_row==targetY))
				{
					strcpy(test1,"Access @ [");
					switch(n_col)
					{
						case 0 : strcat(test1,"A");break;
						case 1 : strcat(test1,"B");break;
						case 2 : strcat(test1,"C");break;
						case 3 : strcat(test1,"D");break;
					}
					strcat(test1,",");
					_itoa(n_row,test2,10);
					strcat(test1,test2);
					strcat(test1,"].");
					sentence2=test1;

					state=0;
					// and set color to that place
					chair_stat[n_col][n_row]=2;//rec
					tmpX=targetX;
					tmpY=targetY;
					targetX=6;
					if(targetX2!=6)
						state=1;
					score=score+20;
					maxscore=maxscore+20;
					count++;
					checkclick++;
					change=1;
				}
				if( (n_col==targetX2)&&(n_row==targetY2))
				{
					strcpy(test1,"Access @ [");
					switch(n_col)
					{
						case 0 : strcat(test1,"A");break;
						case 1 : strcat(test1,"B");break;
						case 2 : strcat(test1,"C");break;
						case 3 : strcat(test1,"D");break;
					}
					strcat(test1,",");
					_itoa(n_row,test2,10);
					strcat(test1,test2);
					strcat(test1,"].");
					sentence2=test1;

					state=0;
					// and set color to that place
					chair_stat[n_col][n_row]=2;//rec
					tmpX=targetX2;
					tmpY=targetY2;
					targetX2=6;
					if(targetX!=6)
						state=1;
					score=score+30;
					maxscore=maxscore+30;
					count++;
					checkclick++;
					change=1;
				}
				if( (checkclick==0)&&( (n_col!=tmpX)||(n_row!=tmpY) ) )
				{
					score=score-3;
					sentence2 = "Wrong Position!!";
					change=1;
				}
				if(state==0)
				{
					strcat(test1," Right Click for next.");
					sentence2=test1;
				}
			}
		}
	}
	if(m_Mouse.GetButtonState(MOUSE_RBUTTON) ==TRUE)
	{
		if(state==0)
		{
			sentence2=" ";
			targetX=6;
			targetY=6;
			targetX2=6;
			targetY2=6;
			tmpX=6;
			tmpY=6;
			SetEvent();
			change=1;
			state=1;
		}
	}
	//***** Mouse Input Check End*****//
	// IF stat==2 will appear red.

	if(chair_stat[0][0]==2)
			chair[0][0].Move(-279.0f,  25,-350.0f);
	if(chair_stat[1][0]==2)
			chair[1][0].Move(-279.0f,  25,-250.0f);
	if(chair_stat[2][0]==2)
			chair[2][0].Move(-279.0f,  25, -42.0f);
	if(chair_stat[3][0]==2)
			chair[3][0].Move(-279.0f,  25,  55.0f);
	if(chair_stat[0][1]==2)
			chair[0][1].Move(-198.0f,  25,-350.0f);
	if(chair_stat[1][1]==2)
			chair[1][1].Move(-198.0f,  25,-250.0f);
	if(chair_stat[2][1]==2)
			chair[2][1].Move(-198.0f,  25, -42.0f);
	if(chair_stat[3][1]==2)
			chair[3][1].Move(-198.0f,  25,  55.0f);
	if(chair_stat[0][2]==2)
			chair[0][2].Move(-117.0f,  25,-350.0f);
	if(chair_stat[1][2]==2)
			chair[1][2].Move(-117.0f,  25,-250.0f);
	if(chair_stat[2][2]==2)
			chair[2][2].Move(-117.0f,  25, -42.0f);
	if(chair_stat[3][2]==2)
			chair[3][2].Move(-117.0f,  25,  55.0f);
	if(chair_stat[0][3]==2)
			chair[0][3].Move( -37.0f,  25,-350.0f);
	if(chair_stat[1][3]==2)
			chair[1][3].Move( -37.0f,  25,-250.0f);
	if(chair_stat[2][3]==2)
			chair[2][3].Move( -37.0f,  25, -42.0f);
	if(chair_stat[3][3]==2)
			chair[3][3].Move( -37.0f,  25,  55.0f);
	if(chair_stat[0][4]==2)
			chair[0][4].Move(  44.0f,  25,-350.0f);
	if(chair_stat[1][4]==2)
			chair[1][4].Move(  44.0f,  25,-250.0f);
	if(chair_stat[2][4]==2)
			chair[2][4].Move(  44.0f,  25, -42.0f);
	if(chair_stat[3][4]==2)
			chair[3][4].Move(  44.0f,  25,  55.0f);
	if(chair_stat[0][5]==2)
			chair[0][5].Move( 125.0f,  25,-350.0f);
	if(chair_stat[1][5]==2)
			chair[1][5].Move( 125.0f,  25,-250.0f);
	if(chair_stat[2][5]==2)
			chair[2][5].Move( 125.0f,  25, -42.0f);
	if(chair_stat[3][5]==2)
			chair[3][5].Move( 125.0f,  25,  55.0f);

	//run score
	if(count==24&&state==1)
	{
		static char t_score[20];
		char n_score[20];
		strcpy(t_score,"SCORE = ");
		_itoa((int)(score*100/maxscore),n_score,10);
		strcat(t_score,n_score);
		strcat(t_score,"%");
		m_score=t_score;
		rank="Try Again!!";
		if((int)(score*100/maxscore)>=80)
			rank="Good";
		if((int)(score*100/maxscore)>=90)
			rank="Very Good.";
		if((int)(score*100/maxscore)==100)
			rank="PERFECT!!";
	}
  }
/********************************************/
/********************************************/
  //Stack
/********************************************/
	if(Stack_yes)
	{
		if(change>0)
	{
		Sleep(300);
	}

	if(end_count==6)
	{
//		sentence="Finish!!";
		sentence2="Finish!!";
		end_count=0;
		change=2;
		start=3;
	}

//***** check stack line is full?
	if(p_box[3][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(3);
		p_box[3][0] = 100;
		p_box[3][1] = 100;
		p_box[3][2] = 100;
		p_box[3][3] = 100;
		change=4;
		MoveTmp();
	}
	if(p_box[4][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(4);
		p_box[4][0] = 100;
		p_box[4][1] = 100;
		p_box[4][2] = 100;
		p_box[4][3] = 100;
		change=4;
		MoveTmp();
	}
	if(p_box[5][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(5);
		p_box[5][0] = 100;
		p_box[5][1] = 100;
		p_box[5][2] = 100;
		p_box[5][3] = 100;
		change=4;
		MoveTmp();
	}
	if(p_box[6][3]!=100)
	{
		Sleep(1000);
		KeepToTmp(6);
		p_box[6][0] = 100;
		p_box[6][1] = 100;
		p_box[6][2] = 100;
		p_box[6][3] = 100;
		change=4;
		MoveTmp();
	}
	if(change==3)
	{
		Move_Box();
		Move_Stack(plate_p);
		change=1;
	}
//******************************************* begin move
	// Left
	if(moving==1)
	{
		if(change==0)
		{
			if(plate_p>0)plate_p--;
			Move_Stack(plate_p);
			change=2;
			moving=0;
			if(start==0)start=1;
		}
	}
	// Right
	if(moving==2)
	{
		if(change==0)
		{
			if(plate_p<6)
			{
				plate_p++;
				Move_Stack(plate_p);
			}
			change=2;
			moving=0;
			if(start==0)start=1;
		}
	}
	// POP Up
	if(moving==3)
	{
		if(change==0)
		{
			if(start==0)start=1;
			sentence="Stack : Can't POP here!";
			if(plate_p>=3&&plate_p<=6)
			{
				sentence="Stack : Can't POP!";
				if(p_box[plate_p][0]==100&&p_box[plate_p][1]==100&&p_box[plate_p][2]==100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][0]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][0]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][0]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
				else if(p_box[plate_p][0]!=100&&p_box[plate_p][1]==100&&p_box[plate_p][2]==100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][1]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][1]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][1]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
				else if(p_box[plate_p][0]!=100&&p_box[plate_p][1]!=100&&p_box[plate_p][2]==100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][2]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][2]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][2]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
				else if(p_box[plate_p][0]!=100&&p_box[plate_p][1]!=100&&p_box[plate_p][2]!=100&&p_box[plate_p][3]==100)
				{
					if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100&&plate_p==b_color[p_stack[2]])
					{
						p_box[plate_p][3]=p_stack[2];
						p_stack[2]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[1]])
					{
						p_box[plate_p][3]=p_stack[1];
						p_stack[1]=100;
						moving=0;
						change=1;
					}
					if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100&&plate_p==b_color[p_stack[0]])
					{
						p_box[plate_p][3]=p_stack[0];
						p_stack[0]=100;
						moving=0;
						change=1;
					}
					Move_Box();
					Move_Stack(plate_p);
				}
			}
			if(change==1)
			{
				sentence="Stack : POP!";
				change++;
			}
		}
	}
	// PUSH Down
	if(moving==4)
	{
		if(change==0)
		{
			if(start==0)start=1;
			sentence= "Stack : Can't PUSH here!";
			if(plate_p>=0&&plate_p<=2)
			{
				sentence= "Stack : Can't PUSH!";
				if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100)
				{
					p_stack[0] = p_box[plate_p][3];
					p_box[plate_p][3] = p_box[plate_p][2];
					p_box[plate_p][2] = p_box[plate_p][1];
					p_box[plate_p][1] = p_box[plate_p][0];
					p_box[plate_p][0] = b_tmp[0];
					ReQueueBox();
					// and relist of queue
					Move_Box();
					MoveTmp();
					Move_Stack(plate_p);
					moving=0;
					change=1;
				}
				if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100)
				{
					p_stack[1] = p_box[plate_p][3];
					p_box[plate_p][3] = p_box[plate_p][2];
					p_box[plate_p][2] = p_box[plate_p][1];
					p_box[plate_p][1] = p_box[plate_p][0];
					p_box[plate_p][0] = b_tmp[0];
					ReQueueBox();
					// and relist of queue
					Move_Box();
					MoveTmp();
					Move_Stack(plate_p);
					moving=0;
					change=1;
				}
				if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]==100)
				{
					p_stack[2] = p_box[plate_p][3];
					p_box[plate_p][3] = p_box[plate_p][2];
					p_box[plate_p][2] = p_box[plate_p][1];
					p_box[plate_p][1] = p_box[plate_p][0];
					p_box[plate_p][0] = b_tmp[0];
					ReQueueBox();
					// and relist of queue
					Move_Box();
					MoveTmp();
					Move_Stack(plate_p);
					moving=0;
					change=1;
				}
				if(change==1)
				{
					sentence= "Stack : PUSH!";
					change++;
				}
			}
		}
	}


//******************************************* end move
//***** Key Input Check start*****//


	if(m_Keyboard.GetKeyState(KEY_LEFT) == TRUE)
	{
		if(change==0)
		{
			moving=1;
			change=1;
		}
	}
	if(m_Keyboard.GetKeyState(KEY_RIGHT) == TRUE)
	{
		if(change==0)
		{
			moving=2;
			change=1;
		}
	}
	if(m_Keyboard.GetKeyState(KEY_UP) == TRUE)
	{
		if(change==0)
		{
			moving=3;
			change=1;
		}
	}
	if(m_Keyboard.GetKeyState(KEY_DOWN) == TRUE)
	{
		if(change==0)
		{
			moving=4;
			change=1;
		}
	}

	ChkSen2();
	//***** Key Input Check end*****//

	if(start==1)	// set time!
	{
		start=2;
		s_time=time(0);
	}
	if(start==2)	// show time!
	{
		//t_time-(time(0)-s_time)
		strcpy(&text_time[0],"Time : ");
		_itoa((t_time-(time(0)-s_time)),num_time,10);
		strcat(&text_time[0],num_time);
		change=1;
	}

	if((t_time-(time(0)-s_time)<=0)||start==3)	//FINISH
	{
		strcpy(&text_time[0],"Time : ");
		_itoa((t_time-(time(0)-s_time)),num_time,10);
		strcat(&text_time[0],num_time);
		sentence2="Finish!!";
		rank="Very Good!!!!";
		if(t_time-(time(0)-s_time)<=60)
			rank="Good.";
		if(t_time-(time(0)-s_time)<=40)
			rank="Slow.";
		if(t_time-(time(0)-s_time)<=20)
			rank="Very Slow.";
		if(t_time-(time(0)-s_time)<=0)
			rank="Try Again.";
	}
	}
/********************************************/
  //Queue
/********************************************/
	if(Queue_yes)
	{
		char num_score[10],num_time[10];
		zone=7;
		if(m_Mouse.GetButtonState(MOUSE_LBUTTON) ==TRUE && start!=3)
	{
		if(start==0)
		{
			s_time=time(0);
			start=1;
		}
		mouseX=m_Mouse.GetXPos();
		mouseY=m_Mouse.GetYPos();
		
		// zone 0 landing
		if( (mouseX>=50)&&(mouseX<=180)&&(mouseY>=155)&&(mouseY<=183)&&(status[0]==1)&&(park<3) )
		{
			zone=0;
			strcpy(&q_text[13][0],&q_text[5][0]);
			park++;
		}
		// zone 1
		if( (mouseX>=50)&&(mouseX<=180)&&(mouseY>=255)&&(mouseY<=283)&&(status[1]==1)&&(park<3) )
		{
			zone=1;
			strcpy(&q_text[13][0],&q_text[6][0]);
			park++;
		}
		// zone 2
		if( (mouseX>=50)&&(mouseX<=180)&&(mouseY>=355)&&(mouseY<=383)&&(status[2]==1)&&(park<3) )
		{
			zone=2;
			strcpy(&q_text[13][0],&q_text[7][0]);
			park++;
		}
		// zone 3 take off
		if( (mouseX>=845)&&(mouseX<=980)&&(mouseY>=155)&&(mouseY<=183)&&(status[3]==1) )
		{
			zone=3;
			strcpy(&q_text[13][0],&q_text[9][0]);
		}
		// zone 4
		if( (mouseX>=845)&&(mouseX<=980)&&(mouseY>=255)&&(mouseY<=283)&&(status[4]==1) )
		{
			zone=4;
			strcpy(&q_text[13][0],&q_text[10][0]);
		}
		// zone 5
		if( (mouseX>=845)&&(mouseX<=980)&&(mouseY>=355)&&(mouseY<=383)&&(status[5]==1) )
		{
			zone=5;
			strcpy(&q_text[13][0],&q_text[11][0]);
		}

		if(status[zone]==1)
		{
			for(int i=0;i<4;i++)
			{
				if(queue[i]==7)
				{
					queue[i]=zone;
					status[zone]=2;
					color[zone][0]=250;
					color[zone][1]=190;
					color[zone][2]=125;
					strcpy(&q_text[1][0],"Enqueue(");
					strcat(&q_text[1][0],&q_text[13][0]);
					strcat(&q_text[1][0],")");
					if(state==0)
						q_button[6].Move(205.0f,230,-90.0f);
					i=4;
				}
			}
		}

		// zone queue for DEQUEUE
		if( (mouseX>=252)&&(mouseX<=285)&&(mouseY>=122)&&(mouseY<=155) )
		{
			if((queue[0]!=7)&&(state==0))
			{
				// DeQueue // 0 1 2 will goto take off list
				if(queue[0]==0)
				{
					state=2;
					color[0][0]=130;
					color[0][1]=240;
					color[0][2]=220;
					//find empty position
					if(status[3]==0)
					{
						strcpy(&q_text[9][0],&q_text[5][0]);
						status[3]=1;
					}
					else if(status[4]==0)
					{
						strcpy(&q_text[10][0],&q_text[5][0]);
						status[4]=1;
					}
					else if(status[5]==0)
					{
						strcpy(&q_text[11][0],&q_text[5][0]);
						status[5]=1;
					}
					strcpy(&q_text[13][0],&q_text[5][0]);
					RandName(&q_text[5][0]);
					status[0]=1;
					zone=7;
				}
				if(queue[0]==1)
				{
					state=2;
					color[1][0]=130;
					color[1][1]=240;
					color[1][2]=220;
					//find empty position
					if(status[3]==0)
					{
						strcpy(&q_text[9][0],&q_text[6][0]);
						status[3]=1;
					}
					else if(status[4]==0)
					{
						strcpy(&q_text[10][0],&q_text[6][0]);
						status[4]=1;
					}
					else if(status[5]==0)
					{
						strcpy(&q_text[11][0],&q_text[6][0]);
						status[5]=1;
					}
					strcpy(&q_text[13][0],&q_text[6][0]);
					RandName(&q_text[6][0]);
					status[1]=1;
					zone=7;
				}
				if(queue[0]==2)
				{
					state=2;
					color[2][0]=130;
					color[2][1]=240;
					color[2][2]=220;
					//find empty position
					if(status[3]==0)
					{
						strcpy(&q_text[9][0],&q_text[7][0]);
						status[3]=1;
					}
					else if(status[4]==0)
					{
						strcpy(&q_text[10][0],&q_text[7][0]);
						status[4]=1;
					}
					else if(status[5]==0)
					{
						strcpy(&q_text[11][0],&q_text[7][0]);
						status[5]=1;
					}
					strcpy(&q_text[13][0],&q_text[7][0]);
					RandName(&q_text[7][0]);
					status[2]=1;
					zone=7;
				}
				if(queue[0]==3)
				{
					state=1;
					color[3][0]=130;
					color[3][1]=240;
					color[3][2]=220;
					strcpy(&q_text[13][0],&q_text[9][0]);
					strcpy(&q_text[9][0]," ");
					status[3]=0;
					zone=7;
					park--;
				}
				if(queue[0]==4)
				{
					state=1;
					color[4][0]=130;
					color[4][1]=240;
					color[4][2]=220;
					strcpy(&q_text[13][0],&q_text[10][0]);
					strcpy(&q_text[10][0]," ");
					status[4]=0;
					zone=7;
					park--;
				}
				if(queue[0]==5)
				{
					state=1;
					color[5][0]=130;
					color[5][1]=240;
					color[5][2]=220;
					strcpy(&q_text[13][0],&q_text[11][0]);
					strcpy(&q_text[11][0]," ");
					status[5]=0;
					zone=7;
					park--;
				}
				strcpy(&q_text[1][0],"Dequeue");
				strcpy(&q_text[12][0],"Plane : ");
				strcat(&q_text[12][0],&q_text[13][0]);
				q_button[6].Move(205.0f,-230,-90.0f);
				score=score+10;
				strcpy(&text_score[0],"Score : ");
				_itoa(score,num_score,10);
				strcat(&text_score[0],num_score);
				round=0;
				queue[0]=queue[1];
				queue[1]=queue[2];
				queue[2]=queue[3];
				queue[3]=7;
			}
		}
		change=1;
	}
	//***** Acting *****//

	if(state==1)	// Take Off
	{
		MoveTakeoff(round);
		round++;
		change=1;
	}
	if(state==2)	// Landing
	{
		MoveLanding(round);
		round++;
		change=1;
	}

	if(start==1)	// show time!
	{
		//t_time-(time(0)-s_time)
		strcpy(&text_time[0],"Time : ");
		_itoa((t_time-(time(0)-s_time)),num_time,10);
		strcat(&text_time[0],num_time);
		change=1;
	}

	if(t_time-(time(0)-s_time)<=0)	//FINISH
	{
		strcpy(&q_text[1][0],"TIME OUT!! ^^b");
		start=3;
	}

	if(status[0]==1)
		q_button[0].Move(252.0f, 250,-112.0f);
	else
		q_button[0].Move(252.0f,-250,-112.0f);

	if(status[1]==1)
		q_button[1].Move(277.0f, 230,-111.3f);
	else
		q_button[1].Move(277.0f,-230,-111.3f);

	if(status[2]==1)
		q_button[2].Move(302.0f, 210,-110.6f);
	else
		q_button[2].Move(302.0f,-210,-110.6f);

	if(status[3]==1)
		q_button[3].Move(252.0f, 250,112.0f);
	else
		q_button[3].Move(252.0f,-250,112.0f);

	if(status[4]==1)
		q_button[4].Move(277.0f, 230,111.0f);
	else
		q_button[4].Move(277.0f,-230,111.0f);

	if(status[5]==1)
		q_button[5].Move(302.0f, 210,110.0f);
	else
		q_button[5].Move(302.0f,-210,110.0f);
	}
/********************************************/
  //linklist
/********************************************/
	if(Linklist_yes)
	{
		if(!keyboard)
		 {
		  if(m_Keyboard.GetKeyState(KEY_UP) == TRUE) 
		  {
			  pos_state++;
			  if(pos_state > 2)pos_state = 2;   
			  MD2.Move(c_Lpos[pos_state],50,c_Wpos[pos_state]);
			  Sleep(150);
	 
		  }
		  if(m_Keyboard.GetKeyState(KEY_DOWN) == TRUE) 
		  {
			  pos_state--;
			  if(pos_state < 0)pos_state = 0;   
			  MD2.Move(c_Lpos[pos_state],50,c_Wpos[pos_state]);
			  Sleep(150);
		  } 
		}
	}
/********************************************/
/********************************************/
  //recursive
/********************************************/
	if(Recur_yes)
	{
		if(m_Keyboard.GetKeyState(KEY_NUMPAD1) == TRUE)
		delay=200;
		if(m_Keyboard.GetKeyState(KEY_NUMPAD2) == TRUE)
		delay=1000;
		if(m_Keyboard.GetKeyState(KEY_NUMPAD3) == TRUE)
			delay=2000;
		if(m_Keyboard.GetKeyState(KEY_NUMPAD4) == TRUE)
		delay=3000;
		if(m_Keyboard.GetKeyState(KEY_NUMPAD5) == TRUE)
		delay=5000;

		if(move_round>0)
	{
		Sleep(delay);
	}
	if(disk_total==3)
	{
		switch(move_round)
		{
			case 0  : if(type==0)
					  {
						  M_Recur[0]="move(3,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 1  : if(type==0)M_Recur[4]="move(2,A,C,B)";
					  if(type==1)M_Recur[4]="move(2,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 2  : if(type==0)
					  {
						  M_Recur[0]="move(2,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 3  : if(type==0)M_Recur[4]="move(1,A,B,C)";
					  if(type==1)M_Recur[4]="move(1,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 4  : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 5  : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f,  0,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 6  : if(type==0)	/* Back Track*/
					  {
						  M_Recur[0]="move(2,A,C,B)";
						  M_Recur[4]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
						  M_Recur[4]="move(1,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[5]="move 2 to B";
					  b2.Move(-200.0f,  0,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 7  : if(type==0)M_Recur[6]="move(1,C,A,B)";
					  if(type==1)M_Recur[6]="move(1,A,C,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 8  : if(type==0)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 9  : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 10,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 10 : if(type==0)	/* Back Track*//* Back Track*/
					  {
						  M_Recur[0]="move(3,A,B,C)";
						  M_Recur[4]="move(2,A,C,B)";
						  M_Recur[5]="move 3 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,B,A)";
						  M_Recur[4]="move(2,C,A,B)";
						  M_Recur[5]="move 3 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  b3.Move(-200.0f,  0,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 11 : if(type==0)M_Recur[6]="move(2,B,A,C)";
					  if(type==1)M_Recur[6]="move(2,B,C,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 12 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 13 : if(type==0)M_Recur[4]="move(1,B,C,A)";
					  if(type==1)M_Recur[4]="move(1,B,A,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 14 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 15 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f,  0,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 16 : if(type==0)	/* Back Track*/
					  {
						  M_Recur[0]="move(2,B,A,C)";
						  M_Recur[4]="move(1,B,C,A)";
						  M_Recur[5]="move 2 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
						  M_Recur[4]="move(1,B,A,C)";
						  M_Recur[5]="move 2 to C";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  b2.Move(-200.0f, 10,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 17 : if(type==0)M_Recur[6]="move(1,A,B,C)";
					  if(type==1)M_Recur[6]="move(1,C,B,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 18 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 19 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 20,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
		}
		change=10;
		move_round++;
		if(move_round>20)
		{
			red[2]=255;green[2]=200;blue[2]=200;
			M_Recur[0]="move(level,current,temp,target)";
			M_Recur[2]="move 1 to target";
			disk_total=0;
			t_tmp = t_tar;
			t_tar = t_cur;
			t_cur = t_tmp;
			t_tmp = 0;
			move_round=0;
		}
	}

	if(disk_total==4)
	{
		switch(move_round)
		{
			case 0  : if(type==0)
					  {
						  M_Recur[0]="move(4,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(4,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 1  : if(type==0)M_Recur[4]="move(3,A,C,B)";
					  if(type==1)M_Recur[4]="move(3,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 2  : if(type==0)
					  {
						  M_Recur[0]="move(3,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 3  : if(type==0)M_Recur[4]="move(2,A,B,C)";
					  if(type==1)M_Recur[4]="move(2,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 4  : if(type==0)
					  {
						  M_Recur[0]="move(2,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 5  : if(type==0)M_Recur[4]="move(1,A,C,B)";
					  if(type==1)M_Recur[4]="move(1,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 6  : if(type==0)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 7  : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f,  0,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 8  : if(type==0)
					  {
						  M_Recur[0]="move(2,A,B,C)";
						  M_Recur[4]="move(1,A,C,B)";
						  M_Recur[5]="move 2 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,B,A)";
						  M_Recur[4]="move(1,C,A,B)";
						  M_Recur[5]="move 2 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  b2.Move(-200.0f,  0,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 9  : if(type==0)M_Recur[6]="move(1,B,A,C)";
					  if(type==1)M_Recur[6]="move(1,B,C,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 10 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 11 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 10,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 12 : if(type==0)
					  {
						  M_Recur[0]="move(3,A,C,B)";
						  M_Recur[4]="move(2,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,A,B)";
						  M_Recur[4]="move(2,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[5]="move 3 to B";
					  b3.Move(-200.0f,  0,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 13 : if(type==0)M_Recur[6]="move(2,C,A,B)";
					  if(type==1)M_Recur[6]="move(2,A,C,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 14 : if(type==0)
					  {
						  M_Recur[0]="move(2,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,A,C,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 15 : if(type==0)M_Recur[4]="move(1,C,B,A)";
					  if(type==1)M_Recur[4]="move(1,A,B,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 16 : if(type==0)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 17 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f, 10,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 18 : if(type==0)
					  {
						  M_Recur[0]="move(2,C,A,B)";
						  M_Recur[4]="move(1,C,B,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,A,C,B)";
						  M_Recur[4]="move(1,A,B,C)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[5]="move 2 to B";
					  b2.Move(-200.0f, 10,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 19 : if(type==0)M_Recur[6]="move(1,A,C,B)";
					  if(type==1)M_Recur[6]="move(1,C,A,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 20 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 21 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 20,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
					  /* BACK TRACK MOVE 4*/
			case 22 : if(type==0)
					  {
						  M_Recur[0]="move(4,A,B,C)";
						  M_Recur[4]="move(3,A,C,B)";
						  M_Recur[5]="move 4 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(4,C,B,A)";
						  M_Recur[4]="move(3,C,A,B)";
						  M_Recur[5]="move 4 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  b4.Move(-200.0f,  0,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 23 : if(type==0)M_Recur[6]="move(3,B,A,C)";
					  if(type==1)M_Recur[6]="move(3,B,C,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 24 : if(type==0)
					  {
						  M_Recur[0]="move(3,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,B,C,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 25 : if(type==0)M_Recur[4]="move(2,B,C,A)";
					  if(type==1)M_Recur[4]="move(2,B,A,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 26 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,A,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 27 : if(type==0)M_Recur[4]="move(1,B,A,C)";
					  if(type==1)M_Recur[4]="move(1,B,C,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 28 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 29 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 10,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 30 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,C,A)";
						  M_Recur[4]="move(1,B,A,C)";
						  M_Recur[5]="move 2 to A";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,A,C)";
						  M_Recur[4]="move(1,B,C,A)";
						  M_Recur[5]="move 2 to C";
					  }
					  M_Recur[2]="move 1 to target";
					  b2.Move(-200.0f,  0,t_cur);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 31 : if(type==0)M_Recur[6]="move(1,C,B,A)";
					  if(type==1)M_Recur[6]="move(1,A,B,C)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 32 : if(type==0)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 33 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f, 10,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 34 : if(type==0)
					  {
						  M_Recur[0]="move(3,B,A,C)";
						  M_Recur[4]="move(2,B,C,A)";
						  M_Recur[5]="move 3 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,B,C,A)";
						  M_Recur[4]="move(2,B,A,C)";
						  M_Recur[5]="move 3 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  b3.Move(-200.0f, 10,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 35 : if(type==0)M_Recur[6]="move(2,A,B,C)";
					  if(type==1)M_Recur[6]="move(2,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 36 : if(type==0)
					  {
						  M_Recur[0]="move(2,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 37 : if(type==0)M_Recur[4]="move(1,A,C,B)";
					  if(type==1)M_Recur[4]="move(1,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 38 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 39 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f,  0,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 40 : if(type==0)
					  {
						  M_Recur[0]="move(2,A,B,C)";
						  M_Recur[4]="move(1,A,C,B)";
						  M_Recur[5]="move 2 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,B,A)";
						  M_Recur[4]="move(1,C,A,B)";
						  M_Recur[5]="move 2 to A";
					  }
					  b2.Move(-200.0f, 20,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 41 : if(type==0)M_Recur[6]="move(1,B,A,C)";
					  if(type==1)M_Recur[6]="move(1,B,C,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 42 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 43 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 30,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
		}
		change=10;
		move_round++;
		if(move_round>44)
		{
			red[2]=255;green[2]=200;blue[2]=200;
			M_Recur[0]="move(level,current,temp,target)";
			M_Recur[2]="move 1 to target";
			disk_total=0;
			t_tmp = t_tar;
			t_tar = t_cur;
			t_cur = t_tmp;
			t_tmp = 0;
			move_round=0;
		}
	}

	if(disk_total==5)
	{
		switch(move_round)
		{
			case 0  : if(type==0)
					  {
						  M_Recur[0]="move(5,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(5,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 1  : if(type==0)M_Recur[4]="move(4,A,C,B)";
					  if(type==1)M_Recur[4]="move(4,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 2  : if(type==0)
					  {
						  M_Recur[0]="move(4,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(4,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 3  : if(type==0)M_Recur[4]="move(3,A,B,C)";
					  if(type==1)M_Recur[4]="move(3,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 4  : if(type==0)
					  {
						  M_Recur[0]="move(3,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 5  : if(type==0)M_Recur[4]="move(2,A,C,B)";
					  if(type==1)M_Recur[4]="move(2,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 6  : if(type==0)
					  {
						  M_Recur[0]="move(2,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 7  : if(type==0)M_Recur[4]="move(1,A,B,C)";
					  if(type==1)M_Recur[4]="move(1,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 8  : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 9  : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f,  0,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 10 : if(type==0)	/* Back Track*/
					  {
						  M_Recur[0]="move(2,A,C,B)";
						  M_Recur[4]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
						  M_Recur[4]="move(1,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[5]="move 2 to B";
					  b2.Move(-200.0f,  0,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 11 : if(type==0)M_Recur[6]="move(1,C,A,B)";
					  if(type==1)M_Recur[6]="move(1,A,C,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 12 : if(type==0)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 13 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 10,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 14 : if(type==0)	/* Back Track*//* Back Track*/
					  {
						  M_Recur[0]="move(3,A,B,C)";
						  M_Recur[4]="move(2,A,C,B)";
						  M_Recur[5]="move 3 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,B,A)";
						  M_Recur[4]="move(2,C,A,B)";
						  M_Recur[5]="move 3 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  b3.Move(-200.0f,  0,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 15 : if(type==0)M_Recur[6]="move(2,B,A,C)";
					  if(type==1)M_Recur[6]="move(2,B,C,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 16 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 17 : if(type==0)M_Recur[4]="move(1,B,C,A)";
					  if(type==1)M_Recur[4]="move(1,B,A,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 18 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 19 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f, 20,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 20 : if(type==0)	/* Back Track*/
					  {
						  M_Recur[0]="move(2,B,A,C)";
						  M_Recur[4]="move(1,B,C,A)";
						  M_Recur[5]="move 2 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
						  M_Recur[4]="move(1,B,A,C)";
						  M_Recur[5]="move 2 to C";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  b2.Move(-200.0f, 10,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 21 : if(type==0)M_Recur[6]="move(1,A,B,C)";
					  if(type==1)M_Recur[6]="move(1,C,B,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 22 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 23 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 20,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 24 : if(type==0)
					  {
						  M_Recur[0]="move(4,A,C,B)";
						  M_Recur[4]="move(3,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(4,C,A,B)";
						  M_Recur[4]="move(3,C,B,A)";
					  }
					  M_Recur[5]="move 4 to B";
					  b4.Move(-200.0f,  0,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 25 : if(type==0)M_Recur[6]="move(3,C,A,B)";
					  if(type==1)M_Recur[6]="move(3,A,C,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 26 : if(type==0)
					  {
						  M_Recur[0]="move(3,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,A,C,B)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 27 : if(type==0)M_Recur[4]="move(2,C,B,A)";
					  if(type==1)M_Recur[4]="move(2,A,B,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 28 : if(type==0)
					  {
						  M_Recur[0]="move(2,C,B,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,A,B,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 29 : if(type==0)M_Recur[4]="move(1,C,A,B)";
					  if(type==1)M_Recur[4]="move(1,A,C,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 30 : if(type==0)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 31 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 10,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 32 : if(type==0)	/* Back Track*/
					  {
						  M_Recur[0]="move(2,C,B,A)";
						  M_Recur[4]="move(1,C,A,B)";
						  M_Recur[5]="move 2 to A";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,A,B,C)";
						  M_Recur[4]="move(1,A,C,B)";
						  M_Recur[5]="move 2 to C";
					  }
					  M_Recur[2]="move 1 to target";
					  b2.Move(-200.0f, 10,t_cur);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 33 : if(type==0)M_Recur[6]="move(1,B,C,A)";
					  if(type==1)M_Recur[6]="move(1,B,A,C)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 34 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 35 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f, 20,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 36 : if(type==0)	/* Back Track*//* Back Track*/
					  {
						  M_Recur[0]="move(3,C,A,B)";
						  M_Recur[4]="move(2,C,B,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,A,C,B)";
						  M_Recur[4]="move(2,A,B,C)";
					  }
					  M_Recur[5]="move 3 to B";
					  M_Recur[2]="move 1 to target";
					  b3.Move(-200.0f, 10,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 37 : if(type==0)M_Recur[6]="move(2,A,C,B)";
					  if(type==1)M_Recur[6]="move(2,C,A,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 38 : if(type==0)
					  {
						  M_Recur[0]="move(2,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 39 : if(type==0)M_Recur[4]="move(1,A,B,C)";
					  if(type==1)M_Recur[4]="move(1,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 40 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 41 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f,  0,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 42 : if(type==0)	/* Back Track*/
					  {
						  M_Recur[0]="move(2,A,C,B)";
						  M_Recur[4]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
						  M_Recur[4]="move(1,C,B,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[5]="move 2 to B";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  b2.Move(-200.0f, 20,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 43 : if(type==0)M_Recur[6]="move(1,A,C,B)";
					  if(type==1)M_Recur[6]="move(1,C,A,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 44 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 45 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 30,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 46 : if(type==0)
					  {
						  M_Recur[0]="move(5,A,B,C)";
						  M_Recur[4]="move(4,A,C,B)";
						  M_Recur[5]="move 5 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(5,C,B,A)";
						  M_Recur[4]="move(4,C,A,B)";
						  M_Recur[5]="move 5 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  b5.Move(-200.0f,  0,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
					  /******5 move ****/
					  /* now move 4 from b to c*/
			case 47 : if(type==0)M_Recur[6]="move(4,B,A,C)";
					  if(type==1)M_Recur[6]="move(4,B,C,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 48 : if(type==0)
					  {
						  M_Recur[0]="move(4,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(4,B,C,A)";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 49 : if(type==0)M_Recur[4]="move(3,B,C,A)";
					  if(type==1)M_Recur[4]="move(3,B,A,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 50 : if(type==0)
					  {
						  M_Recur[0]="move(3,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,B,A,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 51 : if(type==0)M_Recur[4]="move(2,B,A,C)";
					  if(type==1)M_Recur[4]="move(2,B,C,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 52 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 53 : if(type==0)M_Recur[4]="move(1,B,C,A)";
					  if(type==1)M_Recur[4]="move(1,B,A,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 54 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 55 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f,  0,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 56 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,A,C)";
						  M_Recur[4]="move(1,B,C,A)";
						  M_Recur[5]="move 2 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
						  M_Recur[4]="move(1,B,A,C)";
						  M_Recur[5]="move 2 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  b2.Move(-200.0f, 10,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 57 : if(type==0)M_Recur[6]="move(1,A,B,C)";
					  if(type==1)M_Recur[6]="move(1,C,B,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 58 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 59 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 20,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 60 : if(type==0)
					  {
						  M_Recur[0]="move(3,B,C,A)";
						  M_Recur[4]="move(2,B,A,C)";
						  M_Recur[5]="move 3 to A";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,B,A,C)";
						  M_Recur[4]="move(2,B,C,A)";
						  M_Recur[5]="move 3 to C";
					  }
					  M_Recur[2]="move 1 to target";
					  b3.Move(-200.0f,  0,t_cur);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 61 : if(type==0)M_Recur[6]="move(2,C,B,A)";
					  if(type==1)M_Recur[6]="move(2,A,B,C)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 62 : if(type==0)
					  {
						  M_Recur[0]="move(2,C,B,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,A,B,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 63 : if(type==0)M_Recur[4]="move(1,C,A,B)";
					  if(type==1)M_Recur[4]="move(1,A,C,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 64 : if(type==0)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 65 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 10,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 66 : if(type==0)
					  {
						  M_Recur[0]="move(2,C,B,A)";
						  M_Recur[4]="move(1,C,A,B)";
						  M_Recur[5]="move 2 to A";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,A,B,C)";
						  M_Recur[4]="move(1,A,C,B)";
						  M_Recur[5]="move 2 to C";
					  }
					  M_Recur[2]="move 1 to target";
					  b2.Move(-200.0f, 10,t_cur);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 67 : if(type==0)M_Recur[6]="move(1,B,C,A)";
					  if(type==1)M_Recur[6]="move(1,B,A,C)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 68 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 69 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f, 20,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
					  /* BACK TRACK MOVE 4*/
			case 70 : if(type==0)
					  {
						  M_Recur[0]="move(4,B,A,C)";
						  M_Recur[4]="move(3,B,C,A)";
						  M_Recur[5]="move 4 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(4,B,C,A)";
						  M_Recur[4]="move(3,B,A,C)";
						  M_Recur[5]="move 4 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  b4.Move(-200.0f, 10,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 71 : if(type==0)M_Recur[6]="move(3,A,B,C)";
					  if(type==1)M_Recur[6]="move(3,C,B,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 72 : if(type==0)
					  {
						  M_Recur[0]="move(3,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 73 : if(type==0)M_Recur[4]="move(2,A,C,B)";
					  if(type==1)M_Recur[4]="move(2,C,A,B)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 74 : if(type==0)
					  {
						  M_Recur[0]="move(2,A,C,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 75 : if(type==0)M_Recur[4]="move(1,A,B,C)";
					  if(type==1)M_Recur[4]="move(1,C,B,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 76 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 77 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 20,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 78 : if(type==0)
					  {
						  M_Recur[0]="move(2,A,C,B)";
						  M_Recur[4]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,C,A,B)";
						  M_Recur[4]="move(1,C,B,A)";
					  }
					  M_Recur[5]="move 2 to B";
					  M_Recur[2]="move 1 to target";
					  b2.Move(-200.0f,  0,t_tmp);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 79 : if(type==0)M_Recur[6]="move(1,C,A,B)";
					  if(type==1)M_Recur[6]="move(1,A,C,B)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 80 : if(type==0)
					  {
						  M_Recur[0]="move(1,C,A,B)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,A,C,B)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 81 : M_Recur[2]="move 1 to B";
					  b1.Move(-200.0f, 10,t_tmp);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 82 : if(type==0)
					  {
						  M_Recur[0]="move(3,A,B,C)";
						  M_Recur[4]="move(2,A,C,B)";
						  M_Recur[5]="move 3 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(3,C,B,A)";
						  M_Recur[4]="move(2,C,A,B)";
						  M_Recur[5]="move 3 to A";
					  }
					  M_Recur[2]="move 1 to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  b3.Move(-200.0f, 20,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 83 : if(type==0)M_Recur[6]="move(2,B,A,C)";
					  if(type==1)M_Recur[6]="move(2,B,C,A)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 84 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,A,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 85 : if(type==0)M_Recur[4]="move(1,B,C,A)";
					  if(type==1)M_Recur[4]="move(1,B,A,C)";
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[4]=50;green[4]=255;blue[4]=50;
					  break;
			case 86 : if(type==0)
					  {
						  M_Recur[0]="move(1,B,C,A)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,B,A,C)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  red[4]=255;green[4]=200;blue[4]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 87 : if(type==0)M_Recur[2]="move 1 to A";
					  if(type==1)M_Recur[2]="move 1 to C";
					  b1.Move(-200.0f,  0,t_cur);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
			case 88 : if(type==0)
					  {
						  M_Recur[0]="move(2,B,A,C)";
						  M_Recur[4]="move(1,B,C,A)";
						  M_Recur[5]="move 2 to C";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(2,B,C,A)";
						  M_Recur[4]="move(1,B,A,C)";
						  M_Recur[5]="move 2 to A";
					  }
					  b2.Move(-200.0f, 30,t_tar);
					  red[2]=255;green[2]=200;blue[2]=200;
					  red[5]=50;green[5]=255;blue[5]=50;
					  break;
			case 89 : if(type==0)M_Recur[6]="move(1,A,B,C)";
					  if(type==1)M_Recur[6]="move(1,C,B,A)";
					  red[5]=255;green[5]=200;blue[5]=200;
					  red[6]=50;green[6]=255;blue[6]=50;
					  break;
			case 90 : if(type==0)
					  {
						  M_Recur[0]="move(1,A,B,C)";
					  }
					  if(type==1)
					  {
						  M_Recur[0]="move(1,C,B,A)";
					  }
					  M_Recur[4]="move(level-1,current,target,temp)";
					  M_Recur[5]="move level to target";
					  M_Recur[6]="move(level-1,temp,current,target)";
					  red[6]=255;green[6]=200;blue[6]=200;
					  red[0]=50;green[0]=255;blue[0]=50;
					  break;
			case 91 : if(type==0)M_Recur[2]="move 1 to C";
					  if(type==1)M_Recur[2]="move 1 to A";
					  b1.Move(-200.0f, 40,t_tar);
					  red[0]=255;green[0]=200;blue[0]=200;
					  red[2]=50;green[2]=255;blue[2]=50;
					  break;
		}
		change=10;
		move_round++;
		if(move_round>91)
		{
			red[2]=255;green[2]=200;blue[2]=200;
			M_Recur[0]="move(level,current,temp,target)";
			M_Recur[2]="move 1 to target";
			disk_total=0;
			t_tmp = t_tar;
			t_tar = t_cur;
			t_cur = t_tmp;
			t_tmp = 0;
			move_round=0;
		}
	}
//******************************************* end move

//***** Key Input Check start*****//

	if(m_Keyboard.GetKeyState(KEY_3) == TRUE)
	{
		if(disk_total==0)
		{
			disk_total=3;
			move_round=0;
			b1.Move(-200.0f,  20,t_cur);
			b2.Move(-200.0f,  10,t_cur);
			b3.Move(-200.0f,   0,t_cur);
			b4.Move(1200.0f,  10,t_cur);
			b5.Move(1200.0f,   0,t_cur);
			change=2;
			if(t_cur==-100)type=0;
			else if(t_cur==100)type=1;
		}

	}

	if(m_Keyboard.GetKeyState(KEY_4) == TRUE)
	{
		if(disk_total==0)
		{
			disk_total=4;
			move_round=0;
			b1.Move(-200.0f,  30,t_cur);
			b2.Move(-200.0f,  20,t_cur);
			b3.Move(-200.0f,  10,t_cur);
			b4.Move(-200.0f,   0,t_cur);
			b5.Move(1200.0f,   0,t_cur);
			change=2;
			if(t_cur==-100)type=0;
			else if(t_cur==100)type=1;
		}
	}

	if(m_Keyboard.GetKeyState(KEY_5) == TRUE)
	{
		if(disk_total==0)
		{
			disk_total=5;
			move_round=0;
			b1.Move(-200.0f,  40,t_cur);
			b2.Move(-200.0f,  30,t_cur);
			b3.Move(-200.0f,  20,t_cur);
			b4.Move(-200.0f,  10,t_cur);
			b5.Move(-200.0f,   0,t_cur);
			change=2;
			if(t_cur==-100)type=0;
			else if(t_cur==100)type=1;
		}
	}
//***** Key Input Check end*****//
	}
/********************************************/
  BOOL bfootonEarth=FALSE;
  MD2.CheckEarthMoveMent(Elapsed,&bfootonEarth);
 

  BOOL bfootonObj=FALSE;
  
 

  MD2.UpdateMoveMent();
/********************************************/
  //Array
/********************************************/
  if(Array_yes)
  {
	bgtext_r.UpdateMoveMent();
	bgtext_b.UpdateMoveMent();
	//key controll

	bgtext_r.UpdateModel( TRUE,"stand",Elapsed);
	bgtext_b.UpdateModel( TRUE,"stand",Elapsed);
	for(int chair_x2=0;chair_x2<4;chair_x2++)
		for(int chair_y2=0;chair_y2<6;chair_y2++)
		{
			chair[chair_x2][chair_y2].UpdateMoveMent();
			chair[chair_x2][chair_y2].UpdateModel( TRUE,"stand",Elapsed);
		}
  }
/********************************************/
/********************************************/
  //Stack
/********************************************/
  if(Stack_yes)
  {
	plate.UpdateMoveMent();
	for(int loop_b=0;loop_b<24;loop_b++)
	{
		boxs[loop_b].UpdateMoveMent();
		boxs[loop_b].UpdateModel( TRUE,"stand",Elapsed);
	}
	//key controll

	plate.UpdateModel( TRUE,"stand",Elapsed);
  }
/********************************************/
  //Queue
/********************************************/
  if(Queue_yes)
  {
	bgtext_r.UpdateMoveMent();
	bgtext_b.UpdateMoveMent();
	bgtext_l.UpdateMoveMent();
	bgtext_t.UpdateMoveMent();
	Plane.UpdateMoveMent();
	bgtext_r.UpdateModel( TRUE,"stand",Elapsed);
	bgtext_b.UpdateModel( TRUE,"stand",Elapsed);
	bgtext_l.UpdateModel( TRUE,"stand",Elapsed);
	bgtext_t.UpdateModel( TRUE,"stand",Elapsed);
	Plane.UpdateModel( TRUE,"stand",Elapsed);
	for(int i=0;i<7;i++)
	{
		q_button[i].UpdateMoveMent();
		q_button[i].UpdateModel( TRUE,"stand",Elapsed);
	}
  }
/********************************************/
  //linklist
/********************************************/
  if(Linklist_yes)
  {
	 box[0].UpdateMoveMent();
	 box[1].UpdateMoveMent();
	  box[2].UpdateMoveMent();
	  box[3].UpdateMoveMent();
	  box[4].UpdateMoveMent();
	  box[5].UpdateMoveMent();
	  box[6].UpdateMoveMent();
	  box[7].UpdateMoveMent();
	  box[8].UpdateMoveMent();
	  box[9].UpdateMoveMent();

	  box[0].UpdateModel( TRUE,"stand",Elapsed);
	box[1].UpdateModel( TRUE,"stand",Elapsed);
	box[2].UpdateModel( TRUE,"stand",Elapsed);
	box[3].UpdateModel( TRUE,"stand",Elapsed);
	box[4].UpdateModel( TRUE,"stand",Elapsed);
	box[5].UpdateModel( TRUE,"stand",Elapsed);
	box[6].UpdateModel( TRUE,"stand",Elapsed);
	box[7].UpdateModel( TRUE,"stand",Elapsed);
	box[8].UpdateModel( TRUE,"stand",Elapsed);
	box[9].UpdateModel( TRUE,"stand",Elapsed);
  }
/********************************************/
/********************************************/
  //recursive
/********************************************/
  if(Recur_yes)
  {
	  b1.UpdateMoveMent();
	b2.UpdateMoveMent();
	b3.UpdateMoveMent();
	b4.UpdateMoveMent();
	b5.UpdateMoveMent();  

	b1.UpdateModel( TRUE,"stand",Elapsed);
	b2.UpdateModel( TRUE,"stand",Elapsed);
	b3.UpdateModel( TRUE,"stand",Elapsed);
	b4.UpdateModel( TRUE,"stand",Elapsed);
	b5.UpdateModel( TRUE,"stand",Elapsed);
  }
/********************************************/
  //key controll
  
  MD2.UpdateModel( TRUE,"stand",Elapsed);
		

		m_XPos=MD2.GetXPos();
		m_YPos=MD2.GetYPos();
		m_ZPos=MD2.GetZPos();

	

	//get mouse rotate for 3rd
	float dmouseX,dmouseY;
	dmouseX=dmouseY=0;
	dmouseX=(float)m_Mouse.GetXDelta();
	dmouseY=(float)m_Mouse.GetYDelta();

	char c_MMSG[20];
//////////////////////////////////////
	if(menu_yes)
	{
		char t_MMSG[20];
		
		strcpy(t_MMSG,"");

		getmousepos(&c_MMSG[0]);

		if(clickmenu(&c_MMSG[0]))
		{
			strcpy(t_MMSG,c_MMSG);
			closemenu();
			menu_yes = false;
			if(strcmp(t_MMSG,"ARRAY") == 0)
			{
				m_Light.SetRange(10000.0f);
				m_Mesh.Load(&m_Graphics, "GRAPHIC\\array\\array.x", "GRAPHIC\\array\\");
				m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);
				MD2.SetComponent(&m_NodeTreeMesh);
				m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
				MD2.Move(0,850,0);
				MD2.Scale(0.1f,0.1f,0.1f);
				m_Camera.Camera_Obj(Elapsed,0,314,bmode);
				initarray();
				Array_yes = true;
				return true;
			}
			else
			if(strcmp(t_MMSG,"STACK") == 0)
			{			
				m_Light.SetRange(10000.0f);
				m_Mesh.Load(&m_Graphics, "GRAPHIC\\stack\\stack.x", "GRAPHIC\\stack\\");
				m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);
				MD2.SetComponent(&m_NodeTreeMesh);
				m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
				MD2.Move(700.0f,500,0);
				MD2.Scale(0.1f,0.1f,0.1f);
				m_Camera.Camera_Obj(Elapsed,0,150,bmode);
				initstack();
				Stack_yes = true;				
				return true;
				 
			}
			else
			if(strcmp(t_MMSG,"QUEUE") == 0)
			{
				m_Mesh.Load(&m_Graphics, "GRAPHIC\\queue\\airport2.x", "GRAPHIC\\queue\\");
				m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);
				MD2.SetComponent(&m_NodeTreeMesh);
				m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
				MD2.Move(500,400,0);
				MD2.Scale(0.1f,0.1f,0.1f);
				m_Camera.Camera_Obj(Elapsed,0,170,bmode);
				initqueue();
				Queue_yes = true;
				return true;
			}
			else
			if(strcmp(t_MMSG,"LINKLIST") == 0)
			{			
				m_Mesh.Load(&m_Graphics,"GRAPHIC\\linklist\\train.x", "GRAPHIC\\linklist\\");				
				m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);
				c_Lpos[0] = 640.0f;
				c_Wpos[0] = 0.0f;
				c_Lpos[1] = 200.0f;
				c_Wpos[1] = 0.0f;
				c_Lpos[2] = -220.0f;
				c_Wpos[2] = 0.0f;				
				MD2.SetComponent(&m_NodeTreeMesh);
				m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
				MD2.Move(c_Lpos[0],50,c_Wpos[0]);
				initlinklist();
				Linklist_yes = true;
				return true;
			}
			else
			if(strcmp(t_MMSG,"RECURSIVE") == 0)
			{
				m_Light.SetRange(420.0f);
				m_Mesh.Load(&m_Graphics, "GRAPHIC\\hanoi\\hanoi.x", "GRAPHIC\\hanoi\\");
				m_NodeTreeMesh.Create(&m_Graphics, &m_Mesh, OCTREE);
				MD2.SetComponent(&m_NodeTreeMesh);
				m_Camera.SetComponent(&m_NodeTreeMesh,&MD2);
				MD2.Move(200.0f,50,0);
				MD2.Scale(0.1f,0.1f,0.1f);
				initrecursive();
				Recur_yes = true;
				return true;
			}
		}
		sentense=c_MMSG;
		if(strcmp(t_MMSG,"") != 0)sentense =t_MMSG;
	}
//////////////////////////////////////
/********************************************/
  //linklist
/********************************************/
	if(Linklist_yes)
	{		
		getmousepos(&c_MMSG[0]);
	if(keyboard)
	{
		if(clickkeyboard(&c_MMSG[0]))
		{
			if(strcmp(c_MMSG,"KEY C") == 0)
			{
				door_lock.Free();
				game.user_passset("");
				strcpy(tmp,"");
			}
			else
			if(strcmp(c_MMSG,"KEY E") == 0)
			{
				door_lock.Free();
				keyboard = false;
				if(game.true_password())
				{
					strcpy(tmp,"ACCESS GRANT");
					game.user_passset("");
					if(game.next_stage())
					{
						strcpy(tmp,"CONGRATULATION");
					}
					else
					{
						pos_state = 0;
						MD2.Move(c_Lpos[pos_state],50,c_Wpos[pos_state]);
						Sleep(150);
					}
				}
				else
					strcpy(tmp,"ACCESS DENIED");					
				
			}
			else
			{
				strcpy(tmp,"");
				enterpass(&c_MMSG[0]);
				//char tmp[20];
				strcpy(tmp,c_MMSG);
				u_pass = tmp;
				
			}
			
		}
	}
	else
	if(clickitem(&c_MMSG[0]))
	{
		if(strcmp(c_MMSG,"DOOR") != 0)
		{
			if(game.checkgotpass(&c_MMSG[0]))
				if(strcmp(c_MMSG,"Not found") != 0)strcpy(password,c_MMSG);
		}
		else
		{
			if(keyboard == false)
			{
				door_lock.SetComponent(&m_NodeTreeMesh);
				door_lock.Move(-300.0f,50,0.0f);
				door_lock.Scale(0.5f,0.5f,0.5f);
				door_lock.Rotate(90,0,0);
				door_lock.SetFileAnimation("graphic\\knight\\tris.ini");
				door_lock.LoadAnimation("stand");
				door_lock.LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//backtext.md2","GRAPHIC//linklist//keypad.jpg");
				door_lock.UpdateMoveMent();
				door_lock.UpdateModel( TRUE,"stand",Elapsed);				
				keyboard = true;
			}		
		}	

	}
	sentense=c_MMSG;
	if(strcmp(password,"") != 0)sentense = password;
	if(strcmp(tmp,"ACCESS GRANT") == 0)sentense = tmp;
	if(strcmp(tmp,"ACCESS DENIED") == 0)sentense = tmp;
	if(strcmp(tmp,"CONGRATULATION") == 0)sentense = tmp;
	}
/********************************************/
/********************************/ 
/********************************/ 	
	if(menu_yes)
	{		
		static int k = 0;
		if(k == 0)
		{
			m_Camera.ThirdViewXYPlain(80,0,0,0,0);
			k =1;
		}
	}

  // Position light
	if(menu_yes || Linklist_yes || Recur_yes) 
		m_Light.Move(m_XPos, m_YPos+60.0f, m_ZPos);
/********************************/ 
/********************************/ 
	if(Array_yes || Queue_yes)
		m_Light.Move(0,200.0f, 0);
/********************************/
  m_Graphics.SetLight(0, &m_Light);
  if(menu_yes || Linklist_yes)
	m_Camera.Camera_Obj(Elapsed,0,0,bmode);
  if(Recur_yes)
	  m_Camera.Camera_Obj(Elapsed,dmouseX,dmouseY,bmode);

  // Set camera and calculate frustum
  m_Graphics.SetCamera(&m_Camera);
  Frustum.Construct(&m_Graphics,0);
  Frustum2.Construct(&m_Graphics,1000);
  // Render everything
/********************************/
/********************************/
  if(change>0 && Array_yes)
	{
		// Render everything
		m_Graphics.ClearZBuffer(1.0f);
		play = "stand";
		if(m_Graphics.BeginScene() == TRUE)
		{
		    m_Graphics.EnableZBuffer(FALSE);
			m_Graphics.EnableLighting(FALSE);
			m_SkyBox.Render(&m_Camera);
			m_Graphics.EnableZBuffer(TRUE);
			m_Graphics.EnableLighting(TRUE);
			m_NodeTreeMesh.Render(&Frustum);

			MD2.Rotate(0,m_Camera.GetYRotation(),0);
			if(!(bmode||m_Camera.GetZoom()<=65))MD2.RenderModel(FALSE);
		}

		for(int chair_x=0;chair_x<4;chair_x++)
			for(int chair_y=0;chair_y<6;chair_y++)
			{
				if(Frustum2.CheckSphere(chair[chair_x][chair_y].GetXPos(),chair[chair_x][chair_y].GetYPos(),chair[chair_x][chair_y].GetZPos(),chair[chair_x][chair_y].m_XYZRadius))
					chair[chair_x][chair_y].RenderModel(TRUE);
			}


		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(bgtext_r.GetXPos(),bgtext_r.GetYPos(),bgtext_r.GetZPos(),bgtext_r.m_XYZRadius))
			bgtext_r.RenderModel(TRUE);

		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(bgtext_b.GetXPos(),bgtext_b.GetYPos(),bgtext_b.GetZPos(),bgtext_b.m_XYZRadius))
			bgtext_b.RenderModel(TRUE);

		m_Graphics.EndScene();
		m_Font2.Print(sentence,200,600,0,0,D3DCOLOR_RGBA(255,100,100,255));
		m_Font.Print(sentence2,200,670,0,0,D3DCOLOR_RGBA(255,100,100,255));

		m_Font2.Print(col_a,120,10,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(col_b,220,10,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(col_c,450,10,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(col_d,560,10,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(row_0,50,60,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(row_1,50,145,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(row_2,50,230,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(row_3,50,320,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(row_4,50,410,0,0,D3DCOLOR_RGBA(100,255,0,255));
		m_Font2.Print(row_5,50,500,0,0,D3DCOLOR_RGBA(100,255,0,255));

		m_Font.Print(S_Status,200,50,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(S_Name,680,100,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(S_Event,700,200,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(S_Event2,700,250,0,0,D3DCOLOR_RGBA(255,0,0,255));

		m_Font.Print(m_score,760,670,0,0,D3DCOLOR_RGBA(255,100,100,255));
		m_Font.Print(rank,760,600,0,0,D3DCOLOR_RGBA(255,100,100,255));
	
		m_Graphics.Display();
		change--;
	}
/********************************/
/********************************/ 	
	if(Stack_yes)
	{
		if(change>0)
	{
		// Render everything
		m_Graphics.ClearZBuffer(1.0f);
		play = "stand";
		if(m_Graphics.BeginScene() == TRUE)
		{
			m_Graphics.EnableZBuffer(FALSE);
			m_Graphics.EnableLighting(FALSE);
			m_SkyBox.Render(&m_Camera);
			m_Graphics.EnableZBuffer(TRUE);
			m_Graphics.EnableLighting(TRUE);
			m_NodeTreeMesh.Render(&Frustum);
			MD2.Rotate(0,m_Camera.GetYRotation(),0);
			if(!(bmode||m_Camera.GetZoom()<=65))MD2.RenderModel(FALSE);
		}
		if(Frustum2.CheckSphere(plate.GetXPos(),plate.GetYPos(),plate.GetZPos(),plate.m_XYZRadius))
			plate.RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[0].GetXPos(),boxs[0].GetYPos(),boxs[0].GetZPos(),boxs[0].m_XYZRadius))
			boxs[0].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[1].GetXPos(),boxs[1].GetYPos(),boxs[1].GetZPos(),boxs[1].m_XYZRadius))
			boxs[1].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[2].GetXPos(),boxs[2].GetYPos(),boxs[2].GetZPos(),boxs[2].m_XYZRadius))
			boxs[2].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[3].GetXPos(),boxs[3].GetYPos(),boxs[3].GetZPos(),boxs[3].m_XYZRadius))
			boxs[3].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[4].GetXPos(),boxs[4].GetYPos(),boxs[4].GetZPos(),boxs[4].m_XYZRadius))
			boxs[4].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[5].GetXPos(),boxs[5].GetYPos(),boxs[5].GetZPos(),boxs[5].m_XYZRadius))
			boxs[5].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[6].GetXPos(),boxs[6].GetYPos(),boxs[6].GetZPos(),boxs[6].m_XYZRadius))
			boxs[6].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[7].GetXPos(),boxs[7].GetYPos(),boxs[7].GetZPos(),boxs[7].m_XYZRadius))
			boxs[7].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[8].GetXPos(),boxs[8].GetYPos(),boxs[8].GetZPos(),boxs[8].m_XYZRadius))
			boxs[8].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[9].GetXPos(),boxs[9].GetYPos(),boxs[9].GetZPos(),boxs[9].m_XYZRadius))
			boxs[9].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[10].GetXPos(),boxs[10].GetYPos(),boxs[10].GetZPos(),boxs[10].m_XYZRadius))
			boxs[10].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[11].GetXPos(),boxs[11].GetYPos(),boxs[11].GetZPos(),boxs[11].m_XYZRadius))
			boxs[11].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[12].GetXPos(),boxs[12].GetYPos(),boxs[12].GetZPos(),boxs[12].m_XYZRadius))
			boxs[12].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[13].GetXPos(),boxs[13].GetYPos(),boxs[13].GetZPos(),boxs[13].m_XYZRadius))
			boxs[13].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[14].GetXPos(),boxs[14].GetYPos(),boxs[14].GetZPos(),boxs[14].m_XYZRadius))
			boxs[14].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[15].GetXPos(),boxs[15].GetYPos(),boxs[15].GetZPos(),boxs[15].m_XYZRadius))
			boxs[15].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[16].GetXPos(),boxs[16].GetYPos(),boxs[16].GetZPos(),boxs[16].m_XYZRadius))
			boxs[16].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[17].GetXPos(),boxs[17].GetYPos(),boxs[17].GetZPos(),boxs[17].m_XYZRadius))
			boxs[17].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[18].GetXPos(),boxs[18].GetYPos(),boxs[18].GetZPos(),boxs[18].m_XYZRadius))
			boxs[18].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[19].GetXPos(),boxs[19].GetYPos(),boxs[19].GetZPos(),boxs[19].m_XYZRadius))
			boxs[19].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[20].GetXPos(),boxs[20].GetYPos(),boxs[20].GetZPos(),boxs[20].m_XYZRadius))
			boxs[20].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[21].GetXPos(),boxs[21].GetYPos(),boxs[21].GetZPos(),boxs[21].m_XYZRadius))
			boxs[21].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[22].GetXPos(),boxs[22].GetYPos(),boxs[22].GetZPos(),boxs[22].m_XYZRadius))
			boxs[22].RenderModel(TRUE);

		if(Frustum2.CheckSphere(boxs[23].GetXPos(),boxs[23].GetYPos(),boxs[23].GetZPos(),boxs[23].m_XYZRadius))
			boxs[23].RenderModel(TRUE);

	    m_Graphics.EndScene();
		m_Font.Print(sentence,200,600,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(sentence2,200,670,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(text_time,750,600,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(rank,750,670,0,0,D3DCOLOR_RGBA(255,0,0,255));
	
		m_Graphics.Display();
		change--;
	}
	}
/********************************/
/********************************/ 
	if(change>0 && Queue_yes)
	{
		// Render everything
		m_Graphics.ClearZBuffer(1.0f);
		play = "stand";
		if(m_Graphics.BeginScene() == TRUE)
		{
		    m_Graphics.EnableZBuffer(FALSE);
			m_Graphics.EnableLighting(FALSE);
			m_SkyBox.Render(&m_Camera);
			m_Graphics.EnableZBuffer(TRUE);
			m_Graphics.EnableLighting(TRUE);
			m_NodeTreeMesh.Render(&Frustum);

			MD2.Rotate(0,m_Camera.GetYRotation(),0);
			if(!(bmode||m_Camera.GetZoom()<=65))MD2.RenderModel(FALSE);
		}

		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(Plane.GetXPos(),Plane.GetYPos(),Plane.GetZPos(),Plane.m_XYZRadius))
			Plane.RenderModel(TRUE);

		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(bgtext_r.GetXPos(),bgtext_r.GetYPos(),bgtext_r.GetZPos(),bgtext_r.m_XYZRadius))
			bgtext_r.RenderModel(TRUE);

		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(bgtext_b.GetXPos(),bgtext_b.GetYPos(),bgtext_b.GetZPos(),bgtext_b.m_XYZRadius))
			bgtext_b.RenderModel(TRUE);

		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(bgtext_l.GetXPos(),bgtext_l.GetYPos(),bgtext_l.GetZPos(),bgtext_l.m_XYZRadius))
			bgtext_l.RenderModel(TRUE);

		m_Graphics.EnableAlphaBlending(TRUE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		if(Frustum2.CheckSphere(bgtext_t.GetXPos(),bgtext_t.GetYPos(),bgtext_t.GetZPos(),bgtext_t.m_XYZRadius))
			bgtext_t.RenderModel(TRUE);

		m_Graphics.EnableAlphaBlending(FALSE,D3DBLEND_SRCCOLOR,D3DBLEND_INVSRCCOLOR);
		for(int i=0;i<7;i++)
		{
			if(Frustum2.CheckSphere(q_button[i].GetXPos(),q_button[i].GetYPos(),q_button[i].GetZPos(),q_button[i].m_XYZRadius))
				q_button[i].RenderModel(TRUE);
		}
			
		m_Graphics.EndScene();
		m_Font.Print(sentence,600,670,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(q_text[0] ,50 ,600,0,0,D3DCOLOR_RGBA(150,230,50,255));
		m_Font.Print(q_text[1] ,50 ,670,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(q_text[2] ,240, 50,0,0,D3DCOLOR_RGBA(150,230,50,255));
		m_Font.Print(q_text[3] ,340,120,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(q_text[4] ,40 , 50,0,0,D3DCOLOR_RGBA(150,230,50,255));
		m_Font.Print(q_text[5] ,50 ,150,0,0,D3DCOLOR_RGBA(color[0][0],color[0][1],color[0][2],255));
		m_Font.Print(q_text[6] ,50 ,250,0,0,D3DCOLOR_RGBA(color[1][0],color[1][1],color[1][2],255));
		m_Font.Print(q_text[7] ,50 ,350,0,0,D3DCOLOR_RGBA(color[2][0],color[2][1],color[2][2],255));
		m_Font.Print(q_text[8] ,845, 50,0,0,D3DCOLOR_RGBA(150,230,50,255));
		m_Font.Print(q_text[9] ,890,150,0,0,D3DCOLOR_RGBA(color[3][0],color[3][1],color[3][2],255));
		m_Font.Print(q_text[10],890,250,0,0,D3DCOLOR_RGBA(color[4][0],color[4][1],color[4][2],255));
		m_Font.Print(q_text[11],890,350,0,0,D3DCOLOR_RGBA(color[5][0],color[5][1],color[5][2],255));
		m_Font.Print(q_text[12],240,250,0,0,D3DCOLOR_RGBA(150,255,150,255));
		m_Font.Print(text_time,750,600,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(text_score,750,670,0,0,D3DCOLOR_RGBA(255,0,0,255));

		if( (queue[0]>=0)&&(queue[0]<=2) )
			m_Font.Print(q_text[queue[0]+5],300,120,0,0,D3DCOLOR_RGBA(150,255,150,255));
		if( (queue[0]>=3)&&(queue[0]<=5) )
			m_Font.Print(q_text[queue[0]+6],300,120,0,0,D3DCOLOR_RGBA(150,255,150,255));

		if( (queue[1]>=0)&&(queue[1]<=2) )
			m_Font.Print(q_text[queue[1]+5],430,120,0,0,D3DCOLOR_RGBA(150,255,150,255));
		if( (queue[1]>=3)&&(queue[1]<=5) )
			m_Font.Print(q_text[queue[1]+6],430,120,0,0,D3DCOLOR_RGBA(150,255,150,255));

		if( (queue[2]>=0)&&(queue[2]<=2) )
			m_Font.Print(q_text[queue[2]+5],560,120,0,0,D3DCOLOR_RGBA(150,255,150,255));
		if( (queue[2]>=3)&&(queue[2]<=5) )
			m_Font.Print(q_text[queue[2]+6],560,120,0,0,D3DCOLOR_RGBA(150,255,150,255));

		if( (queue[3]>=0)&&(queue[3]<=2) )
			m_Font.Print(q_text[queue[3]+5],690,120,0,0,D3DCOLOR_RGBA(150,255,150,255));
		if( (queue[3]>=3)&&(queue[3]<=5) )
			m_Font.Print(q_text[queue[3]+6],690,120,0,0,D3DCOLOR_RGBA(150,255,150,255));

		m_Font.Print(randname,600,600,0,0,D3DCOLOR_RGBA(255,0,0,255));

		m_Graphics.Display();
		change--;
	}
/********************************/
/********************************/ 
  if(menu_yes || Linklist_yes)
  {
  m_Graphics.ClearZBuffer(1.0f);
  play = "stand"; 	
  if(m_Graphics.BeginScene() == TRUE) {
    m_Graphics.EnableZBuffer(FALSE);
    m_Graphics.EnableLighting(FALSE);
    m_SkyBox.Render(&m_Camera);
    m_Graphics.EnableZBuffer(TRUE);
    m_Graphics.EnableLighting(TRUE);
    m_NodeTreeMesh.Render(&Frustum);	
	MD2.Rotate(0,m_Camera.GetYRotation(),0);	
  }	
  }
/********************************/
/********************************/
  if(Linklist_yes)
  {
	if(Frustum2.CheckSphere(box[0].GetXPos(),box[0].GetYPos(),box[0].GetZPos(),box[0].m_XYZRadius))
		box[0].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[1].GetXPos(),box[1].GetYPos(),box[1].GetZPos(),box[1].m_XYZRadius))
		box[1].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[2].GetXPos(),box[2].GetYPos(),box[2].GetZPos(),box[2].m_XYZRadius))
		box[2].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[3].GetXPos(),box[3].GetYPos(),box[3].GetZPos(),box[3].m_XYZRadius))
		box[3].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[4].GetXPos(),box[4].GetYPos(),box[4].GetZPos(),box[4].m_XYZRadius))
		box[4].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[5].GetXPos(),box[5].GetYPos(),box[5].GetZPos(),box[5].m_XYZRadius))
		box[5].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[6].GetXPos(),box[6].GetYPos(),box[6].GetZPos(),box[6].m_XYZRadius))
		box[6].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[7].GetXPos(),box[7].GetYPos(),box[7].GetZPos(),box[7].m_XYZRadius))
		box[7].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[8].GetXPos(),box[8].GetYPos(),box[8].GetZPos(),box[8].m_XYZRadius))
		box[8].RenderModel(TRUE);
	if(Frustum2.CheckSphere(box[9].GetXPos(),box[9].GetYPos(),box[9].GetZPos(),box[9].m_XYZRadius))
		box[9].RenderModel(TRUE);
	if(keyboard)
		if(Frustum2.CheckSphere(door_lock.GetXPos(),door_lock.GetYPos(),door_lock.GetZPos(),door_lock.m_XYZRadius))
			door_lock.RenderModel(TRUE);
  }
/********************************/
/********************************/
  if(menu_yes)
  {
	m_Title.Print("3D Game For Edutainment",90,50,0,0,D3DCOLOR_RGBA(255,50,10,255));
	m_showmouse.Print(sentense,10,300,0,0,D3DCOLOR_RGBA(255,255,255,255));
	m_array.Print("Array Game",400,500,0,0,D3DCOLOR_RGBA(255,255,255,255));
	m_stack.Print("Stack Game",398,540,0,0,D3DCOLOR_RGBA(255,255,255,255));
	m_queue.Print("Queue Game",388,580,0,0,D3DCOLOR_RGBA(255,255,255,255));	
	m_linklist.Print("Linklist Game",383,620,0,0,D3DCOLOR_RGBA(255,255,255,255));
	m_recur.Print("Recursive Simulation",320,660,0,0,D3DCOLOR_RGBA(255,255,255,255));
  }
	
  if(menu_yes )
  {
  m_Graphics.EndScene();

  m_Graphics.Display();
  }
/********************************/
/********************************/
  if(Linklist_yes)
  {
	  m_Graphics.EndScene();
	  int timeleft = game.checktime();

	if(timeleft != 0)
	{
	
		char showtime[5],tmpstr[2];

		_itoa(timeleft/60,tmpstr,10);
		strcpy(showtime,tmpstr);
		_itoa(timeleft%60,tmpstr,10);
		strcat(showtime,":");
		strcat(showtime,tmpstr);
	
		m_showtime.Print(showtime,10,10,0,0,D3DCOLOR_RGBA(255,0,0,255));
		m_Font.Print(sentense,420,10,0,0,D3DCOLOR_RGBA(255,255,255,255));
		if(keyboard)m_input.Print(u_pass,470,250,0,0,D3DCOLOR_RGBA(0,0,0,255));
	}
	else
	{
		m_Font.Print("Time out",420,10,0,0,D3DCOLOR_RGBA(255,255,255,255));		
	}	

	m_Graphics.Display();

	if(timeleft == 0)
	{
		Sleep(1000);
		return false;
	}
	if(strcmp(tmp,"ACCESS GRANT") == 0)
	{
		Sleep(2000);
		strcpy(tmp,"");
	}
	else if(strcmp(tmp,"ACCESS DENIED") == 0)
	{
		Sleep(2000);
		strcpy(tmp,"");
	}
	else if(strcmp(tmp,"CONGRATULATION") == 0)
	{
		Sleep(3000);
		strcpy(tmp,"");
		return false;
	}
	else if(strcmp(password,"") != 0)
	{
		Sleep(2000);
		strcpy(password,"");
	}
	else if(strcmp(c_MMSG,"Not found") == 0)
	{
		Sleep(800);
	}
	strcpy(c_MMSG,"");
  }
/********************************/
/********************************/
  
  if(change>0 && Recur_yes)
	{
		// Render everything
		m_Graphics.ClearZBuffer(1.0f);
		play = "stand";
		if(m_Graphics.BeginScene() == TRUE)
		{
		    m_Graphics.EnableZBuffer(FALSE);
		    m_Graphics.EnableLighting(FALSE);
		    m_SkyBox.Render(&m_Camera);
		    m_Graphics.EnableZBuffer(TRUE);
		    m_Graphics.EnableLighting(TRUE);
		    m_NodeTreeMesh.Render(&Frustum);

			MD2.Rotate(0,m_Camera.GetYRotation(),0);
			if(!(bmode||m_Camera.GetZoom()<=65))MD2.RenderModel(FALSE);
		}

		if(Frustum2.CheckSphere(b1.GetXPos(),b1.GetYPos(),b1.GetZPos(),b1.m_XYZRadius))
			b1.RenderModel(TRUE);

		if(Frustum2.CheckSphere(b2.GetXPos(),b2.GetYPos(),b2.GetZPos(),b2.m_XYZRadius))
			b2.RenderModel(TRUE);

		if(Frustum2.CheckSphere(b3.GetXPos(),b3.GetYPos(),b3.GetZPos(),b3.m_XYZRadius))
			b3.RenderModel(TRUE);

		if(Frustum2.CheckSphere(b4.GetXPos(),b4.GetYPos(),b4.GetZPos(),b4.m_XYZRadius))
			b4.RenderModel(TRUE);

		if(Frustum2.CheckSphere(b5.GetXPos(),b5.GetYPos(),b5.GetZPos(),b5.m_XYZRadius))
			b5.RenderModel(TRUE);

		m_Graphics.EndScene();

		F_Text.Print(M_Text1,200,600,0,0,D3DCOLOR_RGBA(255,50,50,255));
		F_Text.Print(M_Text2,200,670,0,0,D3DCOLOR_RGBA(50,255,50,255));

		F_Text.Print(t_a,268,250,0,0,D3DCOLOR_RGBA(255,50,50,255));
		F_Text.Print(t_b,500,250,0,0,D3DCOLOR_RGBA(255,50,50,255));
		F_Text.Print(t_c,732,250,0,0,D3DCOLOR_RGBA(255,50,50,255));

		F_Text.Print(M_Recur[0], 50,  8,0,0,D3DCOLOR_RGBA(red[0],green[0],blue[0],255));
		F_Text.Print(M_Recur[1],160, 50,0,0,D3DCOLOR_RGBA(red[1],green[1],blue[1],255));
		F_Text.Print(M_Recur[2],220, 80,0,0,D3DCOLOR_RGBA(red[2],green[2],blue[2],255));
		F_Text.Print(M_Recur[3],160,110,0,0,D3DCOLOR_RGBA(red[3],green[3],blue[3],255));
		F_Text.Print(M_Recur[4],220,140,0,0,D3DCOLOR_RGBA(red[4],green[4],blue[4],255));
		F_Text.Print(M_Recur[5],220,170,0,0,D3DCOLOR_RGBA(red[5],green[5],blue[5],255));
		F_Text.Print(M_Recur[6],220,200,0,0,D3DCOLOR_RGBA(red[6],green[6],blue[6],255));

		m_Graphics.Display();
		change--;
	}
/********************************/
/********************************/
  return TRUE;
}
/////////////////////////////////////
/////////////////////////////////////
//Main Function
/////////////////////////////////////
BOOL cApp::Randomize()
{
	int seed;
	seed = (unsigned)time(0);
	srand(seed);
	return TRUE;
}
/////////////////////////////////////
void cApp::getmousepos(char *m_MMSG)
{
	char test1[10];	
	strcpy(m_MMSG,"");
	mouseX=mouseY = 0;
	if(m_Mouse.GetButtonState(MOUSE_LBUTTON) ==TRUE)
	{
			mouseX=m_Mouse.GetXPos();
			mouseY=m_Mouse.GetYPos();
			Sleep(100);

			strcpy(m_MMSG,"Left Mouse@");
			_itoa((int)mouseX,test1,10);
			strcat(m_MMSG,test1);
			strcat(m_MMSG,",");
			_itoa((int)mouseY,test1,10);
			strcat(m_MMSG,test1);	
	}
}
/////////////////////////////////////
/////////////////////////////////////
//Menu Function
/////////////////////////////////////
bool cApp::clickmenu(char *c_MSG)
{
		if((mouseX > 396) && (mouseX < 625) && (mouseY > 505) && (mouseY < 541)){strcpy(c_MSG,"ARRAY");return true;}
		if((mouseX > 393) && (mouseX < 628) && (mouseY > 547) && (mouseY < 579)){strcpy(c_MSG,"STACK");return true;}
		if((mouseX > 384) && (mouseX < 631) && (mouseY > 585) && (mouseY < 622)){strcpy(c_MSG,"QUEUE");return true;}
		if((mouseX > 381) && (mouseX < 641) && (mouseY > 624) && (mouseY < 661)){strcpy(c_MSG,"LINKLIST");return true;}
		if((mouseX > 316) && (mouseX < 722) && (mouseY > 664) && (mouseY < 701)){strcpy(c_MSG,"RECURSIVE");return true;}

		return false;
}
/////////////////////////////////////
bool cApp::closemenu()
{	
	m_NodeTreeMesh.Free();
	m_Mesh.Free();				
	m_Camera.ThirdViewXYPlain(-80,0,0,0,0);	
	return true;
}

/////////////////////////////////////
/////////////////////////////////////
//Array Function
/////////////////////////////////////
bool cApp::initarray()
{
	sentence  = "Array";
	sentence2 = "Right Click to Start.";
	S_Status  = " ";
	S_Name = " ";
	S_Event = " ";
	S_Event2 = " ";
	customer = 1;
	row_0="0";
	row_1="1";
	row_2="2";
	row_3="3";
	row_4="4";
	row_5="5";
	col_a="A";
	col_b="B";
	col_c="C";
	col_d="D";
	n_col=6;
	n_row=6;
	state=0;//0 Right mouse only //1 Left mose Only
	targetX=6;
	targetY=6;
	targetX2=6;
	targetY2=6;
	score=0;
	maxscore=0;
	m_score=" ";
	count=0;
	rank=" ";
	Randomize();
	checkclick=0;
	tmpX=6,tmpY=6;
	bgtext_r.SetComponent(&m_NodeTreeMesh);
	bgtext_r.Move(-79.0f,  20,268.0f);
	bgtext_r.Scale(2.6f,1.0f,4.8f);
	bgtext_r.SetFileAnimation("graphic\\knight\\tris.ini");
	bgtext_r.LoadAnimation("stand");
	bgtext_r.LoadModelMd2(&m_Graphics,"GRAPHIC//array//backtext.md2","GRAPHIC//array//backtext.bmp");

	bgtext_b.SetComponent(&m_NodeTreeMesh);
	bgtext_b.Move(250.0f,  20,0.0f);
	bgtext_b.Scale(8.0f,1.0f,1.35f);
	bgtext_b.SetFileAnimation("graphic\\knight\\tris.ini");
	bgtext_b.LoadAnimation("stand");
	bgtext_b.LoadModelMd2(&m_Graphics,"GRAPHIC//array//backtext.md2","GRAPHIC//array//backtext.bmp");
	for(int chair_x=0;chair_x<4;chair_x++)
		for(int chair_y=0;chair_y<6;chair_y++)
		{
			chair[chair_x][chair_y].SetComponent(&m_NodeTreeMesh);
			chair[chair_x][chair_y].SetFileAnimation("graphic\\knight\\tris.ini");
			chair[chair_x][chair_y].LoadAnimation("stand");
			chair_stat[chair_x][chair_y]=0;
			chair[chair_x][chair_y].LoadModelMd2(&m_Graphics,"GRAPHIC//array//backtext.md2","GRAPHIC//array//tab1.jpg");
			chair[chair_x][chair_y].Move(-500.0f,  25,-500.0f);
			chair[chair_x][chair_y].Scale(0.5f,1.0f,0.5f);
		}

	m_Font.Create(&m_Graphics,"AngsanaUPC",35,TRUE);
	m_Window.Create(&m_Graphics,&m_Font);
	m_Font2.Create(&m_Graphics,"Arial",35,TRUE);
	m_Window2.Create(&m_Graphics,&m_Font2);
	return true;
}
/////////////////////////////////////
BOOL cApp::SetEvent()
{
	S_Name = "����ش��¡��";
	S_Event = " ";
	S_Event2 = " ";

	int gender;
	static char tmp_sen[20],tmp_sen2[20];
	static int count_pos=0;
	int pos_X=rand() % 4,pos_Y=rand() % 6;
	static char tmp_sen3[20],tmp_sen4[20];
	static char tmp_sen5[20],tmp_sen6[20];
	int event2=0;

	if(count_pos<24)
	{
	switch (rand() % 2)
	{
		case 0 : gender=0;break;
		case 1 : gender=1;break;
	}
	strcpy(tmp_sen,"�١��Ҥ���� ");
	_itoa(customer,tmp_sen2,10);	
	strcat(tmp_sen,tmp_sen2);
	S_Name = tmp_sen;
	// end say man@?
	//if > 0 mean it's using
	//0 no booking
	//1 declare book
	//2 booked
	//3 declare unbook


	while( chair_stat[pos_X][pos_Y]!=0&&count_pos<24)
	{
		pos_X=rand() % 4;pos_Y=rand() % 6;
	}

	strcpy(tmp_sen3,"��ͧ��èͧ��� [");
	switch(pos_X)
	{
		case 0 : strcat(tmp_sen3,"A");break;
		case 1 : strcat(tmp_sen3,"B");break;
		case 2 : strcat(tmp_sen3,"C");break;
		case 3 : strcat(tmp_sen3,"D");break;
	}
	strcat(tmp_sen3,"][");
	_itoa(pos_Y,tmp_sen4,10);	
	strcat(tmp_sen3,tmp_sen4);
	strcat(tmp_sen3,"]");
	S_Event = tmp_sen3;

	targetX=pos_X;
	targetY=pos_Y;
	chair_stat[pos_X][pos_Y]=1;//declare book
	count_pos++;

	switch (rand() % 10)
	{
		case 1 : 
		case 4 : S_Event2 = "��Ѻ";
				 event2=1;//case 2-place booking
				 break;
		default: if(gender==1){strcat(tmp_sen3," ���");}
				 if(gender==0){strcat(tmp_sen3," ��Ѻ");}
				 S_Event = tmp_sen3;
				 targetX2=6;
				 targetY2=6;
				 break;

	}

	if(event2==1&&count_pos<24)
	{
		while( chair_stat[pos_X][pos_Y]!=0&&count_pos<24)
		{
			pos_X=rand() % 4;pos_Y=rand() % 6;
		}
		strcpy(tmp_sen5,"�Ѻ [");
		switch(pos_X)
		{
			case 0 : strcat(tmp_sen5,"A");break;
			case 1 : strcat(tmp_sen5,"B");break;
			case 2 : strcat(tmp_sen5,"C");break;
			case 3 : strcat(tmp_sen5,"D");break;
		}
		strcat(tmp_sen5,"][");
		_itoa(pos_Y,tmp_sen6,10);	
		strcat(tmp_sen5,tmp_sen6);
		strcat(tmp_sen5,"]");
		if(gender==1){strcat(tmp_sen5," ���");}
		if(gender==0){strcat(tmp_sen5," ��Ѻ");}
		S_Event2 = tmp_sen5;
		targetX2=pos_X;
		targetY2=pos_Y;
		chair_stat[pos_X][pos_Y]=1;//declare book
		count_pos++;
	}

	customer++;
	}

	return TRUE;
}
/////////////////////////////////////
BOOL cApp::ChkPosition(long x,long y)
{
	//set n_col & n_row
	if( (x>=112)&&(x<=160) )n_col=0;
	if( (x>=215)&&(x<=265) )n_col=1;
	if( (x>=442)&&(x<=495) )n_col=2;
	if( (x>=545)&&(x<=600) )n_col=3;

	if( (y>=70)&&(y<=112) )n_row=0;
	if( (y>=158)&&(y<=198) )n_row=1;
	if( (y>=244)&&(y<=284) )n_row=2;
	if( (y>=329)&&(y<=371) )n_row=3;
	if( (y>=419)&&(y<=457) )n_row=4;
	if( (y>=508)&&(y<=545) )n_row=5;

	return TRUE;
}
////////////////////////////////////
bool cApp::closearray()
{
	m_NodeTreeMesh.Free();
	m_Mesh.Free();	
	m_Window.Free();
	m_Font.Free();
	m_Window2.Free();
	m_Font2.Free();

	bgtext_r.Free();
	bgtext_b.Free();
	for(int chair_x=0;chair_x<4;chair_x++)
		for(int chair_y=0;chair_y<6;chair_y++)
			chair[chair_x][chair_y].Free();
	return true;
}
/////////////////////////////////////
/////////////////////////////////////
/////////////////////////////////////
//Stack Function
/////////////////////////////////////
bool cApp::initstack()
{
	sentence= "Stack : Size = 3";
	sentence2="Number : 0/3 , Empty Stack.";
	rank=" ";
	strcpy(&text_time[0]," ");
	s_time=time(0);
	t_time=100;
	start=0;

	end_count=0;

	p_box[0][0] = 0;
	p_box[0][1] = 1;
	p_box[0][2] = 2;
	p_box[0][3] = 3;
	p_box[1][0] = 4;
	p_box[1][1] = 5;
	p_box[1][2] = 6;
	p_box[1][3] = 7;
	p_box[2][0] = 8;
	p_box[2][1] = 9;
	p_box[2][2] = 10;
	p_box[2][3] = 11;
	p_box[3][0] = 100;	//100 = no box here
	p_box[3][1] = 100;
	p_box[3][2] = 100;
	p_box[3][3] = 100;
	p_box[4][0] = 100;
	p_box[4][1] = 100;
	p_box[4][2] = 100;
	p_box[4][3] = 100;	
	p_box[5][0] = 100;
	p_box[5][1] = 100;
	p_box[5][2] = 100;
	p_box[5][3] = 100;
	p_box[6][0] = 100;
	p_box[6][1] = 100;
	p_box[6][2] = 100;
	p_box[6][3] = 100;

	b_tmp[0]=12;
	b_tmp[1]=13;
	b_tmp[2]=14;
	b_tmp[3]=15;
	b_tmp[4]=16;
	b_tmp[5]=17;
	b_tmp[6]=18;
	b_tmp[7]=19;
	b_tmp[8]=20;
	b_tmp[9]=21;
	b_tmp[10]=22;
	b_tmp[11]=23;
	b_tmp[12]=100;
	b_tmp[13]=100;
	b_tmp[14]=100;

	p_stack[0] = 100;
	p_stack[1] = 100;
	p_stack[2] = 100;

	
	line_p[0]=120.0f;
	line_p[1]=180.0f;
	line_p[2]=240.0f;

	line_x[0]=-300.0f;
	line_x[1]=-200.0f;
	line_x[2]=-100.0f;
	line_x[3]=   0.0f;
	line_x[4]= 100.0f;
	line_x[5]= 200.0f;
	line_x[6]= 300.0f;

	line_y[0]=-200.0f;
	line_y[1]=-130.0f;
	line_y[2]= -60.0f;
	line_y[3]=  10.0f;

	line_z=10.0f;
	for(int i=0;i<24;i++)
	{
		boxs[i].SetComponent(&m_NodeTreeMesh);
		boxs[i].SetFileAnimation("graphic\\knight\\tris.ini");
		boxs[i].LoadAnimation("stand");
	}

	Move_Box();
	MoveTmp();
	plate.SetFileAnimation("graphic\\knight\\tris.ini");
	plate.LoadAnimation("stand");
	plate.LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box210909.md2","GRAPHIC//stack//plate.jpg");
	plate.Move(line_p[1],  0,0.0f);

	Randomize();
	RandomBoxColor24();
	m_Font.Create(&m_Graphics,"Arial",35,TRUE);
	m_Window.Create(&m_Graphics,&m_Font);
	return true;
}
/////////////////////////////////////
BOOL cApp::Move_Box()
{
	for(int ly=0;ly<=3;ly++)
	{
		for(int lx=0;lx<=6;lx++)
		{
			if(p_box[lx][ly]!=100)
				boxs[p_box[lx][ly]].Move(line_y[ly],  line_z,line_x[lx]);
		}
	}
	return TRUE;
}
/////////////////////////////////////
BOOL cApp::Move_Stack(int plate_p)
{
	plate.Move(line_p[1],  0,line_x[plate_p]);
	for(int lp=0;lp<=2;lp++)
	{
		if(p_stack[lp]!=100)
			boxs[p_stack[lp]].Move(line_p[lp],  line_z,line_x[plate_p]);
	}
	return TRUE;
}
/////////////////////////////////////
BOOL cApp::RandomBoxColor24()
{
	int color[24];
	int pos=rand()%24;
	short i;
	int color_set;
	for(i=0;i<24;i++)color[i]=0;

	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=1;
	}
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=2;
	}
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=3;
	}
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=4;
	}

	color_set=(rand()%4) +1;
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=color_set;
	}

	color_set=(rand()%4) +1;
	for(i=0;i<4;i++)
	{
		while(color[pos]!=0)
		{
			pos=rand()%24;
		}
		color[pos]=color_set;
	}

	for(i=0;i<24;i++)
	{
		switch (color[i])
		{
			case 1 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab1.jpg");
						b_color[i]=3;break;
			case 2 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab2.jpg");
						b_color[i]=4;break;
			case 3 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab3.jpg");
						b_color[i]=5;break;
			case 4 :	boxs[i].LoadModelMd2(&m_Graphics,"GRAPHIC//stack//box606030.md2","GRAPHIC//stack//tab4.jpg");
						b_color[i]=6;break;
		}
	}

	return TRUE;
}
/////////////////////////////////////
BOOL cApp::ReQueueBox()
{
	for(int box_loop=0;box_loop<=13;box_loop++)
	{
		b_tmp[box_loop]=b_tmp[box_loop+1];
	}
	b_tmp[14]=100;
	return TRUE;
}
/////////////////////////////////////
BOOL cApp::MoveTmp()
{
	for(int tmp_loop=0;tmp_loop<=14;tmp_loop++)
	{
		if(b_tmp[tmp_loop] == 100)break;
		boxs[b_tmp[tmp_loop]].Move(-300.0f,  line_z,300.0f);
	}

	return TRUE;
}
/////////////////////////////////////
BOOL cApp::KeepToTmp(int line_py)
{
	end_count++;
	boxs[p_box[line_py][0]].Move(-300.0f,  line_z,300.0f);
	boxs[p_box[line_py][1]].Move(-300.0f,  line_z,300.0f);
	boxs[p_box[line_py][2]].Move(-300.0f,  line_z,300.0f);
	boxs[p_box[line_py][3]].Move(-300.0f,  line_z,300.0f);
	return TRUE;
}
/////////////////////////////////////
BOOL cApp::ChkSen2()
{
	sentence2="Number : 0/3 , Empty Stack.";
	if(p_stack[0]==100&&p_stack[1]==100&&p_stack[2]!=100)
	{
		sentence2="Number : 1/3";
	}
	if(p_stack[0]==100&&p_stack[1]!=100&&p_stack[2]!=100)
	{
		sentence2="Number : 2/3";
	}
	if(p_stack[0]!=100&&p_stack[1]!=100&&p_stack[2]!=100)
	{
		sentence2="Number : 3/3 , Full Stack.";
	}
	return TRUE;
}
/////////////////////////////////////
bool cApp::closestack()
{
	MD2.Free();
	plate.Free();
	boxs[0].Free();
	boxs[1].Free();
	boxs[2].Free();
	boxs[3].Free();
	boxs[4].Free();
	boxs[5].Free();
	boxs[6].Free();
	boxs[7].Free();
	boxs[8].Free();
	boxs[9].Free();
	boxs[10].Free();
	boxs[11].Free();
	boxs[12].Free();
	boxs[13].Free();
	boxs[14].Free();	
	boxs[15].Free();
	boxs[16].Free();
	boxs[17].Free();
	boxs[18].Free();
	boxs[19].Free();
	boxs[20].Free();
	boxs[21].Free();
	boxs[22].Free();
	boxs[23].Free();

	m_Window.Free();
	m_Font.Free();
	return true;
}
/////////////////////////////////////
/////////////////////////////////////
//Queue Function
/////////////////////////////////////
bool cApp::initqueue()
{
	Randomize();

	sentence  = " ";
	S_Status  = "Queue state";
	S_Name = " name";
	S_Event = " event1";
	S_Event2 = " event2";
	round=0;
	state=0;//0 no act,1 take off,2 landing
	score=0;
	s_time=time(0);
	t_time=120;
	start=0;

	strcpy(&q_text[0][0],"Queue");
	strcpy(&q_text[1][0]," ");
	strcpy(&q_text[2][0],"Queue List");
	strcpy(&q_text[3][0]," ");
	strcpy(&q_text[4][0],"Landing");
	strcpy(&q_text[5][0]," ");
	strcpy(&q_text[6][0]," ");
	strcpy(&q_text[7][0]," ");
	strcpy(&q_text[8][0],"Take Off");
	strcpy(&q_text[9][0]," ");
	strcpy(&q_text[10][0]," ");
	strcpy(&q_text[11][0]," ");
	strcpy(&q_text[12][0]," ");
	strcpy(&q_text[13][0]," ");
	strcpy(&text_score[0],"Score : 00");
	strcpy(&text_time[0]," ");
	randname=" ";

	for(int i=0;i<6;i++)
	{
		color[i][0]=130;
		color[i][1]=240;
		color[i][2]=220;
		status[i]=0;
		queue[i % 4]=7;
	}
	zone=7;
	park=1;

	RandName(&q_text[5][0]);status[0]=1;
	RandName(&q_text[6][0]);status[1]=1;
	RandName(&q_text[9][0]);status[3]=1;

	RandName(&q_text[7][0]);status[2]=1;

	bgtext_r.SetComponent(&m_NodeTreeMesh);
	bgtext_r.Move(247.5f, 200,148.0f);
	bgtext_r.Scale(0.6f,1.0f,1.85f);
	bgtext_r.Rotate(-0.72f,0.0f,0.0f);
	bgtext_r.SetFileAnimation("graphic\\knight\\tris.ini");
	bgtext_r.LoadAnimation("stand");
	bgtext_r.LoadModelMd2(&m_Graphics,"GRAPHIC//array//backtext.md2","GRAPHIC//array//backtext.bmp");

	bgtext_l.SetComponent(&m_NodeTreeMesh);
	bgtext_l.Move(247.0f, 200,-148.0f);
	bgtext_l.Scale(0.6f,1.0f,1.85f);
	bgtext_l.Rotate(-0.72f,0.0f,0.0f);
	bgtext_l.SetFileAnimation("graphic\\knight\\tris.ini");
	bgtext_l.LoadAnimation("stand");
	bgtext_l.LoadModelMd2(&m_Graphics,"GRAPHIC//array//backtext.md2","GRAPHIC//array//backtext.bmp");

	bgtext_t.SetComponent(&m_NodeTreeMesh);
	bgtext_t.Move(142.0f, 200,0.0f);
	bgtext_t.Scale(2.63f,1.0f,0.8f);
	bgtext_t.Rotate(-0.72f,0.0f,0.0f);
	bgtext_t.SetFileAnimation("graphic\\knight\\tris.ini");
	bgtext_t.LoadAnimation("stand");
	bgtext_t.LoadModelMd2(&m_Graphics,"GRAPHIC//queue//backtext.md2","GRAPHIC//queue//bg_top.bmp");

	bgtext_b.SetComponent(&m_NodeTreeMesh);
	bgtext_b.Move(392.0f, 200,0.0f);
	bgtext_b.Scale(2.57f,1.0f,0.5f);
	bgtext_b.Rotate(-0.72f,0.0f,0.0f);
	bgtext_b.SetFileAnimation("graphic\\knight\\tris.ini");
	bgtext_b.LoadAnimation("stand");
	bgtext_b.LoadModelMd2(&m_Graphics,"GRAPHIC//array//backtext.md2","GRAPHIC//array//backtext.bmp");

	Plane.SetComponent(&m_NodeTreeMesh);
	Plane.Move(1000.0f, 0,0.0f);
	Plane.Scale(1.0f,1.0f,1.0f);
	Plane.SetFileAnimation("graphic\\knight\\tris.ini");
	Plane.LoadAnimation("stand");
	Plane.LoadModelMd2(&m_Graphics,"GRAPHIC//queue//plane.md2","GRAPHIC//queue//airplane02.jpg");

	for(i=0;i<6;i++)
	{
		q_button[i].SetComponent(&m_NodeTreeMesh);
		q_button[i].Move(200.0f, 50,0.0f);
		q_button[i].Scale(0.18f,0.001f,0.18f);
		q_button[i].Rotate(-0.72f,0.0f,0.0f);
		q_button[i].SetFileAnimation("graphic\\knight\\tris.ini");
		q_button[i].LoadAnimation("stand");
		q_button[i].LoadModelMd2(&m_Graphics,"GRAPHIC//queue//box606030.md2","GRAPHIC//queue//q_in.bmp");
	}

	q_button[0].Move(252.0f, 250,-112.0f);
	q_button[1].Move(277.0f, 230,-111.3f);
	q_button[2].Move(302.0f, 210,-110.6f);
	q_button[3].Move(252.0f, 250,112.0f);
	q_button[4].Move(277.0f, 230,111.0f);
	q_button[5].Move(302.0f, 210,110.0f);

	q_button[6].SetComponent(&m_NodeTreeMesh);
	q_button[6].Move(205.0f,-230,-90.0f);
	q_button[6].Scale(0.2f,0.001f,0.2f);
	q_button[6].Rotate(-0.72f,0.0f,0.0f);
	q_button[6].SetFileAnimation("graphic\\knight\\tris.ini");
	q_button[6].LoadAnimation("stand");
	q_button[6].LoadModelMd2(&m_Graphics,"GRAPHIC//queue//box606030.md2","GRAPHIC//queue//q_out.bmp");

	m_Font.Create(&m_Graphics,"Arial",35,TRUE);
	m_Window.Create(&m_Graphics,&m_Font);
	return true;
}
/////////////////////////////////////
BOOL cApp::MoveTakeoff(int round)
{
	// start
	if(round==0)
	{
		Plane.LoadModelMd2(&m_Graphics,"GRAPHIC//queue//plane.md2","GRAPHIC//queue//airplane01.jpg");
		Plane.Move(160.0f, 2,300.0f);
	}

	// speed for front
	if(round>=  1 && round<= 70)Plane.MoveBack(2.0f);
	if(round>= 71 && round<=110)Plane.MoveBack(3.0f);
	if(round>=111 && round<=140)Plane.MoveBack(4.0f);
	if(round>=141 && round<=200)Plane.MoveBack(5.0f);
	
	// step down
	if(round==111||round==121)
		Plane.MoveUp(1.0f);
	if(round==131||round==141||round==146||round==151)
		Plane.MoveUp(2.0f);
	if(round==156||round==160||round==164||round==168||round==172||round==176)
		Plane.MoveUp(3.0f);
	if(round==180||round==183||round==186||round==189||round==192||round==195||round==198)
		Plane.MoveUp(4.0f);

	// end
	if(round==200)
	{
		state=0;Plane.Move(1000.0f, 0,300.0f);
		strcpy(&q_text[12][0]," ");
		if(queue[0]!=7)
		q_button[6].Move(205.0f,230,-90.0f);
	}

	return TRUE;
}
/////////////////////////////////////
BOOL cApp::MoveLanding(int round)
{
	// start
	if(round==0)
	{
		Plane.LoadModelMd2(&m_Graphics,"GRAPHIC//queue//plane.md2","GRAPHIC//queue//airplane02.jpg");
		Plane.Move(160.0f, 52,-300.0f);
	}

	// speed for front
	if(round>=  1 && round<= 28)Plane.MoveFront(5.0f);
	if(round>= 29 && round<= 78)Plane.MoveFront(4.0f);
	if(round>= 79 && round<=120)Plane.MoveFront(3.0f);
	if(round>=121 && round<=200)Plane.MoveFront(2.0f);
	if(round>=201 && round<=260)Plane.MoveFront(1.0f);
	
	// step down
	if(round== 4||round== 7||round==10||round==13||round==16||round==19||round==22||round==25)
		Plane.MoveDown(4.0f);
	if(round==29||round==33||round==37||round==41)
		Plane.MoveDown(3.0f);
	if(round==45||round==50||round==55)
		Plane.MoveDown(2.0f);

	// end
	if(round==261)
	{
		state=0;Plane.Move(1000.0f, 0,300.0f);
		strcpy(&q_text[12][0]," ");
		if(queue[0]!=7)
		q_button[6].Move(205.0f,230,-90.0f);
	}

	return TRUE;
}
/////////////////////////////////////
BOOL cApp::RandName(char *name)
{
	//set value of randname
	char tempname,tempnum[10];
	int randnum;
	randnum=rand() % 1000;
	_itoa(randnum,tempnum,10);

	switch(rand() % 26)
	{
		case 0	:	strcpy(&tempname,"A");break;
		case 1	:	strcpy(&tempname,"B");break;
		case 2	:	strcpy(&tempname,"C");break;
		case 3	:	strcpy(&tempname,"D");break;
		case 4	:	strcpy(&tempname,"E");break;
		case 5	:	strcpy(&tempname,"F");break;
		case 6	:	strcpy(&tempname,"G");break;
		case 7	:	strcpy(&tempname,"H");break;
		case 8	:	strcpy(&tempname,"I");break;
		case 9	:	strcpy(&tempname,"J");break;
		case 10	:	strcpy(&tempname,"K");break;
		case 11	:	strcpy(&tempname,"L");break;
		case 12	:	strcpy(&tempname,"M");break;
		case 13	:	strcpy(&tempname,"N");break;
		case 14	:	strcpy(&tempname,"O");break;
		case 15	:	strcpy(&tempname,"P");break;
		case 16	:	strcpy(&tempname,"Q");break;
		case 17	:	strcpy(&tempname,"R");break;
		case 18	:	strcpy(&tempname,"S");break;
		case 19	:	strcpy(&tempname,"T");break;
		case 20	:	strcpy(&tempname,"U");break;
		case 21	:	strcpy(&tempname,"V");break;
		case 22	:	strcpy(&tempname,"W");break;
		case 23	:	strcpy(&tempname,"X");break;
		case 24	:	strcpy(&tempname,"Y");break;
		case 25	:	strcpy(&tempname,"Z");break;
	}

	strcat(&tempname,tempnum);
	strcpy(name, &tempname);

	return TRUE;
}
/////////////////////////////////////
bool cApp::closequeue()
{
	m_Graphics.Shutdown();
	MD2.Free();
	m_Window.Free();
	m_Font.Free();

	bgtext_r.Free();
	bgtext_b.Free();
	bgtext_l.Free();
	bgtext_t.Free();

	Plane.Free();
	for(short j=0;j<7;j++)
		q_button[j].Free();
	Queue_yes = false;
	return true;
}
/////////////////////////////////////
/////////////////////////////////////
//Linklist Function
/////////////////////////////////////
bool cApp::initlinklist()
{
	pos_state = 0;
  mouseX=mouseY = 0;
  strcpy(password,"");
  keyboard = false;
  u_pass = "";
   box[0].SetComponent(&m_NodeTreeMesh);
  box[1].SetComponent(&m_NodeTreeMesh);
  box[2].SetComponent(&m_NodeTreeMesh);
  box[3].SetComponent(&m_NodeTreeMesh);
  box[4].SetComponent(&m_NodeTreeMesh);
  box[5].SetComponent(&m_NodeTreeMesh);
  box[6].SetComponent(&m_NodeTreeMesh);
  box[7].SetComponent(&m_NodeTreeMesh);
  box[8].SetComponent(&m_NodeTreeMesh);
  box[9].SetComponent(&m_NodeTreeMesh);

  box[0].Move(-220.0f,10,-100.0f);
  box[1].Move(-110.0f,10,100.0f);
  box[2].Move(-450.0f,10,-100.0f);
  box[3].Move(-600.0f,10,-100.0f);
  box[4].Move(50.0f,10,-100.0f);
  box[5].Move(250.0f,10,-100.0f);
  box[6].Move(-500.0f,10,100.0f);
  box[7].Move(70.0f,10,100.0f);
  box[8].Move(300.0f,10,100.0f);
  box[9].Move(-220.0f,10,100.0f);

  box[0].Scale(0.2f,0.2f,0.2f);
  box[1].Scale(0.2f,0.2f,0.2f);
  box[2].Scale(0.2f,0.2f,0.2f);
  box[3].Scale(0.2f,0.2f,0.2f);
  box[4].Scale(0.2f,0.2f,0.2f);
  box[5].Scale(0.2f,0.2f,0.2f);
  box[6].Scale(0.2f,0.2f,0.2f);
  box[7].Scale(0.2f,0.2f,0.2f);
  box[8].Scale(0.2f,0.2f,0.2f);
  box[9].Scale(0.2f,0.2f,0.2f);

  box[0].SetFileAnimation("graphic\\knight\\tris.ini");
	box[1].SetFileAnimation("graphic\\knight\\tris.ini");
	box[2].SetFileAnimation("graphic\\knight\\tris.ini");
	box[3].SetFileAnimation("graphic\\knight\\tris.ini");
	box[4].SetFileAnimation("graphic\\knight\\tris.ini");
	box[5].SetFileAnimation("graphic\\knight\\tris.ini");
	box[6].SetFileAnimation("graphic\\knight\\tris.ini");
	box[7].SetFileAnimation("graphic\\knight\\tris.ini");
	box[8].SetFileAnimation("graphic\\knight\\tris.ini");
	box[9].SetFileAnimation("graphic\\knight\\tris.ini");

	box[0].LoadAnimation("stand");
	box[1].LoadAnimation("stand");
	box[2].LoadAnimation("stand");
	box[3].LoadAnimation("stand");
	box[4].LoadAnimation("stand");
	box[5].LoadAnimation("stand");
	box[6].LoadAnimation("stand");
	box[7].LoadAnimation("stand");
	box[8].LoadAnimation("stand");
	box[9].LoadAnimation("stand");

	box[0].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[1].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[2].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[3].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[4].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[5].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[6].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[7].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[8].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");
	box[9].LoadModelMd2(&m_Graphics,"GRAPHIC//linklist//box606030.md2","GRAPHIC//linklist//tab1.jpg");

	game.init();
	m_Font.Create(&m_Graphics,"Arial",20,TRUE);
  m_showtime.Create(&m_Graphics,"Arial",20,TRUE);
  m_input.Create(&m_Graphics,"Arial",40,TRUE);
  m_Window.Create(&m_Graphics,&m_Font);
  m_Window.Create(&m_Graphics,&m_showtime);
  m_Window.Create(&m_Graphics,&m_input);
	return true;
}
/////////////////////////////////////
void cApp::enterpass(char *c_MMSG)
{
	char tmp_MSG[2];

	if(strcmp(c_MMSG,"KEY 0") == 0)strcpy(tmp_MSG,"0");
	if(strcmp(c_MMSG,"KEY 1") == 0)strcpy(tmp_MSG,"1");
	if(strcmp(c_MMSG,"KEY 2") == 0)strcpy(tmp_MSG,"2");
	if(strcmp(c_MMSG,"KEY 3") == 0)strcpy(tmp_MSG,"3");
	if(strcmp(c_MMSG,"KEY 4") == 0)strcpy(tmp_MSG,"4");
	if(strcmp(c_MMSG,"KEY 5") == 0)strcpy(tmp_MSG,"5");
	if(strcmp(c_MMSG,"KEY 6") == 0)strcpy(tmp_MSG,"6");
	if(strcmp(c_MMSG,"KEY 7") == 0)strcpy(tmp_MSG,"7");
	if(strcmp(c_MMSG,"KEY 8") == 0)strcpy(tmp_MSG,"8");
	if(strcmp(c_MMSG,"KEY 9") == 0)strcpy(tmp_MSG,"9");

	char *tmp_pass;
	int count = game.user_passcount();
	tmp_pass = game.user_passget();
	if(count < 4)
	{	
		if(count != 0)
		{
			strcat(tmp_pass,tmp_MSG);
		}
		else
			strcpy(tmp_pass,tmp_MSG);
	
		game.user_passset(tmp_pass);
	}

		strcpy(c_MMSG,tmp_pass);
	
}
/////////////////////////////////////
bool cApp::clickkeyboard(char *c_MSG)
{
		if((mouseX > 617) && (mouseX < 750) && (mouseY > 340) && (mouseY < 399)){strcpy(c_MSG,"KEY 9");return true;}
		if((mouseX > 436) && (mouseX < 559) && (mouseY > 340) && (mouseY < 399)){strcpy(c_MSG,"KEY 8");return true;}
		if((mouseX > 262) && (mouseX < 353) && (mouseY > 340) && (mouseY < 399)){strcpy(c_MSG,"KEY 7");return true;}
		if((mouseX > 621) && (mouseX < 764) && (mouseY > 412) && (mouseY < 509)){strcpy(c_MSG,"KEY 6");return true;}
		if((mouseX > 436) && (mouseX < 559) && (mouseY > 412) && (mouseY < 509)){strcpy(c_MSG,"KEY 5");return true;}
		if((mouseX > 252) && (mouseX < 342) && (mouseY > 412) && (mouseY < 509)){strcpy(c_MSG,"KEY 4");return true;}
		if((mouseX > 628) && (mouseX < 777) && (mouseY > 532) && (mouseY < 609)){strcpy(c_MSG,"KEY 3");return true;}
		if((mouseX > 432) && (mouseX < 564) && (mouseY > 532) && (mouseY < 609)){strcpy(c_MSG,"KEY 2");return true;}
		if((mouseX > 237) && (mouseX < 531) && (mouseY > 532) && (mouseY < 609)){strcpy(c_MSG,"KEY 1");return true;}
		if((mouseX > 427) && (mouseX < 564) && (mouseY > 622) && (mouseY < 699)){strcpy(c_MSG,"KEY 0");return true;}
		if((mouseX > 224) && (mouseX < 326) && (mouseY > 422) && (mouseY < 699))
		{
			strcpy(c_MSG,"KEY C");			
			keyboard = false;
			return true;
		}
		if((mouseX > 633) && (mouseX < 787) && (mouseY > 422) && (mouseY < 699)){strcpy(c_MSG,"KEY E");return true;}		

		return false;
}
/////////////////////////////////////
bool cApp::clickitem(char *c_MSG)
{
	if(pos_state == 0)
	{
		if((mouseX > 255) && (mouseX < 292) && (mouseY > 472) && (mouseY < 488)){strcpy(c_MSG,"BOX 1");return true;}
		if((mouseX > 343) && (mouseX < 364) && (mouseY > 441) && (mouseY < 453)){strcpy(c_MSG,"BOX 2");return true;}
		if((mouseX > 396) && (mouseX < 442) && (mouseY > 423) && (mouseY < 431)){strcpy(c_MSG,"BOX 3");return true;}
		if((mouseX > 611) && (mouseX < 628) && (mouseY > 422) && (mouseY < 432)){strcpy(c_MSG,"BOX 9");return true;}
		if((mouseX > 627) && (mouseX < 644) && (mouseY > 430) && (mouseY < 440)){strcpy(c_MSG,"BOX 8");return true;}
		if((mouseX > 662) && (mouseX < 687) && (mouseY > 443) && (mouseY < 456)){strcpy(c_MSG,"BOX 7");return true;}
		if((mouseX > 765) && (mouseX < 806) && (mouseY > 483) && (mouseY < 503)){strcpy(c_MSG,"BOX 6");return true;}
	}
	if(pos_state == 1)
	{
		if((mouseX > 272) && (mouseX < 307) && (mouseY > 462) && (mouseY < 481)){strcpy(c_MSG,"BOX 3");return true;}
		if((mouseX > 358) && (mouseX < 381) && (mouseY > 434) && (mouseY < 447)){strcpy(c_MSG,"BOX 4");return true;}
		if((mouseX > 386) && (mouseX < 405) && (mouseY > 424) && (mouseY < 435)){strcpy(c_MSG,"BOX 5");return true;}
		if((mouseX > 634) && (mouseX < 655) && (mouseY > 431) && (mouseY < 442)){strcpy(c_MSG,"BOX 0");return true;}
		if((mouseX > 714) && (mouseX < 750) && (mouseY > 463) && (mouseY < 481)){strcpy(c_MSG,"BOX 9");return true;}
		if((mouseX > 787) && (mouseX < 836) && (mouseY > 490) && (mouseY < 518)){strcpy(c_MSG,"BOX 8");return true;}
		
	}	
	if(pos_state == 2)
	{
		
		if((mouseX > 72) && (mouseX < 140) && (mouseY > 529) && (mouseY < 561)){strcpy(c_MSG,"BOX 4");return true;}
		if((mouseX > 249) && (mouseX < 286) && (mouseY > 470) && (mouseY < 491)){strcpy(c_MSG,"BOX 5");return true;}
		if((mouseX > 815) && (mouseX < 871) && (mouseY > 508) && (mouseY < 530)){strcpy(c_MSG,"BOX 0");return true;}
		if((mouseX > 456) && (mouseX < 567) && (mouseY > 300) && (mouseY < 500)){strcpy(c_MSG,"DOOR");return true;}
	}
	return false;
}
///////////////////////////////////////////////////////////////////////////////////
bool cApp::closelinklist()
{
	m_NodeTreeMesh.Free();
	m_Mesh.Free();
	door_lock.Free();
  box[0].Free();
  box[1].Free();
  box[2].Free();
  box[3].Free();
  box[4].Free();
  box[5].Free();
  box[6].Free();
  box[7].Free();
  box[8].Free();
  box[9].Free();  
  

  m_Font.Free();
  m_input.Free();
  m_showtime.Free();
  m_Window.Free();
  Linklist_yes = false;
  return true;

}
/////////////////////////////////////
/////////////////////////////////////
//Recursive Function
/////////////////////////////////////
bool cApp::initrecursive()
{
	M_Text1 = "Recursive : Tower of Hanoi";
	M_Text2 = "Press 3 or 4 or 5";

	M_Recur[0]="	move(level,current,temp,target)";
	M_Recur[1]="		if level=1 then";
	M_Recur[2]="			move 1 to target";
	M_Recur[3]="		else";
	M_Recur[4]="			move(level-1,current,target,temp)";
	M_Recur[5]="			move level to target";
	M_Recur[6]="			move(level-1,temp,current,target)";

	t_a="A";
	t_b="B";
	t_c="C";

	delay=1000;

	for(int i=0;i<7;i++)
	{
		red[i]=255;green[i]=200;blue[i]=200;
	}

	b1.SetComponent(&m_NodeTreeMesh);
	b1.Move(-200.0f,  20,-100.0f);
	b1.Scale(0.5f, 1, 0.5f);

	b2.SetComponent(&m_NodeTreeMesh);
	b2.Move(-200.0f,  10,-100.0f);
	b2.Scale(0.7f, 1, 0.7f);

	b3.SetComponent(&m_NodeTreeMesh);
	b3.Move(-200.0f,   0,-100.0f);
	b3.Scale(0.9f, 1, 0.9f);

	b4.SetComponent(&m_NodeTreeMesh);
	b4.Move(-1200.0f,   0,-200.0f);
	b4.Scale(1.1f, 1, 1.1f);

	b5.SetComponent(&m_NodeTreeMesh);
	b5.Move(-1200.0f,   0, 200.0f);
	b5.Scale(1.3f, 1, 1.3f);
	b1.SetFileAnimation("graphic\\knight\\tris.ini");
	b2.SetFileAnimation("graphic\\knight\\tris.ini");
	b3.SetFileAnimation("graphic\\knight\\tris.ini");
	b4.SetFileAnimation("graphic\\knight\\tris.ini");
	b5.SetFileAnimation("graphic\\knight\\tris.ini");

	b1.LoadAnimation("stand");
	b2.LoadAnimation("stand");
	b3.LoadAnimation("stand");
	b4.LoadAnimation("stand");
	b5.LoadAnimation("stand");
	b1.LoadModelMd2(&m_Graphics,"GRAPHIC//hanoi//ring40.md2","GRAPHIC//hanoi//disk1.bmp");
	b2.LoadModelMd2(&m_Graphics,"GRAPHIC//hanoi//ring40.md2","GRAPHIC//hanoi//disk2.bmp");
	b3.LoadModelMd2(&m_Graphics,"GRAPHIC//hanoi//ring40.md2","GRAPHIC//hanoi//disk3.bmp");
	b4.LoadModelMd2(&m_Graphics,"GRAPHIC//hanoi//ring40.md2","GRAPHIC//hanoi//disk4.bmp");
	b5.LoadModelMd2(&m_Graphics,"GRAPHIC//hanoi//ring40.md2","GRAPHIC//hanoi//disk5.bmp");

	F_Text.Create(&m_Graphics,"Arial",35,TRUE);
	W_Text.Create(&m_Graphics,&F_Text);
	return true;
}
///////////////////////////////////////////////////////////////////////////////////
bool cApp::closerecursive()
{
	m_NodeTreeMesh.Free();
	m_Mesh.Free();
	b1.Free();
	b2.Free();
	b3.Free();
	b4.Free();
	b5.Free();
	F_Text.Free();
	W_Text.Free();
	Recur_yes = false;
	return true;
}
/////////////////////////////////////
int PASCAL WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR szCmdLine, int nCmdShow)
{
  cApp App;
  return App.Run();
}
