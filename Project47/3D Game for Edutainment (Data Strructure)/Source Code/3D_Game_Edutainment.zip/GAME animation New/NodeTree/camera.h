#ifndef _CORE_GLOBAL_H_
#include "Core_Global.h"
#endif

class cCamera_tool:public cCamera
{
protected:
	FLOAT m_fdmouseX;
	FLOAT m_fdmouseY;
	FLOAT m_fZoom;
	FLOAT m_fRotateBase;

public:
	cCamera_tool();
	~cCamera_tool();
protected:
	BOOL PointRel(FLOAT XEyeAdd,FLOAT YEyeAdd,FLOAT ZEyeAdd ,FLOAT XAtBase ,FLOAT YAtBase,FLOAT ZAtBase);
public:
	BOOL ThirdViewXYPlain(FLOAT dmouseX,FLOAT dmouseY,FLOAT XAtBase ,FLOAT YAtBase,FLOAT ZAtBase);
	BOOL Zoom(FLOAT zoom);
	BOOL ZoomRel(FLOAT zoomrel);
	FLOAT GetYRotation();
	BOOL SetRotateBase(FLOAT rotate);
	BOOL RotateBaseRel(FLOAT rotateRel);
	FLOAT GetZoom();
	
	/*FirstViewXYPlain*/
	BOOL FirstViewXYPlain(FLOAT dmouseX,FLOAT dmouseY,FLOAT XPos ,FLOAT YPos,FLOAT ZPos);






};

#ifndef _FRUSTUM_H_
#include "Frustum.h"
#endif

#ifndef _NODETREE_H_
#include "NodeTree.h"
#endif

#ifndef _CMD2_OBJ_H_
#include "cMD2_Obj.h"
#endif
class cCamera_obj:public cCamera_tool
{


private:
		cNodeTreeMesh *m_pnodetree;
public:
	cMD2_Obj *m_pMD2Obj;

	cCamera_obj();
	~cCamera_obj();

	void SetComponent(cNodeTreeMesh *nodetree,cMD2_Obj *pMD2);
/*
	BOOL Camera3RDViews(FLOAT Elapsed,FLOAT CamAngleX,FLOAT CamAngleY,FLOAT XPos ,FLOAT YPos,FLOAT ZPos);
	BOOL CameraFSTViews(FLOAT Elapsed,FLOAT CamAngleX,FLOAT CamAngleY,FLOAT XPos ,FLOAT YPos,FLOAT ZPos);
*/
	BOOL Camera_Obj(FLOAT Elapsed,FLOAT dmouseX,FLOAT dmouseY,BOOL bmode);
};