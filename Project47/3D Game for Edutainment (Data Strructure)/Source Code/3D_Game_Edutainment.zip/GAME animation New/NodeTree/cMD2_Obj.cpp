// cMD2_Obj.cpp: implementation of the cMD2_Obj class.
//
//////////////////////////////////////////////////////////////////////

#include "cMD2_Obj.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

cMD2_Obj::cMD2_Obj()
{
	m_ZMove=m_XMove=m_YMove=0;
	m_XSlide=m_YSlide=m_ZSlide=0;
	m_flag1=m_flag2=FALSE;
	m_Head=m_Leg=0;
	cMD2_tool::cMD2_tool();
}


cMD2_Obj::~cMD2_Obj()
{
	cMD2_tool::~cMD2_tool();
}

BOOL cMD2_Obj::LoadModelMd2(cGraphics *Graphic,char *filename,char *texture)
{ BOOL bret;
	//load before calculate radius
	bret=cMD2_tool::LoadModelMd2(Graphic,filename,texture);
	FLOAT MaxX,MaxY,MaxZ,MinX,MinY,MinZ;
	this->GetBound(MaxX,MaxY,MaxZ,MinX,MinY,MinZ);
	//use mean sqr radius cause's it is vector
	m_XZRadius= sqrt( sqr((MaxX-MinX)/2) +sqr((MaxZ-MinZ)/2) )/1.414;
	m_XYZRadius=sqrt( sqr(2*m_XZRadius)  +sqr((MaxY-MinY)/2) )/1.414;
	m_Leg=-MinY;
	m_Head=MaxY;

	return bret;
}
void cMD2_Obj::SetComponent(cNodeTreeMesh *Nodetree)
{
	m_pnodetree=Nodetree;
}
//in original meaning is circle radius 1
void cMD2_Obj::MoveFront(FLOAT speed)
{
    m_XMove += (FLOAT)sin(cMD2_tool::GetYRotation()) *speed;
    m_ZMove += (FLOAT)cos(cMD2_tool::GetYRotation()) *speed;
	m_flag1=TRUE;
}
void cMD2_Obj::MoveBack(FLOAT speed)
{
    m_XMove += -(FLOAT)sin(cMD2_tool::GetYRotation()) *speed;
    m_ZMove += -(FLOAT)cos(cMD2_tool::GetYRotation()) *speed;
	m_flag1=TRUE;
}
void cMD2_Obj::MoveLeft(FLOAT speed)
{
	m_XMove += (FLOAT)sin(cMD2_tool::GetYRotation()- 1.57f) *speed;
    m_ZMove += (FLOAT)cos(cMD2_tool::GetYRotation()- 1.57f) *speed;
	m_flag2=TRUE;
}
void cMD2_Obj::MoveRight(FLOAT speed)
{
	m_XMove += (FLOAT)sin(cMD2_tool::GetYRotation()+ 1.57f) *speed;
    m_ZMove += (FLOAT)cos(cMD2_tool::GetYRotation()+ 1.57f) *speed;
	m_flag2=TRUE;
}

void cMD2_Obj::MoveDown(FLOAT speed)
{	
	m_YMove+= -1 *speed;
}
void cMD2_Obj::MoveUp(FLOAT speed)
{	
	m_YMove+= 1 *speed;
}
void cMD2_Obj::Slide(FLOAT speedX,FLOAT speedY,FLOAT speedZ)
{
	m_XSlide += speedX;
    m_YSlide += speedY;
	m_ZSlide += speedZ;

}


void cMD2_Obj::CheckEarthMoveMent(FLOAT Elapsed,BOOL *bfootonearth)
{
  FLOAT      XPos,YPos,ZPos,Height, Diff, Dist; 
  D3DXVECTOR2   vecDir;
if(bfootonearth!=NULL)
  *bfootonearth =FALSE;
  
	XPos=cMD2_tool::GetXPos();
	YPos=cMD2_tool::GetYPos()-m_Leg; //from mid to model foot
	ZPos=cMD2_tool::GetZPos();

	//press 2 key the speed not go up but change dir from key move
	if(m_flag1&&m_flag2)
	{
	m_XMove /= 1.414f;
	m_ZMove /= 1.414f;
	}

	//force affect
	m_XMove+=m_XSlide;
	m_YMove+=m_YSlide;
	m_ZMove+=m_ZSlide;

	//update by time
	m_XMove *= Elapsed;
	m_YMove *= Elapsed;
	m_ZMove *= Elapsed;

	//can't jump if foot not on ground
	
	//MinY/2 = half of model leg
  Height = m_pnodetree->GetHeightBelow(XPos, YPos +m_Leg/2, ZPos);
  

        //can't move up if head found upper ceiling
	if(m_YMove>0)
	{
		if(m_pnodetree->CheckIntersect(XPos, this->GetYPos(), ZPos
									   ,XPos,this->GetYPos()+m_Head+m_YMove,ZPos
									   ,NULL))
		{

			m_YMove=0;


		}
	}

  if(YPos > Height) {
    // Dropping
    if(YPos +m_YMove < Height)
	{
      //YPos = Height;//if can't go stop moving cause'n it will drop from the trend area
	  m_YMove=Height-YPos;

	  if(bfootonearth!=NULL)
	  *bfootonearth=TRUE;
	}
        
  } else {

	//jump can be(Move up canbe) but can't move down
	if(m_YMove<0)
	m_YMove=0;
	
	if(bfootonearth!=NULL)
	*bfootonearth=TRUE;
	
	 // Climbing
    //YPos = Height;
	m_YMove+=Height-YPos;
  }	

  // Check for movement collisions -
  // can't walk past anything blocking path
  if( TRUE==m_pnodetree->CheckIntersect(XPos,YPos+m_Leg/2 , ZPos,
										XPos + m_XMove, YPos+m_Leg/2 /*+ m_YMove*/, ZPos + m_ZMove,
										&Dist) ) 
  {
    // Adjust coordinates to be exactly 2.5 units away from target
    Diff = Dist - 2.5f;
    D3DXVec2Normalize(&vecDir, &D3DXVECTOR2(m_XMove, m_ZMove));
    vecDir *= Diff;
    m_XMove = vecDir.x;
    m_ZMove = vecDir.y;
  }

	
	//YPos += m_Leg;//model middle
}

void cMD2_Obj::UpdateMoveMent()
{
	cMD2_tool::MoveRel(m_XMove,m_YMove,m_ZMove);

	//reset it
	m_XMove=m_YMove=m_ZMove=0;
	m_XSlide=m_YSlide=m_ZSlide=0;
	m_flag1=m_flag2=FALSE;
}

void cMD2_Obj::Checkcollision(cMD2_Obj *MD2,BOOL *bFootOnObj)
{ 
  BOOL bfootonobj=FALSE;
  FLOAT      thisHeight,thisLeg,ObjHeight,ObjLeg;
	////height of this obj
	thisLeg=this->GetYPos()-m_Leg; //from mid to model foot
	thisHeight=this->GetYPos()+m_Head;

	//height of compare obj
	ObjHeight=MD2->GetYPos()+MD2->m_Head;
	ObjLeg	 =MD2->GetYPos()-MD2->m_Leg;


	
	//if model move near other it can't move in same line
	if( sqr( (MD2->GetXPos()/*+MD2->m_XMove*/) - (this->GetXPos() + this->m_XMove/**Elapsed*/ ) )+       
		sqr( (MD2->GetZPos()/*+MD2->m_ZMove*/) - (this->GetZPos() + this->m_ZMove/**Elapsed*/ ) )
		<
		sqr(MD2->m_XZRadius+ this->m_XZRadius))
	{

		if(thisLeg<ObjHeight&&thisLeg>MD2->GetYPos())
		{	//0.0001 for fix float bug can't compare equal figure
			MoveRel(0,ObjHeight-thisLeg+0.0001f,0);

			//update new value
			thisLeg=this->GetYPos()-m_Leg; //from mid to model foot
			thisHeight=this->GetYPos()+m_Head;

			//update new value	
			ObjHeight=MD2->GetYPos()+MD2->m_Head;
			ObjLeg	 =MD2->GetYPos()-MD2->m_Leg;
			

			m_YMove=MD2->m_YMove;

		 if(MD2->m_YMove>0)
		 {//fix bug stream +0.0001
			m_XMove+=MD2->m_XMove;	
			m_YMove+=MD2->m_YMove;
			m_ZMove+=MD2->m_ZMove;
			//cause's when move down in update it occur collide and do in below 
			bfootonobj =TRUE;
		 }


		}
		//my legs are higher than objhead
		if(thisLeg>=ObjHeight)
		{
			if(thisLeg + m_YMove/**Elapsed*/ <=ObjHeight+MD2->m_YMove+0.0001f)//i'm downing?
			{

			//this->m_YMove=0;//can't move down IDEAL
			this->m_YMove=(ObjHeight-thisLeg)/*/Elapsed*/;//in real!! move until near Obj head
	
			//foot on obj!!

			//advance when obj go? this.m_move +=Obj.m_move 
			//when i'm on the obj it will take me too if i not move
			m_XMove+=MD2->m_XMove;
			m_YMove+=MD2->m_YMove;
			m_ZMove+=MD2->m_ZMove;
			bfootonobj =TRUE;
			}
		}
	
		//if(thisLeg>ObjHeight||ObjLeg>thisHeight) not collision
		if(thisLeg/*+m_YMove*/<ObjHeight &&ObjLeg<thisHeight/*+m_YMove*/)
		{
		this->m_XMove=0;
		this->m_ZMove=0;
		}

		//if downing model take upper collide upper will stop
		if(m_pnodetree->CheckIntersect(this->GetXPos(),this->GetYPos()+m_Head,this->GetZPos()
									,this->GetXPos()+this->m_XMove,this->GetYPos()+m_Head/*+this->m_YMove*/,this->GetZPos()+this->m_ZMove
									,NULL))
		{
		this->m_XMove=0;
		this->m_ZMove=0;
		}

		//if collide upper ceiling down obj  will swap up
		if(m_pnodetree->CheckIntersect(this->GetXPos(),this->GetYPos()+m_Head,this->GetZPos()
									,this->GetXPos(),this->GetYPos()+m_Head+this->m_YMove,this->GetZPos()
									,NULL))
		{
		this->m_YMove-=(MD2->m_Head+this->GetYPos());//move down swaping belowing model (below is upper now and stand on me after next checkmodelcollision)
		}


	}

//comment don't need myhead under obj leg cause's when i jump the obj still on my head(by link list checking)	

		if(bFootOnObj!=NULL)
		*bFootOnObj=bfootonobj;
}