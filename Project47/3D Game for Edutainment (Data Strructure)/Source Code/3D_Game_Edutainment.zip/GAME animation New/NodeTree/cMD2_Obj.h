// cMD2_Obj.h: interface for the cMD2_Obj class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _CMD2_OBJ_H_
#define	_CMD2_OBJ_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef	 _MD2TOOL_H_
#include "MD2tool.h"
#endif

#ifndef _FRUSTUM_H_
#include "Frustum.h"
#endif

#ifndef _NODETREE_H_
#include "NodeTree.h"
#endif

#define sqr(x) (x)*(x)


class cMD2_Obj : public cMD2_tool  
{
private:

	cNodeTreeMesh *m_pnodetree;

public:
	FLOAT m_XMove,m_YMove,m_ZMove;
	FLOAT m_XSlide,m_YSlide,m_ZSlide;
	FLOAT m_XYZRadius,m_XZRadius,m_Leg,m_Head;
	BOOL m_flag1,m_flag2;//if press 2 key  total must div sqrt(2)


public:
	cMD2_Obj();
	
	virtual ~cMD2_Obj();

void SetComponent(cNodeTreeMesh *Nodetree);

BOOL LoadModelMd2(cGraphics *Graphic,char *filename,char *texture);
	
void MoveFront(FLOAT speed);

void MoveLeft(FLOAT speed);

void MoveRight(FLOAT speed);

void MoveBack(FLOAT speed);

void MoveDown(FLOAT speed);//same other movement by external force

void MoveUp(FLOAT speed);//same other movement by external force

void Slide(FLOAT speedX,FLOAT speedY,FLOAT speedZ);

void CheckEarthMoveMent(FLOAT Elapsed,BOOL *bfootonearth);

void UpdateMoveMent();

void Checkcollision(cMD2_Obj *MD2,BOOL *bFootOnObj);

};

#endif // !defined(AFX_CMD2_OBJ_H__0C315C62_35DF_4C9D_B28F_DE3662EAE5A1__INCLUDED_)
