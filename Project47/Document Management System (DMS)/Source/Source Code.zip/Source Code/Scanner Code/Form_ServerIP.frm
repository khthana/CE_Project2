VERSION 5.00
Begin VB.Form Form4 
   BackColor       =   &H00CAFDFF&
   Caption         =   "Server IP"
   ClientHeight    =   1185
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5370
   LinkTopic       =   "Form4"
   ScaleHeight     =   1185
   ScaleWidth      =   5370
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Cmd_ok 
      Caption         =   "OK"
      Height          =   495
      Left            =   3960
      TabIndex        =   2
      Top             =   360
      Width           =   1095
   End
   Begin VB.TextBox Text1 
      Height          =   495
      Left            =   960
      TabIndex        =   0
      Top             =   360
      Width           =   2655
   End
   Begin VB.Label Label1 
      BackColor       =   &H00CAFDFF&
      Caption         =   "Server IP"
      Height          =   495
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   855
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Cmd_ok_Click()
Call Set_IP
End Sub
Private Sub Set_IP()
MDIForm1.Set_IP (Text1.Text)
Open App.Path & "/" & "TMPIP.dat" For Output As #1
Write #1, Text1.Text
Close #1
MDIForm1.Winsock1.Close
MDIForm1.Winsock1.RemoteHost = MDIForm1.Get_IP()
MDIForm1.Winsock1.RemotePort = "5001"
Unload Me
End Sub

Private Sub Form_Load()
Text1.Text = MDIForm1.Get_IP
End Sub

Private Sub Form_Unload(Cancel As Integer)
Load Form2
MDIForm1.Show
End Sub

Private Sub Text1_KeyPress(KeyAscii As Integer)
If (KeyAscii = 13) Then Call Set_IP
End Sub
