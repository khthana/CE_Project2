VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Begin VB.Form Form1 
   Caption         =   "Server Status"
   ClientHeight    =   5235
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   7470
   LinkTopic       =   "Form1"
   Picture         =   "Form_Server.frx":0000
   ScaleHeight     =   5235
   ScaleWidth      =   7470
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox List1 
      Height          =   4740
      ItemData        =   "Form_Server.frx":6F75
      Left            =   360
      List            =   "Form_Server.frx":6F77
      TabIndex        =   0
      Top             =   240
      Width           =   6735
   End
   Begin MSWinsockLib.Winsock Winsock1 
      Index           =   0
      Left            =   7200
      Top             =   4440
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   375
      Left            =   600
      Top             =   4080
      Width           =   3015
      _ExtentX        =   5318
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   8
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   1
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   "Provider=MSDASQL.1;Password=test;Persist Security Info=True;User ID=root;Data Source=test"
      OLEDBString     =   "Provider=MSDASQL.1;Password=test;Persist Security Info=True;User ID=root;Data Source=test"
      OLEDBFile       =   ""
      DataSourceName  =   ""
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   ""
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
Private lSocket As Long

Dim sServerMsg As String
Dim sRequestID As String

Dim Valid_IP(1500) As String
Dim ID(1500) As Integer
Dim User_name(1500) As String
Dim sFile(1500) As String
Dim bFileArriving As Boolean
Dim sArriving As String
Dim valTotal As Long
Dim bSendingFile    As Boolean

Dim conn As ADODB.Connection
Dim rs As ADODB.Recordset
Dim fld As ADODB.Field
Dim sql As String

Private Sub Form_Load()

    lSocket = 0
    Winsock1(0).LocalPort = "5001"
    Winsock1(0).Close
    Winsock1(0).Listen
End Sub


Private Sub Winsock1_Close(index As Integer)
    Valid_IP(index) = ""
    Winsock1(index).Close
    Unload Winsock1(index)
    lSocket = lSocket - 1
End Sub
Private Sub Winsock1_ConnectionRequest(index As Integer, _
                            ByVal requestID As Long)
  If index = 0 Then
    sRequestID = requestID
    lSocket = lSocket + 1

    Load Winsock1(lSocket)
    Winsock1(lSocket).LocalPort = "5001"
    Winsock1(lSocket).Accept requestID
    Winsock1(lSocket).SendData "Start"
  End If
End Sub

Private Sub Winsock1_DataArrival(index As Integer, ByVal bytesTotal As Long)
    Dim sItemData As String
    Dim sData As String
    Dim sOutData As String
    Dim Data As String
    Dim nCount As Integer
    Dim i() As String
    Dim j() As String
If Me.WindowState = 1 Then Me.WindowState = 0
Dim StrValue As String

Winsock1(index).GetData StrValue
    Dim ifreefile
    If (Winsock1(index).RemoteHostIP) <> Valid_IP(index) Then
    
        If Left$(StrValue, 1) = "u" Then
            sArriving = Right(StrValue, Len(StrValue) - 1)
            nCount = Splite(sArriving, Chr$(0), i())
            sArriving = ""
            Call login(i(1), i(2), index)
        End If
    ElseIf Right$(StrValue, 7) = "Filecmp" Then
            bFileArriving = False
            sArriving = sArriving & Left$(StrValue, Len(StrValue) - 7)
            ifreefile = FreeFile
            If Dir(sFile(index)) <> "" Then
                Winsock1(index).SendData "File Already Exists"
            Else

                Open sFile(index) For Binary Access Write As #ifreefile
                Put #ifreefile, 1, sArriving
                Close #ifreefile
            
                ShellExecute 0, vbNullString, App.path & "\" & sFile(index), vbNullString, vbNullString, vbNormalFocus
                sArriving = ""
                Winsock1(index).SendData "Transfer Complete"
                
            End If
    ElseIf Left$(StrValue, 4) = "File" Then
            bFileArriving = True
            Data = Right$(StrValue, Len(StrValue) - 4)
            nCount = Splite(Data, Chr$(0), i())
            sFile(index) = i(1)
            If Dir(sFile(index)) <> "" Then
            Else
                Call InsertDB(index, i(1), i(3), i(2), i(4))
                nCount = Splite(i(1), "/", j())
                If (Len(i(4)) = 0) Then
                Call SaveLog(User_name(index) & " �� Insert File " & j(nCount))
                List1.AddItem (Now() & "  " & User_name(index) & " �� Insert File " & j(nCount))
                Else: Call SaveLog(User_name(index) & " �׹��� ID " & i(4) & "�׹����к�")
                      List1.AddItem (Now() & "  " & User_name(index) & " �׹��� ID " & i(4) & "�׹����к�")
                End If
            End If
    ElseIf bFileArriving Then
             sArriving = sArriving & StrValue
    ElseIf StrValue = "T_a_b" Then
            Call TableShow(index, 1, "")
    ElseIf Left$(StrValue, 7) = "F_i_l_e" Then
            Call TableShow(index, 2, Right$(StrValue, Len(StrValue) - 7))
    ElseIf StrValue = "L_i_s_t" Then
            Call TableShow(index, 3, "")
    ElseIf Left$(StrValue, 11) = "U_p_d_a_t_e" Then
            Data = Right$(StrValue, Len(StrValue) - 11)
            nCount = Splite(Data, Chr$(0), i())
            Call UpdateFile(index, i(1), i(2), i(3))
    ElseIf StrValue = "Disconnect" Then
            Winsock1(index).Close
            Call SaveLog(User_name(index) & " Log out")
            List1.AddItem (Now() & "  " & User_name(index) & " Log out")
    End If

End Sub

Private Sub login(user As String, pass As String, index As Integer)

  Dim n As Integer
  
     sql = "SELECT UserID,UserStatus,UserName FROM user WHERE UserName = """ & user & """ AND Password = """ & pass & """"
  'connect to MySQL server using MySQL ODBC 3.51 Driver
  Set conn = New ADODB.Connection

  conn.ConnectionString = "DRIVER={MySQL ODBC 3.51 Driver};" & "SERVER=localhost;" & " DATABASE=dms;" & "UID=" & Form2.getUser() & ";PWD=" & Form2.getPass() & "; OPTION=3"
  conn.Open
  Set rs = New ADODB.Recordset
  With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
 
  If .RecordCount <> 0 Then
    If rs!UserStatus = "sw" Then
        Valid_IP(index) = Winsock1(index).RemoteHostIP
        ID(index) = rs!UserID
        User_name(index) = rs!UserName
        Winsock1(index).SendData "pass"
        List1.AddItem (Now() & "  " & user & " ��ͤ�Թ������к�" & " IP: " & Valid_IP(index))
        Call SaveLog(user & " ��ͤ�Թ������к�")
    Else
        Winsock1(index).SendData "not_allow"
    End If
  Else
        Winsock1(index).SendData "nopass"
End If
  .Close
  End With
     conn.Close
End Sub

Private Sub TableShow(index As Integer, Mode As Integer, Path_file As String)
Dim Tmp, Tmp1 As String
Dim i, j As Integer
Dim name As String
Dim g As Integer
Dim gTmp As Integer
  
  
  conn.Open
  
  
  Set rs = New ADODB.Recordset
  
  sql = "SELECT T1.Group FROM user T1 WHERE T1.UserID = "
  sql = sql & ID(index)
  With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
  g = rs!group
  rs.Close
  
  With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  End With
  
  If Mode = 1 Then
  sql = "SELECT FolderPath FROM folderpermission WHERE GroupPermiss = " & g & " ORDER BY FolderPath"
  
  
  rs.Open sql
  Tmp = "P_a_t_h"
  For i = 1 To rs.RecordCount
  Tmp = Tmp & rs!FolderPath & Chr$(0)
  rs.MoveNext
  Next i
  Winsock1(index).SendData Tmp
  rs.Close
  
  ElseIf Mode = 2 Then
  sql = "Select Permission From folderpermission WHERE GroupPermiss = " & g & " And FolderPath = """ & Left$(Path_file, Len(Path_file) - 1) & "/"""
  rs.Open sql
  Tmp = rs!Permission
  rs.Close
  
  Tmp1 = "C:/AppServ/www/client/upload/" & Left$(Path_file, Len(Path_file) - 1)
  sql = "SELECT T1.FileID,T1.FileName,T1.Path,T1.FileStatus FROM file T1,permission T2 WHERE T1.FileID = T2.ID AND T1.FileStatus != ""UNUSE"" AND T1.Path = """ & Tmp1 & """ AND T2.GroupAllow = " & g
  rs.Open sql
  Tmp = "f_P_a_t_h" & Tmp & Chr$(0)
  For i = 1 To rs.RecordCount
  Tmp = Tmp & rs!FileID & Chr$(1) & rs!FileName & Chr$(1) & rs!path & Chr$(1) & rs!FileStatus & Chr$(0)
  rs.MoveNext
  Next i
  Winsock1(index).SendData Tmp
  
  rs.Close
  ElseIf Mode = 3 Then
  sql = "SELECT T1.UserName FROM user T1 WHERE T1.UserID = " & ID(index)

  With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
   name = rs!UserName
  rs.Close
  sql = "Select FileID , FileName , Path FROM file WHERE FileStatus = """ & name & """"

  With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
  Tmp = "Unrecent"
  For i = 1 To rs.RecordCount
  Tmp = Tmp & rs!FileID & Chr$(1) & rs!FileName & Chr$(1) & rs!path & Chr$(0)
  rs.MoveNext
  Next i
  rs.Close
  Winsock1(index).SendData Tmp
  End If
  conn.Close
End Sub

Function Splite(ByVal sSource_IN As String, ByVal sDelim_IN As String, sArray() As String) As Integer
   Dim nDelimLen As Integer
   Dim nFieldCount As Integer
   Dim sCurrent As String
   Dim nPos As Integer

   ' Split's the passed string into a number of elements
   ' separated by the indicated delimiter. These fields
   ' are then written into the array passed, which is 1
   ' based. The number of fields found is returned.
   Erase sArray
   nDelimLen = Len(sDelim_IN)
   sCurrent = sSource_IN
   Do
      ' look for the specified delimiter
      nPos = InStr(1, sCurrent, sDelim_IN)
      If nPos > 0 Then
         nFieldCount = nFieldCount + 1
         ReDim Preserve sArray(1 To nFieldCount)
         ' grab the string left of the delimiter and add
        ' to the array
         sArray(nFieldCount) = Left$(sCurrent, nPos - 1)
         ' cut the used portion off the string
         sCurrent = Mid$(sCurrent, nPos + nDelimLen)
      End If
   Loop Until nPos = 0
   
   If sCurrent <> "" Then
      ' Deal with the last item without a trailing delimiter
      nFieldCount = nFieldCount + 1
      ReDim Preserve sArray(1 To nFieldCount) As String
      sArray(nFieldCount) = sCurrent
   End If
   ' return the number of items in the array
   Splite = nFieldCount
End Function

Private Sub InsertDB(index As Integer, AllPath As String, path As String, Description As String, Mode As String)
Dim sql As String
Dim group As Integer
Dim name As String
Dim FileName As String
Dim sPath() As String
Dim nCount As Integer
Dim fpath As String
Dim i As Integer
Dim FileID As Integer
Dim fPermiss As String
Dim PMS As String
Dim rs2 As ADODB.Recordset

nCount = Splite(AllPath, "/", sPath())
FileName = sPath(nCount)
fpath = sPath(1)
For i = 2 To nCount - 1
fpath = fpath & "/" & sPath(i)
Next i

  conn.Open
sql = "SELECT T1.UserName , T1.Group FROM user T1 WHERE T1.UserID = " & ID(index)
  Set rs = New ADODB.Recordset
  With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
   group = rs!group
   name = rs!UserName
rs.Close

sql = "SELECT MAX(FileID) FROM file"
With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
FileID = rs.GetString + 1

rs.Close

If (Len(Mode) <> 0) Then
sql = "SELECT Permiss FROM permission WHERE ID = """ & Mode & """ AND GroupAllow = " & group
With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
PMS = rs!Permiss
rs.Close
End If


sql = "SELECT Permission FROM folderpermission WHERE GroupPermiss = " & group
sql = sql & " AND FolderPath = """ & path & """"
With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
fPermiss = rs!Permission
rs.Close


sql = "INSERT INTO file(FileID,FileName,Path,LastModify,PersonModify,Detail,Type,FileStatus) VALUES (" & FileID & ","
sql = sql & """" & FileName & """,""" & fpath & """,Now(),""" & name & """,""" & Description & """,""file"",""Y"")"
conn.Execute sql


If (Len(Mode) <> 0) Then
sql = "INSERT INTO permission(ID,GroupAllow,Permiss) VALUES (" & FileID & "," & group & ",""" & PMS & """)"
conn.Execute sql
Else:
sql = "INSERT INTO permission(ID,GroupAllow,Permiss) VALUES (" & FileID & "," & group & ",""RWS"")"
conn.Execute sql
End If


sql = "SELECT GroupPermiss FROM folderpermission WHERE FolderPath = """ & path & """ AND GroupPermiss != " & group
With rs
  .ActiveConnection = conn
  .CursorType = adOpenForwardOnly
  .CursorLocation = adUseClient
  .Open sql
  End With
  
    
If (Len(Mode) <> 0) Then
    For i = 1 To rs.RecordCount
    sql = "Select Permiss FROM permission WHERE ID = """ & Mode & """ AND GroupAllow = """ & rs!GroupPermiss & """"
  Set rs2 = New ADODB.Recordset
  With rs2
    .ActiveConnection = conn
    .CursorType = adOpenForwardOnly
    .CursorLocation = adUseClient
    .Open sql
  End With
    sql = "INSERT INTO permission(ID,GroupAllow,Permiss) VALUES (" & FileID & ",""" & rs!GroupPermiss & """,""" & rs2!Permiss & """)"
    conn.Execute sql
    rs.MoveNext
    Next i
    rs2.Close
ElseIf (Splite(path, "/", sPath()) > 1) Then
    For i = 1 To rs.RecordCount
    sql = "Select Permission FROM folderpermission WHERE FolderPath = """ & path & """ AND GroupPermiss = """ & rs!GroupPermiss & """"
    Set rs2 = New ADODB.Recordset
    With rs2
    .ActiveConnection = conn
    .CursorType = adOpenForwardOnly
    .CursorLocation = adUseClient
    .Open sql
    End With

    sql = "INSERT INTO permission(ID,GroupAllow,Permiss) VALUES (" & FileID & ",""" & rs!GroupPermiss & """,""" & rs2!Permission & """)"
    conn.Execute sql
    rs2.Close
    Next i
Else: For i = 1 To rs.RecordCount
        sql = "INSERT INTO permission(ID,GroupAllow,Permiss) VALUES (" & FileID & ",""" & rs!GroupPermiss & """,""R"")"
        conn.Execute sql
        rs.MoveNext
        Next i
End If
rs.Close


If (Len(Mode) = 0) Then
sql = "INSERT INTO virtual(VirtualPath,FileID) VALUES (""" & path & """," & FileID & ")"
        conn.Execute sql
Else:
        sql = "UPDATE virtual SET virtual.FileID = " & FileID & " WHERE virtual.FileID = " & Mode
        conn.Execute sql
End If

conn.Close

End Sub

Private Sub UpdateFile(index As Integer, FileID As String, FileName As String, AllPath As String)
  
  Call FileCopy(AllPath, "C:/AppServ/www/client/unuse/" & FileID & "_" & FileName)
  Call Kill(AllPath)
  conn.Open
  sql = "UPDATE file SET file.FileName = """ & FileID & "_" & FileName & """ , file.FileStatus = ""UNUSE"" , file.Path = ""C:/AppServ/www/client/unuse/"" WHERE file.FileID = " & FileID
  conn.Execute sql
  conn.Close
  Winsock1(index).SendData "U_Complete" & FileID
  
End Sub

Private Sub SaveLog(Log As String)
Dim nFile As Integer
    nFile = FreeFile
    
    Open "C:\AppServ\www\client\Log\LogFile123.php" For Binary As #nFile
    
    Put #nFile, LOF(nFile) + 1, "[" & Format$(Now, "dd-mm-yyyy hh:mm:ss") & "] " & Log & "<br>"
    
    Close #nFile
End Sub
