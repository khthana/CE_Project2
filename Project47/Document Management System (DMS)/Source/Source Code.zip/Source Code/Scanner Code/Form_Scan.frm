VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00CAFDFF&
   Caption         =   "Scan"
   ClientHeight    =   6690
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   9885
   DrawStyle       =   1  'Dash
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   6690
   ScaleWidth      =   9885
   Begin VB.Frame Frame1 
      BackColor       =   &H00CAFDFF&
      Caption         =   "Picture"
      Height          =   5655
      Left            =   480
      TabIndex        =   3
      Top             =   360
      Width           =   4815
      Begin VB.Image Image1 
         Height          =   5325
         Left            =   120
         Stretch         =   -1  'True
         Top             =   240
         Width           =   4575
      End
   End
   Begin VB.CommandButton Cmd_select 
      BackColor       =   &H00FFFF80&
      Caption         =   "Select Source"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5640
      TabIndex        =   2
      Top             =   480
      Width           =   1575
   End
   Begin VB.CommandButton Cmd_capture 
      BackColor       =   &H00FFFF80&
      Caption         =   "Capture"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   5640
      TabIndex        =   1
      Top             =   1320
      Width           =   1575
   End
   Begin VB.CommandButton Cmd_ok 
      Caption         =   "Ok"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   5880
      TabIndex        =   0
      Top             =   4800
      Width           =   1215
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim Selected As String

Private Sub Cmd_ok_Click()
Form3.Show
Me.Hide
End Sub

Private Sub Form_Load()
Form1.Width = MDIForm1.Width
Form1.Height = MDIForm1.Height
End Sub
Private Sub Cmd_capture_Click()
Dim err, iFileNum As Integer
Dim dat As IPictureDisp
Dim Tmp As Long
Dim I As Integer
TWAIN_SetHideUI (0)
Cmd_select.Enabled = False
Cmd_capture.Enabled = False
Cmd_ok.Enabled = False
hdib = TWAIN_Acquire(0)
If (hdib <> 0) Then
Tmp = DIB_WriteToJpeg(hdib, App.Path & "/Tmp.dat")
I = DIB_PutOnClipboard(hdib)
Image1.Picture = Clipboard.GetData(vbCFDIB)
Form3.Image1.Picture = Clipboard.GetData(vbCFDIB)
DIB_Free (hdib)
hdib = 0
End If
Cmd_select.Enabled = True
Cmd_capture.Enabled = True
Cmd_ok.Enabled = True
End Sub

Private Sub Cmd_select_Click()
r = TWAIN_SelectImageSource(Me.hWnd)
End Sub

Function Option_type() As String
Selected = ".jpg"
Option_type = Selected
End Function

Private Sub Option1_Click()
Selected = ".jpg"
End Sub

Private Sub Option2_Click()
Selected = ".bmp"
End Sub

Private Sub Option3_Click()
Selected = ".gif"
End Sub
