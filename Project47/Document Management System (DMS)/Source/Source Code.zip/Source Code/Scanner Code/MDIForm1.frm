VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.MDIForm MDIForm1 
   BackColor       =   &H00CAFDFF&
   Caption         =   "Document Management"
   ClientHeight    =   7095
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   9885
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   2  'CenterScreen
   Begin MSWinsockLib.Winsock Winsock1 
      Left            =   9120
      Top             =   3480
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      RemoteHost      =   "0"
   End
   Begin VB.Menu log_out 
      Caption         =   "Log Out"
      Index           =   2
      NegotiatePosition=   1  'Left
      WindowList      =   -1  'True
   End
   Begin VB.Menu server_IP 
      Caption         =   "ServerIP"
      Index           =   1
      NegotiatePosition=   1  'Left
   End
End
Attribute VB_Name = "MDIForm1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
Dim bFileArriving As Boolean
Dim sFile As String
Dim sArriving As String
Dim valTotal As Long
Dim bSendingFile    As Boolean
Dim server As String


Private Sub log_out_Click(Index As Integer)
On Error GoTo ErrLabel:
    Unload Form1
    Unload Form3
    Load Form2
    'server_IP
If Winsock1.State <> sckClosed Then
    Winsock1.SendData "Disconnect"
    DoEvents
    Winsock1.Close
End If
Exit Sub
ErrLabel:
End Sub

Private Sub MDIForm_Unload(Cancel As Integer)
On Error GoTo ErrLabel:
If Winsock1.State <> sckClosed Then
Winsock1.SendData "Disconnect"
DoEvents
End If
Exit Sub
ErrLabel:
End Sub

Private Sub MDIForm_Load()
Open App.Path & "/" & "TMPIP.dat" For Input As #1
Input #1, server
Close #1
MDIForm1.Winsock1.RemoteHost = MDIForm1.Get_IP()
MDIForm1.Winsock1.RemotePort = "5001"
Load Form2
End Sub

Private Sub Disconnect()
    Winsock1.Close
    Unload Form1
    Unload Form3
End Sub
Private Sub server_IP_Click(Index As Integer)
Load Form4
Form4.Show
MDIForm1.Hide

End Sub

Private Sub Winsock1_DataArrival(ByVal bytesTotal As Long)
    Dim nCount As Integer
    Dim nFolder As Integer
    Dim I, j As Integer
    Dim sPath() As String
    Dim fPath() As String
    Dim StrValue As String
    Dim TmpParent As String
    Dim Data As String
    
   On Error GoTo ErrLabel:
   Winsock1.GetData StrValue
   If (StrValue = "pass") Then
    Load Form3
    Form3.Show
    Unload Form2
   ElseIf (StrValue = "nopass") Then
   MsgBox "Password Incorrect", vbExclamation, "Password Incorrect"
   Form2.Text2.Text = ""
   ElseIf (StrValue = "not_allow") Then
   MsgBox "�س������Ѻ͹حҵ�����Scanner", vbExclamation, "Not Pass"
   Form2.Text2.Text = ""
   Form2.Text1.Text = ""
   ElseIf (StrValue = "Start") Then
   Winsock1.SendData ("u" + Form2.Text1.Text + Chr$(0) + DigestStrToHexStr(Form2.Text2.Text & Form2.Text1.Text))
   ElseIf (StrValue = "File Already Exists") Then
   MsgBox "File Already Exists", vbExclamation, "Error"
   ElseIf (StrValue = "Transfer Complete") Then
   MsgBox "Transfer Complete", vbOKOnly, "Transfer Complete"
   Winsock1.SendData "L_i_s_t"
   
   ElseIf Left$(StrValue, 8) = "Unrecent" Then
   Data = Right$(StrValue, Len(StrValue) - 8)
        Form3.ListView2.ListItems.Clear
        nCount = Splite(Data, Chr$(0), sPath())
        For I = 1 To nCount
            nFolder = Splite(sPath(I), Chr$(1), fPath())
            
            Form3.ListView2.ListItems.Add I, fPath(3) & Chr$(0) & fPath(2) & Chr$(0) & fPath(1), fPath(2) & "(" & Right$(fPath(3), Len(fPath(3)) - 29) & ")", 3, 3
        Next I
   
   ElseIf Left$(StrValue, 7) = "P_a_t_h" Then
   Data = Right$(StrValue, Len(StrValue) - 7)
   
    nCount = Splite(Data, Chr$(0), sPath())
   ' TreeView1.LineStyle = tvwRootLines
   
    For I = 1 To nCount
    nFolder = Splite(sPath(I), "/", fPath)
        TmpParent = ""
        If (nFolder = 1) Then
            Form3.TreeView1.Nodes.Add , , fPath(1) & "/", fPath(1), 1
        Else: For j = 1 To nFolder - 1
            TmpParent = TmpParent & fPath(j)
            TmpParent = TmpParent & "/"
            Next j
            Form3.TreeView1.Nodes.Add TmpParent, tvwChild, TmpParent & fPath(nFolder) & "/", fPath(nFolder), 1
        End If
    Next I
        Winsock1.SendData "L_i_s_t"
  
    ElseIf Left$(StrValue, 9) = "f_P_a_t_h" Then

        Data = Right$(StrValue, Len(StrValue) - 9)
        nCount = Splite(Data, Chr$(0), sPath())
        For I = 2 To nCount
            nFolder = Splite(sPath(I), Chr$(1), fPath())
            If (fPath(nFolder) = "Y") Then
            Form3.ListView1.ListItems.Add I - 1, Right$(fPath(3), Len(fPath(3)) - 29) & "/" & fPath(2), fPath(2), 3, 3
            Else:
            Form3.ListView1.ListItems.Add I - 1, Right$(fPath(3), Len(fPath(3)) - 29) & "/" & fPath(2), fPath(2) & "(���ѧ�١����� '" & fPath(nFolder) & "')", 3, 3
            End If
        Next I

    ElseIf Left$(StrValue, 10) = "U_Complete" Then
   Call SendData(App.Path & "/tmp.dat", "C:/AppServ/www/client/upload/" & Form3.Text2.Text & Form3.Text1.Text, MDIForm1.Winsock1, Right$(StrValue, Len(StrValue) - 10))
    End If
    
   Exit Sub
ErrLabel:
       
End Sub
Function Splite(ByVal sSource_IN As String, ByVal sDelim_IN As String, sArray() As String) As Integer
   Dim nDelimLen As Integer
   Dim nFieldCount As Integer
   Dim sCurrent As String
   Dim nPos As Integer

   ' Split's the passed string into a number of elements
   ' separated by the indicated delimiter. These fields
   ' are then written into the array passed, which is 1
   ' based. The number of fields found is returned.
   Erase sArray
   nDelimLen = Len(sDelim_IN)
   sCurrent = sSource_IN
   Do
      ' look for the specified delimiter
      nPos = InStr(1, sCurrent, sDelim_IN)
      If nPos > 0 Then
         nFieldCount = nFieldCount + 1
         ReDim Preserve sArray(1 To nFieldCount)
         ' grab the string left of the delimiter and add
        ' to the array
         sArray(nFieldCount) = Left$(sCurrent, nPos - 1)
         ' cut the used portion off the string
         sCurrent = Mid$(sCurrent, nPos + nDelimLen)
      End If
   Loop Until nPos = 0
   
   If sCurrent <> "" Then
      ' Deal with the last item without a trailing delimiter
      nFieldCount = nFieldCount + 1
      ReDim Preserve sArray(1 To nFieldCount) As String
      sArray(nFieldCount) = sCurrent
   End If
   ' return the number of items in the array
   Splite = nFieldCount
End Function


Public Sub SendData(sFile As String, sSaveAs As String, tcpCtl As Winsock, Mode As String)
  On Error GoTo ErrHandler
   Dim sSend As String, sBuf As String
   Dim ifreefile As Integer
   Dim lRead As Long, lLen As Long, lThisRead As Long, lLastRead As Long
   ifreefile = FreeFile

   Open sFile For Binary Access Read As #ifreefile
   lLen = LOF(ifreefile)

   
   Do While lRead < lLen
   lThisRead = 200000
   If lThisRead + lRead > lLen Then
     lThisRead = lLen - lRead
   End If
   If Not lThisRead = lLastRead Then
     sBuf = Space$(lThisRead)
   End If
   Get #ifreefile, , sBuf
   lRead = lRead + lThisRead
   sSend = sSend & sBuf
   Loop
   valTotal = lLen
   Close ifreefile
   bSendingFile = True
   
   tcpCtl.SendData "File" & sSaveAs & Chr$(0) & Form3.Text3.Text & Chr$(0) & Form3.Text2.Text & Chr$(0) & Mode & Chr$(0)
   DoEvents
   
   tcpCtl.SendData sSend
   DoEvents
   
   tcpCtl.SendData "Filecmp"
   bSendingFile = False
   Exit Sub
   
ErrHandler:
        MsgBox "Cannot connect to server", vbExclamation, "Error"
            Unload Form1
            Unload Form3
            Load Form2
        If Winsock1.State <> sckClosed Then
            Winsock1.SendData "Disconnect"
            DoEvents
            Winsock1.Close
End If

End Sub

Function Set_IP(IP As String)
server = IP
End Function

Function Get_IP()
Get_IP = server
End Function

