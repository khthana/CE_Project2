VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Log in"
   ClientHeight    =   6690
   ClientLeft      =   60
   ClientTop       =   450
   ClientWidth     =   9885
   LinkTopic       =   "Form2"
   MDIChild        =   -1  'True
   Picture         =   "Form_Connect.frx":0000
   ScaleHeight     =   6690
   ScaleWidth      =   9885
   WindowState     =   2  'Maximized
   Begin VB.PictureBox Picture2 
      Height          =   375
      Left            =   5280
      Picture         =   "Form_Connect.frx":4391
      ScaleHeight     =   315
      ScaleWidth      =   675
      TabIndex        =   3
      Top             =   3900
      Width           =   735
   End
   Begin VB.PictureBox Picture1 
      Height          =   375
      Left            =   4800
      Picture         =   "Form_Connect.frx":48FE
      ScaleHeight     =   315
      ScaleWidth      =   315
      TabIndex        =   2
      Top             =   3900
      Width           =   375
   End
   Begin VB.TextBox Text2 
      Height          =   375
      IMEMode         =   3  'DISABLE
      Left            =   4760
      PasswordChar    =   "*"
      TabIndex        =   1
      Top             =   3240
      Width           =   2175
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   4760
      TabIndex        =   0
      Top             =   2640
      Width           =   2175
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub login()
On Error GoTo ErrLabel:
MDIForm1.Winsock1.Close
MDIForm1.Winsock1.Connect

Exit Sub
ErrLabel: MsgBox "Cannot connect to server", vbOKOnly, "Error"
End Sub


Private Sub Form_Load()
Form2.Width = MDIForm1.Width
Form2.Height = MDIForm1.Height
MDIForm1.log_out(2).Enabled = False
MDIForm1.server_IP(1).Enabled = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
MDIForm1.server_IP(1).Enabled = False
MDIForm1.log_out(2).Enabled = True
End Sub

Private Sub Picture1_Click()
Call login
End Sub

Private Sub Picture2_Click()
Text1.Text = ""
Text2.Text = ""
End Sub

Private Sub Text2_KeyPress(KeyAscii As Integer)
If (KeyAscii = 13) Then Call login
End Sub

