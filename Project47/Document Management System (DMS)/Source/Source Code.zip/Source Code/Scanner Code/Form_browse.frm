VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Begin VB.Form Form3 
   Caption         =   "Upload Window"
   ClientHeight    =   6690
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   9885
   Icon            =   "Form_browse.frx":0000
   LinkTopic       =   "Form3"
   MDIChild        =   -1  'True
   Picture         =   "Form_browse.frx":000C
   ScaleHeight     =   6690
   ScaleWidth      =   9885
   WindowState     =   2  'Maximized
   Begin ComctlLib.ListView ListView2 
      Height          =   1695
      Left            =   6840
      TabIndex        =   16
      Top             =   3480
      Width           =   2655
      _ExtentX        =   4683
      _ExtentY        =   2990
      View            =   2
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   327682
      Icons           =   "ImageList1"
      SmallIcons      =   "ImageList1"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   0
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00C0C0FF&
      Caption         =   "Selected Picture"
      Height          =   2775
      Left            =   7440
      TabIndex        =   13
      Top             =   240
      Width           =   1935
      Begin VB.CommandButton Cmd_Scan 
         BackColor       =   &H8000000B&
         Caption         =   "Scan"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   350
         Left            =   960
         MaskColor       =   &H00C0C0FF&
         TabIndex        =   14
         Top             =   2350
         Width           =   840
      End
      Begin VB.Image Image1 
         Height          =   2055
         Left            =   120
         Stretch         =   -1  'True
         Top             =   240
         Width           =   1695
      End
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         BackColor       =   &H00C0C0FF&
         Caption         =   "Picture"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   222
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   15
         Top             =   2400
         Width           =   615
      End
   End
   Begin VB.CommandButton Cmd_update 
      Caption         =   "Update"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   8400
      TabIndex        =   11
      Top             =   5280
      Width           =   1095
   End
   Begin VB.CommandButton Cmd_send 
      Caption         =   "Send"
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Left            =   5400
      TabIndex        =   8
      Top             =   5040
      Width           =   1215
   End
   Begin VB.TextBox Text3 
      Height          =   735
      Left            =   1320
      TabIndex        =   6
      Top             =   5040
      Width           =   3975
   End
   Begin VB.TextBox Text2 
      Enabled         =   0   'False
      Height          =   375
      Left            =   1320
      TabIndex        =   4
      Top             =   4560
      Width           =   3975
   End
   Begin VB.TextBox Text1 
      Height          =   405
      Left            =   1320
      TabIndex        =   2
      Top             =   4080
      Width           =   3135
   End
   Begin ComctlLib.ListView ListView1 
      Height          =   3615
      Left            =   3360
      TabIndex        =   1
      Top             =   360
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   6376
      View            =   2
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   327682
      Icons           =   "ImageList1"
      SmallIcons      =   "ImageList1"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   0
   End
   Begin ComctlLib.TreeView TreeView1 
      Height          =   3615
      Left            =   240
      TabIndex        =   0
      Top             =   360
      Width           =   3015
      _ExtentX        =   5318
      _ExtentY        =   6376
      _Version        =   327682
      HideSelection   =   0   'False
      LineStyle       =   1
      Sorted          =   -1  'True
      Style           =   7
      ImageList       =   "ImageList1"
      Appearance      =   1
   End
   Begin VB.Label Label7 
      BackColor       =   &H00CAFDFF&
      Caption         =   "File ����ͧ�觤׹�к�"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   6840
      TabIndex        =   12
      Top             =   3240
      Width           =   2655
   End
   Begin VB.Label Label6 
      BackColor       =   &H00CAFDFF&
      Caption         =   "File"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   1
      Left            =   3480
      TabIndex        =   10
      Top             =   120
      Width           =   2655
   End
   Begin VB.Label Label5 
      BackColor       =   &H00CAFDFF&
      Caption         =   "Folder"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Index           =   0
      Left            =   360
      TabIndex        =   9
      Top             =   120
      Width           =   2655
   End
   Begin VB.Label Label3 
      BackColor       =   &H00CAFDFF&
      Caption         =   "Description"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   615
      Left            =   240
      TabIndex        =   7
      Top             =   5040
      Width           =   975
   End
   Begin VB.Label Label2 
      BackColor       =   &H00CAFDFF&
      Caption         =   "Path"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   5
      Top             =   4560
      Width           =   855
   End
   Begin VB.Label Label1 
      BackColor       =   &H00CAFDFF&
      Caption         =   "Filename"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   222
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   3
      Top             =   4080
      Width           =   975
   End
   Begin ComctlLib.ImageList ImageList1 
      Left            =   4920
      Top             =   2160
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   3
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Form_browse.frx":14ED
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Form_browse.frx":183F
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "Form_browse.frx":1B91
            Key             =   ""
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "Form3"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim xx, yy As Long
Dim image_type As String
Dim FileID As String

Private Sub Cmd_Scan_Click()
Load Form1
Form1.Show
Me.Hide
End Sub

Private Sub Cmd_send_Click()
If (Form3.Text1.Text <> "") Then
    If (Dir(App.Path & "/Tmp.dat") <> "") Then
        MDIForm1.SendData App.Path & "/tmp.dat", "C:/AppServ/www/client/upload/" & Text2.Text & Text1.Text & Form1.Option_type(), MDIForm1.Winsock1, ""
        Form3.Text1 = ""
        Form3.Text2 = ""
        Form3.Text3 = ""
    Else: MsgBox "��辺�ٻ���سscan", vbExclamation, "Error"
    End If
Else: MsgBox "�س��ͧ���������", vbExclamation, "Error"
End If

End Sub

Private Sub Cmd_update_Click()
If (Dir(App.Path & "/Tmp.dat") <> "") Then
Tmp = "U_p_d_a_t_e" & FileID & Chr$(0) & Text1.Text & Chr$(0) & "C:/AppServ/www/client/upload/" & Text2.Text & "/" & Text1.Text
MDIForm1.Winsock1.SendData Tmp
Form3.Text1 = ""
Form3.Text2 = ""
Form3.Text3 = ""
Else: MsgBox "��辺�ٻ���سscan", vbExclamation, "Error"
End If


End Sub

Private Sub Form_Load()
Dim Tmmp As String
On Error GoTo ErrLabel:
Form3.Width = MDIForm1.Width
Form3.Height = MDIForm1.Height
TreeView1.ImageList = ImageList1

MDIForm1.Winsock1.SendData ("T_a_b")
Exit Sub
ErrLabel:
        MsgBox "Cannot connect to server", vbExclamation, "Error"
        
End Sub

Private Sub Form_Unload(Cancel As Integer)
If Dir(App.Path & "/Tmp.dat") <> "" Then
Kill App.Path & "/Tmp.dat"
End If
End Sub

Private Sub ListView2_ItemClick(ByVal Item As ComctlLib.ListItem)
Dim key As String
Dim nCount As Integer
Dim sData() As String


Cmd_update.Enabled = True
Cmd_send.Enabled = False
Text1.Enabled = False

key = Item.key
nCount = MDIForm1.Splite(key, Chr$(0), sData())
Text1.Text = sData(2)
Text2.Text = Right$(sData(1), Len(sData(1)) - 29) & "/"
FileID = sData(3)
End Sub

Private Sub TreeView1_Click()
    Dim Node1 As Node
    Dim Tmp As String
On Error GoTo ErrLabel
    Set Node1 = TreeView1.HitTest(xx, yy)
    If Node1 Is Nothing Then
    Else
        Cmd_send.Enabled = True
        Cmd_update.Enabled = False
        Text1.Enabled = True
        Text1.Text = ""
        
        Text2.Text = Node1.key
        Tmp = "F_i_l_e" & Node1.key
        MDIForm1.Winsock1.SendData Tmp
        ListView1.ListItems.Clear
    If (Node1.Expanded = False) Then
        Node1.Expanded = True
    End If
    End If
    Exit Sub
ErrLabel:
MsgBox "Cannot connect to server", vbExclamation, "Error"
            Unload Form1
            Unload Form3
            Load Form2
            
        If Winsock1.State <> sckClosed Then
             Winsock1.SendData "Disconnect"
            DoEvents
            Winsock1.Close
End If

End Sub

Private Sub TreeView1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    xx = X
    yy = Y
    
End Sub

