VERSION 5.00
Begin VB.Form Form2 
   BackColor       =   &H00FFFFC0&
   Caption         =   "MySQL Setting"
   ClientHeight    =   1770
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5730
   LinkTopic       =   "Form2"
   ScaleHeight     =   1770
   ScaleWidth      =   5730
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      BackColor       =   &H00FFFFC0&
      Caption         =   "MySQL"
      Height          =   1575
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   5415
      Begin VB.CommandButton Cmd_ok 
         Caption         =   "OK"
         Height          =   375
         Left            =   4200
         TabIndex        =   5
         Top             =   960
         Width           =   735
      End
      Begin VB.TextBox Text1 
         Height          =   375
         IMEMode         =   3  'DISABLE
         Left            =   1440
         PasswordChar    =   "*"
         TabIndex        =   4
         Top             =   960
         Width           =   2415
      End
      Begin VB.TextBox Text2 
         Height          =   375
         Left            =   1440
         TabIndex        =   3
         Top             =   360
         Width           =   2415
      End
      Begin VB.Label Label2 
         BackColor       =   &H00FFFFC0&
         Caption         =   "User"
         Height          =   375
         Left            =   360
         TabIndex        =   2
         Top             =   360
         Width           =   1215
      End
      Begin VB.Label Label1 
         BackColor       =   &H00FFFFC0&
         Caption         =   "Password"
         Height          =   375
         Left            =   360
         TabIndex        =   1
         Top             =   960
         Width           =   1815
      End
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim SqlPass As String
Dim SqlUser As String

Private Sub Cmd_ok_Click()
SqlPass = Text1.Text
Load Form1
Form1.Show
Unload Form2
End Sub

Function getPass()
getPass = SqlPass
End Function

Function getUser()
getUser = SqlUser
End Function

Private Sub Text1_KeyPress(KeyAscii As Integer)
If (KeyAscii = 13) Then
    SqlPass = Text1.Text
    SqlUser = Text2.Text
    Load Form1
    Form1.Show
    Unload Form2
End If
End Sub

