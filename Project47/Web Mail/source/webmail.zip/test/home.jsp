<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" errorPage="error/errorlogin.jsp" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<a href="compose.jsp">Compose</a> 
<a href="showemail.jsp">Inbox</a>
<a href="showsession.jsp">showsession</a> 
<a href="logout.jsp">Logout</a> 
<br><br><hr>
<%		
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");
	try {
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder("INBOX");
		f.open(Folder.READ_ONLY);
		
		Message msg[] = f.getMessages();
		int newm = f.getNewMessageCount();
		int inb = msg.length;
		f.close(false);
		st.close();
		
%>
You have <%=inb%> messages in your <a href="showemail.jsp">Inbox</a>
<br> <%=newm%> new message ( this note is shown when you use IMAP store )

<%
			
			
	
} catch (Exception e){
		throw new Exception();
		}

%>
</html>
