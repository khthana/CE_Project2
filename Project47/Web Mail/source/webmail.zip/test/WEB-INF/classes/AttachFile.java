// AttachFile.java
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
public class AttachFile {
	public static void main (String args[]) throws Exception {
		Properties pro = System.getProperties();
		pro.put("mail.smtp.host", "localhost");
		Session ses = Session.getInstance(pro, null);
		Message mes = new MimeMessage(ses);
		mes.setFrom(new InternetAddress("jon1@jonnetwork.org"));
		mes.addRecipient(Message.RecipientType.TO, 
			new InternetAddress("jon2@jonnetwork.org"));
		mes.setSubject("Attach File Test");
		Multipart mp = new MimeMultipart();
		BodyPart bp = new MimeBodyPart();
		bp.setText("Hello! this is a text.");
		mp.addBodyPart(bp);

		bp = new MimeBodyPart();
		DataSource ds = new FileDataSource("test.txt");
		bp.setDataHandler(new DataHandler(ds));
		bp.setFileName("test.txt");
		mp.addBodyPart(bp);

		bp = new MimeBodyPart();
		ds = new FileDataSource("Bird.gif");
		bp.setDataHandler(new DataHandler(ds));
		bp.setFileName("Bird.gif");
		mp.addBodyPart(bp);
		mes.setContent(mp);
		Transport.send(mes);
	}
}
