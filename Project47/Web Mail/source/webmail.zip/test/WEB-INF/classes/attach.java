import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;



	public void doPost(HttpServletRequest request,HttpServletResponse response)
throws ServletException, java.io.IOException {
String from = request.getParameter("from");
String to = request.getParameter("to");
String cc = request.getParameter("cc");
String bcc = request.getParameter("bcc");

String subject = request.getParameter("subject");
String filename = request.getParameter("attach");
String text = request.getParameter("text");

PrintWriter writer = response.getWriter();

if (subject == null)
subject = "Null";
if (text == null)
text = "No message";


String status;

try {
// Create the JavaMail session
java.util.Properties properties = System.getProperties
();

properties.put("mail.smtp.host", "localhost");
Session session = Session.getInstance(properties, null);

// Construct the message
MimeMessage message = new MimeMessage(session);

// Set the from address
Address fromAddress = new InternetAddress(from);
message.setFrom(fromAddress);

// Parse and set the recipient addresses
Address[] toAddresses = InternetAddress.parse(to);
message.setRecipients(Message.RecipientType.TO,toAddresses);


Address[] ccAddresses = InternetAddress.parse(cc);
message.setRecipients(Message.RecipientType.CC,ccAddresses);

Address[] bccAddresses = InternetAddress.parse(bcc);
message.setRecipients(Message.RecipientType.BCC,bccAddresses);

// Set the subject and text
message.setSubject(subject);


// Attach file with message
writer.println("<h2> file passed = "+filename);
File file = new File(filename);
if (file.exists())
{
// create and fill the first message part
MimeBodyPart mbp1 = new MimeBodyPart();
mbp1.setText(text);

// create the second message part
MimeBodyPart mbp2 = new MimeBodyPart();

// attach the file to the message
FileDataSource fds = new FileDataSource(filename);
mbp2.setDataHandler(new DataHandler(fds));
mbp2.setFileName(fds.getName());

// create the Multipart and its parts to it
Multipart mp = new MimeMultipart();
mp.addBodyPart(mbp1);
mp.addBodyPart(mbp2);

// add the Multipart to the message
message.setContent(mp);
}
else
{
message.setText(text);
}


// send the message
Transport.send(message);

} catch (Exception e) {

} 

// Output a status message
response.setContentType("text/html");

writer.println("<html><head><title>Status</title></h ead>");
writer.println("<body><p><h2>" + status
+ "</h2></p></body></html>");

writer.close();
}
