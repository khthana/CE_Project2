<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" %>
<html>
<%!
	public String getAddress(Address address)
	{  	String name = "";
		if (address != null) {
			name = ""+address;
			if (address instanceof InternetAddress){
			String personal = ((InternetAddress) address).getPersonal();
			if (personal != null){
			name = personal;
			}
			}
		}
		return name;
	}
	
	public String formatAddress(Address addresses[])
	{ 	String s = "";
		if (addresses != null){
			for (int i=0;i<addresses.length;i++){
				if(i>0){
				s +=", ";
				}
				s += getAddress(addresses[i]);
			}
		}
		return s;
	}

%>
<%
		
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");
		String fold = request.getParameter("fold");

		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder(fold);
		f.open(Folder.READ_ONLY);
		Message msg[] = f.getMessages();
		int i= Integer.parseInt(request.getParameter("index"));
		Message msgs = msg[i];
		
		Address from[] = msgs.getFrom();
		Address to[] = msgs.getRecipients(Message.RecipientType.TO);
		Address cc[] = msgs.getRecipients(Message.RecipientType.CC);
		Address bcc[] = msgs.getRecipients(Message.RecipientType.BCC);
		Object data =msgs.getSubject();
%>
<head><title>Forward E-mail</title></head>
 <body>
<form action="send.jsp" method="post">

   <table align="center">
     <tr><td>To</td><td><input name="to" size="50" /></td></tr>
	<tr><td>CC</td><td><input name="cc" size="50" /></td></tr> 
	<tr><td>BCC</td><td><input name="bcc" size="50" /></td></tr>
	<tr>
       <td>Subject</td>
       <td><input name="subject" size="50" value="[ Forward :<%=msgs.getSubject()%> ]"/></td>
     </tr>
	<tr>
	<td>Attachment</td>
	<td>
  <input type="file" name="attach">
</td>
	</tr>
     <tr><td colspan="2"><textarea name="text" cols="50" rows="20"><%=msgs.getSentDate() %>
From :<%=formatAddress(from)%> 
To   :<%=formatAddress(to)%> 
CC   :<%=formatAddress(cc)%>
BCC  :<%=formatAddress(bcc)%>
Subject:<%=msgs.getSubject() %>
----------------------
<%=data%>
----------------------
</textarea></td></tr>
     <tr><td colspan="2" align="center"><input type="submit" value="Send Email"/></td></tr>
   </table>
  </form>
 </body>
<% 	f.close(false);
		st.close();
%>
</html>
