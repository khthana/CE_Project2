<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" errorPage="error/derror.jsp" %>
<html>
<%		
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");
		
		
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder("TRASH");
		f.open(Folder.READ_WRITE);

		Message msg[] = f.getMessages();
		out.println("Message ");
		String x = request.getParameter("index");
		int index= Integer.parseInt(request.getParameter("index"));
		if (x != null){ 
			msg[index].setFlag(Flags.Flag.DELETED, true);
			out.println(index);

		}

		out.println(" deleted permanently .");
		f.close(true);
		st.close();
		

		

%>
Delete complete
return to <a href="showemail.jsp">Inbox</a>
</html>
