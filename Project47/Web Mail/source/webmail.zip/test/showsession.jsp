<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" %>
<html>

host = <%=session.getValue("host") %><br>
username = <%=session.getValue("username") %><br>
password = <%=session.getValue("password") %><br>
store = <%=session.getValue("store") %><br>


</html>
