<html>
<body>
<br>
<br>
Successful Log out <br>
You just sign out of <%=session.getValue("username")%>@jonnetwork.org<br>
<% 
	session.removeValue("host");
	session.removeValue("username");
	session.removeValue("password");
	session.removeValue("store");
%>
<br>
pls <a href="login.jsp>login </a> again.
</body>
</html>
