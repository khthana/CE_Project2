<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<title>Web Mail</title>
<meta http-equiv="Content-Type" content="text/html; charset=windows-874">
</head>
<%
		String host     = "jonnetwork.org";
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String store = request.getParameter("store");
		
		// session time
		session.setMaxInactiveInterval(5000);
		//set session
		session.putValue("host",host);
		session.putValue("username",username);
		session.putValue("password",password);
		session.putValue("store",store);
%>
<frameset cols="80,*" frameborder="NO" border="0" framespacing="0">
  <frame src="menu.jsp" name="leftFrame" scrolling="NO" noresize>
  <frame src="home.jsp" name="mainFrame">
</frameset>
<noframes><body>
</body></noframes>
</html>
