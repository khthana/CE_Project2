<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" errorPage="error/derror.jsp" %>
<html>
<%		
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");
		String fold = request.getParameter("fold");
		
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder(fold);
		f.open(Folder.READ_WRITE);

		Message msg[] = f.getMessages();
		out.println("Message ");
		String x = request.getParameter("index");
		int index= Integer.parseInt(x);
		if (x != null){ 
			Folder folder = st.getFolder("TRASH");
			
			if (folder == null) {
 			   System.err.println("Can't get record folder.");
  			  System.exit(1);
				}
		
			if (!folder.exists())
		    	folder.create(Folder.HOLDS_MESSAGES);


			Message[] msgs = new Message[1];
			msgs[0] = msg[index];
			folder.appendMessages(msgs);

			msg[index].setFlag(Flags.Flag.DELETED, true);
			out.println(index);

		}

		out.println(" go to TRASH .");
		f.close(true);
		st.close();
		

		

%>
Delete complete
return to <a href="showemail.jsp">Inbox</a>
</html>
