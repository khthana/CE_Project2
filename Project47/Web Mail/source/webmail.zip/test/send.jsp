<%@ page import="java.util.*, javax.mail.*, javax.mail.internet.*,javax.activation.*,java.io.*" %>
<%
  Properties props = new Properties();
  props.put("mail.smtp.host", (String)session.getValue("host"));
  Session s = Session.getInstance(props,null);

  MimeMessage message = new MimeMessage(s);

  	InternetAddress from = new InternetAddress((String)session.getValue("username")+"@jonnetwork.org");
  		message.setFrom(from);
	String toAddresses = request.getParameter("to"); 
		message.addRecipients(Message.RecipientType.TO, toAddresses); 
	String ccAddresses = request.getParameter("cc"); 
		message.setRecipients(Message.RecipientType.CC, ccAddresses); 
	String bccAddresses = request.getParameter("bcc");
 		message.setRecipients(Message.RecipientType.BCC, bccAddresses);


  	String subject = request.getParameter("subject");
	String subject2 = new String(subject.getBytes("ISO8859_1"),"TIS-620");
  		message.setSubject(subject2);
 
	String text = request.getParameter("text");
	String text2 = new String(text.getBytes("ISO8859_1"),"TIS-620");
		message.setText(text2);

		
		String store	= (String)session.getValue("store");

	
		Message msg = (Message)message;
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);

			Folder sent = st.getFolder("SENT");
			
			if (sent == null) {
 			   System.err.println("Can't get record folder.");
  			  System.exit(1);
				}
		
			if (!sent.exists())
		    	sent.create(Folder.HOLDS_MESSAGES);


			Message[] msgs = new Message[1];
			msgs[0] = msg;
			sent.appendMessages(msgs);
		st.close();

		Transport.send(message);
%>
<html>
<p align="center">The Message has been sent.<br>Check your inbox.</p>
<p align="center"><a href="compose.jsp">Click here to send another!</a></p>

</html>
