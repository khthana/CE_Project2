<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" %>
<html>
<%!
	public String getAddress(Address address)
	{  	String name = "";
		if (address != null) {
			name = ""+address;
			if (address instanceof InternetAddress){
			String personal = ((InternetAddress) address).getPersonal();
			if (personal != null){
			name = personal;
			}
			}
		}
		return name;
	}
	
	public String formatAddress(Address addresses[])
	{ 	String s = "";
		if (addresses != null){
			for (int i=0;i<addresses.length;i++){
				if(i>0){
				s +=", ";
				}
				s += getAddress(addresses[i]);
			}
		}
		return s;
	}

%>

<a href="compose.jsp">Compose   </a>
<a href="showemail.jsp">Inbox</a>
<a href="showsession.jsp">showsession  </a>
<a href="logout.jsp">Logout   </a>
<a href="forward.jsp">Forward </a>

<br>
<hr>
<%		
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");
		
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder("TRASH");
		f.open(Folder.READ_ONLY);
		
		int i= Integer.parseInt(request.getParameter("index"));
		Message msg[] = f.getMessages();
		
		Message msgs = msg[i];
		
		Address from[] = msgs.getFrom();
		String reply = formatAddress(from);

		Address to[] = msgs.getRecipients(Message.RecipientType.TO);
		Address cc[] = msgs.getRecipients(Message.RecipientType.CC);
		Address bcc[] = msgs.getRecipients(Message.RecipientType.BCC);

%>		
		Date:  <%=msgs.getSentDate() %><br>
		From:  <%=formatAddress(from)%><br>
		TO:  <%=formatAddress(to)%><br>
		CC:  <%=formatAddress(cc)%><br>
		BCC:  <%=formatAddress(bcc)%><br>
		Subject: <%=msgs.getSubject() %> <br>
		
<hr>
<%		
		Object o = msgs.getContent();
		String a = o.toString();
		
		out.print(a);
	
		
		f.close(false);
		st.close();
		
%>
		<hr>	
		<%out.println("<a href=reply.jsp?reply="+reply+"&index="+i+">Reply  </a><br>"); %>
		<%out.println("<a href=forward.jsp?index="+i+">Forward  </a><br>"); %>
		<%out.println("<a href=delete5.jsp?index="+i+">Delete this message </a>"); %>

</html>
