<%@ page contentType="text/html; charset=iso-8859-1" language="java"  errorPage="" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head><title>Compose E-mail</title></head>
 <body>
<form action="send.jsp" method="post">

   <table align="center">
     <tr><td>To</td><td><input name="to" size="50" /></td></tr>
	<tr><td>CC</td><td><input name="cc" size="50" /></td></tr> 
	<tr><td>BCC</td><td><input name="bcc" size="50" /></td></tr>
	<tr>
       <td>Subject</td>
       <td><input name="subject" size="50" /></td>
     </tr>
	<tr>
	<td>Attachment</td>
	<td>
  <input type="file" name="attach">
</td>
	</tr>
     <tr><td colspan="2"><textarea name="text" cols="50" rows="20"></textarea></td></tr>
     <tr><td colspan="2" align="center"><input type="submit" value="Send Email"/></td></tr>
   </table>
  </form>
 </body>
</html>
