<%@ page contentType="text/html; charset=iso-8859-1" language="java" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Login Jonnetwork.org</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<div align="center">
  <p align="center">Welcome to jonnetwork.org Pls login</p>
  <form name="form1" method="post" action="index.jsp">
    <div align="center">
      <table width="325" border="1">
          <td>store protocol </td>
          <td><select name="store">
            <option value="pop3"selected>POP3</option>
            <option value="imap">IMAP</option>
          </select></td>
        </tr>
        <tr>
          <td>username</td>
          <td><input type="text" name="username" size="15">@jonnetwork.org</td>
        </tr>
        <tr>
          <td>password</td>
          <td><input type="password" name="password"></td>
        </tr>
        <tr>
          <td><input type="submit" name="Submit" value="Login"></td>
          <td><input type="reset" name="Reset" value="Reset"></td>
        </tr>
          </table>
    </div>
  </form>
  <p>&nbsp; </p>
</div>
</body>
</html>
