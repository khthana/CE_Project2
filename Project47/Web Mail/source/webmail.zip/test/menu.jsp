<html>

<head>

<title>Web Mail</title>

<meta http-equiv="Content-Type" content="text/html; charset=tis-620">

<style type="text/css">

<!--

body {  margin: 0px  0px; padding: 0px  0px}

a:link { color: #005CA2; text-decoration: none}

a:visited { color: #005CA2; text-decoration: none}

a:active { color: #0099FF; text-decoration: underline}

a:hover { color: #0099FF; text-decoration: underline}

-->

</style>

</head>



<body bgcolor="#CCCCCC" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">

<br><br>

<p align="center"><a href="home.jsp" target="mainFrame">Main Page</a></p>

<p align="center"><a href="showemail.jsp" target="mainFrame"><img src="pic/newmail1.gif" width="20" border="0">Inbox</a></p>

<p align="center"><a href="compose.jsp" target="mainFrame">Compose</a></p>
<p align="center"><a href="showtrash.jsp" target="mainFrame">Trash</a></p>
<p align="center"><a href="showsent.jsp" target="mainFrame">Sent</a></p>
<p align="center"><a href="showfolder.jsp" target="mainFrame">Folder</a></p>

<p align="center"><a href="showsession.jsp" target="mainFrame">showsession</a></p>
<p align="center"><a href="logout.jsp"target="_parent">Logout</a> </p>


</body>

</html>

