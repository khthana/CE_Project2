<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" %>

<html>

<% 		
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");

	
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder("INBOX");
		f.open(Folder.READ_WRITE);
		Message msg[] = f.getMessages();

		String [] num = request.getParameterValues("checkbox");
		if (num != null)
		{	for (int i=0;i<num.length;i++)
			{ int j= Integer.parseInt(num[i]);
			
			Folder folder = st.getFolder("FOLDER");
			
			if (folder == null) {
 			   System.err.println("Can't get record folder.");
  			  System.exit(1);
				}
		
			if (!folder.exists())
		    	folder.create(Folder.HOLDS_MESSAGES);


			Message[] msgs = new Message[1];
			msgs[0] = msg[j];
			folder.appendMessages(msgs);

			msg[j].setFlag(Flags.Flag.DELETED, true);
			}
		};

		out.println("move to your FOLDER complete. ");
	f.close(true);
	st.close();
%>
</html>
