<%@ page import="java.util.*, javax.mail.*,javax.mail.internet.*,javax.activation.*" errorPage="error/notlogin.jsp" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<a href="compose.jsp">Compose</a> 
<a href="showsession.jsp">showsession</a> 
<br><br><hr><br>
<table border=1>
<tr><td></td><td>From</td><td>Subject</td><td>Size</td><td>Date</td>
  <SCRIPT language="JavaScript"> 
function OnSubmitForm()
{
  if(document.pressed == 'Delete')
  {
   document.myform.action ="delete.jsp";
  }
  else
  if(document.pressed == 'Move')
  {
    document.myform.action ="sent2.jsp";
  }
  
  return true;
}
</SCRIPT>

<form name="myform"  onSubmit="return OnSubmitForm();">
<%
			
		String host     = (String)session.getValue("host");
		String username = (String)session.getValue("username");
		String password = (String)session.getValue("password");
		String store	= (String)session.getValue("store");

	try{	String fold ="FOLDER";
		Properties pro = new Properties();
		pro.put("mail.store.host", host);
		Session ses = Session.getDefaultInstance(pro, null);
		Store st = ses.getStore(store);
		st.connect(host, username, password);
		Folder f = st.getFolder(fold);
		f.open(Folder.READ_WRITE);
			
		Message msg[] = f.getMessages();
	
	int j = msg.length -1 ;
	for (int i=j; i>-1; i--)
		{
%>		
	<tr>
	<td><input type="checkbox" name="checkbox" value="<%=i%>"></td>
	<td><%=msg[i].getFrom()[0]%></td>
	<td><a href=showmail.jsp?index=<%=i%>&fold=<%=fold%>> : <%=msg[i].getSubject()%></a></td>
	<td><%=msg[i].getSize()%></td>
	<td><%=msg[i].getSentDate()%></td></TD>
<%
		}
	f.close(false);
	st.close();
%>
</table>
<input type="submit"   onClick="document.pressed=this.value" value="Delete">
<input type="submit"  onClick="document.pressed=this.value" value="Move">
</form>
<br><b>Total number of Message <%=msg.length%> <br>
<hr>
<%
	} catch (Exception e){
		throw new Exception();
		}
%>

</html>
