<?
	session_start();

	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="read_mail" title="Inbox">
		<p>
		<?
			function readmailz($PHP_AUTH_USER,$PHP_AUTH_PW){
				$MAILSERVER="{mail.kmitlmail.com:143}";
				//$PHP_AUTH_USER = "webmaster";
				//$PHP_AUTH_PW   = "1q2w3e4r";
				$mbox=imap_open($MAILSERVER,$PHP_AUTH_USER."@kmitlmail.com",$PHP_AUTH_PW);
				echo "Number of Total Emails: ".imap_num_msg($mbox)."<br/>";
				echo "Number of Recent Emails: ".imap_num_recent($mbox)."<br/><br/><br/>";
				$headers=imap_headers($mbox);
				for($x=0; $x < count($headers); $x++) {
					$idx=($x+1);
					echo $idx."  <a href=\"read_mail.php?num=$idx\">$headers[$x]</a><br/>";
				}
				
				imap_close($mbox);
			}
			echo"<a href=\"logout.php\">Sign out</a><br/>";
			echo"<a href=\"compose.php\">New message</a><br/><br/>";
			readmailz($temp_user,$temp_pass);
			
			
		?>
		</p>
	</card>
</wml>
