<?
	session_unregister("temp_user");
	session_unregister("temp_pass");

	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="welcome" title="Welcome">
		<p align="center">
			Logout Complet<br/>
			<a href="welcome_login.php#Login">Signin</a>
		</p>
	</card>
</wml>