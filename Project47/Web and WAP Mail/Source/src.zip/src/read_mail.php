<?
	session_start();

	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="read_mail" title="Message">
		<p>
		<?php
			//echo$num;
			function viewmailz($num,$PHP_AUTH_USER,$PHP_AUTH_PW){
				$MAILSERVER="{mail.kmitlmail.com:143}";
				//$PHP_AUTH_USER = "webmaster";
				//$PHP_AUTH_PW   = "1q2w3e4r";
				$mbox=imap_open($MAILSERVER,$PHP_AUTH_USER."@kmitlmail.com",$PHP_AUTH_PW);
				$header=imap_headerinfo($mbox,$num,80,80);
				$from =	$header->from;
				$udate=$header->udate;
				$date=Date("F j, Y, g:i a", $udate);
				echo "<b>Message Number: </b>". $num."<br/>";
				$subject= $header->fetchsubject;
				if (is_array($from)){
					while(list($key, $val) = each($from)) {
						echo "<b>From Address:</b>  ";
						echo $fromaddr=sprintf("%s@%s",$from[0]->mailbox,$from[0]->host)."<br/>";
						//echo "Personal    :  ".$from[0]->personal."<br>";
						//echo "Adl         :  ".$from[0]->adl."<br>";
						//echo "Mailbox     :  ".$from[0]->mailbox."<br>";
						//echo "Host        :  ".$from[0]->host."<br>";
						echo "<b>Subject     :  </b>".$subject."<br/>";
						echo "<b>Date        :  </b>".$date."<br/>";
					}
				}
				echo"<br/><b>Message :</b><br/>";
				echo imap_fetchbody($mbox,$num,1)."<br/><b>END OF Message</b><br/><br/>"; 
				
				imap_close($mbox);
			}
			viewmailz($num,$temp_user,$temp_pass);
		?>
		<img src="pic_wap/inbox.gif" alt="inbox"/><a href="check_mail.php">Inbox message</a><br/>
		<img src="pic_wap/new_mail.gif" alt="new_mail"/><a href="compose.php">New message</a><br/>
		<a href="logout.php">Sign out</a><br/>
		</p>
	</card>
</wml>
