<?php
	session_register("ss_UserID");
	if(isset($btreply)) {
		header("Location: compose.php?paction=reply&pnum=$hnum");
	}
	if(isset($btforward)) {
		header("Location: compose.php?paction=forward&pnum=$hnum");
	}
	if(isset($btdelete)) {
		$ss_mailserver = "{mail.kmitlmail.com:143/imap}INBOX";
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
		$result = mysql_query("select password from user where username = '$ss_UserID';");
		$dbarr = mysql_fetch_array($result);
		$ss_Pwd = $dbarr[0];
		$mbox = imap_open($ss_mailserver, $ss_UserID."@kmitlmail.com", $ss_Pwd);
		imap_delete($mbox, $hnum);
		header("Location: inbox.php");
		imap_close($mbox);
	}
?>