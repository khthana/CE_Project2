<?php
	session_register("ss_UserID");	
?>

<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD">

<br><br>	
	<center><table bgcolor="orange" width="30%">
	<tr><td>
<?php
	
	function check($var,$name) {
		global $list;
		global $flag;
		if(empty($var))
			$flag = 1;
		if(strcmp($name,"Repeat password") != 0 )
			$list[$name] = $var;
	}
	
	$step = 1;
	check("$firstname","����");
	check("$lastname","���ʡ��");
	check("$address","�������");
	check("$phone","�������Ѿ��");
	if($flag) { ?>
		<center><font face = "DilleniaUPC" size = "5"><u><br>��سһ�͹</u><br></font></center>
	<?php	while(list($key,$value) = each($list)) {
				if(empty($value)) { ?>
					<font face = "DilleniaUPC" size = "5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo "- $key<br>"; ?></font>
	<?php		}
			} ?>
			<center><font face = "DilleniaUPC" size = "5"><u>���ú��ǹ</u><br><br></font></center>
			<form>
			<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
			</form>
			
<?php } else {
		echo "<br>";
		
			
				
					if(ereg("^[0-9]+$",$phone) and (strlen($phone) == 9)) {
						$step = 2;
					} else { ?>
						<center><font face = "DilleniaUPC" size = "5"><?php echo "�����Ţ���Ѿ�����١��ͧ"; ?></font>
						<br><br><form>
						<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
						</form>
					<?php }
				
			
		} ?>

<?php		if($step == 2){
			$ss_DBName = "kmitlmail";		
			$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
					or die("Could not connect database."."Invalid username or password.");
			mysql_select_db($ss_DBName, $link);
			
				$up = "update user set firstname='$firstname',lastname='$lastname',address='$address',phone='$phone' where username = '$ss_UserID'";
				mysql_query($up); 
			
				?>
				<script language = 'javascript'>
				window.navigate("inbox.php");
				</script>
			
		<?php
	}	
?>
</table></center>

</body>
</html>		
		