<?php
	session_register("ss_UserID");
?>
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="orange" link='#000000' vlink="#000000" alink="red">
<form action="logout.php" target="_top">
<table>
	<tr>
		<td><img src = 'picture/head_r1.jpg' border='0'></td>
	</tr>
	<tr>
		<td> 
				<a href="compose.php" target='_fContent'><font face = "DilleniaUPC" size = "5"> ��¹������ </font></a> | 
				<a href="organiser.php" target='_fContent'><font face = "DilleniaUPC" size = "5"> �ѹ�֡ </font></a> |
				<a href="contact.php" target='_fContent'><font face = "DilleniaUPC" size = "5"> ��ش��ª��� </font></a> | 
				<a href="edit.php" target='_fContent'><font face = "DilleniaUPC" size = "5"> ��䢢�������ǹ��� </font></a> |
				<a href="logout.php" target='_fContent'><font face = "DilleniaUPC" size = "5"> �͡�ҡ�к� </font></a> |
				&nbsp;&nbsp;&nbsp;&nbsp;
		<b><?php echo $ss_UserID; ?>@kmitlmail.com</b></td>
	</tr>	
</table>
</form>
</body>
</html>