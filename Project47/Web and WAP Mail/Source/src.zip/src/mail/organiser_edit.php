<?php
	session_register("ss_UserID");
	if ($send != null) {
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
		$date = "$year-$month-$day";
		$time = "$hour:$min:$sec"; ?>
		
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD"><br><br>

	
	<center><table bgcolor="orange" width="30%">
	<tr><td>
<?php
	
	function check($var,$name) {
		global $list;
		global $flag;
		if(empty($var))
			$flag = 1;
		if(strcmp($name,"Repeat password") != 0 )
			$list[$name] = $var;
	}
	
	$step = 1;
	check("$hour","�������");
	check("$min","�ҷ�");
	check("$sec","�Թҷ�");
	check("$types","��Ǣ������ͧ");
	
	if($flag) { ?>
		<center><font face = "DilleniaUPC" size = "5"><u><br>��سһ�͹</u><br></font></center>
	<?php	while(list($key,$value) = each($list)) {
				if(empty($value)) { ?>
					<font face = "DilleniaUPC" size = "5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo "- $key<br>"; ?></font>
	<?php		}
			} ?>
			<center><font face = "DilleniaUPC" size = "5"><u>���ú��ǹ</u><br><br></font></center>
			<form>
			<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
			</form>
			
<?php } else {
		echo "<br>";
		
			if((ereg("[0-1]+[0-9]",$hour)  or ereg("[2]+[0-3]",$hour)) and (strlen($hour) == 2)  ) {
				if(ereg("[0-5]+[0-9]",$min) and (strlen($min) == 2)) {
					if(ereg("[0-5]+[0-9]",$sec) and (strlen($sec) == 2)) {
						$step = 2;
					} else { ?>
						<center><font face = "DilleniaUPC" size = "5"><?php echo "�Թҷ����١��ͧ"; ?></font>
						<br><br><form>
						<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
						</form>
					<?php }
				} else {?>
					<center><font face = "DilleniaUPC" size = "5"><?php echo "�ҷ����١��ͧ"; ?></font>
					<br><br><form>
						<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
						</form>
				<?php }
			} else {?>
				<center><font face = "DilleniaUPC" size = "5"><?php echo "����������١��ͧ"; ?></font>
					<br><br><form>
						<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
						</form>
			<?php }
		}
		if($step == 2){
		
				$q = "update organiser set type = '$types' ,date = '$date' ,time='$time'
				where username = '$ss_UserID' and type = '$aaa' and date = '$bbb' and time='$ccc';"; 
				$result2 = mysql_query($q) ?>
				<script language = 'javascript'>

	window.navigate("organiser.php");
</script>
	<?php	}
?>

<?php } ?>
        
						
</table></center>

</body>
</html>						
						
						
						
						
						
						
						
						
						
						
						
						
						
						