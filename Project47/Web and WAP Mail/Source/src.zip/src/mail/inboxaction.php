<?php
	session_register("ss_UserID");
	$ss_mailserver = "{mail.kmitlmail.com:143/imap}INBOX";
	$ss_DBName = "kmitlmail";
	$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	or die("Could not connect database."."Invalid username or password.");
	mysql_select_db($ss_DBName, $link);
	$result = mysql_query("select password from user where username = '$ss_UserID';");
	$dbarr = mysql_fetch_array($result);
	$ss_Pwd = $dbarr[0];
	
if (isset($cCheck)) {
	$mbox = imap_open($ss_mailserver, $ss_UserID."@kmitlmail.com", $ss_Pwd);
	foreach ($cCheck as $eachid) {
		if (isset($btdelete)) {
			imap_delete($mbox , $eachid);
		}
	}
	imap_close($mbox);
?>
<script language = 'javascript'>
	parent._fMenu.location.reload();
	window.navigate("inbox.php");
</script>
<?php
}

if((isset($btdelete)) and (!isset($cCheck))) { ?>
	<script language = 'javascript'>
	window.navigate("inbox.php");
</script>
<?php }
?>
