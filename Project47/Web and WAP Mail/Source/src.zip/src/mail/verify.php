<?php
	//session_register(cUserID);
//if (!session_is_registered("ss_DBName")) session_register("ss_DBName");
//if (!session_is_registered("ss_mailserver")) session_register("ss_mailserver");
//if (!session_is_registered("ss_UserID")) session_register("ss_UserID");
//if (!session_is_registered("ss_Pwd")) session_register("ss_Pwd");
//if (!session_is_registered("ss_CurrentBox")) session_register("ss_CurrentBox");
//if (!session_is_registered("ss_Email")) session_register("ss_Email");

$ss_CurrentBox = "Inbox";
$ss_mailserver = "{localhost:143/imap}INBOX";
$ss_DBName = "kmitlmail";
//$ss_UserID = isset($cUserID) ? $cUserID : "";
//session_start();
//session_unregister(cUserID);
$ss_Pwd = isset($cPwd) ? $cPwd : "";
$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	or die("Could not connect database."."Invalid username or password.");
mysql_select_db($ss_DBName, $link);

if ($btsubmit1 != null) {
	if (($ss_UserID == "") || ( $ss_Pwd=="")) { ?>
	<html>
	<head><title>Kmitl Webmail</title></head>
	<body bgcolor="#FFF1DD">
	<center><img src = 'picture/head_r1.jpg' border='0'></center><br><br><br>
	<br><br>
	<center><table bgcolor="orange" width="45%">
	<tr><td><center><font face = "DilleniaUPC" size = "5">��سһ�͹���ͼ����������ʼ�ҹ���ú��ǹ</font></center>
	<tr><td><br><br><center><input type ='button' name='btreturn' value ='��͹��Ѻ' onClick = 'window.navigate("login.php")'></center>
	<tr><td></td></tr>
	<tr><td></td></tr>
	<tr><td></td></tr>
	</table></center>
	</body>
	</html>
<?php	exit();
 	} else {
	$usersresult = mysql_query("SELECT username , password FROM user WHERE username='$ss_UserID' and password = '$ss_Pwd'");
	if (mysql_num_rows($usersresult) == 1 ) {
		session_register("ss_UserID"); 
	?>
<title>Kmitl Webmail</title>
<frameset rows='150,*' cols="*" bordercolor ="orange">
  <frame name = '_fHeader' src='header.php' scrolling='no' noresize>
  <frameset bordercolor ="orange" cols='15%,*'>
    <frame name = '_fMenu' src='menu.php' scrolling='no' noresize>
    <frame name = '_fContent' src='inbox.php' >
  </frameset>
</frameset><noframes></noframes>

<?php 
} else {
?>
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD">
<center><img src = 'picture/head_r1.jpg' border='0'></center><br><br><br>
<br><br>
<center><table bgcolor="orange" width="45%">
<tr><td><center><font face = "DilleniaUPC" size = "5">���ͼ�����������ʼ�ҹ���١��ͧ</font></center>
<tr><td><br><br><center><input type ='button' name='btreturn' value ='�ͧ����' onClick = 'window.navigate("login.php")'></center>
<tr><td></td></tr>
<tr><td></td></tr>
<tr><td></td></tr>
</table></center>
</body>
</html>
<?php
} }
} else if ($btsubmit2 != null) { ?>
	<title>Kmitl Webmail</title>
	<frameset bordercolor ="orange">
  		<frame name = 'regis' src='register.php' >
	</frameset>
<?php }
?>