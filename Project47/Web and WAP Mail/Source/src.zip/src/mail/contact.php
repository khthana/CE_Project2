<?php
	session_register("ss_UserID");	
?>
<title>Kmitl Webmail</title>
<frameset cols='25%,*' cols="*" border="0">
  <frame name = '_fn' src='contacts.php'  noresize>
  <frame name = '_fs' src='contact_show.php'  noresize>
  </frameset><noframes></noframes>
</frameset>