<?php
	session_register("ss_UserID");
?>
<?php
	$fontcol = (($header -> Unseen == "U") ? "#FFFFCC" : "#FFFFFF");	
	$ss_mailserver = "{mail.kmitlmail.com:143/imap}INBOX";
	$ss_DBName = "kmitlmail";
	$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	or die("Could not connect database."."Invalid username or password.");
	mysql_select_db($ss_DBName, $link);
	$result = mysql_query("select password from user where username = '$ss_UserID';");
	$dbarr = mysql_fetch_array($result);
	$ss_Pwd = $dbarr[0];
	$mbox = imap_open($ss_mailserver, $ss_UserID."@kmitlmail.com", $ss_Pwd);
?>
<br>
<table border="1" bordercolor="#FF9933" width="100%">
	<tr bgcolor="orange">
		<td><center><b>&nbsp;</b></center></td>
		<td><center><b>�����</b></center></td>
		<td><center><b>�������ͧ</b></center></td>
		<td><center><b>�ѹ���</b></center></td>
		<td><center><b>��Ҵ</b></center></td>
	</tr>
	
<?php

$headers = imap_headers($mbox);
for ($i =count($headers);$i >= 1; $i--) {
	$fromname = "";
	$fromaddress = "";
	$header = imap_header($mbox,$i);
	
	$content = imap_fetch_overview($mbox,$i);
	list($key,$val) = each($content);
	//echo $val->seen."<br>";
	//echo $val->from."<br>";
	//echo $val->subject."<br>";
	 
	
	
	$mdelmail = (($ss_CurrentBox == "Deleted box") ? "D" : " ");

	if ($header -> Deleted == $mdelmail) {
		
		
		
		$from = $header -> from;
		$subject = $header -> subject;
		//list($spam,$sub) = split("\[Spam\] ",$subject);
		//$subject = $sub;
		$rcdate	= $header -> date;
		list($rc,$r) = split("\+",$rcdate);
		if (isset($from[0] -> personal)) $fromname = $from[0] -> personal;
		$fromaddress = $from[0] -> mailbox . "@" . $from[0] -> host;
		$fontcolor = (($header -> Unseen == "U") ? "#000000" : "#000000");
		$fontcol = (($val->seen == 0) ? "#FFFFCC" : "#FFFFFF");
		print "<tr bgcolor = '$fontcol'>";
		print "<td><input type='checkbox' name='cCheck[$i]' value='$i'>";
		print "<td><a href='readmail.php?pnum=$i' target='_fContent' ><font size = '2' color=$fontcolor'>" .
			  (($fromname != "") ? $fromname : $fromaddress) ."</font></a>";
		print "<td><font size = '2' color='$fontcolor' face=\"DilleniaUPC\">$subject</font>";
		
		print "<td><font size='2' color='$fontcolor'>$rc</font>";
		$size = ceil($val->size/1024)." KB";
		print "<td><font size='2' color='$fontcolor'>$size</td></font>";
		
		
	}
}
print "</table>";
print "</table>";
imap_close($mbox);
?>
