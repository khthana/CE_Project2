<?php
	session_register("ss_UserID");
	$ss_mailserver = "{mail.kmitlmail.com:143/imap}INBOX";
	$ss_DBName = "kmitlmail";
	$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	or die("Could not connect database."."Invalid username or password.");
	mysql_select_db($ss_DBName, $link);
	$result = mysql_query("select password from user where username = '$ss_UserID';");
	$dbarr = mysql_fetch_array($result);
	$ss_Pwd = $dbarr[0];
	$mbox = imap_open($ss_mailserver, $ss_UserID."@kmitlmail.com", $ss_Pwd);
	$header = imap_header($mbox, $pnum);
	$from = $header->from;
	$to = isset($header->to) ? $header->to : array();
	$cc = isset($header->cc) ? $header->cc : array();
	$subject = isset($header->subject) ? $header->subject : "";

	/*----------
	$m= imap_headerinfo($mbox, $pnum);
	echo $m."nnnnnnnnnnnn<br>";
	echo $m[1]."nnnnnnnnnnnn<br>";
	echo $m[2]."nnnnnnnnnnnn<br>";
	echo $m[3]."nnnnnnnnnnnn<br>";
	echo $m[4]."nnnnnnnnnnnn<br>";
	echo $subject."ddddddddddd<br>";
	$s = $subject;
	//$s = imap_window($subject);
	//$s = imap_utf7_encode($s);
	$s = imap_utf7_decode($s);
	$s = imap_utf8($s); ?>
	
	<font face = "AngsanaUPC" size = "5"><?php echo $s; ?> </font> 
	<?php
	echo "$s MMMMMMMMMMMMMMMM";
	//------------------------*/
	//list($spam,$sub) = split("\[Spam\] ",$subject);
	//$subject = $sub;
	$rcdate = isset($header->date) ? $header->date : "";
	if ( isset ($from[0]->personal))
		$fromname = $from[0]->personal;
	else
		$fromname = "";
	$fromaddress = $from[0]->mailbox . "@" . $from[0]->host;
	$str_to = "";
	foreach ($to as $eachto) {
		if ($str_to != "") $str_to .= "<br>";
		$str_to .= isset($eachto->personal) ? $eachto->personal : "";
		$str_to .= "&nbsp;" . "\"". "$eachto->mailbox" . "@" . "$eachto->host"  .  "\"" ;
	}
	$str_cc = "";
	foreach ($cc as $eachcc) {
		if($str_cc != "") $str_cc .= "<br>";
		$str_cc .= isset($eachcc->personal) ? $eachcc->personal :"";
		$str_cc .= "&nbsp;(".$eachcc->mailbox."@".$eachcc->host.")";
	}
	?>
<body bgcolor="#FFF1DD">
<form name="InboxForm" method="post" action='readmailaction.php'>
	<input type='hidden' name='hnum' value='<?php print $pnum; ?>'>
	<table width = '100%'>
	<tr>
		<td><input type='submit' name='btreply' value='�ͺ��Ѻ'>
        <input type='submit' name='btforward' value='�觵��'>
        <input type='submit' name='btdelete' value='ź������'> 
     	</table>
</form>

<table width="100%" bgcolor="#DEDEDE">
	<tr><td width="100%" bgcolor="#FFFFFF">
		<table width="100%">
			<tr valign="top">
				<td><font size='2'>����ͧ</font>
				<td><font size='2'><?php print $subject; ?></font>
			<tr valign="top">
				<td><font size='2'>�ҡ</font>
				<td><font size='2'><?php print "$fromname ($fromaddress)"; ?></font>
			<tr valign="top">
				<td><font size='2'>�ѹ�����</font>
				<td><font size='2'><?php print $rcdate; ?></font>
			<tr valign="top">
				<td><font size='2'>�觶֧</font>
				<td><font size='2'><?php print $str_to; ?></font>
			<tr valign="top">
				<td><font size='2'>���Ҷ֧</font>
				<td><font size='2'><?php print $str_cc; ?></font>
		</table>
</table><br>			
<table width="100%"	bgcolor='#DEDEDE'>
	<tr><td width="100%" bgcolor="#FFFFFF">
		<table width="100%">
			<tr><td width="100%">
<PRE>
<?php
print imap_fetchbody($mbox, $pnum, 1);
?>
</PRE>
</table>
</table>

<?php



$total = imap_body($mbox, $pnum);


$totals = explode("\n",$total);
$name = "Content-Type: application/octet-stream; name=";
$tim = "";
if ($totals != NULL) {
		foreach ($totals as $eachtotals) {
			if (strstr($eachtotals,$name)) {
				$tims = explode("name=",$eachtotals);
				$ti = substr($tims[1],1);
				$tir = explode("\"",$ti);
				$t[] = $tir[0]; 
			}
		}

	if ($t != NULL) { ?>
		<br>
<table width="100%"	bgcolor='#DEDEDE'>
	<tr><td width="100%" bgcolor="#FFFFFF">
		<table width="100%">
			<tr><td width="100%">
<PRE> <?php 
echo "��������Ѻ :<br>"; 
	foreach ($t as $tt) {
		
		$ttt = explode("/",$tt);
		//$tttt[] = $ttt[1]; ?>
		
		<a href='http://www.kmitlmail.com/mail/<?php echo $tt ?>'><?php echo $ttt[1] ?></a>
	<?php }
		 ?>
	</PRE>
</table>
</table>
<?php } }
?>
	
	
</body>



<?php
	/*$path = "C:\Inetpub\wwwroot\mail\\".$ss_UserID;
	$dh = opendir($path);
	print "<table>";
	while (false != ($mfile = readdir($dh))) {
		$fullpath = $path . "/" .$mfile;
		print "<tr><td>$mfile<td>" . filetype($fullpath);
		print "<td align = 'right'>" . ((filesize($fullpath) > 0) ?
				(ceil(filesize($fullpath) /1024) ." KB") : "");
		$t = date("r", filemtime($fullpath));
		echo "$t<br>";		
		list($t1,$t2,$t3) = split(":",$t);		
		$realtime = "$t1:$t2";
				
		print "<td>" . $realtime . "\n";
		
		//print $fullpath."\n";
		
	}
	
	
	
	print "</table>";
	closedir($dh);
	
	print $rcdate."\n"; */
	
?> 
<?php
	imap_close($mbox);
?>	
	
	



