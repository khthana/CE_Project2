<?php
	session_register("ss_Attach");
	//$ss_Attach = array();
	session_register("ss_AttachSize");
	//$ss_AttachSize = array();
	session_register("ss_UserID");
	if(isset($cbxDel)) {
		foreach ($cbxDel as $key => $eachDel) {
			if (is_file($ss_Attach[$key])) {
				unlink($ss_Attach[$key]);
			}
			unset($ss_Attach[$key]);
			array_splice($ss_Attach, 0, 0);
			unset($ss_AttachSize[$key]);
			array_splice($ss_AttachSize, 0, 0);
		}
	}
	header("Location: compose.php");
?>