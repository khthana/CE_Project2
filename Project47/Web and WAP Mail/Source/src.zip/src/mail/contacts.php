<?php
	session_register("ss_UserID");	
?>


<html>
<body bgcolor="#FFF1DD"><br><br>
<center><table bgcolor ='orange'><tr><td>
 <center><font face = "DilleniaUPC" size = "5"><u>��ش��ª���</u></font><br><br>
 <tr><td><center><form method="post" action="contact_show.php" name="left" target="_fs" >
<input type="submit" name="groups" value="�ҵԾ���ͧ">
</form>
 <tr><td><center><form method="post" action="contact_show.php" name="left" target="_fs" >
<input type="submit" name="groups" value="���;�" >
</form> 
 <tr><td><center><form method="post" action="contact_show.php" name="left" target="_fs" >
<input type="submit" name="groups" value="���͹" >
</form> 
 <tr><td><center><form method="post" action="contact_show.php" name="left" target="_fs" >
<input type="submit" name="groups" value="���͹�����ҹ" >
</form> 
  </center></table>
</body>
</html>
