<?php
	session_register("ss_Attach");
	//$ss_Attach = array();
	session_register("ss_AttachSize");
	//$ss_AttachSize = array();
	session_register("ss_UserID");
	
	if(isset($cAttachfile)) {
		if(is_uploaded_file($cAttachfile)) {
			if(!is_dir("$ss_UserID")) {
				mkdir("$ss_UserID", 0777);
			}
			//if(!is_dir("$ss_UserID/send")) {
			//	mkdir("$ss_UserID/send", 0777);
			//}
			if(move_uploaded_file($cAttachfile, "$ss_UserID/$cAttachfile_name")) {
				chmod("$ss_UserID/$cAttachfile_name", 0777);
				$ss_Attach[] = "$ss_UserID/$cAttachfile_name";
				$ss_AttachSize[] = filesize("$ss_UserID/$cAttachfile_name");
			}
		}
	}
	header("Location: compose.php");
?>
		