<?php
	session_register("ss_UserID");
	
?>


<html>
<body bgcolor="#FFF1DD">

 <br><br>
<font face = "DilleniaUPC" size = "5"><u><?php echo $groups ?></u></font><br><br> 
<table border="2" bordercolor="#FF9933" width="80%">
	<tr bgcolor="orange">
		<td><center><b>�����</b></center></td>
		<td><center><b>����</b></center></td>
		<td><center><b>������</b></center></td>
		<td><center><b>�������Ѿ��</b></center></td>
		<td><center><b>���</b></center></td>
		<td><center><b>ź</b></center></td>
	</tr>	

<?php
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
		$result = mysql_query("SELECT * FROM contact WHERE username = '$ss_UserID' and gro = '$groups'" );
		$total = mysql_num_rows($result);
	if ($total <= 0) { ?>
	<tr bgcolor="#FFF1DD">
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
	</tr> 
<?php	} else { 
	for ($i=0;$i<$total;$i++) { 
	$a = mysql_result($result, $i , "gro");
	$b = mysql_result($result, $i , "name"); 
	$c = mysql_result($result, $i , "email");
	$d = mysql_result($result, $i , "phone"); ?>
	<form action="contact_delete.php">
	<tr bgcolor="#FFF1DD">
		<td><center>&nbsp;<?php echo $a; ?></center></td>
		<td><center>&nbsp;<?php echo $b; ?></center></td>
		<td><center>&nbsp;<?php echo $c; ?></center></td>
		<td><center>&nbsp;<?php echo $d; ?></center></td>
		<td><center>
		
			<input type="submit" name="edit" value = "���" >
		<?php		
			echo "<input type=\"hidden\" name='aa' value='$a'>";
			echo "<input type=\"hidden\" name='bb' value='$b'>";
			echo "<input type=\"hidden\" name='cc' value='$c'>";
			echo "<input type=\"hidden\" name='dd' value='$d'>";
		?>
		</td>
		<td><center>
			<input type="submit" name= "deleted" value = "ź">			
		</td>
	</tr> 
	</form>
 <?php	} 
 	}
 ?>
</table>



<form method="post" action="contact_query.php" target="_fs">
<br> <font face = "DilleniaUPC" size = "5"><u>������ª���</u></font><br><br>

	<table border="2" bordercolor="#FF9933" width="72%" >

	<tr>
		
      <td width="331" align="right">�����&nbsp;&nbsp;&nbsp;&nbsp; 
      <td size="30" align="left" width="366">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <select name="groups">
    <option value='�ҵԾ���ͧ'>�ҵԾ���ͧ</option>
    <option value='���;�'>���;�</option>
    <option value='���͹'>���͹</option>
    <option value='���͹�����ҹ'>���͹�����ҹ</option>
		</select>
    </tr>
	
	<tr> 
      <td align="right">����&nbsp;&nbsp;&nbsp;&nbsp; 
      <td width="366" align="center" size="30"><input type="text" name="name" size="30" maxlength="50">
	</tr>
	
	<tr>
		
      <td align="right">������&nbsp;&nbsp;&nbsp;&nbsp; 
      <td width="366" align="center" size="30"><input type="text" name="email" size="30" maxlength="80">
	</tr>
<tr>
		
      <td align="right" width="331">�������Ѿ��&nbsp;&nbsp;&nbsp;&nbsp; 
      <td width="366" align="center" size="30"><input type="text" name="phone" size="30" maxlength="9">
	</tr>
	<tr><br><td align="right" width="331">&nbsp;&nbsp;&nbsp;&nbsp; 
		<center><td align="center"><input type = "submit" value="������ª���" name="send1"></td></center>
		
	</tr>
	</table>

</form>
</body>
</html>
