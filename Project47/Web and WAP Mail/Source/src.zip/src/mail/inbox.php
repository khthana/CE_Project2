<?php
	session_register("ss_UserID");
?>
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD" link='#000000' vlink="#000000" alink="red">
<?php
	//session_start();
	$ss_CurrentBox = "Inbox";
?>
<script language = 'javascript'>
parent._fMenu.location.reload();
</script>
<form name='InboxForm' method='post' action='inboxaction.php'>
	<table width = "100%">
		<tr><td align="left"><input type = 'submit' name='btdelete' value = 'ź������'></td></tr>
	</table>
<?php 
include("listmail.php");
?>
</form>
</body>
</html>