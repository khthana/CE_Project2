<?php
	session_register("ss_UserID");
?>
<html>
<head><title>Kmitl Webmail</title></head>
<?php 
	
	$ss_mailserver = "{mail.kmitlmail.com:143/imap}INBOX";
	$ss_DBName = "kmitlmail";
	$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	or die("Could not connect database."."Invalid username or password.");
	mysql_select_db($ss_DBName, $link);	
	$result = mysql_query("select password from user where username = '$ss_UserID';");
	$dbarr = mysql_fetch_array($result);
	$ss_Pwd = $dbarr[0];
	$temp = $ss_UserID."@kmitlmail.com";
	$mbox = imap_open($ss_mailserver, $temp, $ss_Pwd);
	$headers = imap_headers($mbox);
	$inboxmail = 0;
	$deletedmail = 0;
	for($i=1;$i<=count($headers);$i++) {
		$header = imap_header($mbox, $i);
		if ($header->Deleted == "D") {
			$deletedmail++;
		} else {
			$inboxmail++;
		}
	}		
?>
<body bgcolor="orange" link='#000000' vlink="#000000" alink="red">
<table width="100%" bgcolor="#FFF1DD">
	<tr><td><center><font size="2" color="black"><b>Folder</b></font></center></td></tr>
</table>
<table width="100%">
	<tr><td><font size="2"><a href='inbox.php' target="_fContent"><b>Inbox</b></a>
		<font color="#FF6600">&nbsp;&nbsp;[<?php echo $inboxmail ?>]</font></font>
	<tr><td><font size="2"><a href='delbox.php' target="_fContent"><b>Delete Items</b></a>
		<font color="#FF6600">&nbsp;&nbsp;[<?php echo $deletedmail ?>]</font></font>
		<a href="expunge.php"><font size="2"><i>(Expunge)</i></font></a>
</table>
</body>
<?php 

imap_close($mbox); 

 ?>

</html>