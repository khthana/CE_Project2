<?php
	session_register("ss_UserID");	
?>


<html>
<body bgcolor="#FFF1DD">

 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<center><font face = "DilleniaUPC" size = "5"><u>�ѹ�֡</u></font></center><br><br>
 
<center><table border="2" bordercolor="#FF9933" width="70%">
	<tr bgcolor="orange">
		<td><center><b>��Ǣ������ͧ</b></center></td>
		<td><center><b>�ѹ���</b></center></td>
		<td><center><b>����</b></center></td>
		<td><center><b>���</b></center></td>
		<td><center><b>ź</b></center></td>
	</tr>	

<?php
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
	
	$result = mysql_query("SELECT * FROM organiser where username = '$ss_UserID' order by date,time");
	$total = mysql_num_rows($result);

	if ($total <= 0) { ?>
	<tr bgcolor="#FFF1DD">
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
		<td><center>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center></td>
	</tr> 
<?php	} else { 
	for ($i=0;$i<$total;$i++) { 
	$a = mysql_result($result, $i , "type");
	$b = mysql_result($result, $i , "date"); 
	$c = mysql_result($result, $i , "time"); ?>
	<form action="organiser_delete.php">
	<tr bgcolor="#FFF1DD">
		<td><center><?php echo $a; ?></center></td>
		<td><center><?php echo $b; ?></center></td>
		<td><center><?php echo $c; ?></center></td>
		<td><center>
		
			<input type="submit" name="edit" value = "���">
		<?php		
			echo "<input type=\"hidden\" name='aa' value='$a'>";
			echo "<input type=\"hidden\" name='bb' value='$b'>";
			echo "<input type=\"hidden\" name='cc' value='$c'>";
		?>
		</td>
		<td><center>
			<input type="submit" name= "deleted" value = "ź">			
		</td>
	</tr> 
	</form>
 <?php	} 
 	}
 ?>
</table></center>
<form method="post" action="organiser_send.php">
<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<center><font face = "DilleniaUPC" size = "5"><u>�����ѹ�֡</u></font><br>

	<center><table border="2" bordercolor="#FF9933" width="45%" >
	<tr>
		<td align="right">��Ǣ������ͧ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<td width="240" align="center" size="30"><input type="text" name="types" size="30">
	</tr>
	<tr>
		<td align="right">�ѹ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<td size="30" align="center"><select name="day">
	<option value="01">1</option>
	<option value="02">2</option>
	<option value="03">3</option>
	<option value="04">4</option>
	<option value="05">5</option>
	<option value="06">6</option>
	<option value="07">7</option>
	<option value="08">8</option>
	<option value="09">9</option>
	<option value="10">10</option>
	<option value="11">11</option>
	<option value="12">12</option>
	<option value="13">13</option>
	<option value="14">14</option>
	<option value="15">15</option>
	<option value="16">16</option>
	<option value="17">17</option>
	<option value="18">18</option>
	<option value="19">19</option>
	<option value="20">20</option>
	<option value="21">21</option>
	<option value="22">22</option>
	<option value="23">23</option>
	<option value="24">24</option>
	<option value="25">25</option>
	<option value="26">26</option>
	<option value="27">27</option>
	<option value="28">28</option>
	<option value="29">29</option>
	<option value="30">30</option>
	<option value="31">31</option>

</select>

<select name="month" >
	<option value="01">���Ҥ�</option>
	<option value="02">����Ҿѹ��</option>
	<option value="03">�չҤ�</option>
	<option value="04">����¹</option>
	<option value="05">����Ҥ�</option>
	<option value="06">�Զع�¹</option>
	<option value="07">�á�Ҥ�</option>
	<option value="08">�ԧ�Ҥ�</option>
	<option value="09">�ѹ��¹</option>
	<option value="10">���Ҥ�</option>
	<option value="11">��Ȩԡ�¹</option>
	<option value="12">�ѹ�Ҥ�</option>
</select>
<select name="year" size="1">
	<option value="2548">2548</option>
</select>

	</tr>
	<tr>
		<td height="26" align="right">����&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<td size="30"  align="center"><input type="text" name="hour" maxlength="2" size="2" value="00">&nbsp;&nbsp;:&nbsp;&nbsp;
									<input type="text" name="min" maxlength="2" size="2" value="00">&nbsp;&nbsp;:&nbsp;&nbsp;
									<input type="text" name="sec" maxlength="2" size="2" value="00">&nbsp;&nbsp;&nbsp;&nbsp;
		
		</td>
	</tr>
	
	<tr><br><td width="135">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<center><td align="right"><input type = "submit" value="�����ѹ�֡" name="send"></td></center>
		
	</tr>

	
	</table></center>

</form>
</body>
</html>

