<?php
session_start();
if (!session_is_registered("ss_DBName")) session_register("ss_DBName");
if (!session_is_registered("ss_mailserver")) session_register("ss_mailserver");
if (!session_is_registered("ss_UserID")) session_register("ss_UserID");
if (!session_is_registered("ss_Pwd")) session_register("ss_Pwd");
if (!session_is_registered("ss_CurrentBox")) session_register("ss_CurrentBox");
if (!session_is_registered("ss_Email")) session_register("ss_Email");
if (!session_is_registered("ss_Attach")) session_register("ss_Attach");

?>
<script language='javascript'>
	parent.location.href = "login.php";
</script>