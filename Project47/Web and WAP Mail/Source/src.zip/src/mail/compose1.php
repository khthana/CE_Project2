<?php
	session_register("ss_Attach");
	//$ss_Attach = array();
	session_register("ss_AttachSize");
	//$ss_AttachSize = array();
	session_register("ss_UserID"); ?>
	
	<html>
				<head><title>Kmitl Webmail</title></head>
				<body bgcolor="#FFF1DD">
				<br><br>
				<center><table bgcolor="orange" width="45%">
				<tr><td></td></tr>
				<tr><td></td></tr>
<?php	
	if(isset($cSendTo) and $cSendTo != "") {
		if(isset($btsend)) {
			$boundary = md5(uniqid(time()));
			if(!isset($cSubject)) $cSubject = "";
			if(!isset($cContent)) $cContent = "";
			$addheader = "From: $ss_UserID@kmitlmail.com\r\n";
			if(isset($cCCto)) $addheader .= "Cc: $cCCto\r\n";
			if(isset($cBCCto)) $addheader .= "Bcc: $cBCCTo\r\n";
			$addheader .= "Reply-To: $ss_UserID@kmitlmail.com\r\n";
			$addheader .= "X-Mailer: PHP/" . phpversion() . "\r\n";
			$addheader .= "MIME-Version: 1.0\r\n";
			$addheader .= "Content-Type: multipart/mixed; " .
						  "boundary=\"$boundary\"\r\n\r\n";
						  
			$message = "--$boundary\r\n";
			$message .= "Content-Type: text/html\r\n";
			$message .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
			$message .= $cContent . "\r\n";
			//echo $ss_Attach[0]; 
			if ($ss_Attach != NULL) {
		
			foreach ($ss_Attach as $eachAttach) {
			//	echo $eachAttach;
				//$eachAttach = "555.txt";
				$filehandle = fopen($eachAttach, "r") or
								die ("Cannot open file $eachAttach");
				$Contents = fread($filehandle, filesize($eachAttach));
				fclose($filehandle);
				$message .= "--$boundary\r\n";
				$message .= "Content-Type: application/octet-stream; " .
							"name=\"$eachAttach\"\r\n";
				$message .= "Content-Transfer-Encoding: base64\r\n";
				$message .= "Content-Disposition: attachment; " .
							"filename=\"" . basename($eachAttach) .
							"\"\r\n\r\n";
				$message .= chunk_split(base64_encode($Contents)) .
							"\r\n"; ?>
					<tr><td><center>			
			<?php	print "Send file : " .basename($eachAttach) . "<br>\n";
				} }
			$message .= "--$boundary--\r\n\r\n";
			if (mail($cSendTo, $cSubject, $message, $addheader)) { 
				?>
				
				<tr><td></td></tr>
				<tr><td><center><font face = "DilleniaUPC" size = "5">���������֧</font></center>
				<tr><td></td></tr>
				<tr><td><center><?php echo $cSendTo ?></center></td></tr>
				<tr><td></td></tr>
				<tr><td><center><font face = "DilleniaUPC" size = "5">��������ó�</font></center></td></tr>
				</table></center>
				</body>
				</html>
			<?php } else { ?>
				<html>
				<head><title>Kmitl Webmail</title></head>
				<body bgcolor="#FFF1DD">
				<br><br>
				<center><table bgcolor="orange" width="45%">
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td><center><font face = "DilleniaUPC" size = "5">�Դ��ͼԴ��Ҵ���������</font></center>
				<tr><td></td></tr>
				<tr><td><center><font face = "DilleniaUPC" size = "5">�������ö��������</font></center>
				<tr><td></td></tr>
				<tr><td></td></tr>
				</table></center>
				</body>
				</html>
			<?php	
			}
		}
	} else { ?>
		<html>
				<head><title>Kmitl Webmail</title></head>
				<body bgcolor="#FFF1DD">
				<br><br>
				<center><table bgcolor="orange" width="45%">
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td></td></tr>
				<tr><td><center><font face = "DilleniaUPC" size = "5">��س�����������ʹ��ʼ���Ѻ���١��ͧ</font></center>
				<tr><td></td></tr>
				<tr><td></font></center>
				<tr><td></td></tr>
				<tr><td></td></tr>
				</table></center>
				</body>
				</html>
<?php	}
	if (session_is_registered("ss_Attach")) session_unregister("ss_Attach");
	if (session_is_registered("ss_AttachSize")) session_unregister("ss_AttachSize");
			
?>
