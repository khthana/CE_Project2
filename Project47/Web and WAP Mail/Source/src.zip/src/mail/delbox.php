<?php
	session_start();
	$ss_CurrentBox = "Deleted box";	
?>

<form name='DelboxForm' method='post' action='delboxaction.php'>
	<table width="100%">
		<tr>
		<td align="left"><input type='submit' name='btundelete' value="�֧��Ѻ�׹"></td>
	</table>
<?php 
include("listmail.php");
?>
</form>