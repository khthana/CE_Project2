<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD">
<center><img src = 'picture/head_r1.jpg' border='0'></center><br><br><br>

<form name = 'register' method='post' action='registers.php'>
	<center><table width="527" bgcolor="orange">
	<tr>	<td width="221" align='right' size='2' >
		<td width="333">
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td height="29" align='right' size='2'><font face = "DilleniaUPC" size = "5"><br>���ͼ����&nbsp;&nbsp;&nbsp;</font>
		<td><br><input type='text' name='username' size="20" maxlength="50">@mail.kmitlserver.com
	<tr>	<td height="29" align='right' size='2'><p><font face = "DilleniaUPC" size = "5">���ʼ�ҹ&nbsp;&nbsp;</font></p>
          <td><input type='password' name='password'  size="20" maxlength="10">
          <font face = "DilleniaUPC" size = "5">&nbsp; </font> 
      <tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">�׹�ѹ���ʼ�ҹ&nbsp;&nbsp;&nbsp;</font>
		<td><input type='password' name='password2'  size="20" maxlength="10">
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">����&nbsp;&nbsp;&nbsp;</font>
		<td><input type='text' name='firstname' size="20" maxlength="50">
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">���ʡ��&nbsp;&nbsp;&nbsp;</font>
		<td><input type='text' name='lastname' size="20" maxlength="50">
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">�������&nbsp;&nbsp;&nbsp;</font>
		<td><input type='text' name='address' size="40" maxlength="200">
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">�������Ѿ��&nbsp;&nbsp;&nbsp;</font>
		<td><input type='text' name='phone' size="20" maxlength="9">
	<tr>	<td colspan='2' align='center'>
		<br><input type='submit' name='confirm' value='�׹�ѹ'>
		<input type='reset' name='cancel' value='Clear'>
		<td width="10">
	<tr>	<td size='2' align='right'>
		<td align="right"><a href="login.php" target ="_top"><font face = "DilleniaUPC" size = "5">��͹��Ѻ</font></a><tr>	<td size='2' align='right'>
		<td>
	</table>
  </center>
</form>
</body>
</html>