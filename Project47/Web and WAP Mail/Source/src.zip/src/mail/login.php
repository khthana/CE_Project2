<?php
		session_start();
		session_unregister("ss_UserID");		
?>
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD">
<?php

	//$ss_DBName = "kmitlmail";
	//$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	//or die("Could not connect database."."Invalid username or password.");
	//mysql_select_db($ss_DBName, $link);
	

?>
<center><img src = 'picture/head_r1.jpg' border='0'></center><br><br><br>
<form name = 'loginForm' method='post' action='verify.php'>
	<center><table bgcolor="orange" width="40%">
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td colspan='2' align='center'><img src = 'picture/menu6.gif' border='0'>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">���ͼ����&nbsp;&nbsp;&nbsp;</font>
		<td><input type='text' name='ss_UserID'>@kmitlmail.com
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">���ʼ�ҹ&nbsp;&nbsp;&nbsp;</font>
		<td><input type='password' name='cPwd'>
	<tr>	<td colspan='2' align='center'>
		<br><input type='submit' name='btsubmit1' value='ŧ���������'>
          <input type='submit' name='btsubmit2' value='ŧ����¹����'> <tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	</table></center>
</form>
</body>
</html>
