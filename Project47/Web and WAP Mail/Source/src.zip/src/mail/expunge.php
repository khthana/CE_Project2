<?php
	session_start();
	$ss_mailserver = "{mail.kmitlmail.com:143/imap}INBOX";
	$ss_DBName = "kmitlmail";
	$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
			or die("Could not connect database."."Invalid username or password.");
	mysql_select_db($ss_DBName, $link);
	$result = mysql_query("select password from user where username = '$ss_UserID';");
	$dbarr = mysql_fetch_array($result);
	$ss_Pwd = $dbarr[0];
	$mbox = imap_open($ss_mailserver, $ss_UserID."@kmitlmail.com", $ss_Pwd);
	imap_expunge($mbox);
	imap_close($mbox);
?>
<script language = 'javascript'>
	window.navigate("menu.php");
<?php 
	if($ss_CurrentBox == "Delete box") {
		print "parent._fContent.location.reload();\n";
	}
?>
</script>