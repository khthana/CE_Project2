<?php
	session_register("ss_UserID");	
?>

<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD">
<br><br>

<?php
	$ss_DBName = "kmitlmail";		
			$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
					or die("Could not connect database."."Invalid username or password.");
			mysql_select_db($ss_DBName, $link);
	$q = mysql_query("select * from user where username = '$ss_UserID'");
	$d = mysql_fetch_array($q);
			
?>

<form name = 'register' method='post' action='edits.php'>
	<center><table width="527" bgcolor="orange">
	<tr>	<td width="221" align='right' size='2' >
		<td width="333">
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td size='2' align='right'>
		<td>
	<tr>	<td height="29" align='right' size='2'><font face = "DilleniaUPC" size = "5"><br>���ͼ����&nbsp;&nbsp;&nbsp;</font>
		<td><br><?php echo "$d[0]"; ?>@mail.kmitlserver.com
	<tr>	<td height="29" align='right' size='2'><p><font face = "DilleniaUPC" size = "5">���ʼ�ҹ&nbsp;&nbsp;</font></p>
          <td><?php 
		  			for ($i=1;$i<=strlen($d[1]);$i++){ ?>
						<b>&bull;</b>
					<?php } ?>
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">����&nbsp;&nbsp;&nbsp;</font>
		<td><?php echo "<input type='text' name='firstname' size='20' maxlength='50' value='$d[2]'>";?>
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">���ʡ��&nbsp;&nbsp;&nbsp;</font>
		<td><?php echo "<input type='text' name='lastname' size='20' maxlength='50' value='$d[3]'>"; ?>
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">�������&nbsp;&nbsp;&nbsp;</font>
		<td><?php echo "<input type='text' name='address' size='40' maxlength='200' value='$d[4]'>"; ?>
	<tr>	<td size='2' align='right'><font face = "DilleniaUPC" size = "5">�������Ѿ��&nbsp;&nbsp;&nbsp;</font>
		<td><?php echo "<input type='text' name='phone' size='20' maxlength='9' value='$d[5]'>"; ?>
	<tr>	<td colspan='2' align='center'>
		<br><input type='submit' name='confirm' value='�׹�ѹ������'>
		
		<td width="10">
	<tr>	<td size='2' align='right'>
		<td align="right"><tr>	<td size='2' align='right'>
		<td><br>
	</table>
  </center>
</form>
</body>
</html>