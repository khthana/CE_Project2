<?php
	session_register("ss_UserID");
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
		if ($deleted != null) {
		 	$q = "delete from contact where username = '$ss_UserID' 
									and gro = '$aa' 
									and name = '$bb' 
									and email ='$cc'
									and phone ='$dd';";
			$user = mysql_query($q); ?>
			<script language = 'javascript'>
	window.navigate("contact_show.php");
	</script>
<?php } else if ($edit != null) { 

?>
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD"><br><br>
		<form method="post" action="contact_edit.php">
		<?php		
			echo "<input type=\"hidden\" name='aaa' value='$aa'>";
			echo "<input type=\"hidden\" name='bbb' value='$bb'>";
			echo "<input type=\"hidden\" name='ccc' value='$cc'>";
			echo "<input type=\"hidden\" name='ddd' value='$dd'>";
		?>
<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<center><font face = "DilleniaUPC" size = "5"><u>�����ª���</u></font><br>

	<center><table border="2" bordercolor="#FF9933" width="63%" >
	<tr>
		<td align="right">�����&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 <td width="325" align="left" size="30">
		 <select name="g">
		<?php 
	
		if (strcmp('�ҵԾ���ͧ',$aa) == 0) { 
		 		echo "<option selected=\"selected\" value='�ҵԾ���ͧ'>�ҵԾ���ͧ</option>";		
		  } else { 
		  
		  		echo "<option value='�ҵԾ���ͧ'>�ҵԾ���ͧ</option>";
		  
		  } 
		  if (strcmp('���;�',$aa) == 0) { 
		 		echo "<option selected=\"selected\" value='���;�'>���;�</option>";		
		  } else { 
		  
		  		echo "<option value='���;�'>���;�</option>";
		  
		  } 
		  if (strcmp('���͹',$aa) == 0) { 
		 		echo "<option selected=\"selected\" value='���͹'>���͹</option>";		
		  } else { 
		  
		  		echo "<option value='���͹'>���͹</option>";
		  
		  } 
		  if (strcmp('���͹�����ҹ',$aa) == 0) { 
		 		echo "<option selected=\"selected\" value='���͹�����ҹ'>���͹�����ҹ</option>";		
		  } else { 
		  
		  		echo "<option value='���͹�����ҹ'>���͹�����ҹ</option>";
		  
		  } 
		  ?>
		  </select>
	</tr>
	<tr>
		<td align="right">����&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 <td width="325" align="left" size="30">
		<?php echo "<input type=\"text\" name=\"name\" size=\"30\" value='$bb'>" ?>
	</tr>
	<tr>
		<td align="right">������&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 <td width="325" align="left" size="30">
		<?php echo "<input type=\"text\" name=\"email\" size=\"30\" value='$cc'>" ?>
	</tr>
	<tr>
		<td align="right">�������Ѿ��&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 <td width="325" align="left" size="30">
		<?php echo "<input type=\"text\" name=\"phone\" size=\"30\" value='$dd'>" ?>
	</tr>
	<tr><br><td width="283">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<td align="center"><input type = "submit" value="�����ª���" name="send"></td>
		
	</tr>

	
	</table></center>

</form>	



<?php } ?>


</body>
</html>					