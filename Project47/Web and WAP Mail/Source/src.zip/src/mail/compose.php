<?php
	session_register("ss_UserID");	
	$ss_mailserver = "{mail.kmitlmail.com:143}INBOX";
	$ss_DBName = "kmitlmail";
	$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
	or die("Could not connect database."."Invalid username or password.");
	mysql_select_db($ss_DBName, $link);
	$result = mysql_query("select password from user where username = '$ss_UserID';");
	$dbarr = mysql_fetch_array($result);
	$ss_Pwd = $dbarr[0];
		
	
	function FileSizeToStr($pFileSize) {
		$sfilesize = ($pFileSize > 1073741824) ? 
		(round($pFileSize / 1073741824, 2) . " Gb") : 
		(($pFileSize > 1048576) ? 
		(round($pFileSize / 1048576, 2) . " Mb") : 
		(ceil($pFileSize / 1024) . " Kb"));
		return $sfilesize;
	}
	if (!session_is_registered("ss_Attach")) {
		session_register("ss_Attach");
		$ss_Attach = array();
	}
	if (!session_is_registered("ss_AttachSize")) {
		session_register("ss_AttachSize");
		$ss_AttachSize = array();
	}

	$msendfrom = "";
	$mreplyto = "";
	$mbody = "";
	$mcontent = "";
	if (isset($paction)) {
		if($paction == "reply" or $paction == "forward") {
			$mbox = imap_open($ss_mailserver, $ss_UserID."@kmitlmail.com", $ss_Pwd);
			$header = imap_header($mbox, $pnum);
			$from = isset($header->from) ? $header->from : array();
			$fromaddress = $from[0]->mailbox . "@" . $from[0]->host;
			$reply = isset($header->from) ? $header->from : array();
			$replyaddress = $reply[0]->mailbox . "@" . $reply[0]->host;
			if (isset($reply[0]->personal)) 
				$mreplyto = $reply[0]->personal;
			if (isset($msendfrom[0]->personal)) 
				$msendfrom = $msendfrom[0]->personal;
			$msendfrom = $msendfrom != "" ? ($msendfrom . " <$fromaddress>") : $fromaddress;
			$mreplyto = $mreplyto != "" ? ("$replyaddress") : $replyaddress;
			if ($paction == "reply") {
				$mcontent = "----- Original Message -----\r\n";
				if (isset($header->subject)) {
					$subject = $header->subject;
					//list($spam,$sub) = split("\[Spam\] ",$subject);
					//$subject = $sub;
					$subject = "Re : " . $subject;
				} else {
					$subject = "Re : ";
				}
			}
			if ($paction == "forward") {
				if(isset($header->subject)) {
					$subject = $header->subject;
					//list($spam,$sub) = split("\[Spam\] ",$subject);
					//$subject = $sub;
					$subject = "Fwd : ". $subject;
				} else {
					$subject = "Fwd : ";
				}
				$mcontent = 	"----- Original Message -----\r\n".
						"Subject : $subject\r\n" . 
						"From : $msendfrom\r\n" .
						"Date : " . $header->date . " \r\n" .
						"-----------------------------------\r\n";
			}
			$mbody = imap_fetchbody($mbox, $pnum, 1);
			$mcontent .= $mbody;
			imap_close($mbox);
		}
	} else {
		$paction = "";
	}
?>

<body bgcolor="#FFF1DD">
<table border="1" bordercolor="#FF9933" width="100%">
	<tr bgcolor="orange">
	<td width="100%"><font size='2' color='#000000'><b> &nbsp;&nbsp;&nbsp;&nbsp;��¹������</b></font>
</table>
	
<form name='ComposeForm' method="post" action='compose1.php'>
  <p> 
    <input type="submit" name='btsend' value='��'>
  </p>
  <table border="1" bordercolor="#FF9933" width="62%">
<tr><td width="43%">�觶֧
	<td width="57%"><input type='text' name='cSendTo' size="60"
		<?php 
		echo ($paction == "reply" ? " value='$mreplyto'" : "");
		?>>
<tr><td>���Ҷ֧<td><input type='text' name='cCCTO' size='60'>
<tr><td>�����Ѻ�֧<td><input type='text' name='cBCCTO' size='60'>
<tr><td>�������ͧ
	<td><input type='text' name='cSubject' size="60"
		<?php
		echo (isset($subject) ? " value='$subject'" : "");
		?>>
</table>			
<p>
    <textarea name='cContent' cols="80" rows="16">
<?php echo $mcontent; ?>
</textarea>
    <br>
    <br>
    <input type='submit' name='btsend' value="��">
  </p>
</form>

<form enctype="multipart/form-data" name='UploadForm' method="post" action="compose_upload.php">
Attach : <input type="file" name="cAttachfile" size="56">
<br><input type="submit" name="btsubmit" value='�������'>
</form>

<form name="attachForm" method="post" action="compose_del.php">
<table width="100%" bgcolor="#DFAF00" border="1">
<tr><td>
	<table width="100%" bgcolor="orange">
	<tr><td><font  color = '#000000'><b>���Ṻ</b></font>
	<td align="right"><input type='submit' name='btDel' value='ź���'>
	</table>
<tr><td>
	<table width="100%" bgcolor="#FFFFFF" >
	<?php 
	if ($ss_Attach != NULL) {
		foreach ($ss_Attach as $key => $eachAttach) {
		print "<tr><td>";
		print "<input type='checkbox' name='cbxDel[$key]'>&nbsp;" .
				"<font size='2' color='#004F9F'>" .
				basename($eachAttach) . "&nbsp;&nbsp;" .
				"<font color='#0000FF'>" .
				FileSizeToStr($ss_AttachSize[$key]) .
				"</font></font>";
		}
	}
	?>
	</table>
</table>
</form>
</body>