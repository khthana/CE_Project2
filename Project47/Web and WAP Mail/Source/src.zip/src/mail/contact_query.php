<?php
	session_register("ss_UserID");
	if ($send1 != null) {
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
?>
		
<html>
<head><title>Kmitl Webmail</title></head>
<body bgcolor="#FFF1DD"><br><br>

	<table bgcolor="orange" width="50%">
	<tr><td>
<?php
	
	function check($var,$name) {
		global $list;
		global $flag;
		if(empty($var))
			$flag = 1;
		if(strcmp($name,"Repeat password") != 0 )
			$list[$name] = $var;
	}
	
	$step = 1;
	check("$name","����");
	
	if($flag) { ?>
		<center><font face = "DilleniaUPC" size = "5"><u><br>��سһ�͹</u><br></font></center>
	<?php	while(list($key,$value) = each($list)) {
				if(empty($value)) { ?>
					<font face = "DilleniaUPC" size = "5">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo "- $key<br>"; ?></font>
	<?php		}
			} ?>
			<br>
			<form>
			<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
			</form>
			
<?php } else {
		echo "<br>";
					
				if ($phone != "") {
					if(ereg("[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]",$phone) and (strlen($phone) == 9)) {
						$step = 2;
					} else { ?>
						<center><font face = "DilleniaUPC" size = "5"><?php echo "�������Ѿ�����١��ͧ"; ?></font>
						<br><br><form>
						<center><input type="button" value="��͹��Ѻ" onClick="history.go(-1)"></center>
						</form>
					<?php }
				} else {
					$step = 2;
				}
				
		} 
		if($step == 2){
		
			$usersresult = mysql_query("insert into contact values('$ss_UserID','$groups','$name','$email','$phone') "); ?>
			<script language = 'javascript'>
	window.navigate("contact_show.php");
</script>
	<?php	}
?>

<?php } ?>
        
						
</table>

</body>
</html>						
						
						
						
						
						
						
						
						
						
						
						
						
						
						