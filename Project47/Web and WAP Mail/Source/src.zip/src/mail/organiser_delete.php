<?php
	session_register("ss_UserID");
		$ss_DBName = "kmitlmail";
		$link = mysql_connect("localhost", "kmitlmail", "kmitlmail")
		or die("Could not connect database."."Invalid username or password.");
		mysql_select_db($ss_DBName, $link);
		if ($deleted != null) {
		 	$q = "delete from organiser where username = '$ss_UserID' and type = '$aa' and date = '$bb' and time='$cc';";
			$user = mysql_query($q); ?>
			<script language = 'javascript'>
			parent._fMenu.location.reload();
			window.navigate("organiser.php");
			</script>
<?php } else if ($edit != null) { 

		list($y ,$m ,$d) = split("-",$bb);
		list($h ,$n ,$s) = split(":",$cc);   
?>

		<form method="post" action="organiser_edit.php">
		<?php		
			echo "<input type=\"hidden\" name='aaa' value='$aa'>";
			echo "<input type=\"hidden\" name='bbb' value='$bb'>";
			echo "<input type=\"hidden\" name='ccc' value='$cc'>";
		?>
<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<center><font face = "DilleniaUPC" size = "5"><u>��䢺ѹ�֡</u></font><br>

	<center><table border="2" bordercolor="#FF9933" width="45%" >
	<tr>
		<td align="right">��Ǣ������ͧ&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 <td width="240" align="center" size="30">
		<?php echo "<input type=\"text\" name=\"types\" size=\"30\" value='$aa'>" ?>
	</tr>
	<tr>
		<td align="right">�ѹ���&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<td size="30" align="center"><select name="day">
	
	 <?php
		for ($i=1;$i<=9;$i++) {
			$dd = "0"."$i"; 	
			if (strcmp($d,$dd) == 0) { 
		 		echo "<option selected=\"selected\" value='$dd'>$i</option>";		
		  } else { 
		  
		  		echo "<option value='$dd'>$i</option>";
		  
		  } 
	}
	for ($i=10;$i<=31;$i++) {
			$dd = $i; 	
			if (strcmp($d,$dd) == 0) { 
		 		echo "<option selected=\"selected\" value='$dd'>$i</option>";		
		  } else { 
		  
		  		echo "<option value='$dd'>$i</option>";
		  
		  } 
	}?>
	
	
</select>
<select name="month" size="1">
<?php
		for ($i=1;$i<=9;$i++) {
			$mm = "0"."$i"; 	
			if (strcmp($m,$mm) == 0) { 
		 		echo "<option selected=\"selected\" value='$mm'>$i</option>";		
		  } else { 
		  
		  		echo "<option value='$mm'>$i</option>";
		  
		  } 
	}
	for ($i=10;$i<=12;$i++) {
			$mm = $i; 	
			if (strcmp($m,$mm) == 0) { 
		 		echo "<option selected=\"selected\" value='$mm'>$i</option>";		
		  } else { 
		  
		  		echo "<option value='$mm'>$i</option>";
		  
		  } 
	}?>
</select>
<select name="year" size="1">
	<option value="2548">2548</option>
</select>

	</tr>
	<tr>
		<td height="26" align="right">����&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<td size="30"  align="center">
		<?php echo "<input type=\"text\" name=\"hour\" maxlength=\"2\" size=\"2\" value='$h'>&nbsp;&nbsp;:&nbsp;&nbsp;
									<input type=\"text\" name=\"min\" maxlength=\"2\" size=\"2\" value='$n'>&nbsp;&nbsp;:&nbsp;&nbsp;
									<input type=\"text\" name=\"sec\" maxlength=\"2\" size=\"2\" value='$s'>&nbsp;&nbsp;&nbsp;&nbsp;"
		?>
		</td>
	</tr>
	
	<tr><br><td width="135">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
		<center><td align="right"><input type = "submit" value="��䢺ѹ�֡" name="send"></td></center>
		
	</tr>

	
	</table></center>

</form>	



<?php } ?>
					