<?
	session_start();

	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="compose_mail" title="New Massage">
		<do type="accept" label="Submit">
			<go href="#send_var"/>
		</do>
		<p>
			<img src="pic_wap/inbox.gif" alt="inbox"/><a href="check_mail.php">inbox message</a><br/>
			<a href="logout.php">Sign out</a><br/><br/>

			Recipient:
			<input title="To" name="to"/><br/>
			Subject:
			<input title="Subject" name="subject"/><br/>
			Message:
			<input title="Message" name="mesg"/><br/>
			From:
			<input title="From" name="from"/><br/>
		</p>
	</card>
	
	<card id="send_var" title="Send E-Mail">
		<p>
		<anchor>
				Yes.<br/>
				<go href="send.php">
					<postfield name="To" value="$to"/>
					<postfield name="Subject" value="$subject"/>
					<postfield name="Mesg" value="$mesg"/>
					<postfield name="From" value="$from"/>
				</go>
		</anchor>
		<anchor>
				NO.<br/>
				<go href="#compose_mail"/>
		</anchor>
		</p>
	</card>

</wml>