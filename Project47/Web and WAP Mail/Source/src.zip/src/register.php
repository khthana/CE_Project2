<?
	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="register_wap_mail" title="Please register">
		<do type="accept" label="Submit">
			<go href="#send_var"/>
		</do>
		<p>
			Username:
			<input title="Username" name="username"/><br/>
			Password:
			<input title="Password" name="password"/><br/>
			First name:
			<input title="First name" name="fname"/><br/>
			Last name:
			<input title="Last name" name="lname"/><br/>
			Address:
			<input title="Address" name="addr"/><br/>
			Phone:
			<input title="Phone" name="phone"/><br/>
		</p>
	</card>

	<card id="send_var" title="Confirm">
		<p>
			<anchor>
					Yes.<br/>
					<go href="insert_db.php">
						<postfield name="Username" value="$username"/>
						<postfield name="Password" value="$password"/>
						<postfield name="Fname" value="$fname"/>
						<postfield name="Lname" value="$lname"/>
						<postfield name="Addr" value="$addr"/>
						<postfield name="Phone" value="$phone"/>
					</go>
			</anchor>
			<br/>
			<anchor>
					NO.<br/>
					<go href="#compose_mail"/>
			</anchor>
		</p>
	</card>
</wml>
