<?
	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="welcome" title="Welcome">
		<p align="center">
			<img src="pic_wap/head_r2.gif" alt="head"/>
		</p>
		
		<p align="center">
			Welcome to KMITL Wap Mail
		</p>

		<p align="center">
			<a href="#Login">Sign in</a><br/>
			<a href="register.php">Register</a><br/>
		</p>
	
	</card>

	<card id="Login" title="Login">
		<do type="accept" label="Submit">
			<go href="#send_var"/>
		</do>
		<p>
	
			Username : <input type="text" name="username" title="Enter username"/>
			Password : <input type="password" name="password" title="Enter Password"/>
			
		</p>
	
	</card>

	<card id="send_var" title="sendvar">
		<p align="left" mode="nowrap">
			Username : $username.<br/>
			Password : $password.<br/>
			<anchor>
				Yes.<br/>
				<go href="check_user_pass.php">
					<postfield name="U" value="$username"/>
					<postfield name="P" value="$password"/>
				</go>
			</anchor>
			<anchor>
				NO.<br/>
				<go href="#Login"/>
			</anchor>
		</p>
		
	</card>
	
</wml>

