<?
	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="insert_db" title="Insert into DB">
		<p>
		<?php
			$host = "localhost";
			$databasename = "kmitlmail";
			$username = "kmitlmail";
			$passwd = "kmitlmail";
			mysql_connect($host,$username,$passwd) or die("Can not connect to DB.");
			$sql = "select username from user;";
			$result = mysql_db_query($databasename,$sql);
			$numrow = mysql_num_rows($result);
			if($numrow == 0){
				echo"No matchs to view.";
			}else{
				while($row=mysql_fetch_array($result)){
					//echo$row[0]."<br/>";
					if($Username == $row[0]){
						$dup_user = 1;
					}else{
						$not_dup_user = 1;
					}
				}
				if($dup_user == 1){
					echo"Username has already use<br/>";
					echo"<a href=\"register.php\">Please try again</a>";
				}else{
					$sql = "insert into user values(\"$Username\",\"$Password\",\"$Fname\",\"$Lname\",\"$Addr\",\"$Phone\");";
					$result = mysql_db_query($databasename,$sql);
					if($result){
						echo"Insert Complete<br/>";
						echo"Welcome to ".$Fname."<br/>";
						echo"<a href=\"welcome_login.php#Login\">Sign in</a>";
					}else{
						echo"Incomplete register<br/>";
						echo"<a href=\"register.php\">Please try again</a>";
					}
				}

			}
		?>
		</p>
	</card>
</wml>
