<?
	session_start();
	session_register("temp_user");
	session_register("temp_pass");

	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="Check_User_Pass" title="Check">
		<p align="center">
		<?php
		//	echo "test CC<br/>";
			$host = "localhost";
			$databasename = "kmitlmail";
			$username = "kmitlmail";
			$passwd = "kmitlmail";
			mysql_connect($host,$username,$passwd);
			$sql = "select * from user;";
			$result = mysql_db_query($databasename,$sql);
			$numrow = mysql_num_rows($result);
			if($numrow == 0){
				echo"No matchs to view.";
			}else{
				//echo"User Profile<br/>";
				$i = 0;
				$temp_user = "none";
				$temp_pass = "none";
			
				while($row=mysql_fetch_array($result)){
					if($U == $row[0]){
						//echo"valid Username\n";
						$temp_user = $row[0];
						//echo $row[1]."<br/>";
						//echo $P;
						if($P == $row[1]){
							//echo"valid Password\n";
							$invalid_passwd = '0';
							$temp_pass = $row[1];
							$temp_firstname = $row[3];
							$temp_lastname  = $row[4];
							break;
						}else{
							//echo"Invalid Password\n";
							$invalid_passwd = '1';
							$temp_user = "none";
							break;
						}
					}else{
						//echo"Non user in database\n";		
					}
				}
				if(($temp_user == "none")&&($temp_pass == "none")&&($invalid_passwd != '1')){
					// Not complete about register //
					echo"Invalid username<br/>";
					echo"Please register <br/>";
					echo"<a href=\"register.php\">Register</a><br/>";
				}else if($invalid_passwd == '1'){
					echo"Invalid  Password<br/>";
					echo"<a href=\"welcome_login.php#Login\">Sign in</a><br/>";
				}else{
					echo"Complete Sign in<br/>";
					echo"<a href=\"#show_profile_user\">Next</a><br/>";
					echo"<a href=\"logout.php#\">Sign out</a><br/>";
				}
			}
			mysql_close();
			?>
		</p>
	</card>

	<card id="show_profile_user" title="Welcome">
		<p align="center">
			<img src="pic_wap/mail_s1.gif" alt="mail"/>
			<br/>
			<big>Welcome to<br/> KMITL WAP MAIL</big><br/>
			
				<img src="pic_wap/inbox.gif" alt="inbox"/><a href="check_mail.php">inbox message</a><br/>
				<img src="pic_wap/new_mail.gif" alt="new_mail"/><a href="compose.php">new message</a><br/>
				<a href="logout.php">Sign out</a>

		</p>
	</card>
</wml>
