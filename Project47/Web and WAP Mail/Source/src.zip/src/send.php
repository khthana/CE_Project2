<?
	session_start();

	header("Content-Type: text/vnd.wap.wml");
	echo "<?xml version=\"1.0\"?>\n";
	echo "<!DOCTYPE wml PUBLIC \"-//WAPFORUM//DTD WML 1.1//EN\" \"http://www.wapforum.org/DTD/wml_1.1.xml\">\n";
?>
<wml>
	<card id="send_email" title="New Massage">
		<p align="center">
			<?
			function errormesg($str){
				echo $str;
				$flag_error = 1;
			?>
				<a href="compose.php">Try to send again</a>
			<?
			}
			function checkaddr($addr){
				if(!eregi("^[a-aA-Z0-9_]+@[a-zA-Z0-9\-]+[a-zA-Z0-9\-\.]+$",$addr)){
					errormesg("Invalid E-Mail Address");
					$flag_error = 1;
				}
				else{
					$flag_error = 0;
				}
				return($flag_error);
			}

			/*echo$From."<br/>";
			echo$To."<br/>";
			echo$Subject."<br/>";
			echo$Mesg."<br/>";
			*/
			
			$flag_To   = checkaddr($To);
			$flag_From = checkaddr($From);
			//echo$flag_To.".....".$flag_From."<br/>";
			if(($flag_To == 0)&&($flag_From == 0)){
				$flag = mail($To,$Subject,$Mesg,"From: $From");
				if($flag){
					echo"Sending complete<br/>";
			?>
					<img src="pic_wap/inbox.gif" alt="inbox"/><a href="check_mail.php">inbox message</a><br/>
					<img src="pic_wap/new_mail.gif" alt="new_mail"/><a href="compose.php">new message</a><br/>
			<?
				}else{
					errormesg("Incomplete sending<br/>");
				}
			}else{
				echo"<br/>";
			}
			?>
		</p>
	</card>
</wml>