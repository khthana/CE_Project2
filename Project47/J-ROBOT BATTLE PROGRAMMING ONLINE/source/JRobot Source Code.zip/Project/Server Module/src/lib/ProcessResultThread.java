/*
 * Created on 15 ��.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ProcessResultThread extends Thread {
	private Connection c  = null;
	private PreparedStatement p = null;	
	private String player1;
	private String player2;
	private Vector p1Script;
	private Vector p2Script;
	private int p1x = -50;
	private int p1y = 50;
	private int p2y = 50;
	private int p1Position = 4;
	private int p2Position = 20;
	private int p1Hp = 100;
	private int p2Hp = 100;
	private int time = 60;
	private Vector result;
	public ProcessResultThread(String p1,String p2,Vector result){
		player1 = p1;
		player2 = p2;
		this.result = result;
	}
	public void run(){
		ObjectNode p1Info;
		ObjectNode p2Info;
		getScript();
		int p1Index = 0;
		int p2Index = 0;
		boolean p1left = false;
		boolean p2left = false;
		boolean p1useSpecial = true;
		boolean p2useSpecial = true;
		if((p1Script.size() > 0) && (p2Script.size()>0)){
L1:			while(time >= 0){
L2:				while(true){
					if(p1Script.size() > 0){
						if(p1Index > p1Script.size()-1)
							p1Index = 0;
						p1Info = (ObjectNode) p1Script.elementAt(p1Index);
						System.out.println(p1Info.NAME);
						if(((ObjectNode) p1Info).NAME.equals(IfopN.NAME)){
							if(p1Position+3 == p2Position)
								p1Index++;
							else
								p1Index += 2;
						}else{
							break L2;
						}
					}
				}
L3:				while(true){
					if(p2Script.size() > 0){
						if(p2Index > p2Script.size()-1)
							p2Index = 0;
						p2Info = (ObjectNode) p2Script.elementAt(p2Index);
						System.out.println(p2Info.NAME);
						if(((ObjectNode) p2Info).NAME.equals(IfopN.NAME)){
							if(p1Position+3 == p2Position)
								p2Index++;
							else
								p2Index += 2;
						}else{
							break L3;
						}
					}
				}		
				if(p1Index > p1Script.size()-1)
					p1Index = 0;
				if(p2Index > p2Script.size()-1)
					p2Index = 0;
				p1Info = (ObjectNode) p1Script.elementAt(p1Index);
				p2Info = (ObjectNode) p2Script.elementAt(p2Index);
				System.out.println("P1 :" + p1Info.NAME);
				System.out.println("P2 :" + p2Info.NAME);
				if(((ObjectNode) p1Info).NAME.equals(MoveN.NAME)){	
					if(((MoveN) p1Info).direction == 0){
						if(p1Position < p2Position-3)
							p1Position++;
					}else{
						if(p1Position > 4)
							p1Position--;
					}
					p1left = (p1left==true?false:true);
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 5;
						}
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 10;
						}				
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 15;
						}				
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}
				}else if(((ObjectNode) p1Info).NAME.equals(PunchN.NAME)){
					if(p1Position+3 == p2Position){
						p2Hp -= 5;
					}
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}	
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 5;
						}
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 10;
							p2Hp -= 10;
						}				
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 15;
						}				
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}					
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						if(p2Position-3 == p2Position){
							p2Hp += 3;
						}
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}		
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}		
					}
				}else if(((ObjectNode) p1Info).NAME.equals(KickN.NAME)){
					if(p1Position+3 == p2Position){
						p2Hp -= 10;
					}
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 5;
							p1Hp -= 10;
						}
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 10;
							p1Hp -= 10;
							p2Hp -= 10;
						}				
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 15;
							p1Hp -= 10;
						}				
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						if(p2Position-3 == p1Position){
							p2Hp += 8;
						}
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}
				}else if(p1useSpecial && ((ObjectNode) p1Info).NAME.equals(SpecialN.NAME)){
					if(p1Position+3 == p2Position){
						p2Hp -= 15;
					}
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 5;
						}
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p2Hp -= 10;
							p1Hp -= 10;
						}				
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 15;
						}				
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0 && p2Hp <= 0){
							result.add(new ResultV("DRAW",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}else if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						if(p2Position-3 == p1Position){
							p2Hp += 13;
						}
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
						if(p2Hp <= 0){
							result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
									  			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}
					p1useSpecial = false;
				}else if(!p1useSpecial && ((ObjectNode) p1Info).NAME.equals(SpecialN.NAME)){
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 5;
						}
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 10;
						}				
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 15;
						}				
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}			
				}else if(((ObjectNode) p1Info).NAME.equals(GuardN.NAME)){
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 2;
						}
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 2;
						}				
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 2;
						}				
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
								   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}
				}else if(((ObjectNode) p1Info).NAME.equals(StandN.NAME)){
					if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
						if(((MoveN) p2Info).direction == 0){
							if(p2Position > p1Position+3)
								p2Position--;
						}else{
							if(p2Position < 20)
								p2Position++;
						}
						p2left = (p2left==true?false:true);
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
								  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 5;
						}
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
								  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 10;
						}				
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
					}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						if(p2Position-3 == p1Position){
							p1Hp -= 15;
						}				
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
						if(p1Hp <= 0){	
							result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
						  			   			   " ",p2Position,p2y,0,true,0,time));	
							break L1;
						}
						p2useSpecial = false;
					}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
								   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
					}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
						result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
											   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					}
				}
				p1Index++;
				p2Index++;
				time--;
			}
		}else if((p1Script.size() <= 0) && (p2Script.size() > 0)){
L2:			while(time >= 0){
				if(p2Index > p2Script.size()-1)
					p2Index = 0;
				p2Info = (ObjectNode) p2Script.elementAt(p2Index);
				System.out.println("STAND");
				System.out.println(p2Info.NAME);	
				if(((ObjectNode) p2Info).NAME.equals(MoveN.NAME)){	
					if(((MoveN) p2Info).direction == 0){
						if(p2Position > p1Position+3)
							p2Position--;
					}else{
						if(p2Position < 20)
							p2Position++;
					}
					p2left = (p2left==true?false:true);
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
							  			   "MOVE",p2Position,p2y,((MoveN) p2Info).direction,p2left,p2Hp,time));
				}else if(((ObjectNode) p2Info).NAME.equals(PunchN.NAME)){
					if(p2Position-3 == p1Position){
						p1Hp -= 5;
					}
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
							  			   "PUNCH",p2Position,p2y,0,p2left,p2Hp,time));
					if(p1Hp <= 0){
						result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
								  			   " ",p2Position,p2y,0,true,0,time));	
						break L2;
					}
				}else if(((ObjectNode) p2Info).NAME.equals(KickN.NAME)){
					if(p2Position-3 == p1Position){
						p1Hp -= 10;
					}				
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
										   "KICK",p2Position,p2y,0,p2left,p2Hp,time));
					if(p1Hp <= 0){
						result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
								  			   " ",p2Position,p2y,0,true,0,time));	
						break L2;
					}
				}else if(p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
					if(p2Position-3 == p1Position){
						p1Hp -= 15;
					}				
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
										   "SPECIAL",p2Position,p2y,0,p2left,p2Hp,time));
					if(p1Hp <= 0){
						result.add(new ResultV("P2WIN",p1Position,p1y,0,true,0,
								  			   " ",p2Position,p2y,0,true,0,time));	
						break L2;
					}
					p2useSpecial = false;
				}else if(!p2useSpecial && ((ObjectNode) p2Info).NAME.equals(SpecialN.NAME)){
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
							   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
				}else if(((ObjectNode) p2Info).NAME.equals(GuardN.NAME)){
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
							   			   "GUARD",p2Position,p2y,0,p2left,p2Hp,time));
				}else if(((ObjectNode) p2Info).NAME.equals(StandN.NAME)){
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
										   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
				}		
				p2Index++;
				time--;		
			}
		}else if((p1Script.size() > 0) && (p2Script.size() <= 0)){
L3:			while(time >= 0){
				if(p1Index > p1Script.size()-1)
					p1Index = 0;
				p1Info = (ObjectNode) p1Script.elementAt(p1Index);
				System.out.println(p1Info.NAME);
				System.out.println("STAND");
				if(((ObjectNode) p1Info).NAME.equals(MoveN.NAME)){	
					if(((MoveN) p1Info).direction == 0){
						if(p1Position < p2Position-3)
							p1Position++;
					}else{
						if(p1Position > 4)
							p1Position--;
					}
					p1left = (p1left==true?false:true);
					result.add(new ResultV("MOVE",p1Position,p1y,((MoveN) p1Info).direction,p1left,p1Hp,
							  			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
				}else if(((ObjectNode) p1Info).NAME.equals(PunchN.NAME)){
					if(p1Position+3 == p2Position){
						p2Hp -= 5;
					}
					result.add(new ResultV("PUNCH",p1Position,p1y,0,p1left,p1Hp,
							  			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					if(p2Hp <= 0){
						result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
											   " ",p2Position,p2y,0,true,0,time));	
						break L3;
					}		
				}else if(((ObjectNode) p1Info).NAME.equals(KickN.NAME)){
					if(p1Position+3 == p2Position){
						p2Hp -= 10;
					}
					result.add(new ResultV("KICK",p1Position,p1y,0,p1left,p1Hp,
							  			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					if(p2Hp <= 0){
						result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
								  			   " ",p2Position,p2y,0,true,0,time));	
						break L3;
					}
				}else if(p1useSpecial && ((ObjectNode) p1Info).NAME.equals(SpecialN.NAME)){
					if(p1Position+3 == p2Position){
						p2Hp -= 15;
					}
					result.add(new ResultV("SPECIAL",p1Position,p1y,0,p1left,p1Hp,
							  			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
					if(p2Hp <= 0){
						result.add(new ResultV("P1WIN",p1Position,p1y,0,true,0,
								  			   " ",p2Position,p2y,0,true,0,time));	
						break L3;
					}
					p1useSpecial = false;
				}else if(!p2useSpecial && ((ObjectNode) p1Info).NAME.equals(SpecialN.NAME)){
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
		  		   			   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
				}else if(((ObjectNode) p1Info).NAME.equals(GuardN.NAME)){
					result.add(new ResultV("GUARD",p1Position,p1y,0,p1left,p1Hp,
								  		   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
				}else if(((ObjectNode) p1Info).NAME.equals(StandN.NAME)){
					result.add(new ResultV("STAND",p1Position,p1y,0,p1left,p1Hp,
					  		   			   "STAND",p2Position,p2y,0,p2left,p2Hp,time));
				}
				p1Index++;
				time--;
			}			
		}
		if(time < 0){
			if(p1Hp == p2Hp){
				result.add(new ResultV("DRAW",p1Position,p1y,p1Hp,true,0,
		   			   				   " ",p2Position,p2y,0,true,p2Hp,time));
			}else if(p1Hp > p2Hp){
				result.add(new ResultV("P1WIN",p1Position,p1y,p1Hp,true,0,
									   " ",p2Position,p2y,0,true,p2Hp,time));
			}else if(p1Hp < p2Hp){
				result.add(new ResultV("P2WIN",p1Position,p1y,p1Hp,true,0,
									   " ",p2Position,p2y,0,true,p2Hp,time));
			}
		}
		result.add(new String("END"));
		System.out.println("----End----");
	}
	private void getScript(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			c = DriverManager.getConnection("jdbc:mysql://localhost/mysql","","");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		
		try {
			p = c.prepareStatement("SELECT script FROM information WHERE name = ?");
			p.setObject(1,player1);
			ResultSet rs = p.executeQuery();
			rs.next();	//	 go to the first record
			p1Script = (Vector) rs.getObject(1);
		} catch (SQLException e) {
			e.printStackTrace();	
		}
		
		try {
			p = c.prepareStatement("SELECT script FROM information WHERE name = ?");
			p.setObject(1,player2);
			ResultSet rs = p.executeQuery();
			rs.next();	//	 go to the first record
			p2Script = (Vector) rs.getObject(1);
		} catch (SQLException e) {
			e.printStackTrace();	
		}
		
		if(p != null){
			try {
				p.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(c != null){
			try {
				c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
}
