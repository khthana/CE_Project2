/*
 * Created on 6 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ProcessTestThread extends Thread {
	private Connection c  = null;
	private PreparedStatement p = null;	
	private String player1;
	private Vector p1Script;
	private int p1x = -50;
	private int p1y = 50;
	private int time;
	private Vector result;
	public ProcessTestThread(String p1,Vector result){
		time = 60;
		player1 = p1;
		this.result = result;
	}
	public void run(){
		ObjectNode info;
		getScript();
		int index = 0;
		boolean p1left = false;
		boolean useSpecial = true;
		System.out.println(p1Script.size());
		while(time >= 0){
//			System.out.println("index:"+index+", size:"+p1Script.size());
L1:			while(true){
				if(p1Script.size() > 0){
					if(index > p1Script.size()-1)
						index = 0;
					info = (ObjectNode) p1Script.elementAt(index);
					System.out.println(info.NAME);
					if(((ObjectNode) info).NAME.equals(IfopN.NAME)){
						index++;			
					}else{
						break L1;
					}
				}
			}
			if(p1Script.size() <= 0){
				result.add(new ResultV("STAND",p1x,p1y,0,p1left,100,
						  "NONE",0,0,0,false,0,time));				
			}else{
				if(index > p1Script.size()-1)
					index = 0;
				info = (ObjectNode) p1Script.elementAt(index);
				System.out.println(info.NAME);
				if(((ObjectNode) info).NAME.equals(MoveN.NAME)){	
					if(((MoveN) info).direction == 0){
						if(p1x <= 250)
							p1x += 25;
					}else{
						if(p1x >= -50)
							p1x -= 25;
					}
					result.add(new ResultV("MOVE",p1x,p1y,((MoveN) info).direction,p1left,100,
							  "NONE",0,0,0,false,0,time));
					p1left = (p1left==true?false:true);
				}else if(((ObjectNode) info).NAME.equals(PunchN.NAME)){
					result.add(new ResultV("PUNCH",p1x,p1y,0,p1left,100,
							  "NONE",0,0,0,false,0,time));
				}else if(((ObjectNode) info).NAME.equals(KickN.NAME)){
					result.add(new ResultV("KICK",p1x,p1y,0,p1left,100,
							  "NONE",0,0,0,false,0,time));
				}else if(((ObjectNode) info).NAME.equals(GuardN.NAME)){
					result.add(new ResultV("GUARD",p1x,p1y,0,p1left,100,
							  "NONE",0,0,0,false,0,time));
				}else if(((ObjectNode) info).NAME.equals(StandN.NAME)){
					result.add(new ResultV("STAND",p1x,p1y,0,p1left,100,
							  "NONE",0,0,0,false,0,time));
				}else if(useSpecial && ((ObjectNode) info).NAME.equals(SpecialN.NAME)){
					result.add(new ResultV("SPECIAL",p1x,p1y,0,p1left,100,
							  "NONE",0,0,0,false,0,time));
					useSpecial = false;
				}else if(!useSpecial && ((ObjectNode) info).NAME.equals(SpecialN.NAME)){
					result.add(new ResultV("STAND",p1x,p1y,0,p1left,100,
							  "NONE",0,0,0,false,0,time));
				}
			}
			index++;
			time--;
		}
		result.add(new String("END"));
	}
	private void getScript(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			c = DriverManager.getConnection("jdbc:mysql://localhost/mysql","","");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		
		try {
			p = c.prepareStatement("SELECT script FROM information WHERE name = ?");
			p.setObject(1,player1);
			ResultSet rs = p.executeQuery();
			rs.next();	//	 go to the first record
			p1Script = (Vector) rs.getObject(1);
		} catch (SQLException e) {
			e.printStackTrace();	
		}

		if(p != null){
			try {
				p.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if(c != null){
			try {
				c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
}
