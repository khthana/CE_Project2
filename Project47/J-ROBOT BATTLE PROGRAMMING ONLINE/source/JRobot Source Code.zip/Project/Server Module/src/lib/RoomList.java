/*
 * Created on 9 ��.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.util.Vector;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class RoomList extends Object{
	private String name = null;
	private String p1 = null;
	private String p2 = null;
	private boolean stat = false;	// wait or empty
	private boolean p1ready = false;
	private boolean p2ready = false;
	private Vector insideChatRoom = null;
	private int p1char = 0;
	private int p2char = 5;
	public void setCreate(String name,String p1){
		insideChatRoom = new Vector();
		insideChatRoom.add("/> User " + p1 + " come in.");
		this.name = name;
		this.p1 = p1;
		this.stat = false;
		this.p1ready = false;
		this.p1char = 0;
	}
	public void setJoin(String p2){
		this.p2 = p2;
		insideChatRoom.add("/> User " + p2 + " come in.");
		this.stat = true;
		this.p2ready = false;
		this.p2char = 1;
	}
	public void setP2Exit(){
		insideChatRoom.add("/> User " + p2 + " go out.");
		this.p2 = null;
		this.stat = false;
		this.p2ready = false;
		this.p2char = 5;
	}
	public void setP1Exit(){
		insideChatRoom.add("/> User " + p1 + " go out.");
		this.p1 = this.p2;
		this.p2 = null;
		this.stat = false;
		this.p1ready = false;
		this.p2ready = false;
		this.p1char = p2char;
		this.p2char = 5;
	}
	public boolean getStatus(){
		return stat;
	}
	public String toString(){
		if(stat)
			return name + " --> ( " + p1 + " VS. " + p2 + " )";
		else
			return name + " --> ( " + p1 + " wait )";
	}
	public void setP1Ready(boolean ready){
		this.p1ready = ready;
	}
	public void setP2Ready(boolean ready){
		this.p2ready = ready;
		if(ready)
			insideChatRoom.add("/> User " + p2 + " ready.");
		else
			insideChatRoom.add("/> User " + p2 + " cancel.");
	}
	public boolean getP2Ready(){
		return p2ready;
	}
	public Vector getInsideChatRoom(){
		return insideChatRoom;
	}
	public boolean getStartSimulate(){
		return p1ready;
	}
	public boolean checkMaster(String name){
		if(name.equals(p1))
			return true;
		else
			return false;
	}
	public String getOpponentName(String name){
		if(name.equals(p1))
			return p2;
		else
			return p1;
	}
	public void setP1Char(int p1char){
		this.p1char = p1char;
	}
	public void setP2Char(int p2char){
		this.p2char = p2char;
	}
	public int getP1Char(){
		return p1char;
	}
	public int getP2Char(){
		return p2char;
	}
}
