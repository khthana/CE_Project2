/*
 * Created on 28 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.util.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserState extends Vector {
	private Vector state;
	public static String isIdle   = "0" ;
	public static String isModify = "1";
	public static String isVS	  = "2";
	public UserState(){
		super();
		state = new Vector();
	}
	public void add(String name){
		super.add(name);
		state.add(new String(isIdle));
	}
	public void setState(String name,String state){
		this.state.setElementAt(state,this.indexOf(name));
	}
	public String getState(String name){
		return (String)this.state.elementAt(this.indexOf(name));
	}
}
