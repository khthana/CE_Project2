/*
 * Created on 29 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.io.*;
import java.util.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class InfoScriptType implements Serializable {
	public String header = null;
	public String name = null;
	public String opponentName = null;
	public Vector script = null;
	public String roomName = null;
}
