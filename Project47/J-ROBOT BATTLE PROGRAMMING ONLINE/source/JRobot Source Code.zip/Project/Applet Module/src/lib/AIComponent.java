/*
 * Created on 18 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.util.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AIComponent extends Hashtable{
	public AIComponent(){
		String movement[] = {MoveN.NAME,StandN.NAME};
		String action[]   = {GuardN.NAME,PunchN.NAME,KickN.NAME,SpecialN.NAME};
		String control[] = {IfopN.NAME};
//		String agent[] = {"Detect Opponent"};
//		this.put("Action",action);
		this.put("Control Statements",control);
		this.put("Movement",movement);
		this.put("Action",action);
//		this.put("Detect",agent);
	}
}