/*
 * Created on 25 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.io.*;
import java.net.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TunnelServlet {
private URL u = null;
private	URLConnection c = null;
private PrintWriter pw = null;
private InputStreamReader ir = null;
private String input = null;
private Object obj = null;
private BufferedReader br = null;
private ObjectInputStream ois = null;
private ObjectOutputStream oos = null;
public static String TEXT = "text/plain";
public static String OBJECT = "application/octet-stream";
	public boolean connect(String url,String type){
	try {
			u = new URL("http://192.168.0.240:8080/JRobot/" + url);
		//	u = new URL("http://localhost:8080/JRobot/" + url);
			c = u.openConnection();
			c.setRequestProperty("CONTENT_TYPE",type);
			c.setDoInput(true);
			c.setDoOutput(true);
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
//			JOptionPane.showMessageDialog(null,e.toString());
			return false;
		}
	}
	public boolean close(){
		try {
			if(ir != null)
				ir.close();
		return true;
		} catch (IOException e) {
			e.printStackTrace();
//			JOptionPane.showMessageDialog(null,2 + e.toString());
			return false;
		}
	}
	public boolean send(String output){
		try {
			pw = new PrintWriter(c.getOutputStream());
			pw.println(output);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally{
			if(pw != null){
				pw.close();
			}
		}
	}
	public boolean sendObj(String output){
		try {
			oos = new ObjectOutputStream(c.getOutputStream());
			oos.writeObject(output);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally{
			if(oos != null){
				try {
					oos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public boolean sendObj(InfoScriptType output){
		try {
			oos = new ObjectOutputStream(c.getOutputStream());
			oos.writeObject(output);
			return true;
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		} finally{
			if(oos != null){
				try {
					oos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}		
	public String receive(){
		try {
			ir = new InputStreamReader(c.getInputStream());			
			br = new BufferedReader(ir);
			input = br.readLine().trim();
		} catch (IOException e) {
			input = null;
			e.printStackTrace();
//			JOptionPane.showMessageDialog(null,3.1 + e.toString());
		} finally{
			if(br != null){
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
//					JOptionPane.showMessageDialog(null,3.2 + e.toString());
				}
			}
			if(ir != null){
				try {
					ir.close();
				} catch (IOException e) {
					e.printStackTrace();
//					JOptionPane.showMessageDialog(null,3.3 + e.toString());
				}
			}
		}
		return input;
	}

	public Object receiveObj(){	
		try {
			ois = new ObjectInputStream(c.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
//			JOptionPane.showMessageDialog(null,4.1 + e.toString());
		}			
		try {
			obj = ois.readObject();
		} catch (IOException e) {
			e.printStackTrace();
//			JOptionPane.showMessageDialog(null,4.2 + e.toString());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
//			JOptionPane.showMessageDialog(null,4.3 + e.toString());
		} finally{
			if(ois != null){
				try {
					ois.close();
				} catch (IOException e) {
					e.printStackTrace();
//					JOptionPane.showMessageDialog(null,4.4 + e.toString());
				}
			}
		}
		return obj;
	}
}
