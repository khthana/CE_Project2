/*
 * Created on 7 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ResultV extends ObjectNode {
	public int p1x,p1y;
	public String p1action;
	public int p1direction;
	public boolean p1left;
	public int p1hp;
	public int p2x,p2y;
	public String p2action;
	public int p2direction;
	public boolean p2left;
	public int p2hp;
	public int time;
	public ResultV(String p1action,int p1x,int p1y,int p1direction,boolean p1left,int p1hp,
				   String p2action,int p2x,int p2y,int p2direction,boolean p2left,int p2hp,
				   int time){
		this.p1action = p1action;
		this.p1x = p1x;
		this.p1y = p1y;
		this.p1direction = p1direction;
		this.p1left = p1left;
		this.p1hp = p1hp;
		this.p2action = p2action;
		this.p2x = p2x;
		this.p2y = p2y;
		this.p2direction = p2direction;
		this.p2left = p2left;
		this.p2hp = p2hp;
		this.time = time;
	}
}
