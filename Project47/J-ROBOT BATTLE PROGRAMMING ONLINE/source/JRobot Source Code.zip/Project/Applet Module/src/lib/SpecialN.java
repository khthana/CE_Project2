/*
 * Created on 20 ��.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SpecialN extends ObjectNode {
	public static String NAME = "Special";
	public SpecialN(){
		super.NAME = SpecialN.NAME;
	}
	public String toString(){
		return "Special();";
	}
}
