/*
 * Created on 9 ��.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.util.Vector;

import javax.swing.JOptionPane;

import ui.WaitRoomUI;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UpdateInsideRoomThread extends Thread {
	private String roomName = null;
	private Vector insideRoomUpdate = null;
	private Vector insideChatRoom = null;
	private TunnelServlet tunnel = null;
	private WaitRoomUI waitroomUI = null; 	
	private Integer opponent = null;
	private Integer startSimulate = null;
	private Integer testMaster = null;
	private Integer statusWaitEmpty = null;
	private String player = null;
	private String opponentName = null;
	private Integer p1char = null;
	private Integer p2char = null;
	private final int timeout = 5;
	private int count;
	public UpdateInsideRoomThread(WaitRoomUI ui,String roomName,String player){
		tunnel = new TunnelServlet();
		this.roomName = roomName;
		this.player = player;
		waitroomUI = ui;
	}
	public void run(){
		while(true){
			try {
				sleep(3600);	
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("UpdateInsideThread -> L");
			}			

			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				} else{
					insideRoomUpdate = null;
					tunnel.sendObj("getInsideRoomUpdate " + roomName + ":" + this.player + ";");
					try{
						insideRoomUpdate = (Vector) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L1");
						tunnel.close();
						continue L1;
					}finally{
						tunnel.close();
					}
					if(insideRoomUpdate != null){
						break L1;
					}
				}	
			}
			insideChatRoom = (Vector)insideRoomUpdate.elementAt(0);
			opponent = (Integer)insideRoomUpdate.elementAt(1); 
			startSimulate = (Integer)insideRoomUpdate.elementAt(2); 
			testMaster = (Integer)insideRoomUpdate.elementAt(3); 
			opponentName = (String) insideRoomUpdate.elementAt(4); 
			statusWaitEmpty = (Integer) insideRoomUpdate.elementAt(5); 
			p1char = (Integer) insideRoomUpdate.elementAt(6);  
			p2char = (Integer) insideRoomUpdate.elementAt(7);  
/*			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				} else{
					insideChatRoom = null;
					tunnel.sendObj("getInsideChatRoom " + roomName + ":");
					try{
						insideChatRoom = (Vector) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L1");
						tunnel.close();
						continue L1;
					}finally{
						tunnel.close();
					}
					if(insideChatRoom != null){
						break L1;
					}
				}	
			}
			count = 0;
L2:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L2;
				} else{
					opponent = null;
					tunnel.sendObj("getOpponentReady " + roomName + ":");
					try{
						opponent = (Integer) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L2");
						tunnel.close();
						continue L2;
					}finally{
						tunnel.close();
					}
					if(opponent != null){
						break L2;
					}
				}
			}
			count = 0;
L3:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L3;
				} else{
					startSimulate = null;
					tunnel.sendObj("getStartSimulate " + roomName + ":");
					try{
						startSimulate = (Integer) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L3");
						tunnel.close();
						continue L3;
					}finally{
						tunnel.close();
					}
					if(startSimulate != null){
						break L3;
					}
				}
			}
			count = 0;
L4:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L4;
				} else{
					testMaster = null;
					tunnel.sendObj("checkMaster " + roomName + ":" + this.player + ";");
					try{
						testMaster = (Integer) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L4");
						tunnel.close();
						continue L4;
					}finally{
						tunnel.close();
					}
					if(testMaster != null){
						break L4;
					}
				}
			}
			count = 0;
L5:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L5;
				} else{
					opponentName = null;
					tunnel.sendObj("getOpponentName " + roomName + ":" + this.player + ";");
					try{
					opponentName = (String) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L5");
						tunnel.close();
						continue L5;
					}finally{
						tunnel.close();
					}
					if(opponentName != null){
						break L5;
					}
				}
			}
			count = 0;
L6:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L6;
				} else{
					statusWaitEmpty = null;
					tunnel.sendObj("getStatus " + roomName + ":");
					try{
						statusWaitEmpty = (Integer) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L6");
						tunnel.close();
						continue L6;
					}finally{
						tunnel.close();
					}
					if(statusWaitEmpty != null){
						break L6;
					}
				}
			}
			count = 0;
L7:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L7;
				} else{
					p1char = null;
					tunnel.sendObj("getP1Char " + roomName + ":");
					try{
						p1char = (Integer) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L7");
						tunnel.close();
						continue L7;
					}finally{
						tunnel.close();
					}
					if(p1char != null){
						break L7;
					}
				}
			}
			count = 0;
L8:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L8;
				} else{
					p2char = null;
					tunnel.sendObj("getP2Char " + roomName + ":");
					try{
						p2char = (Integer) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInsideThread -> L8");
						tunnel.close();
						continue L8;
					}finally{
						tunnel.close();
					}
					if(p2char != null){
						break L8;
					}
				}
			}
	*/		boolean opt,start,master,status;
			opt = start = master = status = false;
			if(opponent.intValue() == 10)
				opt = true;		
			else if(opponent.intValue() == 11)
				opt = false;
			if(startSimulate.intValue() == 20)
				start = true;		
			else if(startSimulate.intValue() == 21)
				start = false;
			if(testMaster.intValue() == 30)
				master = true;		
			else if(testMaster.intValue() == 31)
				master = false;
			if(statusWaitEmpty.intValue() == 40)
				status = true;		
			else if(statusWaitEmpty.intValue() == 41)
				status = false;
			waitroomUI.updateInsideRoom(insideChatRoom,opt,start,master,opponentName,status,p1char.intValue(),p2char.intValue());		
		}
	}
}
