/*
 * Created on 16 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;


/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StandN extends ObjectNode{
	public static String NAME = "Stand";
	public StandN(){
		super.NAME = StandN.NAME;
	}
	public String toString(){
		return "Stand();";
	}
}
