/*
 * Created on 19 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class IfopN extends ObjectNode{
	public static String NAME = "IF Opponent";
	public IfopN(){
		super.NAME = IfopN.NAME;
	}
	public String toString(){
		return "if( Opponent < 2)";
	}
}
