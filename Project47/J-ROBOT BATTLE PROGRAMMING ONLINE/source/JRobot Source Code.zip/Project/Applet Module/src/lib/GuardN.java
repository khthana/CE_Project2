/*
 * Created on 4 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GuardN extends ObjectNode {
	public static String NAME = "Guard";
	public GuardN(){
		super.NAME = GuardN.NAME;
	}
	public String toString(){
		return "Guard();";
	}
}
