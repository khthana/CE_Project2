/*
 * Created on 21 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.util.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CommunicateEvent extends EventObject {
	public static char isConfirmLogin 	 = '0';
	public static char isConfirmRegister = '1';
	public static char isConfirmName	= '2';
	public static char isCancel			= '3';
	public static char isSignout		= '4';
	public static char isConfirmModify	= '5';
	public static char isModify			= '6';
	public static char isTesting 		= '7';
	public static char isLoadComplete   = '8';
	public static char isStartFighting  = '9';
	public static char isExitRoom		= 'A';
	public static char isJoinRoom		= 'B';
	public static char isCreateRoom		= 'C';
	public static char isStartViewResult = 'D';
	public static char isBackRoom 		= 'E';
	public int state; 
	public CommunicateEvent(Object obj,int state) {
		super(obj);
		this.state = state;
	}
	public int getState(){
		return state;
	}
}
