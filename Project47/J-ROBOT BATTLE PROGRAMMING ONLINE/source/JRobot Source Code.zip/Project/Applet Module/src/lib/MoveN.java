/*
 * Created on 19 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class MoveN extends ObjectNode{
	public int direction;
	public int distance;
	public final int FORWARD = 0;
	public final int BACKWARD = 1;
	public static String NAME = "Move";
	public MoveN(){
		super.NAME = MoveN.NAME;
		distance = 1;
		direction = this.FORWARD;
	}
	public String toString(){
		StringBuffer str = new StringBuffer("move(");
		str.append(direction==0?" forward , ":" backward , ");
		str.append(Integer.toString(distance)+" );");
		return(str.toString());
	}
	public String[][] getInfo(){
		return new String[][]{{"direction",(direction==0?"forward":"backward")},
				{"distance",Integer.toString(distance)}};
	}
}
