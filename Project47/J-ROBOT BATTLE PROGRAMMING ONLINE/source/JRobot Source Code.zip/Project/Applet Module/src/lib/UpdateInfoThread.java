/*
 * Created on 27 �.�. 2547
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package lib;

import java.util.*;
import javax.swing.*;
import ui.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UpdateInfoThread extends Thread{
	private String name = null;
	private TunnelServlet tunnel = null;
	private ReceptionUI receptionUI = null; 
	private UserState onlineUser = null;
	private Vector chatRoom = null;
	private Vector room = null;
	private Vector statroom = null;
	private Vector updateInfo = null;
	private final int timeout = 5;
	private int count;
	public UpdateInfoThread(ReceptionUI ui,String name){
		tunnel = new TunnelServlet();
		this.name = name;
		receptionUI = ui;
		count = 0;
L0:		while(count < timeout){
			count++;
			if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
				JOptionPane.showMessageDialog(null,"Can't connect to server.");
				break L0;
			} else{
				String s;
				s = null;
				tunnel.sendObj("add " + name + ":");
				try{
					s = (String) tunnel.receiveObj();
				}catch (Exception e){
					e.printStackTrace();
					System.out.println("UpdateInfoThread -> L0");
					tunnel.close();
					continue L0;
				}finally{
					tunnel.close();
				}
				if(s != null){
					break L0;
				}
			}
		}		
	}
	public void run(){
		while(true){
			try {
				sleep(2000);
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("UpdateInfoThread -> L0");
			}
			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				} else{
					updateInfo = null;
					tunnel.sendObj("getUpdateInfo ");
					try{
						updateInfo = (Vector) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInfoThread -> L1");
						tunnel.close();
						continue L1;
					}finally{
						tunnel.close();
					}
					if(updateInfo != null){
						break L1;
					}
				}
			}			
			onlineUser = (UserState)updateInfo.elementAt(0);
			chatRoom = (Vector)updateInfo.elementAt(1);
			room = (Vector)updateInfo.elementAt(2);
			statroom = (Vector)updateInfo.elementAt(3);
/*		
			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				} else{
					onlineUser = null;
					tunnel.sendObj("getAllUser " + name + ":");
					try{
						onlineUser = (UserState) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInfoThread -> L1");
						tunnel.close();
						continue L1;
					}finally{
						tunnel.close();
					}
					if(onlineUser != null){
						break L1;
					}
				}
			}
			count = 0;
L2:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L2;
				} else{
					chatRoom = null;
					tunnel.sendObj("getChatRoom " + name + ":");
					try{
						chatRoom = (Vector) tunnel.receiveObj();	
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("UpdateInfoThread -> L2");
						tunnel.close();
						continue L2;
					}finally{
						tunnel.close();
					}
					if(chatRoom != null){
						break L2;
					}
				}
			}
			count = 0;
L3:			while(count < timeout){
				count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L3;
				} else{
					if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
					} else{
						room = null;
						tunnel.sendObj("getAllRoom " + name + ":");
						try{
							room = (Vector) tunnel.receiveObj();	
						}catch (Exception e){
							e.printStackTrace();
							System.out.println("UpdateInfoThread -> L3");
							tunnel.close();
							continue L3;
						}finally{
							tunnel.close();
						}
						if(room != null){
							break L3;
						}
					}
				}
			}
			count = 0;
L4:			while(count < timeout){
					count++;
				if(!tunnel.connect("http://192.168.0.240:8080/JRobot/ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L4;
				} else{
					statroom = null;
					tunnel.sendObj("getAllRoomStat " + name + ":");
					try{
						statroom = (Vector) tunnel.receiveObj();	
					}catch (ClassCastException e){
						e.printStackTrace();
						System.out.println("UpdateInfoThread -> L4");
						tunnel.close();
						continue L4;
					}finally{
						tunnel.close();
					}
					if(statroom != null){
						break L4;
					}
				}
			}
*/			
			receptionUI.updateInfo(onlineUser,chatRoom,room,statroom);
		}
	}
}
