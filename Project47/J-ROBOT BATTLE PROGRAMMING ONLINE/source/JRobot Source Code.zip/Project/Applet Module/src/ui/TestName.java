package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import lib.*;
/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class TestName extends JDialog implements ActionListener{
	private JPanel testPanel;
	private JButton cancel;
	private JButton ok;
	private JButton test;
	private JTextField name;
	private JLabel nameLabel;
	private TunnelServlet tunnel;
	private CommunicateListener commu = null;
	public String Name = null;
	private final int timeout = 5;
	private int count;

	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public TestName() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setSize(375, 190);
			{
				testPanel = new JPanel();
				this.getContentPane().add(testPanel, BorderLayout.CENTER);
				testPanel.setLayout(null);
				testPanel.setPreferredSize(new java.awt.Dimension(368, 153));
				{
					nameLabel = new JLabel();
					testPanel.add(nameLabel);
					nameLabel.setText("Name");
					nameLabel.setBounds(40, 30, 60, 30);
				}
				{
					name = new JTextField();
					testPanel.add(name);
					name.setBounds(80, 30, 120, 25);
				}
				{
					test = new JButton();
					testPanel.add(test);
					test.setText("Test");
					test.setBounds(230, 23, 90, 40);
					test.addActionListener(this);
				}
				{
					ok = new JButton();
					testPanel.add(ok);
					ok.setText("OK");
					ok.setBounds(80, 70, 90, 40);
					ok.addActionListener(this);
					ok.setEnabled(false);
				}
				{
					cancel = new JButton();
					testPanel.add(cancel);
					cancel.setText("Cancel");
					cancel.setBounds(190, 70, 90, 40);
					cancel.addActionListener(this);
				}
			}
			tunnel = new TunnelServlet();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == cancel){
			this.Name = null;
			this.setVisible(false);
		}else if(event.getSource() == test){
			String s = null;
			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("ConnectionServlet",TunnelServlet.TEXT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				}else{
					tunnel.send("test " + name.getText() + ":");
					try{
						s = tunnel.receive();
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("TestName -> L1");
						tunnel.close();
						continue L1;
					}finally{
						tunnel.close();
					}
					if(s!=null){
						if(s.equals("accept")){
							this.Name = name.getText();
							ok.setEnabled(true);
						}else{
							name.setText(null);
							this.Name = null;
							JOptionPane.showMessageDialog(null,"Name already exists.");
						}
						break L1;
					}
				}
			}
		}else if(event.getSource() == ok){
			ok.setEnabled(false);
			name.setText(null);
			commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isConfirmName));
		}
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
}
