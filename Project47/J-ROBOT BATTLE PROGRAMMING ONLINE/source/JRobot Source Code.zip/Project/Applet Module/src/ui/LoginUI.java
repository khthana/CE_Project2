package ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import lib.*;
/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class LoginUI extends JPanel implements ActionListener{

	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private JLabel nameLable;
	private JLabel PasswordLable;
	private JPasswordField password;
	private JButton ok;
	private JTextField name;
	private CommunicateListener commu = null;
	private TunnelServlet tunnel;
	public  String NAME;
	private final int timeout = 5;
	private int count;
	public LoginUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setPreferredSize(new java.awt.Dimension(370, 140));
			this.setLayout(null);
			this.setBorder(BorderFactory.createTitledBorder(null, "Login", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,255)));
			{
				{
					nameLable = new JLabel();
					this.add(nameLable);
					nameLable.setText("Name");
					nameLable.setBounds(32, 40, 60, 30);
				}
				{
					PasswordLable = new JLabel();
					this.add(PasswordLable);
					PasswordLable.setText("Password");
					PasswordLable.setBounds(32, 80, 60, 30);
				}
				{
					name = new JTextField();
					this.add(name);
					name.setBounds(120, 40, 130, 25);
				}
				{
					password = new JPasswordField();
					this.add(password);
					password.setBounds(120, 80, 130, 25);
				}
				{
					ok = new JButton();
					this.add(ok);
					ok.setText("Go !!!");
					ok.setBounds(270, 35, 60, 75);
					ok.addActionListener(this);
				}
				
				tunnel = new TunnelServlet();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void actionPerformed(ActionEvent event){
		if(event.getSource() == ok){
			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("ConnectionServlet",TunnelServlet.TEXT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				}else{
					String s = null;
					tunnel.send("login " + name.getText() + ":" + password.getText() +
					";");
					try{
						s = (String)tunnel.receive();
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("LoginUI -> UI");
						tunnel.close();
						continue L1;
					}
					if(s!=null){
						if(s.equals("accept")){	
							this.NAME = name.getText();
							commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isConfirmLogin));
						} else{
							JOptionPane.showMessageDialog(null,"Name or Password are incorrect.");	
						}
						name.setText(null);
						password.setText(null);		
						break L1;
					}
				}
			}
		}
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
}
