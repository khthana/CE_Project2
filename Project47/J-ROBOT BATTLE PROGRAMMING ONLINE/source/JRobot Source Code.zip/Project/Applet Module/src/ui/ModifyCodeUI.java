package ui;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.tree.*;
import javax.swing.table.*;
import lib.*;

import javax.swing.JButton;
/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class ModifyCodeUI extends JPanel implements ActionListener,ItemListener,ListSelectionListener{
	private JButton addButton;
	private JButton removeButton;
	private JTree componentTree;
	private JList codeArea;
	private Vector tmp;
	private AIComponent component;
	private int index;
	private JButton testButton;
	private JButton backButton;
	private JButton saveButton;
	private boolean order = true;
	private JTable properties;
	private TableModel propertiesModel;
    private ArrayList editors = null;
    private JComboBox comboBoxProp_1;
    private JComboBox comboBoxProp_2;
    private JComboBox comboBoxProp_3;
	private CommunicateListener commu = null;
	private TunnelServlet tunnel;
	private String userName = null;
	private InfoScriptType it;
	private final int timeout = 5;
	private int count;
	private int choose = 0;
	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}


	/**
	* Auto-generated main method to display this 
	* JPanel inside a new JFrame.
	*/
	
	public ModifyCodeUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setPreferredSize(new java.awt.Dimension(540, 370));
			this.setLayout(null);
			{
				addButton = new JButton();
				addButton.setText("Add");
				addButton.setBounds(150, 40, 80, 35);
				addButton.addActionListener(this);
				this.add(addButton);
			}
			{
				removeButton = new JButton();
				removeButton.setText("Remove");
				removeButton.setBounds(150, 70, 80, 35);
				removeButton.addActionListener(this);
				this.add(removeButton);
			}
			{
				saveButton = new JButton();
				this.add(saveButton);
				saveButton.setText("Save");
				saveButton.setBounds(150, 100, 80, 35);
				saveButton.addActionListener(this);
			}
			{
				testButton = new JButton();
				this.add(testButton);
				testButton.setText("Test");
				testButton.setBounds(150, 130, 80, 35);
				testButton.addActionListener(this);
			}
			{
				backButton = new JButton();
				this.add(backButton);
				backButton.setText("Back");
				backButton.setBounds(150, 160, 80, 35);
				backButton.addActionListener(this);
			}
			{
				component = new AIComponent();
				componentTree = new JTree(component);
				JScrollPane ct = new JScrollPane(componentTree);				
				ct.setBounds(20, 20, 130, 200);				
				this.add(ct);
			}
			{
				codeArea = new JList();
				codeArea.addListSelectionListener(this);
				JScrollPane ca = new JScrollPane(codeArea);
				ca.setBounds(230, 20, 290, 330);
				this.add(ca);
			}
			{

				properties = new JTable()
		        {
		            //  Determine editor to be used by row
		            public TableCellEditor getCellEditor(int row, int column)
		            {
		                if (column == 1)
		                {
		                    return (TableCellEditor)editors.get(row);
		                }
		                else
		                    return super.getCellEditor(row, column);
		            }
		        };
				properties.setModel(this.CreateEmptyTableModel());
				JScrollPane pt = new JScrollPane(properties);
				pt.setBounds(20, 230, 200, 120);
				this.add(pt);
			}
			tunnel = new TunnelServlet();
			it = new InfoScriptType();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void actionPerformed(ActionEvent event){
		if(event.getSource() == addButton){
			DefaultMutableTreeNode n = (DefaultMutableTreeNode)componentTree.getLastSelectedPathComponent();
			if(n!=null){
				String node = n.toString();
				index = codeArea.getSelectedIndex() + 1;
				if(node == MoveN.NAME){
					if(index != 0){
						tmp.insertElementAt(new MoveN(),index);
					} else{
						tmp.add(new MoveN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);
					choose = 1;
					properties.setModel(this.CreateMoveProperties());
				} else if(node == IfopN.NAME){
					if(index != 0){
						tmp.insertElementAt(new IfopN(),index);
					} else{
						tmp.add(new IfopN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);
				} else if(node == StandN.NAME){
					if(index != 0){
						tmp.insertElementAt(new StandN(),index);
					} else{
						tmp.add(new StandN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);					
				} else if(node == PunchN.NAME){
					if(index != 0){
						tmp.insertElementAt(new PunchN(),index);
					} else{
						tmp.add(new PunchN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);					
				} else if(node == KickN.NAME){
					if(index != 0){
						tmp.insertElementAt(new KickN(),index);
					} else{
						tmp.add(new KickN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);					
				} else if(node == GuardN.NAME){
					if(index != 0){
						tmp.insertElementAt(new GuardN(),index);
					} else{
						tmp.add(new GuardN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);					
				} else if(node == SpecialN.NAME){
					if(index != 0){
						tmp.insertElementAt(new SpecialN(),index);
					} else{
						tmp.add(new SpecialN());						
					}
					order = false;
					codeArea.setListData(tmp);
					codeArea.setSelectedIndex(index);					
				}
			}
		}else if(event.getSource() == removeButton){
			index = codeArea.getSelectedIndex();
			TableModel propertiesModel = this.CreateEmptyTableModel();
			properties.setModel(propertiesModel);
			if(index != -1){
				tmp.removeElementAt(index);
				order = false;
				codeArea.setListData(tmp);
				codeArea.setSelectedIndex(index-1);
				if(index > 0){
					ObjectNode info = (ObjectNode) tmp.elementAt(index);
					if(info.NAME == MoveN.NAME){
						propertiesModel = new DefaultTableModel(
								((MoveN) info).getInfo(),
								new String[] { "Properties", "Value" });
						properties.setModel(propertiesModel);
					}else if(info.NAME == IfopN.NAME){
						propertiesModel = this.CreateEmptyTableModel();
						properties.setModel(propertiesModel);
					}else if(info.NAME == StandN.NAME){
						propertiesModel = this.CreateEmptyTableModel();
						properties.setModel(propertiesModel);
					}else if(info.NAME == PunchN.NAME){
						propertiesModel = this.CreateEmptyTableModel();
						properties.setModel(propertiesModel);
					}else if(info.NAME == KickN.NAME){
						propertiesModel = this.CreateEmptyTableModel();
						properties.setModel(propertiesModel);
					}else if(info.NAME == GuardN.NAME){
						propertiesModel = this.CreateEmptyTableModel();
						properties.setModel(propertiesModel);
					}else if(info.NAME == SpecialN.NAME){
						propertiesModel = this.CreateEmptyTableModel();
						properties.setModel(propertiesModel);
					}
				}
			}
		}else if(event.getSource() == backButton){
			count = 0;
L1:			while(count < timeout){
				count++;
				if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L1;
				}else{
					String s;
					s = null;
					tunnel.sendObj("idle " + this.userName + ":");
					try{
						s = (String) tunnel.receiveObj();
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("ModifyCodeUI -> L1.");
						tunnel.close();
						continue L1;
					}finally{
						tunnel.close();
					}
					if(s != null){
						if(s.equals("confirm"))
							commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isConfirmModify));
						break L1;
					}				
				}		
			}
		}else if(event.getSource() == saveButton){
			count = 0;
L2:			while(count < timeout){
				count++;
				if(!tunnel.connect("ManageScriptServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L2;
				}else{
					it.header = new String("update");
					it.name = this.userName;
					it.script = tmp;
					String s;
					s = null;
					tunnel.sendObj(it);
					try{
						s = (String) tunnel.receiveObj();
					}catch (Exception e){
						e.printStackTrace();
						System.out.println("ModifyCodeUI -> L2");
						tunnel.close();
						continue L2;
					}finally{
						tunnel.close();
					}
					if(s != null){
						if(!s.equals("confirm")){	
							JOptionPane.showMessageDialog(null,"Can't update new script.");
						}else{
							JOptionPane.showMessageDialog(null,"Your script updated.");
						}
						break L2;
					}
				}
			}
		}else if(event.getSource() == testButton){
			commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isTesting));			
		}
	}

	private TableModel CreateEmptyTableModel(){
		return new DefaultTableModel(
				new String[][] {},
				new String[] { "Properties", "Value" });
	}
	
	private TableModel CreateMoveProperties(){
		editors = new ArrayList(2);
		String[] items1 = { "forward", "backward" };
        comboBoxProp_1 = new JComboBox( items1 );
        DefaultCellEditor dce1 = new DefaultCellEditor( comboBoxProp_1 );
        editors.add( dce1 );
 
        String[] items2 = { "1" };//,"2","3","4","5" };
        comboBoxProp_2 = new JComboBox( items2 );
        DefaultCellEditor dce2 = new DefaultCellEditor( comboBoxProp_2 );
        editors.add( dce2 );
        ObjectNode info = (MoveN)tmp.elementAt(index);
		TableModel propertiesModel = new DefaultTableModel(
				((MoveN) info).getInfo(),
				new String[] { "Properties", "Value" });
		comboBoxProp_1.addItemListener(this);
		comboBoxProp_2.addItemListener(this);

		return propertiesModel;
	}
	public void itemStateChanged(ItemEvent event){
		index = codeArea.getSelectedIndex();
		if(choose == 1){
			if(event.getSource() == comboBoxProp_1){
				((MoveN)tmp.elementAt(index)).direction = (event.getItem().toString()=="forward"? 0 : 1);
			}else if(event.getSource() == comboBoxProp_2){
				((MoveN)tmp.elementAt(index)).distance = Integer.parseInt(event.getItem().toString());
			}
		}
		codeArea.updateUI();
	}

	public void valueChanged(ListSelectionEvent event){
		if((event.getSource() == codeArea) && order){
			index = codeArea.getSelectedIndex();
			ObjectNode info = (ObjectNode) tmp.elementAt(index);	
			if(info.NAME.equals(MoveN.NAME)){
				TableModel propertiesModel = new DefaultTableModel(
						((MoveN) info).getInfo(),
						new String[] { "Properties", "Value" });
				properties.setModel(propertiesModel);
			}else if(info.NAME.equals(IfopN.NAME)){
				propertiesModel = this.CreateEmptyTableModel();
				properties.setModel(propertiesModel);
			}else if(info.NAME.equals(StandN.NAME)){
				propertiesModel = this.CreateEmptyTableModel();
				properties.setModel(propertiesModel);
			}else if(info.NAME.equals(PunchN.NAME)){
				propertiesModel = this.CreateEmptyTableModel();
				properties.setModel(propertiesModel);
			}else if(info.NAME.equals(KickN.NAME)){
				propertiesModel = this.CreateEmptyTableModel();
				properties.setModel(propertiesModel);
			}else if(info.NAME.equals(GuardN.NAME)){
				propertiesModel = this.CreateEmptyTableModel();
				properties.setModel(propertiesModel);
			}else if(info.NAME.equals(SpecialN.NAME)){
				propertiesModel = this.CreateEmptyTableModel();
				properties.setModel(propertiesModel);
			}
		}
		order = true;
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
	public void setUserName(String name){
		this.userName = name;
	}
	public void updateScript(){
		Vector script;
		count = 0;
L3:		while(count < timeout){
			count++;
			if(!tunnel.connect("ManageScriptServlet",TunnelServlet.OBJECT)){
				JOptionPane.showMessageDialog(null,"Can't connect to server.");
				break L3;
			}else{
				it.header = new String("load");
				it.name = this.userName;
				script = null;
				tunnel.sendObj(it);
				try{
					script = (Vector) tunnel.receiveObj();	
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("ModifyCodeUI -> L3");
					tunnel.close();
					continue L3;
				}finally{
					tunnel.close();
				}
				if(script != null){
					tmp = script;
					order = false;
					codeArea.setListData(tmp);
					break L3;
				}
			}
		}		
	}
}
