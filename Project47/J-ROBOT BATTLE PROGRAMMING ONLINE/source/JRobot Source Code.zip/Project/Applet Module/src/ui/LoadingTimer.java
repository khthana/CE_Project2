/*
 * Created on 3 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ui;



/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LoadingTimer extends Thread {
	private MyCanvas canvas;
	private byte sumloading = 0;
	public LoadingTimer(MyCanvas canvas){
		this.canvas = canvas;
	}
	public void run(){
		while(true){
			try {
				sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			canvas.setImage((sumloading%4)+2);	// 2-5 loading image
//			System.out.println((sumloading%4)+2);
			canvas.repaint();
			sumloading++;
			if(sumloading<0)
				sumloading = 0;	
		}
	}
}
