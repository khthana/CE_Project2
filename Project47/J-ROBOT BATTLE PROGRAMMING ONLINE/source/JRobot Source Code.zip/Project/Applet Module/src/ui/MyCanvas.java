/*
 * Created on 3 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ui;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.geom.Rectangle2D;
import java.text.DecimalFormat;
import java.util.Vector;

import lib.CommunicateEvent;
import lib.CommunicateListener;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MyCanvas extends Canvas implements CommunicateListener{
	private int width,height;
	private int time;
	private int hpP1,hpP2;
	private String player1,player2;
	private int p1x,p1y;
	private int p2x,p2y;
	private Image p1image,p2image;	
	public byte mode = -1;
	public Vector result;
	public ViewSimulateUI viewsim;
	private AssistControl assist;
	private LoadingTimer ldt;
	public TimeControl tct;
	private Image i,resultImage;
	public MyCanvas(ViewSimulateUI viewsim,int w,int h){
		this.viewsim = viewsim;
		hpP1 = hpP2 = 100;
		time = 99;
		width = w;
		height = h;
		tct = new TimeControl(this);
		i = tct.getImage(2);
	}
	public void paint(Graphics g){
		Graphics2D g2 = (Graphics2D)g;
		if(mode == 0){	// display
			if(resultImage != null)
				g2.drawImage(resultImage,150,50,this);
				
			g2.drawImage(p1image,p1x,p1y,this);
			if(!this.viewsim.getSimulate())
				g2.drawImage(p2image,p2x,p2y,this);
			g2.setColor(new Color(255,255,0));
		//	g2.draw(new Rectangle2D.Double(20,20,100*2,20));
		//	g2.draw(new Rectangle2D.Double(320,20,100*2,20));
			g2.fill(new Rectangle2D.Double(20,20,100*2,20));
			g2.fill(new Rectangle2D.Double(320,20,100*2,20));

			g2.setColor(new Color(255,0,0));
			g2.fill(new Rectangle2D.Double(20,20,hpP1*2,20));
			g2.fill(new Rectangle2D.Double(320+(100-hpP2)*2,20,hpP2*2,20));

			g2.setColor(new Color(0,0,0));
			g2.setFont(new Font("Cordia New",Font.PLAIN,40));
			DecimalFormat df = new DecimalFormat("00");
			g2.drawString(df.format(time),255, 40);
			
			g2.setFont(new Font("Cordia New",Font.PLAIN,18));
			g2.drawString("TIME",255, 15);
			g2.drawString(player1,20, 15);

			if(!this.viewsim.getSimulate())
				g2.drawString(player2,440, 15);
					
		}else if(mode == 1){ // loading
			g2.drawImage(i,150,150,this);	
		}else if(mode == 2){ // StartFighting
			g2.drawImage(i,150,150,this);
		}
	}
	public Dimension getPreferredSize(){
		return new Dimension(width,height);
	}
	public void setTime(int time){
		this.time = time;
	}
	public void setHPPlayer1(int hp){
		this.hpP1 = hp;
	}
	public void setHPPlayer2(int hp){
		this.hpP2 = hp;
	}
	public void setImagePlayer1(Image i,int x,int y){
		this.p1image = i;
		this.p1x = x;
		this.p1y = y;
	}
	public void setImagePlayer2(Image i,int x,int y){
		this.p2image = i;
		this.p2x = x;
		this.p2y = y;
	}
	public void setImageResult(Image i){
		this.resultImage = i;
	}
	public void setImage(Image i){
		this.i = i;
	}
	public void setImage(int i){
		this.i = tct.getImage(i);
	}
	public void start(Vector result){
		this.resultImage = null;
		this.result = result;
		if(this.viewsim.getMaster()){
			player1 = viewsim.userName;
			player2 = viewsim.getOpponentName();
		}else{
			player1 = viewsim.getOpponentName();
			player2 = viewsim.userName;			
		}
		ldt.stop();
		mode = 2;
		System.out.println("Start Assist.");
		assist = new AssistControl(this);
		assist.addCommunicateEvent(this);
		assist.start();
	}
	public void showLoading(){
		mode = 1; 
		ldt = new LoadingTimer(this);
		tct = new TimeControl(this);
		ldt.start();
	}
	public void CommunicateAction(CommunicateEvent event) {
		if(event.getState() == CommunicateEvent.isStartFighting){
			System.out.println("Start tct.");
			mode = 0;
			tct.start();
		}
	}
}
