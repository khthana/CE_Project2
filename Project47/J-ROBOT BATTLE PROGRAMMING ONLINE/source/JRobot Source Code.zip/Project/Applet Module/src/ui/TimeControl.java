/*
 * Created on 3 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ui;

import java.awt.Image;
import java.awt.MediaTracker;
import java.util.Vector;

import javax.swing.ImageIcon;

import lib.ResultV;


/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TimeControl extends Thread {
	int act = -1;
	MediaTracker tracker;
	private MyCanvas canvas;
	private Vector resultScript;
	private ImageIcon ic;
//	private BufferedImage i[];
	private ImageIcon i[];
	private int p1char = 0;
	private int p2char = 0;
	private String resource[] = {
			 "ui/images/info/ready.gif",
			 "ui/images/info/fight.gif",
			 "ui/images/info/loading-0.gif",
			 "ui/images/info/loading-1.gif",
			 "ui/images/info/loading-2.gif",
			 "ui/images/info/loading-3.gif",	
			 "ui/images/info/win.gif",			// 6
			 "ui/images/info/draw.gif",
			 "ui/images/info/lose.gif",			
			 
			 // frog left // 12 acc 9 - 20
			 "ui/images/acchar/frogLeft/stand.gif",	// 9
			 "ui/images/acchar/frogLeft/damage.gif",
		 	 "ui/images/acchar/frogLeft/dead.gif",
		     "ui/images/acchar/frogLeft/guard.gif",
	 		 "ui/images/acchar/frogLeft/move1.gif",	// 13
			 "ui/images/acchar/frogLeft/move2.gif",
			 "ui/images/acchar/frogLeft/punch1.gif",	// 15
			 "ui/images/acchar/frogLeft/punch2.gif",
			 "ui/images/acchar/frogLeft/kick1.gif",	// 17
			 "ui/images/acchar/frogLeft/kick2.gif",
			 "ui/images/acchar/frogLeft/special1.gif", // 19
			 "ui/images/acchar/frogLeft/special2.gif",				 
			 
			 // rat left // 21 - 32
			 "ui/images/acchar/ratLeft/stand.gif",	// 21
			 "ui/images/acchar/ratLeft/damage.gif",
		 	 "ui/images/acchar/ratLeft/dead.gif",
		     "ui/images/acchar/ratLeft/guard.gif",
	 		 "ui/images/acchar/ratLeft/move1.gif",	// 25
			 "ui/images/acchar/ratLeft/move2.gif",
			 "ui/images/acchar/ratLeft/punch1.gif",	// 27
			 "ui/images/acchar/ratLeft/punch2.gif",
			 "ui/images/acchar/ratLeft/kick1.gif",	// 29
			 "ui/images/acchar/ratLeft/kick2.gif",
			 "ui/images/acchar/ratLeft/special1.gif", // 31
			 "ui/images/acchar/ratLeft/special2.gif",				 
			 
			 // elephant left // 57 - 68
			 "ui/images/acchar/eleLeft/stand.gif",	// 57
			 "ui/images/acchar/eleLeft/damage.gif",
		 	 "ui/images/acchar/eleLeft/dead.gif",
		     "ui/images/acchar/eleLeft/guard.gif",
	 		 "ui/images/acchar/eleLeft/move1.gif",	// 61
			 "ui/images/acchar/eleLeft/move2.gif",
			 "ui/images/acchar/eleLeft/punch1.gif",	// 63
			 "ui/images/acchar/eleLeft/punch2.gif",
			 "ui/images/acchar/eleLeft/kick1.gif",	// 65
			 "ui/images/acchar/eleLeft/kick2.gif",
			 "ui/images/acchar/eleLeft/special1.gif", // 67
			 "ui/images/acchar/eleLeft/special2.gif",
			 
			 // panda left // 33 - 44
			 "ui/images/acchar/pandaLeft/stand.gif",	// 33
			 "ui/images/acchar/pandaLeft/damage.gif",
		 	 "ui/images/acchar/pandaLeft/dead.gif",
		     "ui/images/acchar/pandaLeft/guard.gif",
	 		 "ui/images/acchar/pandaLeft/move1.gif",	// 37
			 "ui/images/acchar/pandaLeft/move2.gif",
			 "ui/images/acchar/pandaLeft/punch1.gif",	// 39
			 "ui/images/acchar/pandaLeft/punch2.gif",
			 "ui/images/acchar/pandaLeft/kick1.gif",	// 41
			 "ui/images/acchar/pandaLeft/kick2.gif",
			 "ui/images/acchar/pandaLeft/special1.gif", // 43
			 "ui/images/acchar/pandaLeft/special2.gif",				 
			 
			 // bird left // 45 - 56
			 "ui/images/acchar/birdLeft/stand.gif",	// 45
			 "ui/images/acchar/birdLeft/damage.gif",
		 	 "ui/images/acchar/birdLeft/dead.gif",
		     "ui/images/acchar/birdLeft/guard.gif",
	 		 "ui/images/acchar/birdLeft/move1.gif",	// 49
			 "ui/images/acchar/birdLeft/move2.gif",
			 "ui/images/acchar/birdLeft/punch1.gif",	// 51
			 "ui/images/acchar/birdLeft/punch2.gif",
			 "ui/images/acchar/birdLeft/kick1.gif",	// 53
			 "ui/images/acchar/birdLeft/kick2.gif",
			 "ui/images/acchar/birdLeft/special1.gif", // 55
			 "ui/images/acchar/birdLeft/special2.gif",				 
			 
			 // frog right // 12 acc 69 - 80
			 "ui/images/acchar/frogRight/stand.gif",	// 69
			 "ui/images/acchar/frogRight/damage.gif",
		 	 "ui/images/acchar/frogRight/dead.gif",
		     "ui/images/acchar/frogRight/guard.gif",
	 		 "ui/images/acchar/frogRight/move1.gif",	// 73
			 "ui/images/acchar/frogRight/move2.gif",
			 "ui/images/acchar/frogRight/punch1.gif",	// 75
			 "ui/images/acchar/frogRight/punch2.gif",
			 "ui/images/acchar/frogRight/kick1.gif",	// 77
			 "ui/images/acchar/frogRight/kick2.gif",
			 "ui/images/acchar/frogRight/special1.gif", // 79
			 "ui/images/acchar/frogRight/special2.gif",				 
			 
			 // rat right // 12 acc 81 - 92
			 "ui/images/acchar/ratRight/stand.gif",	// 81
			 "ui/images/acchar/ratRight/damage.gif",
		 	 "ui/images/acchar/ratRight/dead.gif",
		     "ui/images/acchar/ratRight/guard.gif",
	 		 "ui/images/acchar/ratRight/move1.gif",	// 85
			 "ui/images/acchar/ratRight/move2.gif",
			 "ui/images/acchar/ratRight/punch1.gif",	// 87
			 "ui/images/acchar/ratRight/punch2.gif",
			 "ui/images/acchar/ratRight/kick1.gif",	// 89
			 "ui/images/acchar/ratRight/kick2.gif",
			 "ui/images/acchar/ratRight/special1.gif", // 91
			 "ui/images/acchar/ratRight/special2.gif",				 
			 
			 // elephant Right // 57 - 68
			 "ui/images/acchar/eleRight/stand.gif",	
			 "ui/images/acchar/eleRight/damage.gif",
		 	 "ui/images/acchar/eleRight/dead.gif",
		     "ui/images/acchar/eleRight/guard.gif",
	 		 "ui/images/acchar/eleRight/move1.gif",	
			 "ui/images/acchar/eleRight/move2.gif",
			 "ui/images/acchar/eleRight/punch1.gif",	
			 "ui/images/acchar/eleRight/punch2.gif",
			 "ui/images/acchar/eleRight/kick1.gif",	
			 "ui/images/acchar/eleRight/kick2.gif",
			 "ui/images/acchar/eleRight/special1.gif", 
			 "ui/images/acchar/eleRight/special2.gif",
			 
			 // panda Right // 33 - 44
			 "ui/images/acchar/pandaRight/stand.gif",	
			 "ui/images/acchar/pandaRight/damage.gif",
		 	 "ui/images/acchar/pandaRight/dead.gif",
		     "ui/images/acchar/pandaRight/guard.gif",
	 		 "ui/images/acchar/pandaRight/move1.gif",	
			 "ui/images/acchar/pandaRight/move2.gif",
			 "ui/images/acchar/pandaRight/punch1.gif",	
			 "ui/images/acchar/pandaRight/punch2.gif",
			 "ui/images/acchar/pandaRight/kick1.gif",	
			 "ui/images/acchar/pandaRight/kick2.gif",
			 "ui/images/acchar/pandaRight/special1.gif", 
			 "ui/images/acchar/pandaRight/special2.gif",				 
			 
			 // bird Right // 45 - 56
			 "ui/images/acchar/birdRight/stand.gif",	
			 "ui/images/acchar/birdRight/damage.gif",
		 	 "ui/images/acchar/birdRight/dead.gif",
		     "ui/images/acchar/birdRight/guard.gif",
	 		 "ui/images/acchar/birdRight/move1.gif",	
			 "ui/images/acchar/birdRight/move2.gif",
			 "ui/images/acchar/birdRight/punch1.gif",	
			 "ui/images/acchar/birdRight/punch2.gif",
			 "ui/images/acchar/birdRight/kick1.gif",	
			 "ui/images/acchar/birdRight/kick2.gif",
			 "ui/images/acchar/birdRight/special1.gif", 
			 "ui/images/acchar/birdRight/special2.gif"				 
	};	
	public TimeControl(MyCanvas canvas){
		this.canvas = canvas;	    
//		tracker = new MediaTracker(this.canvas);
//		i = new BufferedImage[resource.length];
		i = new ImageIcon[resource.length];
		for(int j=0;j<resource.length;j++){
			i[j] = new ImageIcon(getClass().getClassLoader().getResource(resource[j]));
//			Image temp = ic.getImage();
			Image temp = i[j].getImage();
//		    tracker.addImage(temp, 0);
			int i_w = temp.getWidth(null);
			int i_h = temp.getHeight(null);
			
//			i[j] = new BufferedImage(i_w,i_h,BufferedImage.TYPE_INT_ARGB);
//			Graphics2D g2 = i[j].createGraphics();
//			try {
//				tracker.waitForID(0);
//			} catch (InterruptedException e) {
//			e.printStackTrace();
//			}
//			g2.drawImage(temp,0,0,null);			
		}			
	}
	public Image getImage(int i){
		return this.i[i].getImage();
	}
	public void run(){
		p1char = 3 * 12;
		System.out.println("tct run.");
		resultScript = canvas.result;
		if(canvas.viewsim.getSimulate()){
			while(act < resultScript.size()-2){
				act++;

				ResultV info = (ResultV) resultScript.elementAt(act);
				if(info.p1action.equals("MOVE")){
					int begin = (info.p1direction == 0 ?
								(info.p1x-13):
							    (info.p1x+13));	
					canvas.setImagePlayer1(i[13+p1char].getImage(),begin,info.p1y);						
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			//		begin = info.p1x-i[11].getWidth();	
					canvas.setImagePlayer1(i[14+p1char].getImage(),begin,info.p1y);
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}	
				}else if(info.p1action.equals("PUNCH")){
			//		int begin = info.p1x-i[13].getWidth()-10;
					canvas.setImagePlayer1(i[15+p1char].getImage(),info.p1x,info.p1y);						
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			//		begin = info.p1x-i[14].getWidth()+10;	
					canvas.setImagePlayer1(i[16+p1char].getImage(),info.p1x,info.p1y);
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("KICK")){
			//		int begin = info.p1x-i[15].getWidth()-10;
					canvas.setImagePlayer1(i[17+p1char].getImage(),info.p1x,info.p1y);						
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			//		begin = info.p1x-i[16].getWidth()+10;	
					canvas.setImagePlayer1(i[18+p1char].getImage(),info.p1x,info.p1y);
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("GUARD")){
			//		int begin = info.p1x-i[9].getWidth();
					canvas.setImagePlayer1(i[12+p1char].getImage(),info.p1x,info.p1y);						
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
			//		begin = info.p1x-i[12+p1char].getImage().getWidth();	
					canvas.setImagePlayer1(i[12+p1char].getImage(),info.p1x,info.p1y);
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("STAND")){
					canvas.setImagePlayer1(i[9+p1char].getImage(),info.p1x,info.p1y);						
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[9+p1char].getImage(),info.p1x,info.p1y);
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("SPECIAL")){
					canvas.setImagePlayer1(i[19+p1char].getImage(),info.p1x,info.p1y);						
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[20+p1char].getImage(),info.p1x,info.p1y);
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}
			}
			canvas.viewsim.setEnableBack(true);
		}else{
			p1char = canvas.viewsim.p1char * 12;
			p2char = canvas.viewsim.p2char * 12;
			while(act < resultScript.size()-2){
				act++;
				ResultV info = (ResultV) resultScript.elementAt(act);
				if(info.p1action.equals("MOVE")){
					int begin = (info.p1direction == 0 ?
								((info.p1x*25-200)-13):
							    ((info.p1x*25-200)+13));	
					canvas.setImagePlayer1(i[13+p1char].getImage(),begin,info.p1y);
					if(info.p2action.equals("MOVE")){
						int b1 = (info.p2direction == 0 ?
								((info.p2x*25-200)+13):
							    ((info.p2x*25-200)-13));	
						canvas.setImagePlayer2(i[73+p2char].getImage(),b1,info.p2y);						
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[75+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[77+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[79+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[14+p1char].getImage(),(info.p1x*25-200),info.p1y);
					if(info.p2action.equals("MOVE")){
						canvas.setImagePlayer2(i[74+p2char].getImage(),(info.p2x*25-200),info.p2y);
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[76+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[78+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[80+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}				
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}	
				}else if(info.p1action.equals("PUNCH")){
					canvas.setImagePlayer1(i[15+p1char].getImage(),(info.p1x*25-200),info.p1y);	
					if(info.p2action.equals("MOVE")){
						int b1 = (info.p2direction == 0 ?
								((info.p2x*25-200)+13):
							    ((info.p2x*25-200)-13));	
						canvas.setImagePlayer2(i[73+p2char].getImage(),b1,info.p2y);						
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[75+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[77+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[79+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);	
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[16+p1char].getImage(),(info.p1x*25-200),info.p1y);
					if(info.p2action.equals("MOVE")){
						canvas.setImagePlayer2(i[74+p2char].getImage(),(info.p2x*25-200),info.p2y);
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[76+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[78+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[80+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						if(info.p2x-3 == info.p1x){
							canvas.setImagePlayer2(i[70+p2char].getImage(),info.p2x*25-200,info.p2y);	
						}else{
							canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);
						}
					}	
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("KICK")){
					canvas.setImagePlayer1(i[17+p1char].getImage(),(info.p1x*25-200),info.p1y);	
					if(info.p2action.equals("MOVE")){
						int b1 = (info.p2direction == 0 ?
								((info.p2x*25-200)+13):
							    ((info.p2x*25-200)-13));	
						canvas.setImagePlayer2(i[73+p2char].getImage(),b1,info.p2y);						
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[75+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[77+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[79+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);	
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}					
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[18+p1char].getImage(),(info.p1x*25-200),info.p1y);
					if(info.p2action.equals("MOVE")){
						canvas.setImagePlayer2(i[74+p2char].getImage(),(info.p2x*25-200),info.p2y);
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[76+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[78+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[80+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						if(info.p2x-3 == info.p1x){
							canvas.setImagePlayer2(i[70+p2char].getImage(),info.p2x*25-200,info.p2y);	
						}else{
							canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);
						}						
					}	
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("SPECIAL")){
					canvas.setImagePlayer1(i[19+p1char].getImage(),(info.p1x*25-200),info.p1y);	
					if(info.p2action.equals("MOVE")){
						int b1 = (info.p2direction == 0 ?
								((info.p2x*25-200)+13):
							    ((info.p2x*25-200)-13));	
						canvas.setImagePlayer2(i[73+p2char].getImage(),b1,info.p2y);						
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[75+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[77+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[79+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);	
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}					
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[20+p1char].getImage(),(info.p1x*25-200),info.p1y);
					if(info.p2action.equals("MOVE")){
						canvas.setImagePlayer2(i[74+p2char].getImage(),(info.p2x*25-200),info.p2y);
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[76+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[78+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[80+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						if(info.p2x-3 == info.p1x){
							canvas.setImagePlayer2(i[70+p2char].getImage(),info.p2x*25-200,info.p2y);	
						}else{
							canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);
						}						
					}	
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("GUARD")){
					canvas.setImagePlayer1(i[12+p1char].getImage(),(info.p1x*25-200),info.p1y);						
					canvas.repaint();
					if(info.p2action.equals("MOVE")){
						int b1 = (info.p2direction == 0 ?
								((info.p2x*25-200)+13):
							    ((info.p2x*25-200)-13));	
						canvas.setImagePlayer2(i[73+p2char].getImage(),b1,info.p2y);						
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[75+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[77+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[79+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}					
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[12+p1char].getImage(),(info.p1x*25-200),info.p1y);
					if(info.p2action.equals("MOVE")){
						canvas.setImagePlayer2(i[74+p2char].getImage(),(info.p2x*25-200),info.p2y);
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[76+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[78+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[80+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("STAND")){
					canvas.setImagePlayer1(i[9+p1char].getImage(),(info.p1x*25-200),info.p1y);						
					canvas.repaint();
					if(info.p2action.equals("MOVE")){
						int b1 = (info.p2direction == 0 ?
								((info.p2x*25-200)+13):
							    ((info.p2x*25-200)-13));	
						canvas.setImagePlayer2(i[73+p2char].getImage(),b1,info.p2y);						
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[75+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[77+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[79+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}					
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					canvas.setImagePlayer1(i[9+p1char].getImage(),info.p1x*25-200,info.p1y);
					if(info.p2action.equals("MOVE")){
						canvas.setImagePlayer2(i[74+p2char].getImage(),(info.p2x*25-200),info.p2y);
					}else if(info.p2action.equals("PUNCH")){
						canvas.setImagePlayer2(i[76+p2char].getImage(),info.p2x*25-200,info.p2y);	
						if(info.p2x-3 == info.p1x){
							canvas.setImagePlayer1(i[10+p1char].getImage(),(info.p1x*25-200),info.p1y);	
						}
					}else if(info.p2action.equals("KICK")){
						canvas.setImagePlayer2(i[78+p2char].getImage(),info.p2x*25-200,info.p2y);	
						if(info.p2x-3 == info.p1x){
							canvas.setImagePlayer1(i[10+p1char].getImage(),(info.p1x*25-200),info.p1y);	
						}						
					}else if(info.p2action.equals("SPECIAL")){
						canvas.setImagePlayer2(i[80+p2char].getImage(),info.p2x*25-200,info.p2y);	
						if(info.p2x-3 == info.p1x){
							canvas.setImagePlayer1(i[10+p1char].getImage(),(info.p1x*25-200),info.p1y);	
						}							
					}else if(info.p2action.equals("GUARD")){
						canvas.setImagePlayer2(i[72+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}else if(info.p2action.equals("STAND")){
						canvas.setImagePlayer2(i[69+p2char].getImage(),info.p2x*25-200,info.p2y);							
					}
					canvas.setHPPlayer1(info.p1hp);
					canvas.setHPPlayer2(info.p2hp);
					canvas.setTime(info.time);
					canvas.repaint();
					try {
						sleep(300);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}					
				}else if(info.p1action.equals("P2WIN")){
					canvas.setImagePlayer1(i[11+p1char].getImage(),(info.p1x*25-200),info.p1y);
					if(canvas.viewsim.getMaster()){
						canvas.setImageResult(i[8].getImage());
					}else{
						canvas.setImageResult(i[6].getImage());				
					}
					canvas.repaint();					
				}else if(info.p1action.equals("P1WIN")){
					canvas.setImagePlayer2(i[71+p2char].getImage(),(info.p2x*25-200),info.p2y);
					if(canvas.viewsim.getMaster()){
						canvas.setImageResult(i[6].getImage());
					}else{
						canvas.setImageResult(i[8].getImage());				
					}
					canvas.repaint();					
				}else if(info.p1action.equals("DRAW")){
					if(info.p1hp <= 0 && info.p2hp <= 0){
						canvas.setImagePlayer1(i[11+p1char].getImage(),(info.p1x*25-200),info.p1y);
						canvas.setImagePlayer2(i[71+p2char].getImage(),(info.p2x*25-200),info.p2y);						
					}
					canvas.setImageResult(i[7].getImage());
					canvas.repaint();	
				}
			}
			canvas.viewsim.setEnableBack(true);				
		}
	}
}
