/*
 * Created on 24 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ui;

import java.util.Vector;
import javax.swing.JOptionPane;

import lib.CommunicateEvent;
import lib.CommunicateListener;
import lib.InfoScriptType;
import lib.TunnelServlet;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LoadScript extends Thread {
	ViewSimulateUI vs;
	TunnelServlet tunnel;
	Vector result;
	InfoScriptType it;
	String roomName;
	private boolean master = true;
	private String opponentName = null;
	private boolean sim;
	private CommunicateListener commu = null;
	private final int timeout = 5;
	private int count;
	public LoadScript(ViewSimulateUI vs,boolean sim,String roomName,String opponentName,boolean master){
		this.sim = sim;
		this.opponentName = opponentName;
		this.roomName = roomName;
		this.master = master;
		this.vs = vs;
	}
	public void run(){
		System.out.println("Start Loading.");
		tunnel = new TunnelServlet();
		it = new InfoScriptType();
		count = 0;
L1:		while(count < timeout){
			count++;
			if(!tunnel.connect("ManageScriptServlet",TunnelServlet.OBJECT)){
				JOptionPane.showMessageDialog(null,"Can't connect to server.");
				break L1;
			}else{
				if(sim){
					it.header = new String("simulate");
					it.roomName = new String(" ");
				}
				else{
					it.header = new String("viewResult");
					it.roomName = new String(roomName);
				}
				if(master){
					it.name = vs.userName;
					it.opponentName = opponentName;
				}else{
					it.name = opponentName;
					it.opponentName = vs.userName;
				}
				result = null;
				tunnel.sendObj(it);
				try{
					result = (Vector) tunnel.receiveObj();	
				}catch (Exception e){
					e.printStackTrace();
					System.out.println("LoadScript -> L1");
					tunnel.close();
					continue L1;
				}finally{
					tunnel.close();
				}
				if(result != null){
					break L1;
				}
			}
		}
		vs.result = result;
		commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isLoadComplete));
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
}
