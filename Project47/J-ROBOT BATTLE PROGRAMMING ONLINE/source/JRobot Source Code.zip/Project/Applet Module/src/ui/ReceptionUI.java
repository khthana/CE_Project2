package ui;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import lib.*;

/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class ReceptionUI extends JPanel implements ActionListener {
	private JList allPlayer;
	private JList chatArea;
	private JTextField text;
	private JButton modify;
	private JList battlefields;
	private JPanel fieldPanel;
	private JButton signout;
	private JButton join;
	private JButton create;
	private JPanel menuPanel;
	private JPanel playerlistPanel;
	private JPanel chatPanel;
	private CommunicateListener commu = null;
	private TunnelServlet tunnel;
	private String userName = null;
	private String roomName = null;
	private UserState onlineUser = null;
	private UpdateInfoThread updateInfo = null;
	private Vector room = null;
	private final int timeout = 5;
	private int count;

	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}


	/**
	* Auto-generated main method to display this 
	* JPanel inside a new JFrame.
	*/
	
	public ReceptionUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setPreferredSize(new java.awt.Dimension(540, 370));
			this.setLayout(null);
			{
				chatPanel = new JPanel();
				this.add(chatPanel);
				chatPanel.setBounds(5, 185, 380, 178);
				chatPanel.setLayout(null);
				chatPanel.setBorder(BorderFactory.createTitledBorder(null, "Chat room", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				{
					chatArea = new JList();
					JScrollPane ca2 = new JScrollPane(chatArea);
					chatPanel.add(ca2);
					ca2.setBounds(15, 25, 350, 110);
				}
				{
					text = new JTextField();
					chatPanel.add(text);
					text.setBounds(15, 145, 350, 23);
				}
			}
			{
				playerlistPanel = new JPanel();
				this.add(playerlistPanel);
				playerlistPanel.setBounds(390, 153, 145, 210);
				playerlistPanel.setLayout(null);
				playerlistPanel.setBorder(BorderFactory.createTitledBorder(null, "Player list", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				{
					allPlayer = new JList();
					JScrollPane ca1 = new JScrollPane(allPlayer);
					playerlistPanel.add(ca1);
					ca1.setBounds(15, 25, 115, 170);
				}
			}
			{
				menuPanel = new JPanel();
				this.add(menuPanel);
				menuPanel.setBounds(390, 5, 145, 145);
				menuPanel.setBorder(BorderFactory.createTitledBorder(null, "Menu", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				menuPanel.setLayout(null);
				{
					create = new JButton();
					menuPanel.add(create);
					create.setText("Create room");
					create.setBounds(15, 15, 115, 38);
					create.addActionListener(this);
				}
				{
					join = new JButton();
					menuPanel.add(join);
					join.setText("Join room");
					join.setBounds(15, 43, 115, 38);
					join.addActionListener(this);
				}
				{
					modify = new JButton();
					menuPanel.add(modify);
					modify.setText("Modify code");
					modify.setBounds(15, 71, 115, 38);
					modify.addActionListener(this);
				}
				{
					signout = new JButton();
					menuPanel.add(signout);
					signout.setText("Sign out");
					signout.setBounds(15, 99, 115, 38);
					signout.addActionListener(this);
				}
			}
			{
				fieldPanel = new JPanel();
				this.add(fieldPanel);
				fieldPanel.setBounds(5, 5, 380, 180);
				fieldPanel.setBorder(BorderFactory.createTitledBorder(null, "Battle fields", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				fieldPanel.setLayout(null);
				{
					battlefields = new JList();
					JScrollPane ca3 = new JScrollPane(battlefields);
					fieldPanel.add(ca3);
					ca3.setBounds(15, 25, 350, 140);
				}
			}
			tunnel = new TunnelServlet();
			room = new Vector();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == signout){
			int result = JOptionPane.showConfirmDialog(null,"Are you want to Sign out.","Warning !!!.", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
			if(result == JOptionPane.YES_OPTION){
				updateInfo.stop();
				String s;
				count = 0;
L1:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L1;
					}else{
						s = null;
						tunnel.sendObj("signout " + this.userName + ":");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("ReceptionUI -> L1");
							tunnel.close();
							continue L1;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(!s.equals("confirm")){	
								JOptionPane.showMessageDialog(null,"Can't receive response from server.");
							}else	
								commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isSignout));	
							break L1;
						}							
					}
				}
			}
		}
		else if(event.getSource() == modify){
			String s;
			count = 0;
L2:			while(count < timeout){
				count++;
				if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
					JOptionPane.showMessageDialog(null,"Can't connect to server.");
					break L2;
				}else{
					s = null;
					tunnel.sendObj("modify " + this.userName + ":");
					try{
						s = (String) tunnel.receiveObj();
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("ReceptionUI -> L2");
						tunnel.close();
						continue L2;
					}finally{
						tunnel.close();
					}
					if(s != null){
						if(!s.equals("confirm")){	
							JOptionPane.showMessageDialog(null,"Can't receive response from server.");
						}else				
							commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isModify));				
						break L2;
					}
				}
			}						
		}
		else if(event.getSource() == create){
			String s;
			roomName = JOptionPane.showInputDialog("Please input a room's name.");
			if(roomName != null && !roomName.equals("")){
				count = 0;
L3:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L3;
					}else{
						s = null;
						tunnel.sendObj("testroom " + roomName + ":" + this.userName + ";");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("ReceptionUI -> L3");
							tunnel.close();
							continue L3;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(s.equals("accept")){
								commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isCreateRoom));	
							}else{
								JOptionPane.showMessageDialog(null,"Name already exists.");
							}
							break L3;
						}				
					}
				}
			}
		}
		else if(event.getSource() == join){
			String s;
			int index = battlefields.getSelectedIndex();
			if(index > -1){
				roomName = (String) room.elementAt(index);
				count = 0;
L4:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L4;
					}else{
						s = null;
						tunnel.sendObj("joinroom " + roomName + ":" + this.userName + ";");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("ReceptionUI -> L4");
							tunnel.close();
							continue L4;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(s.equals("accept")){
								commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isJoinRoom));	
							}else{
								JOptionPane.showMessageDialog(null,"Room is full.");
							}	
							break L4;
						}			
					}	
				}		
			}
		}
	}
	public void setUserName(String name){
		this.userName = name;
		fieldPanel.setBorder(BorderFactory.createTitledBorder(null, "Battle fields for \"" + name + "\"", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
		updateInfo = new UpdateInfoThread(this,name);
		updateInfo.start();
	}
	public void updateInfo(Vector onlineUser,Vector chatRoom,Vector room,Vector statroom){
		allPlayer.setListData(onlineUser);
		allPlayer.setCellRenderer(new PlayerCellRenderer((UserState) onlineUser));
		chatArea.setListData(chatRoom);
		battlefields.setListData(statroom);
		this.room = room;
	}
	public String getRoomName(){
		return roomName;
	}
	public void setInfoThreadSuspend(){
		updateInfo.suspend();
	}
	public void setInfoThreadResume(){
		updateInfo.resume();
	}
}
