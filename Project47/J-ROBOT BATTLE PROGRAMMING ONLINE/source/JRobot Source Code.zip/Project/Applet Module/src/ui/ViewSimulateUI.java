package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import lib.CommunicateEvent;
import lib.CommunicateListener;
import lib.InfoScriptType;
/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class ViewSimulateUI extends JPanel implements CommunicateListener,ActionListener{

	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}	
	private boolean sim = true;
	private boolean master;
	private String opponentName = null;
	MyCanvas canvas;
	private TimeControl time;
	public String userName;
	private CommunicateListener commu = null;
	private JButton backButton;
	InfoScriptType it;
	private LoadScript lsc;
	boolean complete = false;
	public Vector result;
	public int p1char;
	public int p2char;
	/**
	* Auto-generated main method to display this 
	* JPanel inside a new JFrame.
	*/
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.getContentPane().add(new ViewSimulateUI());
		frame.pack();
		frame.show();
	}
	
	public ViewSimulateUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			setPreferredSize(new Dimension(540, 360));
			this.setLayout(null);
			{
				canvas = new MyCanvas(this,540,360);
				this.add(canvas);
				canvas.setBounds(0, 0, 540, 330);
			}
			{
				backButton = new JButton();
				this.add(backButton);
				backButton.setText("Back");
				backButton.setBounds(40, 330, 80, 35);
				backButton.addActionListener(this);
			}
			it = new InfoScriptType();

//			lsc = new LoadScript(this);
//			lsc.addCommunicateEvent(this);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void setUserName(String name){
		this.userName = name;
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
	public void CommunicateAction(CommunicateEvent event) {
		if(event.getState() == CommunicateEvent.isLoadComplete){
			System.out.println("Load complete.");
			canvas.start(result);	
		}
	}
	public void setVisible(boolean flag){
		super.setVisible(flag);
		canvas.setVisible(flag);
	}
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == backButton){
			canvas.tct.stop();
			canvas.setTime(99);
			canvas.setImage(2);
			if(sim)
				commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isModify));
			else
				commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isBackRoom));
		}
	}
	public void start(boolean sim,String roomName,String opponentName,boolean master,int p1char,int p2char){	// test = true,viewResult = false
		this.sim = sim;
		this.opponentName = opponentName;
		this.master = master;
		this.p1char = p1char;
		this.p2char = p2char;
		result = null;
		backButton.setEnabled(sim);
		lsc = new LoadScript(this,sim,roomName,opponentName,master);
		lsc.addCommunicateEvent(this);
		lsc.start();
		canvas.showLoading();
	}
	public String getOpponentName(){
		return opponentName;
	}
	public boolean getMaster(){
		return master;
	}
	public void setEnableBack(boolean bool){
		backButton.setEnabled(bool);
	}
	public boolean getSimulate(){
		return sim;
	}
}
