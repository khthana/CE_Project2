package ui;

import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;
import javax.swing.border.*;

import lib.*;

/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class WaitRoomUI extends JPanel implements ActionListener {
	private JList chatArea;
	private JTextField text;
	private JPanel fieldPanel;
	private JButton exit;
	private JButton ready;
	private JPanel menuPanel;
	private JPanel playerlistPanel;
	private JPanel chatPanel;
	private CommunicateListener commu = null;
	private TunnelServlet tunnel;
	private String userName = null;
	private ButtonGroup buttonGroup;
	private JRadioButton selectBird;
	private JRadioButton selectPanda;
	private JRadioButton selectElephant;
	private JRadioButton selectRat;
	private JRadioButton selectFrog;
	private JLabel p1pic;
	private JLabel p2pic;
	private JLabel vspic;
	private UpdateInsideRoomThread updateInside = null;
	private boolean master = false;
	private boolean opponent = false;
	private String roomName = null;
	private String opponentName = null;
	private final int timeout = 5;
	private int count;
	private int p1char,p2char;
	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public WaitRoomUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setPreferredSize(new java.awt.Dimension(540, 370));
			this.setLayout(null);
			{
				chatPanel = new JPanel();
				this.add(chatPanel);
				chatPanel.setBounds(5, 185, 380, 178);
				chatPanel.setLayout(null);
				chatPanel.setBorder(BorderFactory.createTitledBorder(null, "Chat room", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				{
					chatArea = new JList();
					JScrollPane ca2 = new JScrollPane(chatArea);
					chatPanel.add(ca2);
					ca2.setBounds(15, 25, 350, 110);
				}
				{
					text = new JTextField();
					chatPanel.add(text);
					text.setBounds(15, 145, 350, 23);
				}
			}
			{
				playerlistPanel = new JPanel();
				this.add(playerlistPanel);
				playerlistPanel.setBounds(390, 100, 145, 263);
				playerlistPanel.setLayout(null);
				playerlistPanel.setBorder(BorderFactory.createTitledBorder(null, "Character", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				{
					selectFrog = new JRadioButton(); 
					playerlistPanel.add(selectFrog);
					selectFrog.setText("Forkari");
					selectFrog.setBounds(8, 21, 130, 40);
					selectFrog.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/frog1.gif")));
					selectFrog.setSelectedIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/frog2.gif")));
					selectFrog.setSelected(true);
					selectFrog.addActionListener(this);
				}
				{
					selectRat = new JRadioButton();
					playerlistPanel.add(selectRat);
					selectRat.setText("Rabbiga");
					selectRat.setBounds(8, 68, 130, 40);
					selectRat.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/rat1.gif")));
					selectRat.setSelectedIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/rat2.gif")));
					selectRat.addActionListener(this);
				}
				{
					selectElephant = new JRadioButton();
					playerlistPanel.add(selectElephant);
					selectElephant.setText("Elephaga");
					selectElephant.setBounds(8, 118, 130, 40);
					selectElephant.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/elephant1.gif")));
					selectElephant.setSelectedIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/elephant2.gif")));
					selectElephant.addActionListener(this);
				}
				{
					selectPanda = new JRadioButton();
					playerlistPanel.add(selectPanda);
					selectPanda.setText("Pandaki");
					selectPanda.setBounds(8, 167, 130, 40);
					selectPanda.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/panda1.gif")));
					selectPanda.addActionListener(this);
				}
				{
					selectBird = new JRadioButton();
					playerlistPanel.add(selectBird);
					selectBird.setText("Petrori");
					selectBird.setBounds(8, 216, 130, 40);
					selectBird.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/bird1.gif")));
					selectBird.addActionListener(this);
				}
				{
					buttonGroup = new ButtonGroup();
					buttonGroup.add(selectFrog);
					buttonGroup.add(selectRat);
					buttonGroup.add(selectElephant);
					buttonGroup.add(selectPanda);
					selectPanda.setSelectedIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/panda2.gif")));
					buttonGroup.add(selectBird);
					selectBird.setSelectedIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/schar/bird2.gif")));
				}
			}
			{
				menuPanel = new JPanel();
				this.add(menuPanel);
				menuPanel.setBounds(390, 5, 145, 90);
				menuPanel.setBorder(BorderFactory.createTitledBorder(null, "Menu", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				menuPanel.setLayout(null);
				{
					ready = new JButton();
					menuPanel.add(ready);
					ready.setText("Ready");
					ready.setBounds(15, 15, 115, 38);
					ready.addActionListener(this);
				}
				{
					exit = new JButton();
					menuPanel.add(exit);
					exit.setText("Exit");
					exit.setBounds(15, 43, 115, 38);
					exit.addActionListener(this);
				}
			}			
			{
				fieldPanel = new JPanel();
				this.add(fieldPanel);
				fieldPanel.setBounds(5, 5, 380, 180);
				fieldPanel.setBorder(BorderFactory.createTitledBorder(null, "Player", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
				fieldPanel.setLayout(null);
				{
					p1pic = new JLabel();
					fieldPanel.add(p1pic);
					p1pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/frog1.gif")));
					p1pic.setBounds(15, 30, 125, 125);
				}
				{
					p2pic = new JLabel();
					fieldPanel.add(p2pic);
					p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/none.gif")));
					p2pic.setBounds(240, 30, 125, 125);
				}
				{
						vspic = new JLabel();
						fieldPanel.add(vspic);
						vspic.setIcon(new ImageIcon(getClass()
							.getClassLoader().getResource(
								"ui/images/info/versus.gif")));
						vspic.setBounds(144, 73, 86, 46);
				}
			}		
		tunnel = new TunnelServlet();
		p1char = 0;
		p2char = 1;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == exit){
			int result = JOptionPane.showConfirmDialog(null,"Are you want to exit form this room.","Warning !!!.", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
			if(result == JOptionPane.YES_OPTION){
				updateInside.stop();	
				String s;
				count = 0;
L1:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L1;
					}else{
						s = null;
						if(master)
							tunnel.sendObj("exitMasterRoom " + this.roomName + ":" + this.userName + ";");
						else
							tunnel.sendObj("exitSlaveRoom " + this.roomName + ":" + this.userName + ";");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("WaitRoomUI -> L1");
							tunnel.close();
							continue L1;
						}finally{
							tunnel.close();
						}
						if(s != null){
							break L1;
						}
					}
				}			

				count = 0;
L2:				while(count < timeout){
					count++;		
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L2;
					}else{
						s = null;
						tunnel.sendObj("idle " + this.userName + ":");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("WaitRoomUI -> L2");
							tunnel.close();
							continue L2;
						}finally{
							tunnel.close();
						}
						if(s != null){
							break L2;
						}
					}						
				}
				commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isExitRoom));	
			}
		}else if(event.getSource() == ready){
			if(!master){
				String s;
				count = 0;
L3:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L3;
					}else{
						s = null;
						if(ready.getText().equals("Ready")){
							ready.setText("Cancel");
							tunnel.sendObj("slaveReady " + this.roomName + ":");
						}else{
							ready.setText("Ready");
							tunnel.sendObj("slaveCancel " + this.roomName + ":");
						}				
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("WaitRoomUI -> L3");
							tunnel.close();
							continue L3;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(!s.equals("accept")){
								JOptionPane.showMessageDialog(null,"Can't go yet.");
							}	
							break L3;
						}
					}	
				}
			}else{
				String s;
				count = 0;
L4:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L4;
					}else{
						s = null;
						tunnel.sendObj("startSimulate " + this.roomName + ":" + this.userName + ";");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("WaitRoomUI -> L4");
							tunnel.close();
							continue L4;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(!s.equals("accept")){
								JOptionPane.showMessageDialog(null,"Can't play yet.");
							}	
							break L4;
						}
					}
				}
			}
		}else if(event.getSource() == selectFrog){
			if(master){
				p1char = 0;
			}else{
				p2char = 0;
			}
			setPlayerChar(master,0);
			setImage(master,0);
		}else if(event.getSource() == selectRat){
			if(master){
				p1char = 1;
			}else{
				p2char = 1;
			}
			setPlayerChar(master,1);
			setImage(master,1);
		}else if(event.getSource() == selectElephant){
			if(master){
				p1char = 2;
			}else{
				p2char = 2;
			}
			setPlayerChar(master,2);
			setImage(master,2);
		}else if(event.getSource() == selectPanda){
			if(master){
				p1char = 3;
			}else{
				p2char = 3;
			}
			setPlayerChar(master,3);
			setImage(master,3);
		}else if(event.getSource() == selectBird){
			if(master){
				p1char = 4;
			}else{
				p2char = 4;
			}
			setPlayerChar(master,4);
			setImage(master,4);
		}
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
	public void setMaster(boolean master){
		this.master = master;
		if(master){
			ready.setEnabled(false);
		}else{
			p2char = 1;
			selectRat.setSelected(true);
			setImage(master,p2char);
			ready.setEnabled(true);
		}
	}
	public void setUserName(String name){
		this.userName = name;
	}
	public void setRoomName(String roomName){
		this.roomName = roomName;
		fieldPanel.setBorder(BorderFactory.createTitledBorder(null, roomName, TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,0)));
		updateInside = new UpdateInsideRoomThread(this,roomName,userName);
		updateInside.start();		
	}
	public void setBackRoom(){
		updateInside.stop();
		updateInside = new UpdateInsideRoomThread(this,roomName,userName);
		updateInside.start();
	}
	public void updateInsideRoom(Vector insideChatRoom,boolean opponent,boolean start,boolean master,String opponentName,boolean status,int p1char,int p2char){
		if(!this.master && (master == true)){	
			ready.setText("Ready");
			ready.setEnabled(false);
		}
		this.p1char = p1char;
		this.p2char = p2char;
		this.opponentName = opponentName;
		this.master = master;
		this.opponent = opponent;
		setImage(true,p1char);	
		setImage(false,p2char);

		if(!start){ 
			chatArea.setListData(insideChatRoom);
			if(master)
				ready.setEnabled(opponent);
		}else{		// start simulate ,must stop simulate before
			if(master){
				String s;
				count = 0;
L5:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L5;
					}else{
						s = null;
						tunnel.sendObj("stopSimulate " + this.roomName + ":" + this.userName + ";");
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("WaitRoomUI -> L5");
							tunnel.close();
							continue L5;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(!s.equals("accept")){
			//					JOptionPane.showMessageDialog(null,"Can't play yet.");
								break L5;
							}
						}
					}		
				}			
				ready.setEnabled(false);
			}else{
				String s;
				count = 0;
L6:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L6;
					}else{
						ready.setText("Ready");
						s = null;
						tunnel.sendObj("slaveCancel " + this.roomName + ":");				
						try{
							s = (String) tunnel.receiveObj();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("WaitRoomUI -> L6");
							tunnel.close();
							continue L6;
						}finally{
							tunnel.close();
						}
						if(s != null){
							if(s.equals("accept")){
			//					JOptionPane.showMessageDialog(null,"Can't go yet.");
							}	
							break L6;
						}
					}	
				}		
			}			
			commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isStartViewResult));		
			updateInside.stop();						
		}
	}	
	public String getOpponentName(){
		return opponentName;
	}
	public boolean getMaster(){
		return master;
	}
	private void setImage(boolean master,int pchar){
		if(master){
			switch(pchar){
				case 0:	p1pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/frog1.gif")));	
						break;
				case 1: p1pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/rat1.gif")));
						break;
				case 2:	p1pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/elephant1.gif")));
						break;
				case 3: p1pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/panda1.gif")));
						break;
				case 4: p1pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/bird1.gif")));	
						break;
			}
		}else{
			switch(pchar){
			case 0:	p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/frog2.gif")));	
					break;
			case 1: p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/rat2.gif")));
					break;
			case 2:	p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/elephant2.gif")));
					break;
			case 3: p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/panda2.gif")));
					break;
			case 4: p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/bird2.gif")));	
					break;
			case 5:	p2pic.setIcon(new ImageIcon(getClass().getClassLoader().getResource("ui/images/lchar/none.gif")));	
					break;
			}
		}			
	}
	private void setPlayerChar(boolean master,int pchar){
		String s;
		count = 0;
L7:		while(count < timeout){
			count++;
			if(!tunnel.connect("ConcurrentServlet",TunnelServlet.OBJECT)){
				JOptionPane.showMessageDialog(null,"Can't connect to server.");
				break L7;
			}else{
				ready.setText("Ready");
				s = null;
				if(master)
					tunnel.sendObj("setP1Char " + this.roomName + ":" + Integer.toString(pchar) + ";");				
				else
					tunnel.sendObj("setP2Char " + this.roomName + ":" + Integer.toString(pchar) + ";");	
				try{
					s = (String) tunnel.receiveObj();
				}catch(Exception e){
					e.printStackTrace();
					System.out.println("WaitRoomUI -> L7");
					tunnel.close();
					continue L7;
				}finally{
					tunnel.close();
				}
				if(s != null){
					if(s.equals("accept")){
	//					JOptionPane.showMessageDialog(null,"Can't go yet.");
					}	
					break L7;
				}
			}	
		}		
	}
	public int getP1Char(){
		return p1char;
	}
	public int getP2Char(){
		return p2char;
	}
}
