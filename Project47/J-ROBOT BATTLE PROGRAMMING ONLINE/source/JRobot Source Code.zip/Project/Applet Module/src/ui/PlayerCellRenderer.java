package ui;

import java.awt.*;
import javax.swing.*;
import lib.*;

/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class PlayerCellRenderer extends JLabel implements ListCellRenderer{
	Icon ic[];
	int size;
	public PlayerCellRenderer(UserState state){
		size = state.size();
		ic = new Icon[size];
		setOpaque(true);
		for(int i=0;i<size;i++){
			ic[i] = getPicture(state.getState((String) state.elementAt(i)));
		}
	}
	public Component getListCellRendererComponent(JList list,Object value,int index,boolean isSelected,boolean cellHasFocus) {
		setText(value.toString());
		try{
			if(index < size){
				Icon icon = ic[index];
				setIcon(icon);
			}
		} catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}
		if(isSelected){
			setBackground(list.getSelectionBackground());
			setForeground(list.getSelectionForeground());
		} else{
			setBackground(list.getBackground());
			setForeground(list.getForeground());
		}
		return this;
	}	
	private Icon getPicture(String state){
		Icon icon = null; 
		if(state.equals(UserState.isIdle)){
			return new ImageIcon(getClass().getClassLoader().getResource("ui/images/info/idle.GIF"));
		} else if(state.equals(UserState.isModify)){
			return new ImageIcon(getClass().getClassLoader().getResource("ui/images/info/modify.GIF"));
		} else if(state.equals(UserState.isVS)){
			return new ImageIcon(getClass().getClassLoader().getResource("ui/images/info/vs.gif"));
		} else{
			return icon;
		}
	}
}
