package ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;

import lib.*;

import javax.swing.JButton;
/**
* This code was generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* *************************************
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED
* for this machine, so Jigloo or this code cannot be used legally
* for any corporate or commercial purpose.
* *************************************
*/
public class RegisterUI extends JPanel implements  CommunicateListener,ActionListener{

	{
		//Set Look & Feel
		try {
			javax.swing.UIManager.setLookAndFeel("com.sun.java.swing.plaf.motif.MotifLookAndFeel");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	private JLabel nameLabel;
	private JLabel passwordLabel1;
	private JLabel passwordLabel2;
	private JLabel emailLabel;
	private JTextField name;
	private JTextField email;
	private JPasswordField password1;
	private JPasswordField password2;
	private JButton back;
	private JButton testName;
	private JButton reset;
	private JButton ok;
	private CommunicateListener commu = null;
	private TestName testNamedlg;
	private TunnelServlet tunnel;
	private InfoScriptType it;
	private final int timeout = 5;
	private int count;

	public RegisterUI() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			this.setPreferredSize(new java.awt.Dimension(400, 237));
			this.setLayout(null);
			this.setBorder(BorderFactory.createTitledBorder(null, "Register", TitledBorder.LEADING, TitledBorder.TOP, new java.awt.Font("Dialog",0,12), new java.awt.Color(0,0,255)));
			{
				nameLabel = new JLabel();
				this.add(nameLabel);
				nameLabel.setText("Name");
				nameLabel.setBounds(30, 24, 60, 30);
			}
			{
				passwordLabel1 = new JLabel();
				this.add(passwordLabel1);
				passwordLabel1.setText("Password");
				passwordLabel1.setBounds(30, 64, 60, 30);
			}
			{
				passwordLabel2 = new JLabel();
				this.add(passwordLabel2);
				passwordLabel2.setText("Confirm password");
				passwordLabel2.setBounds(30, 104, 114, 30);
			}
			{
				emailLabel = new JLabel();
				this.add(emailLabel);
				emailLabel.setText("Email address");
				emailLabel.setBounds(30, 144, 100, 30);
			}
			{
				name = new JTextField();
				this.add(name);
				name.setBounds(150, 24, 130, 25);
				name.setEditable(false);
			}
			{
				email = new JTextField();
				this.add(email);
				email.setBounds(150, 144, 130, 25);
			}
			{
				password1 = new JPasswordField();
				this.add(password1);
				password1.setBounds(150, 64, 130, 25);
			}
			{
				password2 = new JPasswordField();
				this.add(password2);
				password2.setBounds(150, 104, 130, 25);
			}
			{
				testName = new JButton();
				this.add(testName);
				testName.setText("Test Name");
				testName.setBounds(290, 16, 90, 40);
				testName.addActionListener(this);
			}
			{
				ok = new JButton();
				this.add(ok);
				ok.setText("Confirm");
				ok.setBounds(60, 180, 90, 40);
				ok.addActionListener(this);
			}
			{
				reset = new JButton();
				this.add(reset);
				reset.setText("Reset");
				reset.setBounds(160, 180, 90, 40);
				reset.addActionListener(this);
			}
			{
				back = new JButton();
				this.add(back);
				back.setText("Back");
				back.setBounds(260, 180, 90, 40);
				back.addActionListener(this);
			}
			testNamedlg = new TestName();
			testNamedlg.setModal(true);
			testNamedlg.setVisible(false);
			testNamedlg.addCommunicateEvent(this);
			
			tunnel = new TunnelServlet();
			it = new InfoScriptType();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void actionPerformed(ActionEvent event) {
		if(event.getSource() == ok){
			boolean flag = true;
			StringBuffer str = new StringBuffer();
			if(name.getText().equals("")){
				str.append("Name not spacify.\n");
				flag = false;
			}
			if(password1.getText().equals("")||password2.getText().equals("")){
				str.append("Password not spacify.\n");
				flag = false;
			}
			if(!(password1.getText().equals(password2.getText()))){
				str.append("Password not equivalent.\n");		
				flag = false;		
			}
			if(email.getText().equals("")){
				str.append("Email not spacify.");		
				flag = false;		
			}
			if(flag){
				String s = null;
				String s1 = null;
				count = 0;
				int count2 = 0;
L1:				while(count < timeout){
					count++;
					if(!tunnel.connect("ConnectionServlet",TunnelServlet.TEXT)){
						JOptionPane.showMessageDialog(null,"Can't connect to server.");
						break L1;
					}else{
						tunnel.send("register " + name.getText() + ":" + password1.getText() +
								";" + email.getText() + "/");
						try{
							s = tunnel.receive();
						}catch(Exception e){
							e.printStackTrace();
							System.out.println("RegisterUI -> L1");
							tunnel.close();
							continue L1;
						}finally{
							tunnel.close();
						}
						if(s!=null){
							if(s.equals("confirm")){
L2:								while(count2 < timeout){
									count2++;
									if(!tunnel.connect("ManageScriptServlet",TunnelServlet.OBJECT)){
										JOptionPane.showMessageDialog(null,"Can't connect to server.");
										break L2;
									}else{
										it.header = new String("register");
										it.name = name.getText();
										s1 = null;
										tunnel.sendObj(it);
										try{
											s1 = (String) tunnel.receiveObj();
										}catch(Exception e){
											e.printStackTrace();
											System.out.println("RegisterUI -> L2");
											tunnel.close();
											continue L2;
										}finally{
											tunnel.close();
										}
										if(s1 != null){											
											if(s1.equals("confirm")){					
												JOptionPane.showMessageDialog(null,"Thanks for register.");
												name.setText(null);
												password1.setText(null);
												password2.setText(null);
												email.setText(null);
												commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isConfirmRegister));
											}
											break L2;
										}
									}
								}
							}
							break L1;
						}
					}
				}
			}else{
				JOptionPane.showMessageDialog(null,str);
			}
		}else if(event.getSource() == testName){
			testNamedlg.setVisible(true);
		}else if(event.getSource() == reset){
			name.setText(null);
			password1.setText(null);
			password2.setText(null);
			email.setText(null);
		}else if(event.getSource() == back){
			name.setText(null);
			password1.setText(null);
			password2.setText(null);
			email.setText(null);
			commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isCancel));
		}
	}
	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}

	public void CommunicateAction(CommunicateEvent event) {
		if(event.getState() == CommunicateEvent.isConfirmName){
			testNamedlg.setVisible(false);
			name.setText(testNamedlg.Name);
		}
	}
}
