/*
 * Created on 3 �.�. 2548
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package ui;

import lib.CommunicateEvent;
import lib.CommunicateListener;



/**
 * @author Nopporn
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class AssistControl extends Thread {
	private MyCanvas canvas;
	private CommunicateListener commu = null;
	public AssistControl(MyCanvas canvas){
		this.canvas = canvas;
	}
	public void run(){
		System.out.println("run tct.");
		switch(canvas.mode){
		case 2:	canvas.setImage(0);
				canvas.repaint();
				try {
					sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}	
				canvas.setImage(1);
				canvas.repaint();
				try {
					sleep(800);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}	
				commu.CommunicateAction(new CommunicateEvent(this,CommunicateEvent.isStartFighting));
				break;
		
		}
}

	public void addCommunicateEvent(CommunicateListener commu){
		if(this.commu == null){
			this.commu = commu;
		}
	}
}
