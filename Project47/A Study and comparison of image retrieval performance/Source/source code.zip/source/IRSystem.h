/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#pragma once
#include "Image.h"
#include <time.h>
#include "ASock.h"

class IRSystem
{
public:
	Image resizeImage;
	Image targetImage;
	CString* inputFileName;
	int numFileName;
	CString filePath;
	CString seq;
	BOOL filter;
	CString startTime;
	CString endTime;
	CString resultTime;
	int indexInCorrect;
	int indexCorrect;
	CString* resultFileName;
	int len_seq1;
	int len_seq2;
	int len_seq3;
	bool distribute;
//=================== Network Variable  =========================
	CString sendData;
	CString receiveData;
	int receiveSize;
	// ============== Slave Mode =========================
	bool m_bConnectFlag;	// if have accept m_bConnectFlag is true	
	CASock slave_connSock; //for accept function(slave)
	CASock slave_listenSock;
	CString m_strSlaveIP;
	int m_strSlavePort;
	// ============== Master Mode =========================
	int m_intCountSentByte;	// number of byte which are send		
	CASock master_connSock;// for accept function(master)
	CString m_strMasterIP;
	int m_intMasterPort;
public:
	IRSystem(void);
	~IRSystem(void);
	bool OpenImage(CString* fileName);
	void SetMethod(CString pattern);
	void SetAlgorithm(BOOL algor);
	CString StartRetrieval(int selInput);
	int FindAllImage(CString key);
	void RetrieveAlone(int** allHistogram,int** allFourier,int** allGabor,int* correct,int* inCorrect);
	void RetrieveDistribute(int** allHistogram,int** allFourier,int** allGabor,int* correct,int* inCorrect);
	void DoRetrieve(CRecordset &rs,int startRow,int endRow,int* correct,int* inCorrect,int** allHistogram,int** allFourier,int** allGabor,CString patten);
	void GetFeature2Form(int sub,int** allHistogram,int** allFourier,int** allGabor);
	bool Compare(char feature,int liker,CString* value1,int* value2,int num);
	bool CheckImage(void);
	void FindImageFeatureForStore(void);
	void FindImageFeatureForRetrieval(CString seq);
	CString FindKey(void);
	CString StartStore();
	void GetFeatureStrValue(int subNo,CString& histogramStr,CString& fourierStr,CString& gaborStr);
	void StoreResult(int* correct,int indexCorrect);
	void SetCurrentTime(char type);

	void ConnDB(CDatabase &myDB);
	void DisConnDB(CDatabase &myDB);

	// === for network ===
	bool SlaveListen();
	void SlaveClose();
	void SlaveAccept();
	void SlaveReceive(CString buffData);
	void SlaveSend(CString data);
	void SlaveProcess();
	void MasterClose();
	void MasterOnConnect();
	void MasterConnected();
	void MasterSend(CString dataForSend);
	void MasterReceive(CString buffData);
	void MasterProcess();
};
