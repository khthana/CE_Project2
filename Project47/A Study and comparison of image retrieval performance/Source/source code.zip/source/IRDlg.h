/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
// IRDlg.h : header file

#pragma once
#include "afxwin.h"
#include "IRSystem.h"

// CIRDlg dialog
class CIRDlg : public CDialog
{
// Construction
public:
	CIRDlg(CWnd* pParent = NULL);	// standard constructor

							//	virtual void~CIRDlg();

// Dialog Data
	enum { IDD = IDD_IR_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnClickImageOpen();
	afx_msg void OnClickImageStore();
	afx_msg void OnClickImageRetrieve();
	afx_msg void OnBnClickedCheckAlgor();
	afx_msg void OnBnClickedResetResult();
	afx_msg void OnBnClickedNormalimage();
	afx_msg void OnBnClickedGrayimage();
	afx_msg void OnBnClickedEdgeimage();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnCbnSelchangeSeq1();
	afx_msg void OnCbnSelchangeSeq2();
	afx_msg void OnCbnSelchangeSeq3();
	afx_msg void OnEnChangeLenSeq1();
	afx_msg void OnEnChangeLenSeq2();
	afx_msg void OnEnChangeLenSeq3();
	void ShowPicture(HBITMAP m_hBmpNew);
	afx_msg void OnLbnDblclkShowOutput();
	afx_msg void OnLbnDblclkShowInput();
	afx_msg void OnBnClickedCheck1();
	afx_msg void OnBnClickedSlaveMode();
	afx_msg void OnBnClickedMasterMode();
	afx_msg void OnBnClickedZoomIn();
	afx_msg void OnBnClickedZoomOut();
public:
	CComboBox m_comboSeq1;
	CComboBox m_comboSeq2;
	CComboBox m_comboSeq3;
	CButton m_searchAlgor;
	CButton distributeButton;
public:
	IRSystem* system;
//============= for show in picture control ====================
public:
	CStatic m_picture;
    CRect rectStaticClient;
    int sourcex, sourcey,offsetx,offsety;
	SCROLLINFO horz,vert;
	CSize m_size;
	CPoint m_pt;            // Position for upper left corner of bitmap
	bool erase;
	bool m_filter;
protected:
    CDC m_dcMem;            // Compatible Memory DC for dialog
    HBITMAP m_hBmpOld;    // Handle of old bitmap to save
    HBITMAP m_hBmpNew;    // Handle of new bitmap from file
    BITMAP m_bmInfo;        // Bitmap Information structure

public:
	CScrollBar m_vbar;
	CScrollBar m_hbar;
//===============================================================
public:
	CString m_strShow;
	CButton m_ResetButton;
	CButton m_StoreButton;
	CButton m_RetrieveButton;
	CButton m_ChooseButton;

	int m_len_seq1;
	int m_len_seq2;
	int m_len_seq3;

	CListBox m_show_output;
	CListBox m_show_input;
	int selInput;
	int selOutput;
	bool focusInput;
	bool focusOutput;

	bool m_distribute;
	bool m_masterMode;
	bool m_slaveMode;
	
};
