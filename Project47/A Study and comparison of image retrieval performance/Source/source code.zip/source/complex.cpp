/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#include "StdAfx.h"
#include "complex.h"

complex::complex(void)
{
	real=0;imagin=0;
}

complex::~complex(void)
{
}

double complex::Abs(void)
{
	return sqrt(pow(real,2)+(pow(imagin,2)));
}	

void complex::Conj(void)
{
	imagin=-imagin;
}