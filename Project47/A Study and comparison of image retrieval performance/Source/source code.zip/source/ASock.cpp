/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
// ASock.cpp : implementation file
//

#include "stdafx.h"
#include "IR.h"
#include "ASock.h"

#include "IRDlg.h"

// CASock

CASock::CASock()
{
}

CASock::~CASock()
{
}

void CASock::OnAccept(int nErrorCode)
{
	if(nErrorCode ==0)((CIRDlg*)m_pDwnd)->system->SlaveAccept();
	CAsyncSocket::OnAccept(nErrorCode);
}

void CASock::OnClose(int nErrorCode)
{
	if(nErrorCode==0)((CIRDlg*)m_pDwnd)->system->MasterClose();
	CAsyncSocket::OnClose(nErrorCode);
}

void CASock::OnReceive(int nErrorCode)
{
	CString strRecvMsg;
	char buffer[maxRecChar];
	int nRecv;
	nRecv = Receive(buffer,maxRecChar);// for receive data from socket

	switch(nRecv){		
		// close connection
		case 0 :  Close(); break;	
		// Error occurred
		case SOCKET_ERROR : if(GetLastError() != WSAEWOULDBLOCK)	
							{AfxMessageBox("Error occurred!!!");Close();}break;
		// Receive data
		default :	buffer[nRecv] = NULL;// put "\0" in end of message
					CString strTemp(buffer);					
					if(((CIRDlg*)m_pDwnd)->m_masterMode){((CIRDlg*)m_pDwnd)->system->MasterReceive(strTemp);}// select master mode
					else {((CIRDlg*)m_pDwnd)->system->SlaveReceive(strTemp);}//select slave mode
	}
	CAsyncSocket::OnReceive(nErrorCode);	
}

void CASock::OnConnect(int nErrorCode)
{
	if(0 != nErrorCode){
		switch(nErrorCode){
			case WSAEADDRINUSE : AfxMessageBox("IP Address is already used");	break;
			case WSAEADDRNOTAVAIL : AfxMessageBox("IP Address is busy");			break;
			case WSAECONNREFUSED : AfxMessageBox("Try to connect,but server reject");break;
			case WSAEDESTADDRREQ : AfxMessageBox("Want destitation IP Address");break;
			case WSAEISCONN : AfxMessageBox("Socket is already connected");		break;
			case WSAENETUNREACH : AfxMessageBox("Network can't find path to reach host");break;
			case WSAENOBUFS : AfxMessageBox("No buffer of full buffer,Socket is't connected");break;
			case WSAENOTCONN : AfxMessageBox("Socket is't connected");	break;
			case WSAETIMEDOUT : AfxMessageBox("Try to connect,but can't");	break;
			default : 
				char strError[256];
				wsprintf(strError,"Connect error,Error Code:%d",nErrorCode);
				AfxMessageBox(strError);
				break;
		}
		//AfxMessageBox("Please try again");
	}
	else ((CIRDlg*)m_pDwnd)->system->MasterConnected();
	CAsyncSocket::OnConnect(nErrorCode);
}

void CASock::SetParent(CDialog* pDwnd)
{
	m_pDwnd = pDwnd;
}

// CASock member functions
