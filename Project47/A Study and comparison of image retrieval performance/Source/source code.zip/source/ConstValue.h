/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
// about retrieval
#define maxOpenFile 1000			// number of open file for store
#define maxCharOpen 200000			// number of char for file open dialog box

#define DBUser "IRApp"				// user account in database 
#define DBPass "irapp"				// password account in database
#define DBName "FeatureImageDB"		// database name
//#define DBName "FeatureImageDB_test"
#define ImageFeatureTable "ImageFeature"	// table name
#define ImageFeatureField "ImgNo,SubImg,Histogram,Fourier,Gabor"	// sequence of sql string for store
#define IdentityImageTable "Identifier"		// table name
#define IdentityImageField "ImgName,KeyValue"	// sequence of sql string for store
#define notUsed 1200				// number of incorrect image
#define used 20						// number of correct image
#define strFilter "BMPs  (*.bmp)|*.bmp|GIFs  (*.gif)|*.gif|JPEGs  (*.jpg)|*.jpg;*.jpeg "	// type of image for open

// Constant about ReSizing
#define maxWidthImage 768			// max width of image
#define maxHeightImage 768			// max height of image

// Constant about "Histogram"
#define numHistogram 216			// level of color
#define samplingSpace 43			// use for histogram partition

// Constant about "Fourier"
#define numFourierDesc 512			// number of pixel which is line
#define sobelX {1,2,1,0,0,0,-1,-2,-1}//	mask => sobel
#define sobelY {1,0,-1,2,0,-2,1,0,-1}//	mask => sobel
#define filterEdge 215				// ts for detect line

// Constant about "Gabor"
#define numGaborDesc 8				// number of gabor descriptor
#define scale 2						// number of scale(low feq. & high feq.)
#define orientation 2				// number of orientation(ver. line & hor. line)
#define gaborMaskSizeX 60			// mask size
#define gaborMaskSizeY 60			// mask size
#define ul 0.05						// const. Ul
#define uh 0.4						// const. Uh
#define pi 3.1415926535				// const. pi
#define e 2.718281828				// const. e

// Network
#define portConn 1313					// port for connection
#define slaveIP "161.246.5.105"//161.246.5.106"
#define maxRecChar 5000			// recieve data
// Zoom
#define ratioZoom 0.8