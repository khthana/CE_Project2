/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#include "StdAfx.h"
#include "pixelcomplex.h"

PixelComplex::PixelComplex(void)
{
	pixel.real=0;
	pixel.imagin=0;
	color=0;
}

PixelComplex::~PixelComplex(void)
{
	//delete this;
}
