/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#include "StdAfx.h"
#include "Image.h"

Image::Image(void){}

Image::~Image(void)
{
	if(sub0)sub0.Destroy();
	if(sub1)sub1.Destroy();
	if(sub2)sub2.Destroy();
	if(sub3)sub3.Destroy();
	if(sub4)sub4.Destroy();
	if(sub5)sub5.Destroy();
	if(sub6)sub6.Destroy();
	if(sub7)sub7.Destroy();
	if(sub8)sub8.Destroy();
}

void Image::Histogram(void)
{
	DoHistogram(sub0);
	DoHistogram(sub1);
	DoHistogram(sub2);
	DoHistogram(sub3);
	DoHistogram(sub4);
	DoHistogram(sub5);
	DoHistogram(sub6);
	DoHistogram(sub7);
	DoHistogram(sub8);
}
void Image::OnlyKeyHistogram(void)
{
	DoHistogram(sub2);
	DoHistogram(sub4);
	DoHistogram(sub6);
}
void Image::Fourier(void)
{
	DoFourier(sub0);
	DoFourier(sub1);
	DoFourier(sub2);
	DoFourier(sub3);
	DoFourier(sub4);
	DoFourier(sub5);
	DoFourier(sub6);
	DoFourier(sub7);
	DoFourier(sub8);
}
void Image::Gabor(void)
{
 	DoGabor(sub0);
 	DoGabor(sub1);
	DoGabor(sub2);
	DoGabor(sub3);
	DoGabor(sub4);
	DoGabor(sub5);
	DoGabor(sub6);
	DoGabor(sub7);
	DoGabor(sub8);
}

void Image::DoHistogram(CPImage& subImage)
{
	for(int i=0 ; i<numHistogram ; i++){subImage.histogram[i]=0;}
	Quantization(subImage);	// Quantization subImage
	Normalize(subImage);	// Normalize subImage
}

void Image::Quantization(CPImage& subImage)
{
	int maxWidth = subImage.GetWidth();	
	int maxHight = subImage.GetHeight();
	COLORREF srcColor=0;
	int red,green,blue;
	for (int y=0 ; y<maxHight ; y++) // scan axis y
	{	for (int x=0 ; x<maxWidth ; x++) // scan axis x
		{
			srcColor=subImage.GetColor(x,y);
			red=(int)GetRValue(srcColor);
			green=(int)GetGValue(srcColor);
			blue=(int)GetBValue(srcColor);

			red=(int)(red/samplingSpace);
			green=(int)(green/samplingSpace);
			blue=(int)(blue/samplingSpace);

			if (red==0)	{
				if (green==0)	{
					if (blue==0)		subImage.histogram[0]++;
					else if (blue==1)subImage.histogram[1]++;
					else if (blue==2)subImage.histogram[2]++;
					else if (blue==3)subImage.histogram[3]++;
					else if (blue==4)subImage.histogram[4]++;
					else if (blue==5)subImage.histogram[5]++;	}
				else if (green==1){
					if (blue==0)		subImage.histogram[6]++;
					else if (blue==1)subImage.histogram[7]++;
					else if (blue==2)subImage.histogram[8]++;
					else if (blue==3)subImage.histogram[9]++;
					else if (blue==4)subImage.histogram[10]++;
					else if (blue==5)subImage.histogram[11]++;	}						
				else if (green==2){						
					if (blue==0)		subImage.histogram[12]++;
					else if (blue==1)subImage.histogram[13]++;
					else if (blue==2)subImage.histogram[14]++;
					else if (blue==3)subImage.histogram[15]++;
					else if (blue==4)subImage.histogram[16]++;
					else if (blue==5)subImage.histogram[17]++;	}						
				else if (green==3){						
					if (blue==0)		subImage.histogram[18]++;
					else if (blue==1)subImage.histogram[19]++;
					else if (blue==2)subImage.histogram[20]++;
					else if (blue==3)subImage.histogram[21]++;
					else if (blue==4)subImage.histogram[22]++;
					else if (blue==5)subImage.histogram[23]++;	}						
				else if (green==4){						
					if (blue==0)		subImage.histogram[24]++;
					else if (blue==1)subImage.histogram[25]++;
					else if (blue==2)subImage.histogram[26]++;
					else if (blue==3)subImage.histogram[27]++;
					else if (blue==4)subImage.histogram[28]++;
					else if (blue==5)subImage.histogram[29]++;	}						
				else if (green==5){							
					if (blue==0)		subImage.histogram[30]++;
					else if (blue==1)subImage.histogram[31]++;
					else if (blue==2)subImage.histogram[32]++;
					else if (blue==3)subImage.histogram[33]++;
					else if (blue==4)subImage.histogram[34]++;
					else if (blue==5)subImage.histogram[35]++;	}						
			}							
			else if (red==1){							
				if (green==0)	{						
					if (blue==0)		subImage.histogram[36]++;
					else if (blue==1)subImage.histogram[37]++;
					else if (blue==2)subImage.histogram[38]++;
					else if (blue==3)subImage.histogram[39]++;
					else if (blue==4)subImage.histogram[40]++;
					else if (blue==5)subImage.histogram[41]++;	}						
				else if (green==1){							
					if (blue==0)		subImage.histogram[42]++;
					else if (blue==1)subImage.histogram[43]++;
					else if (blue==2)subImage.histogram[44]++;
					else if (blue==3)subImage.histogram[45]++;
					else if (blue==4)subImage.histogram[46]++;
					else if (blue==5)subImage.histogram[47]++;	}						
				else if (green==2){						
					if (blue==0)		subImage.histogram[48]++;
					else if (blue==1)subImage.histogram[49]++;
					else if (blue==2)subImage.histogram[50]++;
					else if (blue==3)subImage.histogram[51]++;
					else if (blue==4)subImage.histogram[52]++;
					else if (blue==5)subImage.histogram[53]++;	}						
				else if (green==3){							
					if (blue==0)		subImage.histogram[54]++;
					else if (blue==1)subImage.histogram[55]++;
					else if (blue==2)subImage.histogram[56]++;
					else if (blue==3)subImage.histogram[57]++;
					else if (blue==4)subImage.histogram[58]++;
					else if (blue==5)subImage.histogram[59]++;	}						
				else if (green==4){						
					if (blue==0)		subImage.histogram[60]++;
					else if (blue==1)subImage.histogram[61]++;
					else if (blue==2)subImage.histogram[62]++;
					else if (blue==3)subImage.histogram[63]++;
					else if (blue==4)subImage.histogram[64]++;
					else if (blue==5)subImage.histogram[65]++;	}						
				else if (green==5){							
					if (blue==0)		subImage.histogram[66]++;
					else if (blue==1)subImage.histogram[67]++;
					else if (blue==2)subImage.histogram[68]++;
					else if (blue==3)subImage.histogram[69]++;
					else if (blue==4)subImage.histogram[70]++;
					else if (blue==5)subImage.histogram[71]++;	}						
			}							
			else if (red==2){							
				if (green==0)	{						
					if (blue==0)		subImage.histogram[72]++;
					else if (blue==1)subImage.histogram[73]++;
					else if (blue==2)subImage.histogram[74]++;
					else if (blue==3)subImage.histogram[75]++;
					else if (blue==4)subImage.histogram[76]++;
					else if (blue==5)subImage.histogram[77]++;	}						
				else if (green==1){							
					if (blue==0)		subImage.histogram[78]++;
					else if (blue==1)subImage.histogram[79]++;
					else if (blue==2)subImage.histogram[80]++;
					else if (blue==3)subImage.histogram[81]++;
					else if (blue==4)subImage.histogram[82]++;
					else if (blue==5)subImage.histogram[83]++;	}						
				else if (green==2){						
					if (blue==0)		subImage.histogram[84]++;
					else if (blue==1)subImage.histogram[85]++;
					else if (blue==2)subImage.histogram[86]++;
					else if (blue==3)subImage.histogram[87]++;
					else if (blue==4)subImage.histogram[88]++;
					else if (blue==5)subImage.histogram[89]++;	}						
				else if (green==3){							
					if (blue==0)		subImage.histogram[90]++;
					else if (blue==1)subImage.histogram[91]++;
					else if (blue==2)subImage.histogram[92]++;
					else if (blue==3)subImage.histogram[93]++;
					else if (blue==4)subImage.histogram[94]++;
					else if (blue==5)subImage.histogram[95]++;	}						
				else if (green==4){						
					if (blue==0)		subImage.histogram[96]++;
					else if (blue==1)subImage.histogram[97]++;
					else if (blue==2)subImage.histogram[98]++;
					else if (blue==3)subImage.histogram[99]++;
					else if (blue==4)subImage.histogram[100]++;
					else if (blue==5)subImage.histogram[101]++;	}						
				else if (green==5){							
					if (blue==0)		subImage.histogram[102]++;
					else if (blue==1)subImage.histogram[103]++;
					else if (blue==2)subImage.histogram[104]++;
					else if (blue==3)subImage.histogram[105]++;
					else if (blue==4)subImage.histogram[106]++;
					else if (blue==5)subImage.histogram[107]++;	}						
			}							
			else if (red==3){							
				if (green==0)	{						
					if (blue==0)		subImage.histogram[108]++;
					else if (blue==1)subImage.histogram[109]++;
					else if (blue==2)subImage.histogram[110]++;
					else if (blue==3)subImage.histogram[111]++;
					else if (blue==4)subImage.histogram[112]++;
					else if (blue==5)subImage.histogram[113]++;	}						
				else if (green==1){							
					if (blue==0)		subImage.histogram[114]++;
					else if (blue==1)subImage.histogram[115]++;
					else if (blue==2)subImage.histogram[116]++;
					else if (blue==3)subImage.histogram[117]++;
					else if (blue==4)subImage.histogram[118]++;
					else if (blue==5)subImage.histogram[119]++;	}						
				else if (green==2){							
					if (blue==0)		subImage.histogram[120]++;
					else if (blue==1)subImage.histogram[121]++;
					else if (blue==2)subImage.histogram[122]++;
					else if (blue==3)subImage.histogram[123]++;
					else if (blue==4)subImage.histogram[124]++;
					else if (blue==5)subImage.histogram[125]++;	}						
				else if (green==3){							
					if (blue==0)		subImage.histogram[126]++;
					else if (blue==1)subImage.histogram[127]++;
					else if (blue==2)subImage.histogram[128]++;
					else if (blue==3)subImage.histogram[129]++;
					else if (blue==4)subImage.histogram[130]++;
					else if (blue==5)subImage.histogram[131]++;	}						
				else if (green==4){							
					if (blue==0)		subImage.histogram[132]++;
					else if (blue==1)subImage.histogram[133]++;
					else if (blue==2)subImage.histogram[134]++;
					else if (blue==3)subImage.histogram[135]++;
					else if (blue==4)subImage.histogram[136]++;
					else if (blue==5)subImage.histogram[137]++;	}						
				else if (green==5){							
					if (blue==0)		subImage.histogram[138]++;
					else if (blue==1)subImage.histogram[139]++;
					else if (blue==2)subImage.histogram[140]++;
					else if (blue==3)subImage.histogram[141]++;
					else if (blue==4)subImage.histogram[142]++;
					else if (blue==5)subImage.histogram[143]++;	}						
			}							
			else if (red==4){
				if (green==0)	{
					if (blue==0)		subImage.histogram[144]++;
					else if (blue==1)subImage.histogram[145]++;
					else if (blue==2)subImage.histogram[146]++;
					else if (blue==3)subImage.histogram[147]++;
					else if (blue==4)subImage.histogram[148]++;
					else if (blue==5)subImage.histogram[149]++;	}						
				else if (green==1){							
					if (blue==0)		subImage.histogram[150]++;
					else if (blue==1)subImage.histogram[151]++;
					else if (blue==2)subImage.histogram[152]++;
					else if (blue==3)subImage.histogram[153]++;
					else if (blue==4)subImage.histogram[154]++;
					else if (blue==5)subImage.histogram[155]++;	}						
				else if (green==2){							
					if (blue==0)		subImage.histogram[156]++;
					else if (blue==1)subImage.histogram[157]++;
					else if (blue==2)subImage.histogram[158]++;
					else if (blue==3)subImage.histogram[159]++;
					else if (blue==4)subImage.histogram[160]++;
					else if (blue==5)subImage.histogram[161]++;	}						
				else if (green==3){							
					if (blue==0)		subImage.histogram[162]++;
					else if (blue==1)subImage.histogram[163]++;
					else if (blue==2)subImage.histogram[164]++;
					else if (blue==3)subImage.histogram[165]++;
					else if (blue==4)subImage.histogram[166]++;
					else if (blue==5)subImage.histogram[167]++;	}						
				else if (green==4){							
					if (blue==0)		subImage.histogram[168]++;
					else if (blue==1)subImage.histogram[169]++;
					else if (blue==2)subImage.histogram[170]++;
					else if (blue==3)subImage.histogram[171]++;
					else if (blue==4)subImage.histogram[172]++;
					else if (blue==5)subImage.histogram[173]++;	}						
				else if (green==5){							
					if (blue==0)		subImage.histogram[174]++;
					else if (blue==1)subImage.histogram[175]++;
					else if (blue==2)subImage.histogram[176]++;
					else if (blue==3)subImage.histogram[177]++;
					else if (blue==4)subImage.histogram[178]++;
					else if (blue==5)subImage.histogram[179]++;	}						
			}							
			else if (red==5){
				if (green==0)	{
					if (blue==0)		subImage.histogram[180]++;
					else if (blue==1)subImage.histogram[181]++;
					else if (blue==2)subImage.histogram[182]++;
					else if (blue==3)subImage.histogram[183]++;
					else if (blue==4)subImage.histogram[184]++;
					else if (blue==5)subImage.histogram[185]++;	}						
				else if (green==1){							
					if (blue==0)		subImage.histogram[186]++;
					else if (blue==1)subImage.histogram[187]++;
					else if (blue==2)subImage.histogram[188]++;
					else if (blue==3)subImage.histogram[189]++;
					else if (blue==4)subImage.histogram[190]++;
					else if (blue==5)subImage.histogram[191]++;	}
				else if (green==2){			
					if (blue==0)		subImage.histogram[192]++;
					else if (blue==1)subImage.histogram[193]++;
					else if (blue==2)subImage.histogram[194]++;
					else if (blue==3)subImage.histogram[195]++;
					else if (blue==4)subImage.histogram[196]++;
					else if (blue==5)subImage.histogram[197]++;	}						
				else if (green==3){							
					if (blue==0)		subImage.histogram[198]++;
					else if (blue==1)subImage.histogram[199]++;
					else if (blue==2)subImage.histogram[200]++;
					else if (blue==3)subImage.histogram[201]++;
					else if (blue==4)subImage.histogram[202]++;
					else if (blue==5)subImage.histogram[203]++;	}						
				else if (green==4){							
					if (blue==0)		subImage.histogram[204]++;
					else if (blue==1)subImage.histogram[205]++;
					else if (blue==2)subImage.histogram[206]++;
					else if (blue==3)subImage.histogram[207]++;
					else if (blue==4)subImage.histogram[208]++;
					else if (blue==5)subImage.histogram[209]++;	}						
				else if (green==5){							
					if (blue==0)		subImage.histogram[210]++;
					else if (blue==1)subImage.histogram[211]++;
					else if (blue==2)subImage.histogram[212]++;
					else if (blue==3)subImage.histogram[213]++;
					else if (blue==4)subImage.histogram[214]++;
					else if (blue==5)subImage.histogram[215]++;	}
			}
		}	
	}
}
void Image::Normalize(CPImage& subImage)
{
	int allPix = (subImage.GetHeight())*(subImage.GetWidth());
	for (int i=0 ; i<numHistogram ; i++){subImage.histogram[i] = (subImage.histogram[i]/allPix)*100;}
}

void Image::DoFourier(CPImage& subImage)
{
	for(int i=0 ; i<numFourierDesc ; i++){subImage.fourierDesc[i]=0;}
	int h=subImage.GetHeight();
	int w=subImage.GetWidth();
	
	PixelComplex* edge=new PixelComplex[numFourierDesc];
	EdgeDetector(subImage,edge);//{(c1,x1,y1),(c2,x2,y2),(c3,x3,y3),...(cn,xn,yn)}
	FindFourierDesc(subImage,edge);
	delete[] edge;
}

void Image::EdgeDetector(CPImage& subImage,PixelComplex* edge)
{
	int width = subImage.GetWidth();
	int height = subImage.GetHeight();
	int maskX[9]=sobelX;
	int maskY[9]=sobelY;
	double avgUL,avgU,avgUR,avgCL,avgC,avgCR,avgBL,avgB,avgBR;
	double src[9];
	double tmp;
	int index=0;
	
	for (int y=0 ; y<height ; y++){
		for (int x=0 ; x<width ; x++){
			avgC=subImage.GetGray(x,y);
			if (y==0 && x==0){}
			else if (y==0 && x==(width-1)){								
				/* ====== No ====== */			/* ====== No ====== */			/* ====== No ====== */
				avgCL=subImage.GetGray(x-1,y);									/* ====== No ====== */
				avgBL=subImage.GetGray(x-1,y+1); avgB=subImage.GetGray(x,y+1);	/* ====== No ====== */

				src[0]=0;	src[1]=0;	src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=0;
				src[6]=avgBL;	src[7]=avgB;	src[8]=0;
			}
			else if (y==(height-1) && x==0){
				/* ====== No ====== */	avgU=subImage.GetGray(x,y-1); avgUR=subImage.GetGray(x+1,y-1);
				/* ====== No ====== */								  avgCR=subImage.GetGray(x+1,y);
				/* ====== No ====== */	/* ====== No ====== */		  /* ====== No ====== */

				src[0]=0;	src[1]=avgU;	src[2]=avgUR;
				src[3]=0;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;	src[7]=0;	src[8]=0;
			}
			else if (y==(height-1) && x==(width-1)){
				avgUL=subImage.GetGray(x-1,y-1); avgU=subImage.GetGray(x,y-1);	/* ====== No ====== */
				avgCL=subImage.GetGray(x-1,y);									/* ====== No ====== */
				/* ====== No ====== */			/* ====== No ====== */			/* ====== No ====== */

				src[0]=avgUL;	src[1]=avgU;	src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=0;
				src[6]=0;	src[7]=0;	src[8]=0;							  
			}
			else if (y==0){
				/* ====== No ====== */			/* ====== No ====== */			/* ====== No ====== */
				avgCL=subImage.GetGray(x-1,y);								   avgCR=subImage.GetGray(x+1,y);
				avgBL=subImage.GetGray(x-1,y+1); avgB=subImage.GetGray(x,y+1); avgBR=subImage.GetGray(x+1,y+1);
			
				src[0]=0;	src[1]=0;	src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=avgCR;
				src[6]=avgBL;	src[7]=avgB;	src[8]=avgBR;
			}
			else if (y==(height-1)){
				avgUL=subImage.GetGray(x-1,y-1); avgU=subImage.GetGray(x,y-1); avgUR=subImage.GetGray(x+1,y-1);
				avgCL=subImage.GetGray(x-1,y);								   avgCR=subImage.GetGray(x+1,y);
				/* ====== No ====== */			/* ====== No ====== */			/* ====== No ====== */

				src[0]=avgUL;	src[1]=avgU;	src[2]=avgUR;
				src[3]=avgCL;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;	src[7]=0;	src[8]=0;
			}
			else if (x==0){
				/* ====== No ====== */	avgU=subImage.GetGray(x,y-1); avgUR=subImage.GetGray(x+1,y-1);
				/* ====== No ====== */								  avgCR=subImage.GetGray(x+1,y);
				/* ====== No ====== */	avgB=subImage.GetGray(x,y+1); avgBR=subImage.GetGray(x+1,y+1);

				src[0]=0;	src[1]=avgU;	src[2]=avgUR;
				src[3]=0;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;	src[7]=avgB;	src[8]=avgBR;
			}
			else if (x==(width-1)){
				avgUL=subImage.GetGray(x-1,y-1); avgU=subImage.GetGray(x,y-1);	/* ====== No ====== */
				avgCL=subImage.GetGray(x-1,y);									/* ====== No ====== */
				avgBL=subImage.GetGray(x-1,y+1); avgB=subImage.GetGray(x,y+1);	/* ====== No ====== */
				
				src[0]=avgUL;	src[1]=avgU;	src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=0;
				src[6]=avgBL;	src[7]=avgB;	src[8]=0;
			}
			else {
				avgUL=subImage.GetGray(x-1,y-1); avgU=subImage.GetGray(x,y-1); avgUR=subImage.GetGray(x+1,y-1);
				avgCL=subImage.GetGray(x-1,y);								   avgCR=subImage.GetGray(x+1,y);
				avgBL=subImage.GetGray(x-1,y+1); avgB=subImage.GetGray(x,y+1); avgBR=subImage.GetGray(x+1,y+1);
			
				src[0]=avgUL;	src[1]=avgU;	src[2]=avgUR;
				src[3]=avgCL;	src[4]=avgC;	src[5]=avgCR;
				src[6]=avgBL;	src[7]=avgB;	src[8]=avgBR;
			}
			if(x!=0 && y!=0){
				tmp=MulMetrix(src,maskX,maskY);
				if (tmp>filterEdge && x!=0 && y!=0){
					(edge+index)->pixel.real=x;	(edge+index)->pixel.imagin=y;  
					index++;//edge -> white
					if (index==numFourierDesc){x=width;y=height;}// if buffer is full move to end
				}
			}
		}//end width
	}//end height
	if (index<numFourierDesc){// if buffer is not full 
		while (index<numFourierDesc){
			(edge+index)->pixel.real=0;	(edge+index)->pixel.imagin=0;// fullfill remain buffer by 0
			index++;
		}
	}
}

double Image::MulMetrix(double src[],int maskX[],int maskY[])
{
	double sumX=0,sumY=0;
	for (int i=0 ; i<9 ; i++){			
		sumX=sumX+(src[i]*maskX[i]);
		sumY=sumY+(src[i]*maskY[i]);
	}
	double result = fabs(sumX)+fabs(sumY);
	if (result>255)return 255;
	else if (result<0)return 0;
	else return result;
}

void Image::FindFourierDesc(CPImage& subImage,PixelComplex* edge)
{
	int N=(int)(log(numFourierDesc)/log(2));// find N of Radix-2	::Example:: if (nLine==8) N=3
	
	// Arrange Edge for do Butterfly ::Example:: 0,1,2,3,4,5,6,7 => 0,4,2,6,1,5,3,7
	ArrageRadix2Form(edge,N);

	// DIT-FFT Butterfly
	complex W;
	W.real=cos(-(2*pi)/N);	//|
	W.imagin=sin(-(2*pi)/N);//|>> fine W=(cos0 + jsin0) ==> real + j imagin
	Butterfly(edge,N,W);	// forword FFT

	// Store Fourier Descriptor in SubImage
	for (int n=0 ; n<numFourierDesc ; n++){
		subImage.fourierDesc[n]=(edge+n)->pixel.Abs();
	}
}

void Image::Butterfly(PixelComplex* pixel,int N,complex W)
{
	int shift=0;
	int shiftEdge=0;
	int factor=0;
	int factorShift=0;
	int haft=0;
	int allPixel = (int)pow(2,N);
	PixelComplex* tmp1=new PixelComplex[allPixel];
	PixelComplex* tmp2=new PixelComplex[allPixel];
	//copy value of pixel to tmp1&tmp2
	CopyPixelComplex(pixel,tmp1,allPixel);
	CopyPixelComplex(pixel,tmp2,allPixel);

	for (int outLoop=0 ; outLoop<N ; outLoop++)// Do Butterfly
	{
		shift=(int)pow(2,N-outLoop);
		shiftEdge=allPixel/shift;
		factorShift=(int)pow(2,(N-outLoop-1));
		haft=(int)pow(2,outLoop);
		for(int line=0 ; line<allPixel ; line++)//Do all edge
		{			
			if (line!=0){factor=(factor+factorShift)%allPixel;}
			else factor=0;
			double factorReal=pow(W.real,factor);
			double factorImagin=pow(W.imagin,factor);
			if (line%(2*haft)<haft){//Up Butterfly
				tmp1=tmp1+line;				//1# value
				tmp2=tmp2+line+shiftEdge;	//2# value	Multiple Up
				(pixel+line)->pixel.real	=((tmp1->pixel).real  *1)+((tmp2->pixel.real)  *factorReal);
				(pixel+line)->pixel.imagin	=((tmp1->pixel).imagin*1)+((tmp2->pixel.imagin)*factorImagin);
				//reset tmp1,tmp2
				tmp1=tmp1-line;				//set to begin value
				tmp2=tmp2-line-shiftEdge;	//set to begin value				
			}else {//Down Butterfly
				tmp1=tmp1+line-shiftEdge;	//1# value	Multiple Down
				tmp2=tmp2+line;				//2# value
				(pixel+line)->pixel.real	=((tmp1->pixel.real)  *1)+((tmp2->pixel.real)	*factorReal);
				(pixel+line)->pixel.imagin	=((tmp1->pixel.imagin)*1)+((tmp2->pixel.imagin)	*factorImagin);
				//reset tmp1,tmp2
				tmp1=tmp1-line+shiftEdge;	//set to begin value
				tmp2=tmp2-line;				//set to begin value				
			}			
		}
		//copy value of edge to tmp1,tmp2
		CopyPixelComplex(pixel,tmp1,allPixel);
		CopyPixelComplex(pixel,tmp2,allPixel);
	}
	delete[] tmp1;
	delete[] tmp2;
}

void Image::CopyPixelComplex(PixelComplex* src,PixelComplex* dst,int num)
{
	for (int n=0 ; n<num ; n++){//copy value of edge to tmp1,tmp2
			(dst+n)->pixel.real  =(src+n)->pixel.real;	
			(dst+n)->pixel.imagin=(src+n)->pixel.imagin;	
	}
}

void Image::ArrageRadix2Form(PixelComplex* edge,int N)
{
	int tmp=0;
	int interval;
	int allLine = (int)pow(2,N);
	for (int outLoop=0 ; outLoop<N ; outLoop++){
		interval=allLine/(int)pow(2,outLoop);//interval of swop
		for (int swop=0 ; swop<pow(2,outLoop) ; swop++){
			tmp=swop*interval;//shift pointer to start of interval which want to swop
			ArrangeEdge((edge+tmp),interval);//swop array
		}
	}
}

void Image::ArrangeEdge(PixelComplex* edge,int nLine)
{
	int shift = nLine/2;
	int pSrc=0;
	PixelComplex* src = new PixelComplex[nLine];//new temp array
	for (int j=0 ; j<nLine ; j++){*(src+j)=*(edge+j);}// copy value from edge
	for (int i=0 ; i<nLine/2 ; i++){
			edge=edge+i;// shift to start
		(edge)->pixel.real = (src+pSrc)->pixel.real;		//|> copy src to edge		
		(edge)->pixel.imagin = (src+pSrc)->pixel.imagin; //|
			edge=edge+shift;	
			pSrc++;// Next src
		(edge)->pixel.real = (src+pSrc)->pixel.real;		//|> copy src to edge
		(edge)->pixel.imagin = (src+pSrc)->pixel.imagin; //|
			edge=edge-shift-i; // shift to start
			pSrc++;// Next src
	}
	delete[] src;
}

void Image::DoGabor(CPImage& subImage)
{
	for(int i=0 ; i<numGaborDesc ; i++){subImage.gaborDesc[i]=0;}
	int indexGabor=0;
	int width=subImage.GetWidth();
	int height=subImage.GetHeight();
	
	int Nx,Ny;
	Nx = (int)(log(width)/log(2));// find N of Radix-2	::Example:: if (NumPixel==8) N=3
	Ny = (int)(log(height)/log(2));// find N of Radix-2	::Example:: if (NumPixel==8) N=3
	int numPixelX = (int)pow(2,Nx);
	int numPixelY = (int)pow(2,Ny);
	if (numPixelX<(width)){Nx++;numPixelX = (int)pow(2,Nx);}
	if (numPixelY<(height)){Ny++;numPixelY = (int)pow(2,Ny);}

	PixelComplex** pixelData = new PixelComplex*[numPixelY];
	for (int y=0 ; y<numPixelY ; y++){*(pixelData+y) = new PixelComplex[numPixelX];}// horizontal	
	
	PixelComplex** pixelFilter = new PixelComplex*[numPixelY];
	for (int y=0 ; y<numPixelY ; y++){*(pixelFilter+y) = new PixelComplex[numPixelX];}// horizontal	

	double* abs = new double[numPixelY*numPixelX];
	for (int s=0 ; s<scale ; s++){
		for (int o=0 ; o<orientation ;o++){
			GetGaborFilter(subImage,pixelFilter,numPixelX,numPixelY,s,o);
			GetGaborData(subImage,pixelData,numPixelX,numPixelY);	// convert Image to array of PixelComplex
			G_FFT(pixelData,pixelFilter,numPixelX,numPixelY);		// Do fourier of Data => array of PixelComplex
			MulArray(pixelData,pixelFilter,numPixelX,numPixelY);	// Multi Window*Data by (pixel X pixel) => array of PixelComplex
			G_IFFT(pixelData,numPixelX,numPixelY,abs);				// Invert fourier result => Image
			FindGaborDesc(subImage,indexGabor,pixelData,numPixelX,numPixelY,abs);// Find mean & variance of this scale,orientation
		}
	}
	delete[] abs;
	for (int y=0 ; y<numPixelY ; y++) delete[] *(pixelData+y);
	delete[] pixelData;
	for (int y=0 ; y<numPixelY ; y++) delete[] *(pixelFilter+y);
	delete[] pixelFilter;
}

void Image::FindGaborDesc(CPImage& subImage,int& indexGabor,PixelComplex** pixelData,int numPixelX,int numPixelY,double* abs)
{
	int width = subImage.GetWidth();
	int height = subImage.GetHeight();
	int pos=0;
	double E=0;
	double V=0;
	double mean=0;
	double variance=0;

	int i=0;
	for (int index=0 ; index<(numPixelY*numPixelX) ; index++){E = E + *(abs+index);}
	mean = E/(numPixelX*numPixelY);//........................Mean

	for (int index=0 ; index<(numPixelY*numPixelX) ; index++){V = V + pow(((*(abs+index))-mean),2);}
	variance = sqrt(V)/(numPixelX*numPixelY);//................Variance
	
	subImage.gaborDesc[indexGabor]=mean;
	indexGabor++;
	subImage.gaborDesc[indexGabor]=variance;
	indexGabor++;
}

void Image::G_IFFT(PixelComplex** pixelData,int numPixelX,int numPixelY,double* abs)
{
	PixelComplex** pixelDataTmp = new PixelComplex*[numPixelX];
	int x=0;
	int y=0;
	for (x=0 ; x<numPixelX ; x++){*(pixelDataTmp+x) = new PixelComplex[numPixelY];}

	// ++++++++++++++++++ do in horizontal ++++++++++++++++++++
	int N = (int)(log(numPixelX)/log(2));// find N of Radix-2	::Example:: if (NumPixel==8) N=3
	if (pow(2,N) < numPixelX)N++;
	complex W;
	W.real=cos((2*pi)/N);	//|
	W.imagin=sin((2*pi)/N);//|>> fine W=(cos0 + jsin0) ==> real + j imagin
	for (y=0 ; y<numPixelY ; y++){
		// Arrange Edge for do Butterfly ::Example:: 0,1,2,3,4,5,6,7 => 0,4,2,6,1,5,3,7
		ArrageRadix2Form(*(pixelData+y),N);
		
		// DIT-FFT Butterfly
		Butterfly(*(pixelData+y),N,W);	// forword FFT
	}
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	for (y=0 ; y<numPixelY ; y++){
		for (x=0 ; x<numPixelX ; x++){		
			((*(pixelDataTmp+x))+y)->pixel.real   = ((*(pixelData+y))+x)->pixel.real;
			((*(pixelDataTmp+x))+y)->pixel.imagin = ((*(pixelData+y))+x)->pixel.imagin;
		}
	}	
	// +++++++++++++++++ do in vertical +++++++++++++++++++++++
	N = (int)(log(numPixelY)/log(2));// find N of Radix-2	::Example:: if (NumPixel==8) N=3
	if (pow(2,N) < numPixelY)N++;
	for (x=0 ; x<numPixelX ; x++){
		// Arrange Edge for do Butterfly ::Example:: 0,1,2,3,4,5,6,7 => 0,4,2,6,1,5,3,7
		ArrageRadix2Form(*(pixelDataTmp+x),N);
		
		// DIT-FFT Butterfly
		Butterfly(*(pixelDataTmp+x),N,W);	// forword FFT
	}
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	int absIndex=0;
	for (x=0 ; x<numPixelX ; x++){
		for (y=0 ; y<numPixelY ; y++){
			((*(pixelData+y))+x)->pixel.real   = ((*(pixelDataTmp+x))+y)->pixel.real;
			((*(pixelData+y))+x)->pixel.imagin = ((*(pixelDataTmp+x))+y)->pixel.imagin;
			*(abs+absIndex)=(*(pixelData+y)+x)->pixel.Abs();
			absIndex++;
		}
	}
	for (x=0 ; x<numPixelX ; x++){delete[] *(pixelDataTmp+x);}
	delete[] pixelDataTmp;
}

void Image::MulArray(PixelComplex** pixelData , PixelComplex** pixelFilter , int numPixelX,int numPixelY)
{
	for (int y=0 ; y<numPixelY ; y++){
		for (int x=0 ; x<numPixelX ; x++){		
			((*(pixelData+y))+x)->pixel.real	= ((((*(pixelData+y))+x)->pixel.real)   * (((*(pixelFilter+y))+x)->pixel.real));
			((*(pixelData+y))+x)->pixel.imagin  = ((((*(pixelData+y))+x)->pixel.imagin) * (((*(pixelFilter+y))+x)->pixel.imagin));
		}
	}
}

void Image::GetGaborFilter(CPImage& subImage,PixelComplex**& pixelFilter,int numPixelX,int numPixelY,int s,int o)
{
	int width = subImage.GetWidth();
	int height = subImage.GetHeight();
	int indexX=0;
	int indexY=0;
	complex Y;
	int x=0;
	int y=0;
	double a=pow((uh/ul),(1/(scale-1)));

	for (y=0 ; y<numPixelY ; y++){
		if (y<gaborMaskSizeY ){
			for (x=0 ; x<numPixelX ; x++){
				if ( x<gaborMaskSizeX ){
					Y=MotherWavelet(x,y,s,o);
					Y.real=pow(a,-s)*Y.real;	
					Y.imagin=pow(a,-s)*Y.imagin;
					Y.Conj();
					((*(pixelFilter+indexY))+indexX)->pixel.real   = Y.real;
					((*(pixelFilter+indexY))+indexX)->pixel.imagin = Y.imagin;
				}
				else {//over image
					((*(pixelFilter+indexY))+indexX)->pixel.real=0;
					((*(pixelFilter+indexY))+indexX)->pixel.imagin=0;
				}
				indexX++;
			}
		}
		else {//over image
			for (x=0 ; x<numPixelX ; x++){
				((*(pixelFilter+indexY))+indexX)->pixel.real=0;
				((*(pixelFilter+indexY))+indexX)->pixel.imagin=0;
				indexX++;
			}
		}
		indexX=0;
		indexY++;
	}
}

void Image::GetGaborData(CPImage& subImage,PixelComplex**& pixelData,int numPixelX,int numPixelY)
{
	int width = subImage.GetWidth();
	int height = subImage.GetHeight();
	int indexX = 0;
	int indexY = 0;
	double color;
	int x=0;
	int y=0;

	for (y=0 ; y<numPixelY ; y++){ // store position of pixel and color to array of PixelComplex
		if (y<height){
			for (x=0 ; x<numPixelX ; x++){
				if (x<width){
					color = subImage.GetGray(x,y);		
					((*(pixelData+indexY))+indexX)->pixel.real = color;					
					((*(pixelData+indexY))+indexX)->pixel.imagin = color;				
				}
				else {//over image
					((*(pixelData+indexY))+indexX)->pixel.real = 0;					
					((*(pixelData+indexY))+indexX)->pixel.imagin = 0;				
				}
					indexX++;
			}
		}
		else {// over image
			for (x=0 ; x<numPixelX ; x++){
				((*(pixelData+indexY))+indexX)->pixel.real = 0;					
				((*(pixelData+indexY))+indexX)->pixel.imagin = 0;				
				indexX++;		
			}
		}
		indexX = 0;
		indexY++;
	}
}

void Image::G_FFT(PixelComplex** pixelData,PixelComplex** pixelFilter,int numPixelX,int numPixelY)
{
	PixelComplex** pixelDataTmp = new PixelComplex*[numPixelX];
	PixelComplex** pixelFilterTmp = new PixelComplex*[numPixelX];
	int x=0;
	int y=0;
	for (x=0 ; x<numPixelX ; x++){
		*(pixelDataTmp+x) = new PixelComplex[numPixelY];
		*(pixelFilterTmp+x) = new PixelComplex[numPixelY];
	}

	// ++++++++++++++++++ do in horizontal ++++++++++++++++++++
	int N = (int)(log(numPixelX)/log(2));// find N of Radix-2	::Example:: if (NumPixel==8) N=3
	if (pow(2,N) < numPixelX)N++;
	complex W;
	W.real=cos(-(2*pi)/N);	//|
	W.imagin=sin(-(2*pi)/N);//|>> fine W=(cos0 + jsin0) ==> real + j imagin
	for (y=0 ; y<numPixelY ; y++){
		// Arrange Edge for do Butterfly ::Example:: 0,1,2,3,4,5,6,7 => 0,4,2,6,1,5,3,7
		ArrageRadix2Form(*(pixelData+y),N);
		ArrageRadix2Form(*(pixelFilter+y),N);

		// DIT-FFT Butterfly
		Butterfly(*(pixelData+y),N,W);		// forword FFT
		Butterfly(*(pixelFilter+y),N,W);	// forword FFT

		for (x=0 ; x<numPixelX ; x++){	// store in temp for vertical	
			((*(pixelDataTmp+x))+y)->pixel.real   = ((*(pixelData+y))+x)->pixel.real;
			((*(pixelDataTmp+x))+y)->pixel.imagin = ((*(pixelData+y))+x)->pixel.imagin;
			((*(pixelFilterTmp+x))+y)->pixel.real   = ((*(pixelFilter+y))+x)->pixel.real;
			((*(pixelFilterTmp+x))+y)->pixel.imagin = ((*(pixelFilter+y))+x)->pixel.imagin;
		}
	}
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
	// +++++++++++++++++ do in vertical +++++++++++++++++++++++
	N = (int)(log(numPixelY)/log(2));// find N of Radix-2	::Example:: if (NumPixel==8) N=3
	if (pow(2,N) < numPixelY)N++;
	for (x=0 ; x<numPixelX ; x++){
		// Arrange Edge for do Butterfly ::Example:: 0,1,2,3,4,5,6,7 => 0,4,2,6,1,5,3,7
		ArrageRadix2Form(*(pixelDataTmp+x),N);
		ArrageRadix2Form(*(pixelFilterTmp+x),N);
		
		// DIT-FFT Butterfly
		Butterfly(*(pixelDataTmp+x),N,W);	// forword FFT
		Butterfly(*(pixelFilterTmp+x),N,W);	// forword FFT

		for (y=0 ; y<numPixelY ; y++){
			((*(pixelData+y))+x)->pixel.real   = ((*(pixelDataTmp+x))+y)->pixel.real;
			((*(pixelData+y))+x)->pixel.imagin = ((*(pixelDataTmp+x))+y)->pixel.imagin;
			((*(pixelFilter+y))+x)->pixel.real   = ((*(pixelFilterTmp+x))+y)->pixel.real;
			((*(pixelFilter+y))+x)->pixel.imagin = ((*(pixelFilterTmp+x))+y)->pixel.imagin;		
		}
	}
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	
	for (x=0 ; x<numPixelX ; x++){
		delete[] *(pixelDataTmp+x);
		delete[] *(pixelFilterTmp+x);
	}
	delete[] pixelDataTmp;
	delete[] pixelFilterTmp;
}

complex Image::MotherWavelet(int x,int y,int s,int o)
{
	double xBar,yBar;
	double tmpX,tmpY;
	double angle;
	double w;
	double varX,varY;
	double r;//in Exponential Form
	double zeta;//angle in Exponential Form
	double a=pow((uh/ul),(1/(scale-1)));

	complex result;
	//prepare varible
	angle = (o*pi)/orientation;
	tmpX=x*(cos(angle));
	tmpY=y*(sin(angle));
	xBar=pow(a,-s)*(tmpX+tmpY);	// X bar
	tmpX=-x*(cos(angle));
	//tmpY=y*(sin(angle));
	yBar=pow(a,-s)*(tmpX+tmpY);	// Y bar
	w=pow(a,s)*ul;				// W
	double ln2 = (log(2)/log(e));
	varX=((a+1)*sqrt(2*ln2)) / (2*pi*(pow(a,s))*(a-1)*ul);// variance X
	varY=1 / (2*pi*(tan(pi/(2*orientation)))*sqrt((pow(uh,2)/(2*ln2))-pow((1/(2*pi*varX)),2)));// variance y

	// function is pomplex
	r=(1/(2*pi*varX*varY)) * exp((-1/2)*((pow(xBar,2)/pow(varX,2))+(pow(yBar,2)/pow(varY,2))));
	zeta=2*pi*w*xBar;
	result.real=r*cos(zeta);
	result.imagin=r*sin(zeta);
	return result;
}

void Image::PartitionImage()
{	
	int height = GetHeight();
	int width = GetWidth();

	int subH[3]={0,0,0}; int subW[3]={0,0,0};
	int h=height/3;	int w=width/3;

	if (height%3==0){subH[0]=h;subH[1]=h;subH[2]=h;}//(h,h,h)
	else if (height%3==1){subH[0]=h;subH[1]=h;subH[2]=h+1;}//(h,h,h+1)
	else if (height%3==2){subH[0]=h;subH[1]=h+1;subH[2]=h+1;}//(h,h+1,h+1)

	if (width%3==0){subW[0]=w;subW[1]=w;subW[2]=w;}//(w,w,w)
	else if (width%3==1){subW[0]=w;subW[1]=w;subW[2]=w+1;}//(w,w,w+1)
	else if (width%3==2){subW[0]=w;subW[1]=w+1;subW[2]=w+1;}//(w,w+1,w+1)
	
	if (sub0)sub0.Destroy();	sub0.Create(subW[0],subH[0],24);
	if (sub1)sub1.Destroy();	sub1.Create(subW[1],subH[0],24);
	if (sub2)sub2.Destroy();	sub2.Create(subW[2],subH[0],24);
	if (sub3)sub3.Destroy();	sub3.Create(subW[0],subH[1],24);
	if (sub4)sub4.Destroy();	sub4.Create(subW[1],subH[1],24);
	if (sub5)sub5.Destroy();	sub5.Create(subW[2],subH[1],24);
	if (sub6)sub6.Destroy();	sub6.Create(subW[0],subH[2],24);
	if (sub7)sub7.Destroy();	sub7.Create(subW[1],subH[2],24);
	if (sub8)sub8.Destroy();	sub8.Create(subW[2],subH[2],24);

	int minY,maxY,minX,maxX;
	minY=0;  maxY=subH[0];  minX=0;  maxX=subW[0];
	CloneImg(minY,maxY,minX,maxX,sub0);// for subImage 0

	minY=0;  maxY=subH[0];  minX=subW[0];  maxX=subW[0]+subW[1];
	CloneImg(minY,maxY,minX,maxX,sub1);// for subImage 1

	minY=0;  maxY=subH[0];  minX=subW[0]+subW[1];  maxX=subW[0]+subW[1]+subW[2];
	CloneImg(minY,maxY,minX,maxX,sub2);// for subImage 2

	minY=subH[0];  maxY=subH[0]+subH[1];  minX=0;  maxX=subW[0];
	CloneImg(minY,maxY,minX,maxX,sub3);// for subImage 3

	minY=subH[0];  maxY=subH[0]+subH[1];  minX=subW[0];  maxX=subW[0]+subW[1];
	CloneImg(minY,maxY,minX,maxX,sub4);// for subImage 4

	minY=subH[0];  maxY=subH[0]+subH[1];  minX=subW[0]+subW[1];  maxX=subW[0]+subW[1]+subW[2];
	CloneImg(minY,maxY,minX,maxX,sub5);// for subImage 5

	minY=subH[0]+subH[1];  maxY=subH[0]+subH[1]+subH[2];  minX=0;  maxX=subW[0];
	CloneImg(minY,maxY,minX,maxX,sub6);// for subImage 6

	minY=subH[0]+subH[1];  maxY=subH[0]+subH[1]+subH[2];  minX=subW[0];  maxX=subW[0]+subW[1];
	CloneImg(minY,maxY,minX,maxX,sub7);// for subImage 7

	minY=subH[0]+subH[1];  maxY=subH[0]+subH[1]+subH[2];  minX=subW[0]+subW[1];  maxX=subW[0]+subW[1]+subW[2];
	CloneImg(minY,maxY,minX,maxX,sub8);// for subImage 8
}

void Image::CloneImg(int minY,int maxY,int minX,int maxX,CPImage& tarImg)
{
	COLORREF srcColor=0;// pixels color
	for (int y=minY ; y<maxY ; y++){
		for (int x=minX ; x<maxX ; x++){
			srcColor=GetColor(x,y);
			tarImg.SetColor(x-minX,y-minY,srcColor);
		}		
	}
}

void Image::ReSize(Image& resizeImage)
{
	int height = GetHeight();
	int width = GetWidth();
	double ratio=0;
	COLORREF color=0;

	if (width > height){ratio = (double)maxWidthImage/width;}
	else {ratio = (double)maxHeightImage/height;}

	int reWidth = (int)(width * ratio);		if(reWidth > maxWidthImage)reWidth--;
	int reHeight = (int)(height * ratio);	if(reHeight > maxHeightImage)reHeight--;

	if(resizeImage)resizeImage.Destroy();
	resizeImage.Create(reWidth,reHeight,24);
	for(int reY=0 ;reY<reHeight ; reY++){
		for(int reX=0 ; reX<reWidth ; reX++){
			color = BackwordSrc(reX,reY,ratio,width,height,'o');
			resizeImage.SetColor(reX,reY,color);			
		}
	}
}

COLORREF Image::BackwordSrc(int reX,int reY,double ratio,int maxX,int maxY,char dir)
{
	double srcX=0;
	double srcY=0;
	if(dir=='o'){// zoome out
		srcX = reX / ratio;
		srcY = reY / ratio;}
	else {//zoom in
		srcX = reX * ratio;
		srcY = reY * ratio;}
	if (srcX < 0)srcX = 0;			if (srcY < 0)srcY = 0;
	if (srcX >= maxX)srcX = maxX-1;	if (srcY >= maxY)srcY = maxY-1;
	
	int srcX0 = (int)(srcX);	if(srcX0>srcX)srcX0--;
	int srcY0 = (int)(srcY);	if(srcY0>srcY)srcY0--;
	double difX = srcX - srcX0;
	double difY = srcY - srcY0;
	COLORREF colorResult=0;
	COLORREF color00 = 0,color01 = 0,color10 = 0,color11 = 0;

	// bilinear interpolation
	
	color00 = GetColor(srcX0,srcY0);
	if (srcY0 < maxY-2){color01 = GetColor(srcX0,srcY0+1);}else {color01 = GetColor(srcX0,srcY0);}
	if (srcX0 < maxX-2){color10 = GetColor(srcX0+1,srcY0);}else {color10 = GetColor(srcX0,srcY0);}
	if (srcX0 < maxX-2 && srcY0 < maxY-2){color11 = GetColor(srcX0+1,srcY0+1);}else {color11 = GetColor(srcX0,srcY0);}
	colorResult = color00 + (color01 - color00)*(BYTE)difX 
						  + (color01 - color00)*(BYTE)difY 
						  + (color11 + color00 - color01 - color10)*(BYTE)(difX*difY);
	return colorResult;
}

void Image::ToGrayImage()
{
	int width = GetWidth();
	int height = GetHeight();
	BYTE red = 0;
	BYTE green = 0;
	BYTE blue = 0;
	double avg=0;

	for (int y=0 ; y<height ; y++){
		for (int x=0 ; x<width ; x++){
			avg=GetGray(x,y);
			red=(BYTE)avg;	
			green=(BYTE)avg;	
			blue=(BYTE)avg;
			SetColor(x,y,RGB(red,green,blue));
		}
	}
}

void Image::ToEdgeImage()
{
	ToGrayImage();
	int width = GetWidth();
	int height = GetHeight();
	int maskX[9]=sobelX;
	int maskY[9]=sobelY;
	double avgUL,avgU,avgUR,avgCL,avgC,avgCR,avgBL,avgB,avgBR;
	double src[9];
	double tmp;
	double** result = new double*[height];
	for(int y=0 ; y<height ; y++){*(result+y) = new double[width];}
	
	for (int y=0 ; y<height ; y++){
		for (int x=0 ; x<width ; x++){
			avgC=(double)GetBValue(GetColor(x,y));
			if (y==0 && x==0){
				/* ====== No ====== */	/* ====== No ====== */						/* ====== No ====== */
				/* ====== No ====== */												avgCR=(double)GetBValue(GetColor(x+1,y));
				/* ====== No ====== */	avgB=(double)GetBValue(GetColor(x,y+1));	avgBR=(double)GetBValue(GetColor(x+1,y+1));

				src[0]=0;	src[1]=0;		src[2]=0;
				src[3]=0;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;	src[7]=avgB;	src[8]=avgBR;
			}
			else if (y==0 && x==(width-1)){								
				/* ====== No ====== */						/* ====== No ====== */						/* ====== No ====== */
				avgCL=(double)GetBValue(GetColor(x-1,y));												/* ====== No ====== */
				avgBL=(double)GetBValue(GetColor(x-1,y+1)); avgB=(double)GetBValue(GetColor(x,y+1));	/* ====== No ====== */

				src[0]=0;		src[1]=0;		src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=0;
				src[6]=avgBL;	src[7]=avgB;	src[8]=0;
			}
			else if (y==(height-1) && x==0){
				/* ====== No ====== */	avgU=(double)GetBValue(GetColor(x,y-1));	avgUR=(double)GetBValue(GetColor(x+1,y-1));
				/* ====== No ====== */												avgCR=(double)GetBValue(GetColor(x+1,y));
				/* ====== No ====== */	/* ====== No ====== */						/* ====== No ====== */

				src[0]=0;	src[1]=avgU;	src[2]=avgUR;
				src[3]=0;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;	src[7]=0;		src[8]=0;
			}
			else if (y==(height-1) && x==(width-1)){
				avgUL=(double)GetBValue(GetColor(x-1,y-1)); avgU=(double)GetBValue(GetColor(x,y-1));	/* ====== No ====== */
				avgCL=(double)GetBValue(GetColor(x-1,y));												/* ====== No ====== */
				/* ====== No ====== */						/* ====== No ====== */						/* ====== No ====== */

				src[0]=avgUL;	src[1]=avgU;	src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=0;
				src[6]=0;		src[7]=0;		src[8]=0;							  
			}
			else if (y==0){
				/* ====== No ====== */						/* ====== No ====== */						/* ====== No ====== */
				avgCL=(double)GetBValue(GetColor(x-1,y));												avgCR=(double)GetBValue(GetColor(x+1,y));
				avgBL=(double)GetBValue(GetColor(x-1,y+1)); avgB=(double)GetBValue(GetColor(x,y+1));	avgBR=(double)GetBValue(GetColor(x+1,y+1));
			
				src[0]=0;		src[1]=0;		src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=avgCR;
				src[6]=avgBL;	src[7]=avgB;	src[8]=avgBR;
			}
			else if (y==(height-1)){
				avgUL=(double)GetBValue(GetColor(x-1,y-1)); avgU=(double)GetBValue(GetColor(x,y-1));	avgUR=(double)GetBValue(GetColor(x+1,y-1));
				avgCL=(double)GetBValue(GetColor(x-1,y));												avgCR=(double)GetBValue(GetColor(x+1,y));
				/* ====== No ====== */						/* ====== No ====== */						/* ====== No ====== */

				src[0]=avgUL;	src[1]=avgU;	src[2]=avgUR;
				src[3]=avgCL;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;		src[7]=0;		src[8]=0;
			}
			else if (x==0){
				/* ====== No ====== */	avgU=(double)GetBValue(GetColor(x,y-1));	avgUR=(double)GetBValue(GetColor(x+1,y-1));
				/* ====== No ====== */												avgCR=(double)GetBValue(GetColor(x+1,y));
				/* ====== No ====== */	avgB=(double)GetBValue(GetColor(x,y+1));	avgBR=(double)GetBValue(GetColor(x+1,y+1));

				src[0]=0;	src[1]=avgU;	src[2]=avgUR;
				src[3]=0;	src[4]=avgC;	src[5]=avgCR;
				src[6]=0;	src[7]=avgB;	src[8]=avgBR;
			}
			else if (x==(width-1)){
				avgUL=(double)GetBValue(GetColor(x-1,y-1)); avgU=(double)GetBValue(GetColor(x,y-1));	/* ====== No ====== */
				avgCL=(double)GetBValue(GetColor(x-1,y));												/* ====== No ====== */
				avgBL=(double)GetBValue(GetColor(x-1,y+1)); avgB=(double)GetBValue(GetColor(x,y+1));	/* ====== No ====== */
				
				src[0]=avgUL;	src[1]=avgU;	src[2]=0;
				src[3]=avgCL;	src[4]=avgC;	src[5]=0;
				src[6]=avgBL;	src[7]=avgB;	src[8]=0;
			}
			else {
				avgUL=(double)GetBValue(GetColor(x-1,y-1)); avgU=(double)GetBValue(GetColor(x,y-1));	avgUR=(double)GetBValue(GetColor(x+1,y-1));
				avgCL=(double)GetBValue(GetColor(x-1,y));												avgCR=(double)GetBValue(GetColor(x+1,y));
				avgBL=(double)GetBValue(GetColor(x-1,y+1)); avgB=(double)GetBValue(GetColor(x,y+1));	avgBR=(double)GetBValue(GetColor(x+1,y+1));
			
				src[0]=avgUL;	src[1]=avgU;	src[2]=avgUR;
				src[3]=avgCL;	src[4]=avgC;	src[5]=avgCR;
				src[6]=avgBL;	src[7]=avgB;	src[8]=avgBR;
			}
			tmp=MulMetrix(src,maskX,maskY);

			if (tmp < filterEdge){*(*(result+y)+x)=0;}
			else {*(*(result+y)+x)=tmp;}
		}//end width
	}//end height
	COLORREF color=0;
	for (int y=0 ; y<height ; y++){
		for (int x=0 ; x<width ; x++){
			color = RGB((*(*(result+y)+x)),(*(*(result+y)+x)),(*(*(result+y)+x)));
			SetColor(x,y,color);
		}
	}

	delete[] result;
}
void Image::Zoom(Image& zoom,char size)
{
	int height=GetHeight();
	int width=GetWidth();

	double ratio=ratioZoom;
	double newHeight;
	double newWidth;
	switch(size){
		case 'i' : {
					newHeight=height/ratio;
					newWidth=width/ratio;}break;
		case 'o' : {
					newHeight=height*ratio;
					newWidth=width*ratio;}break;	
	}
	if(zoom)zoom.Destroy();
	COLORREF color;
	zoom.Create((int)newWidth,(int)newHeight,24);
	for(int reY=0 ;reY<(int)newHeight ; reY++){
		for(int reX=0 ; reX<(int)newWidth ; reX++){
			color = BackwordSrc(reX,reY,ratio,width,height,size);
			zoom.SetColor(reX,reY,color);
		}
	}
}