//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IR.rc
//
#define IDR_MANIFEST                    1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_IR_DIALOG                   102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_SCROLLBAR1                  1011
#define IDC_SCROLLBAR2                  1012
#define IDC_BUTTON1                     1018
#define IDC_BUTTON2                     1019
#define IDC_EDIT3                       1023
#define IDC_LIST1                       1025
#define IDC_CHECK1                      1026
#define ID_MAIN_PICTURE                 10000
#define ID_NORMALIMAGE                  10001
#define ID_GRAYIMAGE                    10002
#define ID_EDGEIMAGE                    10003
#define ID_LEN_SEQ1                     15000
#define ID_LEN_SEQ2                     15001
#define ID_LEN_SEQ3                     15002
#define ID_SERVER_MODE                  20000
#define ID_CLIENT_MODE                  20001
#define ID_IMAGE_OPEN                   30000
#define ID_STORE_IMAGE                  30001
#define ID_RETRIEVE_IMAGE               30002
#define ID_CHECK_STORE                  30003
#define ID_CHECK_RETRIEVE               30004
#define ID_CHECK_ALGOR                  30005
#define ID_ZOOM_IN                      30010
#define ID_ZOOM_OUT                     30011
#define ID_SEQ_1                        40000
#define ID_SEQ_2                        40001
#define ID_SEQ_3                        40002
#define ID_SEC_TIME                     40010
#define ID_MIN_TIME                     40011
#define ID_SHOW_TEXT                    40012
#define ID_SCALL_DETAIL                 40013
#define ID_RESET_RESULT                 40014
#define ID_RESULT_DIALOG                40015
#define ID_SHOW_OUTPUT                  40016
#define ID_SHOW_INPUT                   40017
#define ID_DIST_JOB                     45000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1030
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
