/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#pragma once
#include "PImage.h"
#include "PixelComplex.h"

class Image : public CPImage
{
public:
	CPImage sub0,sub1,sub2,sub3,sub4,sub5,sub6,sub7,sub8;
public:
	Image(void);
	~Image(void);
	void Histogram(void);
	void OnlyKeyHistogram(void);
	void Fourier(void);
	void Gabor(void);
	void ReSize(Image& resizeImage);
	COLORREF BackwordSrc(int reX,int reY,double ratio,int maxX,int maxY,char dir);
	void Zoom(Image& zoom,char size);

	void DoHistogram(CPImage& subImage);
	void Quantization(CPImage& subImage);
	void Normalize(CPImage& subImage);

	void DoFourier(CPImage& subImage);
	void EdgeDetector(CPImage& subImage,PixelComplex* edge);
	double MulMetrix(double src[9],int maskX[],int maskY[]);
	void FindFourierDesc(CPImage& subImage,PixelComplex* edge);
	void ArrageRadix2Form(PixelComplex* edge,int N);
	void ArrangeEdge(PixelComplex* edge,int nLine);
	void Butterfly(PixelComplex* pixel,int N,complex W);
	void CopyPixelComplex(PixelComplex* src,PixelComplex* dst,int num);


	void DoGabor(CPImage& subImage);
	complex MotherWavelet(int x,int y,int s,int o);
	void GetGaborFilter(CPImage& subImage,PixelComplex**& pixelFilter,int numPixelX,int numPixelY,int s,int o);
	void GetGaborData(CPImage& subImage,PixelComplex**& pixelData,int numPixelX,int numPixelY);
	void G_FFT(PixelComplex** pixelData,PixelComplex** pixelFilter,int numPixelX,int numPixelY);
	void G_IFFT(PixelComplex** pixelData,int numPixelX,int numPixelY,double* abs);
	void FindGaborDesc(CPImage& subImage,int& indexGabor,PixelComplex** pixelData,int numPixelX,int numPixelY,double* abs);
	void MulArray(PixelComplex** pixelData,PixelComplex** pixelFilter,int numPixelX,int numPixelY);

	void PartitionImage();
	void CloneImg(int minY,int maxY,int minX,int maxX,CPImage& tarImg);

	void ToGrayImage();
	void ToEdgeImage();
};

