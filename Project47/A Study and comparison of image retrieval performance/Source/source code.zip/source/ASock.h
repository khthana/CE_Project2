/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#pragma once

// CASock command target

class CASock : public CAsyncSocket
{
public:
	CASock();
	virtual ~CASock();
	virtual void OnAccept(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	void SetParent(CDialog* pDwnd);
protected:
	CDialog* m_pDwnd;
};


