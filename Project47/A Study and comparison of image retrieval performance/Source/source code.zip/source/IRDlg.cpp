/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
// IRDlg.cpp : implementation file
//

#include "stdafx.h"
#include "IR.h"
#include "IRDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD){}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// CIRDlg dialog

CIRDlg::CIRDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CIRDlg::IDD, pParent)
	, m_strShow(_T(""))
	, m_len_seq1(100)
	, m_len_seq2(100)
	, m_len_seq3(100)
	, m_distribute(false)
	, m_masterMode(true)
	, m_slaveMode(false)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CIRDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, ID_SEQ_1, m_comboSeq1);
	DDX_Control(pDX, ID_SEQ_2, m_comboSeq2);
	DDX_Control(pDX, ID_SEQ_3, m_comboSeq3);
	DDX_Control(pDX, ID_MAIN_PICTURE, m_picture);
	DDX_Control(pDX, ID_CHECK_ALGOR, m_searchAlgor);
	DDX_Control(pDX, IDC_SCROLLBAR1, m_vbar);
	DDX_Control(pDX, IDC_SCROLLBAR2, m_hbar);
	DDX_Text(pDX, ID_SHOW_TEXT, m_strShow);
	DDX_Control(pDX, ID_RESET_RESULT, m_ResetButton);
	DDX_Control(pDX, ID_STORE_IMAGE, m_StoreButton);
	DDX_Control(pDX, ID_RETRIEVE_IMAGE, m_RetrieveButton);
	DDX_Text(pDX, ID_LEN_SEQ1, m_len_seq1);
	DDV_MinMaxInt(pDX, m_len_seq1, 1, 100);
	DDX_Text(pDX, ID_LEN_SEQ2, m_len_seq2);
	DDV_MinMaxInt(pDX, m_len_seq2, 1, 100);
	DDX_Text(pDX, ID_LEN_SEQ3, m_len_seq3);
	DDV_MinMaxInt(pDX, m_len_seq3, 1, 100);
	DDX_Control(pDX, ID_SHOW_OUTPUT, m_show_output);
	DDX_Control(pDX, ID_SHOW_INPUT, m_show_input);
	DDX_Control(pDX, ID_IMAGE_OPEN, m_ChooseButton);
	DDX_Control(pDX, IDC_CHECK1, distributeButton);
}

BEGIN_MESSAGE_MAP(CIRDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(ID_IMAGE_OPEN, OnClickImageOpen)
	ON_BN_CLICKED(ID_STORE_IMAGE, OnClickImageStore)
	ON_BN_CLICKED(ID_RETRIEVE_IMAGE, OnClickImageRetrieve)
	ON_BN_CLICKED(ID_CHECK_ALGOR, OnBnClickedCheckAlgor)
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_BN_CLICKED(ID_RESET_RESULT, OnBnClickedResetResult)
	ON_BN_CLICKED(ID_NORMALIMAGE, OnBnClickedNormalimage)
	ON_BN_CLICKED(ID_GRAYIMAGE, OnBnClickedGrayimage)
	ON_BN_CLICKED(ID_EDGEIMAGE, OnBnClickedEdgeimage)
	ON_CBN_SELCHANGE(ID_SEQ_1, OnCbnSelchangeSeq1)
	ON_CBN_SELCHANGE(ID_SEQ_2, OnCbnSelchangeSeq2)
	ON_CBN_SELCHANGE(ID_SEQ_3, OnCbnSelchangeSeq3)
	ON_EN_CHANGE(ID_LEN_SEQ1, OnEnChangeLenSeq1)
	ON_EN_CHANGE(ID_LEN_SEQ2, OnEnChangeLenSeq2)
	ON_EN_CHANGE(ID_LEN_SEQ3, OnEnChangeLenSeq3)
	ON_LBN_DBLCLK(ID_SHOW_OUTPUT, OnLbnDblclkShowOutput)
	ON_LBN_DBLCLK(ID_SHOW_INPUT, OnLbnDblclkShowInput)
	ON_BN_CLICKED(IDC_CHECK1, OnBnClickedCheck1)
	ON_BN_CLICKED(ID_CLIENT_MODE, OnBnClickedSlaveMode)
	ON_BN_CLICKED(ID_SERVER_MODE, OnBnClickedMasterMode)
	ON_BN_CLICKED(ID_ZOOM_IN, OnBnClickedZoomIn)
	ON_BN_CLICKED(ID_ZOOM_OUT, OnBnClickedZoomOut)
END_MESSAGE_MAP()

// CIRDlg message handlers

BOOL CIRDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	ShowWindow(SW_RESTORE);

	// TODO: Add extra initialization here
	// =================== for show in picture control =====================
    CClientDC dc(this);
    m_dcMem.CreateCompatibleDC( &dc );
	m_vbar.ShowWindow(false);
	m_hbar.ShowWindow(false);
	sourcex=sourcey=0;
	// =====================================================================
	m_StoreButton.EnableWindow(false);
	m_RetrieveButton.EnableWindow(false);
	
	system = new IRSystem;
	m_filter=false;
	// Combo box -> Seq1
	m_comboSeq1.AddString("Gabor");
	m_comboSeq1.AddString("Fourier");
	m_comboSeq1.AddString("Histogram");
	// Combo box -> Seq2
	m_comboSeq2.AddString("Gabor");
	m_comboSeq2.AddString("Fourier");
	m_comboSeq2.AddString("Histogram");
	// Combo box -> Seq3
	m_comboSeq3.AddString("Gabor");
	m_comboSeq3.AddString("Fourier");
	m_comboSeq3.AddString("Histogram");

	CheckRadioButton(ID_SERVER_MODE,ID_CLIENT_MODE,ID_SERVER_MODE);
	CheckRadioButton(ID_NORMALIMAGE,ID_EDGEIMAGE,ID_NORMALIMAGE);
	focusInput=true;
	focusOutput=false;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CIRDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CIRDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND,(WPARAM) dc.GetSafeHdc(), 0);// reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
        // =================Add the following Code =============
        CPaintDC dc(this);
		dc.BitBlt(offsetx,offsety,m_size.cx,m_size.cy,&m_dcMem, sourcex, sourcey,SRCCOPY);
		// =====================================================
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CIRDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CIRDlg::OnClickImageOpen()
{
	// TODO: Add your control notification handler code here
	// ====== Show Open File Dialog ======
	char* tmp=new char[maxCharOpen];
	memset(tmp, 0, sizeof(tmp));
	int numFile=0;
	CFileDialog dlg(TRUE,
					NULL,
					NULL,
					OFN_ALLOWMULTISELECT | OFN_HIDEREADONLY,strFilter,this);
	dlg.m_ofn.lpstrTitle = "Choose Image File";
	dlg.m_ofn.lpstrFile = tmp;
	dlg.m_ofn.nMaxFile = maxCharOpen;
	if (dlg.DoModal() != IDOK){delete[] tmp; return;}
	CString* name = new CString[maxOpenFile];
	CString pathName = dlg.GetPathName();
	POSITION pos = dlg.GetStartPosition();
	while (pos){
		*(name+numFile) = dlg.GetNextPathName(pos);
		numFile++;
	}
	system->numFileName = numFile;
	if(system->OpenImage(name)){
		CheckRadioButton(ID_NORMALIMAGE,ID_EDGEIMAGE,ID_NORMALIMAGE);
		selInput=0;
		m_show_input.SetFocus();
		// ====== Display image file ======
		sourcex=sourcey=0;
		ShowPicture(system->targetImage);
		CString tmp;	tmp.Format("%d",system->numFileName);
		m_strShow = "Open : "+tmp+" images\nFrom : "+system->filePath;
		m_show_input.ResetContent();
		for(int j=0 ; j<system->numFileName ; j++){
			m_show_input.AddString("     "+*((system->inputFileName)+j));
		}			
		UpdateData(FALSE);

		m_StoreButton.EnableWindow(true);
		m_RetrieveButton.EnableWindow(true);
	}else AfxMessageBox("Load Image Failed");
	delete[] tmp;
	delete[] name;
}

// function for show picture to screen
void CIRDlg::ShowPicture(HBITMAP m_hBmpNew)
{
		// put the HBITMAP info into the CBitmap (but not the bitmap itself)		
		m_picture.GetClientRect( &rectStaticClient );
		rectStaticClient.NormalizeRect();
		m_size.cx=rectStaticClient.Size().cx;
		m_size.cy=rectStaticClient.Size().cy;
		m_size.cx = rectStaticClient.Width();    // zero based
		m_size.cy = rectStaticClient.Height();    // zero based

        // Convert to screen coordinates using static as base,
        // then to DIALOG (instead of static) client coords 
        // using dialog as base
        m_picture.ClientToScreen( &rectStaticClient );
        ScreenToClient( &rectStaticClient);
        
        m_pt.x = rectStaticClient.left;
        m_pt.y = rectStaticClient.top;
        GetObject( m_hBmpNew , sizeof(BITMAP), &m_bmInfo );
        VERIFY(m_hBmpOld = (HBITMAP)SelectObject(m_dcMem, m_hBmpNew ));
        offsetx= m_pt.x;
        offsety=m_pt.y;   
		// Reset position of Vertical Scroll Bar
		m_vbar.MoveWindow(offsetx+m_size.cx,offsety,18,m_size.cy);    
		// Reset position of Horizontal Scroll Bar
		m_hbar.MoveWindow(offsetx,offsety+m_size.cy,m_size.cx,18);    
   
		horz.cbSize = sizeof(SCROLLINFO);
		horz.fMask = SIF_ALL;
		horz.nMin = 0;
		horz.nMax = m_bmInfo.bmWidth-m_size.cx;
		horz.nPage =0;
		horz.nPos = 0;
		horz.nTrackPos=0;
		if(m_bmInfo.bmWidth<=m_size.cx){
			if((m_size.cx-m_bmInfo.bmWidth)==0)offsetx= m_pt.x;
			else offsetx= m_pt.x+((m_size.cx-m_bmInfo.bmWidth)/2);
			m_vbar.MoveWindow(offsetx+m_bmInfo.bmWidth,offsety,18,m_size.cy);
			m_hbar.ShowWindow(false);
		}
		else m_hbar.ShowWindow(true);
   
		m_hbar.SetScrollInfo(&horz);
		vert.cbSize = sizeof(SCROLLINFO);
		vert.fMask = SIF_ALL;
		vert.nMin = 0;
		vert.nMax = m_bmInfo.bmHeight-(m_size.cy);
		vert.nPage = 0;
		vert.nTrackPos=0;
		if(m_bmInfo.bmHeight<=m_size.cy){
			if((m_size.cy-m_bmInfo.bmHeight)==0)offsety= m_pt.y;
			else
			offsety= m_pt.y+((m_size.cy-m_bmInfo.bmHeight)/2);
			m_hbar.MoveWindow(offsetx,offsety+m_bmInfo.bmHeight,m_size.cx,18);
			m_vbar.ShowWindow(false);
		}
		else m_vbar.ShowWindow(true);
			m_vbar.SetScrollInfo(&vert);
	        InvalidateRect(&rectStaticClient);
}

void CIRDlg::OnClickImageStore()
{
	// TODO: Add your control notification handler code here
	m_strShow = m_strShow + "\n"+"Start store...";
	UpdateData(FALSE);
	CString useTime = system->StartStore();
	if (useTime != "0"){
		CString tmp="\nTime ";
		MessageBox("Store feature image is completed"+tmp+ useTime,"Store",0);
		m_strShow = m_strShow + "\n" + "Finished";
		m_strShow = m_strShow + "\n" + "Time => " + useTime+"\n"+"==========================";
		UpdateData(FALSE);
	}else {
		m_strShow = m_strShow + "\n" + "error!!!";
		UpdateData(FALSE);
	}
	m_ResetButton.EnableWindow(true);
}

void CIRDlg::OnClickImageRetrieve()
{
	// TODO: Add your control notification handler code here
	CString patten="";
	m_strShow = "Start retrieval...";
	UpdateData(FALSE);
	system->seq="";
	system->filter=false;
	CString seq="";
	CString s1,s2,s3;
	int nCurrentSelected1=m_comboSeq1.GetCurSel();
	int nCurrentSelected2=m_comboSeq2.GetCurSel();
	int nCurrentSelected3=m_comboSeq3.GetCurSel();
	
	if(m_len_seq1>0){system->len_seq1=m_len_seq1;}else {AfxMessageBox("Please insert input");return;}
	if(m_len_seq2>0){system->len_seq2=m_len_seq2;}else {AfxMessageBox("Please insert input");return;}
	if(m_len_seq3>0){system->len_seq3=m_len_seq3;}else {AfxMessageBox("Please insert input");return;}

	if (nCurrentSelected1!=LB_ERR){
		m_comboSeq1.GetLBText(nCurrentSelected1,s1);
		if (s1=="Gabor")s1="G";
		else if (s1=="Fourier")s1="F";
		else if (s1=="Histogram")s1="H";
	}else s1="B";

	if (nCurrentSelected2!=LB_ERR){
		m_comboSeq2.GetLBText(nCurrentSelected2,s2);
		if (s2=="Gabor")s2="G";
		else if (s2=="Fourier")s2="F";
		else if (s2=="Histogram")s2="H";
	}else s2="B";

	if (nCurrentSelected3!=LB_ERR){
		m_comboSeq3.GetLBText(nCurrentSelected3,s3);
		if (s3=="Gabor")s3="G";
		else if (s3=="Fourier")s3="F";
		else if (s3=="Histogram")s3="H";
	}else s3="B";

	seq=s1+s2+s3;	// store sequence of retrieval
	
	system->SetAlgorithm(m_filter);
	system->SetMethod(seq);
	CString useTime = system->StartRetrieval(selInput);
	if(useTime!="wait")// wait for slave
	{
		if (useTime == "-2"){
			m_strShow = m_strShow + "\n" + "error!!!";
			UpdateData(FALSE);}
		else if (useTime == "-1"){ // no image is retrieval
			CString ret="";
			ret.Format("%d",system->indexInCorrect);
			MessageBox("No image is retrieved from "+ret+" images","Output",0);
			m_strShow = m_strShow + "\n" + "No image is retrieved";
			UpdateData(FALSE);}
		else if (useTime == "0"){ // no method
			AfxMessageBox("Please select methode",MB_ICONSTOP);
			m_strShow = m_strShow + "\n" + "Please select method before";
			UpdateData(FALSE);}
		else if (useTime == "-3"){ // retrieval over limitted
			CString ret="";
			ret.Format("%d",used);
			AfxMessageBox("Over "+ ret + " images is retrieval",MB_ICONEXCLAMATION);
			int numRetrieval=system->indexCorrect;
			m_strShow = m_strShow + "\n";
			CString ttt="";
			ttt.Format("%d",numRetrieval);
			for (int i=0 ; i<3 ; i++){
				if(system->seq.GetAt(i)=='H'){		if(i!=0)patten=patten+",";
													patten=patten+"Histogram";}
				else if(system->seq.GetAt(i)=='F'){	if(i!=0)patten=patten+",";
													patten=patten+"Fourier";}
				else if(system->seq.GetAt(i)=='G'){	if(i!=0)patten=patten+",";
													patten=patten+"Gabor";}
			}
			if(system->filter)patten+="(Used key)";
			m_strShow = m_strShow + "Over" + ttt + " images result"+"\nby "+patten+" :";
			m_show_output.ResetContent();
			for (int num=0 ; num<numRetrieval ; num++){
				m_show_output.AddString("     "+*(system->resultFileName+num));
			}	
			UpdateData(FALSE);
		}
		else { // image is retrieval
			int allImg = system->indexInCorrect + system->indexCorrect;
			CString all="";	all.Format("%d",allImg);
			CString ret="";
			ret.Format("%d",system->indexCorrect);
			MessageBox("Retrieval "+ret+" image from " + all + " images"+"\n"+"Time " + useTime,"Output",0);
			CString* result=system->resultFileName;
	
			// show in detail
			int numRetrieval=system->indexCorrect;
			m_strShow = m_strShow + "\n";
			CString ttt="";
			ttt.Format("%d",numRetrieval);
			for (int i=0 ; i<3 ; i++){
				if(system->seq.GetAt(i)=='H'){		if(i!=0)patten=patten+",";
													patten=patten+"Histogram";}
				else if(system->seq.GetAt(i)=='F'){	if(i!=0)patten=patten+",";
													patten=patten+"Fourier";}
				else if(system->seq.GetAt(i)=='G'){	if(i!=0)patten=patten+",";
													patten=patten+"Gabor";}
			}
			if(system->filter)patten+="(Used key)";
			m_strShow = m_strShow + ttt + " images result from "+all+"\nby "+patten+" :";
			m_show_output.ResetContent();
			for (int num=0 ; num<numRetrieval ; num++){
				m_show_output.AddString("     "+*(system->resultFileName+num));
			}	
			CString tmp;
			tmp="Time => ";
			m_strShow = m_strShow + "\n" + tmp + useTime;
			UpdateData(FALSE);
			selOutput=0;
		}
	}else{// wait for slave
		
	}
		m_ResetButton.EnableWindow(true);
		m_show_output.SetFocus();
}

void CIRDlg::OnBnClickedCheckAlgor()
{
	// TODO: Add your control notification handler code here
	if (IsDlgButtonChecked(ID_CHECK_ALGOR)) m_filter=true;
	else m_filter=false;
	UpdateData(FALSE);
}

void CIRDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	switch (nSBCode){
		case 0				: sourcey = sourcey-2;if(sourcey<0)sourcey=0;break;//0;		break;//up
		case 1				: sourcey = sourcey+2;break;//INT_MAX;break;//down
		case 2				: sourcey = sourcey-10;if(sourcey<0)sourcey=0;break;
		case 3				: sourcey = sourcey+10;break;//down
		case SB_THUMBTRACK	: sourcey = nPos;	break;
	}
	m_vbar.SetScrollPos(sourcey);
	erase=true;
	InvalidateRect(&rectStaticClient);
	CDialog::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CIRDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	switch (nSBCode){
		case 0				: sourcex = sourcex-2;if(sourcex<0)sourcex=0;break;//0;		break;//left
		case 1				: sourcex = sourcex+2;break;//INT_MAX;break;//right
		case 2				: sourcex = sourcex-10;if(sourcey<0)sourcey=0;break;
		case 3				: sourcex = sourcex+10;break;//down
		case SB_THUMBTRACK	: sourcex = nPos;	break;
	}	
	m_hbar.SetScrollPos(sourcex);
	erase=true;
	InvalidateRect(&rectStaticClient);
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CIRDlg::OnBnClickedResetResult()
{
	// TODO: Add your control notification handler code here
	m_strShow = "";
	UpdateData(FALSE);
	m_show_input.ResetContent();
	m_show_output.ResetContent();
	system->targetImage.Destroy();
	system->resizeImage.Destroy();
}

void CIRDlg::OnBnClickedNormalimage()
{
	// TODO: Add your control notification handler code here
	if(system->targetImage.IsNull())return;
	else {
		sourcex=sourcey=0;
		system->targetImage.Destroy();
		if(focusInput)system->targetImage.Load(*((system->inputFileName)+selInput));
		else system->targetImage.Load(*((system->resultFileName)+selOutput));
		ShowPicture(system->targetImage);
	}
}

void CIRDlg::OnBnClickedGrayimage()
{
	// TODO: Add your control notification handler code here
	if(system->targetImage.IsNull())return;
	else {
		sourcex=sourcey=0;
		system->targetImage.Destroy();
		if(focusInput)system->targetImage.Load(*((system->inputFileName)+selInput));
		else system->targetImage.Load(*((system->resultFileName)+selOutput));
		system->targetImage.ToGrayImage();
		ShowPicture(system->targetImage);
	}
}

void CIRDlg::OnBnClickedEdgeimage()
{
	// TODO: Add your control notification handler code here
	if(system->targetImage.IsNull())return;
	else {
		sourcex=sourcey=0;
		system->targetImage.Destroy();
		if(focusInput)system->targetImage.Load(*((system->inputFileName)+selInput));
		else system->targetImage.Load(*((system->resultFileName)+selOutput));
		system->targetImage.ToEdgeImage();
		ShowPicture(system->targetImage);
	}
}

void CIRDlg::OnCbnSelchangeSeq1()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(ID_LEN_SEQ1)->EnableWindow(true);
}

void CIRDlg::OnCbnSelchangeSeq2()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(ID_LEN_SEQ2)->EnableWindow(true);
}

void CIRDlg::OnCbnSelchangeSeq3()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(ID_LEN_SEQ3)->EnableWindow(true);
}

void CIRDlg::OnEnChangeLenSeq1()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);
}

void CIRDlg::OnEnChangeLenSeq2()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);

}

void CIRDlg::OnEnChangeLenSeq3()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
	UpdateData(TRUE);

}

void CIRDlg::OnLbnDblclkShowOutput()
{
	// TODO: Add your control notification handler code here
	CheckRadioButton(ID_NORMALIMAGE,ID_EDGEIMAGE,ID_NORMALIMAGE);
	CString imgName="";
	int select = m_show_output.GetCurSel();
	imgName = system->filePath + *(system->resultFileName+select);
	if(system->targetImage)system->targetImage.Destroy();
	system->targetImage.Load(imgName);
	ShowPicture(system->targetImage);
	focusInput=false;	focusOutput=true;
	selOutput=select;
}
void CIRDlg::OnLbnDblclkShowInput()
{
	// TODO: Add your control notification handler code here
	CheckRadioButton(ID_NORMALIMAGE,ID_EDGEIMAGE,ID_NORMALIMAGE);
	CString imgName="";
	int select = m_show_input.GetCurSel();
	imgName = system->filePath + *(system->inputFileName+select);
	if(system->targetImage)system->targetImage.Destroy();
	system->targetImage.Load(imgName);
	ShowPicture(system->targetImage);
	focusInput=true;	focusOutput=false;
	selInput=select;
}

void CIRDlg::OnBnClickedCheck1()
{
	// TODO: Add your control notification handler code here
	if(system->distribute){
		m_searchAlgor.EnableWindow(true);
		system->distribute = false;}
	else {
		m_searchAlgor.EnableWindow(false);
		system->distribute = true;}
}

void CIRDlg::OnBnClickedSlaveMode()
{	
	// TODO: Add your control notification handler code here
	if(!m_slaveMode){
		m_slaveMode=true;
		m_masterMode=false;
		m_ResetButton.EnableWindow(false);
		m_StoreButton.EnableWindow(false);
		m_RetrieveButton.EnableWindow(false);
		m_ChooseButton.EnableWindow(false);	
		
		if(system->SlaveListen()){
			system->slave_connSock.SetParent(this);
			system->slave_listenSock.SetParent(this);
			system->master_connSock.SetParent(this);
			system->m_bConnectFlag=false;
			MessageBox("Slave Mode","Mode");
		}
		else {
			m_ChooseButton.EnableWindow(true);
			CheckRadioButton(ID_SERVER_MODE,ID_CLIENT_MODE,ID_SERVER_MODE);
		}
	}
}

void CIRDlg::OnBnClickedMasterMode()
{
	// TODO: Add your control notification handler code here
	if(!m_masterMode){
		m_masterMode=true;
		m_slaveMode=false;
		m_ResetButton.EnableWindow(false);
		m_StoreButton.EnableWindow(false);
		m_RetrieveButton.EnableWindow(false);
		m_ChooseButton.EnableWindow(true);

		system->SlaveClose();
		MessageBox("Master Mode","Mode");	
	}
}


void CIRDlg::OnBnClickedZoomIn()
{
	// TODO: Add your control notification handler code here
	if(system->targetImage){
		Image zoom;
		system->targetImage.Zoom(zoom,'i');
		system->targetImage=zoom;
		sourcex=sourcey=0;
		ShowPicture(zoom);
	}
}

void CIRDlg::OnBnClickedZoomOut()
{
	// TODO: Add your control notification handler code here
	if(system->targetImage){
		Image zoom;
		system->targetImage.Zoom(zoom,'o');
		system->targetImage=zoom;
		sourcex=sourcey=0;
		ShowPicture(zoom);
	}
}
