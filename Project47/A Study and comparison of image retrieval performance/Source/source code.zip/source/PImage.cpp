/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#include "StdAfx.h"
#include "pimage.h"

CPImage::CPImage(void)
{
	for (int n=0 ; n<numHistogram ; n++)histogram[n]=0;
	for (int n=0 ; n<numFourierDesc ; n++)fourierDesc[n]=0;
	for (int n=0 ; n<numGaborDesc ; n++)gaborDesc[n]=0;
}

CPImage::~CPImage(void){}

COLORREF CPImage::GetColor(int x,int y)
{
	BYTE *p = (BYTE*)GetPixelAddress(x,y);
	BYTE red = *(p+2);
	BYTE green = *(p+1);
	BYTE blue = *p;
	return RGB(red,green,blue);
}

void CPImage::SetColor(int x,int y,COLORREF color)
{
	BYTE *p = (BYTE*)GetPixelAddress(x,y);
	*p++ = GetBValue(color);
	*p++ = GetGValue(color);
	*p = GetRValue(color);
}

double CPImage::GetGray(int x,int y)
{	
	COLORREF color=GetColor(x,y);
	double r=(double)GetRValue(color)*0.299;
	double g=(double)GetGValue(color)*0.587;
	double b=(double)GetBValue(color)*0.144;
	double total=r+b+g;
	if(total>255)return 255;
	else if(total<0)return 0;
	else return total;
}

double CPImage::GenMean()
{
	int width=GetWidth();
	int height=GetHeight();
	double all=0;

	for (int i=0 ; i<numHistogram ; i++){all=all+(i*histogram[i]);}
	return all/(width*height);
}

void CPImage::GenStrHis(CString& histogramStr)
{
	CString strValue="";
	histogramStr="";
	int srcLen=0;
	int dstLen=0;
	double his=0;
	for (int i=0 ; i<numHistogram ; i++){
		his = (int)(histogram[i]);// convert to % of all
		strValue.Format("%.0f",his);//have 2 positions _ _
		if (i!=0) histogramStr = histogramStr + "," + strValue;
		else histogramStr= strValue;
	}	
}

void CPImage::GenStrFourier(CString& fourierStr)
{
	CString strValue="";
	fourierStr="";
	double allValue=0;
	double fourierValue=0;
	for (int n=0 ; n<numFourierDesc ; n++){allValue = allValue + fourierDesc[n];}
	for (int i=0 ; i<numFourierDesc ; i++){
		fourierValue=(int)((fourierDesc[i]/allValue)*1000);//conver to % of all
		strValue.Format("%.0f",fourierValue);//have 2 positions _ _
		if (i!=0) fourierStr = fourierStr + "," + strValue;
		else fourierStr = strValue;
	}
}
void CPImage::GenSetGabor(CString& gaborStr)
{
	CString strValue="";
	gaborStr="";
	double allMean=0;
	double allVariance=0;
	double gaborValue=0;
	for (int n=0 ; n<numGaborDesc ; n++){
		if(n%2 == 1){allVariance = allVariance + gaborDesc[n];}
		else		{allMean = allMean + gaborDesc[n];}
	}
	
	for (int i=0 ; i<numGaborDesc ; i++){
		if(i%2 == 1){gaborValue = (int)((gaborDesc[i]/allVariance)*1000);}
		else		{gaborValue = (int)((gaborDesc[i]/allMean)*1000);}
		strValue.Format("%.0f",gaborValue);//have 2 positions _ _
		if (i!=0) gaborStr = gaborStr + "," + strValue;
		else gaborStr = strValue;
	}
}