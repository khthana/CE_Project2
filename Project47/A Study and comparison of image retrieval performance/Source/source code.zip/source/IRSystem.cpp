/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#include "stdafx.h"
#include "IRSystem.h"

IRSystem::IRSystem(void)
{	
	resultFileName=new CString[used];
	seq="";
	filter=false;
	distribute=false;
	inputFileName = new CString[maxOpenFile];
	numFileName=0;
	filePath="";
	m_bConnectFlag=false;
	receiveSize=0;
}

IRSystem::~IRSystem(void)
{
	delete[] resultFileName;
	delete[] inputFileName;
}

bool IRSystem::OpenImage(CString* name)
{
	// ====== store image in targetImage ======
	if (targetImage)targetImage.Destroy();
	targetImage.Load(*(name+0));// show first image of all
	
	CString tmpStr;
	int startName=0;	char tmp;
	for (int a=0 ; a<maxOpenFile ; a++){*(inputFileName+a)="";}
	for (int i=0 ; i<numFileName ; i++){
		startName=0;
		tmpStr=*(name+i);
		for (int j=tmpStr.GetLength() ; j>=0 ; j--){
			tmp=tmpStr.GetAt(j);
			if (tmp==92){startName=j+1;	break;}
		}
		for (int k=startName ; k <tmpStr.GetLength() ; k++){*(inputFileName+i)=*(inputFileName+i)+tmpStr[k];}
	}
	filePath="";
	tmpStr=*(name+0);
	for (int t=0 ; t<startName ; t++){
		filePath = filePath + tmpStr.GetAt(t);;
	}
	if(targetImage)return true;
	else return false;
}


void IRSystem::SetMethod(CString pattern)
{
	if (pattern=="")return;
	seq = pattern;
}
void IRSystem::SetAlgorithm(BOOL algor)
{
	filter = algor;
}

void IRSystem::GetFeature2Form(int sub,int** allHistogram,int** allFourier,int** allGabor)
{
	bool his=false,fourier=false,gabor=false;
	for(int i=0 ; i<3 ; i++){
		if(seq.GetAt(i)=='H')his=true;
		else if(seq.GetAt(i)=='F')fourier=true;
		else if(seq.GetAt(i)=='G')gabor=true;
	}
	double tmp=0;
	double allMean=0;
	double allVariance=0;
	if (sub == 0){// for subImage0
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+0)+i) = (int)(resizeImage.sub0.histogram[i]);}
		}		
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub0.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+0)+i) = (int)((resizeImage.sub0.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub0.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub0.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+0)+i) = (int)((resizeImage.sub0.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+0)+i) = (int)((resizeImage.sub0.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 1){// for subImage1
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+1)+i) = (int)(resizeImage.sub1.histogram[i]);}
		}
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub1.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+1)+i) = (int)((resizeImage.sub1.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub1.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub1.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+1)+i) = (int)((resizeImage.sub1.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+1)+i) = (int)((resizeImage.sub1.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 2){// for subImage2
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+2)+i) = (int)(resizeImage.sub2.histogram[i]);}
		}
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub2.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+2)+i) = (int)((resizeImage.sub2.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub2.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub2.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+2)+i) = (int)((resizeImage.sub2.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+2)+i) = (int)((resizeImage.sub2.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 3){// for subImage3
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+3)+i) = (int)(resizeImage.sub3.histogram[i]);}
		}		
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub3.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+3)+i) = (int)((resizeImage.sub3.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub3.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub3.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+3)+i) = (int)((resizeImage.sub3.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+3)+i) = (int)((resizeImage.sub3.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 4){// for subImage4
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+4)+i) = (int)(resizeImage.sub4.histogram[i]);}
		}		
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub4.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+4)+i) = (int)((resizeImage.sub4.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub4.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub4.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+4)+i) = (int)((resizeImage.sub4.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+4)+i) = (int)((resizeImage.sub4.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 5){// for subImage5
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+5)+i) = (int)(resizeImage.sub5.histogram[i]);}
		}
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub5.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+5)+i) = (int)((resizeImage.sub5.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub5.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub5.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+5)+i) = (int)((resizeImage.sub5.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+5)+i) = (int)((resizeImage.sub5.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 6){// for subImage6
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+6)+i) = (int)(resizeImage.sub6.histogram[i]);}
		}		
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub6.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+6)+i) = (int)((resizeImage.sub6.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub6.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub6.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+6)+i) = (int)((resizeImage.sub6.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+6)+i) = (int)((resizeImage.sub6.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 7){// for subImage7
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+7)+i) = (int)(resizeImage.sub7.histogram[i]);}
		}
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub7.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+7)+i) = (int)((resizeImage.sub7.fourierDesc[i]/tmp)*1000);}
		}
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub7.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub7.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+7)+i) = (int)((resizeImage.sub7.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+7)+i) = (int)((resizeImage.sub7.gaborDesc[i]/allMean)*1000);}}
		}
	}
	else if (sub == 8){// for subImage8
		if(his){
			for (int i=0 ; i<numHistogram ; i++){*(*(allHistogram+8)+i) = (int)(resizeImage.sub8.histogram[i]);}
		}
		if(fourier){
			for (int i=0 ; i<numFourierDesc ; i++){tmp = tmp + resizeImage.sub8.fourierDesc[i];}
			for (int i=0 ; i<numFourierDesc ; i++){*(*(allFourier+8)+i) = (int)((resizeImage.sub8.fourierDesc[i]/tmp)*1000);}
		}		
		if(gabor){
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){allVariance = allVariance + resizeImage.sub8.gaborDesc[i];}
				else		{allMean = allMean + resizeImage.sub8.gaborDesc[i];}}
			for (int i=0 ; i<numGaborDesc ; i++){
				if(i%2 == 1){*(*(allGabor+8)+i) = (int)((resizeImage.sub8.gaborDesc[i]/allVariance)*1000);}
				else		{*(*(allGabor+8)+i) = (int)((resizeImage.sub8.gaborDesc[i]/allMean)*1000);}}
		}
	}
}

void IRSystem::StoreResult(int* correct,int indexCorrect)
{
	for(int i=0 ; i<used ; i++){*(resultFileName+i)="";}
	CString resultNo="";
	for (int num=0 ; num<indexCorrect ; num++){// do all correct image format to CString for query
		if(num < used){
			CString tmp;	tmp.Format("%d",(*(correct+num)));
			if(num!=0)resultNo = resultNo+","+tmp;
			else resultNo = tmp;
		}
	}
	CString table = IdentityImageTable;
	CString sqlStr = "SELECT ImgName FROM "+table+" WHERE ImgNo IN("+resultNo+")";
	CDatabase myDB;
	if (!myDB.IsOpen())ConnDB(myDB);

	CRecordset rs(&myDB);// rs is point to myDB
	rs.Open(CRecordset::snapshot,sqlStr,CRecordset::none);
	rs.MoveFirst();
	CDBVariant varValue;	
	int numImage=0;// number of image are retrieved
	int posImgNo=0;
	while(! rs.IsEOF()){
		rs.GetFieldValue(posImgNo,varValue);	
		*(resultFileName+numImage)=*(varValue.m_pstring);
		numImage++;
		rs.MoveNext();
	}
	DisConnDB(myDB);
}

bool IRSystem::Compare(char feature,int liker,CString* value1,int* value2,int num)
{
	CString strTmpV1;//	CString tmpV2;	
	int intValue1=0;
	int len=(*value1).GetLength();
	int indexV1=0;
	double accLen=0;
	double perLen=0;
	perLen=100.0-liker;
	for (int n=0 ; n<num ; n++){
		strTmpV1=(*value1).GetAt(indexV1);
		while((*value1).GetAt(indexV1+1)!=','){
			strTmpV1 = strTmpV1 + (*value1).GetAt(indexV1+1);
			indexV1++;
			if(indexV1==len)break;
		}
		indexV1 = indexV1 + 2;
 		sscanf(strTmpV1,"%d",&intValue1);

		if(feature=='h')accLen=perLen;else accLen=perLen*5;
		if( accLen < abs(intValue1-*(value2+n)) )
		{return false;}
	}
	return true;
}

bool IRSystem::CheckImage(void)
{
	if (targetImage.IsNull())			{AfxMessageBox("You have to load image before",MB_ICONSTOP);	return false;}
	else if (targetImage.GetBPP()!=24)	{AfxMessageBox("Image file must has 24 bits",MB_ICONSTOP);		return false;}
	else return true;
}

void IRSystem::FindImageFeatureForStore(void)
{
	targetImage.ReSize(resizeImage);// resizing targetImage
	resizeImage.PartitionImage();	// stril have problem

	resizeImage.Histogram();
	resizeImage.Fourier();
	resizeImage.Gabor();
}

CString IRSystem::FindKey(void)
{
	// ====== Find Key ======
	CString key="-1";
	int mean1,mean2,mean3;
	mean1=(int)(resizeImage.sub2.GenMean()*1000);
	mean2=(int)(resizeImage.sub4.GenMean()*1000);
	mean3=(int)(resizeImage.sub6.GenMean()*1000);
	
	if (mean1 > mean2){
		if (mean2 > mean3){key="13";}
		else if (mean2 == mean3){key="12";}
		else if (mean2 < mean3 && mean1 < mean3){key="9";}
		else if (mean2 < mean3 && mean1 == mean3){key="10";}
		else if (mean2 < mean3 && mean1 > mean3){key="11";}		
	}
	else if (mean1 == mean2){
		if (mean2 > mean3){key="3";}
		else if (mean2 == mean3){key="2";}
		else if (mean2 < mean3){key="1";}	
	}
	else if (mean1 < mean2){
		if (mean2 > mean3 && mean3 > mean1){key="6";}
		else if (mean2 > mean3 && mean3 == mean1){key="7";}
		else if (mean2 > mean3 && mean3 < mean1){key="8";}
		else if (mean2 == mean3){key="5";}
		else if (mean2 < mean3){key="4";}
	}
	return key;
}

void IRSystem::GetFeatureStrValue(int subNo,CString& histogramStr,CString& fourierStr,CString& gaborStr)
{
	if (subNo==0){
		resizeImage.sub0.GenStrHis(histogramStr);
		resizeImage.sub0.GenStrFourier(fourierStr);
		resizeImage.sub0.GenSetGabor(gaborStr);
	}
	else if (subNo==1){
		resizeImage.sub1.GenStrHis(histogramStr);
		resizeImage.sub1.GenStrFourier(fourierStr);
		resizeImage.sub1.GenSetGabor(gaborStr);	
	}
	else if (subNo==2){
		resizeImage.sub2.GenStrHis(histogramStr);
		resizeImage.sub2.GenStrFourier(fourierStr);
		resizeImage.sub2.GenSetGabor(gaborStr);
	}
	else if (subNo==3){
		resizeImage.sub3.GenStrHis(histogramStr);
		resizeImage.sub3.GenStrFourier(fourierStr);
		resizeImage.sub3.GenSetGabor(gaborStr);
	}
	else if (subNo==4){
		resizeImage.sub4.GenStrHis(histogramStr);
		resizeImage.sub4.GenStrFourier(fourierStr);
		resizeImage.sub4.GenSetGabor(gaborStr);
	}
	else if (subNo==5){
		resizeImage.sub5.GenStrHis(histogramStr);
		resizeImage.sub5.GenStrFourier(fourierStr);
		resizeImage.sub5.GenSetGabor(gaborStr);
	}
	else if (subNo==6){
		resizeImage.sub6.GenStrHis(histogramStr);
		resizeImage.sub6.GenStrFourier(fourierStr);
		resizeImage.sub6.GenSetGabor(gaborStr);
	}
	else if (subNo==7){
		resizeImage.sub7.GenStrHis(histogramStr);
		resizeImage.sub7.GenStrFourier(fourierStr);
		resizeImage.sub7.GenSetGabor(gaborStr);
	}
	else if (subNo==8){
		resizeImage.sub8.GenStrHis(histogramStr);
		resizeImage.sub8.GenStrFourier(fourierStr);
		resizeImage.sub8.GenSetGabor(gaborStr);
	}
}

void IRSystem::FindImageFeatureForRetrieval(CString seq)
{
	targetImage.ReSize(resizeImage);// resizing targetImage
	resizeImage.PartitionImage();	// stril have problem	
	bool his=false , fourier=false , gabor=false;
	for(int n=0 ; n<3 ; n++){
		switch(seq[n]){
			case 'H' : {if (!his){resizeImage.Histogram();	his=true;}}		break;
			case 'F' : {if (!fourier){resizeImage.Fourier();fourier=true;}}	break;
			case 'G' : {if (!gabor){resizeImage.Gabor();	gabor=true;}}	break;
		}
	}
	if (!his && filter)resizeImage.OnlyKeyHistogram();
}
void IRSystem::DoRetrieve(CRecordset &rs,int startRow,int endRow,int* correct,int* inCorrect,int** allHistogram,int** allFourier,int** allGabor,CString patten)
{
	CDBVariant varValue;
	int imgNo;	
	int subImg;	
	bool script=false;
	bool same=false;
	int imgNoPos=0;
	CString* his=new CString;	
	CString* fourier=new CString;	
	CString* gabor=new CString;

	int counter=startRow*9;
	rs.Move(counter);
	int limmit=(endRow*9);
	while(counter<limmit){
		script=false;
		rs.GetFieldValue(imgNoPos,varValue);
		imgNo	= varValue.m_iVal;
		// ========== check incorrect ===========
		for (int n=0 ; n<indexInCorrect ; n++){if (imgNo == *(inCorrect+n)){script=true; break;}}
		if (!script){
		// ================== Get Other Value ====================
			for (int j=1 ; j<5 ; j++){
				rs.GetFieldValue(j,varValue);
				if (j==1){subImg	= varValue.m_iVal;}
				else if (j==2){*his		= *varValue.m_pstring;}
				else if (j==3){*fourier = *varValue.m_pstring;}
				else if (j==4){*gabor	= *varValue.m_pstring;}
			}
		// ============================ Compare & select ==========================
			for (int n=0 ; n<3 ; n++){
				char meth=patten.GetAt(n);	int liker=0;
				if (meth!='B'){
					switch(n){
						case 0 : {liker=len_seq1;}break;
						case 1 : {liker=len_seq2;}break;
						case 2 : {liker=len_seq3;}break;}
					switch(meth){
						case 'H': {same = Compare('h',liker,his,*(allHistogram+subImg),numHistogram);};		break;
						case 'F': {same = Compare('f',liker,fourier,*(allFourier+subImg),numFourierDesc);};	break;
						case 'G': {same = Compare('g',liker,gabor,*(allGabor+subImg),numGaborDesc);};		break;}
					if (same){// same subImage
						bool already=false;
						for (int index=0 ; index<indexCorrect ; index++){if (*(correct+index) == imgNo){already=true;break;}}
						if (! already){
							*(correct+indexCorrect)=imgNo;
							indexCorrect++;}
					}
					else {// not same subImage
						bool already=false;
						for (int index=0 ; index<indexInCorrect ; index++){if (*(inCorrect+index) == imgNo)already=true;break;}
						if (! already){
							*(inCorrect+indexInCorrect)=imgNo;
							indexInCorrect++;}
						for (int indexC=0 ; indexC<indexCorrect ; indexC++){
							if (*(correct+indexC)==imgNo){
								*(correct+indexC)=-1;
								indexCorrect--;
								for (int n=indexC ; n<indexCorrect ; n++)*(correct+indexC)=*(correct+indexC+1);
							}
						}
						break;
					}
					same=false;
				}				
			}
		}
		// ========================== End Compare & select ========================
		if (indexCorrect!=used){rs.MoveNext();counter++;}
		else {break;}
	}
}
int IRSystem::FindAllImage(CString key)// find all image in database
{
	CDatabase myDB;
	CDBVariant varValue;
	int allImage=0;	int posImgNo=0;
	CString table = IdentityImageTable;
	CString sqlStr = "";
	if(key=="")sqlStr="SELECT COUNT(*) FROM " + table;
	else sqlStr="SELECT COUNT(*) FROM " + table + " WHERE KeyValue like '"+key+"'";
	ConnDB(myDB);		
	CRecordset rs(&myDB);
	rs.Open(CRecordset::dynaset,sqlStr,CRecordset::none);
	rs.GetFieldValue(posImgNo,varValue);
	rs.Close();
	DisConnDB(myDB);
	allImage=varValue.m_iVal;
	return allImage;
}
CString IRSystem::StartRetrieval(int selInput)
{
	targetImage.Destroy();
	targetImage.Load(*(inputFileName+selInput));

	if (CheckImage()==false)return "-2";
	if (seq=="BBB")return "0";	
	// ====== Prepare Image & Find image feature ======
	SetCurrentTime('s');
	FindImageFeatureForRetrieval(seq);	

	int** allHistogram = new int*[9];
		for (int sub=0 ; sub<9 ; sub++){*(allHistogram + sub)=new int[numHistogram];}
	int** allFourier = new int*[9];
		for (int sub=0 ; sub<9 ; sub++){*(allFourier + sub)=new int[numFourierDesc];}
	int** allGabor = new int*[9];
		for (int sub=0 ; sub<9 ; sub++){*(allGabor + sub)=new int[numGaborDesc];}

	for (int sub=0 ; sub<9 ; sub++){GetFeature2Form(sub,allHistogram,allFourier,allGabor);}
	int* inCorrect = new int[notUsed];					
	int* correct = new int[used];
	if(!distribute){
		RetrieveAlone(allHistogram,allFourier,allGabor,correct,inCorrect);
		SetCurrentTime('e');
		SetCurrentTime('r');
		for (int sub=0 ; sub<9 ; sub++){delete[] *(allHistogram + sub);} delete[] allHistogram;
		for (int sub=0 ; sub<9 ; sub++){delete[] *(allFourier + sub);}	 delete[] allFourier;
		for (int sub=0 ; sub<9 ; sub++){delete[] *(allGabor + sub);}	 delete[] allGabor;
		if (indexCorrect==0){return "-1";}
		else if (indexCorrect == used){
			StoreResult(correct,indexCorrect);
			return "-3";}
		else {
			StoreResult(correct,indexCorrect);
			return resultTime;
		}
	}
	else {
		RetrieveDistribute(allHistogram,allFourier,allGabor,correct,inCorrect);
		for (int sub=0 ; sub<9 ; sub++){delete[] *(allHistogram + sub);} delete[] allHistogram;
		for (int sub=0 ; sub<9 ; sub++){delete[] *(allFourier + sub);}	 delete[] allFourier;
		for (int sub=0 ; sub<9 ; sub++){delete[] *(allGabor + sub);}	 delete[] allGabor;
		delete[] inCorrect;
		delete[] correct;
		return "wait";
	}
}

void IRSystem::RetrieveAlone(int** allHistogram,int** allFourier,int** allGabor,int* correct,int* inCorrect)
{
	CString key="";
	CString sqlStr="";
	CString table = ImageFeatureTable;
	CDatabase myDB;

	for (int j=0 ; j<notUsed ; j++){*(inCorrect+j)=-1;}	
	for (int j=0 ; j<used ; j++){*(correct+j)=-1;}
	indexInCorrect=0;	indexCorrect=0;
	
	// ======================= Query String ===============================
	if (filter){// Filter Image
		key = FindKey();
		sqlStr = "SELECT * FROM "+ table +
				 " WHERE ImgNo IN (SELECT ImgNo FROM "+IdentityImageTable+
								  " WHERE KeyValue like'" + key + "')";
	}
	else {sqlStr = "SELECT * FROM " + table;}// not use Filter Image
	int allImage =0;
	allImage = FindAllImage(key); 
	if (!myDB.IsOpen())ConnDB(myDB);
	CRecordset rs(&myDB);// rs is point to myDB
	rs.Open(CRecordset::snapshot,sqlStr,CRecordset::none);
	DoRetrieve(rs,0,allImage,correct,inCorrect,allHistogram,allFourier,allGabor,seq);
	rs.Close();
	DisConnDB(myDB);
}

void IRSystem::RetrieveDistribute(int** allHistogram,int** allFourier,int** allGabor,int* correct,int* inCorrect)
{
	bool his=false,fourier=false,gabor=false; 
	char se;
	for(int j=0 ; j<3 ; j++){
		se=seq.GetAt(j);
		if(se=='H')his=true;
		else if(se=='F')fourier=true;
		else if(se=='G')gabor=true;}
	int allImage=FindAllImage("");
	MasterOnConnect();
	if(master_connSock.GetLastError() != WSAEWOULDBLOCK){
		char strError[256];
		wsprintf(strError,"Socket failed to send,Error Code:%d",master_connSock.GetLastError());
		MasterClose();
		AfxMessageBox(strError);
	}else{
		// ====== prepare feature data ======
		CString histogramStr="";CString fourierStr="";CString gaborStr="";
		CString start="";		CString end="";
		CString strSendSize="";
		for (int subNo=0 ; subNo<9 ; subNo++){ // all 9 SubImage
			GetFeatureStrValue(subNo,histogramStr,fourierStr,gaborStr);
			if(his){if(subNo==0)sendData = sendData+histogramStr;
					else sendData = sendData+":"+histogramStr;}
			if(fourier){
				if(his){sendData = sendData+"/"+fourierStr;}
				else{if(subNo==0)sendData = sendData+fourierStr;
					 else sendData = sendData+":"+fourierStr;}}
			if(gabor){
				if(his || fourier){sendData = sendData+"/"+gaborStr;}
				else{if(subNo==0)sendData = sendData+gaborStr;
					 else sendData = sendData+":"+gaborStr;}}			
			histogramStr="";	fourierStr="";		gaborStr="";
		}
		start.Format("%d",0);
		end.Format("%d",allImage);
		sendData=sendData+"<"+start+","+end+">";
		sendData = sendData+"E";
		// sendData=>01,01,.../02,02,.../03,03,...:11,11,.../12,12,.........<start,end><key>e
		int sendSize = sendData.GetLength();
		strSendSize.Format("%d",sendSize);
		CString seq1="",seq2="",seq3="";
		seq1.Format("%d",len_seq1);	seq2.Format("%d",len_seq2);	seq3.Format("%d",len_seq3);
		MasterSend("a"+seq1+","+seq2+","+seq3);
		MasterSend("s"+strSendSize);	// "s"=> size
		MasterSend("d"+seq+sendData);		// "d"=> data
		sendData="";
	}
}

void IRSystem::SetCurrentTime(char type)
{
	char tmpbuf[20];
	_strtime( tmpbuf );
	switch(type){
		case's' : {startTime = tmpbuf;}	break;
		case'e' : {endTime = tmpbuf;}	break;
		case'r' : {
					int h1=0 , m1=0 , s1=0;
					int h2=0 , m2=0 , s2=0;
					int h=0	, m=0 , s=0;
					CString tmp1="",tmp2="";
					for (int n=0 ; n<7 ; n++){
						tmp1=startTime.GetAt(n);	tmp1=tmp1 + startTime.GetAt(n+1);
						tmp2=endTime.GetAt(n);		tmp2=tmp2 + endTime.GetAt(n+1);
						if(n==0){
							sscanf( tmp1, "%d", &h1 );
							sscanf( tmp2, "%d", &h2 );}
						else if(n==3){
							sscanf( tmp1, "%d", &m1 );
							sscanf( tmp2, "%d", &m2 );}
						else if(n==6){
							sscanf( tmp1, "%d", &s1 );
							sscanf( tmp2, "%d", &s2 );}
					}
					h1 = h1 * 3600;	h2 = h2 * 3600;
					m1 = m1 * 60;	m2 = m2 * 60;
					int all1 = h1 + m1 + s1;
					int all2 = h2 + m2 + s2;
					int all  = all2 - all1;
					h = all/3600;	
					m = (all - (h*3600))/60;
					s = all - (h*3600) - (m*60);
					CString hour;	hour.Format("%d",h);
					CString min;	min.Format("%d",m);
					CString sec;	sec.Format("%d",s);
					resultTime = hour + ":" + min + ":" + sec;
	   			  } break;
	}
}

CString IRSystem::StartStore(void)
{	
	CString key="";
	CString sqlStr="";
	CString histogramStr="";
	CString fourierStr=""; 
	CString gaborStr="";
	
	CDatabase myDB;	
	CString table = IdentityImageTable;		
	CString field = IdentityImageField;
	CString sub;
	CString imgNo;
	SetCurrentTime('s');// set start time
	for(int numFile=0 ; numFile<numFileName ; numFile++){		
		targetImage.Destroy();	
		targetImage.Load(*(inputFileName+numFile));	
		if (CheckImage()==false)return "0";
		// ====== Prepare Image & Find image feature ======
		FindImageFeatureForStore();
		key = FindKey();
		table = IdentityImageTable;
		field = IdentityImageField;
		sqlStr="";
		histogramStr="";	fourierStr=""; 	gaborStr="";				
		// ====== Insert in IdentityImageTable ======	
		if (!myDB.IsOpen())ConnDB(myDB);
		sqlStr = "INSERT INTO " + table + "(" + field + ") VALUES('" + *(inputFileName+numFile) + "','" + key + "')";
		myDB.ExecuteSQL(sqlStr);
		DisConnDB(myDB);
		// ====== Get ImgNo ======
		sqlStr = "SELECT ImgNo FROM "+table+" WHERE ImgName like '"+*(inputFileName+numFile)+"'";
		if (!myDB.IsOpen())ConnDB(myDB);		
		CRecordset rs(&myDB);
		rs.Open(CRecordset::dynaset,sqlStr,CRecordset::none);
		rs.GetFieldValue(0,imgNo);
		rs.Close();
		// ====== Store each SubImage ======
		for (int subNo=0 ; subNo<9 ; subNo++){ // all 9 SubImage
			GetFeatureStrValue(subNo,histogramStr,fourierStr,gaborStr);//get Feature in string format
			table = ImageFeatureTable;
			field = ImageFeatureField;			
			sub.Format("%u",subNo);
			sqlStr= "INSERT INTO " + table + "(" + field + ") VALUES("+imgNo +"," + sub +",'"+histogramStr+"','"+fourierStr+"','"+gaborStr+"')";
			myDB.ExecuteSQL(sqlStr);
		}
		DisConnDB(myDB);
	}
	SetCurrentTime('e');// stop timer
	SetCurrentTime('r');// set used time
	return resultTime;
}

void IRSystem::ConnDB(CDatabase &myDB)
{
	CString user=DBUser;
	CString pass=DBPass;
	myDB.Open(_T(DBName),false,false,_T("ODBC;UID="+user+";PWD="+pass),false);//DSN,Exclusive,ReadOnly,ODBC Connect string,no used cursor lib
}

void IRSystem::DisConnDB(CDatabase &myDB){myDB.Close();}

void IRSystem::MasterClose()
{
	sendData="";
	receiveData="";
	m_bConnectFlag = false;
	master_connSock.Close();
}
void IRSystem::MasterOnConnect()
{
	int port = portConn;
	m_strSlaveIP = slaveIP;
	master_connSock.Create();
	master_connSock.Connect(m_strSlaveIP,port);
}
void IRSystem::MasterConnected()
{
	UINT tempMasterPort=0;
	master_connSock.GetSockName(m_strMasterIP,tempMasterPort);// get ip address,port if master
	m_intMasterPort = tempMasterPort;
}
void IRSystem::MasterProcess()
{
	CString result=receiveData;
	int intValue=0;		CString strValue="";	int indexCorrect=0;
	int* correct = new int[used];		for (int j=0 ; j<used ; j++){*(correct+j)=-1;}	
	for(int i=0 ; i<result.GetLength() ; i++){
		if(result.GetAt(i)==','){
			if(strValue!="-1")sscanf(strValue,"%d",&intValue);
			else break;
			*(correct+indexCorrect)=intValue;
			indexCorrect++;
			strValue="";
		}
		else strValue=strValue+result.GetAt(i);
	}
	SetCurrentTime('e');
	SetCurrentTime('r');
	CString ret="";
	if (indexCorrect==0){
	}
	else if (indexCorrect == used){
		StoreResult(correct,indexCorrect);
	}
	else {
		StoreResult(correct,indexCorrect);
	}
	MasterClose();
}
void IRSystem::MasterReceive(CString buffData)
{
	buffData.Delete(0,1);
	receiveData = buffData;
	MasterProcess();	
}
void IRSystem::MasterSend(CString dataForSend)
{
	CString data=dataForSend;
	int dwBytes = master_connSock.Send(data,data.GetLength());
	if(dwBytes==SOCKET_ERROR)
	{
		if(master_connSock.GetLastError()!=WSAEWOULDBLOCK)
		{
			char strError[256];
			wsprintf(strError,"Socket failed to send,Error Code:%d",master_connSock.GetLastError());
			master_connSock.Close();
			AfxMessageBox(strError);
		}
	}
}
bool IRSystem::SlaveListen()
{
	m_intCountSentByte=0;
	int port=portConn;
	if(!slave_listenSock.Create(port)){
		char strError[256];
		wsprintf(strError,"Socket faled to create,Error Code:%d",slave_listenSock.GetLastError());
		AfxMessageBox(strError,1);
		slave_listenSock.Close();	
		return false;
	}
	slave_listenSock.Listen();
	return true;
}
void IRSystem::SlaveClose()
{
	sendData="";
	receiveData="";
	slave_connSock.Close();
	slave_listenSock.ShutDown();
	slave_listenSock.Close();
}
void IRSystem::SlaveAccept()
{
	if(m_bConnectFlag){
		CAsyncSocket RejectSock;	// new socket
		CString strInfo;
		strInfo = "over connection,please try again";

		slave_listenSock.Accept(RejectSock);
		RejectSock.Send(LPCTSTR(strInfo),strInfo.GetLength());
		RejectSock.Close();
	}else{
		m_bConnectFlag = true;
		UINT tempSlavePort = 0;
		UINT tempMasterPort = 0;		
		slave_listenSock.Accept(slave_connSock);
		// show slave IP address => local
		slave_connSock.GetSockName(m_strSlaveIP,tempSlavePort);
		m_strSlavePort = tempSlavePort;
		// show master IP address => remote
		slave_connSock.GetPeerName(m_strMasterIP,tempMasterPort);
		m_intMasterPort = tempMasterPort;
	}
}
void IRSystem::SlaveProcess()
{
	bool his=false,fourier=false,gabor=false;int startOp=4;
	int numFeature=0;
	for(int j=1 ; j<4 ; j++){char t=receiveData.GetAt(j);
		if(t=='H'){his=true;numFeature++;}
		else if(t=='F'){fourier=true;numFeature++;}
		else if(t=='G'){gabor=true;numFeature++;}
	}
	int** allHistogram = new int*[9];
		for (int sub=0 ; sub<9 ; sub++){*(allHistogram + sub)=new int[numHistogram];}
	int** allFourier = new int*[9];
		for (int sub=0 ; sub<9 ; sub++){*(allFourier + sub)=new int[numFourierDesc];}
	int** allGabor = new int*[9];
		for (int sub=0 ; sub<9 ; sub++){*(allGabor + sub)=new int[numGaborDesc];}
	int pos=numFeature;
	int indexHis=0,indexFourier=0,indexGabor=0;
	int subNo=0;	CString strValue="";		char tmp;	int intValue=0;
	int lenData=receiveData.GetLength();
	bool endFeature=false;
	// convert data to form
	for(int i=startOp ; i<lenData ; i++){
		tmp=receiveData.GetAt(i);
		switch(tmp){
			case ':' : {sscanf(strValue,"%d",&intValue);
						if(receiveData.GetAt((numFeature-pos)+1)=='H'){
							*(*(allHistogram+subNo)+indexHis)=intValue;
							indexHis++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='F'){
							*(*(allFourier+subNo)+indexFourier)=intValue;
							indexFourier++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='G'){
							*(*(allGabor+subNo)+indexGabor)=intValue;
							indexGabor++;}
						strValue="";
						indexHis=0;	indexFourier=0;	indexGabor=0;
						pos=numFeature;	subNo++;}break;
			case '/' : {sscanf(strValue,"%d",&intValue);
						if(receiveData.GetAt((numFeature-pos)+1)=='H'){
							*(*(allHistogram+subNo)+indexHis)=intValue;
							indexHis++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='F'){
							*(*(allFourier+subNo)+indexFourier)=intValue;
							indexFourier++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='G'){
							*(*(allGabor+subNo)+indexGabor)=intValue;
							indexGabor++;}
						strValue="";		
						indexHis=0;	indexFourier=0;	indexGabor=0;	pos--;}break;
			case ',' : {sscanf(strValue,"%d",&intValue);
						if(receiveData.GetAt((numFeature-pos)+1)=='H'){
							*(*(allHistogram+subNo)+indexHis)=intValue;
							indexHis++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='F'){
							*(*(allFourier+subNo)+indexFourier)=intValue;
							indexFourier++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='G'){
							*(*(allGabor+subNo)+indexGabor)=intValue;
							indexGabor++;}
						strValue="";}break;
			case '<': {	sscanf(strValue,"%d",&intValue);
						if(receiveData.GetAt((numFeature-pos)+1)=='H'){
							*(*(allHistogram+subNo)+indexHis)=intValue;
							indexHis++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='F'){
							*(*(allFourier+subNo)+indexFourier)=intValue;
							indexFourier++;}
						else if(receiveData.GetAt((numFeature-pos)+1)=='G'){
							*(*(allGabor+subNo)+indexGabor)=intValue;
							indexGabor++;}
						endFeature=true;}break;
			default : {strValue=strValue+tmp;}
		}
		if(endFeature){startOp=i+1;break;}	// end feature
	}
	strValue="";
	int startRow=0;	
	for(int a=startOp ; a<receiveData.GetLength() ; a++){
		if(receiveData.GetAt(a)!=',')strValue=strValue+receiveData.GetAt(a);
		else {
			sscanf(strValue,"%d",&startRow);
			startOp=a+1;
			break;}
	}
	int endRow=0;
	strValue="";
	for(int b=startOp ; b<receiveData.GetLength() ; b++){
		if(receiveData.GetAt(b)!='>')strValue=strValue+receiveData.GetAt(b);
		else {
			sscanf(strValue,"%d",&endRow);
			startOp=b+2;
			break;}
	}

	// find out in database
	CString sqlStr="";
	CString table = ImageFeatureTable;
	CDatabase myDB;
	int* inCorrect = new int[notUsed];	for (int j=0 ; j<notUsed ; j++){*(inCorrect+j)=-1;}					
	int* correct = new int[used];		for (int j=0 ; j<used ; j++){*(correct+j)=-1;}	
	
	indexInCorrect=0;	indexCorrect=0;
	// ======================= Query String ===============================
	/*if (key!=""){// Filter Image
		sqlStr = "SELECT * FROM "+ table +
				 " WHERE ImgNo IN (SELECT ImgNo FROM "+IdentityImageTable+
								  " WHERE KeyValue like'" + key + "')";
	}
	else {sqlStr = "SELECT * FROM " + table;}// not use Filter Image*/
	sqlStr = "SELECT * FROM " + table;
	if (!myDB.IsOpen())ConnDB(myDB);
	CRecordset rs(&myDB);// rs is point to myDB
	rs.Open(CRecordset::snapshot,sqlStr,CRecordset::none);
	CString patten="";
	patten = patten + receiveData.GetAt(1) + receiveData.GetAt(2) + receiveData.GetAt(3);
	DoRetrieve(rs,startRow,endRow,correct,inCorrect,allHistogram,allFourier,allGabor,patten);
	rs.Close();
	DisConnDB(myDB);	
	// ===== result =====
	CString result="";	CString re="";
	int numResult=0;
	for (int i=0 ; i<used ; i++){if(*(correct+i)!=-1)numResult++;else break;}
	for (int j=0 ; j<numResult ; j++){
		re.Format("%d",*(correct+j));
		if(j==0)result=result+re;
		else result=result+","+re;
		re="";
	}
	result=result+'e';
	for (int sub=0 ; sub<9 ; sub++){delete[] *(allHistogram + sub);} delete[] allHistogram;
	for (int sub=0 ; sub<9 ; sub++){delete[] *(allFourier + sub);}	 delete[] allFourier;
	for (int sub=0 ; sub<9 ; sub++){delete[] *(allGabor + sub);}	 delete[] allGabor;
	SlaveSend(result);
	SlaveClose();
}
void IRSystem::SlaveReceive(CString buffData)
{
	int last=0;
	char sign=buffData.GetAt(0);
	switch(sign){
		case 'a' : {	CString strValue="";	int intValue=0;		int num=1;
						int len=buffData.GetLength();
						for(int k=1 ; k<len ; k++){
							if(buffData.GetAt(k)!=',')strValue=strValue+buffData.GetAt(k);
							else {
									sscanf(strValue,"%d",&intValue);
									if(num==1)len_seq1=intValue;
									else if(num==2)len_seq2=intValue;
									num++;	strValue="";}
							if(k==(len-1)){
								sscanf(strValue,"%d",&intValue);
								len_seq3=intValue;
							}
						}	
				   }break;
		case 's' : {	buffData.Delete(0,1);
						sscanf(buffData,"%d",&receiveSize);
				   }break;
		case 'd' : {	int dataLeftToReceive=receiveSize;
						char* buff;
						CString tmp;
						receiveData = receiveData + buffData;
						last = receiveData.GetLength();
						dataLeftToReceive = dataLeftToReceive - last;
						while(dataLeftToReceive>0){
							buff=new char[dataLeftToReceive];
							slave_connSock.Receive(buff,dataLeftToReceive);
							tmp=buff;
							last = tmp.GetLength();
							receiveData = receiveData + buff;							
							dataLeftToReceive = dataLeftToReceive - last;
							delete[] buff;
						}
						char check=receiveData.GetAt(receiveData.GetLength());
						SlaveProcess();
						receiveData="";
				   }break;
	}
}
void IRSystem::SlaveSend(CString data)
{
	data='d'+data;
	int dwBytes = slave_connSock.Send(data,data.GetLength());
	if(dwBytes==SOCKET_ERROR)
	{
		if(slave_connSock.GetLastError()!=WSAEWOULDBLOCK)
		{
			char strError[256];
			wsprintf(strError,"Socket failed to send,Error Code:%d",slave_connSock.GetLastError());
			AfxMessageBox(strError);
		}
	}else {sendData="";}
}
