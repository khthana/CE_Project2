/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#pragma once
#include "afxstr.h"
#include "atlimage.h"
#include "ConstValue.h"

class CPImage :public CImage
{
public:
	double histogram[numHistogram];
	double fourierDesc[numFourierDesc];
	double gaborDesc[numGaborDesc];
public:
	CPImage(void);
	~CPImage(void);
	COLORREF GetColor(int x,int y);
	void SetColor(int x,int y,COLORREF color);
	double GetGray(int x,int y);
	double GenMean();
	void GenStrHis(CString& histogramStr);
	void GenStrFourier(CString& fourierStr);
	void GenSetGabor(CString& gaborStr);
};
