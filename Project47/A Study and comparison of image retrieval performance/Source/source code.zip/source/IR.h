/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
// IR.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols


// CIRApp:
// See IR.cpp for the implementation of this class
//

class CIRApp : public CWinApp
{
public:
	CIRApp();

// Overrides
	public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern CIRApp theApp;