/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#pragma once
#include "complex.h"

class PixelComplex
{
public:
	complex pixel;
	double color;
public:
	PixelComplex(void);
	~PixelComplex(void);
};
