/* 
===============================================================================
	Name				:	Thee Rojjawat
							Teerawut Kingpaibool
	Project Entitled	:	A Study and comparison of image retrieval performance
	Computer Engineering of King Mongkut's Institute of Tecnology,LadKrabang
===============================================================================
*/
#pragma once
#include <math.h>

class complex
{
public:
	double real;
	double imagin;
public:
	complex(void);
	~complex(void);
	double Abs(void);
	void Conj(void);
};
