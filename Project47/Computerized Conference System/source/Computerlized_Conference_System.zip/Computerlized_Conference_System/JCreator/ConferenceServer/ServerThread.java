import java.io.*;
import java.net.*;
import java.util.Date;
import java.sql.*;
import java.text.*;
import java.util.*;

public class ServerThread extends Thread {
	private Socket sock;
  	protected DataInputStream ddin;
  	protected DataOutputStream ddout;
  	private ByteArrayOutputStream b = new ByteArrayOutputStream();
  	private ByteArrayOutputStream buffer = new ByteArrayOutputStream();
  	private Vector clients;
  	private int x = 0,y = 0,rr = 0,gg = 0,bb = 0;
  	private String user,password,sql,tmp;
  	private ConnectionDatabase cb;
  	private ResultSet r;
  	private byte[] buff;
  	private boolean isFirst = false;
  	private ServerThread projectorthread,chairmanthread;
  	private String status;
  	private int page,scroll,num;
  	private float zoom;
  	private String suser,spassword,sdatabase;
  	private int MeetID = 0;
  	private String day = "",month = "",year = "";
  	
  	// Constructer
  	public ServerThread(Socket socks,Vector clients) {
    	this.sock = socks; this.clients = clients;
    	try {
      	ddin = new DataInputStream(sock.getInputStream());
      	ddout = new DataOutputStream(sock.getOutputStream());
      	
      	FileReader fr = new FileReader("config.inf");
			BufferedReader br = new BufferedReader(fr);
			tmp = br.readLine(); suser = tmp.substring(12);
			tmp = br.readLine(); spassword = tmp.substring(11);
			tmp = br.readLine(); sdatabase = tmp.substring(16);
			br.close();
		
      	cb = new ConnectionDatabase(suser,spassword,sdatabase);
    	} catch(Exception e) { e.printStackTrace(); }
  	}
  	// read file from pdf file to byte[]
  	private byte[] OpenPDFStream(String filename) throws Exception {
    	FileInputStream file = new FileInputStream(filename);
    	int filesize = file.available();
    	byte[] bytedata = new byte[filesize];
    	file.read(bytedata,0,filesize);
    	file.close();
    	return bytedata;
  	}
  	// Disconnect client
  	private void Disconnect() {
    	try {
      	synchronized (clients) {
        		clients.remove(this);
      	}
      	ConferenceServer.setNumberOfClient(clients.size());
      	ConferenceServer.removeClient(this.getName());
    	} catch(Exception e) {}
  	}
  	// Boardcast x,y from whiteboard client
  	private synchronized void BoardCastToProjector(int x,int y,int message) throws IOException {
  		if(projectorthread != null) {
  			projectorthread.ddout.writeInt(message);
      	projectorthread.ddout.writeInt(x);
      	projectorthread.ddout.writeInt(y);
  		} else { System.out.println("Projector Thread Null !!"); }
    	
  	}
  	// read data from pdfpanel mark()
  	private synchronized void ReadDataXY() throws IOException {
  		x = ddin.readInt();
      y = ddin.readInt();
  	}
  	// send file pdf to client
  	public synchronized void sendPdf(int msg) throws Exception {
  		tmp = ddin.readUTF();
  		buff = OpenPDFStream(tmp);
      ConferenceServer.setLogMessage(msg + " :: Send document to " + getName() + " [" + buff.length + "]");
      ddout.writeInt(103);
      ddout.writeInt(buff.length);
      ddout.write(buff);
  	}
  	public synchronized void sendPdf() throws Exception {
  		if(projectorthread != null) {
      	projectorthread.ddout.writeInt(103);
      	projectorthread.ddout.writeInt(buff.length);
      	projectorthread.ddout.write(buff);
      } else { System.out.println("Projector Thread Null !!"); }
  	}
  	// get pdf file to save ^^
  	public synchronized ByteArrayOutputStream getPDF() {
    	try {
      	int size = ddin.readInt();
      	int c = 0;
      	for(int i = 0;i < size;i++) {
        		c = ddin.read();
        		b.write(c);
      	}
    	} catch(Exception e) { e.printStackTrace(); }
    	return b;
  	}
  	private void setDate() {
  		Date now = new Date();
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
		String date = df.format(now);
  		if(date.charAt(1) == '/') day = "0" + date.charAt(0);
      else day = date.charAt(0) + "" + date.charAt(1);
		if(date.charAt(2) == '/' && date.charAt(4) == '/') month = "0" + date.charAt(3);
		else if(date.charAt(1) == '/' && date.charAt(3) == '/') month = "0" + date.charAt(2);
		else if(date.charAt(1) == '/' && date.charAt(4) == '/') month = date.charAt(2) + "" + date.charAt(3);
      else month = date.charAt(3) + "" + date.charAt(4);
		year = date.substring(date.length() - 4);
  	}
  	// main method for thread
  	public void run() {
    	try {
      	while (true) {
        	processMessage(ddin.readInt());
      	}
    	}
    	catch (Exception e) { }
    	finally { Disconnect(); }
  	} // End method run
  	// Dispatch message from client
  	private void processMessage(int message) {
    	try {
      	switch (message) {
        	case 1: { doMessage_1(message); break; } // Connection
        	case 2: { doMessage_2(message); break; } // Disconnect
        	case 3: { doMessage_3(message); break; } // Send PDF
        	case 4: { doMessage_4(message); break; } // Ack from client .... file Transfer complete
        	case 5: { doMessage_5(); break; } // Boardcast whiteboardpanel mark point
        	case 6: { doMessage_6(); break; } // set mark points to projector
        	case 7: { doMessage_7(message); break; } // Set projector PdfPnael
        	case 8: { doMessage_8(message); break; } // Set projector WhiteboardPanel
        	case 9: { doMessage_9(message); break; } // Send topic for open conference system
        	case 10: { doMessage_10(message); break; }  // set display panel of projector to pdf pnael
        	case 11: { doMessage_11(message); break; }  // set display panel of projector to whiteboard panel
        	case 12: { doMessage_12(message); break; } // clear point x,y = null in array point[]
        	case 13: { doMessage_13(message); break; } // get projector from chairman
        	case 14: { doMessage_14(message); break; } // chairman permission OK!!
        	case 15: { doMessage_15(message); break; } // Chairman require Secretary create vote
        	case 16: { doMessage_16(message); break; } // Recive vote topic and boardcast to all user
        	case 17: { doMessage_17(message); break; } // Vote from client
        	case 18: { doMessage_18(message); break; } // set isFirst = true for send pdf stream again
        	case 19: { doMessage_19(message); break; } // set permisson of projector all user [not me]
        	case 20: { doMessage_20(message); break; } // set permisson of projector all user
        	case 21: { doMessage_21(message); break; }
      	} // End switch
    	} catch (Exception e) { e.printStackTrace(); }
  	} // Enf of processMessage
  	
  	
  	//********************************************************************
  	//************************* Message Zone *****************************
  	
  	public synchronized void doMessage_1(int message) throws Exception {
  		try {
        	user = ddin.readUTF();
        	password = ddin.readUTF();
        	sql = "select MemberName,MemberSurname,Granted from member where UserName = '" + user + "' and PassWord = '" + password + "'";
    		r = cb.Query(sql); r.next();
    		status = r.getString(3);
    		setName(r.getString(1) + "   " + r.getString(2));
    		ddout.writeInt(101);
    		ddout.writeUTF(status); // send permission to client
    		ddout.writeUTF(r.getString(1) + "   " + r.getString(2));
    		ConferenceServer.setLogMessage(message + " :: " + this.getName() + " Connected");
    		ConferenceServer.setNameClient(this.getName());
         ConferenceServer.setNumberOfClient(clients.size());
        } catch(SQLException e) { ddout.writeInt(101); ddout.writeUTF("incorrect"); }
  	}
  	public synchronized void doMessage_2(int message) throws Exception {
  		ConferenceServer.setLogMessage(message + " :: " + this.getName() + " Close connection.");
      ddin.close(); ddout.close(); sock.close();
  	}
  	public synchronized void doMessage_3(int message) throws Exception {
  		sendPdf(message);
      isFirst = true;
  	}
  	public synchronized void doMessage_4(int message) throws Exception {
  		ConferenceServer.setLogMessage(message + " :: File Transfer Complete");
  	}
  	public synchronized void doMessage_5() throws Exception {
		x = ddin.readInt();
      y = ddin.readInt();
      rr = ddin.readInt();
      gg = ddin.readInt();
      bb = ddin.readInt();
      projectorthread.ddout.writeInt(152);
      projectorthread.ddout.writeInt(x);
      projectorthread.ddout.writeInt(y);
      projectorthread.ddout.writeInt(rr);
      projectorthread.ddout.writeInt(gg);
      projectorthread.ddout.writeInt(bb);
  	}
  	public synchronized void doMessage_6() throws Exception {
  		ReadDataXY();
      BoardCastToProjector(x,y,151);
  	}
  	public synchronized void doMessage_7(int message) throws Exception {
  		page = ddin.readInt();
		scroll = ddin.readInt();
		zoom = ddin.readFloat();
				
		if(projectorthread == null) {
			for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("projector")) {
      			projectorthread = thread;
      			break;
				}
			}
		}
		if(isFirst) {
      	sendPdf();
      	isFirst = false;
      }
      for(int i = 0;i < clients.size();i++) {
			ServerThread thread = (ServerThread)clients.elementAt(i);
			if(!thread.status.equals("projector") && thread != this) {
      		thread.ddout.writeInt(158);
			}
		}
      projectorthread.ddout.writeInt(150);
      projectorthread.ddout.writeInt(page);
      projectorthread.ddout.writeInt(scroll);
      projectorthread.ddout.writeFloat(zoom);
      ConferenceServer.setLogMessage(message + " :: " + this.getName() + " set PDF to projector");
  	}
  	public synchronized void doMessage_8(int message) throws Exception {
  		if(projectorthread == null) {
			for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("projector")) {
      			projectorthread = thread;
      			break;
				}
			}
		}
		projectorthread.ddout.writeInt(102);
		ConferenceServer.setLogMessage(message + " :: " + this.getName() + " use projector");
  	}
  	public synchronized void doMessage_9(int message) throws Exception {
  		try {
        	setDate();
        	sql = "select MeetID from preparemeeting where d = " + day + " and m = " + month + " and y = " + year;
        	System.out.println(sql);
        	r = cb.Query(sql); r.first();
        	MeetID = Integer.parseInt(r.getString(1));
        	sql = "select hTopic,PathFile from pathmeeting where MeetId = " + MeetID;
        	System.out.println(sql);
        	r = cb.Query(sql); r.last();
        	int row = r.getRow();
        	ConferenceServer.setLogMessage(message + " :: Send " + row + " topic for open conferecne");
        	ddout.writeInt(109);
        	ddout.writeInt(row); r.first(); // send loop for client to get topic
        	// Write first row
        	ddout.writeUTF(r.getString(1)); // Topic name
      	ddout.writeUTF(r.getString(2)); // Path of pdf file
			while(r.next()) {
				ddout.writeUTF(r.getString(1)); // Topic name
      		ddout.writeUTF(r.getString(2)); // Path of pdf file
			}
      } catch(SQLException e) { }
  	}
  	public synchronized void doMessage_10(int message) throws Exception {
  		if(projectorthread == null) {
			for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("projector")) {
      			projectorthread = thread;
      			break;
				}
			}
		}
      projectorthread.ddout.writeInt(153);
      ConferenceServer.setLogMessage(message + " :: " + this.getName() + " set PDF to projector");
  	}
  	public synchronized void doMessage_11(int message) throws Exception {
  		if(projectorthread == null) {
			for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("projector")) {
      			projectorthread = thread;
      			break;
				}
			}
		}
      projectorthread.ddout.writeInt(154);
      ConferenceServer.setLogMessage(message + " :: " + this.getName() + " set whiteboard to projector");
  	}
  	public synchronized void doMessage_12(int message) throws Exception {
  		if(projectorthread == null) {
			for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("projector")) {
      			projectorthread = thread;
      			break;
				}
			}
		}
      projectorthread.ddout.writeInt(155);
      ConferenceServer.setLogMessage(message + " :: " + this.getName() + " clear mark on projector");
  	}
  	public synchronized void doMessage_13(int message) throws Exception {
  		if(chairmanthread == null) {
        	for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("chairman")) {
	      		chairmanthread = thread;
	      		break;
				}
			}
       }
       chairmanthread.ddout.writeInt(130);
       chairmanthread.ddout.writeUTF(this.getName());
       ConferenceServer.setLogMessage(message + " :: " + this.getName() + " get permisson from Chairman");
  	}
  	public synchronized void doMessage_14(int message) throws Exception {
  		tmp = ddin.readUTF();
  		doMessage_20(20);
      for(int i = 0;i < clients.size();i++) {
			ServerThread thread = (ServerThread)clients.elementAt(i);
			if(thread.getName().equals(tmp)) {
	      	thread.ddout.writeInt(131);
	      	isFirst = true;
	      	break;
			}
		}
		ConferenceServer.setLogMessage(message + " :: " + this.getName() + " set permisson for use projector");
  	}
  	public synchronized void doMessage_15(int message) throws Exception {
  		for(int i = 0;i < clients.size();i++) {
			ServerThread thread = (ServerThread)clients.elementAt(i);
			if(thread.status.equals("secretary")) {
	      	thread.ddout.writeInt(104);
	      	break;
			}
		}
		ConferenceServer.setLogMessage(message + " :: Chairman require Secretary for create vote");
  	}
  	public synchronized void doMessage_16(int message) throws Exception {
  		num = ddin.readInt();
     	String tmp[] = new String[num];
      for(int i=0;i<num;i++) {
        	tmp[i] = ddin.readUTF();	
      }
      for(int i = 0;i < clients.size();i++) {
			ServerThread thread = (ServerThread)clients.elementAt(i);
			if(thread.status.equals("projector")) { thread.ddout.writeInt(156); } 
	      else { thread.ddout.writeInt(105); }
	      	thread.ddout.writeInt(num);
	      for(int j=0;j<num;j++) {
	      	thread.ddout.writeUTF(tmp[j]);
	      }
		}
		ConferenceServer.setLogMessage(message + " :: Boardcast topic vote to other user");
  	}
  	public synchronized void doMessage_17(int message) throws Exception {
  		int vote = ddin.readInt();
        	for(int i = 0;i < clients.size();i++) {
				ServerThread thread = (ServerThread)clients.elementAt(i);
				if(thread.status.equals("projector")) {
					thread.ddout.writeInt(157);
					thread.ddout.writeInt(vote);
					break;
				}
			}
		ddout.writeInt(106);
		ConferenceServer.setLogMessage(message + " :: " + this.getName() + " vote complete!!");
		
  	}
  	public synchronized void doMessage_18(int message) throws Exception {
  		isFirst = true;
  	}
  	public synchronized void doMessage_19(int message) throws Exception {
  		for(int i = 0;i < clients.size();i++) {
			ServerThread thread = (ServerThread)clients.elementAt(i);
			if(!thread.status.equals("projector") && thread != this) {
      		thread.ddout.writeInt(158);
			}
		}
		ConferenceServer.setLogMessage(message + " :: Clear permission of projector all user except me!"); // Except me
  	}
  	public synchronized void doMessage_20(int message) throws Exception {
  		for(int i = 0;i < clients.size();i++) {
			ServerThread thread = (ServerThread)clients.elementAt(i);
			if(!thread.status.equals("projector")) {
      		thread.ddout.writeInt(158);
			}
		}
		ConferenceServer.setLogMessage(message + " :: Clear permission of projector all user");
  	}
  	public synchronized void doMessage_21(int message) throws Exception {
  		ConferenceServer.setLogMessage(message + " :: Recive report from Secretary");
  		buffer = getPDF();
  		
  		Date now = new Date();
  		String hour = "" + now.getHours(),minute = "" + now.getMinutes();
  		if(hour.length() == 1) hour = "0" + hour;
  		if(minute.length() == 1) minute = "0" + minute;
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		String s = df.format(now);
		s += "(" + hour + "." + minute + ").pdf";
			
  		FileOutputStream fo = new FileOutputStream("upload/" + s);
  		fo.write(buffer.toByteArray());
  		fo.close();
  		
  		// save into DB
  		sql = "insert into report values (0," + MeetID + ",'" + s + "')";
  		cb.Execute(sql);
  	}
	//************************* End of Message ***************************
	//********************************************************************
	 
	
}// End of class