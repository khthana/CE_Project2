import javax.swing.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class CreateVotePanel extends JPanel {
	 
	 private JPanel p1 = new JPanel();
	 private JPanel p2 = new JPanel();
	 private JTextField t1 = new JTextField(5);
	 private Vector vtext = new Vector();
	 private GridBagConstraints gc = new GridBagConstraints();
	 private DataInputStream din;
  	 private DataOutputStream dout;
  	 private JLabel b1,b2,b3;
	 private ImageIcon icob1,icob2,icob3;
  	 private Socket sock;
  	 private JLabel lnumber = new JLabel("Number of Topic");
	 
	 public CreateVotePanel(Socket sock) {
	 	try {
	 		this.sock = sock;
	 		Init();
	 	} catch (Exception e) { e.printStackTrace(); }
	 }
	 
	 private void Init() throws Exception {
	 	din = new DataInputStream(sock.getInputStream());
      dout = new DataOutputStream(sock.getOutputStream());
      icob1 = new ImageIcon(PermitPanel.class.getResource("ok.png"));
		icob2 = new ImageIcon(PermitPanel.class.getResource("bclear.png"));
		icob3 = new ImageIcon(PermitPanel.class.getResource("submit.png"));
		b1 = new JLabel(icob1); b2 = new JLabel(icob2); b3 = new JLabel(icob3);
		t1.setFont(new Font("",0,30));
		lnumber.setFont(new Font("",0,30));
		setBackground(Color.WHITE);
	 	setLayout(new BorderLayout());
	 	p1.setLayout(new GridBagLayout());
	 	p2.setLayout(new GridBagLayout());
	 	p1.setBackground(Color.WHITE);
	 	p2.setBackground(Color.WHITE);
	 	
	 	gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTH;
		gc.insets.top = 3; gc.insets.bottom = 0;
		gc.insets.left = 5; gc.insets.right = 5;
		
		gc.gridwidth = 1; gc.gridheight = 1; // merge cell from grid
		gc.ipadx = 5; gc.ipady = 5; // size of component
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y
		gc.gridx = 1; gc.gridy = 0; // position of grid [like array two dimention]
		p1.add(t1,gc);
		gc.gridx = 2; gc.gridy = 0; // position of grid [like array two dimention]
		p1.add(b1,gc);
	 	gc.gridx = 3; gc.gridy = 0; // position of grid [like array two dimention]
		p1.add(b2,gc);
	 	
	 	
	 	add(p1,BorderLayout.NORTH);
	 	
	 	MouseListeners mouselistener = new MouseListeners();
	 	b1.addMouseListener(mouselistener);
	 	b2.addMouseListener(mouselistener);
	 	b3.addMouseListener(mouselistener);
	 }
	 
	 private void setTextBox() {
	 	int i;
	 	int loop = Integer.parseInt(t1.getText());
	 	gc.gridwidth = 1; gc.gridheight = 1; // merge cell from grid
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y
		gc.ipadx = 80; gc.ipady = 25; // size of component
		for(i=0;i<loop;i++) {
			JTextField tmptext = new JTextField();
			tmptext.setFont(new Font("",0,20));
			gc.gridx = 0; gc.gridy = i; // position of grid [like array two dimention]
			p2.add(tmptext,gc);
			vtext.addElement(tmptext);
		}
		gc.gridx = 0; gc.gridy = i+1; // position of grid [like array two dimention]
		p2.add(b3,gc);
		add(p2,BorderLayout.CENTER);
		invalidate();
    	repaint();
    	validate();
	 }
	 
	 private void clearText() {
	 	vtext.removeAllElements();
	 	p2.removeAll();
	 	remove(p2);
	 	invalidate();
    	repaint(); 
    	validate();
	 }
	 
	 private void getText() throws Exception {
	 	dout.writeInt(16);
	 	dout.writeInt(vtext.size());
	 	for(int i=0;i<vtext.size();i++) {
	 		JTextField tmp = (JTextField)vtext.elementAt(i);
	 		dout.writeUTF(tmp.getText());
	 	}
	 	dout.writeInt(20);
	 }
  	
  	class MouseListeners implements MouseListener {
    	public void mouseClicked(MouseEvent e) { 
    		try {
		      if(e.getSource() == b1) {
					setTextBox();
		      } else if(e.getSource() == b2) {
					clearText();
		      } else if(e.getSource() == b3) {
		      	getText();
					clearText();
		      }
		   } catch(Exception ex) {}
	    }

    	public void mouseEntered(MouseEvent e) { }
    	public void mouseExited(MouseEvent e) { }
    	public void mousePressed(MouseEvent e) { }
    	public void mouseReleased(MouseEvent e) { }
  }
  
} // end of class