import java.io.*;

public interface SetPdfPanel {
	public void setPanel(String panel,ByteArrayOutputStream b);
	public void setPanel(String panel);
	public void setPageCurrent(int page);
	public void restorePanel();
	public void setMem(String mem);
	public int getPageCurrent();
}