import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class Secretary extends JFrame implements SetPdfPanel {
	
	private static JPanel mainpanel;
	private JPanel menupanel;
	private RulePanel rulepanel;
	private TopicPanel topicpanel;
	private static PdfPanel pdfpanel;
	private static CardLayout c;
	private HeaderPanel headerpanel;
	private WhiteBoardPanel whiteboardpanel;
	private EditorPanel editorpanel;
	private CreateVotePanel createvotepanel;
	private VotePanel votepanel;
	private FooterPanel footerpanel;
	private Socket sock;
	private DataInputStream din;
  	private DataOutputStream dout;
  	private GridBagConstraints gc;
	private JLabel bx,b1,b2,b3,b5,b6,b7;
	private ImageIcon icobx,icob1,icob2,icob3,icob5,icob6,icob7;
	private JLabel lblrule;
	private ClientThread ct;
  	private ByteArrayOutputStream buff;
  	private String mem = "topic";
	
	private static int pagecurrent = 0;
	private int i;
	private String s;
	
	public Secretary(Socket sock,ClientThread ct) {
	try {
		this.sock = sock; this.ct = ct;
      Init();
      OpenConference();
    } catch(Exception e) { e.printStackTrace(); }
	}
	private void Init() throws Exception {
		din = new DataInputStream(sock.getInputStream());
      dout = new DataOutputStream(sock.getOutputStream());
      gc = new GridBagConstraints();
		headerpanel = new HeaderPanel();
		footerpanel = new FooterPanel();
		topicpanel = new TopicPanel(sock);
		pdfpanel = new PdfPanel(sock,true);
		whiteboardpanel = new WhiteBoardPanel(sock,true);
		menupanel = new JPanel(new GridBagLayout());
		rulepanel = new RulePanel();
		editorpanel = new EditorPanel(sock);
		createvotepanel = new CreateVotePanel(sock);
		votepanel = new VotePanel(sock);
		
		ct.setPdfPanelHandle(pdfpanel);
		ct.setPdfPanel(this);
		ct.setTopicPanelHandle(topicpanel);
		ct.setWhiteBoardPanelHandle(whiteboardpanel);
		ct.setVotePanel(votepanel);
		
		icob1 = new ImageIcon(Secretary.class.getResource("topic.png"));
		icob2 = new ImageIcon(Secretary.class.getResource("document.png"));
		icob3 = new ImageIcon(Secretary.class.getResource("whiteboard.png"));
		icob5 = new ImageIcon(Secretary.class.getResource("projector.png"));
		icob6 = new ImageIcon(Secretary.class.getResource("cprojector.png"));
		icob7 = new ImageIcon(Secretary.class.getResource("edit.png"));
		icobx = new ImageIcon(Secretary.class.getResource("exit.png"));
		b1 = new JLabel(icob1); b2 = new JLabel(icob2); b3 = new JLabel(icob3);
		b5 = new JLabel(icob5); bx = new JLabel(icobx); b6 = new JLabel(icob6);
		b7 = new JLabel(icob7);
		
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTH;
		gc.insets.top = 3; gc.insets.bottom = 0;
		gc.insets.left = 5; gc.insets.right = 5;
		
		gc.gridwidth = 1; gc.gridheight = 1; // merge cell from grid
		gc.ipadx = 10; gc.ipady = 10; // size of component
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y
		gc.gridx = 0; gc.gridy = 1; // position of grid [like array two dimention]
		menupanel.add(b1,gc);
		gc.gridx = 0; gc.gridy = 2; // position of grid [like array two dimention]
		menupanel.add(b2,gc);
		gc.gridx = 0; gc.gridy = 3; // position of grid [like array two dimention]
		menupanel.add(b3,gc);
		gc.gridx = 0; gc.gridy = 4; // position of grid [like array two dimention]
		menupanel.add(b5,gc);
		gc.gridx = 0; gc.gridy = 5; // position of grid [like array two dimention]
		menupanel.add(b6,gc);
		gc.gridx = 0; gc.gridy = 6; // position of grid [like array two dimention]
		menupanel.add(b7,gc);
		gc.gridx = 0; gc.gridy = 7; // position of grid [like array two dimention]
		menupanel.add(bx,gc);
		menupanel.setBackground(Color.WHITE);
		
    	mainpanel = new JPanel(new CardLayout());
    	c = (CardLayout)(mainpanel.getLayout());
    	mainpanel.add(rulepanel,"rule");
    	mainpanel.add(topicpanel,"topic");
    	mainpanel.add(pdfpanel,"pdf");
    	mainpanel.add(whiteboardpanel,"whiteboard");
    	mainpanel.add(editorpanel,"edit");
    	mainpanel.add(createvotepanel,"cvote");
    	mainpanel.add(votepanel,"vote");
    	
    	add(headerpanel,BorderLayout.NORTH);
    	add(menupanel,BorderLayout.WEST);
    	add(mainpanel,BorderLayout.CENTER);
    	add(footerpanel,BorderLayout.SOUTH);
    	setUndecorated(true);
    	setSize(Toolkit.getDefaultToolkit().getScreenSize());
    	setVisible(true);
    	MouseListeners mouselistener = new MouseListeners();
    	b1.addMouseListener(mouselistener);
    	b2.addMouseListener(mouselistener);
    	b3.addMouseListener(mouselistener);
  		b5.addMouseListener(mouselistener);
    	b6.addMouseListener(mouselistener);
    	b7.addMouseListener(mouselistener);
    	bx.addMouseListener(mouselistener);
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void restorePanel() {
		c.show(mainpanel,mem);
	}
	// set page current
	public void setPageCurrent(int page) {
		this.pagecurrent = page;
	}
	// get page current
	public int getPageCurrent() {
		return pagecurrent;
	}
	public void setMem(String mem) {
		this.mem = mem;
	}
	// Open Conference system
	// send message to server for get topic of to day.
	private void OpenConference() {
		try {
			dout.writeInt(9); // message 9 use for send to get information of topic.
			pagecurrent = 0;
			mem = "rule";
		} catch(Exception e) { e.printStackTrace(); }
		c.show(mainpanel,"rule");
	}
	public void setPanel(String panel) { 
		c.show(mainpanel,panel);
		invalidate();
    	repaint();
    	validate();
	}
	public void setPanel(String panel,ByteArrayOutputStream b) { // override from Interface
		pdfpanel.OpenFile(b);
		c.show(mainpanel,panel);
		b.reset();
		invalidate();
    	repaint();
    	validate();
	}
	// Listener button event
  class MouseListeners implements MouseListener {
    public void mouseClicked(MouseEvent e) {
    	try {
    		if(e.getSource() == b1) { // set topic panel
    			mem = "topic";
    			c.show(mainpanel,mem);
    			pagecurrent = 1;
    		} else if(e.getSource() == b2) { // set pdf panel
    			mem = "pdf";
    			c.show(mainpanel,mem);
    			pagecurrent = 2;
    			if(pdfpanel.getProjectorStatus()) {
    				dout.writeInt(10);
    			}
    		} else if(e.getSource() == b3) { // set whiteboard panel
    			mem = "whiteboard";
    			c.show(mainpanel,mem);
    			pagecurrent = 3;
    			if(whiteboardpanel.getProjectorStatus()) {
    				dout.writeInt(11);
    			}
    		} else if(e.getSource() == b5) {  // set projector
    			dout.writeInt(13);
    		} else if(e.getSource() == b6) { // cancel projector
    			pdfpanel.setProjectorStatus(false);
    			whiteboardpanel.setProjectorStatus(false);
    			whiteboardpanel.setFirst(true);
    		} else if(e.getSource() == b7) {  // exit
    			mem = "edit";
    			c.show(mainpanel,mem);
    		} else if(e.getSource() == bx) {  // exit
    			dout.writeInt(2);
    			System.exit(0);
    		}
    	} catch(Exception ex) { }
    }
    public void mouseEntered(MouseEvent e) { }
    public void mouseExited(MouseEvent e) { }
    public void mousePressed(MouseEvent e) { }
    public void mouseReleased(MouseEvent e) { }
  }
  
  
} // End of Secretary class