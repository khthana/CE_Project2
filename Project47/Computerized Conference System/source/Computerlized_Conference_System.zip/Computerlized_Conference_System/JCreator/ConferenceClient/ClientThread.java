import java.io.*;
import java.net.*;
import java.awt.*;
import javax.swing.*;

public class ClientThread extends Thread {
	
	private DataInputStream din;
	private String tmp;
	private Socket sock;
	private TopicPanel topicpanel;
	private PdfPanel pdfpanel;
	private WhiteBoardPanel whiteboardpanel;
	private VotePanel votepanel;
  	private DataOutputStream dout;
  	private ByteArrayOutputStream buff,buffsave;
  	private SetPdfPanel setpdfpanel;
  	private ByteArrayOutputStream b = new ByteArrayOutputStream();
	private ConferenceClient conferenceclient;
	private String name = "";
	private myMessageBox msgbox = new myMessageBox();

	public ClientThread(Socket sock,ConferenceClient conferenceclient) {
		try {
			this.sock = sock; this.conferenceclient = conferenceclient;
      	din = new DataInputStream(this.sock.getInputStream());
      	dout = new DataOutputStream(this.sock.getOutputStream());
    	} catch(Exception e) { e.printStackTrace(); }
	}
	public void setPdfPanel(SetPdfPanel setpdfpanel) {
		this.setpdfpanel = setpdfpanel;
	}
	public void setWhiteBoardPanelHandle(WhiteBoardPanel whiteboardpanel) {
		this.whiteboardpanel = whiteboardpanel;
	}
	public void setPdfPanelHandle(PdfPanel pdfpanel) {
		this.pdfpanel = pdfpanel;
	}
	public void setTopicPanelHandle(TopicPanel topicpanel) {
		this.topicpanel = topicpanel;
	}
	public void setVotePanel(VotePanel votepanel) {
		this.votepanel = votepanel;
	}
	public synchronized ByteArrayOutputStream getPDF() {
    	try {
      	int size = din.readInt();
      	int c = 0;
      	for(int i = 0;i < size;i++) {
        		c = din.read();
        		b.write(c);
      	}
      	dout.writeInt(4);
    	} catch(Exception e) { e.printStackTrace(); }
    	return b;
  	}
  	private void SaveLogFile() throws Exception {
  		// if connection complete save ip address and localhost to inf file
  		FileWriter fw = new FileWriter("config.inf");
		BufferedWriter bw = new BufferedWriter(fw);
				
		bw.write("host ip address = " + conferenceclient.getHostIP()); bw.newLine();
		bw.write("port number = " + conferenceclient.getHostPort()); bw.close();
  	}
  	private void Disconnect() {
  		try {
  			dout.writeInt(2);
  		} catch(Exception e) {}
  	}
  	private void setProjector() {
		try {
			dout.writeInt(18);
			dout.writeInt(7);
			dout.writeInt(pdfpanel.getPageCurrent());
			dout.writeInt(pdfpanel.getScrollBar());
			dout.writeFloat(pdfpanel.getZoom());
		} catch(Exception e) { e.printStackTrace(); }
	}
  	// run method --> start thread
  	// ***************************
	public void run() {
		try {
      	while (true) {
        		processMessage(din.readInt());
      	}
    	} catch (Exception e) {}
    	finally { Disconnect(); }
	}
	private void processMessage(int message) throws Exception {
		switch(message) {
      	case 101 : { doMessage_101(); break; } // create instant for user [chairman/secretary/committee/projector]
      	case 102 : { doMessage_102(); break; } // set to whiteboard
      	case 103 : { doMessage_103(); break; } // get PDF from server and set into pdfpanel
      	case 104 : { doMessage_104(); break; } // set to createvotepanel
      	case 105 : { doMessage_105(); break; } // set topic into votepanel
      	case 106 : { doMessage_106(); break; } // restore panel to prev. panel
      	case 109 : { doMessage_109(); break; } // set topic panel [topicname - filepath]
      	//************************************************
      	// Message more then 130 is a message's chairman.
      	//************************************************
      	case 130 : { doMessage_130(); break; } // set permitpanel for get projector from other user
      	case 131 : { doMessage_131(); break; } // other user get permission OK and set ... to projector
      	//************************************************
      	// Message more then 150 is a message's projector.
      	//************************************************
      	case 150 : { doMessage_150(); break; } // set pdf file to pdf panel
      	case 151 : { doMessage_151(); break; } // set mark on projector [pdfpanel]
      	case 152 : { doMessage_152(); break; } // set mark and set color on projector [whiteboardpanel]
      	case 153 : { doMessage_153(); break; } // set main panel to pdfpanel
      	case 154 : { doMessage_154(); break; } // set main panel to whiteboardpanel
      	case 155 : { doMessage_155(); break; } // clear points on whiteboardpanel
      	case 156 : { doMessage_156(); break; } // set topic into votepanel
      	case 157 : { doMessage_157(); break; } // set vote result to projector
      	case 158 : { doMessage_158(); break; } // cancel all permission of user to use projector
      } // End switch
      
   } // End of processMessage


	//********************************************************************
	//************************* Message Zone *****************************
	
	public synchronized void doMessage_101() throws Exception {
  		tmp = din.readUTF(); // Permission of user[chairman-commitee-etc]
  		
	   if(tmp.equals("chairman")) {
	   	name = din.readUTF();
  		 	RulePanel.setWelcome(name,tmp);
	      this.setName(tmp);
	      new Chairman(sock,this);
	      SaveLogFile();
	      conferenceclient.setVisible(false);
	    } else if(tmp.equals("committee")) {
	    	name = din.readUTF();
  		 	RulePanel.setWelcome(name,tmp);
	      this.setName(tmp);
	      new Committee(sock,this);
	      SaveLogFile();
	    	conferenceclient.setVisible(false);
	    } else if(tmp.equals("secretary")) {
	    	name = din.readUTF();
  		 	RulePanel.setWelcome(name,tmp);
	      this.setName(tmp);
	     	new Secretary(sock,this);
	      SaveLogFile();
	      conferenceclient.setVisible(false);
	    } else if(tmp.equals("projector")) {
	    	name = din.readUTF();
  		 	RulePanel.setWelcome(name,tmp);
	      this.setName(tmp);
	      new Projector(sock,this);
	      SaveLogFile();
	      conferenceclient.setVisible(false);
	    } else if(tmp.equals("incorrect")) {
	    	msgbox.setText("User or password incorrect",25);
	    	msgbox.showBox();
	    }
  	}
  	public synchronized void doMessage_102() throws Exception {
  		setpdfpanel.setPanel("whiteboard");
      whiteboardpanel.setFirst(true);
  	}
  	public synchronized void doMessage_103() throws Exception {
  		buff = getPDF();
      setpdfpanel.setPanel("pdf",buff);
      setpdfpanel.setPageCurrent(2);
      setpdfpanel.setMem("pdf");
      if(pdfpanel.getProjectorStatus()) {
      	dout.writeInt(7);
      	dout.writeInt(1);
			dout.writeInt(0);
			dout.writeFloat(1.5f);
      }
  	}
  	public synchronized void doMessage_104() throws Exception {
  		setpdfpanel.setPanel("cvote");
  	}
  	public synchronized void doMessage_105() throws Exception {
  		int x = din.readInt();
  		votepanel.removeVector();
      String tmp[] = new String[x];
      for(int i=0;i<x;i++) {
      	tmp[i] = din.readUTF();
      	votepanel.setTopic(tmp[i],i);
      }
      setpdfpanel.setPanel("vote");
  	}
  	public synchronized void doMessage_106() throws Exception {
  		setpdfpanel.restorePanel();
  	}
  	public synchronized void doMessage_109() throws Exception {
  		String topic,path;
      int row = din.readInt();
		for(int i=0;i<row;i++) {
			topic = din.readUTF();
			path = din.readUTF();
			topicpanel.setTopic(topic,path,0,i);
		}
  	}
  	public synchronized void doMessage_130() throws Exception {
  		tmp = din.readUTF();
      PermitPanel.setWhois(tmp);
     	setpdfpanel.setPanel("permit");
  	}
  	public synchronized void doMessage_131() throws Exception {
  		pdfpanel.setProjectorStatus(true);
	   whiteboardpanel.setProjectorStatus(true);
      switch(setpdfpanel.getPageCurrent()) {
	    	case 2 : {
	    		setProjector();
	    		break;
	    	}
	    	case 3 : {
	    		dout.writeInt(19);
	    		dout.writeInt(8);
	    		break;
	    	}
	    }
  	}
  	public synchronized void doMessage_150() throws Exception {
  		int page = din.readInt();
		int scroll = din.readInt();
		Float zoom = din.readFloat();
		pdfpanel.setPage(page);
		pdfpanel.setScrollBar(scroll);
		pdfpanel.setZoom(zoom);
		setpdfpanel.setPanel("pdf");
  	}
  	public synchronized void doMessage_151() throws Exception {
  		int x = din.readInt();
		int y = din.readInt();
		pdfpanel.MarkProjector(x,y);
  	}
  	public synchronized void doMessage_152() throws Exception {
  		int x = din.readInt();
      int y = din.readInt();
      int r = din.readInt();
      int g = din.readInt();
      int b = din.readInt();
      Color c = new Color(r,g,b);
      whiteboardpanel.MarkProjector(x,y,c);
  	}
  	public synchronized void doMessage_153() throws Exception {
  		setpdfpanel.setPanel("pdf");
  	}
  	public synchronized void doMessage_154() throws Exception {
  		whiteboardpanel.setFirst(true);
      setpdfpanel.setPanel("whiteboard");
  	}
  	public synchronized void doMessage_155() throws Exception {
  		whiteboardpanel.ClearPoints();
  	}
  	public synchronized void doMessage_156() throws Exception {
      int x = din.readInt();
      votepanel.removeVector();
      String tmp[] = new String[x];
      for(int i=0;i<x;i++) {
      	tmp[i] = din.readUTF();
      	votepanel.setProjectorTopic(tmp[i],i);
      }
      setpdfpanel.setPanel("vote");
  	}
  	public synchronized void doMessage_157() throws Exception {
  		int v = din.readInt();
      votepanel.setVoteResult(v);
  	}
  	public synchronized void doMessage_158() throws Exception {
  		pdfpanel.setProjectorStatus(false);
	   whiteboardpanel.setProjectorStatus(false);
  	}
	
	//************************* End of Message ***************************
	//********************************************************************

} // End of class