import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.awt.event.*;
import java.util.*;

public class VotePanel extends JPanel {
	
	private ImageIcon imgok;
	private GridBagConstraints gc;
	private Vector vvote = new Vector();
	private DataInputStream din;
  	private DataOutputStream dout;
  	private Socket sock;

	public VotePanel(Socket sock) {
		try {
			this.sock = sock;
			Init();
		} catch(Exception e) { e.printStackTrace(); }
	}
	
	private void Init() throws Exception {
		din = new DataInputStream(sock.getInputStream());
      dout = new DataOutputStream(sock.getOutputStream());
		setLayout(new GridBagLayout());
		setBackground(Color.WHITE);
		gc = new GridBagConstraints();
		gc.fill = GridBagConstraints.BOTH;
		gc.anchor = GridBagConstraints.NORTH;
		gc.insets.top = 3; gc.insets.bottom = 0;
		gc.insets.left = 5; gc.insets.right = 5;
		gc.gridwidth = 1; gc.gridheight = 1; // merge cell from grid
		gc.ipadx = 10; gc.ipady = 10; // size of component
		
		imgok = new ImageIcon(VotePanel.class.getResource("ovote.png"));
	}
	
	public void setTopic(String topic,int y) {
		MouseListeners mouselistener = new MouseListeners();
		JLabel lblok = new JLabel(imgok);
		lblok.setToolTipText("" + y);
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y
		gc.gridx = 0; gc.gridy = y; // position of grid [like array two dimention]
		add(lblok,gc);
		
		lblok.addMouseListener(mouselistener);
		vvote.addElement(lblok);
		
		gc.gridx = 1; gc.gridy = y; // position of grid [like array two dimention]
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y 
		JLabel ltopic = new JLabel(topic);
		ltopic.setOpaque(true);
		ltopic.setFont(new Font("",Font.PLAIN, 20));
		if((y % 2) == 0) ltopic.setBackground(Color.CYAN);  // set color of label ???
		else ltopic.setBackground(Color.GREEN);  // set color of label ???
		add(ltopic,gc);
	}
	
	public void setProjectorTopic(String topic,int y) {
		JLabel lblresult = new JLabel("0");
		lblresult.setFont(new Font("",0,50));
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y
		gc.gridx = 0; gc.gridy = y; // position of grid [like array two dimention]
		add(lblresult,gc);
		
		vvote.addElement(lblresult);
		
		gc.gridx = 1; gc.gridy = y; // position of grid [like array two dimention]
		gc.weightx = 0; gc.weighty = 0; // resize follow size of screen x ,y 
		JLabel ltopic = new JLabel("    " + topic);
		ltopic.setOpaque(true);
		ltopic.setFont(new Font("",Font.PLAIN, 50));
		ltopic.setBackground(Color.WHITE);
		//if((y % 2) == 0)   // set color of label ???
		//else ltopic.setBackground(Color.GREEN);  // set color of label ???
		add(ltopic,gc);
	}
	
	public void setVoteResult(int v) {
		JLabel lbl = (JLabel)vvote.elementAt(v);
		int x = Integer.parseInt(lbl.getText());
		x++;
		lbl.setFont(new Font("",0,50));
		lbl.setText("" + x);
	}
	
	private void selectTopic(MouseEvent e) {
		try {
			for(int i=0;i<vvote.size();i++) {
				JLabel lbl = (JLabel)vvote.elementAt(i);
				if(e.getSource() == lbl) {
					dout.writeInt(17);
					dout.writeInt(Integer.parseInt(lbl.getToolTipText())); // result vote
					break;
				}
			}
		} catch(Exception ex) { ex.printStackTrace(); }
	}
	
	public void removeVector() {
		vvote.removeAllElements();
		removeAll();
		invalidate();
    	repaint();
    	validate();
	}
	
	class MouseListeners implements MouseListener {
    	public void mouseClicked(MouseEvent e) { selectTopic(e); }
    	public void mouseEntered(MouseEvent e) { }
    	public void mouseExited(MouseEvent e) { }
    	public void mousePressed(MouseEvent e) { }
    	public void mouseReleased(MouseEvent e) { }
  }
  
} // end of class