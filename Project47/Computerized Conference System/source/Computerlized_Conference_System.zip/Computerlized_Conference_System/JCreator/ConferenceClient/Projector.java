import javax.swing.*;
import java.io.*;
import java.net.*;
import java.awt.*;

public final class Projector extends JFrame implements SetPdfPanel {
	
	private static JPanel mainpanel;
	private TopicPanel topicpanel;
	private static PdfPanel pdfpanel;
	private RulePanel rulepanel;
	private static CardLayout c;
	private HeaderPanel headerpanel;
	private WhiteBoardPanel whiteboardpanel;
	private VotePanel votepanel;
	private FooterPanel footerpanel;
	private Socket sock;
	private DataInputStream din;
  	private DataOutputStream dout;
	private ClientThread ct;
	private String vote[];
	private static String mem = "topic";
	
	private int pagecurrent = 0;
	private int i;
	private String s;
	
	public Projector(Socket sock,ClientThread ct) {
		try {
			this.sock = sock; this.ct = ct;
			Init();
			OpenProjector();
		} catch(Exception e) { e.printStackTrace(); }
	}
	private void Init() throws Exception {
		din = new DataInputStream(sock.getInputStream());
      dout = new DataOutputStream(sock.getOutputStream());
      rulepanel = new RulePanel();
		headerpanel = new HeaderPanel();
		footerpanel = new FooterPanel();
		topicpanel = new TopicPanel(sock);
		pdfpanel = new PdfPanel(sock,false);
		whiteboardpanel = new WhiteBoardPanel(sock,false);
		votepanel = new VotePanel(sock);
		
    	mainpanel = new JPanel(new CardLayout());
    	c = (CardLayout)(mainpanel.getLayout());
    	mainpanel.add(topicpanel,"topic");
    	mainpanel.add(pdfpanel,"pdf");
    	mainpanel.add(whiteboardpanel,"whiteboard");
    	mainpanel.add(votepanel,"vote");
    	mainpanel.add(rulepanel,"rule");
    	
    	add(headerpanel,BorderLayout.NORTH);
    	add(mainpanel,BorderLayout.CENTER);
    	add(footerpanel,BorderLayout.SOUTH);
    	setUndecorated(true);
    	setSize(Toolkit.getDefaultToolkit().getScreenSize());
    	setVisible(true);

		ct.setPdfPanelHandle(pdfpanel);
    	ct.setTopicPanelHandle(topicpanel);
    	ct.setWhiteBoardPanelHandle(whiteboardpanel);
    	ct.setVotePanel(votepanel);
    	ct.setPdfPanel(this);
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public int getPageCurrent() {
		return pagecurrent;
	}
	public void setMem(String mem) {
		this.mem = mem;
	}
	public void setVote(int i) {
		vote = new String[i];
	}
	public void setPanel(String panel) { 
		c.show(mainpanel,panel);
		invalidate();
    	repaint();
    	validate();
	}
	public void setPanel(String panel,ByteArrayOutputStream b) { // override from Interface
		pdfpanel.OpenFile(b);
		c.show(mainpanel,panel);
		b.reset();
		invalidate();
    	repaint();
    	validate();
	}
	public void restorePanel() {
		c.show(mainpanel,mem);
	}
	public void setPageCurrent(int page) {
		this.pagecurrent = page;
	}
	private void OpenProjector() {
		try {
			dout.writeInt(9); // message 9 use for send to get information of topic.
			mem = "rule";
		} catch(Exception e) { e.printStackTrace(); }
		c.show(mainpanel,"rule");
	}
	
} // End of class