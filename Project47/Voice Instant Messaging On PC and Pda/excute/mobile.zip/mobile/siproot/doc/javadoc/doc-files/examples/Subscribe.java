/*
 * ============================================================================
 *  Copyright (c) 2004 Nokia.
 *  This material, including documentation and any related computer programs,
 *  is protected by copyright controlled by Nokia. All rights are reserved.
 *  Copying, including reproducing, storing, adapting or translating,
 *  any or all of this material requires the prior written consent of Nokia.
 *  This material also contains confidential information, which may not be
 *  disclosed to others without the prior written consent of Nokia.
 * ============================================================================
 */
package examples;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

import javax.microedition.sip.*;

public class Subscribe extends MIDlet implements SipClientConnectionListener, SipServerConnectionListener {

    private Display display;
    private SipDialog dialog;
    private Form form;

    public Subscribe() {
        display=Display.getDisplay(this);
        form = new Form("SUBSCRIBE from server");
        display.setCurrent(form);
    }
    
    public void startApp() {
        form.append("Starting...\n");
        try {
            SipConnectionNotifier scn = null;
            SipServerConnection ssc = null;
            // Start notifier on port 5060
            scn = (SipConnectionNotifier) Connector.open("sip:5060");
            scn.setListener(this);

            // Open outbound SIP connection to sippy.tester    
            SipClientConnection scc = 
               (SipClientConnection) Connector.open("sip:sippy.tester@172.21.39.135");
            // Initialize and send SUBSCRIBE for 'presence' events
            scc.initRequest("SUBSCRIBE", scn);
	    scc.setHeader("From", "sip:user@host.com");
	    scc.setHeader("Contact", "sip:user@"+scn.getLocalAddress()+":"+scn.getLocalPort());
            scc.setHeader("Expires", "930");
            scc.setHeader("Event", "presence");
            scc.addHeader("Accept", "application/xpidf+xml");
            scc.send();
            scc.receive(5000); // blocking receive
            form.append("Response: "+scc.getStatusCode());
            dialog = scc.getDialog();
            scc.close();

            form.append("Wait 10 secs before unsubscribing...");
            synchronized(this) {
               try{ wait(3000); }catch(Exception ee ){ }
            }
            // Initialize and send un-SUBSCRIBE, with Expires: 0
            scc = dialog.getNewClientConnection("SUBSCRIBE");
            // for example handle response in a listener
            scc.setListener(this);
            scc.setHeader("Expires", "0");
            scc.setHeader("Event", "presence");
            scc.send();
        } catch(IOException ex) {
	    ex.printStackTrace();
            // handle IOException
        }
    }
    
    /** 
     * listener method for incoming responses
     */
    public void notifyResponse(SipClientConnection scc) {
        try {
            scc.receive(0); // non-blocking receive
            form.append("Response: "+scc.getStatusCode());
            // handle response here
            scc.close();
        } catch(IOException ex) {
           // handle IOException
        }
    }
    
    /**
     * listener method for incoming requests
     */
    public void notifyRequest(SipConnectionNotifier scn) {
        SipServerConnection ssc;
        try {
            ssc = scn.acceptAndOpen(); // non-blocking
            form.append("Message: "+ssc.getMethod()+" received");
            // check if the received request is NOTIFY and it belongs to our dialog
            if(ssc.getMethod().equals("NOTIFY") && dialog.isSameDialog(ssc)) {
                String contentType = ssc.getHeader("Content-Type");
                String contentLength = ssc.getHeader("Content-Length");
                int length = Integer.parseInt(contentLength);
                if(contentType.equals("application/xpidf+xml")) {
                InputStream is = ssc.openContentInputStream();
                    byte buf[] = new byte[length];
                    int i = is.read(buf);
                    String tmp = new String(buf, 0, i);
                    form.append("NOTIFY info:"+tmp);
                    ssc.initResponse(200);
                    ssc.send();
                    //
                    // handle presence info
                    //
                }
            } else { 
                // send 481 "Subscription does not exist"
                ssc.initResponse(481);
                ssc.send();
            }
            ssc.close();
        } catch(IOException ex) { }
    }
    
    public void pauseApp() {
    }

    public void destroyApp(boolean b) {
        notifyDestroyed();
    }
    
    public void shutdown() {
        destroyApp(false);
    }   
}
