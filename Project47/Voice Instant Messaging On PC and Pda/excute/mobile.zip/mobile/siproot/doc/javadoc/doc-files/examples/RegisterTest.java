/*
 * ============================================================================
 *  Copyright (c) 2004 Nokia.
 *  This material, including documentation and any related computer programs,
 *  is protected by copyright controlled by Nokia. All rights are reserved.
 *  Copying, including reproducing, storing, adapting or translating,
 *  any or all of this material requires the prior written consent of Nokia.
 *  This material also contains confidential information, which may not be
 *  disclosed to others without the prior written consent of Nokia.
 * ============================================================================
 */
package examples;

import java.util.*;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

import javax.microedition.sip.*;

public class RegisterTest extends MIDlet implements CommandListener {

    private Display display;
    private Form form;
    private TextField registrar;
    private TextField useraddr;
    private TextField contact;
    private Command sendCmd;
    private Command exitCmd;

    public RegisterTest() {
	String ctaddr = "sip:user@host"; // Contact address
	// Open a SipConnectionNotifier in an arbitrary port
	SipConnectionNotifier scn = null;
	try {
	    scn = (SipConnectionNotifier) Connector.open("sip:");
	    if(scn != null) {
		// resolve Contact address from SipConnectionNotifier ino
		ctaddr = new String("sip:user@"+scn.getLocalAddress()+":"+scn.getLocalPort()); 
	    }
	} catch(Exception ex) {
	    ex.printStackTrace();
	}
	display=Display.getDisplay(this);
	form = new Form("Register test");
	registrar = new TextField("Registrar address:", "sip:10.128.0.50", 40, TextField.LAYOUT_LEFT);
	useraddr = new TextField("From-To:", "sip:sippy.tester@10.128.0.50", 40, TextField.LAYOUT_LEFT);
	contact = new TextField("Contact:", ctaddr, 40, TextField.LAYOUT_LEFT);
	form.append(registrar);
	form.append(useraddr);
	form.append(contact);
	sendCmd = new Command("Register", Command.ITEM, 1);
	form.addCommand(sendCmd);
	exitCmd = new Command("Exit", Command.EXIT, 1);
	form.addCommand(exitCmd);
	form.setCommandListener(this);
    }

    public void commandAction(Command c, Displayable d) {
	if(c == sendCmd) {
	    Thread t = new Thread() {
		    public void run() {
			register();
		    }
		};
	    t.start();
	}
	if(c == exitCmd) {
	    destroyApp(true);
	}
    }
    
    public void startApp() {
	display.setCurrent(form);
	
    }

    public void register() {
	try {	    
	    SipClientConnection scc = null;
	    // Open a SipClientConnection for REGISTER targeting the
	    // registrar address
	    scc = (SipClientConnection) Connector.open(registrar.getString());
	    scc.initRequest("REGISTER", null);
	    // Set necessary headers
	    scc.setHeader("From", useraddr.getString());
	    scc.setHeader("To", useraddr.getString());
	    scc.setHeader("Contact", contact.getString());
	    // Send it out
	    scc.send();

	    // wait for response
	    scc.receive(15000);
	    form.append("REGISTER Response: "+scc.getStatusCode()+" "+
			       scc.getReasonPhrase()+"\n");
	    // Display the registered Contact(s)
	    if(scc.getStatusCode() == 200) {
		String hdrs[] = scc.getHeaders("Contact");
		for(int i=0; i <hdrs.length; i++) {
		    form.append("Contact: "+hdrs[i]+"\n");
		}
	    }
	    
	} catch(Exception ex) {
	    ex.printStackTrace();
	}
    }

  public void pauseApp() {
  }
  public void destroyApp(boolean b) {
      notifyDestroyed();
  }
    
}







