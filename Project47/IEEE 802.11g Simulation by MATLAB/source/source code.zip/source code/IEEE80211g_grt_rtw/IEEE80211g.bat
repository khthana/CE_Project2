set MATLAB=D:\programs\MATLAB6p5
"%MATLAB%\rtw\bin\win32\gmake" -f IEEE80211g.mk ADD_MDL_NAME_TO_GLOBALS=1
