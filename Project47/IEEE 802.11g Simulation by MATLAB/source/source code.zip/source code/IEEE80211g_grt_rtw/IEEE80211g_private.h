/*
 * IEEE80211g_private.h
 *
 * Real-Time Workshop code generation for Simulink model "IEEE80211g.mdl".
 *
 * Model Version                        : 1.100
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Tue Apr 19 05:23:12 2005
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Tue Apr 19 05:23:14 2005
 */

#ifndef _RTW_HEADER_IEEE80211g_private_h_
# define _RTW_HEADER_IEEE80211g_private_h_

#ifndef _RTW_COMMON_DEFINES_
# define _RTW_COMMON_DEFINES_

#ifndef TRUE
# define TRUE (1)
#endif
#ifndef FALSE
# define FALSE (0)
#endif
#endif                                  /* _RTW_COMMON_DEFINES_ */

#include "dsp_rt.h"                     /* DSP Blockset general run time support functions */

#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFU) )
#error Fixed point code was generated for compiler with different sized uchars.
#endif

#if ( SCHAR_MAX != (0x7F) )
#error Fixed point code was generated for compiler with different sized chars.
#endif

#if ( USHRT_MAX != (0xFFFFU) )
#error Fixed point code was generated for compiler with different sized ushorts.
#endif

#if ( SHRT_MAX != (0x7FFF) )
#error Fixed point code was generated for compiler with different sized shorts.
#endif

#if ( UINT_MAX != (0xFFFFFFFFU) )
#error Fixed point code was generated for compiler with different sized uints.
#endif

#if ( INT_MAX != (0x7FFFFFFF) )
#error Fixed point code was generated for compiler with different sized ints.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFU) )
#error Fixed point code was generated for compiler with different sized ulongs.
#endif

#if ( LONG_MAX != (0x7FFFFFFF) )
#error Fixed point code was generated for compiler with different sized longs.
#endif
#include "dsprandsrc_rt.h"              /* DSP Blockset run time support library */
#include "dspfilter_rt.h"               /* DSP Blockset run time support library */
#include "dspupfirdn_rt.h"              /* DSP Blockset run time support library */
#include "dsppad_rt.h"                  /* DSP Blockset run time support library */
#include "dsp_ic_rt.h"                  /* DSP Blockset run time support library */
#include "dspeph_rt.h"                  /* DSP Blockset run time support library */
#include "dsprebuff_rt.h"               /* DSP Blockset run time support library */
#include "dspfft_rt.h"                  /* DSP Blockset run time support library */
#include "dspvfdly2_rt.h"               /* DSP Blockset run time support library */

extern void scomapskdemod(SimStruct *rts);
extern void scominterl(SimStruct *rts);
extern void scomselect(SimStruct *rts);
extern void scomapskmod(SimStruct *rts);
extern void scomviterbi(SimStruct *rts);
extern void scomconvenc(SimStruct *rts);
extern void scompnseq2(SimStruct *rts);
extern void scomtrigbuff2(SimStruct *rts);
extern void scomricianlos2(SimStruct *rts);
extern void scommultwithprop2(SimStruct *rts);
extern void scomawgnchan2(SimStruct *rts);
extern void IEEE80211g_Triggered_Ra_a_Init(void);
extern void IEEE80211g_Triggered_Ra_a_Start(void);
extern void IEEE80211g_Triggered_Ra_a(rtModel_IEEE80211g *rtm, int_T
 controlPortIdx, int_T tid);
extern void IEEE80211g_Triggered_Ra_b_Init(void);
extern void IEEE80211g_Triggered_Ra_b_Start(void);
extern void IEEE80211g_Triggered_Ra_b(rtModel_IEEE80211g *rtm, int_T
 controlPortIdx, int_T tid);
extern void IEEE80211g_Triggered_Ra_aFNI(rtModel_IEEE80211g *rtm, int_T
 controlPortIdx, int_T tid);
extern void IEEE80211g_Triggered_Ra_bFNI(rtModel_IEEE80211g *rtm, int_T
 controlPortIdx, int_T tid);
extern int_T rt_CallSys(SimStruct *S, int_T element, int_T tid);

#if !defined(MULTITASKING) && !defined(NRT)
# error Model (IEEE80211g) was built \
  in MultiTasking solver mode, however the MULTITASKING define \
  is not present. Please verify that your template makefile is \
  configured correctly.
#endif

#endif                                  /* _RTW_HEADER_IEEE80211g_private_h_ */
