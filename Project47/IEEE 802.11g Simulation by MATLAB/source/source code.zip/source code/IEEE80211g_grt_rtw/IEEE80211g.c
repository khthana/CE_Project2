/*
 * Real-Time Workshop code generation for Simulink model "IEEE80211g.mdl".
 *
 * Model Version                        : 1.100
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Tue Apr 19 05:23:12 2005
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Tue Apr 19 05:23:14 2005
 */

#include <math.h>
#include <string.h>
#include "IEEE80211g.h"
#include "IEEE80211g_private.h"

/* Block signals (auto storage) */
BlockIO rtB;

/* Block states (auto storage) */
D_Work rtDWork;

/* Parent Simstruct */
static rtModel_IEEE80211g model_S;
rtModel_IEEE80211g *const rtM_IEEE80211g = &model_S;

/* Initial conditions for function-call system: '<S19>/Triggered Rayleigh Profile' */
void IEEE80211g_Triggered_Ra_a_Init(void)
{

  /* DSP Blockset Filter Implementation (sdspfilter) - '<S24>/Doppler Filter' */
  {
    creal_T *statePtr = (creal_T *) &rtDWork.Doppler_Filter_a_FILT_STATES[0];
    /* Scalar expansion of ICs with extra zero element per channel */
    int_T numElems = 8;
    while (numElems--) {
      *statePtr++ = *(const creal_T *)&rtP.Doppler_Filter_a_ICRTP;
    }
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_a_OutIdx = rtDWork.FIR_Rate_Conversi_a_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion1' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_b_OutIdx = rtDWork.FIR_Rate_Conversi_b_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion2' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_c_OutIdx = rtDWork.FIR_Rate_Conversi_c_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion3' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_d_OutIdx = rtDWork.FIR_Rate_Conversi_d_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion4' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_e_OutIdx = rtDWork.FIR_Rate_Conversi_e_MemIdx = 0;
  }
}

/* Start for function-call system: '<S19>/Triggered Rayleigh Profile' */
void IEEE80211g_Triggered_Ra_a_Start(void)
{

  /* Constant Block: <S24>/Constant */
  rtB.Constant_j.re = rtP.Constant_j_Value.re;
  rtB.Constant_j.im = rtP.Constant_j_Value.im;

  /* DSP Blockset Random Source (sdsprandsrc2) - '<S24>/Random Source' */
  {
    uint32_T *seeds = &rtDWork.Random_Source_b_SEED_DWORK;
    /* copy seeds to seed buffer */
    memcpy(seeds,&rtP.Random_Source_b_InitSeed,1*sizeof(uint32_T));
    /* initialize state buffer */
    MWDSP_RandSrcInitState_GZ(seeds,&rtDWork.Random_Source_b_STATE_DWORK[0],1);
  }
}

/* Output and update for function-call system: '<S19>/Triggered Rayleigh Profile' */
void IEEE80211g_Triggered_Ra_a(rtModel_IEEE80211g *rtM_IEEE80211g, int_T
 controlPortIdx, int_T tid)
{
  /* local block i/o variables */
  creal_T rtb_Random_Source_b[2];
  creal_T rtb_FIR_Rate_Conversi_a[6];
  creal_T rtb_FIR_Rate_Conversi_b[18];
  creal_T rtb_FIR_Rate_Conversi_c[90];
  creal_T rtb_FIR_Rate_Conversi_d[450];

  /* Constant: '<S24>/Constant' */
  rtB.Constant_j.re = rtP.Constant_j_Value.re;
  rtB.Constant_j.im = rtP.Constant_j_Value.im;

  /* DSP Blockset Random Source (sdsprandsrc2) - '<S24>/Random Source' */
  MWDSP_RandSrc_GZ_Z((creal64_T*)&rtb_Random_Source_b[0],(creal64_T*)&rtP.Random_Source_b_Mean,1,&rtP.Random_Source_b_Variance,1,&rtDWork.Random_Source_b_STATE_DWORK[0],1,2);

  /* DSP Blockset Inherit Complexity (sdspihcplx2) - '<S24>/Inherit Complexity' */
  memcpy( &rtB.Inherit_Complexity_a[0], &rtb_Random_Source_b[0], (4 *
    sizeof(real_T)) );

  /* DSP Blockset Filter Implementation (sdspfilter) - '<S24>/Doppler Filter' */
  /* Filter algorithm: Cascaded second-order DF2T sections (double precision floating-point) */
  /* Complexities: input - complex, coeffs - real */
  /* Implementing filter algorithm */
  MWDSP_BQ5_DF2T_1fpf_Nsos_ZD(&rtB.Inherit_Complexity_a[0],
   &rtB.Doppler_Filter_a[0], &rtDWork.Doppler_Filter_a_FILT_STATES[0],
   &rtP.Doppler_Filter_a_RTP1COEFF[0], 2, 1, 4);

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion' */
  {
    creal_T *x = &rtB.Doppler_Filter_a[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_a_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_a_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_a_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_a[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_a_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_a_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_a_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 1,
     2,3,1,7,
     7,3,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion1' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_a[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_b_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_b_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_b_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_b[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_b_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_b_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_b_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 1,
     6,3,1,8,
     8,3,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion2' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_b[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_c_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_c_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_c_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_c[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_c_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_c_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_c_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 1,
     18,5,1,9,
     9,5,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion3' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_c[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_d_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_d_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_d_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_d[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_d_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_d_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_d_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 1,
     90,5,1,11,
     11,5,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S24>/FIR Rate Conversion4' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_d[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_e_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_e_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_e_OutBuf[0];
    creal_T *y = &rtB.FIR_Rate_Conversi_e[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_e_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_e_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_e_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 1,
     450,5,1,12,
     12,5,0,1);
  }
}

/* 
 * Forced non-inlined (FNI) function call stub 
 * for '<S19>/Triggered Rayleigh Profile' 
 */
void IEEE80211g_Triggered_Ra_aFNI(rtModel_IEEE80211g *rtM_IEEE80211g, int_T
 controlPortIdx, int_T tid) {

  IEEE80211g_Triggered_Ra_a(rtM_IEEE80211g, controlPortIdx, tid);
}

/* Initial conditions for function-call system: '<S28>/Triggered Rayleigh Profile' */
void IEEE80211g_Triggered_Ra_b_Init(void)
{

  /* DSP Blockset Filter Implementation (sdspfilter) - '<S33>/Doppler Filter' */
  {
    creal_T *statePtr = (creal_T *) &rtDWork.Doppler_Filter_b_FILT_STATES[0];
    /* Scalar expansion of ICs with extra zero element per channel */
    int_T chanCount = 2;
    while (chanCount--) {
      int_T numElems = 8;
      while (numElems--) {
        *statePtr++ = *(const creal_T *)&rtP.Doppler_Filter_b_ICRTP;
      }
    }
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_f_OutIdx = rtDWork.FIR_Rate_Conversi_f_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion1' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_g_OutIdx = rtDWork.FIR_Rate_Conversi_g_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion2' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_h_OutIdx = rtDWork.FIR_Rate_Conversi_h_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion3' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_i_OutIdx = rtDWork.FIR_Rate_Conversi_i_MemIdx = 0;
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion4' */
  {
    /*
     * Initialize the counters and pointers.
     */
    rtDWork.FIR_Rate_Conversi_j_OutIdx = rtDWork.FIR_Rate_Conversi_j_MemIdx = 0;
  }
}

/* Start for function-call system: '<S28>/Triggered Rayleigh Profile' */
void IEEE80211g_Triggered_Ra_b_Start(void)
{

  /* Constant Block: <S33>/Constant */
  rtB.Constant_k.re = rtP.Constant_k_Value.re;
  rtB.Constant_k.im = rtP.Constant_k_Value.im;

  /* DSP Blockset Random Source (sdsprandsrc2) - '<S33>/Random Source' */
  {
    uint32_T *seeds = &rtDWork.Random_Source_c_SEED_DWORK[0];
    /* create seed for each channel */
    MWDSP_RandSrcCreateSeeds_64(rtP.Random_Source_c_InitSeed,seeds,2);
    /* initialize state buffer */
    MWDSP_RandSrcInitState_GZ(seeds,&rtDWork.Random_Source_c_STATE_DWORK[0],2);
  }
}

/* Output and update for function-call system: '<S28>/Triggered Rayleigh Profile' */
void IEEE80211g_Triggered_Ra_b(rtModel_IEEE80211g *rtM_IEEE80211g, int_T
 controlPortIdx, int_T tid)
{
  /* local block i/o variables */
  creal_T rtb_Random_Source_c[4];
  creal_T rtb_FIR_Rate_Conversi_f[12];
  creal_T rtb_FIR_Rate_Conversi_g[36];
  creal_T rtb_FIR_Rate_Conversi_h[180];
  creal_T rtb_FIR_Rate_Conversi_i[900];

  /* Constant: '<S33>/Constant' */
  rtB.Constant_k.re = rtP.Constant_k_Value.re;
  rtB.Constant_k.im = rtP.Constant_k_Value.im;

  /* DSP Blockset Random Source (sdsprandsrc2) - '<S33>/Random Source' */
  MWDSP_RandSrc_GZ_Z((creal64_T*)&rtb_Random_Source_c[0],(creal64_T*)&rtP.Random_Source_c_Mean,1,&rtP.Random_Source_c_Variance,1,&rtDWork.Random_Source_c_STATE_DWORK[0],2,2);

  /* DSP Blockset Inherit Complexity (sdspihcplx2) - '<S33>/Inherit Complexity' */
  memcpy( &rtB.Inherit_Complexity_b[0], &rtb_Random_Source_c[0], (8 *
    sizeof(real_T)) );

  /* DSP Blockset Filter Implementation (sdspfilter) - '<S33>/Doppler Filter' */
  /* Filter algorithm: Cascaded second-order DF2T sections (double precision floating-point) */
  /* Complexities: input - complex, coeffs - real */
  /* Implementing filter algorithm */
  MWDSP_BQ5_DF2T_1fpf_Nsos_ZD(&rtB.Inherit_Complexity_b[0],
   &rtB.Doppler_Filter_b[0], &rtDWork.Doppler_Filter_b_FILT_STATES[0],
   &rtP.Doppler_Filter_b_RTP1COEFF[0], 2, 2, 4);

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion' */
  {
    creal_T *x = &rtB.Doppler_Filter_b[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_f_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_f_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_f_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_f[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_f_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_f_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_f_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 2,
     2,3,1,7,
     7,3,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion1' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_f[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_g_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_g_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_g_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_g[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_g_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_g_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_g_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 2,
     6,3,1,8,
     8,3,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion2' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_g[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_h_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_h_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_h_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_h[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_h_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_h_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_h_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 2,
     18,5,1,9,
     9,5,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion3' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_h[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_i_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_i_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_i_OutBuf[0];
    creal_T *y = &rtb_FIR_Rate_Conversi_i[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_i_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_i_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_i_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 2,
     90,5,1,11,
     11,5,0,1);
  }

  /* DSP Blockset FIR Rate Conversion S-Function (sdspupfirdn2) - '<S33>/FIR Rate Conversion4' */
  {
    creal_T *x = &rtb_FIR_Rate_Conversi_i[0];
    creal_T *tap0 = &rtDWork.FIR_Rate_Conversi_j_InBuf[0];
    creal_T *sums = &rtDWork.FIR_Rate_Conversi_j_PartialSums[0];
    creal_T *outBuf = &rtDWork.FIR_Rate_Conversi_j_OutBuf[0];
    creal_T *y = &rtB.FIR_Rate_Conversi_j[0];
    int_T *tapIdx = &rtDWork.FIR_Rate_Conversi_j_MemIdx;
    int_T *outIdx = &rtDWork.FIR_Rate_Conversi_j_OutIdx;
    const real_T * const filter = (real_T *)&rtP.FIR_Rate_Conversi_j_FILTER[0];

    MWDSP_UpFIRDn_ZD(x,y,tap0,sums,outBuf,filter,tapIdx,outIdx, 2,
     450,5,1,12,
     12,5,0,1);
  }
}

/* 
 * Forced non-inlined (FNI) function call stub 
 * for '<S28>/Triggered Rayleigh Profile' 
 */
void IEEE80211g_Triggered_Ra_bFNI(rtModel_IEEE80211g *rtM_IEEE80211g, int_T
 controlPortIdx, int_T tid) {

  IEEE80211g_Triggered_Ra_b(rtM_IEEE80211g, controlPortIdx, tid);
}

/* Initial conditions for root system: '<Root>' */
void MdlInitialize(void)
{

  /* DSP Blockset Delay (sdspdly2) - '<Root>/Integer Delay1' */
  rtDWork.Integer_Delay1_BUFF_OFFSET = 0;
  MWDSP_DelayCopyScalarICs( (byte_T *)&rtDWork.Integer_Delay1_BUFF[0], (byte_T
    *)&rtP.Integer_Delay1_IC, 1*2, sizeof(real_T) );

  /* DSP Blockset Buffer/Unbuffer (sdsprebuff2) - '<S97>/Buffer' */

  /* Copy ICs into circular buffer */
  {
    const int_T bufLenBytes = 8640 * sizeof(real_T);
    byte_T *circBufPtr = (byte_T *)&rtDWork.Buffer_CircBuff[0];
    const byte_T *icPtr = (const byte_T *)&rtP.Buffer_IC;
    int_T i = 1;
    while (i-- > 0) {
      MWDSP_CopyScalarICs(circBufPtr, icPtr, 4320, sizeof(real_T));
      circBufPtr += bufLenBytes;
    }
  }

  /* Initialize DWork for IN_BUF_PTR and OUT_BUF_PTR */
  {
    *&rtDWork.Buffer_IN_BUF_PTR = (void *)( (byte_T
      *)&rtDWork.Buffer_CircBuff[0] + 4320 * sizeof(real_T) );
    *&rtDWork.Buffer_OUT_BUF_PTR = (void *)( (byte_T
      *)&rtDWork.Buffer_CircBuff[0] );
  }

  /* Calculate shiftPerElement
   * (assuming that number of bits
   *  per element is power of two)
   */
  {
    int_T expn;
    const double frac = frexp((double)sizeof(real_T), &expn);
    *&rtDWork.Buffer_ShiftPerElem = expn - 1;
    UNUSED_ARG(frac);
  }

  /* Level2 S-Function Block: <S101>/PN Sequence Generator (scompnseq2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[132];
    sfcnInitializeConditions(rts);
  }

  {
    int_T *buffoff = &rtDWork.Variable_Fraction_a_BUFF_OFFSET;
    int_T hlen = 12/2;
    *buffoff = 1 + hlen - 1;
  }
  MWDSP_DelayCopyScalarICs( (byte_T *)&rtDWork.Variable_Fraction_a_BUFF[0],
   (byte_T *)&rtP.Variable_Fraction_a_IC, 1*8, 2*sizeof(real_T) );

  /* Level2 S-Function Block: <S22>/S-Function (scomtrigbuff2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[133];
    sfcnInitializeConditions(rts);
  }
  IEEE80211g_Triggered_Ra_a_Init();

  {
    int_T *buffoff = &rtDWork.Variable_Fraction_b_BUFF_OFFSET;
    int_T hlen = 12/2;
    *buffoff = 2 + hlen - 1;
  }
  MWDSP_DelayCopyScalarICs( (byte_T *)&rtDWork.Variable_Fraction_b_BUFF[0],
   (byte_T *)&rtP.Variable_Fraction_b_IC, 2*9, 2*sizeof(real_T) );

  /* Level2 S-Function Block: <S31>/S-Function (scomtrigbuff2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[136];
    sfcnInitializeConditions(rts);
  }
  IEEE80211g_Triggered_Ra_b_Init();

  /* Level2 S-Function Block: <S12>/Dynamic AWGN (scomawgnchan2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[139];
    sfcnInitializeConditions(rts);
  }

  /* DSP Blockset Repeat (sdsprepeat2) - '<S92>/Repeat' */
  /* Reset counters */
  rtDWork.Repeat_REPEAT_CNT = 0;
  rtDWork.Repeat_ITERATION_CNT = 0;

  /* DSP Blockset Delay (sdspdly2) - '<S1>/Integer Delay2' */
  rtDWork.Integer_Delay2_BUFF_OFFSET = 0;
  MWDSP_DelayCopyScalarICs( (byte_T *)&rtDWork.Integer_Delay2_BUFF[0], (byte_T
    *)&rtP.Integer_Delay2_IC, 1*2, sizeof(real_T) );
}

/* Start for root system: '<Root>' */
void MdlStart(void)
{

  /* Start for enable system: '<S97>/Binary source' */
  /* enable SubSystem Block: <S97>/Binary source */
  rtDWork.Binary_sourc_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* DSP Blockset Random Source (sdsprandsrc2) - '<S107>/Random Source' */
  {
    uint32_T *seeds = &rtDWork.Random_Source_d_SEED_DWORK;
    /* copy seeds to seed buffer */
    memcpy(seeds,&rtP.Random_Source_d_InitSeed,1*sizeof(uint32_T));
    /* initialize state buffer */
    MWDSP_RandSrcInitState_U_64(seeds,&rtDWork.Random_Source_d_STATE_DWORK[0],1);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S107>/data out */

  {
    int_T i1;

    real_T *u0 = &rtB.Relational_Operator_b[0];

    for (i1=0; i1 < 240; i1++) {
      u0[i1] = rtP.data_out_Y0;
    }
  }

  /* Start for enable system: '<S99>/Modulator 1' */
  /* enable SubSystem Block: <S99>/Modulator 1 */
  rtDWork.Modulator_1_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S110>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[73];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S122>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[74];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S110>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[75];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S110>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[76];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 1' */

  /* Level2 S-Function Block: <S110>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[76];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 2' */
  /* enable SubSystem Block: <S99>/Modulator 2 */
  rtDWork.Modulator_2_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S114>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[93];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S126>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[94];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S114>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[95];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S114>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[96];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 2' */

  /* Level2 S-Function Block: <S114>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[96];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 3' */
  /* enable SubSystem Block: <S99>/Modulator 3 */
  rtDWork.Modulator_3_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S115>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[98];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S127>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[99];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S115>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[100];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S115>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[101];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 3' */

  /* Level2 S-Function Block: <S115>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[101];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 4' */
  /* enable SubSystem Block: <S99>/Modulator 4 */
  rtDWork.Modulator_4_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S116>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[103];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S128>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[104];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S116>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[105];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S116>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[106];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 4' */

  /* Level2 S-Function Block: <S116>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[106];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 5' */
  /* enable SubSystem Block: <S99>/Modulator 5 */
  rtDWork.Modulator_5_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S117>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[108];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S129>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[109];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S117>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[110];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S117>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[111];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 5' */

  /* Level2 S-Function Block: <S117>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[111];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 6' */
  /* enable SubSystem Block: <S99>/Modulator 6 */
  rtDWork.Modulator_6_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S118>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[113];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S130>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[114];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S118>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[115];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S118>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[116];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 6' */

  /* Level2 S-Function Block: <S118>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[116];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 7' */
  /* enable SubSystem Block: <S99>/Modulator 7 */
  rtDWork.Modulator_7_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S119>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[118];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S131>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[119];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S119>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[120];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S119>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[121];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 7' */

  /* Level2 S-Function Block: <S119>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[121];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 8' */
  /* enable SubSystem Block: <S99>/Modulator 8 */
  rtDWork.Modulator_8_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S120>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[123];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S132>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[124];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S120>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[125];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S120>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[126];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 8' */

  /* Level2 S-Function Block: <S120>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[126];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 9' */
  /* enable SubSystem Block: <S99>/Modulator 9 */
  rtDWork.Modulator_9_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S121>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[128];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S133>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[129];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S121>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[130];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S121>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[131];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 9' */

  /* Level2 S-Function Block: <S121>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[131];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 10' */
  /* enable SubSystem Block: <S99>/Modulator 10 */
  rtDWork.Modulator_10_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S111>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[78];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S123>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[79];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S111>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[80];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S111>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[81];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 10' */

  /* Level2 S-Function Block: <S111>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[81];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 11' */
  /* enable SubSystem Block: <S99>/Modulator 11 */
  rtDWork.Modulator_11_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S112>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[83];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S124>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[84];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S112>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[85];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S112>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[86];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 11' */

  /* Level2 S-Function Block: <S112>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[86];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S99>/Modulator 12' */
  /* enable SubSystem Block: <S99>/Modulator 12 */
  rtDWork.Modulator_12_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S113>/P2 Puncture (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[88];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S125>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[89];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S113>/General Block Interleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[90];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S113>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[91];
    sfcnStart(rts);
  }

  /* Initial conditions for enable system: '<S99>/Modulator 12' */

  /* Level2 S-Function Block: <S113>/Rectangular QAM Modulator Baseband (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[91];
    sfcnInitializeConditions(rts);
  }

  /* Constant Block: <S105>/Constant */
  {
    int_T i1;

    creal_T *y0 = &rtB.Constant_d[0];
    const creal_T *p_Constant_d_Value = &rtP.Constant_d_Value[0];

    for (i1=0; i1 < 20; i1++) {
      y0[i1].re = p_Constant_d_Value[i1].re;
      y0[i1].im = p_Constant_d_Value[i1].im;
    }
  }

  IEEE80211g_Triggered_Ra_a_Start();

  /* Level2 S-Function Block: <S22>/S-Function (scomtrigbuff2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[133];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S23>/S-Function (scomricianlos2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[134];
    sfcnStart(rts);
  }

  IEEE80211g_Triggered_Ra_b_Start();

  /* Level2 S-Function Block: <S31>/S-Function (scomtrigbuff2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[136];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S32>/S-Function (scomricianlos2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[137];
    sfcnStart(rts);
  }

  /* DSP Blockset Random Source (sdsprandsrc2) - '<S12>/Random Source' */
  {
    uint32_T *seeds = &rtDWork.Random_Source_a_SEED_DWORK;
    /* copy seeds to seed buffer */
    memcpy(seeds,&rtP.Random_Source_a_InitSeed,1*sizeof(uint32_T));
    /* initialize state buffer */
    MWDSP_RandSrcInitState_GZ(seeds,&rtDWork.Random_Source_a_STATE_DWORK[0],1);
  }

  /* Level2 S-Function Block: <S12>/Dynamic AWGN (scomawgnchan2) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[139];
    sfcnStart(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 1' */
  /* enable SubSystem Block: <S47>/Demodulator 1 */
  rtDWork.Demodulato_a_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S55>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[0];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S55>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[1];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S68>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[2];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S55>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[3];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S55>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[4];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S55>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_a[0];

    for (i1=0; i1 < 480; i1++) {
      u0[i1] = rtP.rxdata_a_Y0;
    }
  }

  /* (Virtual) Outport Block: <S55>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_h[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_a_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 1' */

  /* Level2 S-Function Block: <S55>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[0];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S55>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[4];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S55>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[5];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 2' */
  /* enable SubSystem Block: <S47>/Demodulator 2 */
  rtDWork.Demodulato_b_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S59>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[24];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S59>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[25];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S76>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[26];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S59>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[27];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S59>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[28];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S59>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_e[0];

    for (i1=0; i1 < 720; i1++) {
      u0[i1] = rtP.rxdata_e_Y0;
    }
  }

  /* (Virtual) Outport Block: <S59>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_p[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_e_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 2' */

  /* Level2 S-Function Block: <S59>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[24];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S59>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[28];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S59>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[29];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 3' */
  /* enable SubSystem Block: <S47>/Demodulator 3 */
  rtDWork.Demodulato_c_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S60>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[30];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S60>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[31];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S78>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[32];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S60>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[33];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S60>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[34];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S60>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_f[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1] = rtP.rxdata_f_Y0;
    }
  }

  /* (Virtual) Outport Block: <S60>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_r[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_f_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 3' */

  /* Level2 S-Function Block: <S60>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[30];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S60>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[34];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S60>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[35];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 4' */
  /* enable SubSystem Block: <S47>/Demodulator 4 */
  rtDWork.Demodulato_d_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S61>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[36];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S61>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[37];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S80>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[38];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S61>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[39];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S61>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[40];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S61>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_g[0];

    for (i1=0; i1 < 1440; i1++) {
      u0[i1] = rtP.rxdata_g_Y0;
    }
  }

  /* (Virtual) Outport Block: <S61>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_t[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_g_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 4' */

  /* Level2 S-Function Block: <S61>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[36];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S61>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[40];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S61>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[41];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 5' */
  /* enable SubSystem Block: <S47>/Demodulator 5 */
  rtDWork.Demodulato_e_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S62>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[42];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S62>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[43];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S82>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[44];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S62>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[45];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S62>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[46];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S62>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_h[0];

    for (i1=0; i1 < 1920; i1++) {
      u0[i1] = rtP.rxdata_h_Y0;
    }
  }

  /* (Virtual) Outport Block: <S62>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_v[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_h_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 5' */

  /* Level2 S-Function Block: <S62>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[42];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S62>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[46];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S62>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[47];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 6' */
  /* enable SubSystem Block: <S47>/Demodulator 6 */
  rtDWork.Demodulato_f_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S63>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[48];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S63>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[49];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S84>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[50];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S63>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[51];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S63>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[52];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S63>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_i[0];

    for (i1=0; i1 < 2880; i1++) {
      u0[i1] = rtP.rxdata_i_Y0;
    }
  }

  /* (Virtual) Outport Block: <S63>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_x[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_i_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 6' */

  /* Level2 S-Function Block: <S63>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[48];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S63>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[52];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S63>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[53];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 7' */
  /* enable SubSystem Block: <S47>/Demodulator 7 */
  rtDWork.Demodulato_g_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S64>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[54];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S64>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[55];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S86>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[56];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S64>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[57];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S64>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[58];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S64>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_j[0];

    for (i1=0; i1 < 3840; i1++) {
      u0[i1] = rtP.rxdata_j_Y0;
    }
  }

  /* (Virtual) Outport Block: <S64>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_z[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_j_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 7' */

  /* Level2 S-Function Block: <S64>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[54];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S64>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[58];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S64>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[59];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 8' */
  /* enable SubSystem Block: <S47>/Demodulator 8 */
  rtDWork.Demodulato_h_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S65>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[60];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S65>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[61];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S88>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[62];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S65>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[63];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S65>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[64];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S65>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_k[0];

    for (i1=0; i1 < 4320; i1++) {
      u0[i1] = rtP.rxdata_k_Y0;
    }
  }

  /* (Virtual) Outport Block: <S65>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_ab[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_k_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 8' */

  /* Level2 S-Function Block: <S65>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[60];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S65>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[64];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S65>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[65];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 9' */
  /* enable SubSystem Block: <S47>/Demodulator 9 */
  rtDWork.Demodulato_i_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S66>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[66];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S66>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[67];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S90>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[68];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S66>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[69];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S66>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[70];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S66>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_l[0];

    for (i1=0; i1 < 720; i1++) {
      u0[i1] = rtP.rxdata_l_Y0;
    }
  }

  /* (Virtual) Outport Block: <S66>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_ad[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_l_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 9' */

  /* Level2 S-Function Block: <S66>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[66];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S66>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[70];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S66>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[71];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 10' */
  /* enable SubSystem Block: <S47>/Demodulator 10 */
  rtDWork.Demodulato_j_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S56>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[6];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S56>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[7];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S70>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[8];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S56>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[9];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S56>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[10];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S56>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_b[0];

    for (i1=0; i1 < 1440; i1++) {
      u0[i1] = rtP.rxdata_b_Y0;
    }
  }

  /* (Virtual) Outport Block: <S56>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_j[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_b_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 10' */

  /* Level2 S-Function Block: <S56>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[6];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S56>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[10];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S56>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[11];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 11' */
  /* enable SubSystem Block: <S47>/Demodulator 11 */
  rtDWork.Demodulato_k_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S57>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[12];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S57>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[13];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S72>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[14];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S57>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[15];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S57>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[16];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S57>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_c[0];

    for (i1=0; i1 < 1440; i1++) {
      u0[i1] = rtP.rxdata_c_Y0;
    }
  }

  /* (Virtual) Outport Block: <S57>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_l[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_c_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 11' */

  /* Level2 S-Function Block: <S57>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[12];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S57>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[16];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S57>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[17];
    sfcnInitializeConditions(rts);
  }

  /* Start for enable system: '<S47>/Demodulator 12' */
  /* enable SubSystem Block: <S47>/Demodulator 12 */
  rtDWork.Demodulato_l_MODE[0] = (int_T) SUBSYS_DISABLED;

  /* Level2 S-Function Block: <S58>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[18];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S58>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[19];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S74>/General Block Deinterleaver (scominterl) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[20];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S58>/Insert Zero4 (scomselect) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[21];
    sfcnStart(rts);
  }

  /* Level2 S-Function Block: <S58>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[22];
    sfcnStart(rts);
  }

  /* virtual outports code */

  /* (Virtual) Outport Block: <S58>/rxdata */

  {
    int_T i1;

    real_T *u0 = &rtB.Viterbi_Decoder1_d[0];

    for (i1=0; i1 < 1440; i1++) {
      u0[i1] = rtP.rxdata_d_Y0;
    }
  }

  /* (Virtual) Outport Block: <S58>/symerr */

  {
    int_T i1;

    creal_T *u0 = &rtB.Sum_n[0];

    for (i1=0; i1 < 960; i1++) {
      u0[i1].re = rtP.symerr_d_Y0;
      u0[i1].im = 0.0;
    }
  }

  /* Initial conditions for enable system: '<S47>/Demodulator 12' */

  /* Level2 S-Function Block: <S58>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[18];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S58>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[22];
    sfcnInitializeConditions(rts);
  }

  /* Level2 S-Function Block: <S58>/Viterbi Decoder1 (scomviterbi) */
  {
    SimStruct *rts = rtM_IEEE80211g->childSfunctions[23];
    sfcnInitializeConditions(rts);
  }

  /* Width Block: <S39>/Width */
  rtB.Width_a = (real_T)1;

  /* Width Block: <S40>/Width */
  rtB.Width_b = (real_T)4320;

  /* Width Block: <S41>/Width */
  rtB.Width_c = (real_T)4320;

  /* Width Block: <S42>/Width */
  rtB.Width_d = (real_T)1;

  /* ToWorkspace Block: <S7>/To Workspace */
  {
    static const int_T rt_ToWksWidths[] = {4320};
    static const int_T rt_ToWksNumDimensions[] = {2};
    static const int_T rt_ToWksDimensions[] = {4320, 1};
    static const BuiltInDTypeId rt_ToWksDataTypeIds[] = {SS_DOUBLE};
    static const int_T rt_ToWksComplexSignals[] = {0};
    static const int_T rt_ToWksFrameData[] = {1};
    static const char_T rt_ToWksLabels[] = "";
    static const RTWLogSignalInfo rt_ToWksSignalInfo = {
      1,
      rt_ToWksWidths,
      rt_ToWksNumDimensions,
      rt_ToWksDimensions,
      rt_ToWksDataTypeIds,
      rt_ToWksComplexSignals,
      rt_ToWksFrameData,
      rt_ToWksLabels,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL,
      NULL
    };
    static const char_T rt_ToWksBlockName[] =
      "IEEE80211g/Transmitter/To Workspace";

    rtDWork.To_Workspace_PWORK.LoggedData =
      rt_CreateStructLogVar(rtM_IEEE80211g->rtwLogInfo,
      rtM_IEEE80211g->Timing.tFinal, rtM_IEEE80211g->Timing.stepSize,
      &(rtmGetErrorStatus(rtM_IEEE80211g)), "simout", 0, 0, 1, 7.68E-005,
      &rt_ToWksSignalInfo, rt_ToWksBlockName);

    if (rtDWork.To_Workspace_PWORK.LoggedData == NULL) return;
  }

  MdlInitialize();
}

/* Outputs for root system: '<Root>' */
void MdlOutputs(int_T tid)
{
  /* local block i/o variables */
  creal_T rtb_Select_data_blocks_o1[100];
  creal_T rtb_Select_data_blocks_o2[260];
  creal_T rtb_Select_data_blocks_o3[120];
  creal_T rtb_Select_data_blocks_o4[120];
  creal_T rtb_Select_data_blocks_o5[260];
  creal_T rtb_Select_data_blocks_o6[100];
  creal_T rtb_Assemble_Subcarriers[1060];
  creal_T rtb_Zero_Pad_a[1536];
  creal_T rtb_Reshape2[1920];
  creal_T rtb_Permute_Matrix_b[3840];
  creal_T rtb_Combine_Paths_b[1920];
  creal_T rtb_Remove_DC_component[1248];
  creal_T rtb_Select_training_data_o2[1040];
  creal_T rtb_Transpose_a[208];
  creal_T rtb_Repeat[1040];
  creal_T rtb_Pilots[80];
  creal_T rtb_Multiport_Switch1[960];
  creal_T rtb_temp213[960];
  creal_T rtb_temp214[1272];
  creal_T rtb_temp215[1920];
  creal_T rtb_temp216[1920];
  creal_T rtb_temp217[208];
  creal_T rtb_temp218[52];
  creal_T rtb_temp219[1040];
  creal_T rtb_temp220[1536];
  real_T rtb_Integer_Delay1;
  real_T rtb_Fcn2_a;
  real_T rtb_Fcn1_a;
  real_T rtb_Fcn3_a;
  real_T rtb_Fcn4_a;
  real_T rtb_Fcn5_a;
  real_T rtb_Fcn6_a;
  real_T rtb_Fcn7_a;
  real_T rtb_Fcn8_a;
  real_T rtb_Fcn9_a;
  real_T rtb_Fcn10_a;
  real_T rtb_Fcn11_a;
  real_T rtb_Fcn12_a;
  real_T rtb_Fcn4_b;
  real_T rtb_Fcn1_b;
  real_T rtb_Fcn2_b;
  real_T rtb_Fcn3_b;
  real_T rtb_Fcn5_b;
  real_T rtb_Fcn6_b;
  real_T rtb_Fcn7_b;
  real_T rtb_Fcn8_b;
  real_T rtb_Fcn9_b;
  real_T rtb_Fcn10_b;
  real_T rtb_Fcn11_b;
  real_T rtb_Fcn12_b;
  real_T rtb_Math_Function2;
  real_T rtb_log10_a;
  real_T rtb_Sum2_a;
  real_T rtb_Direct_Look_Up_Table_n_D_c;
  real_T rtb_Direct_Look_Up_Table_n_D_d;
  real_T rtb_Variance;
  real_T rtb_log10_b;
  real_T rtb_Remove_training_DC_componen[208];
  real_T rtb_Gain_b[20];
  real_T rtb_Math_Function_b[208];
  real_T rtb_Mean1[52];
  real_T rtb_Abs[960];
  real_T rtb_Matrix_Concatenation1_a[2];
  real_T rtb_Matrix_Concatenation1_b[4321];
  real_T rtb_Zero_Pad2[4320];
  real_T rtb_Zero_Pad3[4320];
  real_T rtb_Zero_Pad4[4320];
  real_T rtb_Zero_Pad5[4320];
  real_T rtb_Zero_Pad6[4320];
  real_T rtb_Zero_Pad7[4320];
  real_T rtb_Zero_Pad8[4320];
  real_T rtb_Zero_Pad9[4320];
  real_T rtb_Zero_Pad10[4320];
  real_T rtb_Zero_Pad11[4320];
  real_T rtb_Zero_Pad12[4320];
  real_T rtb_Matrix_Concatenation1_c[4321];
  real_T rtb_Matrix_Concatenation1_d[2];
  real_T rtb_Complex_to_Real_Imag_o2[8646];
  real_T rtb_Random_Source_d[240];
  real_T rtb_temp311[20];
  real_T rtb_temp312[8646];
  real_T rtb_temp313;
  real_T rtb_temp314[4320];
  real_T rtb_temp315;

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* DSP Blockset Delay (sdspdly2) - '<Root>/Integer Delay1' */

    {
      int_T ti = rtDWork.Integer_Delay1_BUFF_OFFSET;

      memcpy(&rtb_Integer_Delay1, ((byte_T *) &rtDWork.Integer_Delay1_BUFF[0] +
        (ti*sizeof(real_T))), sizeof(real_T));
    }

    /* Selector: '<S49>/Remove training DC component' incorporates:
     *   Constant: '<S54>/Training sequence'
     */
    {
      static const int_T rowIndices[52] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
        12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
        49, 50, 51, 52};

      {
        int_T i1;

        const real_T *u0 = &rtP.Training_sequence_a_Value[0];
        real_T *y0 = &rtb_Remove_training_DC_componen[0];

        for (i1=0; i1 < 52; i1++) {
          y0[i1] = u0[0+rowIndices[i1]];
        }
      }
      {
        int_T i1;

        const real_T *u0 = &rtP.Training_sequence_a_Value[0];
        real_T *y0 = &rtb_Remove_training_DC_componen[0];

        for (i1=0; i1 < 52; i1++) {
          y0[i1 + 52] = u0[53+rowIndices[i1]];
        }
      }
      {
        int_T i1;

        const real_T *u0 = &rtP.Training_sequence_a_Value[0];
        real_T *y0 = &rtb_Remove_training_DC_componen[0];

        for (i1=0; i1 < 52; i1++) {
          y0[i1 + 104] = u0[106+rowIndices[i1]];
        }
      }
      {
        int_T i1;

        const real_T *u0 = &rtP.Training_sequence_a_Value[0];
        real_T *y0 = &rtb_Remove_training_DC_componen[0];

        for (i1=0; i1 < 52; i1++) {
          y0[i1 + 156] = u0[159+rowIndices[i1]];
        }
      }
    }

    /* S-Function (sfun_nddirectlook): '<S109>/Direct Look-Up Table (n-D)' incorporates:
     *   Sum: '<S109>/Sum'
     *   Constant: '<S109>/Constant'
     */

    /* LookupNDDirect: '<S109>/Direct Look-Up Table (n-D)' */
    /* 1-dimensional Direct Look-Up returning a Scalar */
    {
      int_T rt_uClip = (int_T)(rtb_Integer_Delay1 - rtP.Constant_b_Value);

      rt_uClip = rt_SATURATE(rt_uClip,0,7);
      rtb_temp313 = rtP.Direct_Look_Up_Table_n_D_a_tabl[rt_uClip];
    }

    /* RelationalOperator: '<S108>/Relational Operator1' incorporates:
     *   Constant: '<S108>/Constant'
     */
    {
      int_T i1;

      const real_T *u0 = &rtP.Constant_a_Value[0];
      real_T *y0 = &rtB.Relational_Operator1_a[0];

      for (i1=0; i1 < 18; i1++) {
        y0[i1] = (u0[i1] <= rtb_temp313);
      }
    }

    /* DSP Blockset Buffer/Unbuffer (sdsprebuff2) - '<S108>/Unbuffer' */
    {
      memcpy( &rtB.Unbuffer[0], &rtB.Relational_Operator1_a[0], (18 *
        sizeof(real_T)) );
    }
  }

  /* SubSystem: '<S97>/Binary source' */

  /* Output and update for enable system: '<S97>/Binary source' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 0, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Binary_sourc_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 0, tid)) { /* Sample time: [4.2666666666666668E-006, 0.0] */
      rtDWork.Binary_sourc_MODE[1]= (int_T) SUBSYS_DISABLED;
      {
        int_T i1;

        const real_T *uenable = &rtB.Unbuffer[0];

        for (i1=0; i1 < 18; i1++) {
          rtDWork.Binary_sourc_MODE[1] |= (int_T) (uenable[i1] > 0.0) ?
            SUBSYS_ENABLED : SUBSYS_DISABLED;
        }
      }
    }

    enableState = (EnableStates) rtDWork.Binary_sourc_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Binary_sourc_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S97>/Binary source' */
        /* DisableFcn of enable SubSystem Block: <S97>/Binary source */
        if (rtDWork.Binary_sourc_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S107>/data out */

          {
            int_T i1;

            real_T *u0 = &rtB.Relational_Operator_b[0];

            for (i1=0; i1 < 240; i1++) {
              u0[i1] = rtP.data_out_Y0;
            }
          }

          rtDWork.Binary_sourc_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Binary_sourc_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 0, tid)) {

      /* DSP Blockset Random Source (sdsprandsrc2) - '<S107>/Random Source' */
      MWDSP_RandSrc_U_D((real64_T*)&rtb_Random_Source_d[0],&rtP.Random_Source_d_Min,1,&rtP.Random_Source_d_Max,1,&rtDWork.Random_Source_d_STATE_DWORK[0],1,240);

      /* RelationalOperator: '<S107>/Relational Operator' incorporates:
       *   Constant: '<S107>/Constant'
       */
      {
        int_T i1;

        const real_T *u0 = &rtb_Random_Source_d[0];
        real_T *y0 = &rtB.Relational_Operator_b[0];

        for (i1=0; i1 < 240; i1++) {
          y0[i1] = (u0[i1] > rtP.Constant_x_Value);
        }
      }
    } }

  /* DSP Blockset Buffer/Unbuffer (sdsprebuff2) - '<S97>/Buffer' */
  {
    /* Copy input samples to buffer */
    if (rtmIsSampleHit(rtM_IEEE80211g, 0, tid)) {
      MWDSP_Buf_CopyFrame_OL_1ch((const byte_T *)&rtB.Relational_Operator_b[0],
       (byte_T **)&rtDWork.Buffer_IN_BUF_PTR, (byte_T
        *)&rtDWork.Buffer_CircBuff[0], *&rtDWork.Buffer_ShiftPerElem, 8640 *
       sizeof(real_T) ,240);
    }

    /* Copy output samples from buffer */
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
      MWDSP_Buf_OutputFrame_1ch((byte_T *)&rtB.Buffer[0], (byte_T
        **)&rtDWork.Buffer_OUT_BUF_PTR, (byte_T *)&rtDWork.Buffer_CircBuff[0],
       *&rtDWork.Buffer_ShiftPerElem, 8640 * sizeof(real_T) ,4320, 0);
    }
  }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn2'
     *
     * Regarding '<S99>/Fcn2':
     *   Expression: u==1
     */
    rtb_Fcn2_a = rtb_Integer_Delay1 == 1.0;
  }

  /* SubSystem: '<S99>/Modulator 1' */

  /* Output and update for enable system: '<S99>/Modulator 1' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_1_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_1_MODE[1] = (rtb_Fcn2_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_1_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_1_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_1_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_1_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S110>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [480 x 1] */
      memcpy( &rtB.Zero_Pad_b[0], &rtB.Buffer[0], (480 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S110>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[72];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S110>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[73];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S122>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[74];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S110>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[75];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S110>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[76];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S110>/Gain1'
       *
       * Regarding '<S110>/Gain1':
       *   Gain value: rtP.Gain1_a_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_m[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_a_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_a_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn1'
     *
     * Regarding '<S99>/Fcn1':
     *   Expression: u==2
     */
    rtb_Fcn1_a = rtb_Integer_Delay1 == 2.0;
  }

  /* SubSystem: '<S99>/Modulator 2' */

  /* Output and update for enable system: '<S99>/Modulator 2' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_2_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_2_MODE[1] = (rtb_Fcn1_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_2_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_2_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_2_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_2_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S114>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [720 x 1] */
      memcpy( &rtB.Zero_Pad_f[0], &rtB.Buffer[0], (720 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S114>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[92];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S114>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[93];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S126>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[94];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S114>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[95];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S114>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[96];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S114>/Gain1'
       *
       * Regarding '<S114>/Gain1':
       *   Gain value: rtP.Gain1_e_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_q[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_e_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_e_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn3'
     *
     * Regarding '<S99>/Fcn3':
     *   Expression: u==3
     */
    rtb_Fcn3_a = rtb_Integer_Delay1 == 3.0;
  }

  /* SubSystem: '<S99>/Modulator 3' */

  /* Output and update for enable system: '<S99>/Modulator 3' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_3_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_3_MODE[1] = (rtb_Fcn3_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_3_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_3_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_3_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_3_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S115>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [960 x 1] */
      memcpy( &rtB.Zero_Pad_g[0], &rtB.Buffer[0], (960 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S115>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[97];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S115>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[98];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S127>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[99];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S115>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[100];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S115>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[101];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S115>/Gain1'
       *
       * Regarding '<S115>/Gain1':
       *   Gain value: rtP.Gain1_f_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_r[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_f_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_f_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn4'
     *
     * Regarding '<S99>/Fcn4':
     *   Expression: u==4
     */
    rtb_Fcn4_a = rtb_Integer_Delay1 == 4.0;
  }

  /* SubSystem: '<S99>/Modulator 4' */

  /* Output and update for enable system: '<S99>/Modulator 4' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_4_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_4_MODE[1] = (rtb_Fcn4_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_4_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_4_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_4_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_4_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S116>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [1440 x 1] */
      memcpy( &rtB.Zero_Pad_h[0], &rtB.Buffer[0], (1440 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S116>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[102];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S116>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[103];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S128>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[104];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S116>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[105];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S116>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[106];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S116>/Gain1'
       *
       * Regarding '<S116>/Gain1':
       *   Gain value: rtP.Gain1_g_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_s[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_g_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_g_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn5'
     *
     * Regarding '<S99>/Fcn5':
     *   Expression: u==5
     */
    rtb_Fcn5_a = rtb_Integer_Delay1 == 5.0;
  }

  /* SubSystem: '<S99>/Modulator 5' */

  /* Output and update for enable system: '<S99>/Modulator 5' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_5_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_5_MODE[1] = (rtb_Fcn5_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_5_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_5_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_5_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_5_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S117>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [1920 x 1] */
      memcpy( &rtB.Zero_Pad_i[0], &rtB.Buffer[0], (1920 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S117>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[107];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S117>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[108];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S129>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[109];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S117>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[110];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S117>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[111];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S117>/Gain1'
       *
       * Regarding '<S117>/Gain1':
       *   Gain value: rtP.Gain1_h_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_t[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_h_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_h_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn6'
     *
     * Regarding '<S99>/Fcn6':
     *   Expression: u==6
     */
    rtb_Fcn6_a = rtb_Integer_Delay1 == 6.0;
  }

  /* SubSystem: '<S99>/Modulator 6' */

  /* Output and update for enable system: '<S99>/Modulator 6' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_6_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_6_MODE[1] = (rtb_Fcn6_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_6_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_6_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_6_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_6_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S118>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [2880 x 1] */
      memcpy( &rtB.Zero_Pad_j[0], &rtB.Buffer[0], (2880 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S118>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[112];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S118>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[113];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S130>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[114];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S118>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[115];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S118>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[116];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S118>/Gain1'
       *
       * Regarding '<S118>/Gain1':
       *   Gain value: rtP.Gain1_i_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_u[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_i_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_i_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn7'
     *
     * Regarding '<S99>/Fcn7':
     *   Expression: u==7
     */
    rtb_Fcn7_a = rtb_Integer_Delay1 == 7.0;
  }

  /* SubSystem: '<S99>/Modulator 7' */

  /* Output and update for enable system: '<S99>/Modulator 7' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_7_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_7_MODE[1] = (rtb_Fcn7_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_7_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_7_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_7_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_7_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S119>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [3840 x 1] */
      memcpy( &rtB.Zero_Pad_k[0], &rtB.Buffer[0], (3840 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S119>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[117];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S119>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[118];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S131>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[119];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S119>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[120];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S119>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[121];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S119>/Gain1'
       *
       * Regarding '<S119>/Gain1':
       *   Gain value: rtP.Gain1_j_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_v[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_j_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_j_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn8'
     *
     * Regarding '<S99>/Fcn8':
     *   Expression: u==8
     */
    rtb_Fcn8_a = rtb_Integer_Delay1 == 8.0;
  }

  /* SubSystem: '<S99>/Modulator 8' */

  /* Output and update for enable system: '<S99>/Modulator 8' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_8_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_8_MODE[1] = (rtb_Fcn8_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_8_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_8_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_8_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_8_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S120>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [4320 x 1] */
      memcpy( &rtB.Zero_Pad_l[0], &rtB.Buffer[0], (4320 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S120>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[122];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S120>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[123];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S132>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[124];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S120>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[125];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S120>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[126];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S120>/Gain1'
       *
       * Regarding '<S120>/Gain1':
       *   Gain value: rtP.Gain1_k_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_w[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_k_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_k_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn9'
     *
     * Regarding '<S99>/Fcn9':
     *   Expression: u==9
     */
    rtb_Fcn9_a = rtb_Integer_Delay1 == 9.0;
  }

  /* SubSystem: '<S99>/Modulator 9' */

  /* Output and update for enable system: '<S99>/Modulator 9' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_9_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_9_MODE[1] = (rtb_Fcn9_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_9_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_9_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_9_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_9_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S121>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [720 x 1] */
      memcpy( &rtB.Zero_Pad_m[0], &rtB.Buffer[0], (720 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S121>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[127];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S121>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[128];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S133>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[129];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S121>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[130];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S121>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[131];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S121>/Gain1'
       *
       * Regarding '<S121>/Gain1':
       *   Gain value: rtP.Gain1_l_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_x[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_l_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_l_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn10'
     *
     * Regarding '<S99>/Fcn10':
     *   Expression: u==10
     */
    rtb_Fcn10_a = rtb_Integer_Delay1 == 10.0;
  }

  /* SubSystem: '<S99>/Modulator 10' */

  /* Output and update for enable system: '<S99>/Modulator 10' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_10_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_10_MODE[1] = (rtb_Fcn10_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_10_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_10_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_10_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_10_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S111>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [1440 x 1] */
      memcpy( &rtB.Zero_Pad_c[0], &rtB.Buffer[0], (1440 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S111>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[77];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S111>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[78];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S123>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[79];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S111>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[80];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S111>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[81];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S111>/Gain1'
       *
       * Regarding '<S111>/Gain1':
       *   Gain value: rtP.Gain1_b_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_n[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_b_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_b_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn11'
     *
     * Regarding '<S99>/Fcn11':
     *   Expression: u==11
     */
    rtb_Fcn11_a = rtb_Integer_Delay1 == 11.0;
  }

  /* SubSystem: '<S99>/Modulator 11' */

  /* Output and update for enable system: '<S99>/Modulator 11' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_11_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_11_MODE[1] = (rtb_Fcn11_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_11_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_11_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_11_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_11_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S112>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [1440 x 1] */
      memcpy( &rtB.Zero_Pad_d[0], &rtB.Buffer[0], (1440 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S112>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[82];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S112>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[83];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S124>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[84];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S112>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[85];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S112>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[86];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S112>/Gain1'
       *
       * Regarding '<S112>/Gain1':
       *   Gain value: rtP.Gain1_c_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_o[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_c_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_c_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S99>/Fcn12'
     *
     * Regarding '<S99>/Fcn12':
     *   Expression: u==12
     */
    rtb_Fcn12_a = rtb_Integer_Delay1 == 12.0;
  }

  /* SubSystem: '<S99>/Modulator 12' */

  /* Output and update for enable system: '<S99>/Modulator 12' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Modulator_12_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Modulator_12_MODE[1] = (rtb_Fcn12_a > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Modulator_12_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Modulator_12_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */
        /* (system disable function is empty) */
        rtDWork.Modulator_12_MODE[0] = (int_T) SUBSYS_DISABLED;
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Modulator_12_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* DSP Blockset Pad (sdsppad) - '<S113>/Zero Pad' */
      /* Input dimensions: [4320 x 1], output dimensions: [1440 x 1] */
      memcpy( &rtB.Zero_Pad_e[0], &rtB.Buffer[0], (1440 * sizeof(real_T)) );

      /* Level2 S-Function Block: <S113>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[87];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S113>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[88];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S125>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[89];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S113>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[90];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S113>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[91];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S113>/Gain1'
       *
       * Regarding '<S113>/Gain1':
       *   Gain value: rtP.Gain1_d_Gain
       */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_p[0];
        creal_T *y0 = &rtB.Merge1[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re * rtP.Gain1_d_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Gain1_d_Gain;
        }
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* S-Function Block: <S98>/Group data for OFDM symbols  */
    {
      int_T i1;

      const creal_T *u0 = &rtB.Merge1[0];
      creal_T *y0 = &rtb_temp213[0];

      for (i1=0; i1 < 960; i1++) {
        y0[i1].re = u0[i1].re;
        y0[i1].im = u0[i1].im;
      }
    }

    /* DSP Blockset Multi-port Selector (sdspmultiportsel) - '<S96>/Select data blocks' */
    {
      const byte_T *u = (byte_T *)&rtb_temp213[0]; /* input port */
      const int_T *index = (const int_T
        *)&rtP.Select_data_blocks_INDEX_ARRAY_[0];
      const int_T *length = (const int_T
        *)&rtP.Select_data_blocks_LEN_ARRAY_FL[0];
      byte_T *outPortAddr[6];           /* Local array of pointers to the output port locations */
      int_T outIdx;
      outPortAddr[0] = (byte_T *)&rtb_Select_data_blocks_o1[0];
      outPortAddr[1] = (byte_T *)&rtb_Select_data_blocks_o2[0];
      outPortAddr[2] = (byte_T *)&rtb_Select_data_blocks_o3[0];
      outPortAddr[3] = (byte_T *)&rtb_Select_data_blocks_o4[0];
      outPortAddr[4] = (byte_T *)&rtb_Select_data_blocks_o5[0];
      outPortAddr[5] = (byte_T *)&rtb_Select_data_blocks_o6[0];

      /* Loop over each output port and copy bytes */
      for (outIdx = 0; outIdx < 6; outIdx++) {
        const int_T numRowsThisOutput = *length++;
        const int_T bytesPerElement = 2 * sizeof(real_T);
        const int_T bytesPerOutCol = numRowsThisOutput * bytesPerElement;
        byte_T *y = outPortAddr[outIdx];
        int_T ctr;

        /* Loop over each row of current output port index */
        for (ctr = 0; ctr < numRowsThisOutput; ctr++) {
          int_T inputRowIdx = *index++;
          int_T inputRowOffsetBytes;
          int_T outputRowOffsetBytes;
          int_T sampleIdx;

          /* Clip bad index */
          if (inputRowIdx < 0) {
            inputRowIdx = 0;
          } else if (inputRowIdx > 47) {
            inputRowIdx = 47;
          }
          inputRowOffsetBytes = inputRowIdx * bytesPerElement;
          outputRowOffsetBytes = ctr * bytesPerElement;
          /* Copy one sample at a time from each input column */
          for (sampleIdx = 0; sampleIdx < 20; sampleIdx++) {
            memcpy(
             (y + (sampleIdx * bytesPerOutCol) + outputRowOffsetBytes),
             (u + (sampleIdx * (48 * bytesPerElement)) + inputRowOffsetBytes),
             bytesPerElement );
          }
        }                               /* output row loop */
      }                                 /* output port loop */
    }                                   /* end <S96>/Select data blocks */

    /* Level2 S-Function Block: <S101>/PN Sequence Generator (scompnseq2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[132];
      sfcnOutputs(rts, tid);
    }

    /* Gain: '<S134>/Polarity' incorporates:
     *   Sum: '<S134>/Sum'
     *   Gain: '<S134>/Gain'
     *   Constant: '<S134>/Constant'
     *
     * Regarding '<S134>/Polarity':
     *   Gain value: rtP.Polarity_a_Gain
     *
     * Regarding '<S134>/Gain':
     *   Gain value: rtP.Gain_a_Gain
     */
    {
      int_T i1;

      real_T *y0 = &rtb_temp311[0];

      for (i1=0; i1 < 20; i1++) {
        y0[i1] = ((rtB.PN_Sequence_Generator[i1] * rtP.Gain_a_Gain) -
          rtP.Constant_c_Value) * rtP.Polarity_a_Gain;
      }
    }

    /* S-Function Block: <S101>/Reshape */

    /* Constant: '<S105>/Constant' */
    {
      int_T i1;

      creal_T *y0 = &rtB.Constant_d[0];
      const creal_T *p_Constant_d_Value = &rtP.Constant_d_Value[0];

      for (i1=0; i1 < 20; i1++) {
        y0[i1].re = p_Constant_d_Value[i1].re;
        y0[i1].im = p_Constant_d_Value[i1].im;
      }
    }

    /* Gain: '<S96>/Gain'
     *
     * Regarding '<S96>/Gain':
     *   Gain value: rtP.Gain_b_Gain
     */
    {
      int_T i1;

      const real_T *u0 = &rtb_temp311[0];
      real_T *y0 = &rtb_Gain_b[0];

      for (i1=0; i1 < 20; i1++) {
        y0[i1] = u0[i1] * rtP.Gain_b_Gain;
      }
    }

    /* 
     * Matrix Concatenation: <S96>/Assemble Subcarriers
     * Vertical matrix concatenation, 
     * 11 inputs, real and complex, data type: real_T.
     */
    {
      int_T outputByteCount = 0;
      const int_T nCols = 20;
      int_T colNum;
      for ( colNum = 0; colNum < nCols; colNum++ ) {
        /* Input 1: [5x20], complex, 5 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtb_Select_data_blocks_o1[0])) + (colNum * 5 *
          sizeof(creal_T)), 5 * sizeof(creal_T) );
        outputByteCount += 5 * sizeof(creal_T);
        /* Input 2: [1x20], real, 1 * sizeof(real_T) bytes per col
         * Copy real input sample bytes to real part of output,
         * zeroize imaginary part
         */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)&rtb_temp311[0]) + (colNum * 1 * sizeof(real_T)),
         sizeof(real_T) );
        outputByteCount += sizeof(real_T);
        *(real_T *)(((char *)&rtb_Assemble_Subcarriers[0]) + outputByteCount) =
          0.0;
        outputByteCount += sizeof(real_T);
        /* Input 3: [13x20], complex, 13 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtb_Select_data_blocks_o2[0])) + (colNum * 13 *
          sizeof(creal_T)), 13 * sizeof(creal_T) );
        outputByteCount += 13 * sizeof(creal_T);
        /* Input 4: [1x20], real, 1 * sizeof(real_T) bytes per col
         * Copy real input sample bytes to real part of output,
         * zeroize imaginary part
         */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)&rtb_temp311[0]) + (colNum * 1 * sizeof(real_T)),
         sizeof(real_T) );
        outputByteCount += sizeof(real_T);
        *(real_T *)(((char *)&rtb_Assemble_Subcarriers[0]) + outputByteCount) =
          0.0;
        outputByteCount += sizeof(real_T);
        /* Input 5: [6x20], complex, 6 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtb_Select_data_blocks_o3[0])) + (colNum * 6 *
          sizeof(creal_T)), 6 * sizeof(creal_T) );
        outputByteCount += 6 * sizeof(creal_T);
        /* Input 6: [1x20], complex, 1 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtB.Constant_d[0])) + (colNum * 1 * sizeof(creal_T)), 1 *
         sizeof(creal_T) );
        outputByteCount += 1 * sizeof(creal_T);
        /* Input 7: [6x20], complex, 6 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtb_Select_data_blocks_o4[0])) + (colNum * 6 *
          sizeof(creal_T)), 6 * sizeof(creal_T) );
        outputByteCount += 6 * sizeof(creal_T);
        /* Input 8: [1x20], real, 1 * sizeof(real_T) bytes per col
         * Copy real input sample bytes to real part of output,
         * zeroize imaginary part
         */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)&rtb_temp311[0]) + (colNum * 1 * sizeof(real_T)),
         sizeof(real_T) );
        outputByteCount += sizeof(real_T);
        *(real_T *)(((char *)&rtb_Assemble_Subcarriers[0]) + outputByteCount) =
          0.0;
        outputByteCount += sizeof(real_T);
        /* Input 9: [13x20], complex, 13 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtb_Select_data_blocks_o5[0])) + (colNum * 13 *
          sizeof(creal_T)), 13 * sizeof(creal_T) );
        outputByteCount += 13 * sizeof(creal_T);
        /* Input 10: [1x20], real, 1 * sizeof(real_T) bytes per col
         * Copy real input sample bytes to real part of output,
         * zeroize imaginary part
         */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)&rtb_Gain_b[0]) + (colNum * 1 * sizeof(real_T)),
         sizeof(real_T) );
        outputByteCount += sizeof(real_T);
        *(real_T *)(((char *)&rtb_Assemble_Subcarriers[0]) + outputByteCount) =
          0.0;
        outputByteCount += sizeof(real_T);
        /* Input 11: [5x20], complex, 5 * sizeof(creal_T) bytes per col */
        (void) memcpy( ((byte_T *)(&rtb_Assemble_Subcarriers[0])) +
         outputByteCount,
         ((byte_T *)(&rtb_Select_data_blocks_o6[0])) + (colNum * 5 *
          sizeof(creal_T)), 5 * sizeof(creal_T) );
        outputByteCount += 5 * sizeof(creal_T);
      }
    }

    /* 
     * Matrix Concatenation: <S96>/Prepend training seq
     * Horizontal matrix concatenation, 
     * 2 inputs, real and complex, data type: real_T.
     */
    /* Input 1: [53x4], real */
    {
      int_T cnt;
      for ( cnt = 0; cnt < 212; cnt++ ) {
        /* 
         * Copy real input sample bytes to real part of output, 
         * zeroize imaginary part
         */
        (void) memcpy( ((byte_T *)(&rtb_temp214[0])) + (cnt * sizeof(creal_T)),
         ((byte_T *)(&rtP.Training_sequence_b_Value[0])) + (cnt *
          sizeof(real_T)), sizeof(real_T) );
        *(real_T *)(((char *)&rtb_temp214[0]) + (cnt * sizeof(creal_T)) +
         sizeof(real_T)) = 0.0;
      }                                 /* end cnt */
    }
    /* Input 2: [53x[53x20]], complex */
    (void) memcpy( ((byte_T *)(&rtb_temp214[0])) + 212*sizeof(creal_T),
     (byte_T *)&rtb_Assemble_Subcarriers[0], 1060 * sizeof(creal_T) );

    /* DSP Blockset Pad (sdsppad) - '<S7>/Zero Pad' */
    /* Input dimensions: [53 x 24], output dimensions: [64 x 24] */
    MWDSP_PadAlongCols( (const byte_T *)&rtb_temp214[0], (byte_T
      *)&rtb_Zero_Pad_a[0], (byte_T *)(&rtP.Zero_Pad_a_PadValue), 24, 106 *
     sizeof(real_T), 11, 2 * sizeof(real_T) );

    /* Selector: '<S102>/Shift for FFT' */
    {
      static const int_T rowIndices[64] = {26, 27, 28, 29, 30, 31, 32, 33, 34,
        35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
        53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3, 4, 5, 6, 7, 8,
        9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25};

      {
        int_T i1;

        const creal_T *u0 = &rtb_Zero_Pad_a[0];
        creal_T *y0 = &rtb_temp220[0];

        for (i1=0; i1 < 24; i1++) {
          {
            int_T i2;

            for (i2=0; i2 < 64; i2++) {
              y0[i2 + 64*i1] = u0[(64*i1)+rowIndices[i2]];
            }
          }
        }
      }
    }

    /* DSP Blockset FFT (sdspfft2) - '<S102>/IFFT' */
    /* Complex input, complex output,24 channels, 64 rows, linear output order */
    MWDSP_R2BR_Z(&rtb_temp220[0], 24, 64, 64); /* In-place bit-reverse reordering */
    /* Radix-2 DIT IFFT using TableSpeed twiddle computation */
    MWDSP_R2DIT_TBLS_Z(&rtb_temp220[0], 24, 64, 64, &rtP.IFFT_TwiddleTable[0],
     1, 1);
    MWDSP_ScaleData_DZ(&rtb_temp220[0], 1536, 1.0/64);

    /* Gain: '<S102>/Normalize'
     *
     * Regarding '<S102>/Normalize':
     *   Gain value: rtP.Normalize_a_Gain
     */
    {
      int_T i1;

      const creal_T *u0 = &rtb_temp220[0];
      creal_T *y0 = &rtb_temp220[0];

      for (i1=0; i1 < 1536; i1++) {
        {
          real_T tmpReal = u0[i1].re * rtP.Normalize_a_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Normalize_a_Gain;
          y0[i1].re = tmpReal;
        }
      }
    }

    /* Selector: '<S103>/Add Cyclic Prefix' */
    {
      static const int_T rowIndices[80] = {48, 49, 50, 51, 52, 53, 54, 55, 56,
        57, 58, 59, 60, 61, 62, 63, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,
        13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
        49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63};

      {
        int_T i1;

        const creal_T *u0 = &rtb_temp220[0];
        creal_T *y0 = &rtb_temp215[0];

        for (i1=0; i1 < 24; i1++) {
          {
            int_T i2;

            for (i2=0; i2 < 80; i2++) {
              y0[i2 + 80*i1] = u0[(64*i1)+rowIndices[i2]];
            }
          }
        }
      }
    }

    /* S-Function Block: <S100>/Reshape2 */
    {
      int_T i1;

      const creal_T *u0 = &rtb_temp215[0];
      creal_T *y0 = &rtb_Reshape2[0];

      for (i1=0; i1 < 1920; i1++) {
        y0[i1].re = u0[i1].re;
        y0[i1].im = u0[i1].im;
      }
    }

    /* DSP Blockset Permute Matrix (sdspperm2) - '<S20>/Permute Matrix' */
    {
      int_T i;
      for (i = 0; i < 1; i++) {
        /* Copy entire input column to each output column */
        memcpy(&rtb_temp216[i*1920], &rtb_Reshape2[0], 3840*sizeof(real_T));
      }
    }

    /* DSP Blockset Interp (sdspvfdly2) - '<S20>/Variable Fractional Delay' */
    {
      const real_T *filtptr = &rtP.Variable_Fraction_a_FilterArgs[0];
      const creal_T *uptr = &rtb_temp216[0];
      creal_T *yptr = &rtB.Variable_Fraction_a[0];
      int_T *buffoff = &rtDWork.Variable_Fraction_a_BUFF_OFFSET;
      creal_T *buff = &rtDWork.Variable_Fraction_a_BUFF[0];
      int_T buffstart = *buffoff;
      int_T samps = 1920;
      real_T t = rtP.Constant2_a_Value;
      int_T ti;
      real_T frac;
      t = CLIP(t,0.0, (real_T)1);
      ti = (int_T)t;
      frac = t - ti;
      while (samps--) {
        if (++buffstart == 8) buffstart = 0;
        *(buff + buffstart) = *uptr++;

        /* Check if we need to use linear interp: */
        if (ti < 6 - 1) {
          MWDSP_Vfdly_Lin_Z(buff ,8 ,&yptr ,ti ,buffstart ,frac);
        } else {
          /* FIR interpolation mode */
          MWDSP_Vfdly_FIR_Z(filtptr, 12, 10 ,buff, 8 ,&yptr ,ti,buffstart ,frac);
        }
      }
      buff += 8;
      *buffoff += 1920;
      while (*buffoff >= 8) *buffoff -= 8;
    }

    /* Level2 S-Function Block: <S22>/S-Function (scomtrigbuff2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[133];
      sfcnOutputs(rts, tid);
    }

    /* Level2 S-Function Block: <S23>/S-Function (scomricianlos2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[134];
      sfcnOutputs(rts, tid);
    }

    /* Level2 S-Function Block: <S21>/S-Function (scommultwithprop2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[135];
      sfcnOutputs(rts, tid);
    }

    /* DSP Blockset Matrix Sum (sdspmsumprod) - '<S18>/Combine Paths' */
    /* Output == Input */
    memcpy(&rtb_temp216[0], &rtB.S_Function_c[0], sizeof(creal_T) * 1920 );

    /* DSP Blockset Permute Matrix (sdspperm2) - '<S29>/Permute Matrix' */
    {
      int_T i;
      for (i = 0; i < 2; i++) {
        /* Copy entire input column to each output column */
        memcpy(&rtb_Permute_Matrix_b[i*1920], &rtb_Reshape2[0],
         3840*sizeof(real_T));
      }
    }

    /* DSP Blockset Interp (sdspvfdly2) - '<S29>/Variable Fractional Delay' */
    {
      const real_T *filtptr = &rtP.Variable_Fraction_b_FilterArgs[0];
      const creal_T *uptr = &rtb_Permute_Matrix_b[0];
      creal_T *yptr = &rtB.Variable_Fraction_b[0];
      int_T *buffoff = &rtDWork.Variable_Fraction_b_BUFF_OFFSET;
      creal_T *buff = &rtDWork.Variable_Fraction_b_BUFF[0];
      int_T chans = 2;
      int_T samps;
      int_T i = 0;
      while(chans--) {
        int_T buffstart = *buffoff;
        real_T t = rtP.Constant2_b_Value[i++];
        int_T ti;
        real_T frac;
        t = CLIP(t,0.0, (real_T)2);
        ti = (int_T)t;
        samps = 1920;
        while (samps--) {
          frac = t - ti;
          if (++buffstart == 9) buffstart = 0;
          *(buff + buffstart) = *uptr++;

          /* Check if we need to use linear interp: */
          if (ti < 6 - 1) {
            MWDSP_Vfdly_Lin_Z(buff ,9 ,&yptr ,ti ,buffstart ,frac);
          } else {
            /* FIR interpolation mode */
            MWDSP_Vfdly_FIR_Z(filtptr, 12, 10 ,buff, 9 ,&yptr ,ti,buffstart
             ,frac);
          }
        }
        buff += 9;
      }
      *buffoff += 1920;
      while (*buffoff >= 9) *buffoff -= 9;
    }

    /* Level2 S-Function Block: <S31>/S-Function (scomtrigbuff2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[136];
      sfcnOutputs(rts, tid);
    }

    /* Level2 S-Function Block: <S32>/S-Function (scomricianlos2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[137];
      sfcnOutputs(rts, tid);
    }

    /* Level2 S-Function Block: <S30>/S-Function (scommultwithprop2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[138];
      sfcnOutputs(rts, tid);
    }

    /* DSP Blockset Matrix Sum (sdspmsumprod) - '<S27>/Combine Paths' */
    /* Matrix row sum. */
    {
      const creal_T *u = &rtB.S_Function_f[0];
      creal_T *y = &rtb_Combine_Paths_b[0];
      int_T j;
      for (j=0; j++<1920; ) {
        creal_T s = *u;
        int_T i;
        for (i=1; i<2; i++) {
          s.re += u[1920*i].re;
          s.im += u[1920*i].im;
        }
        *y++ = s;
        u++;
      }
    }

    /* MultiPortSwitch: '<S11>/Multiport Switch' incorporates:
     *   Constant: '<S11>/fadingMode'
     */
    switch ((int_T)rtP.fadingMode_Value) {
     case 1:

      (void) memcpy (&rtB.Multiport_Switch_a[0], &rtb_Reshape2[0], 1920 * sizeof
       (creal_T));
      break;
     case 2:

      (void) memcpy (&rtB.Multiport_Switch_a[0], &rtb_temp216[0], 1920 * sizeof
       (creal_T));
      break;
     case 3:

      (void) memcpy (&rtB.Multiport_Switch_a[0], &rtb_Combine_Paths_b[0], 1920 *
       sizeof (creal_T));
      break;
     default:
      /* Result undefined */
#if defined(MATLAB_MEX_FILE)
      (void)mexPrintf("Error: Invalid control input for block:"
       "IEEE80211g/Channel/Multipath channel/Multiport Switch\n"
       "Result is undefined.");
#endif
      break;
    }

    /* DSP Blockset Random Source (sdsprandsrc2) - '<S12>/Random Source' */
    MWDSP_RandSrc_GZ_Z((creal64_T*)&rtB.Random_Source_a[0],(creal64_T*)&rtP.Random_Source_a_Mean,1,&rtP.Random_Source_a_Variance,1,&rtDWork.Random_Source_a_STATE_DWORK[0],1,1920);

    /* Math: '<S17>/Math Function' incorporates:
     *   Gain: '<S17>/Gain'
     *   Constant: '<S11>/SNRdB'
     *
     * Regarding '<S17>/Math Function':
     *   Op: 10^u
     *
     * Regarding '<S17>/Gain':
     *   Gain value: rtP.Gain_c_Gain
     */

    rtB.Math_Function_a = pow(10.0, (rtP.SNRdB_Value * rtP.Gain_c_Gain));

    /* Level2 S-Function Block: <S12>/Dynamic AWGN (scomawgnchan2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[139];
      sfcnOutputs(rts, tid);
    }

    /* S-Function Block: <S48>/Demultiplex */
    {
      int_T i1;

      const creal_T *u0 = &rtB.Dynamic_AWGN[0];
      creal_T *y0 = &rtb_temp215[0];

      for (i1=0; i1 < 1920; i1++) {
        y0[i1].re = u0[i1].re;
        y0[i1].im = u0[i1].im;
      }
    }

    /* Selector: '<S52>/Remove cyclic prefix' */
    {
      static const int_T rowIndices[64] = {16, 17, 18, 19, 20, 21, 22, 23, 24,
        25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
        43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
        61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78,
        79};

      {
        int_T i1;

        const creal_T *u0 = &rtb_temp215[0];
        creal_T *y0 = &rtb_temp220[0];

        for (i1=0; i1 < 24; i1++) {
          {
            int_T i2;

            for (i2=0; i2 < 64; i2++) {
              y0[i2 + 64*i1] = u0[(80*i1)+rowIndices[i2]];
            }
          }
        }
      }
    }

    /* DSP Blockset FFT (sdspfft2) - '<S51>/FFT' */
    /* Complex input, 24 channels, 64 rows, linear output order */
    MWDSP_R2BR_Z(&rtb_temp220[0], 24, 64, 64); /* In-place bit-reverse reordering */
    /* Radix-2 DIT FFT using TableSpeed twiddle computation */
    MWDSP_R2DIT_TBLS_Z(&rtb_temp220[0], 24, 64, 64, &rtP.FFT_TwiddleTable[0], 1,
     0);

    /* Gain: '<S51>/Normalize'
     *
     * Regarding '<S51>/Normalize':
     *   Gain value: rtP.Normalize_b_Gain
     */
    {
      int_T i1;

      const creal_T *u0 = &rtb_temp220[0];
      creal_T *y0 = &rtb_temp220[0];

      for (i1=0; i1 < 1536; i1++) {
        {
          real_T tmpReal = u0[i1].re * rtP.Normalize_b_Gain - u0[i1].im * 0.0;
          y0[i1].im = u0[i1].re * 0.0 + u0[i1].im * rtP.Normalize_b_Gain;
          y0[i1].re = tmpReal;
        }
      }
    }

    /* Selector: '<S50>/Select symbols' */
    {
      static const int_T rowIndices[53] = {38, 39, 40, 41, 42, 43, 44, 45, 46,
        47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 0,
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        21, 22, 23, 24, 25, 26};

      {
        int_T i1;

        const creal_T *u0 = &rtb_temp220[0];
        creal_T *y0 = &rtb_temp214[0];

        for (i1=0; i1 < 24; i1++) {
          {
            int_T i2;

            for (i2=0; i2 < 53; i2++) {
              y0[i2 + 53*i1] = u0[(64*i1)+rowIndices[i2]];
            }
          }
        }
      }
    }

    /* Selector: '<S49>/Remove DC component' */
    {
      static const int_T rowIndices[52] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
        12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
        49, 50, 51, 52};

      {
        int_T i1;

        const creal_T *u0 = &rtb_temp214[0];
        creal_T *y0 = &rtb_Remove_DC_component[0];

        for (i1=0; i1 < 24; i1++) {
          {
            int_T i2;

            for (i2=0; i2 < 52; i2++) {
              y0[i2 + 52*i1] = u0[(53*i1)+rowIndices[i2]];
            }
          }
        }
      }
    }

    /* DSP Blockset Multi-port Selector (sdspmultiportsel) - '<S49>/Select training//data' */
    {
      const byte_T *u = (byte_T *)&rtb_Remove_DC_component[0]; /* input port */
      const int_T *index = (const int_T
        *)&rtP.Select_training_data_INDEX_ARRA[0];
      const int_T *length = (const int_T
        *)&rtP.Select_training_data_LEN_ARRAY_[0];
      byte_T *outPortAddr[2];           /* Local array of pointers to the output port locations */
      int_T outIdx;
      outPortAddr[0] = (byte_T *)&rtb_temp217[0];
      outPortAddr[1] = (byte_T *)&rtb_Select_training_data_o2[0];

      /* Loop over each output port and copy bytes */
      for (outIdx = 0; outIdx < 2; outIdx++) {
        const int_T numColsThisOutput = *length++;
        byte_T *y = outPortAddr[outIdx];
        const int_T bytesPerElement = 2 * sizeof(real_T);
        int_T ctr;

        /* Loop over each column of current output port index */
        for (ctr = 0; ctr < numColsThisOutput; ctr++) {
          int_T inputColIdx = *index++;

          /* Clip bad index */
          if (inputColIdx < 0) {
            inputColIdx = 0;
          } else if (inputColIdx > 23) {
            inputColIdx = 23;
          }

          /* Copy an entire column worth of bytes
           * offset input ptr to start of column index "inputColIdx"
           */
          memcpy( y, (u + inputColIdx * (52 * bytesPerElement)), (52 *
            bytesPerElement) );
          y += (52 * bytesPerElement); /* next output column */
        }                               /* output column loop */
      }                                 /* output port loop */
    }                                   /* end <S49>/Select training//data */

    /* Product: '<S49>/Product1' */
    {
      creal_T output;
      {
        int_T i1;

        const real_T *u0 = &rtb_Remove_training_DC_componen[0];
        const creal_T *u1 = &rtb_temp217[0];
        creal_T *y0 = &rtb_temp217[0];

        for (i1=0; i1 < 208; i1++) {
          output.re = 1.0/(u0[i1]);
          output.im = 0.0;
          {
            real_T tmpReal = output.re * u1[i1].re - output.im * u1[i1].im;
            output.im = output.re * u1[i1].im + output.im * u1[i1].re;
            output.re = tmpReal;
          }
          y0[i1] = output;
        }
      }
    }

    /* DSP Blockset Matrix Transpose (sdspmtrnsp2) - '<S92>/Transpose' */

    {
      /*
       * Transpose matrix:  Walk the inputs in order down 
       * the columns and write the outputs across the rows 
       */

      real_T *u = (real_T *)&rtb_temp217[0];
      real_T *y = (real_T *)&rtb_Transpose_a[0];
      int_T j = 4;
      while(j-- > 0) {
        real_T *yy = y;
        int_T i = 52;
        while(i-- > 0) {
          *yy = *u++;                   /* Copy real part */
          *(yy+1) = *u++;               /* Copy imag to imag */
          yy += 2*4;
        }
        y += 2;
      }
    }

    /* DSP Blockset Mean (sdspstatfcns) - '<S92>/Mean' */
    {
      const creal_T *u = &rtb_Transpose_a[0];
      creal_T *y = &rtb_temp218[0];
      int_T j = 52;
      while (j-- > 0) {
        creal_T sumVal = {0.0,0.0};
        int_T i = 4;
        while (i-- > 0) {
          sumVal.re += (*u).re;
          sumVal.im += (*u).im;
          u++;
        }
        (*y).re = sumVal.re / 4;
        (*y++).im = sumVal.im / 4;
      }
    }

    /* Math: '<S92>/Math Function1'
     *
     * Regarding '<S92>/Math Function1':
     *   Op: conj
     */

    {
      int_T i1;

      const creal_T *u0 = &rtb_temp218[0];
      creal_T *y0 = &rtb_temp218[0];

      for (i1=0; i1 < 52; i1++) {
        y0[i1].re = u0[i1].re;
        y0[i1].im = - u0[i1].im;
      }
    }

    /* Math: '<S92>/Math Function'
     *
     * Regarding '<S92>/Math Function':
     *   Op: magnitude^2
     */

    {
      int_T i1;

      const creal_T *u0 = &rtb_Transpose_a[0];
      real_T *y0 = &rtb_Math_Function_b[0];

      for (i1=0; i1 < 208; i1++) {
        y0[i1] = u0[i1].re * u0[i1].re + u0[i1].im * u0[i1].im;
      }
    }

    /* DSP Blockset Mean (sdspstatfcns) - '<S92>/Mean1' */
    {
      const real_T *u = &rtb_Math_Function_b[0];
      real_T *y = &rtb_Mean1[0];
      int_T j = 52;
      while (j-- > 0) {
        real_T sumVal = 0.0;
        int_T i = 4;
        while (i-- > 0) {
          sumVal += (*u);
          u++;
        }
        *y++ = sumVal / 4;
      }
    }

    /* Product: '<S92>/Product3' */
    {
      creal_T output;
      {
        int_T i1;

        const creal_T *u0 = &rtb_temp218[0];
        const real_T *u1 = &rtb_Mean1[0];
        creal_T *y0 = &rtB.Product3[0];

        for (i1=0; i1 < 52; i1++) {
          output = u0[i1];
          output.re = output.re / u1[i1];
          output.im = output.im / u1[i1];
          y0[i1] = output;
        }
      }
    }

    /* DSP Blockset Repeat (sdsprepeat2) - '<S92>/Repeat' */
    /* Not multi-rate and Multitasking mode */
    {
      byte_T *y = (byte_T *)(&rtb_Repeat[0]);
      byte_T *uptr = (byte_T *)(&rtB.Product3[0]);
      int_T Input_repeat_cnt;
      int_T Iteration_cnt;
      int_T n;
      for (n=0; n<52; n++) {
        /* Point to next channel: */
        if (n!=0) uptr+=(2 * sizeof(real_T));
        /* Reset the counters */
        Input_repeat_cnt = rtDWork.Repeat_REPEAT_CNT;
        Iteration_cnt = rtDWork.Repeat_ITERATION_CNT;
        {
          int_T k;
          for (k=0; k < 20; k++) {
            memcpy(y,uptr + Iteration_cnt*(2 * sizeof(real_T)),(2 *
              sizeof(real_T)));
            y+=(2 * sizeof(real_T));
            if (++Input_repeat_cnt == 20) {
              Input_repeat_cnt = 0;
            }
          }
        }
      }
      /* Update counters */
      rtDWork.Repeat_ITERATION_CNT = Iteration_cnt;
      rtDWork.Repeat_REPEAT_CNT = Input_repeat_cnt;
    }

    /* DSP Blockset Matrix Transpose (sdspmtrnsp2) - '<S92>/Transpose1' */

    {
      /*
       * Transpose matrix:  Walk the inputs in order down 
       * the columns and write the outputs across the rows 
       */

      real_T *u = (real_T *)&rtb_Repeat[0];
      real_T *y = (real_T *)&rtb_temp219[0];
      int_T j = 52;
      while(j-- > 0) {
        real_T *yy = y;
        int_T i = 20;
        while(i-- > 0) {
          *yy = *u++;                   /* Copy real part */
          *(yy+1) = *u++;               /* Copy imag to imag */
          yy += 2*52;
        }
        y += 2;
      }
    }

    /* Product: '<S49>/Product2' */
    {
      creal_T output;
      {
        int_T i1;

        const creal_T *u0 = &rtb_temp219[0];
        const creal_T *u1 = &rtb_Select_training_data_o2[0];
        creal_T *y0 = &rtb_temp219[0];

        for (i1=0; i1 < 1040; i1++) {
          output = u0[i1];
          {
            real_T tmpReal = output.re * u1[i1].re - output.im * u1[i1].im;
            output.im = output.re * u1[i1].im + output.im * u1[i1].re;
            output.re = tmpReal;
          }
          y0[i1] = output;
        }
      }
    }

    /* DSP Blockset Multi-port Selector (sdspmultiportsel) - '<S53>/Remove pilots' */
    {
      const byte_T *u = (byte_T *)&rtb_temp219[0]; /* input port */
      const int_T *index = (const int_T *)&rtP.Remove_pilots_INDEX_ARRAY_FLAT[0];
      const int_T *length = (const int_T *)&rtP.Remove_pilots_LEN_ARRAY_FLAT[0];
      byte_T *outPortAddr[2];           /* Local array of pointers to the output port locations */
      int_T outIdx;
      outPortAddr[0] = (byte_T *)&rtb_temp213[0];
      outPortAddr[1] = (byte_T *)&rtb_Pilots[0];

      /* Loop over each output port and copy bytes */
      for (outIdx = 0; outIdx < 2; outIdx++) {
        const int_T numRowsThisOutput = *length++;
        const int_T bytesPerElement = 2 * sizeof(real_T);
        const int_T bytesPerOutCol = numRowsThisOutput * bytesPerElement;
        byte_T *y = outPortAddr[outIdx];
        int_T ctr;

        /* Loop over each row of current output port index */
        for (ctr = 0; ctr < numRowsThisOutput; ctr++) {
          int_T inputRowIdx = *index++;
          int_T inputRowOffsetBytes;
          int_T outputRowOffsetBytes;
          int_T sampleIdx;

          /* Clip bad index */
          if (inputRowIdx < 0) {
            inputRowIdx = 0;
          } else if (inputRowIdx > 51) {
            inputRowIdx = 51;
          }
          inputRowOffsetBytes = inputRowIdx * bytesPerElement;
          outputRowOffsetBytes = ctr * bytesPerElement;
          /* Copy one sample at a time from each input column */
          for (sampleIdx = 0; sampleIdx < 20; sampleIdx++) {
            memcpy(
             (y + (sampleIdx * bytesPerOutCol) + outputRowOffsetBytes),
             (u + (sampleIdx * (52 * bytesPerElement)) + inputRowOffsetBytes),
             bytesPerElement );
          }
        }                               /* output row loop */
      }                                 /* output port loop */
    }                                   /* end <S53>/Remove pilots */

    /* S-Function Block: <S53>/Reshape3 */
    {
      int_T i1;

      const creal_T *u0 = &rtb_temp213[0];
      creal_T *y0 = &rtB.Reshape3[0];

      for (i1=0; i1 < 960; i1++) {
        y0[i1].re = u0[i1].re;
        y0[i1].im = u0[i1].im;
      }
    }

    /* Fcn: '<S47>/Fcn4'
     *
     * Regarding '<S47>/Fcn4':
     *   Expression: u==1
     */
    rtb_Fcn4_b = rtb_Integer_Delay1 == 1.0;
  }

  /* SubSystem: '<S47>/Demodulator 1' */

  /* Output and update for enable system: '<S47>/Demodulator 1' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_a_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_a_MODE[1] = (rtb_Fcn4_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_a_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_a_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 1' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 1 */
        if (rtDWork.Demodulato_a_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S55>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_a[0];

            for (i1=0; i1 < 480; i1++) {
              u0[i1] = rtP.rxdata_a_Y0;
            }
          }

          /* (Virtual) Outport Block: <S55>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_h[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_a_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_a_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_a_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S55>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[0];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S69>/Polarity' incorporates:
       *   Sum: '<S69>/Sum'
       *   Gain: '<S69>/Gain'
       *   Constant: '<S69>/Constant'
       *
       * Regarding '<S69>/Polarity':
       *   Gain value: rtP.Polarity_b_Gain
       *
       * Regarding '<S69>/Gain':
       *   Gain value: rtP.Gain_f_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp184[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_a[i1] * rtP.Gain_f_Gain) -
            rtP.Constant_l_Value) * rtP.Polarity_b_Gain;
        }
      }

      /* Level2 S-Function Block: <S55>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[1];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S68>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[2];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S55>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[3];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S55>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[4];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S55>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_a[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_h[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S55>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[5];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn1'
     *
     * Regarding '<S47>/Fcn1':
     *   Expression: u==2
     */
    rtb_Fcn1_b = rtb_Integer_Delay1 == 2.0;
  }

  /* SubSystem: '<S47>/Demodulator 2' */

  /* Output and update for enable system: '<S47>/Demodulator 2' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_b_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_b_MODE[1] = (rtb_Fcn1_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_b_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_b_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 2' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 2 */
        if (rtDWork.Demodulato_b_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S59>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_e[0];

            for (i1=0; i1 < 720; i1++) {
              u0[i1] = rtP.rxdata_e_Y0;
            }
          }

          /* (Virtual) Outport Block: <S59>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_p[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_e_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_b_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_b_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S59>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[24];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S77>/Polarity' incorporates:
       *   Sum: '<S77>/Sum'
       *   Gain: '<S77>/Gain'
       *   Constant: '<S77>/Constant'
       *
       * Regarding '<S77>/Polarity':
       *   Gain value: rtP.Polarity_f_Gain
       *
       * Regarding '<S77>/Gain':
       *   Gain value: rtP.Gain_j_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp180[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_e[i1] * rtP.Gain_j_Gain) -
            rtP.Constant_p_Value) * rtP.Polarity_f_Gain;
        }
      }

      /* Level2 S-Function Block: <S59>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[25];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S76>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[26];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S59>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[27];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S59>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[28];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S59>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_e[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_p[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S59>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[29];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn2'
     *
     * Regarding '<S47>/Fcn2':
     *   Expression: u==3
     */
    rtb_Fcn2_b = rtb_Integer_Delay1 == 3.0;
  }

  /* SubSystem: '<S47>/Demodulator 3' */

  /* Output and update for enable system: '<S47>/Demodulator 3' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_c_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_c_MODE[1] = (rtb_Fcn2_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_c_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_c_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 3' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 3 */
        if (rtDWork.Demodulato_c_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S60>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_f[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1] = rtP.rxdata_f_Y0;
            }
          }

          /* (Virtual) Outport Block: <S60>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_r[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_f_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_c_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_c_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S60>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[30];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S79>/Polarity' incorporates:
       *   Sum: '<S79>/Sum'
       *   Gain: '<S79>/Gain'
       *   Constant: '<S79>/Constant'
       *
       * Regarding '<S79>/Polarity':
       *   Gain value: rtP.Polarity_g_Gain
       *
       * Regarding '<S79>/Gain':
       *   Gain value: rtP.Gain_k_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp178[0];

        for (i1=0; i1 < 1920; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_f[i1] * rtP.Gain_k_Gain) -
            rtP.Constant_q_Value) * rtP.Polarity_g_Gain;
        }
      }

      /* Level2 S-Function Block: <S60>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[31];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S78>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[32];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S60>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[33];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S60>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[34];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S60>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_f[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_r[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S60>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[35];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn3'
     *
     * Regarding '<S47>/Fcn3':
     *   Expression: u==4
     */
    rtb_Fcn3_b = rtb_Integer_Delay1 == 4.0;
  }

  /* SubSystem: '<S47>/Demodulator 4' */

  /* Output and update for enable system: '<S47>/Demodulator 4' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_d_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_d_MODE[1] = (rtb_Fcn3_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_d_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_d_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 4' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 4 */
        if (rtDWork.Demodulato_d_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S61>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_g[0];

            for (i1=0; i1 < 1440; i1++) {
              u0[i1] = rtP.rxdata_g_Y0;
            }
          }

          /* (Virtual) Outport Block: <S61>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_t[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_g_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_d_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_d_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S61>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[36];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S81>/Polarity' incorporates:
       *   Sum: '<S81>/Sum'
       *   Gain: '<S81>/Gain'
       *   Constant: '<S81>/Constant'
       *
       * Regarding '<S81>/Polarity':
       *   Gain value: rtP.Polarity_h_Gain
       *
       * Regarding '<S81>/Gain':
       *   Gain value: rtP.Gain_l_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp177[0];

        for (i1=0; i1 < 1920; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_g[i1] * rtP.Gain_l_Gain) -
            rtP.Constant_r_Value) * rtP.Polarity_h_Gain;
        }
      }

      /* Level2 S-Function Block: <S61>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[37];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S80>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[38];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S61>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[39];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S61>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[40];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S61>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_g[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_t[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S61>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[41];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn5'
     *
     * Regarding '<S47>/Fcn5':
     *   Expression: u==5
     */
    rtb_Fcn5_b = rtb_Integer_Delay1 == 5.0;
  }

  /* SubSystem: '<S47>/Demodulator 5' */

  /* Output and update for enable system: '<S47>/Demodulator 5' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_e_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_e_MODE[1] = (rtb_Fcn5_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_e_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_e_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 5' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 5 */
        if (rtDWork.Demodulato_e_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S62>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_h[0];

            for (i1=0; i1 < 1920; i1++) {
              u0[i1] = rtP.rxdata_h_Y0;
            }
          }

          /* (Virtual) Outport Block: <S62>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_v[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_h_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_e_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_e_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S62>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[42];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S83>/Polarity' incorporates:
       *   Sum: '<S83>/Sum'
       *   Gain: '<S83>/Gain'
       *   Constant: '<S83>/Constant'
       *
       * Regarding '<S83>/Polarity':
       *   Gain value: rtP.Polarity_i_Gain
       *
       * Regarding '<S83>/Gain':
       *   Gain value: rtP.Gain_m_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp175[0];

        for (i1=0; i1 < 3840; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_h[i1] * rtP.Gain_m_Gain) -
            rtP.Constant_s_Value) * rtP.Polarity_i_Gain;
        }
      }

      /* Level2 S-Function Block: <S62>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[43];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S82>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[44];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S62>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[45];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S62>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[46];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S62>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_h[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_v[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S62>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[47];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn6'
     *
     * Regarding '<S47>/Fcn6':
     *   Expression: u==6
     */
    rtb_Fcn6_b = rtb_Integer_Delay1 == 6.0;
  }

  /* SubSystem: '<S47>/Demodulator 6' */

  /* Output and update for enable system: '<S47>/Demodulator 6' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_f_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_f_MODE[1] = (rtb_Fcn6_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_f_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_f_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 6' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 6 */
        if (rtDWork.Demodulato_f_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S63>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_i[0];

            for (i1=0; i1 < 2880; i1++) {
              u0[i1] = rtP.rxdata_i_Y0;
            }
          }

          /* (Virtual) Outport Block: <S63>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_x[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_i_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_f_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_f_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S63>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[48];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S85>/Polarity' incorporates:
       *   Sum: '<S85>/Sum'
       *   Gain: '<S85>/Gain'
       *   Constant: '<S85>/Constant'
       *
       * Regarding '<S85>/Polarity':
       *   Gain value: rtP.Polarity_j_Gain
       *
       * Regarding '<S85>/Gain':
       *   Gain value: rtP.Gain_n_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp174[0];

        for (i1=0; i1 < 3840; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_i[i1] * rtP.Gain_n_Gain) -
            rtP.Constant_t_Value) * rtP.Polarity_j_Gain;
        }
      }

      /* Level2 S-Function Block: <S63>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[49];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S84>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[50];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S63>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[51];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S63>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[52];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S63>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_i[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_x[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S63>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[53];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn7'
     *
     * Regarding '<S47>/Fcn7':
     *   Expression: u==7
     */
    rtb_Fcn7_b = rtb_Integer_Delay1 == 7.0;
  }

  /* SubSystem: '<S47>/Demodulator 7' */

  /* Output and update for enable system: '<S47>/Demodulator 7' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_g_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_g_MODE[1] = (rtb_Fcn7_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_g_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_g_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 7' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 7 */
        if (rtDWork.Demodulato_g_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S64>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_j[0];

            for (i1=0; i1 < 3840; i1++) {
              u0[i1] = rtP.rxdata_j_Y0;
            }
          }

          /* (Virtual) Outport Block: <S64>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_z[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_j_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_g_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_g_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S64>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[54];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S87>/Polarity' incorporates:
       *   Sum: '<S87>/Sum'
       *   Gain: '<S87>/Gain'
       *   Constant: '<S87>/Constant'
       *
       * Regarding '<S87>/Polarity':
       *   Gain value: rtP.Polarity_k_Gain
       *
       * Regarding '<S87>/Gain':
       *   Gain value: rtP.Gain_o_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp173[0];

        for (i1=0; i1 < 5760; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_j[i1] * rtP.Gain_o_Gain) -
            rtP.Constant_u_Value) * rtP.Polarity_k_Gain;
        }
      }

      /* Level2 S-Function Block: <S64>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[55];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S86>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[56];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S64>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[57];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S64>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[58];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S64>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_j[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_z[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S64>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[59];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn8'
     *
     * Regarding '<S47>/Fcn8':
     *   Expression: u==8
     */
    rtb_Fcn8_b = rtb_Integer_Delay1 == 8.0;
  }

  /* SubSystem: '<S47>/Demodulator 8' */

  /* Output and update for enable system: '<S47>/Demodulator 8' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_h_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_h_MODE[1] = (rtb_Fcn8_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_h_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_h_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 8' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 8 */
        if (rtDWork.Demodulato_h_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S65>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_k[0];

            for (i1=0; i1 < 4320; i1++) {
              u0[i1] = rtP.rxdata_k_Y0;
            }
          }

          /* (Virtual) Outport Block: <S65>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_ab[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_k_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_h_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_h_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S65>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[60];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S89>/Polarity' incorporates:
       *   Sum: '<S89>/Sum'
       *   Gain: '<S89>/Gain'
       *   Constant: '<S89>/Constant'
       *
       * Regarding '<S89>/Polarity':
       *   Gain value: rtP.Polarity_l_Gain
       *
       * Regarding '<S89>/Gain':
       *   Gain value: rtP.Gain_p_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp172[0];

        for (i1=0; i1 < 5760; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_k[i1] * rtP.Gain_p_Gain) -
            rtP.Constant_v_Value) * rtP.Polarity_l_Gain;
        }
      }

      /* Level2 S-Function Block: <S65>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[61];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S88>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[62];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S65>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[63];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S65>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[64];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S65>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_k[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_ab[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S65>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[65];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn9'
     *
     * Regarding '<S47>/Fcn9':
     *   Expression: u==9
     */
    rtb_Fcn9_b = rtb_Integer_Delay1 == 9.0;
  }

  /* SubSystem: '<S47>/Demodulator 9' */

  /* Output and update for enable system: '<S47>/Demodulator 9' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_i_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_i_MODE[1] = (rtb_Fcn9_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_i_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_i_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 9' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 9 */
        if (rtDWork.Demodulato_i_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S66>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_l[0];

            for (i1=0; i1 < 720; i1++) {
              u0[i1] = rtP.rxdata_l_Y0;
            }
          }

          /* (Virtual) Outport Block: <S66>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_ad[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_l_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_i_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_i_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S66>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[66];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S91>/Polarity' incorporates:
       *   Sum: '<S91>/Sum'
       *   Gain: '<S91>/Gain'
       *   Constant: '<S91>/Constant'
       *
       * Regarding '<S91>/Polarity':
       *   Gain value: rtP.Polarity_m_Gain
       *
       * Regarding '<S91>/Gain':
       *   Gain value: rtP.Gain_q_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp171[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_l[i1] * rtP.Gain_q_Gain) -
            rtP.Constant_w_Value) * rtP.Polarity_m_Gain;
        }
      }

      /* Level2 S-Function Block: <S66>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[67];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S90>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[68];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S66>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[69];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S66>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[70];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S66>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_l[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_ad[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S66>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[71];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn10'
     *
     * Regarding '<S47>/Fcn10':
     *   Expression: u==10
     */
    rtb_Fcn10_b = rtb_Integer_Delay1 == 10.0;
  }

  /* SubSystem: '<S47>/Demodulator 10' */

  /* Output and update for enable system: '<S47>/Demodulator 10' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_j_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_j_MODE[1] = (rtb_Fcn10_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_j_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_j_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 10' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 10 */
        if (rtDWork.Demodulato_j_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S56>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_b[0];

            for (i1=0; i1 < 1440; i1++) {
              u0[i1] = rtP.rxdata_b_Y0;
            }
          }

          /* (Virtual) Outport Block: <S56>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_j[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_b_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_j_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_j_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S56>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[6];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S71>/Polarity' incorporates:
       *   Sum: '<S71>/Sum'
       *   Gain: '<S71>/Gain'
       *   Constant: '<S71>/Constant'
       *
       * Regarding '<S71>/Polarity':
       *   Gain value: rtP.Polarity_c_Gain
       *
       * Regarding '<S71>/Gain':
       *   Gain value: rtP.Gain_g_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp183[0];

        for (i1=0; i1 < 1920; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_b[i1] * rtP.Gain_g_Gain) -
            rtP.Constant_m_Value) * rtP.Polarity_c_Gain;
        }
      }

      /* Level2 S-Function Block: <S56>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[7];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S70>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[8];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S56>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[9];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S56>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[10];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S56>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_b[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_j[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S56>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[11];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn11'
     *
     * Regarding '<S47>/Fcn11':
     *   Expression: u==11
     */
    rtb_Fcn11_b = rtb_Integer_Delay1 == 11.0;
  }

  /* SubSystem: '<S47>/Demodulator 11' */

  /* Output and update for enable system: '<S47>/Demodulator 11' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_k_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_k_MODE[1] = (rtb_Fcn11_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_k_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_k_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 11' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 11 */
        if (rtDWork.Demodulato_k_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S57>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_c[0];

            for (i1=0; i1 < 1440; i1++) {
              u0[i1] = rtP.rxdata_c_Y0;
            }
          }

          /* (Virtual) Outport Block: <S57>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_l[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_c_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_k_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_k_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S57>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[12];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S73>/Polarity' incorporates:
       *   Sum: '<S73>/Sum'
       *   Gain: '<S73>/Gain'
       *   Constant: '<S73>/Constant'
       *
       * Regarding '<S73>/Polarity':
       *   Gain value: rtP.Polarity_d_Gain
       *
       * Regarding '<S73>/Gain':
       *   Gain value: rtP.Gain_h_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp182[0];

        for (i1=0; i1 < 1920; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_c[i1] * rtP.Gain_h_Gain) -
            rtP.Constant_n_Value) * rtP.Polarity_d_Gain;
        }
      }

      /* Level2 S-Function Block: <S57>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[13];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S72>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[14];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S57>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[15];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S57>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[16];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S57>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_c[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_l[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S57>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[17];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* Fcn: '<S47>/Fcn12'
     *
     * Regarding '<S47>/Fcn12':
     *   Expression: u==12
     */
    rtb_Fcn12_b = rtb_Integer_Delay1 == 12.0;
  }

  /* SubSystem: '<S47>/Demodulator 12' */

  /* Output and update for enable system: '<S47>/Demodulator 12' */
  /* detect enable/disable transitions */
  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {
    EnableStates prevEnableState = (EnableStates) rtDWork.Demodulato_l_MODE[0];
    EnableStates enableState;

    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */
     rtDWork.Demodulato_l_MODE[1] = (rtb_Fcn12_b > 0.0) ? SUBSYS_ENABLED :
        SUBSYS_DISABLED;
    }

    enableState = (EnableStates) rtDWork.Demodulato_l_MODE[1];
    if (enableState == SUBSYS_ENABLED) {
      if (prevEnableState == SUBSYS_DISABLED) {
        /* SUBSYS_BECOMING_ENABLED */
        /* (system enable function is empty) */
        rtDWork.Demodulato_l_MODE[0] = (int_T) SUBSYS_ENABLED;
      }
    } else {
      if (prevEnableState == SUBSYS_ENABLED) {
        /* SUBSYS_BECOMING_DISABLED */

        /* Disable for enable system: '<S47>/Demodulator 12' */
        /* DisableFcn of enable SubSystem Block: <S47>/Demodulator 12 */
        if (rtDWork.Demodulato_l_MODE[0] == (int_T) SUBSYS_ENABLED) {

          /* (Virtual) Outport Block: <S58>/rxdata */

          {
            int_T i1;

            real_T *u0 = &rtB.Viterbi_Decoder1_d[0];

            for (i1=0; i1 < 1440; i1++) {
              u0[i1] = rtP.rxdata_d_Y0;
            }
          }

          /* (Virtual) Outport Block: <S58>/symerr */

          {
            int_T i1;

            creal_T *u0 = &rtB.Sum_n[0];

            for (i1=0; i1 < 960; i1++) {
              u0[i1].re = rtP.symerr_d_Y0;
              u0[i1].im = 0.0;
            }
          }

          rtDWork.Demodulato_l_MODE[0] = (int_T) SUBSYS_DISABLED;
        }
      }
    }
  }

  /* run blocks if enabled */
  if (rtDWork.Demodulato_l_MODE[0] == SUBSYS_ENABLED) {
    if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) {

      /* Level2 S-Function Block: <S58>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[18];
        sfcnOutputs(rts, tid);
      }

      /* Gain: '<S75>/Polarity' incorporates:
       *   Sum: '<S75>/Sum'
       *   Gain: '<S75>/Gain'
       *   Constant: '<S75>/Constant'
       *
       * Regarding '<S75>/Polarity':
       *   Gain value: rtP.Polarity_e_Gain
       *
       * Regarding '<S75>/Gain':
       *   Gain value: rtP.Gain_i_Gain
       */
      {
        int_T i1;

        real_T *y0 = &rtB.temp181[0];

        for (i1=0; i1 < 1920; i1++) {
          y0[i1] = ((rtB.Rectangular_QAM_Demod_d[i1] * rtP.Gain_i_Gain) -
            rtP.Constant_o_Value) * rtP.Polarity_e_Gain;
        }
      }

      /* Level2 S-Function Block: <S58>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[19];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S74>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[20];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S58>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[21];
        sfcnOutputs(rts, tid);
      }

      /* Level2 S-Function Block: <S58>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[22];
        sfcnOutputs(rts, tid);
      }

      /* Sum: '<S58>/Sum' */
      {
        int_T i1;

        const creal_T *u0 = &rtB.Rectangular_QAM_Modula_d[0];
        const creal_T *u1 = &rtB.Reshape3[0];
        creal_T *y0 = &rtB.Sum_n[0];

        for (i1=0; i1 < 960; i1++) {
          y0[i1].re = u0[i1].re - u1[i1].re;
          y0[i1].im = u0[i1].im - u1[i1].im;
        }
      }

      /* Level2 S-Function Block: <S58>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[23];
        sfcnOutputs(rts, tid);
      }
    } }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* MultiPortSwitch: '<S47>/Multiport Switch1' */
    switch ((int_T)rtb_Integer_Delay1) {
     case 1:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_h[0], 960 * sizeof
       (creal_T));
      break;
     case 2:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_p[0], 960 * sizeof
       (creal_T));
      break;
     case 3:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_r[0], 960 * sizeof
       (creal_T));
      break;
     case 4:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_t[0], 960 * sizeof
       (creal_T));
      break;
     case 5:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_v[0], 960 * sizeof
       (creal_T));
      break;
     case 6:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_x[0], 960 * sizeof
       (creal_T));
      break;
     case 7:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_z[0], 960 * sizeof
       (creal_T));
      break;
     case 8:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_ab[0], 960 * sizeof
       (creal_T));
      break;
     case 9:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_ad[0], 960 * sizeof
       (creal_T));
      break;
     case 10:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_j[0], 960 * sizeof
       (creal_T));
      break;
     case 11:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_l[0], 960 * sizeof
       (creal_T));
      break;
     case 12:

      (void) memcpy (&rtb_Multiport_Switch1[0], &rtB.Sum_n[0], 960 * sizeof
       (creal_T));
      break;
     default:
      /* Result undefined */
#if defined(MATLAB_MEX_FILE)
      (void)mexPrintf("Error: Invalid control input for block:"
       "IEEE80211g/Reciever/Demodulator1/Multiport Switch1\n"
       "Result is undefined.");
#endif
      break;
    }

    /* Abs: '<S47>/Abs' */
    {
      int_T i1;

      const creal_T *u0 = &rtb_Multiport_Switch1[0];
      real_T *y0 = &rtb_Abs[0];

      for (i1=0; i1 < 960; i1++) {
        y0[i1] = sqrt( u0[i1].re*u0[i1].re + u0[i1].im*u0[i1].im );
      }
    }

    /* DSP Blockset RMS (sdspstatfcns) - '<S5>/RMS' */
    {
      const real_T *u = &rtb_Abs[0];
      real_T *y = &rtb_temp313;
      int_T j = 1;
      while (j-- > 0) {
        real_T sqVal = 0.0;
        int_T i = 960;
        while (i-- > 0) {
          sqVal += (*u)*(*u);
          u++;
        }
        *y++ = sqrt(sqVal / 960);
      }
    }

    /* DSP Blockset Matrix Square (sdspmsqr2) - '<S5>/Matrix Square' */
    /* Input is a scalar */
    rtb_temp315 = rtb_temp313 * rtb_temp313;

    /* Math: '<S5>/Math Function2'
     *
     * Regarding '<S5>/Math Function2':
     *   Op: reciprocal
     */

    rtb_Math_Function2 = 1.0/(rtb_temp315);

    /* Gain: '<S44>/Scale by R' incorporates:
     *   Sum: '<S44>/Sum1'
     *   Constant: '<S44>/Constant'
     *
     * Regarding '<S44>/Scale by R':
     *   Gain value: rtP.Scale_by_R_a_Gain
     */
    rtb_temp315 = (rtb_Math_Function2 + rtP.Constant_e_Value) *
      rtP.Scale_by_R_a_Gain;

    /* Math: '<S44>/log10'
     *
     * Regarding '<S44>/log10':
     *   Op: log10
     */

    if (rtb_temp315 <= 0.0) {
      rtb_log10_a = rtMinusInf;
    } else {
      rtb_log10_a = log10(rtb_temp315);
    }

    /* Sum: '<S44>/Sum2' incorporates:
     *   Gain: '<S44>/Gain'
     *   Constant: '<S44>/Constant1'
     *
     * Regarding '<S44>/Gain':
     *   Gain value: rtP.Gain_d_Gain
     */
    rtb_Sum2_a = (rtb_log10_a * rtP.Gain_d_Gain) + rtP.Constant1_a_Value;

    /* DSP Blockset Delay (sdspdly2) - '<S1>/Integer Delay2' */

    {
      int_T ti = rtDWork.Integer_Delay2_BUFF_OFFSET;

      memcpy(&rtB.Integer_Delay2, ((byte_T *) &rtDWork.Integer_Delay2_BUFF[0] +
        (ti*sizeof(real_T))), sizeof(real_T));
    }

    /* S-Function (sfun_nddirectlook): '<S8>/Direct Look-Up Table (n-D)' incorporates:
     *   Sum: '<S8>/Sum'
     *   Constant: '<S8>/Constant'
     */

    /* LookupNDDirect: '<S8>/Direct Look-Up Table (n-D)' */
    /* 1-dimensional Direct Look-Up returning a Scalar */
    {
      int_T rt_uClip = (int_T)(rtB.Integer_Delay2 - rtP.Constant_f_Value);

      rt_uClip = rt_SATURATE(rt_uClip,0,7);
      rtb_temp315 = rtP.Direct_Look_Up_Table_n_D_b_tabl[rt_uClip];
    }

    /* DSP Blockset Matrix Transpose (sdspmtrnsp2) - '<S39>/Transpose' */

    {
      real_T *u = (real_T *)&rtB.Width_a;
      real_T *y = (real_T *)&rtb_temp315;

      int i=1;
      while (i-- > 0) {
        *y++ = *u++;
      }
    }

    /* S-Function Block: <S39>/Reshape */
    rtb_temp313 = rtb_Integer_Delay1;

    /* 
     * Matrix Concatenation: <S39>/Matrix Concatenation1
     * Vertical matrix concatenation, 
     * 2 inputs, real, data type: real_T.
     */
    {
      (void) memcpy( (byte_T *)(&rtb_Matrix_Concatenation1_a[0]),
       (byte_T *)(&rtb_temp315), 1 * sizeof(real_T) ); /* Input 1: [1x1], 1 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_Matrix_Concatenation1_a[0])) +
       1*sizeof(real_T),
       (byte_T *)(&rtb_temp313), 1 * sizeof(real_T) ); /* Input 2: [1x1], 1 * sizeof(real_T) bytes per col */
    }

    /* DSP Blockset Matrix Transpose (sdspmtrnsp2) - '<S40>/Transpose' */

    {
      real_T *u = (real_T *)&rtB.Width_b;
      real_T *y = (real_T *)&rtb_temp315;

      int i=1;
      while (i-- > 0) {
        *y++ = *u++;
      }
    }

    /* S-Function Block: <S40>/Reshape */
    {
      int_T i1;

      const real_T *u0 = &rtB.Buffer[0];
      real_T *y0 = &rtb_temp314[0];

      for (i1=0; i1 < 4320; i1++) {
        y0[i1] = u0[i1];
      }
    }

    /* 
     * Matrix Concatenation: <S40>/Matrix Concatenation1
     * Vertical matrix concatenation, 
     * 2 inputs, real, data type: real_T.
     */
    {
      (void) memcpy( (byte_T *)(&rtb_Matrix_Concatenation1_b[0]),
       (byte_T *)(&rtb_temp315), 1 * sizeof(real_T) ); /* Input 1: [1x1], 1 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_Matrix_Concatenation1_b[0])) +
       1*sizeof(real_T),
       (byte_T *)(&rtb_temp314[0]), 4320 * sizeof(real_T) ); /* Input 2: [4320x1], 4320 * sizeof(real_T) bytes per col */
    }

    /* DSP Blockset Matrix Transpose (sdspmtrnsp2) - '<S41>/Transpose' */

    {
      real_T *u = (real_T *)&rtB.Width_c;
      real_T *y = (real_T *)&rtb_temp315;

      int i=1;
      while (i-- > 0) {
        *y++ = *u++;
      }
    }

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad1' */
    /* Input dimensions: [480 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_a[0], (byte_T
      *)&rtb_temp314[0], (byte_T *)(&rtP.Zero_Pad1_PadValue), 1, 480 *
     sizeof(real_T), 3840, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad2' */
    /* Input dimensions: [720 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_e[0], (byte_T
      *)&rtb_Zero_Pad2[0], (byte_T *)(&rtP.Zero_Pad2_PadValue), 1, 720 *
     sizeof(real_T), 3600, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad3' */
    /* Input dimensions: [960 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_f[0], (byte_T
      *)&rtb_Zero_Pad3[0], (byte_T *)(&rtP.Zero_Pad3_PadValue), 1, 960 *
     sizeof(real_T), 3360, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad4' */
    /* Input dimensions: [1440 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_g[0], (byte_T
      *)&rtb_Zero_Pad4[0], (byte_T *)(&rtP.Zero_Pad4_PadValue), 1, 1440 *
     sizeof(real_T), 2880, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad5' */
    /* Input dimensions: [1920 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_h[0], (byte_T
      *)&rtb_Zero_Pad5[0], (byte_T *)(&rtP.Zero_Pad5_PadValue), 1, 1920 *
     sizeof(real_T), 2400, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad6' */
    /* Input dimensions: [2880 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_i[0], (byte_T
      *)&rtb_Zero_Pad6[0], (byte_T *)(&rtP.Zero_Pad6_PadValue), 1, 2880 *
     sizeof(real_T), 1440, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad7' */
    /* Input dimensions: [3840 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_j[0], (byte_T
      *)&rtb_Zero_Pad7[0], (byte_T *)(&rtP.Zero_Pad7_PadValue), 1, 3840 *
     sizeof(real_T), 480, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad8' */
    /* Input dimensions: [4320 x 1], output dimensions: [4320 x 1] */
    memcpy( &rtb_Zero_Pad8[0], &rtB.Viterbi_Decoder1_k[0], (4320 *
      sizeof(real_T)) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad9' */
    /* Input dimensions: [720 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_l[0], (byte_T
      *)&rtb_Zero_Pad9[0], (byte_T *)(&rtP.Zero_Pad9_PadValue), 1, 720 *
     sizeof(real_T), 3600, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad10' */
    /* Input dimensions: [1440 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_b[0], (byte_T
      *)&rtb_Zero_Pad10[0], (byte_T *)(&rtP.Zero_Pad10_PadValue), 1, 1440 *
     sizeof(real_T), 2880, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad11' */
    /* Input dimensions: [1440 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_c[0], (byte_T
      *)&rtb_Zero_Pad11[0], (byte_T *)(&rtP.Zero_Pad11_PadValue), 1, 1440 *
     sizeof(real_T), 2880, sizeof(real_T) );

    /* DSP Blockset Pad (sdsppad) - '<S47>/Zero Pad12' */
    /* Input dimensions: [1440 x 1], output dimensions: [4320 x 1] */
    MWDSP_PadAlongCols( (const byte_T *)&rtB.Viterbi_Decoder1_d[0], (byte_T
      *)&rtb_Zero_Pad12[0], (byte_T *)(&rtP.Zero_Pad12_PadValue), 1, 1440 *
     sizeof(real_T), 2880, sizeof(real_T) );

    /* MultiPortSwitch: '<S47>/Multiport Switch' */
    switch ((int_T)rtb_Integer_Delay1) {
     case 1:

      break;
     case 2:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad2[0], 4320 * sizeof (real_T));
      break;
     case 3:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad3[0], 4320 * sizeof (real_T));
      break;
     case 4:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad4[0], 4320 * sizeof (real_T));
      break;
     case 5:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad5[0], 4320 * sizeof (real_T));
      break;
     case 6:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad6[0], 4320 * sizeof (real_T));
      break;
     case 7:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad7[0], 4320 * sizeof (real_T));
      break;
     case 8:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad8[0], 4320 * sizeof (real_T));
      break;
     case 9:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad9[0], 4320 * sizeof (real_T));
      break;
     case 10:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad10[0], 4320 * sizeof
       (real_T));
      break;
     case 11:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad11[0], 4320 * sizeof
       (real_T));
      break;
     case 12:

      (void) memcpy (&rtb_temp314[0], &rtb_Zero_Pad12[0], 4320 * sizeof
       (real_T));
      break;
     default:
      /* Result undefined */
#if defined(MATLAB_MEX_FILE)
      (void)mexPrintf("Error: Invalid control input for block:"
       "IEEE80211g/Reciever/Demodulator1/Multiport Switch\n"
       "Result is undefined.");
#endif
      break;
    }

    /* S-Function Block: <S41>/Reshape */

    /* 
     * Matrix Concatenation: <S41>/Matrix Concatenation1
     * Vertical matrix concatenation, 
     * 2 inputs, real, data type: real_T.
     */
    {
      (void) memcpy( (byte_T *)(&rtb_Matrix_Concatenation1_c[0]),
       (byte_T *)(&rtb_temp315), 1 * sizeof(real_T) ); /* Input 1: [1x1], 1 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_Matrix_Concatenation1_c[0])) +
       1*sizeof(real_T),
       (byte_T *)(&rtb_temp314[0]), 4320 * sizeof(real_T) ); /* Input 2: [4320x1], 4320 * sizeof(real_T) bytes per col */
    }

    /* DSP Blockset Matrix Transpose (sdspmtrnsp2) - '<S42>/Transpose' */

    {
      real_T *u = (real_T *)&rtB.Width_d;
      real_T *y = (real_T *)&rtb_temp315;

      int i=1;
      while (i-- > 0) {
        *y++ = *u++;
      }
    }

    /* S-Function Block: <S42>/Reshape */
    rtb_temp313 = rtb_Sum2_a;

    /* 
     * Matrix Concatenation: <S42>/Matrix Concatenation1
     * Vertical matrix concatenation, 
     * 2 inputs, real, data type: real_T.
     */
    {
      (void) memcpy( (byte_T *)(&rtb_Matrix_Concatenation1_d[0]),
       (byte_T *)(&rtb_temp315), 1 * sizeof(real_T) ); /* Input 1: [1x1], 1 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_Matrix_Concatenation1_d[0])) +
       1*sizeof(real_T),
       (byte_T *)(&rtb_temp313), 1 * sizeof(real_T) ); /* Input 2: [1x1], 1 * sizeof(real_T) bytes per col */
    }

    /* 
     * Matrix Concatenation: <S4>/concat
     * Vertical matrix concatenation, 
     * 4 inputs, real, data type: real_T.
     */
    {
      (void) memcpy( (byte_T *)(&rtb_temp312[0]),
       (byte_T *)(&rtb_Matrix_Concatenation1_a[0]), 2 * sizeof(real_T) ); /* Input 1: [2x1], 2 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_temp312[0])) + 2*sizeof(real_T),
       (byte_T *)(&rtb_Matrix_Concatenation1_b[0]), 4321 * sizeof(real_T) ); /* Input 2: [4321x1], 4321 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_temp312[0])) + 4323*sizeof(real_T),
       (byte_T *)(&rtb_Matrix_Concatenation1_c[0]), 4321 * sizeof(real_T) ); /* Input 3: [4321x1], 4321 * sizeof(real_T) bytes per col */
      (void) memcpy( ((byte_T *)(&rtb_temp312[0])) + 8644*sizeof(real_T),
       (byte_T *)(&rtb_Matrix_Concatenation1_d[0]), 2 * sizeof(real_T) ); /* Input 4: [2x1], 2 * sizeof(real_T) bytes per col */
    }

    /* ComplexToRealImag: '<S38>/Complex to Real-Imag' */
    {
      int_T i1;

      const real_T *u0 = &rtb_temp312[0];
      real_T *y0 = &rtb_temp312[0];
      real_T *y1 = &rtb_Complex_to_Real_Imag_o2[0];

      for (i1=0; i1 < 8646; i1++) {
        y0[i1] = u0[i1];
        y1[i1] = 0.0;
      }
    }

    /* 
     * Matrix Concatenation: <S38>/Concatenate
     * Horizontal matrix concatenation, 
     * 2 inputs, real, data type: real_T.
     */
    (void) memcpy( ((byte_T *)(&rtB.Concatenate[0])),
     (byte_T *)&rtb_temp312[0], 8646 * sizeof(real_T) ); /* Input 1: [8646x1] */
    (void) memcpy( ((byte_T *)(&rtB.Concatenate[0])) + (8646 * sizeof(real_T)),
     (byte_T *)&rtb_Complex_to_Real_Imag_o2[0], 8646 * sizeof(real_T) ); /* Input 2: [8646x1] */

    /* S-Function (sfun_nddirectlook): '<S10>/Direct Look-Up Table (n-D)' incorporates:
     *   Sum: '<S10>/Sum'
     *   Constant: '<S10>/Constant'
     */

    /* LookupNDDirect: '<S10>/Direct Look-Up Table (n-D)' */
    /* 1-dimensional Direct Look-Up returning a Scalar */
    {
      int_T rt_uClip = (int_T)(rtB.Integer_Delay2 - rtP.Constant_g_Value);

      rt_uClip = rt_SATURATE(rt_uClip,0,7);
      rtb_Direct_Look_Up_Table_n_D_c =
        rtP.Direct_Look_Up_Table_n_D_c_tabl[rt_uClip];
    }

    /* S-Function (sfun_nddirectlook): '<S9>/Direct Look-Up Table (n-D)' incorporates:
     *   Sum: '<S9>/Sum'
     *   Constant: '<S9>/Constant'
     */

    /* LookupNDDirect: '<S9>/Direct Look-Up Table (n-D)' */
    /* 1-dimensional Direct Look-Up returning a Scalar */
    {
      int_T rt_uClip = (int_T)(rtB.Integer_Delay2 - rtP.Constant_h_Value);

      rt_uClip = rt_SATURATE(rt_uClip,0,7);
      rtb_Direct_Look_Up_Table_n_D_d =
        rtP.Direct_Look_Up_Table_n_D_d_tabl[rt_uClip];
    }

    /* Sum: '<S1>/Add1' incorporates:
     *   RelationalOperator: '<S1>/Relational Operator'
     *   RelationalOperator: '<S1>/Relational Operator1'
     *
     * Regarding '<S1>/Add1':
     * Sum Block: '<S1>/Add1'
     *
     *  y =  u0 - u1 + u2
     *
     * Input0  Data Type:  Fixed Point    U8
     * Input1  Data Type:  Fixed Point    U8
     * Input2  Data Type:  Floating Point real_T
     * Output0 Data Type:  Floating Point real_T
     * Round Mode: Floor
     * Saturation Mode: Wrap
     */
    rtB.Add1 = ((double)(rtb_Sum2_a > rtb_Direct_Look_Up_Table_n_D_c));
    rtB.Add1 -= ((double)(rtb_Sum2_a <= rtb_Direct_Look_Up_Table_n_D_d));
    rtB.Add1 += rtB.Integer_Delay2;

    /* DSP Blockset Variance (sdspstatfcns) - '<S11>/Variance' */
    {
      const creal_T *u = &rtB.Multiport_Switch_a[0];
      real_T *y = &rtb_Variance;
      int_T j = 1;
      while (j-- > 0) {
        creal_T sumVal = {0.0,0.0};
        real_T sqVal = 0.0;
        int_T i = 1920;
        while (i-- > 0) {
          sumVal.re += (*u).re;
          sumVal.im += (*u).im;
          sqVal += CMAGSQ((*u));
          u++;
        }
        *y++ = (sqVal - CMAGSQ(sumVal) / 1920) / (1920 - 1);
      }
    }

    /* Gain: '<S16>/Scale by R' incorporates:
     *   Sum: '<S16>/Sum1'
     *   Constant: '<S16>/Constant'
     *
     * Regarding '<S16>/Scale by R':
     *   Gain value: rtP.Scale_by_R_b_Gain
     */
    rtb_temp315 = (rtb_Variance + rtP.Constant_i_Value) * rtP.Scale_by_R_b_Gain;

    /* Math: '<S16>/log10'
     *
     * Regarding '<S16>/log10':
     *   Op: log10
     */

    if (rtb_temp315 <= 0.0) {
      rtb_log10_b = rtMinusInf;
    } else {
      rtb_log10_b = log10(rtb_temp315);
    }

    /* Sum: '<S11>/Sum' incorporates:
     *   Constant: '<S11>/SNRdB'
     *   Sum: '<S16>/Sum2'
     *   Gain: '<S16>/Gain'
     *   Constant: '<S16>/Constant1'
     *
     * Regarding '<S16>/Gain':
     *   Gain value: rtP.Gain_e_Gain
     */
    rtb_temp315 = rtP.SNRdB_Value
      + ((rtb_log10_b * rtP.Gain_e_Gain) + rtP.Constant1_b_Value);
  }

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* ToWorkspace: '<S7>/To Workspace' */

    rt_UpdateStructLogVar(rtDWork.To_Workspace_PWORK.LoggedData, NULL,
     &rtB.Buffer[0]);
  }
}

/* Update for root system: '<Root>' */
void MdlUpdate(int_T tid)
{

  if (rtmIsSampleHit(rtM_IEEE80211g, 1, tid)) { /* Sample time: [7.68E-005, 0.0] */

    /* DSP Blockset Delay (sdspdly2) - '<Root>/Integer Delay1' */
    {
      const int_T bytesPerElem = sizeof(real_T);
      int_T bufferStart;

      /* Scalar input */
      bufferStart = rtDWork.Integer_Delay1_BUFF_OFFSET;
      memcpy(((byte_T *) &rtDWork.Integer_Delay1_BUFF[0]) +
       (bufferStart*bytesPerElem), &rtB.Integer_Delay2, bytesPerElem);
      rtDWork.Integer_Delay1_BUFF_OFFSET += 1;
      while (rtDWork.Integer_Delay1_BUFF_OFFSET >= rtP.Integer_Delay1_Delays)
      rtDWork.Integer_Delay1_BUFF_OFFSET -= rtP.Integer_Delay1_Delays;
    }

    /* DSP Blockset Delay (sdspdly2) - '<S1>/Integer Delay2' */
    {
      const int_T bytesPerElem = sizeof(real_T);
      int_T bufferStart;

      /* Scalar input */
      bufferStart = rtDWork.Integer_Delay2_BUFF_OFFSET;
      memcpy(((byte_T *) &rtDWork.Integer_Delay2_BUFF[0]) +
       (bufferStart*bytesPerElem), &rtB.Add1, bytesPerElem);
      rtDWork.Integer_Delay2_BUFF_OFFSET += 1;
      while (rtDWork.Integer_Delay2_BUFF_OFFSET >= rtP.Integer_Delay2_Delays)
      rtDWork.Integer_Delay2_BUFF_OFFSET -= rtP.Integer_Delay2_Delays;
    }
  }
}

/* Terminate for root system: '<Root>' */
void MdlTerminate(void)
{
  if(rtM_IEEE80211g != NULL) {

    /* Terminate for enable system: '<S99>/Modulator 1' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S110>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[72];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S110>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[73];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S122>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[74];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S110>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[75];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S110>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[76];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 2' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S114>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[92];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S114>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[93];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S126>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[94];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S114>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[95];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S114>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[96];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 3' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S115>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[97];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S115>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[98];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S127>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[99];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S115>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[100];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S115>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[101];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 4' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S116>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[102];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S116>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[103];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S128>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[104];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S116>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[105];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S116>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[106];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 5' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S117>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[107];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S117>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[108];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S129>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[109];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S117>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[110];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S117>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[111];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 6' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S118>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[112];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S118>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[113];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S130>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[114];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S118>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[115];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S118>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[116];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 7' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S119>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[117];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S119>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[118];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S131>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[119];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S119>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[120];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S119>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[121];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 8' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S120>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[122];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S120>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[123];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S132>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[124];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S120>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[125];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S120>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[126];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 9' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S121>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[127];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S121>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[128];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S133>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[129];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S121>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[130];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S121>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[131];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 10' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S111>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[77];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S111>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[78];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S123>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[79];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S111>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[80];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S111>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[81];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 11' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S112>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[82];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S112>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[83];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S124>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[84];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S112>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[85];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S112>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[86];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S99>/Modulator 12' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S113>/Convolutional Encoder1 (scomconvenc) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[87];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S113>/P2 Puncture (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[88];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S125>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[89];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S113>/General Block Interleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[90];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S113>/Rectangular QAM Modulator Baseband (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[91];
        sfcnTerminate(rts);
      }
    }

    /* Level2 S-Function Block: <S101>/PN Sequence Generator (scompnseq2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[132];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S22>/S-Function (scomtrigbuff2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[133];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S23>/S-Function (scomricianlos2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[134];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S21>/S-Function (scommultwithprop2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[135];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S31>/S-Function (scomtrigbuff2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[136];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S32>/S-Function (scomricianlos2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[137];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S30>/S-Function (scommultwithprop2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[138];
      sfcnTerminate(rts);
    }

    /* Level2 S-Function Block: <S12>/Dynamic AWGN (scomawgnchan2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[139];
      sfcnTerminate(rts);
    }

    /* Terminate for enable system: '<S47>/Demodulator 1' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S55>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[0];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S55>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[1];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S68>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[2];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S55>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[3];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S55>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[4];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S55>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[5];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 2' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S59>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[24];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S59>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[25];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S76>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[26];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S59>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[27];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S59>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[28];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S59>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[29];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 3' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S60>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[30];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S60>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[31];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S78>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[32];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S60>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[33];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S60>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[34];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S60>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[35];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 4' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S61>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[36];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S61>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[37];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S80>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[38];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S61>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[39];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S61>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[40];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S61>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[41];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 5' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S62>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[42];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S62>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[43];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S82>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[44];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S62>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[45];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S62>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[46];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S62>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[47];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 6' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S63>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[48];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S63>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[49];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S84>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[50];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S63>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[51];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S63>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[52];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S63>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[53];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 7' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S64>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[54];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S64>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[55];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S86>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[56];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S64>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[57];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S64>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[58];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S64>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[59];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 8' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S65>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[60];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S65>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[61];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S88>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[62];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S65>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[63];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S65>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[64];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S65>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[65];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 9' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S66>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[66];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S66>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[67];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S90>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[68];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S66>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[69];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S66>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[70];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S66>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[71];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 10' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S56>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[6];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S56>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[7];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S70>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[8];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S56>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[9];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S56>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[10];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S56>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[11];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 11' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S57>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[12];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S57>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[13];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S72>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[14];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S57>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[15];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S57>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[16];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S57>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[17];
        sfcnTerminate(rts);
      }
    }

    /* Terminate for enable system: '<S47>/Demodulator 12' */
    if(rtM_IEEE80211g != NULL) {

      /* Level2 S-Function Block: <S58>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[18];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S58>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[19];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S74>/General Block Deinterleaver (scominterl) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[20];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S58>/Insert Zero4 (scomselect) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[21];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S58>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[22];
        sfcnTerminate(rts);
      }

      /* Level2 S-Function Block: <S58>/Viterbi Decoder1 (scomviterbi) */
      {
        SimStruct *rts = rtM_IEEE80211g->childSfunctions[23];
        sfcnTerminate(rts);
      }
    }
  }
}

/* Helper function to make function calls from non-inlined S-functions */
int_T rt_CallSys(SimStruct *S, int_T element, int_T tid)
{
  (*(S)->callSys.fcns[element])((S)->callSys.args1[element],
   (S)->callSys.args2[element], tid);

  if (ssGetErrorStatus(S) != NULL) {
    return 0;
  } else {
    return 1;
  }
}

/* Function to initialize sizes */
void MdlInitializeSizes(void)
{
  rtM_IEEE80211g->Sizes.numContStates = (0); /* Number of continuous states */
  rtM_IEEE80211g->Sizes.numY = (0);     /* Number of model outputs */
  rtM_IEEE80211g->Sizes.numU = (0);     /* Number of model inputs */
  rtM_IEEE80211g->Sizes.sysDirFeedThru = (0); /* The model is not direct feedthrough */
  rtM_IEEE80211g->Sizes.numSampTimes = (2); /* Number of sample times */
  rtM_IEEE80211g->Sizes.numBlocks = (437); /* Number of blocks */
  rtM_IEEE80211g->Sizes.numBlockIO = (186); /* Number of block outputs */
  rtM_IEEE80211g->Sizes.numBlockPrms = (136959); /* Sum of parameter "widths" */
}

/* Function to initialize sample times */
void MdlInitializeSampleTimes(void)
{
  /* task periods */
  rtM_IEEE80211g->Timing.sampleTimes[0] = (4.2666666666666668E-006);
  rtM_IEEE80211g->Timing.sampleTimes[1] = (7.68E-005);

  /* task offsets */
  rtM_IEEE80211g->Timing.offsetTimes[0] = (0.0);
  rtM_IEEE80211g->Timing.offsetTimes[1] = (0.0);
}

/* Function to register the model */
rtModel_IEEE80211g *IEEE80211g(void)
{
  (void)memset((char *)rtM_IEEE80211g, 0, sizeof(rtModel_IEEE80211g));

  {
    /* Setup solver object */
    static RTWSolverInfo rt_SolverInfo;
    rtM_IEEE80211g->solverInfo = (&rt_SolverInfo);

    rtsiSetSimTimeStepPtr(rtM_IEEE80211g->solverInfo,
     &rtM_IEEE80211g->Timing.simTimeStep);
    rtsiSetTPtr(rtM_IEEE80211g->solverInfo, &rtmGetTPtr(rtM_IEEE80211g));
    rtsiSetStepSizePtr(rtM_IEEE80211g->solverInfo,
     &rtM_IEEE80211g->Timing.stepSize);
    rtsiSetdXPtr(rtM_IEEE80211g->solverInfo, &rtM_IEEE80211g->ModelData.derivs);
    rtsiSetContStatesPtr(rtM_IEEE80211g->solverInfo,
     &rtM_IEEE80211g->ModelData.contStates);
    rtsiSetNumContStatesPtr(rtM_IEEE80211g->solverInfo,
     &rtM_IEEE80211g->Sizes.numContStates);
    rtsiSetErrorStatusPtr(rtM_IEEE80211g->solverInfo,
     &rtmGetErrorStatus(rtM_IEEE80211g));

    rtsiSetRTModelPtr(rtM_IEEE80211g->solverInfo, rtM_IEEE80211g);
  }

  /* timing info */
  {
    static time_T mdlPeriod[NSAMPLE_TIMES];
    static time_T mdlOffset[NSAMPLE_TIMES];
    static time_T mdlTaskTimes[NSAMPLE_TIMES];
    static int_T mdlTsMap[NSAMPLE_TIMES];
    static int_T mdlSampleHits[NSAMPLE_TIMES];

    {
      int_T i;

      for(i = 0; i < NSAMPLE_TIMES; i++) {
        mdlPeriod[i] = 0.0;
        mdlOffset[i] = 0.0;
        mdlTaskTimes[i] = 0.0;
      }
    }
    (void)memset((char_T *)&mdlTsMap[0], 0, 2 * sizeof(int_T));
    (void)memset((char_T *)&mdlSampleHits[0], 0, 2 * sizeof(int_T));

    rtM_IEEE80211g->Timing.sampleTimes = (&mdlPeriod[0]);
    rtM_IEEE80211g->Timing.offsetTimes = (&mdlOffset[0]);
    rtM_IEEE80211g->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    rtmSetTPtr(rtM_IEEE80211g, &mdlTaskTimes[0]);
    rtM_IEEE80211g->Timing.sampleHits = (&mdlSampleHits[0]);
  }
  {
    static int_T mdlPerTaskSampleHits[NSAMPLE_TIMES * NSAMPLE_TIMES];

    (void)memset((char_T *)&mdlPerTaskSampleHits[0], 0,
     2 * 2 * sizeof(int_T));
    rtM_IEEE80211g->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
  }
  rtsiSetSolverMode(rtM_IEEE80211g->solverInfo, SOLVER_MODE_MULTITASKING);

  /*
   * initialize model vectors and cache them in SimStruct
   */

  /* block I/O */
  {
    void *b = (void *) &rtB;
    rtM_IEEE80211g->ModelData.blockIO = (b);

    {
      int_T i;

      b = &rtB.Merge1[0].re;
      for (i = 0; i < 61584; i++) {
        ((real_T*)b)[i] = 0.0;
      }
      b = &rtB.Rectangular_QAM_Modula_x[0].re;
      for (i = 0; i < 82648; i++) {
        ((real_T*)b)[i] = 0.0;
      }
      b = &rtB.Relational_Operator1_a[0];
      for (i = 0; i < 21675; i++) {
        ((real_T*)b)[i] = 0.0;
      }
      b =&rtB.General_Block_Interleaver_x[0];
      for (i = 0; i < 306480; i++) {
        ((real_T*)b)[i] = 0.0;
      }
    }
  }

  /* parameters */
  rtM_IEEE80211g->ModelData.defaultParam = ((real_T *) &rtP);

  /* data type work */
  {
    void *dwork = (void *) &rtDWork;
    rtM_IEEE80211g->Work.dwork = (dwork);
    (void)memset((char_T *) dwork, 0, sizeof(D_Work));
    {
      int_T i;
      real_T *dwork_ptr = (real_T *) &rtDWork.Doppler_Filter_a_FILT_STATES[0].re;

      for (i = 0; i < 123392; i++) {
        dwork_ptr[i] = 0.0;
      }
    }
  }

  /* Model specific registration */

  rtM_IEEE80211g->modelName = ("IEEE80211g");
  rtM_IEEE80211g->path = ("IEEE80211g");

  rtmSetTStart(rtM_IEEE80211g, 0.0);
  rtM_IEEE80211g->Timing.tFinal = (10.0);
  rtM_IEEE80211g->Timing.stepSize = (4.2666666666666668E-006);
  rtsiSetFixedStepSize(rtM_IEEE80211g->solverInfo, 4.2666666666666668E-006);
  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;

    rtM_IEEE80211g->rtwLogInfo = (&rt_DataLoggingInfo);

    rtliSetLogFormat(rtM_IEEE80211g->rtwLogInfo, 0);

    rtliSetLogMaxRows(rtM_IEEE80211g->rtwLogInfo, 1000);

    rtliSetLogDecimation(rtM_IEEE80211g->rtwLogInfo, 1);

    rtliSetLogVarNameModifier(rtM_IEEE80211g->rtwLogInfo, "rt_");

    rtliSetLogT(rtM_IEEE80211g->rtwLogInfo, "tout");

    rtliSetLogX(rtM_IEEE80211g->rtwLogInfo, "");

    rtliSetLogXFinal(rtM_IEEE80211g->rtwLogInfo, "");

    rtliSetLogXSignalInfo(rtM_IEEE80211g->rtwLogInfo, NULL);

    rtliSetLogXSignalPtrs(rtM_IEEE80211g->rtwLogInfo, NULL);

    rtliSetLogY(rtM_IEEE80211g->rtwLogInfo, "");

    rtliSetLogYSignalInfo(rtM_IEEE80211g->rtwLogInfo, NULL);

    rtliSetLogYSignalPtrs(rtM_IEEE80211g->rtwLogInfo, NULL);
  }

  rtM_IEEE80211g->Sizes.checksums[0] = (741820232U);
  rtM_IEEE80211g->Sizes.checksums[1] = (3344517473U);
  rtM_IEEE80211g->Sizes.checksums[2] = (3073899804U);
  rtM_IEEE80211g->Sizes.checksums[3] = (898203539U);

  /* Non-finite (run-time) assignments */
  {

    rtP.Direct_Look_Up_Table_n_D_c_tabl[7] = rtInf;
    rtP.Direct_Look_Up_Table_n_D_d_tabl[0] = rtMinusInf;
  }

  /* child S-Function registration */
  {
    static RTWSfcnInfo _sfcnInfo;
    RTWSfcnInfo *sfcnInfo = &_sfcnInfo;

    rtM_IEEE80211g->sfcnInfo = (sfcnInfo);

    rtssSetErrorStatusPtr(sfcnInfo, &rtmGetErrorStatus(rtM_IEEE80211g));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &rtM_IEEE80211g->Sizes.numSampTimes);
    rtssSetTPtrPtr(sfcnInfo, &rtmGetTPtr(rtM_IEEE80211g));
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(rtM_IEEE80211g));
    rtssSetTFinalPtr(sfcnInfo, &rtM_IEEE80211g->Timing.tFinal);
    rtssSetTimeOfLastOutputPtr(sfcnInfo,
     &rtM_IEEE80211g->Timing.timeOfLastOutput);
    rtssSetStepSizePtr(sfcnInfo, &rtM_IEEE80211g->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo,
     &rtM_IEEE80211g->Timing.stopRequestedFlag);
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
     &rtM_IEEE80211g->ModelData.derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
     &rtM_IEEE80211g->ModelData.zCCacheNeedsReset);
    rtssSetBlkStateChangePtr(sfcnInfo,
     &rtM_IEEE80211g->ModelData.blkStateChange);
    rtssSetSampleHitsPtr(sfcnInfo, &rtM_IEEE80211g->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
     &rtM_IEEE80211g->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &rtM_IEEE80211g->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &rtM_IEEE80211g->solverInfo);
  }

  rtM_IEEE80211g->Sizes.numSFcns = (140);

  /* register each child */
  {
    static SimStruct childSFunctions[140];
    static SimStruct *childSFunctionPtrs[140];

    (void)memset((char_T *)&childSFunctions[0], 0, sizeof(childSFunctions));
    rtM_IEEE80211g->childSfunctions = (&childSFunctionPtrs[0]);
    {
      int_T i;

      for(i = 0; i < 140; i++) {
        rtM_IEEE80211g->childSfunctions[i] = (&childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: IEEE80211g/<S55>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[0];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_a[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 1/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_a_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_a_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_a_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_a_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_a_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_a_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_a_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_a_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_a_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_a_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_a_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_a_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_a_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 960);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_a_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 3);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_a_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_a_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_a_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_a_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_a_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_a_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_a_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_a_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_a_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S55>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[1];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp184[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp185[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 1/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_aa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_ac[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S68>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[2];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp185[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp184[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 1/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ba[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_bc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S55>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[3];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp184[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp185[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 1/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_a_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_a_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S55>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[4];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_a[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_a[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 1/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_a_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_a_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_a_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_a_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_a_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_a_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_a_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_a_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_a_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_a_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_a_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_a_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_a_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_a_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_a_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_a_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_a_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_a_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_a_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S55>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[5];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.temp185[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 480;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 480);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_a[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 1/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_a_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_a_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_a_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_a_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_a_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_a_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_a_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_a_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_a_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_a_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_a_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_a_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_a_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_a_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_a_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_a_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 480);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S56>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[6];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 10/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_b_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_b_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_b_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_b_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_b_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_b_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_b_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_b_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_b_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_b_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_b_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_b_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_b_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1920);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_b_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 5);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_b_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_b_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_b_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_b_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_b_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_b_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_b_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_b_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_b_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S56>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[7];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp183[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 10/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ca[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_cc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S70>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[8];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_c[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp183[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 10/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_da[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_dc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S56>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[9];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp183[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 10/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_b_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_b_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S56>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[10];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_b[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 10/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_b_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_b_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_b_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_b_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_b_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_b_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_b_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_b_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_b_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_b_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_b_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_b_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_b_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_b_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_b_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_b_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_b_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_b_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_b_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S56>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[11];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_b[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 10/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_b_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_b_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_b_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_b_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_b_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_b_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_b_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_b_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_b_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_b_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_b_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_b_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_b_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_b_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_b_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_b_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S57>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[12];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 11/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_c_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_c_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_c_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_c_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_c_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_c_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_c_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_c_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_c_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_c_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_c_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_c_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_c_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1920);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_c_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 5);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_c_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_c_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_c_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_c_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_c_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_c_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_c_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_c_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_c_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S57>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[13];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp182[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 11/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ea[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_ec[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S72>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[14];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_e[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp182[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 11/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_fa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_fc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S57>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[15];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp182[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 11/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_c_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_c_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S57>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[16];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_c[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 11/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_c_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_c_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_c_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_c_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_c_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_c_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_c_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_c_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_c_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_c_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_c_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_c_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_c_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_c_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_c_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_c_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_c_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_c_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_c_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S57>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[17];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_c[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 11/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_c_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_c_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_c_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_c_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_c_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_c_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_c_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_c_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_c_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_c_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_c_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_c_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_c_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_c_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_c_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_c_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S58>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[18];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 12/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_d_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_d_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_d_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_d_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_d_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_d_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_d_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_d_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_d_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_d_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_d_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_d_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_d_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1920);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_d_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 5);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_d_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_d_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_d_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_d_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_d_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_d_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_d_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_d_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_d_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S58>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[19];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp181[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 12/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ga[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_gc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S74>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[20];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_g[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp181[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 12/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ha[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_hc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S58>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[21];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp181[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 12/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_d_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_d_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S58>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[22];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_d[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 12/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_d_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_d_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_d_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_d_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_d_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_d_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_d_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_d_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_d_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_d_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_d_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_d_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_d_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_d_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_d_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_d_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_d_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_d_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_d_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S58>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[23];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_d[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 12/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_d_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_d_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_d_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_d_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_d_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_d_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_d_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_d_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_d_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_d_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_d_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_d_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_d_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_d_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_d_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_d_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S59>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[24];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 2/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_e_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_e_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_e_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_e_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_e_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_e_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_e_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_e_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_e_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_e_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_e_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_e_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_e_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 960);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_e_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 3);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_e_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_e_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_e_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_e_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_e_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_e_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_e_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_e_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_e_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S59>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[25];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp180[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 2/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ia[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_ic[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S76>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[26];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_i[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp180[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 2/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ja[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_jc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S59>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[27];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp180[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 2/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_e_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_e_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S59>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[28];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_e[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 2/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_e_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_e_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_e_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_e_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_e_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_e_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_e_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_e_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_e_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_e_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_e_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_e_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_e_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_e_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_e_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_e_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_e_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_e_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_e_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S59>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[29];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_e[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 720;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 720);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 2/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_e_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_e_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_e_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_e_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_e_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_e_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_e_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_e_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_e_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_e_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_e_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_e_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_e_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_e_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_e_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_e_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 720);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S60>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[30];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_f[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 3/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_f_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_f_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_f_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_f_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_f_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_f_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_f_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_f_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_f_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_f_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_f_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_f_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_f_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1920);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_f_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 5);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_f_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_f_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_f_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_f_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_f_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_f_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_f_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_f_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_f_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S60>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[31];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp178[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp179[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 3/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ka[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_kc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S78>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[32];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp179[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp178[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 3/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_la[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_lc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S60>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[33];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp178[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp179[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 3/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_f_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_f_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S60>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[34];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_f[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_f[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 3/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_f_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_f_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_f_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_f_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_f_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_f_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_f_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_f_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_f_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_f_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_f_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_f_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_f_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_f_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_f_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_f_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_f_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_f_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_f_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S60>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[35];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.temp179[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_f[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 3/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_f_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_f_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_f_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_f_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_f_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_f_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_f_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_f_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_f_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_f_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_f_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_f_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_f_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_f_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_f_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_f_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S61>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[36];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 4/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_g_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_g_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_g_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_g_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_g_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_g_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_g_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_g_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_g_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_g_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_g_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_g_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_g_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1920);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_g_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 5);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_g_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_g_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_g_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_g_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_g_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_g_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_g_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_g_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_g_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S61>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[37];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp177[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_m[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 4/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ma[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_mc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S80>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[38];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_m[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp177[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 4/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_na[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_nc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S61>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[39];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp177[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 4/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_g_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_g_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S61>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[40];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_g[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 4/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_g_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_g_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_g_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_g_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_g_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_g_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_g_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_g_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_g_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_g_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_g_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_g_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_g_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_g_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_g_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_g_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_g_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_g_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_g_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S61>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[41];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_g[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 4/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_g_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_g_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_g_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_g_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_g_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_g_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_g_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_g_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_g_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_g_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_g_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_g_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_g_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_g_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_g_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_g_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S62>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[42];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_h[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 5/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_h_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_h_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_h_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_h_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_h_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_h_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_h_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_h_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_h_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_h_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_h_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_h_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 16);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_h_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 3840);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_h_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 17);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_h_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_h_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_h_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_h_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_h_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_h_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_h_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_h_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_h_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S62>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[43];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp175[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp176[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 5/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_oa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_oc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S82>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[44];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp176[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp175[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 5/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_pa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_pc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S62>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[45];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp175[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp176[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 5/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_h_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_h_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S62>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[46];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_h[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_h[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 5/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_h_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_h_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_h_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_h_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_h_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_h_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_h_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_h_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_h_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_h_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_h_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_h_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 16);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_h_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_h_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_h_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_h_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_h_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_h_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_h_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S62>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[47];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.temp176[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_h[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 5/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_h_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_h_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_h_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_h_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_h_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_h_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_h_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_h_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_h_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_h_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_h_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_h_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_h_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_h_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_h_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_h_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S63>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[48];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 6/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_i_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_i_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_i_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_i_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_i_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_i_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_i_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_i_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_i_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_i_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_i_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_i_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 16);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_i_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 3840);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_i_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 17);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_i_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_i_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_i_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_i_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_i_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_i_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_i_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_i_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_i_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S63>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[49];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp174[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_q[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 6/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_qa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_qc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S84>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[50];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_q[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp174[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 6/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ra[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_rc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S63>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[51];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp174[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 6/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_i_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_i_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S63>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[52];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_i[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 6/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_i_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_i_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_i_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_i_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_i_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_i_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_i_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_i_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_i_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_i_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_i_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_i_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 16);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_i_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_i_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_i_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_i_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_i_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_i_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_i_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S63>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[53];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_i[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 6/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_i_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_i_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_i_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_i_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_i_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_i_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_i_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_i_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_i_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_i_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_i_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_i_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_i_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_i_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_i_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_i_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S64>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[54];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 7/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_j_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_j_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_j_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_j_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_j_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_j_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_j_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_j_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_j_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_j_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_j_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_j_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 64);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_j_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 5760);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_j_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 65);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_j_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_j_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_j_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_j_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_j_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_j_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_j_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_j_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_j_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S64>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[55];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp173[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_s[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 7/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_sa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_sc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S86>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[56];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_s[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp173[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 7/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ta[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_tc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S64>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[57];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp173[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 7680;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 7680);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 7/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_j_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_j_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 7680);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S64>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[58];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_j[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 7/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_j_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_j_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_j_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_j_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_j_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_j_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_j_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_j_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_j_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_j_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_j_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_j_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 64);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_j_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_j_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_j_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_j_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_j_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_j_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_j_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S64>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[59];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_j[0]);
          dimensions[0] = 7680;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 7680);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 7/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_j_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_j_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_j_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_j_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_j_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_j_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_j_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_j_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_j_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_j_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_j_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_j_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_j_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_j_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_j_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_j_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 7680);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S65>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[60];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_k[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 8/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_k_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_k_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_k_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_k_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_k_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_k_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_k_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_k_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_k_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_k_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_k_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_k_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 64);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_k_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 5760);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_k_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 65);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_k_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_k_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_k_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_k_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_k_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_k_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_k_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_k_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_k_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S65>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[61];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp172[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_u[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 8/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_ua[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_uc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S88>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[62];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_u[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp172[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 8/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_va[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_vc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S65>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[63];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp172[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 8640;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 8640);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_k[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 8/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_k_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_k_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 8640);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S65>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[64];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_k[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_k[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 8/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_k_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_k_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_k_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_k_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_k_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_k_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_k_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_k_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_k_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_k_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_k_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_k_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 64);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_k_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_k_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_k_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_k_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_k_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_k_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_k_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S65>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[65];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_k[0]);
          dimensions[0] = 8640;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 8640);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 4320;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 4320);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_k[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 8/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_k_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_k_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_k_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_k_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_k_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_k_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_k_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_k_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_k_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_k_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_k_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_k_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_k_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_k_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_k_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_k_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 8640);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 4320);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S66>/Rectangular QAM Demodulator Baseband (scomapskdemod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[66];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Reshape3[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Rectangular_QAM_Demod_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nDemodulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 9/Rectangular QAM Demodulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Demod_l_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Demod_l_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Demod_l_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Demod_l_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Demod_l_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Demod_l_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Demod_l_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Demod_l_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Demod_l_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Demod_l_P10_Siz[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Demod_l_P11_Siz[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Demod_l_P12_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[11];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 11);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Demod_l_DWORK_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 960);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Demod_l_DWORK_f[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 3);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Demod_l_DWORK_d[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Demod_l_DWORK_b);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Demod_l_DWORK_g);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Demod_l_DWORK_h);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Demod_l_DWORK_e);

        /* DWORK8 */
        ssSetDWorkWidth(rts, 7, 1);
        ssSetDWorkDataType(rts, 7,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 7, 1);
        ssSetDWork(rts, 7, &rtDWork.Rectangular_QAM_Demod_l_DWORK_c);

        /* DWORK9 */
        ssSetDWorkWidth(rts, 8, 1);
        ssSetDWorkDataType(rts, 8,SS_INT32);
        ssSetDWorkComplexSignal(rts, 8, 0);
        ssSetDWork(rts, 8, &rtDWork.Rectangular_QAM_Demod_l_DWORK_i);

        /* DWORK10 */
        ssSetDWorkWidth(rts, 9, 1);
        ssSetDWorkDataType(rts, 9,SS_INT32);
        ssSetDWorkComplexSignal(rts, 9, 0);
        ssSetDWork(rts, 9, &rtDWork.Rectangular_QAM_Demod_l_DWORK_j);

        /* DWORK11 */
        ssSetDWorkWidth(rts, 10, 1);
        ssSetDWorkDataType(rts, 10,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 10, 0);
        ssSetDWork(rts, 10, &rtDWork.Rectangular_QAM_Demod_l_DWORK_k);
      }

      /* registration */
      scomapskdemod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S66>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[67];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp171[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Deinterleaver_w[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 9/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_wa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_wc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S90>/General Block Deinterleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[68];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Deinterleaver_w[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp171[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nDeinterleaver");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 9/Matrix Deinterleaver/General Block Deinterleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Deinterlea_xa[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Deinterlea_xc[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S66>/Insert Zero4 (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[69];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp171[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Insert_Zero4_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Insert Zero4");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 9/Insert Zero4");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Insert_Zero4_l_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Insert_Zero4_l_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S66>/Rectangular QAM Modulator Baseband1 (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[70];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Rectangular_QAM_Demod_l[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 9/Rectangular QAM Modulator Baseband1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_l_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_l_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_l_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_l_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_l_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_l_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_l_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_l_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_l_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_l_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_l_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_l_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_l_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_l_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_l_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_l_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_l_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_l_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_l_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S66>/Viterbi Decoder1 (scomviterbi) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[71];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Insert_Zero4_l[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 720;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 720);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.Viterbi_Decoder1_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Viterbi Decoder1");
      ssSetPath(rts,
       "IEEE80211g/Reciever/Demodulator1/Demodulator 9/Viterbi Decoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[10];

        ssSetSFcnParamsCount(rts, 10);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Viterbi_Decoder1_l_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Viterbi_Decoder1_l_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Viterbi_Decoder1_l_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Viterbi_Decoder1_l_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Viterbi_Decoder1_l_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Viterbi_Decoder1_l_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.Viterbi_Decoder1_l_P7_Size[0]);
        ssSetSFcnParam(rts, 7, &rtP.Viterbi_Decoder1_l_P8_Size[0]);
        ssSetSFcnParam(rts, 8, &rtP.Viterbi_Decoder1_l_P9_Size[0]);
        ssSetSFcnParam(rts, 9, &rtP.Viterbi_Decoder1_l_P10_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[6];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 6);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Viterbi_Decoder1_l_DWORK7_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 64);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Viterbi_Decoder1_l_DWORK7_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 64);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.Viterbi_Decoder1_l_DWORK7_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2240);
        ssSetDWorkDataType(rts, 3,SS_INT32);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.Viterbi_Decoder1_l_DWORK7_d[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 2240);
        ssSetDWorkDataType(rts, 4,SS_INT32);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Viterbi_Decoder1_l_DWORK7_e[0]);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Viterbi_Decoder1_l_DWORK7_f);
      }

      /* registration */
      scomviterbi(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 720);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S110>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[72];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_b[0]);
          dimensions[0] = 480;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 480);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp170[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 1/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_a_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_a_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_a_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_a_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_a_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_a_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_a_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 480);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S110>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[73];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp170[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_a[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 1/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_a_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_a_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S122>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[74];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_a[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp170[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 1/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_a_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_a_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S110>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[75];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp170[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 1/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_b_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_b_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S110>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[76];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_b[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_m[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 1/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_m_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_m_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_m_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_m_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_m_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_m_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_m_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_m_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_m_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_m_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_m_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_m_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_m_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_m_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_m_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_m_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_m_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_m_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_m_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S111>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[77];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_c[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 10/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_b_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_b_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_b_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_b_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_b_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_b_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_b_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S111>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[78];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[2880];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_b[0];

            for (i1=0; i1 < 2880; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 10/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_b_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_b_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S123>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[79];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_b[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 10/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_c_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_c_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S111>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[80];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_c[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 10/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_d_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_d_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S111>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[81];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_d[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_n[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 10/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_n_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_n_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_n_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_n_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_n_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_n_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_n_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_n_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_n_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_n_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_n_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_n_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_n_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_n_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_n_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_n_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_n_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_n_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_n_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S112>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[82];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_d[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 11/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_c_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_c_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_c_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_c_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_c_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_c_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_c_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S112>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[83];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[2880];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_c[0];

            for (i1=0; i1 < 2880; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 11/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_c_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_c_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S124>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[84];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_c[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 11/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_e_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_e_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S112>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[85];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_e[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_f[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 11/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_f_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_f_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S112>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[86];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_f[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_o[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 11/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_o_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_o_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_o_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_o_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_o_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_o_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_o_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_o_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_o_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_o_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_o_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_o_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_o_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_o_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_o_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_o_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_o_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_o_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_o_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S113>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[87];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_e[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 12/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_d_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_d_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_d_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_d_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_d_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_d_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_d_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S113>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[88];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[2880];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_d[0];

            for (i1=0; i1 < 2880; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_d[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 12/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_d_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_d_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S125>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[89];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_d[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 12/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_g_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_g_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S113>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[90];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_g[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_h[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 12/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_h_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_h_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S113>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[91];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_h[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_p[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 12/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_p_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_p_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_p_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_p_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_p_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_p_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_p_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_p_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_p_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_p_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_p_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_p_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_p_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_p_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_p_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_p_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_p_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_p_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_p_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S114>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[92];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_f[0]);
          dimensions[0] = 720;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 720);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 2/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_e_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_e_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_e_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_e_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_e_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_e_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_e_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 720);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S114>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[93];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1440];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_e[0];

            for (i1=0; i1 < 1440; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 2/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_e_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_e_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S126>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[94];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_e[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 2/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_i_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_i_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S114>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[95];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_i[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 2/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_j_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_j_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S114>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[96];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_j[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_q[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 2/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_q_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_q_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_q_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_q_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_q_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_q_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_q_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_q_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_q_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_q_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_q_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_q_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_q_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_q_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_q_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_q_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_q_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_q_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_q_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S115>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[97];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_g[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp169[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 3/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_f_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_f_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_f_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_f_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_f_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_f_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_f_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S115>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[98];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp169[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_f[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 3/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_f_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_f_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S127>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[99];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_f[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp169[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 3/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_k_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_k_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S115>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[100];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp169[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 3/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_l_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_l_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S115>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[101];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_l[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_r[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 3/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_r_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_r_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_r_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_r_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_r_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_r_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_r_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_r_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_r_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_r_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_r_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_r_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_r_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_r_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_r_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_r_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_r_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_r_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_r_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S116>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[102];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_h[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 2880);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 4/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_g_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_g_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_g_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_g_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_g_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_g_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_g_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 2880);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S116>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[103];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[2880];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_g[0];

            for (i1=0; i1 < 2880; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_g[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 4/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_g_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_g_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S128>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[104];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_g[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_m[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 4/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_m_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_m_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S116>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[105];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_m[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_n[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 4/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_n_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_n_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S116>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[106];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_n[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_s[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 4/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_s_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_s_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_s_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_s_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_s_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_s_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_s_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_s_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_s_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_s_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_s_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_s_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_s_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_s_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_s_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_s_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_s_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_s_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_s_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S117>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[107];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_i[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp168[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 5/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_h_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_h_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_h_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_h_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_h_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_h_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_h_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S117>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[108];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp168[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_h[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 5/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_h_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_h_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S129>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[109];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_h[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.temp168[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 5/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_o_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_o_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S117>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[110];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.temp168[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_p[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 5/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_p_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_p_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S117>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[111];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_p[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_t[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 5/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_t_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_t_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_t_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_t_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_t_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_t_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_t_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_t_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_t_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_t_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_t_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_t_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 16);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_t_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_t_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_t_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_t_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_t_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_t_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_t_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S118>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[112];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_j[0]);
          dimensions[0] = 2880;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2880);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 6/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_i_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_i_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_i_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_i_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_i_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_i_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_i_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2880);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S118>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[113];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_i[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_i[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 6/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_i_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_i_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S130>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[114];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_i[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_q[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 6/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_q_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_q_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S118>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[115];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_q[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_r[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 6/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_r_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_r_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S118>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[116];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_r[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_u[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 6/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_u_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_u_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_u_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_u_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_u_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_u_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_u_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_u_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_u_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_u_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_u_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_u_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 16);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_u_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_u_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_u_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_u_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_u_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_u_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_u_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S119>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[117];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_k[0]);
          dimensions[0] = 3840;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 7680;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 7680);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 7/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_j_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_j_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_j_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_j_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_j_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_j_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_j_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 7680);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S119>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[118];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[7680];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_j[0];

            for (i1=0; i1 < 7680; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 7680;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 7680);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_j[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 7/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_j_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_j_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 7680);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S131>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[119];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_j[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_s[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 7/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_s_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_s_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S119>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[120];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_s[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_t[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 7/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_t_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_t_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S119>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[121];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_t[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_v[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 7/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_v_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_v_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_v_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_v_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_v_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_v_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_v_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_v_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_v_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_v_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_v_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_v_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 64);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_v_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_v_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_v_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_v_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_v_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_v_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_v_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S120>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[122];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_l[0]);
          dimensions[0] = 4320;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 4320);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 8640;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 8640);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_k[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 8/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_k_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_k_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_k_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_k_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_k_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_k_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_k_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 4320);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 8640);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S120>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[123];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[8640];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_k[0];

            for (i1=0; i1 < 8640; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 8640;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 8640);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_k[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 8/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_k_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_k_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 8640);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S132>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[124];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_k[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_u[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 8/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_u_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_u_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S120>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[125];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[5760];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_u[0];

            for (i1=0; i1 < 5760; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 5760);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_v[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 8/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_v_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_v_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 5760);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S120>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[126];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_v[0]);
          dimensions[0] = 5760;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 5760);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_w[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 8/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_w_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_w_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_w_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_w_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_w_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_w_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_w_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_w_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_w_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_w_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_w_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_w_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 64);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_w_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_w_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_w_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_w_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_w_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_w_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_w_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 5760);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S121>/Convolutional Encoder1 (scomconvenc) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[127];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.Zero_Pad_m[0]);
          dimensions[0] = 720;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 720);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1440);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.Convolutional_Encoder1_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Convolutional\nEncoder1");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 9/Convolutional Encoder1");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Convolutional_Encoder1_l_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Convolutional_Encoder1_l_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Convolutional_Encoder1_l_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Convolutional_Encoder1_l_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Convolutional_Encoder1_l_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Convolutional_Encoder1_l_P6_Siz[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Convolutional_Encoder1_l_DWORK2);
      }

      /* registration */
      scomconvenc(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 720);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1440);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S121>/P2 Puncture (scomselect) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[128];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[1440];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.Convolutional_Encoder1_l[0];

            for (i1=0; i1 < 1440; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1440;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1440);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *) &rtB.P2_Puncture_l[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "P2 Puncture");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 9/P2 Puncture");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.P2_Puncture_l_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.P2_Puncture_l_P2_Size[0]);
      }

      /* registration */
      scomselect(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1440);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S133>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[129];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.P2_Puncture_l[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_w[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 9/Matrix Interleaver/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_w_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_w_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S121>/General Block Interleaver (scominterl) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[130];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static real_T const *sfcnUPtrs[960];
          static int_T dimensions[2];
          {
            int_T i1;

            const real_T *u0 = &rtB.General_Block_Interleaver_w[0];

            for (i1=0; i1 < 960; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.General_Block_Interleaver_x[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "General Block\nInterleaver");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 9/General Block Interleaver");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[2];

        ssSetSFcnParamsCount(rts, 2);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.General_Block_Interleaver_x_P1_[0]);
        ssSetSFcnParam(rts, 1, &rtP.General_Block_Interleaver_x_P2_[0]);
      }

      /* registration */
      scominterl(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 0);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S121>/Rectangular QAM Modulator Baseband (scomapskmod) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[131];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static int_T dimensions[2];
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &rtB.General_Block_Interleaver_x[0]);
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 960);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 960;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 960);
          ssSetOutputPortSignal(rts, 0, ((creal_T *)
            &rtB.Rectangular_QAM_Modula_x[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Rectangular QAM\nModulator\nBaseband");
      ssSetPath(rts,
       "IEEE80211g/Transmitter/Modulator1/Modulator 9/Rectangular QAM Modulator Baseband");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[12];

        ssSetSFcnParamsCount(rts, 12);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Rectangular_QAM_Modula_x_P1_Siz[0]);
        ssSetSFcnParam(rts, 1, &rtP.Rectangular_QAM_Modula_x_P2_Siz[0]);
        ssSetSFcnParam(rts, 2, &rtP.Rectangular_QAM_Modula_x_P3_Siz[0]);
        ssSetSFcnParam(rts, 3, &rtP.Rectangular_QAM_Modula_x_P4_Siz[0]);
        ssSetSFcnParam(rts, 4, &rtP.Rectangular_QAM_Modula_x_P5_Siz[0]);
        ssSetSFcnParam(rts, 5, &rtP.Rectangular_QAM_Modula_x_P6_Siz[0]);
        ssSetSFcnParam(rts, 6, &rtP.Rectangular_QAM_Modula_x_P7_Siz[0]);
        ssSetSFcnParam(rts, 7, &rtP.Rectangular_QAM_Modula_x_P8_Siz[0]);
        ssSetSFcnParam(rts, 8, &rtP.Rectangular_QAM_Modula_x_P9_Siz[0]);
        ssSetSFcnParam(rts, 9, &rtP.Rectangular_QAM_Modula_x_P10_Si[0]);
        ssSetSFcnParam(rts, 10, &rtP.Rectangular_QAM_Modula_x_P11_Si[0]);
        ssSetSFcnParam(rts, 11, &rtP.Rectangular_QAM_Modula_x_P12_Si[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[7];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 7);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.Rectangular_QAM_Modula_x_DWOR_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_BOOLEAN);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.Rectangular_QAM_Modula_x_DWOR_g);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 960);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 1);
        ssSetDWork(rts, 2, &rtDWork.Rectangular_QAM_Modula_x_DWOR_b[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 960);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 1);
        ssSetDWork(rts, 3, &rtDWork.Rectangular_QAM_Modula_x_DWOR_c[0]);

        /* DWORK5 */
        ssSetDWorkWidth(rts, 4, 1);
        ssSetDWorkDataType(rts, 4,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 4, 0);
        ssSetDWork(rts, 4, &rtDWork.Rectangular_QAM_Modula_x_DWOR_d);

        /* DWORK6 */
        ssSetDWorkWidth(rts, 5, 1);
        ssSetDWorkDataType(rts, 5,SS_INT32);
        ssSetDWorkComplexSignal(rts, 5, 0);
        ssSetDWork(rts, 5, &rtDWork.Rectangular_QAM_Modula_x_DWOR_e);

        /* DWORK7 */
        ssSetDWorkWidth(rts, 6, 1);
        ssSetDWorkDataType(rts, 6,SS_INT32);
        ssSetDWorkComplexSignal(rts, 6, 0);
        ssSetDWork(rts, 6, &rtDWork.Rectangular_QAM_Modula_x_DWOR_f);
      }

      /* registration */
      scomapskmod(rts);

      sfcnInitializeSizes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 960);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 960);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      /* Update port-based sample time attributes */
      _ssSetInputPortSampleTimeIndex(rts, 0, 0);
      ssSetInputPortSampleTime(rts, 0, 7.68E-005);
      ssSetInputPortOffsetTime(rts, 0, 0.0);
      _ssSetOutputPortSampleTimeIndex(rts, 0, 0);
      ssSetOutputPortSampleTime(rts, 0, 7.68E-005);
      ssSetOutputPortOffsetTime(rts, 0, 0.0);
      sfcnInitializeSampleTimes(rts);
    }

    /* Level2 S-Function Block: IEEE80211g/<S101>/PN Sequence Generator (scompnseq2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[132];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 20;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 20);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &rtB.PN_Sequence_Generator[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "PN Sequence\nGenerator");
      ssSetPath(rts, "IEEE80211g/Transmitter/Pilots/PN Sequence Generator");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[7];

        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.PN_Sequence_Generator_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.PN_Sequence_Generator_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.PN_Sequence_Generator_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.PN_Sequence_Generator_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.PN_Sequence_Generator_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.PN_Sequence_Generator_P6_Size[0]);
        ssSetSFcnParam(rts, 6, &rtP.PN_Sequence_Generator_P7_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[3];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 3);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 7);
        ssSetDWorkDataType(rts, 0,SS_INT32);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.PN_Sequence_Generator_DWORK4_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 7);
        ssSetDWorkDataType(rts, 1,SS_INT32);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.PN_Sequence_Generator_DWORK4_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 7);
        ssSetDWorkDataType(rts, 2,SS_INT32);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.PN_Sequence_Generator_DWORK4_c[0]);
      }

      /* registration */
      scompnseq2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: IEEE80211g/<S22>/S-Function (scomtrigbuff2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[133];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[2250];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.FIR_Rate_Conversi_e[0];

            for (i1=0; i1 < 2250; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 2250;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 2250);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[2];
        _ssSetNumOutputPorts(rts, 2);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, NULL);
        }
        /* port 1 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 1, dimensions);
          _ssSetOutputPortNumDimensions(rts, 1, 2);
          ssSetOutputPortWidth(rts, 1, 1920);
          ssSetOutputPortSignal(rts, 1, ((creal_T *) &rtB.S_Function_a_o2[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile/Rebuffer with  Input Trigger/S-Function");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.S_Function_a_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.S_Function_a_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.S_Function_a_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.S_Function_a_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.S_Function_a_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.S_Function_a_P6_Size[0]);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &rtDWork.S_Function_a_IWORK[0]);
      ssSetPWork(rts, (void **) &rtDWork.S_Function_a_PWORK);
      {
        static struct _ssDWorkRecord dWorkRecord[3];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 3);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2250);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.S_Function_a_DWORK4[0]);

        /* IWORK */
        ssSetDWorkWidth(rts, 1, 5);
        ssSetDWorkDataType(rts, 1,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.S_Function_a_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.S_Function_a_PWORK);
      }

      /* register function-calls */
      {
        static int_T callSysOutputs[1];
        static void *callSysArgs1[1];
        static int_T callSysArgs2[1];
        static SysOutputFcn callSysFcns[1];

        {
          int_T i;
          for (i = 0; i < 1; i++) {
            callSysOutputs[i] = 0;
            callSysFcns[i] = (SysOutputFcn) NULL;
          }
        }
        ssSetCallSystemOutputPtr(rts, &callSysOutputs[0]);
        ssSetCallSystemOutputArg1List(rts, &callSysArgs1[0]);
        ssSetCallSystemOutputArg2List(rts, &callSysArgs2[0]);
        ssSetCallSystemOutputFcnList(rts, &callSysFcns[0]);

        callSysArgs1[0] = (void *)rtM_IEEE80211g;
        callSysArgs2[0] = 0;
        callSysFcns[0] = (SysOutputFcn) IEEE80211g_Triggered_Ra_aFNI;
        callSysOutputs[0] = 1;
      }

      /* registration */
      scomtrigbuff2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 2250);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1);

      ssSetOutputPortWidth(rts, 1, 1920);

      _ssSetNumDWork(rts, 3);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S23>/S-Function (scomricianlos2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[134];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.S_Function_a_o2[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((creal_T *) &rtB.S_Function_b[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile/Rician Channel  Effects/S-Function");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[5];

        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.S_Function_b_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.S_Function_b_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.S_Function_b_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.S_Function_b_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.S_Function_b_P5_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[4];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 4);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.S_Function_b_DWORK5_a);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.S_Function_b_DWORK5_b);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.S_Function_b_DWORK5_c);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 1);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.S_Function_b_DWORK5_d);
      }

      /* registration */
      scomricianlos2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S21>/S-Function (scommultwithprop2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[135];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[2];

        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Variable_Fraction_a[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }

        /* port 1 */
        {

          static creal_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u1 = &rtB.S_Function_b[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u1[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 1, dimensions);
          _ssSetInputPortNumDimensions(rts, 1, 2);
          ssSetInputPortWidth(rts, 1, 1920);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((creal_T *) &rtB.S_Function_c[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Multiply with  back propagation/S-Function");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[3];

        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.S_Function_c_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.S_Function_c_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.S_Function_c_P3_Size[0]);
      }

      /* registration */
      scommultwithprop2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetInputPortWidth(rts, 1, 1920);
      ssSetInputPortDataType(rts, 1, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 1, 1);
      ssSetInputPortFrameData(rts, 1, 1);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S31>/S-Function (scomtrigbuff2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[136];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[4500];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.FIR_Rate_Conversi_j[0];

            for (i1=0; i1 < 4500; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 2250;
          dimensions[1] = 2;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 4500);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[2];
        _ssSetNumOutputPorts(rts, 2);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, NULL);
        }
        /* port 1 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 2;
          _ssSetOutputPortDimensionsPtr(rts, 1, dimensions);
          _ssSetOutputPortNumDimensions(rts, 1, 2);
          ssSetOutputPortWidth(rts, 1, 3840);
          ssSetOutputPortSignal(rts, 1, ((creal_T *) &rtB.S_Function_d_o2[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile/Rebuffer with  Input Trigger/S-Function");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.S_Function_d_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.S_Function_d_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.S_Function_d_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.S_Function_d_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.S_Function_d_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.S_Function_d_P6_Size[0]);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &rtDWork.S_Function_d_IWORK[0]);
      ssSetPWork(rts, (void **) &rtDWork.S_Function_d_PWORK);
      {
        static struct _ssDWorkRecord dWorkRecord[3];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 3);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 4500);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 1);
        ssSetDWork(rts, 0, &rtDWork.S_Function_d_DWORK4[0]);

        /* IWORK */
        ssSetDWorkWidth(rts, 1, 5);
        ssSetDWorkDataType(rts, 1,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.S_Function_d_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 2, 1);
        ssSetDWorkDataType(rts, 2,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.S_Function_d_PWORK);
      }

      /* register function-calls */
      {
        static int_T callSysOutputs[1];
        static void *callSysArgs1[1];
        static int_T callSysArgs2[1];
        static SysOutputFcn callSysFcns[1];

        {
          int_T i;
          for (i = 0; i < 1; i++) {
            callSysOutputs[i] = 0;
            callSysFcns[i] = (SysOutputFcn) NULL;
          }
        }
        ssSetCallSystemOutputPtr(rts, &callSysOutputs[0]);
        ssSetCallSystemOutputArg1List(rts, &callSysArgs1[0]);
        ssSetCallSystemOutputArg2List(rts, &callSysArgs2[0]);
        ssSetCallSystemOutputFcnList(rts, &callSysFcns[0]);

        callSysArgs1[0] = (void *)rtM_IEEE80211g;
        callSysArgs2[0] = 0;
        callSysFcns[0] = (SysOutputFcn) IEEE80211g_Triggered_Ra_bFNI;
        callSysOutputs[0] = 1;
      }

      /* registration */
      scomtrigbuff2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 4500);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 1);

      ssSetOutputPortWidth(rts, 1, 3840);

      _ssSetNumDWork(rts, 3);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S32>/S-Function (scomricianlos2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[137];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[1];

        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.S_Function_d_o2[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 2;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 2;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((creal_T *) &rtB.S_Function_e[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile/Rician Channel  Effects/S-Function");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[5];

        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.S_Function_e_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.S_Function_e_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.S_Function_e_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.S_Function_e_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.S_Function_e_P5_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[4];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 4);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.S_Function_e_DWORK5_a[0]);

        /* DWORK2 */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &rtDWork.S_Function_e_DWORK5_b[0]);

        /* DWORK3 */
        ssSetDWorkWidth(rts, 2, 2);
        ssSetDWorkDataType(rts, 2,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 2, 0);
        ssSetDWork(rts, 2, &rtDWork.S_Function_e_DWORK5_c[0]);

        /* DWORK4 */
        ssSetDWorkWidth(rts, 3, 2);
        ssSetDWorkDataType(rts, 3,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 3, 0);
        ssSetDWork(rts, 3, &rtDWork.S_Function_e_DWORK5_d[0]);
      }

      /* registration */
      scomricianlos2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S30>/S-Function (scommultwithprop2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[138];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[2];

        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Variable_Fraction_b[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 2;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 3840);
        }

        /* port 1 */
        {

          static creal_T const *sfcnUPtrs[3840];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u1 = &rtB.S_Function_e[0];

            for (i1=0; i1 < 3840; i1++) {
              sfcnUPtrs[i1] = &u1[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 2;
          _ssSetInputPortDimensionsPtr(rts, 1, dimensions);
          _ssSetInputPortNumDimensions(rts, 1, 2);
          ssSetInputPortWidth(rts, 1, 3840);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 2;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 3840);
          ssSetOutputPortSignal(rts, 0, ((creal_T *) &rtB.S_Function_f[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Multiply with  back propagation/S-Function");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[3];

        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.S_Function_f_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.S_Function_f_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.S_Function_f_P3_Size[0]);
      }

      /* registration */
      scommultwithprop2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 3840);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetInputPortWidth(rts, 1, 3840);
      ssSetInputPortDataType(rts, 1, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 1, 1);
      ssSetInputPortFrameData(rts, 1, 1);

      ssSetOutputPortWidth(rts, 0, 3840);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: IEEE80211g/<S12>/Dynamic AWGN (scomawgnchan2) */
    {
      SimStruct *rts = rtM_IEEE80211g->childSfunctions[139];
      /* timing info */
      static time_T sfcnPeriod[1];
      static time_T sfcnOffset[1];
      static int_T sfcnTsMap[1];

      {
        int_T i;

        for(i = 0; i < 1; i++) {
          sfcnPeriod[i] = sfcnOffset[i] = 0.0;
        }
      }
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      /* Set up the mdlInfo pointer */
      {
        static struct _ssBlkInfo2 _blkInfo2;
        struct _ssBlkInfo2 *blkInfo2 = &_blkInfo2;
        ssSetBlkInfo2Ptr(rts, blkInfo2);
        ssSetRTWSfcnInfo(rts, rtM_IEEE80211g->sfcnInfo);
      }

      /* Allocate memory of model methods 2 */
      {
        static struct _ssSFcnModelMethods2 methods2;
        ssSetModelMethods2(rts, &methods2);
      }

      /* inputs */
      {
        static struct _ssPortInputs inputPortInfo[3];

        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts, &inputPortInfo[0]);

        /* port 0 */
        {

          static creal_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u0 = &rtB.Multiport_Switch_a[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetInputPortNumDimensions(rts, 0, 2);
          ssSetInputPortWidth(rts, 0, 1920);
        }

        /* port 1 */
        {

          static creal_T const *sfcnUPtrs[1920];
          static int_T dimensions[2];
          {
            int_T i1;

            const creal_T *u1 = &rtB.Random_Source_a[0];

            for (i1=0; i1 < 1920; i1++) {
              sfcnUPtrs[i1] = &u1[i1];
            }
          }
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetInputPortDimensionsPtr(rts, 1, dimensions);
          _ssSetInputPortNumDimensions(rts, 1, 2);
          ssSetInputPortWidth(rts, 1, 1920);
        }

        /* port 2 */
        {

          static real_T const *sfcnUPtrs[1];
          sfcnUPtrs[0] = &rtB.Math_Function_a;
          ssSetInputPortSignalPtrs(rts, 2, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }
      }

      /* outputs */
      {
        static struct _ssPortOutputs outputPortInfo[1];
        _ssSetNumOutputPorts(rts, 1);
        ssSetPortInfoForOutputs(rts, &outputPortInfo[0]);
        /* port 0 */
        {
          static int_T dimensions[2];
          dimensions[0] = 1920;
          dimensions[1] = 1;
          _ssSetOutputPortDimensionsPtr(rts, 0, dimensions);
          _ssSetOutputPortNumDimensions(rts, 0, 2);
          ssSetOutputPortWidth(rts, 0, 1920);
          ssSetOutputPortSignal(rts, 0, ((creal_T *) &rtB.Dynamic_AWGN[0]));
        }
      }
      /* path info */
      ssSetModelName(rts, "Dynamic AWGN");
      ssSetPath(rts,
       "IEEE80211g/Channel/Multipath channel/AWGN Channel/Dynamic AWGN");
      ssSetRTModel(rts,rtM_IEEE80211g);
      ssSetParentSS(rts, NULL);
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        static mxArray *sfcnParams[6];

        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);

        ssSetSFcnParam(rts, 0, &rtP.Dynamic_AWGN_P1_Size[0]);
        ssSetSFcnParam(rts, 1, &rtP.Dynamic_AWGN_P2_Size[0]);
        ssSetSFcnParam(rts, 2, &rtP.Dynamic_AWGN_P3_Size[0]);
        ssSetSFcnParam(rts, 3, &rtP.Dynamic_AWGN_P4_Size[0]);
        ssSetSFcnParam(rts, 4, &rtP.Dynamic_AWGN_P5_Size[0]);
        ssSetSFcnParam(rts, 5, &rtP.Dynamic_AWGN_P6_Size[0]);
      }

      /* work vectors */
      {
        static struct _ssDWorkRecord dWorkRecord[1];

        ssSetSFcnDWork(rts, dWorkRecord);
        _ssSetNumDWork(rts, 1);

        /* DWORK1 */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &rtDWork.Dynamic_AWGN_DWORK2);
      }

      /* registration */
      scomawgnchan2(rts);

      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 7.68E-005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */

      ssSetInputPortWidth(rts, 0, 1920);
      ssSetInputPortDataType(rts, 0, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 0, 1);
      ssSetInputPortFrameData(rts, 0, 1);

      ssSetInputPortWidth(rts, 1, 1920);
      ssSetInputPortDataType(rts, 1, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 1, 1);
      ssSetInputPortFrameData(rts, 1, 0);

      ssSetInputPortWidth(rts, 2, 1);
      ssSetInputPortDataType(rts, 2, SS_DOUBLE);
      ssSetInputPortComplexSignal(rts, 2, 0);
      ssSetInputPortFrameData(rts, 2, 0);

      ssSetOutputPortWidth(rts, 0, 1920);
      ssSetOutputPortDataType(rts, 0, SS_DOUBLE);
      ssSetOutputPortComplexSignal(rts, 0, 1);
      ssSetOutputPortFrameData(rts, 0, 1);

      ssSetNumNonsampledZCs(rts, 0);
      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }
  }

  return rtM_IEEE80211g;
}

