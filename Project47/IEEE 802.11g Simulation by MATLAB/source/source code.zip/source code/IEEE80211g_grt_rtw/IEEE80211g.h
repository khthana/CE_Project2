/*
 * IEEE80211g.h
 *
 * Real-Time Workshop code generation for Simulink model "IEEE80211g.mdl".
 *
 * Model Version                        : 1.100
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Tue Apr 19 05:23:12 2005
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Tue Apr 19 05:23:14 2005
 */

#ifndef _RTW_HEADER_IEEE80211g_h_
# define _RTW_HEADER_IEEE80211g_h_

#include <limits.h>
#include "tmwtypes.h"
#ifndef _IEEE80211g_COMMON_INCLUDES_
# define _IEEE80211g_COMMON_INCLUDES_
#include <math.h>
#include <string.h>

#include "simstruc.h"
#include "simstruc_types.h"
#include "rt_logging.h"
#include "rtlibsrc.h"

#endif                                  /* _IEEE80211g_COMMON_INCLUDES_ */

#include "IEEE80211g_types.h"

#define MODEL_NAME                      IEEE80211g
#define NSAMPLE_TIMES                   (2)                      /* Number of sample times */
#define NINPUTS                         (0)                      /* Number of model inputs */
#define NOUTPUTS                        (0)                      /* Number of model outputs */
#define NBLOCKIO                        (186)                    /* Number of data output port signals */
#define NUM_ZC_EVENTS                   (0)                      /* Number of zero-crossing events */

#ifndef NCSTATES
# define NCSTATES (0)                   /* Number of continuous states */
#elif NCSTATES != 0
# error Invalid specification of NCSTATES defined in compiler command
#endif

/* Intrinsic types */
#ifndef POINTER_T
# define POINTER_T
typedef void * pointer_T;
#endif

/* Block signals (auto storage) */
typedef struct _BlockIO {
  creal_T Merge1[960];                  /* '<S99>/Merge1' */
  creal_T Constant_d[20];               /* '<S105>/Constant' */
  creal_T Variable_Fraction_a[1920];    /* '<S20>/Variable Fractional Delay' */
  creal_T S_Function_a_o2[1920];        /* '<S22>/S-Function' */
  creal_T S_Function_b[1920];           /* '<S23>/S-Function' */
  creal_T S_Function_c[1920];           /* '<S21>/S-Function' */
  creal_T Variable_Fraction_b[3840];    /* '<S29>/Variable Fractional Delay' */
  creal_T S_Function_d_o2[3840];        /* '<S31>/S-Function' */
  creal_T S_Function_e[3840];           /* '<S32>/S-Function' */
  creal_T S_Function_f[3840];           /* '<S30>/S-Function' */
  creal_T Multiport_Switch_a[1920];     /* '<S11>/Multiport Switch' */
  creal_T Random_Source_a[1920];        /* '<S12>/Random Source' */
  creal_T Dynamic_AWGN[1920];           /* '<S12>/Dynamic AWGN' */
  creal_T Product3[52];                 /* '<S92>/Product3' */
  creal_T Reshape3[960];                /* '<S53>/Reshape3' */
  creal_T Rectangular_QAM_Modula_x[960]; /* '<S121>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_w[960]; /* '<S120>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_v[960]; /* '<S119>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_u[960]; /* '<S118>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_t[960]; /* '<S117>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_s[960]; /* '<S116>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_r[960]; /* '<S115>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_q[960]; /* '<S114>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_p[960]; /* '<S113>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_o[960]; /* '<S112>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_n[960]; /* '<S111>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_m[960]; /* '<S110>/Rectangular QAM Modulator Baseband' */
  creal_T Rectangular_QAM_Modula_l[960]; /* '<S66>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_ad[960];                  /* '<S66>/Sum' */
  creal_T Rectangular_QAM_Modula_k[960]; /* '<S65>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_ab[960];                  /* '<S65>/Sum' */
  creal_T Rectangular_QAM_Modula_j[960]; /* '<S64>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_z[960];                   /* '<S64>/Sum' */
  creal_T Rectangular_QAM_Modula_i[960]; /* '<S63>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_x[960];                   /* '<S63>/Sum' */
  creal_T Rectangular_QAM_Modula_h[960]; /* '<S62>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_v[960];                   /* '<S62>/Sum' */
  creal_T Rectangular_QAM_Modula_g[960]; /* '<S61>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_t[960];                   /* '<S61>/Sum' */
  creal_T Rectangular_QAM_Modula_f[960]; /* '<S60>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_r[960];                   /* '<S60>/Sum' */
  creal_T Rectangular_QAM_Modula_e[960]; /* '<S59>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_p[960];                   /* '<S59>/Sum' */
  creal_T Rectangular_QAM_Modula_d[960]; /* '<S58>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_n[960];                   /* '<S58>/Sum' */
  creal_T Rectangular_QAM_Modula_c[960]; /* '<S57>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_l[960];                   /* '<S57>/Sum' */
  creal_T Rectangular_QAM_Modula_b[960]; /* '<S56>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_j[960];                   /* '<S56>/Sum' */
  creal_T Rectangular_QAM_Modula_a[960]; /* '<S55>/Rectangular QAM Modulator Baseband1' */
  creal_T Sum_h[960];                   /* '<S55>/Sum' */
  creal_T Constant_k;                   /* '<S33>/Constant' */
  creal_T Inherit_Complexity_b[4];      /* '<S33>/Inherit Complexity' */
  creal_T Doppler_Filter_b[4];          /* '<S33>/Doppler Filter' */
  creal_T FIR_Rate_Conversi_j[4500];    /* '<S33>/FIR Rate Conversion4' */
  creal_T Constant_j;                   /* '<S24>/Constant' */
  creal_T Inherit_Complexity_a[2];      /* '<S24>/Inherit Complexity' */
  creal_T Doppler_Filter_a[2];          /* '<S24>/Doppler Filter' */
  creal_T FIR_Rate_Conversi_e[2250];    /* '<S24>/FIR Rate Conversion4' */
  real_T Relational_Operator1_a[18];    /* '<S108>/Relational Operator1' */
  real_T Unbuffer[18];                  /* '<S108>/Unbuffer' */
  real_T Buffer[4320];                  /* '<S97>/Buffer' */
  real_T PN_Sequence_Generator[20];     /* '<S101>/PN Sequence Generator' */
  real_T Math_Function_a;               /* '<S17>/Math Function' */
  real_T Integer_Delay2;                /* '<S1>/Integer Delay2' */
  real_T Width_a;                       /* '<S39>/Width' */
  real_T Width_b;                       /* '<S40>/Width' */
  real_T Width_c;                       /* '<S41>/Width' */
  real_T Width_d;                       /* '<S42>/Width' */
  real_T Concatenate[17292];            /* '<S38>/Concatenate' */
  real_T Add1;                          /* '<S1>/Add1' */
  real_T General_Block_Interleaver_x[960]; /* '<S121>/General Block Interleaver' */
  real_T General_Block_Interleaver_v[5760]; /* '<S120>/General Block Interleaver' */
  real_T General_Block_Interleaver_t[5760]; /* '<S119>/General Block Interleaver' */
  real_T General_Block_Interleaver_r[3840]; /* '<S118>/General Block Interleaver' */
  real_T General_Block_Interleaver_p[3840]; /* '<S117>/General Block Interleaver' */
  real_T General_Block_Interleaver_n[1920]; /* '<S116>/General Block Interleaver' */
  real_T General_Block_Interleaver_l[1920]; /* '<S115>/General Block Interleaver' */
  real_T General_Block_Interleaver_j[960]; /* '<S114>/General Block Interleaver' */
  real_T General_Block_Interleaver_h[1920]; /* '<S113>/General Block Interleaver' */
  real_T General_Block_Interleaver_f[1920]; /* '<S112>/General Block Interleaver' */
  real_T General_Block_Interleaver_d[1920]; /* '<S111>/General Block Interleaver' */
  real_T General_Block_Interleaver_b[960]; /* '<S110>/General Block Interleaver' */
  real_T Relational_Operator_b[240];    /* '<S107>/Relational Operator' */
  real_T Rectangular_QAM_Demod_l[960]; /* '<S66>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_l[720];       /* '<S66>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_k[5760]; /* '<S65>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_k[4320];      /* '<S65>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_j[5760]; /* '<S64>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_j[3840];      /* '<S64>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_i[3840]; /* '<S63>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_i[2880];      /* '<S63>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_h[3840]; /* '<S62>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_h[1920];      /* '<S62>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_g[1920]; /* '<S61>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_g[1440];      /* '<S61>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_f[1920]; /* '<S60>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_f[960];       /* '<S60>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_e[960]; /* '<S59>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_e[720];       /* '<S59>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_d[1920]; /* '<S58>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_d[1440];      /* '<S58>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_c[1920]; /* '<S57>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_c[1440];      /* '<S57>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_b[1920]; /* '<S56>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_b[1440];      /* '<S56>/Viterbi Decoder1' */
  real_T Rectangular_QAM_Demod_a[960]; /* '<S55>/Rectangular QAM Demodulator Baseband' */
  real_T Viterbi_Decoder1_a[480];       /* '<S55>/Viterbi Decoder1' */
  real_T Zero_Pad_m[720];               /* '<S121>/Zero Pad' */
  real_T Convolutional_Encoder1_l[1440]; /* '<S121>/Convolutional Encoder1' */
  real_T P2_Puncture_l[960];            /* '<S121>/P2 Puncture' */
  real_T General_Block_Interleaver_w[960]; /* '<S133>/General Block Interleaver' */
  real_T Zero_Pad_l[4320];              /* '<S120>/Zero Pad' */
  real_T Convolutional_Encoder1_k[8640]; /* '<S120>/Convolutional Encoder1' */
  real_T P2_Puncture_k[5760];           /* '<S120>/P2 Puncture' */
  real_T General_Block_Interleaver_u[5760]; /* '<S132>/General Block Interleaver' */
  real_T Zero_Pad_k[3840];              /* '<S119>/Zero Pad' */
  real_T Convolutional_Encoder1_j[7680]; /* '<S119>/Convolutional Encoder1' */
  real_T P2_Puncture_j[5760];           /* '<S119>/P2 Puncture' */
  real_T General_Block_Interleaver_s[5760]; /* '<S131>/General Block Interleaver' */
  real_T Zero_Pad_j[2880];              /* '<S118>/Zero Pad' */
  real_T Convolutional_Encoder1_i[5760]; /* '<S118>/Convolutional Encoder1' */
  real_T P2_Puncture_i[3840];           /* '<S118>/P2 Puncture' */
  real_T General_Block_Interleaver_q[3840]; /* '<S130>/General Block Interleaver' */
  real_T Zero_Pad_i[1920];              /* '<S117>/Zero Pad' */
  real_T P2_Puncture_h[3840];           /* '<S117>/P2 Puncture' */
  real_T Zero_Pad_h[1440];              /* '<S116>/Zero Pad' */
  real_T Convolutional_Encoder1_g[2880]; /* '<S116>/Convolutional Encoder1' */
  real_T P2_Puncture_g[1920];           /* '<S116>/P2 Puncture' */
  real_T General_Block_Interleaver_m[1920]; /* '<S128>/General Block Interleaver' */
  real_T Zero_Pad_g[960];               /* '<S115>/Zero Pad' */
  real_T P2_Puncture_f[1920];           /* '<S115>/P2 Puncture' */
  real_T Zero_Pad_f[720];               /* '<S114>/Zero Pad' */
  real_T Convolutional_Encoder1_e[1440]; /* '<S114>/Convolutional Encoder1' */
  real_T P2_Puncture_e[960];            /* '<S114>/P2 Puncture' */
  real_T General_Block_Interleaver_i[960]; /* '<S126>/General Block Interleaver' */
  real_T Zero_Pad_e[1440];              /* '<S113>/Zero Pad' */
  real_T Convolutional_Encoder1_d[2880]; /* '<S113>/Convolutional Encoder1' */
  real_T P2_Puncture_d[1920];           /* '<S113>/P2 Puncture' */
  real_T General_Block_Interleaver_g[1920]; /* '<S125>/General Block Interleaver' */
  real_T Zero_Pad_d[1440];              /* '<S112>/Zero Pad' */
  real_T Convolutional_Encoder1_c[2880]; /* '<S112>/Convolutional Encoder1' */
  real_T P2_Puncture_c[1920];           /* '<S112>/P2 Puncture' */
  real_T General_Block_Interleaver_e[1920]; /* '<S124>/General Block Interleaver' */
  real_T Zero_Pad_c[1440];              /* '<S111>/Zero Pad' */
  real_T Convolutional_Encoder1_b[2880]; /* '<S111>/Convolutional Encoder1' */
  real_T P2_Puncture_b[1920];           /* '<S111>/P2 Puncture' */
  real_T General_Block_Interleaver_c[1920]; /* '<S123>/General Block Interleaver' */
  real_T Zero_Pad_b[480];               /* '<S110>/Zero Pad' */
  real_T P2_Puncture_a[960];            /* '<S110>/P2 Puncture' */
  real_T General_Block_Deinterleaver_w[960]; /* '<S66>/General Block Deinterleaver' */
  real_T Insert_Zero4_l[1440];          /* '<S66>/Insert Zero4' */
  real_T General_Block_Deinterleaver_u[5760]; /* '<S65>/General Block Deinterleaver' */
  real_T Insert_Zero4_k[8640];          /* '<S65>/Insert Zero4' */
  real_T General_Block_Deinterleaver_s[5760]; /* '<S64>/General Block Deinterleaver' */
  real_T Insert_Zero4_j[7680];          /* '<S64>/Insert Zero4' */
  real_T General_Block_Deinterleaver_q[3840]; /* '<S63>/General Block Deinterleaver' */
  real_T Insert_Zero4_i[5760];          /* '<S63>/Insert Zero4' */
  real_T General_Block_Deinterleaver_m[1920]; /* '<S61>/General Block Deinterleaver' */
  real_T Insert_Zero4_g[2880];          /* '<S61>/Insert Zero4' */
  real_T General_Block_Deinterleaver_i[960]; /* '<S59>/General Block Deinterleaver' */
  real_T Insert_Zero4_e[1440];          /* '<S59>/Insert Zero4' */
  real_T General_Block_Deinterleaver_g[1920]; /* '<S58>/General Block Deinterleaver' */
  real_T Insert_Zero4_d[2880];          /* '<S58>/Insert Zero4' */
  real_T General_Block_Deinterleaver_e[1920]; /* '<S57>/General Block Deinterleaver' */
  real_T Insert_Zero4_c[2880];          /* '<S57>/Insert Zero4' */
  real_T General_Block_Deinterleaver_c[1920]; /* '<S56>/General Block Deinterleaver' */
  real_T Insert_Zero4_b[2880];          /* '<S56>/Insert Zero4' */
  real_T temp168[3840];                 /* '<S129>/General Block Interleaver' */
  real_T temp169[1920];                 /* '<S127>/General Block Interleaver' */
  real_T temp170[960];                  /* '<S122>/General Block Interleaver' */
  real_T temp171[960];                  /* '<S90>/General Block Deinterleaver' */
  real_T temp172[5760];                 /* '<S88>/General Block Deinterleaver' */
  real_T temp173[5760];                 /* '<S86>/General Block Deinterleaver' */
  real_T temp174[3840];                 /* '<S84>/General Block Deinterleaver' */
  real_T temp175[3840];                 /* '<S82>/General Block Deinterleaver' */
  real_T temp176[3840];                 /* '<S62>/Insert Zero4' */
  real_T temp177[1920];                 /* '<S80>/General Block Deinterleaver' */
  real_T temp178[1920];                 /* '<S78>/General Block Deinterleaver' */
  real_T temp179[1920];                 /* '<S60>/Insert Zero4' */
  real_T temp180[960];                  /* '<S76>/General Block Deinterleaver' */
  real_T temp181[1920];                 /* '<S74>/General Block Deinterleaver' */
  real_T temp182[1920];                 /* '<S72>/General Block Deinterleaver' */
  real_T temp183[1920];                 /* '<S70>/General Block Deinterleaver' */
  real_T temp184[960];                  /* '<S68>/General Block Deinterleaver' */
  real_T temp185[960];                  /* '<S55>/Insert Zero4' */
} BlockIO;

/* Block states (auto storage) for system: '<Root>' */
typedef struct D_Work_tag {
  creal_T Doppler_Filter_a_FILT_STATES[8]; /* <S24>/Doppler Filter */
  creal_T Doppler_Filter_b_FILT_STATES[16]; /* <S33>/Doppler Filter */
  creal_T Variable_Fraction_a_BUFF[8]; /* <S20>/Variable Fractional Delay */
  creal_T Variable_Fraction_b_BUFF[18]; /* <S29>/Variable Fractional Delay */
  real_T Integer_Delay1_BUFF[2];        /* <Root>/Integer Delay1 */
  real_T Buffer_CircBuff[8640];         /* <S97>/Buffer */
  real_T Integer_Delay2_BUFF[2];        /* <S1>/Integer Delay2 */
  creal_T Rectangular_QAM_Demod_a_DWORK_a[2]; /* <S55>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_b_DWORK_a[4]; /* <S56>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_c_DWORK_a[4]; /* <S57>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_d_DWORK_a[4]; /* <S58>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_e_DWORK_a[2]; /* <S59>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_f_DWORK_a[4]; /* <S60>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_g_DWORK_a[4]; /* <S61>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_h_DWORK_a[16]; /* <S62>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_i_DWORK_a[16]; /* <S63>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_j_DWORK_a[64]; /* <S64>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_k_DWORK_a[64]; /* <S65>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_l_DWORK_a[2]; /* <S66>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_a_DWORK_b; /* <S55>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_b_DWORK_b; /* <S56>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_c_DWORK_b; /* <S57>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_d_DWORK_b; /* <S58>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_e_DWORK_b; /* <S59>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_f_DWORK_b; /* <S60>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_g_DWORK_b; /* <S61>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_h_DWORK_b; /* <S62>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_i_DWORK_b; /* <S63>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_j_DWORK_b; /* <S64>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_k_DWORK_b; /* <S65>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_l_DWORK_b; /* <S66>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_a_DWORK_c; /* <S55>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_b_DWORK_c; /* <S56>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_c_DWORK_c; /* <S57>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_d_DWORK_c; /* <S58>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_e_DWORK_c; /* <S59>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_f_DWORK_c; /* <S60>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_g_DWORK_c; /* <S61>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_h_DWORK_c; /* <S62>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_i_DWORK_c; /* <S63>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_j_DWORK_c; /* <S64>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_k_DWORK_c; /* <S65>/Rectangular QAM Demodulator Baseband */
  creal_T Rectangular_QAM_Demod_l_DWORK_c; /* <S66>/Rectangular QAM Demodulator Baseband */
  creal_T FIR_Rate_Conversi_a_PartialSums[3]; /* <S24>/FIR Rate Conversion */
  creal_T FIR_Rate_Conversi_f_PartialSums[6]; /* <S33>/FIR Rate Conversion */
  creal_T FIR_Rate_Conversi_a_InBuf[7]; /* <S24>/FIR Rate Conversion */
  creal_T FIR_Rate_Conversi_f_InBuf[14]; /* <S33>/FIR Rate Conversion */
  creal_T FIR_Rate_Conversi_a_OutBuf[3]; /* <S24>/FIR Rate Conversion */
  creal_T FIR_Rate_Conversi_f_OutBuf[6]; /* <S33>/FIR Rate Conversion */
  creal_T Rectangular_QAM_Modula_m_DWOR_a[2]; /* <S110>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_n_DWOR_a[4]; /* <S111>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_o_DWOR_a[4]; /* <S112>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_p_DWOR_a[4]; /* <S113>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_q_DWOR_a[2]; /* <S114>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_r_DWOR_a[4]; /* <S115>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_s_DWOR_a[4]; /* <S116>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_t_DWOR_a[16]; /* <S117>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_u_DWOR_a[16]; /* <S118>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_v_DWOR_a[64]; /* <S119>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_w_DWOR_a[64]; /* <S120>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_x_DWOR_a[2]; /* <S121>/Rectangular QAM Modulator Baseband */
  creal_T FIR_Rate_Conversi_b_PartialSums[3]; /* <S24>/FIR Rate Conversion1 */
  creal_T FIR_Rate_Conversi_g_PartialSums[6]; /* <S33>/FIR Rate Conversion1 */
  creal_T Rectangular_QAM_Modula_m_DWOR_b[960]; /* <S110>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_n_DWOR_b[960]; /* <S111>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_o_DWOR_b[960]; /* <S112>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_p_DWOR_b[960]; /* <S113>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_q_DWOR_b[960]; /* <S114>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_r_DWOR_b[960]; /* <S115>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_s_DWOR_b[960]; /* <S116>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_t_DWOR_b[960]; /* <S117>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_u_DWOR_b[960]; /* <S118>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_v_DWOR_b[960]; /* <S119>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_w_DWOR_b[960]; /* <S120>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_x_DWOR_b[960]; /* <S121>/Rectangular QAM Modulator Baseband */
  creal_T FIR_Rate_Conversi_b_InBuf[8]; /* <S24>/FIR Rate Conversion1 */
  creal_T FIR_Rate_Conversi_g_InBuf[16]; /* <S33>/FIR Rate Conversion1 */
  creal_T Rectangular_QAM_Modula_m_DWOR_c[960]; /* <S110>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_n_DWOR_c[960]; /* <S111>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_o_DWOR_c[960]; /* <S112>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_p_DWOR_c[960]; /* <S113>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_q_DWOR_c[960]; /* <S114>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_r_DWOR_c[960]; /* <S115>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_s_DWOR_c[960]; /* <S116>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_t_DWOR_c[960]; /* <S117>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_u_DWOR_c[960]; /* <S118>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_v_DWOR_c[960]; /* <S119>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_w_DWOR_c[960]; /* <S120>/Rectangular QAM Modulator Baseband */
  creal_T Rectangular_QAM_Modula_x_DWOR_c[960]; /* <S121>/Rectangular QAM Modulator Baseband */
  creal_T FIR_Rate_Conversi_b_OutBuf[3]; /* <S24>/FIR Rate Conversion1 */
  creal_T FIR_Rate_Conversi_g_OutBuf[6]; /* <S33>/FIR Rate Conversion1 */
  creal_T FIR_Rate_Conversi_c_PartialSums[5]; /* <S24>/FIR Rate Conversion2 */
  creal_T FIR_Rate_Conversi_h_PartialSums[10]; /* <S33>/FIR Rate Conversion2 */
  creal_T FIR_Rate_Conversi_c_InBuf[9]; /* <S24>/FIR Rate Conversion2 */
  creal_T FIR_Rate_Conversi_h_InBuf[18]; /* <S33>/FIR Rate Conversion2 */
  creal_T FIR_Rate_Conversi_c_OutBuf[5]; /* <S24>/FIR Rate Conversion2 */
  creal_T FIR_Rate_Conversi_h_OutBuf[10]; /* <S33>/FIR Rate Conversion2 */
  creal_T FIR_Rate_Conversi_d_PartialSums[5]; /* <S24>/FIR Rate Conversion3 */
  creal_T FIR_Rate_Conversi_i_PartialSums[10]; /* <S33>/FIR Rate Conversion3 */
  creal_T FIR_Rate_Conversi_d_InBuf[11]; /* <S24>/FIR Rate Conversion3 */
  creal_T FIR_Rate_Conversi_i_InBuf[22]; /* <S33>/FIR Rate Conversion3 */
  creal_T FIR_Rate_Conversi_d_OutBuf[5]; /* <S24>/FIR Rate Conversion3 */
  creal_T FIR_Rate_Conversi_i_OutBuf[10]; /* <S33>/FIR Rate Conversion3 */
  creal_T Rectangular_QAM_Modula_a_DWOR_a[2]; /* <S55>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_b_DWOR_a[4]; /* <S56>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_c_DWOR_a[4]; /* <S57>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_d_DWOR_a[4]; /* <S58>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_e_DWOR_a[2]; /* <S59>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_f_DWOR_a[4]; /* <S60>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_g_DWOR_a[4]; /* <S61>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_h_DWOR_a[16]; /* <S62>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_i_DWOR_a[16]; /* <S63>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_j_DWOR_a[64]; /* <S64>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_k_DWOR_a[64]; /* <S65>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_l_DWOR_a[2]; /* <S66>/Rectangular QAM Modulator Baseband1 */
  creal_T FIR_Rate_Conversi_e_PartialSums[5]; /* <S24>/FIR Rate Conversion4 */
  creal_T FIR_Rate_Conversi_j_PartialSums[10]; /* <S33>/FIR Rate Conversion4 */
  creal_T Rectangular_QAM_Modula_a_DWOR_b[960]; /* <S55>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_b_DWOR_b[960]; /* <S56>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_c_DWOR_b[960]; /* <S57>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_d_DWOR_b[960]; /* <S58>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_e_DWOR_b[960]; /* <S59>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_f_DWOR_b[960]; /* <S60>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_g_DWOR_b[960]; /* <S61>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_h_DWOR_b[960]; /* <S62>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_i_DWOR_b[960]; /* <S63>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_j_DWOR_b[960]; /* <S64>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_k_DWOR_b[960]; /* <S65>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_l_DWOR_b[960]; /* <S66>/Rectangular QAM Modulator Baseband1 */
  creal_T FIR_Rate_Conversi_e_InBuf[12]; /* <S24>/FIR Rate Conversion4 */
  creal_T FIR_Rate_Conversi_j_InBuf[24]; /* <S33>/FIR Rate Conversion4 */
  creal_T Rectangular_QAM_Modula_a_DWOR_c[960]; /* <S55>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_b_DWOR_c[960]; /* <S56>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_c_DWOR_c[960]; /* <S57>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_d_DWOR_c[960]; /* <S58>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_e_DWOR_c[960]; /* <S59>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_f_DWOR_c[960]; /* <S60>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_g_DWOR_c[960]; /* <S61>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_h_DWOR_c[960]; /* <S62>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_i_DWOR_c[960]; /* <S63>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_j_DWOR_c[960]; /* <S64>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_k_DWOR_c[960]; /* <S65>/Rectangular QAM Modulator Baseband1 */
  creal_T Rectangular_QAM_Modula_l_DWOR_c[960]; /* <S66>/Rectangular QAM Modulator Baseband1 */
  creal_T FIR_Rate_Conversi_e_OutBuf[5]; /* <S24>/FIR Rate Conversion4 */
  creal_T FIR_Rate_Conversi_j_OutBuf[10]; /* <S33>/FIR Rate Conversion4 */
  creal_T S_Function_a_DWORK4[2250];    /* <S22>/S-Function */
  creal_T S_Function_d_DWORK4[4500];    /* <S31>/S-Function */
  creal_T Mean_DWORK2[208];             /* <S92>/Mean */
  creal_T Variance_DWORK2[1920];        /* <S11>/Variance */
  real_T Rectangular_QAM_Demod_a_DWORK_d[3]; /* <S55>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_b_DWORK_d[5]; /* <S56>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_c_DWORK_d[5]; /* <S57>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_d_DWORK_d[5]; /* <S58>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_e_DWORK_d[3]; /* <S59>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_f_DWORK_d[5]; /* <S60>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_g_DWORK_d[5]; /* <S61>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_h_DWORK_d[17]; /* <S62>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_i_DWORK_d[17]; /* <S63>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_j_DWORK_d[65]; /* <S64>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_k_DWORK_d[65]; /* <S65>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_l_DWORK_d[3]; /* <S66>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_a_DWORK_e; /* <S55>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_b_DWORK_e; /* <S56>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_c_DWORK_e; /* <S57>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_d_DWORK_e; /* <S58>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_e_DWORK_e; /* <S59>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_f_DWORK_e; /* <S60>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_g_DWORK_e; /* <S61>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_h_DWORK_e; /* <S62>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_i_DWORK_e; /* <S63>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_j_DWORK_e; /* <S64>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_k_DWORK_e; /* <S65>/Rectangular QAM Demodulator Baseband */
  real_T Rectangular_QAM_Demod_l_DWORK_e; /* <S66>/Rectangular QAM Demodulator Baseband */
  real_T Random_Source_d_STATE_DWORK[35]; /* <S107>/Random Source */
  real_T Rectangular_QAM_Modula_m_DWOR_d; /* <S110>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_n_DWOR_d; /* <S111>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_o_DWOR_d; /* <S112>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_p_DWOR_d; /* <S113>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_q_DWOR_d; /* <S114>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_r_DWOR_d; /* <S115>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_s_DWOR_d; /* <S116>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_t_DWOR_d; /* <S117>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_u_DWOR_d; /* <S118>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_v_DWOR_d; /* <S119>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_w_DWOR_d; /* <S120>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_x_DWOR_d; /* <S121>/Rectangular QAM Modulator Baseband */
  real_T Rectangular_QAM_Modula_a_DWOR_d; /* <S55>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_b_DWOR_d; /* <S56>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_c_DWOR_d; /* <S57>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_d_DWOR_d; /* <S58>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_e_DWOR_d; /* <S59>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_f_DWOR_d; /* <S60>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_g_DWOR_d; /* <S61>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_h_DWOR_d; /* <S62>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_i_DWOR_d; /* <S63>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_j_DWOR_d; /* <S64>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_k_DWOR_d; /* <S65>/Rectangular QAM Modulator Baseband1 */
  real_T Rectangular_QAM_Modula_l_DWOR_d; /* <S66>/Rectangular QAM Modulator Baseband1 */
  real_T Viterbi_Decoder1_a_DWORK7_a[4]; /* <S55>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_b_DWORK7_a[4]; /* <S56>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_c_DWORK7_a[4]; /* <S57>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_d_DWORK7_a[4]; /* <S58>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_e_DWORK7_a[4]; /* <S59>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_f_DWORK7_a[4]; /* <S60>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_g_DWORK7_a[4]; /* <S61>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_h_DWORK7_a[4]; /* <S62>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_i_DWORK7_a[4]; /* <S63>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_j_DWORK7_a[4]; /* <S64>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_k_DWORK7_a[4]; /* <S65>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_l_DWORK7_a[4]; /* <S66>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_a_DWORK7_b[64]; /* <S55>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_b_DWORK7_b[64]; /* <S56>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_c_DWORK7_b[64]; /* <S57>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_d_DWORK7_b[64]; /* <S58>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_e_DWORK7_b[64]; /* <S59>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_f_DWORK7_b[64]; /* <S60>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_g_DWORK7_b[64]; /* <S61>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_h_DWORK7_b[64]; /* <S62>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_i_DWORK7_b[64]; /* <S63>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_j_DWORK7_b[64]; /* <S64>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_k_DWORK7_b[64]; /* <S65>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_l_DWORK7_b[64]; /* <S66>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_a_DWORK7_c[64]; /* <S55>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_b_DWORK7_c[64]; /* <S56>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_c_DWORK7_c[64]; /* <S57>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_d_DWORK7_c[64]; /* <S58>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_e_DWORK7_c[64]; /* <S59>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_f_DWORK7_c[64]; /* <S60>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_g_DWORK7_c[64]; /* <S61>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_h_DWORK7_c[64]; /* <S62>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_i_DWORK7_c[64]; /* <S63>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_j_DWORK7_c[64]; /* <S64>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_k_DWORK7_c[64]; /* <S65>/Viterbi Decoder1 */
  real_T Viterbi_Decoder1_l_DWORK7_c[64]; /* <S66>/Viterbi Decoder1 */
  real_T S_Function_b_DWORK5_a;         /* <S23>/S-Function */
  real_T S_Function_b_DWORK5_b;         /* <S23>/S-Function */
  real_T S_Function_b_DWORK5_c;         /* <S23>/S-Function */
  real_T S_Function_b_DWORK5_d;         /* <S23>/S-Function */
  real_T S_Function_e_DWORK5_a[2];      /* <S32>/S-Function */
  real_T S_Function_e_DWORK5_b[2];      /* <S32>/S-Function */
  real_T S_Function_e_DWORK5_c[2];      /* <S32>/S-Function */
  real_T S_Function_e_DWORK5_d[2];      /* <S32>/S-Function */
  real_T Dynamic_AWGN_DWORK2;           /* <S12>/Dynamic AWGN */
  real_T Mean1_DWORK2[208];             /* <S92>/Mean1 */
  real_T RMS_DWORK2[960];               /* <S5>/RMS */
  pointer_T Buffer_IN_BUF_PTR;          /* <S97>/Buffer */
  pointer_T Buffer_OUT_BUF_PTR;         /* <S97>/Buffer */
  void *S_Function_a_PWORK;             /* '<S22>/S-Function' */
  void *S_Function_d_PWORK;             /* '<S31>/S-Function' */
  void *Repeat_PWORK[52];               /* '<S92>/Repeat' */
  struct {
    void *LoggedData;
  } To_Workspace_PWORK;                 /* '<S7>/To Workspace' */
  int32_T Unbuffer_CircBuff;            /* <S108>/Unbuffer */
  int32_T Integer_Delay1_BUFF_OFFSET;   /* <Root>/Integer Delay1 */
  int32_T Rectangular_QAM_Demod_a_DWORK_f[960]; /* <S55>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_b_DWORK_f[1920]; /* <S56>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_c_DWORK_f[1920]; /* <S57>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_d_DWORK_f[1920]; /* <S58>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_e_DWORK_f[960]; /* <S59>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_f_DWORK_f[1920]; /* <S60>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_g_DWORK_f[1920]; /* <S61>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_h_DWORK_f[3840]; /* <S62>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_i_DWORK_f[3840]; /* <S63>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_j_DWORK_f[5760]; /* <S64>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_k_DWORK_f[5760]; /* <S65>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_l_DWORK_f[960]; /* <S66>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_a_DWORK_g; /* <S55>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_b_DWORK_g; /* <S56>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_c_DWORK_g; /* <S57>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_d_DWORK_g; /* <S58>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_e_DWORK_g; /* <S59>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_f_DWORK_g; /* <S60>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_g_DWORK_g; /* <S61>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_h_DWORK_g; /* <S62>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_i_DWORK_g; /* <S63>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_j_DWORK_g; /* <S64>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_k_DWORK_g; /* <S65>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_l_DWORK_g; /* <S66>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_a_DWORK_h; /* <S55>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_b_DWORK_h; /* <S56>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_c_DWORK_h; /* <S57>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_d_DWORK_h; /* <S58>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_e_DWORK_h; /* <S59>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_f_DWORK_h; /* <S60>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_g_DWORK_h; /* <S61>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_h_DWORK_h; /* <S62>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_i_DWORK_h; /* <S63>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_j_DWORK_h; /* <S64>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_k_DWORK_h; /* <S65>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_l_DWORK_h; /* <S66>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_a_DWORK_i; /* <S55>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_b_DWORK_i; /* <S56>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_c_DWORK_i; /* <S57>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_d_DWORK_i; /* <S58>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_e_DWORK_i; /* <S59>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_f_DWORK_i; /* <S60>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_g_DWORK_i; /* <S61>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_h_DWORK_i; /* <S62>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_i_DWORK_i; /* <S63>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_j_DWORK_i; /* <S64>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_k_DWORK_i; /* <S65>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_l_DWORK_i; /* <S66>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_a_DWORK_j; /* <S55>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_b_DWORK_j; /* <S56>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_c_DWORK_j; /* <S57>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_d_DWORK_j; /* <S58>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_e_DWORK_j; /* <S59>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_f_DWORK_j; /* <S60>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_g_DWORK_j; /* <S61>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_h_DWORK_j; /* <S62>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_i_DWORK_j; /* <S63>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_j_DWORK_j; /* <S64>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_k_DWORK_j; /* <S65>/Rectangular QAM Demodulator Baseband */
  int32_T Rectangular_QAM_Demod_l_DWORK_j; /* <S66>/Rectangular QAM Demodulator Baseband */
  int32_T Convolutional_Encoder1_a_DWORK2; /* <S110>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_b_DWORK2; /* <S111>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_c_DWORK2; /* <S112>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_d_DWORK2; /* <S113>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_e_DWORK2; /* <S114>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_f_DWORK2; /* <S115>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_g_DWORK2; /* <S116>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_h_DWORK2; /* <S117>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_i_DWORK2; /* <S118>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_j_DWORK2; /* <S119>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_k_DWORK2; /* <S120>/Convolutional Encoder1 */
  int32_T Convolutional_Encoder1_l_DWORK2; /* <S121>/Convolutional Encoder1 */
  int32_T FIR_Rate_Conversi_a_OutIdx;   /* <S24>/FIR Rate Conversion */
  int32_T FIR_Rate_Conversi_f_OutIdx;   /* <S33>/FIR Rate Conversion */
  int32_T FIR_Rate_Conversi_a_MemIdx;   /* <S24>/FIR Rate Conversion */
  int32_T FIR_Rate_Conversi_f_MemIdx;   /* <S33>/FIR Rate Conversion */
  int32_T FIR_Rate_Conversi_b_OutIdx;   /* <S24>/FIR Rate Conversion1 */
  int32_T FIR_Rate_Conversi_g_OutIdx;   /* <S33>/FIR Rate Conversion1 */
  int32_T FIR_Rate_Conversi_b_MemIdx;   /* <S24>/FIR Rate Conversion1 */
  int32_T FIR_Rate_Conversi_g_MemIdx;   /* <S33>/FIR Rate Conversion1 */
  int32_T Rectangular_QAM_Modula_m_DWOR_e; /* <S110>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_n_DWOR_e; /* <S111>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_o_DWOR_e; /* <S112>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_p_DWOR_e; /* <S113>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_q_DWOR_e; /* <S114>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_r_DWOR_e; /* <S115>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_s_DWOR_e; /* <S116>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_t_DWOR_e; /* <S117>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_u_DWOR_e; /* <S118>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_v_DWOR_e; /* <S119>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_w_DWOR_e; /* <S120>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_x_DWOR_e; /* <S121>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_m_DWOR_f; /* <S110>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_n_DWOR_f; /* <S111>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_o_DWOR_f; /* <S112>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_p_DWOR_f; /* <S113>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_q_DWOR_f; /* <S114>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_r_DWOR_f; /* <S115>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_s_DWOR_f; /* <S116>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_t_DWOR_f; /* <S117>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_u_DWOR_f; /* <S118>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_v_DWOR_f; /* <S119>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_w_DWOR_f; /* <S120>/Rectangular QAM Modulator Baseband */
  int32_T Rectangular_QAM_Modula_x_DWOR_f; /* <S121>/Rectangular QAM Modulator Baseband */
  int32_T FIR_Rate_Conversi_c_OutIdx;   /* <S24>/FIR Rate Conversion2 */
  int32_T FIR_Rate_Conversi_h_OutIdx;   /* <S33>/FIR Rate Conversion2 */
  int32_T FIR_Rate_Conversi_c_MemIdx;   /* <S24>/FIR Rate Conversion2 */
  int32_T FIR_Rate_Conversi_h_MemIdx;   /* <S33>/FIR Rate Conversion2 */
  int32_T FIR_Rate_Conversi_d_OutIdx;   /* <S24>/FIR Rate Conversion3 */
  int32_T FIR_Rate_Conversi_i_OutIdx;   /* <S33>/FIR Rate Conversion3 */
  int32_T FIR_Rate_Conversi_d_MemIdx;   /* <S24>/FIR Rate Conversion3 */
  int32_T FIR_Rate_Conversi_i_MemIdx;   /* <S33>/FIR Rate Conversion3 */
  int32_T FIR_Rate_Conversi_e_OutIdx;   /* <S24>/FIR Rate Conversion4 */
  int32_T FIR_Rate_Conversi_j_OutIdx;   /* <S33>/FIR Rate Conversion4 */
  int32_T FIR_Rate_Conversi_e_MemIdx;   /* <S24>/FIR Rate Conversion4 */
  int32_T FIR_Rate_Conversi_j_MemIdx;   /* <S33>/FIR Rate Conversion4 */
  int32_T Rectangular_QAM_Modula_a_DWOR_e; /* <S55>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_b_DWOR_e; /* <S56>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_c_DWOR_e; /* <S57>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_d_DWOR_e; /* <S58>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_e_DWOR_e; /* <S59>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_f_DWOR_e; /* <S60>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_g_DWOR_e; /* <S61>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_h_DWOR_e; /* <S62>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_i_DWOR_e; /* <S63>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_j_DWOR_e; /* <S64>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_k_DWOR_e; /* <S65>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_l_DWOR_e; /* <S66>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_a_DWOR_f; /* <S55>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_b_DWOR_f; /* <S56>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_c_DWOR_f; /* <S57>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_d_DWOR_f; /* <S58>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_e_DWOR_f; /* <S59>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_f_DWOR_f; /* <S60>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_g_DWOR_f; /* <S61>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_h_DWOR_f; /* <S62>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_i_DWOR_f; /* <S63>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_j_DWOR_f; /* <S64>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_k_DWOR_f; /* <S65>/Rectangular QAM Modulator Baseband1 */
  int32_T Rectangular_QAM_Modula_l_DWOR_f; /* <S66>/Rectangular QAM Modulator Baseband1 */
  int32_T Viterbi_Decoder1_a_DWORK7_d[2240]; /* <S55>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_b_DWORK7_d[2240]; /* <S56>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_c_DWORK7_d[2240]; /* <S57>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_d_DWORK7_d[2240]; /* <S58>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_e_DWORK7_d[2240]; /* <S59>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_f_DWORK7_d[2240]; /* <S60>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_g_DWORK7_d[2240]; /* <S61>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_h_DWORK7_d[2240]; /* <S62>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_i_DWORK7_d[2240]; /* <S63>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_j_DWORK7_d[2240]; /* <S64>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_k_DWORK7_d[2240]; /* <S65>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_l_DWORK7_d[2240]; /* <S66>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_a_DWORK7_e[2240]; /* <S55>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_b_DWORK7_e[2240]; /* <S56>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_c_DWORK7_e[2240]; /* <S57>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_d_DWORK7_e[2240]; /* <S58>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_e_DWORK7_e[2240]; /* <S59>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_f_DWORK7_e[2240]; /* <S60>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_g_DWORK7_e[2240]; /* <S61>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_h_DWORK7_e[2240]; /* <S62>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_i_DWORK7_e[2240]; /* <S63>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_j_DWORK7_e[2240]; /* <S64>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_k_DWORK7_e[2240]; /* <S65>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_l_DWORK7_e[2240]; /* <S66>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_a_DWORK7_f; /* <S55>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_b_DWORK7_f; /* <S56>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_c_DWORK7_f; /* <S57>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_d_DWORK7_f; /* <S58>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_e_DWORK7_f; /* <S59>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_f_DWORK7_f; /* <S60>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_g_DWORK7_f; /* <S61>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_h_DWORK7_f; /* <S62>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_i_DWORK7_f; /* <S63>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_j_DWORK7_f; /* <S64>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_k_DWORK7_f; /* <S65>/Viterbi Decoder1 */
  int32_T Viterbi_Decoder1_l_DWORK7_f; /* <S66>/Viterbi Decoder1 */
  int32_T Buffer_ShiftPerElem;          /* <S97>/Buffer */
  int32_T PN_Sequence_Generator_DWORK4_a[7]; /* <S101>/PN Sequence Generator */
  int32_T PN_Sequence_Generator_DWORK4_b[7]; /* <S101>/PN Sequence Generator */
  int32_T PN_Sequence_Generator_DWORK4_c[7]; /* <S101>/PN Sequence Generator */
  int32_T Variable_Fraction_a_BUFF_OFFSET; /* <S20>/Variable Fractional Delay */
  int32_T Variable_Fraction_b_BUFF_OFFSET; /* <S29>/Variable Fractional Delay */
  int32_T Repeat_REPEAT_CNT;            /* <S92>/Repeat */
  int32_T Repeat_ITERATION_CNT;         /* <S92>/Repeat */
  int32_T Integer_Delay2_BUFF_OFFSET;   /* <S1>/Integer Delay2 */
  uint32_T Random_Source_b_SEED_DWORK; /* <S24>/Random Source */
  uint32_T Random_Source_c_SEED_DWORK[2]; /* <S33>/Random Source */
  uint32_T Random_Source_d_SEED_DWORK; /* <S107>/Random Source */
  uint32_T Random_Source_b_STATE_DWORK[2]; /* <S24>/Random Source */
  uint32_T Random_Source_c_STATE_DWORK[4]; /* <S33>/Random Source */
  uint32_T Random_Source_a_SEED_DWORK; /* <S12>/Random Source */
  uint32_T Random_Source_a_STATE_DWORK[2]; /* <S12>/Random Source */
  int_T S_Function_a_IWORK[5];          /* '<S22>/S-Function' */
  int_T S_Function_d_IWORK[5];          /* '<S31>/S-Function' */
  int_T Binary_sourc_MODE[2];           /* <S97>/Binary source */
  int_T Modulator_1_MODE[2];            /* <S99>/Modulator 1 */
  int_T Modulator_2_MODE[2];            /* <S99>/Modulator 2 */
  int_T Modulator_3_MODE[2];            /* <S99>/Modulator 3 */
  int_T Modulator_4_MODE[2];            /* <S99>/Modulator 4 */
  int_T Modulator_5_MODE[2];            /* <S99>/Modulator 5 */
  int_T Modulator_6_MODE[2];            /* <S99>/Modulator 6 */
  int_T Modulator_7_MODE[2];            /* <S99>/Modulator 7 */
  int_T Modulator_8_MODE[2];            /* <S99>/Modulator 8 */
  int_T Modulator_9_MODE[2];            /* <S99>/Modulator 9 */
  int_T Modulator_10_MODE[2];           /* <S99>/Modulator 10 */
  int_T Modulator_11_MODE[2];           /* <S99>/Modulator 11 */
  int_T Modulator_12_MODE[2];           /* <S99>/Modulator 12 */
  int_T Demodulato_a_MODE[2];           /* <S47>/Demodulator 1 */
  int_T Demodulato_b_MODE[2];           /* <S47>/Demodulator 2 */
  int_T Demodulato_c_MODE[2];           /* <S47>/Demodulator 3 */
  int_T Demodulato_d_MODE[2];           /* <S47>/Demodulator 4 */
  int_T Demodulato_e_MODE[2];           /* <S47>/Demodulator 5 */
  int_T Demodulato_f_MODE[2];           /* <S47>/Demodulator 6 */
  int_T Demodulato_g_MODE[2];           /* <S47>/Demodulator 7 */
  int_T Demodulato_h_MODE[2];           /* <S47>/Demodulator 8 */
  int_T Demodulato_i_MODE[2];           /* <S47>/Demodulator 9 */
  int_T Demodulato_j_MODE[2];           /* <S47>/Demodulator 10 */
  int_T Demodulato_k_MODE[2];           /* <S47>/Demodulator 11 */
  int_T Demodulato_l_MODE[2];           /* <S47>/Demodulator 12 */
  boolean_T Rectangular_QAM_Demod_a_DWORK_k; /* <S55>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_b_DWORK_k; /* <S56>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_c_DWORK_k; /* <S57>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_d_DWORK_k; /* <S58>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_e_DWORK_k; /* <S59>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_f_DWORK_k; /* <S60>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_g_DWORK_k; /* <S61>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_h_DWORK_k; /* <S62>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_i_DWORK_k; /* <S63>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_j_DWORK_k; /* <S64>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_k_DWORK_k; /* <S65>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Demod_l_DWORK_k; /* <S66>/Rectangular QAM Demodulator Baseband */
  boolean_T Rectangular_QAM_Modula_m_DWOR_g; /* <S110>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_n_DWOR_g; /* <S111>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_o_DWOR_g; /* <S112>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_p_DWOR_g; /* <S113>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_q_DWOR_g; /* <S114>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_r_DWOR_g; /* <S115>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_s_DWOR_g; /* <S116>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_t_DWOR_g; /* <S117>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_u_DWOR_g; /* <S118>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_v_DWOR_g; /* <S119>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_w_DWOR_g; /* <S120>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_x_DWOR_g; /* <S121>/Rectangular QAM Modulator Baseband */
  boolean_T Rectangular_QAM_Modula_a_DWOR_g; /* <S55>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_b_DWOR_g; /* <S56>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_c_DWOR_g; /* <S57>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_d_DWOR_g; /* <S58>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_e_DWOR_g; /* <S59>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_f_DWOR_g; /* <S60>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_g_DWOR_g; /* <S61>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_h_DWOR_g; /* <S62>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_i_DWOR_g; /* <S63>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_j_DWOR_g; /* <S64>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_k_DWOR_g; /* <S65>/Rectangular QAM Modulator Baseband1 */
  boolean_T Rectangular_QAM_Modula_l_DWOR_g; /* <S66>/Rectangular QAM Modulator Baseband1 */
} D_Work;

/* Parameters (auto storage) */
struct _Parameters {
  real_T Integer_Delay1_IC;             /* Computed Parameter: IC
                                         * '<Root>/Integer Delay1'
                                         */
  real_T Training_sequence_a_Value[212]; /* Expression: repmat(params.long_training_seq, [1 params.OFDMTrainPerFrame])
                                          * '<S54>/Training sequence'
                                          */
  real_T fadingMode_Value;              /* Expression: fadingMode
                                         * '<S11>/fadingMode'
                                         */
  real_T Training_sequence_b_Value[212]; /* Expression: repmat(params.long_training_seq, [1 params.OFDMTrainPerFrame])
                                          * '<S104>/Training sequence'
                                          */
  real_T Constant_a_Value[18];          /* Expression: (1:max(params.nS)).'
                                         * '<S108>/Constant'
                                         */
  real_T Constant_b_Value;              /* Expression: 1
                                         * '<S109>/Constant'
                                         */
  real_T Direct_Look_Up_Table_n_D_a_tabl[8]; /* Expression: mxTable
                                              * '<S109>/Direct Look-Up Table (n-D)'
                                              */
  real_T Buffer_IC;                     /* Computed Parameter: IC
                                         * '<S97>/Buffer'
                                         */
  real_T Group_data_for_OFDM_symbols_P1; /* Expression: OutputDimensionality
                                          * '<S98>/Group data for OFDM symbols '
                                          */
  real_T Group_data_for_OFDM_symbols_P2[2]; /* Expression: OutputDimensions
                                             * '<S98>/Group data for OFDM symbols '
                                             */
  real_T Select_data_blocks_BAD_INDEX; /* Computed Parameter: BAD_INDEX
                                        * '<S96>/Select data blocks'
                                        */
  real_T PN_Sequence_Generator_P1_Size[2]; /* Computed Parameter: P1Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P1[8];   /* Expression: poly
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T PN_Sequence_Generator_P2_Size[2]; /* Computed Parameter: P2Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P2[7];   /* Expression: ini_sta
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T PN_Sequence_Generator_P3_Size[2]; /* Computed Parameter: P3Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P3;      /* Expression: shift
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T PN_Sequence_Generator_P4_Size[2]; /* Computed Parameter: P4Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P4;      /* Expression: Ts
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T PN_Sequence_Generator_P5_Size[2]; /* Computed Parameter: P5Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P5;      /* Expression: frameBased
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T PN_Sequence_Generator_P6_Size[2]; /* Computed Parameter: P6Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P6;      /* Expression: sampPerFrame
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T PN_Sequence_Generator_P7_Size[2]; /* Computed Parameter: P7Size
                                            * '<S101>/PN Sequence Generator'
                                            */
  real_T PN_Sequence_Generator_P7;      /* Expression: reset
                                         * '<S101>/PN Sequence Generator'
                                         */
  real_T Gain_a_Gain;                   /* Expression: 2
                                         * '<S134>/Gain'
                                         */
  real_T Constant_c_Value;              /* Expression: M-1
                                         * '<S134>/Constant'
                                         */
  real_T Polarity_a_Gain;               /* Expression: pole
                                         * '<S134>/Polarity'
                                         */
  real_T Reshape_a_P1;                  /* Expression: OutputDimensionality
                                         * '<S101>/Reshape'
                                         */
  real_T Reshape_a_P2[2];               /* Expression: OutputDimensions
                                         * '<S101>/Reshape'
                                         */
  real_T Gain_b_Gain;                   /* Expression: -1
                                         * '<S96>/Gain'
                                         */
  real_T IFFT_TwiddleTable[48];         /* Computed Parameter: TwiddleTable
                                         * '<S102>/IFFT'
                                         */
  real_T Normalize_a_Gain;              /* Expression: sqrt(params.NFFT)*sqrt(params.NFFT/params.NST)
                                         * '<S102>/Normalize'
                                         */
  real_T Reshape2_P1;                   /* Expression: OutputDimensionality
                                         * '<S100>/Reshape2'
                                         */
  real_T Reshape2_P2;                   /* Expression: OutputDimensions
                                         * '<S100>/Reshape2'
                                         */
  real_T Constant3_a_Value;             /* Expression: ones(1,nPaths)
                                         * '<S20>/Constant3'
                                         */
  real_T Constant2_a_Value;             /* Expression: [delayVector(:)]'
                                         * '<S20>/Constant2'
                                         */
  real_T Variable_Fraction_a_FilterArgs[120]; /* Computed Parameter: FilterArgs
                                               * '<S20>/Variable Fractional Delay'
                                               */
  real_T S_Function_a_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P1;               /* Expression: startSample
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P2;               /* Expression: numChan
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P3;               /* Expression: inputWidthMode
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P4_Size[2];       /* Computed Parameter: P4Size
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P4;               /* Expression: inputWidth
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P5_Size[2];       /* Computed Parameter: P5Size
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P5;               /* Expression: inputWidthMin
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P6_Size[2];       /* Computed Parameter: P6Size
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_a_P6;               /* Expression: inputWidthStep
                                         * '<S22>/S-Function'
                                         */
  real_T S_Function_b_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P1;               /* Expression: Doppler
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P2;               /* Expression: K
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P3;               /* Expression: opPower
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P4_Size[2];       /* Computed Parameter: P4Size
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P4;               /* Expression: Ts
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P5_Size[2];       /* Computed Parameter: P5Size
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_b_P5;               /* Expression: numChan
                                         * '<S23>/S-Function'
                                         */
  real_T S_Function_c_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S21>/S-Function'
                                         */
  real_T S_Function_c_P1;               /* Expression: propTarget
                                         * '<S21>/S-Function'
                                         */
  real_T S_Function_c_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S21>/S-Function'
                                         */
  real_T S_Function_c_P2;               /* Expression: Ts
                                         * '<S21>/S-Function'
                                         */
  real_T S_Function_c_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S21>/S-Function'
                                         */
  real_T S_Function_c_P3;               /* Expression: numChan
                                         * '<S21>/S-Function'
                                         */
  real_T Constant3_b_Value[2];          /* Expression: ones(1,nPaths)
                                         * '<S29>/Constant3'
                                         */
  real_T Constant2_b_Value[2];          /* Expression: [delayVector(:)]'
                                         * '<S29>/Constant2'
                                         */
  real_T Variable_Fraction_b_FilterArgs[120]; /* Computed Parameter: FilterArgs
                                               * '<S29>/Variable Fractional Delay'
                                               */
  real_T S_Function_d_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P1;               /* Expression: startSample
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P2;               /* Expression: numChan
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P3;               /* Expression: inputWidthMode
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P4_Size[2];       /* Computed Parameter: P4Size
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P4;               /* Expression: inputWidth
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P5_Size[2];       /* Computed Parameter: P5Size
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P5;               /* Expression: inputWidthMin
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P6_Size[2];       /* Computed Parameter: P6Size
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_d_P6;               /* Expression: inputWidthStep
                                         * '<S31>/S-Function'
                                         */
  real_T S_Function_e_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P1[2];            /* Expression: Doppler
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P2[2];            /* Expression: K
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P3[2];            /* Expression: opPower
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P4_Size[2];       /* Computed Parameter: P4Size
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P4;               /* Expression: Ts
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P5_Size[2];       /* Computed Parameter: P5Size
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_e_P5;               /* Expression: numChan
                                         * '<S32>/S-Function'
                                         */
  real_T S_Function_f_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S30>/S-Function'
                                         */
  real_T S_Function_f_P1;               /* Expression: propTarget
                                         * '<S30>/S-Function'
                                         */
  real_T S_Function_f_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S30>/S-Function'
                                         */
  real_T S_Function_f_P2;               /* Expression: Ts
                                         * '<S30>/S-Function'
                                         */
  real_T S_Function_f_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S30>/S-Function'
                                         */
  real_T S_Function_f_P3;               /* Expression: numChan
                                         * '<S30>/S-Function'
                                         */
  real_T Random_Source_a_Variance;      /* Expression: Var
                                         * '<S12>/Random Source'
                                         */
  real_T Random_Source_a_DialogSeed;    /* Expression: Seed
                                         * '<S12>/Random Source'
                                         */
  real_T SNRdB_Value;                   /* Expression: SNRdB
                                         * '<S11>/SNRdB'
                                         */
  real_T Gain_c_Gain;                   /* Expression: -0.1
                                         * '<S17>/Gain'
                                         */
  real_T Dynamic_AWGN_P1_Size[2];       /* Computed Parameter: P1Size
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P1;               /* Expression: noiseMode
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P2_Size[2];       /* Computed Parameter: P2Size
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P2;               /* Expression: EsNodB
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P3_Size[2];       /* Computed Parameter: P3Size
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P3;               /* Expression: SNRdB
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P4_Size[2];       /* Computed Parameter: P4Size
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P4;               /* Expression: Ps
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P5_Size[2];       /* Computed Parameter: P5Size
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P5;               /* Expression: Tsym
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P6_Size[2];       /* Computed Parameter: P6Size
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Dynamic_AWGN_P6;               /* Expression: variance
                                         * '<S12>/Dynamic AWGN'
                                         */
  real_T Demultiplex_P1;                /* Expression: OutputDimensionality
                                         * '<S48>/Demultiplex'
                                         */
  real_T Demultiplex_P2[2];             /* Expression: OutputDimensions
                                         * '<S48>/Demultiplex'
                                         */
  real_T FFT_TwiddleTable[48];          /* Computed Parameter: TwiddleTable
                                         * '<S51>/FFT'
                                         */
  real_T Normalize_b_Gain;              /* Expression: 1/sqrt(params.NFFT)/(sqrt(params.NFFT/params.NST))
                                         * '<S51>/Normalize'
                                         */
  real_T Select_training_data_BAD_INDEX; /* Computed Parameter: BAD_INDEX
                                          * '<S49>/Select training//data'
                                          */
  real_T Remove_pilots_BAD_INDEX;       /* Computed Parameter: BAD_INDEX
                                         * '<S53>/Remove pilots'
                                         */
  real_T Reshape3_P1;                   /* Expression: OutputDimensionality
                                         * '<S53>/Reshape3'
                                         */
  real_T Reshape3_P2;                   /* Expression: OutputDimensions
                                         * '<S53>/Reshape3'
                                         */
  real_T Constant_e_Value;              /* Expression: fuzz_val
                                         * '<S44>/Constant'
                                         */
  real_T Scale_by_R_a_Gain;             /* Expression: 1./R
                                         * '<S44>/Scale by R'
                                         */
  real_T Gain_d_Gain;                   /* Expression: 10
                                         * '<S44>/Gain'
                                         */
  real_T Constant1_a_Value;             /* Expression: dBval
                                         * '<S44>/Constant1'
                                         */
  real_T Integer_Delay2_IC;             /* Computed Parameter: IC
                                         * '<S1>/Integer Delay2'
                                         */
  real_T Constant_f_Value;              /* Expression: 1
                                         * '<S8>/Constant'
                                         */
  real_T Direct_Look_Up_Table_n_D_b_tabl[8]; /* Expression: mxTable
                                              * '<S8>/Direct Look-Up Table (n-D)'
                                              */
  real_T Reshape_b_P1;                  /* Expression: OutputDimensionality
                                         * '<S39>/Reshape'
                                         */
  real_T Reshape_b_P2[2];               /* Expression: OutputDimensions
                                         * '<S39>/Reshape'
                                         */
  real_T Reshape_c_P1;                  /* Expression: OutputDimensionality
                                         * '<S40>/Reshape'
                                         */
  real_T Reshape_c_P2[2];               /* Expression: OutputDimensions
                                         * '<S40>/Reshape'
                                         */
  real_T Zero_Pad1_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad1'
                                         */
  real_T Zero_Pad2_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad2'
                                         */
  real_T Zero_Pad3_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad3'
                                         */
  real_T Zero_Pad4_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad4'
                                         */
  real_T Zero_Pad5_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad5'
                                         */
  real_T Zero_Pad6_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad6'
                                         */
  real_T Zero_Pad7_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad7'
                                         */
  real_T Zero_Pad8_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad8'
                                         */
  real_T Zero_Pad9_PadValue;            /* Expression: 0
                                         * '<S47>/Zero Pad9'
                                         */
  real_T Zero_Pad10_PadValue;           /* Expression: 0
                                         * '<S47>/Zero Pad10'
                                         */
  real_T Zero_Pad11_PadValue;           /* Expression: 0
                                         * '<S47>/Zero Pad11'
                                         */
  real_T Zero_Pad12_PadValue;           /* Expression: 0
                                         * '<S47>/Zero Pad12'
                                         */
  real_T Reshape_d_P1;                  /* Expression: OutputDimensionality
                                         * '<S41>/Reshape'
                                         */
  real_T Reshape_d_P2[2];               /* Expression: OutputDimensions
                                         * '<S41>/Reshape'
                                         */
  real_T Reshape_e_P1;                  /* Expression: OutputDimensionality
                                         * '<S42>/Reshape'
                                         */
  real_T Reshape_e_P2[2];               /* Expression: OutputDimensions
                                         * '<S42>/Reshape'
                                         */
  real_T Constant_g_Value;              /* Expression: 1
                                         * '<S10>/Constant'
                                         */
  real_T Direct_Look_Up_Table_n_D_c_tabl[8]; /* Expression: mxTable
                                              * '<S10>/Direct Look-Up Table (n-D)'
                                              */
  real_T Constant_h_Value;              /* Expression: 1
                                         * '<S9>/Constant'
                                         */
  real_T Direct_Look_Up_Table_n_D_d_tabl[8]; /* Expression: mxTable
                                              * '<S9>/Direct Look-Up Table (n-D)'
                                              */
  real_T Check_Signal_Attributes_a_P1; /* Expression: SigAttribCheckMethod
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P2; /* Expression: Complexity
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P3; /* Expression: Frame
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P4; /* Expression: DimsCheckMethod
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P5; /* Expression: Dimensions
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P6; /* Expression: DatatypeCheckMethod
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P7; /* Expression: DatatypeGeneral
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P8; /* Expression: DtypeFloatSpecific
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P9; /* Expression: DtypeFixedSpecific
                                        * '<S45>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_a_P10; /* Expression: DtypeIntSpecific
                                         * '<S45>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_a_P11; /* Expression: SampleMode
                                         * '<S45>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_b_P1; /* Expression: SigAttribCheckMethod
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P2; /* Expression: Complexity
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P3; /* Expression: Frame
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P4; /* Expression: DimsCheckMethod
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P5; /* Expression: Dimensions
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P6; /* Expression: DatatypeCheckMethod
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P7; /* Expression: DatatypeGeneral
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P8; /* Expression: DtypeFloatSpecific
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P9; /* Expression: DtypeFixedSpecific
                                        * '<S46>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_b_P10; /* Expression: DtypeIntSpecific
                                         * '<S46>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_b_P11; /* Expression: SampleMode
                                         * '<S46>/Check Signal Attributes'
                                         */
  real_T Constant_i_Value;              /* Expression: fuzz_val
                                         * '<S16>/Constant'
                                         */
  real_T Scale_by_R_b_Gain;             /* Expression: 1./R
                                         * '<S16>/Scale by R'
                                         */
  real_T Gain_e_Gain;                   /* Expression: 10
                                         * '<S16>/Gain'
                                         */
  real_T Constant1_b_Value;             /* Expression: dBval
                                         * '<S16>/Constant1'
                                         */
  real_T Check_Signal_Attributes_c_P1; /* Expression: SigAttribCheckMethod
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P2; /* Expression: Complexity
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P3; /* Expression: Frame
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P4; /* Expression: DimsCheckMethod
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P5; /* Expression: Dimensions
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P6; /* Expression: DatatypeCheckMethod
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P7; /* Expression: DatatypeGeneral
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P8; /* Expression: DtypeFloatSpecific
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P9; /* Expression: DtypeFixedSpecific
                                        * '<S26>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_c_P10; /* Expression: DtypeIntSpecific
                                         * '<S26>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_c_P11; /* Expression: SampleMode
                                         * '<S26>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_d_P1; /* Expression: SigAttribCheckMethod
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P2; /* Expression: Complexity
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P3; /* Expression: Frame
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P4; /* Expression: DimsCheckMethod
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P5; /* Expression: Dimensions
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P6; /* Expression: DatatypeCheckMethod
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P7; /* Expression: DatatypeGeneral
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P8; /* Expression: DtypeFloatSpecific
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P9; /* Expression: DtypeFixedSpecific
                                        * '<S35>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_d_P10; /* Expression: DtypeIntSpecific
                                         * '<S35>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_d_P11; /* Expression: SampleMode
                                         * '<S35>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_e_P1; /* Expression: SigAttribCheckMethod
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P2; /* Expression: Complexity
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P3; /* Expression: Frame
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P4; /* Expression: DimsCheckMethod
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P5; /* Expression: Dimensions
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P6; /* Expression: DatatypeCheckMethod
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P7; /* Expression: DatatypeGeneral
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P8; /* Expression: DtypeFloatSpecific
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P9; /* Expression: DtypeFixedSpecific
                                        * '<S36>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_e_P10; /* Expression: DtypeIntSpecific
                                         * '<S36>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_e_P11; /* Expression: SampleMode
                                         * '<S36>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_f_P1; /* Expression: SigAttribCheckMethod
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P2; /* Expression: Complexity
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P3; /* Expression: Frame
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P4; /* Expression: DimsCheckMethod
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P5; /* Expression: Dimensions
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P6; /* Expression: DatatypeCheckMethod
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P7; /* Expression: DatatypeGeneral
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P8; /* Expression: DtypeFloatSpecific
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P9; /* Expression: DtypeFixedSpecific
                                        * '<S37>/Check Signal Attributes'
                                        */
  real_T Check_Signal_Attributes_f_P10; /* Expression: DtypeIntSpecific
                                         * '<S37>/Check Signal Attributes'
                                         */
  real_T Check_Signal_Attributes_f_P11; /* Expression: SampleMode
                                         * '<S37>/Check Signal Attributes'
                                         */
  real_T Random_Source_b_Variance;      /* Expression: Var
                                         * '<S24>/Random Source'
                                         */
  real_T Random_Source_b_DialogSeed;    /* Expression: Seed
                                         * '<S24>/Random Source'
                                         */
  real_T Doppler_Filter_a_RTP1COEFF[20]; /* Expression: a.Coeff1
                                          * '<S24>/Doppler Filter'
                                          */
  real_T FIR_Rate_Conversi_a_FILTER[21]; /* Computed Parameter: FILTER
                                          * '<S24>/FIR Rate Conversion'
                                          */
  real_T FIR_Rate_Conversi_b_FILTER[24]; /* Computed Parameter: FILTER
                                          * '<S24>/FIR Rate Conversion1'
                                          */
  real_T FIR_Rate_Conversi_c_FILTER[45]; /* Computed Parameter: FILTER
                                          * '<S24>/FIR Rate Conversion2'
                                          */
  real_T FIR_Rate_Conversi_d_FILTER[55]; /* Computed Parameter: FILTER
                                          * '<S24>/FIR Rate Conversion3'
                                          */
  real_T FIR_Rate_Conversi_e_FILTER[60]; /* Computed Parameter: FILTER
                                          * '<S24>/FIR Rate Conversion4'
                                          */
  real_T Random_Source_c_Variance;      /* Expression: Var
                                         * '<S33>/Random Source'
                                         */
  real_T Random_Source_c_DialogSeed;    /* Expression: Seed
                                         * '<S33>/Random Source'
                                         */
  real_T Doppler_Filter_b_RTP1COEFF[20]; /* Expression: a.Coeff1
                                          * '<S33>/Doppler Filter'
                                          */
  real_T FIR_Rate_Conversi_f_FILTER[21]; /* Computed Parameter: FILTER
                                          * '<S33>/FIR Rate Conversion'
                                          */
  real_T FIR_Rate_Conversi_g_FILTER[24]; /* Computed Parameter: FILTER
                                          * '<S33>/FIR Rate Conversion1'
                                          */
  real_T FIR_Rate_Conversi_h_FILTER[45]; /* Computed Parameter: FILTER
                                          * '<S33>/FIR Rate Conversion2'
                                          */
  real_T FIR_Rate_Conversi_i_FILTER[55]; /* Computed Parameter: FILTER
                                          * '<S33>/FIR Rate Conversion3'
                                          */
  real_T FIR_Rate_Conversi_j_FILTER[60]; /* Computed Parameter: FILTER
                                          * '<S33>/FIR Rate Conversion4'
                                          */
  real_T symerr_a_Y0;                   /* Expression: 0
                                         * '<S55>/symerr'
                                         */
  real_T rxdata_a_Y0;                   /* Expression: 0
                                         * '<S55>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_a_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P1;    /* Expression: M
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P2;    /* Expression: OutType
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P3;    /* Expression: Dec
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P4;    /* Expression: PowType
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P5;    /* Expression: MinDist
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P6;    /* Expression: AvgPow
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P7;    /* Expression: PeakPow
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P8;    /* Expression: Ph
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P9;    /* Expression: numSamp
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P10;   /* Expression: 0
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P11;   /* Expression: 0
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_a_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S55>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_a_P12;   /* Expression: 4
                                         * '<S55>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_f_Gain;                   /* Expression: 2
                                         * '<S69>/Gain'
                                         */
  real_T Constant_l_Value;              /* Expression: M-1
                                         * '<S69>/Constant'
                                         */
  real_T Polarity_b_Gain;               /* Expression: pole
                                         * '<S69>/Polarity'
                                         */
  real_T General_Block_Deinterlea_aa[2]; /* Computed Parameter: P1Size
                                          * '<S55>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ab[960]; /* Expression: elements
                                            * '<S55>/General Block Deinterleaver'
                                            */
  real_T General_Block_Deinterlea_ac[2]; /* Computed Parameter: P2Size
                                          * '<S55>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ad;   /* Expression: method
                                         * '<S55>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_ba[2]; /* Computed Parameter: P1Size
                                          * '<S68>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_bb[960]; /* Expression: elements
                                            * '<S68>/General Block Deinterleaver'
                                            */
  real_T General_Block_Deinterlea_bc[2]; /* Computed Parameter: P2Size
                                          * '<S68>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_bd;   /* Expression: method
                                         * '<S68>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_a_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S55>/Insert Zero4'
                                         */
  real_T Insert_Zero4_a_P1;             /* Expression: insertZeroVector
                                         * '<S55>/Insert Zero4'
                                         */
  real_T Insert_Zero4_a_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S55>/Insert Zero4'
                                         */
  real_T Insert_Zero4_a_P2;             /* Expression: method
                                         * '<S55>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_a_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P1;   /* Expression: M
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P2;   /* Expression: InType
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P3;   /* Expression: Enc
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P4;   /* Expression: PowType
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P5;   /* Expression: MinDist
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P6;   /* Expression: AvgPow
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P7;   /* Expression: PeakPow
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P8;   /* Expression: Ph
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P9;   /* Expression: numSamp
                                         * '<S55>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_a_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P10; /* Expression: 0
                                        * '<S55>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_a_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P11; /* Expression: 0
                                        * '<S55>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_a_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S55>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_a_P12; /* Expression: 4
                                        * '<S55>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_a_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P1;         /* Expression: S.k
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P2;         /* Expression: S.n
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P3;         /* Expression: S.numStates
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P4[128];    /* Expression: S.outputs
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P5[128];    /* Expression: S.nextStates
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P6;         /* Expression: dectype
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P7;         /* Expression: nsdecb
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P8;         /* Expression: tbdepth
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P9;         /* Expression: opmode
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_a_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S55>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_a_P10;        /* Expression: reset
                                         * '<S55>/Viterbi Decoder1'
                                         */
  real_T symerr_b_Y0;                   /* Expression: 0
                                         * '<S56>/symerr'
                                         */
  real_T rxdata_b_Y0;                   /* Expression: 0
                                         * '<S56>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_b_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P1;    /* Expression: M
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P2;    /* Expression: OutType
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P3;    /* Expression: Dec
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P4;    /* Expression: PowType
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P5;    /* Expression: MinDist
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P6;    /* Expression: AvgPow
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P7;    /* Expression: PeakPow
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P8;    /* Expression: Ph
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P9;    /* Expression: numSamp
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P10;   /* Expression: 0
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P11;   /* Expression: 0
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_b_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S56>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_b_P12;   /* Expression: 4
                                         * '<S56>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_g_Gain;                   /* Expression: 2
                                         * '<S71>/Gain'
                                         */
  real_T Constant_m_Value;              /* Expression: M-1
                                         * '<S71>/Constant'
                                         */
  real_T Polarity_c_Gain;               /* Expression: pole
                                         * '<S71>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ca[2]; /* Computed Parameter: P1Size
                                          * '<S56>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_cb[1920]; /* Expression: elements
                                             * '<S56>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_cc[2]; /* Computed Parameter: P2Size
                                          * '<S56>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_cd;   /* Expression: method
                                         * '<S56>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_da[2]; /* Computed Parameter: P1Size
                                          * '<S70>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_db[1920]; /* Expression: elements
                                             * '<S70>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_dc[2]; /* Computed Parameter: P2Size
                                          * '<S70>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_dd;   /* Expression: method
                                         * '<S70>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_b_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S56>/Insert Zero4'
                                         */
  real_T Insert_Zero4_b_P1[6];          /* Expression: insertZeroVector
                                         * '<S56>/Insert Zero4'
                                         */
  real_T Insert_Zero4_b_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S56>/Insert Zero4'
                                         */
  real_T Insert_Zero4_b_P2;             /* Expression: method
                                         * '<S56>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_b_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P1;   /* Expression: M
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P2;   /* Expression: InType
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P3;   /* Expression: Enc
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P4;   /* Expression: PowType
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P5;   /* Expression: MinDist
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P6;   /* Expression: AvgPow
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P7;   /* Expression: PeakPow
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P8;   /* Expression: Ph
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P9;   /* Expression: numSamp
                                         * '<S56>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_b_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P10; /* Expression: 0
                                        * '<S56>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_b_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P11; /* Expression: 0
                                        * '<S56>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_b_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S56>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_b_P12; /* Expression: 4
                                        * '<S56>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_b_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P1;         /* Expression: S.k
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P2;         /* Expression: S.n
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P3;         /* Expression: S.numStates
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P4[128];    /* Expression: S.outputs
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P5[128];    /* Expression: S.nextStates
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P6;         /* Expression: dectype
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P7;         /* Expression: nsdecb
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P8;         /* Expression: tbdepth
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P9;         /* Expression: opmode
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_b_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S56>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_b_P10;        /* Expression: reset
                                         * '<S56>/Viterbi Decoder1'
                                         */
  real_T symerr_c_Y0;                   /* Expression: 0
                                         * '<S57>/symerr'
                                         */
  real_T rxdata_c_Y0;                   /* Expression: 0
                                         * '<S57>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_c_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P1;    /* Expression: M
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P2;    /* Expression: OutType
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P3;    /* Expression: Dec
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P4;    /* Expression: PowType
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P5;    /* Expression: MinDist
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P6;    /* Expression: AvgPow
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P7;    /* Expression: PeakPow
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P8;    /* Expression: Ph
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P9;    /* Expression: numSamp
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P10;   /* Expression: 0
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P11;   /* Expression: 0
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_c_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S57>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_c_P12;   /* Expression: 4
                                         * '<S57>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_h_Gain;                   /* Expression: 2
                                         * '<S73>/Gain'
                                         */
  real_T Constant_n_Value;              /* Expression: M-1
                                         * '<S73>/Constant'
                                         */
  real_T Polarity_d_Gain;               /* Expression: pole
                                         * '<S73>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ea[2]; /* Computed Parameter: P1Size
                                          * '<S57>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_eb[1920]; /* Expression: elements
                                             * '<S57>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_ec[2]; /* Computed Parameter: P2Size
                                          * '<S57>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ed;   /* Expression: method
                                         * '<S57>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_fa[2]; /* Computed Parameter: P1Size
                                          * '<S72>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_fb[1920]; /* Expression: elements
                                             * '<S72>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_fc[2]; /* Computed Parameter: P2Size
                                          * '<S72>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_fd;   /* Expression: method
                                         * '<S72>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_c_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S57>/Insert Zero4'
                                         */
  real_T Insert_Zero4_c_P1[6];          /* Expression: insertZeroVector
                                         * '<S57>/Insert Zero4'
                                         */
  real_T Insert_Zero4_c_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S57>/Insert Zero4'
                                         */
  real_T Insert_Zero4_c_P2;             /* Expression: method
                                         * '<S57>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_c_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P1;   /* Expression: M
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P2;   /* Expression: InType
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P3;   /* Expression: Enc
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P4;   /* Expression: PowType
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P5;   /* Expression: MinDist
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P6;   /* Expression: AvgPow
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P7;   /* Expression: PeakPow
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P8;   /* Expression: Ph
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P9;   /* Expression: numSamp
                                         * '<S57>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_c_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P10; /* Expression: 0
                                        * '<S57>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_c_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P11; /* Expression: 0
                                        * '<S57>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_c_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S57>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_c_P12; /* Expression: 4
                                        * '<S57>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_c_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P1;         /* Expression: S.k
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P2;         /* Expression: S.n
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P3;         /* Expression: S.numStates
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P4[128];    /* Expression: S.outputs
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P5[128];    /* Expression: S.nextStates
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P6;         /* Expression: dectype
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P7;         /* Expression: nsdecb
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P8;         /* Expression: tbdepth
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P9;         /* Expression: opmode
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_c_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S57>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_c_P10;        /* Expression: reset
                                         * '<S57>/Viterbi Decoder1'
                                         */
  real_T symerr_d_Y0;                   /* Expression: 0
                                         * '<S58>/symerr'
                                         */
  real_T rxdata_d_Y0;                   /* Expression: 0
                                         * '<S58>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_d_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P1;    /* Expression: M
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P2;    /* Expression: OutType
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P3;    /* Expression: Dec
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P4;    /* Expression: PowType
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P5;    /* Expression: MinDist
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P6;    /* Expression: AvgPow
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P7;    /* Expression: PeakPow
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P8;    /* Expression: Ph
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P9;    /* Expression: numSamp
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P10;   /* Expression: 0
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P11;   /* Expression: 0
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_d_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S58>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_d_P12;   /* Expression: 4
                                         * '<S58>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_i_Gain;                   /* Expression: 2
                                         * '<S75>/Gain'
                                         */
  real_T Constant_o_Value;              /* Expression: M-1
                                         * '<S75>/Constant'
                                         */
  real_T Polarity_e_Gain;               /* Expression: pole
                                         * '<S75>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ga[2]; /* Computed Parameter: P1Size
                                          * '<S58>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_gb[1920]; /* Expression: elements
                                             * '<S58>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_gc[2]; /* Computed Parameter: P2Size
                                          * '<S58>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_gd;   /* Expression: method
                                         * '<S58>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_ha[2]; /* Computed Parameter: P1Size
                                          * '<S74>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_hb[1920]; /* Expression: elements
                                             * '<S74>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_hc[2]; /* Computed Parameter: P2Size
                                          * '<S74>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_hd;   /* Expression: method
                                         * '<S74>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_d_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S58>/Insert Zero4'
                                         */
  real_T Insert_Zero4_d_P1[6];          /* Expression: insertZeroVector
                                         * '<S58>/Insert Zero4'
                                         */
  real_T Insert_Zero4_d_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S58>/Insert Zero4'
                                         */
  real_T Insert_Zero4_d_P2;             /* Expression: method
                                         * '<S58>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_d_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P1;   /* Expression: M
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P2;   /* Expression: InType
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P3;   /* Expression: Enc
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P4;   /* Expression: PowType
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P5;   /* Expression: MinDist
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P6;   /* Expression: AvgPow
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P7;   /* Expression: PeakPow
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P8;   /* Expression: Ph
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P9;   /* Expression: numSamp
                                         * '<S58>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_d_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P10; /* Expression: 0
                                        * '<S58>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_d_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P11; /* Expression: 0
                                        * '<S58>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_d_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S58>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_d_P12; /* Expression: 4
                                        * '<S58>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_d_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P1;         /* Expression: S.k
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P2;         /* Expression: S.n
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P3;         /* Expression: S.numStates
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P4[128];    /* Expression: S.outputs
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P5[128];    /* Expression: S.nextStates
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P6;         /* Expression: dectype
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P7;         /* Expression: nsdecb
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P8;         /* Expression: tbdepth
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P9;         /* Expression: opmode
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_d_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S58>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_d_P10;        /* Expression: reset
                                         * '<S58>/Viterbi Decoder1'
                                         */
  real_T symerr_e_Y0;                   /* Expression: 0
                                         * '<S59>/symerr'
                                         */
  real_T rxdata_e_Y0;                   /* Expression: 0
                                         * '<S59>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_e_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P1;    /* Expression: M
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P2;    /* Expression: OutType
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P3;    /* Expression: Dec
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P4;    /* Expression: PowType
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P5;    /* Expression: MinDist
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P6;    /* Expression: AvgPow
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P7;    /* Expression: PeakPow
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P8;    /* Expression: Ph
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P9;    /* Expression: numSamp
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P10;   /* Expression: 0
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P11;   /* Expression: 0
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_e_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S59>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_e_P12;   /* Expression: 4
                                         * '<S59>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_j_Gain;                   /* Expression: 2
                                         * '<S77>/Gain'
                                         */
  real_T Constant_p_Value;              /* Expression: M-1
                                         * '<S77>/Constant'
                                         */
  real_T Polarity_f_Gain;               /* Expression: pole
                                         * '<S77>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ia[2]; /* Computed Parameter: P1Size
                                          * '<S59>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ib[960]; /* Expression: elements
                                            * '<S59>/General Block Deinterleaver'
                                            */
  real_T General_Block_Deinterlea_ic[2]; /* Computed Parameter: P2Size
                                          * '<S59>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_id;   /* Expression: method
                                         * '<S59>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_ja[2]; /* Computed Parameter: P1Size
                                          * '<S76>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_jb[960]; /* Expression: elements
                                            * '<S76>/General Block Deinterleaver'
                                            */
  real_T General_Block_Deinterlea_jc[2]; /* Computed Parameter: P2Size
                                          * '<S76>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_jd;   /* Expression: method
                                         * '<S76>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_e_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S59>/Insert Zero4'
                                         */
  real_T Insert_Zero4_e_P1[6];          /* Expression: insertZeroVector
                                         * '<S59>/Insert Zero4'
                                         */
  real_T Insert_Zero4_e_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S59>/Insert Zero4'
                                         */
  real_T Insert_Zero4_e_P2;             /* Expression: method
                                         * '<S59>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_e_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P1;   /* Expression: M
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P2;   /* Expression: InType
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P3;   /* Expression: Enc
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P4;   /* Expression: PowType
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P5;   /* Expression: MinDist
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P6;   /* Expression: AvgPow
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P7;   /* Expression: PeakPow
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P8;   /* Expression: Ph
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P9;   /* Expression: numSamp
                                         * '<S59>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_e_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P10; /* Expression: 0
                                        * '<S59>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_e_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P11; /* Expression: 0
                                        * '<S59>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_e_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S59>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_e_P12; /* Expression: 4
                                        * '<S59>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_e_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P1;         /* Expression: S.k
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P2;         /* Expression: S.n
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P3;         /* Expression: S.numStates
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P4[128];    /* Expression: S.outputs
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P5[128];    /* Expression: S.nextStates
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P6;         /* Expression: dectype
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P7;         /* Expression: nsdecb
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P8;         /* Expression: tbdepth
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P9;         /* Expression: opmode
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_e_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S59>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_e_P10;        /* Expression: reset
                                         * '<S59>/Viterbi Decoder1'
                                         */
  real_T symerr_f_Y0;                   /* Expression: 0
                                         * '<S60>/symerr'
                                         */
  real_T rxdata_f_Y0;                   /* Expression: 0
                                         * '<S60>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_f_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P1;    /* Expression: M
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P2;    /* Expression: OutType
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P3;    /* Expression: Dec
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P4;    /* Expression: PowType
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P5;    /* Expression: MinDist
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P6;    /* Expression: AvgPow
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P7;    /* Expression: PeakPow
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P8;    /* Expression: Ph
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P9;    /* Expression: numSamp
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P10;   /* Expression: 0
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P11;   /* Expression: 0
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_f_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S60>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_f_P12;   /* Expression: 4
                                         * '<S60>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_k_Gain;                   /* Expression: 2
                                         * '<S79>/Gain'
                                         */
  real_T Constant_q_Value;              /* Expression: M-1
                                         * '<S79>/Constant'
                                         */
  real_T Polarity_g_Gain;               /* Expression: pole
                                         * '<S79>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ka[2]; /* Computed Parameter: P1Size
                                          * '<S60>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_kb[1920]; /* Expression: elements
                                             * '<S60>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_kc[2]; /* Computed Parameter: P2Size
                                          * '<S60>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_kd;   /* Expression: method
                                         * '<S60>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_la[2]; /* Computed Parameter: P1Size
                                          * '<S78>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_lb[1920]; /* Expression: elements
                                             * '<S78>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_lc[2]; /* Computed Parameter: P2Size
                                          * '<S78>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ld;   /* Expression: method
                                         * '<S78>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_f_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S60>/Insert Zero4'
                                         */
  real_T Insert_Zero4_f_P1;             /* Expression: insertZeroVector
                                         * '<S60>/Insert Zero4'
                                         */
  real_T Insert_Zero4_f_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S60>/Insert Zero4'
                                         */
  real_T Insert_Zero4_f_P2;             /* Expression: method
                                         * '<S60>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_f_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P1;   /* Expression: M
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P2;   /* Expression: InType
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P3;   /* Expression: Enc
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P4;   /* Expression: PowType
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P5;   /* Expression: MinDist
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P6;   /* Expression: AvgPow
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P7;   /* Expression: PeakPow
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P8;   /* Expression: Ph
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P9;   /* Expression: numSamp
                                         * '<S60>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_f_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P10; /* Expression: 0
                                        * '<S60>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_f_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P11; /* Expression: 0
                                        * '<S60>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_f_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S60>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_f_P12; /* Expression: 4
                                        * '<S60>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_f_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P1;         /* Expression: S.k
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P2;         /* Expression: S.n
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P3;         /* Expression: S.numStates
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P4[128];    /* Expression: S.outputs
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P5[128];    /* Expression: S.nextStates
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P6;         /* Expression: dectype
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P7;         /* Expression: nsdecb
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P8;         /* Expression: tbdepth
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P9;         /* Expression: opmode
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_f_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S60>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_f_P10;        /* Expression: reset
                                         * '<S60>/Viterbi Decoder1'
                                         */
  real_T symerr_g_Y0;                   /* Expression: 0
                                         * '<S61>/symerr'
                                         */
  real_T rxdata_g_Y0;                   /* Expression: 0
                                         * '<S61>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_g_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P1;    /* Expression: M
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P2;    /* Expression: OutType
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P3;    /* Expression: Dec
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P4;    /* Expression: PowType
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P5;    /* Expression: MinDist
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P6;    /* Expression: AvgPow
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P7;    /* Expression: PeakPow
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P8;    /* Expression: Ph
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P9;    /* Expression: numSamp
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P10;   /* Expression: 0
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P11;   /* Expression: 0
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_g_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S61>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_g_P12;   /* Expression: 4
                                         * '<S61>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_l_Gain;                   /* Expression: 2
                                         * '<S81>/Gain'
                                         */
  real_T Constant_r_Value;              /* Expression: M-1
                                         * '<S81>/Constant'
                                         */
  real_T Polarity_h_Gain;               /* Expression: pole
                                         * '<S81>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ma[2]; /* Computed Parameter: P1Size
                                          * '<S61>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_mb[1920]; /* Expression: elements
                                             * '<S61>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_mc[2]; /* Computed Parameter: P2Size
                                          * '<S61>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_md;   /* Expression: method
                                         * '<S61>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_na[2]; /* Computed Parameter: P1Size
                                          * '<S80>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_nb[1920]; /* Expression: elements
                                             * '<S80>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_nc[2]; /* Computed Parameter: P2Size
                                          * '<S80>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_nd;   /* Expression: method
                                         * '<S80>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_g_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S61>/Insert Zero4'
                                         */
  real_T Insert_Zero4_g_P1[6];          /* Expression: insertZeroVector
                                         * '<S61>/Insert Zero4'
                                         */
  real_T Insert_Zero4_g_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S61>/Insert Zero4'
                                         */
  real_T Insert_Zero4_g_P2;             /* Expression: method
                                         * '<S61>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_g_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P1;   /* Expression: M
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P2;   /* Expression: InType
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P3;   /* Expression: Enc
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P4;   /* Expression: PowType
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P5;   /* Expression: MinDist
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P6;   /* Expression: AvgPow
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P7;   /* Expression: PeakPow
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P8;   /* Expression: Ph
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P9;   /* Expression: numSamp
                                         * '<S61>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_g_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P10; /* Expression: 0
                                        * '<S61>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_g_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P11; /* Expression: 0
                                        * '<S61>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_g_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S61>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_g_P12; /* Expression: 4
                                        * '<S61>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_g_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P1;         /* Expression: S.k
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P2;         /* Expression: S.n
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P3;         /* Expression: S.numStates
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P4[128];    /* Expression: S.outputs
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P5[128];    /* Expression: S.nextStates
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P6;         /* Expression: dectype
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P7;         /* Expression: nsdecb
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P8;         /* Expression: tbdepth
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P9;         /* Expression: opmode
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_g_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S61>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_g_P10;        /* Expression: reset
                                         * '<S61>/Viterbi Decoder1'
                                         */
  real_T symerr_h_Y0;                   /* Expression: 0
                                         * '<S62>/symerr'
                                         */
  real_T rxdata_h_Y0;                   /* Expression: 0
                                         * '<S62>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_h_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P1;    /* Expression: M
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P2;    /* Expression: OutType
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P3;    /* Expression: Dec
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P4;    /* Expression: PowType
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P5;    /* Expression: MinDist
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P6;    /* Expression: AvgPow
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P7;    /* Expression: PeakPow
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P8;    /* Expression: Ph
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P9;    /* Expression: numSamp
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P10;   /* Expression: 0
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P11;   /* Expression: 0
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_h_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S62>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_h_P12;   /* Expression: 4
                                         * '<S62>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_m_Gain;                   /* Expression: 2
                                         * '<S83>/Gain'
                                         */
  real_T Constant_s_Value;              /* Expression: M-1
                                         * '<S83>/Constant'
                                         */
  real_T Polarity_i_Gain;               /* Expression: pole
                                         * '<S83>/Polarity'
                                         */
  real_T General_Block_Deinterlea_oa[2]; /* Computed Parameter: P1Size
                                          * '<S62>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ob[3840]; /* Expression: elements
                                             * '<S62>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_oc[2]; /* Computed Parameter: P2Size
                                          * '<S62>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_od;   /* Expression: method
                                         * '<S62>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_pa[2]; /* Computed Parameter: P1Size
                                          * '<S82>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_pb[3840]; /* Expression: elements
                                             * '<S82>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_pc[2]; /* Computed Parameter: P2Size
                                          * '<S82>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_pd;   /* Expression: method
                                         * '<S82>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_h_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S62>/Insert Zero4'
                                         */
  real_T Insert_Zero4_h_P1;             /* Expression: insertZeroVector
                                         * '<S62>/Insert Zero4'
                                         */
  real_T Insert_Zero4_h_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S62>/Insert Zero4'
                                         */
  real_T Insert_Zero4_h_P2;             /* Expression: method
                                         * '<S62>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_h_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P1;   /* Expression: M
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P2;   /* Expression: InType
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P3;   /* Expression: Enc
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P4;   /* Expression: PowType
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P5;   /* Expression: MinDist
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P6;   /* Expression: AvgPow
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P7;   /* Expression: PeakPow
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P8;   /* Expression: Ph
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P9;   /* Expression: numSamp
                                         * '<S62>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_h_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P10; /* Expression: 0
                                        * '<S62>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_h_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P11; /* Expression: 0
                                        * '<S62>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_h_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S62>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_h_P12; /* Expression: 4
                                        * '<S62>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_h_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P1;         /* Expression: S.k
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P2;         /* Expression: S.n
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P3;         /* Expression: S.numStates
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P4[128];    /* Expression: S.outputs
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P5[128];    /* Expression: S.nextStates
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P6;         /* Expression: dectype
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P7;         /* Expression: nsdecb
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P8;         /* Expression: tbdepth
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P9;         /* Expression: opmode
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_h_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S62>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_h_P10;        /* Expression: reset
                                         * '<S62>/Viterbi Decoder1'
                                         */
  real_T symerr_i_Y0;                   /* Expression: 0
                                         * '<S63>/symerr'
                                         */
  real_T rxdata_i_Y0;                   /* Expression: 0
                                         * '<S63>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_i_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P1;    /* Expression: M
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P2;    /* Expression: OutType
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P3;    /* Expression: Dec
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P4;    /* Expression: PowType
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P5;    /* Expression: MinDist
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P6;    /* Expression: AvgPow
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P7;    /* Expression: PeakPow
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P8;    /* Expression: Ph
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P9;    /* Expression: numSamp
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P10;   /* Expression: 0
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P11;   /* Expression: 0
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_i_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S63>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_i_P12;   /* Expression: 4
                                         * '<S63>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_n_Gain;                   /* Expression: 2
                                         * '<S85>/Gain'
                                         */
  real_T Constant_t_Value;              /* Expression: M-1
                                         * '<S85>/Constant'
                                         */
  real_T Polarity_j_Gain;               /* Expression: pole
                                         * '<S85>/Polarity'
                                         */
  real_T General_Block_Deinterlea_qa[2]; /* Computed Parameter: P1Size
                                          * '<S63>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_qb[3840]; /* Expression: elements
                                             * '<S63>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_qc[2]; /* Computed Parameter: P2Size
                                          * '<S63>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_qd;   /* Expression: method
                                         * '<S63>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_ra[2]; /* Computed Parameter: P1Size
                                          * '<S84>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_rb[3840]; /* Expression: elements
                                             * '<S84>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_rc[2]; /* Computed Parameter: P2Size
                                          * '<S84>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_rd;   /* Expression: method
                                         * '<S84>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_i_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S63>/Insert Zero4'
                                         */
  real_T Insert_Zero4_i_P1[6];          /* Expression: insertZeroVector
                                         * '<S63>/Insert Zero4'
                                         */
  real_T Insert_Zero4_i_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S63>/Insert Zero4'
                                         */
  real_T Insert_Zero4_i_P2;             /* Expression: method
                                         * '<S63>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_i_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P1;   /* Expression: M
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P2;   /* Expression: InType
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P3;   /* Expression: Enc
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P4;   /* Expression: PowType
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P5;   /* Expression: MinDist
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P6;   /* Expression: AvgPow
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P7;   /* Expression: PeakPow
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P8;   /* Expression: Ph
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P9;   /* Expression: numSamp
                                         * '<S63>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_i_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P10; /* Expression: 0
                                        * '<S63>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_i_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P11; /* Expression: 0
                                        * '<S63>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_i_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S63>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_i_P12; /* Expression: 4
                                        * '<S63>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_i_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P1;         /* Expression: S.k
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P2;         /* Expression: S.n
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P3;         /* Expression: S.numStates
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P4[128];    /* Expression: S.outputs
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P5[128];    /* Expression: S.nextStates
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P6;         /* Expression: dectype
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P7;         /* Expression: nsdecb
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P8;         /* Expression: tbdepth
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P9;         /* Expression: opmode
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_i_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S63>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_i_P10;        /* Expression: reset
                                         * '<S63>/Viterbi Decoder1'
                                         */
  real_T symerr_j_Y0;                   /* Expression: 0
                                         * '<S64>/symerr'
                                         */
  real_T rxdata_j_Y0;                   /* Expression: 0
                                         * '<S64>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_j_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P1;    /* Expression: M
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P2;    /* Expression: OutType
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P3;    /* Expression: Dec
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P4;    /* Expression: PowType
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P5;    /* Expression: MinDist
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P6;    /* Expression: AvgPow
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P7;    /* Expression: PeakPow
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P8;    /* Expression: Ph
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P9;    /* Expression: numSamp
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P10;   /* Expression: 0
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P11;   /* Expression: 0
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_j_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S64>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_j_P12;   /* Expression: 4
                                         * '<S64>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_o_Gain;                   /* Expression: 2
                                         * '<S87>/Gain'
                                         */
  real_T Constant_u_Value;              /* Expression: M-1
                                         * '<S87>/Constant'
                                         */
  real_T Polarity_k_Gain;               /* Expression: pole
                                         * '<S87>/Polarity'
                                         */
  real_T General_Block_Deinterlea_sa[2]; /* Computed Parameter: P1Size
                                          * '<S64>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_sb[5760]; /* Expression: elements
                                             * '<S64>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_sc[2]; /* Computed Parameter: P2Size
                                          * '<S64>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_sd;   /* Expression: method
                                         * '<S64>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_ta[2]; /* Computed Parameter: P1Size
                                          * '<S86>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_tb[5760]; /* Expression: elements
                                             * '<S86>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_tc[2]; /* Computed Parameter: P2Size
                                          * '<S86>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_td;   /* Expression: method
                                         * '<S86>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_j_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S64>/Insert Zero4'
                                         */
  real_T Insert_Zero4_j_P1[4];          /* Expression: insertZeroVector
                                         * '<S64>/Insert Zero4'
                                         */
  real_T Insert_Zero4_j_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S64>/Insert Zero4'
                                         */
  real_T Insert_Zero4_j_P2;             /* Expression: method
                                         * '<S64>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_j_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P1;   /* Expression: M
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P2;   /* Expression: InType
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P3;   /* Expression: Enc
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P4;   /* Expression: PowType
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P5;   /* Expression: MinDist
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P6;   /* Expression: AvgPow
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P7;   /* Expression: PeakPow
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P8;   /* Expression: Ph
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P9;   /* Expression: numSamp
                                         * '<S64>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_j_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P10; /* Expression: 0
                                        * '<S64>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_j_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P11; /* Expression: 0
                                        * '<S64>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_j_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S64>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_j_P12; /* Expression: 4
                                        * '<S64>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_j_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P1;         /* Expression: S.k
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P2;         /* Expression: S.n
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P3;         /* Expression: S.numStates
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P4[128];    /* Expression: S.outputs
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P5[128];    /* Expression: S.nextStates
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P6;         /* Expression: dectype
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P7;         /* Expression: nsdecb
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P8;         /* Expression: tbdepth
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P9;         /* Expression: opmode
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_j_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S64>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_j_P10;        /* Expression: reset
                                         * '<S64>/Viterbi Decoder1'
                                         */
  real_T symerr_k_Y0;                   /* Expression: 0
                                         * '<S65>/symerr'
                                         */
  real_T rxdata_k_Y0;                   /* Expression: 0
                                         * '<S65>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_k_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P1;    /* Expression: M
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P2;    /* Expression: OutType
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P3;    /* Expression: Dec
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P4;    /* Expression: PowType
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P5;    /* Expression: MinDist
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P6;    /* Expression: AvgPow
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P7;    /* Expression: PeakPow
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P8;    /* Expression: Ph
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P9;    /* Expression: numSamp
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P10;   /* Expression: 0
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P11;   /* Expression: 0
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_k_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S65>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_k_P12;   /* Expression: 4
                                         * '<S65>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_p_Gain;                   /* Expression: 2
                                         * '<S89>/Gain'
                                         */
  real_T Constant_v_Value;              /* Expression: M-1
                                         * '<S89>/Constant'
                                         */
  real_T Polarity_l_Gain;               /* Expression: pole
                                         * '<S89>/Polarity'
                                         */
  real_T General_Block_Deinterlea_ua[2]; /* Computed Parameter: P1Size
                                          * '<S65>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ub[5760]; /* Expression: elements
                                             * '<S65>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_uc[2]; /* Computed Parameter: P2Size
                                          * '<S65>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_ud;   /* Expression: method
                                         * '<S65>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_va[2]; /* Computed Parameter: P1Size
                                          * '<S88>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_vb[5760]; /* Expression: elements
                                             * '<S88>/General Block Deinterleaver'
                                             */
  real_T General_Block_Deinterlea_vc[2]; /* Computed Parameter: P2Size
                                          * '<S88>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_vd;   /* Expression: method
                                         * '<S88>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_k_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S65>/Insert Zero4'
                                         */
  real_T Insert_Zero4_k_P1[6];          /* Expression: insertZeroVector
                                         * '<S65>/Insert Zero4'
                                         */
  real_T Insert_Zero4_k_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S65>/Insert Zero4'
                                         */
  real_T Insert_Zero4_k_P2;             /* Expression: method
                                         * '<S65>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_k_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P1;   /* Expression: M
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P2;   /* Expression: InType
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P3;   /* Expression: Enc
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P4;   /* Expression: PowType
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P5;   /* Expression: MinDist
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P6;   /* Expression: AvgPow
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P7;   /* Expression: PeakPow
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P8;   /* Expression: Ph
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P9;   /* Expression: numSamp
                                         * '<S65>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_k_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P10; /* Expression: 0
                                        * '<S65>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_k_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P11; /* Expression: 0
                                        * '<S65>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_k_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S65>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_k_P12; /* Expression: 4
                                        * '<S65>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_k_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P1;         /* Expression: S.k
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P2;         /* Expression: S.n
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P3;         /* Expression: S.numStates
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P4[128];    /* Expression: S.outputs
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P5[128];    /* Expression: S.nextStates
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P6;         /* Expression: dectype
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P7;         /* Expression: nsdecb
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P8;         /* Expression: tbdepth
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P9;         /* Expression: opmode
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_k_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S65>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_k_P10;        /* Expression: reset
                                         * '<S65>/Viterbi Decoder1'
                                         */
  real_T symerr_l_Y0;                   /* Expression: 0
                                         * '<S66>/symerr'
                                         */
  real_T rxdata_l_Y0;                   /* Expression: 0
                                         * '<S66>/rxdata'
                                         */
  real_T Rectangular_QAM_Demod_l_P1_Size[2]; /* Computed Parameter: P1Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P1;    /* Expression: M
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P2_Size[2]; /* Computed Parameter: P2Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P2;    /* Expression: OutType
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P3_Size[2]; /* Computed Parameter: P3Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P3;    /* Expression: Dec
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P4_Size[2]; /* Computed Parameter: P4Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P4;    /* Expression: PowType
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P5_Size[2]; /* Computed Parameter: P5Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P5;    /* Expression: MinDist
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P6_Size[2]; /* Computed Parameter: P6Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P6;    /* Expression: AvgPow
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P7_Size[2]; /* Computed Parameter: P7Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P7;    /* Expression: PeakPow
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P8_Size[2]; /* Computed Parameter: P8Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P8;    /* Expression: Ph
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P9_Size[2]; /* Computed Parameter: P9Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P9;    /* Expression: numSamp
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P10_Siz[2]; /* Computed Parameter: P10Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P10;   /* Expression: 0
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P11_Siz[2]; /* Computed Parameter: P11Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P11;   /* Expression: 0
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Rectangular_QAM_Demod_l_P12_Siz[2]; /* Computed Parameter: P12Size
                                              * '<S66>/Rectangular QAM Demodulator Baseband'
                                              */
  real_T Rectangular_QAM_Demod_l_P12;   /* Expression: 4
                                         * '<S66>/Rectangular QAM Demodulator Baseband'
                                         */
  real_T Gain_q_Gain;                   /* Expression: 2
                                         * '<S91>/Gain'
                                         */
  real_T Constant_w_Value;              /* Expression: M-1
                                         * '<S91>/Constant'
                                         */
  real_T Polarity_m_Gain;               /* Expression: pole
                                         * '<S91>/Polarity'
                                         */
  real_T General_Block_Deinterlea_wa[2]; /* Computed Parameter: P1Size
                                          * '<S66>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_wb[960]; /* Expression: elements
                                            * '<S66>/General Block Deinterleaver'
                                            */
  real_T General_Block_Deinterlea_wc[2]; /* Computed Parameter: P2Size
                                          * '<S66>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_wd;   /* Expression: method
                                         * '<S66>/General Block Deinterleaver'
                                         */
  real_T General_Block_Deinterlea_xa[2]; /* Computed Parameter: P1Size
                                          * '<S90>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_xb[960]; /* Expression: elements
                                            * '<S90>/General Block Deinterleaver'
                                            */
  real_T General_Block_Deinterlea_xc[2]; /* Computed Parameter: P2Size
                                          * '<S90>/General Block Deinterleaver'
                                          */
  real_T General_Block_Deinterlea_xd;   /* Expression: method
                                         * '<S90>/General Block Deinterleaver'
                                         */
  real_T Insert_Zero4_l_P1_Size[2];     /* Computed Parameter: P1Size
                                         * '<S66>/Insert Zero4'
                                         */
  real_T Insert_Zero4_l_P1[6];          /* Expression: insertZeroVector
                                         * '<S66>/Insert Zero4'
                                         */
  real_T Insert_Zero4_l_P2_Size[2];     /* Computed Parameter: P2Size
                                         * '<S66>/Insert Zero4'
                                         */
  real_T Insert_Zero4_l_P2;             /* Expression: method
                                         * '<S66>/Insert Zero4'
                                         */
  real_T Rectangular_QAM_Modula_l_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P1;   /* Expression: M
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P2;   /* Expression: InType
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P3;   /* Expression: Enc
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P4;   /* Expression: PowType
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P5;   /* Expression: MinDist
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P6;   /* Expression: AvgPow
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P7;   /* Expression: PeakPow
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P8;   /* Expression: Ph
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P9;   /* Expression: numSamp
                                         * '<S66>/Rectangular QAM Modulator Baseband1'
                                         */
  real_T Rectangular_QAM_Modula_l_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P10; /* Expression: 0
                                        * '<S66>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_l_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P11; /* Expression: 0
                                        * '<S66>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Rectangular_QAM_Modula_l_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S66>/Rectangular QAM Modulator Baseband1'
                                              */
  real_T Rectangular_QAM_Modula_l_P12; /* Expression: 4
                                        * '<S66>/Rectangular QAM Modulator Baseband1'
                                        */
  real_T Viterbi_Decoder1_l_P1_Size[2]; /* Computed Parameter: P1Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P1;         /* Expression: S.k
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P2_Size[2]; /* Computed Parameter: P2Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P2;         /* Expression: S.n
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P3_Size[2]; /* Computed Parameter: P3Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P3;         /* Expression: S.numStates
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P4_Size[2]; /* Computed Parameter: P4Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P4[128];    /* Expression: S.outputs
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P5_Size[2]; /* Computed Parameter: P5Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P5[128];    /* Expression: S.nextStates
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P6_Size[2]; /* Computed Parameter: P6Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P6;         /* Expression: dectype
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P7_Size[2]; /* Computed Parameter: P7Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P7;         /* Expression: nsdecb
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P8_Size[2]; /* Computed Parameter: P8Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P8;         /* Expression: tbdepth
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P9_Size[2]; /* Computed Parameter: P9Size
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P9;         /* Expression: opmode
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T Viterbi_Decoder1_l_P10_Size[2]; /* Computed Parameter: P10Size
                                          * '<S66>/Viterbi Decoder1'
                                          */
  real_T Viterbi_Decoder1_l_P10;        /* Expression: reset
                                         * '<S66>/Viterbi Decoder1'
                                         */
  real_T data_out_Y0;                   /* Expression: 0
                                         * '<S107>/data out'
                                         */
  real_T Constant_x_Value;              /* Expression: 0.5
                                         * '<S107>/Constant'
                                         */
  real_T Random_Source_d_Min;           /* Expression: Min
                                         * '<S107>/Random Source'
                                         */
  real_T Random_Source_d_Max;           /* Expression: Max
                                         * '<S107>/Random Source'
                                         */
  real_T Random_Source_d_DialogSeed;    /* Expression: Seed
                                         * '<S107>/Random Source'
                                         */
  real_T Zero_Pad_b_PadValue;           /* Expression: 0
                                         * '<S110>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_a_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S110>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_a_P1;   /* Expression: s.k
                                         * '<S110>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_a_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S110>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_a_P2;   /* Expression: s.n
                                         * '<S110>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_a_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S110>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_a_P3;   /* Expression: s.numStates
                                         * '<S110>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_a_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S110>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_a_P4[128]; /* Expression: s.outputs
                                            * '<S110>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_a_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S110>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_a_P5[128]; /* Expression: s.nextStates
                                            * '<S110>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_a_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S110>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_a_P6;   /* Expression: s.reset
                                         * '<S110>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_a_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S110>/P2 Puncture'
                                         */
  real_T P2_Puncture_a_P1;              /* Expression: punctureVector
                                         * '<S110>/P2 Puncture'
                                         */
  real_T P2_Puncture_a_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S110>/P2 Puncture'
                                         */
  real_T P2_Puncture_a_P2;              /* Expression: method
                                         * '<S110>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_a_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S122>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_a_P1[960]; /* Expression: elements
                                               * '<S122>/General Block Interleaver'
                                               */
  real_T General_Block_Interleaver_a_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S122>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_a_P2; /* Expression: method
                                          * '<S122>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_b_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S110>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_b_P1[960]; /* Expression: elements
                                               * '<S110>/General Block Interleaver'
                                               */
  real_T General_Block_Interleaver_b_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S110>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_b_P2; /* Expression: method
                                          * '<S110>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_m_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P1;   /* Expression: M
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P2;   /* Expression: InType
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P3;   /* Expression: Enc
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P4;   /* Expression: PowType
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P5;   /* Expression: MinDist
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P6;   /* Expression: AvgPow
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P7;   /* Expression: PeakPow
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P8;   /* Expression: Ph
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P9;   /* Expression: numSamp
                                         * '<S110>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_m_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P10; /* Expression: 0
                                        * '<S110>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_m_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P11; /* Expression: 0
                                        * '<S110>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_m_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S110>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_m_P12; /* Expression: 4
                                        * '<S110>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_a_Gain;                  /* Expression: 1
                                         * '<S110>/Gain1'
                                         */
  real_T Zero_Pad_c_PadValue;           /* Expression: 0
                                         * '<S111>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_b_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S111>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_b_P1;   /* Expression: s.k
                                         * '<S111>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_b_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S111>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_b_P2;   /* Expression: s.n
                                         * '<S111>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_b_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S111>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_b_P3;   /* Expression: s.numStates
                                         * '<S111>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_b_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S111>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_b_P4[128]; /* Expression: s.outputs
                                            * '<S111>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_b_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S111>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_b_P5[128]; /* Expression: s.nextStates
                                            * '<S111>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_b_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S111>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_b_P6;   /* Expression: s.reset
                                         * '<S111>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_b_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S111>/P2 Puncture'
                                         */
  real_T P2_Puncture_b_P1[6];           /* Expression: punctureVector
                                         * '<S111>/P2 Puncture'
                                         */
  real_T P2_Puncture_b_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S111>/P2 Puncture'
                                         */
  real_T P2_Puncture_b_P2;              /* Expression: method
                                         * '<S111>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_c_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S123>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_c_P1[1920]; /* Expression: elements
                                                * '<S123>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_c_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S123>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_c_P2; /* Expression: method
                                          * '<S123>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_d_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S111>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_d_P1[1920]; /* Expression: elements
                                                * '<S111>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_d_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S111>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_d_P2; /* Expression: method
                                          * '<S111>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_n_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P1;   /* Expression: M
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P2;   /* Expression: InType
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P3;   /* Expression: Enc
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P4;   /* Expression: PowType
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P5;   /* Expression: MinDist
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P6;   /* Expression: AvgPow
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P7;   /* Expression: PeakPow
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P8;   /* Expression: Ph
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P9;   /* Expression: numSamp
                                         * '<S111>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_n_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P10; /* Expression: 0
                                        * '<S111>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_n_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P11; /* Expression: 0
                                        * '<S111>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_n_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S111>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_n_P12; /* Expression: 4
                                        * '<S111>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_b_Gain;                  /* Expression: 1
                                         * '<S111>/Gain1'
                                         */
  real_T Zero_Pad_d_PadValue;           /* Expression: 0
                                         * '<S112>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_c_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S112>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_c_P1;   /* Expression: s.k
                                         * '<S112>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_c_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S112>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_c_P2;   /* Expression: s.n
                                         * '<S112>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_c_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S112>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_c_P3;   /* Expression: s.numStates
                                         * '<S112>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_c_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S112>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_c_P4[128]; /* Expression: s.outputs
                                            * '<S112>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_c_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S112>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_c_P5[128]; /* Expression: s.nextStates
                                            * '<S112>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_c_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S112>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_c_P6;   /* Expression: s.reset
                                         * '<S112>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_c_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S112>/P2 Puncture'
                                         */
  real_T P2_Puncture_c_P1[6];           /* Expression: punctureVector
                                         * '<S112>/P2 Puncture'
                                         */
  real_T P2_Puncture_c_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S112>/P2 Puncture'
                                         */
  real_T P2_Puncture_c_P2;              /* Expression: method
                                         * '<S112>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_e_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S124>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_e_P1[1920]; /* Expression: elements
                                                * '<S124>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_e_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S124>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_e_P2; /* Expression: method
                                          * '<S124>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_f_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S112>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_f_P1[1920]; /* Expression: elements
                                                * '<S112>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_f_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S112>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_f_P2; /* Expression: method
                                          * '<S112>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_o_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P1;   /* Expression: M
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P2;   /* Expression: InType
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P3;   /* Expression: Enc
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P4;   /* Expression: PowType
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P5;   /* Expression: MinDist
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P6;   /* Expression: AvgPow
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P7;   /* Expression: PeakPow
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P8;   /* Expression: Ph
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P9;   /* Expression: numSamp
                                         * '<S112>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_o_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P10; /* Expression: 0
                                        * '<S112>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_o_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P11; /* Expression: 0
                                        * '<S112>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_o_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S112>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_o_P12; /* Expression: 4
                                        * '<S112>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_c_Gain;                  /* Expression: 1
                                         * '<S112>/Gain1'
                                         */
  real_T Zero_Pad_e_PadValue;           /* Expression: 0
                                         * '<S113>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_d_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S113>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_d_P1;   /* Expression: s.k
                                         * '<S113>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_d_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S113>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_d_P2;   /* Expression: s.n
                                         * '<S113>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_d_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S113>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_d_P3;   /* Expression: s.numStates
                                         * '<S113>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_d_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S113>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_d_P4[128]; /* Expression: s.outputs
                                            * '<S113>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_d_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S113>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_d_P5[128]; /* Expression: s.nextStates
                                            * '<S113>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_d_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S113>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_d_P6;   /* Expression: s.reset
                                         * '<S113>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_d_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S113>/P2 Puncture'
                                         */
  real_T P2_Puncture_d_P1[6];           /* Expression: punctureVector
                                         * '<S113>/P2 Puncture'
                                         */
  real_T P2_Puncture_d_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S113>/P2 Puncture'
                                         */
  real_T P2_Puncture_d_P2;              /* Expression: method
                                         * '<S113>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_g_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S125>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_g_P1[1920]; /* Expression: elements
                                                * '<S125>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_g_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S125>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_g_P2; /* Expression: method
                                          * '<S125>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_h_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S113>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_h_P1[1920]; /* Expression: elements
                                                * '<S113>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_h_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S113>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_h_P2; /* Expression: method
                                          * '<S113>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_p_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P1;   /* Expression: M
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P2;   /* Expression: InType
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P3;   /* Expression: Enc
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P4;   /* Expression: PowType
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P5;   /* Expression: MinDist
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P6;   /* Expression: AvgPow
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P7;   /* Expression: PeakPow
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P8;   /* Expression: Ph
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P9;   /* Expression: numSamp
                                         * '<S113>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_p_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P10; /* Expression: 0
                                        * '<S113>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_p_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P11; /* Expression: 0
                                        * '<S113>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_p_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S113>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_p_P12; /* Expression: 4
                                        * '<S113>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_d_Gain;                  /* Expression: 1
                                         * '<S113>/Gain1'
                                         */
  real_T Zero_Pad_f_PadValue;           /* Expression: 0
                                         * '<S114>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_e_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S114>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_e_P1;   /* Expression: s.k
                                         * '<S114>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_e_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S114>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_e_P2;   /* Expression: s.n
                                         * '<S114>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_e_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S114>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_e_P3;   /* Expression: s.numStates
                                         * '<S114>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_e_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S114>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_e_P4[128]; /* Expression: s.outputs
                                            * '<S114>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_e_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S114>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_e_P5[128]; /* Expression: s.nextStates
                                            * '<S114>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_e_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S114>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_e_P6;   /* Expression: s.reset
                                         * '<S114>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_e_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S114>/P2 Puncture'
                                         */
  real_T P2_Puncture_e_P1[6];           /* Expression: punctureVector
                                         * '<S114>/P2 Puncture'
                                         */
  real_T P2_Puncture_e_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S114>/P2 Puncture'
                                         */
  real_T P2_Puncture_e_P2;              /* Expression: method
                                         * '<S114>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_i_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S126>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_i_P1[960]; /* Expression: elements
                                               * '<S126>/General Block Interleaver'
                                               */
  real_T General_Block_Interleaver_i_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S126>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_i_P2; /* Expression: method
                                          * '<S126>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_j_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S114>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_j_P1[960]; /* Expression: elements
                                               * '<S114>/General Block Interleaver'
                                               */
  real_T General_Block_Interleaver_j_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S114>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_j_P2; /* Expression: method
                                          * '<S114>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_q_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P1;   /* Expression: M
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P2;   /* Expression: InType
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P3;   /* Expression: Enc
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P4;   /* Expression: PowType
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P5;   /* Expression: MinDist
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P6;   /* Expression: AvgPow
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P7;   /* Expression: PeakPow
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P8;   /* Expression: Ph
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P9;   /* Expression: numSamp
                                         * '<S114>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_q_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P10; /* Expression: 0
                                        * '<S114>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_q_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P11; /* Expression: 0
                                        * '<S114>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_q_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S114>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_q_P12; /* Expression: 4
                                        * '<S114>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_e_Gain;                  /* Expression: 1
                                         * '<S114>/Gain1'
                                         */
  real_T Zero_Pad_g_PadValue;           /* Expression: 0
                                         * '<S115>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_f_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S115>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_f_P1;   /* Expression: s.k
                                         * '<S115>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_f_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S115>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_f_P2;   /* Expression: s.n
                                         * '<S115>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_f_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S115>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_f_P3;   /* Expression: s.numStates
                                         * '<S115>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_f_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S115>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_f_P4[128]; /* Expression: s.outputs
                                            * '<S115>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_f_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S115>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_f_P5[128]; /* Expression: s.nextStates
                                            * '<S115>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_f_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S115>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_f_P6;   /* Expression: s.reset
                                         * '<S115>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_f_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S115>/P2 Puncture'
                                         */
  real_T P2_Puncture_f_P1;              /* Expression: punctureVector
                                         * '<S115>/P2 Puncture'
                                         */
  real_T P2_Puncture_f_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S115>/P2 Puncture'
                                         */
  real_T P2_Puncture_f_P2;              /* Expression: method
                                         * '<S115>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_k_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S127>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_k_P1[1920]; /* Expression: elements
                                                * '<S127>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_k_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S127>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_k_P2; /* Expression: method
                                          * '<S127>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_l_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S115>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_l_P1[1920]; /* Expression: elements
                                                * '<S115>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_l_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S115>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_l_P2; /* Expression: method
                                          * '<S115>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_r_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P1;   /* Expression: M
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P2;   /* Expression: InType
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P3;   /* Expression: Enc
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P4;   /* Expression: PowType
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P5;   /* Expression: MinDist
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P6;   /* Expression: AvgPow
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P7;   /* Expression: PeakPow
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P8;   /* Expression: Ph
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P9;   /* Expression: numSamp
                                         * '<S115>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_r_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P10; /* Expression: 0
                                        * '<S115>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_r_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P11; /* Expression: 0
                                        * '<S115>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_r_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S115>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_r_P12; /* Expression: 4
                                        * '<S115>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_f_Gain;                  /* Expression: 1
                                         * '<S115>/Gain1'
                                         */
  real_T Zero_Pad_h_PadValue;           /* Expression: 0
                                         * '<S116>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_g_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S116>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_g_P1;   /* Expression: s.k
                                         * '<S116>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_g_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S116>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_g_P2;   /* Expression: s.n
                                         * '<S116>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_g_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S116>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_g_P3;   /* Expression: s.numStates
                                         * '<S116>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_g_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S116>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_g_P4[128]; /* Expression: s.outputs
                                            * '<S116>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_g_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S116>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_g_P5[128]; /* Expression: s.nextStates
                                            * '<S116>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_g_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S116>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_g_P6;   /* Expression: s.reset
                                         * '<S116>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_g_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S116>/P2 Puncture'
                                         */
  real_T P2_Puncture_g_P1[6];           /* Expression: punctureVector
                                         * '<S116>/P2 Puncture'
                                         */
  real_T P2_Puncture_g_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S116>/P2 Puncture'
                                         */
  real_T P2_Puncture_g_P2;              /* Expression: method
                                         * '<S116>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_m_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S128>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_m_P1[1920]; /* Expression: elements
                                                * '<S128>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_m_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S128>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_m_P2; /* Expression: method
                                          * '<S128>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_n_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S116>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_n_P1[1920]; /* Expression: elements
                                                * '<S116>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_n_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S116>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_n_P2; /* Expression: method
                                          * '<S116>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_s_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P1;   /* Expression: M
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P2;   /* Expression: InType
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P3;   /* Expression: Enc
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P4;   /* Expression: PowType
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P5;   /* Expression: MinDist
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P6;   /* Expression: AvgPow
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P7;   /* Expression: PeakPow
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P8;   /* Expression: Ph
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P9;   /* Expression: numSamp
                                         * '<S116>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_s_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P10; /* Expression: 0
                                        * '<S116>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_s_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P11; /* Expression: 0
                                        * '<S116>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_s_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S116>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_s_P12; /* Expression: 4
                                        * '<S116>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_g_Gain;                  /* Expression: 1
                                         * '<S116>/Gain1'
                                         */
  real_T Zero_Pad_i_PadValue;           /* Expression: 0
                                         * '<S117>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_h_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S117>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_h_P1;   /* Expression: s.k
                                         * '<S117>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_h_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S117>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_h_P2;   /* Expression: s.n
                                         * '<S117>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_h_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S117>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_h_P3;   /* Expression: s.numStates
                                         * '<S117>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_h_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S117>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_h_P4[128]; /* Expression: s.outputs
                                            * '<S117>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_h_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S117>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_h_P5[128]; /* Expression: s.nextStates
                                            * '<S117>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_h_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S117>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_h_P6;   /* Expression: s.reset
                                         * '<S117>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_h_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S117>/P2 Puncture'
                                         */
  real_T P2_Puncture_h_P1;              /* Expression: punctureVector
                                         * '<S117>/P2 Puncture'
                                         */
  real_T P2_Puncture_h_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S117>/P2 Puncture'
                                         */
  real_T P2_Puncture_h_P2;              /* Expression: method
                                         * '<S117>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_o_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S129>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_o_P1[3840]; /* Expression: elements
                                                * '<S129>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_o_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S129>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_o_P2; /* Expression: method
                                          * '<S129>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_p_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S117>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_p_P1[3840]; /* Expression: elements
                                                * '<S117>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_p_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S117>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_p_P2; /* Expression: method
                                          * '<S117>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_t_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P1;   /* Expression: M
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P2;   /* Expression: InType
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P3;   /* Expression: Enc
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P4;   /* Expression: PowType
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P5;   /* Expression: MinDist
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P6;   /* Expression: AvgPow
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P7;   /* Expression: PeakPow
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P8;   /* Expression: Ph
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P9;   /* Expression: numSamp
                                         * '<S117>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_t_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P10; /* Expression: 0
                                        * '<S117>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_t_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P11; /* Expression: 0
                                        * '<S117>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_t_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S117>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_t_P12; /* Expression: 4
                                        * '<S117>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_h_Gain;                  /* Expression: 1
                                         * '<S117>/Gain1'
                                         */
  real_T Zero_Pad_j_PadValue;           /* Expression: 0
                                         * '<S118>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_i_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S118>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_i_P1;   /* Expression: s.k
                                         * '<S118>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_i_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S118>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_i_P2;   /* Expression: s.n
                                         * '<S118>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_i_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S118>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_i_P3;   /* Expression: s.numStates
                                         * '<S118>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_i_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S118>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_i_P4[128]; /* Expression: s.outputs
                                            * '<S118>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_i_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S118>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_i_P5[128]; /* Expression: s.nextStates
                                            * '<S118>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_i_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S118>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_i_P6;   /* Expression: s.reset
                                         * '<S118>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_i_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S118>/P2 Puncture'
                                         */
  real_T P2_Puncture_i_P1[6];           /* Expression: punctureVector
                                         * '<S118>/P2 Puncture'
                                         */
  real_T P2_Puncture_i_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S118>/P2 Puncture'
                                         */
  real_T P2_Puncture_i_P2;              /* Expression: method
                                         * '<S118>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_q_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S130>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_q_P1[3840]; /* Expression: elements
                                                * '<S130>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_q_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S130>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_q_P2; /* Expression: method
                                          * '<S130>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_r_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S118>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_r_P1[3840]; /* Expression: elements
                                                * '<S118>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_r_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S118>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_r_P2; /* Expression: method
                                          * '<S118>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_u_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P1;   /* Expression: M
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P2;   /* Expression: InType
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P3;   /* Expression: Enc
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P4;   /* Expression: PowType
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P5;   /* Expression: MinDist
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P6;   /* Expression: AvgPow
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P7;   /* Expression: PeakPow
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P8;   /* Expression: Ph
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P9;   /* Expression: numSamp
                                         * '<S118>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_u_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P10; /* Expression: 0
                                        * '<S118>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_u_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P11; /* Expression: 0
                                        * '<S118>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_u_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S118>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_u_P12; /* Expression: 4
                                        * '<S118>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_i_Gain;                  /* Expression: 1
                                         * '<S118>/Gain1'
                                         */
  real_T Zero_Pad_k_PadValue;           /* Expression: 0
                                         * '<S119>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_j_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S119>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_j_P1;   /* Expression: s.k
                                         * '<S119>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_j_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S119>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_j_P2;   /* Expression: s.n
                                         * '<S119>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_j_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S119>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_j_P3;   /* Expression: s.numStates
                                         * '<S119>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_j_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S119>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_j_P4[128]; /* Expression: s.outputs
                                            * '<S119>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_j_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S119>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_j_P5[128]; /* Expression: s.nextStates
                                            * '<S119>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_j_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S119>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_j_P6;   /* Expression: s.reset
                                         * '<S119>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_j_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S119>/P2 Puncture'
                                         */
  real_T P2_Puncture_j_P1[4];           /* Expression: punctureVector
                                         * '<S119>/P2 Puncture'
                                         */
  real_T P2_Puncture_j_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S119>/P2 Puncture'
                                         */
  real_T P2_Puncture_j_P2;              /* Expression: method
                                         * '<S119>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_s_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S131>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_s_P1[5760]; /* Expression: elements
                                                * '<S131>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_s_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S131>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_s_P2; /* Expression: method
                                          * '<S131>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_t_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S119>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_t_P1[5760]; /* Expression: elements
                                                * '<S119>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_t_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S119>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_t_P2; /* Expression: method
                                          * '<S119>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_v_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P1;   /* Expression: M
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P2;   /* Expression: InType
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P3;   /* Expression: Enc
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P4;   /* Expression: PowType
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P5;   /* Expression: MinDist
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P6;   /* Expression: AvgPow
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P7;   /* Expression: PeakPow
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P8;   /* Expression: Ph
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P9;   /* Expression: numSamp
                                         * '<S119>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_v_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P10; /* Expression: 0
                                        * '<S119>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_v_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P11; /* Expression: 0
                                        * '<S119>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_v_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S119>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_v_P12; /* Expression: 4
                                        * '<S119>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_j_Gain;                  /* Expression: 1
                                         * '<S119>/Gain1'
                                         */
  real_T Zero_Pad_l_PadValue;           /* Expression: 0
                                         * '<S120>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_k_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S120>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_k_P1;   /* Expression: s.k
                                         * '<S120>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_k_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S120>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_k_P2;   /* Expression: s.n
                                         * '<S120>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_k_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S120>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_k_P3;   /* Expression: s.numStates
                                         * '<S120>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_k_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S120>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_k_P4[128]; /* Expression: s.outputs
                                            * '<S120>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_k_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S120>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_k_P5[128]; /* Expression: s.nextStates
                                            * '<S120>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_k_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S120>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_k_P6;   /* Expression: s.reset
                                         * '<S120>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_k_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S120>/P2 Puncture'
                                         */
  real_T P2_Puncture_k_P1[6];           /* Expression: punctureVector
                                         * '<S120>/P2 Puncture'
                                         */
  real_T P2_Puncture_k_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S120>/P2 Puncture'
                                         */
  real_T P2_Puncture_k_P2;              /* Expression: method
                                         * '<S120>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_u_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S132>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_u_P1[5760]; /* Expression: elements
                                                * '<S132>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_u_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S132>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_u_P2; /* Expression: method
                                          * '<S132>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_v_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S120>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_v_P1[5760]; /* Expression: elements
                                                * '<S120>/General Block Interleaver'
                                                */
  real_T General_Block_Interleaver_v_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S120>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_v_P2; /* Expression: method
                                          * '<S120>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_w_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P1;   /* Expression: M
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P2;   /* Expression: InType
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P3;   /* Expression: Enc
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P4;   /* Expression: PowType
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P5;   /* Expression: MinDist
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P6;   /* Expression: AvgPow
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P7;   /* Expression: PeakPow
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P8;   /* Expression: Ph
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P9;   /* Expression: numSamp
                                         * '<S120>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_w_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P10; /* Expression: 0
                                        * '<S120>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_w_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P11; /* Expression: 0
                                        * '<S120>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_w_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S120>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_w_P12; /* Expression: 4
                                        * '<S120>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_k_Gain;                  /* Expression: 1
                                         * '<S120>/Gain1'
                                         */
  real_T Zero_Pad_m_PadValue;           /* Expression: 0
                                         * '<S121>/Zero Pad'
                                         */
  real_T Convolutional_Encoder1_l_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S121>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_l_P1;   /* Expression: s.k
                                         * '<S121>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_l_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S121>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_l_P2;   /* Expression: s.n
                                         * '<S121>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_l_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S121>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_l_P3;   /* Expression: s.numStates
                                         * '<S121>/Convolutional Encoder1'
                                         */
  real_T Convolutional_Encoder1_l_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S121>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_l_P4[128]; /* Expression: s.outputs
                                            * '<S121>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_l_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S121>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_l_P5[128]; /* Expression: s.nextStates
                                            * '<S121>/Convolutional Encoder1'
                                            */
  real_T Convolutional_Encoder1_l_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S121>/Convolutional Encoder1'
                                              */
  real_T Convolutional_Encoder1_l_P6;   /* Expression: s.reset
                                         * '<S121>/Convolutional Encoder1'
                                         */
  real_T P2_Puncture_l_P1_Size[2];      /* Computed Parameter: P1Size
                                         * '<S121>/P2 Puncture'
                                         */
  real_T P2_Puncture_l_P1[6];           /* Expression: punctureVector
                                         * '<S121>/P2 Puncture'
                                         */
  real_T P2_Puncture_l_P2_Size[2];      /* Computed Parameter: P2Size
                                         * '<S121>/P2 Puncture'
                                         */
  real_T P2_Puncture_l_P2;              /* Expression: method
                                         * '<S121>/P2 Puncture'
                                         */
  real_T General_Block_Interleaver_w_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S133>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_w_P1[960]; /* Expression: elements
                                               * '<S133>/General Block Interleaver'
                                               */
  real_T General_Block_Interleaver_w_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S133>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_w_P2; /* Expression: method
                                          * '<S133>/General Block Interleaver'
                                          */
  real_T General_Block_Interleaver_x_P1_[2]; /* Computed Parameter: P1Size
                                              * '<S121>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_x_P1[960]; /* Expression: elements
                                               * '<S121>/General Block Interleaver'
                                               */
  real_T General_Block_Interleaver_x_P2_[2]; /* Computed Parameter: P2Size
                                              * '<S121>/General Block Interleaver'
                                              */
  real_T General_Block_Interleaver_x_P2; /* Expression: method
                                          * '<S121>/General Block Interleaver'
                                          */
  real_T Rectangular_QAM_Modula_x_P1_Siz[2]; /* Computed Parameter: P1Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P1;   /* Expression: M
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P2_Siz[2]; /* Computed Parameter: P2Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P2;   /* Expression: InType
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P3_Siz[2]; /* Computed Parameter: P3Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P3;   /* Expression: Enc
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P4_Siz[2]; /* Computed Parameter: P4Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P4;   /* Expression: PowType
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P5_Siz[2]; /* Computed Parameter: P5Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P5;   /* Expression: MinDist
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P6_Siz[2]; /* Computed Parameter: P6Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P6;   /* Expression: AvgPow
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P7_Siz[2]; /* Computed Parameter: P7Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P7;   /* Expression: PeakPow
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P8_Siz[2]; /* Computed Parameter: P8Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P8;   /* Expression: Ph
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P9_Siz[2]; /* Computed Parameter: P9Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P9;   /* Expression: numSamp
                                         * '<S121>/Rectangular QAM Modulator Baseband'
                                         */
  real_T Rectangular_QAM_Modula_x_P10_Si[2]; /* Computed Parameter: P10Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P10; /* Expression: 0
                                        * '<S121>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_x_P11_Si[2]; /* Computed Parameter: P11Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P11; /* Expression: 0
                                        * '<S121>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Rectangular_QAM_Modula_x_P12_Si[2]; /* Computed Parameter: P12Size
                                              * '<S121>/Rectangular QAM Modulator Baseband'
                                              */
  real_T Rectangular_QAM_Modula_x_P12; /* Expression: 4
                                        * '<S121>/Rectangular QAM Modulator Baseband'
                                        */
  real_T Gain1_l_Gain;                  /* Expression: 1
                                         * '<S121>/Gain1'
                                         */
  creal_T Constant_d_Value[20];         /* Expression: complex(zeros(1,params.OFDMSymPerFrame))
                                         * '<S105>/Constant'
                                         */
  creal_T Zero_Pad_a_PadValue;          /* Expression: 0
                                         * '<S7>/Zero Pad'
                                         */
  creal_T Variable_Fraction_a_IC;       /* Computed Parameter: IC
                                         * '<S20>/Variable Fractional Delay'
                                         */
  creal_T Variable_Fraction_b_IC;       /* Computed Parameter: IC
                                         * '<S29>/Variable Fractional Delay'
                                         */
  creal_T Random_Source_a_Mean;         /* Computed Parameter: Mean
                                         * '<S12>/Random Source'
                                         */
  creal_T Repeat_IC;                    /* Computed Parameter: IC
                                         * '<S92>/Repeat'
                                         */
  creal_T Constant_j_Value;             /* Expression: j
                                         * '<S24>/Constant'
                                         */
  creal_T Random_Source_b_Mean;         /* Computed Parameter: Mean
                                         * '<S24>/Random Source'
                                         */
  creal_T Doppler_Filter_a_ICRTP;       /* Computed Parameter: ICRTP
                                         * '<S24>/Doppler Filter'
                                         */
  creal_T Constant_k_Value;             /* Expression: j
                                         * '<S33>/Constant'
                                         */
  creal_T Random_Source_c_Mean;         /* Computed Parameter: Mean
                                         * '<S33>/Random Source'
                                         */
  creal_T Doppler_Filter_b_ICRTP;       /* Computed Parameter: ICRTP
                                         * '<S33>/Doppler Filter'
                                         */
  int32_T Integer_Delay1_Delays;        /* Computed Parameter: Delays
                                         * '<Root>/Integer Delay1'
                                         */
  int32_T Select_data_blocks_INDEX_ARRAY_[48]; /* Computed Parameter: INDEX_ARRAY_FLAT
                                                * '<S96>/Select data blocks'
                                                */
  int32_T Select_data_blocks_LEN_ARRAY_FL[6]; /* Computed Parameter: LEN_ARRAY_FLAT
                                               * '<S96>/Select data blocks'
                                               */
  int32_T Select_training_data_INDEX_ARRA[24]; /* Computed Parameter: INDEX_ARRAY_FLAT
                                                * '<S49>/Select training//data'
                                                */
  int32_T Select_training_data_LEN_ARRAY_[2]; /* Computed Parameter: LEN_ARRAY_FLAT
                                               * '<S49>/Select training//data'
                                               */
  int32_T Remove_pilots_INDEX_ARRAY_FLAT[52]; /* Computed Parameter: INDEX_ARRAY_FLAT
                                               * '<S53>/Remove pilots'
                                               */
  int32_T Remove_pilots_LEN_ARRAY_FLAT[2]; /* Computed Parameter: LEN_ARRAY_FLAT
                                            * '<S53>/Remove pilots'
                                            */
  int32_T Integer_Delay2_Delays;        /* Computed Parameter: Delays
                                         * '<S1>/Integer Delay2'
                                         */
  uint32_T Random_Source_a_InitSeed;    /* Expression: SFcnSeed
                                         * '<S12>/Random Source'
                                         */
  uint32_T Random_Source_b_InitSeed;    /* Expression: SFcnSeed
                                         * '<S24>/Random Source'
                                         */
  uint32_T Random_Source_c_InitSeed;    /* Expression: SFcnSeed
                                         * '<S33>/Random Source'
                                         */
  uint32_T Random_Source_d_InitSeed;    /* Expression: SFcnSeed
                                         * '<S107>/Random Source'
                                         */
};

/* Real-time Model Data Structure */
struct _rtModel_IEEE80211g_Tag {
  const char *path;
  const char *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char *errorStatus;
  SS_SimMode simMode;
  RTWLogInfo *rtwLogInfo;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo *solverInfo;
  void *sfcnInfo;

  /*
   * ModelData:
   * The following substructure contains information regarding
   * the data used in the model.
   */
  struct {
    void *blockIO;
    const void *constBlockIO;
    real_T *defaultParam;
    ZCSigState *prevZCSigState;
    real_T *contStates;
    real_T *discStates;
    real_T *derivs;
    real_T *nonsampledZCs;
    void *inputs;
    void *outputs;
    boolean_T contStateDisabled;
    boolean_T zCCacheNeedsReset;
    boolean_T derivCacheNeedsReset;
    boolean_T blkStateChange;
  } ModelData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T *t;
    time_T tStart;
    time_T tFinal;
    time_T stepSize;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
  } Timing;

  /*
   * Work:
   * The following substructure contains information regarding
   * the work vectors in the model.
   */
  struct {
    struct _ssDWorkRecord *dwork;
  } Work;
};

/* Simulation structure */
extern rtModel_IEEE80211g *const rtM_IEEE80211g;

/* Macros for accessing real-time model data structure  */
#ifndef rtmGetBlkStateChangeFlag
# define rtmGetBlkStateChangeFlag(rtm) ((rtm)->ModelData.blkStateChange)
#endif

#ifndef rtmSetBlkStateChangeFlag
# define rtmSetBlkStateChangeFlag(rtm, val) ((rtm)->ModelData.blkStateChange = (val))
#endif

#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm) ((rtm)->ModelData.blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val) ((rtm)->ModelData.blockIO = (val))
#endif

#ifndef rtmGetCTaskTicks
# define rtmGetCTaskTicks(rtm) ((rtm)->Timing.cTaskTicks)
#endif

#ifndef rtmSetCTaskTicks
# define rtmSetCTaskTicks(rtm, val) ((rtm)->Timing.cTaskTicks = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm) ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val) ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetClockTick
# define rtmGetClockTick(rtm) ((rtm)->Timing.clockTick)
#endif

#ifndef rtmSetClockTick
# define rtmSetClockTick(rtm, val) ((rtm)->Timing.clockTick = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm) ((rtm)->ModelData.constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val) ((rtm)->ModelData.constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm) ((rtm)->ModelData.contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->ModelData.contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm) ((rtm)->ModelData.contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val) ((rtm)->ModelData.contStates = (val))
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm) ((rtm)->ModelData.defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val) ((rtm)->ModelData.defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->ModelData.derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->ModelData.derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm) ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetDiscStates
# define rtmGetDiscStates(rtm) ((rtm)->ModelData.discStates)
#endif

#ifndef rtmSetDiscStates
# define rtmSetDiscStates(rtm, val) ((rtm)->ModelData.discStates = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm) ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm) ((rtm)->Timing.firstInitCondFlag)
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ((rtm)->Timing.firstInitCondFlag = (val))
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm) ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm) ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val) ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNTaskTicks
# define rtmGetNTaskTicks(rtm) ((rtm)->Timing.nTaskTicks)
#endif

#ifndef rtmSetNTaskTicks
# define rtmSetNTaskTicks(rtm, val) ((rtm)->Timing.nTaskTicks = (val))
#endif

#ifndef rtmGetNonsampledZCs
# define rtmGetNonsampledZCs(rtm) ((rtm)->ModelData.nonsampledZCs)
#endif

#ifndef rtmSetNonsampledZCs
# define rtmSetNonsampledZCs(rtm, val) ((rtm)->ModelData.nonsampledZCs = (val))
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm) ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val) ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm) ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm) ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val) ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm) ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm) ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val) ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm) ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm) ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm) ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm) ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm) ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm) ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm) ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val) ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm) ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val) ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm) ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm) ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val) ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm) ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val) ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm) ((rtm)->ModelData.prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->ModelData.prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm) ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm) ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm) ((rtm)->rtwLogInfo)
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val) ((rtm)->rtwLogInfo = (val))
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ((rtm)->modelMethodsInfo)
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ((rtm)->modelMethodsInfo = (val))
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm) ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val) ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm) ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm) ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm) ((rtm)->Work.dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val) ((rtm)->Work.dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm) ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val) ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm) ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val) ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm) ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm) ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val) ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm) ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val) ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm) ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val) ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm) ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val) ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm) ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm) ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val) ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTaskTimes
# define rtmGetTaskTimes(rtm) ((rtm)->Timing.taskTimes)
#endif

#ifndef rtmSetTaskTimes
# define rtmSetTaskTimes(rtm, val) ((rtm)->Timing.taskTimes = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm) ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSetTimeOfLastOutput
# define rtmSetTimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm) ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val) ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm) ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val) ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm) ((rtm)->ModelData.inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val) ((rtm)->ModelData.inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm) ((rtm)->ModelData.outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val) ((rtm)->ModelData.outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm) ((rtm)->ModelData.zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->ModelData.zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm) ((rtm)->ModelData.derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val) ((rtm)->ModelData.derivs = (val))
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx) ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx) ((rtm)->Work.dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val) ((rtm)->Work.dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx) ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx) ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx) ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTime
# define rtmGetVarNextHitTime(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTime
# define rtmSetVarNextHitTime(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) (tid) == 0
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm) (rtm)->errorStatus
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val) (rtm)->errorStatus = ((val))
#endif

#ifndef rtmIsFirstInitCond
# define rtmIsFirstInitCond(rtm) rtmGetT((rtm)) == (rtmGetTStart((rtm)))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm) ((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm) ((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) ((rtm)->Timing.sampleTimeTaskIDPtr[sti] == (tid))
#endif

#ifndef rtmSetSampleHitInTask
# define rtmSetSampleHitInTask(rtm, tIdxj, tIdxi, val) ((rtm)->Timing.perTaskSampleHits)[(tIdxj)+((tIdxi) * ((rtm)->Sizes.numSampTimes))]=((val))
#endif

#ifndef rtmIsSpecialSampleHit
# define rtmIsSpecialSampleHit(rtm, sti, prom_sti, tid) (rtmIsMajorTimeStep((rtm)) && (rtm)->Timing.perTaskSampleHits[(rtm)->Timing.sampleTimeTaskIDPtr[sti]+((tid) * ((rtm)->Sizes.numSampTimes))])
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm) (rtm)->Timing.stopRequestedFlag
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) (rtm)->Timing.stopRequestedFlag = ((val))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm) rtmGetTPtr((rtm))[0]
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val) rtmGetTPtr((rtm))[0] = ((val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm) (rtm)->Timing.t
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val) (rtm)->Timing.t = ((val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm) (rtm)->Timing.tStart
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val) (rtm)->Timing.tStart = ((val))
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti) rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]]
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) rtmGetTPtr((rtm))[sti] = ((val))
#endif

/* Definition for use in the target main file */
#define IEEE80211g_rtModel              rtModel_IEEE80211g

extern Parameters rtP;                  /* parameters */

/* External data declarations for dependent source files */

/* non-finites */
extern real_T rtInf;
extern real_T rtMinusInf;

/* 
 * The generated code includes comments that allow you to trace directly 
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : IEEE80211g
 * '<S1>'   : IEEE80211g/Adaptive  Modulation  Control
 * '<S2>'   : IEEE80211g/Channel
 * '<S3>'   : IEEE80211g/DocBlock
 * '<S4>'   : IEEE80211g/MATLAB graphics1
 * '<S5>'   : IEEE80211g/MSE Calculation
 * '<S6>'   : IEEE80211g/Reciever
 * '<S7>'   : IEEE80211g/Transmitter
 * '<S8>'   : IEEE80211g/Adaptive  Modulation  Control/Bit Rate
 * '<S9>'   : IEEE80211g/Adaptive  Modulation  Control/SNR down threshold
 * '<S10>'  : IEEE80211g/Adaptive  Modulation  Control/SNR up threshold
 * '<S11>'  : IEEE80211g/Channel/Multipath channel
 * '<S12>'  : IEEE80211g/Channel/Multipath channel/AWGN Channel
 * '<S13>'  : IEEE80211g/Channel/Multipath channel/Frame Status Conversion1
 * '<S14>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1
 * '<S15>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2
 * '<S16>'  : IEEE80211g/Channel/Multipath channel/dB Conversion1
 * '<S17>'  : IEEE80211g/Channel/Multipath channel/invdB1
 * '<S18>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel
 * '<S19>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile
 * '<S20>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Multiple Delayed Signals
 * '<S21>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Multiply with  back propagation
 * '<S22>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile/Rebuffer with  Input Trigger
 * '<S23>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile/Rician Channel  Effects
 * '<S24>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile/Triggered Rayleigh Profile
 * '<S25>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Fading Profile/Triggered Rayleigh Profile/Frame Status Conversion
 * '<S26>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel1/Multipath Fading Channel/Multiple Delayed Signals/Check Signal Attributes
 * '<S27>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel
 * '<S28>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile
 * '<S29>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Multiple Delayed Signals
 * '<S30>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Multiply with  back propagation
 * '<S31>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile/Rebuffer with  Input Trigger
 * '<S32>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile/Rician Channel  Effects
 * '<S33>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile/Triggered Rayleigh Profile
 * '<S34>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Fading Profile/Triggered Rayleigh Profile/Frame Status Conversion
 * '<S35>'  : IEEE80211g/Channel/Multipath channel/Multipath Rayleigh Fading Channel2/Multipath Fading Channel/Multiple Delayed Signals/Check Signal Attributes
 * '<S36>'  : IEEE80211g/Channel/Multipath channel/dB Conversion1/Err if non-flt
 * '<S37>'  : IEEE80211g/Channel/Multipath channel/dB Conversion1/Error if Cplx
 * '<S38>'  : IEEE80211g/MATLAB graphics1/Transform data
 * '<S39>'  : IEEE80211g/MATLAB graphics1/append1
 * '<S40>'  : IEEE80211g/MATLAB graphics1/append2
 * '<S41>'  : IEEE80211g/MATLAB graphics1/append3
 * '<S42>'  : IEEE80211g/MATLAB graphics1/append7
 * '<S43>'  : IEEE80211g/MATLAB graphics1/Transform data/Frame Status Conversion
 * '<S44>'  : IEEE80211g/MSE Calculation/dB Conversion
 * '<S45>'  : IEEE80211g/MSE Calculation/dB Conversion/Err if non-flt
 * '<S46>'  : IEEE80211g/MSE Calculation/dB Conversion/Error if Cplx
 * '<S47>'  : IEEE80211g/Reciever/Demodulator1
 * '<S48>'  : IEEE80211g/Reciever/Demultiplex
 * '<S49>'  : IEEE80211g/Reciever/Equalizer
 * '<S50>'  : IEEE80211g/Reciever/Select symbols
 * '<S51>'  : IEEE80211g/Reciever/Transform to frequency domain
 * '<S52>'  : IEEE80211g/Reciever/remove cyclic prefix
 * '<S53>'  : IEEE80211g/Reciever/remove pilots and deframe
 * '<S54>'  : IEEE80211g/Reciever/training
 * '<S55>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 1
 * '<S56>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 10
 * '<S57>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 11
 * '<S58>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 12
 * '<S59>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 2
 * '<S60>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 3
 * '<S61>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 4
 * '<S62>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 5
 * '<S63>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 6
 * '<S64>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 7
 * '<S65>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 8
 * '<S66>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 9
 * '<S67>'  : IEEE80211g/Reciever/Demodulator1/Frame Status Conversion
 * '<S68>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 1/Matrix Deinterleaver
 * '<S69>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 1/Unipolar to Bipolar Converter2
 * '<S70>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 10/Matrix Deinterleaver
 * '<S71>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 10/Unipolar to Bipolar Converter2
 * '<S72>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 11/Matrix Deinterleaver
 * '<S73>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 11/Unipolar to Bipolar Converter2
 * '<S74>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 12/Matrix Deinterleaver
 * '<S75>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 12/Unipolar to Bipolar Converter2
 * '<S76>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 2/Matrix Deinterleaver
 * '<S77>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 2/Unipolar to Bipolar Converter2
 * '<S78>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 3/Matrix Deinterleaver
 * '<S79>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 3/Unipolar to Bipolar Converter2
 * '<S80>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 4/Matrix Deinterleaver
 * '<S81>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 4/Unipolar to Bipolar Converter2
 * '<S82>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 5/Matrix Deinterleaver
 * '<S83>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 5/Unipolar to Bipolar Converter2
 * '<S84>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 6/Matrix Deinterleaver
 * '<S85>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 6/Unipolar to Bipolar Converter2
 * '<S86>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 7/Matrix Deinterleaver
 * '<S87>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 7/Unipolar to Bipolar Converter2
 * '<S88>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 8/Matrix Deinterleaver
 * '<S89>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 8/Unipolar to Bipolar Converter2
 * '<S90>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 9/Matrix Deinterleaver
 * '<S91>'  : IEEE80211g/Reciever/Demodulator1/Demodulator 9/Unipolar to Bipolar Converter2
 * '<S92>'  : IEEE80211g/Reciever/Equalizer/Equalizer gains
 * '<S93>'  : IEEE80211g/Reciever/Equalizer/Equalizer gains/Frame Status Conversion
 * '<S94>'  : IEEE80211g/Reciever/Transform to frequency domain/Frame Status Conversion
 * '<S95>'  : IEEE80211g/Reciever/training/Frame Status Conversion
 * '<S96>'  : IEEE80211g/Transmitter/Assemble OFDM frame
 * '<S97>'  : IEEE80211g/Transmitter/Data Generator
 * '<S98>'  : IEEE80211g/Transmitter/Group into OFDM symbols
 * '<S99>'  : IEEE80211g/Transmitter/Modulator1
 * '<S100>' : IEEE80211g/Transmitter/Multiplex
 * '<S101>' : IEEE80211g/Transmitter/Pilots
 * '<S102>' : IEEE80211g/Transmitter/Transform to time domain
 * '<S103>' : IEEE80211g/Transmitter/cyclic prefix
 * '<S104>' : IEEE80211g/Transmitter/training sequence
 * '<S105>' : IEEE80211g/Transmitter/Assemble OFDM frame/DC value
 * '<S106>' : IEEE80211g/Transmitter/Assemble OFDM frame/DC value/Frame Status Conversion
 * '<S107>' : IEEE80211g/Transmitter/Data Generator/Binary source
 * '<S108>' : IEEE80211g/Transmitter/Data Generator/Source enable
 * '<S109>' : IEEE80211g/Transmitter/Data Generator/Source enable/slot size
 * '<S110>' : IEEE80211g/Transmitter/Modulator1/Modulator 1
 * '<S111>' : IEEE80211g/Transmitter/Modulator1/Modulator 10
 * '<S112>' : IEEE80211g/Transmitter/Modulator1/Modulator 11
 * '<S113>' : IEEE80211g/Transmitter/Modulator1/Modulator 12
 * '<S114>' : IEEE80211g/Transmitter/Modulator1/Modulator 2
 * '<S115>' : IEEE80211g/Transmitter/Modulator1/Modulator 3
 * '<S116>' : IEEE80211g/Transmitter/Modulator1/Modulator 4
 * '<S117>' : IEEE80211g/Transmitter/Modulator1/Modulator 5
 * '<S118>' : IEEE80211g/Transmitter/Modulator1/Modulator 6
 * '<S119>' : IEEE80211g/Transmitter/Modulator1/Modulator 7
 * '<S120>' : IEEE80211g/Transmitter/Modulator1/Modulator 8
 * '<S121>' : IEEE80211g/Transmitter/Modulator1/Modulator 9
 * '<S122>' : IEEE80211g/Transmitter/Modulator1/Modulator 1/Matrix Interleaver
 * '<S123>' : IEEE80211g/Transmitter/Modulator1/Modulator 10/Matrix Interleaver
 * '<S124>' : IEEE80211g/Transmitter/Modulator1/Modulator 11/Matrix Interleaver
 * '<S125>' : IEEE80211g/Transmitter/Modulator1/Modulator 12/Matrix Interleaver
 * '<S126>' : IEEE80211g/Transmitter/Modulator1/Modulator 2/Matrix Interleaver
 * '<S127>' : IEEE80211g/Transmitter/Modulator1/Modulator 3/Matrix Interleaver
 * '<S128>' : IEEE80211g/Transmitter/Modulator1/Modulator 4/Matrix Interleaver
 * '<S129>' : IEEE80211g/Transmitter/Modulator1/Modulator 5/Matrix Interleaver
 * '<S130>' : IEEE80211g/Transmitter/Modulator1/Modulator 6/Matrix Interleaver
 * '<S131>' : IEEE80211g/Transmitter/Modulator1/Modulator 7/Matrix Interleaver
 * '<S132>' : IEEE80211g/Transmitter/Modulator1/Modulator 8/Matrix Interleaver
 * '<S133>' : IEEE80211g/Transmitter/Modulator1/Modulator 9/Matrix Interleaver
 * '<S134>' : IEEE80211g/Transmitter/Pilots/Unipolar to Bipolar Converter
 * '<S135>' : IEEE80211g/Transmitter/training sequence/Frame Status Conversion
 */

#endif                                  /* _RTW_HEADER_IEEE80211g_h_ */
