/*
 *  rtmodel.h:
 *
 * Real-Time Workshop code generation for Simulink model "IEEE80211g.mdl".
 *
 * Model Version                        : 1.100
 * Real-Time Workshop file version      : 5.0 $Date: 2002/05/30 19:21:33 $
 * Real-Time Workshop file generated on : Tue Apr 19 05:23:12 2005
 * TLC version                          : 5.0 (Jun 18 2002)
 * C source code generated on           : Tue Apr 19 05:23:14 2005
 */

#ifndef _RTW_HEADER_rtmodel_h_
# define _RTW_HEADER_rtmodel_h_

/*
 *  Includes the appropriate headers when we are using rtModel
 */
#include "IEEE80211g.h"

#endif                                  /* _RTW_HEADER_rtmodel_h_ */
