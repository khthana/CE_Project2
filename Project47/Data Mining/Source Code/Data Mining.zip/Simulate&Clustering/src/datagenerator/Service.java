package datagenerator;

//import java.awt.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dbswing.*;
import java.util.*;
import java.sql.*;
import java.awt.event.*;
import java.io.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Service extends JFrame {
  private XYLayout xYLayout1 = new XYLayout();
  private JLabel numberOfCustomerLabel = new JLabel();
  private JTextField cus_noTextField = new JTextField();
  private JLabel conditionLabel = new JLabel();
  private JLabel cus_percentLabel = new JLabel();
  private JTextField cus_percentTextField = new JTextField();
  private JLabel serv_rateLabel = new JLabel();
  private JTextField serv_rateTextField1 = new JTextField();
  private JLabel after_setup_rateLabel = new JLabel();
  private JTextField after_setup_rateTextField1 = new JTextField();
  private JLabel not_finish_rateLabel = new JLabel();
  private JTextField not_finish_rateTextField1 = new JTextField();
  private JLabel year_noLabel = new JLabel();
  private JTextField year_noTextField1 = new JTextField();
  private JLabel point_percentLabel = new JLabel();
  private JLabel point1Label = new JLabel();
  private JTextField point1TextField = new JTextField();
  private JLabel point2Label = new JLabel();
  private JTextField point2TextField = new JTextField();
  private JLabel point3Label = new JLabel();
  private JTextField point3TextField = new JTextField();
  private JLabel point4Label = new JLabel();
  private JTextField point4TextField = new JTextField();
  private JLabel point5Label5 = new JLabel();
  private JTextField point5TextField = new JTextField();
  private JList conditionJList = new JList();
  private JButton deleteButton = new JButton();
  private JButton insertButton = new JButton();
  private JButton generateDataButton = new JButton();
  private Database database1 = new Database();
  private QueryDataSet queryDataSet1 = new QueryDataSet();
  private TableScrollPane tableScrollPane1 = new TableScrollPane();
  private JdbTable serv_ratedbTable1 = new JdbTable();

  static final String JDBC_DRIVER = "sun.jdbc.odbc.JdbcOdbcDriver";
  static final String DATABASE_URL = "jdbc:odbc:datamining";
  private QueryExecute queryExecute;
  private String query;

  private double cus_no;
  private int count = 0;
  private List cus_percentList = new LinkedList();
  private List serv_rateList1 = new LinkedList();
  private List serv_rateList2 = new LinkedList();
  private List serv_rateList3 = new LinkedList();
  private List serv_rateList4 = new LinkedList();
  private List serv_rateList5 = new LinkedList();

  private List after_setup_rateList1 = new LinkedList();
  private List after_setup_rateList2 = new LinkedList();
  private List after_setup_rateList3 = new LinkedList();
  private List after_setup_rateList4 = new LinkedList();
  private List after_setup_rateList5 = new LinkedList();

  private List not_finish_rateList1 = new LinkedList();
  private List not_finish_rateList2 = new LinkedList();
  private List not_finish_rateList3 = new LinkedList();
  private List not_finish_rateList4 = new LinkedList();
  private List not_finish_rateList5 = new LinkedList();

  private List year_noList1 = new LinkedList();
  private List year_noList2 = new LinkedList();
  private List year_noList3 = new LinkedList();
  private List year_noList4 = new LinkedList();
  private List year_noList5 = new LinkedList();

  private List point1List = new LinkedList();
  private List point2List = new LinkedList();
  private List point3List = new LinkedList();
  private List point4List = new LinkedList();
  private List point5List = new LinkedList();
  private List conditionList = new LinkedList();
  private JScrollPane jScrollPane2 = new JScrollPane();
  private JButton deleteDataButton = new JButton();
  private JTextField not_finish_rateTextField2 = new JTextField();
  private JTextField year_noTextField2 = new JTextField();
  private JTextField serv_rateTextField2 = new JTextField();
  private JTextField after_setup_rateTextField2 = new JTextField();
  private JTextField after_setup_rateTextField3 = new JTextField();
  private JTextField not_finish_rateTextField3 = new JTextField();
  private JTextField year_noTextField3 = new JTextField();
  private JTextField serv_rateTextField3 = new JTextField();
  private JTextField after_setup_rateTextField4 = new JTextField();
  private JTextField not_finish_rateTextField4 = new JTextField();
  private JTextField year_noTextField4 = new JTextField();
  private JTextField serv_rateTextField4 = new JTextField();
  private JTextField after_setup_rateTextField5 = new JTextField();
  private JTextField not_finish_rateTextField5 = new JTextField();
  private JTextField year_noTextField5 = new JTextField();
  private JTextField serv_rateTextField5 = new JTextField();
  private JLabel PercentLabel = new JLabel();
  private JButton saveButton = new JButton();

  public Service() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    Service service = new Service();
  }
  private void jbInit() throws Exception {
    numberOfCustomerLabel.setText("Number of customers");
    this.getContentPane().setLayout(xYLayout1);
    xYLayout1.setWidth(681);
    xYLayout1.setHeight(609);
    conditionLabel.setFont(new java.awt.Font("Dialog", 1, 12));
    conditionLabel.setText("Conditions");
    cus_percentLabel.setText("Percent of customers");
    serv_rateLabel.setText("Service Rate");
    after_setup_rateLabel.setText("After set up Rate");
    not_finish_rateLabel.setText("Not finish Rate");
    year_noLabel.setText("Number of years");
    point_percentLabel.setText("Service points");
    point1Label.setText("1");
    point2Label.setText("2");
    point3Label.setText("3");
    point4Label.setText("4");
    point5Label5.setText("5");
    deleteButton.setEnabled(false);
    deleteButton.setText("Delete");
    deleteButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteButton_actionPerformed(e);
      }
    });
    insertButton.setText("Insert");
    insertButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        insertButton_actionPerformed(e);
      }
    });
    generateDataButton.setText("GenerateData");
    generateDataButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        generateDataButton_actionPerformed(e);
      }
    });

    cus_noTextField.setNextFocusableComponent(cus_percentTextField);
    cus_percentTextField.setNextFocusableComponent(serv_rateTextField1);
    cus_percentTextField.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        cus_percentTextField_focusGained(e);
      }
    });
    serv_rateTextField1.setNextFocusableComponent(serv_rateTextField2);
    serv_rateTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        serv_rateTextField1_focusGained(e);
      }
    });
    after_setup_rateTextField1.setNextFocusableComponent(after_setup_rateTextField2);
    after_setup_rateTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        after_setup_rateTextField1_focusGained(e);
      }
    });
    not_finish_rateTextField1.setNextFocusableComponent(not_finish_rateTextField2);
    not_finish_rateTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        not_finish_rateTextField1_focusGained(e);
      }
    });
    serv_ratedbTable1.setEditable(false);
    deleteDataButton.setText("DeleteData");
    deleteDataButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        deleteDataButton_actionPerformed(e);
      }
    });
    this.setTitle("Service");
    year_noTextField1.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        year_noTextField1_focusGained(e);
      }
    });
    point1TextField.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        point1TextField_focusGained(e);
      }
    });
    point2TextField.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        point2TextField_focusGained(e);
      }
    });
    point3TextField.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        point3TextField_focusGained(e);
      }
    });
    point4TextField.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        point4TextField_focusGained(e);
      }
    });
    point5TextField.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        point5TextField_focusGained(e);
      }
    });
    not_finish_rateTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        not_finish_rateTextField2_focusGained(e);
      }
    });
    not_finish_rateTextField2.setNextFocusableComponent(not_finish_rateTextField3);
    year_noTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        year_noTextField2_focusGained(e);
      }
    });
    serv_rateTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        serv_rateTextField2_focusGained(e);
      }
    });
    serv_rateTextField2.setNextFocusableComponent(serv_rateTextField3);
    after_setup_rateTextField2.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        after_setup_rateTextField2_focusGained(e);
      }
    });
    after_setup_rateTextField2.setNextFocusableComponent(after_setup_rateTextField3);
    after_setup_rateTextField3.setNextFocusableComponent(after_setup_rateTextField4);
    after_setup_rateTextField3.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        after_setup_rateTextField3_focusGained(e);
      }
    });
    not_finish_rateTextField3.setNextFocusableComponent(not_finish_rateTextField4);
    not_finish_rateTextField3.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        not_finish_rateTextField3_focusGained(e);
      }
    });
    year_noTextField3.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        year_noTextField3_focusGained(e);
      }
    });
    serv_rateTextField3.setNextFocusableComponent(serv_rateTextField4);
    serv_rateTextField3.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        serv_rateTextField3_focusGained(e);
      }
    });
    after_setup_rateTextField4.setNextFocusableComponent(after_setup_rateTextField5);
    after_setup_rateTextField4.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        after_setup_rateTextField4_focusGained(e);
      }
    });
    not_finish_rateTextField4.setNextFocusableComponent(not_finish_rateTextField5);
    not_finish_rateTextField4.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        not_finish_rateTextField4_focusGained(e);
      }
    });
    year_noTextField4.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        year_noTextField4_focusGained(e);
      }
    });
    serv_rateTextField4.setNextFocusableComponent(serv_rateTextField5);
    serv_rateTextField4.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        serv_rateTextField4_focusGained(e);
      }
    });
    after_setup_rateTextField5.setNextFocusableComponent(not_finish_rateTextField1);
    after_setup_rateTextField5.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        after_setup_rateTextField5_focusGained(e);
      }
    });
    not_finish_rateTextField5.setNextFocusableComponent(year_noTextField1);
    not_finish_rateTextField5.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        not_finish_rateTextField5_focusGained(e);
      }
    });
    year_noTextField5.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        year_noTextField5_focusGained(e);
      }
    });
    serv_rateTextField5.setNextFocusableComponent(after_setup_rateTextField1);
    serv_rateTextField5.addFocusListener(new java.awt.event.FocusAdapter() {
      public void focusGained(FocusEvent e) {
        serv_rateTextField5_focusGained(e);
      }
    });
    year_noTextField1.setNextFocusableComponent(year_noTextField2);
    year_noTextField2.setNextFocusableComponent(year_noTextField3);
    year_noTextField3.setNextFocusableComponent(year_noTextField4);
    year_noTextField4.setNextFocusableComponent(year_noTextField5);
    year_noTextField5.setNextFocusableComponent(point1TextField);
    point5TextField.setNextFocusableComponent(insertButton);
    PercentLabel.setFont(new java.awt.Font("Dialog", 1, 12));
    PercentLabel.setText("Percent");
    saveButton.setText("SaveConditions");
    saveButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        saveButton_actionPerformed(e);
      }
    });
    this.getContentPane().add(numberOfCustomerLabel,  new XYConstraints(5, 10, -1, -1));
    this.getContentPane().add(cus_noTextField,       new XYConstraints(135, 6, 70, -1));
    this.getContentPane().add(conditionLabel,   new XYConstraints(5, 30, -1, -1));
    this.getContentPane().add(cus_percentLabel,   new XYConstraints(10, 50, -1, -1));
    this.getContentPane().add(tableScrollPane1,   new XYConstraints(6, 412, 616, 191));
    this.getContentPane().add(jScrollPane2,    new XYConstraints(6, 264, 408, 143));
    this.getContentPane().add(cus_percentTextField, new XYConstraints(133, 47, 70, -1));
    this.getContentPane().add(deleteDataButton,  new XYConstraints(417, 346, 121, -1));
    this.getContentPane().add(generateDataButton,  new XYConstraints(417, 379, 121, -1));
    this.getContentPane().add(serv_rateTextField1, new XYConstraints(167, 91, 35, -1));
    this.getContentPane().add(serv_rateLabel,   new XYConstraints(10, 91, -1, -1));
    this.getContentPane().add(not_finish_rateLabel,  new XYConstraints(10, 151, -1, -1));
    this.getContentPane().add(year_noLabel,  new XYConstraints(10, 180, -1, -1));
    this.getContentPane().add(year_noTextField1, new XYConstraints(167, 180, 35, -1));
    this.getContentPane().add(not_finish_rateTextField1, new XYConstraints(167, 151, 35, -1));
    this.getContentPane().add(after_setup_rateTextField1, new XYConstraints(167, 121, 35, -1));
    this.getContentPane().add(point_percentLabel,  new XYConstraints(10, 208, -1, -1));
    this.getContentPane().add(point5TextField, new XYConstraints(346, 208, 35, -1));
    this.getContentPane().add(point1TextField, new XYConstraints(167, 208, 35, -1));
    this.getContentPane().add(point2TextField, new XYConstraints(212, 208, 35, -1));
    this.getContentPane().add(point3TextField, new XYConstraints(257, 208, 35, -1));
    this.getContentPane().add(point4TextField, new XYConstraints(301, 208, 35, -1));
    this.getContentPane().add(deleteButton, new XYConstraints(96, 234, 84, -1));
    this.getContentPane().add(insertButton, new XYConstraints(6, 234, 85, -1));
    this.getContentPane().add(point4Label, new XYConstraints(315, 70, -1, -1));
    this.getContentPane().add(point5Label5, new XYConstraints(360, 70, -1, -1));
    this.getContentPane().add(point1Label, new XYConstraints(181, 70, -1, -1));
    this.getContentPane().add(point2Label, new XYConstraints(226, 70, -1, -1));
    this.getContentPane().add(point3Label, new XYConstraints(271, 70, -1, -1));
    this.getContentPane().add(serv_rateTextField2, new XYConstraints(212, 91, 35, -1));
    this.getContentPane().add(not_finish_rateTextField2, new XYConstraints(212, 151, 35, -1));
    this.getContentPane().add(year_noTextField2, new XYConstraints(212, 180, 35, -1));
    this.getContentPane().add(after_setup_rateTextField2, new XYConstraints(212, 121, 35, -1));
    jScrollPane2.getViewport().add(conditionJList, null);
    tableScrollPane1.getViewport().add(serv_ratedbTable1, null);
    this.getContentPane().add(serv_rateTextField3, new XYConstraints(258, 91, 35, -1));
    this.getContentPane().add(after_setup_rateTextField3, new XYConstraints(258, 121, 35, -1));
    this.getContentPane().add(not_finish_rateTextField3, new XYConstraints(258, 151, 35, -1));
    this.getContentPane().add(year_noTextField3, new XYConstraints(258, 180, 35, -1));
    this.getContentPane().add(serv_rateTextField5, new XYConstraints(346, 91, 35, -1));
    this.getContentPane().add(after_setup_rateTextField5, new XYConstraints(346, 121, 35, -1));
    this.getContentPane().add(not_finish_rateTextField5, new XYConstraints(346, 151, 35, -1));
    this.getContentPane().add(year_noTextField5, new XYConstraints(346, 180, 35, -1));
    this.getContentPane().add(serv_rateTextField4,  new XYConstraints(301, 91, 35, -1));
    this.getContentPane().add(after_setup_rateTextField4, new XYConstraints(301, 121, 35, -1));
    this.getContentPane().add(not_finish_rateTextField4, new XYConstraints(301, 151, 35, -1));
    this.getContentPane().add(year_noTextField4, new XYConstraints(301, 180, 35, -1));
    this.getContentPane().add(PercentLabel, new XYConstraints(5, 71, -1, -1));
    this.getContentPane().add(after_setup_rateLabel,  new XYConstraints(10, 121, -1, -1));
    this.getContentPane().add(saveButton,           new XYConstraints(417, 311, -1, 28));

    database1.setConnection(new com.borland.dx.sql.dataset.ConnectionDescriptor("jdbc:odbc:datamining", "", "", false, "sun.jdbc.odbc.JdbcOdbcDriver"));
    queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, "SELECT * FROM SERVICE", null, true, Load.ALL));
    serv_ratedbTable1.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
    serv_ratedbTable1.setDataSet(queryDataSet1);
  }

  void insertButton_actionPerformed(ActionEvent e) {
    double check_cus = 0;

    String tmpstring[];
    for (int i = 0; i < cus_percentList.size() ; i++) check_cus = check_cus + Double.parseDouble(String.valueOf(cus_percentList.get(i)));
    if ( (Double.parseDouble( cus_percentTextField.getText() ) > 0.0) && (Double.parseDouble( cus_percentTextField.getText() ) <= 100.0) ) {
    if ( check_cus + Double.parseDouble( cus_percentTextField.getText() ) <= 100.0){
      boolean isCorrect = true;
      double per=0.0;
      int test=0;
      if ( point1TextField.getText().length() != 0 ){
        per += Integer.parseInt(point1TextField.getText());
        test++;
      }
      if ( point2TextField.getText().length() != 0 ){
        per += Integer.parseInt(point2TextField.getText());
        test++;
      }
      if ( point3TextField.getText().length() != 0 ){
        per += Integer.parseInt(point3TextField.getText());
        test++;
      }
      if ( point4TextField.getText().length() != 0 ){
        per += Integer.parseInt(point4TextField.getText());
        test++;
      }
      if ( point5TextField.getText().length() != 0 ){
        per += Integer.parseInt(point5TextField.getText());
        test++;
      }
      if ((per!=100.0)&&(test==5)) isCorrect = false;
      else if (per>100.0) isCorrect = false;
      if ( isCorrect ) {
        cus_percentList.add( cus_percentTextField.getText() );
        if ( serv_rateTextField1.getText().length() == 0 )
          serv_rateList1.add("-");
        else serv_rateList1.add( serv_rateTextField1.getText() );
        if ( serv_rateTextField2.getText().length() == 0 )
          serv_rateList2.add("-");
        else serv_rateList2.add( serv_rateTextField2.getText() );
        if ( serv_rateTextField3.getText().length() == 0 )
          serv_rateList3.add("-");
        else serv_rateList3.add( serv_rateTextField3.getText() );
        if ( serv_rateTextField4.getText().length() == 0 )
          serv_rateList4.add("-");
        else serv_rateList4.add( serv_rateTextField4.getText() );
        if ( serv_rateTextField5.getText().length() == 0 )
          serv_rateList5.add("-");
        else serv_rateList5.add( serv_rateTextField5.getText() );

        if ( after_setup_rateTextField1.getText().length() == 0 )
          after_setup_rateList1.add("-");
        else after_setup_rateList1.add( after_setup_rateTextField1.getText() );
        if ( after_setup_rateTextField2.getText().length() == 0 )
          after_setup_rateList2.add("-");
        else after_setup_rateList2.add( after_setup_rateTextField2.getText() );
        if ( after_setup_rateTextField3.getText().length() == 0 )
          after_setup_rateList3.add("-");
        else after_setup_rateList3.add( after_setup_rateTextField3.getText() );
        if ( after_setup_rateTextField4.getText().length() == 0 )
          after_setup_rateList4.add("-");
        else after_setup_rateList4.add( after_setup_rateTextField4.getText() );
        if ( after_setup_rateTextField5.getText().length() == 0 )
          after_setup_rateList5.add("-");
        else after_setup_rateList5.add( after_setup_rateTextField5.getText() );

        if ( not_finish_rateTextField1.getText().length() == 0 )
          not_finish_rateList1.add("-");
        else not_finish_rateList1.add( not_finish_rateTextField1.getText() );
        if ( not_finish_rateTextField2.getText().length() == 0 )
          not_finish_rateList2.add("-");
        else not_finish_rateList2.add( not_finish_rateTextField2.getText() );
        if ( not_finish_rateTextField3.getText().length() == 0 )
          not_finish_rateList3.add("-");
        else not_finish_rateList3.add( not_finish_rateTextField3.getText() );
        if ( not_finish_rateTextField4.getText().length() == 0 )
          not_finish_rateList4.add("-");
        else not_finish_rateList4.add( not_finish_rateTextField4.getText() );
        if ( not_finish_rateTextField5.getText().length() == 0 )
          not_finish_rateList5.add("-");
        else not_finish_rateList5.add( not_finish_rateTextField5.getText() );


        if ( year_noTextField1.getText().length() == 0  )
          year_noList1.add( "-" );
        else year_noList1.add( year_noTextField1.getText() );
        if ( year_noTextField2.getText().length() == 0  )
          year_noList2.add( "-" );
        else year_noList2.add( year_noTextField2.getText() );
        if ( year_noTextField3.getText().length() == 0  )
          year_noList3.add( "-" );
        else year_noList3.add( year_noTextField3.getText() );
        if ( year_noTextField4.getText().length() == 0  )
          year_noList4.add( "-" );
        else year_noList4.add( year_noTextField4.getText() );
        if ( year_noTextField5.getText().length() == 0  )
          year_noList5.add( "-" );
        else year_noList5.add( year_noTextField5.getText() );


        if ( point1TextField.getText().length() == 0 )
          point1List.add("-");
        else point1List.add( point1TextField.getText() );
        if ( point2TextField.getText().length() == 0 )
          point2List.add("-");
        else point2List.add( point2TextField.getText() );
        if ( point3TextField.getText().length() == 0 )
          point3List.add("-");
        else point3List.add( point3TextField.getText() );
        if ( point4TextField.getText().length() == 0 )
          point4List.add("-");
        else point4List.add( point4TextField.getText() );
        if ( point5TextField.getText().length() == 0 )
          point5List.add("-");
        else point5List.add( point5TextField.getText() );

      String temp;

      temp = "%cus = " + cus_percentTextField.getText() + "; sr = " ;
      temp = temp + serv_rateList1.get(serv_rateList1.size()-1) + "," ;
      temp = temp + serv_rateList2.get(serv_rateList2.size()-1) + "," ;
      temp = temp + serv_rateList3.get(serv_rateList3.size()-1) + "," ;
      temp = temp + serv_rateList4.get(serv_rateList4.size()-1) + "," ;
      temp = temp + serv_rateList5.get(serv_rateList5.size()-1) + "," ;
      temp += "; ar = ";
      temp = temp + after_setup_rateList1.get(after_setup_rateList1.size()-1) + ",";
      temp = temp + after_setup_rateList2.get(after_setup_rateList2.size()-1) + ",";
      temp = temp + after_setup_rateList3.get(after_setup_rateList3.size()-1) + ",";
      temp = temp + after_setup_rateList4.get(after_setup_rateList4.size()-1) + ",";
      temp = temp + after_setup_rateList5.get(after_setup_rateList5.size()-1) + ",";
      temp += "; nfr = ";
      temp = temp + not_finish_rateList1.get(not_finish_rateList1.size()-1) + ",";
      temp = temp + not_finish_rateList2.get(not_finish_rateList2.size()-1) + ",";
      temp = temp + not_finish_rateList3.get(not_finish_rateList3.size()-1) + ",";
      temp = temp + not_finish_rateList4.get(not_finish_rateList4.size()-1) + ",";
      temp = temp + not_finish_rateList5.get(not_finish_rateList5.size()-1) + ",";
      temp += "; noy = ";
      temp = temp + year_noList1.get(year_noList1.size()-1) + ",";
      temp = temp + year_noList2.get(year_noList2.size()-1) + ",";
      temp = temp + year_noList3.get(year_noList3.size()-1) + ",";
      temp = temp + year_noList4.get(year_noList4.size()-1) + ",";
      temp = temp + year_noList5.get(year_noList5.size()-1) + ",";
      temp += "; sp = " ;
      temp = temp + point1List.get(point1List.size()-1) + "," + point2List.get(point2List.size()-1) + ",";
      temp = temp + point3List.get(point3List.size()-1) + "," + point4List.get(point4List.size()-1) + ",";
      temp = temp + point5List.get(point5List.size()-1) + ";";
      count++;
      conditionList.add(temp);

      tmpstring = new String[count];
      for (int i=0; i < count; i++){
        tmpstring[i] = String.valueOf(conditionList.get(i));
      }

      conditionJList.setListData(tmpstring);
      deleteButton.setEnabled(true) ;
      }else JOptionPane.showMessageDialog( null, "all Percent of point must not over or less than 100%",
                                     "Input error", JOptionPane.ERROR_MESSAGE );
    }
    else JOptionPane.showMessageDialog( null, "all Percent of customer must not over 100%",
                                     "Input error", JOptionPane.ERROR_MESSAGE );
    }
    else JOptionPane.showMessageDialog( null, "Must input percent of customer",
                                     "Input error", JOptionPane.ERROR_MESSAGE );
  }

  void generateDataButton_actionPerformed(ActionEvent e) {
    try {
    if (cus_noTextField.getText().length() != 0){
      cus_no = Double.parseDouble(cus_noTextField.getText());
      database1.closeConnection();
      // connect to data base
      queryExecute = new QueryExecute( JDBC_DRIVER, DATABASE_URL);

      double conper = 0;
      int point = 0;
      int serv =0;
      double bound = 0;
      double xx=0;

      List nodata = new LinkedList();
      for (int i=0; i < cus_percentList.size() ; i++){
        xx = Double.parseDouble(String.valueOf(cus_percentList.get(i)))/100.0 *cus_no;
        conper = conper+Integer.parseInt(String.valueOf(cus_percentList.get(i)));
        for (int j=1; j <= Double.parseDouble(String.valueOf(cus_percentList.get(i))) * cus_no/100.0; j++){
          query = "INSERT INTO SERVICE (SERV_RATE,SERV_AFTER_SETUP_RATE,SERV_NOT_FINISH_RATE,NO_YEAR,SERV_POINT) ";
          query = query + "VALUES (" ;
////////////////////////////////////////////////////////////////////////
//          service rate point
////////////////////////////////////////////////////////////////////////
          nodata.clear();
          bound=0;
          serv =0;
          if (serv_rateList1.get(i) != "-") {
// This will make exactly match to percent input but no random ability
//            bound = Double.parseDouble(String.valueOf(serv_rateList1.get(i)))*xx;
//            if (Math.random()*100<bound){
// but we want to randomly then it may not match exactly it will be +-2%
            if (Math.random()*100 < Double.parseDouble(String.valueOf(serv_rateList1.get(i)))){
              serv = 1 ;
            }
          }
          if (serv==0) {
            if (serv_rateList2.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(serv_rateList2.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(serv_rateList2.get(i)))){
                serv = 2 ;
              }
            }
          }
          if (serv==0) {
            if (serv_rateList3.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(serv_rateList3.get(i)))/100.0*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(serv_rateList3.get(i)))){
                serv = 3 ;
              }
            }
          }
          if (serv==0) {
            if (serv_rateList4.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(serv_rateList4.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(serv_rateList4.get(i)))){
                serv = 4 ;
              }
            }
          }
          if (serv==0) {
            if (serv_rateList5.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(serv_rateList5.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(serv_rateList5.get(i)))){
                serv = 5 ;
              }
            }
          }
          if (serv==0){
            if (serv_rateList1.get(i) == "-") nodata.add("1");
            if (serv_rateList2.get(i) == "-") nodata.add("2");
            if (serv_rateList3.get(i) == "-") nodata.add("3");
            if (serv_rateList4.get(i) == "-") nodata.add("4");
            if (serv_rateList5.get(i) == "-") nodata.add("5");
            if (nodata.size()!=0){
              query = query + nodata.get((int)(Math.random()*nodata.size())) + ",";
            } else query += String.valueOf((int)(Math.random()*5)+1) + "," ;
          } else query += String.valueOf(serv) + ",";
//////////////////////////////////////////////////////////////////////
//              after setup rate point
//////////////////////////////////////////////////////////////////////
          nodata.clear();
          bound=0;
          serv =0;
          if (after_setup_rateList1.get(i) != "-") {
//            bound = Double.parseDouble(String.valueOf(after_setup_rateList1.get(i)))*xx;
//            if (Math.random()*100<bound){
            if (Math.random()*100 < Double.parseDouble(String.valueOf(after_setup_rateList1.get(i)))){
              serv = 1 ;
            }
          }
          if (serv==0) {
            if (after_setup_rateList2.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(after_setup_rateList2.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(after_setup_rateList2.get(i)))){
                serv = 2 ;
              }
            }
          }
          if (serv==0) {
            if (after_setup_rateList3.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(after_setup_rateList3.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(after_setup_rateList3.get(i)))){
                serv = 3 ;
              }
            }
          }
          if (serv==0) {
            if (after_setup_rateList4.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(after_setup_rateList4.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(after_setup_rateList4.get(i)))){
                serv = 4 ;
              }
            }
          }
          if (serv==0) {
            if (after_setup_rateList5.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(after_setup_rateList5.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(after_setup_rateList5.get(i)))){
                serv = 5 ;
              }
            }
          }
          if (serv==0){
            if (after_setup_rateList1.get(i) == "-") nodata.add("1");
            if (after_setup_rateList2.get(i) == "-") nodata.add("2");
            if (after_setup_rateList3.get(i) == "-") nodata.add("3");
            if (after_setup_rateList4.get(i) == "-") nodata.add("4");
            if (after_setup_rateList5.get(i) == "-") nodata.add("5");
            if (nodata.size()!=0){
              query = query + nodata.get((int)(Math.random()*nodata.size())) + ",";
            } else query += String.valueOf((int)(Math.random()*5)+1) + "," ;
          } else query += String.valueOf(serv) + ",";
//////////////////////////////////////////////////////////////////////
//         Not finish rate point
//////////////////////////////////////////////////////////////////////
          nodata.clear();
          bound=0;
          serv =0;
          if (not_finish_rateList1.get(i) != "-") {
//            bound = Double.parseDouble(String.valueOf(not_finish_rateList1.get(i)))*xx;
//            if (Math.random()*100<bound){
            if (Math.random()*100 < Double.parseDouble(String.valueOf(not_finish_rateList1.get(i)))){
              serv = 1 ;
            }
          }
          if (serv==0) {
            if (not_finish_rateList2.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(not_finish_rateList2.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(not_finish_rateList2.get(i)))){
                serv = 2 ;
              }
            }
          }
          if (serv==0) {
            if (not_finish_rateList3.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(not_finish_rateList3.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(not_finish_rateList3.get(i)))){
                serv = 3 ;
              }
            }
          }
          if (serv==0) {
            if (not_finish_rateList4.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(not_finish_rateList4.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(not_finish_rateList4.get(i)))){
                serv = 4 ;
              }
            }
          }
          if (serv==0) {
            if (not_finish_rateList5.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(not_finish_rateList5.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(not_finish_rateList5.get(i)))){
                serv = 5 ;
              }
            }
          }
          if (serv==0){
            if (not_finish_rateList1.get(i) == "-") nodata.add("1");
            if (not_finish_rateList2.get(i) == "-") nodata.add("2");
            if (not_finish_rateList3.get(i) == "-") nodata.add("3");
            if (not_finish_rateList4.get(i) == "-") nodata.add("4");
            if (not_finish_rateList5.get(i) == "-") nodata.add("5");
            if (nodata.size()!=0){
              query = query + nodata.get((int)(Math.random()*nodata.size())) + ",";
            } else query += String.valueOf((int)(Math.random()*5)+1) + "," ;
          } else query += String.valueOf(serv) + ",";

//////////////////////////////////////////////////////////////////////
          //         Year after setup(installation)
//////////////////////////////////////////////////////////////////////
          nodata.clear();
          bound=0;
          serv =0;
          if (year_noList1.get(i) != "-") {
//            bound = Double.parseDouble(String.valueOf(year_noList1.get(i)))*xx;
//            if (Math.random()*100<bound){
            if (Math.random()*100 < Double.parseDouble(String.valueOf(year_noList1.get(i)))){
              serv = 1 ;
            }
          }
          if (serv==0) {
            if (year_noList2.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(year_noList2.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(year_noList2.get(i)))){
                serv = 2 ;
              }
            }
          }
          if (serv==0) {
            if (year_noList3.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(year_noList3.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(year_noList3.get(i)))){
                serv = 3 ;
              }
            }
          }
          if (serv==0) {
            if (year_noList4.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(year_noList4.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(year_noList4.get(i)))){
                serv = 4 ;
              }
            }
          }
          if (serv==0) {
            if (year_noList5.get(i) != "-") {
//              bound = Double.parseDouble(String.valueOf(year_noList5.get(i)))*xx;
//              if (Math.random()*100<bound){
              if (Math.random()*100 < Double.parseDouble(String.valueOf(year_noList5.get(i)))){
                serv = 5 ;
              }
            }
          }
          if (serv==0){
            if (year_noList1.get(i) == "-") nodata.add("1");
            if (year_noList2.get(i) == "-") nodata.add("2");
            if (year_noList3.get(i) == "-") nodata.add("3");
            if (year_noList4.get(i) == "-") nodata.add("4");
            if (year_noList5.get(i) == "-") nodata.add("5");
            if (nodata.size()!=0){
              query = query + nodata.get((int)(Math.random()*nodata.size())) + ",";
            } else query += String.valueOf((int)(Math.random()*5)+1) + "," ;
          } else query += String.valueOf(serv) + ",";
///////////////////////////////////////////////////////////////////////////////

          nodata.clear();
          bound = 0;
          if (point1List.get(i) != "-") {
            bound = Double.parseDouble(String.valueOf(point1List.get(i)))/100.0 * Double.parseDouble(String.valueOf(cus_percentList.get(i)))/100.0 *cus_no;
            if ( j <= bound ){
              query = query + 1 + ")";
              queryExecute.setQuery(query);
              continue;
            }
          } else nodata.add("1");

          if (point2List.get(i) != "-" ){
            bound += Double.parseDouble(String.valueOf(point2List.get(i)))/100.0 * Double.parseDouble(String.valueOf(cus_percentList.get(i)))/100.0 *cus_no;
            if ( j <= bound ){
              query = query + 2 + ")";
              queryExecute.setQuery(query);
              continue;
            }
          } else nodata.add("2");

          if (point3List.get(i) != "-" ){
            bound += Double.parseDouble(String.valueOf(point3List.get(i)))/100.0 * Double.parseDouble(String.valueOf(cus_percentList.get(i)))/100.0 *cus_no;
            if ( j <= bound ){
              query = query + 3 + ")";
              queryExecute.setQuery(query);
              continue;
            }
          } else nodata.add("3");

          if (point4List.get(i) != "-" ){
            bound += Double.parseDouble(String.valueOf(point4List.get(i)))/100.0 * Double.parseDouble(String.valueOf(cus_percentList.get(i)))/100.0 *cus_no;
            if ( j <= bound ){
              query = query + 4 + ")";
              queryExecute.setQuery(query);
              continue;
            }
          } else nodata.add("4");

          if (point5List.get(i) != "-" ){
            bound += Double.parseDouble(String.valueOf(point5List.get(i)))/100.0 * Double.parseDouble(String.valueOf(cus_percentList.get(i)))/100.0 *cus_no;
            if ( j <= bound ){
              query = query + 5 + ")";
              queryExecute.setQuery(query);
              continue;
            }
          } else nodata.add("5");

          query = query + nodata.get((int)(Math.random()*nodata.size())) + ")";
          queryExecute.setQuery(query);

        } // end for j
      } // end for i
      if (conper < 100) {
        for (int j=1; j <= (100-conper)*cus_no/100; j++){
          query = "INSERT INTO SERVICE (SERV_RATE,SERV_AFTER_SETUP_RATE,SERV_NOT_FINISH_RATE,NO_YEAR,SERV_POINT) ";
          query = query + "VALUES (";
          for (int x=1; x <= 5; x++) {
            int tempran=0;
            switch (x){
              case 1 : tempran = (int)(Math.random()*5)+1;/*SERV_RATE*/
                break;
              case 2 : tempran = (int)(Math.random()*5)+1;/*AFTER_SET_UP_RATE*/
                break;
              case 3 : tempran = (int)(Math.random()*5)+1;/*NOT_FINISH_RATE*/
                break;
              case 4 : tempran = (int)(Math.random()*5)+1;/*NO_YEAR*/
                break;
              case 5 : tempran = (int)(Math.random()*5)+1;/*SERV_POINT*/
                break;
            }
          query += tempran;
          if (x<5) query += ",";
        }
        query += ")";
          queryExecute.setQuery(query);
        }
      }
      queryExecute.disconnectFromDatabase();
      database1.openConnection();
      queryDataSet1.refresh();
    }// end if
    else JOptionPane.showMessageDialog ( null, "Must input number of customers",
                                      "Input Error", JOptionPane.ERROR_MESSAGE );
    }// end try

    // detect problems interaction with the database
    catch ( SQLException sqlException ) {
      JOptionPane.showMessageDialog ( null, sqlException.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE );
      queryExecute.disconnectFromDatabase() ;

    //  System.exit( 1 );
    }
    // detect problems loading database driver
    catch ( ClassNotFoundException classNotFound ) {
      JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
                                     "Driver Not Found", JOptionPane.ERROR_MESSAGE );
      System.exit( 1 );
    }
  }

  void deleteButton_actionPerformed(ActionEvent e) {
    if (!conditionJList.isSelectionEmpty() ) {
      for (int i = conditionJList.getHeight();i>=0; i--) {
        if (conditionJList.isSelectedIndex(i)){
          count--;
          conditionList.remove(i) ;
          cus_percentList.remove(i) ;
          serv_rateList1.remove(i) ;
          serv_rateList2.remove(i) ;
          serv_rateList3.remove(i) ;
          serv_rateList4.remove(i) ;
          serv_rateList5.remove(i) ;
          after_setup_rateList1.remove(i) ;
          after_setup_rateList2.remove(i) ;
          after_setup_rateList3.remove(i) ;
          after_setup_rateList4.remove(i) ;
          after_setup_rateList5.remove(i) ;
          not_finish_rateList1.remove(i) ;
          not_finish_rateList2.remove(i) ;
          not_finish_rateList3.remove(i) ;
          not_finish_rateList4.remove(i) ;
          not_finish_rateList5.remove(i) ;
          year_noList1.remove(i) ;
          year_noList2.remove(i) ;
          year_noList3.remove(i) ;
          year_noList4.remove(i) ;
          year_noList5.remove(i) ;
          point1List.remove(i) ;
          point2List.remove(i) ;
          point3List.remove(i) ;
          point4List.remove(i) ;
          point5List.remove(i) ;
        }
      }
      String tmpstring[] = new String[count];
      for (int i=0; i < count; i++){
        tmpstring[i] = String.valueOf(conditionList.get(i));
      }
      conditionJList.setListData(tmpstring);
    }
    if (conditionList.size() == 0) deleteButton.setEnabled(false) ;

  }

  void deleteDataButton_actionPerformed(ActionEvent e) {
    try {
      database1.closeConnection();
      queryExecute = new QueryExecute( JDBC_DRIVER, DATABASE_URL);
      query ="DELETE FROM SERVICE";
      queryExecute.setQuery(query);
      queryExecute.disconnectFromDatabase();
      database1.openConnection();
      queryDataSet1.refresh();
    }
    // detect problems interaction with the database
    catch ( SQLException sqlException ) {
      JOptionPane.showMessageDialog ( null, sqlException.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE );
      queryExecute.disconnectFromDatabase() ;

    //  System.exit( 1 );
    }
    // detect problems loading database driver
    catch ( ClassNotFoundException classNotFound ) {
      JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
                                     "Driver Not Found", JOptionPane.ERROR_MESSAGE );
      System.exit( 1 );
    }
  }

  void cus_percentTextField_focusGained(FocusEvent e) {
    cus_percentTextField.selectAll();
  }

  void serv_rateTextField1_focusGained(FocusEvent e) {
    serv_rateTextField1.selectAll();
  }

  void after_setup_rateTextField1_focusGained(FocusEvent e) {
    after_setup_rateTextField1.selectAll();
  }

  void not_finish_rateTextField1_focusGained(FocusEvent e) {
    not_finish_rateTextField1.selectAll();
  }

  void year_noTextField1_focusGained(FocusEvent e) {
    year_noTextField1.selectAll();
  }

  void point1TextField_focusGained(FocusEvent e) {
    point1TextField.selectAll();
  }

  void point2TextField_focusGained(FocusEvent e) {
    point2TextField.selectAll();
  }

  void point3TextField_focusGained(FocusEvent e) {
    point3TextField.selectAll();
  }

  void point4TextField_focusGained(FocusEvent e) {
    point4TextField.selectAll();
  }

  void point5TextField_focusGained(FocusEvent e) {
    point5TextField.selectAll();
  }
  void not_finish_rateTextField2_focusGained(FocusEvent e) {
    not_finish_rateTextField2.selectAll();
  }
  void year_noTextField2_focusGained(FocusEvent e) {
    year_noTextField2.selectAll();
  }
  void serv_rateTextField2_focusGained(FocusEvent e) {
    serv_rateTextField2.selectAll();
  }
  void after_setup_rateTextField2_focusGained(FocusEvent e) {
    after_setup_rateTextField2.selectAll();
  }
  void after_setup_rateTextField3_focusGained(FocusEvent e) {
    after_setup_rateTextField3.selectAll();
  }
  void not_finish_rateTextField3_focusGained(FocusEvent e) {
    not_finish_rateTextField3.selectAll();
  }
  void year_noTextField3_focusGained(FocusEvent e) {
    year_noTextField3.selectAll();
  }
  void serv_rateTextField3_focusGained(FocusEvent e) {
    serv_rateTextField3.selectAll();
  }
  void after_setup_rateTextField4_focusGained(FocusEvent e) {
    after_setup_rateTextField4.selectAll();
  }
  void not_finish_rateTextField4_focusGained(FocusEvent e) {
    not_finish_rateTextField4.selectAll();
  }
  void year_noTextField4_focusGained(FocusEvent e) {
    year_noTextField4.selectAll();
  }
  void serv_rateTextField4_focusGained(FocusEvent e) {
    serv_rateTextField4.selectAll();
  }
  void after_setup_rateTextField5_focusGained(FocusEvent e) {
    after_setup_rateTextField5.selectAll();
  }
  void not_finish_rateTextField5_focusGained(FocusEvent e) {
    not_finish_rateTextField5.selectAll();
  }
  void year_noTextField5_focusGained(FocusEvent e) {
    year_noTextField5.selectAll();
  }
  void serv_rateTextField5_focusGained(FocusEvent e) {
    serv_rateTextField5.selectAll();
  }

  void saveButton_actionPerformed(ActionEvent e) {

    FileOutputStream output;
    PrintStream pstream;

    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );

    int result = fileChooser.showSaveDialog( this );

    if ( result == JFileChooser.CANCEL_OPTION )
      return;

    File name = fileChooser.getSelectedFile();

    if (name == null || name.getName().equals(""))
      JOptionPane.showMessageDialog( this, "Invalid File Name" , "Invalid File Name",
                                      JOptionPane.ERROR_MESSAGE );
    else {

      try{
        output = new FileOutputStream( name ) ;
        pstream = new PrintStream(output);
        pstream.println("Number of customer = "+cus_noTextField.getText());
        for (int i=0; i < conditionList.size(); i++){
          pstream.println(String.valueOf(conditionList.get(i)));
          pstream.flush();
        }
        pstream.close();
      }

      catch (IOException ioException ){
        JOptionPane.showMessageDialog(this, "Error writing to file", "IO Exception", JOptionPane.ERROR_MESSAGE);
      }
    }

  }
}