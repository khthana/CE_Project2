package datagenerator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class MainFrame extends JFrame {
  private JMenuBar jMenuBar1 = new JMenuBar();
  private JMenu filesMenu = new JMenu();
  private JMenuItem aboutMenuItem = new JMenuItem();
  private JMenuItem exitMenuItem = new JMenuItem();
  private JMenu openMenu = new JMenu();
  private XYLayout xYLayout1 = new XYLayout();
  private JMenuItem productMenuItem = new JMenuItem();
  private JMenuItem serviceMenuItem = new JMenuItem();
  private ItemHandler itemHandler = new ItemHandler();

  public MainFrame() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    MainFrame mainFrame = new MainFrame();
  }
  private void jbInit() throws Exception {
    this.getContentPane().setLayout(xYLayout1);
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setJMenuBar(jMenuBar1);
    this.setTitle("DataGenerator");
    filesMenu.setMnemonic('F');
    filesMenu.setText("Files");
    aboutMenuItem.setMnemonic('A');
    aboutMenuItem.setText("About....");
    aboutMenuItem.addActionListener(
        new ActionListener() {
      public void actionPerformed( ActionEvent event )
      {
        JOptionPane.showMessageDialog(MainFrame.this,
        "This is a Data Generator program uses with Data Mining Technique For Air-condition Business program.",
        "About", JOptionPane.PLAIN_MESSAGE);
      }
        }
    );
    exitMenuItem.setMnemonic('X');
    exitMenuItem.setText("Exit");
    exitMenuItem.setAccelerator(javax.swing.KeyStroke.getKeyStroke(88, java.awt.event.KeyEvent.ALT_MASK, false));
    exitMenuItem.addActionListener(
        new ActionListener() {
      public void actionPerformed( ActionEvent enent ) {
        System.exit( 0 );
      }
        }
    );
    openMenu.setMnemonic('O');
    openMenu.setText("Open");
    productMenuItem.setMnemonic('P');
    productMenuItem.setText("Product");
    serviceMenuItem.setMnemonic('S');
    serviceMenuItem.setText("Service");
    filesMenu.add(aboutMenuItem);
    filesMenu.addSeparator();
    filesMenu.add(exitMenuItem);
    openMenu.add(productMenuItem);
    productMenuItem.addActionListener(itemHandler);
    openMenu.add(serviceMenuItem);
    serviceMenuItem.addActionListener(itemHandler);
    jMenuBar1.add(filesMenu);
    jMenuBar1.add(openMenu);

    setSize(1024,768);
    setVisible( true );
  }
  private class ItemHandler implements ActionListener {

  public void actionPerformed( ActionEvent event )
  {
    if ( productMenuItem.isArmed() ) {
      Product product = new Product();
      product.setSize( 1000,750 );
      product.setVisible(true);
    }
    if ( serviceMenuItem.isArmed() ) {
      Service service = new Service();
      service.setSize( 750,750 );
      service.setVisible(true);
    }
  }
  }
}