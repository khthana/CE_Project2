package datagenerator;
import java.sql.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class QueryExecute {
  // declare Connection and Statement for accessing and querying database
  private Connection connection;
  private Statement statement;

  // keep track of database connection status
  private boolean connectedToDatabase = false;

  public QueryExecute( String driver, String url )
      throws SQLException, ClassNotFoundException
  {
    // load database driver class
    Class.forName( driver );

    // connect to database
    connection = DriverManager.getConnection( url ) ;

    // create Statement to query database
    statement = connection.createStatement();
    // update database connection status
    connectedToDatabase = true;

    // set query and execute it
  //  setQuery( query );
  }

  // set new database query string
  public void setQuery( String query )
      throws SQLException, IllegalStateException
  {
    if ( !connectedToDatabase )
      throw new IllegalStateException( "Not Connected to Database" );
    // execute query
    statement.executeUpdate(query);

  }

  // close Statement and Connection
  public void disconnectFromDatabase()
  {
    // close Statement and Connection
    try {
      statement.close();
      connection.close();
    }

    // catch SQLException and print error message
    catch ( SQLException sqlException ) {
      sqlException.printStackTrace() ;
    }

    // update database connection status
    finally {
      connectedToDatabase = false;
    }
  }
}