package datagenerator;

import java.util.*;
import com.borland.jbcl.layout.*;
import javax.swing.*;
import java.awt.event.*;
import com.borland.dx.sql.dataset.*;
import com.borland.dbswing.*;
import java.sql.*;
import java.awt.*;
import com.borland.dx.dataset.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Cluster extends JDialog{
  private Connection connection;
  private Statement statement;
  private String driver="sun.jdbc.odbc.JdbcOdbcDriver";
  private String url="jdbc:odbc:datamining";
  private XYLayout xYLayout1 = new XYLayout();
  private XYLayout xYLayout2 = new XYLayout();
  private JTextField Num_of_Cluster = new JTextField();
  private JButton Button_OK = new JButton();
  private JLabel Label_Amount_Cluster = new JLabel();
  private JLabel Label_Result2 = new JLabel();
  private JLabel Label_numcluster = new JLabel();
  private JLabel Label_Result = new JLabel();
  private TableScrollPane tableScrollPane1 = new TableScrollPane();
  private JdbTable productdbTable = new JdbTable();
  private TableScrollPane tableScrollPane2 = new TableScrollPane();
  private JdbTable jdbTable1 = new JdbTable();
  private QueryDataSet queryDataSet1 = new QueryDataSet();
  private Database database1 = new Database();
  private QueryExecute queryExecute;
  private JLabel Label_Num = new JLabel();
  private JLabel Label_num_data = new JLabel();
  private String query;
  private String query_row;
  private int numdata = 0;
  private String output_text[];
  private String num_merge_text[];
  private JButton button_delete = new JButton();


  public Cluster(){
      try {
         // load database driver class
         Class.forName( driver );

         // establish connection to database
         connection = DriverManager.getConnection( url );

         // create Statement for querying database
         statement = connection.createStatement();

       } catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, sqlException.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }

      // detect problems loading database driver
      catch ( ClassNotFoundException classNotFound ) {
         JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
            "Driver Not Found", JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
      }

      try {
      jbInit();
      ResultSet count_row = statement.executeQuery( "SELECT * FROM product" );

        while ( count_row.next() ) {
          numdata++;
        }
      Label_num_data.setText(String.valueOf(numdata));
      }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    xYLayout2.setWidth(990);
    xYLayout2.setHeight(700);
    this.getContentPane().setLayout(xYLayout2);
    Button_OK.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        Button_OK_actionPerformed(e);
      }
    });
    Button_OK.setText("OK");
    Label_Amount_Cluster.setText("Amount_Cluster");
    Label_Result2.setHorizontalAlignment(SwingConstants.CENTER);
    Label_Result2.setText("groups After Clustering");

    Label_Result.setHorizontalAlignment(SwingConstants.CENTER);
    Label_Result.setText("Results show");
    queryDataSet1.setDisplayErrors(false);
    queryDataSet1.setQuery(new com.borland.dx.sql.dataset.QueryDescriptor(database1, "select * from cluster", null, true, Load.ALL));
    database1.setConnection(new com.borland.dx.sql.dataset.ConnectionDescriptor("jdbc:odbc:DataMining", "", "", false, "sun.jdbc.odbc.JdbcOdbcDriver"));
    jdbTable1.setDataSet(queryDataSet1);
    Label_Num.setHorizontalAlignment(SwingConstants.CENTER);
    Label_Num.setText("Number_Data");
    this.setTitle("Clustering");
    Label_numcluster.setHorizontalAlignment(SwingConstants.CENTER);
    Label_num_data.setHorizontalAlignment(SwingConstants.CENTER);
    button_delete.setText("Delete Cluster Data");
    button_delete.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        button_delete_actionPerformed(e);
      }
    });
    this.getContentPane().add(Label_Amount_Cluster,  new XYConstraints(56, 54, 106, 32));
    this.getContentPane().add(Num_of_Cluster,    new XYConstraints(177, 54, 49, 32));
    this.getContentPane().add(Button_OK,  new XYConstraints(266, 54, 58, 32));
    this.getContentPane().add(Label_Result, new XYConstraints(47, 108, 94, 39));
    this.getContentPane().add(tableScrollPane2,              new XYConstraints(20, 157, 942, 449));
    this.getContentPane().add(Label_Result2,   new XYConstraints(158, 108, 157, 39));
    this.getContentPane().add(Label_Num, new XYConstraints(52, 24, 87, 22));
    this.getContentPane().add(Label_numcluster, new XYConstraints(132, 108, 37, 39));
    this.getContentPane().add(Label_num_data,    new XYConstraints(131, 24, 66, 22));
    this.getContentPane().add(button_delete, new XYConstraints(379, 628, 153, 34));
    tableScrollPane2.getViewport().add(jdbTable1, null);
  }

  public void clus(int amount){
    int countrow=0;
    int count=0;
    String input;
    try {
      ResultSet resultSet = statement.executeQuery( "SELECT * FROM product" );
      StringBuffer results = new StringBuffer();
      ResultSetMetaData metaData = resultSet.getMetaData();
      int numberOfColumns = metaData.getColumnCount();

      /////// loop for read value from table to keep in array metric /////////////////
      LinkedList brand = new LinkedList();
      LinkedList quality = new LinkedList();
      LinkedList save_energy = new LinkedList();
      LinkedList airpure = new LinkedList();
      LinkedList quiet = new LinkedList();
      LinkedList beauty = new LinkedList();
      LinkedList price = new LinkedList();
      LinkedList service = new LinkedList();
      LinkedList other= new LinkedList();
      LinkedList merge = new LinkedList();

     //Store all data in table into Linklist for Clustering
      while ( resultSet.next() ) {
        brand.addLast(resultSet.getObject(1));
        quality.addLast(resultSet.getObject(2));
        save_energy.addLast(resultSet.getObject(3));
        airpure.addLast(resultSet.getObject(4));
        quiet.addLast(resultSet.getObject(5));
        beauty.addLast(resultSet.getObject(6));
        price.addLast(resultSet.getObject(7));
        service.addLast(resultSet.getObject(8));
        other.addLast(resultSet.getObject(9));
        merge.addLast( new Integer(1) );
      }

      // Clustering
      while (quality.size()>amount){
        double min = 100;
        double total = 0;
        int row =0,row2=0;
        double tmp[];
        tmp = new double[numberOfColumns];
        int countmerge=0;

      for (int i=0;i< brand.size()-1;i++){
         for (int j=i+1;j< brand.size();j++){

               total  =   Math.abs(Double.parseDouble(String.valueOf(brand.get(i))) - Double.parseDouble(String.valueOf(brand.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(quality.get(i))) - Double.parseDouble(String.valueOf( quality.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(save_energy.get(i))) - Double.parseDouble(String.valueOf(save_energy.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(airpure.get(i))) - Double.parseDouble(String.valueOf(airpure.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(quiet.get(i))) - Double.parseDouble(String.valueOf(quiet.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(beauty.get(i))) - Double.parseDouble(String.valueOf(beauty.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(price.get(i))) - Double.parseDouble(String.valueOf(price.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(service.get(i))) - Double.parseDouble(String.valueOf(service.get(j))))+
                          Math.abs(Double.parseDouble(String.valueOf(other.get(i))) - Double.parseDouble(String.valueOf(other.get(j))));

                if (total < min){
                  min = total;
                  row = i;
                  row2 = j;
                }
         }
      }
     // SUM A PAIR OF MIN AND DIVIDE WITH 2
     tmp[0] = (Double.parseDouble(String.valueOf(brand.get(row))) + Double.parseDouble(String.valueOf( brand.get(row2))))/2;
     tmp[1] = (Double.parseDouble(String.valueOf(quality.get(row))) + Double.parseDouble(String.valueOf( quality.get(row2))))/2;
     tmp[2] = (Double.parseDouble(String.valueOf(save_energy.get(row))) + Double.parseDouble(String.valueOf(save_energy.get(row2))))/2;
     tmp[3] = (Double.parseDouble(String.valueOf(airpure.get(row))) + Double.parseDouble(String.valueOf(airpure.get(row2))))/2;
     tmp[4] = (Double.parseDouble(String.valueOf(quiet.get(row))) + Double.parseDouble(String.valueOf(quiet.get(row2))))/2;
     tmp[5] = (Double.parseDouble(String.valueOf(beauty.get(row))) + Double.parseDouble(String.valueOf(beauty.get(row2))))/2;
     tmp[6] = (Double.parseDouble(String.valueOf(price.get(row))) + Double.parseDouble(String.valueOf(price.get(row2))))/2;
     tmp[7] = (Double.parseDouble(String.valueOf(service.get(row))) + Double.parseDouble(String.valueOf( service.get(row2))))/2;
     tmp[8] = (Double.parseDouble(String.valueOf(other.get(row))) + Double.parseDouble(String.valueOf( other.get(row2))))/2;
     countmerge = Integer.parseInt(String.valueOf(merge.get(row))) + Integer.parseInt(String.valueOf(merge.get(row2)));

      ////////////////////////////////////////////////
      // REMOVE A PAIR OF MIN FROM LINKLIST
       brand.remove(row2);
       quality.remove(row2);
       save_energy.remove(row2);
       airpure.remove(row2);
       quiet.remove(row2);
       beauty.remove(row2);
       price.remove(row2);
       service.remove(row2);
       other.remove(row2);
       merge.remove(row2);

       brand.remove(row);
       quality.remove(row);
       save_energy.remove(row);
       airpure.remove(row);
       quiet.remove(row);
       beauty.remove(row);
       price.remove(row);
       service.remove(row);
       other.remove(row);
       merge.remove(row);
       //Add new value to LinkList
       brand.addLast(String.valueOf(tmp[0]));
       quality.addLast(String.valueOf(tmp[1]));
       save_energy.addLast(String.valueOf(tmp[2]));
       airpure.addLast(String.valueOf(tmp[3]));
       quiet.addLast(String.valueOf(tmp[4]));
       beauty.addLast(String.valueOf(tmp[5]));
       price.addLast(String.valueOf(tmp[6]));
       service.addLast(String.valueOf(tmp[7]));
       other.addLast(String.valueOf(tmp[8]));
       merge.addLast(String.valueOf(countmerge));
      }

      double output[];
      int num_merge[];
      output = new double[amount * numberOfColumns];
      output_text = new String [amount * numberOfColumns];
      num_merge = new int[amount];
      num_merge_text = new String [amount];
      int swap=0;
      double swap2=0;
      //Loop for keep value in array
    for(int m=0;m<amount;m++){
       num_merge[m] = Integer.parseInt(String.valueOf(merge.get(m)));
       output[count]  = (Math.round(((Double.parseDouble(String.valueOf(brand.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(brand.get(m))));
       output[count+1] = (Math.round(((Double.parseDouble(String.valueOf(quality.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(quality.get(m))));
       output[count+2]  = (Math.round(((Double.parseDouble(String.valueOf(save_energy.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(save_energy.get(m))));
       output[count+3]  = (Math.round(((Double.parseDouble(String.valueOf(airpure.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(airpure.get(m))));
       output[count+4]  = (Math.round(((Double.parseDouble(String.valueOf(quiet.get(m)))) * 1000) %1000)*0.001)  + Math.floor(Double.parseDouble(String.valueOf(quiet.get(m))));
       output[count+5]  = (Math.round(((Double.parseDouble(String.valueOf(beauty.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(beauty.get(m))));
       output[count+6]  = (Math.round(((Double.parseDouble(String.valueOf(price.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(price.get(m))));
       output[count+7]  = (Math.round(((Double.parseDouble(String.valueOf(service.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(service.get(m))));
       output[count+8]  = (Math.round(((Double.parseDouble(String.valueOf(other.get(m)))) * 1000) %1000)*0.001) + Math.floor(Double.parseDouble(String.valueOf(other.get(m))));
       count=count+9;
     } //end Clustering

     ////Loop for Sort Max to Min (Cluster Amount)
   for (int s=0; s<amount;s++){
      for(int n=0;n<amount;n++){
       if (n < amount - 1){
         if (num_merge[n] < num_merge[n+1]){
           swap = num_merge[n+1];
           num_merge[n+1] = num_merge[n];
           num_merge[n] = swap;
           for (int k=0; k<9; k++){
            swap2 = output[((n+1)*9)+k];
            output[((n+1)*9)+k] = output[(n*9)+k];
            output[(n*9)+k] = swap2;
           // t++;
           }
         }
         //else if (num_merge[n] == num_merge[n+1]){}
       }
      }
   }  //end Loop for Sort Max to Min (Cluster Amount)

  //Loop for convert double to string and format result in decimal notation 2 position
      count=0;
      for (int p=0; p < amount;p++){
        num_merge_text[p] = String.valueOf(num_merge[p]);
        for(int tmp=0;tmp<9;tmp++){
          output_text[count+tmp] = String.valueOf(output[count+tmp]);
          if (output_text[count+tmp].length() > 5){
            output_text[count+tmp] = output_text[count+tmp].substring(0,5);
          }
          else if (output_text[count+tmp].length() == 3){
            output_text[count+tmp]= output_text[count+tmp].concat("00");
          }
          else if (output_text[count+tmp].length() == 4){
            output_text[count+tmp]=output_text[count+tmp].concat("0");
          }
        }
        count = count+9;
      }//end Loop for convert double to string and format result in decimal notation 3 position

    } catch ( SQLException sqlException ) {
         JOptionPane.showMessageDialog( null, sqlException.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE );

         System.exit( 1 );
     }
  }

  void Button_OK_actionPerformed(ActionEvent e) {
  try{
    int amount_clus=0;

         if (Num_of_Cluster.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Please put your cluster 's number",null, JOptionPane.ERROR_MESSAGE );
         }
         else {
           amount_clus = Integer.parseInt(Num_of_Cluster.getText());

         Label_numcluster.setText(Num_of_Cluster.getText());
         clus(amount_clus);

         database1.closeConnection();
      // connect to data base
         queryExecute = new QueryExecute( driver, url);

         for (int n=0; n < amount_clus; n++){
           query = "INSERT INTO CLUSTER (AMOUNT_CLUSTER,BUY_BRAND,BUY_QUALITY,BUY_SAVE_ENERGY,BUY_AIR_PURIFY,BUY_QUIET,BUY_BEAUTY,BUY_PRICE,BUY_SERVICE,BUY_OTHER)";
           query = query+" VALUES (";
           query += num_merge_text[n] ;
           query += ",";
            for (int k=0; k<9; k++){
              query += output_text[(n*9)+k];
              if (k < 8) query += ",";
            }
          query = query + ")";
          queryExecute.setQuery(query);
         } // end for loop all row

         queryExecute.disconnectFromDatabase();
         database1.openConnection();
         queryDataSet1.refresh();
        //end if
         }//end else
    }// end try

    // detect problems interaction with the database
    catch ( SQLException sqlException ) {
      JOptionPane.showMessageDialog ( null, sqlException.getMessage(),
                                      "Database Error", JOptionPane.ERROR_MESSAGE );
      queryExecute.disconnectFromDatabase() ;
    }
    // detect problems loading database driver
    catch ( ClassNotFoundException classNotFound ) {
      JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
                                   "Driver Not Found", JOptionPane.ERROR_MESSAGE );
      System.exit( 1 );

    }
  }

  void button_delete_actionPerformed(ActionEvent e) {
    try {
                  database1.closeConnection();
                  queryExecute = new QueryExecute( driver, url);
                  query ="DELETE FROM cluster";
                  queryExecute.setQuery(query);
                  queryExecute.disconnectFromDatabase();
                  database1.openConnection();
                  queryDataSet1.refresh();
    }
                // detect problems interaction with the database
    catch ( SQLException sqlException ) {
                  JOptionPane.showMessageDialog ( null, sqlException.getMessage(),
                                                  "Database Error", JOptionPane.ERROR_MESSAGE );
                  queryExecute.disconnectFromDatabase() ;
    }
                // detect problems loading database driver
    catch ( ClassNotFoundException classNotFound ) {
                  JOptionPane.showMessageDialog( null, classNotFound.getMessage(),
                                                 "Driver Not Found", JOptionPane.ERROR_MESSAGE );
                  System.exit( 1 );
    }
  }
}








